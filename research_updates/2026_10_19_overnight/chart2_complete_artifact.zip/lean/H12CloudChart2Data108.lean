import H12CloudChart2Data107

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env26516 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,185,656,1212,32768,33830,185,262144,1025,32769,185,34324,1045,33467,537,1044,262281,184,185,35512,33437,1197,173,168,1213,512]

theorem envBound26516 : H12AffineFastState.Bounded env26516 := by
  intro p hp
  have h : env26516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26515_26516 : H12AffineEnvironment.transform 12 656 env26515 = env26516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 656 env26515 == env26516) = true)

theorem identity26516 : scanCanonicalize (H12AffineFastState.compose env26516 (packedSelected [1,3,13] rootPS)) = affineNative (2^(17+1) ^^^ 36541) := by decide +kernel

theorem selectedBound26516 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env26517 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,185,656,1212,32768,33830,185,36541,1025,32769,185,34324,1045,33467,537,1044,36404,184,185,35512,33437,1197,173,168,1213,512]

theorem envBound26517 : H12AffineFastState.Bounded env26517 := by
  intro p hp
  have h : env26517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26516_26517 : H12AffineEnvironment.transform 17 36541 env26516 = env26517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 36541 env26516 == env26517) = true)

theorem identity26517 : scanCanonicalize (H12AffineFastState.compose env26517 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 674) := by decide +kernel

theorem selectedBound26517 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env26518 : List Nat := [2,4,8,16,32,16,128,173,512,1024,674,185,656,1212,32768,33830,185,33823,1025,32769,185,34324,1045,33467,537,1044,33942,184,185,32794,33437,1197,173,168,1213,512]

theorem envBound26518 : H12AffineFastState.Bounded env26518 := by
  intro p hp
  have h : env26518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26517_26518 : H12AffineEnvironment.transform 10 674 env26517 = env26518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 674 env26517 == env26518) = true)

theorem identity26518 : scanCanonicalize (H12AffineFastState.compose env26518 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 561) := by decide +kernel

theorem selectedBound26518 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env26519 : List Nat := [2,4,8,16,32,16,128,173,512,1024,674,185,656,1212,561,1559,185,1582,1025,560,185,1061,1045,138,537,1044,1703,184,185,555,172,1197,173,168,1213,512]

theorem envBound26519 : H12AffineFastState.Bounded env26519 := by
  intro p hp
  have h : env26519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26518_26519 : H12AffineEnvironment.transform 14 561 env26518 = env26519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 561 env26518 == env26519) = true)

theorem identity26519 : scanCanonicalize (H12AffineFastState.compose env26519 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound26519 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26520 : List Nat := [2,4,8,16,32,16,35,14,512,1024,513,26,563,1055,561,1559,26,1582,1025,560,26,1061,1045,41,537,1044,1540,27,26,555,15,1038,14,11,1054,512]

theorem envBound26520 : H12AffineFastState.Bounded env26520 := by
  intro p hp
  have h : env26520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26519_26520 : H12AffineEnvironment.transform 6 35 env26519 = env26520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env26519 == env26520) = true)

theorem identity26520 : scanCanonicalize (H12AffineFastState.compose env26520 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound26520 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env26521 : List Nat := [2,4,8,10,32,10,35,14,512,1024,513,0,553,1029,555,1549,0,1582,1025,554,0,1061,1039,41,515,1038,1540,1,0,555,15,1038,14,11,1028,512]

theorem envBound26521 : H12AffineFastState.Bounded env26521 := by
  intro p hp
  have h : env26521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26520_26521 : H12AffineEnvironment.transform 3 10 env26520 = env26521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env26520 == env26521) = true)

def env26522 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61568,147473,58519,143497,20497,508075,148668,148669,96266,90263,1197,173,131088,1212,135680]

theorem envBound26522 : H12AffineFastState.Bounded env26522 := by
  intro p hp
  have h : env26522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26510_26522 : H12AffineEnvironment.transform 5 17 env26510 = env26522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env26510 == env26522) = true)

theorem identity26522 : scanCanonicalize (H12AffineFastState.compose env26522 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 208054) := by decide +kernel

theorem selectedBound26522 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env26523 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,208054,136193,32769,4096,61568,147473,58519,143497,20497,60445,148668,148669,96266,90263,1197,173,131088,1212,135680]

theorem envBound26523 : H12AffineFastState.Bounded env26523 := by
  intro p hp
  have h : env26523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26522_26523 : H12AffineEnvironment.transform 17 208054 env26522 = env26523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 208054 env26522 == env26523) = true)

theorem identity26523 : scanCanonicalize (H12AffineFastState.compose env26523 (packedSelected [1,3,5,7,8,10,20,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53282) := by decide +kernel

theorem selectedBound26523 : packedSelected [1,3,5,7,8,10,20,26,27] rootPS < 2^1333 := by decide +kernel

def env26524 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,53282,131072,195732,136193,32769,4096,61568,147473,58519,143497,20497,60445,148668,148669,43048,45237,1197,173,131088,1212,135680]

theorem envBound26524 : H12AffineFastState.Bounded env26524 := by
  intro p hp
  have h : env26524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26523_26524 : H12AffineEnvironment.transform 15 53282 env26523 = env26524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53282 env26523 == env26524) = true)

theorem identity26524 : scanCanonicalize (H12AffineFastState.compose env26524 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(16+1) ^^^ 21692) := by decide +kernel

theorem selectedBound26524 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env26525 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,53282,21692,43048,16573,32769,4096,61568,5293,58519,25653,20497,60445,4096,4097,43048,45237,1197,173,21676,1212,18108]

theorem envBound26525 : H12AffineFastState.Bounded env26525 := by
  intro p hp
  have h : env26525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26524_26525 : H12AffineEnvironment.transform 16 21692 env26524 = env26525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 21692 env26524 == env26525) = true)

theorem identity26525 : scanCanonicalize (H12AffineFastState.compose env26525 (packedSelected [4,9,20] rootPS)) = affineNative (2^(13+1) ^^^ 5124) := by decide +kernel

theorem selectedBound26525 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env26526 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,5124,32768,33830,184,43048,5305,32769,4096,42116,5293,45203,12337,1045,47129,4096,4097,43048,45237,1197,173,168,1212,4792]

theorem envBound26526 : H12AffineFastState.Bounded env26526 := by
  intro p hp
  have h : env26526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26525_26526 : H12AffineEnvironment.transform 13 5124 env26525 = env26526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5124 env26525 == env26526) = true)

theorem identity26526 : scanCanonicalize (H12AffineFastState.compose env26526 (packedSelected [0,2,3,4,5,6,11,13,16,17] rootPS)) = affineNative (2^(12+1) ^^^ 672) := by decide +kernel

theorem selectedBound26526 : packedSelected [0,2,3,4,5,6,11,13,16,17] rootPS < 2^1333 := by decide +kernel

def env26527 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,672,5124,32768,33830,184,35464,5305,32769,4096,34340,5293,37427,4753,1045,39609,4096,4097,35464,37397,1197,173,168,1212,4792]

theorem envBound26527 : H12AffineFastState.Bounded env26527 := by
  intro p hp
  have h : env26527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26526_26527 : H12AffineEnvironment.transform 12 672 env26526 = env26527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 672 env26526 == env26527) = true)

theorem identity26527 : scanCanonicalize (H12AffineFastState.compose env26527 (packedSelected [1,3,6,7,9,11,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 1174) := by decide +kernel

theorem selectedBound26527 : packedSelected [1,3,6,7,9,11,13,15] rootPS < 2^1333 := by decide +kernel

def env26528 : List Nat := [2,4,8,16,32,17,128,173,512,1024,1174,4096,672,5124,32768,33830,184,34334,5305,32769,4096,34340,5293,37427,4753,1045,38447,4096,4097,34334,37397,1197,173,168,1212,4792]

theorem envBound26528 : H12AffineFastState.Bounded env26528 := by
  intro p hp
  have h : env26528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26527_26528 : H12AffineEnvironment.transform 10 1174 env26527 = env26528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1174 env26527 == env26528) = true)

theorem identity26528 : scanCanonicalize (H12AffineFastState.compose env26528 (packedSelected [1,3,4,9,13,16] rootPS)) = affineNative (2^(14+1) ^^^ 5773) := by decide +kernel

theorem selectedBound26528 : packedSelected [1,3,4,9,13,16] rootPS < 2^1333 := by decide +kernel

def env26529 : List Nat := [2,4,8,16,32,17,128,173,512,1024,1174,4096,672,5124,5773,4779,184,4243,5305,5772,4096,4265,5293,1214,4753,1045,162,4096,4097,4243,1176,1197,173,168,1212,4792]

theorem envBound26529 : H12AffineFastState.Bounded env26529 := by
  intro p hp
  have h : env26529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26528_26529 : H12AffineEnvironment.transform 14 5773 env26528 = env26529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 5773 env26528 == env26529) = true)

theorem identity26529 : scanCanonicalize (H12AffineFastState.compose env26529 (packedSelected [1,4,6,7,8,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 1686) := by decide +kernel

theorem selectedBound26529 : packedSelected [1,4,6,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env26530 : List Nat := [2,4,8,16,32,17,128,173,512,1024,1174,1686,672,658,27,1085,184,1541,559,26,1686,1599,571,1214,1031,1045,162,1686,1687,1541,1176,1197,173,168,1212,1070]

theorem envBound26530 : H12AffineFastState.Bounded env26530 := by
  intro p hp
  have h : env26530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26529_26530 : H12AffineEnvironment.transform 11 1686 env26529 = env26530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1686 env26529 == env26530) = true)

theorem identity26530 : scanCanonicalize (H12AffineFastState.compose env26530 (packedSelected [2,3,4,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound26530 : packedSelected [2,3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env26531 : List Nat := [2,4,8,16,32,17,128,173,512,517,659,147,672,658,27,568,184,0,559,26,147,58,571,699,514,528,162,147,146,0,669,680,173,168,697,555]

theorem envBound26531 : H12AffineFastState.Bounded env26531 := by
  intro p hp
  have h : env26531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26530_26531 : H12AffineEnvironment.transform 9 517 env26530 = env26531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env26530 == env26531) = true)

theorem identity26531 : scanCanonicalize (H12AffineFastState.compose env26531 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 163) := by decide +kernel

theorem selectedBound26531 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26532 : List Nat := [2,4,8,16,32,17,128,173,163,166,48,147,3,49,27,155,184,0,140,26,147,58,152,24,161,179,162,147,146,0,62,11,173,168,26,136]

theorem envBound26532 : H12AffineFastState.Bounded env26532 := by
  intro p hp
  have h : env26532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26531_26532 : H12AffineEnvironment.transform 8 163 env26531 = env26532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 163 env26531 == env26532) = true)

theorem identity26532 : scanCanonicalize (H12AffineFastState.compose env26532 (packedSelected [1,3,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound26532 : packedSelected [1,3,6] rootPS < 2^1333 := by decide +kernel

def env26533 : List Nat := [2,4,8,16,32,17,9,36,42,47,48,26,3,49,27,18,49,0,5,26,26,58,17,24,40,58,43,26,27,0,62,11,36,33,26,1]

theorem envBound26533 : H12AffineFastState.Bounded env26533 := by
  intro p hp
  have h : env26533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26532_26533 : H12AffineEnvironment.transform 6 9 env26532 = env26533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env26532 == env26533) = true)

theorem identity26533 : scanCanonicalize (H12AffineFastState.compose env26533 (packedSelected [3,5] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound26533 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env26534 : List Nat := [2,4,8,10,32,11,9,36,42,47,42,0,3,43,1,8,43,0,5,0,0,32,11,2,40,32,43,0,1,0,36,11,36,33,0,1]

theorem envBound26534 : H12AffineFastState.Bounded env26534 := by
  intro p hp
  have h : env26534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26533_26534 : H12AffineEnvironment.transform 3 10 env26533 = env26534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env26533 == env26534) = true)

theorem identity26534 : scanCanonicalize (H12AffineFastState.compose env26534 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound26534 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26535 : List Nat := [2,4,8,10,12,11,9,8,6,3,6,0,3,7,1,8,7,0,5,0,0,12,11,2,4,12,7,0,1,0,8,11,8,13,0,1]

theorem envBound26535 : H12AffineFastState.Bounded env26535 := by
  intro p hp
  have h : env26535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26534_26535 : H12AffineEnvironment.transform 4 12 env26534 = env26535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env26534 == env26535) = true)

theorem identity26535 : scanCanonicalize (H12AffineFastState.compose env26535 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound26535 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env26536 : List Nat := [2,2,8,10,10,11,9,8,0,3,0,0,3,1,1,8,1,0,3,0,0,10,11,2,2,10,1,0,1,0,8,11,8,11,0,1]

theorem envBound26536 : H12AffineFastState.Bounded env26536 := by
  intro p hp
  have h : env26536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26535_26536 : H12AffineEnvironment.transform 1 2 env26535 = env26536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env26535 == env26536) = true)

theorem identity26536 : scanCanonicalize (H12AffineFastState.compose env26536 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound26536 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26537 : List Nat := [2,2,0,2,2,3,1,0,0,3,0,0,3,1,1,0,1,0,3,0,0,2,3,2,2,2,1,0,1,0,0,3,0,3,0,1]

theorem envBound26537 : H12AffineFastState.Bounded env26537 := by
  intro p hp
  have h : env26537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26536_26537 : H12AffineEnvironment.transform 2 0 env26536 = env26537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env26536 == env26537) = true)

theorem identity26537 : scanCanonicalize (H12AffineFastState.compose env26537 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound26537 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env26538 : List Nat := [1,1,0,1,1,0,1,0,0,0,0,0,0,1,1,0,1,0,0,0,0,1,0,1,1,1,1,0,1,0,0,0,0,0,0,1]

theorem envBound26538 : H12AffineFastState.Bounded env26538 := by
  intro p hp
  have h : env26538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26537_26538 : H12AffineEnvironment.transform 0 1 env26537 = env26538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env26537 == env26538) = true)

def env26539 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,16777216,533640,672784,17245633,148800,545088,96347,16876544,17495099,256,131137,1345,525825]

theorem envBound26539 : H12AffineFastState.Bounded env26539 := by
  intro p hp
  have h : env26539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26415_26539 : H12AffineEnvironment.transform 26 17245633 env26415 = env26539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245633 env26415 == env26539) = true)

theorem identity26539 : scanCanonicalize (H12AffineFastState.compose env26539 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 41002) := by decide +kernel

theorem selectedBound26539 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env26540 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,41002,533640,672784,493035,148800,545088,96347,74794,676881,256,131137,1345,525825]

theorem envBound26540 : H12AffineFastState.Bounded env26540 := by
  intro p hp
  have h : env26540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26539_26540 : H12AffineEnvironment.transform 23 41002 env26539 = env26540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41002 env26539 == env26540) = true)

def env26541 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147520,41002,143496,20496,493035,148800,148800,96347,74794,16401,256,131137,1345,135681]

theorem envBound26541 : H12AffineFastState.Bounded env26541 := by
  intro p hp
  have h : env26541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26540_26541 : H12AffineEnvironment.transform 18 136192 env26540 = env26541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136192 env26540 == env26541) = true)

def env26542 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147520,41002,143496,20496,492615,148716,148716,96347,74794,16401,172,131137,1261,135681]

theorem envBound26542 : H12AffineFastState.Bounded env26542 := by
  intro p hp
  have h : env26542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26541_26542 : H12AffineEnvironment.transform 7 172 env26541 = env26542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env26541 == env26542) = true)

def env26543 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61569,147472,41002,143496,20496,492567,148668,148668,96267,74794,16401,172,131089,1213,135681]

theorem envBound26543 : H12AffineFastState.Bounded env26543 := by
  intro p hp
  have h : env26543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26542_26543 : H12AffineEnvironment.transform 5 16 env26542 = env26543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env26542 == env26543) = true)

theorem identity26543 : scanCanonicalize (H12AffineFastState.compose env26543 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 137352) := by decide +kernel

theorem selectedBound26543 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env26544 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,137352,136192,32769,4096,61569,147472,41002,143496,20496,105631,148668,148668,96267,74794,16401,172,131089,1213,135681]

theorem envBound26544 : H12AffineFastState.Bounded env26544 := by
  intro p hp
  have h : env26544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26543_26544 : H12AffineEnvironment.transform 17 137352 env26543 = env26544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137352 env26543 == env26544) = true)

theorem identity26544 : scanCanonicalize (H12AffineFastState.compose env26544 (packedSelected [1,5,8,18,19,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 13375) := by decide +kernel

theorem selectedBound26544 : packedSelected [1,5,8,18,19,23,24,26] rootPS < 2^1333 := by decide +kernel

def env26545 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,13375,131072,137352,136192,32769,4096,61569,147472,41002,143496,20496,43168,148668,148668,19508,4117,16401,172,131089,1213,135681]

theorem envBound26545 : H12AffineFastState.Bounded env26545 := by
  intro p hp
  have h : env26545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26544_26545 : H12AffineEnvironment.transform 15 13375 env26544 = env26545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13375 env26544 == env26545) = true)

theorem identity26545 : scanCanonicalize (H12AffineFastState.compose env26545 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound26545 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env26546 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1213,32768,13375,131072,137352,136192,32769,4096,46140,132269,41002,143496,5293,43168,131073,131073,2185,4117,1196,172,131089,1213,135681]

theorem envBound26546 : H12AffineFastState.Bounded env26546 := by
  intro p hp
  have h : env26546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26545_26546 : H12AffineEnvironment.transform 13 1213 env26545 = env26546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env26545 == env26546) = true)

theorem identity26546 : scanCanonicalize (H12AffineFastState.compose env26546 (packedSelected [13,17] rootPS)) = affineNative (2^(14+1) ^^^ 9381) := by decide +kernel

theorem selectedBound26546 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env26547 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1213,9381,13375,131072,137352,136192,9380,4096,4249,132269,1167,143496,5293,3077,131073,131073,2185,4117,1196,172,131089,1213,135681]

theorem envBound26547 : H12AffineFastState.Bounded env26547 := by
  intro p hp
  have h : env26547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26546_26547 : H12AffineEnvironment.transform 14 9381 env26546 = env26547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9381 env26546 == env26547) = true)

theorem identity26547 : scanCanonicalize (H12AffineFastState.compose env26547 (packedSelected [6,12,13,15] rootPS)) = affineNative (2^(16+1) ^^^ 5125) := by decide +kernel

theorem selectedBound26547 : packedSelected [6,12,13,15] rootPS < 2^1333 := by decide +kernel

def env26548 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1213,9381,13375,5125,3213,5,9380,4096,4249,4264,1167,9357,5293,3077,5124,5124,2185,4117,1196,172,5140,1213,1540]

theorem envBound26548 : H12AffineFastState.Bounded env26548 := by
  intro p hp
  have h : env26548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26547_26548 : H12AffineEnvironment.transform 16 5125 env26547 = env26548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5125 env26547 == env26548) = true)

theorem identity26548 : scanCanonicalize (H12AffineFastState.compose env26548 (packedSelected [2,3,6,7,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 7311) := by decide +kernel

theorem selectedBound26548 : packedSelected [2,3,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env26549 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,7311,1213,6186,2224,5125,3213,5,6187,4096,4249,4264,1167,6146,5293,3077,5124,5124,2185,4117,1196,172,5140,1213,1540]

theorem envBound26549 : H12AffineFastState.Bounded env26549 := by
  intro p hp
  have h : env26549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26548_26549 : H12AffineEnvironment.transform 12 7311 env26548 = env26549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7311 env26548 == env26549) = true)

theorem identity26549 : scanCanonicalize (H12AffineFastState.compose env26549 (packedSelected [0,3,5,7,10] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound26549 : packedSelected [0,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env26550 : List Nat := [2,4,8,16,32,16,18,62,512,1024,2048,4096,7197,1071,6186,2082,5125,3103,5,6187,4096,4107,4154,1053,6146,5183,3077,5124,5124,2075,4117,1086,62,5140,1071,1540]

theorem envBound26550 : H12AffineFastState.Bounded env26550 := by
  intro p hp
  have h : env26550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26549_26550 : H12AffineEnvironment.transform 6 18 env26549 = env26550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env26549 == env26550) = true)

theorem identity26550 : scanCanonicalize (H12AffineFastState.compose env26550 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 1583) := by decide +kernel

theorem selectedBound26550 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env26551 : List Nat := [2,4,8,16,32,16,18,62,512,1024,2048,1583,2610,1071,3589,2082,554,3103,5,3588,1583,1572,1557,1053,3629,528,3077,555,555,2075,1594,1086,62,571,1071,1540]

theorem envBound26551 : H12AffineFastState.Bounded env26551 := by
  intro p hp
  have h : env26551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26550_26551 : H12AffineEnvironment.transform 11 1583 env26550 = env26551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1583 env26550 == env26551) = true)

theorem identity26551 : scanCanonicalize (H12AffineFastState.compose env26551 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound26551 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env26552 : List Nat := [2,4,8,16,32,16,18,62,512,1024,43,1583,537,1071,1582,9,554,1076,5,1583,1583,1572,1557,1053,1542,528,1070,555,555,48,1594,1086,62,571,1071,1540]

theorem envBound26552 : H12AffineFastState.Bounded env26552 := by
  intro p hp
  have h : env26552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26551_26552 : H12AffineEnvironment.transform 10 43 env26551 = env26552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env26551 == env26552) = true)

theorem identity26552 : scanCanonicalize (H12AffineFastState.compose env26552 (packedSelected [0,1,2,4,5,11] rootPS)) = affineNative (2^(9+1) ^^^ 542) := by decide +kernel

theorem selectedBound26552 : packedSelected [0,1,2,4,5,11] rootPS < 2^1333 := by decide +kernel

def env26553 : List Nat := [2,4,8,16,32,16,18,62,512,542,43,49,537,561,48,9,554,554,5,49,49,58,11,515,24,528,560,555,555,48,36,544,62,571,561,26]

theorem envBound26553 : H12AffineFastState.Bounded env26553 := by
  intro p hp
  have h : env26553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26552_26553 : H12AffineEnvironment.transform 9 542 env26552 = env26553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 542 env26552 == env26553) = true)

theorem identity26553 : scanCanonicalize (H12AffineFastState.compose env26553 (packedSelected [1,2,5] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound26553 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env26554 : List Nat := [2,4,8,16,32,16,18,62,27,5,43,49,2,42,48,9,49,49,5,49,49,58,11,24,24,11,43,48,48,48,36,59,62,32,42,26]

theorem envBound26554 : H12AffineFastState.Bounded env26554 := by
  intro p hp
  have h : env26554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26553_26554 : H12AffineEnvironment.transform 8 27 env26553 = env26554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env26553 == env26554) = true)

theorem identity26554 : scanCanonicalize (H12AffineFastState.compose env26554 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 24) := by decide +kernel

theorem selectedBound26554 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env26555 : List Nat := [2,4,8,16,24,16,18,6,27,5,19,9,2,18,8,9,9,9,5,9,9,2,11,24,24,11,19,8,8,8,28,3,6,24,18,26]

theorem envBound26555 : H12AffineFastState.Bounded env26555 := by
  intro p hp
  have h : env26555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26554_26555 : H12AffineEnvironment.transform 4 24 env26554 = env26555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 24 env26554 == env26555) = true)

def env26556 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61568,147473,41002,143496,20496,492566,148669,148669,96266,74794,16401,172,131088,1212,135681]

theorem envBound26556 : H12AffineFastState.Bounded env26556 := by
  intro p hp
  have h : env26556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26542_26556 : H12AffineEnvironment.transform 5 17 env26542 = env26556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env26542 == env26556) = true)

theorem identity26556 : scanCanonicalize (H12AffineFastState.compose env26556 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 45216) := by decide +kernel

theorem selectedBound26556 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env26557 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,45216,262144,42144,32769,4096,61568,61617,41002,32808,20496,341174,62493,62493,96266,74794,16401,172,45232,1212,41633]

theorem envBound26557 : H12AffineFastState.Bounded env26557 := by
  intro p hp
  have h : env26557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26556_26557 : H12AffineEnvironment.transform 16 45216 env26556 = env26557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45216 env26556 == env26557) = true)

theorem identity26557 : scanCanonicalize (H12AffineFastState.compose env26557 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound26557 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env26558 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1213,32768,65536,45216,262144,42144,32769,4096,46141,46092,41002,32808,5293,341174,45216,45216,81079,74794,1196,172,45232,1212,41633]

theorem envBound26558 : H12AffineFastState.Bounded env26558 := by
  intro p hp
  have h : env26558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26557_26558 : H12AffineEnvironment.transform 13 1213 env26557 = env26558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env26557 == env26558) = true)

theorem identity26558 : scanCanonicalize (H12AffineFastState.compose env26558 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 33831) := by decide +kernel

theorem selectedBound26558 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env26559 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1213,32768,33831,45216,262144,42144,32769,4096,46141,46092,41002,32808,5293,307345,45216,45216,47248,40973,1196,172,45232,1212,41633]

theorem envBound26559 : H12AffineFastState.Bounded env26559 := by
  intro p hp
  have h : env26559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26558_26559 : H12AffineEnvironment.transform 15 33831 env26558 = env26559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33831 env26558 == env26559) = true)

theorem identity26559 : scanCanonicalize (H12AffineFastState.compose env26559 (packedSelected [4,9,20] rootPS)) = affineNative (2^(11+1) ^^^ 185) := by decide +kernel

theorem selectedBound26559 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env26560 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,185,8192,1213,32768,33831,40985,262144,42144,32769,185,42116,42165,41002,32808,1044,303144,40985,40985,43049,40973,1196,172,40969,1212,41633]

theorem envBound26560 : H12AffineFastState.Bounded env26560 := by
  intro p hp
  have h : env26560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26559_26560 : H12AffineEnvironment.transform 11 185 env26559 = env26560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 185 env26559 == env26560) = true)

theorem identity26560 : scanCanonicalize (H12AffineFastState.compose env26560 (packedSelected [1,3,5,6,8,13] rootPS)) = affineNative (2^(17+1) ^^^ 2184) := by decide +kernel

theorem selectedBound26560 : packedSelected [1,3,5,6,8,13] rootPS < 2^1333 := by decide +kernel

def env26561 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,185,8192,1213,32768,33831,40985,2184,42144,32769,185,42116,42165,41002,32808,1044,43168,40985,40985,43049,40973,1196,172,40969,1212,41633]

theorem envBound26561 : H12AffineFastState.Bounded env26561 := by
  intro p hp
  have h : env26561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26560_26561 : H12AffineEnvironment.transform 17 2184 env26560 = env26561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2184 env26560 == env26561) = true)

theorem identity26561 : scanCanonicalize (H12AffineFastState.compose env26561 (packedSelected [0,3,5,7,10] rootPS)) = affineNative (2^(12+1) ^^^ 3237) := by decide +kernel

theorem selectedBound26561 : packedSelected [0,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env26562 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,185,3237,1213,32768,33831,36028,2184,34821,32769,185,34849,34832,35983,32808,1044,33797,36028,36028,33932,36008,1196,172,36012,1212,36356]

theorem envBound26562 : H12AffineFastState.Bounded env26562 := by
  intro p hp
  have h : env26562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26561_26562 : H12AffineEnvironment.transform 12 3237 env26561 = env26562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3237 env26561 == env26562) = true)

theorem identity26562 : scanCanonicalize (H12AffineFastState.compose env26562 (packedSelected [1,2,4,5,6,9] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound26562 : packedSelected [1,2,4,5,6,9] rootPS < 2^1333 := by decide +kernel

def env26563 : List Nat := [2,4,8,16,32,17,128,172,27,1024,2048,185,3237,1213,32768,33831,36028,2184,34821,32769,185,34849,34832,35983,32808,1044,33797,36028,36028,33932,36008,1196,172,36012,1212,35871]

theorem envBound26563 : H12AffineFastState.Bounded env26563 := by
  intro p hp
  have h : env26563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26562_26563 : H12AffineEnvironment.transform 8 27 env26562 = env26563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env26562 == env26563) = true)

theorem identity26563 : scanCanonicalize (H12AffineFastState.compose env26563 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 1070) := by decide +kernel

theorem selectedBound26563 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env26564 : List Nat := [2,4,8,16,32,17,128,172,27,1024,1070,185,139,1213,32768,33831,32914,1190,33835,32769,185,33807,33854,32929,32808,1044,33797,32914,32914,33932,32902,1196,172,32898,1212,32817]

theorem envBound26564 : H12AffineFastState.Bounded env26564 := by
  intro p hp
  have h : env26564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26563_26564 : H12AffineEnvironment.transform 10 1070 env26563 = env26564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1070 env26563 == env26564) = true)

theorem identity26564 : scanCanonicalize (H12AffineFastState.compose env26564 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound26564 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env26565 : List Nat := [2,4,8,16,32,17,8,36,27,1024,1070,49,3,1077,32768,33831,32794,1070,33835,32769,49,33807,33854,32809,32808,1044,33797,32794,32794,33796,32782,1060,36,32778,1076,32817]

theorem envBound26565 : H12AffineFastState.Bounded env26565 := by
  intro p hp
  have h : env26565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26564_26565 : H12AffineEnvironment.transform 6 8 env26564 = env26565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env26564 == env26565) = true)

theorem identity26565 : scanCanonicalize (H12AffineFastState.compose env26565 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(14+1) ^^^ 1077) := by decide +kernel

theorem selectedBound26565 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env26566 : List Nat := [2,4,8,16,32,17,8,36,27,1024,1070,49,3,1077,1077,18,1071,1070,30,1076,49,58,11,1052,1053,1044,48,1071,1071,49,1083,1060,36,1087,1076,1028]

theorem envBound26566 : H12AffineFastState.Bounded env26566 := by
  intro p hp
  have h : env26566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26565_26566 : H12AffineEnvironment.transform 14 1077 env26565 = env26566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1077 env26565 == env26566) = true)

theorem identity26566 : scanCanonicalize (H12AffineFastState.compose env26566 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound26566 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env26567 : List Nat := [2,4,8,11,32,10,8,36,0,1024,1070,42,3,1070,1070,9,1071,1070,5,1071,42,33,11,1031,1030,1039,43,1071,1071,42,1056,1060,36,1060,1071,1028]

theorem envBound26567 : H12AffineFastState.Bounded env26567 := by
  intro p hp
  have h : env26567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26566_26567 : H12AffineEnvironment.transform 3 11 env26566 = env26567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env26566 == env26567) = true)

def env26568 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147520,41002,143496,20496,492614,148717,148717,96347,74794,16401,173,131137,1260,135681]

theorem envBound26568 : H12AffineFastState.Bounded env26568 := by
  intro p hp
  have h : env26568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26541_26568 : H12AffineEnvironment.transform 7 173 env26541 = env26568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env26541 == env26568) = true)

def env26569 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61569,147472,41002,143496,20496,492566,148669,148669,96267,74794,16401,173,131089,1212,135681]

theorem envBound26569 : H12AffineFastState.Bounded env26569 := by
  intro p hp
  have h : env26569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26568_26569 : H12AffineEnvironment.transform 5 16 env26568 = env26569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env26568 == env26569) = true)

theorem identity26569 : scanCanonicalize (H12AffineFastState.compose env26569 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 223243) := by decide +kernel

theorem selectedBound26569 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env26570 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,223243,136192,32769,4096,61569,147472,41002,143496,20496,60445,148669,148669,96267,74794,16401,173,131089,1212,135681]

theorem envBound26570 : H12AffineFastState.Bounded env26570 := by
  intro p hp
  have h : env26570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26569_26570 : H12AffineEnvironment.transform 17 223243 env26569 = env26570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223243 env26569 == env26570) = true)

theorem identity26570 : scanCanonicalize (H12AffineFastState.compose env26570 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 28802) := by decide +kernel

theorem selectedBound26570 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env26571 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,28802,131072,137353,136192,32769,4096,61569,147472,41002,143496,20496,60445,148669,148669,2185,21672,16401,173,131089,1212,135681]

theorem envBound26571 : H12AffineFastState.Bounded env26571 := by
  intro p hp
  have h : env26571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26570_26571 : H12AffineEnvironment.transform 15 28802 env26570 = env26571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28802 env26570 == env26571) = true)

theorem identity26571 : scanCanonicalize (H12AffineFastState.compose env26571 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(14+1) ^^^ 12313) := by decide +kernel

theorem selectedBound26571 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env26572 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,12313,28802,131072,137353,136192,12312,4096,16536,147472,4147,143496,20496,23556,148669,148669,2185,21672,16401,173,131089,1212,135681]

theorem envBound26572 : H12AffineFastState.Bounded env26572 := by
  intro p hp
  have h : env26572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26571_26572 : H12AffineEnvironment.transform 14 12313 env26571 = env26572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12313 env26571 == env26572) = true)

theorem identity26572 : scanCanonicalize (H12AffineFastState.compose env26572 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound26572 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env26573 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1212,12313,13374,131072,137353,136192,12312,4096,1060,132268,4147,143496,5292,6328,131073,131073,2185,4116,1197,173,131089,1212,135681]

theorem envBound26573 : H12AffineFastState.Bounded env26573 := by
  intro p hp
  have h : env26573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26572_26573 : H12AffineEnvironment.transform 13 1212 env26572 = env26573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env26572 == env26573) = true)

theorem identity26573 : scanCanonicalize (H12AffineFastState.compose env26573 (packedSelected [0,4,5,7,8,9,10,13] rootPS)) = affineNative (2^(16+1) ^^^ 10378) := by decide +kernel

theorem selectedBound26573 : packedSelected [0,4,5,7,8,9,10,13] rootPS < 2^1333 := by decide +kernel

def env26574 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1212,12313,13374,10378,12291,15498,12312,4096,1060,11302,4147,6146,5292,6328,10379,10379,2185,4116,1197,173,10395,1212,14987]

theorem envBound26574 : H12AffineFastState.Bounded env26574 := by
  intro p hp
  have h : env26574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26573_26574 : H12AffineEnvironment.transform 16 10378 env26573 = env26574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 10378 env26573 == env26574) = true)

theorem identity26574 : scanCanonicalize (H12AffineFastState.compose env26574 (packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 7311) := by decide +kernel

theorem selectedBound26574 : packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env26575 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,7311,1212,3222,2225,5125,3212,5,3223,4096,1060,4265,4147,6146,5292,6328,5124,5124,2185,4116,1197,173,5140,1212,1540]

theorem envBound26575 : H12AffineFastState.Bounded env26575 := by
  intro p hp
  have h : env26575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26574_26575 : H12AffineEnvironment.transform 12 7311 env26574 = env26575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7311 env26574 == env26575) = true)

theorem identity26575 : scanCanonicalize (H12AffineFastState.compose env26575 (packedSelected [1,2,3,4,6,9,10,11,16] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound26575 : packedSelected [1,2,3,4,6,9,10,11,16] rootPS < 2^1333 := by decide +kernel

def env26576 : List Nat := [2,4,8,16,32,16,128,173,1,1024,2048,4096,7311,1212,3222,2225,5125,3212,5,3223,4096,1060,4265,4147,6146,5292,6328,5124,5124,2185,4116,1197,173,5140,1212,1029]

theorem envBound26576 : H12AffineFastState.Bounded env26576 := by
  intro p hp
  have h : env26576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26575_26576 : H12AffineEnvironment.transform 8 1 env26575 = env26576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env26575 == env26576) = true)

theorem identity26576 : scanCanonicalize (H12AffineFastState.compose env26576 (packedSelected [1,2,3,5,6,8,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 163) := by decide +kernel

theorem selectedBound26576 : packedSelected [1,2,3,5,6,8,10,11] rootPS < 2^1333 := by decide +kernel

def env26577 : List Nat := [2,4,8,16,32,16,128,173,1,1024,163,4096,5164,1212,1077,18,5125,1071,5,1076,4096,1060,4265,4147,4257,5292,4123,5124,5124,42,4116,1197,173,5140,1212,1029]

theorem envBound26577 : H12AffineFastState.Bounded env26577 := by
  intro p hp
  have h : env26577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26576_26577 : H12AffineEnvironment.transform 10 163 env26576 = env26577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 163 env26576 == env26577) = true)

theorem identity26577 : scanCanonicalize (H12AffineFastState.compose env26577 (packedSelected [1,5] rootPS)) = affineNative (2^(11+1) ^^^ 1213) := by decide +kernel

theorem selectedBound26577 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env26578 : List Nat := [2,4,8,16,32,16,128,173,1,1024,163,1213,145,1212,1077,18,184,1071,5,1076,1213,1060,1044,1166,1052,17,1190,185,185,42,1193,1197,173,169,1212,1029]

theorem envBound26578 : H12AffineFastState.Bounded env26578 := by
  intro p hp
  have h : env26578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26577_26578 : H12AffineEnvironment.transform 11 1213 env26577 = env26578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1213 env26577 == env26578) = true)

theorem identity26578 : scanCanonicalize (H12AffineFastState.compose env26578 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(9+1) ^^^ 154) := by decide +kernel

theorem selectedBound26578 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env26579 : List Nat := [2,4,8,16,32,16,128,173,1,154,163,39,145,38,175,18,184,181,5,174,39,190,142,20,134,17,60,185,185,42,51,55,173,169,38,159]

theorem envBound26579 : H12AffineFastState.Bounded env26579 := by
  intro p hp
  have h : env26579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26578_26579 : H12AffineEnvironment.transform 9 154 env26578 = env26579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 154 env26578 == env26579) = true)

theorem identity26579 : scanCanonicalize (H12AffineFastState.compose env26579 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound26579 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env26580 : List Nat := [2,4,4,16,32,16,128,161,1,150,163,39,145,38,163,18,180,181,5,162,39,178,130,20,134,17,48,181,181,38,51,55,161,165,38,147]

theorem envBound26580 : H12AffineFastState.Bounded env26580 := by
  intro p hp
  have h : env26580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26579_26580 : H12AffineEnvironment.transform 2 4 env26579 = env26580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env26579 == env26580) = true)

theorem identity26580 : scanCanonicalize (H12AffineFastState.compose env26580 (packedSelected [0,2,3,7] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound26580 : packedSelected [0,2,3,7] rootPS < 2^1333 := by decide +kernel

def env26581 : List Nat := [2,4,4,16,32,16,19,50,1,5,48,39,2,38,48,18,39,38,5,49,39,33,17,20,21,17,48,38,38,38,51,55,50,54,38,0]

theorem envBound26581 : H12AffineFastState.Bounded env26581 := by
  intro p hp
  have h : env26581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26580_26581 : H12AffineEnvironment.transform 6 19 env26580 = env26581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env26580 == env26581) = true)

theorem identity26581 : scanCanonicalize (H12AffineFastState.compose env26581 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound26581 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26582 : List Nat := [2,4,4,5,32,5,6,39,1,5,37,39,2,38,37,7,39,38,5,36,39,33,4,1,0,4,37,38,38,38,38,34,39,35,38,0]

theorem envBound26582 : H12AffineFastState.Bounded env26582 := by
  intro p hp
  have h : env26582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26581_26582 : H12AffineEnvironment.transform 3 5 env26581 = env26582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env26581 == env26582) = true)

theorem identity26582 : scanCanonicalize (H12AffineFastState.compose env26582 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound26582 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26583 : List Nat := [2,4,4,5,3,5,6,4,1,5,6,4,2,5,6,7,4,5,5,7,4,2,4,1,0,4,6,5,5,5,5,1,4,0,5,0]

theorem envBound26583 : H12AffineFastState.Bounded env26583 := by
  intro p hp
  have h : env26583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26582_26583 : H12AffineEnvironment.transform 4 3 env26582 = env26583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env26582 == env26583) = true)

theorem identity26583 : scanCanonicalize (H12AffineFastState.compose env26583 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound26583 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26584 : List Nat := [2,3,3,2,3,2,1,3,1,2,1,3,2,2,1,0,3,2,2,0,3,2,3,1,0,3,1,2,2,2,2,1,3,0,2,0]

theorem envBound26584 : H12AffineFastState.Bounded env26584 := by
  intro p hp
  have h : env26584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26583_26584 : H12AffineEnvironment.transform 1 3 env26583 = env26584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env26583 == env26584) = true)

theorem identity26584 : scanCanonicalize (H12AffineFastState.compose env26584 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound26584 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env26585 : List Nat := [1,0,0,1,0,1,1,0,1,1,1,0,1,1,1,0,0,1,1,0,0,1,0,1,0,0,1,1,1,1,1,1,0,0,1,0]

theorem envBound26585 : H12AffineFastState.Bounded env26585 := by
  intro p hp
  have h : env26585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26584_26585 : H12AffineEnvironment.transform 0 1 env26584 = env26585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env26584 == env26585) = true)

def env26586 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61568,147473,41002,143496,20496,492567,148668,148668,96266,74794,16401,173,131088,1213,135681]

theorem envBound26586 : H12AffineFastState.Bounded env26586 := by
  intro p hp
  have h : env26586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26568_26586 : H12AffineEnvironment.transform 5 17 env26568 = env26586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env26568 == env26586) = true)

theorem identity26586 : scanCanonicalize (H12AffineFastState.compose env26586 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 114722) := by decide +kernel

theorem selectedBound26586 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env26587 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,114722,262144,119842,32769,4096,61568,98355,41002,127146,20496,279605,99486,99486,96266,74794,16401,173,114738,1213,119331]

theorem envBound26587 : H12AffineFastState.Bounded env26587 := by
  intro p hp
  have h : env26587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26586_26587 : H12AffineEnvironment.transform 16 114722 env26586 = env26587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114722 env26586 == env26587) = true)

theorem identity26587 : scanCanonicalize (H12AffineFastState.compose env26587 (packedSelected [3,10,16,18,19,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 92339) := by decide +kernel

theorem selectedBound26587 : packedSelected [3,10,16,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env26588 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,114722,92339,119842,32769,4096,61568,98355,41002,127146,20496,76934,99486,99486,96266,74794,16401,173,114738,1213,119331]

theorem envBound26588 : H12AffineFastState.Bounded env26588 := by
  intro p hp
  have h : env26588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26587_26588 : H12AffineEnvironment.transform 17 92339 env26587 = env26588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 92339 env26587 == env26588) = true)

theorem identity26588 : scanCanonicalize (H12AffineFastState.compose env26588 (packedSelected [7,16,18,19,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53283) := by decide +kernel

theorem selectedBound26588 : packedSelected [7,16,18,19,23,26,27] rootPS < 2^1333 := by decide +kernel

def env26589 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,53283,4097,47248,1025,32769,4096,61568,20496,41002,8329,20496,64677,21693,21693,43049,62473,16401,173,4113,1213,512]

theorem envBound26589 : H12AffineFastState.Bounded env26589 := by
  intro p hp
  have h : env26589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26588_26589 : H12AffineEnvironment.transform 15 53283 env26588 = env26589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53283 env26588 == env26589) = true)

theorem identity26589 : scanCanonicalize (H12AffineFastState.compose env26589 (packedSelected [4,9,16] rootPS)) = affineNative (2^(13+1) ^^^ 5124) := by decide +kernel

theorem selectedBound26589 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env26590 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,5124,32768,33831,4097,47248,1025,32769,4096,42116,1044,41002,8329,1044,43169,185,185,43049,40973,5141,173,4113,1213,512]

theorem envBound26590 : H12AffineFastState.Bounded env26590 := by
  intro p hp
  have h : env26590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26589_26590 : H12AffineEnvironment.transform 13 5124 env26589 = env26590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5124 env26589 == env26590) = true)

theorem identity26590 : scanCanonicalize (H12AffineFastState.compose env26590 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 5772) := by decide +kernel

theorem selectedBound26590 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env26591 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,5124,5772,4779,4097,11804,1025,5773,4096,12808,1044,13990,8329,1044,15917,185,185,16037,13953,5141,173,4113,1213,512]

theorem envBound26591 : H12AffineFastState.Bounded env26591 := by
  intro p hp
  have h : env26591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26590_26591 : H12AffineEnvironment.transform 14 5772 env26590 = env26591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 5772 env26590 == env26591) = true)

theorem identity26591 : scanCanonicalize (H12AffineFastState.compose env26591 (packedSelected [0,3,4,8,13] rootPS)) = affineNative (2^(12+1) ^^^ 1166) := by decide +kernel

theorem selectedBound26591 : packedSelected [0,3,4,8,13] rootPS < 2^1333 := by decide +kernel

def env26592 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,1166,5124,5772,4779,4097,2706,1025,5773,4096,5766,1044,4648,1031,1044,6819,185,185,6699,4623,5141,173,4113,1213,512]

theorem envBound26592 : H12AffineFastState.Bounded env26592 := by
  intro p hp
  have h : env26592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26591_26592 : H12AffineEnvironment.transform 12 1166 env26591 = env26592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1166 env26591 == env26592) = true)

theorem identity26592 : scanCanonicalize (H12AffineFastState.compose env26592 (packedSelected [2,4,5,8,9,11,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 3615) := by decide +kernel

theorem selectedBound26592 : packedSelected [2,4,5,8,9,11,12,15] rootPS < 2^1333 := by decide +kernel

def env26593 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,3615,1166,2587,2195,3252,3614,2706,1025,2194,3615,2201,1044,3127,1031,1044,1212,185,185,1076,3088,2570,173,3598,1213,512]

theorem envBound26593 : H12AffineFastState.Bounded env26593 := by
  intro p hp
  have h : env26593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26592_26593 : H12AffineEnvironment.transform 11 3615 env26592 = env26593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3615 env26592 == env26593) = true)

theorem identity26593 : scanCanonicalize (H12AffineFastState.compose env26593 (packedSelected [0,3,4,5,7,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound26593 : packedSelected [0,3,4,5,7,9,11] rootPS < 2^1333 := by decide +kernel

def env26594 : List Nat := [2,4,8,16,32,17,128,173,512,1024,42,1589,1166,561,185,1182,1588,696,1025,184,1589,179,1044,1053,1031,1044,1212,185,185,1076,1082,544,173,1572,1213,512]

theorem envBound26594 : H12AffineFastState.Bounded env26594 := by
  intro p hp
  have h : env26594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26593_26594 : H12AffineEnvironment.transform 10 42 env26593 = env26594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env26593 == env26594) = true)

theorem identity26594 : scanCanonicalize (H12AffineFastState.compose env26594 (packedSelected [1,3,4,5,6,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 141) := by decide +kernel

theorem selectedBound26594 : packedSelected [1,3,4,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env26595 : List Nat := [2,4,8,16,32,17,128,173,512,141,42,696,3,561,185,19,697,696,140,184,696,179,153,144,138,153,49,185,185,185,183,544,173,681,48,512]

theorem envBound26595 : H12AffineFastState.Bounded env26595 := by
  intro p hp
  have h : env26595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26594_26595 : H12AffineEnvironment.transform 9 141 env26594 = env26595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 141 env26594 == env26595) = true)

theorem identity26595 : scanCanonicalize (H12AffineFastState.compose env26595 (packedSelected [0,2,3,6] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound26595 : packedSelected [0,2,3,6] rootPS < 2^1333 := by decide +kernel

def env26596 : List Nat := [2,4,8,16,32,17,128,173,26,141,42,162,3,43,185,19,163,162,140,184,162,179,153,144,138,153,49,185,185,185,183,58,173,179,48,26]

theorem envBound26596 : H12AffineFastState.Bounded env26596 := by
  intro p hp
  have h : env26596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26595_26596 : H12AffineEnvironment.transform 8 26 env26595 = env26596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env26595 == env26596) = true)

theorem identity26596 : scanCanonicalize (H12AffineFastState.compose env26596 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound26596 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26597 : List Nat := [2,4,8,16,17,17,128,156,26,141,27,147,3,26,136,19,146,147,140,137,147,130,153,144,138,153,0,136,136,136,134,11,156,130,1,26]

theorem envBound26597 : H12AffineFastState.Bounded env26597 := by
  intro p hp
  have h : env26597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26596_26597 : H12AffineEnvironment.transform 4 17 env26596 = env26597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env26596 == env26597) = true)

theorem identity26597 : scanCanonicalize (H12AffineFastState.compose env26597 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 30) := by decide +kernel

theorem selectedBound26597 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26598 : List Nat := [2,4,8,16,17,17,30,2,26,19,27,13,3,26,22,19,12,13,18,23,13,28,7,14,20,7,0,22,22,22,24,11,2,28,1,26]

theorem envBound26598 : H12AffineFastState.Bounded env26598 := by
  intro p hp
  have h : env26598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26597_26598 : H12AffineEnvironment.transform 6 30 env26597 = env26598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 30 env26597 == env26598) = true)

theorem identity26598 : scanCanonicalize (H12AffineFastState.compose env26598 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound26598 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env26599 : List Nat := [2,4,8,11,10,10,5,2,1,8,0,13,3,1,13,8,12,13,9,12,13,7,7,14,15,7,0,13,13,13,3,11,2,7,1,1]

theorem envBound26599 : H12AffineFastState.Bounded env26599 := by
  intro p hp
  have h : env26599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26598_26599 : H12AffineEnvironment.transform 3 11 env26598 = env26599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env26598 == env26599) = true)

theorem identity26599 : scanCanonicalize (H12AffineFastState.compose env26599 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound26599 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26600 : List Nat := [2,4,4,7,6,6,5,2,1,4,0,1,3,1,1,4,0,1,5,0,1,7,7,2,3,7,0,1,1,1,3,7,2,7,1,1]

theorem envBound26600 : H12AffineFastState.Bounded env26600 := by
  intro p hp
  have h : env26600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26599_26600 : H12AffineEnvironment.transform 2 4 env26599 = env26600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env26599 == env26600) = true)

def env26601 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147520,41002,143497,20497,493035,148800,148801,96347,74794,16400,256,131137,1345,135680]

theorem envBound26601 : H12AffineFastState.Bounded env26601 := by
  intro p hp
  have h : env26601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26540_26601 : H12AffineEnvironment.transform 18 136193 env26540 = env26601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136193 env26540 == env26601) = true)

def env26602 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147520,41002,143497,20497,492615,148716,148717,96347,74794,16400,172,131137,1261,135680]

theorem envBound26602 : H12AffineFastState.Bounded env26602 := by
  intro p hp
  have h : env26602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26601_26602 : H12AffineEnvironment.transform 7 172 env26601 = env26602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env26601 == env26602) = true)

def env26603 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61569,147472,41002,143497,20497,492567,148668,148669,96267,74794,16400,172,131089,1213,135680]

theorem envBound26603 : H12AffineFastState.Bounded env26603 := by
  intro p hp
  have h : env26603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26602_26603 : H12AffineEnvironment.transform 5 16 env26602 = env26603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env26602 == env26603) = true)

theorem identity26603 : scanCanonicalize (H12AffineFastState.compose env26603 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 45217) := by decide +kernel

theorem selectedBound26603 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env26604 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,45217,262144,42144,32769,4096,61569,61617,41002,32808,20497,341174,62493,62492,96267,74794,16400,172,45232,1213,41633]

theorem envBound26604 : H12AffineFastState.Bounded env26604 := by
  intro p hp
  have h : env26604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26603_26604 : H12AffineEnvironment.transform 16 45217 env26603 = env26604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45217 env26603 == env26604) = true)

theorem identity26604 : scanCanonicalize (H12AffineFastState.compose env26604 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound26604 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env26605 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1212,32768,65536,45217,262144,42144,32769,4096,46141,46093,41002,32808,5293,341174,45217,45216,81079,74794,1196,172,45232,1213,41633]

theorem envBound26605 : H12AffineFastState.Bounded env26605 := by
  intro p hp
  have h : env26605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26604_26605 : H12AffineEnvironment.transform 13 1212 env26604 = env26605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env26604 == env26605) = true)

theorem identity26605 : scanCanonicalize (H12AffineFastState.compose env26605 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 33830) := by decide +kernel

theorem selectedBound26605 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env26606 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1212,32768,33830,45217,262144,42144,32769,4096,46141,46093,41002,32808,5293,307344,45217,45216,47249,40972,1196,172,45232,1213,41633]

theorem envBound26606 : H12AffineFastState.Bounded env26606 := by
  intro p hp
  have h : env26606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26605_26606 : H12AffineEnvironment.transform 15 33830 env26605 = env26606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33830 env26605 == env26606) = true)

theorem identity26606 : scanCanonicalize (H12AffineFastState.compose env26606 (packedSelected [4,9,20] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound26606 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env26607 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,184,8192,1212,32768,33830,40985,262144,42144,32769,184,42117,42165,41002,32808,1045,303144,40985,40984,43049,40972,1196,172,40968,1213,41633]

theorem envBound26607 : H12AffineFastState.Bounded env26607 := by
  intro p hp
  have h : env26607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26606_26607 : H12AffineEnvironment.transform 11 184 env26606 = env26607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env26606 == env26607) = true)

theorem identity26607 : scanCanonicalize (H12AffineFastState.compose env26607 (packedSelected [1,3,5,6,8,13] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound26607 : packedSelected [1,3,5,6,8,13] rootPS < 2^1333 := by decide +kernel

def env26608 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,184,8192,1212,32768,33830,40985,43049,42144,32769,184,42117,42165,41002,32808,1045,2049,40985,40984,43049,40972,1196,172,40968,1213,41633]

theorem envBound26608 : H12AffineFastState.Bounded env26608 := by
  intro p hp
  have h : env26608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26607_26608 : H12AffineEnvironment.transform 17 43049 env26607 = env26608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env26607 == env26608) = true)

theorem identity26608 : scanCanonicalize (H12AffineFastState.compose env26608 (packedSelected [2,3,4,6,8,9] rootPS)) = affineNative (2^(8+1) ^^^ 146) := by decide +kernel

theorem selectedBound26608 : packedSelected [2,3,4,6,8,9] rootPS < 2^1333 := by decide +kernel

def env26609 : List Nat := [2,4,8,16,32,16,128,172,146,1024,2048,184,8192,1212,32768,33830,40985,43049,42144,32769,184,42117,42165,41002,32808,1045,2049,40985,40984,43049,40972,1196,172,40968,1213,41011]

theorem envBound26609 : H12AffineFastState.Bounded env26609 := by
  intro p hp
  have h : env26609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26608_26609 : H12AffineEnvironment.transform 8 146 env26608 = env26609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 146 env26608 == env26609) = true)

theorem identity26609 : scanCanonicalize (H12AffineFastState.compose env26609 (packedSelected [1,3,6] rootPS)) = affineNative (2^(14+1) ^^^ 1071) := by decide +kernel

theorem selectedBound26609 : packedSelected [1,3,6] rootPS < 2^1333 := by decide +kernel

def env26610 : List Nat := [2,4,8,16,32,16,128,172,146,1024,2048,184,8192,1212,1071,9,9270,11270,8335,1070,184,8362,8346,9221,1031,1045,2049,9270,9271,11270,9251,1196,172,9255,1213,9244]

theorem envBound26610 : H12AffineFastState.Bounded env26610 := by
  intro p hp
  have h : env26610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26609_26610 : H12AffineEnvironment.transform 14 1071 env26609 = env26610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1071 env26609 == env26610) = true)

theorem identity26610 : scanCanonicalize (H12AffineFastState.compose env26610 (packedSelected [0,7,10] rootPS)) = affineNative (2^(10+1) ^^^ 185) := by decide +kernel

theorem selectedBound26610 : packedSelected [0,7,10] rootPS < 2^1333 := by decide +kernel

def env26611 : List Nat := [2,4,8,16,32,16,128,172,146,1024,185,184,8192,1212,1071,9,9270,9407,8335,1070,184,8362,8346,9221,1031,1045,184,9270,9271,9407,9251,1196,172,9255,1213,9244]

theorem envBound26611 : H12AffineFastState.Bounded env26611 := by
  intro p hp
  have h : env26611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26610_26611 : H12AffineEnvironment.transform 10 185 env26610 = env26611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 185 env26610 == env26611) = true)

theorem identity26611 : scanCanonicalize (H12AffineFastState.compose env26611 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(12+1) ^^^ 138) := by decide +kernel

theorem selectedBound26611 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env26612 : List Nat := [2,4,8,16,32,16,128,172,146,1024,185,184,138,1212,1071,9,1212,1077,5,1070,184,32,16,1167,1031,1045,184,1212,1213,1077,1193,1196,172,1197,1213,1174]

theorem envBound26612 : H12AffineFastState.Bounded env26612 := by
  intro p hp
  have h : env26612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26611_26612 : H12AffineEnvironment.transform 12 138 env26611 = env26612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 138 env26611 == env26612) = true)

theorem identity26612 : scanCanonicalize (H12AffineFastState.compose env26612 (packedSelected [1,2] rootPS)) = affineNative (2^(6+1) ^^^ 52) := by decide +kernel

theorem selectedBound26612 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env26613 : List Nat := [2,4,8,16,32,16,52,24,38,1024,13,12,62,1032,1071,9,1032,1077,5,1070,12,32,16,1083,1031,1045,12,1032,1033,1077,1053,1048,24,1049,1033,1058]

theorem envBound26613 : H12AffineFastState.Bounded env26613 := by
  intro p hp
  have h : env26613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26612_26613 : H12AffineEnvironment.transform 6 52 env26612 = env26613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 52 env26612 == env26613) = true)

theorem identity26613 : scanCanonicalize (H12AffineFastState.compose env26613 (packedSelected [1,3,5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound26613 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env26614 : List Nat := [2,4,8,11,32,11,47,3,38,1024,13,12,37,1032,1071,9,1032,1070,5,1070,12,32,11,1056,1031,1038,12,1032,1033,1070,1030,1027,3,1026,1033,1058]

theorem envBound26614 : H12AffineFastState.Bounded env26614 := by
  intro p hp
  have h : env26614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26613_26614 : H12AffineEnvironment.transform 3 11 env26613 = env26614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env26613 == env26614) = true)

theorem identity26614 : scanCanonicalize (H12AffineFastState.compose env26614 (packedSelected [1,3,8] rootPS)) = affineNative (2^(9+1) ^^^ 34) := by decide +kernel

theorem selectedBound26614 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env26615 : List Nat := [2,4,8,11,32,11,47,3,38,34,13,12,37,42,13,9,42,12,5,12,12,32,11,2,37,44,12,42,43,12,36,33,3,32,43,0]

theorem envBound26615 : H12AffineFastState.Bounded env26615 := by
  intro p hp
  have h : env26615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26614_26615 : H12AffineEnvironment.transform 9 34 env26614 = env26615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 34 env26614 == env26615) = true)

def env26616 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61568,147473,41002,143497,20497,492566,148669,148668,96266,74794,16400,172,131088,1212,135680]

theorem envBound26616 : H12AffineFastState.Bounded env26616 := by
  intro p hp
  have h : env26616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26602_26616 : H12AffineEnvironment.transform 5 17 env26602 = env26616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env26602 == env26616) = true)

theorem identity26616 : scanCanonicalize (H12AffineFastState.compose env26616 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 137353) := by decide +kernel

theorem selectedBound26616 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env26617 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,137353,136193,32769,4096,61568,147473,41002,143497,20497,105631,148669,148668,96266,74794,16400,172,131088,1212,135680]

theorem envBound26617 : H12AffineFastState.Bounded env26617 := by
  intro p hp
  have h : env26617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26616_26617 : H12AffineEnvironment.transform 17 137353 env26616 = env26617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137353 env26616 == env26617) = true)

theorem identity26617 : scanCanonicalize (H12AffineFastState.compose env26617 (packedSelected [1,5,8,18,19,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 13375) := by decide +kernel

theorem selectedBound26617 : packedSelected [1,5,8,18,19,23,24,26] rootPS < 2^1333 := by decide +kernel

def env26618 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,13375,131072,137353,136193,32769,4096,61568,147473,41002,143497,20497,43168,148669,148668,19509,4117,16400,172,131088,1212,135680]

theorem envBound26618 : H12AffineFastState.Bounded env26618 := by
  intro p hp
  have h : env26618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26617_26618 : H12AffineEnvironment.transform 15 13375 env26617 = env26618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13375 env26617 == env26618) = true)

theorem identity26618 : scanCanonicalize (H12AffineFastState.compose env26618 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound26618 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env26619 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1212,32768,13375,131072,137353,136193,32769,4096,46140,132269,41002,143497,5293,43168,131073,131072,2185,4117,1196,172,131088,1212,135680]

theorem envBound26619 : H12AffineFastState.Bounded env26619 := by
  intro p hp
  have h : env26619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26618_26619 : H12AffineEnvironment.transform 13 1212 env26618 = env26619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env26618 == env26619) = true)

theorem identity26619 : scanCanonicalize (H12AffineFastState.compose env26619 (packedSelected [13,17] rootPS)) = affineNative (2^(16+1) ^^^ 46245) := by decide +kernel

theorem selectedBound26619 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env26620 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1212,32768,13375,46245,44076,41124,32769,4096,46140,45064,41002,33836,5293,43168,46244,46245,2185,4117,1196,172,46261,1212,42661]

theorem envBound26620 : H12AffineFastState.Bounded env26620 := by
  intro p hp
  have h : env26620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26619_26620 : H12AffineEnvironment.transform 16 46245 env26619 = env26620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46245 env26619 == env26620) = true)

theorem identity26620 : scanCanonicalize (H12AffineFastState.compose env26620 (packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 2075) := by decide +kernel

theorem selectedBound26620 : packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env26621 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,2075,8192,1212,32768,11300,44222,44076,41124,32769,2075,44071,43027,41002,33836,3254,43168,44223,44222,2185,2062,1196,172,44206,1212,42661]

theorem envBound26621 : H12AffineFastState.Bounded env26621 := by
  intro p hp
  have h : env26621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26620_26621 : H12AffineEnvironment.transform 11 2075 env26620 = env26621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2075 env26620 == env26621) = true)

theorem identity26621 : scanCanonicalize (H12AffineFastState.compose env26621 (packedSelected [1,5] rootPS)) = affineNative (2^(12+1) ^^^ 3263) := by decide +kernel

theorem selectedBound26621 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env26622 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,2075,3263,1212,32768,155,32769,32915,35867,32769,2075,32920,33964,35989,33836,3254,33823,32768,32769,2185,2062,1196,172,32785,1212,35354]

theorem envBound26622 : H12AffineFastState.Bounded env26622 := by
  intro p hp
  have h : env26622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26621_26622 : H12AffineEnvironment.transform 12 3263 env26621 = env26622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3263 env26621 == env26622) = true)

theorem identity26622 : scanCanonicalize (H12AffineFastState.compose env26622 (packedSelected [0,4,11,13] rootPS)) = affineNative (2^(14+1) ^^^ 3735) := by decide +kernel

theorem selectedBound26622 : packedSelected [0,4,11,13] rootPS < 2^1333 := by decide +kernel

def env26623 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,2075,3263,1212,3735,155,3734,3588,652,3734,2075,3599,2619,514,2747,3254,2696,3735,3734,2185,2062,1196,172,3718,1212,1165]

theorem envBound26623 : H12AffineFastState.Bounded env26623 := by
  intro p hp
  have h : env26623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26622_26623 : H12AffineEnvironment.transform 14 3735 env26622 = env26623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 3735 env26622 == env26623) = true)

theorem identity26623 : scanCanonicalize (H12AffineFastState.compose env26623 (packedSelected [0,2,9,10,16] rootPS)) = affineNative (2^(10+1) ^^^ 1583) := by decide +kernel

theorem selectedBound26623 : packedSelected [0,2,9,10,16] rootPS < 2^1333 := by decide +kernel

def env26624 : List Nat := [2,4,8,16,32,17,128,172,512,1024,1583,1588,656,1212,184,155,185,43,652,185,1588,32,1044,514,1172,665,1191,184,185,1702,1569,1196,172,169,1212,1165]

theorem envBound26624 : H12AffineFastState.Bounded env26624 := by
  intro p hp
  have h : env26624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26623_26624 : H12AffineEnvironment.transform 10 1583 env26623 = env26624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1583 env26623 == env26624) = true)

theorem identity26624 : scanCanonicalize (H12AffineFastState.compose env26624 (packedSelected [2,3,6,7,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound26624 : packedSelected [2,3,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env26625 : List Nat := [2,4,8,16,32,17,128,172,512,517,42,49,656,697,184,155,185,43,652,185,49,32,529,514,657,665,674,184,185,163,36,681,172,169,697,648]

theorem envBound26625 : H12AffineFastState.Bounded env26625 := by
  intro p hp
  have h : env26625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26624_26625 : H12AffineEnvironment.transform 9 517 env26624 = env26625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env26624 == env26625) = true)

theorem identity26625 : scanCanonicalize (H12AffineFastState.compose env26625 (packedSelected [2,3,6,8] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound26625 : packedSelected [2,3,6,8] rootPS < 2^1333 := by decide +kernel

def env26626 : List Nat := [2,4,8,16,32,17,128,172,26,31,42,49,138,163,184,155,185,43,150,185,49,32,11,24,139,131,184,184,185,163,36,179,172,169,163,146]

theorem envBound26626 : H12AffineFastState.Bounded env26626 := by
  intro p hp
  have h : env26626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26625_26626 : H12AffineEnvironment.transform 8 26 env26625 = env26626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env26625 == env26626) = true)

theorem identity26626 : scanCanonicalize (H12AffineFastState.compose env26626 (packedSelected [0,2,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 36) := by decide +kernel

theorem selectedBound26626 : packedSelected [0,2,3,4] rootPS < 2^1333 := by decide +kernel

def env26627 : List Nat := [2,4,8,16,32,17,36,8,26,31,42,49,46,7,28,63,29,43,50,29,49,32,11,24,47,39,28,28,29,7,36,23,8,13,7,54]

theorem envBound26627 : H12AffineFastState.Bounded env26627 := by
  intro p hp
  have h : env26627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26626_26627 : H12AffineEnvironment.transform 6 36 env26626 = env26627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 36 env26626 == env26627) = true)

theorem identity26627 : scanCanonicalize (H12AffineFastState.compose env26627 (packedSelected [0,3,6,7] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound26627 : packedSelected [0,3,6,7] rootPS < 2^1333 := by decide +kernel

def env26628 : List Nat := [2,4,8,16,13,17,9,8,26,31,7,28,3,7,28,18,29,6,31,29,28,13,11,24,2,10,28,28,29,7,9,23,8,13,7,27]

theorem envBound26628 : H12AffineFastState.Bounded env26628 := by
  intro p hp
  have h : env26628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26627_26628 : H12AffineEnvironment.transform 4 13 env26627 = env26628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env26627 == env26628) = true)

theorem identity26628 : scanCanonicalize (H12AffineFastState.compose env26628 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound26628 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26629 : List Nat := [0,4,8,16,13,17,9,8,24,29,5,28,1,5,28,16,29,4,29,29,28,13,9,24,0,8,28,28,29,5,9,21,8,13,5,25]

theorem envBound26629 : H12AffineFastState.Bounded env26629 := by
  intro p hp
  have h : env26629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26628_26629 : H12AffineEnvironment.transform 0 0 env26628 = env26629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env26628 == env26629) = true)

theorem identity26629 : scanCanonicalize (H12AffineFastState.compose env26629 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound26629 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26630 : List Nat := [0,4,8,4,13,5,9,8,12,9,5,8,1,5,8,4,9,4,9,9,8,13,9,12,0,8,8,8,9,5,9,1,8,13,5,13]

theorem envBound26630 : H12AffineFastState.Bounded env26630 := by
  intro p hp
  have h : env26630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26629_26630 : H12AffineEnvironment.transform 3 4 env26629 = env26630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env26629 == env26630) = true)

theorem identity26630 : scanCanonicalize (H12AffineFastState.compose env26630 (packedSelected [2,3] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound26630 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env26631 : List Nat := [0,4,0,4,5,5,1,0,4,1,5,0,1,5,0,4,1,4,1,1,0,5,1,4,0,0,0,0,1,5,1,1,0,5,5,5]

theorem envBound26631 : H12AffineFastState.Bounded env26631 := by
  intro p hp
  have h : env26631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26630_26631 : H12AffineEnvironment.transform 2 0 env26630 = env26631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env26630 == env26631) = true)

def env26632 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147520,41002,143497,20497,492614,148717,148716,96347,74794,16400,173,131137,1260,135680]

theorem envBound26632 : H12AffineFastState.Bounded env26632 := by
  intro p hp
  have h : env26632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26601_26632 : H12AffineEnvironment.transform 7 173 env26601 = env26632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env26601 == env26632) = true)

def env26633 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61569,147472,41002,143497,20497,492566,148669,148668,96267,74794,16400,173,131089,1212,135680]

theorem envBound26633 : H12AffineFastState.Bounded env26633 := by
  intro p hp
  have h : env26633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26632_26633 : H12AffineEnvironment.transform 5 16 env26632 = env26633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env26632 == env26633) = true)

theorem identity26633 : scanCanonicalize (H12AffineFastState.compose env26633 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 114722) := by decide +kernel

theorem selectedBound26633 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env26634 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,114722,262144,119843,32769,4096,61569,98354,41002,127147,20497,279604,99487,99486,96267,74794,16400,173,114739,1212,119330]

theorem envBound26634 : H12AffineFastState.Bounded env26634 := by
  intro p hp
  have h : env26634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26633_26634 : H12AffineEnvironment.transform 16 114722 env26633 = env26634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114722 env26633 == env26634) = true)

theorem identity26634 : scanCanonicalize (H12AffineFastState.compose env26634 (packedSelected [3,10,16,18,19,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 92339) := by decide +kernel

theorem selectedBound26634 : packedSelected [3,10,16,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env26635 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,114722,92339,119843,32769,4096,61569,98354,41002,127147,20497,76935,99487,99486,96267,74794,16400,173,114739,1212,119330]

theorem envBound26635 : H12AffineFastState.Bounded env26635 := by
  intro p hp
  have h : env26635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26634_26635 : H12AffineEnvironment.transform 17 92339 env26634 = env26635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 92339 env26634 == env26635) = true)

theorem identity26635 : scanCanonicalize (H12AffineFastState.compose env26635 (packedSelected [7,16,18,19,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53282) := by decide +kernel

theorem selectedBound26635 : packedSelected [7,16,18,19,23,26,27] rootPS < 2^1333 := by decide +kernel

def env26636 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,53282,4096,47249,1025,32769,4096,61569,20496,41002,8329,20497,64677,21693,21692,43049,62472,16400,173,4113,1212,512]

theorem envBound26636 : H12AffineFastState.Bounded env26636 := by
  intro p hp
  have h : env26636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26635_26636 : H12AffineEnvironment.transform 15 53282 env26635 = env26636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53282 env26635 == env26636) = true)

theorem identity26636 : scanCanonicalize (H12AffineFastState.compose env26636 (packedSelected [4,9,16] rootPS)) = affineNative (2^(13+1) ^^^ 5124) := by decide +kernel

theorem selectedBound26636 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env26637 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,5124,32768,33830,4096,47249,1025,32769,4096,42117,1044,41002,8329,1045,43169,185,184,43049,40972,5140,173,4113,1212,512]

theorem envBound26637 : H12AffineFastState.Bounded env26637 := by
  intro p hp
  have h : env26637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26636_26637 : H12AffineEnvironment.transform 13 5124 env26636 = env26637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5124 env26636 == env26637) = true)

theorem identity26637 : scanCanonicalize (H12AffineFastState.compose env26637 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 5676) := by decide +kernel

theorem selectedBound26637 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env26638 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,5676,5124,32768,33830,4096,36541,1025,32769,4096,37545,1044,38406,5797,1045,40589,185,184,40453,38432,5140,173,4113,1212,512]

theorem envBound26638 : H12AffineFastState.Bounded env26638 := by
  intro p hp
  have h : env26638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26637_26638 : H12AffineEnvironment.transform 12 5676 env26637 = env26638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5676 env26637 == env26638) = true)

theorem identity26638 : scanCanonicalize (H12AffineFastState.compose env26638 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(14+1) ^^^ 1071) := by decide +kernel

theorem selectedBound26638 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env26639 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,5676,5124,1071,9,4096,2706,1025,1070,4096,5766,1044,4649,5797,1045,6818,185,184,6698,4623,5140,173,4113,1212,512]

theorem envBound26639 : H12AffineFastState.Bounded env26639 := by
  intro p hp
  have h : env26639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26638_26639 : H12AffineEnvironment.transform 14 1071 env26638 = env26639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1071 env26638 == env26639) = true)

theorem identity26639 : scanCanonicalize (H12AffineFastState.compose env26639 (packedSelected [2,3,4,5,7,11,12,15,17] rootPS)) = affineNative (2^(11+1) ^^^ 3077) := by decide +kernel

theorem selectedBound26639 : packedSelected [2,3,4,5,7,11,12,15,17] rootPS < 2^1333 := by decide +kernel

def env26640 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,3077,2601,2049,1071,9,3077,2706,1025,1070,3077,2691,1044,3628,2720,1045,1703,185,184,1583,3594,2065,173,3092,1212,512]

theorem envBound26640 : H12AffineFastState.Bounded env26640 := by
  intro p hp
  have h : env26640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26639_26640 : H12AffineEnvironment.transform 11 3077 env26639 = env26640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3077 env26639 == env26640) = true)

theorem identity26640 : scanCanonicalize (H12AffineFastState.compose env26640 (packedSelected [1,2,3,4,6,9,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 561) := by decide +kernel

theorem selectedBound26640 : packedSelected [1,2,3,4,6,9,11,12] rootPS < 2^1333 := by decide +kernel

def env26641 : List Nat := [2,4,8,16,32,16,128,173,512,1024,561,1588,24,560,1071,9,1588,163,1025,1070,1588,178,1044,1053,145,1045,1703,185,184,1583,1083,544,173,1573,1212,512]

theorem envBound26641 : H12AffineFastState.Bounded env26641 := by
  intro p hp
  have h : env26641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26640_26641 : H12AffineEnvironment.transform 10 561 env26640 = env26641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 561 env26640 == env26641) = true)

theorem identity26641 : scanCanonicalize (H12AffineFastState.compose env26641 (packedSelected [0,3,5,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 140) := by decide +kernel

theorem selectedBound26641 : packedSelected [0,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env26642 : List Nat := [2,4,8,16,32,16,128,173,512,140,561,696,24,560,163,9,696,163,141,162,696,178,152,145,145,153,555,185,184,675,183,544,173,681,48,512]

theorem envBound26642 : H12AffineFastState.Bounded env26642 := by
  intro p hp
  have h : env26642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26641_26642 : H12AffineEnvironment.transform 9 140 env26641 = env26642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 140 env26641 == env26642) = true)

theorem identity26642 : scanCanonicalize (H12AffineFastState.compose env26642 (packedSelected [0,1,2,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound26642 : packedSelected [0,1,2,3,5] rootPS < 2^1333 := by decide +kernel

def env26643 : List Nat := [2,4,8,16,32,16,19,62,512,31,561,555,24,560,48,9,555,48,30,49,555,33,11,2,2,10,555,42,43,560,36,544,62,570,48,512]

theorem envBound26643 : H12AffineFastState.Bounded env26643 := by
  intro p hp
  have h : env26643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26642_26643 : H12AffineEnvironment.transform 6 19 env26642 = env26643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env26642 == env26643) = true)

theorem identity26643 : scanCanonicalize (H12AffineFastState.compose env26643 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound26643 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env26644 : List Nat := [2,4,8,11,32,11,8,37,512,4,554,555,3,555,43,9,555,43,5,42,555,33,11,2,2,10,555,42,43,555,36,544,37,545,43,512]

theorem envBound26644 : H12AffineFastState.Bounded env26644 := by
  intro p hp
  have h : env26644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26643_26644 : H12AffineEnvironment.transform 3 11 env26643 = env26644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env26643 == env26644) = true)

theorem identity26644 : scanCanonicalize (H12AffineFastState.compose env26644 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound26644 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env26645 : List Nat := [2,4,8,11,10,11,8,15,512,4,512,513,3,513,1,9,513,1,5,0,513,11,11,2,2,10,513,0,1,513,14,522,15,523,1,512]

theorem envBound26645 : H12AffineFastState.Bounded env26645 := by
  intro p hp
  have h : env26645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26644_26645 : H12AffineEnvironment.transform 4 10 env26644 = env26645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env26644 == env26645) = true)

theorem identity26645 : scanCanonicalize (H12AffineFastState.compose env26645 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound26645 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26646 : List Nat := [2,4,8,11,10,11,8,15,1,4,1,0,3,0,1,9,0,1,5,0,0,11,11,2,2,10,0,0,1,0,14,11,15,10,1,1]

theorem envBound26646 : H12AffineFastState.Bounded env26646 := by
  intro p hp
  have h : env26646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26645_26646 : H12AffineEnvironment.transform 8 1 env26645 = env26646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env26645 == env26646) = true)

theorem identity26646 : scanCanonicalize (H12AffineFastState.compose env26646 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound26646 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26647 : List Nat := [2,4,4,7,6,7,4,3,1,4,1,0,3,0,1,5,0,1,5,0,0,7,7,2,2,6,0,0,1,0,2,7,3,6,1,1]

theorem envBound26647 : H12AffineFastState.Bounded env26647 := by
  intro p hp
  have h : env26647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26646_26647 : H12AffineEnvironment.transform 2 4 env26646 = env26647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env26646 == env26647) = true)

def env26648 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61568,147473,41002,143497,20497,492567,148668,148669,96266,74794,16400,173,131088,1213,135680]

theorem envBound26648 : H12AffineFastState.Bounded env26648 := by
  intro p hp
  have h : env26648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26632_26648 : H12AffineEnvironment.transform 5 17 env26632 = env26648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env26632 == env26648) = true)

theorem identity26648 : scanCanonicalize (H12AffineFastState.compose env26648 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 223243) := by decide +kernel

theorem selectedBound26648 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env26649 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,223243,136193,32769,4096,61568,147473,41002,143497,20497,60444,148668,148669,96266,74794,16400,173,131088,1213,135680]

theorem envBound26649 : H12AffineFastState.Bounded env26649 := by
  intro p hp
  have h : env26649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26648_26649 : H12AffineEnvironment.transform 17 223243 env26648 = env26649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223243 env26648 == env26649) = true)

theorem identity26649 : scanCanonicalize (H12AffineFastState.compose env26649 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 28803) := by decide +kernel

theorem selectedBound26649 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env26650 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,28803,131072,137352,136193,32769,4096,61568,147473,41002,143497,20497,60444,148668,148669,2185,21673,16400,173,131088,1213,135680]

theorem envBound26650 : H12AffineFastState.Bounded env26650 := by
  intro p hp
  have h : env26650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26649_26650 : H12AffineEnvironment.transform 15 28803 env26649 = env26650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28803 env26649 == env26650) = true)

theorem identity26650 : scanCanonicalize (H12AffineFastState.compose env26650 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(14+1) ^^^ 12312) := by decide +kernel

theorem selectedBound26650 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env26651 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,12312,28803,131072,137352,136193,12313,4096,16536,147473,4146,143497,20497,23556,148668,148669,2185,21673,16400,173,131088,1213,135680]

theorem envBound26651 : H12AffineFastState.Bounded env26651 := by
  intro p hp
  have h : env26651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26650_26651 : H12AffineEnvironment.transform 14 12312 env26650 = env26651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12312 env26650 == env26651) = true)

theorem identity26651 : scanCanonicalize (H12AffineFastState.compose env26651 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound26651 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env26652 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1213,12312,13374,131072,137352,136193,12313,4096,1061,132268,4146,143497,5292,6329,131073,131072,2185,4116,1197,173,131088,1213,135680]

theorem envBound26652 : H12AffineFastState.Bounded env26652 := by
  intro p hp
  have h : env26652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26651_26652 : H12AffineEnvironment.transform 13 1213 env26651 = env26652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env26651 == env26652) = true)

theorem identity26652 : scanCanonicalize (H12AffineFastState.compose env26652 (packedSelected [0,4,5,7,8,9,10,13] rootPS)) = affineNative (2^(16+1) ^^^ 14386) := by decide +kernel

theorem selectedBound26652 : packedSelected [0,4,5,7,8,9,10,13] rootPS < 2^1333 := by decide +kernel

def env26653 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1213,12312,13374,14386,8378,11315,12313,4096,1061,15518,4146,2235,5292,6329,14387,14386,2185,4116,1197,173,14370,1213,10802]

theorem envBound26653 : H12AffineFastState.Bounded env26653 := by
  intro p hp
  have h : env26653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26652_26653 : H12AffineEnvironment.transform 16 14386 env26652 = env26653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 14386 env26652 == env26653) = true)

theorem identity26653 : scanCanonicalize (H12AffineFastState.compose env26653 (packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 1213) := by decide +kernel

theorem selectedBound26653 : packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env26654 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,1213,8192,1213,9381,8323,11407,8378,11315,9380,1213,1061,10275,1167,2235,17,3076,11406,11407,2185,1193,1197,173,11423,1213,10802]

theorem envBound26654 : H12AffineFastState.Bounded env26654 := by
  intro p hp
  have h : env26654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26653_26654 : H12AffineEnvironment.transform 11 1213 env26653 = env26654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1213 env26653 == env26654) = true)

theorem identity26654 : scanCanonicalize (H12AffineFastState.compose env26654 (packedSelected [1,2,3,6,10,11] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound26654 : packedSelected [1,2,3,6,10,11] rootPS < 2^1333 := by decide +kernel

def env26655 : List Nat := [2,4,8,16,32,17,128,173,512,517,2048,696,8192,696,8864,8323,10890,8378,10806,8865,696,544,10275,650,2235,17,2561,10891,10890,2185,684,680,173,10906,696,10802]

theorem envBound26655 : H12AffineFastState.Bounded env26655 := by
  intro p hp
  have h : env26655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26654_26655 : H12AffineEnvironment.transform 9 517 env26654 = env26655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env26654 == env26655) = true)

theorem identity26655 : scanCanonicalize (H12AffineFastState.compose env26655 (packedSelected [0,1,3,4,6,7,8,9] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound26655 : packedSelected [0,1,3,4,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env26656 : List Nat := [2,4,4,16,32,17,128,161,512,517,2048,692,8192,692,8864,8323,10886,8374,10806,8865,692,544,10275,646,2231,17,2561,10887,10886,2181,672,676,161,10902,692,10802]

theorem envBound26656 : H12AffineFastState.Bounded env26656 := by
  intro p hp
  have h : env26656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26655_26656 : H12AffineEnvironment.transform 2 4 env26655 = env26656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env26655 == env26656) = true)

theorem identity26656 : scanCanonicalize (H12AffineFastState.compose env26656 (packedSelected [0,1,3,5,6,7,16] rootPS)) = affineNative (2^(10+1) ^^^ 675) := by decide +kernel

theorem selectedBound26656 : packedSelected [0,1,3,5,6,7,16] rootPS < 2^1333 := by decide +kernel

def env26657 : List Nat := [2,4,4,16,32,17,128,161,512,517,675,692,8192,692,8864,8323,8229,8374,8341,8865,692,544,8832,646,532,17,162,8228,8229,550,672,676,161,8245,692,8337]

theorem envBound26657 : H12AffineFastState.Bounded env26657 := by
  intro p hp
  have h : env26657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26656_26657 : H12AffineEnvironment.transform 10 675 env26656 = env26657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 675 env26656 == env26657) = true)

theorem identity26657 : scanCanonicalize (H12AffineFastState.compose env26657 (packedSelected [1,5] rootPS)) = affineNative (2^(12+1) ^^^ 145) := by decide +kernel

theorem selectedBound26657 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env26658 : List Nat := [2,4,4,16,32,17,128,161,512,517,675,692,145,692,561,18,180,39,4,560,692,544,529,646,532,17,162,181,180,550,672,676,161,164,692,0]

theorem envBound26658 : H12AffineFastState.Bounded env26658 := by
  intro p hp
  have h : env26658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26657_26658 : H12AffineEnvironment.transform 12 145 env26657 = env26658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 145 env26657 == env26658) = true)

theorem identity26658 : scanCanonicalize (H12AffineFastState.compose env26658 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound26658 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env26659 : List Nat := [2,4,4,7,32,6,128,161,512,517,675,675,134,675,550,5,163,39,4,551,675,544,518,646,515,6,162,162,163,550,672,676,161,164,675,0]

theorem envBound26659 : H12AffineFastState.Bounded env26659 := by
  intro p hp
  have h : env26659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26658_26659 : H12AffineEnvironment.transform 3 7 env26658 = env26659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env26658 == env26659) = true)

theorem identity26659 : scanCanonicalize (H12AffineFastState.compose env26659 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 38) := by decide +kernel

theorem selectedBound26659 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26660 : List Nat := [2,4,4,7,32,6,128,161,38,35,133,133,134,133,0,5,163,39,4,1,133,6,32,160,37,6,162,162,163,0,134,130,161,164,133,0]

theorem envBound26660 : H12AffineFastState.Bounded env26660 := by
  intro p hp
  have h : env26660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26659_26660 : H12AffineEnvironment.transform 8 38 env26659 = env26660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 38 env26659 == env26660) = true)

theorem identity26660 : scanCanonicalize (H12AffineFastState.compose env26660 (packedSelected [1,3,6] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound26660 : packedSelected [1,3,6] rootPS < 2^1333 := by decide +kernel

def env26661 : List Nat := [2,4,4,7,32,6,35,2,38,35,38,38,37,38,0,5,0,39,4,1,38,6,32,3,37,6,1,1,0,0,37,33,2,7,38,0]

theorem envBound26661 : H12AffineFastState.Bounded env26661 := by
  intro p hp
  have h : env26661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26660_26661 : H12AffineEnvironment.transform 6 35 env26660 = env26661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env26660 == env26661) = true)

def env26662 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,16777216,533641,672784,134217728,148800,545089,96347,16876545,17495099,257,131136,151462016,525824]

theorem envBound26662 : H12AffineFastState.Bounded env26662 := by
  intro p hp
  have h : env26662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26414_26662 : H12AffineEnvironment.transform 24 533641 env26414 = env26662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 533641 env26414 == env26662) = true)

def env26663 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,16777216,533641,672784,17245632,148800,545089,96347,16876545,17495099,257,131136,1344,525824]

theorem envBound26663 : H12AffineFastState.Bounded env26663 := by
  intro p hp
  have h : env26663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26662_26663 : H12AffineEnvironment.transform 26 17245632 env26662 = env26663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245632 env26662 == env26663) = true)

theorem identity26663 : scanCanonicalize (H12AffineFastState.compose env26663 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(18+1) ^^^ 95615) := by decide +kernel

theorem selectedBound26663 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env26664 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95615,32769,4096,61649,147520,16777216,86518,209263,17245632,148800,74814,96347,16876545,17006916,257,131136,1344,95103]

theorem envBound26664 : H12AffineFastState.Bounded env26664 := by
  intro p hp
  have h : env26664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26663_26664 : H12AffineEnvironment.transform 18 95615 env26663 = env26664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 95615 env26663 == env26664) = true)

def env26665 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95615,32769,4096,61649,147520,284032,86518,209263,225344,148800,74814,96347,381313,513220,257,131136,1344,95103]

theorem envBound26665 : H12AffineFastState.Bounded env26665 := by
  intro p hp
  have h : env26665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26664_26665 : H12AffineEnvironment.transform 23 284032 env26664 = env26665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 284032 env26664 == env26665) = true)

def env26666 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16464,262144,95615,32769,4096,61649,16,284032,86518,94527,77840,1296,74814,96347,381313,365716,257,16400,1344,95103]

theorem envBound26666 : H12AffineFastState.Bounded env26666 := by
  intro p hp
  have h : env26666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26665_26666 : H12AffineEnvironment.transform 16 16464 env26665 = env26666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16464 env26665 == env26666) = true)

def env26667 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1344,262144,77935,32769,4096,46529,16,266384,70886,78895,77840,1296,74814,81227,365713,365716,257,1280,1344,79471]

theorem envBound26667 : H12AffineFastState.Bounded env26667 := by
  intro p hp
  have h : env26667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26666_26667 : H12AffineEnvironment.transform 13 1296 env26666 = env26667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env26666 == env26667) = true)

theorem identity26667 : scanCanonicalize (H12AffineFastState.compose env26667 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound26667 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env26668 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1344,262144,77935,13340,4096,476,16,266384,70886,78895,77840,1296,74814,81227,336012,336009,257,1280,1344,79471]

theorem envBound26668 : H12AffineFastState.Bounded env26668 := by
  intro p hp
  have h : env26668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26667_26668 : H12AffineEnvironment.transform 14 13341 env26667 = env26668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env26667 == env26668) = true)

def env26669 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1344,65664,77935,13340,4096,476,16,69648,70886,78895,77840,1296,74814,81227,8204,8201,257,1280,1344,79471]

theorem envBound26669 : H12AffineFastState.Bounded env26669 := by
  intro p hp
  have h : env26669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26668_26669 : H12AffineEnvironment.transform 17 65664 env26668 = env26669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env26668 == env26669) = true)

theorem identity26669 : scanCanonicalize (H12AffineFastState.compose env26669 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound26669 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env26670 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1296,9245,65536,1344,65664,73839,9244,0,476,16,65552,66790,74799,73744,1296,74814,77131,8204,8201,257,1280,1344,75375]

theorem envBound26670 : H12AffineFastState.Bounded env26670 := by
  intro p hp
  have h : env26670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26669_26670 : H12AffineEnvironment.transform 11 0 env26669 = env26670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env26669 == env26670) = true)

def env26671 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,0,8192,1296,9245,65536,1296,65664,73791,9244,0,396,16,65552,66742,74799,73744,1296,74814,77083,8204,8201,257,1280,1296,75327]

theorem envBound26671 : H12AffineFastState.Bounded env26671 := by
  intro p hp
  have h : env26671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26670_26671 : H12AffineEnvironment.transform 5 16 env26670 = env26671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env26670 == env26671) = true)

theorem identity26671 : scanCanonicalize (H12AffineFastState.compose env26671 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 9515) := by decide +kernel

theorem selectedBound26671 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env26672 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,0,8192,1296,9245,9515,1296,9643,1300,9244,0,396,16,9531,8605,260,1339,1296,277,2096,8204,8201,257,1280,1296,788]

theorem envBound26672 : H12AffineFastState.Bounded env26672 := by
  intro p hp
  have h : env26672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26671_26672 : H12AffineEnvironment.transform 15 9515 env26671 = env26672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9515 env26671 == env26672) = true)

theorem identity26672 : scanCanonicalize (H12AffineFastState.compose env26672 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound26672 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env26673 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,0,8192,1,8460,8250,1,8378,5,8461,0,396,16,8234,8605,260,42,1,277,2096,8204,8201,257,17,1,788]

theorem envBound26673 : H12AffineFastState.Bounded env26673 := by
  intro p hp
  have h : env26673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26672_26673 : H12AffineEnvironment.transform 9 273 env26672 = env26673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env26672 == env26673) = true)

theorem identity26673 : scanCanonicalize (H12AffineFastState.compose env26673 (packedSelected [0,1,2,3,7,10,17,18,19] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound26673 : packedSelected [0,1,2,3,7,10,17,18,19] rootPS < 2^1333 := by decide +kernel

def env26674 : List Nat := [2,4,8,16,32,16,128,256,512,273,49,0,8192,1,8460,8250,1,8378,5,8461,0,396,16,8234,8605,260,42,1,277,1,8204,8201,257,17,1,788]

theorem envBound26674 : H12AffineFastState.Bounded env26674 := by
  intro p hp
  have h : env26674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26673_26674 : H12AffineEnvironment.transform 10 49 env26673 = env26674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env26673 == env26674) = true)

theorem identity26674 : scanCanonicalize (H12AffineFastState.compose env26674 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound26674 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26675 : List Nat := [2,4,8,16,32,16,128,256,292,273,49,0,8192,1,8460,8250,1,8378,5,8461,0,396,16,8234,8605,260,42,1,277,1,8204,8201,257,17,1,48]

theorem envBound26675 : H12AffineFastState.Bounded env26675 := by
  intro p hp
  have h : env26675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26674_26675 : H12AffineEnvironment.transform 8 292 env26674 = env26675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env26674 == env26675) = true)

theorem identity26675 : scanCanonicalize (H12AffineFastState.compose env26675 (packedSelected [3,8] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound26675 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env26676 : List Nat := [2,4,8,16,17,16,128,256,277,273,0,0,8192,1,8460,8203,1,8331,5,8461,0,396,16,8219,8605,260,27,1,277,1,8204,8201,257,17,1,1]

theorem envBound26676 : H12AffineFastState.Bounded env26676 := by
  intro p hp
  have h : env26676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26675_26676 : H12AffineEnvironment.transform 4 17 env26675 = env26676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env26675 == env26676) = true)

theorem identity26676 : scanCanonicalize (H12AffineFastState.compose env26676 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound26676 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env26677 : List Nat := [2,4,8,16,17,16,8,256,277,273,0,0,8192,1,8460,8203,1,8195,5,8461,0,260,16,8219,8469,260,27,1,277,1,8204,8201,257,17,1,1]

theorem envBound26677 : H12AffineFastState.Bounded env26677 := by
  intro p hp
  have h : env26677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26676_26677 : H12AffineEnvironment.transform 6 8 env26676 = env26677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env26676 == env26677) = true)

theorem identity26677 : scanCanonicalize (H12AffineFastState.compose env26677 (packedSelected [4,9] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound26677 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env26678 : List Nat := [2,4,8,11,10,11,8,256,270,266,0,0,8192,1,8460,8203,1,8195,5,8461,0,260,11,8192,8462,260,0,1,270,1,8204,8201,257,10,1,1]

theorem envBound26678 : H12AffineFastState.Bounded env26678 := by
  intro p hp
  have h : env26678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26677_26678 : H12AffineEnvironment.transform 3 11 env26677 = env26678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env26677 == env26678) = true)

theorem identity26678 : scanCanonicalize (H12AffineFastState.compose env26678 (packedSelected [1,5] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound26678 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env26679 : List Nat := [2,4,8,11,10,11,8,256,270,266,0,0,269,1,1,262,1,270,5,0,0,260,11,269,3,260,0,1,270,1,257,260,257,10,1,1]

theorem envBound26679 : H12AffineFastState.Bounded env26679 := by
  intro p hp
  have h : env26679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26678_26679 : H12AffineEnvironment.transform 12 269 env26678 = env26679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env26678 == env26679) = true)

theorem identity26679 : scanCanonicalize (H12AffineFastState.compose env26679 (packedSelected [0,1,4] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound26679 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env26680 : List Nat := [2,2,8,11,10,11,8,256,264,266,0,0,267,1,1,256,1,264,3,0,0,258,11,267,3,258,0,1,264,1,257,258,257,10,1,1]

theorem envBound26680 : H12AffineFastState.Bounded env26680 := by
  intro p hp
  have h : env26680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26679_26680 : H12AffineEnvironment.transform 1 2 env26679 = env26680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env26679 == env26680) = true)

def env26681 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,0,8192,1296,9245,65536,1297,65664,73790,9244,0,397,16,65552,66743,74799,73744,1296,74814,77082,8204,8201,257,1280,1297,75326]

theorem envBound26681 : H12AffineFastState.Bounded env26681 := by
  intro p hp
  have h : env26681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26670_26681 : H12AffineEnvironment.transform 5 17 env26670 = env26681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env26670 == env26681) = true)

theorem identity26681 : scanCanonicalize (H12AffineFastState.compose env26681 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound26681 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env26682 : List Nat := [2,4,8,16,32,17,128,20,512,1024,2048,0,8192,1028,9245,65536,1029,65664,73790,9244,0,153,16,65552,66743,74799,73744,1028,74814,76814,8204,8201,21,1044,1029,75326]

theorem envBound26682 : H12AffineFastState.Bounded env26682 := by
  intro p hp
  have h : env26682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26681_26682 : H12AffineEnvironment.transform 7 20 env26681 = env26682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env26681 == env26682) = true)

theorem identity26682 : scanCanonicalize (H12AffineFastState.compose env26682 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 8251) := by decide +kernel

theorem selectedBound26682 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env26683 : List Nat := [2,4,8,16,32,17,128,20,512,1024,2048,0,8192,1028,9245,8251,1029,8379,5,9244,0,153,16,8235,9356,1044,43,1028,1029,3125,8204,8201,21,1044,1029,1541]

theorem envBound26683 : H12AffineFastState.Bounded env26683 := by
  intro p hp
  have h : env26683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26682_26683 : H12AffineEnvironment.transform 15 8251 env26682 = env26683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8251 env26682 == env26683) = true)

theorem identity26683 : scanCanonicalize (H12AffineFastState.compose env26683 (packedSelected [10,11,13,17,18,19] rootPS)) = affineNative (2^(12+1) ^^^ 3) := by decide +kernel

theorem selectedBound26683 : packedSelected [10,11,13,17,18,19] rootPS < 2^1333 := by decide +kernel

def env26684 : List Nat := [2,4,8,16,32,17,128,20,512,1024,2048,0,3,1028,1054,56,1029,184,5,1055,0,153,16,40,1167,1044,43,1028,1029,3125,15,10,21,1044,1029,1541]

theorem envBound26684 : H12AffineFastState.Bounded env26684 := by
  intro p hp
  have h : env26684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26683_26684 : H12AffineEnvironment.transform 12 3 env26683 = env26684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3 env26683 == env26684) = true)

theorem identity26684 : scanCanonicalize (H12AffineFastState.compose env26684 (packedSelected [0,3,7,8,11] rootPS)) = affineNative (2^(9+1) ^^^ 652) := by decide +kernel

theorem selectedBound26684 : packedSelected [0,3,7,8,11] rootPS < 2^1333 := by decide +kernel

def env26685 : List Nat := [2,4,8,16,32,17,128,20,512,652,2048,0,3,648,658,56,649,184,5,659,0,153,16,40,515,664,43,648,649,2745,15,10,21,664,649,137]

theorem envBound26685 : H12AffineFastState.Bounded env26685 := by
  intro p hp
  have h : env26685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26684_26685 : H12AffineEnvironment.transform 9 652 env26684 = env26685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 652 env26684 == env26685) = true)

theorem identity26685 : scanCanonicalize (H12AffineFastState.compose env26685 (packedSelected [1,2,3,13] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound26685 : packedSelected [1,2,3,13] rootPS < 2^1333 := by decide +kernel

def env26686 : List Nat := [2,4,8,16,17,17,128,20,512,652,2048,0,3,648,658,9,649,137,5,659,0,153,16,25,515,664,26,648,649,2696,15,10,21,664,649,137]

theorem envBound26686 : H12AffineFastState.Bounded env26686 := by
  intro p hp
  have h : env26686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26685_26686 : H12AffineEnvironment.transform 4 17 env26685 = env26686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env26685 == env26686) = true)

theorem identity26686 : scanCanonicalize (H12AffineFastState.compose env26686 (packedSelected [1,8] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound26686 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env26687 : List Nat := [2,4,8,16,17,17,19,20,512,543,2048,0,3,539,513,9,538,26,5,512,0,10,16,25,515,523,26,539,538,2587,15,10,21,523,538,26]

theorem envBound26687 : H12AffineFastState.Bounded env26687 := by
  intro p hp
  have h : env26687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26686_26687 : H12AffineEnvironment.transform 6 19 env26686 = env26687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env26686 == env26687) = true)

theorem identity26687 : scanCanonicalize (H12AffineFastState.compose env26687 (packedSelected [2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound26687 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env26688 : List Nat := [2,4,8,16,17,17,19,20,512,543,513,0,3,539,513,9,538,26,5,512,0,10,16,25,515,523,26,539,538,26,15,10,21,523,538,26]

theorem envBound26688 : H12AffineFastState.Bounded env26688 := by
  intro p hp
  have h : env26688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26687_26688 : H12AffineEnvironment.transform 10 513 env26687 = env26688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env26687 == env26688) = true)

def env26689 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1344,65665,77935,13340,4096,476,16,69649,70886,78895,77840,1296,74814,81227,8205,8200,257,1280,1344,79471]

theorem envBound26689 : H12AffineFastState.Bounded env26689 := by
  intro p hp
  have h : env26689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26668_26689 : H12AffineEnvironment.transform 17 65665 env26668 = env26689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env26668 == env26689) = true)

theorem identity26689 : scanCanonicalize (H12AffineFastState.compose env26689 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound26689 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env26690 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,80,12637,65536,0,65665,77935,12636,4096,476,16,69649,70054,78191,77840,80,74110,79883,8205,8200,257,64,0,78639]

theorem envBound26690 : H12AffineFastState.Bounded env26690 := by
  intro p hp
  have h : env26690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26689_26690 : H12AffineEnvironment.transform 9 320 env26689 = env26690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env26689 == env26690) = true)

def env26691 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,4096,8192,0,12557,65536,0,65665,77887,12556,4096,396,16,69649,70054,78143,77840,0,74030,79883,8205,8200,257,16,0,78639]

theorem envBound26691 : H12AffineFastState.Bounded env26691 := by
  intro p hp
  have h : env26691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26690_26691 : H12AffineEnvironment.transform 5 16 env26690 = env26691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env26690 == env26691) = true)

theorem identity26691 : scanCanonicalize (H12AffineFastState.compose env26691 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 8251) := by decide +kernel

theorem selectedBound26691 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env26692 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,4096,8192,0,12557,8251,0,8378,4100,12556,4096,396,16,12330,12701,4356,4139,0,277,6192,8205,8200,257,16,0,4884]

theorem envBound26692 : H12AffineFastState.Bounded env26692 := by
  intro p hp
  have h : env26692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26691_26692 : H12AffineEnvironment.transform 15 8251 env26691 = env26692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8251 env26691 == env26692) = true)

theorem identity26692 : scanCanonicalize (H12AffineFastState.compose env26692 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound26692 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env26693 : List Nat := [2,4,8,16,32,16,128,21,512,5,2048,4096,8192,0,12312,8251,0,8378,4100,12313,4096,153,16,12330,12424,4113,4139,0,0,6192,8205,8200,20,16,0,4609]

theorem envBound26693 : H12AffineFastState.Bounded env26693 := by
  intro p hp
  have h : env26693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26692_26693 : H12AffineEnvironment.transform 7 21 env26692 = env26693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env26692 == env26693) = true)

theorem identity26693 : scanCanonicalize (H12AffineFastState.compose env26693 (packedSelected [10,11,13,17,18,19] rootPS)) = affineNative (2^(12+1) ^^^ 6330) := by decide +kernel

theorem selectedBound26693 : packedSelected [10,11,13,17,18,19] rootPS < 2^1333 := by decide +kernel

def env26694 : List Nat := [2,4,8,16,32,16,128,21,512,5,2048,4096,6330,0,2210,6273,0,6144,4100,2211,4096,153,16,2192,2098,4113,4139,0,0,6192,6327,6322,20,16,0,4609]

theorem envBound26694 : H12AffineFastState.Bounded env26694 := by
  intro p hp
  have h : env26694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26693_26694 : H12AffineEnvironment.transform 12 6330 env26693 = env26694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6330 env26693 == env26694) = true)

theorem identity26694 : scanCanonicalize (H12AffineFastState.compose env26694 (packedSelected [0,7,11] rootPS)) = affineNative (2^(11+1) ^^^ 2211) := by decide +kernel

theorem selectedBound26694 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env26695 : List Nat := [2,4,8,16,32,16,128,21,512,5,2048,2211,25,0,2210,34,0,163,2215,2211,2211,153,16,2192,2098,2226,2184,0,0,147,20,17,20,16,0,2722]

theorem envBound26695 : H12AffineFastState.Bounded env26695 := by
  intro p hp
  have h : env26695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26694_26695 : H12AffineEnvironment.transform 11 2211 env26694 = env26695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2211 env26694 == env26695) = true)

theorem identity26695 : scanCanonicalize (H12AffineFastState.compose env26695 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 675) := by decide +kernel

theorem selectedBound26695 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env26696 : List Nat := [2,4,8,16,32,16,128,21,512,5,675,512,25,0,513,34,0,163,516,512,512,153,16,563,657,529,555,0,0,147,20,17,20,16,0,1]

theorem envBound26696 : H12AffineFastState.Bounded env26696 := by
  intro p hp
  have h : env26696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26695_26696 : H12AffineEnvironment.transform 10 675 env26695 = env26696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 675 env26695 == env26696) = true)

theorem identity26696 : scanCanonicalize (H12AffineFastState.compose env26696 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound26696 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env26697 : List Nat := [2,4,8,11,32,11,128,14,512,5,675,512,2,0,513,34,0,163,516,512,512,130,11,552,650,522,555,0,0,136,15,10,15,11,0,1]

theorem envBound26697 : H12AffineFastState.Bounded env26697 := by
  intro p hp
  have h : env26697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26696_26697 : H12AffineEnvironment.transform 3 11 env26696 = env26697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env26696 == env26697) = true)

theorem identity26697 : scanCanonicalize (H12AffineFastState.compose env26697 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 45) := by decide +kernel

theorem selectedBound26697 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26698 : List Nat := [2,4,8,11,32,11,128,14,45,5,142,45,2,0,44,34,0,163,41,45,45,130,11,5,167,39,6,0,0,136,15,10,15,11,0,1]

theorem envBound26698 : H12AffineFastState.Bounded env26698 := by
  intro p hp
  have h : env26698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26697_26698 : H12AffineEnvironment.transform 8 45 env26697 = env26698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 45 env26697 == env26698) = true)

theorem identity26698 : scanCanonicalize (H12AffineFastState.compose env26698 (packedSelected [4,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound26698 : packedSelected [4,5,7] rootPS < 2^1333 := by decide +kernel

def env26699 : List Nat := [2,4,8,11,10,11,128,14,7,5,142,7,2,0,6,8,0,137,3,7,7,130,11,5,141,13,6,0,0,136,15,10,15,11,0,1]

theorem envBound26699 : H12AffineFastState.Bounded env26699 := by
  intro p hp
  have h : env26699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26698_26699 : H12AffineEnvironment.transform 4 10 env26698 = env26699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env26698 == env26699) = true)

theorem identity26699 : scanCanonicalize (H12AffineFastState.compose env26699 (packedSelected [5] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound26699 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env26700 : List Nat := [2,3,8,11,10,11,128,9,0,2,137,0,2,0,1,8,0,137,3,0,0,130,11,2,138,10,1,0,0,136,8,10,8,11,0,1]

theorem envBound26700 : H12AffineFastState.Bounded env26700 := by
  intro p hp
  have h : env26700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26699_26700 : H12AffineEnvironment.transform 1 3 env26699 = env26700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env26699 == env26700) = true)

theorem identity26700 : scanCanonicalize (H12AffineFastState.compose env26700 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound26700 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26701 : List Nat := [2,3,0,3,2,3,128,1,0,2,129,0,2,0,1,0,0,129,3,0,0,130,3,2,130,2,1,0,0,128,0,2,0,3,0,1]

theorem envBound26701 : H12AffineFastState.Bounded env26701 := by
  intro p hp
  have h : env26701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26700_26701 : H12AffineEnvironment.transform 2 0 env26700 = env26701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env26700 == env26701) = true)

theorem identity26701 : scanCanonicalize (H12AffineFastState.compose env26701 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 0) := by decide +kernel

theorem selectedBound26701 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26702 : List Nat := [2,3,0,3,2,3,0,1,0,2,1,0,2,0,1,0,0,1,3,0,0,2,3,2,2,2,1,0,0,0,0,2,0,3,0,1]

theorem envBound26702 : H12AffineFastState.Bounded env26702 := by
  intro p hp
  have h : env26702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26701_26702 : H12AffineEnvironment.transform 6 0 env26701 = env26702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 0 env26701 == env26702) = true)

theorem identity26702 : scanCanonicalize (H12AffineFastState.compose env26702 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound26702 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env26703 : List Nat := [0,1,0,1,0,1,0,1,0,0,1,0,0,0,1,0,0,1,1,0,0,0,1,0,0,0,1,0,0,0,0,0,0,1,0,1]

theorem envBound26703 : H12AffineFastState.Bounded env26703 := by
  intro p hp
  have h : env26703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26702_26703 : H12AffineEnvironment.transform 0 0 env26702 = env26703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env26702 == env26703) = true)

def env26704 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,4096,8192,1,12556,65536,0,65665,77886,12557,4096,397,16,69649,70054,78142,77840,1,74031,79883,8205,8200,257,17,0,78639]

theorem envBound26704 : H12AffineFastState.Bounded env26704 := by
  intro p hp
  have h : env26704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26690_26704 : H12AffineEnvironment.transform 5 17 env26690 = env26704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env26690 == env26704) = true)

theorem identity26704 : scanCanonicalize (H12AffineFastState.compose env26704 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound26704 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env26705 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,276,8192,1,8216,65536,0,65665,74026,8217,276,397,16,65797,65714,73770,73988,1,74031,76063,8205,8200,257,17,0,74299]

theorem envBound26705 : H12AffineFastState.Bounded env26705 := by
  intro p hp
  have h : env26705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26704_26705 : H12AffineEnvironment.transform 11 276 env26704 = env26705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env26704 == env26705) = true)

theorem identity26705 : scanCanonicalize (H12AffineFastState.compose env26705 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound26705 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env26706 : List Nat := [2,4,8,16,32,17,128,20,512,5,2048,0,8192,1,8216,65536,0,65665,73790,8217,0,153,16,65553,65714,73770,73744,1,73787,75787,8205,8200,21,17,0,74299]

theorem envBound26706 : H12AffineFastState.Bounded env26706 := by
  intro p hp
  have h : env26706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26705_26706 : H12AffineEnvironment.transform 7 20 env26705 = env26706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env26705 == env26706) = true)

theorem identity26706 : scanCanonicalize (H12AffineFastState.compose env26706 (packedSelected [0,1,3,7,10,11,17,19] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound26706 : packedSelected [0,1,3,7,10,11,17,19] rootPS < 2^1333 := by decide +kernel

def env26707 : List Nat := [2,4,8,16,10,17,128,20,512,5,2048,0,8192,1,8216,65536,0,65665,73748,8217,0,153,16,65553,65688,73728,73744,1,73745,75787,8205,8200,21,17,0,74257]

theorem envBound26707 : H12AffineFastState.Bounded env26707 := by
  intro p hp
  have h : env26707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26706_26707 : H12AffineEnvironment.transform 4 10 env26706 = env26707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env26706 == env26707) = true)

theorem identity26707 : scanCanonicalize (H12AffineFastState.compose env26707 (packedSelected [0,1,7,8,10,11,13,15,17] rootPS)) = affineNative (2^(15+1) ^^^ 18) := by decide +kernel

theorem selectedBound26707 : packedSelected [0,1,7,8,10,11,13,15,17] rootPS < 2^1333 := by decide +kernel

def env26708 : List Nat := [2,4,8,16,10,17,128,20,512,5,2048,0,8192,1,8216,18,0,147,8198,8217,0,153,16,3,138,8210,8194,1,8195,10265,8205,8200,21,17,0,8707]

theorem envBound26708 : H12AffineFastState.Bounded env26708 := by
  intro p hp
  have h : env26708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26707_26708 : H12AffineEnvironment.transform 15 18 env26707 = env26708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 18 env26707 == env26708) = true)

theorem identity26708 : scanCanonicalize (H12AffineFastState.compose env26708 (packedSelected [2,3,5,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound26708 : packedSelected [2,3,5,7,9] rootPS < 2^1333 := by decide +kernel

def env26709 : List Nat := [2,4,8,16,10,17,9,20,512,5,2048,0,8192,1,8216,18,0,26,8198,8217,0,16,16,3,3,8210,8194,1,8195,10265,8205,8200,21,17,0,8707]

theorem envBound26709 : H12AffineFastState.Bounded env26709 := by
  intro p hp
  have h : env26709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26708_26709 : H12AffineEnvironment.transform 6 9 env26708 = env26709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env26708 == env26709) = true)

theorem identity26709 : scanCanonicalize (H12AffineFastState.compose env26709 (packedSelected [1,2,3] rootPS)) = affineNative (2^(12+1) ^^^ 2584) := by decide +kernel

theorem selectedBound26709 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env26710 : List Nat := [2,4,8,16,10,17,9,20,512,5,2048,0,2584,1,2560,18,0,26,2590,2561,0,16,16,3,3,2570,2586,1,2587,513,2581,2576,21,17,0,2075]

theorem envBound26710 : H12AffineFastState.Bounded env26710 := by
  intro p hp
  have h : env26710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26709_26710 : H12AffineEnvironment.transform 12 2584 env26709 = env26710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2584 env26709 == env26710) = true)

theorem identity26710 : scanCanonicalize (H12AffineFastState.compose env26710 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound26710 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env26711 : List Nat := [2,4,8,16,10,17,9,20,512,5,512,0,24,1,0,18,0,26,30,1,0,16,16,3,3,10,26,1,27,513,21,16,21,17,0,539]

theorem envBound26711 : H12AffineFastState.Bounded env26711 := by
  intro p hp
  have h : env26711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26710_26711 : H12AffineEnvironment.transform 10 512 env26710 = env26711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env26710 == env26711) = true)

theorem identity26711 : scanCanonicalize (H12AffineFastState.compose env26711 (packedSelected [1,2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound26711 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env26712 : List Nat := [2,2,8,16,10,17,9,18,512,3,512,0,24,1,0,18,0,26,24,1,0,16,16,3,3,10,26,1,27,513,19,16,19,17,0,539]

theorem envBound26712 : H12AffineFastState.Bounded env26712 := by
  intro p hp
  have h : env26712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26711_26712 : H12AffineEnvironment.transform 1 2 env26711 = env26712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env26711 == env26712) = true)

theorem identity26712 : scanCanonicalize (H12AffineFastState.compose env26712 (packedSelected [5] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound26712 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env26713 : List Nat := [2,2,8,16,10,17,9,18,27,3,27,0,24,1,0,18,0,26,24,1,0,16,16,3,3,10,26,1,27,26,19,16,19,17,0,0]

theorem envBound26713 : H12AffineFastState.Bounded env26713 := by
  intro p hp
  have h : env26713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26712_26713 : H12AffineEnvironment.transform 8 27 env26712 = env26713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env26712 == env26713) = true)

theorem identity26713 : scanCanonicalize (H12AffineFastState.compose env26713 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound26713 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26714 : List Nat := [2,2,8,10,10,11,9,8,1,3,1,0,2,1,0,8,0,0,2,1,0,10,10,3,3,10,0,1,1,0,9,10,9,11,0,0]

theorem envBound26714 : H12AffineFastState.Bounded env26714 := by
  intro p hp
  have h : env26714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26713_26714 : H12AffineEnvironment.transform 3 10 env26713 = env26714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env26713 == env26714) = true)

theorem identity26714 : scanCanonicalize (H12AffineFastState.compose env26714 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound26714 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26715 : List Nat := [2,2,0,2,2,3,1,0,1,3,1,0,2,1,0,0,0,0,2,1,0,2,2,3,3,2,0,1,1,0,1,2,1,3,0,0]

theorem envBound26715 : H12AffineFastState.Bounded env26715 := by
  intro p hp
  have h : env26715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26714_26715 : H12AffineEnvironment.transform 2 0 env26714 = env26715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env26714 == env26715) = true)

theorem identity26715 : scanCanonicalize (H12AffineFastState.compose env26715 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound26715 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env26716 : List Nat := [1,1,0,1,1,0,1,0,1,0,1,0,1,1,0,0,0,0,1,1,0,1,1,0,0,1,0,1,1,0,1,1,1,0,0,0]

theorem envBound26716 : H12AffineFastState.Bounded env26716 := by
  intro p hp
  have h : env26716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26715_26716 : H12AffineEnvironment.transform 0 1 env26715 = env26716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env26715 == env26716) = true)

def env26717 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1345,262144,77934,32769,4096,46528,16,266385,70887,78894,77840,1296,74814,81226,365712,365716,257,1281,1344,79470]

theorem envBound26717 : H12AffineFastState.Bounded env26717 := by
  intro p hp
  have h : env26717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26666_26717 : H12AffineEnvironment.transform 13 1297 env26666 = env26717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env26666 == env26717) = true)

theorem identity26717 : scanCanonicalize (H12AffineFastState.compose env26717 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32882) := by decide +kernel

theorem selectedBound26717 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env26718 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,32882,1345,262144,45084,32769,4096,46528,16,266385,38037,46172,45154,1296,42060,48440,267490,267494,257,1281,1344,46620]

theorem envBound26718 : H12AffineFastState.Bounded env26718 := by
  intro p hp
  have h : env26718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26717_26718 : H12AffineEnvironment.transform 15 32882 env26717 = env26718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32882 env26717 == env26718) = true)

def env26719 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32882,1345,262144,42332,32769,1344,41088,16,263633,33237,41244,42274,1296,42060,43128,262562,262566,257,1281,1344,41820]

theorem envBound26719 : H12AffineFastState.Bounded env26719 := by
  intro p hp
  have h : env26719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26718_26719 : H12AffineEnvironment.transform 11 1344 env26718 = env26719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env26718 == env26719) = true)

theorem identity26719 : scanCanonicalize (H12AffineFastState.compose env26719 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 41147) := by decide +kernel

theorem selectedBound26719 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env26720 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32882,1345,41147,42332,32769,1344,41088,16,42346,33237,41244,42274,1296,42060,43128,41241,41245,257,1281,1344,41820]

theorem envBound26720 : H12AffineFastState.Bounded env26720 := by
  intro p hp
  have h : env26720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26719_26720 : H12AffineEnvironment.transform 17 41147 env26719 = env26720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 41147 env26719 == env26720) = true)

theorem identity26720 : scanCanonicalize (H12AffineFastState.compose env26720 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound26720 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env26721 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,8540,8494,1345,487,1024,8541,1344,476,16,1078,8329,64,1150,1296,1296,2340,69,65,257,1281,1344,512]

theorem envBound26721 : H12AffineFastState.Bounded env26721 := by
  intro p hp
  have h : env26721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26720_26721 : H12AffineEnvironment.transform 14 8540 env26720 = env26721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env26720 == env26721) = true)

theorem identity26721 : scanCanonicalize (H12AffineFastState.compose env26721 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 85) := by decide +kernel

theorem selectedBound26721 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env26722 : List Nat := [2,4,8,16,32,64,128,256,512,85,2048,277,8192,324,8540,8494,276,487,85,8541,277,476,16,99,8329,64,43,325,325,2340,69,65,257,340,277,512]

theorem envBound26722 : H12AffineFastState.Bounded env26722 := by
  intro p hp
  have h : env26722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26721_26722 : H12AffineEnvironment.transform 9 85 env26721 = env26722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env26721 == env26722) = true)

theorem identity26722 : scanCanonicalize (H12AffineFastState.compose env26722 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 900) := by decide +kernel

theorem selectedBound26722 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env26723 : List Nat := [2,4,8,16,32,64,128,256,512,85,2048,277,900,324,728,682,276,487,85,729,277,476,16,99,781,64,43,325,325,2340,69,65,257,340,277,512]

theorem envBound26723 : H12AffineFastState.Bounded env26723 := by
  intro p hp
  have h : env26723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26722_26723 : H12AffineEnvironment.transform 12 900 env26722 = env26723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 900 env26722 == env26723) = true)

theorem identity26723 : scanCanonicalize (H12AffineFastState.compose env26723 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound26723 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env26724 : List Nat := [2,4,8,16,32,17,128,256,512,4,2048,277,900,277,649,682,276,438,4,648,277,397,16,50,781,17,43,276,276,2340,20,16,257,261,277,512]

theorem envBound26724 : H12AffineFastState.Bounded env26724 := by
  intro p hp
  have h : env26724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26723_26724 : H12AffineEnvironment.transform 5 17 env26723 = env26724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env26723 == env26724) = true)

theorem identity26724 : scanCanonicalize (H12AffineFastState.compose env26724 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 391) := by decide +kernel

theorem selectedBound26724 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env26725 : List Nat := [2,4,8,16,32,17,128,256,512,4,391,277,900,277,649,682,276,438,4,648,277,397,16,50,781,17,43,276,276,163,20,16,257,261,277,512]

theorem envBound26725 : H12AffineFastState.Bounded env26725 := by
  intro p hp
  have h : env26725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26724_26725 : H12AffineEnvironment.transform 10 391 env26724 = env26725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 391 env26724 == env26725) = true)

theorem identity26725 : scanCanonicalize (H12AffineFastState.compose env26725 (packedSelected [0,1,2,5,7,11] rootPS)) = affineNative (2^(8+1) ^^^ 439) := by decide +kernel

theorem selectedBound26725 : packedSelected [0,1,2,5,7,11] rootPS < 2^1333 := by decide +kernel

def env26726 : List Nat := [2,4,8,16,32,17,128,256,439,4,391,277,51,277,318,285,276,438,4,319,277,397,16,50,186,17,43,276,276,163,20,16,257,261,277,439]

theorem envBound26726 : H12AffineFastState.Bounded env26726 := by
  intro p hp
  have h : env26726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26725_26726 : H12AffineEnvironment.transform 8 439 env26725 = env26726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 439 env26725 == env26726) = true)

theorem identity26726 : scanCanonicalize (H12AffineFastState.compose env26726 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 156) := by decide +kernel

theorem selectedBound26726 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env26727 : List Nat := [2,4,8,16,32,17,128,156,43,4,27,137,51,137,162,129,136,42,4,163,137,17,16,50,186,17,43,136,136,163,20,16,157,153,137,43]

theorem envBound26727 : H12AffineFastState.Bounded env26727 := by
  intro p hp
  have h : env26727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26726_26727 : H12AffineEnvironment.transform 7 156 env26726 = env26727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 156 env26726 == env26727) = true)

theorem identity26727 : scanCanonicalize (H12AffineFastState.compose env26727 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound26727 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env26728 : List Nat := [2,4,8,16,17,17,128,156,26,4,27,137,2,137,147,129,136,27,4,146,137,17,16,3,139,17,26,136,136,146,20,16,157,153,137,26]

theorem envBound26728 : H12AffineFastState.Bounded env26728 := by
  intro p hp
  have h : env26728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26727_26728 : H12AffineEnvironment.transform 4 17 env26727 = env26728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env26727 == env26728) = true)

theorem identity26728 : scanCanonicalize (H12AffineFastState.compose env26728 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound26728 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env26729 : List Nat := [2,4,8,11,10,10,128,135,1,4,0,137,2,137,136,129,136,0,4,137,137,10,11,3,139,10,1,136,136,137,15,11,134,130,137,1]

theorem envBound26729 : H12AffineFastState.Bounded env26729 := by
  intro p hp
  have h : env26729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26728_26729 : H12AffineEnvironment.transform 3 11 env26728 = env26729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env26728 == env26729) = true)

theorem identity26729 : scanCanonicalize (H12AffineFastState.compose env26729 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound26729 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env26730 : List Nat := [2,4,8,11,10,10,9,14,1,4,0,0,2,0,1,8,1,0,4,0,0,10,11,3,2,10,1,1,1,0,15,11,15,11,0,1]

theorem envBound26730 : H12AffineFastState.Bounded env26730 := by
  intro p hp
  have h : env26730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26729_26730 : H12AffineEnvironment.transform 6 9 env26729 = env26730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env26729 == env26730) = true)

theorem identity26730 : scanCanonicalize (H12AffineFastState.compose env26730 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound26730 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26731 : List Nat := [2,3,8,11,10,10,9,9,1,3,0,0,2,0,1,8,1,0,3,0,0,10,11,3,2,10,1,1,1,0,8,11,8,11,0,1]

theorem envBound26731 : H12AffineFastState.Bounded env26731 := by
  intro p hp
  have h : env26731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26730_26731 : H12AffineEnvironment.transform 1 3 env26730 = env26731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env26730 == env26731) = true)

def env26732 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32882,1345,262144,42333,32769,1345,41089,16,263632,33236,41245,42275,1296,42060,43129,262563,262567,257,1281,1344,41821]

theorem envBound26732 : H12AffineFastState.Bounded env26732 := by
  intro p hp
  have h : env26732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26718_26732 : H12AffineEnvironment.transform 11 1345 env26718 = env26732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env26718 == env26732) = true)

theorem identity26732 : scanCanonicalize (H12AffineFastState.compose env26732 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 73) := by decide +kernel

theorem selectedBound26732 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env26733 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,73,1297,32768,32882,1345,262144,34068,32769,1345,32968,16,263632,33236,33108,34154,1296,33797,34864,262563,262567,257,1281,1344,33556]

theorem envBound26733 : H12AffineFastState.Bounded env26733 := by
  intro p hp
  have h : env26733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26732_26733 : H12AffineEnvironment.transform 12 73 env26732 = env26733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env26732 == env26733) = true)

theorem identity26733 : scanCanonicalize (H12AffineFastState.compose env26733 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound26733 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env26734 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,1345,73,1297,32768,32882,1345,262144,34068,32769,1345,32968,16,263632,33236,33108,34154,1296,33797,34864,262563,262567,257,1281,1344,33180]

theorem envBound26734 : H12AffineFastState.Bounded env26734 := by
  intro p hp
  have h : env26734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26733_26734 : H12AffineEnvironment.transform 8 136 env26733 = env26734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env26733 == env26734) = true)

def env26735 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16465,262144,95615,32769,4096,61649,17,284032,86518,94526,77841,1297,74814,96347,381313,365717,257,16401,1344,95103]

theorem envBound26735 : H12AffineFastState.Bounded env26735 := by
  intro p hp
  have h : env26735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26665_26735 : H12AffineEnvironment.transform 16 16465 env26665 = env26735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16465 env26665 == env26735) = true)

def env26736 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1345,262144,77935,32769,4096,46529,17,266384,70886,78894,77841,1297,74814,81227,365713,365717,257,1281,1344,79471]

theorem envBound26736 : H12AffineFastState.Bounded env26736 := by
  intro p hp
  have h : env26736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26735_26736 : H12AffineEnvironment.transform 13 1296 env26735 = env26736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env26735 == env26736) = true)

theorem identity26736 : scanCanonicalize (H12AffineFastState.compose env26736 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32883) := by decide +kernel

theorem selectedBound26736 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env26737 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,32883,1345,262144,45084,32769,4096,46529,17,266384,38037,46173,45154,1297,42061,48440,267490,267494,257,1281,1344,46620]

theorem envBound26737 : H12AffineFastState.Bounded env26737 := by
  intro p hp
  have h : env26737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26736_26737 : H12AffineEnvironment.transform 15 32883 env26736 = env26737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32883 env26736 == env26737) = true)

def env26738 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32883,1345,262144,42332,32769,1344,41089,17,263632,33237,41245,42274,1297,42061,43128,262562,262566,257,1281,1344,41820]

theorem envBound26738 : H12AffineFastState.Bounded env26738 := by
  intro p hp
  have h : env26738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26737_26738 : H12AffineEnvironment.transform 11 1344 env26737 = env26738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env26737 == env26738) = true)

theorem identity26738 : scanCanonicalize (H12AffineFastState.compose env26738 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 9455) := by decide +kernel

theorem selectedBound26738 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env26739 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32883,1345,9455,42332,32769,1344,41089,17,8511,33237,41245,42274,1297,42061,43128,9549,9545,257,1281,1344,41820]

theorem envBound26739 : H12AffineFastState.Bounded env26739 := by
  intro p hp
  have h : env26739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26738_26739 : H12AffineEnvironment.transform 17 9455 env26738 = env26739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 9455 env26738 == env26739) = true)

theorem identity26739 : scanCanonicalize (H12AffineFastState.compose env26739 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound26739 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env26740 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,1344,8192,1296,32768,32883,1345,9455,42332,32769,1344,41089,17,8511,33237,41245,42274,1297,42061,43128,9549,9545,257,1281,1344,41428]

theorem envBound26740 : H12AffineFastState.Bounded env26740 := by
  intro p hp
  have h : env26740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26739_26740 : H12AffineEnvironment.transform 8 136 env26739 = env26740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env26739 == env26740) = true)

def env26741 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32883,1345,262144,42333,32769,1345,41088,17,263633,33236,41244,42275,1297,42061,43129,262563,262567,257,1281,1344,41821]

theorem envBound26741 : H12AffineFastState.Bounded env26741 := by
  intro p hp
  have h : env26741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26737_26741 : H12AffineEnvironment.transform 11 1345 env26737 = env26741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env26737 == env26741) = true)

theorem identity26741 : scanCanonicalize (H12AffineFastState.compose env26741 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 9244) := by decide +kernel

theorem selectedBound26741 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env26742 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,9244,9327,1345,262144,321,9245,1345,1180,17,263633,9672,1280,319,1297,81,3173,262563,262567,257,1281,1344,1857]

theorem envBound26742 : H12AffineFastState.Bounded env26742 := by
  intro p hp
  have h : env26742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26741_26742 : H12AffineEnvironment.transform 14 9244 env26741 = env26742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9244 env26741 == env26742) = true)

theorem identity26742 : scanCanonicalize (H12AffineFastState.compose env26742 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound26742 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env26743 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,0,8192,81,8541,8494,0,262144,321,8540,0,477,17,262288,8329,65,319,80,81,2340,262563,262567,257,64,1,512]

theorem envBound26743 : H12AffineFastState.Bounded env26743 := by
  intro p hp
  have h : env26743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26742_26743 : H12AffineEnvironment.transform 9 321 env26742 = env26743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env26742 == env26743) = true)

theorem identity26743 : scanCanonicalize (H12AffineFastState.compose env26743 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound26743 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env26744 : List Nat := [2,4,8,16,32,64,128,20,512,85,2048,0,8192,81,8265,8250,0,262144,85,8264,0,201,17,262288,8329,65,43,80,81,2096,262327,262323,21,64,1,512]

theorem envBound26744 : H12AffineFastState.Bounded env26744 := by
  intro p hp
  have h : env26744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26743_26744 : H12AffineEnvironment.transform 7 20 env26743 = env26744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env26743 == env26744) = true)

theorem identity26744 : scanCanonicalize (H12AffineFastState.compose env26744 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 657) := by decide +kernel

theorem selectedBound26744 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env26745 : List Nat := [2,4,8,16,32,64,128,20,512,85,2048,0,657,81,728,683,0,262144,85,729,0,201,17,262288,536,65,43,80,81,2096,262327,262323,21,64,1,512]

theorem envBound26745 : H12AffineFastState.Bounded env26745 := by
  intro p hp
  have h : env26745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26744_26745 : H12AffineEnvironment.transform 12 657 env26744 = env26745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 657 env26744 == env26745) = true)

theorem identity26745 : scanCanonicalize (H12AffineFastState.compose env26745 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound26745 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env26746 : List Nat := [2,4,8,16,32,17,128,20,512,4,2048,0,657,0,649,683,0,262144,4,648,0,152,17,262288,536,16,43,1,0,2096,262327,262323,21,17,1,512]

theorem envBound26746 : H12AffineFastState.Bounded env26746 := by
  intro p hp
  have h : env26746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26745_26746 : H12AffineEnvironment.transform 5 17 env26745 = env26746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env26745 == env26746) = true)

theorem identity26746 : scanCanonicalize (H12AffineFastState.compose env26746 (packedSelected [1,3,13] rootPS)) = affineNative (2^(17+1) ^^^ 2097) := by decide +kernel

theorem selectedBound26746 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env26747 : List Nat := [2,4,8,16,32,17,128,20,512,4,2048,0,657,0,649,683,0,2097,4,648,0,152,17,2209,536,16,43,1,0,2096,2182,2178,21,17,1,512]

theorem envBound26747 : H12AffineFastState.Bounded env26747 := by
  intro p hp
  have h : env26747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26746_26747 : H12AffineEnvironment.transform 17 2097 env26746 = env26747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2097 env26746 == env26747) = true)

theorem identity26747 : scanCanonicalize (H12AffineFastState.compose env26747 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 147) := by decide +kernel

theorem selectedBound26747 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env26748 : List Nat := [2,4,8,16,32,17,128,20,512,4,147,0,657,0,649,683,0,162,4,648,0,152,17,50,536,16,43,1,0,163,21,17,21,17,1,512]

theorem envBound26748 : H12AffineFastState.Bounded env26748 := by
  intro p hp
  have h : env26748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26747_26748 : H12AffineEnvironment.transform 10 147 env26747 = env26748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 147 env26747 == env26748) = true)

theorem identity26748 : scanCanonicalize (H12AffineFastState.compose env26748 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 7) := by decide +kernel

theorem selectedBound26748 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26749 : List Nat := [2,4,8,16,32,17,128,20,7,4,147,0,150,0,142,172,0,162,4,143,0,152,17,50,31,16,43,1,0,163,21,17,21,17,1,7]

theorem envBound26749 : H12AffineFastState.Bounded env26749 := by
  intro p hp
  have h : env26749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26748_26749 : H12AffineEnvironment.transform 8 7 env26748 = env26749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 7 env26748 == env26749) = true)

theorem identity26749 : scanCanonicalize (H12AffineFastState.compose env26749 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound26749 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env26750 : List Nat := [2,4,8,16,32,17,8,20,7,4,27,0,30,0,6,36,0,42,4,7,0,16,17,50,31,16,43,1,0,43,21,17,21,17,1,7]

theorem envBound26750 : H12AffineFastState.Bounded env26750 := by
  intro p hp
  have h : env26750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26749_26750 : H12AffineEnvironment.transform 6 8 env26749 = env26750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env26749 == env26750) = true)

theorem identity26750 : scanCanonicalize (H12AffineFastState.compose env26750 (packedSelected [0,2,4] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound26750 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env26751 : List Nat := [2,4,8,10,32,11,8,14,7,4,1,0,4,0,6,36,0,42,4,7,0,10,11,40,5,10,43,1,0,43,15,11,15,11,1,7]

theorem envBound26751 : H12AffineFastState.Bounded env26751 := by
  intro p hp
  have h : env26751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26750_26751 : H12AffineEnvironment.transform 3 10 env26750 = env26751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env26750 == env26751) = true)

theorem identity26751 : scanCanonicalize (H12AffineFastState.compose env26751 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound26751 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26752 : List Nat := [2,4,8,10,12,11,8,14,7,4,1,0,4,0,6,8,0,6,4,7,0,10,11,4,5,10,7,1,0,7,15,11,15,11,1,7]

theorem envBound26752 : H12AffineFastState.Bounded env26752 := by
  intro p hp
  have h : env26752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26751_26752 : H12AffineEnvironment.transform 4 12 env26751 = env26752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env26751 == env26752) = true)

theorem identity26752 : scanCanonicalize (H12AffineFastState.compose env26752 (packedSelected [5] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound26752 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env26753 : List Nat := [2,3,8,10,11,11,8,9,0,3,1,0,3,0,1,8,0,1,3,0,0,10,11,3,2,10,0,1,0,0,8,11,8,11,1,0]

theorem envBound26753 : H12AffineFastState.Bounded env26753 := by
  intro p hp
  have h : env26753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26752_26753 : H12AffineEnvironment.transform 1 3 env26752 = env26753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env26752 == env26753) = true)

def env26754 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1344,262144,77934,32769,4096,46528,17,266385,70887,78895,77841,1297,74814,81226,365712,365717,257,1280,1344,79470]

theorem envBound26754 : H12AffineFastState.Bounded env26754 := by
  intro p hp
  have h : env26754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26735_26754 : H12AffineEnvironment.transform 13 1297 env26735 = env26754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env26735 == env26754) = true)

theorem identity26754 : scanCanonicalize (H12AffineFastState.compose env26754 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound26754 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env26755 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1344,262144,77934,13340,4096,477,17,266385,70887,78895,77841,1297,74814,81226,336013,336008,257,1280,1344,79470]

theorem envBound26755 : H12AffineFastState.Bounded env26755 := by
  intro p hp
  have h : env26755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26754_26755 : H12AffineEnvironment.transform 14 13341 env26754 = env26755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env26754 == env26755) = true)

def env26756 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1344,65664,77934,13340,4096,477,17,69649,70887,78895,77841,1297,74814,81226,8205,8200,257,1280,1344,79470]

theorem envBound26756 : H12AffineFastState.Bounded env26756 := by
  intro p hp
  have h : env26756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26755_26756 : H12AffineEnvironment.transform 17 65664 env26755 = env26756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env26755 == env26756) = true)

theorem identity26756 : scanCanonicalize (H12AffineFastState.compose env26756 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 72) := by decide +kernel

theorem selectedBound26756 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env26757 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,72,1297,5205,65536,1344,65664,69670,5204,4096,477,17,69649,70887,70759,69721,1297,66678,72962,69,64,257,1280,1344,71206]

theorem envBound26757 : H12AffineFastState.Bounded env26757 := by
  intro p hp
  have h : env26757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26756_26757 : H12AffineEnvironment.transform 12 72 env26756 = env26757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env26756 == env26757) = true)

def env26758 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,24,1297,5125,65536,1296,65664,69670,5124,4096,397,17,69649,70839,70711,69641,1297,66598,72962,21,16,257,1280,1296,71206]

theorem envBound26758 : H12AffineFastState.Bounded env26758 := by
  intro p hp
  have h : env26758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26757_26758 : H12AffineEnvironment.transform 5 16 env26757 = env26758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env26757 == env26758) = true)

theorem identity26758 : scanCanonicalize (H12AffineFastState.compose env26758 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound26758 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env26759 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,277,24,1297,1296,65536,1296,65664,65843,1297,277,397,17,65796,66978,66850,65820,1297,66598,68631,21,16,257,1280,1296,67379]

theorem envBound26759 : H12AffineFastState.Bounded env26759 := by
  intro p hp
  have h : env26759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26758_26759 : H12AffineEnvironment.transform 11 277 env26758 = env26759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env26758 == env26759) = true)

theorem identity26759 : scanCanonicalize (H12AffineFastState.compose env26759 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound26759 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env26760 : List Nat := [2,4,8,16,32,16,128,256,512,5,2048,277,24,276,277,65536,277,65664,65843,276,277,397,17,65796,65959,65831,65820,276,65571,67602,21,16,257,261,277,66358]

theorem envBound26760 : H12AffineFastState.Bounded env26760 := by
  intro p hp
  have h : env26760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26759_26760 : H12AffineEnvironment.transform 9 5 env26759 = env26760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env26759 == env26760) = true)

theorem identity26760 : scanCanonicalize (H12AffineFastState.compose env26760 (packedSelected [0,2,7,10,18,19] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound26760 : packedSelected [0,2,7,10,18,19] rootPS < 2^1333 := by decide +kernel

def env26761 : List Nat := [2,4,8,16,32,16,128,256,136,5,2048,277,24,276,277,65536,277,65664,65843,276,277,397,17,65796,65959,65831,65820,276,65571,67602,21,16,257,261,277,65982]

theorem envBound26761 : H12AffineFastState.Bounded env26761 := by
  intro p hp
  have h : env26761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26760_26761 : H12AffineEnvironment.transform 8 136 env26760 = env26761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env26760 == env26761) = true)

theorem identity26761 : scanCanonicalize (H12AffineFastState.compose env26761 (packedSelected [3,8,11,12,15,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 391) := by decide +kernel

theorem selectedBound26761 : packedSelected [3,8,11,12,15,17,18] rootPS < 2^1333 := by decide +kernel

def env26762 : List Nat := [2,4,8,16,32,16,128,256,136,5,391,277,24,276,277,65536,277,65664,65843,276,277,397,17,65796,65959,65831,65820,276,65571,65941,21,16,257,261,277,65982]

theorem envBound26762 : H12AffineFastState.Bounded env26762 := by
  intro p hp
  have h : env26762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26761_26762 : H12AffineEnvironment.transform 10 391 env26761 = env26762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 391 env26761 == env26762) = true)

theorem identity26762 : scanCanonicalize (H12AffineFastState.compose env26762 (packedSelected [0,2,3,5,7,11,13] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound26762 : packedSelected [0,2,3,5,7,11,13] rootPS < 2^1333 := by decide +kernel

def env26763 : List Nat := [2,4,8,16,32,16,128,20,136,5,147,1,24,0,1,65536,1,65664,65575,0,1,153,17,65552,65715,65587,65544,0,65571,65665,21,16,21,17,1,65706]

theorem envBound26763 : H12AffineFastState.Bounded env26763 := by
  intro p hp
  have h : env26763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26762_26763 : H12AffineEnvironment.transform 7 20 env26762 = env26763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env26762 == env26763) = true)

theorem identity26763 : scanCanonicalize (H12AffineFastState.compose env26763 (packedSelected [2,5] rootPS)) = affineNative (2^(15+1) ^^^ 21) := by decide +kernel

theorem selectedBound26763 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env26764 : List Nat := [2,4,8,16,32,16,128,20,136,5,147,1,24,0,1,21,1,149,50,0,1,153,17,5,166,38,29,0,54,148,21,16,21,17,1,191]

theorem envBound26764 : H12AffineFastState.Bounded env26764 := by
  intro p hp
  have h : env26764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26763_26764 : H12AffineEnvironment.transform 15 21 env26763 = env26764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21 env26763 == env26764) = true)

theorem identity26764 : scanCanonicalize (H12AffineFastState.compose env26764 (packedSelected [2,3,8] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound26764 : packedSelected [2,3,8] rootPS < 2^1333 := by decide +kernel

def env26765 : List Nat := [2,4,8,16,32,16,56,20,48,5,43,1,24,0,1,21,1,45,50,0,1,33,17,5,30,38,29,0,54,44,21,16,21,17,1,7]

theorem envBound26765 : H12AffineFastState.Bounded env26765 := by
  intro p hp
  have h : env26765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26764_26765 : H12AffineEnvironment.transform 6 56 env26764 = env26765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env26764 == env26765) = true)

theorem identity26765 : scanCanonicalize (H12AffineFastState.compose env26765 (packedSelected [2,3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound26765 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env26766 : List Nat := [2,2,8,16,32,16,56,18,48,3,43,1,24,0,1,19,1,43,50,0,1,33,17,3,24,32,27,0,48,42,19,16,19,17,1,1]

theorem envBound26766 : H12AffineFastState.Bounded env26766 := by
  intro p hp
  have h : env26766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26765_26766 : H12AffineEnvironment.transform 1 2 env26765 = env26766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env26765 == env26766) = true)

theorem identity26766 : scanCanonicalize (H12AffineFastState.compose env26766 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound26766 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26767 : List Nat := [2,2,8,11,32,11,35,9,43,3,43,1,3,0,1,8,1,43,41,0,1,33,10,3,3,32,0,0,43,42,8,11,8,10,1,1]

theorem envBound26767 : H12AffineFastState.Bounded env26767 := by
  intro p hp
  have h : env26767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26766_26767 : H12AffineEnvironment.transform 3 11 env26766 = env26767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env26766 == env26767) = true)

def env26768 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,25,1297,5124,65536,1297,65664,69670,5125,4096,396,17,69649,70838,70710,69640,1297,66599,72962,20,17,257,1280,1297,71206]

theorem envBound26768 : H12AffineFastState.Bounded env26768 := by
  intro p hp
  have h : env26768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26757_26768 : H12AffineEnvironment.transform 5 17 env26757 = env26768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env26757 == env26768) = true)

theorem identity26768 : scanCanonicalize (H12AffineFastState.compose env26768 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 1331) := by decide +kernel

theorem selectedBound26768 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env26769 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,25,1297,5124,1331,1297,1459,5397,5125,4096,396,17,5410,4485,4357,5435,1297,276,6193,20,17,257,1280,1297,4885]

theorem envBound26769 : H12AffineFastState.Bounded env26769 := by
  intro p hp
  have h : env26769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26768_26769 : H12AffineEnvironment.transform 15 1331 env26768 = env26769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1331 env26768 == env26769) = true)

theorem identity26769 : scanCanonicalize (H12AffineFastState.compose env26769 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound26769 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env26770 : List Nat := [2,4,8,16,32,17,128,256,512,5,2048,4096,25,276,4097,310,276,438,4368,4096,4096,396,17,4391,4485,4357,4414,276,276,6193,20,17,257,261,276,4885]

theorem envBound26770 : H12AffineFastState.Bounded env26770 := by
  intro p hp
  have h : env26770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26769_26770 : H12AffineEnvironment.transform 9 5 env26769 = env26770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env26769 == env26770) = true)

theorem identity26770 : scanCanonicalize (H12AffineFastState.compose env26770 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 2745) := by decide +kernel

theorem selectedBound26770 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env26771 : List Nat := [2,4,8,16,32,17,128,256,512,5,2048,2745,25,276,2744,310,276,438,2985,2745,2745,396,17,2974,2876,3004,2951,276,276,648,20,17,257,261,276,2476]

end H12CloudChart2