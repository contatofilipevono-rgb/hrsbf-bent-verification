import H12CloudChart2Data149

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound37369 : H12AffineFastState.Bounded env37369 := by
  intro p hp
  have h : env37369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37368_37369 : H12AffineEnvironment.transform 14 21041 env37368 = env37369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21041 env37368 == env37369) = true)

theorem identity37369 : scanCanonicalize (H12AffineFastState.compose env37369 (packedSelected [1,4,6,7,8,10,11] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound37369 : packedSelected [1,4,6,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env37370 : List Nat := [2,4,8,16,32,16,128,173,42,4,146,4096,4146,16384,20507,57,20664,16531,16573,20506,4097,4265,4264,186,20483,20497,162,4096,4097,16531,20636,20649,173,168,184,16530]

theorem envBound37370 : H12AffineFastState.Bounded env37370 := by
  intro p hp
  have h : env37370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37369_37370 : H12AffineEnvironment.transform 8 42 env37369 = env37370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env37369 == env37370) = true)

theorem identity37370 : scanCanonicalize (H12AffineFastState.compose env37370 (packedSelected [2,3,4,7,8] rootPS)) = affineNative (2^(13+1) ^^^ 162) := by decide +kernel

theorem selectedBound37370 : packedSelected [2,3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env37371 : List Nat := [2,4,8,16,32,16,128,173,42,4,146,4096,4146,162,4281,57,4122,49,31,4280,4097,4265,4264,186,4257,4275,162,4096,4097,49,4158,4107,173,168,184,48]

theorem envBound37371 : H12AffineFastState.Bounded env37371 := by
  intro p hp
  have h : env37371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37370_37371 : H12AffineEnvironment.transform 13 162 env37370 = env37371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 162 env37370 == env37371) = true)

theorem identity37371 : scanCanonicalize (H12AffineFastState.compose env37371 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound37371 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env37372 : List Nat := [2,4,8,16,16,16,128,157,26,4,146,4096,4098,146,4233,9,4122,1,31,4232,4097,4249,4248,138,4241,4227,146,4096,4097,1,4110,4107,157,152,136,0]

theorem envBound37372 : H12AffineFastState.Bounded env37372 := by
  intro p hp
  have h : env37372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37371_37372 : H12AffineEnvironment.transform 4 16 env37371 = env37372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env37371 == env37372) = true)

theorem identity37372 : scanCanonicalize (H12AffineFastState.compose env37372 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 31) := by decide +kernel

theorem selectedBound37372 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37373 : List Nat := [2,4,8,16,16,16,31,2,26,4,13,4096,4098,13,4118,9,4122,1,31,4119,4097,4102,4103,21,4110,4124,13,4096,4097,1,4110,4107,2,7,23,0]

theorem envBound37373 : H12AffineFastState.Bounded env37373 := by
  intro p hp
  have h : env37373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37372_37373 : H12AffineEnvironment.transform 6 31 env37372 = env37373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 31 env37372 == env37373) = true)

theorem identity37373 : scanCanonicalize (H12AffineFastState.compose env37373 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound37373 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37374 : List Nat := [2,4,8,6,6,6,9,2,12,4,13,4096,4098,13,4096,9,4108,1,9,4097,4097,4102,4103,3,4110,4106,13,4096,4097,1,4110,4107,2,7,1,0]

theorem envBound37374 : H12AffineFastState.Bounded env37374 := by
  intro p hp
  have h : env37374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37373_37374 : H12AffineEnvironment.transform 3 6 env37373 = env37374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env37373 == env37374) = true)

theorem identity37374 : scanCanonicalize (H12AffineFastState.compose env37374 (packedSelected [3] rootPS)) = affineNative (2^(11+1) ^^^ 13) := by decide +kernel

theorem selectedBound37374 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env37375 : List Nat := [2,4,8,6,6,6,9,2,12,4,13,13,15,13,13,9,1,1,9,12,12,11,10,3,3,7,13,13,12,1,3,6,2,7,1,0]

theorem envBound37375 : H12AffineFastState.Bounded env37375 := by
  intro p hp
  have h : env37375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37374_37375 : H12AffineEnvironment.transform 11 13 env37374 = env37375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 13 env37374 == env37375) = true)

def env37376 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61569,147473,58519,143497,20497,508074,148669,148668,96267,90263,131088,173,1196,1213,135680]

theorem envBound37376 : H12AffineFastState.Bounded env37376 := by
  intro p hp
  have h : env37376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37361_37376 : H12AffineEnvironment.transform 5 17 env37361 = env37376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env37361 == env37376) = true)

theorem identity37376 : scanCanonicalize (H12AffineFastState.compose env37376 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 99487) := by decide +kernel

theorem selectedBound37376 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env37377 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,99487,262144,102558,32769,4097,61569,115854,58519,111638,20497,279605,114722,114723,96267,90263,99471,173,1196,1213,104095]

theorem envBound37377 : H12AffineFastState.Bounded env37377 := by
  intro p hp
  have h : env37377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37376_37377 : H12AffineEnvironment.transform 16 99487 env37376 = env37377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 99487 env37376 == env37377) = true)

theorem identity37377 : scanCanonicalize (H12AffineFastState.compose env37377 (packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 184) := by decide +kernel

theorem selectedBound37377 : packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS < 2^1333 := by decide +kernel

def env37378 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,184,32768,65536,99487,262144,102558,32769,4097,45113,99382,42031,111638,4265,263309,98458,98459,80051,73775,99471,173,1196,1213,104095]

theorem envBound37378 : H12AffineFastState.Bounded env37378 := by
  intro p hp
  have h : env37378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37377_37378 : H12AffineEnvironment.transform 13 184 env37377 = env37378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 184 env37377 == env37378) = true)

theorem identity37378 : scanCanonicalize (H12AffineFastState.compose env37378 (packedSelected [3,7,10,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 38047) := by decide +kernel

theorem selectedBound37378 : packedSelected [3,7,10,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env37379 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,184,32768,38047,4096,262144,1025,32769,4097,45113,4265,42031,8329,4265,263309,5125,5124,44076,46256,4112,173,1196,1213,512]

theorem envBound37379 : H12AffineFastState.Bounded env37379 := by
  intro p hp
  have h : env37379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37378_37379 : H12AffineEnvironment.transform 15 38047 env37378 = env37379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38047 env37378 == env37379) = true)

theorem identity37379 : scanCanonicalize (H12AffineFastState.compose env37379 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound37379 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env37380 : List Nat := [2,4,8,16,32,17,128,173,512,4,2048,4096,8192,184,32768,37019,4096,262144,5,32769,4097,45113,4265,41003,8329,4265,262281,4097,4096,43048,45236,4112,173,168,185,512]

theorem envBound37380 : H12AffineFastState.Bounded env37380 := by
  intro p hp
  have h : env37380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37379_37380 : H12AffineEnvironment.transform 9 4 env37379 = env37380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env37379 == env37380) = true)

theorem identity37380 : scanCanonicalize (H12AffineFastState.compose env37380 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 4648) := by decide +kernel

theorem selectedBound37380 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env37381 : List Nat := [2,4,8,16,32,17,128,173,512,4,2048,4096,4648,184,32768,37019,4096,262144,5,32769,4097,33297,4265,37379,4769,4265,262281,4097,4096,39424,33436,4112,173,168,185,512]

theorem envBound37381 : H12AffineFastState.Bounded env37381 := by
  intro p hp
  have h : env37381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37380_37381 : H12AffineEnvironment.transform 12 4648 env37380 = env37381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4648 env37380 == env37381) = true)

theorem identity37381 : scanCanonicalize (H12AffineFastState.compose env37381 (packedSelected [1,3,13] rootPS)) = affineNative (2^(17+1) ^^^ 35513) := by decide +kernel

theorem selectedBound37381 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env37382 : List Nat := [2,4,8,16,32,17,128,173,512,4,2048,4096,4648,184,32768,37019,4096,35513,5,32769,4097,33297,4265,37379,4769,4265,35376,4097,4096,39424,33436,4112,173,168,185,512]

theorem envBound37382 : H12AffineFastState.Bounded env37382 := by
  intro p hp
  have h : env37382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37381_37382 : H12AffineEnvironment.transform 17 35513 env37381 = env37382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35513 env37381 == env37382) = true)

theorem identity37382 : scanCanonicalize (H12AffineFastState.compose env37382 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 2586) := by decide +kernel

theorem selectedBound37382 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env37383 : List Nat := [2,4,8,16,32,17,128,173,512,4,2048,2586,2098,184,32768,35457,2586,35513,5,32769,2587,33297,2739,34841,2235,2739,35376,2587,2586,32794,33436,2570,173,168,185,512]

theorem envBound37383 : H12AffineFastState.Bounded env37383 := by
  intro p hp
  have h : env37383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37382_37383 : H12AffineEnvironment.transform 11 2586 env37382 = env37383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2586 env37382 == env37383) = true)

def env37384 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,16777216,533641,672784,134217728,148801,545088,96346,16876545,135255226,257,151462080,151462016,525824]

theorem envBound37384 : H12AffineFastState.Bounded env37384 := by
  intro p hp
  have h : env37384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37149_37384 : H12AffineEnvironment.transform 24 533641 env37149 = env37384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 533641 env37149 == env37384) = true)

def env37385 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,16777216,533641,672784,17245632,148801,545088,96346,16876545,17363322,257,1280,1344,525824]

theorem envBound37385 : H12AffineFastState.Bounded env37385 := by
  intro p hp
  have h : env37385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37384_37385 : H12AffineEnvironment.transform 26 17245632 env37384 = env37385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245632 env37384 == env37385) = true)

theorem identity37385 : scanCanonicalize (H12AffineFastState.compose env37385 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 74863) := by decide +kernel

theorem selectedBound37385 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env37386 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,524288,32769,4097,61648,91183,16777216,533641,614527,17039791,90414,545088,96346,16876545,17363322,257,1280,1344,525824]

theorem envBound37386 : H12AffineFastState.Bounded env37386 := by
  intro p hp
  have h : env37386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37385_37386 : H12AffineEnvironment.transform 16 74863 env37385 = env37386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 74863 env37385 == env37386) = true)

def env37387 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,524288,32769,4097,61648,91183,123164,533641,614527,385203,90414,545088,96346,25885,594022,257,1280,1344,525824]

theorem envBound37387 : H12AffineFastState.Bounded env37387 := by
  intro p hp
  have h : env37387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37386_37387 : H12AffineEnvironment.transform 23 123164 env37386 = env37387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 123164 env37386 == env37387) = true)

def env37388 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,21584,32769,4097,61648,91183,123164,28889,78895,385203,90414,1296,96346,25885,82998,257,1280,1344,21072]

theorem envBound37388 : H12AffineFastState.Bounded env37388 := by
  intro p hp
  have h : env37388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37387_37388 : H12AffineEnvironment.transform 18 21584 env37387 = env37388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21584 env37387 == env37388) = true)

theorem identity37388 : scanCanonicalize (H12AffineFastState.compose env37388 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 25676) := by decide +kernel

theorem selectedBound37388 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env37389 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,25676,65536,74863,262144,21584,25677,4097,5276,91183,66896,28889,78895,328959,90414,1296,96346,25885,82998,257,1280,1344,21072]

theorem envBound37389 : H12AffineFastState.Bounded env37389 := by
  intro p hp
  have h : env37389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37388_37389 : H12AffineEnvironment.transform 14 25676 env37388 = env37389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25676 env37388 == env37389) = true)

def env37390 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74863,262144,4416,8541,4097,5276,74047,66896,13769,78895,328959,74814,1296,81226,8205,65830,257,1280,1344,5952]

theorem envBound37390 : H12AffineFastState.Bounded env37390 := by
  intro p hp
  have h : env37390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37389_37390 : H12AffineEnvironment.transform 13 1296 env37389 = env37390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env37389 == env37390) = true)

def env37391 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74863,65664,4416,8541,4097,5276,74047,66896,13769,78895,1151,74814,1296,81226,8205,65830,257,1280,1344,5952]

theorem envBound37391 : H12AffineFastState.Bounded env37391 := by
  intro p hp
  have h : env37391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37390_37391 : H12AffineEnvironment.transform 17 65664 env37390 = env37391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env37390 == env37391) = true)

theorem identity37391 : scanCanonicalize (H12AffineFastState.compose env37391 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound37391 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env37392 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,8192,1,8540,65536,74110,65664,4416,8541,4097,4493,74047,65601,12504,78142,366,74031,1,79963,8205,65830,257,17,81,4689]

theorem envBound37392 : H12AffineFastState.Bounded env37392 := by
  intro p hp
  have h : env37392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37391_37392 : H12AffineEnvironment.transform 9 273 env37391 = env37392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env37391 == env37392) = true)

def env37393 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,772,8192,1,8540,65536,74110,65664,580,8541,773,649,74047,65601,9180,74298,366,74031,1,76639,8205,65830,257,17,81,341]

theorem envBound37393 : H12AffineFastState.Bounded env37393 := by
  intro p hp
  have h : env37393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37392_37393 : H12AffineEnvironment.transform 11 772 env37392 = env37393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 772 env37392 == env37393) = true)

def env37394 : List Nat := [2,4,8,16,32,0,128,256,512,273,2048,772,8192,1,8476,65536,74046,65664,516,8477,773,649,74047,65537,9116,74298,302,74031,1,76575,8205,65830,257,17,17,277]

theorem envBound37394 : H12AffineFastState.Bounded env37394 := by
  intro p hp
  have h : env37394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37393_37394 : H12AffineEnvironment.transform 5 0 env37393 = env37394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env37393 == env37394) = true)

theorem identity37394 : scanCanonicalize (H12AffineFastState.compose env37394 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 62) := by decide +kernel

theorem selectedBound37394 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env37395 : List Nat := [2,4,8,16,32,0,128,256,512,273,2048,772,8192,1,8476,62,8448,190,516,8477,773,649,8449,63,9116,8708,302,8465,1,11041,8205,280,257,17,17,277]

theorem envBound37395 : H12AffineFastState.Bounded env37395 := by
  intro p hp
  have h : env37395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37394_37395 : H12AffineEnvironment.transform 15 62 env37394 = env37395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62 env37394 == env37395) = true)

def env37396 : List Nat := [2,4,8,16,32,0,128,256,512,273,2048,772,272,1,12,62,16,190,516,13,773,649,17,63,652,788,302,1,1,2609,285,280,257,17,17,277]

theorem envBound37396 : H12AffineFastState.Bounded env37396 := by
  intro p hp
  have h : env37396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37395_37396 : H12AffineEnvironment.transform 12 272 env37395 = env37396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 272 env37395 == env37396) = true)

theorem identity37396 : scanCanonicalize (H12AffineFastState.compose env37396 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 24) := by decide +kernel

theorem selectedBound37396 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env37397 : List Nat := [2,4,8,16,32,0,128,24,512,9,2048,540,8,1,12,62,16,190,516,13,541,649,17,63,652,524,54,1,1,2609,5,0,25,17,17,13]

theorem envBound37397 : H12AffineFastState.Bounded env37397 := by
  intro p hp
  have h : env37397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37396_37397 : H12AffineEnvironment.transform 7 24 env37396 = env37397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 24 env37396 == env37397) = true)

theorem identity37397 : scanCanonicalize (H12AffineFastState.compose env37397 (packedSelected [0,2,3,5,7,10,11,12,15,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 675) := by decide +kernel

theorem selectedBound37397 : packedSelected [0,2,3,5,7,10,11,12,15,17,18,20] rootPS < 2^1333 := by decide +kernel

def env37398 : List Nat := [2,4,8,16,32,0,128,24,512,9,675,540,8,1,12,62,16,190,516,13,541,649,17,63,652,524,54,1,1,146,5,0,25,17,17,13]

theorem envBound37398 : H12AffineFastState.Bounded env37398 := by
  intro p hp
  have h : env37398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37397_37398 : H12AffineEnvironment.transform 10 675 env37397 = env37398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 675 env37397 == env37398) = true)

theorem identity37398 : scanCanonicalize (H12AffineFastState.compose env37398 (packedSelected [1,3,8,12,13,15] rootPS)) = affineNative (2^(8+1) ^^^ 13) := by decide +kernel

theorem selectedBound37398 : packedSelected [1,3,8,12,13,15] rootPS < 2^1333 := by decide +kernel

def env37399 : List Nat := [2,4,8,16,32,0,128,24,13,9,174,17,8,1,12,62,16,190,9,13,16,132,17,63,129,1,54,1,1,146,5,0,25,17,17,13]

theorem envBound37399 : H12AffineFastState.Bounded env37399 := by
  intro p hp
  have h : env37399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37398_37399 : H12AffineEnvironment.transform 8 13 env37398 = env37399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 13 env37398 == env37399) = true)

theorem identity37399 : scanCanonicalize (H12AffineFastState.compose env37399 (packedSelected [5] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound37399 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env37400 : List Nat := [2,4,8,16,32,0,41,24,13,9,7,17,8,1,12,62,16,23,9,13,16,45,17,63,40,1,54,1,1,59,5,0,25,17,17,13]

theorem envBound37400 : H12AffineFastState.Bounded env37400 := by
  intro p hp
  have h : env37400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37399_37400 : H12AffineEnvironment.transform 6 41 env37399 = env37400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env37399 == env37400) = true)

theorem identity37400 : scanCanonicalize (H12AffineFastState.compose env37400 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound37400 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env37401 : List Nat := [2,4,8,10,32,0,41,2,13,9,7,11,8,1,12,36,10,13,9,13,10,45,11,37,40,1,44,1,1,33,5,0,3,11,11,13]

theorem envBound37401 : H12AffineFastState.Bounded env37401 := by
  intro p hp
  have h : env37401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37400_37401 : H12AffineEnvironment.transform 3 10 env37400 = env37401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env37400 == env37401) = true)

theorem identity37401 : scanCanonicalize (H12AffineFastState.compose env37401 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound37401 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37402 : List Nat := [2,4,8,10,10,0,3,2,13,9,7,11,8,1,12,14,10,13,9,13,10,7,11,15,2,1,6,1,1,11,5,0,3,11,11,13]

theorem envBound37402 : H12AffineFastState.Bounded env37402 := by
  intro p hp
  have h : env37402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37401_37402 : H12AffineEnvironment.transform 4 10 env37401 = env37402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env37401 == env37402) = true)

theorem identity37402 : scanCanonicalize (H12AffineFastState.compose env37402 (packedSelected [7] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound37402 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env37403 : List Nat := [2,2,8,10,10,0,3,2,11,9,1,11,8,1,10,8,10,11,9,11,10,1,11,9,2,1,0,1,1,11,3,0,3,11,11,11]

theorem envBound37403 : H12AffineFastState.Bounded env37403 := by
  intro p hp
  have h : env37403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37402_37403 : H12AffineEnvironment.transform 1 2 env37402 = env37403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env37402 == env37403) = true)

theorem identity37403 : scanCanonicalize (H12AffineFastState.compose env37403 (packedSelected [8] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound37403 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env37404 : List Nat := [2,2,3,1,1,0,3,2,0,2,1,0,3,1,1,3,1,0,2,0,1,1,0,2,2,1,0,1,1,0,3,0,3,0,0,0]

theorem envBound37404 : H12AffineFastState.Bounded env37404 := by
  intro p hp
  have h : env37404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37403_37404 : H12AffineEnvironment.transform 2 3 env37403 = env37404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env37403 == env37404) = true)

def env37405 : List Nat := [2,4,8,16,32,0,128,256,512,273,2048,772,273,1,13,62,17,190,516,12,773,649,16,63,653,789,302,0,1,2608,284,280,257,17,17,277]

theorem envBound37405 : H12AffineFastState.Bounded env37405 := by
  intro p hp
  have h : env37405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37395_37405 : H12AffineEnvironment.transform 12 273 env37395 = env37405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 273 env37395 == env37405) = true)

theorem identity37405 : scanCanonicalize (H12AffineFastState.compose env37405 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound37405 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env37406 : List Nat := [2,4,8,16,32,0,128,20,512,5,2048,528,5,1,13,62,17,190,516,12,529,649,16,63,653,513,58,0,1,2608,8,12,21,17,17,1]

theorem envBound37406 : H12AffineFastState.Bounded env37406 := by
  intro p hp
  have h : env37406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37405_37406 : H12AffineEnvironment.transform 7 20 env37405 = env37406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env37405 == env37406) = true)

theorem identity37406 : scanCanonicalize (H12AffineFastState.compose env37406 (packedSelected [0,1,3,4,7,8,9,10,16,17,19,20] rootPS)) = affineNative (2^(10+1) ^^^ 131) := by decide +kernel

theorem selectedBound37406 : packedSelected [0,1,3,4,7,8,9,10,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env37407 : List Nat := [2,4,8,16,32,0,128,20,512,5,131,528,5,1,13,62,17,190,516,12,529,649,16,63,653,513,58,0,1,691,8,12,21,17,17,1]

theorem envBound37407 : H12AffineFastState.Bounded env37407 := by
  intro p hp
  have h : env37407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37406_37407 : H12AffineEnvironment.transform 10 131 env37406 = env37407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 131 env37406 == env37407) = true)

theorem identity37407 : scanCanonicalize (H12AffineFastState.compose env37407 (packedSelected [0,1,3,7,12,15,16] rootPS)) = affineNative (2^(8+1) ^^^ 184) := by decide +kernel

theorem selectedBound37407 : packedSelected [0,1,3,7,12,15,16] rootPS < 2^1333 := by decide +kernel

def env37408 : List Nat := [2,4,8,16,32,0,128,20,184,5,131,168,5,1,13,62,17,190,188,12,169,49,16,63,53,185,58,0,1,11,8,12,21,17,17,1]

theorem envBound37408 : H12AffineFastState.Bounded env37408 := by
  intro p hp
  have h : env37408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37407_37408 : H12AffineEnvironment.transform 8 184 env37407 = env37408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 184 env37407 == env37408) = true)

theorem identity37408 : scanCanonicalize (H12AffineFastState.compose env37408 (packedSelected [1,3,5,7,9,10,11] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound37408 : packedSelected [1,3,5,7,9,10,11] rootPS < 2^1333 := by decide +kernel

def env37409 : List Nat := [2,4,2,16,32,0,128,20,178,5,131,162,5,1,7,52,17,180,182,6,163,49,16,53,53,179,48,0,1,1,2,6,21,17,17,1]

theorem envBound37409 : H12AffineFastState.Bounded env37409 := by
  intro p hp
  have h : env37409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37408_37409 : H12AffineEnvironment.transform 2 2 env37408 = env37409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env37408 == env37409) = true)

theorem identity37409 : scanCanonicalize (H12AffineFastState.compose env37409 (packedSelected [1,2,3,4,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound37409 : packedSelected [1,2,3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env37410 : List Nat := [2,4,2,16,32,0,4,20,54,5,7,38,5,1,7,52,17,48,50,6,39,49,16,53,53,55,48,0,1,1,2,6,21,17,17,1]

theorem envBound37410 : H12AffineFastState.Bounded env37410 := by
  intro p hp
  have h : env37410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37409_37410 : H12AffineEnvironment.transform 6 4 env37409 = env37410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env37409 == env37410) = true)

theorem identity37410 : scanCanonicalize (H12AffineFastState.compose env37410 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound37410 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37411 : List Nat := [2,4,2,6,32,0,4,2,32,5,7,38,5,1,7,34,7,38,36,6,39,39,6,35,35,33,38,0,1,1,2,6,3,7,7,1]

theorem envBound37411 : H12AffineFastState.Bounded env37411 := by
  intro p hp
  have h : env37411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37410_37411 : H12AffineEnvironment.transform 3 6 env37410 = env37411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env37410 == env37411) = true)

theorem identity37411 : scanCanonicalize (H12AffineFastState.compose env37411 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound37411 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env37412 : List Nat := [2,3,2,1,32,0,3,2,32,2,0,33,2,1,0,34,0,33,35,1,32,32,1,35,35,33,33,0,1,1,2,1,3,0,0,1]

theorem envBound37412 : H12AffineFastState.Bounded env37412 := by
  intro p hp
  have h : env37412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37411_37412 : H12AffineEnvironment.transform 1 3 env37411 = env37412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env37411 == env37412) = true)

def env37413 : List Nat := [2,4,8,16,32,1,128,256,512,273,2048,772,8192,1,8477,65536,74047,65664,517,8476,773,649,74047,65536,9117,74298,303,74031,1,76574,8205,65830,257,17,16,276]

theorem envBound37413 : H12AffineFastState.Bounded env37413 := by
  intro p hp
  have h : env37413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37393_37413 : H12AffineEnvironment.transform 5 1 env37393 = env37413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env37393 == env37413) = true)

theorem identity37413 : scanCanonicalize (H12AffineFastState.compose env37413 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 8230) := by decide +kernel

theorem selectedBound37413 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env37414 : List Nat := [2,4,8,16,32,1,128,256,512,273,2048,772,8192,1,8477,8230,281,8358,517,8476,773,649,281,8230,9117,540,303,265,1,2872,8205,8448,257,17,16,276]

theorem envBound37414 : H12AffineFastState.Bounded env37414 := by
  intro p hp
  have h : env37414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37413_37414 : H12AffineEnvironment.transform 15 8230 env37413 = env37414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8230 env37413 == env37414) = true)

def env37415 : List Nat := [2,4,8,16,32,1,128,256,512,273,2048,772,272,1,13,310,281,438,517,12,773,649,281,310,653,540,303,265,1,2872,285,16,257,17,16,276]

theorem envBound37415 : H12AffineFastState.Bounded env37415 := by
  intro p hp
  have h : env37415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37414_37415 : H12AffineEnvironment.transform 12 272 env37414 = env37415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 272 env37414 == env37415) = true)

theorem identity37415 : scanCanonicalize (H12AffineFastState.compose env37415 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 25) := by decide +kernel

theorem selectedBound37415 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env37416 : List Nat := [2,4,8,16,32,1,128,25,512,8,2048,541,9,1,13,47,0,175,517,12,540,649,0,47,653,540,54,16,1,2593,4,16,24,17,16,13]

theorem envBound37416 : H12AffineFastState.Bounded env37416 := by
  intro p hp
  have h : env37416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37415_37416 : H12AffineEnvironment.transform 7 25 env37415 = env37416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 25 env37415 == env37416) = true)

theorem identity37416 : scanCanonicalize (H12AffineFastState.compose env37416 (packedSelected [4,9,16] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound37416 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env37417 : List Nat := [2,4,5,16,32,1,128,20,512,5,2048,528,4,1,0,34,0,162,517,1,529,644,0,34,640,529,54,16,1,2593,4,16,21,17,16,0]

theorem envBound37417 : H12AffineFastState.Bounded env37417 := by
  intro p hp
  have h : env37417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37416_37417 : H12AffineEnvironment.transform 2 5 env37416 = env37417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env37416 == env37417) = true)

theorem identity37417 : scanCanonicalize (H12AffineFastState.compose env37417 (packedSelected [2,8,10,12,13] rootPS)) = affineNative (2^(6+1) ^^^ 20) := by decide +kernel

theorem selectedBound37417 : packedSelected [2,8,10,12,13] rootPS < 2^1333 := by decide +kernel

def env37418 : List Nat := [2,4,5,16,32,1,20,20,512,5,2048,528,4,1,0,34,0,54,517,1,529,528,0,34,532,529,54,16,1,2593,4,16,21,17,16,0]

theorem envBound37418 : H12AffineFastState.Bounded env37418 := by
  intro p hp
  have h : env37418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37417_37418 : H12AffineEnvironment.transform 6 20 env37417 = env37418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 20 env37417 == env37418) = true)

theorem identity37418 : scanCanonicalize (H12AffineFastState.compose env37418 (packedSelected [0,2,5,7,10,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound37418 : packedSelected [0,2,5,7,10,11,12] rootPS < 2^1333 := by decide +kernel

def env37419 : List Nat := [2,4,5,16,32,1,20,20,512,5,0,528,4,1,0,34,0,54,517,1,529,528,0,34,532,529,54,16,1,545,4,16,21,17,16,0]

theorem envBound37419 : H12AffineFastState.Bounded env37419 := by
  intro p hp
  have h : env37419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37418_37419 : H12AffineEnvironment.transform 10 0 env37418 = env37419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env37418 == env37419) = true)

theorem identity37419 : scanCanonicalize (H12AffineFastState.compose env37419 (packedSelected [1,2,3,5] rootPS)) = affineNative (2^(8+1) ^^^ 54) := by decide +kernel

theorem selectedBound37419 : packedSelected [1,2,3,5] rootPS < 2^1333 := by decide +kernel

def env37420 : List Nat := [2,4,5,16,32,1,20,20,54,5,0,38,4,1,0,34,0,54,51,1,39,38,0,34,34,39,54,16,1,23,4,16,21,17,16,0]

theorem envBound37420 : H12AffineFastState.Bounded env37420 := by
  intro p hp
  have h : env37420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37419_37420 : H12AffineEnvironment.transform 8 54 env37419 = env37420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 54 env37419 == env37420) = true)

theorem identity37420 : scanCanonicalize (H12AffineFastState.compose env37420 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound37420 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env37421 : List Nat := [2,4,5,16,17,1,20,20,7,5,0,23,4,1,0,19,0,7,2,1,22,23,0,19,19,22,7,16,1,23,4,16,21,17,16,0]

theorem envBound37421 : H12AffineFastState.Bounded env37421 := by
  intro p hp
  have h : env37421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37420_37421 : H12AffineEnvironment.transform 4 17 env37420 = env37421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env37420 == env37421) = true)

theorem identity37421 : scanCanonicalize (H12AffineFastState.compose env37421 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound37421 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37422 : List Nat := [2,2,3,16,17,1,18,18,1,3,0,17,2,1,0,19,0,1,2,1,16,17,0,19,19,16,1,16,1,17,2,16,19,17,16,0]

theorem envBound37422 : H12AffineFastState.Bounded env37422 := by
  intro p hp
  have h : env37422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37421_37422 : H12AffineEnvironment.transform 1 2 env37421 = env37422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env37421 == env37422) = true)

theorem identity37422 : scanCanonicalize (H12AffineFastState.compose env37422 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound37422 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37423 : List Nat := [1,1,0,16,17,1,17,17,1,0,0,17,1,1,0,16,0,1,1,1,16,17,0,16,16,16,1,16,1,17,1,16,16,17,16,0]

theorem envBound37423 : H12AffineFastState.Bounded env37423 := by
  intro p hp
  have h : env37423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37422_37423 : H12AffineEnvironment.transform 0 1 env37422 = env37423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env37422 == env37423) = true)

theorem identity37423 : scanCanonicalize (H12AffineFastState.compose env37423 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound37423 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37424 : List Nat := [1,1,0,0,1,1,1,1,1,0,0,1,1,1,0,0,0,1,1,1,0,1,0,0,0,0,1,0,1,1,1,0,0,1,0,0]

theorem envBound37424 : H12AffineFastState.Bounded env37424 := by
  intro p hp
  have h : env37424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37423_37424 : H12AffineEnvironment.transform 3 0 env37423 = env37424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env37423 == env37424) = true)

def env37425 : List Nat := [2,4,8,16,32,1,128,256,512,273,2048,772,273,1,12,311,281,439,517,13,773,649,281,311,652,540,303,265,1,2872,284,17,257,17,16,276]

theorem envBound37425 : H12AffineFastState.Bounded env37425 := by
  intro p hp
  have h : env37425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37414_37425 : H12AffineEnvironment.transform 12 273 env37414 = env37425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 273 env37414 == env37425) = true)

theorem identity37425 : scanCanonicalize (H12AffineFastState.compose env37425 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound37425 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env37426 : List Nat := [2,4,8,16,32,1,128,20,512,5,2048,528,5,1,12,35,13,163,517,13,529,649,13,35,652,540,59,29,1,2604,8,17,21,17,16,0]

theorem envBound37426 : H12AffineFastState.Bounded env37426 := by
  intro p hp
  have h : env37426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37425_37426 : H12AffineEnvironment.transform 7 20 env37425 = env37426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env37425 == env37426) = true)

theorem identity37426 : scanCanonicalize (H12AffineFastState.compose env37426 (packedSelected [4,5,8,9,10,13,15,16,17] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound37426 : packedSelected [4,5,8,9,10,13,15,16,17] rootPS < 2^1333 := by decide +kernel

def env37427 : List Nat := [2,4,8,16,32,1,128,20,48,5,2048,32,5,1,12,35,13,163,53,13,33,185,13,35,188,44,59,29,1,2076,8,17,21,17,16,0]

theorem envBound37427 : H12AffineFastState.Bounded env37427 := by
  intro p hp
  have h : env37427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37426_37427 : H12AffineEnvironment.transform 8 48 env37426 = env37427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env37426 == env37427) = true)

theorem identity37427 : scanCanonicalize (H12AffineFastState.compose env37427 (packedSelected [0,2,3,4,7,9,10,12,16,18] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound37427 : packedSelected [0,2,3,4,7,9,10,12,16,18] rootPS < 2^1333 := by decide +kernel

def env37428 : List Nat := [2,3,8,16,32,1,128,19,48,2,2048,32,2,1,11,35,10,163,50,10,33,185,10,35,187,43,59,26,1,2075,8,17,18,17,16,0]

theorem envBound37428 : H12AffineFastState.Bounded env37428 := by
  intro p hp
  have h : env37428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37427_37428 : H12AffineEnvironment.transform 1 3 env37427 = env37428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env37427 == env37428) = true)

theorem identity37428 : scanCanonicalize (H12AffineFastState.compose env37428 (packedSelected [0,2,3,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound37428 : packedSelected [0,2,3,7,8] rootPS < 2^1333 := by decide +kernel

def env37429 : List Nat := [2,3,8,16,26,1,128,19,10,2,2048,26,2,1,11,25,10,153,8,10,27,131,10,25,129,17,1,26,1,2075,8,17,18,17,16,0]

theorem envBound37429 : H12AffineFastState.Bounded env37429 := by
  intro p hp
  have h : env37429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37428_37429 : H12AffineEnvironment.transform 4 26 env37428 = env37429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env37428 == env37429) = true)

theorem identity37429 : scanCanonicalize (H12AffineFastState.compose env37429 (packedSelected [0,2,5,9] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound37429 : packedSelected [0,2,5,9] rootPS < 2^1333 := by decide +kernel

def env37430 : List Nat := [2,3,2,16,16,1,128,19,0,2,2048,16,2,1,1,19,0,147,2,0,17,131,0,19,129,17,1,16,1,2065,2,17,18,17,16,0]

theorem envBound37430 : H12AffineFastState.Bounded env37430 := by
  intro p hp
  have h : env37430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37429_37430 : H12AffineEnvironment.transform 2 2 env37429 = env37430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env37429 == env37430) = true)

theorem identity37430 : scanCanonicalize (H12AffineFastState.compose env37430 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound37430 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37431 : List Nat := [2,3,2,16,16,1,128,19,0,2,1,16,2,1,1,19,0,147,2,0,17,131,0,19,129,17,1,16,1,16,2,17,18,17,16,0]

theorem envBound37431 : H12AffineFastState.Bounded env37431 := by
  intro p hp
  have h : env37431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37430_37431 : H12AffineEnvironment.transform 10 1 env37430 = env37431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env37430 == env37431) = true)

def env37432 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,773,8192,1,8540,65536,74110,65664,581,8541,772,648,74047,65601,9181,74299,366,74031,1,76638,8205,65830,257,17,81,340]

theorem envBound37432 : H12AffineFastState.Bounded env37432 := by
  intro p hp
  have h : env37432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37392_37432 : H12AffineEnvironment.transform 11 773 env37392 = env37432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 773 env37392 == env37432) = true)

def env37433 : List Nat := [2,4,8,16,32,0,128,256,512,273,2048,773,8192,1,8476,65536,74046,65664,517,8477,772,648,74047,65537,9117,74299,302,74031,1,76574,8205,65830,257,17,17,276]

theorem envBound37433 : H12AffineFastState.Bounded env37433 := by
  intro p hp
  have h : env37433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37432_37433 : H12AffineEnvironment.transform 5 0 env37432 = env37433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env37432 == env37433) = true)

theorem identity37433 : scanCanonicalize (H12AffineFastState.compose env37433 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 272) := by decide +kernel

theorem selectedBound37433 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env37434 : List Nat := [2,4,8,16,32,0,128,256,512,273,2048,773,272,1,12,65536,65582,65664,517,13,772,648,65583,65537,653,66347,302,65599,1,68110,285,65830,257,17,17,276]

theorem envBound37434 : H12AffineFastState.Bounded env37434 := by
  intro p hp
  have h : env37434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37433_37434 : H12AffineEnvironment.transform 12 272 env37433 = env37434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 272 env37433 == env37434) = true)

def env37435 : List Nat := [2,4,4,16,32,0,128,256,512,273,2048,773,272,1,0,65536,65570,65664,517,1,772,644,65571,65537,641,66343,290,65587,1,68098,273,65830,257,17,17,276]

theorem envBound37435 : H12AffineFastState.Bounded env37435 := by
  intro p hp
  have h : env37435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37434_37435 : H12AffineEnvironment.transform 2 4 env37434 = env37435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env37434 == env37435) = true)

theorem identity37435 : scanCanonicalize (H12AffineFastState.compose env37435 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound37435 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env37436 : List Nat := [2,4,4,16,32,0,128,20,512,5,2048,529,4,1,0,65536,65570,65664,517,1,528,644,65571,65537,641,66099,54,65587,1,68098,5,65586,21,17,17,0]

theorem envBound37436 : H12AffineFastState.Bounded env37436 := by
  intro p hp
  have h : env37436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37435_37436 : H12AffineEnvironment.transform 7 20 env37435 = env37436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env37435 == env37436) = true)

theorem identity37436 : scanCanonicalize (H12AffineFastState.compose env37436 (packedSelected [0,3,4,7,8,9,10,12,13,16,17,18,19] rootPS)) = affineNative (2^(10+1) ^^^ 677) := by decide +kernel

theorem selectedBound37436 : packedSelected [0,3,4,7,8,9,10,12,13,16,17,18,19] rootPS < 2^1333 := by decide +kernel

def env37437 : List Nat := [2,4,4,16,32,0,128,20,512,5,677,529,4,1,0,65536,65570,65664,517,1,528,644,65571,65537,641,66099,54,65587,1,65703,5,65586,21,17,17,0]

theorem envBound37437 : H12AffineFastState.Bounded env37437 := by
  intro p hp
  have h : env37437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37436_37437 : H12AffineEnvironment.transform 10 677 env37436 = env37437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 677 env37436 == env37437) = true)

theorem identity37437 : scanCanonicalize (H12AffineFastState.compose env37437 (packedSelected [1,2,5,8] rootPS)) = affineNative (2^(15+1) ^^^ 688) := by decide +kernel

theorem selectedBound37437 : packedSelected [1,2,5,8] rootPS < 2^1333 := by decide +kernel

def env37438 : List Nat := [2,4,4,16,32,0,128,20,512,5,677,529,4,1,0,688,658,560,517,1,528,644,659,689,641,131,54,643,1,535,5,642,21,17,17,0]

theorem envBound37438 : H12AffineFastState.Bounded env37438 := by
  intro p hp
  have h : env37438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37437_37438 : H12AffineEnvironment.transform 15 688 env37437 = env37438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 688 env37437 == env37438) = true)

theorem identity37438 : scanCanonicalize (H12AffineFastState.compose env37438 (packedSelected [0,5,7,10,11,13] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound37438 : packedSelected [0,5,7,10,11,13] rootPS < 2^1333 := by decide +kernel

def env37439 : List Nat := [2,4,4,16,6,0,128,20,512,5,643,529,4,1,0,662,658,534,517,1,528,644,659,663,641,131,16,643,1,535,5,642,21,17,17,0]

theorem envBound37439 : H12AffineFastState.Bounded env37439 := by
  intro p hp
  have h : env37439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37438_37439 : H12AffineEnvironment.transform 4 6 env37438 = env37439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env37438 == env37439) = true)

theorem identity37439 : scanCanonicalize (H12AffineFastState.compose env37439 (packedSelected [0,1,2,3,7] rootPS)) = affineNative (2^(8+1) ^^^ 149) := by decide +kernel

theorem selectedBound37439 : packedSelected [0,1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env37440 : List Nat := [2,4,4,16,6,0,128,20,149,5,22,132,4,1,0,3,7,131,144,1,133,17,6,2,20,131,16,22,1,130,5,23,21,17,17,0]

theorem envBound37440 : H12AffineFastState.Bounded env37440 := by
  intro p hp
  have h : env37440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37439_37440 : H12AffineEnvironment.transform 8 149 env37439 = env37440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 149 env37439 == env37440) = true)

theorem identity37440 : scanCanonicalize (H12AffineFastState.compose env37440 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound37440 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37441 : List Nat := [2,4,4,16,6,0,19,20,6,5,22,23,4,1,0,3,7,16,3,1,22,17,6,2,20,16,16,22,1,17,5,23,21,17,17,0]

theorem envBound37441 : H12AffineFastState.Bounded env37441 := by
  intro p hp
  have h : env37441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37440_37441 : H12AffineEnvironment.transform 6 19 env37440 = env37441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env37440 == env37441) = true)

theorem identity37441 : scanCanonicalize (H12AffineFastState.compose env37441 (packedSelected [1,3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound37441 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env37442 : List Nat := [2,2,2,16,0,0,19,18,0,3,16,17,2,1,0,3,1,16,3,1,16,17,0,2,18,16,16,16,1,17,3,17,19,17,17,0]

theorem envBound37442 : H12AffineFastState.Bounded env37442 := by
  intro p hp
  have h : env37442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37441_37442 : H12AffineEnvironment.transform 1 2 env37441 = env37442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env37441 == env37442) = true)

theorem identity37442 : scanCanonicalize (H12AffineFastState.compose env37442 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound37442 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37443 : List Nat := [2,2,2,0,0,0,3,2,0,3,0,1,2,1,0,3,1,0,3,1,0,1,0,2,2,0,0,0,1,1,3,1,3,1,1,0]

theorem envBound37443 : H12AffineFastState.Bounded env37443 := by
  intro p hp
  have h : env37443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37442_37443 : H12AffineEnvironment.transform 3 0 env37442 = env37443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env37442 == env37443) = true)

def env37444 : List Nat := [2,4,5,16,32,0,128,256,512,273,2048,773,272,1,1,65536,65571,65664,517,0,772,645,65570,65537,640,66342,291,65586,1,68099,272,65830,257,17,17,276]

theorem envBound37444 : H12AffineFastState.Bounded env37444 := by
  intro p hp
  have h : env37444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37434_37444 : H12AffineEnvironment.transform 2 5 env37434 = env37444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env37434 == env37444) = true)

theorem identity37444 : scanCanonicalize (H12AffineFastState.compose env37444 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound37444 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env37445 : List Nat := [2,4,5,16,32,0,128,256,512,273,2048,773,272,1,1,35,0,163,517,0,772,645,1,34,640,773,291,17,1,2592,272,261,257,17,17,276]

theorem envBound37445 : H12AffineFastState.Bounded env37445 := by
  intro p hp
  have h : env37445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37444_37445 : H12AffineEnvironment.transform 15 35 env37444 = env37445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env37444 == env37445) = true)

theorem identity37445 : scanCanonicalize (H12AffineFastState.compose env37445 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound37445 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env37446 : List Nat := [2,4,5,16,32,0,128,20,512,5,2048,529,4,1,1,35,0,163,517,0,528,645,1,34,640,529,55,17,1,2592,4,17,21,17,17,0]

theorem envBound37446 : H12AffineFastState.Bounded env37446 := by
  intro p hp
  have h : env37446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37445_37446 : H12AffineEnvironment.transform 7 20 env37445 = env37446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env37445 == env37446) = true)

theorem identity37446 : scanCanonicalize (H12AffineFastState.compose env37446 (packedSelected [2,8,10,12,13] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound37446 : packedSelected [2,8,10,12,13] rootPS < 2^1333 := by decide +kernel

def env37447 : List Nat := [2,4,5,16,32,0,128,20,512,5,528,529,4,1,1,35,0,163,517,0,528,645,1,34,640,529,55,17,1,48,4,17,21,17,17,0]

theorem envBound37447 : H12AffineFastState.Bounded env37447 := by
  intro p hp
  have h : env37447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37446_37447 : H12AffineEnvironment.transform 10 528 env37446 = env37447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env37446 == env37447) = true)

theorem identity37447 : scanCanonicalize (H12AffineFastState.compose env37447 (packedSelected [1,3,5,10,12] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound37447 : packedSelected [1,3,5,10,12] rootPS < 2^1333 := by decide +kernel

def env37448 : List Nat := [2,4,5,16,32,0,128,20,33,5,49,48,4,1,1,35,0,163,36,0,49,164,1,34,161,48,55,17,1,48,4,17,21,17,17,0]

theorem envBound37448 : H12AffineFastState.Bounded env37448 := by
  intro p hp
  have h : env37448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37447_37448 : H12AffineEnvironment.transform 8 33 env37447 = env37448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env37447 == env37448) = true)

theorem identity37448 : scanCanonicalize (H12AffineFastState.compose env37448 (packedSelected [3,8] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound37448 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env37449 : List Nat := [2,4,5,16,0,0,128,20,1,5,17,16,4,1,1,3,0,131,4,0,17,132,1,2,129,16,23,17,1,16,4,17,21,17,17,0]

theorem envBound37449 : H12AffineFastState.Bounded env37449 := by
  intro p hp
  have h : env37449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37448_37449 : H12AffineEnvironment.transform 4 0 env37448 = env37449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env37448 == env37449) = true)

theorem identity37449 : scanCanonicalize (H12AffineFastState.compose env37449 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound37449 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37450 : List Nat := [2,0,1,16,0,0,128,16,1,1,17,16,0,1,1,3,0,131,0,0,17,128,1,2,129,16,19,17,1,16,0,17,17,17,17,0]

theorem envBound37450 : H12AffineFastState.Bounded env37450 := by
  intro p hp
  have h : env37450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37449_37450 : H12AffineEnvironment.transform 1 0 env37449 = env37450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env37449 == env37450) = true)

theorem identity37450 : scanCanonicalize (H12AffineFastState.compose env37450 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound37450 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37451 : List Nat := [2,0,1,0,0,0,128,0,1,1,1,0,0,1,1,3,0,131,0,0,1,128,1,2,129,0,3,1,1,0,0,1,1,1,1,0]

theorem envBound37451 : H12AffineFastState.Bounded env37451 := by
  intro p hp
  have h : env37451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37450_37451 : H12AffineEnvironment.transform 3 0 env37450 = env37451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env37450 == env37451) = true)

def env37452 : List Nat := [2,4,8,16,32,1,128,256,512,273,2048,773,8192,1,8477,65536,74047,65664,516,8476,772,648,74047,65536,9116,74299,303,74031,1,76575,8205,65830,257,17,16,277]

theorem envBound37452 : H12AffineFastState.Bounded env37452 := by
  intro p hp
  have h : env37452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37432_37452 : H12AffineEnvironment.transform 5 1 env37432 = env37452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env37432 == env37452) = true)

theorem identity37452 : scanCanonicalize (H12AffineFastState.compose env37452 (packedSelected [1,8,28] rootPS)) = affineNative (2^(7+1) ^^^ 8) := by decide +kernel

theorem selectedBound37452 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env37453 : List Nat := [2,4,8,16,32,1,128,8,512,25,2048,525,8192,1,8213,65536,73783,65664,516,8212,524,648,73783,65536,8852,74299,39,73767,1,76311,8205,65582,9,17,16,29]

theorem envBound37453 : H12AffineFastState.Bounded env37453 := by
  intro p hp
  have h : env37453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37452_37453 : H12AffineEnvironment.transform 7 8 env37452 = env37453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 8 env37452 == env37453) = true)

def env37454 : List Nat := [2,4,8,16,32,1,128,8,512,25,2048,525,24,1,13,65536,65583,65664,516,12,524,648,65583,65536,652,66083,39,65599,1,68111,21,65582,9,17,16,29]

theorem envBound37454 : H12AffineFastState.Bounded env37454 := by
  intro p hp
  have h : env37454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37453_37454 : H12AffineEnvironment.transform 12 24 env37453 = env37454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env37453 == env37454) = true)

theorem identity37454 : scanCanonicalize (H12AffineFastState.compose env37454 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 51) := by decide +kernel

theorem selectedBound37454 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env37455 : List Nat := [2,4,8,16,32,1,128,8,512,25,2048,525,24,1,13,51,28,179,516,12,524,648,28,51,652,528,39,12,1,2620,21,29,9,17,16,29]

theorem envBound37455 : H12AffineFastState.Bounded env37455 := by
  intro p hp
  have h : env37455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37454_37455 : H12AffineEnvironment.transform 15 51 env37454 = env37455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 51 env37454 == env37455) = true)

theorem identity37455 : scanCanonicalize (H12AffineFastState.compose env37455 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound37455 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env37456 : List Nat := [2,4,8,12,32,1,128,8,512,5,2048,525,4,1,13,47,0,175,516,12,524,648,0,47,652,524,39,12,1,2592,9,1,9,13,12,1]

theorem envBound37456 : H12AffineFastState.Bounded env37456 := by
  intro p hp
  have h : env37456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37455_37456 : H12AffineEnvironment.transform 3 12 env37455 = env37456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env37455 == env37456) = true)

theorem identity37456 : scanCanonicalize (H12AffineFastState.compose env37456 (packedSelected [0,1,5,7,8,10,11,12,15] rootPS)) = affineNative (2^(8+1) ^^^ 142) := by decide +kernel

theorem selectedBound37456 : packedSelected [0,1,5,7,8,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env37457 : List Nat := [2,4,8,12,32,1,128,8,142,5,2048,131,4,1,13,47,0,175,138,12,130,6,0,47,2,130,39,12,1,2222,9,1,9,13,12,1]

theorem envBound37457 : H12AffineFastState.Bounded env37457 := by
  intro p hp
  have h : env37457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37456_37457 : H12AffineEnvironment.transform 8 142 env37456 = env37457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 142 env37456 == env37457) = true)

theorem identity37457 : scanCanonicalize (H12AffineFastState.compose env37457 (packedSelected [0,2,7,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 168) := by decide +kernel

theorem selectedBound37457 : packedSelected [0,2,7,8,11] rootPS < 2^1333 := by decide +kernel

def env37458 : List Nat := [2,4,8,12,32,1,128,8,142,5,168,131,4,1,13,47,0,175,138,12,130,6,0,47,2,130,39,12,1,6,9,1,9,13,12,1]

theorem envBound37458 : H12AffineFastState.Bounded env37458 := by
  intro p hp
  have h : env37458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37457_37458 : H12AffineEnvironment.transform 10 168 env37457 = env37458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 168 env37457 == env37458) = true)

theorem identity37458 : scanCanonicalize (H12AffineFastState.compose env37458 (packedSelected [0,1,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound37458 : packedSelected [0,1,5,7] rootPS < 2^1333 := by decide +kernel

def env37459 : List Nat := [2,4,8,12,13,1,128,8,142,5,133,131,4,1,13,2,0,130,138,12,130,6,0,2,2,130,10,12,1,6,9,1,9,13,12,1]

theorem envBound37459 : H12AffineFastState.Bounded env37459 := by
  intro p hp
  have h : env37459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37458_37459 : H12AffineEnvironment.transform 4 13 env37458 = env37459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env37458 == env37459) = true)

theorem identity37459 : scanCanonicalize (H12AffineFastState.compose env37459 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 15) := by decide +kernel

theorem selectedBound37459 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37460 : List Nat := [2,4,8,12,13,1,15,8,1,5,10,12,4,1,13,2,0,13,5,12,13,6,0,2,2,13,10,12,1,6,9,1,9,13,12,1]

theorem envBound37460 : H12AffineFastState.Bounded env37460 := by
  intro p hp
  have h : env37460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37459_37460 : H12AffineEnvironment.transform 6 15 env37459 = env37460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 15 env37459 == env37460) = true)

theorem identity37460 : scanCanonicalize (H12AffineFastState.compose env37460 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound37460 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37461 : List Nat := [2,4,2,6,7,1,5,2,1,5,0,6,4,1,7,2,0,7,5,6,7,6,0,2,2,7,0,6,1,6,3,1,3,7,6,1]

theorem envBound37461 : H12AffineFastState.Bounded env37461 := by
  intro p hp
  have h : env37461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37460_37461 : H12AffineEnvironment.transform 2 2 env37460 = env37461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env37460 == env37461) = true)

def env37462 : List Nat := [2,4,8,16,32,1,128,8,512,25,2048,525,25,1,12,65536,65582,65664,516,13,524,648,65582,65536,653,66082,39,65598,1,68110,20,65582,9,17,16,29]

theorem envBound37462 : H12AffineFastState.Bounded env37462 := by
  intro p hp
  have h : env37462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37453_37462 : H12AffineEnvironment.transform 12 25 env37453 = env37462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env37453 == env37462) = true)

theorem identity37462 : scanCanonicalize (H12AffineFastState.compose env37462 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 559) := by decide +kernel

theorem selectedBound37462 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env37463 : List Nat := [2,4,8,16,32,1,128,8,512,25,2048,525,25,1,12,559,513,687,516,13,524,648,513,559,653,13,39,529,1,2081,20,513,9,17,16,29]

theorem envBound37463 : H12AffineFastState.Bounded env37463 := by
  intro p hp
  have h : env37463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37462_37463 : H12AffineEnvironment.transform 15 559 env37462 = env37463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 559 env37462 == env37463) = true)

theorem identity37463 : scanCanonicalize (H12AffineFastState.compose env37463 (packedSelected [0,1,2,3,7,10,12,17,20] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound37463 : packedSelected [0,1,2,3,7,10,12,17,20] rootPS < 2^1333 := by decide +kernel

def env37464 : List Nat := [2,4,8,6,32,1,128,8,512,15,2048,525,15,1,12,559,513,687,516,13,524,648,513,559,653,13,39,519,1,2081,2,513,9,7,6,11]

theorem envBound37464 : H12AffineFastState.Bounded env37464 := by
  intro p hp
  have h : env37464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37463_37464 : H12AffineEnvironment.transform 3 6 env37463 = env37464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env37463 == env37464) = true)

theorem identity37464 : scanCanonicalize (H12AffineFastState.compose env37464 (packedSelected [0,3,4,7,8,9,10,11,16,17] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound37464 : packedSelected [0,3,4,7,8,9,10,11,16,17] rootPS < 2^1333 := by decide +kernel

def env37465 : List Nat := [2,4,8,6,32,1,128,8,512,15,1,525,15,1,12,559,513,687,516,13,524,648,513,559,653,13,39,519,1,32,2,513,9,7,6,11]

theorem envBound37465 : H12AffineFastState.Bounded env37465 := by
  intro p hp
  have h : env37465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37464_37465 : H12AffineEnvironment.transform 10 1 env37464 = env37465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env37464 == env37465) = true)

theorem identity37465 : scanCanonicalize (H12AffineFastState.compose env37465 (packedSelected [1,2,3,8] rootPS)) = affineNative (2^(8+1) ^^^ 174) := by decide +kernel

theorem selectedBound37465 : packedSelected [1,2,3,8] rootPS < 2^1333 := by decide +kernel

def env37466 : List Nat := [2,4,8,6,32,1,128,8,174,15,1,163,15,1,12,129,175,1,170,13,162,38,175,129,35,13,39,169,1,32,2,175,9,7,6,11]

theorem envBound37466 : H12AffineFastState.Bounded env37466 := by
  intro p hp
  have h : env37466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37465_37466 : H12AffineEnvironment.transform 8 174 env37465 = env37466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 174 env37465 == env37466) = true)

theorem identity37466 : scanCanonicalize (H12AffineFastState.compose env37466 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound37466 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env37467 : List Nat := [2,4,8,6,32,1,34,8,12,15,1,1,15,1,12,35,13,1,8,13,0,38,13,35,35,13,39,11,1,32,2,13,9,7,6,11]

theorem envBound37467 : H12AffineFastState.Bounded env37467 := by
  intro p hp
  have h : env37467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37466_37467 : H12AffineEnvironment.transform 6 34 env37466 = env37467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env37466 == env37467) = true)

theorem identity37467 : scanCanonicalize (H12AffineFastState.compose env37467 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound37467 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env37468 : List Nat := [2,2,8,0,32,1,34,8,10,9,1,1,9,1,10,35,11,1,8,11,0,32,11,35,35,11,33,11,1,32,2,11,9,1,0,11]

theorem envBound37468 : H12AffineFastState.Bounded env37468 := by
  intro p hp
  have h : env37468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37467_37468 : H12AffineEnvironment.transform 1 2 env37467 = env37468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env37467 == env37468) = true)

theorem identity37468 : scanCanonicalize (H12AffineFastState.compose env37468 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 8) := by decide +kernel

theorem selectedBound37468 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env37469 : List Nat := [2,2,8,0,8,1,10,8,10,9,1,1,9,1,10,11,11,1,8,11,0,8,11,11,11,11,9,11,1,8,2,11,9,1,0,11]

theorem envBound37469 : H12AffineFastState.Bounded env37469 := by
  intro p hp
  have h : env37469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37468_37469 : H12AffineEnvironment.transform 4 8 env37468 = env37469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 8 env37468 == env37469) = true)

theorem identity37469 : scanCanonicalize (H12AffineFastState.compose env37469 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound37469 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37470 : List Nat := [2,2,2,0,2,1,0,2,0,3,1,1,3,1,0,1,1,1,2,1,0,2,1,1,1,1,3,1,1,2,2,1,3,1,0,1]

theorem envBound37470 : H12AffineFastState.Bounded env37470 := by
  intro p hp
  have h : env37470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37469_37470 : H12AffineEnvironment.transform 2 2 env37469 = env37470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env37469 == env37470) = true)

theorem identity37470 : scanCanonicalize (H12AffineFastState.compose env37470 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound37470 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37471 : List Nat := [0,0,0,0,0,1,0,0,0,1,1,1,1,1,0,1,1,1,0,1,0,0,1,1,1,1,1,1,1,0,0,1,1,1,0,1]

theorem envBound37471 : H12AffineFastState.Bounded env37471 := by
  intro p hp
  have h : env37471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37470_37471 : H12AffineEnvironment.transform 0 0 env37470 = env37471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env37470 == env37471) = true)

def env37472 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74863,65665,4416,8541,4097,5276,74047,66896,13769,78895,1150,74814,1296,81226,8205,65830,257,1280,1344,5952]

theorem envBound37472 : H12AffineFastState.Bounded env37472 := by
  intro p hp
  have h : env37472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37390_37472 : H12AffineEnvironment.transform 17 65665 env37390 = env37472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env37390 == env37472) = true)

theorem identity37472 : scanCanonicalize (H12AffineFastState.compose env37472 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound37472 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env37473 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,8192,1296,8540,65536,74863,65665,272,8541,81,1228,74047,66896,9625,74879,1150,74814,1296,77082,8205,65830,257,1280,1344,1808]

theorem envBound37473 : H12AffineFastState.Bounded env37473 := by
  intro p hp
  have h : env37473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37472_37473 : H12AffineEnvironment.transform 11 80 env37472 = env37473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env37472 == env37473) = true)

def env37474 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,80,8192,80,8540,65536,74031,65665,272,8541,81,396,74047,65552,8409,74047,318,74110,80,75866,8205,65830,257,64,0,592]

theorem envBound37474 : H12AffineFastState.Bounded env37474 := by
  intro p hp
  have h : env37474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37473_37474 : H12AffineEnvironment.transform 9 320 env37473 = env37474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env37473 == env37474) = true)

theorem identity37474 : scanCanonicalize (H12AffineFastState.compose env37474 (packedSelected [7,20,27] rootPS)) = affineNative (2^(15+1) ^^^ 8299) := by decide +kernel

theorem selectedBound37474 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env37475 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,80,8192,80,8540,8299,324,8426,272,8541,81,396,340,8315,8409,340,318,277,80,2097,8205,8525,257,64,0,592]

theorem envBound37475 : H12AffineFastState.Bounded env37475 := by
  intro p hp
  have h : env37475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37474_37475 : H12AffineEnvironment.transform 15 8299 env37474 = env37475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8299 env37474 == env37475) = true)

theorem identity37475 : scanCanonicalize (H12AffineFastState.compose env37475 (packedSelected [0,1,4,7,8,9,16,19,20] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound37475 : packedSelected [0,1,4,7,8,9,16,19,20] rootPS < 2^1333 := by decide +kernel

def env37476 : List Nat := [2,4,8,16,32,64,128,69,512,5,2048,80,8192,80,8217,8299,1,8426,85,8216,81,201,17,8315,8409,17,123,80,80,2097,8205,8200,68,64,0,592]

theorem envBound37476 : H12AffineFastState.Bounded env37476 := by
  intro p hp
  have h : env37476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37475_37476 : H12AffineEnvironment.transform 7 69 env37475 = env37476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env37475 == env37476) = true)

theorem identity37476 : scanCanonicalize (H12AffineFastState.compose env37476 (packedSelected [0,1,3,5,7,8,13,17,18] rootPS)) = affineNative (2^(12+1) ^^^ 2283) := by decide +kernel

theorem selectedBound37476 : packedSelected [0,1,3,5,7,8,13,17,18] rootPS < 2^1333 := by decide +kernel

def env37477 : List Nat := [2,4,8,16,32,64,128,69,512,5,2048,80,2283,80,2290,2176,1,2049,85,2291,81,201,17,2192,2098,17,123,80,80,2097,2278,2275,68,64,0,592]

theorem envBound37477 : H12AffineFastState.Bounded env37477 := by
  intro p hp
  have h : env37477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37476_37477 : H12AffineEnvironment.transform 12 2283 env37476 = env37477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2283 env37476 == env37477) = true)

theorem identity37477 : scanCanonicalize (H12AffineFastState.compose env37477 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound37477 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env37478 : List Nat := [2,4,8,16,32,64,128,69,512,5,42,80,193,80,216,170,1,43,85,217,81,201,17,186,24,17,123,80,80,27,204,201,68,64,0,592]

theorem envBound37478 : H12AffineFastState.Bounded env37478 := by
  intro p hp
  have h : env37478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37477_37478 : H12AffineEnvironment.transform 10 42 env37477 = env37478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env37477 == env37478) = true)

theorem identity37478 : scanCanonicalize (H12AffineFastState.compose env37478 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound37478 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env37479 : List Nat := [2,4,8,16,32,64,128,69,137,5,42,80,193,80,216,170,1,43,85,217,81,201,17,186,24,17,123,80,80,27,204,201,68,64,0,217]

theorem envBound37479 : H12AffineFastState.Bounded env37479 := by
  intro p hp
  have h : env37479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37478_37479 : H12AffineEnvironment.transform 8 137 env37478 = env37479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env37478 == env37479) = true)

theorem identity37479 : scanCanonicalize (H12AffineFastState.compose env37479 (packedSelected [0,4,7,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound37479 : packedSelected [0,4,7,9,10] rootPS < 2^1333 := by decide +kernel

def env37480 : List Nat := [2,4,8,16,32,64,57,69,48,5,42,80,120,80,97,19,1,43,85,96,81,112,17,3,24,17,123,80,80,27,117,112,68,64,0,96]

theorem envBound37480 : H12AffineFastState.Bounded env37480 := by
  intro p hp
  have h : env37480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37479_37480 : H12AffineEnvironment.transform 6 57 env37479 = env37480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env37479 == env37480) = true)

theorem identity37480 : scanCanonicalize (H12AffineFastState.compose env37480 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound37480 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env37481 : List Nat := [2,4,8,10,32,64,35,69,42,5,42,74,98,74,97,9,1,43,79,96,75,106,11,3,2,11,97,74,74,1,111,106,68,64,0,96]

theorem envBound37481 : H12AffineFastState.Bounded env37481 := by
  intro p hp
  have h : env37481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37480_37481 : H12AffineEnvironment.transform 3 10 env37480 = env37481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env37480 == env37481) = true)

theorem identity37481 : scanCanonicalize (H12AffineFastState.compose env37481 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound37481 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env37482 : List Nat := [2,4,8,10,32,11,35,14,42,5,42,1,41,1,42,9,1,43,4,43,0,33,11,3,2,11,42,1,1,1,36,33,15,11,0,43]

theorem envBound37482 : H12AffineFastState.Bounded env37482 := by
  intro p hp
  have h : env37482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37481_37482 : H12AffineEnvironment.transform 5 11 env37481 = env37482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env37481 == env37482) = true)

theorem identity37482 : scanCanonicalize (H12AffineFastState.compose env37482 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound37482 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env37483 : List Nat := [2,4,0,2,32,3,35,6,34,5,34,1,33,1,34,1,1,35,4,35,0,33,3,3,2,3,34,1,1,1,36,33,7,3,0,35]

theorem envBound37483 : H12AffineFastState.Bounded env37483 := by
  intro p hp
  have h : env37483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37482_37483 : H12AffineEnvironment.transform 2 0 env37482 = env37483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env37482 == env37483) = true)

def env37484 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,80,8192,81,8540,65536,74030,65665,272,8541,81,397,74047,65553,8408,74046,319,74111,81,75867,8205,65830,257,65,1,593]

theorem envBound37484 : H12AffineFastState.Bounded env37484 := by
  intro p hp
  have h : env37484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37473_37484 : H12AffineEnvironment.transform 9 321 env37473 = env37484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env37473 == env37484) = true)

theorem identity37484 : scanCanonicalize (H12AffineFastState.compose env37484 (packedSelected [7,20,27] rootPS)) = affineNative (2^(15+1) ^^^ 8250) := by decide +kernel

theorem selectedBound37484 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env37485 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,80,8192,81,8540,8250,276,8379,272,8541,81,397,261,8235,8408,260,319,325,81,2145,8205,8476,257,65,1,593]

theorem envBound37485 : H12AffineFastState.Bounded env37485 := by
  intro p hp
  have h : env37485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37484_37485 : H12AffineEnvironment.transform 15 8250 env37484 = env37485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8250 env37484 == env37485) = true)

theorem identity37485 : scanCanonicalize (H12AffineFastState.compose env37485 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound37485 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env37486 : List Nat := [2,4,8,16,32,64,128,68,512,5,2048,80,8192,81,8216,8250,80,8379,84,8217,81,201,65,8235,8408,64,123,1,81,2145,8205,8280,69,65,1,593]

theorem envBound37486 : H12AffineFastState.Bounded env37486 := by
  intro p hp
  have h : env37486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37485_37486 : H12AffineEnvironment.transform 7 68 env37485 = env37486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env37485 == env37486) = true)

theorem identity37486 : scanCanonicalize (H12AffineFastState.compose env37486 (packedSelected [10,13,17,19] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound37486 : packedSelected [10,13,17,19] rootPS < 2^1333 := by decide +kernel

def env37487 : List Nat := [2,4,8,16,32,11,128,15,512,5,2048,27,8192,26,8216,8250,27,8379,31,8217,26,130,10,8235,8339,11,48,1,26,2090,8205,8211,14,10,1,538]

theorem envBound37487 : H12AffineFastState.Bounded env37487 := by
  intro p hp
  have h : env37487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37486_37487 : H12AffineEnvironment.transform 5 11 env37486 = env37487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env37486 == env37487) = true)

theorem identity37487 : scanCanonicalize (H12AffineFastState.compose env37487 (packedSelected [1,2,3,13] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound37487 : packedSelected [1,2,3,13] rootPS < 2^1333 := by decide +kernel

def env37488 : List Nat := [2,4,8,16,32,11,128,15,512,5,42,27,8192,26,8216,8250,27,8379,31,8217,26,130,10,8235,8339,11,48,1,26,0,8205,8211,14,10,1,538]

theorem envBound37488 : H12AffineFastState.Bounded env37488 := by
  intro p hp
  have h : env37488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37487_37488 : H12AffineEnvironment.transform 10 42 env37487 = env37488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env37487 == env37488) = true)

theorem identity37488 : scanCanonicalize (H12AffineFastState.compose env37488 (packedSelected [2,3,7,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound37488 : packedSelected [2,3,7,8,9] rootPS < 2^1333 := by decide +kernel

def env37489 : List Nat := [2,4,8,16,32,11,128,15,512,5,42,27,25,26,1,35,27,162,31,0,26,130,10,50,138,11,48,1,26,0,20,10,14,10,1,538]

theorem envBound37489 : H12AffineFastState.Bounded env37489 := by
  intro p hp
  have h : env37489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37488_37489 : H12AffineEnvironment.transform 12 25 env37488 = env37489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env37488 == env37489) = true)

theorem identity37489 : scanCanonicalize (H12AffineFastState.compose env37489 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound37489 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env37490 : List Nat := [2,4,8,16,32,11,128,15,136,5,42,27,25,26,1,35,27,162,31,0,26,130,10,50,138,11,48,1,26,0,20,10,14,10,1,146]

theorem envBound37490 : H12AffineFastState.Bounded env37490 := by
  intro p hp
  have h : env37490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37489_37490 : H12AffineEnvironment.transform 8 136 env37489 = env37490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env37489 == env37490) = true)

theorem identity37490 : scanCanonicalize (H12AffineFastState.compose env37490 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound37490 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env37491 : List Nat := [2,4,8,16,17,11,128,15,136,5,27,27,25,26,1,18,27,147,31,0,26,130,10,3,138,11,1,1,26,0,20,10,14,10,1,146]

theorem envBound37491 : H12AffineFastState.Bounded env37491 := by
  intro p hp
  have h : env37491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37490_37491 : H12AffineEnvironment.transform 4 17 env37490 = env37491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env37490 == env37491) = true)

theorem identity37491 : scanCanonicalize (H12AffineFastState.compose env37491 (packedSelected [1,2] rootPS)) = affineNative (2^(6+1) ^^^ 31) := by decide +kernel

theorem selectedBound37491 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env37492 : List Nat := [2,4,8,16,17,11,31,15,23,5,27,27,25,26,1,18,27,12,31,0,26,29,10,3,21,11,1,1,26,0,20,10,14,10,1,13]

theorem envBound37492 : H12AffineFastState.Bounded env37492 := by
  intro p hp
  have h : env37492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37491_37492 : H12AffineEnvironment.transform 6 31 env37491 = env37492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 31 env37491 == env37492) = true)

def env37493 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74863,262144,4417,8540,4097,5276,74046,66896,13768,78895,328959,74815,1296,81227,8204,65831,257,1280,1344,5953]

theorem envBound37493 : H12AffineFastState.Bounded env37493 := by
  intro p hp
  have h : env37493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37389_37493 : H12AffineEnvironment.transform 13 1297 env37389 = env37493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env37389 == env37493) = true)

def env37494 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74863,65664,4417,8540,4097,5276,74046,66896,13768,78895,1151,74815,1296,81227,8204,65831,257,1280,1344,5953]

theorem envBound37494 : H12AffineFastState.Bounded env37494 := by
  intro p hp
  have h : env37494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37493_37494 : H12AffineEnvironment.transform 17 65664 env37493 = env37494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env37493 == env37494) = true)

theorem identity37494 : scanCanonicalize (H12AffineFastState.compose env37494 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5464) := by decide +kernel

theorem selectedBound37494 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env37495 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5464,1297,5125,65536,69943,65664,4417,5124,4097,5276,70758,66896,144,65911,1151,69991,1296,67603,5460,65831,257,1280,1344,5953]

theorem envBound37495 : H12AffineFastState.Bounded env37495 := by
  intro p hp
  have h : env37495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37494_37495 : H12AffineEnvironment.transform 12 5464 env37494 = env37495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5464 env37494 == env37495) = true)

def env37496 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1556,844,1297,529,65536,67363,65664,1877,528,1557,648,66162,66896,144,65911,1151,67443,1296,67603,832,65831,257,1280,1344,341]

theorem envBound37496 : H12AffineFastState.Bounded env37496 := by
  intro p hp
  have h : env37496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37495_37496 : H12AffineEnvironment.transform 11 1556 env37495 = env37496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1556 env37495 == env37496) = true)

def env37497 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,836,844,65,529,65536,66163,65664,517,528,837,648,66162,65536,144,65911,303,66083,64,67603,832,65831,257,80,16,341]

theorem envBound37497 : H12AffineFastState.Bounded env37497 := by
  intro p hp
  have h : env37497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37496_37497 : H12AffineEnvironment.transform 9 336 env37496 = env37497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 336 env37496 == env37497) = true)

theorem identity37497 : scanCanonicalize (H12AffineFastState.compose env37497 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 418) := by decide +kernel

theorem selectedBound37497 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env37498 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,836,844,65,529,418,977,290,517,528,837,648,976,418,144,213,303,897,64,2481,832,133,257,80,16,341]

theorem envBound37498 : H12AffineFastState.Bounded env37498 := by
  intro p hp
  have h : env37498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37497_37498 : H12AffineEnvironment.transform 15 418 env37497 = env37498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 418 env37497 == env37498) = true)

def env37499 : List Nat := [2,4,8,16,32,64,128,256,512,336,772,836,844,65,529,418,977,290,517,528,837,648,976,418,144,213,303,897,64,693,832,133,257,80,16,341]

theorem envBound37499 : H12AffineFastState.Bounded env37499 := by
  intro p hp
  have h : env37499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37498_37499 : H12AffineEnvironment.transform 10 772 env37498 = env37499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 772 env37498 == env37499) = true)

def env37500 : List Nat := [2,4,8,16,32,64,128,256,416,336,164,228,236,65,433,418,113,290,421,432,229,296,112,418,144,213,303,33,64,277,224,133,257,80,16,341]

theorem envBound37500 : H12AffineFastState.Bounded env37500 := by
  intro p hp
  have h : env37500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37499_37500 : H12AffineEnvironment.transform 8 416 env37499 = env37500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 416 env37499 == env37500) = true)

theorem identity37500 : scanCanonicalize (H12AffineFastState.compose env37500 (packedSelected [0,2,3,4,8,10,13,15,17,19,23] rootPS)) = affineNative (2^(6+1) ^^^ 51) := by decide +kernel

theorem selectedBound37500 : packedSelected [0,2,3,4,8,10,13,15,17,19,23] rootPS < 2^1333 := by decide +kernel

def env37501 : List Nat := [2,4,8,16,32,64,51,256,275,336,23,87,95,65,258,273,113,290,278,259,86,296,112,273,35,102,303,33,64,277,83,54,257,80,16,341]

theorem envBound37501 : H12AffineFastState.Bounded env37501 := by
  intro p hp
  have h : env37501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37500_37501 : H12AffineEnvironment.transform 6 51 env37500 = env37501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 51 env37500 == env37501) = true)

theorem identity37501 : scanCanonicalize (H12AffineFastState.compose env37501 (packedSelected [3,4,8,9,10,11,15,16] rootPS)) = affineNative (2^(7+1) ^^^ 24) := by decide +kernel

theorem selectedBound37501 : packedSelected [3,4,8,9,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env37502 : List Nat := [2,4,8,16,32,64,51,24,11,72,23,87,95,65,26,9,113,58,14,27,86,48,112,9,35,102,55,33,64,13,83,54,25,80,16,77]

theorem envBound37502 : H12AffineFastState.Bounded env37502 := by
  intro p hp
  have h : env37502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37501_37502 : H12AffineEnvironment.transform 7 24 env37501 = env37502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 24 env37501 == env37502) = true)

theorem identity37502 : scanCanonicalize (H12AffineFastState.compose env37502 (packedSelected [0,1,2,5,7,8,11] rootPS)) = affineNative (2^(5+1) ^^^ 45) := by decide +kernel

theorem selectedBound37502 : packedSelected [0,1,2,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env37503 : List Nat := [2,4,8,16,32,45,51,24,11,37,23,58,50,44,26,9,28,58,14,27,59,48,29,9,35,11,55,33,45,13,62,54,25,61,16,32]

theorem envBound37503 : H12AffineFastState.Bounded env37503 := by
  intro p hp
  have h : env37503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37502_37503 : H12AffineEnvironment.transform 5 45 env37502 = env37503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 45 env37502 == env37503) = true)

theorem identity37503 : scanCanonicalize (H12AffineFastState.compose env37503 (packedSelected [0,1,4] rootPS)) = affineNative (2^(4+1) ^^^ 29) := by decide +kernel

theorem selectedBound37503 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env37504 : List Nat := [2,4,8,16,29,16,14,24,11,24,23,7,15,17,26,9,28,7,14,27,6,13,29,9,30,11,10,28,16,13,3,11,25,0,16,29]

theorem envBound37504 : H12AffineFastState.Bounded env37504 := by
  intro p hp
  have h : env37504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37503_37504 : H12AffineEnvironment.transform 4 29 env37503 = env37504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 29 env37503 == env37504) = true)

def env37505 : List Nat := [2,4,8,16,32,64,128,256,417,336,165,229,237,65,432,418,112,290,420,433,228,297,113,418,144,213,303,32,64,276,225,133,257,80,16,341]

theorem envBound37505 : H12AffineFastState.Bounded env37505 := by
  intro p hp
  have h : env37505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37499_37505 : H12AffineEnvironment.transform 8 417 env37499 = env37505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 417 env37499 == env37505) = true)

theorem identity37505 : scanCanonicalize (H12AffineFastState.compose env37505 (packedSelected [0,2,3,4,8,10,13,15,17,19,23] rootPS)) = affineNative (2^(6+1) ^^^ 53) := by decide +kernel

theorem selectedBound37505 : packedSelected [0,2,3,4,8,10,13,15,17,19,23] rootPS < 2^1333 := by decide +kernel

def env37506 : List Nat := [2,4,8,16,32,64,53,256,276,336,16,80,88,65,261,279,112,290,273,260,81,297,113,279,37,96,303,32,64,276,84,48,257,80,16,341]

theorem envBound37506 : H12AffineFastState.Bounded env37506 := by
  intro p hp
  have h : env37506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37505_37506 : H12AffineEnvironment.transform 6 53 env37505 = env37506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 53 env37505 == env37506) = true)

theorem identity37506 : scanCanonicalize (H12AffineFastState.compose env37506 (packedSelected [0,8,9,12,15,16,17] rootPS)) = affineNative (2^(7+1) ^^^ 115) := by decide +kernel

theorem selectedBound37506 : packedSelected [0,8,9,12,15,16,17] rootPS < 2^1333 := by decide +kernel

def env37507 : List Nat := [2,4,8,16,32,64,53,115,103,35,16,80,88,65,118,100,112,81,98,119,81,90,113,100,37,96,92,32,64,103,84,48,114,80,16,38]

theorem envBound37507 : H12AffineFastState.Bounded env37507 := by
  intro p hp
  have h : env37507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37506_37507 : H12AffineEnvironment.transform 7 115 env37506 = env37507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 115 env37506 == env37507) = true)

theorem identity37507 : scanCanonicalize (H12AffineFastState.compose env37507 (packedSelected [0,1,5,7,10] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound37507 : packedSelected [0,1,5,7,10] rootPS < 2^1333 := by decide +kernel

def env37508 : List Nat := [2,4,8,16,32,10,53,57,45,35,16,26,18,11,60,46,58,27,40,61,27,16,59,46,37,42,22,32,10,45,30,48,56,26,16,38]

theorem envBound37508 : H12AffineFastState.Bounded env37508 := by
  intro p hp
  have h : env37508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37507_37508 : H12AffineEnvironment.transform 5 10 env37507 = env37508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env37507 == env37508) = true)

def env37509 : List Nat := [2,4,8,16,32,64,128,256,512,336,773,836,844,65,529,418,977,290,517,528,837,648,976,418,144,213,303,897,64,692,832,133,257,80,16,341]

theorem envBound37509 : H12AffineFastState.Bounded env37509 := by
  intro p hp
  have h : env37509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37498_37509 : H12AffineEnvironment.transform 10 773 env37498 = env37509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 773 env37498 == env37509) = true)

def env37510 : List Nat := [2,4,8,16,32,64,128,256,416,336,165,228,236,65,433,418,113,290,421,432,229,296,112,418,144,213,303,33,64,276,224,133,257,80,16,341]

theorem envBound37510 : H12AffineFastState.Bounded env37510 := by
  intro p hp
  have h : env37510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37509_37510 : H12AffineEnvironment.transform 8 416 env37509 = env37510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 416 env37509 == env37510) = true)

theorem identity37510 : scanCanonicalize (H12AffineFastState.compose env37510 (packedSelected [0,2,3,4,8,10,13,15,17,19,23] rootPS)) = affineNative (2^(7+1) ^^^ 41) := by decide +kernel

theorem selectedBound37510 : packedSelected [0,2,3,4,8,10,13,15,17,19,23] rootPS < 2^1333 := by decide +kernel

def env37511 : List Nat := [2,4,8,16,32,64,128,41,137,121,165,228,236,65,152,139,113,11,140,153,229,1,112,139,144,213,6,33,64,61,224,133,40,80,16,124]

theorem envBound37511 : H12AffineFastState.Bounded env37511 := by
  intro p hp
  have h : env37511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37510_37511 : H12AffineEnvironment.transform 7 41 env37510 = env37511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 41 env37510 == env37511) = true)

theorem identity37511 : scanCanonicalize (H12AffineFastState.compose env37511 (packedSelected [0,2,3,4,13,15,17,18] rootPS)) = affineNative (2^(6+1) ^^^ 79) := by decide +kernel

theorem selectedBound37511 : packedSelected [0,2,3,4,13,15,17,18] rootPS < 2^1333 := by decide +kernel

def env37512 : List Nat := [2,4,8,16,32,64,79,41,70,121,106,43,35,65,87,68,113,11,67,86,42,1,112,68,95,26,6,33,64,61,47,74,40,80,16,124]

theorem envBound37512 : H12AffineFastState.Bounded env37512 := by
  intro p hp
  have h : env37512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37511_37512 : H12AffineEnvironment.transform 6 79 env37511 = env37512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 79 env37511 == env37512) = true)

theorem identity37512 : scanCanonicalize (H12AffineFastState.compose env37512 (packedSelected [0,1,2,4,5,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 29) := by decide +kernel

theorem selectedBound37512 : packedSelected [0,1,2,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env37513 : List Nat := [2,4,8,16,29,64,79,20,70,68,87,22,30,65,87,68,76,11,67,86,23,1,77,68,95,26,6,28,64,0,18,74,21,80,16,65]

theorem envBound37513 : H12AffineFastState.Bounded env37513 := by
  intro p hp
  have h : env37513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37512_37513 : H12AffineEnvironment.transform 4 29 env37512 = env37513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 29 env37512 == env37513) = true)

theorem identity37513 : scanCanonicalize (H12AffineFastState.compose env37513 (packedSelected [0,1,2,3,4,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 23) := by decide +kernel

theorem selectedBound37513 : packedSelected [0,1,2,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env37514 : List Nat := [2,4,8,16,29,23,24,20,17,19,0,22,30,22,0,19,27,11,20,1,23,1,26,19,8,26,6,28,23,0,18,29,21,7,16,22]

theorem envBound37514 : H12AffineFastState.Bounded env37514 := by
  intro p hp
  have h : env37514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37513_37514 : H12AffineEnvironment.transform 5 23 env37513 = env37514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 23 env37513 == env37514) = true)

theorem identity37514 : scanCanonicalize (H12AffineFastState.compose env37514 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound37514 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37515 : List Nat := [2,4,8,12,1,11,4,8,13,15,0,10,2,10,0,15,7,11,8,1,11,1,6,15,8,6,6,0,11,0,14,1,9,7,12,10]

theorem envBound37515 : H12AffineFastState.Bounded env37515 := by
  intro p hp
  have h : env37515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37514_37515 : H12AffineEnvironment.transform 3 12 env37514 = env37515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env37514 == env37515) = true)

theorem identity37515 : scanCanonicalize (H12AffineFastState.compose env37515 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound37515 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37516 : List Nat := [2,3,8,11,1,11,3,8,10,8,0,10,2,10,0,8,0,11,8,1,11,1,1,8,8,1,1,0,11,0,9,1,9,0,11,10]

theorem envBound37516 : H12AffineFastState.Bounded env37516 := by
  intro p hp
  have h : env37516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37515_37516 : H12AffineEnvironment.transform 1 3 env37515 = env37516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env37515 == env37516) = true)

theorem identity37516 : scanCanonicalize (H12AffineFastState.compose env37516 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound37516 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37517 : List Nat := [2,3,2,1,1,1,3,2,0,2,0,0,2,0,0,2,0,1,2,1,1,1,1,2,2,1,1,0,1,0,3,1,3,0,1,0]

theorem envBound37517 : H12AffineFastState.Bounded env37517 := by
  intro p hp
  have h : env37517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37516_37517 : H12AffineEnvironment.transform 2 2 env37516 = env37517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env37516 == env37517) = true)

def env37518 : List Nat := [2,4,8,16,32,64,128,256,417,336,164,229,237,65,432,418,112,290,420,433,228,297,113,418,144,213,303,32,64,277,225,133,257,80,16,341]

theorem envBound37518 : H12AffineFastState.Bounded env37518 := by
  intro p hp
  have h : env37518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37509_37518 : H12AffineEnvironment.transform 8 417 env37509 = env37518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 417 env37509 == env37518) = true)

theorem identity37518 : scanCanonicalize (H12AffineFastState.compose env37518 (packedSelected [0,2,3,4,8,10,13,15,17,19,23] rootPS)) = affineNative (2^(7+1) ^^^ 47) := by decide +kernel

theorem selectedBound37518 : packedSelected [0,2,3,4,8,10,13,15,17,19,23] rootPS < 2^1333 := by decide +kernel

def env37519 : List Nat := [2,4,8,16,32,64,128,47,142,127,164,229,237,65,159,141,112,13,139,158,228,6,113,141,144,213,0,32,64,58,225,133,46,80,16,122]

theorem envBound37519 : H12AffineFastState.Bounded env37519 := by
  intro p hp
  have h : env37519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37518_37519 : H12AffineEnvironment.transform 7 47 env37518 = env37519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 47 env37518 == env37519) = true)

theorem identity37519 : scanCanonicalize (H12AffineFastState.compose env37519 (packedSelected [1,7,9,16] rootPS)) = affineNative (2^(6+1) ^^^ 30) := by decide +kernel

theorem selectedBound37519 : packedSelected [1,7,9,16] rootPS < 2^1333 := by decide +kernel

def env37520 : List Nat := [2,4,8,16,32,64,30,47,16,127,58,123,115,65,1,19,112,13,21,0,122,6,113,19,14,75,0,32,64,58,127,27,46,80,16,122]

theorem envBound37520 : H12AffineFastState.Bounded env37520 := by
  intro p hp
  have h : env37520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37519_37520 : H12AffineEnvironment.transform 6 30 env37519 = env37520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 30 env37519 == env37520) = true)

theorem identity37520 : scanCanonicalize (H12AffineFastState.compose env37520 (packedSelected [2,4,5,8,9,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound37520 : packedSelected [2,4,5,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env37521 : List Nat := [2,4,8,16,32,48,30,47,16,15,58,11,3,49,1,19,0,13,21,0,10,6,1,19,14,59,0,32,48,58,15,27,46,32,16,10]

theorem envBound37521 : H12AffineFastState.Bounded env37521 := by
  intro p hp
  have h : env37521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37520_37521 : H12AffineEnvironment.transform 5 48 env37520 = env37521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env37520 == env37521) = true)

theorem identity37521 : scanCanonicalize (H12AffineFastState.compose env37521 (packedSelected [1,3,8] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound37521 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env37522 : List Nat := [2,4,8,16,16,0,30,31,16,15,10,11,3,1,1,19,0,13,21,0,10,6,1,19,14,11,0,16,0,10,15,27,30,16,16,10]

theorem envBound37522 : H12AffineFastState.Bounded env37522 := by
  intro p hp
  have h : env37522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37521_37522 : H12AffineEnvironment.transform 4 16 env37521 = env37522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env37521 == env37522) = true)

theorem identity37522 : scanCanonicalize (H12AffineFastState.compose env37522 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound37522 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37523 : List Nat := [2,4,8,7,7,0,9,8,7,15,10,11,3,1,1,4,0,13,2,0,10,6,1,4,14,11,0,7,0,10,15,12,9,7,7,10]

theorem envBound37523 : H12AffineFastState.Bounded env37523 := by
  intro p hp
  have h : env37523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37522_37523 : H12AffineEnvironment.transform 3 7 env37522 = env37523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env37522 == env37523) = true)

theorem identity37523 : scanCanonicalize (H12AffineFastState.compose env37523 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound37523 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env37524 : List Nat := [2,4,4,7,7,0,5,4,7,3,6,7,3,1,1,4,0,1,2,0,6,6,1,4,2,7,0,7,0,6,3,0,5,7,7,6]

theorem envBound37524 : H12AffineFastState.Bounded env37524 := by
  intro p hp
  have h : env37524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37523_37524 : H12AffineEnvironment.transform 2 4 env37523 = env37524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env37523 == env37524) = true)

theorem identity37524 : scanCanonicalize (H12AffineFastState.compose env37524 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound37524 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37525 : List Nat := [2,1,1,2,2,0,0,1,2,3,3,2,3,1,1,1,0,1,2,0,3,3,1,1,2,2,0,2,0,3,3,0,0,2,2,3]

theorem envBound37525 : H12AffineFastState.Bounded env37525 := by
  intro p hp
  have h : env37525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37524_37525 : H12AffineEnvironment.transform 1 1 env37524 = env37525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env37524 == env37525) = true)

theorem identity37525 : scanCanonicalize (H12AffineFastState.compose env37525 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound37525 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env37526 : List Nat := [0,1,1,0,0,0,0,1,0,1,1,0,1,1,1,1,0,1,0,0,1,1,1,1,0,0,0,0,0,1,1,0,0,0,0,1]

theorem envBound37526 : H12AffineFastState.Bounded env37526 := by
  intro p hp
  have h : env37526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37525_37526 : H12AffineEnvironment.transform 0 0 env37525 = env37526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env37525 == env37526) = true)

def env37527 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,837,844,64,529,65536,66162,65664,516,528,836,648,66162,65537,144,65911,302,66082,65,67603,832,65831,257,81,17,341]

theorem envBound37527 : H12AffineFastState.Bounded env37527 := by
  intro p hp
  have h : env37527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37496_37527 : H12AffineEnvironment.transform 9 337 env37496 = env37527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 337 env37496 == env37527) = true)

theorem identity37527 : scanCanonicalize (H12AffineFastState.compose env37527 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 694) := by decide +kernel

theorem selectedBound37527 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env37528 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,837,844,64,529,694,196,566,516,528,836,648,196,695,144,961,302,148,65,2725,832,913,257,81,17,341]

theorem envBound37528 : H12AffineFastState.Bounded env37528 := by
  intro p hp
  have h : env37528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37527_37528 : H12AffineEnvironment.transform 15 694 env37527 = env37528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 694 env37527 == env37528) = true)

def env37529 : List Nat := [2,4,8,16,32,64,84,256,512,337,2048,837,844,64,529,610,16,566,516,528,836,604,16,611,68,789,302,64,65,2673,832,837,257,81,17,341]

theorem envBound37529 : H12AffineFastState.Bounded env37529 := by
  intro p hp
  have h : env37529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37528_37529 : H12AffineEnvironment.transform 6 84 env37528 = env37529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 84 env37528 == env37529) = true)

theorem identity37529 : scanCanonicalize (H12AffineFastState.compose env37529 (packedSelected [13,21] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound37529 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env37530 : List Nat := [2,4,8,0,32,64,68,256,512,321,2048,837,844,64,513,610,0,550,516,512,836,588,0,611,68,773,302,64,65,2657,832,837,257,65,1,325]

theorem envBound37530 : H12AffineFastState.Bounded env37530 := by
  intro p hp
  have h : env37530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37529_37530 : H12AffineEnvironment.transform 3 0 env37529 = env37530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env37529 == env37530) = true)

theorem identity37530 : scanCanonicalize (H12AffineFastState.compose env37530 (packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,16,18,20] rootPS)) = affineNative (2^(7+1) ^^^ 8) := by decide +kernel

theorem selectedBound37530 : packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,16,18,20] rootPS < 2^1333 := by decide +kernel

def env37531 : List Nat := [2,4,8,0,32,64,68,8,512,73,2048,589,580,64,513,610,0,550,516,512,588,588,0,611,68,525,38,64,65,2657,584,589,9,65,1,77]

theorem envBound37531 : H12AffineFastState.Bounded env37531 := by
  intro p hp
  have h : env37531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37530_37531 : H12AffineEnvironment.transform 7 8 env37530 = env37531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 8 env37530 == env37531) = true)

theorem identity37531 : scanCanonicalize (H12AffineFastState.compose env37531 (packedSelected [1,3,5,12,17] rootPS)) = affineNative (2^(8+1) ^^^ 97) := by decide +kernel

theorem selectedBound37531 : packedSelected [1,3,5,12,17] rootPS < 2^1333 := by decide +kernel

def env37532 : List Nat := [2,4,8,0,32,64,68,8,97,73,2048,44,37,64,96,3,0,71,101,97,45,45,0,2,68,108,38,64,65,2048,41,44,9,65,1,77]

theorem envBound37532 : H12AffineFastState.Bounded env37532 := by
  intro p hp
  have h : env37532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37531_37532 : H12AffineEnvironment.transform 8 97 env37531 = env37532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 97 env37531 == env37532) = true)

theorem identity37532 : scanCanonicalize (H12AffineFastState.compose env37532 (packedSelected [1,2,5,8,10,12] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound37532 : packedSelected [1,2,5,8,10,12] rootPS < 2^1333 := by decide +kernel

def env37533 : List Nat := [2,3,8,0,32,64,67,8,97,73,2048,43,34,64,96,3,0,64,98,97,42,42,0,2,67,107,33,64,65,2048,41,43,9,65,1,74]

theorem envBound37533 : H12AffineFastState.Bounded env37533 := by
  intro p hp
  have h : env37533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37532_37533 : H12AffineEnvironment.transform 1 3 env37532 = env37533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env37532 == env37533) = true)

theorem identity37533 : scanCanonicalize (H12AffineFastState.compose env37533 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound37533 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env37534 : List Nat := [2,3,8,0,32,33,34,8,0,40,2048,43,34,33,1,3,0,33,3,0,42,42,0,2,34,10,33,33,32,2048,41,43,9,32,1,43]

theorem envBound37534 : H12AffineFastState.Bounded env37534 := by
  intro p hp
  have h : env37534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37533_37534 : H12AffineEnvironment.transform 5 33 env37533 = env37534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env37533 == env37534) = true)

theorem identity37534 : scanCanonicalize (H12AffineFastState.compose env37534 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound37534 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env37535 : List Nat := [2,3,8,0,32,33,34,8,0,40,33,43,34,33,1,3,0,33,3,0,42,42,0,2,34,10,33,33,32,33,41,43,9,32,1,43]

theorem envBound37535 : H12AffineFastState.Bounded env37535 := by
  intro p hp
  have h : env37535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37534_37535 : H12AffineEnvironment.transform 10 33 env37534 = env37535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env37534 == env37535) = true)

theorem identity37535 : scanCanonicalize (H12AffineFastState.compose env37535 (packedSelected [1,2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound37535 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env37536 : List Nat := [2,3,2,0,32,33,34,2,0,34,33,33,34,33,1,3,0,33,3,0,32,32,0,2,34,0,33,33,32,33,35,33,3,32,1,33]

theorem envBound37536 : H12AffineFastState.Bounded env37536 := by
  intro p hp
  have h : env37536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37535_37536 : H12AffineEnvironment.transform 2 2 env37535 = env37536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env37535 == env37536) = true)

theorem identity37536 : scanCanonicalize (H12AffineFastState.compose env37536 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound37536 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env37537 : List Nat := [2,3,2,0,1,0,3,2,0,3,0,0,3,0,1,3,0,0,3,0,1,1,0,2,3,0,0,0,1,0,2,0,3,1,1,0]

theorem envBound37537 : H12AffineFastState.Bounded env37537 := by
  intro p hp
  have h : env37537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37536_37537 : H12AffineEnvironment.transform 4 1 env37536 = env37537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env37536 == env37537) = true)

def env37538 : List Nat := [2,4,8,16,32,64,85,256,512,337,2048,837,844,64,529,611,17,566,516,528,836,605,17,610,69,788,302,65,65,2672,832,836,257,81,17,341]

theorem envBound37538 : H12AffineFastState.Bounded env37538 := by
  intro p hp
  have h : env37538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37528_37538 : H12AffineEnvironment.transform 6 85 env37528 = env37538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 85 env37528 == env37538) = true)

theorem identity37538 : scanCanonicalize (H12AffineFastState.compose env37538 (packedSelected [13,21] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound37538 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env37539 : List Nat := [2,4,8,16,32,64,85,256,1,337,2048,324,333,64,16,98,17,55,5,17,325,92,17,99,69,277,302,65,65,2161,321,325,257,81,17,341]

theorem envBound37539 : H12AffineFastState.Bounded env37539 := by
  intro p hp
  have h : env37539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37538_37539 : H12AffineEnvironment.transform 8 1 env37538 = env37539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env37538 == env37539) = true)

theorem identity37539 : scanCanonicalize (H12AffineFastState.compose env37539 (packedSelected [0,1,3,4,7,8,9,10,16,17,19,20] rootPS)) = affineNative (2^(10+1) ^^^ 339) := by decide +kernel

theorem selectedBound37539 : packedSelected [0,1,3,4,7,8,9,10,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env37540 : List Nat := [2,4,8,16,32,64,85,256,1,337,339,324,333,64,16,98,17,55,5,17,325,92,17,99,69,277,302,65,65,290,321,325,257,81,17,341]

theorem envBound37540 : H12AffineFastState.Bounded env37540 := by
  intro p hp
  have h : env37540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37539_37540 : H12AffineEnvironment.transform 10 339 env37539 = env37540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 339 env37539 == env37540) = true)

theorem identity37540 : scanCanonicalize (H12AffineFastState.compose env37540 (packedSelected [1,4,5,9,10,12,13,15,16,17] rootPS)) = affineNative (2^(5+1) ^^^ 60) := by decide +kernel

theorem selectedBound37540 : packedSelected [1,4,5,9,10,12,13,15,16,17] rootPS < 2^1333 := by decide +kernel

def env37541 : List Nat := [2,4,8,16,32,60,41,256,1,301,303,312,305,60,16,30,17,55,5,17,313,32,17,31,57,277,302,61,61,290,317,313,257,45,17,297]

theorem envBound37541 : H12AffineFastState.Bounded env37541 := by
  intro p hp
  have h : env37541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37540_37541 : H12AffineEnvironment.transform 5 60 env37540 = env37541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 60 env37540 == env37541) = true)

theorem identity37541 : scanCanonicalize (H12AffineFastState.compose env37541 (packedSelected [0,2,4,10,11] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound37541 : packedSelected [0,2,4,10,11] rootPS < 2^1333 := by decide +kernel

def env37542 : List Nat := [2,4,8,16,32,60,41,14,1,35,33,54,63,60,16,30,17,55,5,17,55,32,17,31,57,27,32,61,61,44,51,55,15,45,17,39]

theorem envBound37542 : H12AffineFastState.Bounded env37542 := by
  intro p hp
  have h : env37542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37541_37542 : H12AffineEnvironment.transform 7 14 env37541 = env37542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env37541 == env37542) = true)

theorem identity37542 : scanCanonicalize (H12AffineFastState.compose env37542 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound37542 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env37543 : List Nat := [2,4,8,16,11,23,2,14,1,8,10,29,20,23,16,30,17,28,5,17,28,11,17,31,18,27,11,22,22,7,24,28,15,6,17,12]

theorem envBound37543 : H12AffineFastState.Bounded env37543 := by
  intro p hp
  have h : env37543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37542_37543 : H12AffineEnvironment.transform 4 11 env37542 = env37543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env37542 == env37543) = true)

theorem identity37543 : scanCanonicalize (H12AffineFastState.compose env37543 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound37543 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env37544 : List Nat := [2,4,8,12,11,11,2,14,1,8,10,1,8,11,12,2,13,0,5,13,0,11,13,3,14,7,11,10,10,7,4,0,15,6,13,12]

theorem envBound37544 : H12AffineFastState.Bounded env37544 := by
  intro p hp
  have h : env37544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37543_37544 : H12AffineEnvironment.transform 3 12 env37543 = env37544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env37543 == env37544) = true)

theorem identity37544 : scanCanonicalize (H12AffineFastState.compose env37544 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound37544 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37545 : List Nat := [2,4,5,1,6,6,2,3,1,5,7,1,5,6,1,2,0,0,5,0,0,6,0,3,3,7,6,7,7,7,4,0,2,6,0,1]

theorem envBound37545 : H12AffineFastState.Bounded env37545 := by
  intro p hp
  have h : env37545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37544_37545 : H12AffineEnvironment.transform 2 5 env37544 = env37545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env37544 == env37545) = true)

def env37546 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1557,845,1297,528,65536,67362,65664,1876,529,1556,649,66163,66896,144,65911,1151,67442,1296,67603,833,65831,257,1280,1344,340]

theorem envBound37546 : H12AffineFastState.Bounded env37546 := by
  intro p hp
  have h : env37546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37495_37546 : H12AffineEnvironment.transform 11 1557 env37495 = env37546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1557 env37495 == env37546) = true)

def env37547 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,837,845,65,528,65536,66162,65664,516,529,836,649,66163,65536,144,65911,303,66082,64,67603,833,65831,257,80,16,340]

theorem envBound37547 : H12AffineFastState.Bounded env37547 := by
  intro p hp
  have h : env37547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37546_37547 : H12AffineEnvironment.transform 9 336 env37546 = env37547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 336 env37546 == env37547) = true)

theorem identity37547 : scanCanonicalize (H12AffineFastState.compose env37547 (packedSelected [1,8,28] rootPS)) = affineNative (2^(8+1) ^^^ 448) := by decide +kernel

theorem selectedBound37547 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env37548 : List Nat := [2,4,8,16,32,64,128,256,448,336,2048,133,141,65,464,65536,65970,65664,452,465,132,329,65971,65536,144,65911,303,66018,64,67603,129,65831,257,80,16,340]

theorem envBound37548 : H12AffineFastState.Bounded env37548 := by
  intro p hp
  have h : env37548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37547_37548 : H12AffineEnvironment.transform 8 448 env37547 = env37548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 448 env37547 == env37548) = true)

def env37549 : List Nat := [2,4,8,16,32,64,128,256,448,336,2048,133,141,65,464,2068,2470,2196,452,465,132,329,2471,2068,144,2403,303,2550,64,7,129,2355,257,80,16,340]

theorem envBound37549 : H12AffineFastState.Bounded env37549 := by
  intro p hp
  have h : env37549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37548_37549 : H12AffineEnvironment.transform 15 2068 env37548 = env37549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2068 env37548 == env37549) = true)

theorem identity37549 : scanCanonicalize (H12AffineFastState.compose env37549 (packedSelected [1,3,4,9,11,20,21,32] rootPS)) = affineNative (2^(7+1) ^^^ 56) := by decide +kernel

theorem selectedBound37549 : packedSelected [1,3,4,9,11,20,21,32] rootPS < 2^1333 := by decide +kernel

def env37550 : List Nat := [2,4,8,16,32,64,128,56,248,104,2048,133,141,65,232,2068,2206,2196,252,233,132,113,2207,2068,144,2139,23,2254,64,7,129,2059,57,80,16,108]

theorem envBound37550 : H12AffineFastState.Bounded env37550 := by
  intro p hp
  have h : env37550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37549_37550 : H12AffineEnvironment.transform 7 56 env37549 = env37550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 56 env37549 == env37550) = true)

theorem identity37550 : scanCanonicalize (H12AffineFastState.compose env37550 (packedSelected [2,5,8,12,17,20] rootPS)) = affineNative (2^(10+1) ^^^ 143) := by decide +kernel

theorem selectedBound37550 : packedSelected [2,5,8,12,17,20] rootPS < 2^1333 := by decide +kernel

def env37551 : List Nat := [2,4,8,16,32,64,128,56,248,104,143,133,141,65,232,155,17,27,252,233,132,113,16,155,144,212,23,65,64,7,129,132,57,80,16,108]

theorem envBound37551 : H12AffineFastState.Bounded env37551 := by
  intro p hp
  have h : env37551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37550_37551 : H12AffineEnvironment.transform 10 143 env37550 = env37551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 143 env37550 == env37551) = true)

theorem identity37551 : scanCanonicalize (H12AffineFastState.compose env37551 (packedSelected [5,13] rootPS)) = affineNative (2^(6+1) ^^^ 53) := by decide +kernel

theorem selectedBound37551 : packedSelected [5,13] rootPS < 2^1333 := by decide +kernel

def env37552 : List Nat := [2,4,8,16,32,64,53,56,77,104,58,48,56,65,93,46,17,27,73,92,49,113,16,46,37,97,23,65,64,7,52,49,57,80,16,108]

theorem envBound37552 : H12AffineFastState.Bounded env37552 := by
  intro p hp
  have h : env37552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37551_37552 : H12AffineEnvironment.transform 6 53 env37551 = env37552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 53 env37551 == env37552) = true)

theorem identity37552 : scanCanonicalize (H12AffineFastState.compose env37552 (packedSelected [1,2,5,10] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound37552 : packedSelected [1,2,5,10] rootPS < 2^1333 := by decide +kernel

def env37553 : List Nat := [2,4,2,16,32,64,53,50,71,98,48,48,50,65,87,36,17,17,67,86,49,113,16,36,37,97,23,65,64,7,52,49,51,80,16,102]

theorem envBound37553 : H12AffineFastState.Bounded env37553 := by
  intro p hp
  have h : env37553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37552_37553 : H12AffineEnvironment.transform 2 2 env37552 = env37553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env37552 == env37553) = true)

theorem identity37553 : scanCanonicalize (H12AffineFastState.compose env37553 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound37553 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env37554 : List Nat := [2,4,2,6,32,64,35,36,71,98,38,38,36,65,65,36,7,7,67,64,39,103,6,36,37,97,1,65,64,7,34,39,37,70,6,102]

theorem envBound37554 : H12AffineFastState.Bounded env37554 := by
  intro p hp
  have h : env37554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37553_37554 : H12AffineEnvironment.transform 3 6 env37553 = env37554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env37553 == env37554) = true)

theorem identity37554 : scanCanonicalize (H12AffineFastState.compose env37554 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound37554 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env37555 : List Nat := [2,2,2,0,32,64,35,34,65,98,32,32,34,65,65,34,1,1,67,64,33,97,0,34,35,97,1,65,64,1,34,33,35,64,0,96]

theorem envBound37555 : H12AffineFastState.Bounded env37555 := by
  intro p hp
  have h : env37555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37554_37555 : H12AffineEnvironment.transform 1 2 env37554 = env37555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env37554 == env37555) = true)

def env37556 : List Nat := [2,4,8,16,32,64,128,256,448,336,2048,133,141,65,464,2069,2471,2197,452,465,132,329,2470,2069,144,2402,303,2551,64,6,129,2354,257,80,16,340]

theorem envBound37556 : H12AffineFastState.Bounded env37556 := by
  intro p hp
  have h : env37556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37548_37556 : H12AffineEnvironment.transform 15 2069 env37548 = env37556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2069 env37548 == env37556) = true)

theorem identity37556 : scanCanonicalize (H12AffineFastState.compose env37556 (packedSelected [1,3,4,9,11,20,21,32] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound37556 : packedSelected [1,3,4,9,11,20,21,32] rootPS < 2^1333 := by decide +kernel

def env37557 : List Nat := [2,4,8,16,32,64,128,256,448,336,26,133,141,65,464,15,445,143,452,465,132,329,444,15,144,376,303,493,64,6,129,296,257,80,16,340]

theorem envBound37557 : H12AffineFastState.Bounded env37557 := by
  intro p hp
  have h : env37557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37556_37557 : H12AffineEnvironment.transform 10 26 env37556 = env37557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env37556 == env37557) = true)

theorem identity37557 : scanCanonicalize (H12AffineFastState.compose env37557 (packedSelected [0,1,2,5,7,10,11,12,13,15,17,20,23] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound37557 : packedSelected [0,1,2,5,7,10,11,12,13,15,17,20,23] rootPS < 2^1333 := by decide +kernel

def env37558 : List Nat := [2,4,8,16,32,64,120,256,312,336,26,125,117,65,296,15,325,119,316,297,124,329,324,15,104,376,303,277,64,6,121,296,257,80,16,340]

theorem envBound37558 : H12AffineFastState.Bounded env37558 := by
  intro p hp
  have h : env37558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37557_37558 : H12AffineEnvironment.transform 6 120 env37557 = env37558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env37557 == env37558) = true)

theorem identity37558 : scanCanonicalize (H12AffineFastState.compose env37558 (packedSelected [2,3,4,5,9,10,11,16,18] rootPS)) = affineNative (2^(5+1) ^^^ 29) := by decide +kernel

theorem selectedBound37558 : packedSelected [2,3,4,5,9,10,11,16,18] rootPS < 2^1333 := by decide +kernel

def env37559 : List Nat := [2,4,8,16,32,29,37,256,312,269,26,32,40,28,296,15,280,42,316,297,33,276,281,15,53,293,303,277,29,6,36,296,257,13,16,265]

theorem envBound37559 : H12AffineFastState.Bounded env37559 := by
  intro p hp
  have h : env37559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37558_37559 : H12AffineEnvironment.transform 5 29 env37558 = env37559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 29 env37558 == env37559) = true)

theorem identity37559 : scanCanonicalize (H12AffineFastState.compose env37559 (packedSelected [0,2,3,5,9] rootPS)) = affineNative (2^(7+1) ^^^ 3) := by decide +kernel

theorem selectedBound37559 : packedSelected [0,2,3,5,9] rootPS < 2^1333 := by decide +kernel

def env37560 : List Nat := [2,4,8,16,32,29,37,3,59,14,26,32,40,28,43,15,27,42,63,42,33,23,26,15,53,38,44,22,29,6,36,43,2,13,16,10]

theorem envBound37560 : H12AffineFastState.Bounded env37560 := by
  intro p hp
  have h : env37560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37559_37560 : H12AffineEnvironment.transform 7 3 env37559 = env37560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 3 env37559 == env37560) = true)

theorem identity37560 : scanCanonicalize (H12AffineFastState.compose env37560 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound37560 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env37561 : List Nat := [2,4,8,13,32,0,37,3,38,14,7,32,40,1,43,15,6,42,34,42,33,10,7,15,40,38,44,11,0,6,36,43,2,13,13,10]

theorem envBound37561 : H12AffineFastState.Bounded env37561 := by
  intro p hp
  have h : env37561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37560_37561 : H12AffineEnvironment.transform 3 13 env37560 = env37561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env37560 == env37561) = true)

theorem identity37561 : scanCanonicalize (H12AffineFastState.compose env37561 (packedSelected [0,2,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound37561 : packedSelected [0,2,3,4] rootPS < 2^1333 := by decide +kernel

def env37562 : List Nat := [2,4,8,13,1,0,4,3,7,14,7,1,9,1,10,15,6,11,3,11,0,10,7,15,9,7,13,11,0,6,5,10,2,13,13,10]

theorem envBound37562 : H12AffineFastState.Bounded env37562 := by
  intro p hp
  have h : env37562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37561_37562 : H12AffineEnvironment.transform 4 1 env37561 = env37562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env37561 == env37562) = true)

theorem identity37562 : scanCanonicalize (H12AffineFastState.compose env37562 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound37562 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37563 : List Nat := [2,4,3,6,1,0,4,3,7,5,7,1,2,1,1,4,6,0,3,0,0,1,7,4,2,7,6,0,0,6,5,1,2,6,6,1]

theorem envBound37563 : H12AffineFastState.Bounded env37563 := by
  intro p hp
  have h : env37563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37562_37563 : H12AffineEnvironment.transform 2 3 env37562 = env37563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env37562 == env37563) = true)

def env37564 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,836,845,64,528,65536,66163,65664,517,529,837,649,66163,65537,144,65911,302,66083,65,67603,833,65831,257,81,17,340]

theorem envBound37564 : H12AffineFastState.Bounded env37564 := by
  intro p hp
  have h : env37564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37546_37564 : H12AffineEnvironment.transform 9 337 env37546 = env37564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 337 env37546 == env37564) = true)

theorem identity37564 : scanCanonicalize (H12AffineFastState.compose env37564 (packedSelected [1,8,28] rootPS)) = affineNative (2^(6+1) ^^^ 85) := by decide +kernel

theorem selectedBound37564 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env37565 : List Nat := [2,4,8,16,32,64,85,256,512,337,2048,836,845,64,528,65536,66163,65621,517,529,837,604,66163,65537,69,65911,302,66083,65,67603,833,65831,257,81,17,340]

theorem envBound37565 : H12AffineFastState.Bounded env37565 := by
  intro p hp
  have h : env37565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37564_37565 : H12AffineEnvironment.transform 6 85 env37564 = env37565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 85 env37564 == env37565) = true)

def env37566 : List Nat := [2,4,8,16,32,64,85,256,512,337,2048,836,845,64,528,2116,2615,2065,517,529,837,604,2615,2117,69,2355,302,2663,65,87,833,2403,257,81,17,340]

theorem envBound37566 : H12AffineFastState.Bounded env37566 := by
  intro p hp
  have h : env37566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37565_37566 : H12AffineEnvironment.transform 15 2116 env37565 = env37566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2116 env37565 == env37566) = true)

def env37567 : List Nat := [2,4,8,16,32,64,85,256,512,337,16,836,845,64,528,84,551,1,517,529,837,604,551,85,69,291,302,631,65,87,833,371,257,81,17,340]

theorem envBound37567 : H12AffineFastState.Bounded env37567 := by
  intro p hp
  have h : env37567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37566_37567 : H12AffineEnvironment.transform 10 16 env37566 = env37567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env37566 == env37567) = true)

theorem identity37567 : scanCanonicalize (H12AffineFastState.compose env37567 (packedSelected [0,1,2,3,5,9,12,15,16,18,23,24] rootPS)) = affineNative (2^(8+1) ^^^ 97) := by decide +kernel

theorem selectedBound37567 : packedSelected [0,1,2,3,5,9,12,15,16,18,23,24] rootPS < 2^1333 := by decide +kernel

def env37568 : List Nat := [2,4,8,16,32,64,85,256,97,337,16,293,300,64,113,84,70,1,100,112,292,61,70,85,69,291,302,22,65,87,288,371,257,81,17,340]

theorem envBound37568 : H12AffineFastState.Bounded env37568 := by
  intro p hp
  have h : env37568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37567_37568 : H12AffineEnvironment.transform 8 97 env37567 = env37568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 97 env37567 == env37568) = true)

theorem identity37568 : scanCanonicalize (H12AffineFastState.compose env37568 (packedSelected [0,1,2,3,4,7,9,10,11,13,15] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound37568 : packedSelected [0,1,2,3,4,7,9,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env37569 : List Nat := [2,4,8,16,13,64,85,256,76,337,16,264,257,64,92,84,70,1,73,93,265,16,70,85,69,270,259,22,65,87,269,350,257,81,17,340]

theorem envBound37569 : H12AffineFastState.Bounded env37569 := by
  intro p hp
  have h : env37569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37568_37569 : H12AffineEnvironment.transform 4 13 env37568 = env37569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env37568 == env37569) = true)

theorem identity37569 : scanCanonicalize (H12AffineFastState.compose env37569 (packedSelected [2,3,4,7,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 13) := by decide +kernel

theorem selectedBound37569 : packedSelected [2,3,4,7,10,11,12] rootPS < 2^1333 := by decide +kernel

def env37570 : List Nat := [2,4,8,16,13,13,24,256,1,284,16,264,257,13,17,25,11,1,4,16,265,16,11,24,8,270,259,22,12,26,269,275,257,28,17,281]

theorem envBound37570 : H12AffineFastState.Bounded env37570 := by
  intro p hp
  have h : env37570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37569_37570 : H12AffineEnvironment.transform 5 13 env37569 = env37570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 13 env37569 == env37570) = true)

theorem identity37570 : scanCanonicalize (H12AffineFastState.compose env37570 (packedSelected [1,4,5,7,8] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound37570 : packedSelected [1,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env37571 : List Nat := [2,4,8,12,13,13,4,256,1,256,12,264,257,13,13,5,11,1,4,12,265,12,11,4,8,270,259,10,12,6,269,271,257,0,13,261]

theorem envBound37571 : H12AffineFastState.Bounded env37571 := by
  intro p hp
  have h : env37571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37570_37571 : H12AffineEnvironment.transform 3 12 env37570 = env37571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env37570 == env37571) = true)

theorem identity37571 : scanCanonicalize (H12AffineFastState.compose env37571 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound37571 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37572 : List Nat := [2,4,8,12,13,13,4,4,1,4,12,12,5,13,13,5,11,1,4,12,13,12,11,4,8,10,7,10,12,6,9,11,5,0,13,1]

theorem envBound37572 : H12AffineFastState.Bounded env37572 := by
  intro p hp
  have h : env37572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37571_37572 : H12AffineEnvironment.transform 7 4 env37571 = env37572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env37571 == env37572) = true)

theorem identity37572 : scanCanonicalize (H12AffineFastState.compose env37572 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound37572 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37573 : List Nat := [2,3,8,11,10,10,3,3,1,3,11,11,2,10,10,2,11,1,3,11,10,11,11,3,8,10,0,10,11,1,9,11,2,0,10,1]

theorem envBound37573 : H12AffineFastState.Bounded env37573 := by
  intro p hp
  have h : env37573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37572_37573 : H12AffineEnvironment.transform 1 3 env37572 = env37573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env37572 == env37573) = true)

theorem identity37573 : scanCanonicalize (H12AffineFastState.compose env37573 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound37573 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37574 : List Nat := [2,3,3,0,1,1,3,3,1,3,0,0,2,1,1,2,0,1,3,0,1,0,0,3,3,1,0,1,0,1,2,0,2,0,1,1]

theorem envBound37574 : H12AffineFastState.Bounded env37574 := by
  intro p hp
  have h : env37574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37573_37574 : H12AffineEnvironment.transform 2 3 env37573 = env37574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env37573 == env37574) = true)

def env37575 : List Nat := [2,4,8,16,32,64,85,256,512,337,17,836,845,64,528,85,550,0,517,529,837,604,550,84,69,290,302,630,65,87,833,370,257,81,17,340]

theorem envBound37575 : H12AffineFastState.Bounded env37575 := by
  intro p hp
  have h : env37575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37566_37575 : H12AffineEnvironment.transform 10 17 env37566 = env37575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env37566 == env37575) = true)

theorem identity37575 : scanCanonicalize (H12AffineFastState.compose env37575 (packedSelected [0,1,2,3,5,9,12,15,16,18,23,24] rootPS)) = affineNative (2^(8+1) ^^^ 103) := by decide +kernel

theorem selectedBound37575 : packedSelected [0,1,2,3,5,9,12,15,16,18,23,24] rootPS < 2^1333 := by decide +kernel

def env37576 : List Nat := [2,4,8,16,32,64,85,256,103,337,17,291,298,64,119,85,65,0,98,118,290,59,65,84,69,290,302,17,65,87,294,370,257,81,17,340]

theorem envBound37576 : H12AffineFastState.Bounded env37576 := by
  intro p hp
  have h : env37576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37575_37576 : H12AffineEnvironment.transform 8 103 env37575 = env37576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 103 env37575 == env37576) = true)

theorem identity37576 : scanCanonicalize (H12AffineFastState.compose env37576 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound37576 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env37577 : List Nat := [2,4,8,16,10,64,85,256,77,337,17,265,256,64,93,85,65,0,72,92,264,17,65,84,69,264,260,17,65,87,268,344,257,81,17,340]

theorem envBound37577 : H12AffineFastState.Bounded env37577 := by
  intro p hp
  have h : env37577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37576_37577 : H12AffineEnvironment.transform 4 10 env37576 = env37577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env37576 == env37577) = true)

theorem identity37577 : scanCanonicalize (H12AffineFastState.compose env37577 (packedSelected [0,1,2,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound37577 : packedSelected [0,1,2,9,11] rootPS < 2^1333 := by decide +kernel

def env37578 : List Nat := [2,4,8,16,10,10,31,256,7,283,17,265,256,10,23,31,11,0,2,22,264,17,11,30,15,264,260,17,11,29,268,274,257,27,17,286]

theorem envBound37578 : H12AffineFastState.Bounded env37578 := by
  intro p hp
  have h : env37578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37577_37578 : H12AffineEnvironment.transform 5 10 env37577 = env37578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env37577 == env37578) = true)

theorem identity37578 : scanCanonicalize (H12AffineFastState.compose env37578 (packedSelected [0,4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound37578 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env37579 : List Nat := [2,4,2,16,0,0,21,256,7,273,17,259,256,0,23,21,1,0,2,22,258,17,1,20,5,258,260,17,1,23,262,274,257,17,17,276]

theorem envBound37579 : H12AffineFastState.Bounded env37579 := by
  intro p hp
  have h : env37579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37578_37579 : H12AffineEnvironment.transform 2 2 env37578 = env37579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env37578 == env37579) = true)

theorem identity37579 : scanCanonicalize (H12AffineFastState.compose env37579 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 2) := by decide +kernel

theorem selectedBound37579 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37580 : List Nat := [2,4,2,16,0,0,21,2,7,19,17,1,2,0,23,21,1,0,2,22,0,17,1,20,5,0,6,17,1,23,4,16,3,17,17,22]

theorem envBound37580 : H12AffineFastState.Bounded env37580 := by
  intro p hp
  have h : env37580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37579_37580 : H12AffineEnvironment.transform 7 2 env37579 = env37580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 2 env37579 == env37580) = true)

theorem identity37580 : scanCanonicalize (H12AffineFastState.compose env37580 (packedSelected [2,3] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound37580 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env37581 : List Nat := [2,4,2,7,0,0,2,2,7,4,6,1,2,0,0,2,1,0,2,1,0,6,1,3,5,0,6,6,1,0,4,7,3,6,6,1]

theorem envBound37581 : H12AffineFastState.Bounded env37581 := by
  intro p hp
  have h : env37581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37580_37581 : H12AffineEnvironment.transform 3 7 env37580 = env37581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env37580 == env37581) = true)

theorem identity37581 : scanCanonicalize (H12AffineFastState.compose env37581 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound37581 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37582 : List Nat := [2,3,2,0,0,0,2,2,0,3,1,1,2,0,0,2,1,0,2,1,0,1,1,3,2,0,1,1,1,0,3,0,3,1,1,1]

theorem envBound37582 : H12AffineFastState.Bounded env37582 := by
  intro p hp
  have h : env37582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37581_37582 : H12AffineEnvironment.transform 1 3 env37581 = env37582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env37581 == env37582) = true)

theorem identity37582 : scanCanonicalize (H12AffineFastState.compose env37582 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound37582 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37583 : List Nat := [0,1,0,0,0,0,0,0,0,1,1,1,0,0,0,0,1,0,0,1,0,1,1,1,0,0,1,1,1,0,1,0,1,1,1,1]

theorem envBound37583 : H12AffineFastState.Bounded env37583 := by
  intro p hp
  have h : env37583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37582_37583 : H12AffineEnvironment.transform 0 0 env37582 = env37583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env37582 == env37583) = true)

def env37584 : List Nat := [2,4,8,16,32,64,85,256,512,337,2048,836,845,64,528,2117,2614,2064,517,529,837,604,2614,2116,69,2354,302,2662,65,86,833,2402,257,81,17,340]

theorem envBound37584 : H12AffineFastState.Bounded env37584 := by
  intro p hp
  have h : env37584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37565_37584 : H12AffineEnvironment.transform 15 2117 env37565 = env37584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2117 env37565 == env37584) = true)

def env37585 : List Nat := [2,4,8,16,32,64,85,256,512,337,16,836,845,64,528,85,550,0,517,529,837,604,550,84,69,290,302,630,65,86,833,370,257,81,17,340]

theorem envBound37585 : H12AffineFastState.Bounded env37585 := by
  intro p hp
  have h : env37585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37584_37585 : H12AffineEnvironment.transform 10 16 env37584 = env37585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env37584 == env37585) = true)

theorem identity37585 : scanCanonicalize (H12AffineFastState.compose env37585 (packedSelected [0,1,2,3,5,9,12,15,16,18,23,24] rootPS)) = affineNative (2^(8+1) ^^^ 123) := by decide +kernel

theorem selectedBound37585 : packedSelected [0,1,2,3,5,9,12,15,16,18,23,24] rootPS < 2^1333 := by decide +kernel

def env37586 : List Nat := [2,4,8,16,32,64,85,256,123,337,16,319,310,64,107,85,93,0,126,106,318,39,93,84,69,290,302,13,65,86,314,370,257,81,17,340]

theorem envBound37586 : H12AffineFastState.Bounded env37586 := by
  intro p hp
  have h : env37586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37585_37586 : H12AffineEnvironment.transform 8 123 env37585 = env37586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 123 env37585 == env37586) = true)

theorem identity37586 : scanCanonicalize (H12AffineFastState.compose env37586 (packedSelected [1,2,3,4,5,7,8,10,11,13,15,17] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound37586 : packedSelected [1,2,3,4,5,7,8,10,11,13,15,17] rootPS < 2^1333 := by decide +kernel

def env37587 : List Nat := [2,4,8,16,32,64,85,20,123,69,16,43,34,64,107,85,93,0,126,106,42,39,93,84,69,54,58,13,65,86,46,102,21,81,17,64]

theorem envBound37587 : H12AffineFastState.Bounded env37587 := by
  intro p hp
  have h : env37587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37586_37587 : H12AffineEnvironment.transform 7 20 env37586 = env37587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env37586 == env37587) = true)

theorem identity37587 : scanCanonicalize (H12AffineFastState.compose env37587 (packedSelected [1,4,5,7,10,11] rootPS)) = affineNative (2^(5+1) ^^^ 6) := by decide +kernel

theorem selectedBound37587 : packedSelected [1,4,5,7,10,11] rootPS < 2^1333 := by decide +kernel

def env37588 : List Nat := [2,4,8,16,32,6,19,20,61,3,16,43,34,6,45,19,27,0,56,44,42,39,27,18,3,54,58,13,7,16,46,32,21,23,17,6]

theorem envBound37588 : H12AffineFastState.Bounded env37588 := by
  intro p hp
  have h : env37588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37587_37588 : H12AffineEnvironment.transform 5 6 env37587 = env37588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 6 env37587 == env37588) = true)

theorem identity37588 : scanCanonicalize (H12AffineFastState.compose env37588 (packedSelected [0,2,3,4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound37588 : packedSelected [0,2,3,4] rootPS < 2^1333 := by decide +kernel

def env37589 : List Nat := [2,3,8,16,32,1,19,19,58,3,16,43,34,1,42,19,27,0,56,43,42,32,27,18,3,49,58,10,0,16,41,32,18,16,17,1]

theorem envBound37589 : H12AffineFastState.Bounded env37589 := by
  intro p hp
  have h : env37589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37588_37589 : H12AffineEnvironment.transform 1 3 env37588 = env37589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env37588 == env37589) = true)

theorem identity37589 : scanCanonicalize (H12AffineFastState.compose env37589 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound37589 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env37590 : List Nat := [2,3,8,10,32,1,9,9,32,3,10,43,34,1,42,9,1,0,34,43,42,32,1,8,3,43,32,10,0,10,41,32,8,10,11,1]

theorem envBound37590 : H12AffineFastState.Bounded env37590 := by
  intro p hp
  have h : env37590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37589_37590 : H12AffineEnvironment.transform 3 10 env37589 = env37590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env37589 == env37590) = true)

theorem identity37590 : scanCanonicalize (H12AffineFastState.compose env37590 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound37590 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37591 : List Nat := [2,3,3,1,32,1,2,2,32,3,1,32,34,1,33,2,1,0,34,32,33,32,1,3,3,32,32,1,0,1,34,32,3,1,0,1]

theorem envBound37591 : H12AffineFastState.Bounded env37591 := by
  intro p hp
  have h : env37591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37590_37591 : H12AffineEnvironment.transform 2 3 env37590 = env37591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env37590 == env37591) = true)

theorem identity37591 : scanCanonicalize (H12AffineFastState.compose env37591 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound37591 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env37592 : List Nat := [2,3,3,1,1,1,2,2,1,3,1,1,3,1,0,2,1,0,3,1,0,1,1,3,3,1,1,1,0,1,3,1,3,1,0,1]

theorem envBound37592 : H12AffineFastState.Bounded env37592 := by
  intro p hp
  have h : env37592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37591_37592 : H12AffineEnvironment.transform 4 1 env37591 = env37592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env37591 == env37592) = true)

def env37593 : List Nat := [2,4,8,16,32,64,85,256,512,337,17,836,845,64,528,84,551,1,517,529,837,604,551,85,69,291,302,631,65,86,833,371,257,81,17,340]

theorem envBound37593 : H12AffineFastState.Bounded env37593 := by
  intro p hp
  have h : env37593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37584_37593 : H12AffineEnvironment.transform 10 17 env37584 = env37593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env37584 == env37593) = true)

theorem identity37593 : scanCanonicalize (H12AffineFastState.compose env37593 (packedSelected [0,1,2,3,5,9,12,15,16,18,23,24] rootPS)) = affineNative (2^(8+1) ^^^ 124) := by decide +kernel

theorem selectedBound37593 : packedSelected [0,1,2,3,5,9,12,15,16,18,23,24] rootPS < 2^1333 := by decide +kernel

def env37594 : List Nat := [2,4,8,16,32,64,85,256,124,337,17,312,305,64,108,84,91,1,121,109,313,32,91,85,69,291,302,11,65,86,317,371,257,81,17,340]

theorem envBound37594 : H12AffineFastState.Bounded env37594 := by
  intro p hp
  have h : env37594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37593_37594 : H12AffineEnvironment.transform 8 124 env37593 = env37594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 124 env37593 == env37594) = true)

theorem identity37594 : scanCanonicalize (H12AffineFastState.compose env37594 (packedSelected [0,4,5,12,13,16] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound37594 : packedSelected [0,4,5,12,13,16] rootPS < 2^1333 := by decide +kernel

def env37595 : List Nat := [2,4,8,16,32,48,37,256,12,289,17,312,305,48,28,36,43,1,9,29,313,32,43,37,53,291,302,11,49,38,317,259,257,33,17,292]

theorem envBound37595 : H12AffineFastState.Bounded env37595 := by
  intro p hp
  have h : env37595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37594_37595 : H12AffineEnvironment.transform 5 48 env37594 = env37595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env37594 == env37595) = true)

theorem identity37595 : scanCanonicalize (H12AffineFastState.compose env37595 (packedSelected [0,4,5,7,9,12] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound37595 : packedSelected [0,4,5,7,9,12] rootPS < 2^1333 := by decide +kernel

def env37596 : List Nat := [2,4,8,16,26,10,31,256,12,283,17,258,267,10,28,30,17,1,9,29,259,26,17,31,15,281,276,11,11,28,263,259,257,27,17,286]

theorem envBound37596 : H12AffineFastState.Bounded env37596 := by
  intro p hp
  have h : env37596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37595_37596 : H12AffineEnvironment.transform 4 26 env37595 = env37596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env37595 == env37596) = true)

theorem identity37596 : scanCanonicalize (H12AffineFastState.compose env37596 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 25) := by decide +kernel

theorem selectedBound37596 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env37597 : List Nat := [2,4,8,16,26,10,31,25,12,2,17,27,18,10,28,30,17,1,9,29,26,26,17,31,15,0,13,11,11,28,30,26,24,27,17,7]

theorem envBound37597 : H12AffineFastState.Bounded env37597 := by
  intro p hp
  have h : env37597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37596_37597 : H12AffineEnvironment.transform 7 25 env37596 = env37597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 25 env37596 == env37597) = true)

theorem identity37597 : scanCanonicalize (H12AffineFastState.compose env37597 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound37597 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37598 : List Nat := [2,4,8,0,10,10,15,9,12,2,1,11,2,10,12,14,1,1,9,13,10,10,1,15,15,0,13,11,11,12,14,10,8,11,1,7]

theorem envBound37598 : H12AffineFastState.Bounded env37598 := by
  intro p hp
  have h : env37598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37597_37598 : H12AffineEnvironment.transform 3 0 env37597 = env37598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env37597 == env37598) = true)

theorem identity37598 : scanCanonicalize (H12AffineFastState.compose env37598 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound37598 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env37599 : List Nat := [2,4,5,0,7,7,2,4,1,2,1,6,2,7,1,3,1,1,4,0,7,7,1,2,2,0,0,6,6,1,3,7,5,6,1,7]

theorem envBound37599 : H12AffineFastState.Bounded env37599 := by
  intro p hp
  have h : env37599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37598_37599 : H12AffineEnvironment.transform 2 5 env37598 = env37599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env37598 == env37599) = true)

theorem identity37599 : scanCanonicalize (H12AffineFastState.compose env37599 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound37599 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env37600 : List Nat := [2,3,2,0,0,0,2,3,1,2,1,1,2,0,1,3,1,1,3,0,0,0,1,2,2,0,0,1,1,1,3,0,2,1,1,0]

theorem envBound37600 : H12AffineFastState.Bounded env37600 := by
  intro p hp
  have h : env37600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37599_37600 : H12AffineEnvironment.transform 1 3 env37599 = env37600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env37599 == env37600) = true)

theorem identity37600 : scanCanonicalize (H12AffineFastState.compose env37600 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound37600 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37601 : List Nat := [1,0,1,0,0,0,1,0,1,1,1,1,1,0,1,0,1,1,0,0,0,0,1,1,1,0,0,1,1,1,0,0,1,1,1,0]

theorem envBound37601 : H12AffineFastState.Bounded env37601 := by
  intro p hp
  have h : env37601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37600_37601 : H12AffineEnvironment.transform 0 1 env37600 = env37601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env37600 == env37601) = true)

def env37602 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74863,65665,4417,8540,4097,5276,74046,66896,13768,78895,1150,74815,1296,81227,8204,65831,257,1280,1344,5953]

theorem envBound37602 : H12AffineFastState.Bounded env37602 := by
  intro p hp
  have h : env37602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37493_37602 : H12AffineEnvironment.transform 17 65665 env37493 = env37602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env37493 == env37602) = true)

theorem identity37602 : scanCanonicalize (H12AffineFastState.compose env37602 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound37602 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env37603 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,24,1297,325,65536,66679,65665,4417,324,4097,5276,65830,66896,5584,70711,1150,66599,1296,73043,20,65831,257,1280,1344,5953]

theorem envBound37603 : H12AffineFastState.Bounded env37603 := by
  intro p hp
  have h : env37603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37602_37603 : H12AffineEnvironment.transform 12 24 env37602 = env37603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env37602 == env37603) = true)

def env37604 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1556,24,1297,325,65536,66679,65665,1877,324,1557,648,65830,66896,964,66083,1150,66599,1296,68423,20,65831,257,1280,1344,341]

theorem envBound37604 : H12AffineFastState.Bounded env37604 := by
  intro p hp
  have h : env37604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37603_37604 : H12AffineEnvironment.transform 11 1556 env37603 = env37604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1556 env37603 == env37604) = true)

def env37605 : List Nat := [2,4,8,16,32,0,128,256,512,1024,2048,1556,24,1297,261,65536,66615,65665,1813,260,1557,648,65830,66832,900,66083,1086,66599,1296,68359,20,65831,257,1280,1280,277]

theorem envBound37605 : H12AffineFastState.Bounded env37605 := by
  intro p hp
  have h : env37605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37604_37605 : H12AffineEnvironment.transform 5 0 env37604 = env37605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env37604 == env37605) = true)

theorem identity37605 : scanCanonicalize (H12AffineFastState.compose env37605 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 695) := by decide +kernel

theorem selectedBound37605 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env37606 : List Nat := [2,4,8,16,32,0,128,256,512,1024,2048,1556,24,1297,261,695,1664,566,1813,260,1557,648,913,1959,900,148,1086,1680,1296,2480,20,912,257,1280,1280,277]

theorem envBound37606 : H12AffineFastState.Bounded env37606 := by
  intro p hp
  have h : env37606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37605_37606 : H12AffineEnvironment.transform 15 695 env37605 = env37606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 695 env37605 == env37606) = true)

def env37607 : List Nat := [2,4,8,16,32,0,128,256,512,272,2048,772,24,1,261,695,912,566,517,260,773,648,913,695,900,148,302,896,0,2480,20,912,257,16,16,277]

theorem envBound37607 : H12AffineFastState.Bounded env37607 := by
  intro p hp
  have h : env37607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37606_37607 : H12AffineEnvironment.transform 9 272 env37606 = env37607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env37606 == env37607) = true)

theorem identity37607 : scanCanonicalize (H12AffineFastState.compose env37607 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 132) := by decide +kernel

theorem selectedBound37607 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env37608 : List Nat := [2,4,8,16,32,0,128,256,132,272,2048,384,24,1,261,51,276,178,129,260,385,12,277,51,256,148,302,260,0,2480,20,276,257,16,16,277]

theorem envBound37608 : H12AffineFastState.Bounded env37608 := by
  intro p hp
  have h : env37608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37607_37608 : H12AffineEnvironment.transform 8 132 env37607 = env37608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 132 env37607 == env37608) = true)

theorem identity37608 : scanCanonicalize (H12AffineFastState.compose env37608 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound37608 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env37609 : List Nat := [2,4,8,16,32,0,4,256,0,272,2048,260,24,1,261,51,276,54,5,260,261,12,277,51,256,16,302,260,0,2356,20,276,257,16,16,277]

theorem envBound37609 : H12AffineFastState.Bounded env37609 := by
  intro p hp
  have h : env37609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37608_37609 : H12AffineEnvironment.transform 6 4 env37608 = env37609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env37608 == env37609) = true)

theorem identity37609 : scanCanonicalize (H12AffineFastState.compose env37609 (packedSelected [1,2,3,15] rootPS)) = affineNative (2^(10+1) ^^^ 296) := by decide +kernel

theorem selectedBound37609 : packedSelected [1,2,3,15] rootPS < 2^1333 := by decide +kernel

def env37610 : List Nat := [2,4,8,16,32,0,4,256,0,272,296,260,24,1,261,51,276,54,5,260,261,12,277,51,256,16,302,260,0,28,20,276,257,16,16,277]

theorem envBound37610 : H12AffineFastState.Bounded env37610 := by
  intro p hp
  have h : env37610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37609_37610 : H12AffineEnvironment.transform 10 296 env37609 = env37610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 296 env37609 == env37610) = true)

theorem identity37610 : scanCanonicalize (H12AffineFastState.compose env37610 (packedSelected [1,3,5,12] rootPS)) = affineNative (2^(4+1) ^^^ 29) := by decide +kernel

theorem selectedBound37610 : packedSelected [1,3,5,12] rootPS < 2^1333 := by decide +kernel

def env37611 : List Nat := [2,4,8,16,29,0,4,256,0,272,277,260,24,1,261,14,276,11,5,260,261,12,277,14,256,16,275,260,0,28,20,276,257,16,16,277]

theorem envBound37611 : H12AffineFastState.Bounded env37611 := by
  intro p hp
  have h : env37611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37610_37611 : H12AffineEnvironment.transform 4 29 env37610 = env37611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 29 env37610 == env37611) = true)

theorem identity37611 : scanCanonicalize (H12AffineFastState.compose env37611 (packedSelected [0,1,4] rootPS)) = affineNative (2^(7+1) ^^^ 25) := by decide +kernel

theorem selectedBound37611 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env37612 : List Nat := [2,4,8,16,29,0,4,25,0,9,12,29,24,1,28,14,13,11,5,29,28,12,12,14,25,16,10,29,0,28,20,13,24,16,16,12]

theorem envBound37612 : H12AffineFastState.Bounded env37612 := by
  intro p hp
  have h : env37612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37611_37612 : H12AffineEnvironment.transform 7 25 env37611 = env37612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 25 env37611 == env37612) = true)

theorem identity37612 : scanCanonicalize (H12AffineFastState.compose env37612 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound37612 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env37613 : List Nat := [2,4,8,11,6,0,4,2,0,9,12,6,3,1,7,14,13,11,5,6,7,12,12,14,2,11,10,6,0,7,15,13,3,11,11,12]

theorem envBound37613 : H12AffineFastState.Bounded env37613 := by
  intro p hp
  have h : env37613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37612_37613 : H12AffineEnvironment.transform 3 11 env37612 = env37613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env37612 == env37613) = true)

theorem identity37613 : scanCanonicalize (H12AffineFastState.compose env37613 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound37613 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37614 : List Nat := [2,4,5,6,6,0,4,2,0,4,1,6,3,1,7,3,0,6,5,6,7,1,1,3,2,6,7,6,0,7,2,0,3,6,6,1]

theorem envBound37614 : H12AffineFastState.Bounded env37614 := by
  intro p hp
  have h : env37614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37613_37614 : H12AffineEnvironment.transform 2 5 env37613 = env37614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env37613 == env37614) = true)

theorem identity37614 : scanCanonicalize (H12AffineFastState.compose env37614 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound37614 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37615 : List Nat := [2,1,0,3,3,0,1,2,0,1,1,3,3,1,2,3,0,3,0,3,2,1,1,3,2,3,2,3,0,2,2,0,3,3,3,1]

theorem envBound37615 : H12AffineFastState.Bounded env37615 := by
  intro p hp
  have h : env37615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37614_37615 : H12AffineEnvironment.transform 1 1 env37614 = env37615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env37614 == env37615) = true)

theorem identity37615 : scanCanonicalize (H12AffineFastState.compose env37615 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound37615 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env37616 : List Nat := [1,1,0,0,0,0,1,1,0,1,1,0,0,1,1,0,0,0,0,0,1,1,1,0,1,0,1,0,0,1,1,0,0,0,0,1]

theorem envBound37616 : H12AffineFastState.Bounded env37616 := by
  intro p hp
  have h : env37616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37615_37616 : H12AffineEnvironment.transform 0 1 env37615 = env37616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env37615 == env37616) = true)

def env37617 : List Nat := [2,4,8,16,32,0,128,256,512,273,2048,773,24,0,261,695,913,566,516,260,772,648,913,694,900,148,303,897,1,2480,20,912,257,17,17,277]

theorem envBound37617 : H12AffineFastState.Bounded env37617 := by
  intro p hp
  have h : env37617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37606_37617 : H12AffineEnvironment.transform 9 273 env37606 = env37617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env37606 == env37617) = true)

theorem identity37617 : scanCanonicalize (H12AffineFastState.compose env37617 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 144) := by decide +kernel

theorem selectedBound37617 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env37618 : List Nat := [2,4,8,16,32,0,128,144,512,129,2048,661,24,0,149,695,513,566,516,148,660,648,513,694,532,148,191,529,1,2080,20,512,145,17,17,133]

theorem envBound37618 : H12AffineFastState.Bounded env37618 := by
  intro p hp
  have h : env37618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37617_37618 : H12AffineEnvironment.transform 7 144 env37617 = env37618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 144 env37617 == env37618) = true)

theorem identity37618 : scanCanonicalize (H12AffineFastState.compose env37618 (packedSelected [0,1,2,3,7,10,12,17,20] rootPS)) = affineNative (2^(10+1) ^^^ 29) := by decide +kernel

theorem selectedBound37618 : packedSelected [0,1,2,3,7,10,12,17,20] rootPS < 2^1333 := by decide +kernel

def env37619 : List Nat := [2,4,8,16,32,0,128,144,512,129,29,661,24,0,149,695,513,566,516,148,660,648,513,694,532,148,191,529,1,61,20,512,145,17,17,133]

theorem envBound37619 : H12AffineFastState.Bounded env37619 := by
  intro p hp
  have h : env37619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37618_37619 : H12AffineEnvironment.transform 10 29 env37618 = env37619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 29 env37618 == env37619) = true)

theorem identity37619 : scanCanonicalize (H12AffineFastState.compose env37619 (packedSelected [0,2,4,5,7,9,11,13,15,16] rootPS)) = affineNative (2^(8+1) ^^^ 12) := by decide +kernel

theorem selectedBound37619 : packedSelected [0,2,4,5,7,9,11,13,15,16] rootPS < 2^1333 := by decide +kernel

def env37620 : List Nat := [2,4,8,16,32,0,128,144,12,129,29,153,24,0,149,187,13,58,8,148,152,132,13,186,24,148,191,29,1,61,20,12,145,17,17,133]

theorem envBound37620 : H12AffineFastState.Bounded env37620 := by
  intro p hp
  have h : env37620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37619_37620 : H12AffineEnvironment.transform 8 12 env37619 = env37620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 12 env37619 == env37620) = true)

theorem identity37620 : scanCanonicalize (H12AffineFastState.compose env37620 (packedSelected [0,4,5,12] rootPS)) = affineNative (2^(6+1) ^^^ 36) := by decide +kernel

theorem selectedBound37620 : packedSelected [0,4,5,12] rootPS < 2^1333 := by decide +kernel

def env37621 : List Nat := [2,4,8,16,32,0,36,52,12,37,29,61,24,0,49,31,13,58,8,48,60,32,13,30,24,48,27,29,1,61,20,12,53,17,17,33]

theorem envBound37621 : H12AffineFastState.Bounded env37621 := by
  intro p hp
  have h : env37621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37620_37621 : H12AffineEnvironment.transform 6 36 env37620 = env37621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 36 env37620 == env37621) = true)

theorem identity37621 : scanCanonicalize (H12AffineFastState.compose env37621 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound37621 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env37622 : List Nat := [2,4,8,16,26,0,30,14,12,31,29,7,24,0,11,31,13,0,8,10,6,26,13,30,24,10,27,29,1,7,20,12,15,17,17,27]

theorem envBound37622 : H12AffineFastState.Bounded env37622 := by
  intro p hp
  have h : env37622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37621_37622 : H12AffineEnvironment.transform 4 26 env37621 = env37622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env37621 == env37622) = true)

theorem identity37622 : scanCanonicalize (H12AffineFastState.compose env37622 (packedSelected [1,2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound37622 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env37623 : List Nat := [2,2,8,16,26,0,24,8,10,25,27,1,24,0,11,25,11,0,8,10,0,26,11,24,24,10,27,27,1,1,18,10,9,17,17,27]

theorem envBound37623 : H12AffineFastState.Bounded env37623 := by
  intro p hp
  have h : env37623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37622_37623 : H12AffineEnvironment.transform 1 2 env37622 = env37623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env37622 == env37623) = true)

theorem identity37623 : scanCanonicalize (H12AffineFastState.compose env37623 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound37623 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env37624 : List Nat := [2,2,8,1,11,0,9,8,10,8,10,1,9,0,11,8,11,0,8,10,0,11,11,9,9,10,10,10,1,1,3,10,9,0,0,10]

theorem envBound37624 : H12AffineFastState.Bounded env37624 := by
  intro p hp
  have h : env37624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37623_37624 : H12AffineEnvironment.transform 3 1 env37623 = env37624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env37623 == env37624) = true)

def env37625 : List Nat := [2,4,8,16,32,1,128,256,512,1024,2048,1556,24,1297,260,65536,66614,65665,1812,261,1557,648,65830,66833,901,66083,1087,66599,1296,68358,20,65831,257,1280,1281,276]

theorem envBound37625 : H12AffineFastState.Bounded env37625 := by
  intro p hp
  have h : env37625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37604_37625 : H12AffineEnvironment.transform 5 1 env37604 = env37625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env37604 == env37625) = true)

theorem identity37625 : scanCanonicalize (H12AffineFastState.compose env37625 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 1959) := by decide +kernel

theorem selectedBound37625 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env37626 : List Nat := [2,4,8,16,32,1,128,256,512,1024,2048,1556,24,1297,260,1959,913,1830,1812,261,1557,648,1665,694,901,1412,1087,896,1296,3233,20,1664,257,1280,1281,276]

theorem envBound37626 : H12AffineFastState.Bounded env37626 := by
  intro p hp
  have h : env37626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37625_37626 : H12AffineEnvironment.transform 15 1959 env37625 = env37626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1959 env37625 == env37626) = true)

def env37627 : List Nat := [2,4,8,16,32,1,128,256,512,272,2048,772,24,1,260,695,913,566,516,261,773,648,913,694,901,148,303,896,0,2481,20,912,257,16,17,276]

theorem envBound37627 : H12AffineFastState.Bounded env37627 := by
  intro p hp
  have h : env37627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37626_37627 : H12AffineEnvironment.transform 9 272 env37626 = env37627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env37626 == env37627) = true)

theorem identity37627 : scanCanonicalize (H12AffineFastState.compose env37627 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 133) := by decide +kernel

theorem selectedBound37627 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env37628 : List Nat := [2,4,8,16,32,1,128,256,133,272,2048,385,24,1,260,50,276,179,129,261,384,13,276,51,256,148,303,261,0,2481,20,277,257,16,17,276]

theorem envBound37628 : H12AffineFastState.Bounded env37628 := by
  intro p hp
  have h : env37628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37627_37628 : H12AffineEnvironment.transform 8 133 env37627 = env37628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 133 env37627 == env37628) = true)

theorem identity37628 : scanCanonicalize (H12AffineFastState.compose env37628 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound37628 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env37629 : List Nat := [2,4,8,16,32,1,4,256,1,272,2048,261,24,1,260,50,276,55,5,261,260,13,276,51,256,16,303,261,0,2357,20,277,257,16,17,276]

theorem envBound37629 : H12AffineFastState.Bounded env37629 := by
  intro p hp
  have h : env37629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37628_37629 : H12AffineEnvironment.transform 6 4 env37628 = env37629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env37628 == env37629) = true)

theorem identity37629 : scanCanonicalize (H12AffineFastState.compose env37629 (packedSelected [1,2,3,15] rootPS)) = affineNative (2^(10+1) ^^^ 313) := by decide +kernel

theorem selectedBound37629 : packedSelected [1,2,3,15] rootPS < 2^1333 := by decide +kernel

def env37630 : List Nat := [2,4,8,16,32,1,4,256,1,272,313,261,24,1,260,50,276,55,5,261,260,13,276,51,256,16,303,261,0,12,20,277,257,16,17,276]

theorem envBound37630 : H12AffineFastState.Bounded env37630 := by
  intro p hp
  have h : env37630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37629_37630 : H12AffineEnvironment.transform 10 313 env37629 = env37630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 313 env37629 == env37630) = true)

theorem identity37630 : scanCanonicalize (H12AffineFastState.compose env37630 (packedSelected [1,12] rootPS)) = affineNative (2^(7+1) ^^^ 34) := by decide +kernel

theorem selectedBound37630 : packedSelected [1,12] rootPS < 2^1333 := by decide +kernel

def env37631 : List Nat := [2,4,8,16,32,1,4,34,1,50,27,39,24,1,38,50,54,55,5,39,38,13,54,51,34,16,13,39,0,12,20,55,35,16,17,54]

end H12CloudChart2