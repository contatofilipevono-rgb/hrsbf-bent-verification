import H12CloudChart2Data154

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans38663_38664 : H12AffineEnvironment.transform 8 413 env38663 = env38664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 413 env38663 == env38664) = true)

theorem identity38664 : scanCanonicalize (H12AffineFastState.compose env38664 (packedSelected [0,4,5,7,9,18,21,23,26,28] rootPS)) = affineNative (2^(15+1) ^^^ 2333) := by decide +kernel

theorem selectedBound38664 : packedSelected [0,4,5,7,9,18,21,23,26,28] rootPS < 2^1333 := by decide +kernel

def env38665 : List Nat := [2,4,8,16,32,16,128,256,413,273,2048,277,8192,0,8217,2333,0,2460,10294,8216,277,397,16,2072,2478,10551,10264,0,10291,8195,8204,8200,257,16,0,10426]

theorem envBound38665 : H12AffineFastState.Bounded env38665 := by
  intro p hp
  have h : env38665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38664_38665 : H12AffineEnvironment.transform 15 2333 env38664 = env38665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2333 env38664 == env38665) = true)

theorem identity38665 : scanCanonicalize (H12AffineFastState.compose env38665 (packedSelected [1,2,3,11,12,15,18] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound38665 : packedSelected [1,2,3,11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env38666 : List Nat := [2,4,8,16,32,16,128,173,48,188,2048,184,8192,0,8217,2224,0,2097,10294,8216,184,32,16,2072,2051,10394,10264,0,10291,8195,8204,8200,172,16,0,10426]

theorem envBound38666 : H12AffineFastState.Bounded env38666 := by
  intro p hp
  have h : env38666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38665_38666 : H12AffineEnvironment.transform 7 173 env38665 = env38666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env38665 == env38666) = true)

theorem identity38666 : scanCanonicalize (H12AffineFastState.compose env38666 (packedSelected [0,1,4,5,7,9,10,13] rootPS)) = affineNative (2^(12+1) ^^^ 2187) := by decide +kernel

theorem selectedBound38666 : packedSelected [0,1,4,5,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env38667 : List Nat := [2,4,8,16,32,16,128,173,48,188,2048,184,2187,0,2194,2224,0,2097,189,2195,184,32,16,2072,2051,17,147,0,184,2184,2183,2179,172,16,0,49]

theorem envBound38667 : H12AffineFastState.Bounded env38667 := by
  intro p hp
  have h : env38667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38666_38667 : H12AffineEnvironment.transform 12 2187 env38666 = env38667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2187 env38666 == env38667) = true)

theorem identity38667 : scanCanonicalize (H12AffineFastState.compose env38667 (packedSelected [0,4,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 168) := by decide +kernel

theorem selectedBound38667 : packedSelected [0,4,5,8] rootPS < 2^1333 := by decide +kernel

def env38668 : List Nat := [2,4,8,16,32,16,128,173,48,188,168,184,35,0,58,24,0,153,189,59,184,32,16,176,171,17,147,0,184,32,47,43,172,16,0,49]

theorem envBound38668 : H12AffineFastState.Bounded env38668 := by
  intro p hp
  have h : env38668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38667_38668 : H12AffineEnvironment.transform 10 168 env38667 = env38668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 168 env38667 == env38668) = true)

theorem identity38668 : scanCanonicalize (H12AffineFastState.compose env38668 (packedSelected [1,3,4,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 21) := by decide +kernel

theorem selectedBound38668 : packedSelected [1,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env38669 : List Nat := [2,4,8,16,32,16,21,56,48,41,61,45,35,0,58,24,0,12,40,59,45,32,16,37,62,17,6,0,45,32,47,43,57,16,0,49]

theorem envBound38669 : H12AffineFastState.Bounded env38669 := by
  intro p hp
  have h : env38669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38668_38669 : H12AffineEnvironment.transform 6 21 env38668 = env38669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 21 env38668 == env38669) = true)

theorem identity38669 : scanCanonicalize (H12AffineFastState.compose env38669 (packedSelected [0,1,3,5,9] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound38669 : packedSelected [0,1,3,5,9] rootPS < 2^1333 := by decide +kernel

def env38670 : List Nat := [2,4,8,1,32,1,4,41,33,41,44,45,35,0,43,9,0,12,40,42,45,32,1,37,47,0,6,0,45,32,47,43,40,1,0,32]

theorem envBound38670 : H12AffineFastState.Bounded env38670 := by
  intro p hp
  have h : env38670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38669_38670 : H12AffineEnvironment.transform 3 1 env38669 = env38670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env38669 == env38670) = true)

theorem identity38670 : scanCanonicalize (H12AffineFastState.compose env38670 (packedSelected [2,3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound38670 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env38671 : List Nat := [2,2,8,1,32,1,2,41,33,41,42,43,35,0,43,9,0,10,40,42,43,32,1,35,41,0,0,0,43,32,41,43,40,1,0,32]

theorem envBound38671 : H12AffineFastState.Bounded env38671 := by
  intro p hp
  have h : env38671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38670_38671 : H12AffineEnvironment.transform 1 2 env38670 = env38671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env38670 == env38671) = true)

theorem identity38671 : scanCanonicalize (H12AffineFastState.compose env38671 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound38671 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38672 : List Nat := [2,2,3,1,32,1,2,34,33,34,33,32,35,0,32,2,0,1,35,33,32,32,1,35,34,0,0,0,32,32,34,32,35,1,0,32]

theorem envBound38672 : H12AffineFastState.Bounded env38672 := by
  intro p hp
  have h : env38672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38671_38672 : H12AffineEnvironment.transform 2 3 env38671 = env38672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env38671 == env38672) = true)

theorem identity38672 : scanCanonicalize (H12AffineFastState.compose env38672 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound38672 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38673 : List Nat := [0,0,1,1,32,1,0,32,33,32,33,32,33,0,32,0,0,1,33,33,32,32,1,33,32,0,0,0,32,32,32,32,33,1,0,32]

theorem envBound38673 : H12AffineFastState.Bounded env38673 := by
  intro p hp
  have h : env38673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38672_38673 : H12AffineEnvironment.transform 0 0 env38672 = env38673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env38672 == env38673) = true)

def env38674 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,4096,8192,1,12557,65536,0,65665,77887,12556,4096,396,16,69648,70054,78142,77840,1,74031,79883,8204,8200,257,17,0,78639]

theorem envBound38674 : H12AffineFastState.Bounded env38674 := by
  intro p hp
  have h : env38674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38661_38674 : H12AffineEnvironment.transform 5 17 env38661 = env38674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env38661 == env38674) = true)

theorem identity38674 : scanCanonicalize (H12AffineFastState.compose env38674 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 8250) := by decide +kernel

theorem selectedBound38674 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env38675 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,4096,8192,1,12557,8250,0,8379,4101,12556,4096,396,16,12330,12700,4356,4138,1,277,6193,8204,8200,257,17,0,4885]

theorem envBound38675 : H12AffineFastState.Bounded env38675 := by
  intro p hp
  have h : env38675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38674_38675 : H12AffineEnvironment.transform 15 8250 env38674 = env38675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8250 env38674 == env38675) = true)

def env38676 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16465,262144,95615,32769,4096,61649,17,284032,86518,94526,77841,1296,74815,96347,381313,381317,257,1281,1345,95103]

theorem envBound38676 : H12AffineFastState.Bounded env38676 := by
  intro p hp
  have h : env38676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38619_38676 : H12AffineEnvironment.transform 16 16465 env38619 = env38676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16465 env38619 == env38676) = true)

def env38677 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1345,262144,77935,32769,4096,46529,17,266384,70886,78894,77841,1296,74815,81227,365713,365717,257,1281,1345,79471]

theorem envBound38677 : H12AffineFastState.Bounded env38677 := by
  intro p hp
  have h : env38677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38676_38677 : H12AffineEnvironment.transform 13 1296 env38676 = env38677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env38676 == env38677) = true)

theorem identity38677 : scanCanonicalize (H12AffineFastState.compose env38677 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound38677 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env38678 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1345,262144,77935,13340,4096,476,17,266384,70886,78894,77841,1296,74815,81227,336012,336008,257,1281,1345,79471]

theorem envBound38678 : H12AffineFastState.Bounded env38678 := by
  intro p hp
  have h : env38678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38677_38678 : H12AffineEnvironment.transform 14 13341 env38677 = env38678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env38677 == env38678) = true)

def env38679 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1345,65664,77935,13340,4096,476,17,69648,70886,78894,77841,1296,74815,81227,8204,8200,257,1281,1345,79471]

theorem envBound38679 : H12AffineFastState.Bounded env38679 := by
  intro p hp
  have h : env38679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38678_38679 : H12AffineEnvironment.transform 17 65664 env38678 = env38679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env38678 == env38679) = true)

theorem identity38679 : scanCanonicalize (H12AffineFastState.compose env38679 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 72) := by decide +kernel

theorem selectedBound38679 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env38680 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,72,1296,5205,65536,1345,65664,69671,5204,4096,476,17,69648,70886,70758,69721,1296,66679,72963,68,64,257,1281,1345,71207]

theorem envBound38680 : H12AffineFastState.Bounded env38680 := by
  intro p hp
  have h : env38680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38679_38680 : H12AffineEnvironment.transform 12 72 env38679 = env38680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env38679 == env38680) = true)

def env38681 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,24,1296,5125,65536,1297,65664,69671,5124,4096,396,17,69648,70838,70710,69641,1296,66599,72963,20,16,257,1281,1297,71207]

theorem envBound38681 : H12AffineFastState.Bounded env38681 := by
  intro p hp
  have h : env38681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38680_38681 : H12AffineEnvironment.transform 5 16 env38680 = env38681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38680 == env38681) = true)

theorem identity38681 : scanCanonicalize (H12AffineFastState.compose env38681 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 1331) := by decide +kernel

theorem selectedBound38681 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env38682 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,24,1296,5125,1331,1297,1459,5396,5124,4096,396,17,5411,4485,4357,5434,1296,276,6192,20,16,257,1281,1297,4884]

theorem envBound38682 : H12AffineFastState.Bounded env38682 := by
  intro p hp
  have h : env38682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38681_38682 : H12AffineEnvironment.transform 15 1331 env38681 = env38682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1331 env38681 == env38682) = true)

theorem identity38682 : scanCanonicalize (H12AffineFastState.compose env38682 (packedSelected [2,3,10,13,21,23,24,26,32] rootPS)) = affineNative (2^(9+1) ^^^ 653) := by decide +kernel

theorem selectedBound38682 : packedSelected [2,3,10,13,21,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env38683 : List Nat := [2,4,8,16,32,16,128,256,512,653,2048,4096,24,925,4744,958,924,830,5017,4745,4096,396,17,5038,4485,4357,5047,925,276,6192,20,16,257,908,924,4884]

theorem envBound38683 : H12AffineFastState.Bounded env38683 := by
  intro p hp
  have h : env38683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38682_38683 : H12AffineEnvironment.transform 9 653 env38682 = env38683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 653 env38682 == env38683) = true)

theorem identity38683 : scanCanonicalize (H12AffineFastState.compose env38683 (packedSelected [0,3,4,5,7,9,10,13,18,23,24,28] rootPS)) = affineNative (2^(11+1) ^^^ 2090) := by decide +kernel

theorem selectedBound38683 : packedSelected [0,3,4,5,7,9,10,13,18,23,24,28] rootPS < 2^1333 := by decide +kernel

def env38684 : List Nat := [2,4,8,16,32,16,128,256,512,653,2048,2090,24,925,2722,958,924,830,2995,2723,2090,396,17,2948,2479,2351,2973,925,276,26,20,16,257,908,924,2878]

theorem envBound38684 : H12AffineFastState.Bounded env38684 := by
  intro p hp
  have h : env38684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38683_38684 : H12AffineEnvironment.transform 11 2090 env38683 = env38684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2090 env38683 == env38684) = true)

theorem identity38684 : scanCanonicalize (H12AffineFastState.compose env38684 (packedSelected [1,2,3,5,8,10,11,18,19] rootPS)) = affineNative (2^(10+1) ^^^ 782) := by decide +kernel

theorem selectedBound38684 : packedSelected [1,2,3,5,8,10,11,18,19] rootPS < 2^1333 := by decide +kernel

def env38685 : List Nat := [2,4,8,16,32,16,128,256,512,653,782,804,24,925,428,958,924,830,189,429,804,396,17,138,673,545,147,925,276,26,20,16,257,908,924,48]

theorem envBound38685 : H12AffineFastState.Bounded env38685 := by
  intro p hp
  have h : env38685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38684_38685 : H12AffineEnvironment.transform 10 782 env38684 = env38685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 782 env38684 == env38685) = true)

theorem identity38685 : scanCanonicalize (H12AffineFastState.compose env38685 (packedSelected [0,2,9,12] rootPS)) = affineNative (2^(8+1) ^^^ 163) := by decide +kernel

theorem selectedBound38685 : packedSelected [0,2,9,12] rootPS < 2^1333 := by decide +kernel

def env38686 : List Nat := [2,4,8,16,32,16,128,256,163,46,429,391,24,318,428,285,319,413,189,429,391,396,17,138,2,130,147,318,276,26,20,16,257,303,319,48]

theorem envBound38686 : H12AffineFastState.Bounded env38686 := by
  intro p hp
  have h : env38686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38685_38686 : H12AffineEnvironment.transform 8 163 env38685 = env38686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 163 env38685 == env38686) = true)

theorem identity38686 : scanCanonicalize (H12AffineFastState.compose env38686 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound38686 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env38687 : List Nat := [2,4,8,16,32,16,128,14,163,46,163,137,24,48,162,19,49,147,189,163,137,130,17,138,2,130,147,48,26,26,20,16,15,33,49,48]

theorem envBound38687 : H12AffineFastState.Bounded env38687 := by
  intro p hp
  have h : env38687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38686_38687 : H12AffineEnvironment.transform 7 14 env38686 = env38687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env38686 == env38687) = true)

theorem identity38687 : scanCanonicalize (H12AffineFastState.compose env38687 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound38687 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env38688 : List Nat := [2,4,8,16,11,16,128,14,136,5,136,137,24,27,137,19,26,147,150,136,137,130,17,138,2,130,147,27,26,26,20,16,15,10,26,27]

theorem envBound38688 : H12AffineFastState.Bounded env38688 := by
  intro p hp
  have h : env38688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38687_38688 : H12AffineEnvironment.transform 4 11 env38687 = env38688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env38687 == env38688) = true)

theorem identity38688 : scanCanonicalize (H12AffineFastState.compose env38688 (packedSelected [1,5] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound38688 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env38689 : List Nat := [2,4,8,16,11,16,8,14,0,5,0,1,24,27,1,19,26,27,30,0,1,10,17,2,2,10,27,27,26,26,20,16,15,10,26,27]

theorem envBound38689 : H12AffineFastState.Bounded env38689 := by
  intro p hp
  have h : env38689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38688_38689 : H12AffineEnvironment.transform 6 8 env38688 = env38689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env38688 == env38689) = true)

theorem identity38689 : scanCanonicalize (H12AffineFastState.compose env38689 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound38689 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38690 : List Nat := [2,4,8,11,11,11,8,14,0,5,0,1,3,0,1,8,1,0,5,0,1,10,10,2,2,10,0,0,1,1,15,11,15,10,1,0]

theorem envBound38690 : H12AffineFastState.Bounded env38690 := by
  intro p hp
  have h : env38690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38689_38690 : H12AffineEnvironment.transform 3 11 env38689 = env38690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env38689 == env38690) = true)

theorem identity38690 : scanCanonicalize (H12AffineFastState.compose env38690 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound38690 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38691 : List Nat := [2,2,8,11,11,11,8,8,0,3,0,1,3,0,1,8,1,0,3,0,1,10,10,2,2,10,0,0,1,1,9,11,9,10,1,0]

theorem envBound38691 : H12AffineFastState.Bounded env38691 := by
  intro p hp
  have h : env38691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38690_38691 : H12AffineEnvironment.transform 1 2 env38690 = env38691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env38690 == env38691) = true)

def env38692 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,25,1296,5124,65536,1296,65664,69671,5125,4096,397,17,69648,70839,70711,69640,1296,66598,72963,21,17,257,1281,1296,71207]

theorem envBound38692 : H12AffineFastState.Bounded env38692 := by
  intro p hp
  have h : env38692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38680_38692 : H12AffineEnvironment.transform 5 17 env38680 = env38692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env38680 == env38692) = true)

theorem identity38692 : scanCanonicalize (H12AffineFastState.compose env38692 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound38692 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env38693 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,276,25,1296,1296,65536,1296,65664,65843,1297,276,397,17,65796,66979,66851,65820,1296,66598,68631,21,17,257,1281,1296,67379]

theorem envBound38693 : H12AffineFastState.Bounded env38693 := by
  intro p hp
  have h : env38693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38692_38693 : H12AffineEnvironment.transform 11 276 env38692 = env38693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env38692 == env38693) = true)

def env38694 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1345,65665,77935,13340,4096,476,17,69649,70886,78894,77841,1296,74815,81227,8205,8201,257,1281,1345,79471]

theorem envBound38694 : H12AffineFastState.Bounded env38694 := by
  intro p hp
  have h : env38694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38678_38694 : H12AffineEnvironment.transform 17 65665 env38678 = env38694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env38678 == env38694) = true)

theorem identity38694 : scanCanonicalize (H12AffineFastState.compose env38694 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5384) := by decide +kernel

theorem selectedBound38694 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env38695 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5384,1296,277,65536,1345,65665,66919,276,4096,476,17,69649,70886,65830,66841,1296,69943,67651,5381,5377,257,1281,1345,66407]

theorem envBound38695 : H12AffineFastState.Bounded env38695 := by
  intro p hp
  have h : env38695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38694_38695 : H12AffineEnvironment.transform 12 5384 env38694 = env38695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5384 env38694 == env38695) = true)

def env38696 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,5384,1296,277,65536,1297,65665,66871,276,4096,396,17,69649,70838,65830,66841,1296,69943,67603,5381,5377,257,1281,1297,66359]

theorem envBound38696 : H12AffineFastState.Bounded env38696 := by
  intro p hp
  have h : env38696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38695_38696 : H12AffineEnvironment.transform 5 16 env38695 = env38696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38695 == env38696) = true)

theorem identity38696 : scanCanonicalize (H12AffineFastState.compose env38696 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 4131) := by decide +kernel

theorem selectedBound38696 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env38697 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,5384,1296,277,4131,1297,4258,5396,276,4096,396,17,50,1173,4357,5434,1296,276,6192,5381,5377,257,1281,1297,4884]

theorem envBound38697 : H12AffineFastState.Bounded env38697 := by
  intro p hp
  have h : env38697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38696_38697 : H12AffineEnvironment.transform 15 4131 env38696 = env38697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4131 env38696 == env38697) = true)

theorem identity38697 : scanCanonicalize (H12AffineFastState.compose env38697 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound38697 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env38698 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,276,1052,1296,277,311,1297,438,1024,276,276,396,17,50,1173,17,1070,1296,276,2340,1041,1045,257,1281,1297,512]

theorem envBound38698 : H12AffineFastState.Bounded env38698 := by
  intro p hp
  have h : env38698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38697_38698 : H12AffineEnvironment.transform 11 276 env38697 = env38698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env38697 == env38698) = true)

theorem identity38698 : scanCanonicalize (H12AffineFastState.compose env38698 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 276) := by decide +kernel

theorem selectedBound38698 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env38699 : List Nat := [2,4,8,16,32,16,128,256,512,1024,276,276,1052,1296,277,311,1297,438,1024,276,276,396,17,50,1173,17,1070,1296,276,48,1041,1045,257,1281,1297,512]

theorem envBound38699 : H12AffineFastState.Bounded env38699 := by
  intro p hp
  have h : env38699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38698_38699 : H12AffineEnvironment.transform 10 276 env38698 = env38699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 276 env38698 == env38699) = true)

theorem identity38699 : scanCanonicalize (H12AffineFastState.compose env38699 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound38699 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env38700 : List Nat := [2,4,8,16,32,16,128,256,0,1024,276,276,1052,1296,277,311,1297,438,1024,276,276,396,17,50,1173,17,1070,1296,276,48,1041,1045,257,1281,1297,0]

theorem envBound38700 : H12AffineFastState.Bounded env38700 := by
  intro p hp
  have h : env38700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38699_38700 : H12AffineEnvironment.transform 8 0 env38699 = env38700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env38699 == env38700) = true)

theorem identity38700 : scanCanonicalize (H12AffineFastState.compose env38700 (packedSelected [0,2,8] rootPS)) = affineNative (2^(9+1) ^^^ 167) := by decide +kernel

theorem selectedBound38700 : packedSelected [0,2,8] rootPS < 2^1333 := by decide +kernel

def env38701 : List Nat := [2,4,8,16,32,16,128,256,0,167,276,276,187,439,277,311,438,438,167,276,276,396,17,50,50,17,137,439,276,48,182,178,257,422,438,0]

theorem envBound38701 : H12AffineFastState.Bounded env38701 := by
  intro p hp
  have h : env38701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38700_38701 : H12AffineEnvironment.transform 9 167 env38700 = env38701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 167 env38700 == env38701) = true)

theorem identity38701 : scanCanonicalize (H12AffineFastState.compose env38701 (packedSelected [0,3,7,9] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound38701 : packedSelected [0,3,7,9] rootPS < 2^1333 := by decide +kernel

def env38702 : List Nat := [2,4,8,11,32,11,128,256,0,167,271,271,160,428,270,300,429,429,167,271,271,396,10,41,41,10,137,428,271,43,173,169,257,422,429,0]

theorem envBound38702 : H12AffineFastState.Bounded env38702 := by
  intro p hp
  have h : env38702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38701_38702 : H12AffineEnvironment.transform 3 11 env38701 = env38702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env38701 == env38702) = true)

theorem identity38702 : scanCanonicalize (H12AffineFastState.compose env38702 (packedSelected [0,1,2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound38702 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env38703 : List Nat := [2,4,8,11,32,11,8,256,0,47,271,271,40,292,270,300,293,293,47,271,271,260,10,41,41,10,1,292,271,43,37,33,257,302,293,0]

theorem envBound38703 : H12AffineFastState.Bounded env38703 := by
  intro p hp
  have h : env38703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38702_38703 : H12AffineEnvironment.transform 6 8 env38702 = env38703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env38702 == env38703) = true)

theorem identity38703 : scanCanonicalize (H12AffineFastState.compose env38703 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound38703 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env38704 : List Nat := [2,4,8,11,11,11,8,256,0,4,271,271,3,271,270,263,270,270,4,271,271,260,10,2,2,10,1,271,271,0,14,10,257,261,270,0]

theorem envBound38704 : H12AffineFastState.Bounded env38704 := by
  intro p hp
  have h : env38704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38703_38704 : H12AffineEnvironment.transform 4 11 env38703 = env38704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env38703 == env38704) = true)

theorem identity38704 : scanCanonicalize (H12AffineFastState.compose env38704 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound38704 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env38705 : List Nat := [2,4,8,11,11,11,8,14,0,4,1,1,3,1,0,9,0,0,4,1,1,10,10,2,2,10,1,1,1,0,14,10,15,11,0,0]

theorem envBound38705 : H12AffineFastState.Bounded env38705 := by
  intro p hp
  have h : env38705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38704_38705 : H12AffineEnvironment.transform 7 14 env38704 = env38705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env38704 == env38705) = true)

theorem identity38705 : scanCanonicalize (H12AffineFastState.compose env38705 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound38705 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38706 : List Nat := [2,3,8,11,11,11,8,9,0,3,1,1,3,1,0,9,0,0,3,1,1,10,10,2,2,10,1,1,1,0,9,10,8,11,0,0]

theorem envBound38706 : H12AffineFastState.Bounded env38706 := by
  intro p hp
  have h : env38706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38705_38706 : H12AffineEnvironment.transform 1 3 env38705 = env38706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env38705 == env38706) = true)

def env38707 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,5384,1296,277,65536,1296,65665,66870,276,4096,397,17,69649,70839,65830,66841,1296,69943,67602,5381,5377,257,1281,1296,66358]

theorem envBound38707 : H12AffineFastState.Bounded env38707 := by
  intro p hp
  have h : env38707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38695_38707 : H12AffineEnvironment.transform 5 17 env38695 = env38707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env38695 == env38707) = true)

theorem identity38707 : scanCanonicalize (H12AffineFastState.compose env38707 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound38707 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env38708 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,276,1052,1296,277,65536,1296,65665,66870,276,276,397,17,65797,66979,65830,66841,1296,65571,67602,1041,1045,257,1281,1296,66358]

theorem envBound38708 : H12AffineFastState.Bounded env38708 := by
  intro p hp
  have h : env38708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38707_38708 : H12AffineEnvironment.transform 11 276 env38707 = env38708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env38707 == env38708) = true)

theorem identity38708 : scanCanonicalize (H12AffineFastState.compose env38708 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 311) := by decide +kernel

theorem selectedBound38708 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env38709 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,276,1052,1296,277,311,1296,438,1025,276,276,397,17,50,1172,17,1070,1296,276,2341,1041,1045,257,1281,1296,513]

theorem envBound38709 : H12AffineFastState.Bounded env38709 := by
  intro p hp
  have h : env38709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38708_38709 : H12AffineEnvironment.transform 15 311 env38708 = env38709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 311 env38708 == env38709) = true)

theorem identity38709 : scanCanonicalize (H12AffineFastState.compose env38709 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 548) := by decide +kernel

theorem selectedBound38709 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env38710 : List Nat := [2,4,8,16,32,17,128,256,512,548,2048,276,568,820,277,311,820,438,549,276,276,397,17,50,688,17,522,820,276,2341,565,561,257,805,820,513]

theorem envBound38710 : H12AffineFastState.Bounded env38710 := by
  intro p hp
  have h : env38710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38709_38710 : H12AffineEnvironment.transform 9 548 env38709 = env38710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 548 env38709 == env38710) = true)

theorem identity38710 : scanCanonicalize (H12AffineFastState.compose env38710 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 303) := by decide +kernel

theorem selectedBound38710 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env38711 : List Nat := [2,4,8,16,32,17,128,256,512,548,303,276,568,820,277,311,820,438,549,276,276,397,17,50,688,17,522,820,276,10,565,561,257,805,820,513]

theorem envBound38711 : H12AffineFastState.Bounded env38711 := by
  intro p hp
  have h : env38711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38710_38711 : H12AffineEnvironment.transform 10 303 env38710 = env38711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 303 env38710 == env38711) = true)

theorem identity38711 : scanCanonicalize (H12AffineFastState.compose env38711 (packedSelected [0,7,18] rootPS)) = affineNative (2^(7+1) ^^^ 188) := by decide +kernel

theorem selectedBound38711 : packedSelected [0,7,18] rootPS < 2^1333 := by decide +kernel

def env38712 : List Nat := [2,4,8,16,32,17,128,188,512,548,147,168,568,648,169,139,648,10,549,168,168,49,17,50,688,17,522,648,168,10,565,561,189,665,648,513]

theorem envBound38712 : H12AffineFastState.Bounded env38712 := by
  intro p hp
  have h : env38712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38711_38712 : H12AffineEnvironment.transform 7 188 env38711 = env38712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 188 env38711 == env38712) = true)

theorem identity38712 : scanCanonicalize (H12AffineFastState.compose env38712 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound38712 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env38713 : List Nat := [2,4,8,16,32,17,56,4,512,548,43,16,568,560,17,51,560,10,549,16,16,49,17,50,520,17,522,560,16,10,565,561,5,545,560,513]

theorem envBound38713 : H12AffineFastState.Bounded env38713 := by
  intro p hp
  have h : env38713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38712_38713 : H12AffineEnvironment.transform 6 56 env38712 = env38713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env38712 == env38713) = true)

theorem identity38713 : scanCanonicalize (H12AffineFastState.compose env38713 (packedSelected [0,1,3,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound38713 : packedSelected [0,1,3,4,5] rootPS < 2^1333 := by decide +kernel

def env38714 : List Nat := [2,4,8,16,7,17,31,4,512,515,12,16,543,535,17,20,535,10,514,16,16,22,17,21,520,17,522,535,16,10,530,534,5,518,535,513]

theorem envBound38714 : H12AffineFastState.Bounded env38714 := by
  intro p hp
  have h : env38714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38713_38714 : H12AffineEnvironment.transform 4 7 env38713 = env38714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env38713 == env38714) = true)

theorem identity38714 : scanCanonicalize (H12AffineFastState.compose env38714 (packedSelected [2,3,4,7] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound38714 : packedSelected [2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env38715 : List Nat := [2,4,8,16,7,17,31,4,16,19,12,16,15,7,17,20,7,10,18,16,16,22,17,21,24,17,26,7,16,10,2,6,5,22,7,17]

theorem envBound38715 : H12AffineFastState.Bounded env38715 := by
  intro p hp
  have h : env38715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38714_38715 : H12AffineEnvironment.transform 8 16 env38714 = env38715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env38714 == env38715) = true)

theorem identity38715 : scanCanonicalize (H12AffineFastState.compose env38715 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound38715 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env38716 : List Nat := [2,4,8,12,7,13,3,4,12,15,12,12,15,7,13,8,7,10,14,12,12,10,13,9,4,13,6,7,12,10,2,6,5,10,7,13]

theorem envBound38716 : H12AffineFastState.Bounded env38716 := by
  intro p hp
  have h : env38716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38715_38716 : H12AffineEnvironment.transform 3 12 env38715 = env38716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env38715 == env38716) = true)

theorem identity38716 : scanCanonicalize (H12AffineFastState.compose env38716 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound38716 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38717 : List Nat := [2,2,8,10,1,11,3,2,10,9,10,10,9,1,11,8,1,10,8,10,10,10,11,9,2,11,0,1,10,10,2,0,3,10,1,11]

theorem envBound38717 : H12AffineFastState.Bounded env38717 := by
  intro p hp
  have h : env38717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38716_38717 : H12AffineEnvironment.transform 1 2 env38716 = env38717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env38716 == env38717) = true)

theorem identity38717 : scanCanonicalize (H12AffineFastState.compose env38717 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound38717 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38718 : List Nat := [2,2,0,2,1,3,3,2,2,1,2,2,1,1,3,0,1,2,0,2,2,2,3,1,2,3,0,1,2,2,2,0,3,2,1,3]

theorem envBound38718 : H12AffineFastState.Bounded env38718 := by
  intro p hp
  have h : env38718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38717_38718 : H12AffineEnvironment.transform 2 0 env38717 = env38718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env38717 == env38718) = true)

theorem identity38718 : scanCanonicalize (H12AffineFastState.compose env38718 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound38718 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env38719 : List Nat := [0,0,0,0,1,1,1,0,0,1,0,0,1,1,1,0,1,0,0,0,0,0,1,1,0,1,0,1,0,0,0,0,1,0,1,1]

theorem envBound38719 : H12AffineFastState.Bounded env38719 := by
  intro p hp
  have h : env38719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38718_38719 : H12AffineEnvironment.transform 0 0 env38718 = env38719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env38718 == env38719) = true)

def env38720 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1344,262144,77934,32769,4096,46528,17,266385,70887,78895,77841,1296,74815,81226,365712,365716,257,1281,1345,79470]

theorem envBound38720 : H12AffineFastState.Bounded env38720 := by
  intro p hp
  have h : env38720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38676_38720 : H12AffineEnvironment.transform 13 1297 env38676 = env38720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env38676 == env38720) = true)

theorem identity38720 : scanCanonicalize (H12AffineFastState.compose env38720 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32882) := by decide +kernel

theorem selectedBound38720 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env38721 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,32882,1344,262144,45084,32769,4096,46528,17,266385,38037,46173,45155,1296,42061,48440,267490,267494,257,1281,1345,46620]

theorem envBound38721 : H12AffineFastState.Bounded env38721 := by
  intro p hp
  have h : env38721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38720_38721 : H12AffineEnvironment.transform 15 32882 env38720 = env38721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32882 env38720 == env38721) = true)

def env38722 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32882,1344,262144,42332,32769,1344,41088,17,263633,33237,41245,42275,1296,42061,43128,262562,262566,257,1281,1345,41820]

theorem envBound38722 : H12AffineFastState.Bounded env38722 := by
  intro p hp
  have h : env38722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38721_38722 : H12AffineEnvironment.transform 11 1344 env38721 = env38722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env38721 == env38722) = true)

theorem identity38722 : scanCanonicalize (H12AffineFastState.compose env38722 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 34226) := by decide +kernel

theorem selectedBound38722 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env38723 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32882,1344,34226,42332,32769,1344,41088,17,32867,33237,41245,42275,1296,42061,43128,33808,33812,257,1281,1345,41820]

theorem envBound38723 : H12AffineFastState.Bounded env38723 := by
  intro p hp
  have h : env38723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38722_38723 : H12AffineEnvironment.transform 17 34226 env38722 = env38723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 34226 env38722 == env38723) = true)

theorem identity38723 : scanCanonicalize (H12AffineFastState.compose env38723 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(14+1) ^^^ 3614) := by decide +kernel

theorem selectedBound38723 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env38724 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,3614,3692,1344,2988,11074,3615,1344,11934,17,3709,4043,12035,11069,1296,10835,9830,2574,2570,257,1281,1345,11586]

theorem envBound38724 : H12AffineFastState.Bounded env38724 := by
  intro p hp
  have h : env38724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38723_38724 : H12AffineEnvironment.transform 14 3614 env38723 = env38724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 3614 env38723 == env38724) = true)

def env38725 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32882,1344,262144,42333,32769,1345,41089,17,263632,33236,41244,42274,1296,42061,43129,262563,262567,257,1281,1345,41821]

theorem envBound38725 : H12AffineFastState.Bounded env38725 := by
  intro p hp
  have h : env38725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38721_38725 : H12AffineEnvironment.transform 11 1345 env38721 = env38725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env38721 == env38725) = true)

theorem identity38725 : scanCanonicalize (H12AffineFastState.compose env38725 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound38725 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env38726 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,0,8192,80,32768,32882,1,262144,40988,32769,0,41089,17,262289,33236,41244,41059,81,41228,43129,262563,262567,257,64,0,41821]

theorem envBound38726 : H12AffineFastState.Bounded env38726 := by
  intro p hp
  have h : env38726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38725_38726 : H12AffineEnvironment.transform 9 321 env38725 = env38726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env38725 == env38726) = true)

theorem identity38726 : scanCanonicalize (H12AffineFastState.compose env38726 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound38726 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env38727 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,0,8192,80,8541,8495,1,262144,321,8540,0,476,17,262289,8329,65,318,81,81,2340,262563,262567,257,64,0,512]

theorem envBound38727 : H12AffineFastState.Bounded env38727 := by
  intro p hp
  have h : env38727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38726_38727 : H12AffineEnvironment.transform 14 8541 env38726 = env38727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env38726 == env38727) = true)

theorem identity38727 : scanCanonicalize (H12AffineFastState.compose env38727 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound38727 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env38728 : List Nat := [2,4,8,16,32,64,128,20,512,85,2048,0,8192,80,8265,8251,1,262144,85,8264,0,200,17,262289,8329,65,42,81,81,2096,262327,262323,21,64,0,512]

theorem envBound38728 : H12AffineFastState.Bounded env38728 := by
  intro p hp
  have h : env38728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38727_38728 : H12AffineEnvironment.transform 7 20 env38727 = env38728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env38727 == env38728) = true)

theorem identity38728 : scanCanonicalize (H12AffineFastState.compose env38728 (packedSelected [3,5,10] rootPS)) = affineNative (2^(17+1) ^^^ 8754) := by decide +kernel

theorem selectedBound38728 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env38729 : List Nat := [2,4,8,16,32,64,128,20,512,85,2048,0,8192,80,8265,8251,1,8754,85,8264,0,200,17,8867,8329,65,42,81,81,2096,8837,8833,21,64,0,512]

theorem envBound38729 : H12AffineFastState.Bounded env38729 := by
  intro p hp
  have h : env38729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38728_38729 : H12AffineEnvironment.transform 17 8754 env38728 = env38729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8754 env38728 == env38729) = true)

theorem identity38729 : scanCanonicalize (H12AffineFastState.compose env38729 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound38729 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env38730 : List Nat := [2,4,8,16,32,16,128,20,512,5,2048,0,8192,0,8217,8251,1,8754,5,8216,0,152,17,8867,8329,17,42,1,1,2096,8837,8833,21,16,0,512]

theorem envBound38730 : H12AffineFastState.Bounded env38730 := by
  intro p hp
  have h : env38730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38729_38730 : H12AffineEnvironment.transform 5 16 env38729 = env38730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38729 == env38730) = true)

theorem identity38730 : scanCanonicalize (H12AffineFastState.compose env38730 (packedSelected [1,3,13] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound38730 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env38731 : List Nat := [2,4,8,16,32,16,128,20,512,5,42,0,8192,0,8217,8251,1,8754,5,8216,0,152,17,8867,8329,17,42,1,1,26,8837,8833,21,16,0,512]

theorem envBound38731 : H12AffineFastState.Bounded env38731 := by
  intro p hp
  have h : env38731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38730_38731 : H12AffineEnvironment.transform 10 42 env38730 = env38731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env38730 == env38731) = true)

theorem identity38731 : scanCanonicalize (H12AffineFastState.compose env38731 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound38731 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env38732 : List Nat := [2,4,8,16,32,16,56,20,512,5,42,0,8192,0,8217,8251,1,8754,5,8216,0,32,17,8731,8241,17,42,1,1,26,8765,8761,21,16,0,512]

theorem envBound38732 : H12AffineFastState.Bounded env38732 := by
  intro p hp
  have h : env38732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38731_38732 : H12AffineEnvironment.transform 6 56 env38731 = env38732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env38731 == env38732) = true)

theorem identity38732 : scanCanonicalize (H12AffineFastState.compose env38732 (packedSelected [1,2,5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound38732 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env38733 : List Nat := [2,4,8,11,32,11,35,15,512,5,42,0,8192,0,8194,8224,1,8745,5,8195,0,32,10,8704,8234,10,42,1,1,1,8742,8738,14,11,0,512]

theorem envBound38733 : H12AffineFastState.Bounded env38733 := by
  intro p hp
  have h : env38733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38732_38733 : H12AffineEnvironment.transform 3 11 env38732 = env38733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env38732 == env38733) = true)

theorem identity38733 : scanCanonicalize (H12AffineFastState.compose env38733 (packedSelected [0,2,4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound38733 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env38734 : List Nat := [2,4,8,11,32,11,35,15,1,5,42,0,8192,0,8194,8224,1,8232,5,8195,0,32,10,8193,8234,10,42,1,1,1,8231,8227,14,11,0,1]

theorem envBound38734 : H12AffineFastState.Bounded env38734 := by
  intro p hp
  have h : env38734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38733_38734 : H12AffineEnvironment.transform 8 1 env38733 = env38734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env38733 == env38734) = true)

theorem identity38734 : scanCanonicalize (H12AffineFastState.compose env38734 (packedSelected [0,1,2] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound38734 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env38735 : List Nat := [2,4,8,11,32,11,35,15,1,5,42,0,40,0,42,8,1,0,5,43,0,32,10,41,2,10,42,1,1,1,15,11,14,11,0,1]

theorem envBound38735 : H12AffineFastState.Bounded env38735 := by
  intro p hp
  have h : env38735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38734_38735 : H12AffineEnvironment.transform 12 40 env38734 = env38735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env38734 == env38735) = true)

theorem identity38735 : scanCanonicalize (H12AffineFastState.compose env38735 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound38735 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38736 : List Nat := [2,2,8,11,32,11,35,9,1,3,42,0,40,0,42,8,1,0,3,43,0,32,10,41,2,10,42,1,1,1,9,11,8,11,0,1]

theorem envBound38736 : H12AffineFastState.Bounded env38736 := by
  intro p hp
  have h : env38736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38735_38736 : H12AffineEnvironment.transform 1 2 env38735 = env38736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env38735 == env38736) = true)

def env38737 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95615,32769,4096,61649,147520,284033,86518,209263,225345,148801,74815,96347,381312,381316,257,1281,1345,95103]

theorem envBound38737 : H12AffineFastState.Bounded env38737 := by
  intro p hp
  have h : env38737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38618_38737 : H12AffineEnvironment.transform 23 284033 env38618 = env38737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 284033 env38618 == env38737) = true)

def env38738 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16464,262144,95615,32769,4096,61649,16,284033,86518,94527,77841,1297,74815,96347,381312,381316,257,1281,1345,95103]

theorem envBound38738 : H12AffineFastState.Bounded env38738 := by
  intro p hp
  have h : env38738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38737_38738 : H12AffineEnvironment.transform 16 16464 env38737 = env38738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16464 env38737 == env38738) = true)

def env38739 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1344,262144,77935,32769,4096,46529,16,266385,70886,78895,77841,1297,74815,81227,365712,365716,257,1281,1345,79471]

theorem envBound38739 : H12AffineFastState.Bounded env38739 := by
  intro p hp
  have h : env38739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38738_38739 : H12AffineEnvironment.transform 13 1296 env38738 = env38739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env38738 == env38739) = true)

theorem identity38739 : scanCanonicalize (H12AffineFastState.compose env38739 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32883) := by decide +kernel

theorem selectedBound38739 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env38740 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,32883,1344,262144,45084,32769,4096,46529,16,266385,38037,46172,45154,1297,42060,48440,267491,267495,257,1281,1345,46620]

theorem envBound38740 : H12AffineFastState.Bounded env38740 := by
  intro p hp
  have h : env38740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38739_38740 : H12AffineEnvironment.transform 15 32883 env38739 = env38740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32883 env38739 == env38740) = true)

def env38741 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32883,1344,262144,42332,32769,1344,41089,16,263633,33237,41244,42274,1297,42060,43128,262563,262567,257,1281,1345,41820]

theorem envBound38741 : H12AffineFastState.Bounded env38741 := by
  intro p hp
  have h : env38741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38740_38741 : H12AffineEnvironment.transform 11 1344 env38740 = env38741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env38740 == env38741) = true)

theorem identity38741 : scanCanonicalize (H12AffineFastState.compose env38741 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 41147) := by decide +kernel

theorem selectedBound38741 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env38742 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32883,1344,41147,42332,32769,1344,41089,16,42346,33237,41244,42274,1297,42060,43128,41240,41244,257,1281,1345,41820]

theorem envBound38742 : H12AffineFastState.Bounded env38742 := by
  intro p hp
  have h : env38742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38741_38742 : H12AffineEnvironment.transform 17 41147 env38741 = env38742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 41147 env38741 == env38742) = true)

theorem identity38742 : scanCanonicalize (H12AffineFastState.compose env38742 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound38742 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env38743 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,8540,8495,1344,487,1024,8541,1344,477,16,1078,8329,64,1150,1297,1296,2340,68,64,257,1281,1345,512]

theorem envBound38743 : H12AffineFastState.Bounded env38743 := by
  intro p hp
  have h : env38743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38742_38743 : H12AffineEnvironment.transform 14 8540 env38742 = env38743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env38742 == env38743) = true)

theorem identity38743 : scanCanonicalize (H12AffineFastState.compose env38743 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 85) := by decide +kernel

theorem selectedBound38743 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env38744 : List Nat := [2,4,8,16,32,64,128,256,512,85,2048,277,8192,325,8540,8495,277,487,85,8541,277,477,16,99,8329,64,43,324,325,2340,68,64,257,340,276,512]

theorem envBound38744 : H12AffineFastState.Bounded env38744 := by
  intro p hp
  have h : env38744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38743_38744 : H12AffineEnvironment.transform 9 85 env38743 = env38744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env38743 == env38744) = true)

theorem identity38744 : scanCanonicalize (H12AffineFastState.compose env38744 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 704) := by decide +kernel

theorem selectedBound38744 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env38745 : List Nat := [2,4,8,16,32,64,128,256,512,85,2048,277,704,325,924,1007,277,487,85,925,277,477,16,99,585,64,43,324,325,2340,68,64,257,340,276,512]

theorem envBound38745 : H12AffineFastState.Bounded env38745 := by
  intro p hp
  have h : env38745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38744_38745 : H12AffineEnvironment.transform 12 704 env38744 = env38745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 704 env38744 == env38745) = true)

theorem identity38745 : scanCanonicalize (H12AffineFastState.compose env38745 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound38745 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env38746 : List Nat := [2,4,8,16,32,16,128,256,512,5,2048,277,656,277,924,959,277,439,5,925,277,397,16,51,537,16,43,276,277,2340,20,16,257,260,276,512]

theorem envBound38746 : H12AffineFastState.Bounded env38746 := by
  intro p hp
  have h : env38746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38745_38746 : H12AffineEnvironment.transform 5 16 env38745 = env38746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38745 == env38746) = true)

theorem identity38746 : scanCanonicalize (H12AffineFastState.compose env38746 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 270) := by decide +kernel

theorem selectedBound38746 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env38747 : List Nat := [2,4,8,16,32,16,128,256,512,5,270,277,656,277,924,959,277,439,5,925,277,397,16,51,537,16,43,276,277,42,20,16,257,260,276,512]

theorem envBound38747 : H12AffineFastState.Bounded env38747 := by
  intro p hp
  have h : env38747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38746_38747 : H12AffineEnvironment.transform 10 270 env38746 = env38747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 270 env38746 == env38747) = true)

def env38748 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32883,1344,262144,42333,32769,1345,41088,16,263632,33236,41245,42275,1297,42060,43129,262562,262566,257,1281,1345,41821]

theorem envBound38748 : H12AffineFastState.Bounded env38748 := by
  intro p hp
  have h : env38748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38740_38748 : H12AffineEnvironment.transform 11 1345 env38740 = env38748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env38740 == env38748) = true)

theorem identity38748 : scanCanonicalize (H12AffineFastState.compose env38748 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 73) := by decide +kernel

theorem selectedBound38748 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env38749 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,73,1296,32768,32883,1344,262144,34068,32769,1345,32969,16,263632,33236,33108,34154,1297,33797,34864,262562,262566,257,1281,1345,33556]

theorem envBound38749 : H12AffineFastState.Bounded env38749 := by
  intro p hp
  have h : env38749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38748_38749 : H12AffineEnvironment.transform 12 73 env38748 = env38749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env38748 == env38749) = true)

theorem identity38749 : scanCanonicalize (H12AffineFastState.compose env38749 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(17+1) ^^^ 2989) := by decide +kernel

theorem selectedBound38749 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env38750 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,73,1296,32768,32883,1344,2989,34068,32769,1345,32969,16,3709,33236,33108,34154,1297,33797,34864,2575,2571,257,1281,1345,33556]

theorem envBound38750 : H12AffineFastState.Bounded env38750 := by
  intro p hp
  have h : env38750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38749_38750 : H12AffineEnvironment.transform 17 2989 env38749 = env38750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2989 env38749 == env38750) = true)

def env38751 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1345,262144,77934,32769,4096,46528,16,266384,70887,78894,77841,1297,74815,81226,365713,365717,257,1281,1345,79470]

theorem envBound38751 : H12AffineFastState.Bounded env38751 := by
  intro p hp
  have h : env38751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38738_38751 : H12AffineEnvironment.transform 13 1297 env38738 = env38751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env38738 == env38751) = true)

theorem identity38751 : scanCanonicalize (H12AffineFastState.compose env38751 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound38751 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env38752 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1345,262144,77934,13340,4096,477,16,266384,70887,78894,77841,1297,74815,81226,336012,336008,257,1281,1345,79470]

theorem envBound38752 : H12AffineFastState.Bounded env38752 := by
  intro p hp
  have h : env38752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38751_38752 : H12AffineEnvironment.transform 14 13341 env38751 = env38752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env38751 == env38752) = true)

def env38753 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1345,65664,77934,13340,4096,477,16,69648,70887,78894,77841,1297,74815,81226,8204,8200,257,1281,1345,79470]

theorem envBound38753 : H12AffineFastState.Bounded env38753 := by
  intro p hp
  have h : env38753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38752_38753 : H12AffineEnvironment.transform 17 65664 env38752 = env38753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env38752 == env38753) = true)

theorem identity38753 : scanCanonicalize (H12AffineFastState.compose env38753 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12590) := by decide +kernel

theorem selectedBound38753 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env38754 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,12590,1345,12718,320,13340,4096,477,16,8510,9673,1280,319,1297,5393,3172,8204,8200,257,1281,1345,1856]

theorem envBound38754 : H12AffineFastState.Bounded env38754 := by
  intro p hp
  have h : env38754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38753_38754 : H12AffineEnvironment.transform 15 12590 env38753 = env38754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12590 env38753 == env38754) = true)

def env38755 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,81,12637,12590,1,12718,320,12636,4096,477,16,8510,8329,64,319,81,4177,2340,8204,8200,257,65,1,512]

theorem envBound38755 : H12AffineFastState.Bounded env38755 := by
  intro p hp
  have h : env38755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38754_38755 : H12AffineEnvironment.transform 9 320 env38754 = env38755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env38754 == env38755) = true)

theorem identity38755 : scanCanonicalize (H12AffineFastState.compose env38755 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound38755 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env38756 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,277,8192,81,8264,8251,1,8379,320,8265,277,477,16,8510,8329,64,319,81,324,2340,8204,8200,257,65,1,512]

theorem envBound38756 : H12AffineFastState.Bounded env38756 := by
  intro p hp
  have h : env38756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38755_38756 : H12AffineEnvironment.transform 11 277 env38755 = env38756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env38755 == env38756) = true)

theorem identity38756 : scanCanonicalize (H12AffineFastState.compose env38756 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound38756 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env38757 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,277,8192,1,8216,8251,1,8379,272,8217,277,397,16,8510,8329,16,319,1,276,2340,8204,8200,257,17,1,512]

theorem envBound38757 : H12AffineFastState.Bounded env38757 := by
  intro p hp
  have h : env38757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38756_38757 : H12AffineEnvironment.transform 5 16 env38756 = env38757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38756 == env38757) = true)

theorem identity38757 : scanCanonicalize (H12AffineFastState.compose env38757 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 2365) := by decide +kernel

theorem selectedBound38757 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env38758 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,277,2365,1,2341,2310,1,2438,272,2340,277,397,16,2051,2484,16,319,1,276,2340,2353,2357,257,17,1,512]

theorem envBound38758 : H12AffineFastState.Bounded env38758 := by
  intro p hp
  have h : env38758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38757_38758 : H12AffineEnvironment.transform 12 2365 env38757 = env38758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2365 env38757 == env38758) = true)

theorem identity38758 : scanCanonicalize (H12AffineFastState.compose env38758 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(8+1) ^^^ 270) := by decide +kernel

theorem selectedBound38758 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env38759 : List Nat := [2,4,8,16,32,16,128,256,270,272,2048,277,2365,1,2341,2310,1,2438,272,2340,277,397,16,2051,2484,16,319,1,276,2340,2353,2357,257,17,1,270]

theorem envBound38759 : H12AffineFastState.Bounded env38759 := by
  intro p hp
  have h : env38759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38758_38759 : H12AffineEnvironment.transform 8 270 env38758 = env38759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 270 env38758 == env38759) = true)

theorem identity38759 : scanCanonicalize (H12AffineFastState.compose env38759 (packedSelected [1,2,3,12,13] rootPS)) = affineNative (2^(10+1) ^^^ 391) := by decide +kernel

theorem selectedBound38759 : packedSelected [1,2,3,12,13] rootPS < 2^1333 := by decide +kernel

def env38760 : List Nat := [2,4,8,16,32,16,128,256,270,272,391,277,186,1,162,129,1,1,272,163,277,397,16,388,51,16,319,1,276,163,182,178,257,17,1,270]

theorem envBound38760 : H12AffineFastState.Bounded env38760 := by
  intro p hp
  have h : env38760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38759_38760 : H12AffineEnvironment.transform 10 391 env38759 = env38760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 391 env38759 == env38760) = true)

theorem identity38760 : scanCanonicalize (H12AffineFastState.compose env38760 (packedSelected [0,1,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound38760 : packedSelected [0,1,7,8] rootPS < 2^1333 := by decide +kernel

def env38761 : List Nat := [2,4,8,16,10,16,128,256,270,272,391,277,144,1,136,129,1,1,272,137,277,397,16,388,25,16,277,1,276,137,156,152,257,17,1,270]

theorem envBound38761 : H12AffineFastState.Bounded env38761 := by
  intro p hp
  have h : env38761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38760_38761 : H12AffineEnvironment.transform 4 10 env38760 = env38761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env38760 == env38761) = true)

theorem identity38761 : scanCanonicalize (H12AffineFastState.compose env38761 (packedSelected [0,3] rootPS)) = affineNative (2^(7+1) ^^^ 135) := by decide +kernel

theorem selectedBound38761 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env38762 : List Nat := [2,4,8,16,10,16,128,135,137,151,0,146,144,1,136,129,1,1,151,137,146,10,16,3,25,16,146,1,147,137,156,152,134,17,1,137]

theorem envBound38762 : H12AffineFastState.Bounded env38762 := by
  intro p hp
  have h : env38762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38761_38762 : H12AffineEnvironment.transform 7 135 env38761 = env38762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 135 env38761 == env38762) = true)

theorem identity38762 : scanCanonicalize (H12AffineFastState.compose env38762 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound38762 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env38763 : List Nat := [2,4,8,16,10,16,8,15,1,31,0,26,24,1,0,9,1,1,31,1,26,10,16,3,25,16,26,1,27,1,20,16,14,17,1,1]

theorem envBound38763 : H12AffineFastState.Bounded env38763 := by
  intro p hp
  have h : env38763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38762_38763 : H12AffineEnvironment.transform 6 8 env38762 = env38763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env38762 == env38763) = true)

theorem identity38763 : scanCanonicalize (H12AffineFastState.compose env38763 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound38763 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38764 : List Nat := [2,4,8,12,10,12,8,15,1,3,0,6,4,1,0,9,1,1,3,1,6,10,12,3,5,12,6,1,7,1,8,12,14,13,1,1]

theorem envBound38764 : H12AffineFastState.Bounded env38764 := by
  intro p hp
  have h : env38764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38763_38764 : H12AffineEnvironment.transform 3 12 env38763 = env38764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env38763 == env38764) = true)

theorem identity38764 : scanCanonicalize (H12AffineFastState.compose env38764 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound38764 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38765 : List Nat := [2,2,8,10,10,10,8,9,1,3,0,0,2,1,0,9,1,1,3,1,0,10,10,3,3,10,0,1,1,1,8,10,8,11,1,1]

theorem envBound38765 : H12AffineFastState.Bounded env38765 := by
  intro p hp
  have h : env38765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38764_38765 : H12AffineEnvironment.transform 1 2 env38764 = env38765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env38764 == env38765) = true)

def env38766 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,80,12636,12590,0,12718,320,12637,4096,477,16,8510,8328,65,319,80,4176,2341,8204,8200,257,64,0,513]

theorem envBound38766 : H12AffineFastState.Bounded env38766 := by
  intro p hp
  have h : env38766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38754_38766 : H12AffineEnvironment.transform 9 321 env38754 = env38766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env38754 == env38766) = true)

theorem identity38766 : scanCanonicalize (H12AffineFastState.compose env38766 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 325) := by decide +kernel

theorem selectedBound38766 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env38767 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,325,8192,80,8217,8299,0,8427,320,8216,325,477,16,8510,8328,65,319,80,277,2341,8204,8200,257,64,0,513]

theorem envBound38767 : H12AffineFastState.Bounded env38767 := by
  intro p hp
  have h : env38767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38766_38767 : H12AffineEnvironment.transform 11 325 env38766 = env38767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 325 env38766 == env38767) = true)

theorem identity38767 : scanCanonicalize (H12AffineFastState.compose env38767 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound38767 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env38768 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,325,24,80,1,115,0,243,320,0,325,477,16,294,144,65,319,80,277,2341,20,16,257,64,0,513]

theorem envBound38768 : H12AffineFastState.Bounded env38768 := by
  intro p hp
  have h : env38768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38767_38768 : H12AffineEnvironment.transform 12 24 env38767 = env38768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env38767 == env38768) = true)

theorem identity38768 : scanCanonicalize (H12AffineFastState.compose env38768 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound38768 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env38769 : List Nat := [2,4,8,16,32,0,128,256,512,257,2048,261,24,16,1,51,0,179,256,0,261,413,16,294,144,1,319,16,277,2341,20,16,257,0,0,513]

theorem envBound38769 : H12AffineFastState.Bounded env38769 := by
  intro p hp
  have h : env38769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38768_38769 : H12AffineEnvironment.transform 5 0 env38768 = env38769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env38768 == env38769) = true)

theorem identity38769 : scanCanonicalize (H12AffineFastState.compose env38769 (packedSelected [2,11,12,13,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 396) := by decide +kernel

theorem selectedBound38769 : packedSelected [2,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env38770 : List Nat := [2,4,8,16,32,0,128,256,396,257,2048,261,24,16,1,51,0,179,256,0,261,413,16,294,144,1,319,16,277,2341,20,16,257,0,0,397]

theorem envBound38770 : H12AffineFastState.Bounded env38770 := by
  intro p hp
  have h : env38770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38769_38770 : H12AffineEnvironment.transform 8 396 env38769 = env38770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 396 env38769 == env38770) = true)

theorem identity38770 : scanCanonicalize (H12AffineFastState.compose env38770 (packedSelected [0,2,3,7,8,11,12,13,15,17] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound38770 : packedSelected [0,2,3,7,8,11,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env38771 : List Nat := [2,4,8,16,32,0,57,256,309,257,2048,261,24,16,1,51,0,10,256,0,261,292,16,294,41,1,319,16,277,2341,20,16,257,0,0,308]

theorem envBound38771 : H12AffineFastState.Bounded env38771 := by
  intro p hp
  have h : env38771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38770_38771 : H12AffineEnvironment.transform 6 57 env38770 = env38771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env38770 == env38771) = true)

theorem identity38771 : scanCanonicalize (H12AffineFastState.compose env38771 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 290) := by decide +kernel

theorem selectedBound38771 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env38772 : List Nat := [2,4,8,16,32,0,57,256,309,257,290,261,24,16,1,51,0,10,256,0,261,292,16,294,41,1,319,16,277,7,20,16,257,0,0,308]

theorem envBound38772 : H12AffineFastState.Bounded env38772 := by
  intro p hp
  have h : env38772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38771_38772 : H12AffineEnvironment.transform 10 290 env38771 = env38772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 290 env38771 == env38772) = true)

theorem identity38772 : scanCanonicalize (H12AffineFastState.compose env38772 (packedSelected [3,4,8,9,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 25) := by decide +kernel

theorem selectedBound38772 : packedSelected [3,4,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env38773 : List Nat := [2,4,8,16,32,0,57,25,44,24,59,28,24,16,1,51,0,10,25,0,28,61,16,63,41,1,38,16,12,7,20,16,24,0,0,45]

theorem envBound38773 : H12AffineFastState.Bounded env38773 := by
  intro p hp
  have h : env38773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38772_38773 : H12AffineEnvironment.transform 7 25 env38772 = env38773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 25 env38772 == env38773) = true)

theorem identity38773 : scanCanonicalize (H12AffineFastState.compose env38773 (packedSelected [4,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound38773 : packedSelected [4,7,8] rootPS < 2^1333 := by decide +kernel

def env38774 : List Nat := [2,4,8,16,6,0,31,25,10,24,29,28,24,16,1,21,0,10,25,0,28,27,16,25,15,1,0,16,12,7,20,16,24,0,0,11]

theorem envBound38774 : H12AffineFastState.Bounded env38774 := by
  intro p hp
  have h : env38774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38773_38774 : H12AffineEnvironment.transform 4 6 env38773 = env38774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env38773 == env38774) = true)

theorem identity38774 : scanCanonicalize (H12AffineFastState.compose env38774 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound38774 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env38775 : List Nat := [2,3,8,16,1,0,24,25,10,24,26,27,24,16,1,18,0,10,25,0,27,27,16,25,8,1,0,16,11,0,19,16,24,0,0,11]

theorem envBound38775 : H12AffineFastState.Bounded env38775 := by
  intro p hp
  have h : env38775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38774_38775 : H12AffineEnvironment.transform 1 3 env38774 = env38775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env38774 == env38775) = true)

def env38776 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1345,65665,77934,13340,4096,477,16,69649,70887,78894,77841,1297,74815,81226,8205,8201,257,1281,1345,79470]

theorem envBound38776 : H12AffineFastState.Bounded env38776 := by
  intro p hp
  have h : env38776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38752_38776 : H12AffineEnvironment.transform 17 65665 env38752 = env38776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env38752 == env38776) = true)

theorem identity38776 : scanCanonicalize (H12AffineFastState.compose env38776 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9326) := by decide +kernel

theorem selectedBound38776 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env38777 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,9326,1345,9455,5120,13340,4096,477,16,13439,12425,4160,5247,1297,81,6436,8205,8201,257,1281,1345,4608]

theorem envBound38777 : H12AffineFastState.Bounded env38777 := by
  intro p hp
  have h : env38777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38776_38777 : H12AffineEnvironment.transform 15 9326 env38776 = env38777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9326 env38776 == env38777) = true)

def env38778 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1297,9245,9326,1345,9455,1024,9244,0,477,16,9343,8329,64,1151,1297,81,2340,8205,8201,257,1281,1345,512]

theorem envBound38778 : H12AffineFastState.Bounded env38778 := by
  intro p hp
  have h : env38778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38777_38778 : H12AffineEnvironment.transform 11 0 env38777 = env38778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env38777 == env38778) = true)

theorem identity38778 : scanCanonicalize (H12AffineFastState.compose env38778 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound38778 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env38779 : List Nat := [2,4,8,16,32,64,128,21,512,1024,2048,0,8192,1028,9245,9326,1108,9455,1024,9244,0,200,16,9343,8329,64,1151,1028,81,2097,8205,8201,20,1044,1108,512]

theorem envBound38779 : H12AffineFastState.Bounded env38779 := by
  intro p hp
  have h : env38779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38778_38779 : H12AffineEnvironment.transform 7 21 env38778 = env38779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env38778 == env38779) = true)

theorem identity38779 : scanCanonicalize (H12AffineFastState.compose env38779 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound38779 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env38780 : List Nat := [2,4,8,16,32,16,128,21,512,1024,2048,0,8192,1028,9245,9278,1028,9407,1024,9244,0,152,16,9263,8329,16,1071,1028,1,2097,8205,8201,20,1044,1028,512]

theorem envBound38780 : H12AffineFastState.Bounded env38780 := by
  intro p hp
  have h : env38780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38779_38780 : H12AffineEnvironment.transform 5 16 env38779 = env38780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38779 == env38780) = true)

theorem identity38780 : scanCanonicalize (H12AffineFastState.compose env38780 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 1164) := by decide +kernel

theorem selectedBound38780 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env38781 : List Nat := [2,4,8,16,32,16,128,21,512,1024,1164,0,8192,1028,9245,9278,1028,9407,1024,9244,0,152,16,9263,8329,16,1071,1028,1,1213,8205,8201,20,1044,1028,512]

theorem envBound38781 : H12AffineFastState.Bounded env38781 := by
  intro p hp
  have h : env38781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38780_38781 : H12AffineEnvironment.transform 10 1164 env38780 = env38781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1164 env38780 == env38781) = true)

theorem identity38781 : scanCanonicalize (H12AffineFastState.compose env38781 (packedSelected [0,7,11] rootPS)) = affineNative (2^(12+1) ^^^ 145) := by decide +kernel

theorem selectedBound38781 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env38782 : List Nat := [2,4,8,16,32,16,128,21,512,1024,1164,0,145,1028,1164,1199,1028,1070,1024,1165,0,152,16,1214,24,16,1071,1028,1,1213,156,152,20,1044,1028,512]

theorem envBound38782 : H12AffineFastState.Bounded env38782 := by
  intro p hp
  have h : env38782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38781_38782 : H12AffineEnvironment.transform 12 145 env38781 = env38782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 145 env38781 == env38782) = true)

theorem identity38782 : scanCanonicalize (H12AffineFastState.compose env38782 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(9+1) ^^^ 701) := by decide +kernel

theorem selectedBound38782 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env38783 : List Nat := [2,4,8,16,32,16,128,21,512,701,561,0,145,697,561,530,697,659,701,560,0,152,16,515,24,16,658,697,1,512,156,152,20,681,697,512]

theorem envBound38783 : H12AffineFastState.Bounded env38783 := by
  intro p hp
  have h : env38783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38782_38783 : H12AffineEnvironment.transform 9 701 env38782 = env38783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 701 env38782 == env38783) = true)

theorem identity38783 : scanCanonicalize (H12AffineFastState.compose env38783 (packedSelected [0,2,5] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound38783 : packedSelected [0,2,5] rootPS < 2^1333 := by decide +kernel

def env38784 : List Nat := [2,4,8,16,32,16,57,21,512,516,561,0,40,512,561,530,512,554,516,560,0,33,16,515,24,16,555,512,1,512,37,33,20,528,512,512]

theorem envBound38784 : H12AffineFastState.Bounded env38784 := by
  intro p hp
  have h : env38784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38783_38784 : H12AffineEnvironment.transform 6 57 env38783 = env38784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env38783 == env38784) = true)

theorem identity38784 : scanCanonicalize (H12AffineFastState.compose env38784 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound38784 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env38785 : List Nat := [2,4,8,16,32,16,57,21,49,53,0,0,40,49,0,35,49,27,53,1,0,33,16,50,24,16,26,49,1,49,37,33,20,33,49,49]

theorem envBound38785 : H12AffineFastState.Bounded env38785 := by
  intro p hp
  have h : env38785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38784_38785 : H12AffineEnvironment.transform 8 49 env38784 = env38785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env38784 == env38785) = true)

theorem identity38785 : scanCanonicalize (H12AffineFastState.compose env38785 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 29) := by decide +kernel

theorem selectedBound38785 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38786 : List Nat := [2,4,8,16,29,16,4,21,12,8,0,0,21,12,0,30,12,27,8,1,0,28,16,15,24,16,26,12,1,12,24,28,20,28,12,12]

theorem envBound38786 : H12AffineFastState.Bounded env38786 := by
  intro p hp
  have h : env38786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38785_38786 : H12AffineEnvironment.transform 4 29 env38785 = env38786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 29 env38785 == env38786) = true)

theorem identity38786 : scanCanonicalize (H12AffineFastState.compose env38786 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound38786 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38787 : List Nat := [2,4,5,16,16,16,4,21,1,5,0,0,21,1,0,19,1,22,5,1,0,17,16,2,21,16,23,1,1,1,21,17,20,17,1,1]

theorem envBound38787 : H12AffineFastState.Bounded env38787 := by
  intro p hp
  have h : env38787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38786_38787 : H12AffineEnvironment.transform 2 5 env38786 = env38787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env38786 == env38787) = true)

def env38788 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1297,9244,9326,1345,9455,1025,9245,1,477,16,9342,8328,65,1150,1297,81,2341,8205,8201,257,1281,1345,513]

theorem envBound38788 : H12AffineFastState.Bounded env38788 := by
  intro p hp
  have h : env38788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38777_38788 : H12AffineEnvironment.transform 11 1 env38777 = env38788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env38777 == env38788) = true)

theorem identity38788 : scanCanonicalize (H12AffineFastState.compose env38788 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound38788 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env38789 : List Nat := [2,4,8,16,32,64,128,68,512,1024,2048,1,8192,1109,9244,9326,1029,9455,1025,9245,1,153,16,9342,8328,65,1150,1109,81,2145,8205,8201,69,1093,1029,513]

theorem envBound38789 : H12AffineFastState.Bounded env38789 := by
  intro p hp
  have h : env38789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38788_38789 : H12AffineEnvironment.transform 7 68 env38788 = env38789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env38788 == env38789) = true)

theorem identity38789 : scanCanonicalize (H12AffineFastState.compose env38789 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound38789 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env38790 : List Nat := [2,4,8,16,32,64,128,68,512,1024,2048,1,1052,1109,0,114,1029,243,1025,1,1,153,16,98,1172,65,1150,1109,81,2145,1041,1045,69,1093,1029,513]

theorem envBound38790 : H12AffineFastState.Bounded env38790 := by
  intro p hp
  have h : env38790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38789_38790 : H12AffineEnvironment.transform 12 1052 env38789 = env38790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env38789 == env38790) = true)

theorem identity38790 : scanCanonicalize (H12AffineFastState.compose env38790 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound38790 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env38791 : List Nat := [2,4,8,16,32,1,128,5,512,1024,2048,1,1052,1044,0,51,1029,178,1025,1,1,153,16,35,1172,0,1087,1044,16,2080,1041,1045,4,1028,1029,513]

theorem envBound38791 : H12AffineFastState.Bounded env38791 := by
  intro p hp
  have h : env38791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38790_38791 : H12AffineEnvironment.transform 5 1 env38790 = env38791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env38790 == env38791) = true)

theorem identity38791 : scanCanonicalize (H12AffineFastState.compose env38791 (packedSelected [1,2,3,5,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 1706) := by decide +kernel

theorem selectedBound38791 : packedSelected [1,2,3,5,13,15] rootPS < 2^1333 := by decide +kernel

def env38792 : List Nat := [2,4,8,16,32,1,128,5,512,1024,1706,1,1052,1044,0,51,1029,178,1025,1,1,153,16,35,1172,0,1087,1044,16,1674,1041,1045,4,1028,1029,513]

theorem envBound38792 : H12AffineFastState.Bounded env38792 := by
  intro p hp
  have h : env38792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38791_38792 : H12AffineEnvironment.transform 10 1706 env38791 = env38792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1706 env38791 == env38792) = true)

theorem identity38792 : scanCanonicalize (H12AffineFastState.compose env38792 (packedSelected [1,3,5,11,12,18] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound38792 : packedSelected [1,3,5,11,12,18] rootPS < 2^1333 := by decide +kernel

def env38793 : List Nat := [2,4,8,16,32,1,128,5,136,1024,1058,1,1052,1044,0,51,1029,178,1025,1,1,153,16,35,1172,0,1087,1044,16,1026,1041,1045,4,1028,1029,137]

theorem envBound38793 : H12AffineFastState.Bounded env38793 := by
  intro p hp
  have h : env38793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38792_38793 : H12AffineEnvironment.transform 8 136 env38792 = env38793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env38792 == env38793) = true)

theorem identity38793 : scanCanonicalize (H12AffineFastState.compose env38793 (packedSelected [1,2,3,12] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound38793 : packedSelected [1,2,3,12] rootPS < 2^1333 := by decide +kernel

def env38794 : List Nat := [2,4,8,16,32,1,128,5,136,5,39,1,25,17,0,51,0,178,4,1,1,153,16,35,145,0,58,17,16,7,20,16,4,1,0,137]

theorem envBound38794 : H12AffineFastState.Bounded env38794 := by
  intro p hp
  have h : env38794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38793_38794 : H12AffineEnvironment.transform 9 5 env38793 = env38794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env38793 == env38794) = true)

theorem identity38794 : scanCanonicalize (H12AffineFastState.compose env38794 (packedSelected [2,8] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound38794 : packedSelected [2,8] rootPS < 2^1333 := by decide +kernel

def env38795 : List Nat := [2,4,8,16,32,1,18,5,26,5,39,1,25,17,0,51,0,32,4,1,1,11,16,35,3,0,58,17,16,7,20,16,4,1,0,27]

theorem envBound38795 : H12AffineFastState.Bounded env38795 := by
  intro p hp
  have h : env38795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38794_38795 : H12AffineEnvironment.transform 6 18 env38794 = env38795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env38794 == env38795) = true)

theorem identity38795 : scanCanonicalize (H12AffineFastState.compose env38795 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound38795 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38796 : List Nat := [2,4,8,13,32,1,15,5,7,5,39,1,4,12,0,46,0,32,4,1,1,11,13,35,3,0,39,12,13,7,9,13,4,1,0,6]

theorem envBound38796 : H12AffineFastState.Bounded env38796 := by
  intro p hp
  have h : env38796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38795_38796 : H12AffineEnvironment.transform 3 13 env38795 = env38796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env38795 == env38796) = true)

theorem identity38796 : scanCanonicalize (H12AffineFastState.compose env38796 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound38796 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env38797 : List Nat := [2,4,8,13,3,1,15,5,7,5,4,1,4,12,0,13,0,3,4,1,1,11,13,0,3,0,4,12,13,7,9,13,4,1,0,6]

theorem envBound38797 : H12AffineFastState.Bounded env38797 := by
  intro p hp
  have h : env38797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38796_38797 : H12AffineEnvironment.transform 4 3 env38796 = env38797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env38796 == env38797) = true)

theorem identity38797 : scanCanonicalize (H12AffineFastState.compose env38797 (packedSelected [3,5] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound38797 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env38798 : List Nat := [2,3,8,10,3,1,8,2,0,2,3,1,3,11,0,10,0,3,3,1,1,11,10,0,3,0,3,11,10,0,9,10,3,1,0,1]

theorem envBound38798 : H12AffineFastState.Bounded env38798 := by
  intro p hp
  have h : env38798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38797_38798 : H12AffineEnvironment.transform 1 3 env38797 = env38798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env38797 == env38798) = true)

theorem identity38798 : scanCanonicalize (H12AffineFastState.compose env38798 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound38798 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38799 : List Nat := [1,0,8,9,0,1,8,1,0,1,0,1,0,8,0,9,0,0,0,1,1,8,9,0,0,0,0,8,9,0,9,9,0,1,0,1]

theorem envBound38799 : H12AffineFastState.Bounded env38799 := by
  intro p hp
  have h : env38799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38798_38799 : H12AffineEnvironment.transform 0 1 env38798 = env38799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env38798 == env38799) = true)

theorem identity38799 : scanCanonicalize (H12AffineFastState.compose env38799 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound38799 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38800 : List Nat := [1,0,0,1,0,1,0,1,0,1,0,1,0,0,0,1,0,0,0,1,1,0,1,0,0,0,0,0,1,0,1,1,0,1,0,1]

theorem envBound38800 : H12AffineFastState.Bounded env38800 := by
  intro p hp
  have h : env38800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38799_38800 : H12AffineEnvironment.transform 2 0 env38799 = env38800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env38799 == env38800) = true)

def env38801 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16465,262144,95615,32769,4096,61649,17,284033,86518,94526,77840,1296,74815,96347,381312,381316,257,1281,1345,95103]

theorem envBound38801 : H12AffineFastState.Bounded env38801 := by
  intro p hp
  have h : env38801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38737_38801 : H12AffineEnvironment.transform 16 16465 env38737 = env38801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16465 env38737 == env38801) = true)

def env38802 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1345,262144,77935,32769,4096,46529,17,266385,70886,78894,77840,1296,74815,81227,365712,365716,257,1281,1345,79471]

theorem envBound38802 : H12AffineFastState.Bounded env38802 := by
  intro p hp
  have h : env38802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38801_38802 : H12AffineEnvironment.transform 13 1296 env38801 = env38802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env38801 == env38802) = true)

theorem identity38802 : scanCanonicalize (H12AffineFastState.compose env38802 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound38802 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env38803 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1345,262144,77935,13340,4096,476,17,266385,70886,78894,77840,1296,74815,81227,336013,336009,257,1281,1345,79471]

theorem envBound38803 : H12AffineFastState.Bounded env38803 := by
  intro p hp
  have h : env38803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38802_38803 : H12AffineEnvironment.transform 14 13341 env38802 = env38803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env38802 == env38803) = true)

def env38804 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1345,65664,77935,13340,4096,476,17,69649,70886,78894,77840,1296,74815,81227,8205,8201,257,1281,1345,79471]

theorem envBound38804 : H12AffineFastState.Bounded env38804 := by
  intro p hp
  have h : env38804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38803_38804 : H12AffineEnvironment.transform 17 65664 env38803 = env38804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env38803 == env38804) = true)

theorem identity38804 : scanCanonicalize (H12AffineFastState.compose env38804 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 358) := by decide +kernel

theorem selectedBound38804 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env38805 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,358,1345,486,12553,13340,4096,476,17,4471,5504,13640,12662,1296,9561,15405,8205,8201,257,1281,1345,14089]

theorem envBound38805 : H12AffineFastState.Bounded env38805 := by
  intro p hp
  have h : env38805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38804_38805 : H12AffineEnvironment.transform 15 358 env38804 = env38805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 358 env38804 == env38805) = true)

def env38806 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,7632,1296,2509,358,1345,486,3289,2508,4096,476,17,4471,5504,2200,3238,1296,6281,509,7645,7641,257,1281,1345,2777]

theorem envBound38806 : H12AffineFastState.Bounded env38806 := by
  intro p hp
  have h : env38806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38805_38806 : H12AffineEnvironment.transform 12 7632 env38805 = env38806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7632 env38805 == env38806) = true)

def env38807 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1344,4096,4240,1296,1165,358,1345,486,409,1164,4096,476,17,4471,5504,1496,486,1296,5577,509,4253,4249,257,1281,1345,1945]

theorem envBound38807 : H12AffineFastState.Bounded env38807 := by
  intro p hp
  have h : env38807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38806_38807 : H12AffineEnvironment.transform 10 1344 env38806 = env38807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1344 env38806 == env38807) = true)

theorem identity38807 : scanCanonicalize (H12AffineFastState.compose env38807 (packedSelected [13] rootPS)) = affineNative (2^(7+1) ^^^ 204) := by decide +kernel

theorem selectedBound38807 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env38808 : List Nat := [2,4,8,16,32,64,128,204,512,1024,1164,4096,4240,1244,1165,170,1165,42,85,1164,4096,16,17,4283,5196,1044,42,1244,5125,49,4253,4249,205,1229,1165,1621]

theorem envBound38808 : H12AffineFastState.Bounded env38808 := by
  intro p hp
  have h : env38808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38807_38808 : H12AffineEnvironment.transform 7 204 env38807 = env38808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 204 env38807 == env38808) = true)

theorem identity38808 : scanCanonicalize (H12AffineFastState.compose env38808 (packedSelected [3,7,8,9,11,16,17,18] rootPS)) = affineNative (2^(11+1) ^^^ 1687) := by decide +kernel

theorem selectedBound38808 : packedSelected [3,7,8,9,11,16,17,18] rootPS < 2^1333 := by decide +kernel

def env38809 : List Nat := [2,4,8,16,32,64,128,204,512,1024,1164,1687,1543,1244,1165,170,1165,42,85,1164,1687,16,17,1580,731,1044,42,1244,658,49,1546,1550,205,1229,1165,1621]

theorem envBound38809 : H12AffineFastState.Bounded env38809 := by
  intro p hp
  have h : env38809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38808_38809 : H12AffineEnvironment.transform 11 1687 env38808 = env38809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1687 env38808 == env38809) = true)

theorem identity38809 : scanCanonicalize (H12AffineFastState.compose env38809 (packedSelected [10,11,12,15] rootPS)) = affineNative (2^(8+1) ^^^ 185) := by decide +kernel

theorem selectedBound38809 : packedSelected [10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env38810 : List Nat := [2,4,8,16,32,64,128,204,185,1024,1164,1070,1214,1244,1165,170,1165,42,85,1164,1070,16,17,1173,98,1044,42,1244,43,49,1203,1207,205,1229,1165,1260]

theorem envBound38810 : H12AffineFastState.Bounded env38810 := by
  intro p hp
  have h : env38810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38809_38810 : H12AffineEnvironment.transform 8 185 env38809 = env38810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 185 env38809 == env38810) = true)

theorem identity38810 : scanCanonicalize (H12AffineFastState.compose env38810 (packedSelected [3,4,7,8,16] rootPS)) = affineNative (2^(6+1) ^^^ 105) := by decide +kernel

theorem selectedBound38810 : packedSelected [3,4,7,8,16] rootPS < 2^1333 := by decide +kernel

def env38811 : List Nat := [2,4,8,16,32,64,105,37,80,1024,1125,1070,1111,1077,1124,67,1124,42,85,1125,1070,16,17,1148,98,1044,42,1077,43,49,1114,1118,36,1060,1124,1029]

theorem envBound38811 : H12AffineFastState.Bounded env38811 := by
  intro p hp
  have h : env38811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38810_38811 : H12AffineEnvironment.transform 6 105 env38810 = env38811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 105 env38810 == env38811) = true)

theorem identity38811 : scanCanonicalize (H12AffineFastState.compose env38811 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound38811 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env38812 : List Nat := [2,4,8,16,32,33,8,37,49,1024,1028,1070,1078,1077,1029,34,1029,42,52,1028,1070,16,17,1053,3,1044,42,1077,43,49,1083,1087,36,1060,1029,1029]

theorem envBound38812 : H12AffineFastState.Bounded env38812 := by
  intro p hp
  have h : env38812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38811_38812 : H12AffineEnvironment.transform 5 33 env38811 = env38812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env38811 == env38812) = true)

theorem identity38812 : scanCanonicalize (H12AffineFastState.compose env38812 (packedSelected [1,2,4,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound38812 : packedSelected [1,2,4,5,7] rootPS < 2^1333 := by decide +kernel

def env38813 : List Nat := [2,4,8,16,10,11,8,15,27,1024,1028,1028,1052,1055,1029,8,1029,0,30,1028,1028,16,17,1053,3,1044,0,1055,1,27,1041,1045,14,1038,1029,1029]

theorem envBound38813 : H12AffineFastState.Bounded env38813 := by
  intro p hp
  have h : env38813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38812_38813 : H12AffineEnvironment.transform 4 10 env38812 = env38813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env38812 == env38813) = true)

theorem identity38813 : scanCanonicalize (H12AffineFastState.compose env38813 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 30) := by decide +kernel

theorem selectedBound38813 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env38814 : List Nat := [2,4,8,16,10,11,8,15,27,30,26,26,2,1,27,8,27,0,30,26,26,16,17,3,3,10,0,1,1,27,15,11,14,16,27,27]

theorem envBound38814 : H12AffineFastState.Bounded env38814 := by
  intro p hp
  have h : env38814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38813_38814 : H12AffineEnvironment.transform 9 30 env38813 = env38814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 30 env38813 == env38814) = true)

theorem identity38814 : scanCanonicalize (H12AffineFastState.compose env38814 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound38814 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env38815 : List Nat := [2,4,8,10,10,11,8,15,1,4,0,0,2,1,1,8,1,0,4,0,0,10,11,3,3,10,0,1,1,1,15,11,14,10,1,1]

theorem envBound38815 : H12AffineFastState.Bounded env38815 := by
  intro p hp
  have h : env38815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38814_38815 : H12AffineEnvironment.transform 3 10 env38814 = env38815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env38814 == env38815) = true)

theorem identity38815 : scanCanonicalize (H12AffineFastState.compose env38815 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound38815 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38816 : List Nat := [2,3,8,10,10,11,8,8,1,3,0,0,2,1,1,8,1,0,3,0,0,10,11,3,3,10,0,1,1,1,8,11,9,10,1,1]

theorem envBound38816 : H12AffineFastState.Bounded env38816 := by
  intro p hp
  have h : env38816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38815_38816 : H12AffineEnvironment.transform 1 3 env38815 = env38816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env38815 == env38816) = true)

def env38817 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1345,4096,4241,1296,1164,358,1345,486,408,1165,4096,476,17,4471,5504,1497,487,1296,5576,509,4252,4248,257,1281,1345,1944]

theorem envBound38817 : H12AffineFastState.Bounded env38817 := by
  intro p hp
  have h : env38817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38806_38817 : H12AffineEnvironment.transform 10 1345 env38806 = env38817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1345 env38806 == env38817) = true)

theorem identity38817 : scanCanonicalize (H12AffineFastState.compose env38817 (packedSelected [13] rootPS)) = affineNative (2^(9+1) ^^^ 221) := by decide +kernel

theorem selectedBound38817 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env38818 : List Nat := [2,4,8,16,32,64,128,256,512,221,412,4096,4241,461,81,358,412,486,408,80,4096,476,17,4471,4445,260,487,461,4373,509,4252,4248,257,476,412,837]

theorem envBound38818 : H12AffineFastState.Bounded env38818 := by
  intro p hp
  have h : env38818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38817_38818 : H12AffineEnvironment.transform 9 221 env38817 = env38818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 221 env38817 == env38818) = true)

theorem identity38818 : scanCanonicalize (H12AffineFastState.compose env38818 (packedSelected [1,3,5,8,12,18,20] rootPS)) = affineNative (2^(11+1) ^^^ 486) := by decide +kernel

theorem selectedBound38818 : packedSelected [1,3,5,8,12,18,20] rootPS < 2^1333 := by decide +kernel

def env38819 : List Nat := [2,4,8,16,32,64,128,256,512,221,412,486,375,461,81,358,412,486,408,80,486,476,17,145,187,260,487,461,243,509,378,382,257,476,412,837]

theorem envBound38819 : H12AffineFastState.Bounded env38819 := by
  intro p hp
  have h : env38819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38818_38819 : H12AffineEnvironment.transform 11 486 env38818 = env38819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 486 env38818 == env38819) = true)

theorem identity38819 : scanCanonicalize (H12AffineFastState.compose env38819 (packedSelected [1,3,7,9,10,12,16,17] rootPS)) = affineNative (2^(8+1) ^^^ 487) := by decide +kernel

theorem selectedBound38819 : packedSelected [1,3,7,9,10,12,16,17] rootPS < 2^1333 := by decide +kernel

def env38820 : List Nat := [2,4,8,16,32,64,128,256,487,221,412,486,375,461,81,358,412,486,408,80,486,476,17,145,187,260,487,461,243,509,378,382,257,476,412,162]

theorem envBound38820 : H12AffineFastState.Bounded env38820 := by
  intro p hp
  have h : env38820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38819_38820 : H12AffineEnvironment.transform 8 487 env38819 = env38820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 487 env38819 == env38820) = true)

theorem identity38820 : scanCanonicalize (H12AffineFastState.compose env38820 (packedSelected [0,3,7,8,12,16] rootPS)) = affineNative (2^(7+1) ^^^ 182) := by decide +kernel

theorem selectedBound38820 : packedSelected [0,3,7,8,12,16] rootPS < 2^1333 := by decide +kernel

def env38821 : List Nat := [2,4,8,16,32,64,128,182,81,221,42,80,193,123,81,208,42,80,46,80,80,106,17,145,187,178,81,123,243,75,204,200,183,106,42,162]

theorem envBound38821 : H12AffineFastState.Bounded env38821 := by
  intro p hp
  have h : env38821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38820_38821 : H12AffineEnvironment.transform 7 182 env38820 = env38821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 182 env38820 == env38821) = true)

theorem identity38821 : scanCanonicalize (H12AffineFastState.compose env38821 (packedSelected [0,1,2,3,7,10] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound38821 : packedSelected [0,1,2,3,7,10] rootPS < 2^1333 := by decide +kernel

def env38822 : List Nat := [2,4,8,16,16,64,128,134,81,221,26,80,193,75,81,208,26,80,30,80,80,90,17,145,139,130,81,75,195,75,204,200,135,90,26,146]

theorem envBound38822 : H12AffineFastState.Bounded env38822 := by
  intro p hp
  have h : env38822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38821_38822 : H12AffineEnvironment.transform 4 16 env38821 = env38822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env38821 == env38822) = true)

theorem identity38822 : scanCanonicalize (H12AffineFastState.compose env38822 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound38822 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38823 : List Nat := [2,4,8,16,16,64,9,15,81,84,26,80,72,75,81,89,26,80,30,80,80,90,17,24,2,11,81,75,74,75,69,65,14,90,26,27]

theorem envBound38823 : H12AffineFastState.Bounded env38823 := by
  intro p hp
  have h : env38823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38822_38823 : H12AffineEnvironment.transform 6 9 env38822 = env38823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env38822 == env38823) = true)

theorem identity38823 : scanCanonicalize (H12AffineFastState.compose env38823 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound38823 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env38824 : List Nat := [2,4,8,16,16,17,9,15,0,5,26,1,25,26,0,8,26,1,30,1,1,11,17,24,2,11,0,26,27,26,20,16,14,11,26,27]

theorem envBound38824 : H12AffineFastState.Bounded env38824 := by
  intro p hp
  have h : env38824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38823_38824 : H12AffineEnvironment.transform 5 17 env38823 = env38824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env38823 == env38824) = true)

theorem identity38824 : scanCanonicalize (H12AffineFastState.compose env38824 (packedSelected [0,1,4] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound38824 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env38825 : List Nat := [2,4,8,7,7,6,9,15,0,5,13,1,14,13,0,8,13,1,9,1,1,11,6,15,2,11,0,13,12,13,3,7,14,11,13,12]

theorem envBound38825 : H12AffineFastState.Bounded env38825 := by
  intro p hp
  have h : env38825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38824_38825 : H12AffineEnvironment.transform 3 7 env38824 = env38825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env38824 == env38825) = true)

theorem identity38825 : scanCanonicalize (H12AffineFastState.compose env38825 (packedSelected [1,5] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound38825 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env38826 : List Nat := [2,4,5,7,7,6,4,2,0,5,0,1,3,0,0,5,0,1,4,1,1,6,6,2,2,6,0,0,1,0,3,7,3,6,0,1]

theorem envBound38826 : H12AffineFastState.Bounded env38826 := by
  intro p hp
  have h : env38826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38825_38826 : H12AffineEnvironment.transform 2 5 env38825 = env38826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env38825 == env38826) = true)

theorem identity38826 : scanCanonicalize (H12AffineFastState.compose env38826 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound38826 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38827 : List Nat := [1,4,5,4,4,5,4,1,0,5,0,1,0,0,0,5,0,1,4,1,1,5,5,1,1,5,0,0,1,0,0,4,0,5,0,1]

theorem envBound38827 : H12AffineFastState.Bounded env38827 := by
  intro p hp
  have h : env38827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38826_38827 : H12AffineEnvironment.transform 0 1 env38826 = env38827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env38826 == env38827) = true)

theorem identity38827 : scanCanonicalize (H12AffineFastState.compose env38827 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound38827 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38828 : List Nat := [1,0,1,0,0,1,0,1,0,1,0,1,0,0,0,1,0,1,0,1,1,1,1,1,1,1,0,0,1,0,0,0,0,1,0,1]

theorem envBound38828 : H12AffineFastState.Bounded env38828 := by
  intro p hp
  have h : env38828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38827_38828 : H12AffineEnvironment.transform 1 0 env38827 = env38828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env38827 == env38828) = true)

def env38829 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,7633,1296,2508,358,1345,486,3288,2509,4096,476,17,4471,5504,2201,3239,1296,6280,508,7644,7640,257,1281,1345,2776]

theorem envBound38829 : H12AffineFastState.Bounded env38829 := by
  intro p hp
  have h : env38829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38805_38829 : H12AffineEnvironment.transform 12 7633 env38805 = env38829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7633 env38805 == env38829) = true)

def env38830 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1344,4096,4241,1296,1164,358,1345,486,408,1165,4096,476,17,4471,5504,1497,487,1296,5576,508,4252,4248,257,1281,1345,1944]

theorem envBound38830 : H12AffineFastState.Bounded env38830 := by
  intro p hp
  have h : env38830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38829_38830 : H12AffineEnvironment.transform 10 1344 env38829 = env38830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1344 env38829 == env38830) = true)

theorem identity38830 : scanCanonicalize (H12AffineFastState.compose env38830 (packedSelected [13] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound38830 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env38831 : List Nat := [2,4,8,16,32,64,128,69,512,1024,1029,4096,4241,1109,1164,35,1028,163,221,1165,4096,153,17,4146,5317,1180,162,1109,5261,185,4252,4248,68,1092,1028,1757]

theorem envBound38831 : H12AffineFastState.Bounded env38831 := by
  intro p hp
  have h : env38831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38830_38831 : H12AffineEnvironment.transform 7 69 env38830 = env38831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env38830 == env38831) = true)

theorem identity38831 : scanCanonicalize (H12AffineFastState.compose env38831 (packedSelected [0,1,3,4,11,17,18,19,20,21] rootPS)) = affineNative (2^(11+1) ^^^ 649) := by decide +kernel

theorem selectedBound38831 : packedSelected [0,1,3,4,11,17,18,19,20,21] rootPS < 2^1333 := by decide +kernel

def env38832 : List Nat := [2,4,8,16,32,64,128,69,512,1024,1029,649,536,1109,1164,35,1028,163,221,1165,649,153,17,699,1612,1180,162,1109,1540,185,533,529,68,1092,1028,1757]

theorem envBound38832 : H12AffineFastState.Bounded env38832 := by
  intro p hp
  have h : env38832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38831_38832 : H12AffineEnvironment.transform 11 649 env38831 = env38832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 649 env38831 == env38832) = true)

theorem identity38832 : scanCanonicalize (H12AffineFastState.compose env38832 (packedSelected [4,5,8,9,16,17,20] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound38832 : packedSelected [4,5,8,9,16,17,20] rootPS < 2^1333 := by decide +kernel

def env38833 : List Nat := [2,4,8,16,32,64,57,69,512,1024,1029,560,536,1109,1077,35,1028,26,100,1076,560,32,17,514,1612,1061,27,1109,1540,0,533,529,68,1092,1028,1636]

theorem envBound38833 : H12AffineFastState.Bounded env38833 := by
  intro p hp
  have h : env38833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38832_38833 : H12AffineEnvironment.transform 6 57 env38832 = env38833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env38832 == env38833) = true)

theorem identity38833 : scanCanonicalize (H12AffineFastState.compose env38833 (packedSelected [0,1,4,8,10,12,15] rootPS)) = affineNative (2^(8+1) ^^^ 80) := by decide +kernel

theorem selectedBound38833 : packedSelected [0,1,4,8,10,12,15] rootPS < 2^1333 := by decide +kernel

def env38834 : List Nat := [2,4,8,16,32,64,57,69,80,1024,1029,96,72,1109,1077,35,1028,26,100,1076,96,32,17,82,1052,1061,27,1109,1108,0,69,65,68,1092,1028,1076]

theorem envBound38834 : H12AffineFastState.Bounded env38834 := by
  intro p hp
  have h : env38834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38833_38834 : H12AffineEnvironment.transform 8 80 env38833 = env38834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 80 env38833 == env38834) = true)

theorem identity38834 : scanCanonicalize (H12AffineFastState.compose env38834 (packedSelected [0,4,5,7,8,9,10] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound38834 : packedSelected [0,4,5,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env38835 : List Nat := [2,4,8,16,16,64,9,69,80,1024,1029,80,72,1109,1029,19,1028,26,84,1028,80,16,17,82,1052,1045,27,1109,1108,0,69,65,68,1092,1028,1028]

theorem envBound38835 : H12AffineFastState.Bounded env38835 := by
  intro p hp
  have h : env38835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38834_38835 : H12AffineEnvironment.transform 4 16 env38834 = env38835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env38834 == env38835) = true)

theorem identity38835 : scanCanonicalize (H12AffineFastState.compose env38835 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(9+1) ^^^ 85) := by decide +kernel

theorem selectedBound38835 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env38836 : List Nat := [2,4,8,16,16,64,9,69,80,85,80,80,72,0,80,19,81,26,84,81,80,16,17,82,73,64,27,0,1,0,69,65,68,17,81,81]

theorem envBound38836 : H12AffineFastState.Bounded env38836 := by
  intro p hp
  have h : env38836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38835_38836 : H12AffineEnvironment.transform 9 85 env38835 = env38836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env38835 == env38836) = true)

theorem identity38836 : scanCanonicalize (H12AffineFastState.compose env38836 (packedSelected [0,1] rootPS)) = affineNative (2^(5+1) ^^^ 25) := by decide +kernel

theorem selectedBound38836 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env38837 : List Nat := [2,4,8,16,16,25,9,28,9,12,9,9,17,0,9,19,8,26,13,8,9,16,17,11,16,25,27,0,1,0,28,24,29,17,8,8]

theorem envBound38837 : H12AffineFastState.Bounded env38837 := by
  intro p hp
  have h : env38837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38836_38837 : H12AffineEnvironment.transform 5 25 env38836 = env38837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 25 env38836 == env38837) = true)

theorem identity38837 : scanCanonicalize (H12AffineFastState.compose env38837 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound38837 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38838 : List Nat := [2,4,1,16,16,16,0,21,0,5,0,0,17,0,0,19,1,19,4,1,0,16,17,2,16,16,18,0,1,0,21,17,20,17,1,1]

theorem envBound38838 : H12AffineFastState.Bounded env38838 := by
  intro p hp
  have h : env38838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38837_38838 : H12AffineEnvironment.transform 2 1 env38837 = env38838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env38837 == env38838) = true)

theorem identity38838 : scanCanonicalize (H12AffineFastState.compose env38838 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound38838 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38839 : List Nat := [2,0,1,16,16,16,0,17,0,1,0,0,17,0,0,19,1,19,0,1,0,16,17,2,16,16,18,0,1,0,17,17,16,17,1,1]

theorem envBound38839 : H12AffineFastState.Bounded env38839 := by
  intro p hp
  have h : env38839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38838_38839 : H12AffineEnvironment.transform 1 0 env38838 = env38839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env38838 == env38839) = true)

theorem identity38839 : scanCanonicalize (H12AffineFastState.compose env38839 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound38839 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env38840 : List Nat := [2,0,1,2,2,2,0,3,0,1,0,0,3,0,0,1,1,1,0,1,0,2,3,2,2,2,0,0,1,0,3,3,2,3,1,1]

theorem envBound38840 : H12AffineFastState.Bounded env38840 := by
  intro p hp
  have h : env38840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38839_38840 : H12AffineEnvironment.transform 3 2 env38839 = env38840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env38839 == env38840) = true)

theorem identity38840 : scanCanonicalize (H12AffineFastState.compose env38840 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound38840 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env38841 : List Nat := [1,0,1,1,1,1,0,0,0,1,0,0,0,0,0,1,1,1,0,1,0,1,0,1,1,1,0,0,1,0,0,0,1,0,1,1]

theorem envBound38841 : H12AffineFastState.Bounded env38841 := by
  intro p hp
  have h : env38841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38840_38841 : H12AffineEnvironment.transform 0 1 env38840 = env38841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env38840 == env38841) = true)

def env38842 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1345,4096,4240,1296,1165,358,1345,486,409,1164,4096,476,17,4471,5504,1496,486,1296,5577,508,4253,4249,257,1281,1345,1945]

theorem envBound38842 : H12AffineFastState.Bounded env38842 := by
  intro p hp
  have h : env38842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38829_38842 : H12AffineEnvironment.transform 10 1345 env38829 = env38842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1345 env38829 == env38842) = true)

theorem identity38842 : scanCanonicalize (H12AffineFastState.compose env38842 (packedSelected [13] rootPS)) = affineNative (2^(9+1) ^^^ 85) := by decide +kernel

theorem selectedBound38842 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env38843 : List Nat := [2,4,8,16,32,64,128,256,512,85,276,4096,4240,325,216,358,276,486,409,217,4096,476,17,4471,4565,397,486,325,4508,508,4253,4249,257,340,276,972]

theorem envBound38843 : H12AffineFastState.Bounded env38843 := by
  intro p hp
  have h : env38843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38842_38843 : H12AffineEnvironment.transform 9 85 env38842 = env38843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env38842 == env38843) = true)

theorem identity38843 : scanCanonicalize (H12AffineFastState.compose env38843 (packedSelected [0,1,7,8,19,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound38843 : packedSelected [0,1,7,8,19,20,21] rootPS < 2^1333 := by decide +kernel

def env38844 : List Nat := [2,4,8,16,32,64,128,21,512,85,1,4096,4240,80,216,115,1,243,140,217,4096,201,17,4194,4288,152,243,80,4233,233,4253,4249,20,65,1,729]

theorem envBound38844 : H12AffineFastState.Bounded env38844 := by
  intro p hp
  have h : env38844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38843_38844 : H12AffineEnvironment.transform 7 21 env38843 = env38844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env38843 == env38844) = true)

theorem identity38844 : scanCanonicalize (H12AffineFastState.compose env38844 (packedSelected [1,2,4,5,7,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 104) := by decide +kernel

theorem selectedBound38844 : packedSelected [1,2,4,5,7,12,15] rootPS < 2^1333 := by decide +kernel

def env38845 : List Nat := [2,4,8,16,32,64,104,21,512,85,1,4096,4216,80,48,115,1,27,100,49,4096,33,17,4194,4136,112,27,80,4193,1,4213,4209,20,65,1,561]

theorem envBound38845 : H12AffineFastState.Bounded env38845 := by
  intro p hp
  have h : env38845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38844_38845 : H12AffineEnvironment.transform 6 104 env38844 = env38845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 104 env38844 == env38845) = true)

theorem identity38845 : scanCanonicalize (H12AffineFastState.compose env38845 (packedSelected [2,3,7,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 26) := by decide +kernel

theorem selectedBound38845 : packedSelected [2,3,7,8,9] rootPS < 2^1333 := by decide +kernel

def env38846 : List Nat := [2,4,8,16,32,64,104,21,512,85,1,26,98,80,48,115,1,27,100,49,26,33,17,120,50,112,27,80,123,1,111,107,20,65,1,561]

theorem envBound38846 : H12AffineFastState.Bounded env38846 := by
  intro p hp
  have h : env38846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38845_38846 : H12AffineEnvironment.transform 11 26 env38845 = env38846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 26 env38845 == env38846) = true)

theorem identity38846 : scanCanonicalize (H12AffineFastState.compose env38846 (packedSelected [0,1,2,7,8,10] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound38846 : packedSelected [0,1,2,7,8,10] rootPS < 2^1333 := by decide +kernel

def env38847 : List Nat := [2,4,8,16,32,64,104,21,48,85,1,26,98,80,48,115,1,27,100,49,26,33,17,120,50,112,27,80,123,1,111,107,20,65,1,1]

theorem envBound38847 : H12AffineFastState.Bounded env38847 := by
  intro p hp
  have h : env38847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38846_38847 : H12AffineEnvironment.transform 8 48 env38846 = env38847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env38846 == env38847) = true)

theorem identity38847 : scanCanonicalize (H12AffineFastState.compose env38847 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound38847 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env38848 : List Nat := [2,4,8,16,32,59,19,21,48,46,1,26,25,43,48,8,1,27,31,49,26,33,17,3,50,11,27,43,0,1,20,16,20,58,1,1]

theorem envBound38848 : H12AffineFastState.Bounded env38848 := by
  intro p hp
  have h : env38848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38847_38848 : H12AffineEnvironment.transform 5 59 env38847 = env38848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env38847 == env38848) = true)

theorem identity38848 : scanCanonicalize (H12AffineFastState.compose env38848 (packedSelected [4,7] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound38848 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env38849 : List Nat := [2,4,8,16,17,10,19,21,1,31,1,26,25,26,1,8,1,27,31,0,26,16,17,3,3,11,27,26,0,1,20,16,20,11,1,1]

theorem envBound38849 : H12AffineFastState.Bounded env38849 := by
  intro p hp
  have h : env38849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38848_38849 : H12AffineEnvironment.transform 4 17 env38848 = env38849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env38848 == env38849) = true)

theorem identity38849 : scanCanonicalize (H12AffineFastState.compose env38849 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound38849 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env38850 : List Nat := [2,4,8,10,11,10,9,15,1,5,1,0,3,0,1,8,1,1,5,0,0,10,11,3,3,11,1,0,0,1,14,10,14,11,1,1]

theorem envBound38850 : H12AffineFastState.Bounded env38850 := by
  intro p hp
  have h : env38850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38849_38850 : H12AffineEnvironment.transform 3 10 env38849 = env38850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env38849 == env38850) = true)

theorem identity38850 : scanCanonicalize (H12AffineFastState.compose env38850 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound38850 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38851 : List Nat := [2,2,8,10,11,10,9,9,1,3,1,0,3,0,1,8,1,1,3,0,0,10,11,3,3,11,1,0,0,1,8,10,8,11,1,1]

theorem envBound38851 : H12AffineFastState.Bounded env38851 := by
  intro p hp
  have h : env38851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38850_38851 : H12AffineEnvironment.transform 1 2 env38850 = env38851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env38850 == env38851) = true)

def env38852 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1345,65665,77935,13340,4096,476,17,69648,70886,78894,77840,1296,74815,81227,8204,8200,257,1281,1345,79471]

theorem envBound38852 : H12AffineFastState.Bounded env38852 := by
  intro p hp
  have h : env38852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38803_38852 : H12AffineEnvironment.transform 17 65665 env38803 = env38852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env38803 == env38852) = true)

theorem identity38852 : scanCanonicalize (H12AffineFastState.compose env38852 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5158) := by decide +kernel

theorem selectedBound38852 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env38853 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,5158,1345,5287,9289,13340,4096,476,17,1078,192,8200,9270,1296,12313,10605,8204,8200,257,1281,1345,8777]

theorem envBound38853 : H12AffineFastState.Bounded env38853 := by
  intro p hp
  have h : env38853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38852_38853 : H12AffineEnvironment.transform 15 5158 env38852 = env38853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5158 env38852 == env38853) = true)

def env38854 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,1296,13341,5158,1297,5287,9241,13340,4096,396,17,1078,144,8200,9270,1296,12313,10557,8204,8200,257,1281,1297,8729]

theorem envBound38854 : H12AffineFastState.Bounded env38854 := by
  intro p hp
  have h : env38854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38853_38854 : H12AffineEnvironment.transform 5 16 env38853 = env38854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38853 == env38854) = true)

theorem identity38854 : scanCanonicalize (H12AffineFastState.compose env38854 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 4365) := by decide +kernel

theorem selectedBound38854 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env38855 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,4365,1296,1296,5158,1297,5287,5396,1297,4096,396,17,1078,144,4357,5435,1296,276,6192,4353,4357,257,1281,1297,4884]

theorem envBound38855 : H12AffineFastState.Bounded env38855 := by
  intro p hp
  have h : env38855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38854_38855 : H12AffineEnvironment.transform 12 4365 env38854 = env38855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4365 env38854 == env38855) = true)

theorem identity38855 : scanCanonicalize (H12AffineFastState.compose env38855 (packedSelected [1,2,3,5,8,10,13,19,21,23,32] rootPS)) = affineNative (2^(11+1) ^^^ 925) := by decide +kernel

theorem selectedBound38855 : packedSelected [1,2,3,5,8,10,13,19,21,23,32] rootPS < 2^1333 := by decide +kernel

def env38856 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,925,656,1296,1296,1979,1297,1850,1673,1297,925,396,17,1078,144,664,1702,1296,276,2989,668,664,257,1281,1297,137]

theorem envBound38856 : H12AffineFastState.Bounded env38856 := by
  intro p hp
  have h : env38856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38855_38856 : H12AffineEnvironment.transform 11 925 env38855 = env38856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 925 env38855 == env38856) = true)

theorem identity38856 : scanCanonicalize (H12AffineFastState.compose env38856 (packedSelected [0,1,3,4,7,8,9,10,13,18,19,23,26,28] rootPS)) = affineNative (2^(10+1) ^^^ 1970) := by decide +kernel

theorem selectedBound38856 : packedSelected [0,1,3,4,7,8,9,10,13,18,19,23,26,28] rootPS < 2^1333 := by decide +kernel

def env38857 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1970,925,656,1296,1296,1979,1297,1850,1673,1297,925,396,17,1078,144,664,1702,1296,276,1055,668,664,257,1281,1297,137]

theorem envBound38857 : H12AffineFastState.Bounded env38857 := by
  intro p hp
  have h : env38857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38856_38857 : H12AffineEnvironment.transform 10 1970 env38856 = env38857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1970 env38856 == env38857) = true)

theorem identity38857 : scanCanonicalize (H12AffineFastState.compose env38857 (packedSelected [0,1,4,7,8,9,12,15,17,19] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound38857 : packedSelected [0,1,4,7,8,9,12,15,17,19] rootPS < 2^1333 := by decide +kernel

def env38858 : List Nat := [2,4,8,16,32,16,57,256,512,1024,1803,804,553,1296,1296,1794,1297,1850,1584,1297,804,309,17,1078,41,545,1567,1296,276,1055,549,545,257,1281,1297,48]

theorem envBound38858 : H12AffineFastState.Bounded env38858 := by
  intro p hp
  have h : env38858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38857_38858 : H12AffineEnvironment.transform 6 57 env38857 = env38858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env38857 == env38858) = true)

theorem identity38858 : scanCanonicalize (H12AffineFastState.compose env38858 (packedSelected [2,3,4,7,8,10,12,13] rootPS)) = affineNative (2^(9+1) ^^^ 558) := by decide +kernel

theorem selectedBound38858 : packedSelected [2,3,4,7,8,10,12,13] rootPS < 2^1333 := by decide +kernel

def env38859 : List Nat := [2,4,8,16,32,16,57,256,512,558,293,804,553,830,830,300,831,276,30,831,804,309,17,536,41,545,49,830,276,561,549,545,257,815,831,48]

theorem envBound38859 : H12AffineFastState.Bounded env38859 := by
  intro p hp
  have h : env38859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38858_38859 : H12AffineEnvironment.transform 9 558 env38858 = env38859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 558 env38858 == env38859) = true)

def env38860 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,1296,13341,5158,1296,5287,9240,13340,4096,397,17,1078,145,8200,9270,1296,12313,10556,8204,8200,257,1281,1296,8728]

theorem envBound38860 : H12AffineFastState.Bounded env38860 := by
  intro p hp
  have h : env38860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38853_38860 : H12AffineEnvironment.transform 5 17 env38853 = env38860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env38853 == env38860) = true)

theorem identity38860 : scanCanonicalize (H12AffineFastState.compose env38860 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound38860 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env38861 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,276,8192,1296,9481,1330,1296,1459,9240,9480,276,397,17,1078,145,8200,9270,1296,8461,10556,8204,8200,257,1281,1296,8728]

theorem envBound38861 : H12AffineFastState.Bounded env38861 := by
  intro p hp
  have h : env38861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38860_38861 : H12AffineEnvironment.transform 11 276 env38860 = env38861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env38860 == env38861) = true)

def env38862 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1344,262144,77934,32769,4096,46528,17,266384,70887,78895,77840,1296,74815,81226,365713,365717,257,1281,1345,79470]

theorem envBound38862 : H12AffineFastState.Bounded env38862 := by
  intro p hp
  have h : env38862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38801_38862 : H12AffineEnvironment.transform 13 1297 env38801 = env38862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env38801 == env38862) = true)

theorem identity38862 : scanCanonicalize (H12AffineFastState.compose env38862 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32882) := by decide +kernel

theorem selectedBound38862 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env38863 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,32882,1344,262144,45084,32769,4096,46528,17,266384,38037,46173,45154,1296,42061,48440,267491,267495,257,1281,1345,46620]

theorem envBound38863 : H12AffineFastState.Bounded env38863 := by
  intro p hp
  have h : env38863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38862_38863 : H12AffineEnvironment.transform 15 32882 env38862 = env38863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32882 env38862 == env38863) = true)

def env38864 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32882,1344,262144,42332,32769,1344,41088,17,263632,33237,41245,42274,1296,42061,43128,262563,262567,257,1281,1345,41820]

theorem envBound38864 : H12AffineFastState.Bounded env38864 := by
  intro p hp
  have h : env38864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38863_38864 : H12AffineEnvironment.transform 11 1344 env38863 = env38864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env38863 == env38864) = true)

theorem identity38864 : scanCanonicalize (H12AffineFastState.compose env38864 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 9454) := by decide +kernel

theorem selectedBound38864 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env38865 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32882,1344,9454,42332,32769,1344,41088,17,8510,33237,41245,42274,1296,42061,43128,9549,9545,257,1281,1345,41820]

theorem envBound38865 : H12AffineFastState.Bounded env38865 := by
  intro p hp
  have h : env38865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38864_38865 : H12AffineEnvironment.transform 17 9454 env38864 = env38865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 9454 env38864 == env38865) = true)

theorem identity38865 : scanCanonicalize (H12AffineFastState.compose env38865 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(12+1) ^^^ 3907) := by decide +kernel

theorem selectedBound38865 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env38866 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,3907,1297,32768,32882,1344,2989,35359,32769,1344,36803,17,3709,33237,36446,35425,1296,35598,34619,2574,2570,257,1281,1345,35871]

theorem envBound38866 : H12AffineFastState.Bounded env38866 := by
  intro p hp
  have h : env38866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38865_38866 : H12AffineEnvironment.transform 12 3907 env38865 = env38866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3907 env38865 == env38866) = true)

def env38867 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32882,1344,262144,42333,32769,1345,41089,17,263633,33236,41244,42275,1296,42061,43129,262562,262566,257,1281,1345,41821]

theorem envBound38867 : H12AffineFastState.Bounded env38867 := by
  intro p hp
  have h : env38867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38863_38867 : H12AffineEnvironment.transform 11 1345 env38863 = env38867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env38863 == env38867) = true)

theorem identity38867 : scanCanonicalize (H12AffineFastState.compose env38867 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 9245) := by decide +kernel

theorem selectedBound38867 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env38868 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,9245,9327,1344,262144,320,9244,1345,1180,17,263633,9673,1281,318,1296,80,3172,262562,262566,257,1281,1345,1856]

theorem envBound38868 : H12AffineFastState.Bounded env38868 := by
  intro p hp
  have h : env38868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38867_38868 : H12AffineEnvironment.transform 14 9245 env38867 = env38868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9245 env38867 == env38868) = true)

theorem identity38868 : scanCanonicalize (H12AffineFastState.compose env38868 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound38868 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env38869 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,1,8192,81,8541,8495,0,262144,320,8540,1,476,17,262289,8329,65,318,80,80,2340,262562,262566,257,65,1,512]

theorem envBound38869 : H12AffineFastState.Bounded env38869 := by
  intro p hp
  have h : env38869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38868_38869 : H12AffineEnvironment.transform 9 320 env38868 = env38869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env38868 == env38869) = true)

theorem identity38869 : scanCanonicalize (H12AffineFastState.compose env38869 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound38869 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env38870 : List Nat := [2,4,8,16,32,64,128,21,512,85,2048,1,8192,81,8264,8250,0,262144,85,8265,1,201,17,262289,8329,65,43,80,80,2097,262327,262323,20,65,1,512]

theorem envBound38870 : H12AffineFastState.Bounded env38870 := by
  intro p hp
  have h : env38870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38869_38870 : H12AffineEnvironment.transform 7 21 env38869 = env38870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env38869 == env38870) = true)

theorem identity38870 : scanCanonicalize (H12AffineFastState.compose env38870 (packedSelected [3,5,10] rootPS)) = affineNative (2^(17+1) ^^^ 8755) := by decide +kernel

theorem selectedBound38870 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env38871 : List Nat := [2,4,8,16,32,64,128,21,512,85,2048,1,8192,81,8264,8250,0,8755,85,8265,1,201,17,8866,8329,65,43,80,80,2097,8836,8832,20,65,1,512]

theorem envBound38871 : H12AffineFastState.Bounded env38871 := by
  intro p hp
  have h : env38871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38870_38871 : H12AffineEnvironment.transform 17 8755 env38870 = env38871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8755 env38870 == env38871) = true)

theorem identity38871 : scanCanonicalize (H12AffineFastState.compose env38871 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound38871 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env38872 : List Nat := [2,4,8,16,32,16,128,21,512,5,2048,1,8192,1,8216,8250,0,8755,5,8217,1,153,17,8866,8329,17,43,0,0,2097,8836,8832,20,17,1,512]

theorem envBound38872 : H12AffineFastState.Bounded env38872 := by
  intro p hp
  have h : env38872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38871_38872 : H12AffineEnvironment.transform 5 16 env38871 = env38872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38871 == env38872) = true)

theorem identity38872 : scanCanonicalize (H12AffineFastState.compose env38872 (packedSelected [1,3,13] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound38872 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env38873 : List Nat := [2,4,8,16,32,16,128,21,512,5,43,1,8192,1,8216,8250,0,8755,5,8217,1,153,17,8866,8329,17,43,0,0,26,8836,8832,20,17,1,512]

theorem envBound38873 : H12AffineFastState.Bounded env38873 := by
  intro p hp
  have h : env38873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38872_38873 : H12AffineEnvironment.transform 10 43 env38872 = env38873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env38872 == env38873) = true)

theorem identity38873 : scanCanonicalize (H12AffineFastState.compose env38873 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound38873 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env38874 : List Nat := [2,4,8,16,32,16,57,21,512,5,43,1,8192,1,8216,8250,0,8755,5,8217,1,32,17,8731,8240,17,43,0,0,26,8765,8761,20,17,1,512]

theorem envBound38874 : H12AffineFastState.Bounded env38874 := by
  intro p hp
  have h : env38874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38873_38874 : H12AffineEnvironment.transform 6 57 env38873 = env38874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env38873 == env38874) = true)

theorem identity38874 : scanCanonicalize (H12AffineFastState.compose env38874 (packedSelected [1,2,5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound38874 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env38875 : List Nat := [2,4,8,11,32,11,34,14,512,5,43,1,8192,1,8195,8225,0,8744,5,8194,1,32,10,8704,8235,10,43,0,0,1,8742,8738,15,10,1,512]

theorem envBound38875 : H12AffineFastState.Bounded env38875 := by
  intro p hp
  have h : env38875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38874_38875 : H12AffineEnvironment.transform 3 11 env38874 = env38875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env38874 == env38875) = true)

theorem identity38875 : scanCanonicalize (H12AffineFastState.compose env38875 (packedSelected [0,2,4] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound38875 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env38876 : List Nat := [2,4,8,11,32,11,34,14,512,5,43,1,41,1,42,8,0,513,5,43,1,32,10,553,2,10,43,0,0,1,527,523,15,10,1,512]

theorem envBound38876 : H12AffineFastState.Bounded env38876 := by
  intro p hp
  have h : env38876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38875_38876 : H12AffineEnvironment.transform 12 41 env38875 = env38876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env38875 == env38876) = true)

theorem identity38876 : scanCanonicalize (H12AffineFastState.compose env38876 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound38876 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env38877 : List Nat := [2,4,8,11,32,11,34,14,43,5,43,1,41,1,42,8,0,42,5,43,1,32,10,2,2,10,43,0,0,1,36,32,15,10,1,43]

theorem envBound38877 : H12AffineFastState.Bounded env38877 := by
  intro p hp
  have h : env38877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38876_38877 : H12AffineEnvironment.transform 8 43 env38876 = env38877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env38876 == env38877) = true)

theorem identity38877 : scanCanonicalize (H12AffineFastState.compose env38877 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound38877 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38878 : List Nat := [2,4,8,11,11,11,9,14,0,5,0,1,2,1,1,8,0,1,5,0,1,11,10,2,2,10,0,0,0,1,15,11,15,10,1,0]

theorem envBound38878 : H12AffineFastState.Bounded env38878 := by
  intro p hp
  have h : env38878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38877_38878 : H12AffineEnvironment.transform 4 11 env38877 = env38878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env38877 == env38878) = true)

theorem identity38878 : scanCanonicalize (H12AffineFastState.compose env38878 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound38878 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38879 : List Nat := [2,4,5,6,6,6,4,3,0,5,0,1,2,1,1,5,0,1,5,0,1,6,7,2,2,7,0,0,0,1,2,6,2,7,1,0]

theorem envBound38879 : H12AffineFastState.Bounded env38879 := by
  intro p hp
  have h : env38879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38878_38879 : H12AffineEnvironment.transform 2 5 env38878 = env38879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env38878 == env38879) = true)

def env38880 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,16777216,533641,672784,17245633,148801,545088,96347,16876545,17363322,257,1281,1344,525824]

theorem envBound38880 : H12AffineFastState.Bounded env38880 := by
  intro p hp
  have h : env38880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38616_38880 : H12AffineEnvironment.transform 26 17245633 env38616 = env38880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245633 env38616 == env38880) = true)

theorem identity38880 : scanCanonicalize (H12AffineFastState.compose env38880 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 74862) := by decide +kernel

theorem selectedBound38880 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env38881 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,524288,32769,4096,61649,91182,16777216,533641,614526,17039791,90415,545088,96347,16876545,17363322,257,1281,1344,525824]

theorem envBound38881 : H12AffineFastState.Bounded env38881 := by
  intro p hp
  have h : env38881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38880_38881 : H12AffineEnvironment.transform 16 74862 env38880 = env38881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 74862 env38880 == env38881) = true)

def env38882 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,524288,32769,4096,61649,91182,123164,533641,614526,385203,90415,545088,96347,25885,594022,257,1281,1344,525824]

theorem envBound38882 : H12AffineFastState.Bounded env38882 := by
  intro p hp
  have h : env38882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38881_38882 : H12AffineEnvironment.transform 23 123164 env38881 = env38882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 123164 env38881 == env38882) = true)

def env38883 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,21584,32769,4096,61649,91182,123164,28889,78894,385203,90415,1296,96347,25885,82998,257,1281,1344,21072]

theorem envBound38883 : H12AffineFastState.Bounded env38883 := by
  intro p hp
  have h : env38883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38882_38883 : H12AffineEnvironment.transform 18 21584 env38882 = env38883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21584 env38882 == env38883) = true)

theorem identity38883 : scanCanonicalize (H12AffineFastState.compose env38883 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 25676) := by decide +kernel

theorem selectedBound38883 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env38884 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,25676,65536,74862,262144,21584,25677,4096,5277,91182,66896,28889,78894,328959,90415,1296,96347,25885,82998,257,1281,1344,21072]

theorem envBound38884 : H12AffineFastState.Bounded env38884 := by
  intro p hp
  have h : env38884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38883_38884 : H12AffineEnvironment.transform 14 25676 env38883 = env38884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25676 env38883 == env38884) = true)

def env38885 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74862,262144,4416,8541,4096,5277,74046,66896,13769,78894,328959,74815,1296,81227,8205,65830,257,1281,1344,5952]

theorem envBound38885 : H12AffineFastState.Bounded env38885 := by
  intro p hp
  have h : env38885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38884_38885 : H12AffineEnvironment.transform 13 1296 env38884 = env38885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env38884 == env38885) = true)

def env38886 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74862,65664,4416,8541,4096,5277,74046,66896,13769,78894,1151,74815,1296,81227,8205,65830,257,1281,1344,5952]

theorem envBound38886 : H12AffineFastState.Bounded env38886 := by
  intro p hp
  have h : env38886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38885_38886 : H12AffineEnvironment.transform 17 65664 env38885 = env38886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env38885 == env38886) = true)

theorem identity38886 : scanCanonicalize (H12AffineFastState.compose env38886 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound38886 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env38887 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,81,8540,65536,74031,65664,4416,8541,4096,4572,74046,65553,12424,78191,318,74110,81,79882,8205,65830,257,64,1,4609]

theorem envBound38887 : H12AffineFastState.Bounded env38887 := by
  intro p hp
  have h : env38887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38886_38887 : H12AffineEnvironment.transform 9 321 env38886 = env38887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env38886 == env38887) = true)

def env38888 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,852,8192,81,8540,65536,74031,65664,532,8541,852,648,74046,65553,9180,74299,318,74110,81,76638,8205,65830,257,64,1,341]

theorem envBound38888 : H12AffineFastState.Bounded env38888 := by
  intro p hp
  have h : env38888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38887_38888 : H12AffineEnvironment.transform 11 852 env38887 = env38888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 852 env38887 == env38888) = true)

def env38889 : List Nat := [2,4,8,0,32,64,128,256,512,321,2048,836,8192,65,8524,65536,74031,65664,516,8525,836,648,74030,65537,9164,74283,302,74094,65,76622,8205,65830,257,64,1,325]

theorem envBound38889 : H12AffineFastState.Bounded env38889 := by
  intro p hp
  have h : env38889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38888_38889 : H12AffineEnvironment.transform 3 0 env38888 = env38889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env38888 == env38889) = true)

theorem identity38889 : scanCanonicalize (H12AffineFastState.compose env38889 (packedSelected [1,8,28] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound38889 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env38890 : List Nat := [2,4,8,0,6,64,128,256,512,321,2048,836,8192,65,8524,65536,73993,65664,516,8525,836,648,73992,65537,9164,74253,264,74056,65,76622,8205,65792,257,64,1,325]

theorem envBound38890 : H12AffineFastState.Bounded env38890 := by
  intro p hp
  have h : env38890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38889_38890 : H12AffineEnvironment.transform 4 6 env38889 = env38890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env38889 == env38890) = true)

def env38891 : List Nat := [2,4,8,0,6,64,128,256,512,321,2048,836,8192,65,8524,8456,1,8584,516,8525,836,648,0,8457,9164,773,264,64,65,2630,8205,8200,257,64,1,325]

theorem envBound38891 : H12AffineFastState.Bounded env38891 := by
  intro p hp
  have h : env38891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38890_38891 : H12AffineEnvironment.transform 15 8456 env38890 = env38891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8456 env38890 == env38891) = true)

theorem identity38891 : scanCanonicalize (H12AffineFastState.compose env38891 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound38891 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env38892 : List Nat := [2,4,8,0,6,64,128,68,512,5,2048,512,8192,65,8200,8268,1,8396,516,8201,512,648,0,8269,8840,577,76,64,65,2630,8205,8200,69,64,1,1]

theorem envBound38892 : H12AffineFastState.Bounded env38892 := by
  intro p hp
  have h : env38892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38891_38892 : H12AffineEnvironment.transform 7 68 env38891 = env38892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env38891 == env38892) = true)

theorem identity38892 : scanCanonicalize (H12AffineFastState.compose env38892 (packedSelected [0,1,3,4,7,8,9,10,16,17,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 584) := by decide +kernel

theorem selectedBound38892 : packedSelected [0,1,3,4,7,8,9,10,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env38893 : List Nat := [2,4,8,0,6,64,128,68,512,5,2048,512,584,65,576,516,1,644,516,577,512,648,0,517,192,577,76,64,65,2630,581,576,69,64,1,1]

theorem envBound38893 : H12AffineFastState.Bounded env38893 := by
  intro p hp
  have h : env38893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38892_38893 : H12AffineEnvironment.transform 12 584 env38892 = env38893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 584 env38892 == env38893) = true)

theorem identity38893 : scanCanonicalize (H12AffineFastState.compose env38893 (packedSelected [0,3,7,10,11,15] rootPS)) = affineNative (2^(8+1) ^^^ 142) := by decide +kernel

theorem selectedBound38893 : packedSelected [0,3,7,10,11,15] rootPS < 2^1333 := by decide +kernel

def env38894 : List Nat := [2,4,8,0,6,64,128,68,142,5,2048,142,198,65,206,138,1,10,138,207,142,6,0,139,192,207,76,64,65,2248,203,206,69,64,1,1]

theorem envBound38894 : H12AffineFastState.Bounded env38894 := by
  intro p hp
  have h : env38894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38893_38894 : H12AffineEnvironment.transform 8 142 env38893 = env38894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 142 env38893 == env38894) = true)

theorem identity38894 : scanCanonicalize (H12AffineFastState.compose env38894 (packedSelected [0,2,4,5,7,9] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound38894 : packedSelected [0,2,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env38895 : List Nat := [2,4,2,0,6,64,128,68,132,5,2048,132,198,65,196,128,1,0,128,197,132,6,0,129,192,197,70,64,65,2242,193,196,69,64,1,1]

theorem envBound38895 : H12AffineFastState.Bounded env38895 := by
  intro p hp
  have h : env38895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38894_38895 : H12AffineEnvironment.transform 2 2 env38894 = env38895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env38894 == env38895) = true)

theorem identity38895 : scanCanonicalize (H12AffineFastState.compose env38895 (packedSelected [2,4,5,7] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound38895 : packedSelected [2,4,5,7] rootPS < 2^1333 := by decide +kernel

def env38896 : List Nat := [2,2,2,0,0,64,128,66,130,3,2048,130,192,65,194,128,1,0,128,195,130,0,0,129,192,195,64,64,65,2242,193,194,67,64,1,1]

theorem envBound38896 : H12AffineFastState.Bounded env38896 := by
  intro p hp
  have h : env38896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38895_38896 : H12AffineEnvironment.transform 1 2 env38895 = env38896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env38895 == env38896) = true)

theorem identity38896 : scanCanonicalize (H12AffineFastState.compose env38896 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound38896 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38897 : List Nat := [2,2,2,0,0,64,128,66,130,3,0,130,192,65,194,128,1,0,128,195,130,0,0,129,192,195,64,64,65,194,193,194,67,64,1,1]

theorem envBound38897 : H12AffineFastState.Bounded env38897 := by
  intro p hp
  have h : env38897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38896_38897 : H12AffineEnvironment.transform 10 0 env38896 = env38897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env38896 == env38897) = true)

theorem identity38897 : scanCanonicalize (H12AffineFastState.compose env38897 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound38897 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38898 : List Nat := [2,2,2,0,0,64,3,66,1,3,0,1,67,65,65,3,1,0,3,64,1,0,0,2,67,64,64,64,65,65,66,65,67,64,1,1]

theorem envBound38898 : H12AffineFastState.Bounded env38898 := by
  intro p hp
  have h : env38898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38897_38898 : H12AffineEnvironment.transform 6 3 env38897 = env38898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env38897 == env38898) = true)

def env38899 : List Nat := [2,4,8,0,6,64,128,256,512,321,2048,836,8192,65,8524,8457,0,8585,516,8525,836,648,1,8456,9164,772,264,65,65,2631,8205,8201,257,64,1,325]

theorem envBound38899 : H12AffineFastState.Bounded env38899 := by
  intro p hp
  have h : env38899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38890_38899 : H12AffineEnvironment.transform 15 8457 env38890 = env38899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8457 env38890 == env38899) = true)

theorem identity38899 : scanCanonicalize (H12AffineFastState.compose env38899 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound38899 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env38900 : List Nat := [2,4,8,0,6,64,128,256,512,321,2048,836,8,65,324,257,0,385,516,325,836,648,1,256,964,772,264,65,65,2631,5,1,257,64,1,325]

theorem envBound38900 : H12AffineFastState.Bounded env38900 := by
  intro p hp
  have h : env38900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38899_38900 : H12AffineEnvironment.transform 12 8 env38899 = env38900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env38899 == env38900) = true)

theorem identity38900 : scanCanonicalize (H12AffineFastState.compose env38900 (packedSelected [1,2,3,4,5,8,9,11,15,16,18] rootPS)) = affineNative (2^(8+1) ^^^ 328) := by decide +kernel

theorem selectedBound38900 : packedSelected [1,2,3,4,5,8,9,11,15,16,18] rootPS < 2^1333 := by decide +kernel

def env38901 : List Nat := [2,4,8,0,6,64,128,256,328,321,2048,12,8,65,324,257,0,385,332,325,12,448,1,256,140,76,264,65,65,2319,5,1,257,64,1,325]

theorem envBound38901 : H12AffineFastState.Bounded env38901 := by
  intro p hp
  have h : env38901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38900_38901 : H12AffineEnvironment.transform 8 328 env38900 = env38901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 328 env38900 == env38901) = true)

theorem identity38901 : scanCanonicalize (H12AffineFastState.compose env38901 (packedSelected [8,10,13,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 206) := by decide +kernel

theorem selectedBound38901 : packedSelected [8,10,13,15,17] rootPS < 2^1333 := by decide +kernel

def env38902 : List Nat := [2,4,8,0,6,64,128,256,328,321,206,12,8,65,324,257,0,385,332,325,12,448,1,256,140,76,264,65,65,449,5,1,257,64,1,325]

theorem envBound38902 : H12AffineFastState.Bounded env38902 := by
  intro p hp
  have h : env38902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38901_38902 : H12AffineEnvironment.transform 10 206 env38901 = env38902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 206 env38901 == env38902) = true)

theorem identity38902 : scanCanonicalize (H12AffineFastState.compose env38902 (packedSelected [0,3,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 202) := by decide +kernel

theorem selectedBound38902 : packedSelected [0,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env38903 : List Nat := [2,4,8,0,6,64,128,202,130,139,206,12,8,65,142,203,0,75,134,143,12,10,1,202,140,76,194,65,65,11,5,1,203,64,1,143]

theorem envBound38903 : H12AffineFastState.Bounded env38903 := by
  intro p hp
  have h : env38903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38902_38903 : H12AffineEnvironment.transform 7 202 env38902 = env38903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 202 env38902 == env38903) = true)

theorem identity38903 : scanCanonicalize (H12AffineFastState.compose env38903 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(5+1) ^^^ 12) := by decide +kernel

theorem selectedBound38903 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env38904 : List Nat := [2,4,8,0,6,12,128,134,130,139,130,12,8,13,142,135,0,7,134,143,12,10,1,134,140,0,142,13,13,11,5,1,135,12,1,143]

theorem envBound38904 : H12AffineFastState.Bounded env38904 := by
  intro p hp
  have h : env38904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38903_38904 : H12AffineEnvironment.transform 5 12 env38903 = env38904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 12 env38903 == env38904) = true)

theorem identity38904 : scanCanonicalize (H12AffineFastState.compose env38904 (packedSelected [2,3] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound38904 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env38905 : List Nat := [2,4,8,0,6,12,8,14,10,3,10,12,8,13,6,15,0,7,14,7,12,10,1,14,4,0,6,13,13,11,5,1,15,12,1,7]

theorem envBound38905 : H12AffineFastState.Bounded env38905 := by
  intro p hp
  have h : env38905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38904_38905 : H12AffineEnvironment.transform 6 8 env38904 = env38905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env38904 == env38905) = true)

def env38906 : List Nat := [2,4,8,1,32,64,128,256,512,321,2048,837,8192,64,8525,65536,74031,65664,517,8524,837,648,74031,65536,9165,74282,303,74095,64,76623,8205,65830,257,64,1,324]

theorem envBound38906 : H12AffineFastState.Bounded env38906 := by
  intro p hp
  have h : env38906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38888_38906 : H12AffineEnvironment.transform 3 1 env38888 = env38906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env38888 == env38906) = true)

theorem identity38906 : scanCanonicalize (H12AffineFastState.compose env38906 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 110) := by decide +kernel

theorem selectedBound38906 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env38907 : List Nat := [2,4,8,1,32,64,128,256,512,321,2048,837,110,64,291,65536,65857,65664,517,290,837,648,65857,65536,931,66116,303,65793,64,68385,99,65830,257,64,1,324]

theorem envBound38907 : H12AffineFastState.Bounded env38907 := by
  intro p hp
  have h : env38907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38906_38907 : H12AffineEnvironment.transform 12 110 env38906 = env38907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 110 env38906 == env38907) = true)

def env38908 : List Nat := [2,4,8,1,32,64,128,4,512,69,2048,577,110,64,39,65536,65605,65664,517,38,577,648,65605,65536,679,66116,43,65541,64,68133,99,65570,5,64,1,64]

theorem envBound38908 : H12AffineFastState.Bounded env38908 := by
  intro p hp
  have h : env38908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38907_38908 : H12AffineEnvironment.transform 7 4 env38907 = env38908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env38907 == env38908) = true)

theorem identity38908 : scanCanonicalize (H12AffineFastState.compose env38908 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(8+1) ^^^ 64) := by decide +kernel

theorem selectedBound38908 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env38909 : List Nat := [2,4,8,1,32,64,128,4,64,69,2048,1,110,64,39,65536,65605,65664,69,38,1,200,65605,65536,231,65540,43,65541,64,67685,99,65570,5,64,1,64]

theorem envBound38909 : H12AffineFastState.Bounded env38909 := by
  intro p hp
  have h : env38909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38908_38909 : H12AffineEnvironment.transform 8 64 env38908 = env38909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 64 env38908 == env38909) = true)

theorem identity38909 : scanCanonicalize (H12AffineFastState.compose env38909 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 111) := by decide +kernel

theorem selectedBound38909 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env38910 : List Nat := [2,4,8,1,32,64,111,4,64,69,2048,1,110,64,39,65536,65605,65647,69,38,1,39,65605,65536,8,65540,43,65541,64,67685,99,65570,5,64,1,64]

theorem envBound38910 : H12AffineFastState.Bounded env38910 := by
  intro p hp
  have h : env38910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38909_38910 : H12AffineEnvironment.transform 6 111 env38909 = env38910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 111 env38909 == env38910) = true)

theorem identity38910 : scanCanonicalize (H12AffineFastState.compose env38910 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 68) := by decide +kernel

theorem selectedBound38910 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env38911 : List Nat := [2,4,8,1,32,64,111,4,64,69,2048,1,110,64,39,68,1,43,69,38,1,39,1,68,8,64,43,65,64,2081,99,102,5,64,1,64]

theorem envBound38911 : H12AffineFastState.Bounded env38911 := by
  intro p hp
  have h : env38911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38910_38911 : H12AffineEnvironment.transform 15 68 env38910 = env38911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 68 env38910 == env38911) = true)

theorem identity38911 : scanCanonicalize (H12AffineFastState.compose env38911 (packedSelected [2,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound38911 : packedSelected [2,5,7] rootPS < 2^1333 := by decide +kernel

def env38912 : List Nat := [2,4,8,1,13,64,66,4,64,69,2048,1,67,64,10,68,1,6,69,11,1,10,1,68,8,64,6,65,64,2060,78,75,5,64,1,64]

theorem envBound38912 : H12AffineFastState.Bounded env38912 := by
  intro p hp
  have h : env38912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38911_38912 : H12AffineEnvironment.transform 4 13 env38911 = env38912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env38911 == env38912) = true)

theorem identity38912 : scanCanonicalize (H12AffineFastState.compose env38912 (packedSelected [8] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound38912 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env38913 : List Nat := [2,2,8,1,11,64,66,2,64,67,2048,1,67,64,10,66,1,0,67,11,1,10,1,66,8,64,0,65,64,2058,72,75,3,64,1,64]

theorem envBound38913 : H12AffineFastState.Bounded env38913 := by
  intro p hp
  have h : env38913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38912_38913 : H12AffineEnvironment.transform 1 2 env38912 = env38913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env38912 == env38913) = true)

theorem identity38913 : scanCanonicalize (H12AffineFastState.compose env38913 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound38913 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38914 : List Nat := [2,2,8,1,11,64,66,2,64,67,0,1,67,64,10,66,1,0,67,11,1,10,1,66,8,64,0,65,64,10,72,75,3,64,1,64]

theorem envBound38914 : H12AffineFastState.Bounded env38914 := by
  intro p hp
  have h : env38914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38913_38914 : H12AffineEnvironment.transform 10 0 env38913 = env38914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env38913 == env38914) = true)

theorem identity38914 : scanCanonicalize (H12AffineFastState.compose env38914 (packedSelected [0,1] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound38914 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env38915 : List Nat := [2,2,8,1,11,0,2,2,0,3,0,1,3,0,10,2,1,0,3,11,1,10,1,2,8,0,0,1,0,10,8,11,3,0,1,0]

theorem envBound38915 : H12AffineFastState.Bounded env38915 := by
  intro p hp
  have h : env38915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38914_38915 : H12AffineEnvironment.transform 5 0 env38914 = env38915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env38914 == env38915) = true)

theorem identity38915 : scanCanonicalize (H12AffineFastState.compose env38915 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound38915 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38916 : List Nat := [2,2,3,1,0,0,2,2,0,3,0,1,3,0,1,2,1,0,3,0,1,1,1,2,3,0,0,1,0,1,3,0,3,0,1,0]

theorem envBound38916 : H12AffineFastState.Bounded env38916 := by
  intro p hp
  have h : env38916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38915_38916 : H12AffineEnvironment.transform 2 3 env38915 = env38916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env38915 == env38916) = true)

def env38917 : List Nat := [2,4,8,1,32,64,128,5,512,68,2048,576,110,64,38,65536,65604,65664,517,39,576,648,65604,65536,678,66116,42,65540,64,68132,99,65571,4,64,1,65]

theorem envBound38917 : H12AffineFastState.Bounded env38917 := by
  intro p hp
  have h : env38917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38907_38917 : H12AffineEnvironment.transform 7 5 env38907 = env38917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env38907 == env38917) = true)

theorem identity38917 : scanCanonicalize (H12AffineFastState.compose env38917 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(8+1) ^^^ 103) := by decide +kernel

theorem selectedBound38917 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env38918 : List Nat := [2,4,8,1,32,64,128,5,103,68,2048,39,110,64,38,65536,65604,65664,98,39,39,239,65604,65536,193,65571,42,65540,64,67651,99,65571,4,64,1,65]

theorem envBound38918 : H12AffineFastState.Bounded env38918 := by
  intro p hp
  have h : env38918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38917_38918 : H12AffineEnvironment.transform 8 103 env38917 = env38918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 103 env38917 == env38918) = true)

theorem identity38918 : scanCanonicalize (H12AffineFastState.compose env38918 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 68) := by decide +kernel

theorem selectedBound38918 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env38919 : List Nat := [2,4,8,1,32,64,128,5,103,68,2048,39,110,64,38,68,0,196,98,39,39,239,0,68,193,103,42,64,64,2055,99,103,4,64,1,65]

theorem envBound38919 : H12AffineFastState.Bounded env38919 := by
  intro p hp
  have h : env38919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38918_38919 : H12AffineEnvironment.transform 15 68 env38918 = env38919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 68 env38918 == env38919) = true)

theorem identity38919 : scanCanonicalize (H12AffineFastState.compose env38919 (packedSelected [1,2,5,10,12,13,15] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound38919 : packedSelected [1,2,5,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env38920 : List Nat := [2,4,8,1,32,64,4,5,103,68,2048,39,110,64,38,68,0,64,98,39,39,107,0,68,69,103,42,64,64,2055,99,103,4,64,1,65]

theorem envBound38920 : H12AffineFastState.Bounded env38920 := by
  intro p hp
  have h : env38920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38919_38920 : H12AffineEnvironment.transform 6 4 env38919 = env38920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env38919 == env38920) = true)

theorem identity38920 : scanCanonicalize (H12AffineFastState.compose env38920 (packedSelected [1,3,5,10] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound38920 : packedSelected [1,3,5,10] rootPS < 2^1333 := by decide +kernel

def env38921 : List Nat := [2,4,8,1,11,64,4,5,76,68,2048,12,69,64,13,68,0,64,73,12,12,64,0,68,69,76,1,64,64,2055,72,76,4,64,1,65]

theorem envBound38921 : H12AffineFastState.Bounded env38921 := by
  intro p hp
  have h : env38921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38920_38921 : H12AffineEnvironment.transform 4 11 env38920 = env38921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env38920 == env38921) = true)

theorem identity38921 : scanCanonicalize (H12AffineFastState.compose env38921 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound38921 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38922 : List Nat := [2,4,8,1,11,0,4,5,12,4,2048,12,5,0,13,4,0,0,9,12,12,0,0,4,5,12,1,0,0,2055,8,12,4,0,1,1]

theorem envBound38922 : H12AffineFastState.Bounded env38922 := by
  intro p hp
  have h : env38922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38921_38922 : H12AffineEnvironment.transform 5 0 env38921 = env38922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env38921 == env38922) = true)

theorem identity38922 : scanCanonicalize (H12AffineFastState.compose env38922 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound38922 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env38923 : List Nat := [2,4,2,1,1,0,4,5,6,4,2048,6,5,0,7,4,0,0,3,6,6,0,0,4,5,6,1,0,0,2055,2,6,4,0,1,1]

theorem envBound38923 : H12AffineFastState.Bounded env38923 := by
  intro p hp
  have h : env38923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38922_38923 : H12AffineEnvironment.transform 2 2 env38922 = env38923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env38922 == env38923) = true)

theorem identity38923 : scanCanonicalize (H12AffineFastState.compose env38923 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound38923 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env38924 : List Nat := [2,4,2,1,1,0,4,5,6,4,1,6,5,0,7,4,0,0,3,6,6,0,0,4,5,6,1,0,0,6,2,6,4,0,1,1]

theorem envBound38924 : H12AffineFastState.Bounded env38924 := by
  intro p hp
  have h : env38924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38923_38924 : H12AffineEnvironment.transform 10 1 env38923 = env38924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env38923 == env38924) = true)

theorem identity38924 : scanCanonicalize (H12AffineFastState.compose env38924 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

end H12CloudChart2