import H12CloudChart2Data114

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound28325 : H12AffineFastState.Bounded env28325 := by
  intro p hp
  have h : env28325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28324_28325 : H12AffineEnvironment.transform 10 163 env28324 = env28325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 163 env28324 == env28325) = true)

theorem identity28325 : scanCanonicalize (H12AffineFastState.compose env28325 (packedSelected [3,5] rootPS)) = affineNative (2^(6+1) ^^^ 52) := by decide +kernel

theorem selectedBound28325 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env28326 : List Nat := [2,4,5,16,32,0,52,21,0,5,23,17,20,0,17,50,0,6,4,16,16,48,0,50,37,17,55,16,1,55,21,1,20,17,17,1]

theorem envBound28326 : H12AffineFastState.Bounded env28326 := by
  intro p hp
  have h : env28326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28325_28326 : H12AffineEnvironment.transform 6 52 env28325 = env28326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 52 env28325 == env28326) = true)

theorem identity28326 : scanCanonicalize (H12AffineFastState.compose env28326 (packedSelected [2,3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound28326 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env28327 : List Nat := [2,2,3,16,32,0,50,19,0,3,17,17,18,0,17,50,0,0,2,16,16,48,0,50,35,17,49,16,1,49,19,1,18,17,17,1]

theorem envBound28327 : H12AffineFastState.Bounded env28327 := by
  intro p hp
  have h : env28327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28326_28327 : H12AffineEnvironment.transform 1 2 env28326 = env28327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env28326 == env28327) = true)

theorem identity28327 : scanCanonicalize (H12AffineFastState.compose env28327 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound28327 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28328 : List Nat := [2,2,3,16,3,0,17,19,0,3,17,17,18,0,17,17,0,0,2,16,16,19,0,17,0,17,18,16,1,18,19,1,18,17,17,1]

theorem envBound28328 : H12AffineFastState.Bounded env28328 := by
  intro p hp
  have h : env28328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28327_28328 : H12AffineEnvironment.transform 4 3 env28327 = env28328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env28327 == env28328) = true)

theorem identity28328 : scanCanonicalize (H12AffineFastState.compose env28328 (packedSelected [2,4] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound28328 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env28329 : List Nat := [2,2,3,3,3,0,2,0,0,3,2,2,1,0,2,2,0,0,2,3,3,0,0,2,0,2,1,3,1,1,0,1,1,2,2,1]

theorem envBound28329 : H12AffineFastState.Bounded env28329 := by
  intro p hp
  have h : env28329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28328_28329 : H12AffineEnvironment.transform 3 3 env28328 = env28329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env28328 == env28329) = true)

theorem identity28329 : scanCanonicalize (H12AffineFastState.compose env28329 (packedSelected [2] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound28329 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28330 : List Nat := [0,0,1,1,1,0,0,0,0,1,0,0,1,0,0,0,0,0,0,1,1,0,0,0,0,0,1,1,1,1,0,1,1,0,0,1]

theorem envBound28330 : H12AffineFastState.Bounded env28330 := by
  intro p hp
  have h : env28330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28329_28330 : H12AffineEnvironment.transform 0 0 env28329 = env28330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env28329 == env28330) = true)

def env28331 : List Nat := [2,4,8,16,32,1,128,256,512,1024,2048,1556,25,1296,261,65536,66614,65664,1813,260,1557,649,65831,66833,901,66083,1086,66599,1297,68358,21,65830,257,1281,1280,277]

theorem envBound28331 : H12AffineFastState.Bounded env28331 := by
  intro p hp
  have h : env28331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28310_28331 : H12AffineEnvironment.transform 5 1 env28310 = env28331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env28310 == env28331) = true)

theorem identity28331 : scanCanonicalize (H12AffineFastState.compose env28331 (packedSelected [1,8,28] rootPS)) = affineNative (2^(9+1) ^^^ 520) := by decide +kernel

theorem selectedBound28331 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env28332 : List Nat := [2,4,8,16,32,1,128,256,512,520,2048,28,25,792,261,65536,66110,65664,285,260,29,649,65831,66329,901,66083,566,66095,793,68358,21,65830,257,777,776,277]

theorem envBound28332 : H12AffineFastState.Bounded env28332 := by
  intro p hp
  have h : env28332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28331_28332 : H12AffineEnvironment.transform 9 520 env28331 = env28332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 520 env28331 == env28332) = true)

def env28333 : List Nat := [2,4,8,16,32,1,128,256,280,272,2048,28,25,0,261,65536,65830,65664,285,260,29,401,65831,65537,157,65851,302,65847,1,67614,21,65830,257,17,16,277]

theorem envBound28333 : H12AffineFastState.Bounded env28333 := by
  intro p hp
  have h : env28333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28332_28333 : H12AffineEnvironment.transform 8 280 env28332 = env28333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 280 env28332 == env28333) = true)

theorem identity28333 : scanCanonicalize (H12AffineFastState.compose env28333 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 63) := by decide +kernel

theorem selectedBound28333 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env28334 : List Nat := [2,4,8,16,32,1,128,256,280,272,2048,28,25,0,261,63,281,191,285,260,29,401,280,62,157,260,302,264,1,2081,21,281,257,17,16,277]

theorem envBound28334 : H12AffineFastState.Bounded env28334 := by
  intro p hp
  have h : env28334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28333_28334 : H12AffineEnvironment.transform 15 63 env28333 = env28334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 63 env28333 == env28334) = true)

theorem identity28334 : scanCanonicalize (H12AffineFastState.compose env28334 (packedSelected [0,1,2,3,7,10,12,17,20] rootPS)) = affineNative (2^(7+1) ^^^ 183) := by decide +kernel

theorem selectedBound28334 : packedSelected [0,1,2,3,7,10,12,17,20] rootPS < 2^1333 := by decide +kernel

def env28335 : List Nat := [2,4,8,16,32,1,128,183,175,167,2048,28,25,0,178,63,174,191,170,179,29,38,175,62,157,179,153,191,1,2081,21,174,182,17,16,162]

theorem envBound28335 : H12AffineFastState.Bounded env28335 := by
  intro p hp
  have h : env28335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28334_28335 : H12AffineEnvironment.transform 7 183 env28334 = env28335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 183 env28334 == env28335) = true)

theorem identity28335 : scanCanonicalize (H12AffineFastState.compose env28335 (packedSelected [1,2,4,5,8,9,12,13,15,16,17] rootPS)) = affineNative (2^(10+1) ^^^ 28) := by decide +kernel

theorem selectedBound28335 : packedSelected [1,2,4,5,8,9,12,13,15,16,17] rootPS < 2^1333 := by decide +kernel

def env28336 : List Nat := [2,4,8,16,32,1,128,183,175,167,28,28,25,0,178,63,174,191,170,179,29,38,175,62,157,179,153,191,1,61,21,174,182,17,16,162]

theorem envBound28336 : H12AffineFastState.Bounded env28336 := by
  intro p hp
  have h : env28336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28335_28336 : H12AffineEnvironment.transform 10 28 env28335 = env28336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 28 env28335 == env28336) = true)

theorem identity28336 : scanCanonicalize (H12AffineFastState.compose env28336 (packedSelected [0,1,3,9,11,12] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound28336 : packedSelected [0,1,3,9,11,12] rootPS < 2^1333 := by decide +kernel

def env28337 : List Nat := [2,4,8,16,1,1,128,150,142,134,28,28,25,0,147,30,143,158,139,146,29,7,142,31,157,146,153,158,1,28,21,143,151,17,16,131]

theorem envBound28337 : H12AffineFastState.Bounded env28337 := by
  intro p hp
  have h : env28337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28336_28337 : H12AffineEnvironment.transform 4 1 env28336 = env28337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env28336 == env28337) = true)

theorem identity28337 : scanCanonicalize (H12AffineFastState.compose env28337 (packedSelected [2,3,4,7] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound28337 : packedSelected [2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env28338 : List Nat := [2,4,8,16,1,1,4,18,10,2,28,28,25,0,23,30,11,26,15,22,29,7,10,31,25,22,29,26,1,28,21,11,19,17,16,7]

theorem envBound28338 : H12AffineFastState.Bounded env28338 := by
  intro p hp
  have h : env28338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28337_28338 : H12AffineEnvironment.transform 6 4 env28337 = env28338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env28337 == env28338) = true)

theorem identity28338 : scanCanonicalize (H12AffineFastState.compose env28338 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound28338 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env28339 : List Nat := [2,4,8,1,1,1,4,3,10,2,13,13,8,0,6,15,11,11,15,7,12,7,10,14,8,7,12,11,1,13,4,11,2,0,1,7]

theorem envBound28339 : H12AffineFastState.Bounded env28339 := by
  intro p hp
  have h : env28339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28338_28339 : H12AffineEnvironment.transform 3 1 env28338 = env28339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env28338 == env28339) = true)

theorem identity28339 : scanCanonicalize (H12AffineFastState.compose env28339 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound28339 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28340 : List Nat := [2,4,4,1,1,1,4,3,6,2,1,1,4,0,6,3,7,7,3,7,0,7,6,2,4,7,0,7,1,1,4,7,2,0,1,7]

theorem envBound28340 : H12AffineFastState.Bounded env28340 := by
  intro p hp
  have h : env28340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28339_28340 : H12AffineEnvironment.transform 2 4 env28339 = env28340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env28339 == env28340) = true)

theorem identity28340 : scanCanonicalize (H12AffineFastState.compose env28340 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound28340 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28341 : List Nat := [0,4,4,1,1,1,4,1,4,0,1,1,4,0,4,1,5,5,1,5,0,5,4,0,4,5,0,5,1,1,4,5,0,0,1,5]

theorem envBound28341 : H12AffineFastState.Bounded env28341 := by
  intro p hp
  have h : env28341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28340_28341 : H12AffineEnvironment.transform 0 0 env28340 = env28341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env28340 == env28341) = true)

def env28342 : List Nat := [2,4,8,16,32,1,128,256,281,273,2048,28,25,1,261,65536,65831,65664,285,260,29,400,65831,65536,156,65850,303,65846,0,67615,21,65830,257,16,17,277]

theorem envBound28342 : H12AffineFastState.Bounded env28342 := by
  intro p hp
  have h : env28342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28332_28342 : H12AffineEnvironment.transform 8 281 env28332 = env28342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 281 env28332 == env28342) = true)

theorem identity28342 : scanCanonicalize (H12AffineFastState.compose env28342 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 51) := by decide +kernel

theorem selectedBound28342 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env28343 : List Nat := [2,4,8,16,32,1,128,256,281,273,2048,28,25,1,261,51,276,179,285,260,29,400,276,51,156,265,303,261,0,2092,21,277,257,16,17,277]

theorem envBound28343 : H12AffineFastState.Bounded env28343 := by
  intro p hp
  have h : env28343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28342_28343 : H12AffineEnvironment.transform 15 51 env28342 = env28343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 51 env28342 == env28343) = true)

theorem identity28343 : scanCanonicalize (H12AffineFastState.compose env28343 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound28343 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env28344 : List Nat := [2,4,8,16,32,1,128,21,12,4,2048,28,25,1,16,51,1,179,8,17,29,133,1,51,156,28,58,16,0,2092,21,0,20,16,17,0]

theorem envBound28344 : H12AffineFastState.Bounded env28344 := by
  intro p hp
  have h : env28344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28343_28344 : H12AffineEnvironment.transform 7 21 env28343 = env28344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env28343 == env28344) = true)

theorem identity28344 : scanCanonicalize (H12AffineFastState.compose env28344 (packedSelected [0,1,5,7,8,10,11,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 21) := by decide +kernel

theorem selectedBound28344 : packedSelected [0,1,5,7,8,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env28345 : List Nat := [2,4,8,16,32,1,21,21,12,4,2048,28,25,1,16,51,1,38,8,17,29,16,1,51,9,28,58,16,0,2092,21,0,20,16,17,0]

theorem envBound28345 : H12AffineFastState.Bounded env28345 := by
  intro p hp
  have h : env28345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28344_28345 : H12AffineEnvironment.transform 6 21 env28344 = env28345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 21 env28344 == env28345) = true)

theorem identity28345 : scanCanonicalize (H12AffineFastState.compose env28345 (packedSelected [0,1,2,7,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 39) := by decide +kernel

theorem selectedBound28345 : packedSelected [0,1,2,7,8,11] rootPS < 2^1333 := by decide +kernel

def env28346 : List Nat := [2,4,8,16,32,1,21,21,12,4,39,28,25,1,16,51,1,38,8,17,29,16,1,51,9,28,58,16,0,11,21,0,20,16,17,0]

theorem envBound28346 : H12AffineFastState.Bounded env28346 := by
  intro p hp
  have h : env28346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28345_28346 : H12AffineEnvironment.transform 10 39 env28345 = env28346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 39 env28345 == env28346) = true)

theorem identity28346 : scanCanonicalize (H12AffineFastState.compose env28346 (packedSelected [1,2,4,5,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 22) := by decide +kernel

theorem selectedBound28346 : packedSelected [1,2,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env28347 : List Nat := [2,4,8,16,22,1,21,21,12,4,17,28,25,1,16,5,1,16,8,17,29,16,1,5,9,28,12,16,0,11,21,0,20,16,17,0]

theorem envBound28347 : H12AffineFastState.Bounded env28347 := by
  intro p hp
  have h : env28347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28346_28347 : H12AffineEnvironment.transform 4 22 env28346 = env28347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 22 env28346 == env28347) = true)

theorem identity28347 : scanCanonicalize (H12AffineFastState.compose env28347 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound28347 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env28348 : List Nat := [2,4,8,6,0,1,3,3,12,4,7,10,15,1,6,5,1,6,8,7,11,6,1,5,9,10,12,6,0,11,3,0,2,6,7,0]

theorem envBound28348 : H12AffineFastState.Bounded env28348 := by
  intro p hp
  have h : env28348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28347_28348 : H12AffineEnvironment.transform 3 6 env28347 = env28348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env28347 == env28348) = true)

theorem identity28348 : scanCanonicalize (H12AffineFastState.compose env28348 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound28348 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28349 : List Nat := [2,4,5,6,0,1,3,3,1,4,7,7,2,1,6,5,1,6,5,7,6,6,1,5,4,7,1,6,0,6,3,0,2,6,7,0]

theorem envBound28349 : H12AffineFastState.Bounded env28349 := by
  intro p hp
  have h : env28349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28348_28349 : H12AffineEnvironment.transform 2 5 env28348 = env28349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env28348 == env28349) = true)

theorem identity28349 : scanCanonicalize (H12AffineFastState.compose env28349 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound28349 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28350 : List Nat := [2,1,0,3,0,1,3,3,1,1,2,2,2,1,3,0,1,3,0,2,3,3,1,0,1,2,1,3,0,3,3,0,2,3,2,0]

theorem envBound28350 : H12AffineFastState.Bounded env28350 := by
  intro p hp
  have h : env28350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28349_28350 : H12AffineEnvironment.transform 1 1 env28349 = env28350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env28349 == env28350) = true)

theorem identity28350 : scanCanonicalize (H12AffineFastState.compose env28350 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound28350 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28351 : List Nat := [1,1,0,0,0,1,0,0,1,1,1,1,1,1,0,0,1,0,0,1,0,0,1,0,1,1,1,0,0,0,0,0,1,0,1,0]

theorem envBound28351 : H12AffineFastState.Bounded env28351 := by
  intro p hp
  have h : env28351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28350_28351 : H12AffineEnvironment.transform 0 1 env28350 = env28351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env28350 == env28351) = true)

def env28352 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1557,25,1296,324,65536,66679,65664,1877,325,1556,648,65831,66896,965,66082,1151,66599,1297,68422,21,65830,257,1281,1345,341]

theorem envBound28352 : H12AffineFastState.Bounded env28352 := by
  intro p hp
  have h : env28352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28309_28352 : H12AffineEnvironment.transform 11 1557 env28309 = env28352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1557 env28309 == env28352) = true)

def env28353 : List Nat := [2,4,8,16,32,0,128,256,512,1024,2048,1557,25,1296,260,65536,66615,65664,1813,261,1556,648,65831,66832,901,66082,1087,66599,1297,68358,21,65830,257,1281,1281,277]

theorem envBound28353 : H12AffineFastState.Bounded env28353 := by
  intro p hp
  have h : env28353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28352_28353 : H12AffineEnvironment.transform 5 0 env28352 = env28353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env28352 == env28353) = true)

theorem identity28353 : scanCanonicalize (H12AffineFastState.compose env28353 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 559) := by decide +kernel

theorem selectedBound28353 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env28354 : List Nat := [2,4,8,16,32,0,128,256,512,1024,2048,1557,25,1296,260,559,1560,687,1813,261,1556,648,776,1855,901,13,1087,1544,1297,2345,21,777,257,1281,1281,277]

theorem envBound28354 : H12AffineFastState.Bounded env28354 := by
  intro p hp
  have h : env28354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28353_28354 : H12AffineEnvironment.transform 15 559 env28353 = env28354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 559 env28353 == env28354) = true)

def env28355 : List Nat := [2,4,8,16,32,0,128,256,264,1024,2048,1309,25,1296,260,295,1296,423,1053,261,1308,384,0,1079,141,13,1087,1280,1297,2345,21,1,257,1281,1281,277]

theorem envBound28355 : H12AffineFastState.Bounded env28355 := by
  intro p hp
  have h : env28355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28354_28355 : H12AffineEnvironment.transform 8 264 env28354 = env28355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 264 env28354 == env28355) = true)

theorem identity28355 : scanCanonicalize (H12AffineFastState.compose env28355 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 25) := by decide +kernel

theorem selectedBound28355 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env28356 : List Nat := [2,4,8,16,32,0,128,256,264,25,2048,260,25,265,260,295,265,423,4,261,261,384,0,46,141,13,38,281,264,2345,21,1,257,280,280,277]

theorem envBound28356 : H12AffineFastState.Bounded env28356 := by
  intro p hp
  have h : env28356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28355_28356 : H12AffineEnvironment.transform 9 25 env28355 = env28356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 25 env28355 == env28356) = true)

theorem identity28356 : scanCanonicalize (H12AffineFastState.compose env28356 (packedSelected [0,1,2,7,10,11,17,18,20,21] rootPS)) = affineNative (2^(10+1) ^^^ 162) := by decide +kernel

theorem selectedBound28356 : packedSelected [0,1,2,7,10,11,17,18,20,21] rootPS < 2^1333 := by decide +kernel

def env28357 : List Nat := [2,4,8,16,32,0,128,256,264,25,162,260,25,265,260,295,265,423,4,261,261,384,0,46,141,13,38,281,264,395,21,1,257,280,280,277]

theorem envBound28357 : H12AffineFastState.Bounded env28357 := by
  intro p hp
  have h : env28357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28356_28357 : H12AffineEnvironment.transform 10 162 env28356 = env28357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 162 env28356 == env28357) = true)

theorem identity28357 : scanCanonicalize (H12AffineFastState.compose env28357 (packedSelected [0,1,2,7,10,11,19] rootPS)) = affineNative (2^(7+1) ^^^ 177) := by decide +kernel

theorem selectedBound28357 : packedSelected [0,1,2,7,10,11,19] rootPS < 2^1333 := by decide +kernel

def env28358 : List Nat := [2,4,8,16,32,0,128,177,185,25,162,181,25,184,181,150,184,22,4,180,180,49,0,46,141,13,38,168,185,58,21,1,176,169,169,164]

theorem envBound28358 : H12AffineFastState.Bounded env28358 := by
  intro p hp
  have h : env28358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28357_28358 : H12AffineEnvironment.transform 7 177 env28357 = env28358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 177 env28357 == env28358) = true)

theorem identity28358 : scanCanonicalize (H12AffineFastState.compose env28358 (packedSelected [3,4,5,8,9,12] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound28358 : packedSelected [3,4,5,8,9,12] rootPS < 2^1333 := by decide +kernel

def env28359 : List Nat := [2,4,8,16,12,0,128,157,149,25,142,153,25,148,153,150,148,22,4,152,152,29,0,2,141,13,10,132,149,22,21,1,156,133,133,136]

theorem envBound28359 : H12AffineFastState.Bounded env28359 := by
  intro p hp
  have h : env28359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28358_28359 : H12AffineEnvironment.transform 4 12 env28358 = env28359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env28358 == env28359) = true)

theorem identity28359 : scanCanonicalize (H12AffineFastState.compose env28359 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 30) := by decide +kernel

theorem selectedBound28359 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env28360 : List Nat := [2,4,8,16,12,0,30,3,11,25,16,7,25,10,7,8,10,22,4,6,6,29,0,2,19,13,10,26,11,22,21,1,2,27,27,22]

theorem envBound28360 : H12AffineFastState.Bounded env28360 := by
  intro p hp
  have h : env28360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28359_28360 : H12AffineEnvironment.transform 6 30 env28359 = env28360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 30 env28359 == env28360) = true)

theorem identity28360 : scanCanonicalize (H12AffineFastState.compose env28360 (packedSelected [2,3,5] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound28360 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env28361 : List Nat := [2,2,8,16,10,0,24,3,11,25,16,1,25,10,1,8,10,16,2,0,0,27,0,2,19,11,10,26,11,16,19,1,2,27,27,16]

theorem envBound28361 : H12AffineFastState.Bounded env28361 := by
  intro p hp
  have h : env28361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28360_28361 : H12AffineEnvironment.transform 1 2 env28360 = env28361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env28360 == env28361) = true)

def env28362 : List Nat := [2,4,8,16,32,0,128,256,265,1024,2048,1308,25,1296,260,294,1297,422,1052,261,1309,385,1,1078,140,13,1087,1281,1297,2345,21,0,257,1281,1281,277]

theorem envBound28362 : H12AffineFastState.Bounded env28362 := by
  intro p hp
  have h : env28362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28354_28362 : H12AffineEnvironment.transform 8 265 env28354 = env28362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 265 env28354 == env28362) = true)

theorem identity28362 : scanCanonicalize (H12AffineFastState.compose env28362 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound28362 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env28363 : List Nat := [2,4,8,16,32,0,128,256,265,5,2048,281,25,277,260,294,276,422,25,261,280,385,1,51,140,13,58,260,276,2345,21,0,257,260,260,277]

theorem envBound28363 : H12AffineFastState.Bounded env28363 := by
  intro p hp
  have h : env28363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28362_28363 : H12AffineEnvironment.transform 9 5 env28362 = env28363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env28362 == env28363) = true)

def env28364 : List Nat := [2,4,8,16,32,1,128,256,512,1024,2048,1557,25,1296,261,65536,66614,65664,1812,260,1556,648,65831,66833,900,66082,1086,66599,1297,68359,21,65830,257,1281,1280,276]

theorem envBound28364 : H12AffineFastState.Bounded env28364 := by
  intro p hp
  have h : env28364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28352_28364 : H12AffineEnvironment.transform 5 1 env28352 = env28364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env28352 == env28364) = true)

theorem identity28364 : scanCanonicalize (H12AffineFastState.compose env28364 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 1855) := by decide +kernel

theorem selectedBound28364 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env28365 : List Nat := [2,4,8,16,32,1,128,256,512,1024,2048,1557,25,1296,261,1855,777,1983,1812,260,1556,648,1560,558,900,1309,1086,792,1297,3128,21,1561,257,1281,1280,276]

theorem envBound28365 : H12AffineFastState.Bounded env28365 := by
  intro p hp
  have h : env28365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28364_28365 : H12AffineEnvironment.transform 15 1855 env28364 = env28365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1855 env28364 == env28365) = true)

def env28366 : List Nat := [2,4,8,16,32,1,128,256,264,1024,2048,1309,25,1296,261,1079,1,1207,1052,260,1308,384,1296,294,140,1309,1086,16,1297,3128,21,1297,257,1281,1280,276]

theorem envBound28366 : H12AffineFastState.Bounded env28366 := by
  intro p hp
  have h : env28366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28365_28366 : H12AffineEnvironment.transform 8 264 env28365 = env28366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 264 env28365 == env28366) = true)

theorem identity28366 : scanCanonicalize (H12AffineFastState.compose env28366 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound28366 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env28367 : List Nat := [2,4,8,12,32,1,128,256,264,1024,2048,1281,5,1292,261,1067,1,1195,1024,260,1280,384,1292,294,140,1281,1058,12,1293,3108,9,1293,257,1281,1280,264]

theorem envBound28367 : H12AffineFastState.Bounded env28367 := by
  intro p hp
  have h : env28367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28366_28367 : H12AffineEnvironment.transform 3 12 env28366 = env28367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env28366 == env28367) = true)

theorem identity28367 : scanCanonicalize (H12AffineFastState.compose env28367 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 9) := by decide +kernel

theorem selectedBound28367 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env28368 : List Nat := [2,4,8,12,32,1,128,9,1,1024,2048,1032,5,1029,12,1067,1,1195,1024,13,1033,137,1029,47,140,1032,1058,12,1028,3108,9,1028,8,1032,1033,1]

theorem envBound28368 : H12AffineFastState.Bounded env28368 := by
  intro p hp
  have h : env28368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28367_28368 : H12AffineEnvironment.transform 7 9 env28367 = env28368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 9 env28367 == env28368) = true)

theorem identity28368 : scanCanonicalize (H12AffineFastState.compose env28368 (packedSelected [0,1,2,7,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 1194) := by decide +kernel

theorem selectedBound28368 : packedSelected [0,1,2,7,8,11] rootPS < 2^1333 := by decide +kernel

def env28369 : List Nat := [2,4,8,12,32,1,128,9,1,1024,1194,1032,5,1029,12,1067,1,1195,1024,13,1033,137,1029,47,140,1032,1058,12,1028,142,9,1028,8,1032,1033,1]

theorem envBound28369 : H12AffineFastState.Bounded env28369 := by
  intro p hp
  have h : env28369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28368_28369 : H12AffineEnvironment.transform 10 1194 env28368 = env28369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1194 env28368 == env28369) = true)

theorem identity28369 : scanCanonicalize (H12AffineFastState.compose env28369 (packedSelected [0,2,5,7,9,12] rootPS)) = affineNative (2^(9+1) ^^^ 140) := by decide +kernel

theorem selectedBound28369 : packedSelected [0,2,5,7,9,12] rootPS < 2^1333 := by decide +kernel

def env28370 : List Nat := [2,4,8,12,32,1,128,9,1,140,38,132,5,137,12,167,1,39,140,13,133,137,137,47,140,132,174,12,136,142,9,136,8,132,133,1]

theorem envBound28370 : H12AffineFastState.Bounded env28370 := by
  intro p hp
  have h : env28370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28369_28370 : H12AffineEnvironment.transform 9 140 env28369 = env28370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 140 env28369 == env28370) = true)

theorem identity28370 : scanCanonicalize (H12AffineFastState.compose env28370 (packedSelected [1,2,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound28370 : packedSelected [1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env28371 : List Nat := [2,4,8,12,32,1,41,9,1,37,38,45,5,32,12,14,1,39,37,13,44,32,32,47,37,45,7,12,33,39,9,33,8,45,44,1]

theorem envBound28371 : H12AffineFastState.Bounded env28371 := by
  intro p hp
  have h : env28371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28370_28371 : H12AffineEnvironment.transform 6 41 env28370 = env28371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env28370 == env28371) = true)

theorem identity28371 : scanCanonicalize (H12AffineFastState.compose env28371 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound28371 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28372 : List Nat := [2,4,4,0,32,1,37,5,1,37,38,33,5,32,0,2,1,39,37,1,32,32,32,35,37,33,7,0,33,39,5,33,4,33,32,1]

theorem envBound28372 : H12AffineFastState.Bounded env28372 := by
  intro p hp
  have h : env28372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28371_28372 : H12AffineEnvironment.transform 2 4 env28371 = env28372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env28371 == env28372) = true)

theorem identity28372 : scanCanonicalize (H12AffineFastState.compose env28372 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound28372 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28373 : List Nat := [2,3,3,0,32,1,34,2,1,34,33,33,2,32,0,2,1,32,34,1,32,32,32,35,34,33,0,0,33,32,2,33,3,33,32,1]

theorem envBound28373 : H12AffineFastState.Bounded env28373 := by
  intro p hp
  have h : env28373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28372_28373 : H12AffineEnvironment.transform 1 3 env28372 = env28373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env28372 == env28373) = true)

theorem identity28373 : scanCanonicalize (H12AffineFastState.compose env28373 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound28373 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28374 : List Nat := [2,3,3,0,0,1,2,2,1,2,1,1,2,0,0,2,1,0,2,1,0,0,0,3,2,1,0,0,1,0,2,1,3,1,0,1]

theorem envBound28374 : H12AffineFastState.Bounded env28374 := by
  intro p hp
  have h : env28374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28373_28374 : H12AffineEnvironment.transform 4 0 env28373 = env28374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env28373 == env28374) = true)

def env28375 : List Nat := [2,4,8,16,32,1,128,256,265,1024,2048,1308,25,1296,261,1078,0,1206,1053,260,1309,385,1297,295,141,1309,1086,17,1297,3128,21,1296,257,1281,1280,276]

theorem envBound28375 : H12AffineFastState.Bounded env28375 := by
  intro p hp
  have h : env28375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28365_28375 : H12AffineEnvironment.transform 8 265 env28365 = env28375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 265 env28365 == env28375) = true)

theorem identity28375 : scanCanonicalize (H12AffineFastState.compose env28375 (packedSelected [0,2,3,5,10,13,15,17,21,23,27,32,41] rootPS)) = affineNative (2^(7+1) ^^^ 140) := by decide +kernel

theorem selectedBound28375 : packedSelected [0,2,3,5,10,13,15,17,21,23,27,32,41] rootPS < 2^1333 := by decide +kernel

def env28376 : List Nat := [2,4,8,16,32,1,128,140,133,1024,2048,1168,25,1180,137,1078,0,1206,1053,136,1169,13,1181,171,141,1169,1086,17,1181,3128,21,1180,141,1165,1164,152]

theorem envBound28376 : H12AffineFastState.Bounded env28376 := by
  intro p hp
  have h : env28376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28375_28376 : H12AffineEnvironment.transform 7 140 env28375 = env28376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 140 env28375 == env28376) = true)

theorem identity28376 : scanCanonicalize (H12AffineFastState.compose env28376 (packedSelected [3,4,7,8,9,13,15,17,18,21,23,24,27] rootPS)) = affineNative (2^(10+1) ^^^ 1065) := by decide +kernel

theorem selectedBound28376 : packedSelected [3,4,7,8,9,13,15,17,18,21,23,24,27] rootPS < 2^1333 := by decide +kernel

def env28377 : List Nat := [2,4,8,16,32,1,128,140,133,1024,1065,1168,25,1180,137,1078,0,1206,1053,136,1169,13,1181,171,141,1169,1086,17,1181,17,21,1180,141,1165,1164,152]

theorem envBound28377 : H12AffineFastState.Bounded env28377 := by
  intro p hp
  have h : env28377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28376_28377 : H12AffineEnvironment.transform 10 1065 env28376 = env28377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1065 env28376 == env28377) = true)

theorem identity28377 : scanCanonicalize (H12AffineFastState.compose env28377 (packedSelected [1,3,5,12,13,17,18] rootPS)) = affineNative (2^(9+1) ^^^ 19) := by decide +kernel

theorem selectedBound28377 : packedSelected [1,3,5,12,13,17,18] rootPS < 2^1333 := by decide +kernel

def env28378 : List Nat := [2,4,8,16,32,1,128,140,133,19,58,131,25,143,137,37,0,165,14,136,130,13,142,171,141,130,45,17,142,17,21,143,141,158,159,152]

theorem envBound28378 : H12AffineFastState.Bounded env28378 := by
  intro p hp
  have h : env28378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28377_28378 : H12AffineEnvironment.transform 9 19 env28377 = env28378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 19 env28377 == env28378) = true)

theorem identity28378 : scanCanonicalize (H12AffineFastState.compose env28378 (packedSelected [1,5,12] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound28378 : packedSelected [1,5,12] rootPS < 2^1333 := by decide +kernel

def env28379 : List Nat := [2,4,8,16,32,1,56,52,61,19,58,59,25,55,49,37,0,29,14,48,58,13,54,19,53,58,45,17,54,17,21,55,53,38,39,32]

theorem envBound28379 : H12AffineFastState.Bounded env28379 := by
  intro p hp
  have h : env28379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28378_28379 : H12AffineEnvironment.transform 6 56 env28378 = env28379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env28378 == env28379) = true)

theorem identity28379 : scanCanonicalize (H12AffineFastState.compose env28379 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound28379 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env28380 : List Nat := [2,3,8,16,32,1,56,51,58,19,58,59,25,48,49,34,0,26,9,48,58,10,49,19,50,58,42,17,49,17,18,48,50,33,32,32]

theorem envBound28380 : H12AffineFastState.Bounded env28380 := by
  intro p hp
  have h : env28380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28379_28380 : H12AffineEnvironment.transform 1 3 env28379 = env28380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env28379 == env28380) = true)

theorem identity28380 : scanCanonicalize (H12AffineFastState.compose env28380 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound28380 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env28381 : List Nat := [2,3,8,10,32,1,34,41,32,9,32,33,3,42,43,34,0,0,9,42,32,10,43,9,40,32,42,11,43,11,8,42,40,33,32,32]

theorem envBound28381 : H12AffineFastState.Bounded env28381 := by
  intro p hp
  have h : env28381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28380_28381 : H12AffineEnvironment.transform 3 10 env28380 = env28381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env28380 == env28381) = true)

theorem identity28381 : scanCanonicalize (H12AffineFastState.compose env28381 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound28381 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28382 : List Nat := [2,3,8,10,0,1,2,9,0,9,0,1,3,10,11,2,0,0,9,10,0,10,11,9,8,0,10,11,11,11,8,10,8,1,0,0]

theorem envBound28382 : H12AffineFastState.Bounded env28382 := by
  intro p hp
  have h : env28382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28381_28382 : H12AffineEnvironment.transform 4 0 env28381 = env28382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env28381 == env28382) = true)

theorem identity28382 : scanCanonicalize (H12AffineFastState.compose env28382 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound28382 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env28383 : List Nat := [2,3,2,0,0,1,2,3,0,3,0,1,3,0,1,2,0,0,3,0,0,0,1,3,2,0,0,1,1,1,2,0,2,1,0,0]

theorem envBound28383 : H12AffineFastState.Bounded env28383 := by
  intro p hp
  have h : env28383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28382_28383 : H12AffineEnvironment.transform 2 2 env28382 = env28383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env28382 == env28383) = true)

def env28384 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74862,65665,4416,8540,4097,5277,74046,66896,13769,78894,1150,74814,1297,81226,8204,65830,257,1281,1345,5952]

theorem envBound28384 : H12AffineFastState.Bounded env28384 := by
  intro p hp
  have h : env28384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28307_28384 : H12AffineEnvironment.transform 17 65665 env28307 = env28384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env28307 == env28384) = true)

theorem identity28384 : scanCanonicalize (H12AffineFastState.compose env28384 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5464) := by decide +kernel

theorem selectedBound28384 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env28385 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5464,1296,5125,65536,69942,65665,4416,5124,4097,5277,70758,66896,145,65910,1150,69990,1297,67602,5460,65830,257,1281,1345,5952]

theorem envBound28385 : H12AffineFastState.Bounded env28385 := by
  intro p hp
  have h : env28385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28384_28385 : H12AffineEnvironment.transform 12 5464 env28384 = env28385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5464 env28384 == env28385) = true)

def env28386 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1556,844,1296,529,65536,67362,65665,1876,528,1557,649,66162,66896,145,65910,1150,67442,1297,67602,832,65830,257,1281,1345,340]

theorem envBound28386 : H12AffineFastState.Bounded env28386 := by
  intro p hp
  have h : env28386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28385_28386 : H12AffineEnvironment.transform 11 1556 env28385 = env28386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1556 env28385 == env28386) = true)

def env28387 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,836,844,64,529,65536,66162,65665,516,528,837,649,66162,65536,145,65910,302,66082,65,67602,832,65830,257,81,17,340]

theorem envBound28387 : H12AffineFastState.Bounded env28387 := by
  intro p hp
  have h : env28387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28386_28387 : H12AffineEnvironment.transform 9 336 env28386 = env28387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 336 env28386 == env28387) = true)

theorem identity28387 : scanCanonicalize (H12AffineFastState.compose env28387 (packedSelected [1,8,28] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound28387 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env28388 : List Nat := [2,4,4,16,32,64,128,256,512,336,2048,836,832,64,529,65536,66162,65665,516,528,837,645,66162,65536,145,65910,290,66082,65,67602,832,65830,257,81,17,340]

theorem envBound28388 : H12AffineFastState.Bounded env28388 := by
  intro p hp
  have h : env28388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28387_28388 : H12AffineEnvironment.transform 2 4 env28387 = env28388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env28387 == env28388) = true)

def env28389 : List Nat := [2,4,4,0,32,64,128,256,512,320,2048,836,832,64,513,65536,66146,65665,516,512,837,645,66146,65536,129,65894,290,66082,65,67586,832,65830,257,65,1,324]

theorem envBound28389 : H12AffineFastState.Bounded env28389 := by
  intro p hp
  have h : env28389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28388_28389 : H12AffineEnvironment.transform 3 0 env28388 = env28389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env28388 == env28389) = true)

theorem identity28389 : scanCanonicalize (H12AffineFastState.compose env28389 (packedSelected [0,3,4,5,7,8,9,10,11,13,15,32] rootPS)) = affineNative (2^(7+1) ^^^ 128) := by decide +kernel

theorem selectedBound28389 : packedSelected [0,3,4,5,7,8,9,10,11,13,15,32] rootPS < 2^1333 := by decide +kernel

def env28390 : List Nat := [2,4,4,0,32,64,128,128,512,192,2048,708,704,64,513,65536,66146,65665,516,512,709,645,66146,65536,129,65766,162,66082,65,67586,704,65702,129,65,1,196]

theorem envBound28390 : H12AffineFastState.Bounded env28390 := by
  intro p hp
  have h : env28390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28389_28390 : H12AffineEnvironment.transform 7 128 env28389 = env28390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 128 env28389 == env28390) = true)

theorem identity28390 : scanCanonicalize (H12AffineFastState.compose env28390 (packedSelected [0,2,3,5,7,8,10,11,13,15,17,18,19,20,24] rootPS)) = affineNative (2^(10+1) ^^^ 131) := by decide +kernel

theorem selectedBound28390 : packedSelected [0,2,3,5,7,8,10,11,13,15,17,18,19,20,24] rootPS < 2^1333 := by decide +kernel

def env28391 : List Nat := [2,4,4,0,32,64,128,128,512,192,131,708,704,64,513,65536,66146,65665,516,512,709,645,66146,65536,129,65766,162,66082,65,65665,704,65702,129,65,1,196]

theorem envBound28391 : H12AffineFastState.Bounded env28391 := by
  intro p hp
  have h : env28391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28390_28391 : H12AffineEnvironment.transform 10 131 env28390 = env28391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 131 env28390 == env28391) = true)

theorem identity28391 : scanCanonicalize (H12AffineFastState.compose env28391 (packedSelected [0,7,16] rootPS)) = affineNative (2^(15+1) ^^^ 710) := by decide +kernel

theorem selectedBound28391 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env28392 : List Nat := [2,4,4,0,32,64,128,128,512,192,131,708,704,64,513,710,164,583,516,512,709,645,164,710,129,544,162,228,65,583,704,608,129,65,1,196]

theorem envBound28392 : H12AffineFastState.Bounded env28392 := by
  intro p hp
  have h : env28392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28391_28392 : H12AffineEnvironment.transform 15 710 env28391 = env28392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 710 env28391 == env28392) = true)

theorem identity28392 : scanCanonicalize (H12AffineFastState.compose env28392 (packedSelected [0,1,3,7,10,11,12] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound28392 : packedSelected [0,1,3,7,10,11,12] rootPS < 2^1333 := by decide +kernel

def env28393 : List Nat := [2,4,4,0,6,64,128,128,512,192,131,708,704,64,513,710,130,583,516,512,709,645,130,710,129,518,132,194,65,583,704,582,129,65,1,196]

theorem envBound28393 : H12AffineFastState.Bounded env28393 := by
  intro p hp
  have h : env28393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28392_28393 : H12AffineEnvironment.transform 4 6 env28392 = env28393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env28392 == env28393) = true)

theorem identity28393 : scanCanonicalize (H12AffineFastState.compose env28393 (packedSelected [1,8] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound28393 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env28394 : List Nat := [2,4,4,0,6,64,5,5,512,69,6,577,581,64,513,579,7,583,516,512,576,512,7,579,4,518,1,71,65,583,581,582,4,65,1,65]

theorem envBound28394 : H12AffineFastState.Bounded env28394 := by
  intro p hp
  have h : env28394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28393_28394 : H12AffineEnvironment.transform 6 5 env28393 = env28394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env28393 == env28394) = true)

theorem identity28394 : scanCanonicalize (H12AffineFastState.compose env28394 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 65) := by decide +kernel

theorem selectedBound28394 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28395 : List Nat := [2,4,4,0,6,64,5,5,65,69,6,0,4,64,64,2,7,6,69,65,1,65,7,2,4,71,1,71,65,6,4,7,4,65,1,65]

theorem envBound28395 : H12AffineFastState.Bounded env28395 := by
  intro p hp
  have h : env28395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28394_28395 : H12AffineEnvironment.transform 8 65 env28394 = env28395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 65 env28394 == env28395) = true)

theorem identity28395 : scanCanonicalize (H12AffineFastState.compose env28395 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound28395 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28396 : List Nat := [2,3,3,0,1,64,2,2,65,66,1,0,3,64,64,2,0,1,66,65,1,65,0,2,3,64,1,64,65,1,3,0,3,65,1,65]

theorem envBound28396 : H12AffineFastState.Bounded env28396 := by
  intro p hp
  have h : env28396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28395_28396 : H12AffineEnvironment.transform 1 3 env28395 = env28396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env28395 == env28396) = true)

def env28397 : List Nat := [2,4,4,1,32,64,128,256,512,321,2048,836,832,64,512,65536,66147,65665,516,513,837,645,66147,65536,128,65895,290,66082,65,67587,832,65830,257,64,0,325]

theorem envBound28397 : H12AffineFastState.Bounded env28397 := by
  intro p hp
  have h : env28397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28388_28397 : H12AffineEnvironment.transform 3 1 env28388 = env28397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env28388 == env28397) = true)

theorem identity28397 : scanCanonicalize (H12AffineFastState.compose env28397 (packedSelected [1,3,5,7,8,10,19,20,27] rootPS)) = affineNative (2^(8+1) ^^^ 325) := by decide +kernel

theorem selectedBound28397 : packedSelected [1,3,5,7,8,10,19,20,27] rootPS < 2^1333 := by decide +kernel

def env28398 : List Nat := [2,4,4,1,32,64,128,256,325,321,2048,1,5,64,325,65536,65830,65665,321,324,0,448,65830,65536,128,65895,290,65895,65,67587,5,65830,257,64,0,325]

theorem envBound28398 : H12AffineFastState.Bounded env28398 := by
  intro p hp
  have h : env28398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28397_28398 : H12AffineEnvironment.transform 8 325 env28397 = env28398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 325 env28397 == env28398) = true)

theorem identity28398 : scanCanonicalize (H12AffineFastState.compose env28398 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound28398 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env28399 : List Nat := [2,4,4,1,32,64,128,256,325,321,2048,1,5,64,325,35,261,162,321,324,0,448,261,35,128,324,290,324,65,2080,5,261,257,64,0,325]

theorem envBound28399 : H12AffineFastState.Bounded env28399 := by
  intro p hp
  have h : env28399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28398_28399 : H12AffineEnvironment.transform 15 35 env28398 = env28399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env28398 == env28399) = true)

theorem identity28399 : scanCanonicalize (H12AffineFastState.compose env28399 (packedSelected [0,2,3,7,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 357) := by decide +kernel

theorem selectedBound28399 : packedSelected [0,2,3,7,11,12] rootPS < 2^1333 := by decide +kernel

def env28400 : List Nat := [2,4,4,1,32,64,128,256,325,321,357,1,5,64,325,35,261,162,321,324,0,448,261,35,128,324,290,324,65,325,5,261,257,64,0,325]

theorem envBound28400 : H12AffineFastState.Bounded env28400 := by
  intro p hp
  have h : env28400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28399_28400 : H12AffineEnvironment.transform 10 357 env28399 = env28400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 357 env28399 == env28400) = true)

theorem identity28400 : scanCanonicalize (H12AffineFastState.compose env28400 (packedSelected [1,2,3,7,8,10,11] rootPS)) = affineNative (2^(7+1) ^^^ 135) := by decide +kernel

theorem selectedBound28400 : packedSelected [1,2,3,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env28401 : List Nat := [2,4,4,1,32,64,128,135,194,198,226,1,5,64,194,35,130,162,198,195,0,71,130,35,128,195,165,195,65,194,5,130,134,64,0,194]

theorem envBound28401 : H12AffineFastState.Bounded env28401 := by
  intro p hp
  have h : env28401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28400_28401 : H12AffineEnvironment.transform 7 135 env28400 = env28401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 135 env28400 == env28401) = true)

theorem identity28401 : scanCanonicalize (H12AffineFastState.compose env28401 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 39) := by decide +kernel

theorem selectedBound28401 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28402 : List Nat := [2,4,4,1,32,39,128,135,165,161,133,1,5,39,165,35,130,162,161,164,0,32,130,35,128,164,165,164,38,165,5,130,134,39,0,165]

theorem envBound28402 : H12AffineFastState.Bounded env28402 := by
  intro p hp
  have h : env28402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28401_28402 : H12AffineEnvironment.transform 5 39 env28401 = env28402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 39 env28401 == env28402) = true)

theorem identity28402 : scanCanonicalize (H12AffineFastState.compose env28402 (packedSelected [0,2,4] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound28402 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env28403 : List Nat := [2,4,4,1,32,39,4,3,33,37,1,1,5,39,33,35,6,38,37,32,0,32,6,35,4,32,33,32,38,33,5,6,2,39,0,33]

theorem envBound28403 : H12AffineFastState.Bounded env28403 := by
  intro p hp
  have h : env28403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28402_28403 : H12AffineEnvironment.transform 6 4 env28402 = env28403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env28402 == env28403) = true)

theorem identity28403 : scanCanonicalize (H12AffineFastState.compose env28403 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound28403 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28404 : List Nat := [2,3,3,1,32,32,3,3,33,34,1,1,2,32,33,35,1,33,34,32,0,32,1,35,3,32,33,32,33,33,2,1,2,32,0,33]

theorem envBound28404 : H12AffineFastState.Bounded env28404 := by
  intro p hp
  have h : env28404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28403_28404 : H12AffineEnvironment.transform 1 3 env28403 = env28404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env28403 == env28404) = true)

theorem identity28404 : scanCanonicalize (H12AffineFastState.compose env28404 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound28404 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28405 : List Nat := [2,3,3,1,1,1,3,3,0,3,1,1,2,1,0,2,1,0,3,1,0,1,1,2,3,1,0,1,0,0,2,1,2,1,0,0]

theorem envBound28405 : H12AffineFastState.Bounded env28405 := by
  intro p hp
  have h : env28405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28404_28405 : H12AffineEnvironment.transform 4 1 env28404 = env28405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env28404 == env28405) = true)

def env28406 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,837,844,65,529,65536,66163,65665,517,528,836,649,66162,65537,145,65910,303,66083,64,67602,832,65830,257,80,16,340]

theorem envBound28406 : H12AffineFastState.Bounded env28406 := by
  intro p hp
  have h : env28406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28386_28406 : H12AffineEnvironment.transform 9 337 env28386 = env28406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 337 env28386 == env28406) = true)

theorem identity28406 : scanCanonicalize (H12AffineFastState.compose env28406 (packedSelected [1,8,28] rootPS)) = affineNative (2^(8+1) ^^^ 281) := by decide +kernel

theorem selectedBound28406 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env28407 : List Nat := [2,4,8,16,32,64,128,256,281,337,2048,92,85,65,264,65536,65898,65665,284,265,93,400,65899,65537,145,65910,303,65850,64,67602,89,65830,257,80,16,340]

theorem envBound28407 : H12AffineFastState.Bounded env28407 := by
  intro p hp
  have h : env28407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28406_28407 : H12AffineEnvironment.transform 8 281 env28406 = env28407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 281 env28406 == env28407) = true)

def env28408 : List Nat := [2,4,8,16,32,0,128,256,281,273,2048,28,21,1,264,65536,65834,65665,284,265,29,400,65835,65537,145,65846,303,65850,0,67602,25,65830,257,16,16,276]

theorem envBound28408 : H12AffineFastState.Bounded env28408 := by
  intro p hp
  have h : env28408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28407_28408 : H12AffineEnvironment.transform 5 0 env28407 = env28408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env28407 == env28408) = true)

theorem identity28408 : scanCanonicalize (H12AffineFastState.compose env28408 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 62) := by decide +kernel

theorem selectedBound28408 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env28409 : List Nat := [2,4,8,16,32,0,128,256,281,273,2048,28,21,1,264,62,276,191,284,265,29,400,277,63,145,264,303,260,0,2092,25,280,257,16,16,276]

theorem envBound28409 : H12AffineFastState.Bounded env28409 := by
  intro p hp
  have h : env28409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28408_28409 : H12AffineEnvironment.transform 15 62 env28408 = env28409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62 env28408 == env28409) = true)

theorem identity28409 : scanCanonicalize (H12AffineFastState.compose env28409 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound28409 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env28410 : List Nat := [2,4,8,16,32,0,128,21,12,4,2048,28,21,1,29,62,1,191,9,28,29,133,0,63,145,29,58,17,0,2092,25,13,20,16,16,1]

theorem envBound28410 : H12AffineFastState.Bounded env28410 := by
  intro p hp
  have h : env28410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28409_28410 : H12AffineEnvironment.transform 7 21 env28409 = env28410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env28409 == env28410) = true)

def env28411 : List Nat := [2,4,8,16,32,1,128,256,281,272,2048,29,20,0,264,65536,65835,65665,284,265,28,400,65834,65537,145,65847,303,65850,1,67602,24,65830,257,17,16,277]

theorem envBound28411 : H12AffineFastState.Bounded env28411 := by
  intro p hp
  have h : env28411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28407_28411 : H12AffineEnvironment.transform 5 1 env28407 = env28411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env28407 == env28411) = true)

theorem identity28411 : scanCanonicalize (H12AffineFastState.compose env28411 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 51) := by decide +kernel

theorem selectedBound28411 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env28412 : List Nat := [2,4,8,16,32,1,128,256,281,272,2048,29,20,0,264,51,280,178,284,265,28,400,281,50,145,260,303,265,1,2081,24,277,257,17,16,277]

theorem envBound28412 : H12AffineFastState.Bounded env28412 := by
  intro p hp
  have h : env28412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28411_28412 : H12AffineEnvironment.transform 15 51 env28411 = env28412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 51 env28411 == env28412) = true)

theorem identity28412 : scanCanonicalize (H12AffineFastState.compose env28412 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 24) := by decide +kernel

theorem selectedBound28412 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env28413 : List Nat := [2,4,8,16,32,1,128,24,1,8,2048,29,20,0,16,51,0,178,4,17,28,136,1,50,145,28,55,17,1,2081,24,13,25,17,16,13]

theorem envBound28413 : H12AffineFastState.Bounded env28413 := by
  intro p hp
  have h : env28413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28412_28413 : H12AffineEnvironment.transform 7 24 env28412 = env28413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 24 env28412 == env28413) = true)

theorem identity28413 : scanCanonicalize (H12AffineFastState.compose env28413 (packedSelected [10,12] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound28413 : packedSelected [10,12] rootPS < 2^1333 := by decide +kernel

def env28414 : List Nat := [2,4,8,16,32,1,128,24,1,8,0,29,20,0,16,51,0,178,4,17,28,136,1,50,145,28,55,17,1,33,24,13,25,17,16,13]

theorem envBound28414 : H12AffineFastState.Bounded env28414 := by
  intro p hp
  have h : env28414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28413_28414 : H12AffineEnvironment.transform 10 0 env28413 = env28414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env28413 == env28414) = true)

theorem identity28414 : scanCanonicalize (H12AffineFastState.compose env28414 (packedSelected [1,2,5,8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound28414 : packedSelected [1,2,5,8] rootPS < 2^1333 := by decide +kernel

def env28415 : List Nat := [2,4,8,0,32,1,128,8,1,8,0,13,4,0,0,35,0,162,4,1,12,136,1,34,129,12,39,1,1,33,8,13,9,1,0,13]

theorem envBound28415 : H12AffineFastState.Bounded env28415 := by
  intro p hp
  have h : env28415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28414_28415 : H12AffineEnvironment.transform 3 0 env28414 = env28415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env28414 == env28415) = true)

theorem identity28415 : scanCanonicalize (H12AffineFastState.compose env28415 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound28415 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28416 : List Nat := [2,4,8,0,1,1,128,8,1,8,0,13,4,0,0,2,0,131,4,1,12,136,1,3,129,12,6,1,1,0,8,13,9,1,0,13]

theorem envBound28416 : H12AffineFastState.Bounded env28416 := by
  intro p hp
  have h : env28416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28415_28416 : H12AffineEnvironment.transform 4 1 env28415 = env28416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env28415 == env28416) = true)

theorem identity28416 : scanCanonicalize (H12AffineFastState.compose env28416 (packedSelected [0,3,4] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound28416 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env28417 : List Nat := [2,4,5,0,1,1,128,5,1,5,0,0,4,0,0,2,0,131,4,1,1,133,1,3,129,1,6,1,1,0,5,0,4,1,0,0]

theorem envBound28417 : H12AffineFastState.Bounded env28417 := by
  intro p hp
  have h : env28417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28416_28417 : H12AffineEnvironment.transform 2 5 env28416 = env28417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env28416 == env28417) = true)

theorem identity28417 : scanCanonicalize (H12AffineFastState.compose env28417 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 1) := by decide +kernel

theorem selectedBound28417 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28418 : List Nat := [2,4,5,0,1,1,1,5,1,5,0,0,4,0,0,2,0,2,4,1,1,4,1,3,0,1,6,1,1,0,5,0,4,1,0,0]

theorem envBound28418 : H12AffineFastState.Bounded env28418 := by
  intro p hp
  have h : env28418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28417_28418 : H12AffineEnvironment.transform 6 1 env28417 = env28418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 1 env28417 == env28418) = true)

theorem identity28418 : scanCanonicalize (H12AffineFastState.compose env28418 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound28418 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28419 : List Nat := [0,4,5,0,1,1,1,5,1,5,0,0,4,0,0,0,0,0,4,1,1,4,1,1,0,1,4,1,1,0,5,0,4,1,0,0]

theorem envBound28419 : H12AffineFastState.Bounded env28419 := by
  intro p hp
  have h : env28419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28418_28419 : H12AffineEnvironment.transform 0 0 env28418 = env28419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env28418 == env28419) = true)

theorem identity28419 : scanCanonicalize (H12AffineFastState.compose env28419 (packedSelected [5] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound28419 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env28420 : List Nat := [0,0,1,0,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,1,1,0,1,1,0,1,0,1,1,0,1,0,0,1,0,0]

theorem envBound28420 : H12AffineFastState.Bounded env28420 := by
  intro p hp
  have h : env28420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28419_28420 : H12AffineEnvironment.transform 1 0 env28419 = env28420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env28419 == env28420) = true)

def env28421 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1557,845,1296,528,65536,67363,65665,1877,529,1556,648,66163,66896,145,65910,1150,67443,1297,67602,833,65830,257,1281,1345,341]

theorem envBound28421 : H12AffineFastState.Bounded env28421 := by
  intro p hp
  have h : env28421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28385_28421 : H12AffineEnvironment.transform 11 1557 env28385 = env28421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1557 env28385 == env28421) = true)

def env28422 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,837,845,64,528,65536,66163,65665,517,529,836,648,66163,65536,145,65910,302,66083,65,67602,833,65830,257,81,17,341]

theorem envBound28422 : H12AffineFastState.Bounded env28422 := by
  intro p hp
  have h : env28422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28421_28422 : H12AffineEnvironment.transform 9 336 env28421 = env28422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 336 env28421 == env28422) = true)

theorem identity28422 : scanCanonicalize (H12AffineFastState.compose env28422 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 622) := by decide +kernel

theorem selectedBound28422 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env28423 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,837,845,64,528,622,29,751,517,529,836,648,29,622,145,792,302,77,65,2684,833,840,257,81,17,341]

theorem envBound28423 : H12AffineFastState.Bounded env28423 := by
  intro p hp
  have h : env28423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28422_28423 : H12AffineEnvironment.transform 15 622 env28422 = env28423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 622 env28422 == env28423) = true)

def env28424 : List Nat := [2,4,8,16,32,64,128,256,16,336,2048,341,349,64,0,126,29,255,21,1,340,152,29,126,145,264,302,77,65,2156,337,344,257,81,17,341]

theorem envBound28424 : H12AffineFastState.Bounded env28424 := by
  intro p hp
  have h : env28424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28423_28424 : H12AffineEnvironment.transform 8 16 env28423 = env28424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env28423 == env28424) = true)

theorem identity28424 : scanCanonicalize (H12AffineFastState.compose env28424 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 29) := by decide +kernel

theorem selectedBound28424 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env28425 : List Nat := [2,4,8,16,32,29,128,256,16,269,2048,264,256,29,0,35,29,162,21,1,265,152,29,35,145,264,302,16,28,2097,268,261,257,12,17,264]

theorem envBound28425 : H12AffineFastState.Bounded env28425 := by
  intro p hp
  have h : env28425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28424_28425 : H12AffineEnvironment.transform 5 29 env28424 = env28425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 29 env28424 == env28425) = true)

theorem identity28425 : scanCanonicalize (H12AffineFastState.compose env28425 (packedSelected [4,9,16] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound28425 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env28426 : List Nat := [2,4,8,1,32,12,128,256,1,269,2048,264,256,12,0,35,12,162,4,1,265,137,12,35,128,264,302,1,13,2080,268,261,257,12,0,264]

theorem envBound28426 : H12AffineFastState.Bounded env28426 := by
  intro p hp
  have h : env28426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28425_28426 : H12AffineEnvironment.transform 3 1 env28425 = env28426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env28425 == env28426) = true)

theorem identity28426 : scanCanonicalize (H12AffineFastState.compose env28426 (packedSelected [5,10] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound28426 : packedSelected [5,10] rootPS < 2^1333 := by decide +kernel

def env28427 : List Nat := [2,4,8,1,32,12,2,256,1,269,2048,264,256,12,0,35,12,32,4,1,265,11,12,35,2,264,302,1,13,2080,268,261,257,12,0,264]

theorem envBound28427 : H12AffineFastState.Bounded env28427 := by
  intro p hp
  have h : env28427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28426_28427 : H12AffineEnvironment.transform 6 2 env28426 = env28427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env28426 == env28427) = true)

theorem identity28427 : scanCanonicalize (H12AffineFastState.compose env28427 (packedSelected [2,3,5,13] rootPS)) = affineNative (2^(7+1) ^^^ 2) := by decide +kernel

theorem selectedBound28427 : packedSelected [2,3,5,13] rootPS < 2^1333 := by decide +kernel

def env28428 : List Nat := [2,4,8,1,32,12,2,2,1,15,2048,10,2,12,0,35,12,32,4,1,11,11,12,35,2,10,44,1,13,2080,14,7,3,12,0,10]

theorem envBound28428 : H12AffineFastState.Bounded env28428 := by
  intro p hp
  have h : env28428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28427_28428 : H12AffineEnvironment.transform 7 2 env28427 = env28428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 2 env28427 == env28428) = true)

theorem identity28428 : scanCanonicalize (H12AffineFastState.compose env28428 (packedSelected [0,1,2,3,4,5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound28428 : packedSelected [0,1,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env28429 : List Nat := [2,4,3,1,32,7,2,2,1,4,2048,1,2,7,0,35,7,32,4,1,0,0,7,35,2,1,39,1,6,2080,5,7,3,7,0,1]

theorem envBound28429 : H12AffineFastState.Bounded env28429 := by
  intro p hp
  have h : env28429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28428_28429 : H12AffineEnvironment.transform 2 3 env28428 = env28429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env28428 == env28429) = true)

def env28430 : List Nat := [2,4,8,16,32,64,128,256,17,336,2048,340,348,64,1,127,29,254,20,0,341,153,29,127,145,265,302,77,65,2157,336,345,257,81,17,341]

theorem envBound28430 : H12AffineFastState.Bounded env28430 := by
  intro p hp
  have h : env28430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28423_28430 : H12AffineEnvironment.transform 8 17 env28423 = env28430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env28423 == env28430) = true)

theorem identity28430 : scanCanonicalize (H12AffineFastState.compose env28430 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound28430 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env28431 : List Nat := [2,4,8,16,32,64,128,84,17,4,2048,0,8,64,1,127,29,254,20,0,1,153,29,127,145,93,122,77,65,2157,4,13,85,81,17,1]

theorem envBound28431 : H12AffineFastState.Bounded env28431 := by
  intro p hp
  have h : env28431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28430_28431 : H12AffineEnvironment.transform 7 84 env28430 = env28431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env28430 == env28431) = true)

theorem identity28431 : scanCanonicalize (H12AffineFastState.compose env28431 (packedSelected [0,2,3,7,8,11,12,15] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound28431 : packedSelected [0,2,3,7,8,11,12,15] rootPS < 2^1333 := by decide +kernel

def env28432 : List Nat := [2,4,8,16,17,64,128,84,17,4,2048,0,8,64,1,78,29,207,20,0,1,153,29,78,145,93,75,77,65,2140,4,13,85,81,17,1]

theorem envBound28432 : H12AffineFastState.Bounded env28432 := by
  intro p hp
  have h : env28432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28431_28432 : H12AffineEnvironment.transform 4 17 env28431 = env28432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env28431 == env28432) = true)

theorem identity28432 : scanCanonicalize (H12AffineFastState.compose env28432 (packedSelected [3,10,17] rootPS)) = affineNative (2^(10+1) ^^^ 27) := by decide +kernel

theorem selectedBound28432 : packedSelected [3,10,17] rootPS < 2^1333 := by decide +kernel

def env28433 : List Nat := [2,4,8,16,17,64,128,84,17,4,27,0,8,64,1,78,29,207,20,0,1,153,29,78,145,93,75,77,65,71,4,13,85,81,17,1]

theorem envBound28433 : H12AffineFastState.Bounded env28433 := by
  intro p hp
  have h : env28433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28432_28433 : H12AffineEnvironment.transform 10 27 env28432 = env28433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 27 env28432 == env28433) = true)

theorem identity28433 : scanCanonicalize (H12AffineFastState.compose env28433 (packedSelected [4,5,8,9,10,11] rootPS)) = affineNative (2^(6+1) ^^^ 83) := by decide +kernel

theorem selectedBound28433 : packedSelected [4,5,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env28434 : List Nat := [2,4,8,16,17,64,83,84,17,4,27,0,8,64,1,78,29,28,20,0,1,74,29,78,66,93,75,77,65,71,4,13,85,81,17,1]

theorem envBound28434 : H12AffineFastState.Bounded env28434 := by
  intro p hp
  have h : env28434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28433_28434 : H12AffineEnvironment.transform 6 83 env28433 = env28434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 83 env28433 == env28434) = true)

theorem identity28434 : scanCanonicalize (H12AffineFastState.compose env28434 (packedSelected [0,1,4] rootPS)) = affineNative (2^(5+1) ^^^ 7) := by decide +kernel

theorem selectedBound28434 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env28435 : List Nat := [2,4,8,16,17,7,20,19,17,4,27,0,8,7,1,9,29,28,20,0,1,13,29,9,5,26,12,10,6,0,4,13,18,22,17,1]

theorem envBound28435 : H12AffineFastState.Bounded env28435 := by
  intro p hp
  have h : env28435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28434_28435 : H12AffineEnvironment.transform 5 7 env28434 = env28435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 7 env28434 == env28435) = true)

theorem identity28435 : scanCanonicalize (H12AffineFastState.compose env28435 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound28435 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env28436 : List Nat := [2,4,5,16,17,7,20,19,17,4,22,0,5,7,1,4,16,17,20,0,1,0,16,4,5,23,1,7,6,0,4,0,18,22,17,1]

theorem envBound28436 : H12AffineFastState.Bounded env28436 := by
  intro p hp
  have h : env28436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28435_28436 : H12AffineEnvironment.transform 2 5 env28435 = env28436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env28435 == env28436) = true)

def env28437 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,836,845,65,528,65536,66162,65665,516,529,837,648,66163,65537,145,65910,303,66082,64,67602,833,65830,257,80,16,341]

theorem envBound28437 : H12AffineFastState.Bounded env28437 := by
  intro p hp
  have h : env28437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28421_28437 : H12AffineEnvironment.transform 9 337 env28421 = env28437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 337 env28421 == env28437) = true)

theorem identity28437 : scanCanonicalize (H12AffineFastState.compose env28437 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 378) := by decide +kernel

theorem selectedBound28437 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env28438 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,836,845,65,528,378,776,507,516,529,837,648,777,379,145,12,303,856,64,2408,833,92,257,80,16,341]

theorem envBound28438 : H12AffineFastState.Bounded env28438 := by
  intro p hp
  have h : env28438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28437_28438 : H12AffineEnvironment.transform 15 378 env28437 = env28438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 378 env28437 == env28438) = true)

def env28439 : List Nat := [2,4,8,16,32,64,128,256,16,337,2048,340,349,65,0,378,280,507,20,1,341,152,281,379,145,12,303,328,64,2408,337,92,257,80,16,341]

theorem envBound28439 : H12AffineFastState.Bounded env28439 := by
  intro p hp
  have h : env28439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28438_28439 : H12AffineEnvironment.transform 8 16 env28438 = env28439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env28438 == env28439) = true)

theorem identity28439 : scanCanonicalize (H12AffineFastState.compose env28439 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 89) := by decide +kernel

theorem selectedBound28439 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env28440 : List Nat := [2,4,8,16,32,64,128,89,16,8,2048,13,4,65,0,35,65,162,20,1,12,152,64,34,145,12,118,17,64,2097,8,92,88,80,16,12]

theorem envBound28440 : H12AffineFastState.Bounded env28440 := by
  intro p hp
  have h : env28440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28439_28440 : H12AffineEnvironment.transform 7 89 env28439 = env28440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 89 env28439 == env28440) = true)

theorem identity28440 : scanCanonicalize (H12AffineFastState.compose env28440 (packedSelected [4,9,16] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound28440 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env28441 : List Nat := [2,4,8,0,32,64,128,73,0,8,2048,13,4,65,0,35,65,162,4,1,12,136,64,34,129,12,102,1,64,2081,8,76,72,64,0,12]

theorem envBound28441 : H12AffineFastState.Bounded env28441 := by
  intro p hp
  have h : env28441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28440_28441 : H12AffineEnvironment.transform 3 0 env28440 = env28441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env28440 == env28441) = true)

theorem identity28441 : scanCanonicalize (H12AffineFastState.compose env28441 (packedSelected [5,10] rootPS)) = affineNative (2^(6+1) ^^^ 67) := by decide +kernel

theorem selectedBound28441 : packedSelected [5,10] rootPS < 2^1333 := by decide +kernel

def env28442 : List Nat := [2,4,8,0,32,64,67,73,0,8,2048,13,4,65,0,35,65,97,4,1,12,75,64,34,66,12,102,1,64,2081,8,76,72,64,0,12]

theorem envBound28442 : H12AffineFastState.Bounded env28442 := by
  intro p hp
  have h : env28442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28441_28442 : H12AffineEnvironment.transform 6 67 env28441 = env28442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 67 env28441 == env28442) = true)

theorem identity28442 : scanCanonicalize (H12AffineFastState.compose env28442 (packedSelected [5,8,13] rootPS)) = affineNative (2^(10+1) ^^^ 97) := by decide +kernel

theorem selectedBound28442 : packedSelected [5,8,13] rootPS < 2^1333 := by decide +kernel

def env28443 : List Nat := [2,4,8,0,32,64,67,73,0,8,97,13,4,65,0,35,65,97,4,1,12,75,64,34,66,12,102,1,64,64,8,76,72,64,0,12]

theorem envBound28443 : H12AffineFastState.Bounded env28443 := by
  intro p hp
  have h : env28443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28442_28443 : H12AffineEnvironment.transform 10 97 env28442 = env28443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 97 env28442 == env28443) = true)

theorem identity28443 : scanCanonicalize (H12AffineFastState.compose env28443 (packedSelected [2,4,5,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound28443 : packedSelected [2,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env28444 : List Nat := [2,4,8,0,32,10,9,3,0,8,43,13,4,11,0,35,11,43,4,1,12,1,10,34,8,12,44,1,10,10,8,6,2,10,0,12]

theorem envBound28444 : H12AffineFastState.Bounded env28444 := by
  intro p hp
  have h : env28444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28443_28444 : H12AffineEnvironment.transform 5 10 env28443 = env28444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env28443 == env28444) = true)

theorem identity28444 : scanCanonicalize (H12AffineFastState.compose env28444 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound28444 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env28445 : List Nat := [2,4,8,0,10,10,9,3,0,8,1,13,4,11,0,9,11,1,4,1,12,1,10,8,8,12,6,1,10,10,8,6,2,10,0,12]

theorem envBound28445 : H12AffineFastState.Bounded env28445 := by
  intro p hp
  have h : env28445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28444_28445 : H12AffineEnvironment.transform 4 10 env28444 = env28445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env28444 == env28445) = true)

theorem identity28445 : scanCanonicalize (H12AffineFastState.compose env28445 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound28445 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28446 : List Nat := [2,2,8,0,10,10,9,3,0,8,1,11,2,11,0,9,11,1,2,1,10,1,10,8,8,10,0,1,10,10,8,0,2,10,0,10]

theorem envBound28446 : H12AffineFastState.Bounded env28446 := by
  intro p hp
  have h : env28446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28445_28446 : H12AffineEnvironment.transform 1 2 env28445 = env28446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env28445 == env28446) = true)

theorem identity28446 : scanCanonicalize (H12AffineFastState.compose env28446 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound28446 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28447 : List Nat := [2,2,2,0,0,0,3,3,0,2,1,1,2,1,0,3,1,1,2,1,0,1,0,2,2,0,0,1,0,0,2,0,2,0,0,0]

theorem envBound28447 : H12AffineFastState.Bounded env28447 := by
  intro p hp
  have h : env28447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28446_28447 : H12AffineEnvironment.transform 2 2 env28446 = env28447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env28446 == env28447) = true)

def env28448 : List Nat := [2,4,8,16,32,64,128,256,17,337,2048,341,348,65,1,378,281,507,21,0,340,153,280,379,145,12,303,329,64,2408,336,92,257,80,16,341]

theorem envBound28448 : H12AffineFastState.Bounded env28448 := by
  intro p hp
  have h : env28448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28438_28448 : H12AffineEnvironment.transform 8 17 env28438 = env28448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env28438 == env28448) = true)

theorem identity28448 : scanCanonicalize (H12AffineFastState.compose env28448 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound28448 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env28449 : List Nat := [2,4,8,16,32,64,128,85,17,4,2048,0,9,65,1,47,76,174,21,0,1,153,77,46,145,12,122,28,64,2109,5,92,84,80,16,0]

theorem envBound28449 : H12AffineFastState.Bounded env28449 := by
  intro p hp
  have h : env28449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28448_28449 : H12AffineEnvironment.transform 7 85 env28448 = env28449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env28448 == env28449) = true)

theorem identity28449 : scanCanonicalize (H12AffineFastState.compose env28449 (packedSelected [0,2,3,7,8,11,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 44) := by decide +kernel

theorem selectedBound28449 : packedSelected [0,2,3,7,8,11,12,15] rootPS < 2^1333 := by decide +kernel

def env28450 : List Nat := [2,4,8,16,32,44,128,57,17,4,2048,0,9,45,1,47,32,174,21,0,1,153,33,46,145,12,22,28,44,2109,5,48,56,60,16,0]

theorem envBound28450 : H12AffineFastState.Bounded env28450 := by
  intro p hp
  have h : env28450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28449_28450 : H12AffineEnvironment.transform 5 44 env28449 = env28450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 44 env28449 == env28450) = true)

theorem identity28450 : scanCanonicalize (H12AffineFastState.compose env28450 (packedSelected [3,10,17] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound28450 : packedSelected [3,10,17] rootPS < 2^1333 := by decide +kernel

def env28451 : List Nat := [2,4,8,16,32,44,128,57,17,4,11,0,9,45,1,47,32,174,21,0,1,153,33,46,145,12,22,28,44,54,5,48,56,60,16,0]

theorem envBound28451 : H12AffineFastState.Bounded env28451 := by
  intro p hp
  have h : env28451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28450_28451 : H12AffineEnvironment.transform 10 11 env28450 = env28451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env28450 == env28451) = true)

theorem identity28451 : scanCanonicalize (H12AffineFastState.compose env28451 (packedSelected [2,5] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound28451 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env28452 : List Nat := [2,4,8,16,7,11,128,30,17,4,11,0,9,10,1,8,7,137,21,0,1,153,6,9,145,12,22,28,11,17,5,23,31,27,16,0]

theorem envBound28452 : H12AffineFastState.Bounded env28452 := by
  intro p hp
  have h : env28452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28451_28452 : H12AffineEnvironment.transform 4 7 env28451 = env28452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env28451 == env28452) = true)

theorem identity28452 : scanCanonicalize (H12AffineFastState.compose env28452 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound28452 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env28453 : List Nat := [2,3,8,16,0,11,128,25,17,3,11,0,9,10,1,8,0,137,18,0,1,153,1,9,145,11,17,27,11,17,2,16,24,27,16,0]

theorem envBound28453 : H12AffineFastState.Bounded env28453 := by
  intro p hp
  have h : env28453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28452_28453 : H12AffineEnvironment.transform 1 3 env28452 = env28453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env28452 == env28453) = true)

theorem identity28453 : scanCanonicalize (H12AffineFastState.compose env28453 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound28453 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env28454 : List Nat := [2,3,8,16,0,11,2,25,17,3,11,0,9,10,1,8,0,11,18,0,1,27,1,9,19,11,17,27,11,17,2,16,24,27,16,0]

theorem envBound28454 : H12AffineFastState.Bounded env28454 := by
  intro p hp
  have h : env28454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28453_28454 : H12AffineEnvironment.transform 6 2 env28453 = env28454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env28453 == env28454) = true)

theorem identity28454 : scanCanonicalize (H12AffineFastState.compose env28454 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound28454 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28455 : List Nat := [2,3,8,0,0,11,2,9,1,3,11,0,9,10,1,8,0,11,2,0,1,11,1,9,3,11,1,11,11,1,2,0,8,11,0,0]

theorem envBound28455 : H12AffineFastState.Bounded env28455 := by
  intro p hp
  have h : env28455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28454_28455 : H12AffineEnvironment.transform 3 0 env28454 = env28455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env28454 == env28455) = true)

theorem identity28455 : scanCanonicalize (H12AffineFastState.compose env28455 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound28455 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28456 : List Nat := [2,3,0,0,0,3,2,1,1,3,3,0,1,2,1,0,0,3,2,0,1,3,1,1,3,3,1,3,3,1,2,0,0,3,0,0]

theorem envBound28456 : H12AffineFastState.Bounded env28456 := by
  intro p hp
  have h : env28456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28455_28456 : H12AffineEnvironment.transform 2 0 env28455 = env28456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env28455 == env28456) = true)

def env28457 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74862,262144,4417,8541,4097,5277,74047,66896,13768,78894,328959,74815,1297,81227,8205,65831,257,1281,1345,5953]

theorem envBound28457 : H12AffineFastState.Bounded env28457 := by
  intro p hp
  have h : env28457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28306_28457 : H12AffineEnvironment.transform 13 1297 env28306 = env28457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env28306 == env28457) = true)

def env28458 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74862,65664,4417,8541,4097,5277,74047,66896,13768,78894,1151,74815,1297,81227,8205,65831,257,1281,1345,5953]

theorem envBound28458 : H12AffineFastState.Bounded env28458 := by
  intro p hp
  have h : env28458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28457_28458 : H12AffineEnvironment.transform 17 65664 env28457 = env28458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env28457 == env28458) = true)

theorem identity28458 : scanCanonicalize (H12AffineFastState.compose env28458 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound28458 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env28459 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,8192,1297,8540,65536,74862,65664,273,8541,81,1229,74047,66896,9624,74878,1151,74815,1297,77083,8205,65831,257,1281,1345,1809]

theorem envBound28459 : H12AffineFastState.Bounded env28459 := by
  intro p hp
  have h : env28459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28458_28459 : H12AffineEnvironment.transform 11 80 env28458 = env28459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env28458 == env28459) = true)

def env28460 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,80,8192,81,8540,65536,74030,65664,273,8541,81,397,74047,65552,8408,74046,319,74111,81,75867,8205,65831,257,65,1,593]

theorem envBound28460 : H12AffineFastState.Bounded env28460 := by
  intro p hp
  have h : env28460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28459_28460 : H12AffineEnvironment.transform 9 320 env28459 = env28460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env28459 == env28460) = true)

theorem identity28460 : scanCanonicalize (H12AffineFastState.compose env28460 (packedSelected [7,20,27] rootPS)) = affineNative (2^(15+1) ^^^ 8250) := by decide +kernel

theorem selectedBound28460 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env28461 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,80,8192,81,8540,8250,276,8378,273,8541,81,397,261,8234,8408,260,319,325,81,2145,8205,8477,257,65,1,593]

theorem envBound28461 : H12AffineFastState.Bounded env28461 := by
  intro p hp
  have h : env28461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28460_28461 : H12AffineEnvironment.transform 15 8250 env28460 = env28461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8250 env28460 == env28461) = true)

theorem identity28461 : scanCanonicalize (H12AffineFastState.compose env28461 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound28461 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env28462 : List Nat := [2,4,8,16,32,64,128,21,512,85,2048,80,8192,81,8265,8250,1,8378,4,8264,81,152,16,8234,8408,17,42,80,81,2145,8205,8200,20,65,1,593]

theorem envBound28462 : H12AffineFastState.Bounded env28462 := by
  intro p hp
  have h : env28462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28461_28462 : H12AffineEnvironment.transform 7 21 env28461 = env28462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env28461 == env28462) = true)

theorem identity28462 : scanCanonicalize (H12AffineFastState.compose env28462 (packedSelected [0,3,7,8,11] rootPS)) = affineNative (2^(12+1) ^^^ 235) := by decide +kernel

theorem selectedBound28462 : packedSelected [0,3,7,8,11] rootPS < 2^1333 := by decide +kernel

def env28463 : List Nat := [2,4,8,16,32,64,128,21,512,85,2048,80,235,81,162,209,1,81,4,163,81,152,16,193,51,17,42,80,81,2145,230,227,20,65,1,593]

theorem envBound28463 : H12AffineFastState.Bounded env28463 := by
  intro p hp
  have h : env28463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28462_28463 : H12AffineEnvironment.transform 12 235 env28462 = env28463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 235 env28462 == env28463) = true)

theorem identity28463 : scanCanonicalize (H12AffineFastState.compose env28463 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound28463 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env28464 : List Nat := [2,4,8,16,32,17,128,21,512,4,2048,1,186,0,162,128,1,0,4,163,0,152,16,144,51,17,42,1,0,2096,183,178,20,16,1,512]

theorem envBound28464 : H12AffineFastState.Bounded env28464 := by
  intro p hp
  have h : env28464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28463_28464 : H12AffineEnvironment.transform 5 17 env28463 = env28464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env28463 == env28464) = true)

theorem identity28464 : scanCanonicalize (H12AffineFastState.compose env28464 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 674) := by decide +kernel

theorem selectedBound28464 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28465 : List Nat := [2,4,8,16,32,17,128,21,512,4,674,1,186,0,162,128,1,0,4,163,0,152,16,144,51,17,42,1,0,658,183,178,20,16,1,512]

theorem envBound28465 : H12AffineFastState.Bounded env28465 := by
  intro p hp
  have h : env28465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28464_28465 : H12AffineEnvironment.transform 10 674 env28464 = env28465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 674 env28464 == env28465) = true)

theorem identity28465 : scanCanonicalize (H12AffineFastState.compose env28465 (packedSelected [3,8] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound28465 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env28466 : List Nat := [2,4,8,16,10,17,128,21,512,4,648,1,144,0,136,128,1,0,4,137,0,152,16,144,25,17,0,1,0,658,157,152,20,16,1,512]

theorem envBound28466 : H12AffineFastState.Bounded env28466 := by
  intro p hp
  have h : env28466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28465_28466 : H12AffineEnvironment.transform 4 10 env28465 = env28466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env28465 == env28466) = true)

theorem identity28466 : scanCanonicalize (H12AffineFastState.compose env28466 (packedSelected [4,7] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound28466 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env28467 : List Nat := [2,4,8,16,10,17,128,21,0,4,136,1,144,0,136,128,1,0,4,137,0,152,16,144,25,17,0,1,0,146,157,152,20,16,1,0]

theorem envBound28467 : H12AffineFastState.Bounded env28467 := by
  intro p hp
  have h : env28467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28466_28467 : H12AffineEnvironment.transform 8 0 env28466 = env28467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env28466 == env28467) = true)

theorem identity28467 : scanCanonicalize (H12AffineFastState.compose env28467 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound28467 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env28468 : List Nat := [2,4,8,16,10,17,8,21,0,4,0,1,24,0,0,8,1,0,4,1,0,16,16,24,25,17,0,1,0,26,21,16,20,16,1,0]

theorem envBound28468 : H12AffineFastState.Bounded env28468 := by
  intro p hp
  have h : env28468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28467_28468 : H12AffineEnvironment.transform 6 8 env28467 = env28468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env28467 == env28468) = true)

theorem identity28468 : scanCanonicalize (H12AffineFastState.compose env28468 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound28468 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28469 : List Nat := [2,4,5,16,7,17,5,21,0,4,0,1,21,0,0,5,1,0,4,1,0,16,16,21,20,17,0,1,0,23,21,16,20,16,1,0]

theorem envBound28469 : H12AffineFastState.Bounded env28469 := by
  intro p hp
  have h : env28469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28468_28469 : H12AffineEnvironment.transform 2 5 env28468 = env28469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env28468 == env28469) = true)

def env28470 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,80,8192,80,8540,65536,74031,65664,273,8541,81,396,74047,65553,8409,74047,318,74110,80,75866,8205,65831,257,64,0,592]

theorem envBound28470 : H12AffineFastState.Bounded env28470 := by
  intro p hp
  have h : env28470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28459_28470 : H12AffineEnvironment.transform 9 321 env28459 = env28470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env28459 == env28470) = true)

theorem identity28470 : scanCanonicalize (H12AffineFastState.compose env28470 (packedSelected [7,20,27] rootPS)) = affineNative (2^(15+1) ^^^ 8299) := by decide +kernel

theorem selectedBound28470 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env28471 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,80,8192,80,8540,8299,324,8427,273,8541,81,396,340,8314,8409,340,318,277,80,2097,8205,8524,257,64,0,592]

theorem envBound28471 : H12AffineFastState.Bounded env28471 := by
  intro p hp
  have h : env28471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28470_28471 : H12AffineEnvironment.transform 15 8299 env28470 = env28471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8299 env28470 == env28471) = true)

theorem identity28471 : scanCanonicalize (H12AffineFastState.compose env28471 (packedSelected [0,1,4,7,8,9,16,19,20] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound28471 : packedSelected [0,1,4,7,8,9,16,19,20] rootPS < 2^1333 := by decide +kernel

def env28472 : List Nat := [2,4,8,16,32,64,128,21,512,84,2048,80,8192,80,8265,8299,81,8427,4,8264,81,153,65,8314,8409,65,43,0,80,2097,8205,8281,20,64,0,592]

theorem envBound28472 : H12AffineFastState.Bounded env28472 := by
  intro p hp
  have h : env28472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28471_28472 : H12AffineEnvironment.transform 7 21 env28471 = env28472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env28471 == env28472) = true)

theorem identity28472 : scanCanonicalize (H12AffineFastState.compose env28472 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound28472 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env28473 : List Nat := [2,4,8,16,32,16,128,21,512,4,2048,0,8192,0,8217,8251,1,8379,4,8216,1,153,17,8234,8329,17,43,0,0,2097,8205,8201,20,16,0,512]

theorem envBound28473 : H12AffineFastState.Bounded env28473 := by
  intro p hp
  have h : env28473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28472_28473 : H12AffineEnvironment.transform 5 16 env28472 = env28473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env28472 == env28473) = true)

theorem identity28473 : scanCanonicalize (H12AffineFastState.compose env28473 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 2601) := by decide +kernel

theorem selectedBound28473 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28474 : List Nat := [2,4,8,16,32,16,128,21,512,4,2048,0,2601,0,2608,2578,1,2706,4,2609,1,153,17,2563,2720,17,43,0,0,2097,2596,2592,20,16,0,512]

theorem envBound28474 : H12AffineFastState.Bounded env28474 := by
  intro p hp
  have h : env28474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28473_28474 : H12AffineEnvironment.transform 12 2601 env28473 = env28474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2601 env28473 == env28474) = true)

theorem identity28474 : scanCanonicalize (H12AffineFastState.compose env28474 (packedSelected [3,8] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound28474 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env28475 : List Nat := [2,4,8,16,11,16,128,21,512,4,2048,0,2562,0,2587,2578,1,2706,4,2586,1,153,17,2563,2699,17,0,0,0,2074,2575,2571,20,16,0,512]

theorem envBound28475 : H12AffineFastState.Bounded env28475 := by
  intro p hp
  have h : env28475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28474_28475 : H12AffineEnvironment.transform 4 11 env28474 = env28475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env28474 == env28475) = true)

theorem identity28475 : scanCanonicalize (H12AffineFastState.compose env28475 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound28475 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env28476 : List Nat := [2,4,8,16,11,16,128,21,136,4,2048,0,2186,0,2195,2202,1,2074,4,2194,1,153,17,2187,2051,17,0,0,0,2074,2183,2179,20,16,0,136]

theorem envBound28476 : H12AffineFastState.Bounded env28476 := by
  intro p hp
  have h : env28476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28475_28476 : H12AffineEnvironment.transform 8 136 env28475 = env28476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env28475 == env28476) = true)

theorem identity28476 : scanCanonicalize (H12AffineFastState.compose env28476 (packedSelected [3,4] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound28476 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env28477 : List Nat := [2,4,8,10,11,10,128,15,136,4,2048,0,2186,0,2185,2176,1,2048,4,2184,1,131,11,2187,2051,11,0,0,0,2048,2183,2179,14,10,0,136]

theorem envBound28477 : H12AffineFastState.Bounded env28477 := by
  intro p hp
  have h : env28477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28476_28477 : H12AffineEnvironment.transform 3 10 env28476 = env28477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env28476 == env28477) = true)

theorem identity28477 : scanCanonicalize (H12AffineFastState.compose env28477 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound28477 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env28478 : List Nat := [2,4,8,10,11,10,128,15,136,4,1,0,139,0,136,129,1,1,4,137,1,131,11,138,2,11,0,0,0,1,134,130,14,10,0,136]

theorem envBound28478 : H12AffineFastState.Bounded env28478 := by
  intro p hp
  have h : env28478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28477_28478 : H12AffineEnvironment.transform 10 1 env28477 = env28478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env28477 == env28478) = true)

def env28479 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74862,65665,4417,8541,4097,5277,74047,66896,13768,78894,1150,74815,1297,81227,8205,65831,257,1281,1345,5953]

theorem envBound28479 : H12AffineFastState.Bounded env28479 := by
  intro p hp
  have h : env28479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28457_28479 : H12AffineEnvironment.transform 17 65665 env28457 = env28479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env28457 == env28479) = true)

theorem identity28479 : scanCanonicalize (H12AffineFastState.compose env28479 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound28479 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env28480 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,8192,1,8540,65536,74110,65665,4417,8541,4097,4493,74047,65600,12504,78142,366,74031,1,79963,8205,65831,257,17,81,4689]

theorem envBound28480 : H12AffineFastState.Bounded env28480 := by
  intro p hp
  have h : env28480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28479_28480 : H12AffineEnvironment.transform 9 272 env28479 = env28480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env28479 == env28480) = true)

def env28481 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,772,8192,1,8540,65536,74110,65665,581,8541,773,649,74047,65600,9180,74298,366,74031,1,76639,8205,65831,257,17,81,341]

theorem envBound28481 : H12AffineFastState.Bounded env28481 := by
  intro p hp
  have h : env28481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28480_28481 : H12AffineEnvironment.transform 11 772 env28480 = env28481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 772 env28480 == env28481) = true)

def env28482 : List Nat := [2,4,8,16,32,0,128,256,512,272,2048,772,8192,1,8476,65536,74046,65665,517,8477,773,649,74047,65536,9116,74298,302,74031,1,76575,8205,65831,257,17,17,277]

theorem envBound28482 : H12AffineFastState.Bounded env28482 := by
  intro p hp
  have h : env28482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28481_28482 : H12AffineEnvironment.transform 5 0 env28481 = env28482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env28481 == env28482) = true)

theorem identity28482 : scanCanonicalize (H12AffineFastState.compose env28482 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 167) := by decide +kernel

theorem selectedBound28482 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env28483 : List Nat := [2,4,8,16,32,0,128,256,512,272,2048,772,8192,1,8476,167,8601,38,517,8477,773,649,8600,167,9116,8861,302,8584,1,11192,8205,384,257,17,17,277]

theorem envBound28483 : H12AffineFastState.Bounded env28483 := by
  intro p hp
  have h : env28483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28482_28483 : H12AffineEnvironment.transform 15 167 env28482 = env28483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 167 env28482 == env28483) = true)

def env28484 : List Nat := [2,4,8,16,32,0,128,256,512,272,2048,772,684,1,944,167,821,38,517,945,773,649,820,167,304,49,302,804,1,2324,673,384,257,17,17,277]

theorem envBound28484 : H12AffineFastState.Bounded env28484 := by
  intro p hp
  have h : env28484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28483_28484 : H12AffineEnvironment.transform 12 684 env28483 = env28484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 684 env28483 == env28484) = true)

def env28485 : List Nat := [2,4,8,16,32,0,128,144,512,128,2048,660,684,1,544,167,677,38,517,545,661,649,676,167,160,49,190,692,1,2180,673,16,145,17,17,133]

theorem envBound28485 : H12AffineFastState.Bounded env28485 := by
  intro p hp
  have h : env28485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28484_28485 : H12AffineEnvironment.transform 7 144 env28484 = env28485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 144 env28484 == env28485) = true)

theorem identity28485 : scanCanonicalize (H12AffineFastState.compose env28485 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound28485 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env28486 : List Nat := [2,4,8,16,0,0,128,144,512,128,2048,660,652,1,512,135,645,6,517,513,661,649,644,135,128,17,158,660,1,2180,641,16,145,17,17,133]

theorem envBound28486 : H12AffineFastState.Bounded env28486 := by
  intro p hp
  have h : env28486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28485_28486 : H12AffineEnvironment.transform 4 0 env28485 = env28486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env28485 == env28486) = true)

theorem identity28486 : scanCanonicalize (H12AffineFastState.compose env28486 (packedSelected [4,9,16] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound28486 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env28487 : List Nat := [2,4,8,16,0,0,4,20,512,4,2048,528,520,1,512,3,513,6,517,513,529,525,512,3,4,17,26,528,1,2048,517,16,21,17,17,1]

theorem envBound28487 : H12AffineFastState.Bounded env28487 := by
  intro p hp
  have h : env28487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28486_28487 : H12AffineEnvironment.transform 6 4 env28486 = env28487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env28486 == env28487) = true)

theorem identity28487 : scanCanonicalize (H12AffineFastState.compose env28487 (packedSelected [2,5,8,10,12] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound28487 : packedSelected [2,5,8,10,12] rootPS < 2^1333 := by decide +kernel

def env28488 : List Nat := [2,4,8,16,0,0,4,20,16,4,2048,0,24,1,16,3,17,6,21,17,1,29,16,3,4,17,26,0,1,2048,21,16,21,17,17,1]

theorem envBound28488 : H12AffineFastState.Bounded env28488 := by
  intro p hp
  have h : env28488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28487_28488 : H12AffineEnvironment.transform 8 16 env28487 = env28488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env28487 == env28488) = true)

theorem identity28488 : scanCanonicalize (H12AffineFastState.compose env28488 (packedSelected [3,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound28488 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env28489 : List Nat := [2,4,8,1,0,0,4,5,1,4,2048,0,9,1,1,3,0,6,4,0,1,12,1,3,4,0,11,0,1,2048,4,1,4,0,0,1]

theorem envBound28489 : H12AffineFastState.Bounded env28489 := by
  intro p hp
  have h : env28489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28488_28489 : H12AffineEnvironment.transform 3 1 env28488 = env28489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env28488 == env28489) = true)

theorem identity28489 : scanCanonicalize (H12AffineFastState.compose env28489 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 12) := by decide +kernel

theorem selectedBound28489 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28490 : List Nat := [2,4,8,1,0,0,4,5,1,4,12,0,9,1,1,3,0,6,4,0,1,12,1,3,4,0,11,0,1,12,4,1,4,0,0,1]

theorem envBound28490 : H12AffineFastState.Bounded env28490 := by
  intro p hp
  have h : env28490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28489_28490 : H12AffineEnvironment.transform 10 12 env28489 = env28490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 12 env28489 == env28490) = true)

theorem identity28490 : scanCanonicalize (H12AffineFastState.compose env28490 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound28490 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28491 : List Nat := [2,4,3,1,0,0,4,5,1,4,7,0,2,1,1,3,0,6,4,0,1,7,1,3,4,0,0,0,1,7,4,1,4,0,0,1]

theorem envBound28491 : H12AffineFastState.Bounded env28491 := by
  intro p hp
  have h : env28491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28490_28491 : H12AffineEnvironment.transform 2 3 env28490 = env28491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env28490 == env28491) = true)

theorem identity28491 : scanCanonicalize (H12AffineFastState.compose env28491 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound28491 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28492 : List Nat := [2,2,3,1,0,0,2,3,1,2,1,0,2,1,1,3,0,0,2,0,1,1,1,3,2,0,0,0,1,1,2,1,2,0,0,1]

theorem envBound28492 : H12AffineFastState.Bounded env28492 := by
  intro p hp
  have h : env28492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28491_28492 : H12AffineEnvironment.transform 1 2 env28491 = env28492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env28491 == env28492) = true)

def env28493 : List Nat := [2,4,8,16,32,0,128,145,512,129,2048,661,684,1,545,167,676,38,517,544,660,649,677,167,161,49,191,693,1,2181,673,17,144,17,17,132]

theorem envBound28493 : H12AffineFastState.Bounded env28493 := by
  intro p hp
  have h : env28493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28484_28493 : H12AffineEnvironment.transform 7 145 env28484 = env28493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 145 env28484 == env28493) = true)

theorem identity28493 : scanCanonicalize (H12AffineFastState.compose env28493 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound28493 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env28494 : List Nat := [2,4,8,16,32,0,128,145,1,129,2048,148,173,1,32,167,165,38,4,33,149,136,164,167,161,49,191,180,1,2181,160,17,144,17,17,132]

theorem envBound28494 : H12AffineFastState.Bounded env28494 := by
  intro p hp
  have h : env28494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28493_28494 : H12AffineEnvironment.transform 8 1 env28493 = env28494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env28493 == env28494) = true)

theorem identity28494 : scanCanonicalize (H12AffineFastState.compose env28494 (packedSelected [0,1,2,3,4,7,8,9,10,11,13,16] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound28494 : packedSelected [0,1,2,3,4,7,8,9,10,11,13,16] rootPS < 2^1333 := by decide +kernel

def env28495 : List Nat := [2,4,8,13,32,0,128,140,1,129,2048,137,173,1,32,167,165,38,4,33,136,136,164,167,161,44,162,169,1,2181,160,12,141,12,12,132]

theorem envBound28495 : H12AffineFastState.Bounded env28495 := by
  intro p hp
  have h : env28495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28494_28495 : H12AffineEnvironment.transform 3 13 env28494 = env28495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env28494 == env28495) = true)

theorem identity28495 : scanCanonicalize (H12AffineFastState.compose env28495 (packedSelected [4,5,9,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 45) := by decide +kernel

theorem selectedBound28495 : packedSelected [4,5,9,11,12] rootPS < 2^1333 := by decide +kernel

def env28496 : List Nat := [2,4,8,13,32,0,128,140,1,129,45,137,173,1,32,167,165,38,4,33,136,136,164,167,161,44,162,169,1,168,160,12,141,12,12,132]

theorem envBound28496 : H12AffineFastState.Bounded env28496 := by
  intro p hp
  have h : env28496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28495_28496 : H12AffineEnvironment.transform 10 45 env28495 = env28496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 45 env28495 == env28496) = true)

theorem identity28496 : scanCanonicalize (H12AffineFastState.compose env28496 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound28496 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env28497 : List Nat := [2,4,8,13,32,0,34,46,1,35,45,43,15,1,32,5,7,38,4,33,42,42,6,5,3,44,0,11,1,10,2,12,47,12,12,38]

theorem envBound28497 : H12AffineFastState.Bounded env28497 := by
  intro p hp
  have h : env28497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28496_28497 : H12AffineEnvironment.transform 6 34 env28496 = env28497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env28496 == env28497) = true)

theorem identity28497 : scanCanonicalize (H12AffineFastState.compose env28497 (packedSelected [2,3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound28497 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env28498 : List Nat := [2,3,8,10,32,0,34,41,1,35,42,43,8,1,32,2,0,33,3,33,42,42,1,2,3,43,0,11,1,10,2,11,40,11,11,33]

theorem envBound28498 : H12AffineFastState.Bounded env28498 := by
  intro p hp
  have h : env28498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28497_28498 : H12AffineEnvironment.transform 1 3 env28497 = env28498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env28497 == env28498) = true)

theorem identity28498 : scanCanonicalize (H12AffineFastState.compose env28498 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound28498 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28499 : List Nat := [2,3,8,10,11,0,9,2,1,8,1,0,8,1,11,2,0,10,3,10,1,1,1,2,3,0,0,11,1,10,2,11,3,11,11,10]

theorem envBound28499 : H12AffineFastState.Bounded env28499 := by
  intro p hp
  have h : env28499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28498_28499 : H12AffineEnvironment.transform 4 11 env28498 = env28499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env28498 == env28499) = true)

theorem identity28499 : scanCanonicalize (H12AffineFastState.compose env28499 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound28499 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28500 : List Nat := [2,3,2,0,1,0,3,2,1,2,1,0,2,1,1,2,0,0,3,0,1,1,1,2,3,0,0,1,1,0,2,1,3,1,1,0]

theorem envBound28500 : H12AffineFastState.Bounded env28500 := by
  intro p hp
  have h : env28500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28499_28500 : H12AffineEnvironment.transform 2 2 env28499 = env28500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env28499 == env28500) = true)

theorem identity28500 : scanCanonicalize (H12AffineFastState.compose env28500 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound28500 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28501 : List Nat := [1,0,1,0,1,0,0,1,1,1,1,0,1,1,1,1,0,0,0,0,1,1,1,1,0,0,0,1,1,0,1,1,0,1,1,0]

theorem envBound28501 : H12AffineFastState.Bounded env28501 := by
  intro p hp
  have h : env28501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28500_28501 : H12AffineEnvironment.transform 0 1 env28500 = env28501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env28500 == env28501) = true)

def env28502 : List Nat := [2,4,8,16,32,0,128,256,512,272,2048,772,685,1,945,167,820,38,517,944,773,649,821,167,305,48,302,805,1,2325,672,384,257,17,17,277]

theorem envBound28502 : H12AffineFastState.Bounded env28502 := by
  intro p hp
  have h : env28502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28483_28502 : H12AffineEnvironment.transform 12 685 env28483 = env28502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 685 env28483 == env28502) = true)

def env28503 : List Nat := [2,4,8,16,32,0,128,144,512,128,2048,660,685,1,545,167,676,38,517,544,661,649,677,167,161,48,190,693,1,2181,672,16,145,17,17,133]

theorem envBound28503 : H12AffineFastState.Bounded env28503 := by
  intro p hp
  have h : env28503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28502_28503 : H12AffineEnvironment.transform 7 144 env28502 = env28503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 144 env28502 == env28503) = true)

theorem identity28503 : scanCanonicalize (H12AffineFastState.compose env28503 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound28503 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env28504 : List Nat := [2,4,8,16,1,0,128,144,512,128,2048,660,652,1,512,134,645,7,517,513,661,649,644,134,128,17,159,660,1,2181,641,16,145,17,17,133]

theorem envBound28504 : H12AffineFastState.Bounded env28504 := by
  intro p hp
  have h : env28504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28503_28504 : H12AffineEnvironment.transform 4 1 env28503 = env28504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env28503 == env28504) = true)

theorem identity28504 : scanCanonicalize (H12AffineFastState.compose env28504 (packedSelected [4,9,16] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound28504 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env28505 : List Nat := [2,4,8,16,1,0,4,20,512,4,2048,528,520,1,512,2,513,7,517,513,529,525,512,2,4,17,27,528,1,2049,517,16,21,17,17,1]

theorem envBound28505 : H12AffineFastState.Bounded env28505 := by
  intro p hp
  have h : env28505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28504_28505 : H12AffineEnvironment.transform 6 4 env28504 = env28505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env28504 == env28505) = true)

theorem identity28505 : scanCanonicalize (H12AffineFastState.compose env28505 (packedSelected [2,5,8,10,12] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound28505 : packedSelected [2,5,8,10,12] rootPS < 2^1333 := by decide +kernel

def env28506 : List Nat := [2,4,8,16,1,0,4,20,1,4,2048,17,9,1,1,2,0,7,4,0,16,12,1,2,4,17,27,17,1,2049,4,16,21,17,17,1]

theorem envBound28506 : H12AffineFastState.Bounded env28506 := by
  intro p hp
  have h : env28506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28505_28506 : H12AffineEnvironment.transform 8 1 env28505 = env28506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env28505 == env28506) = true)

theorem identity28506 : scanCanonicalize (H12AffineFastState.compose env28506 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound28506 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28507 : List Nat := [2,4,4,16,1,0,4,20,1,4,2048,17,5,1,1,2,0,7,4,0,16,0,1,2,4,17,23,17,1,2049,4,16,21,17,17,1]

theorem envBound28507 : H12AffineFastState.Bounded env28507 := by
  intro p hp
  have h : env28507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28506_28507 : H12AffineEnvironment.transform 2 4 env28506 = env28507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env28506 == env28507) = true)

theorem identity28507 : scanCanonicalize (H12AffineFastState.compose env28507 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 23) := by decide +kernel

theorem selectedBound28507 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28508 : List Nat := [2,4,4,16,1,0,4,20,1,4,23,17,5,1,1,2,0,7,4,0,16,0,1,2,4,17,23,17,1,22,4,16,21,17,17,1]

theorem envBound28508 : H12AffineFastState.Bounded env28508 := by
  intro p hp
  have h : env28508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28507_28508 : H12AffineEnvironment.transform 10 23 env28507 = env28508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 23 env28507 == env28508) = true)

theorem identity28508 : scanCanonicalize (H12AffineFastState.compose env28508 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound28508 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28509 : List Nat := [2,4,4,6,1,0,4,2,1,4,1,7,5,1,1,2,0,7,4,0,6,0,1,2,4,7,1,7,1,0,4,6,3,7,7,1]

theorem envBound28509 : H12AffineFastState.Bounded env28509 := by
  intro p hp
  have h : env28509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28508_28509 : H12AffineEnvironment.transform 3 6 env28508 = env28509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env28508 == env28509) = true)

def env28510 : List Nat := [2,4,8,16,32,0,128,145,512,129,2048,661,685,1,544,167,677,38,517,545,660,649,676,167,160,48,191,692,1,2180,672,17,144,17,17,132]

theorem envBound28510 : H12AffineFastState.Bounded env28510 := by
  intro p hp
  have h : env28510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28502_28510 : H12AffineEnvironment.transform 7 145 env28502 = env28510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 145 env28502 == env28510) = true)

theorem identity28510 : scanCanonicalize (H12AffineFastState.compose env28510 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound28510 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env28511 : List Nat := [2,4,8,16,32,0,128,145,1,129,2048,148,172,1,33,167,164,38,4,32,149,136,165,167,160,48,191,181,1,2180,161,17,144,17,17,132]

theorem envBound28511 : H12AffineFastState.Bounded env28511 := by
  intro p hp
  have h : env28511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28510_28511 : H12AffineEnvironment.transform 8 1 env28510 = env28511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env28510 == env28511) = true)

theorem identity28511 : scanCanonicalize (H12AffineFastState.compose env28511 (packedSelected [0,1,2,3,4,7,8,9,10,11,13,16] rootPS)) = affineNative (2^(4+1) ^^^ 29) := by decide +kernel

theorem selectedBound28511 : packedSelected [0,1,2,3,4,7,8,9,10,11,13,16] rootPS < 2^1333 := by decide +kernel

def env28512 : List Nat := [2,4,8,16,29,0,128,145,1,129,2048,148,145,1,28,154,153,27,4,29,149,136,152,154,157,13,130,136,1,2180,156,17,144,17,17,132]

theorem envBound28512 : H12AffineFastState.Bounded env28512 := by
  intro p hp
  have h : env28512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28511_28512 : H12AffineEnvironment.transform 4 29 env28511 = env28512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 29 env28511 == env28512) = true)

theorem identity28512 : scanCanonicalize (H12AffineFastState.compose env28512 (packedSelected [2,3,4,5,8,9,11] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound28512 : packedSelected [2,3,4,5,8,9,11] rootPS < 2^1333 := by decide +kernel

def env28513 : List Nat := [2,4,8,16,29,0,8,25,1,9,2048,28,25,1,28,18,17,27,4,29,29,0,16,18,21,13,10,0,1,2060,20,17,24,17,17,12]

theorem envBound28513 : H12AffineFastState.Bounded env28513 := by
  intro p hp
  have h : env28513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28512_28513 : H12AffineEnvironment.transform 6 8 env28512 = env28513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env28512 == env28513) = true)

theorem identity28513 : scanCanonicalize (H12AffineFastState.compose env28513 (packedSelected [0,2,3,7] rootPS)) = affineNative (2^(10+1) ^^^ 7) := by decide +kernel

theorem selectedBound28513 : packedSelected [0,2,3,7] rootPS < 2^1333 := by decide +kernel

def env28514 : List Nat := [2,4,8,16,29,0,8,25,1,9,7,28,25,1,28,18,17,27,4,29,29,0,16,18,21,13,10,0,1,11,20,17,24,17,17,12]

theorem envBound28514 : H12AffineFastState.Bounded env28514 := by
  intro p hp
  have h : env28514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28513_28514 : H12AffineEnvironment.transform 10 7 env28513 = env28514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 7 env28513 == env28514) = true)

theorem identity28514 : scanCanonicalize (H12AffineFastState.compose env28514 (packedSelected [0,2,3,4] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound28514 : packedSelected [0,2,3,4] rootPS < 2^1333 := by decide +kernel

def env28515 : List Nat := [2,4,8,10,7,0,8,3,1,9,7,6,3,1,6,8,11,1,4,7,7,0,10,8,15,13,10,0,1,11,14,11,2,11,11,12]

theorem envBound28515 : H12AffineFastState.Bounded env28515 := by
  intro p hp
  have h : env28515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28514_28515 : H12AffineEnvironment.transform 3 10 env28514 = env28515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env28514 == env28515) = true)

theorem identity28515 : scanCanonicalize (H12AffineFastState.compose env28515 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound28515 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28516 : List Nat := [2,4,2,0,7,0,2,3,1,3,7,6,3,1,6,2,1,1,4,7,7,0,0,2,5,7,0,0,1,1,4,1,2,1,1,6]

theorem envBound28516 : H12AffineFastState.Bounded env28516 := by
  intro p hp
  have h : env28516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28515_28516 : H12AffineEnvironment.transform 2 2 env28515 = env28516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env28515 == env28516) = true)

theorem identity28516 : scanCanonicalize (H12AffineFastState.compose env28516 (packedSelected [5] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound28516 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env28517 : List Nat := [2,3,2,0,0,0,2,3,1,3,0,1,3,1,1,2,1,1,3,0,0,0,0,2,2,0,0,0,1,1,3,1,2,1,1,1]

theorem envBound28517 : H12AffineFastState.Bounded env28517 := by
  intro p hp
  have h : env28517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28516_28517 : H12AffineEnvironment.transform 1 3 env28516 = env28517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env28516 == env28517) = true)

def env28518 : List Nat := [2,4,8,16,32,1,128,256,512,272,2048,772,8192,1,8477,65536,74047,65665,516,8476,773,649,74047,65537,9117,74298,303,74031,1,76574,8205,65831,257,17,16,276]

theorem envBound28518 : H12AffineFastState.Bounded env28518 := by
  intro p hp
  have h : env28518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28481_28518 : H12AffineEnvironment.transform 5 1 env28481 = env28518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env28481 == env28518) = true)

theorem identity28518 : scanCanonicalize (H12AffineFastState.compose env28518 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 8383) := by decide +kernel

theorem selectedBound28518 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env28519 : List Nat := [2,4,8,16,32,1,128,256,512,272,2048,772,8192,1,8477,8383,384,8254,516,8476,773,649,384,8382,9117,645,303,400,1,2977,8205,8600,257,17,16,276]

theorem envBound28519 : H12AffineFastState.Bounded env28519 := by
  intro p hp
  have h : env28519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28518_28519 : H12AffineEnvironment.transform 15 8383 env28518 = env28519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8383 env28518 == env28519) = true)

def env28520 : List Nat := [2,4,8,16,32,1,128,256,512,272,512,772,8192,1,8477,8383,384,8254,516,8476,773,649,384,8382,9117,645,303,400,1,417,8205,8600,257,17,16,276]

theorem envBound28520 : H12AffineFastState.Bounded env28520 := by
  intro p hp
  have h : env28520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28519_28520 : H12AffineEnvironment.transform 10 512 env28519 = env28520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env28519 == env28520) = true)

def env28521 : List Nat := [2,4,8,16,32,1,128,188,512,172,512,696,8192,1,8353,8383,60,8254,516,8352,697,649,60,8382,8737,645,147,44,1,29,8205,8228,189,17,16,168]

theorem envBound28521 : H12AffineFastState.Bounded env28521 := by
  intro p hp
  have h : env28521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28520_28521 : H12AffineEnvironment.transform 7 188 env28520 = env28521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 188 env28520 == env28521) = true)

theorem identity28521 : scanCanonicalize (H12AffineFastState.compose env28521 (packedSelected [0,1,3,7,11,12,15,16,18,19,21] rootPS)) = affineNative (2^(12+1) ^^^ 47) := by decide +kernel

theorem selectedBound28521 : packedSelected [0,1,3,7,11,12,15,16,18,19,21] rootPS < 2^1333 := by decide +kernel

def env28522 : List Nat := [2,4,8,16,32,1,128,188,512,172,512,696,47,1,142,144,60,17,516,143,697,649,60,145,526,645,147,44,1,29,34,11,189,17,16,168]

theorem envBound28522 : H12AffineFastState.Bounded env28522 := by
  intro p hp
  have h : env28522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28521_28522 : H12AffineEnvironment.transform 12 47 env28521 = env28522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 47 env28521 == env28522) = true)

theorem identity28522 : scanCanonicalize (H12AffineFastState.compose env28522 (packedSelected [0,4,7,8,9,10,15,17] rootPS)) = affineNative (2^(6+1) ^^^ 52) := by decide +kernel

theorem selectedBound28522 : packedSelected [0,4,7,8,9,10,15,17] rootPS < 2^1333 := by decide +kernel

def env28523 : List Nat := [2,4,8,16,32,1,52,8,512,24,512,524,47,1,58,36,60,17,516,59,525,573,60,37,526,561,39,44,1,29,34,11,9,17,16,28]

theorem envBound28523 : H12AffineFastState.Bounded env28523 := by
  intro p hp
  have h : env28523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28522_28523 : H12AffineEnvironment.transform 6 52 env28522 = env28523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 52 env28522 == env28523) = true)

theorem identity28523 : scanCanonicalize (H12AffineFastState.compose env28523 (packedSelected [1,2] rootPS)) = affineNative (2^(8+1) ^^^ 6) := by decide +kernel

theorem selectedBound28523 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env28524 : List Nat := [2,4,8,16,32,1,52,8,6,24,6,10,47,1,58,36,60,17,2,59,11,59,60,37,8,55,39,44,1,29,34,11,9,17,16,28]

theorem envBound28524 : H12AffineFastState.Bounded env28524 := by
  intro p hp
  have h : env28524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28523_28524 : H12AffineEnvironment.transform 8 6 env28523 = env28524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 6 env28523 == env28524) = true)

def env28525 : List Nat := [2,4,8,16,32,1,128,189,512,173,512,697,8192,1,8352,8383,61,8254,516,8353,696,649,61,8382,8736,645,146,45,1,28,8205,8229,188,17,16,169]

theorem envBound28525 : H12AffineFastState.Bounded env28525 := by
  intro p hp
  have h : env28525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28520_28525 : H12AffineEnvironment.transform 7 189 env28520 = env28525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 189 env28520 == env28525) = true)

theorem identity28525 : scanCanonicalize (H12AffineFastState.compose env28525 (packedSelected [0,1,3,7,11,12,15,16,18,19,21] rootPS)) = affineNative (2^(12+1) ^^^ 128) := by decide +kernel

theorem selectedBound28525 : packedSelected [0,1,3,7,11,12,15,16,18,19,21] rootPS < 2^1333 := by decide +kernel

def env28526 : List Nat := [2,4,8,16,32,1,128,189,512,173,512,697,128,1,32,63,61,190,516,33,696,649,61,62,672,645,146,45,1,28,141,165,188,17,16,169]

theorem envBound28526 : H12AffineFastState.Bounded env28526 := by
  intro p hp
  have h : env28526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28525_28526 : H12AffineEnvironment.transform 12 128 env28525 = env28526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 128 env28525 == env28526) = true)

theorem identity28526 : scanCanonicalize (H12AffineFastState.compose env28526 (packedSelected [0,1,2,3,4,5,7,8,9,12,13,15,17] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound28526 : packedSelected [0,1,2,3,4,5,7,8,9,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env28527 : List Nat := [2,4,8,16,11,1,128,150,512,134,512,658,128,1,11,20,22,149,516,10,659,649,22,21,651,645,146,6,1,28,141,142,151,17,16,130]

theorem envBound28527 : H12AffineFastState.Bounded env28527 := by
  intro p hp
  have h : env28527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28526_28527 : H12AffineEnvironment.transform 4 11 env28526 = env28527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env28526 == env28527) = true)

theorem identity28527 : scanCanonicalize (H12AffineFastState.compose env28527 (packedSelected [0,2,3,7,8,10] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound28527 : packedSelected [0,2,3,7,8,10] rootPS < 2^1333 := by decide +kernel

def env28528 : List Nat := [2,4,8,16,11,1,5,19,512,3,512,535,5,1,11,20,22,16,516,10,534,524,22,21,526,512,23,6,1,28,8,11,18,17,16,7]

theorem envBound28528 : H12AffineFastState.Bounded env28528 := by
  intro p hp
  have h : env28528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28527_28528 : H12AffineEnvironment.transform 6 5 env28527 = env28528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env28527 == env28528) = true)

theorem identity28528 : scanCanonicalize (H12AffineFastState.compose env28528 (packedSelected [1,2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound28528 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env28529 : List Nat := [2,4,2,16,1,1,5,19,512,3,512,535,5,1,1,20,22,16,516,0,534,518,22,21,516,512,23,6,1,22,2,1,18,17,16,7]

theorem envBound28529 : H12AffineFastState.Bounded env28529 := by
  intro p hp
  have h : env28529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28528_28529 : H12AffineEnvironment.transform 2 2 env28528 = env28529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env28528 == env28529) = true)

theorem identity28529 : scanCanonicalize (H12AffineFastState.compose env28529 (packedSelected [0,4] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound28529 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env28530 : List Nat := [2,2,2,16,1,1,3,19,512,3,512,529,3,1,1,18,16,16,514,0,528,512,16,19,514,512,17,0,1,16,2,1,18,17,16,1]

theorem envBound28530 : H12AffineFastState.Bounded env28530 := by
  intro p hp
  have h : env28530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28529_28530 : H12AffineEnvironment.transform 1 2 env28529 = env28530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env28529 == env28530) = true)

theorem identity28530 : scanCanonicalize (H12AffineFastState.compose env28530 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound28530 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env28531 : List Nat := [2,2,2,16,1,1,3,19,1,3,1,16,3,1,1,18,16,16,3,0,17,1,16,19,3,1,17,0,1,16,2,1,18,17,16,1]

theorem envBound28531 : H12AffineFastState.Bounded env28531 := by
  intro p hp
  have h : env28531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28530_28531 : H12AffineEnvironment.transform 8 1 env28530 = env28531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env28530 == env28531) = true)

def env28532 : List Nat := [2,4,8,16,32,1,128,256,512,272,513,772,8192,1,8477,8383,384,8254,516,8476,773,649,384,8382,9117,645,303,400,1,416,8205,8600,257,17,16,276]

theorem envBound28532 : H12AffineFastState.Bounded env28532 := by
  intro p hp
  have h : env28532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28519_28532 : H12AffineEnvironment.transform 10 513 env28519 = env28532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env28519 == env28532) = true)

def env28533 : List Nat := [2,4,8,16,32,1,128,188,512,172,513,696,8192,1,8353,8383,60,8254,516,8352,697,649,60,8382,8737,645,147,44,1,28,8205,8228,189,17,16,168]

theorem envBound28533 : H12AffineFastState.Bounded env28533 := by
  intro p hp
  have h : env28533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28532_28533 : H12AffineEnvironment.transform 7 188 env28532 = env28533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 188 env28532 == env28533) = true)

theorem identity28533 : scanCanonicalize (H12AffineFastState.compose env28533 (packedSelected [0,1,3,7,11,12,15,16,18,19,21] rootPS)) = affineNative (2^(12+1) ^^^ 62) := by decide +kernel

theorem selectedBound28533 : packedSelected [0,1,3,7,11,12,15,16,18,19,21] rootPS < 2^1333 := by decide +kernel

def env28534 : List Nat := [2,4,8,16,32,1,128,188,512,172,513,696,62,1,159,129,60,0,516,158,697,649,60,128,543,645,147,44,1,28,51,26,189,17,16,168]

theorem envBound28534 : H12AffineFastState.Bounded env28534 := by
  intro p hp
  have h : env28534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28533_28534 : H12AffineEnvironment.transform 12 62 env28533 = env28534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 62 env28533 == env28534) = true)

theorem identity28534 : scanCanonicalize (H12AffineFastState.compose env28534 (packedSelected [1,2,3,4,5,9,10,11,16,17,18] rootPS)) = affineNative (2^(8+1) ^^^ 7) := by decide +kernel

theorem selectedBound28534 : packedSelected [1,2,3,4,5,9,10,11,16,17,18] rootPS < 2^1333 := by decide +kernel

def env28535 : List Nat := [2,4,8,16,32,1,128,188,7,172,6,191,62,1,159,129,60,0,3,158,190,142,60,128,24,130,147,44,1,28,51,26,189,17,16,168]

theorem envBound28535 : H12AffineFastState.Bounded env28535 := by
  intro p hp
  have h : env28535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28534_28535 : H12AffineEnvironment.transform 8 7 env28534 = env28535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 7 env28534 == env28535) = true)

theorem identity28535 : scanCanonicalize (H12AffineFastState.compose env28535 (packedSelected [0,7,11] rootPS)) = affineNative (2^(6+1) ^^^ 50) := by decide +kernel

theorem selectedBound28535 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env28536 : List Nat := [2,4,8,16,32,1,50,14,7,30,6,13,62,1,45,51,60,0,3,44,12,60,60,50,24,48,33,44,1,28,51,26,15,17,16,26]

theorem envBound28536 : H12AffineFastState.Bounded env28536 := by
  intro p hp
  have h : env28536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28535_28536 : H12AffineEnvironment.transform 6 50 env28535 = env28536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 50 env28535 == env28536) = true)

theorem identity28536 : scanCanonicalize (H12AffineFastState.compose env28536 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound28536 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env28537 : List Nat := [2,4,8,16,16,1,2,14,7,30,6,13,14,1,29,3,12,0,3,28,12,12,12,2,24,0,17,28,1,28,3,26,15,17,16,26]

theorem envBound28537 : H12AffineFastState.Bounded env28537 := by
  intro p hp
  have h : env28537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28536_28537 : H12AffineEnvironment.transform 4 16 env28536 = env28537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env28536 == env28537) = true)

theorem identity28537 : scanCanonicalize (H12AffineFastState.compose env28537 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound28537 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28538 : List Nat := [2,4,8,7,7,1,2,14,7,9,6,13,14,1,10,3,12,0,3,11,12,12,12,2,15,0,6,11,1,11,3,13,15,6,7,13]

theorem envBound28538 : H12AffineFastState.Bounded env28538 := by
  intro p hp
  have h : env28538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28537_28538 : H12AffineEnvironment.transform 3 7 env28537 = env28538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env28537 == env28538) = true)

def env28539 : List Nat := [2,4,8,16,32,1,128,189,512,173,513,697,8192,1,8352,8383,61,8254,516,8353,696,649,61,8382,8736,645,146,45,1,29,8205,8229,188,17,16,169]

theorem envBound28539 : H12AffineFastState.Bounded env28539 := by
  intro p hp
  have h : env28539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28532_28539 : H12AffineEnvironment.transform 7 189 env28532 = env28539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 189 env28532 == env28539) = true)

theorem identity28539 : scanCanonicalize (H12AffineFastState.compose env28539 (packedSelected [0,1,3,7,11,12,15,16,18,19,21] rootPS)) = affineNative (2^(12+1) ^^^ 144) := by decide +kernel

theorem selectedBound28539 : packedSelected [0,1,3,7,11,12,15,16,18,19,21] rootPS < 2^1333 := by decide +kernel

def env28540 : List Nat := [2,4,8,16,32,1,128,189,512,173,513,697,144,1,48,47,61,174,516,49,696,649,61,46,688,645,146,45,1,29,157,181,188,17,16,169]

theorem envBound28540 : H12AffineFastState.Bounded env28540 := by
  intro p hp
  have h : env28540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28539_28540 : H12AffineEnvironment.transform 12 144 env28539 = env28540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 144 env28539 == env28540) = true)

theorem identity28540 : scanCanonicalize (H12AffineFastState.compose env28540 (packedSelected [1,2,3,5,8,10,12,13] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound28540 : packedSelected [1,2,3,5,8,10,12,13] rootPS < 2^1333 := by decide +kernel

def env28541 : List Nat := [2,4,8,16,0,1,128,157,512,141,513,665,144,1,16,15,29,142,516,17,664,649,29,14,656,645,146,13,1,29,157,149,156,17,16,137]

theorem envBound28541 : H12AffineFastState.Bounded env28541 := by
  intro p hp
  have h : env28541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28540_28541 : H12AffineEnvironment.transform 4 0 env28540 = env28541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env28540 == env28541) = true)

theorem identity28541 : scanCanonicalize (H12AffineFastState.compose env28541 (packedSelected [1,4,8,9,11,12] rootPS)) = affineNative (2^(8+1) ^^^ 13) := by decide +kernel

theorem selectedBound28541 : packedSelected [1,4,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env28542 : List Nat := [2,4,8,16,0,1,128,157,13,141,12,148,144,1,16,15,29,142,9,17,149,132,29,14,157,136,146,13,1,29,157,149,156,17,16,137]

theorem envBound28542 : H12AffineFastState.Bounded env28542 := by
  intro p hp
  have h : env28542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28541_28542 : H12AffineEnvironment.transform 8 13 env28541 = env28542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 13 env28541 == env28542) = true)

theorem identity28542 : scanCanonicalize (H12AffineFastState.compose env28542 (packedSelected [0,1,3,5,7] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound28542 : packedSelected [0,1,3,5,7] rootPS < 2^1333 := by decide +kernel

def env28543 : List Nat := [2,4,2,16,0,1,128,151,7,135,6,148,144,1,16,5,23,132,3,17,149,132,23,4,151,130,146,7,1,23,151,149,150,17,16,131]

theorem envBound28543 : H12AffineFastState.Bounded env28543 := by
  intro p hp
  have h : env28543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28542_28543 : H12AffineEnvironment.transform 2 2 env28542 = env28543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env28542 == env28543) = true)

theorem identity28543 : scanCanonicalize (H12AffineFastState.compose env28543 (packedSelected [1,2] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound28543 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env28544 : List Nat := [2,4,2,16,0,1,2,21,7,5,6,22,18,1,16,5,23,6,3,17,23,6,23,4,21,0,16,7,1,23,21,23,20,17,16,1]

theorem envBound28544 : H12AffineFastState.Bounded env28544 := by
  intro p hp
  have h : env28544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28543_28544 : H12AffineEnvironment.transform 6 2 env28543 = env28544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env28543 == env28544) = true)

def env28545 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,773,8192,1,8540,65536,74110,65665,580,8541,772,648,74047,65600,9181,74299,366,74031,1,76638,8205,65831,257,17,81,340]

theorem envBound28545 : H12AffineFastState.Bounded env28545 := by
  intro p hp
  have h : env28545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28480_28545 : H12AffineEnvironment.transform 11 773 env28480 = env28545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 773 env28480 == env28545) = true)

def env28546 : List Nat := [2,4,8,16,32,0,128,256,512,272,2048,773,8192,1,8476,65536,74046,65665,516,8477,772,648,74047,65536,9117,74299,302,74031,1,76574,8205,65831,257,17,17,276]

theorem envBound28546 : H12AffineFastState.Bounded env28546 := by
  intro p hp
  have h : env28546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28545_28546 : H12AffineEnvironment.transform 5 0 env28545 = env28546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env28545 == env28546) = true)

theorem identity28546 : scanCanonicalize (H12AffineFastState.compose env28546 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 393) := by decide +kernel

theorem selectedBound28546 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env28547 : List Nat := [2,4,8,16,32,0,128,256,512,272,2048,773,393,1,149,65536,65719,65665,516,148,772,648,65718,65536,532,66482,302,65702,1,68247,388,65831,257,17,17,276]

theorem envBound28547 : H12AffineFastState.Bounded env28547 := by
  intro p hp
  have h : env28547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28546_28547 : H12AffineEnvironment.transform 12 393 env28546 = env28547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 393 env28546 == env28547) = true)

def env28548 : List Nat := [2,4,8,16,32,0,128,144,512,128,2048,661,25,1,149,65536,65719,65665,516,148,660,648,65718,65536,532,66082,190,65702,1,68247,20,65719,145,17,17,132]

theorem envBound28548 : H12AffineFastState.Bounded env28548 := by
  intro p hp
  have h : env28548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28547_28548 : H12AffineEnvironment.transform 7 144 env28547 = env28548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 144 env28547 == env28548) = true)

theorem identity28548 : scanCanonicalize (H12AffineFastState.compose env28548 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 51) := by decide +kernel

theorem selectedBound28548 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env28549 : List Nat := [2,4,8,16,32,0,128,144,512,128,2048,661,25,1,149,51,132,178,516,148,660,648,133,51,532,529,190,149,1,2724,20,132,145,17,17,132]

theorem envBound28549 : H12AffineFastState.Bounded env28549 := by
  intro p hp
  have h : env28549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28548_28549 : H12AffineEnvironment.transform 15 51 env28548 = env28549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 51 env28548 == env28549) = true)

theorem identity28549 : scanCanonicalize (H12AffineFastState.compose env28549 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound28549 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env28550 : List Nat := [2,4,8,16,32,0,128,144,0,128,2048,149,25,1,149,51,132,178,4,148,148,136,133,51,20,17,190,149,1,2212,20,132,145,17,17,132]

theorem envBound28550 : H12AffineFastState.Bounded env28550 := by
  intro p hp
  have h : env28550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28549_28550 : H12AffineEnvironment.transform 8 0 env28549 = env28550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env28549 == env28550) = true)

theorem identity28550 : scanCanonicalize (H12AffineFastState.compose env28550 (packedSelected [1,2,3,15] rootPS)) = affineNative (2^(6+1) ^^^ 52) := by decide +kernel

theorem selectedBound28550 : packedSelected [1,2,3,15] rootPS < 2^1333 := by decide +kernel

def env28551 : List Nat := [2,4,8,16,32,0,52,36,0,52,2048,33,25,1,33,51,48,6,4,32,32,60,49,51,20,17,10,33,1,2064,20,48,37,17,17,48]

theorem envBound28551 : H12AffineFastState.Bounded env28551 := by
  intro p hp
  have h : env28551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28550_28551 : H12AffineEnvironment.transform 6 52 env28550 = env28551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 52 env28550 == env28551) = true)

theorem identity28551 : scanCanonicalize (H12AffineFastState.compose env28551 (packedSelected [0,2,7,8,10,11] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound28551 : packedSelected [0,2,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env28552 : List Nat := [2,4,8,13,32,0,41,36,0,41,2048,33,4,1,33,46,45,6,4,32,32,33,44,46,9,12,10,33,1,2061,9,45,37,12,12,45]

theorem envBound28552 : H12AffineFastState.Bounded env28552 := by
  intro p hp
  have h : env28552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28551_28552 : H12AffineEnvironment.transform 3 13 env28551 = env28552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env28551 == env28552) = true)

theorem identity28552 : scanCanonicalize (H12AffineFastState.compose env28552 (packedSelected [0,2,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound28552 : packedSelected [0,2,5,7] rootPS < 2^1333 := by decide +kernel

def env28553 : List Nat := [2,4,8,13,32,0,41,36,0,41,11,33,4,1,33,46,45,6,4,32,32,33,44,46,9,12,10,33,1,6,9,45,37,12,12,45]

theorem envBound28553 : H12AffineFastState.Bounded env28553 := by
  intro p hp
  have h : env28553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28552_28553 : H12AffineEnvironment.transform 10 11 env28552 = env28553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env28552 == env28553) = true)

theorem identity28553 : scanCanonicalize (H12AffineFastState.compose env28553 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound28553 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env28554 : List Nat := [2,4,8,13,10,0,3,14,0,3,11,11,4,1,11,4,7,6,4,10,10,11,6,4,9,12,10,11,1,6,9,7,15,12,12,7]

theorem envBound28554 : H12AffineFastState.Bounded env28554 := by
  intro p hp
  have h : env28554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28553_28554 : H12AffineEnvironment.transform 4 10 env28553 = env28554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env28553 == env28554) = true)

theorem identity28554 : scanCanonicalize (H12AffineFastState.compose env28554 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound28554 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28555 : List Nat := [2,4,2,7,0,0,3,4,0,3,1,1,4,1,1,4,7,6,4,0,0,1,6,4,3,6,0,1,1,6,3,7,5,6,6,7]

theorem envBound28555 : H12AffineFastState.Bounded env28555 := by
  intro p hp
  have h : env28555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28554_28555 : H12AffineEnvironment.transform 2 2 env28554 = env28555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env28554 == env28555) = true)

theorem identity28555 : scanCanonicalize (H12AffineFastState.compose env28555 (packedSelected [0,4] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound28555 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env28556 : List Nat := [2,2,2,1,0,0,3,2,0,3,1,1,2,1,1,2,1,0,2,0,0,1,0,2,3,0,0,1,1,0,3,1,3,0,0,1]

theorem envBound28556 : H12AffineFastState.Bounded env28556 := by
  intro p hp
  have h : env28556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28555_28556 : H12AffineEnvironment.transform 1 2 env28555 = env28556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env28555 == env28556) = true)

theorem identity28556 : scanCanonicalize (H12AffineFastState.compose env28556 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound28556 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28557 : List Nat := [0,0,0,1,0,0,1,0,0,1,1,1,0,1,1,0,1,0,0,0,0,1,0,0,1,0,0,1,1,0,1,1,1,0,0,1]

theorem envBound28557 : H12AffineFastState.Bounded env28557 := by
  intro p hp
  have h : env28557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28556_28557 : H12AffineEnvironment.transform 0 0 env28556 = env28557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env28556 == env28557) = true)

def env28558 : List Nat := [2,4,8,16,32,0,128,145,512,129,2048,660,24,1,149,65536,65719,65665,516,148,661,648,65718,65536,532,66083,191,65702,1,68247,21,65718,144,17,17,133]

theorem envBound28558 : H12AffineFastState.Bounded env28558 := by
  intro p hp
  have h : env28558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28547_28558 : H12AffineEnvironment.transform 7 145 env28547 = env28558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 145 env28547 == env28558) = true)

theorem identity28558 : scanCanonicalize (H12AffineFastState.compose env28558 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 695) := by decide +kernel

theorem selectedBound28558 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env28559 : List Nat := [2,4,8,16,32,0,128,145,512,129,2048,660,24,1,149,695,512,566,516,148,661,648,513,695,532,148,191,529,1,2080,21,513,144,17,17,133]

theorem envBound28559 : H12AffineFastState.Bounded env28559 := by
  intro p hp
  have h : env28559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28558_28559 : H12AffineEnvironment.transform 15 695 env28558 = env28559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 695 env28558 == env28559) = true)

theorem identity28559 : scanCanonicalize (H12AffineFastState.compose env28559 (packedSelected [0,1,2,3,7,10,12,17,20] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound28559 : packedSelected [0,1,2,3,7,10,12,17,20] rootPS < 2^1333 := by decide +kernel

def env28560 : List Nat := [2,4,8,16,32,0,128,145,512,129,32,660,24,1,149,695,512,566,516,148,661,648,513,695,532,148,191,529,1,0,21,513,144,17,17,133]

theorem envBound28560 : H12AffineFastState.Bounded env28560 := by
  intro p hp
  have h : env28560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28559_28560 : H12AffineEnvironment.transform 10 32 env28559 = env28560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env28559 == env28560) = true)

theorem identity28560 : scanCanonicalize (H12AffineFastState.compose env28560 (packedSelected [0,1,2,3,4,7,8,9,10,12,13,15,16,17,18] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound28560 : packedSelected [0,1,2,3,4,7,8,9,10,12,13,15,16,17,18] rootPS < 2^1333 := by decide +kernel

def env28561 : List Nat := [2,4,4,16,32,0,128,145,512,129,32,660,20,1,149,695,512,566,516,148,661,644,513,695,532,148,179,529,1,0,21,513,144,17,17,133]

theorem envBound28561 : H12AffineFastState.Bounded env28561 := by
  intro p hp
  have h : env28561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28560_28561 : H12AffineEnvironment.transform 2 4 env28560 = env28561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env28560 == env28561) = true)

theorem identity28561 : scanCanonicalize (H12AffineFastState.compose env28561 (packedSelected [1,2,3,5,7,9,10] rootPS)) = affineNative (2^(8+1) ^^^ 147) := by decide +kernel

theorem selectedBound28561 : packedSelected [1,2,3,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env28562 : List Nat := [2,4,4,16,32,0,128,145,147,129,32,7,20,1,149,36,147,165,151,148,6,23,146,36,135,148,179,130,1,0,21,146,144,17,17,133]

theorem envBound28562 : H12AffineFastState.Bounded env28562 := by
  intro p hp
  have h : env28562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28561_28562 : H12AffineEnvironment.transform 8 147 env28561 = env28562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 147 env28561 == env28562) = true)

theorem identity28562 : scanCanonicalize (H12AffineFastState.compose env28562 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound28562 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env28563 : List Nat := [2,4,4,16,7,0,128,145,147,129,7,7,20,1,149,3,147,130,151,148,6,23,146,3,135,148,148,130,1,0,21,146,144,17,17,133]

theorem envBound28563 : H12AffineFastState.Bounded env28563 := by
  intro p hp
  have h : env28563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28562_28563 : H12AffineEnvironment.transform 4 7 env28562 = env28563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env28562 == env28563) = true)

theorem identity28563 : scanCanonicalize (H12AffineFastState.compose env28563 (packedSelected [2,3] rootPS)) = affineNative (2^(6+1) ^^^ 20) := by decide +kernel

theorem selectedBound28563 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env28564 : List Nat := [2,4,4,16,7,0,20,5,7,21,7,7,20,1,1,3,7,22,3,0,6,23,6,3,19,0,0,22,1,0,21,6,4,17,17,17]

theorem envBound28564 : H12AffineFastState.Bounded env28564 := by
  intro p hp
  have h : env28564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28563_28564 : H12AffineEnvironment.transform 6 20 env28563 = env28564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 20 env28563 == env28564) = true)

theorem identity28564 : scanCanonicalize (H12AffineFastState.compose env28564 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound28564 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28565 : List Nat := [2,3,3,16,0,0,19,2,0,18,0,0,19,1,1,3,0,17,3,0,1,16,1,3,19,0,0,17,1,0,18,1,3,17,17,17]

theorem envBound28565 : H12AffineFastState.Bounded env28565 := by
  intro p hp
  have h : env28565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28564_28565 : H12AffineEnvironment.transform 1 3 env28564 = env28565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env28564 == env28565) = true)

theorem identity28565 : scanCanonicalize (H12AffineFastState.compose env28565 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound28565 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28566 : List Nat := [2,3,3,1,0,0,2,2,0,3,0,0,2,1,1,3,0,0,3,0,1,1,1,3,2,0,0,0,1,0,3,1,3,0,0,0]

theorem envBound28566 : H12AffineFastState.Bounded env28566 := by
  intro p hp
  have h : env28566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28565_28566 : H12AffineEnvironment.transform 3 1 env28565 = env28566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env28565 == env28566) = true)

def env28567 : List Nat := [2,4,8,16,32,1,128,256,512,272,2048,773,8192,1,8477,65536,74047,65665,517,8476,772,648,74047,65537,9116,74299,303,74031,1,76575,8205,65831,257,17,16,277]

theorem envBound28567 : H12AffineFastState.Bounded env28567 := by
  intro p hp
  have h : env28567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28545_28567 : H12AffineEnvironment.transform 5 1 env28545 = env28567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env28545 == env28567) = true)

theorem identity28567 : scanCanonicalize (H12AffineFastState.compose env28567 (packedSelected [1,8,28] rootPS)) = affineNative (2^(7+1) ^^^ 145) := by decide +kernel

theorem selectedBound28567 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env28568 : List Nat := [2,4,8,16,32,1,128,145,512,129,2048,660,8192,1,8332,65536,73902,65665,517,8333,661,648,73902,65537,8717,74299,190,73918,1,76430,8205,65718,144,17,16,132]

theorem envBound28568 : H12AffineFastState.Bounded env28568 := by
  intro p hp
  have h : env28568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28567_28568 : H12AffineEnvironment.transform 7 145 env28567 = env28568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 145 env28567 == env28568) = true)

def env28569 : List Nat := [2,4,8,16,32,1,128,145,512,129,2048,660,24,1,148,65536,65718,65665,517,149,661,648,65718,65537,533,66083,190,65702,1,68246,21,65718,144,17,16,132]

theorem envBound28569 : H12AffineFastState.Bounded env28569 := by
  intro p hp
  have h : env28569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28568_28569 : H12AffineEnvironment.transform 12 24 env28568 = env28569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env28568 == env28569) = true)

theorem identity28569 : scanCanonicalize (H12AffineFastState.compose env28569 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 695) := by decide +kernel

theorem selectedBound28569 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env28570 : List Nat := [2,4,8,16,32,1,128,145,512,129,2048,660,24,1,148,695,513,566,517,149,661,648,513,694,533,148,190,529,1,2081,21,513,144,17,16,132]

theorem envBound28570 : H12AffineFastState.Bounded env28570 := by
  intro p hp
  have h : env28570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28569_28570 : H12AffineEnvironment.transform 15 695 env28569 = env28570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 695 env28569 == env28570) = true)

theorem identity28570 : scanCanonicalize (H12AffineFastState.compose env28570 (packedSelected [0,1,2,3,7,10,12,17,20] rootPS)) = affineNative (2^(10+1) ^^^ 560) := by decide +kernel

theorem selectedBound28570 : packedSelected [0,1,2,3,7,10,12,17,20] rootPS < 2^1333 := by decide +kernel

def env28571 : List Nat := [2,4,8,16,32,1,128,145,512,129,560,660,24,1,148,695,513,566,517,149,661,648,513,694,533,148,190,529,1,529,21,513,144,17,16,132]

theorem envBound28571 : H12AffineFastState.Bounded env28571 := by
  intro p hp
  have h : env28571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28570_28571 : H12AffineEnvironment.transform 10 560 env28570 = env28571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 560 env28570 == env28571) = true)

theorem identity28571 : scanCanonicalize (H12AffineFastState.compose env28571 (packedSelected [0,3,4,5,7,8,9,10,13,15,16,18] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound28571 : packedSelected [0,3,4,5,7,8,9,10,13,15,16,18] rootPS < 2^1333 := by decide +kernel

def env28572 : List Nat := [2,4,8,16,32,1,9,24,512,8,560,541,24,1,29,574,513,566,517,28,540,513,513,575,533,29,55,529,1,529,21,513,25,17,16,13]

theorem envBound28572 : H12AffineFastState.Bounded env28572 := by
  intro p hp
  have h : env28572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28571_28572 : H12AffineEnvironment.transform 6 9 env28571 = env28572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env28571 == env28572) = true)

theorem identity28572 : scanCanonicalize (H12AffineFastState.compose env28572 (packedSelected [1,3,10,11] rootPS)) = affineNative (2^(8+1) ^^^ 29) := by decide +kernel

theorem selectedBound28572 : packedSelected [1,3,10,11] rootPS < 2^1333 := by decide +kernel

def env28573 : List Nat := [2,4,8,16,32,1,9,24,29,8,45,0,24,1,29,35,28,43,24,28,1,28,28,34,8,29,55,12,1,12,21,28,25,17,16,13]

theorem envBound28573 : H12AffineFastState.Bounded env28573 := by
  intro p hp
  have h : env28573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28572_28573 : H12AffineEnvironment.transform 8 29 env28572 = env28573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 29 env28572 == env28573) = true)

theorem identity28573 : scanCanonicalize (H12AffineFastState.compose env28573 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound28573 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28574 : List Nat := [2,4,8,16,0,1,9,24,29,8,13,0,24,1,29,3,28,11,24,28,1,28,28,2,8,29,23,12,1,12,21,28,25,17,16,13]

theorem envBound28574 : H12AffineFastState.Bounded env28574 := by
  intro p hp
  have h : env28574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28573_28574 : H12AffineEnvironment.transform 4 0 env28573 = env28574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env28573 == env28574) = true)

theorem identity28574 : scanCanonicalize (H12AffineFastState.compose env28574 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound28574 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env28575 : List Nat := [2,4,8,12,0,1,9,4,1,8,13,0,4,1,1,3,0,11,4,0,1,0,0,2,8,1,11,12,1,12,9,0,5,13,12,13]

theorem envBound28575 : H12AffineFastState.Bounded env28575 := by
  intro p hp
  have h : env28575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28574_28575 : H12AffineEnvironment.transform 3 12 env28574 = env28575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env28574 == env28575) = true)

theorem identity28575 : scanCanonicalize (H12AffineFastState.compose env28575 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound28575 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env28576 : List Nat := [2,4,3,7,0,1,2,4,1,3,6,0,4,1,1,3,0,0,4,0,1,0,0,2,3,1,0,7,1,7,2,0,5,6,7,6]

theorem envBound28576 : H12AffineFastState.Bounded env28576 := by
  intro p hp
  have h : env28576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28575_28576 : H12AffineEnvironment.transform 2 3 env28575 = env28576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env28575 == env28576) = true)

theorem identity28576 : scanCanonicalize (H12AffineFastState.compose env28576 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound28576 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28577 : List Nat := [2,3,3,0,0,1,2,3,1,3,1,0,3,1,1,3,0,0,3,0,1,0,0,2,3,1,0,0,1,0,2,0,2,1,0,1]

theorem envBound28577 : H12AffineFastState.Bounded env28577 := by
  intro p hp
  have h : env28577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28576_28577 : H12AffineEnvironment.transform 1 3 env28576 = env28577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env28576 == env28577) = true)

def env28578 : List Nat := [2,4,8,16,32,1,128,145,512,129,2048,660,25,1,149,65536,65719,65665,517,148,661,648,65719,65537,532,66082,190,65703,1,68247,20,65718,144,17,16,132]

theorem envBound28578 : H12AffineFastState.Bounded env28578 := by
  intro p hp
  have h : env28578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28568_28578 : H12AffineEnvironment.transform 12 25 env28568 = env28578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env28568 == env28578) = true)

theorem identity28578 : scanCanonicalize (H12AffineFastState.compose env28578 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 50) := by decide +kernel

theorem selectedBound28578 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env28579 : List Nat := [2,4,8,16,32,1,128,145,512,129,2048,660,25,1,149,50,133,179,517,148,661,648,133,51,532,528,190,149,1,2725,20,132,144,17,16,132]

theorem envBound28579 : H12AffineFastState.Bounded env28579 := by
  intro p hp
  have h : env28579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28578_28579 : H12AffineEnvironment.transform 15 50 env28578 = env28579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 50 env28578 == env28579) = true)

theorem identity28579 : scanCanonicalize (H12AffineFastState.compose env28579 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound28579 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env28580 : List Nat := [2,4,8,16,32,1,128,145,1,129,2048,149,25,1,149,50,133,179,4,148,148,137,133,51,21,17,190,149,1,2212,20,132,144,17,16,132]

theorem envBound28580 : H12AffineFastState.Bounded env28580 := by
  intro p hp
  have h : env28580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28579_28580 : H12AffineEnvironment.transform 8 1 env28579 = env28580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env28579 == env28580) = true)

theorem identity28580 : scanCanonicalize (H12AffineFastState.compose env28580 (packedSelected [1,2,3,15] rootPS)) = affineNative (2^(6+1) ^^^ 36) := by decide +kernel

theorem selectedBound28580 : packedSelected [1,2,3,15] rootPS < 2^1333 := by decide +kernel

def env28581 : List Nat := [2,4,8,16,32,1,36,53,1,37,2048,49,25,1,49,50,33,23,4,48,48,45,33,51,21,17,26,49,1,2048,20,32,52,17,16,32]

theorem envBound28581 : H12AffineFastState.Bounded env28581 := by
  intro p hp
  have h : env28581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28580_28581 : H12AffineEnvironment.transform 6 36 env28580 = env28581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 36 env28580 == env28581) = true)

theorem identity28581 : scanCanonicalize (H12AffineFastState.compose env28581 (packedSelected [0,2,3,5,7,8,10,11] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound28581 : packedSelected [0,2,3,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env28582 : List Nat := [2,4,8,16,1,1,5,20,1,4,2048,16,25,1,16,19,0,23,4,17,17,12,0,18,21,17,26,16,1,2048,20,1,21,17,16,1]

theorem envBound28582 : H12AffineFastState.Bounded env28582 := by
  intro p hp
  have h : env28582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28581_28582 : H12AffineEnvironment.transform 4 1 env28581 = env28582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env28581 == env28582) = true)

theorem identity28582 : scanCanonicalize (H12AffineFastState.compose env28582 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 7) := by decide +kernel

theorem selectedBound28582 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28583 : List Nat := [2,4,8,16,1,1,5,20,1,4,7,16,25,1,16,19,0,23,4,17,17,12,0,18,21,17,26,16,1,7,20,1,21,17,16,1]

theorem envBound28583 : H12AffineFastState.Bounded env28583 := by
  intro p hp
  have h : env28583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28582_28583 : H12AffineEnvironment.transform 10 7 env28582 = env28583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 7 env28582 == env28583) = true)

theorem identity28583 : scanCanonicalize (H12AffineFastState.compose env28583 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound28583 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28584 : List Nat := [2,3,8,16,1,1,2,19,1,3,0,16,25,1,16,19,0,16,3,17,17,11,0,18,18,17,26,16,1,0,19,1,18,17,16,1]

theorem envBound28584 : H12AffineFastState.Bounded env28584 := by
  intro p hp
  have h : env28584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28583_28584 : H12AffineEnvironment.transform 1 3 env28583 = env28584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env28583 == env28584) = true)

theorem identity28584 : scanCanonicalize (H12AffineFastState.compose env28584 (packedSelected [0,3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound28584 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env28585 : List Nat := [2,3,2,16,1,1,2,19,1,3,0,16,19,1,16,19,0,16,3,17,17,1,0,18,18,17,16,16,1,0,19,1,18,17,16,1]

theorem envBound28585 : H12AffineFastState.Bounded env28585 := by
  intro p hp
  have h : env28585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28584_28585 : H12AffineEnvironment.transform 2 2 env28584 = env28585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env28584 == env28585) = true)

theorem identity28585 : scanCanonicalize (H12AffineFastState.compose env28585 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound28585 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

end H12CloudChart2