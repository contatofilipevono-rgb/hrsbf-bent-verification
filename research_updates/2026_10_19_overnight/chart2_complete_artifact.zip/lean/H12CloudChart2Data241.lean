import H12CloudChart2Data240

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity60893 : scanCanonicalize (H12AffineFastState.compose env60893 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 62) := by decide +kernel

theorem selectedBound60893 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env60894 : List Nat := [2,4,8,16,32,17,57,62,0,1024,43,1029,51,1070,42,35,1070,27,1066,43,1028,10,16,1078,40,58,1029,1071,1070,27,62,1087,62,59,1071,43]

theorem envBound60894 : H12AffineFastState.Bounded env60894 := by
  intro p hp
  have h : env60894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60893_60894 : H12AffineEnvironment.transform 7 62 env60893 = env60894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 62 env60893 == env60894) = true)

theorem identity60894 : scanCanonicalize (H12AffineFastState.compose env60894 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 31) := by decide +kernel

theorem selectedBound60894 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env60895 : List Nat := [2,4,8,16,32,17,57,62,0,31,43,26,51,49,42,35,49,27,53,43,27,10,16,41,40,58,26,48,49,27,62,32,62,59,48,43]

theorem envBound60895 : H12AffineFastState.Bounded env60895 := by
  intro p hp
  have h : env60895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60894_60895 : H12AffineEnvironment.transform 9 31 env60894 = env60895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 31 env60894 == env60895) = true)

theorem identity60895 : scanCanonicalize (H12AffineFastState.compose env60895 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound60895 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env60896 : List Nat := [2,4,8,16,10,17,19,20,0,31,1,26,25,27,0,9,27,27,31,1,27,10,16,3,2,16,26,26,27,27,20,10,20,17,26,1]

theorem envBound60896 : H12AffineFastState.Bounded env60896 := by
  intro p hp
  have h : env60896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60895_60896 : H12AffineEnvironment.transform 4 10 env60895 = env60896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env60895 == env60896) = true)

theorem identity60896 : scanCanonicalize (H12AffineFastState.compose env60896 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound60896 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env60897 : List Nat := [2,4,8,3,10,2,0,7,0,12,1,9,10,8,0,9,8,8,12,1,8,10,3,3,2,3,9,9,8,8,7,10,7,2,9,1]

theorem envBound60897 : H12AffineFastState.Bounded env60897 := by
  intro p hp
  have h : env60897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60896_60897 : H12AffineEnvironment.transform 3 3 env60896 = env60897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env60896 == env60897) = true)

theorem identity60897 : scanCanonicalize (H12AffineFastState.compose env60897 (packedSelected [0,4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound60897 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env60898 : List Nat := [2,4,3,3,1,2,0,7,0,7,1,2,1,3,0,2,3,3,7,1,3,1,3,3,2,3,2,2,3,3,7,1,7,2,2,1]

theorem envBound60898 : H12AffineFastState.Bounded env60898 := by
  intro p hp
  have h : env60898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60897_60898 : H12AffineEnvironment.transform 2 3 env60897 = env60898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env60897 == env60898) = true)

theorem identity60898 : scanCanonicalize (H12AffineFastState.compose env60898 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound60898 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60899 : List Nat := [2,2,3,3,1,2,0,1,0,1,1,2,1,3,0,2,3,3,1,1,3,1,3,3,2,3,2,2,3,3,1,1,1,2,2,1]

theorem envBound60899 : H12AffineFastState.Bounded env60899 := by
  intro p hp
  have h : env60899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60898_60899 : H12AffineEnvironment.transform 1 2 env60898 = env60899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env60898 == env60899) = true)

theorem identity60899 : scanCanonicalize (H12AffineFastState.compose env60899 (packedSelected [5] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound60899 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env60900 : List Nat := [1,1,0,0,1,1,0,1,0,1,1,1,1,0,0,1,0,0,1,1,0,1,0,0,1,0,1,1,0,0,1,1,1,1,1,1]

theorem envBound60900 : H12AffineFastState.Bounded env60900 := by
  intro p hp
  have h : env60900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60899_60900 : H12AffineEnvironment.transform 0 1 env60899 = env60900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env60899 == env60900) = true)

def env60901 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1344,262144,77935,32769,4097,46529,16,266384,70887,78894,77840,1297,74814,81227,365713,74798,256,308667,1344,79470]

theorem envBound60901 : H12AffineFastState.Bounded env60901 := by
  intro p hp
  have h : env60901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60847_60901 : H12AffineEnvironment.transform 13 1297 env60847 = env60901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env60847 == env60901) = true)

theorem identity60901 : scanCanonicalize (H12AffineFastState.compose env60901 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32883) := by decide +kernel

theorem selectedBound60901 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env60902 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,32883,1344,262144,45084,32769,4097,46529,16,266384,38036,46173,45155,1297,42061,48440,267490,42077,256,308667,1344,46621]

theorem envBound60902 : H12AffineFastState.Bounded env60902 := by
  intro p hp
  have h : env60902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60901_60902 : H12AffineEnvironment.transform 15 32883 env60901 = env60902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32883 env60901 == env60902) = true)

def env60903 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32883,1344,262144,42332,32769,1345,41089,16,263632,33236,41245,42275,1297,42061,43128,262562,42077,256,303355,1344,41821]

theorem envBound60903 : H12AffineFastState.Bounded env60903 := by
  intro p hp
  have h : env60903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60902_60903 : H12AffineEnvironment.transform 11 1344 env60902 = env60903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env60902 == env60903) = true)

theorem identity60903 : scanCanonicalize (H12AffineFastState.compose env60903 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 9292) := by decide +kernel

theorem selectedBound60903 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env60904 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,9292,9279,1344,262144,272,9293,1345,1229,16,263632,9624,1361,367,1297,1,3124,262562,17,256,263351,1344,1809]

theorem envBound60904 : H12AffineFastState.Bounded env60904 := by
  intro p hp
  have h : env60904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60903_60904 : H12AffineEnvironment.transform 14 9292 env60903 = env60904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9292 env60903 == env60904) = true)

theorem identity60904 : scanCanonicalize (H12AffineFastState.compose env60904 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound60904 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env60905 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,81,8192,0,8541,8494,81,262144,272,8540,80,476,16,262337,8329,64,367,0,1,2341,262562,17,256,262566,81,512]

theorem envBound60905 : H12AffineFastState.Bounded env60905 := by
  intro p hp
  have h : env60905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60904_60905 : H12AffineEnvironment.transform 9 273 env60904 = env60905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env60904 == env60905) = true)

theorem identity60905 : scanCanonicalize (H12AffineFastState.compose env60905 (packedSelected [4,9,16] rootPS)) = affineNative (2^(17+1) ^^^ 243) := by decide +kernel

theorem selectedBound60905 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60906 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,81,8192,0,8541,8494,81,243,272,8540,80,476,16,50,8329,64,367,0,1,2341,337,17,256,341,81,512]

theorem envBound60906 : H12AffineFastState.Bounded env60906 := by
  intro p hp
  have h : env60906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60905_60906 : H12AffineEnvironment.transform 17 243 env60905 = env60906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 243 env60905 == env60906) = true)

theorem identity60906 : scanCanonicalize (H12AffineFastState.compose env60906 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 980) := by decide +kernel

theorem selectedBound60906 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env60907 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,81,980,0,649,762,81,243,272,648,80,476,16,50,861,64,367,0,1,2341,337,17,256,341,81,512]

theorem envBound60907 : H12AffineFastState.Bounded env60907 := by
  intro p hp
  have h : env60907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60906_60907 : H12AffineEnvironment.transform 12 980 env60906 = env60907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 980 env60906 == env60907) = true)

theorem identity60907 : scanCanonicalize (H12AffineFastState.compose env60907 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound60907 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env60908 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,900,0,649,682,1,163,272,648,0,396,16,50,781,16,319,0,1,2341,257,17,256,261,1,512]

theorem envBound60908 : H12AffineFastState.Bounded env60908 := by
  intro p hp
  have h : env60908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60907_60908 : H12AffineEnvironment.transform 5 16 env60907 = env60908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env60907 == env60908) = true)

theorem identity60908 : scanCanonicalize (H12AffineFastState.compose env60908 (packedSelected [1,3,13] rootPS)) = affineNative (2^(10+1) ^^^ 391) := by decide +kernel

theorem selectedBound60908 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env60909 : List Nat := [2,4,8,16,32,16,128,256,512,273,391,1,900,0,649,682,1,163,272,648,0,396,16,50,781,16,319,0,1,162,257,17,256,261,1,512]

theorem envBound60909 : H12AffineFastState.Bounded env60909 := by
  intro p hp
  have h : env60909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60908_60909 : H12AffineEnvironment.transform 10 391 env60908 = env60909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 391 env60908 == env60909) = true)

theorem identity60909 : scanCanonicalize (H12AffineFastState.compose env60909 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound60909 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env60910 : List Nat := [2,4,8,16,32,16,128,20,512,5,147,1,656,0,649,682,1,163,4,648,0,152,16,50,537,16,43,0,1,162,21,17,20,17,1,512]

theorem envBound60910 : H12AffineFastState.Bounded env60910 := by
  intro p hp
  have h : env60910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60909_60910 : H12AffineEnvironment.transform 7 20 env60909 = env60910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env60909 == env60910) = true)

theorem identity60910 : scanCanonicalize (H12AffineFastState.compose env60910 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 14) := by decide +kernel

theorem selectedBound60910 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env60911 : List Nat := [2,4,8,16,32,16,14,20,512,5,29,1,542,0,519,548,1,45,4,518,0,22,16,50,537,16,43,0,1,44,21,17,20,17,1,512]

theorem envBound60911 : H12AffineFastState.Bounded env60911 := by
  intro p hp
  have h : env60911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60910_60911 : H12AffineEnvironment.transform 6 14 env60910 = env60911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 14 env60910 == env60911) = true)

theorem identity60911 : scanCanonicalize (H12AffineFastState.compose env60911 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound60911 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env60912 : List Nat := [2,2,8,16,32,16,8,18,512,3,27,1,536,0,513,546,1,43,2,512,0,16,16,50,537,16,43,0,1,42,19,17,18,17,1,512]

theorem envBound60912 : H12AffineFastState.Bounded env60912 := by
  intro p hp
  have h : env60912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60911_60912 : H12AffineEnvironment.transform 1 2 env60911 = env60912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env60911 == env60912) = true)

theorem identity60912 : scanCanonicalize (H12AffineFastState.compose env60912 (packedSelected [0,2,4] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound60912 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env60913 : List Nat := [2,2,8,16,10,16,8,18,512,3,27,1,536,0,513,520,1,1,2,512,0,16,16,24,537,16,1,0,1,0,19,17,18,17,1,512]

theorem envBound60913 : H12AffineFastState.Bounded env60913 := by
  intro p hp
  have h : env60913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60912_60913 : H12AffineEnvironment.transform 4 10 env60912 = env60913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env60912 == env60913) = true)

theorem identity60913 : scanCanonicalize (H12AffineFastState.compose env60913 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound60913 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60914 : List Nat := [2,2,8,10,10,10,8,8,512,3,1,1,514,0,513,520,1,1,2,512,0,10,10,2,515,10,1,0,1,0,9,11,8,11,1,512]

theorem envBound60914 : H12AffineFastState.Bounded env60914 := by
  intro p hp
  have h : env60914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60913_60914 : H12AffineEnvironment.transform 3 10 env60913 = env60914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env60913 == env60914) = true)

def env60915 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32883,1344,262144,42333,32769,1344,41088,16,263633,33237,41244,42274,1297,42061,43129,262563,42077,256,303354,1344,41820]

theorem envBound60915 : H12AffineFastState.Bounded env60915 := by
  intro p hp
  have h : env60915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60902_60915 : H12AffineEnvironment.transform 11 1345 env60902 = env60915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env60902 == env60915) = true)

theorem identity60915 : scanCanonicalize (H12AffineFastState.compose env60915 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 9406) := by decide +kernel

theorem selectedBound60915 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env60916 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32883,1344,9406,42333,32769,1344,41088,16,8559,33237,41244,42274,1297,42061,43129,9501,42077,256,33860,1344,41820]

theorem envBound60916 : H12AffineFastState.Bounded env60916 := by
  intro p hp
  have h : env60916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60915_60916 : H12AffineEnvironment.transform 17 9406 env60915 = env60916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 9406 env60915 == env60916) = true)

theorem identity60916 : scanCanonicalize (H12AffineFastState.compose env60916 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(14+1) ^^^ 9173) := by decide +kernel

theorem selectedBound60916 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env60917 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,9173,9126,1344,9406,1672,9172,1344,853,16,8559,8704,713,1783,1297,1944,2988,9501,1928,256,10129,1344,137]

theorem envBound60917 : H12AffineFastState.Bounded env60917 := by
  intro p hp
  have h : env60917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60916_60917 : H12AffineEnvironment.transform 14 9173 env60916 = env60917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9173 env60916 == env60917) = true)

def env60918 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147521,16777216,533640,672784,17245633,148800,545088,96346,16876545,205167,256,17552660,1345,525825]

theorem envBound60918 : H12AffineFastState.Bounded env60918 := by
  intro p hp
  have h : env60918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60629_60918 : H12AffineEnvironment.transform 26 17245633 env60629 = env60918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245633 env60629 == env60918) = true)

theorem identity60918 : scanCanonicalize (H12AffineFastState.compose env60918 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 74863) := by decide +kernel

theorem selectedBound60918 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env60919 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,524288,32769,4097,61648,91182,16777216,533640,614527,17039790,90415,545088,96346,16876545,1280,256,17363323,1345,525825]

theorem envBound60919 : H12AffineFastState.Bounded env60919 := by
  intro p hp
  have h : env60919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60918_60919 : H12AffineEnvironment.transform 16 74863 env60918 = env60919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 74863 env60918 == env60919) = true)

def env60920 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,524288,32769,4097,61648,91182,123164,533640,614527,385202,90415,545088,96346,25885,1280,256,594023,1345,525825]

theorem envBound60920 : H12AffineFastState.Bounded env60920 := by
  intro p hp
  have h : env60920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60919_60920 : H12AffineEnvironment.transform 23 123164 env60919 = env60920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 123164 env60919 == env60920) = true)

def env60921 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,21584,32769,4097,61648,91182,123164,28888,78895,385202,90415,1296,96346,25885,1280,256,82999,1345,21073]

theorem envBound60921 : H12AffineFastState.Bounded env60921 := by
  intro p hp
  have h : env60921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60920_60921 : H12AffineEnvironment.transform 18 21584 env60920 = env60921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21584 env60920 == env60921) = true)

theorem identity60921 : scanCanonicalize (H12AffineFastState.compose env60921 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 25676) := by decide +kernel

theorem selectedBound60921 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env60922 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,25676,65536,74863,262144,21584,25677,4097,5276,91182,66896,28888,78895,328958,90415,1296,96346,25885,1280,256,82999,1345,21073]

theorem envBound60922 : H12AffineFastState.Bounded env60922 := by
  intro p hp
  have h : env60922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60921_60922 : H12AffineEnvironment.transform 14 25676 env60921 = env60922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25676 env60921 == env60922) = true)

def env60923 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74863,262144,4416,8541,4097,5276,74046,66896,13768,78895,328958,74815,1296,81226,8205,1280,256,65831,1345,5953]

theorem envBound60923 : H12AffineFastState.Bounded env60923 := by
  intro p hp
  have h : env60923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60922_60923 : H12AffineEnvironment.transform 13 1296 env60922 = env60923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env60922 == env60923) = true)

def env60924 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74863,65664,4416,8541,4097,5276,74046,66896,13768,78895,1150,74815,1296,81226,8205,1280,256,65831,1345,5953]

theorem envBound60924 : H12AffineFastState.Bounded env60924 := by
  intro p hp
  have h : env60924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60923_60924 : H12AffineEnvironment.transform 17 65664 env60923 = env60924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env60923 == env60924) = true)

theorem identity60924 : scanCanonicalize (H12AffineFastState.compose env60924 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound60924 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env60925 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,8192,0,8540,65536,74111,65664,4416,8541,4097,4492,74046,65600,12504,78143,366,74031,0,79962,8205,16,256,65831,81,4689]

theorem envBound60925 : H12AffineFastState.Bounded env60925 := by
  intro p hp
  have h : env60925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60924_60925 : H12AffineEnvironment.transform 9 272 env60924 = env60925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env60924 == env60925) = true)

def env60926 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,772,8192,0,8540,65536,74111,65664,580,8541,773,648,74046,65600,9180,74299,366,74031,0,76638,8205,16,256,65831,81,341]

theorem envBound60926 : H12AffineFastState.Bounded env60926 := by
  intro p hp
  have h : env60926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60925_60926 : H12AffineEnvironment.transform 11 772 env60925 = env60926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 772 env60925 == env60926) = true)

def env60927 : List Nat := [2,4,8,16,32,0,128,256,512,272,2048,772,8192,0,8476,65536,74047,65664,516,8477,773,648,74046,65536,9116,74299,302,74031,0,76574,8205,16,256,65831,17,277]

theorem envBound60927 : H12AffineFastState.Bounded env60927 := by
  intro p hp
  have h : env60927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60926_60927 : H12AffineEnvironment.transform 5 0 env60926 = env60927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env60926 == env60927) = true)

theorem identity60927 : scanCanonicalize (H12AffineFastState.compose env60927 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 679) := by decide +kernel

theorem selectedBound60927 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env60928 : List Nat := [2,4,8,16,32,0,128,256,512,272,2048,772,8192,0,8476,679,9112,551,516,8477,773,648,9113,679,9116,8348,302,9096,0,10681,8205,16,256,896,17,277]

theorem envBound60928 : H12AffineFastState.Bounded env60928 := by
  intro p hp
  have h : env60928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60927_60928 : H12AffineEnvironment.transform 15 679 env60927 = env60928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 679 env60927 == env60928) = true)

def env60929 : List Nat := [2,4,8,16,32,0,128,256,400,272,2048,148,8192,0,8476,311,8200,439,404,8477,149,280,8201,311,8204,8348,302,8216,0,10681,8205,16,256,16,17,277]

theorem envBound60929 : H12AffineFastState.Bounded env60929 := by
  intro p hp
  have h : env60929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60928_60929 : H12AffineEnvironment.transform 8 400 env60928 = env60929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 400 env60928 == env60929) = true)

theorem identity60929 : scanCanonicalize (H12AffineFastState.compose env60929 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(12+1) ^^^ 393) := by decide +kernel

theorem selectedBound60929 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env60930 : List Nat := [2,4,8,16,32,0,128,256,400,272,2048,148,393,0,149,311,385,439,404,148,149,280,384,311,389,277,302,401,0,2096,388,16,256,16,17,277]

theorem envBound60930 : H12AffineFastState.Bounded env60930 := by
  intro p hp
  have h : env60930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60929_60930 : H12AffineEnvironment.transform 12 393 env60929 = env60930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 393 env60929 == env60930) = true)

theorem identity60930 : scanCanonicalize (H12AffineFastState.compose env60930 (packedSelected [1,3,4,9,13,15,16,17,19] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound60930 : packedSelected [1,3,4,9,13,15,16,17,19] rootPS < 2^1333 := by decide +kernel

def env60931 : List Nat := [2,4,8,16,1,0,128,256,400,272,2048,148,393,0,149,278,385,406,404,148,149,280,384,278,389,277,271,401,0,2065,388,16,256,16,17,277]

theorem envBound60931 : H12AffineFastState.Bounded env60931 := by
  intro p hp
  have h : env60931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60930_60931 : H12AffineEnvironment.transform 4 1 env60930 = env60931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env60930 == env60931) = true)

theorem identity60931 : scanCanonicalize (H12AffineFastState.compose env60931 (packedSelected [3,4,9,10,16,17] rootPS)) = affineNative (2^(10+1) ^^^ 146) := by decide +kernel

theorem selectedBound60931 : packedSelected [3,4,9,10,16,17] rootPS < 2^1333 := by decide +kernel

def env60932 : List Nat := [2,4,8,16,1,0,128,256,400,272,146,148,393,0,149,278,385,406,404,148,149,280,384,278,389,277,271,401,0,131,388,16,256,16,17,277]

theorem envBound60932 : H12AffineFastState.Bounded env60932 := by
  intro p hp
  have h : env60932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60931_60932 : H12AffineEnvironment.transform 10 146 env60931 = env60932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 146 env60931 == env60932) = true)

theorem identity60932 : scanCanonicalize (H12AffineFastState.compose env60932 (packedSelected [0,2,3,4,7,8,9,12] rootPS)) = affineNative (2^(7+1) ^^^ 30) := by decide +kernel

theorem selectedBound60932 : packedSelected [0,2,3,4,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env60933 : List Nat := [2,4,8,16,1,0,128,30,142,14,146,148,151,0,149,8,159,136,138,148,149,6,158,8,155,11,17,143,0,131,154,16,30,16,17,11]

theorem envBound60933 : H12AffineFastState.Bounded env60933 := by
  intro p hp
  have h : env60933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60932_60933 : H12AffineEnvironment.transform 7 30 env60932 = env60933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 30 env60932 == env60933) = true)

theorem identity60933 : scanCanonicalize (H12AffineFastState.compose env60933 (packedSelected [0,2,4] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound60933 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env60934 : List Nat := [2,4,8,10,1,0,128,4,142,14,136,142,141,0,143,8,133,136,138,142,143,6,132,8,129,11,11,143,0,131,128,10,4,10,11,11]

theorem envBound60934 : H12AffineFastState.Bounded env60934 := by
  intro p hp
  have h : env60934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60933_60934 : H12AffineEnvironment.transform 3 10 env60933 = env60934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env60933 == env60934) = true)

theorem identity60934 : scanCanonicalize (H12AffineFastState.compose env60934 (packedSelected [2,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound60934 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env60935 : List Nat := [2,4,8,10,1,0,3,4,13,14,11,13,14,0,12,8,6,11,9,13,12,6,7,8,2,11,11,12,0,0,3,10,4,10,11,11]

theorem envBound60935 : H12AffineFastState.Bounded env60935 := by
  intro p hp
  have h : env60935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60934_60935 : H12AffineEnvironment.transform 6 3 env60934 = env60935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env60934 == env60935) = true)

theorem identity60935 : scanCanonicalize (H12AffineFastState.compose env60935 (packedSelected [1,2] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound60935 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env60936 : List Nat := [2,4,5,7,1,0,3,4,0,3,6,0,3,0,1,5,6,6,4,0,1,6,7,5,2,6,6,1,0,0,3,7,4,7,6,6]

theorem envBound60936 : H12AffineFastState.Bounded env60936 := by
  intro p hp
  have h : env60936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60935_60936 : H12AffineEnvironment.transform 2 5 env60935 = env60936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env60935 == env60936) = true)

def env60937 : List Nat := [2,4,8,16,32,0,128,256,401,272,2048,149,8192,0,8476,310,8201,438,405,8477,148,281,8200,310,8205,8348,302,8217,0,10681,8205,16,256,17,17,277]

theorem envBound60937 : H12AffineFastState.Bounded env60937 := by
  intro p hp
  have h : env60937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60928_60937 : H12AffineEnvironment.transform 8 401 env60928 = env60937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 401 env60928 == env60937) = true)

theorem identity60937 : scanCanonicalize (H12AffineFastState.compose env60937 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(6+1) ^^^ 20) := by decide +kernel

theorem selectedBound60937 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env60938 : List Nat := [2,4,8,16,32,0,20,256,261,272,2048,1,8192,0,8476,310,8201,290,257,8477,0,281,8200,310,8205,8200,302,8217,0,10541,8205,16,256,17,17,277]

theorem envBound60938 : H12AffineFastState.Bounded env60938 := by
  intro p hp
  have h : env60938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60937_60938 : H12AffineEnvironment.transform 6 20 env60937 = env60938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 20 env60937 == env60938) = true)

theorem identity60938 : scanCanonicalize (H12AffineFastState.compose env60938 (packedSelected [2,4,9,11,12,13,15,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 256) := by decide +kernel

theorem selectedBound60938 : packedSelected [2,4,9,11,12,13,15,16,18] rootPS < 2^1333 := by decide +kernel

def env60939 : List Nat := [2,4,8,16,32,0,20,256,261,272,2048,1,256,0,28,310,265,290,257,29,0,281,264,310,269,264,302,281,0,2093,269,16,256,17,17,277]

theorem envBound60939 : H12AffineFastState.Bounded env60939 := by
  intro p hp
  have h : env60939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60938_60939 : H12AffineEnvironment.transform 12 256 env60938 = env60939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 256 env60938 == env60939) = true)

theorem identity60939 : scanCanonicalize (H12AffineFastState.compose env60939 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound60939 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env60940 : List Nat := [2,4,8,16,32,0,20,20,17,4,2048,1,20,0,28,34,29,54,21,29,0,13,28,34,25,28,58,13,0,2093,25,16,20,17,17,1]

theorem envBound60940 : H12AffineFastState.Bounded env60940 := by
  intro p hp
  have h : env60940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60939_60940 : H12AffineEnvironment.transform 7 20 env60939 = env60940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env60939 == env60940) = true)

theorem identity60940 : scanCanonicalize (H12AffineFastState.compose env60940 (packedSelected [0,1,3,5,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 7) := by decide +kernel

theorem selectedBound60940 : packedSelected [0,1,3,5,7,11] rootPS < 2^1333 := by decide +kernel

def env60941 : List Nat := [2,4,8,16,32,0,20,20,17,4,7,1,20,0,28,34,29,54,21,29,0,13,28,34,25,28,58,13,0,42,25,16,20,17,17,1]

theorem envBound60941 : H12AffineFastState.Bounded env60941 := by
  intro p hp
  have h : env60941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60940_60941 : H12AffineEnvironment.transform 10 7 env60940 = env60941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 7 env60940 == env60941) = true)

theorem identity60941 : scanCanonicalize (H12AffineFastState.compose env60941 (packedSelected [0,1,4] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound60941 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env60942 : List Nat := [2,4,4,16,32,0,20,20,17,4,7,1,20,0,16,34,17,54,21,17,0,1,16,34,21,16,54,1,0,38,21,16,20,17,17,1]

theorem envBound60942 : H12AffineFastState.Bounded env60942 := by
  intro p hp
  have h : env60942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60941_60942 : H12AffineEnvironment.transform 2 4 env60941 = env60942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env60941 == env60942) = true)

theorem identity60942 : scanCanonicalize (H12AffineFastState.compose env60942 (packedSelected [2,3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound60942 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env60943 : List Nat := [2,4,4,1,32,0,5,5,0,4,7,1,5,0,1,34,0,39,4,0,0,1,1,34,4,1,39,1,0,38,4,1,5,0,0,1]

theorem envBound60943 : H12AffineFastState.Bounded env60943 := by
  intro p hp
  have h : env60943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60942_60943 : H12AffineEnvironment.transform 3 1 env60942 = env60943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env60942 == env60943) = true)

theorem identity60943 : scanCanonicalize (H12AffineFastState.compose env60943 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound60943 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env60944 : List Nat := [2,4,4,1,6,0,5,5,0,4,7,1,5,0,1,4,0,1,4,0,0,1,1,4,4,1,1,1,0,0,4,1,5,0,0,1]

theorem envBound60944 : H12AffineFastState.Bounded env60944 := by
  intro p hp
  have h : env60944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60943_60944 : H12AffineEnvironment.transform 4 6 env60943 = env60944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env60943 == env60944) = true)

theorem identity60944 : scanCanonicalize (H12AffineFastState.compose env60944 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound60944 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60945 : List Nat := [2,1,1,1,3,0,0,0,0,1,2,1,0,0,1,1,0,1,1,0,0,1,1,1,1,1,1,1,0,0,1,1,0,0,0,1]

theorem envBound60945 : H12AffineFastState.Bounded env60945 := by
  intro p hp
  have h : env60945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60944_60945 : H12AffineEnvironment.transform 1 1 env60944 = env60945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env60944 == env60945) = true)

def env60946 : List Nat := [2,4,8,16,32,1,128,256,512,272,2048,772,8192,0,8477,65536,74046,65664,517,8476,773,648,74046,65537,9117,74299,303,74031,0,76575,8205,16,256,65831,16,276]

theorem envBound60946 : H12AffineFastState.Bounded env60946 := by
  intro p hp
  have h : env60946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60926_60946 : H12AffineEnvironment.transform 5 1 env60926 = env60946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env60926 == env60946) = true)

theorem identity60946 : scanCanonicalize (H12AffineFastState.compose env60946 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 8894) := by decide +kernel

theorem selectedBound60946 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env60947 : List Nat := [2,4,8,16,32,1,128,256,512,272,2048,772,8192,0,8477,8894,896,8766,517,8476,773,648,896,8895,9117,133,303,913,0,2465,8205,16,256,9113,16,276]

theorem envBound60947 : H12AffineFastState.Bounded env60947 := by
  intro p hp
  have h : env60947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60946_60947 : H12AffineEnvironment.transform 15 8894 env60946 = env60947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8894 env60946 == env60947) = true)

def env60948 : List Nat := [2,4,8,16,32,1,128,256,512,272,2048,772,904,0,661,310,896,438,517,660,773,648,896,311,21,133,303,913,0,2465,901,16,256,17,16,276]

theorem envBound60948 : H12AffineFastState.Bounded env60948 := by
  intro p hp
  have h : env60948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60947_60948 : H12AffineEnvironment.transform 12 904 env60947 = env60948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 904 env60947 == env60948) = true)

theorem identity60948 : scanCanonicalize (H12AffineFastState.compose env60948 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound60948 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env60949 : List Nat := [2,4,8,16,32,1,128,256,261,272,2048,1,141,0,400,310,133,438,256,401,0,397,133,311,21,133,303,148,0,2465,128,16,256,17,16,276]

theorem envBound60949 : H12AffineFastState.Bounded env60949 := by
  intro p hp
  have h : env60949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60948_60949 : H12AffineEnvironment.transform 8 261 env60948 = env60949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env60948 == env60949) = true)

theorem identity60949 : scanCanonicalize (H12AffineFastState.compose env60949 (packedSelected [2,4,9,11,12,13,15,16,18] rootPS)) = affineNative (2^(7+1) ^^^ 25) := by decide +kernel

theorem selectedBound60949 : packedSelected [2,4,9,11,12,13,15,16,18] rootPS < 2^1333 := by decide +kernel

def env60950 : List Nat := [2,4,8,16,32,1,128,25,28,9,2048,1,141,0,137,47,133,175,25,136,0,148,133,46,21,133,54,148,0,2232,128,16,25,17,16,13]

theorem envBound60950 : H12AffineFastState.Bounded env60950 := by
  intro p hp
  have h : env60950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60949_60950 : H12AffineEnvironment.transform 7 25 env60949 = env60950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 25 env60949 == env60950) = true)

theorem identity60950 : scanCanonicalize (H12AffineFastState.compose env60950 (packedSelected [3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound60950 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env60951 : List Nat := [2,4,8,12,32,1,128,5,0,9,2048,1,141,0,137,47,133,175,5,136,0,136,133,46,9,133,42,136,0,2212,128,12,5,13,12,13]

theorem envBound60951 : H12AffineFastState.Bounded env60951 := by
  intro p hp
  have h : env60951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60950_60951 : H12AffineEnvironment.transform 3 12 env60950 = env60951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env60950 == env60951) = true)

theorem identity60951 : scanCanonicalize (H12AffineFastState.compose env60951 (packedSelected [0,2,3,7,8,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 174) := by decide +kernel

theorem selectedBound60951 : packedSelected [0,2,3,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env60952 : List Nat := [2,4,8,12,32,1,128,5,0,9,174,1,141,0,137,47,133,175,5,136,0,136,133,46,9,133,42,136,0,10,128,12,5,13,12,13]

theorem envBound60952 : H12AffineFastState.Bounded env60952 := by
  intro p hp
  have h : env60952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60951_60952 : H12AffineEnvironment.transform 10 174 env60951 = env60952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 174 env60951 == env60952) = true)

theorem identity60952 : scanCanonicalize (H12AffineFastState.compose env60952 (packedSelected [1,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound60952 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env60953 : List Nat := [2,4,8,12,1,1,128,5,0,9,143,1,141,0,137,14,133,142,5,136,0,136,133,15,9,133,11,136,0,10,128,12,5,13,12,13]

theorem envBound60953 : H12AffineFastState.Bounded env60953 := by
  intro p hp
  have h : env60953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60952_60953 : H12AffineEnvironment.transform 4 1 env60952 = env60953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env60952 == env60953) = true)

theorem identity60953 : scanCanonicalize (H12AffineFastState.compose env60953 (packedSelected [0,1,4] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound60953 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env60954 : List Nat := [2,4,8,12,1,1,9,5,0,9,6,1,4,0,0,14,12,7,5,1,0,1,12,15,9,12,11,1,0,10,9,12,5,13,12,13]

theorem envBound60954 : H12AffineFastState.Bounded env60954 := by
  intro p hp
  have h : env60954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60953_60954 : H12AffineEnvironment.transform 6 9 env60953 = env60954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env60953 == env60954) = true)

theorem identity60954 : scanCanonicalize (H12AffineFastState.compose env60954 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound60954 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env60955 : List Nat := [2,4,3,7,1,1,2,5,0,2,6,1,4,0,0,5,7,7,5,1,0,1,7,4,2,7,0,1,0,1,2,7,5,6,7,6]

theorem envBound60955 : H12AffineFastState.Bounded env60955 := by
  intro p hp
  have h : env60955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60954_60955 : H12AffineEnvironment.transform 2 3 env60954 = env60955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env60954 == env60955) = true)

def env60956 : List Nat := [2,4,8,16,32,1,128,256,512,272,2048,772,905,0,660,311,896,439,517,661,773,648,896,310,20,133,303,913,0,2465,900,16,256,16,16,276]

theorem envBound60956 : H12AffineFastState.Bounded env60956 := by
  intro p hp
  have h : env60956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60947_60956 : H12AffineEnvironment.transform 12 905 env60947 = env60956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 905 env60947 == env60956) = true)

theorem identity60956 : scanCanonicalize (H12AffineFastState.compose env60956 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 145) := by decide +kernel

theorem selectedBound60956 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env60957 : List Nat := [2,4,8,16,32,1,128,145,512,129,2048,661,536,0,660,166,529,38,517,661,660,648,529,167,20,133,190,512,0,2096,533,16,145,16,16,133]

theorem envBound60957 : H12AffineFastState.Bounded env60957 := by
  intro p hp
  have h : env60957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60956_60957 : H12AffineEnvironment.transform 7 145 env60956 = env60957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 145 env60956 == env60957) = true)

theorem identity60957 : scanCanonicalize (H12AffineFastState.compose env60957 (packedSelected [1,3,4,9,13,15,16,17,19] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound60957 : packedSelected [1,3,4,9,13,15,16,17,19] rootPS < 2^1333 := by decide +kernel

def env60958 : List Nat := [2,4,8,16,32,1,128,145,32,129,2048,181,56,0,180,166,49,38,37,181,180,168,49,167,20,133,190,32,0,2096,53,16,145,16,16,133]

theorem envBound60958 : H12AffineFastState.Bounded env60958 := by
  intro p hp
  have h : env60958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60957_60958 : H12AffineEnvironment.transform 8 32 env60957 = env60958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env60957 == env60958) = true)

theorem identity60958 : scanCanonicalize (H12AffineFastState.compose env60958 (packedSelected [3,4,9,10,16,17] rootPS)) = affineNative (2^(10+1) ^^^ 55) := by decide +kernel

theorem selectedBound60958 : packedSelected [3,4,9,10,16,17] rootPS < 2^1333 := by decide +kernel

def env60959 : List Nat := [2,4,8,16,32,1,128,145,32,129,55,181,56,0,180,166,49,38,37,181,180,168,49,167,20,133,190,32,0,7,53,16,145,16,16,133]

theorem envBound60959 : H12AffineFastState.Bounded env60959 := by
  intro p hp
  have h : env60959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60958_60959 : H12AffineEnvironment.transform 10 55 env60958 = env60959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 55 env60958 == env60959) = true)

theorem identity60959 : scanCanonicalize (H12AffineFastState.compose env60959 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 31) := by decide +kernel

theorem selectedBound60959 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env60960 : List Nat := [2,4,8,16,32,1,31,14,32,30,55,42,56,0,43,57,49,38,37,42,43,55,49,56,20,26,33,32,0,7,53,16,14,16,16,26]

theorem envBound60960 : H12AffineFastState.Bounded env60960 := by
  intro p hp
  have h : env60960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60959_60960 : H12AffineEnvironment.transform 6 31 env60959 = env60960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 31 env60959 == env60960) = true)

theorem identity60960 : scanCanonicalize (H12AffineFastState.compose env60960 (packedSelected [0,4,5] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound60960 : packedSelected [0,4,5] rootPS < 2^1333 := by decide +kernel

def env60961 : List Nat := [2,4,8,6,32,1,9,14,32,8,33,42,46,0,43,47,39,38,37,42,43,33,39,46,2,12,33,32,0,7,35,6,14,6,6,12]

theorem envBound60961 : H12AffineFastState.Bounded env60961 := by
  intro p hp
  have h : env60961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60960_60961 : H12AffineEnvironment.transform 3 6 env60960 = env60961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env60960 == env60961) = true)

theorem identity60961 : scanCanonicalize (H12AffineFastState.compose env60961 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound60961 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env60962 : List Nat := [2,4,8,6,0,1,9,14,0,8,1,10,14,0,11,15,7,6,5,10,11,1,7,14,2,12,1,0,0,7,3,6,14,6,6,12]

theorem envBound60962 : H12AffineFastState.Bounded env60962 := by
  intro p hp
  have h : env60962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60961_60962 : H12AffineEnvironment.transform 4 0 env60961 = env60962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env60961 == env60962) = true)

theorem identity60962 : scanCanonicalize (H12AffineFastState.compose env60962 (packedSelected [0,7] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound60962 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env60963 : List Nat := [2,4,3,6,0,1,2,5,0,3,1,1,5,0,0,4,7,6,5,1,0,1,7,5,2,7,1,0,0,7,3,6,5,6,6,7]

theorem envBound60963 : H12AffineFastState.Bounded env60963 := by
  intro p hp
  have h : env60963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60962_60963 : H12AffineEnvironment.transform 2 3 env60962 = env60963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env60962 == env60963) = true)

def env60964 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,773,8192,0,8540,65536,74111,65664,581,8541,772,649,74046,65600,9181,74298,366,74031,0,76639,8205,16,256,65831,81,340]

theorem envBound60964 : H12AffineFastState.Bounded env60964 := by
  intro p hp
  have h : env60964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60925_60964 : H12AffineEnvironment.transform 11 773 env60925 = env60964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 773 env60925 == env60964) = true)

def env60965 : List Nat := [2,4,8,16,32,0,128,256,512,272,2048,773,8192,0,8476,65536,74047,65664,517,8477,772,649,74046,65536,9117,74298,302,74031,0,76575,8205,16,256,65831,17,276]

theorem envBound60965 : H12AffineFastState.Bounded env60965 := by
  intro p hp
  have h : env60965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60964_60965 : H12AffineEnvironment.transform 5 0 env60964 = env60965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env60964 == env60965) = true)

theorem identity60965 : scanCanonicalize (H12AffineFastState.compose env60965 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 905) := by decide +kernel

theorem selectedBound60965 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env60966 : List Nat := [2,4,8,16,32,0,128,256,512,272,2048,773,905,0,661,65536,66230,65664,517,660,772,649,66231,65536,20,65971,302,66214,0,67734,900,16,256,65831,17,276]

theorem envBound60966 : H12AffineFastState.Bounded env60966 := by
  intro p hp
  have h : env60966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60965_60966 : H12AffineEnvironment.transform 12 905 env60965 = env60966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 905 env60965 == env60966) = true)

def env60967 : List Nat := [2,4,8,16,32,0,128,256,512,272,2048,773,905,0,661,304,902,432,517,660,772,649,903,304,20,131,302,918,0,2470,900,16,256,23,17,276]

theorem envBound60967 : H12AffineFastState.Bounded env60967 := by
  intro p hp
  have h : env60967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60966_60967 : H12AffineEnvironment.transform 15 304 env60966 = env60967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 304 env60966 == env60967) = true)

theorem identity60967 : scanCanonicalize (H12AffineFastState.compose env60967 (packedSelected [1,2,3,7,12,19,20,23,27,32,38,41] rootPS)) = affineNative (2^(8+1) ^^^ 313) := by decide +kernel

theorem selectedBound60967 : packedSelected [1,2,3,7,12,19,20,23,27,32,38,41] rootPS < 2^1333 := by decide +kernel

def env60968 : List Nat := [2,4,8,16,32,0,128,256,313,272,2048,60,176,0,428,304,191,432,316,429,61,432,190,304,20,131,302,175,0,2470,189,16,256,23,17,276]

theorem envBound60968 : H12AffineFastState.Bounded env60968 := by
  intro p hp
  have h : env60968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60967_60968 : H12AffineEnvironment.transform 8 313 env60967 = env60968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 313 env60967 == env60968) = true)

theorem identity60968 : scanCanonicalize (H12AffineFastState.compose env60968 (packedSelected [2,3,4,5,8,9,10,11,13,16,18,21,24] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound60968 : packedSelected [2,3,4,5,8,9,10,11,13,16,18,21,24] rootPS < 2^1333 := by decide +kernel

def env60969 : List Nat := [2,4,8,13,32,0,128,256,292,269,2048,33,173,0,428,301,162,429,289,429,32,429,163,301,9,131,302,175,0,2470,160,13,256,10,12,265]

theorem envBound60969 : H12AffineFastState.Bounded env60969 := by
  intro p hp
  have h : env60969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60968_60969 : H12AffineEnvironment.transform 3 13 env60968 = env60969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env60968 == env60969) = true)

theorem identity60969 : scanCanonicalize (H12AffineFastState.compose env60969 (packedSelected [4,8,9,15] rootPS)) = affineNative (2^(10+1) ^^^ 7) := by decide +kernel

theorem selectedBound60969 : packedSelected [4,8,9,15] rootPS < 2^1333 := by decide +kernel

def env60970 : List Nat := [2,4,8,13,32,0,128,256,292,269,7,33,173,0,428,301,162,429,289,429,32,429,163,301,9,131,302,175,0,417,160,13,256,10,12,265]

theorem envBound60970 : H12AffineFastState.Bounded env60970 := by
  intro p hp
  have h : env60970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60969_60970 : H12AffineEnvironment.transform 10 7 env60969 = env60970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 7 env60969 == env60970) = true)

theorem identity60970 : scanCanonicalize (H12AffineFastState.compose env60970 (packedSelected [0,1,2,7,10] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound60970 : packedSelected [0,1,2,7,10] rootPS < 2^1333 := by decide +kernel

def env60971 : List Nat := [2,4,8,13,32,0,128,14,42,3,7,33,173,0,162,35,162,163,47,163,32,163,163,35,9,131,32,175,0,175,160,13,14,10,12,7]

theorem envBound60971 : H12AffineFastState.Bounded env60971 := by
  intro p hp
  have h : env60971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60970_60971 : H12AffineEnvironment.transform 7 14 env60970 = env60971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env60970 == env60971) = true)

theorem identity60971 : scanCanonicalize (H12AffineFastState.compose env60971 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound60971 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env60972 : List Nat := [2,4,8,13,1,0,128,14,11,3,7,0,140,0,131,2,131,130,14,130,1,130,130,2,9,131,1,142,0,142,129,13,14,10,12,7]

theorem envBound60972 : H12AffineFastState.Bounded env60972 := by
  intro p hp
  have h : env60972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60971_60972 : H12AffineEnvironment.transform 4 1 env60971 = env60972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env60971 == env60972) = true)

theorem identity60972 : scanCanonicalize (H12AffineFastState.compose env60972 (packedSelected [0,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 14) := by decide +kernel

theorem selectedBound60972 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env60973 : List Nat := [2,4,8,13,1,0,14,14,11,3,7,0,2,0,13,2,13,12,14,12,1,12,12,2,9,13,1,0,0,0,15,13,14,10,12,7]

theorem envBound60973 : H12AffineFastState.Bounded env60973 := by
  intro p hp
  have h : env60973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60972_60973 : H12AffineEnvironment.transform 6 14 env60972 = env60973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 14 env60972 == env60973) = true)

theorem identity60973 : scanCanonicalize (H12AffineFastState.compose env60973 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound60973 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env60974 : List Nat := [2,4,3,6,1,0,5,5,0,3,7,0,2,0,6,2,6,7,5,7,1,7,7,2,2,6,1,0,0,0,4,6,5,1,7,7]

theorem envBound60974 : H12AffineFastState.Bounded env60974 := by
  intro p hp
  have h : env60974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60973_60974 : H12AffineEnvironment.transform 2 3 env60973 = env60974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env60973 == env60974) = true)

def env60975 : List Nat := [2,4,8,16,32,0,128,256,512,272,2048,773,905,0,661,305,903,433,517,660,772,649,902,305,20,130,302,919,0,2471,900,16,256,22,17,276]

theorem envBound60975 : H12AffineFastState.Bounded env60975 := by
  intro p hp
  have h : env60975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60966_60975 : H12AffineEnvironment.transform 15 305 env60966 = env60975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 305 env60966 == env60975) = true)

theorem identity60975 : scanCanonicalize (H12AffineFastState.compose env60975 (packedSelected [1,2,3,7,12,19,20,23,27,32,38,41] rootPS)) = affineNative (2^(8+1) ^^^ 319) := by decide +kernel

theorem selectedBound60975 : packedSelected [1,2,3,7,12,19,20,23,27,32,38,41] rootPS < 2^1333 := by decide +kernel

def env60976 : List Nat := [2,4,8,16,32,0,128,256,319,272,2048,58,182,0,426,305,184,433,314,427,59,438,185,305,20,130,302,168,0,2471,187,16,256,22,17,276]

theorem envBound60976 : H12AffineFastState.Bounded env60976 := by
  intro p hp
  have h : env60976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60975_60976 : H12AffineEnvironment.transform 8 319 env60975 = env60976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 319 env60975 == env60976) = true)

theorem identity60976 : scanCanonicalize (H12AffineFastState.compose env60976 (packedSelected [2,4,8,9,11,12,17,24] rootPS)) = affineNative (2^(10+1) ^^^ 412) := by decide +kernel

theorem selectedBound60976 : packedSelected [2,4,8,9,11,12,17,24] rootPS < 2^1333 := by decide +kernel

def env60977 : List Nat := [2,4,8,16,32,0,128,256,319,272,412,58,182,0,426,305,184,433,314,427,59,438,185,305,20,130,302,168,0,59,187,16,256,22,17,276]

theorem envBound60977 : H12AffineFastState.Bounded env60977 := by
  intro p hp
  have h : env60977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60976_60977 : H12AffineEnvironment.transform 10 412 env60976 = env60977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 412 env60976 == env60977) = true)

theorem identity60977 : scanCanonicalize (H12AffineFastState.compose env60977 (packedSelected [4,8,9,10,11,15] rootPS)) = affineNative (2^(7+1) ^^^ 41) := by decide +kernel

theorem selectedBound60977 : packedSelected [4,8,9,10,11,15] rootPS < 2^1333 := by decide +kernel

def env60978 : List Nat := [2,4,8,16,32,0,128,41,22,57,181,58,182,0,131,24,184,152,19,130,59,159,185,24,20,130,7,168,0,59,187,16,41,22,17,61]

theorem envBound60978 : H12AffineFastState.Bounded env60978 := by
  intro p hp
  have h : env60978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60977_60978 : H12AffineEnvironment.transform 7 41 env60977 = env60978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 41 env60977 == env60978) = true)

theorem identity60978 : scanCanonicalize (H12AffineFastState.compose env60978 (packedSelected [0,1,5,7,8,10,11,12] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound60978 : packedSelected [0,1,5,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env60979 : List Nat := [2,4,8,0,32,0,128,41,6,41,165,42,166,0,131,8,168,136,3,130,43,143,169,8,4,130,7,168,0,43,171,0,41,6,1,45]

theorem envBound60979 : H12AffineFastState.Bounded env60979 := by
  intro p hp
  have h : env60979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60978_60979 : H12AffineEnvironment.transform 3 0 env60978 = env60979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env60978 == env60979) = true)

theorem identity60979 : scanCanonicalize (H12AffineFastState.compose env60979 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound60979 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env60980 : List Nat := [2,4,8,0,32,0,2,41,6,41,39,42,36,0,1,8,42,10,3,0,43,13,43,8,4,0,7,42,0,43,41,0,41,6,1,45]

theorem envBound60980 : H12AffineFastState.Bounded env60980 := by
  intro p hp
  have h : env60980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60979_60980 : H12AffineEnvironment.transform 6 2 env60979 = env60980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env60979 == env60980) = true)

theorem identity60980 : scanCanonicalize (H12AffineFastState.compose env60980 (packedSelected [1,2,5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound60980 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env60981 : List Nat := [2,4,2,0,32,0,2,35,6,35,39,32,36,0,1,2,32,0,3,0,33,7,33,2,4,0,7,32,0,33,35,0,35,6,1,39]

theorem envBound60981 : H12AffineFastState.Bounded env60981 := by
  intro p hp
  have h : env60981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60980_60981 : H12AffineEnvironment.transform 2 2 env60980 = env60981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env60980 == env60981) = true)

theorem identity60981 : scanCanonicalize (H12AffineFastState.compose env60981 (packedSelected [1,2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound60981 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env60982 : List Nat := [2,3,2,0,32,0,2,35,1,35,32,32,35,0,1,2,32,0,3,0,33,0,33,2,3,0,0,32,0,33,35,0,35,1,1,32]

theorem envBound60982 : H12AffineFastState.Bounded env60982 := by
  intro p hp
  have h : env60982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60981_60982 : H12AffineEnvironment.transform 1 3 env60981 = env60982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env60981 == env60982) = true)

theorem identity60982 : scanCanonicalize (H12AffineFastState.compose env60982 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound60982 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env60983 : List Nat := [2,3,2,0,0,0,2,3,1,3,0,0,3,0,1,2,0,0,3,0,1,0,1,2,3,0,0,0,0,1,3,0,3,1,1,0]

theorem envBound60983 : H12AffineFastState.Bounded env60983 := by
  intro p hp
  have h : env60983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60982_60983 : H12AffineEnvironment.transform 4 0 env60982 = env60983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env60982 == env60983) = true)

theorem identity60983 : scanCanonicalize (H12AffineFastState.compose env60983 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound60983 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60984 : List Nat := [0,1,0,0,0,0,0,1,1,1,0,0,1,0,1,0,0,0,1,0,1,0,1,0,1,0,0,0,0,1,1,0,1,1,1,0]

theorem envBound60984 : H12AffineFastState.Bounded env60984 := by
  intro p hp
  have h : env60984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60983_60984 : H12AffineEnvironment.transform 0 0 env60983 = env60984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env60983 == env60984) = true)

def env60985 : List Nat := [2,4,8,16,32,1,128,256,512,272,2048,773,8192,0,8477,65536,74046,65664,516,8476,772,649,74046,65537,9116,74298,303,74031,0,76574,8205,16,256,65831,16,277]

theorem envBound60985 : H12AffineFastState.Bounded env60985 := by
  intro p hp
  have h : env60985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60964_60985 : H12AffineEnvironment.transform 5 1 env60964 = env60985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env60964 == env60985) = true)

theorem identity60985 : scanCanonicalize (H12AffineFastState.compose env60985 (packedSelected [1,8,28] rootPS)) = affineNative (2^(8+1) ^^^ 400) := by decide +kernel

theorem selectedBound60985 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env60986 : List Nat := [2,4,8,16,32,1,128,256,400,272,2048,149,8192,0,8477,65536,74046,65664,404,8476,148,281,74046,65537,8204,74154,303,74031,0,75918,8205,16,256,65831,16,277]

theorem envBound60986 : H12AffineFastState.Bounded env60986 := by
  intro p hp
  have h : env60986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60985_60986 : H12AffineEnvironment.transform 8 400 env60985 = env60986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 400 env60985 == env60986) = true)

def env60987 : List Nat := [2,4,8,16,32,1,128,256,400,272,2048,149,8192,0,8477,304,8206,432,404,8476,148,281,8206,305,8204,8346,303,8223,0,10686,8205,16,256,23,16,277]

theorem envBound60987 : H12AffineFastState.Bounded env60987 := by
  intro p hp
  have h : env60987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60986_60987 : H12AffineEnvironment.transform 15 304 env60986 = env60987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 304 env60986 == env60987) = true)

theorem identity60987 : scanCanonicalize (H12AffineFastState.compose env60987 (packedSelected [1,2,3,4,7,9,15,16,17,19,20,21,23,27,32] rootPS)) = affineNative (2^(7+1) ^^^ 41) := by decide +kernel

theorem selectedBound60987 : packedSelected [1,2,3,4,7,9,15,16,17,19,20,21,23,27,32] rootPS < 2^1333 := by decide +kernel

def env60988 : List Nat := [2,4,8,16,32,1,128,41,185,57,2048,149,8192,0,8244,25,8206,153,189,8245,148,48,8206,24,8204,8346,6,8223,0,10391,8205,16,41,23,16,60]

theorem envBound60988 : H12AffineFastState.Bounded env60988 := by
  intro p hp
  have h : env60988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60987_60988 : H12AffineEnvironment.transform 7 41 env60987 = env60988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 41 env60987 == env60988) = true)

theorem identity60988 : scanCanonicalize (H12AffineFastState.compose env60988 (packedSelected [3,4,5,9,10,11,12,13,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 59) := by decide +kernel

theorem selectedBound60988 : packedSelected [3,4,5,9,10,11,12,13,18,20] rootPS < 2^1333 := by decide +kernel

def env60989 : List Nat := [2,4,8,16,32,1,128,41,185,57,59,149,8192,0,8244,25,8206,153,189,8245,148,48,8206,24,8204,8346,6,8223,0,8364,8205,16,41,23,16,60]

theorem envBound60989 : H12AffineFastState.Bounded env60989 := by
  intro p hp
  have h : env60989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60988_60989 : H12AffineEnvironment.transform 10 59 env60988 = env60989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 59 env60988 == env60989) = true)

theorem identity60989 : scanCanonicalize (H12AffineFastState.compose env60989 (packedSelected [1,3,10,11,13,16,17] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound60989 : packedSelected [1,3,10,11,13,16,17] rootPS < 2^1333 := by decide +kernel

def env60990 : List Nat := [2,4,8,7,32,1,128,41,174,46,44,130,8192,0,8227,14,8206,142,170,8226,131,39,8206,15,8204,8333,6,8200,0,8364,8205,7,41,0,7,43]

theorem envBound60990 : H12AffineFastState.Bounded env60990 := by
  intro p hp
  have h : env60990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60989_60990 : H12AffineEnvironment.transform 3 7 env60989 = env60990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env60989 == env60990) = true)

theorem identity60990 : scanCanonicalize (H12AffineFastState.compose env60990 (packedSelected [1,2,4,8,9,11] rootPS)) = affineNative (2^(6+1) ^^^ 47) := by decide +kernel

theorem selectedBound60990 : packedSelected [1,2,4,8,9,11] rootPS < 2^1333 := by decide +kernel

def env60991 : List Nat := [2,4,8,7,32,1,47,41,1,46,44,45,8192,0,8227,14,8206,33,5,8226,44,39,8206,15,8204,8226,6,8200,0,8195,8205,7,41,0,7,43]

theorem envBound60991 : H12AffineFastState.Bounded env60991 := by
  intro p hp
  have h : env60991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60990_60991 : H12AffineEnvironment.transform 6 47 env60990 = env60991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 47 env60990 == env60991) = true)

theorem identity60991 : scanCanonicalize (H12AffineFastState.compose env60991 (packedSelected [0,1,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound60991 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env60992 : List Nat := [2,4,8,7,1,1,14,8,1,15,13,12,8192,0,8194,14,8206,0,5,8195,13,6,8206,15,8204,8195,6,8200,0,8195,8205,7,8,0,7,10]

theorem envBound60992 : H12AffineFastState.Bounded env60992 := by
  intro p hp
  have h : env60992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60991_60992 : H12AffineEnvironment.transform 4 1 env60991 = env60992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env60991 == env60992) = true)

theorem identity60992 : scanCanonicalize (H12AffineFastState.compose env60992 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound60992 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env60993 : List Nat := [2,4,8,7,1,1,14,8,1,15,13,12,8,0,10,14,6,0,5,11,13,6,6,15,4,11,6,0,0,11,5,7,8,0,7,10]

theorem envBound60993 : H12AffineFastState.Bounded env60993 := by
  intro p hp
  have h : env60993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60992_60993 : H12AffineEnvironment.transform 12 8 env60992 = env60993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env60992 == env60993) = true)

theorem identity60993 : scanCanonicalize (H12AffineFastState.compose env60993 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound60993 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60994 : List Nat := [2,3,8,0,1,1,9,8,1,8,10,11,8,0,10,9,1,0,2,11,10,1,1,8,3,11,1,0,0,11,2,0,8,0,0,10]

theorem envBound60994 : H12AffineFastState.Bounded env60994 := by
  intro p hp
  have h : env60994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60993_60994 : H12AffineEnvironment.transform 1 3 env60993 = env60994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env60993 == env60994) = true)

theorem identity60994 : scanCanonicalize (H12AffineFastState.compose env60994 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound60994 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env60995 : List Nat := [2,3,3,0,1,1,2,3,1,3,1,0,3,0,1,2,1,0,2,0,1,1,1,3,3,0,1,0,0,0,2,0,3,0,0,1]

theorem envBound60995 : H12AffineFastState.Bounded env60995 := by
  intro p hp
  have h : env60995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60994_60995 : H12AffineEnvironment.transform 2 3 env60994 = env60995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env60994 == env60995) = true)

def env60996 : List Nat := [2,4,8,16,32,1,128,256,400,272,2048,149,8192,0,8477,305,8207,433,404,8476,148,281,8207,304,8204,8347,303,8222,0,10687,8205,16,256,22,16,277]

theorem envBound60996 : H12AffineFastState.Bounded env60996 := by
  intro p hp
  have h : env60996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60986_60996 : H12AffineEnvironment.transform 15 305 env60986 = env60996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 305 env60986 == env60996) = true)

theorem identity60996 : scanCanonicalize (H12AffineFastState.compose env60996 (packedSelected [1,2,3,4,7,9,15,16,17,19,20,21,23,27,32] rootPS)) = affineNative (2^(7+1) ^^^ 47) := by decide +kernel

theorem selectedBound60996 : packedSelected [1,2,3,4,7,9,15,16,17,19,20,21,23,27,32] rootPS < 2^1333 := by decide +kernel

def env60997 : List Nat := [2,4,8,16,32,1,128,47,191,63,2048,149,8192,0,8242,30,8207,158,187,8243,148,54,8207,31,8204,8347,0,8222,0,10384,8205,16,47,22,16,58]

theorem envBound60997 : H12AffineFastState.Bounded env60997 := by
  intro p hp
  have h : env60997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60996_60997 : H12AffineEnvironment.transform 7 47 env60996 = env60997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 47 env60996 == env60997) = true)

theorem identity60997 : scanCanonicalize (H12AffineFastState.compose env60997 (packedSelected [0,1,3,4,8,15,16,17,19,20,21] rootPS)) = affineNative (2^(10+1) ^^^ 159) := by decide +kernel

theorem selectedBound60997 : packedSelected [0,1,3,4,8,15,16,17,19,20,21] rootPS < 2^1333 := by decide +kernel

def env60998 : List Nat := [2,4,8,16,32,1,128,47,191,63,159,149,8192,0,8242,30,8207,158,187,8243,148,54,8207,31,8204,8347,0,8222,0,8207,8205,16,47,22,16,58]

theorem envBound60998 : H12AffineFastState.Bounded env60998 := by
  intro p hp
  have h : env60998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60997_60998 : H12AffineEnvironment.transform 10 159 env60997 = env60998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 159 env60997 == env60998) = true)

theorem identity60998 : scanCanonicalize (H12AffineFastState.compose env60998 (packedSelected [0,1,4,7,8,9,11,16,17,18] rootPS)) = affineNative (2^(12+1) ^^^ 128) := by decide +kernel

theorem selectedBound60998 : packedSelected [0,1,4,7,8,9,11,16,17,18] rootPS < 2^1333 := by decide +kernel

def env60999 : List Nat := [2,4,8,16,32,1,128,47,191,63,159,149,128,0,178,30,143,158,187,179,148,54,143,31,140,27,0,158,0,143,141,16,47,22,16,58]

theorem envBound60999 : H12AffineFastState.Bounded env60999 := by
  intro p hp
  have h : env60999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60998_60999 : H12AffineEnvironment.transform 12 128 env60998 = env60999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 128 env60998 == env60999) = true)

theorem identity60999 : scanCanonicalize (H12AffineFastState.compose env60999 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(6+1) ^^^ 47) := by decide +kernel

theorem selectedBound60999 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env61000 : List Nat := [2,4,8,16,32,1,47,47,16,63,48,58,47,0,29,30,32,49,20,28,59,54,32,31,35,27,0,49,0,32,34,16,47,22,16,58]

theorem envBound61000 : H12AffineFastState.Bounded env61000 := by
  intro p hp
  have h : env61000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60999_61000 : H12AffineEnvironment.transform 6 47 env60999 = env61000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 47 env60999 == env61000) = true)

theorem identity61000 : scanCanonicalize (H12AffineFastState.compose env61000 (packedSelected [1,2,3,5,7,9] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound61000 : packedSelected [1,2,3,5,7,9] rootPS < 2^1333 := by decide +kernel

def env61001 : List Nat := [2,4,3,16,32,1,36,36,16,52,48,49,36,0,22,21,32,49,20,23,48,54,32,20,35,16,0,49,0,32,34,16,36,22,16,49]

theorem envBound61001 : H12AffineFastState.Bounded env61001 := by
  intro p hp
  have h : env61001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61000_61001 : H12AffineEnvironment.transform 2 3 env61000 = env61001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env61000 == env61001) = true)

theorem identity61001 : scanCanonicalize (H12AffineFastState.compose env61001 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound61001 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env61002 : List Nat := [2,4,3,16,0,1,4,4,16,20,16,17,4,0,22,21,0,17,20,23,16,22,0,20,3,16,0,17,0,0,2,16,4,22,16,17]

theorem envBound61002 : H12AffineFastState.Bounded env61002 := by
  intro p hp
  have h : env61002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61001_61002 : H12AffineEnvironment.transform 4 0 env61001 = env61002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env61001 == env61002) = true)

theorem identity61002 : scanCanonicalize (H12AffineFastState.compose env61002 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound61002 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env61003 : List Nat := [0,4,1,16,0,1,4,4,16,20,16,17,4,0,20,21,0,17,20,21,16,20,0,20,1,16,0,17,0,0,0,16,4,20,16,17]

theorem envBound61003 : H12AffineFastState.Bounded env61003 := by
  intro p hp
  have h : env61003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61002_61003 : H12AffineEnvironment.transform 0 0 env61002 = env61003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env61002 == env61003) = true)

theorem identity61003 : scanCanonicalize (H12AffineFastState.compose env61003 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound61003 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env61004 : List Nat := [0,4,1,5,0,1,4,4,5,1,5,4,4,0,1,0,0,4,1,0,5,1,0,1,1,5,0,4,0,0,0,5,4,1,5,4]

theorem envBound61004 : H12AffineFastState.Bounded env61004 := by
  intro p hp
  have h : env61004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61003_61004 : H12AffineEnvironment.transform 3 5 env61003 = env61004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env61003 == env61004) = true)

def env61005 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74863,65665,4416,8541,4097,5276,74046,66896,13768,78895,1151,74815,1296,81226,8205,1280,256,65831,1345,5953]

theorem envBound61005 : H12AffineFastState.Bounded env61005 := by
  intro p hp
  have h : env61005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60923_61005 : H12AffineEnvironment.transform 17 65665 env60923 = env61005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env60923 == env61005) = true)

theorem identity61005 : scanCanonicalize (H12AffineFastState.compose env61005 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound61005 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env61006 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,8192,1296,8540,65536,74863,65665,272,8541,81,1228,74046,66896,9624,74879,1151,74815,1296,77082,8205,1280,256,65831,1345,1809]

theorem envBound61006 : H12AffineFastState.Bounded env61006 := by
  intro p hp
  have h : env61006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61005_61006 : H12AffineEnvironment.transform 11 80 env61005 = env61006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env61005 == env61006) = true)

def env61007 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,80,8192,80,8540,65536,74031,65665,272,8541,81,396,74046,65552,8408,74047,319,74111,80,75866,8205,64,256,65831,1,593]

theorem envBound61007 : H12AffineFastState.Bounded env61007 := by
  intro p hp
  have h : env61007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61006_61007 : H12AffineEnvironment.transform 9 320 env61006 = env61007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env61006 == env61007) = true)

theorem identity61007 : scanCanonicalize (H12AffineFastState.compose env61007 (packedSelected [7,20,27] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound61007 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env61008 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,80,348,80,0,65536,65651,65665,272,1,81,396,65634,65552,388,65635,319,65571,80,67846,337,64,256,65831,1,593]

theorem envBound61008 : H12AffineFastState.Bounded env61008 := by
  intro p hp
  have h : env61008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61007_61008 : H12AffineEnvironment.transform 12 348 env61007 = env61008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env61007 == env61008) = true)

def env61009 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,80,8192,81,8540,65536,74030,65665,272,8541,81,397,74046,65553,8409,74046,318,74110,81,75867,8205,65,256,65831,0,592]

theorem envBound61009 : H12AffineFastState.Bounded env61009 := by
  intro p hp
  have h : env61009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61006_61009 : H12AffineEnvironment.transform 9 321 env61006 = env61009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env61006 == env61009) = true)

theorem identity61009 : scanCanonicalize (H12AffineFastState.compose env61009 (packedSelected [7,20,27] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound61009 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env61010 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,80,268,81,80,65536,65570,65665,272,81,81,397,65586,65553,469,65586,318,65650,81,67927,257,65,256,65831,0,592]

theorem envBound61010 : H12AffineFastState.Bounded env61010 := by
  intro p hp
  have h : env61010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61009_61010 : H12AffineEnvironment.transform 12 268 env61009 = env61010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env61009 == env61010) = true)

theorem identity61010 : scanCanonicalize (H12AffineFastState.compose env61010 (packedSelected [1,2,3,4,5,8,9,10,16,19,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 1006) := by decide +kernel

theorem selectedBound61010 : packedSelected [1,2,3,4,5,8,9,10,16,19,23,32] rootPS < 2^1333 := by decide +kernel

def env61011 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,80,268,81,80,1006,972,879,272,81,81,397,988,1023,469,988,318,924,81,2745,257,65,256,713,0,592]

theorem envBound61011 : H12AffineFastState.Bounded env61011 := by
  intro p hp
  have h : env61011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61010_61011 : H12AffineEnvironment.transform 15 1006 env61010 = env61011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1006 env61010 == env61011) = true)

theorem identity61011 : scanCanonicalize (H12AffineFastState.compose env61011 (packedSelected [1,2,3,4,5,8,9,10,11,13,16,18,19,24,28] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound61011 : packedSelected [1,2,3,4,5,8,9,10,11,13,16,18,19,24,28] rootPS < 2^1333 := by decide +kernel

def env61012 : List Nat := [2,4,8,16,32,64,128,68,512,5,2048,80,72,81,80,682,648,555,84,81,81,201,664,699,145,664,122,728,81,2745,69,65,68,713,0,592]

theorem envBound61012 : H12AffineFastState.Bounded env61012 := by
  intro p hp
  have h : env61012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61011_61012 : H12AffineEnvironment.transform 7 68 env61011 = env61012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env61011 == env61012) = true)

theorem identity61012 : scanCanonicalize (H12AffineFastState.compose env61012 (packedSelected [0,1,2,3,7,11,12,13,15] rootPS)) = affineNative (2^(6+1) ^^^ 115) := by decide +kernel

theorem selectedBound61012 : packedSelected [0,1,2,3,7,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env61013 : List Nat := [2,4,8,16,32,64,115,68,512,5,2048,80,72,81,80,601,635,555,84,81,81,58,619,584,98,619,122,555,81,2634,69,65,68,570,0,592]

theorem envBound61013 : H12AffineFastState.Bounded env61013 := by
  intro p hp
  have h : env61013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61012_61013 : H12AffineEnvironment.transform 6 115 env61012 = env61013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 115 env61012 == env61013) = true)

theorem identity61013 : scanCanonicalize (H12AffineFastState.compose env61013 (packedSelected [0,1,3,5,7,8,10,11,12,13] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound61013 : packedSelected [0,1,3,5,7,8,10,11,12,13] rootPS < 2^1333 := by decide +kernel

def env61014 : List Nat := [2,4,8,16,32,64,115,68,512,5,49,80,72,81,80,601,635,555,84,81,81,58,619,584,98,619,122,555,81,635,69,65,68,570,0,592]

theorem envBound61014 : H12AffineFastState.Bounded env61014 := by
  intro p hp
  have h : env61014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61013_61014 : H12AffineEnvironment.transform 10 49 env61013 = env61014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env61013 == env61014) = true)

theorem identity61014 : scanCanonicalize (H12AffineFastState.compose env61014 (packedSelected [0,1,3,7,10] rootPS)) = affineNative (2^(8+1) ^^^ 96) := by decide +kernel

theorem selectedBound61014 : packedSelected [0,1,3,7,10] rootPS < 2^1333 := by decide +kernel

def env61015 : List Nat := [2,4,8,16,32,64,115,68,96,5,49,80,72,81,80,57,27,75,84,81,81,58,11,40,98,11,122,75,81,27,69,65,68,90,0,48]

theorem envBound61015 : H12AffineFastState.Bounded env61015 := by
  intro p hp
  have h : env61015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61014_61015 : H12AffineEnvironment.transform 8 96 env61014 = env61015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 96 env61014 == env61015) = true)

theorem identity61015 : scanCanonicalize (H12AffineFastState.compose env61015 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound61015 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env61016 : List Nat := [2,4,8,16,32,59,8,63,27,5,49,43,51,42,43,57,27,48,47,42,42,58,11,40,25,11,1,48,42,27,62,58,63,33,0,48]

theorem envBound61016 : H12AffineFastState.Bounded env61016 := by
  intro p hp
  have h : env61016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61015_61016 : H12AffineEnvironment.transform 5 59 env61015 = env61016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env61015 == env61016) = true)

theorem identity61016 : scanCanonicalize (H12AffineFastState.compose env61016 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound61016 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env61017 : List Nat := [2,4,8,16,11,16,8,20,27,5,26,0,24,1,0,18,27,27,4,1,1,17,11,3,25,11,1,27,1,27,21,17,20,10,0,27]

theorem envBound61017 : H12AffineFastState.Bounded env61017 := by
  intro p hp
  have h : env61017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61016_61017 : H12AffineEnvironment.transform 4 11 env61016 = env61017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env61016 == env61017) = true)

theorem identity61017 : scanCanonicalize (H12AffineFastState.compose env61017 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound61017 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env61018 : List Nat := [2,4,8,10,11,10,8,14,1,5,0,0,2,1,0,8,1,1,4,1,1,11,11,3,3,11,1,1,1,1,15,11,14,10,0,1]

theorem envBound61018 : H12AffineFastState.Bounded env61018 := by
  intro p hp
  have h : env61018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61017_61018 : H12AffineEnvironment.transform 3 10 env61017 = env61018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env61017 == env61018) = true)

theorem identity61018 : scanCanonicalize (H12AffineFastState.compose env61018 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound61018 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env61019 : List Nat := [2,3,8,10,11,10,8,9,1,2,0,0,2,1,0,8,1,1,3,1,1,11,11,3,3,11,1,1,1,1,8,11,9,10,0,1]

theorem envBound61019 : H12AffineFastState.Bounded env61019 := by
  intro p hp
  have h : env61019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61018_61019 : H12AffineEnvironment.transform 1 3 env61018 = env61019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env61018 == env61019) = true)

def env61020 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74863,262144,4417,8540,4097,5276,74047,66896,13769,78895,328958,74814,1296,81227,8204,1280,256,65830,1345,5952]

theorem envBound61020 : H12AffineFastState.Bounded env61020 := by
  intro p hp
  have h : env61020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60922_61020 : H12AffineEnvironment.transform 13 1297 env60922 = env61020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env60922 == env61020) = true)

def env61021 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74863,65664,4417,8540,4097,5276,74047,66896,13769,78895,1150,74814,1296,81227,8204,1280,256,65830,1345,5952]

theorem envBound61021 : H12AffineFastState.Bounded env61021 := by
  intro p hp
  have h : env61021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61020_61021 : H12AffineEnvironment.transform 17 65664 env61020 = env61021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env61020 == env61021) = true)

theorem identity61021 : scanCanonicalize (H12AffineFastState.compose env61021 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5465) := by decide +kernel

theorem selectedBound61021 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env61022 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5465,1297,5124,65536,69942,65664,4417,5125,4097,5276,70758,66896,144,65910,1150,69991,1296,67602,5461,1280,256,65830,1345,5952]

theorem envBound61022 : H12AffineFastState.Bounded env61022 := by
  intro p hp
  have h : env61022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61021_61022 : H12AffineEnvironment.transform 12 5465 env61021 = env61022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5465 env61021 == env61022) = true)

def env61023 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1556,845,1297,528,65536,67362,65664,1877,529,1557,648,66162,66896,144,65910,1150,67443,1296,67602,833,1280,256,65830,1345,340]

theorem envBound61023 : H12AffineFastState.Bounded env61023 := by
  intro p hp
  have h : env61023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61022_61023 : H12AffineEnvironment.transform 11 1556 env61022 = env61023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1556 env61022 == env61023) = true)

def env61024 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,836,845,65,528,65536,66162,65664,517,529,837,648,66162,65536,144,65910,302,66083,64,67602,833,80,256,65830,17,340]

theorem envBound61024 : H12AffineFastState.Bounded env61024 := by
  intro p hp
  have h : env61024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61023_61024 : H12AffineEnvironment.transform 9 336 env61023 = env61024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 336 env61023 == env61024) = true)

theorem identity61024 : scanCanonicalize (H12AffineFastState.compose env61024 (packedSelected [1,8,28] rootPS)) = affineNative (2^(8+1) ^^^ 13) := by decide +kernel

theorem selectedBound61024 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env61025 : List Nat := [2,4,8,16,32,64,128,256,13,336,2048,329,320,65,29,65536,65663,65664,8,28,328,133,65663,65536,144,65910,302,65582,64,67602,332,80,256,65830,17,340]

theorem envBound61025 : H12AffineFastState.Bounded env61025 := by
  intro p hp
  have h : env61025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61024_61025 : H12AffineEnvironment.transform 8 13 env61024 = env61025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 13 env61024 == env61025) = true)

def env61026 : List Nat := [2,4,8,16,32,64,128,24,13,72,2048,81,88,65,29,65536,65663,65664,8,28,80,133,65663,65536,144,65646,54,65582,64,67602,84,80,24,65598,17,76]

theorem envBound61026 : H12AffineFastState.Bounded env61026 := by
  intro p hp
  have h : env61026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61025_61026 : H12AffineEnvironment.transform 7 24 env61025 = env61026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 24 env61025 == env61026) = true)

theorem identity61026 : scanCanonicalize (H12AffineFastState.compose env61026 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound61026 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env61027 : List Nat := [2,4,8,13,32,64,128,5,13,72,2048,76,69,65,0,65536,65634,65664,8,1,77,133,65634,65536,141,65646,43,65582,64,67599,73,77,5,65571,12,76]

theorem envBound61027 : H12AffineFastState.Bounded env61027 := by
  intro p hp
  have h : env61027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61026_61027 : H12AffineEnvironment.transform 3 13 env61026 = env61027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env61026 == env61027) = true)

theorem identity61027 : scanCanonicalize (H12AffineFastState.compose env61027 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 13) := by decide +kernel

theorem selectedBound61027 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env61028 : List Nat := [2,4,8,13,32,13,128,5,13,5,2048,1,8,12,0,65536,65583,65664,8,1,0,133,65583,65536,141,65571,43,65582,13,67599,4,0,5,65571,12,1]

theorem envBound61028 : H12AffineFastState.Bounded env61028 := by
  intro p hp
  have h : env61028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61027_61028 : H12AffineEnvironment.transform 5 13 env61027 = env61028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 13 env61027 == env61028) = true)

theorem identity61028 : scanCanonicalize (H12AffineFastState.compose env61028 (packedSelected [0,2,3,7,8,11,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 2176) := by decide +kernel

theorem selectedBound61028 : packedSelected [0,2,3,7,8,11,12,15] rootPS < 2^1333 := by decide +kernel

def env61029 : List Nat := [2,4,8,13,32,13,128,5,13,5,2048,1,8,12,0,2176,2223,2048,8,1,0,133,2223,2176,141,2211,43,2222,13,143,4,0,5,2211,12,1]

theorem envBound61029 : H12AffineFastState.Bounded env61029 := by
  intro p hp
  have h : env61029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61028_61029 : H12AffineEnvironment.transform 15 2176 env61028 = env61029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2176 env61028 == env61029) = true)

theorem identity61029 : scanCanonicalize (H12AffineFastState.compose env61029 (packedSelected [0,3,5,7,8,10,11,12] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound61029 : packedSelected [0,3,5,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env61030 : List Nat := [2,4,2,7,32,7,128,5,7,5,2048,1,2,6,0,2176,2213,2048,2,1,0,133,2213,2176,135,2211,33,2212,7,133,4,0,5,2211,6,1]

theorem envBound61030 : H12AffineFastState.Bounded env61030 := by
  intro p hp
  have h : env61030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61029_61030 : H12AffineEnvironment.transform 2 2 env61029 = env61030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env61029 == env61030) = true)

theorem identity61030 : scanCanonicalize (H12AffineFastState.compose env61030 (packedSelected [2,4,7] rootPS)) = affineNative (2^(10+1) ^^^ 165) := by decide +kernel

theorem selectedBound61030 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env61031 : List Nat := [2,4,2,7,32,7,128,5,7,5,165,1,2,6,0,37,0,165,2,1,0,133,0,37,135,6,33,1,7,133,4,0,5,6,6,1]

theorem envBound61031 : H12AffineFastState.Bounded env61031 := by
  intro p hp
  have h : env61031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61030_61031 : H12AffineEnvironment.transform 10 165 env61030 = env61031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 165 env61030 == env61031) = true)

theorem identity61031 : scanCanonicalize (H12AffineFastState.compose env61031 (packedSelected [1,2] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound61031 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env61032 : List Nat := [2,4,2,7,32,7,5,5,7,5,32,1,2,6,0,37,0,32,2,1,0,0,0,37,2,6,33,1,7,0,4,0,5,6,6,1]

theorem envBound61032 : H12AffineFastState.Bounded env61032 := by
  intro p hp
  have h : env61032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61031_61032 : H12AffineEnvironment.transform 6 5 env61031 = env61032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env61031 == env61032) = true)

theorem identity61032 : scanCanonicalize (H12AffineFastState.compose env61032 (packedSelected [1,3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound61032 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env61033 : List Nat := [2,3,2,0,32,0,2,2,0,2,32,1,2,1,0,34,0,32,2,1,0,0,0,34,2,1,33,1,0,0,3,0,2,1,1,1]

theorem envBound61033 : H12AffineFastState.Bounded env61033 := by
  intro p hp
  have h : env61033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61032_61033 : H12AffineEnvironment.transform 1 3 env61032 = env61033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env61032 == env61033) = true)

theorem identity61033 : scanCanonicalize (H12AffineFastState.compose env61033 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound61033 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env61034 : List Nat := [1,0,1,0,32,0,1,1,0,1,32,1,1,1,0,33,0,32,1,1,0,0,0,33,1,1,33,1,0,0,0,0,1,1,1,1]

theorem envBound61034 : H12AffineFastState.Bounded env61034 := by
  intro p hp
  have h : env61034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61033_61034 : H12AffineEnvironment.transform 0 1 env61033 = env61034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env61033 == env61034) = true)

theorem identity61034 : scanCanonicalize (H12AffineFastState.compose env61034 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound61034 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env61035 : List Nat := [1,0,1,0,0,0,1,1,0,1,0,1,1,1,0,1,0,0,1,1,0,0,0,1,1,1,1,1,0,0,0,0,1,1,1,1]

theorem envBound61035 : H12AffineFastState.Bounded env61035 := by
  intro p hp
  have h : env61035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61034_61035 : H12AffineEnvironment.transform 4 0 env61034 = env61035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env61034 == env61035) = true)

def env61036 : List Nat := [2,4,8,16,32,64,128,25,13,73,2048,80,89,65,29,65536,65663,65664,8,28,81,133,65663,65536,144,65647,55,65582,64,67602,85,80,25,65599,17,77]

theorem envBound61036 : H12AffineFastState.Bounded env61036 := by
  intro p hp
  have h : env61036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61025_61036 : H12AffineEnvironment.transform 7 25 env61025 = env61036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 25 env61025 == env61036) = true)

theorem identity61036 : scanCanonicalize (H12AffineFastState.compose env61036 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(5+1) ^^^ 29) := by decide +kernel

theorem selectedBound61036 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env61037 : List Nat := [2,4,8,16,32,29,128,25,13,20,2048,13,4,28,29,65536,65570,65664,8,28,12,133,65570,65536,144,65586,55,65582,29,67602,8,13,25,65599,17,16]

theorem envBound61037 : H12AffineFastState.Bounded env61037 := by
  intro p hp
  have h : env61037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61036_61037 : H12AffineEnvironment.transform 5 29 env61036 = env61037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 29 env61036 == env61037) = true)

theorem identity61037 : scanCanonicalize (H12AffineFastState.compose env61037 (packedSelected [0,5,7,10,11,15,18,20] rootPS)) = affineNative (2^(15+1) ^^^ 50) := by decide +kernel

theorem selectedBound61037 : packedSelected [0,5,7,10,11,15,18,20] rootPS < 2^1333 := by decide +kernel

def env61038 : List Nat := [2,4,8,16,32,29,128,25,13,20,2048,13,4,28,29,50,16,178,8,28,12,133,16,50,144,0,55,28,29,2080,8,13,25,13,17,16]

theorem envBound61038 : H12AffineFastState.Bounded env61038 := by
  intro p hp
  have h : env61038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61037_61038 : H12AffineEnvironment.transform 15 50 env61037 = env61038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 50 env61037 == env61038) = true)

theorem identity61038 : scanCanonicalize (H12AffineFastState.compose env61038 (packedSelected [8,13] rootPS)) = affineNative (2^(6+1) ^^^ 62) := by decide +kernel

theorem selectedBound61038 : packedSelected [8,13] rootPS < 2^1333 := by decide +kernel

def env61039 : List Nat := [2,4,8,16,32,29,62,25,13,20,2048,13,4,28,29,50,16,12,8,28,12,59,16,50,46,0,55,28,29,2080,8,13,25,13,17,16]

theorem envBound61039 : H12AffineFastState.Bounded env61039 := by
  intro p hp
  have h : env61039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61038_61039 : H12AffineEnvironment.transform 6 62 env61038 = env61039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 62 env61038 == env61039) = true)

theorem identity61039 : scanCanonicalize (H12AffineFastState.compose env61039 (packedSelected [3,5,15] rootPS)) = affineNative (2^(10+1) ^^^ 29) := by decide +kernel

theorem selectedBound61039 : packedSelected [3,5,15] rootPS < 2^1333 := by decide +kernel

def env61040 : List Nat := [2,4,8,16,32,29,62,25,13,20,29,13,4,28,29,50,16,12,8,28,12,59,16,50,46,0,55,28,29,61,8,13,25,13,17,16]

theorem envBound61040 : H12AffineFastState.Bounded env61040 := by
  intro p hp
  have h : env61040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61039_61040 : H12AffineEnvironment.transform 10 29 env61039 = env61040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 29 env61039 == env61040) = true)

theorem identity61040 : scanCanonicalize (H12AffineFastState.compose env61040 (packedSelected [2,3,5,8] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound61040 : packedSelected [2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env61041 : List Nat := [2,4,8,16,10,29,20,25,13,20,29,13,4,28,29,24,16,12,8,28,12,17,16,24,4,0,29,28,29,23,8,13,25,13,17,16]

theorem envBound61041 : H12AffineFastState.Bounded env61041 := by
  intro p hp
  have h : env61041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61040_61041 : H12AffineEnvironment.transform 4 10 env61040 = env61041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env61040 == env61041) = true)

def env61042 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,837,845,64,528,65536,66163,65664,516,529,836,648,66162,65537,144,65910,303,66082,65,67602,833,81,256,65830,16,340]

theorem envBound61042 : H12AffineFastState.Bounded env61042 := by
  intro p hp
  have h : env61042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61023_61042 : H12AffineEnvironment.transform 9 337 env61023 = env61042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 337 env61023 == env61042) = true)

theorem identity61042 : scanCanonicalize (H12AffineFastState.compose env61042 (packedSelected [1,8,28] rootPS)) = affineNative (2^(7+1) ^^^ 24) := by decide +kernel

theorem selectedBound61042 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env61043 : List Nat := [2,4,8,16,32,64,128,24,512,73,2048,605,597,64,528,65536,66163,65664,516,529,604,648,66162,65537,144,65646,55,66082,65,67602,601,81,24,65598,16,76]

theorem envBound61043 : H12AffineFastState.Bounded env61043 := by
  intro p hp
  have h : env61043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61042_61043 : H12AffineEnvironment.transform 7 24 env61042 = env61043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 24 env61042 == env61043) = true)

def env61044 : List Nat := [2,4,8,16,32,64,128,24,12,73,2048,81,89,64,28,65536,65663,65664,8,29,80,132,65662,65537,144,65646,55,65582,65,67602,85,81,24,65598,16,76]

theorem envBound61044 : H12AffineFastState.Bounded env61044 := by
  intro p hp
  have h : env61044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61043_61044 : H12AffineEnvironment.transform 8 12 env61043 = env61044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 12 env61043 == env61044) = true)

theorem identity61044 : scanCanonicalize (H12AffineFastState.compose env61044 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound61044 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env61045 : List Nat := [2,4,8,12,32,64,128,4,12,73,2048,77,69,64,0,65536,65635,65664,8,1,76,132,65634,65537,140,65646,43,65582,65,67598,73,77,4,65570,12,76]

theorem envBound61045 : H12AffineFastState.Bounded env61045 := by
  intro p hp
  have h : env61045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61044_61045 : H12AffineEnvironment.transform 3 12 env61044 = env61045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env61044 == env61045) = true)

theorem identity61045 : scanCanonicalize (H12AffineFastState.compose env61045 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 12) := by decide +kernel

theorem selectedBound61045 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env61046 : List Nat := [2,4,8,12,32,12,128,4,12,5,2048,1,9,12,0,65536,65583,65664,8,1,0,132,65582,65537,140,65570,43,65582,13,67598,5,1,4,65570,12,0]

theorem envBound61046 : H12AffineFastState.Bounded env61046 := by
  intro p hp
  have h : env61046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61045_61046 : H12AffineEnvironment.transform 5 12 env61045 = env61046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 12 env61045 == env61046) = true)

theorem identity61046 : scanCanonicalize (H12AffineFastState.compose env61046 (packedSelected [0,2,3,7,8,11,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 163) := by decide +kernel

theorem selectedBound61046 : packedSelected [0,2,3,7,8,11,12,15] rootPS < 2^1333 := by decide +kernel

def env61047 : List Nat := [2,4,8,12,32,12,128,4,12,5,163,1,9,12,0,65536,65583,65664,8,1,0,132,65582,65537,140,65570,43,65582,13,65709,5,1,4,65570,12,0]

theorem envBound61047 : H12AffineFastState.Bounded env61047 := by
  intro p hp
  have h : env61047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61046_61047 : H12AffineEnvironment.transform 10 163 env61046 = env61047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 163 env61046 == env61047) = true)

theorem identity61047 : scanCanonicalize (H12AffineFastState.compose env61047 (packedSelected [0,1,2,3,5,7,11] rootPS)) = affineNative (2^(15+1) ^^^ 46) := by decide +kernel

theorem selectedBound61047 : packedSelected [0,1,2,3,5,7,11] rootPS < 2^1333 := by decide +kernel

def env61048 : List Nat := [2,4,8,12,32,12,128,4,12,5,163,1,9,12,0,46,1,174,8,1,0,132,0,47,140,12,43,0,13,131,5,1,4,12,12,0]

theorem envBound61048 : H12AffineFastState.Bounded env61048 := by
  intro p hp
  have h : env61048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61047_61048 : H12AffineEnvironment.transform 15 46 env61047 = env61048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 46 env61047 == env61048) = true)

theorem identity61048 : scanCanonicalize (H12AffineFastState.compose env61048 (packedSelected [2,3] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound61048 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env61049 : List Nat := [2,4,4,0,32,0,128,4,0,5,163,1,5,0,0,34,1,162,4,1,0,132,0,35,128,0,39,0,1,131,5,1,4,0,0,0]

theorem envBound61049 : H12AffineFastState.Bounded env61049 := by
  intro p hp
  have h : env61049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61048_61049 : H12AffineEnvironment.transform 2 4 env61048 = env61049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env61048 == env61049) = true)

theorem identity61049 : scanCanonicalize (H12AffineFastState.compose env61049 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound61049 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env61050 : List Nat := [2,4,4,0,32,0,3,4,0,5,32,1,5,0,0,34,1,33,4,1,0,7,0,35,3,0,39,0,1,0,5,1,4,0,0,0]

theorem envBound61050 : H12AffineFastState.Bounded env61050 := by
  intro p hp
  have h : env61050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61049_61050 : H12AffineEnvironment.transform 6 3 env61049 = env61050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env61049 == env61050) = true)

theorem identity61050 : scanCanonicalize (H12AffineFastState.compose env61050 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound61050 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env61051 : List Nat := [2,4,4,0,7,0,3,4,0,5,7,1,5,0,0,5,1,6,4,1,0,7,0,4,3,0,0,0,1,0,5,1,4,0,0,0]

theorem envBound61051 : H12AffineFastState.Bounded env61051 := by
  intro p hp
  have h : env61051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61050_61051 : H12AffineEnvironment.transform 4 7 env61050 = env61051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env61050 == env61051) = true)

theorem identity61051 : scanCanonicalize (H12AffineFastState.compose env61051 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound61051 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env61052 : List Nat := [2,3,3,0,0,0,3,3,0,2,0,1,2,0,0,2,1,1,3,1,0,0,0,3,3,0,0,0,1,0,2,1,3,0,0,0]

theorem envBound61052 : H12AffineFastState.Bounded env61052 := by
  intro p hp
  have h : env61052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61051_61052 : H12AffineEnvironment.transform 1 3 env61051 = env61052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env61051 == env61052) = true)

def env61053 : List Nat := [2,4,8,16,32,64,128,24,13,73,2048,80,88,64,29,65536,65662,65664,9,28,81,133,65663,65537,144,65646,55,65583,65,67602,84,81,24,65598,16,76]

theorem envBound61053 : H12AffineFastState.Bounded env61053 := by
  intro p hp
  have h : env61053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61043_61053 : H12AffineEnvironment.transform 8 13 env61043 = env61053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 13 env61043 == env61053) = true)

theorem identity61053 : scanCanonicalize (H12AffineFastState.compose env61053 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(5+1) ^^^ 28) := by decide +kernel

theorem selectedBound61053 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env61054 : List Nat := [2,4,8,16,32,28,128,24,13,21,2048,12,4,28,29,65536,65570,65664,9,28,13,133,65571,65537,144,65586,55,65583,29,67602,8,13,24,65598,16,16]

theorem envBound61054 : H12AffineFastState.Bounded env61054 := by
  intro p hp
  have h : env61054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61053_61054 : H12AffineEnvironment.transform 5 28 env61053 = env61054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 28 env61053 == env61054) = true)

def env61055 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1557,844,1297,529,65536,67363,65664,1876,528,1556,649,66163,66896,144,65910,1150,67442,1296,67602,832,1280,256,65830,1345,341]

theorem envBound61055 : H12AffineFastState.Bounded env61055 := by
  intro p hp
  have h : env61055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61022_61055 : H12AffineEnvironment.transform 11 1557 env61022 = env61055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1557 env61022 == env61055) = true)

def env61056 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,837,844,65,529,65536,66163,65664,516,528,836,649,66163,65536,144,65910,302,66082,64,67602,832,80,256,65830,17,341]

theorem envBound61056 : H12AffineFastState.Bounded env61056 := by
  intro p hp
  have h : env61056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61055_61056 : H12AffineEnvironment.transform 9 336 env61055 = env61056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 336 env61055 == env61056) = true)

theorem identity61056 : scanCanonicalize (H12AffineFastState.compose env61056 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 110) := by decide +kernel

theorem selectedBound61056 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env61057 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,837,844,65,529,110,541,238,516,528,836,649,541,110,144,280,302,588,64,2172,832,80,256,328,17,341]

theorem envBound61057 : H12AffineFastState.Bounded env61057 := by
  intro p hp
  have h : env61057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61056_61057 : H12AffineEnvironment.transform 15 110 env61056 = env61057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 110 env61056 == env61057) = true)

def env61058 : List Nat := [2,4,8,16,32,64,128,88,512,8,2048,541,532,65,529,110,541,238,516,528,540,649,541,110,144,64,118,588,64,2172,536,80,88,16,17,13]

theorem envBound61058 : H12AffineFastState.Bounded env61058 := by
  intro p hp
  have h : env61058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61057_61058 : H12AffineEnvironment.transform 7 88 env61057 = env61058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 88 env61057 == env61058) = true)

theorem identity61058 : scanCanonicalize (H12AffineFastState.compose env61058 (packedSelected [1,3,4,9,11,20,21,32] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound61058 : packedSelected [1,3,4,9,11,20,21,32] rootPS < 2^1333 := by decide +kernel

def env61059 : List Nat := [2,4,8,16,32,64,128,88,512,8,10,541,532,65,529,110,541,238,516,528,540,649,541,110,144,64,118,588,64,118,536,80,88,16,17,13]

theorem envBound61059 : H12AffineFastState.Bounded env61059 := by
  intro p hp
  have h : env61059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61058_61059 : H12AffineEnvironment.transform 10 10 env61058 = env61059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env61058 == env61059) = true)

theorem identity61059 : scanCanonicalize (H12AffineFastState.compose env61059 (packedSelected [0,2,3,7,11,13,17,18,19,20,21] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound61059 : packedSelected [0,2,3,7,11,13,17,18,19,20,21] rootPS < 2^1333 := by decide +kernel

def env61060 : List Nat := [2,4,8,16,27,64,128,88,512,8,10,541,532,65,529,85,541,213,516,528,540,649,541,85,144,64,77,588,64,77,536,80,88,16,17,13]

theorem envBound61060 : H12AffineFastState.Bounded env61060 := by
  intro p hp
  have h : env61060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61059_61060 : H12AffineEnvironment.transform 4 27 env61059 = env61060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env61059 == env61060) = true)

theorem identity61060 : scanCanonicalize (H12AffineFastState.compose env61060 (packedSelected [0,2,5,7,8,12] rootPS)) = affineNative (2^(8+1) ^^^ 77) := by decide +kernel

theorem selectedBound61060 : packedSelected [0,2,5,7,8,12] rootPS < 2^1333 := by decide +kernel

def env61061 : List Nat := [2,4,8,16,27,64,128,88,77,8,10,80,89,65,92,85,80,213,73,93,81,196,80,85,144,64,77,1,64,77,85,80,88,16,17,13]

theorem envBound61061 : H12AffineFastState.Bounded env61061 := by
  intro p hp
  have h : env61061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61060_61061 : H12AffineEnvironment.transform 8 77 env61060 = env61061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 77 env61060 == env61061) = true)

theorem identity61061 : scanCanonicalize (H12AffineFastState.compose env61061 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound61061 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env61062 : List Nat := [2,4,8,16,27,17,128,9,28,8,10,1,8,16,13,4,1,132,24,12,0,149,1,4,144,17,28,1,17,28,4,1,9,16,17,13]

theorem envBound61062 : H12AffineFastState.Bounded env61062 := by
  intro p hp
  have h : env61062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61061_61062 : H12AffineEnvironment.transform 5 17 env61061 = env61062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env61061 == env61062) = true)

theorem identity61062 : scanCanonicalize (H12AffineFastState.compose env61062 (packedSelected [5,8] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound61062 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env61063 : List Nat := [2,4,8,7,12,6,128,9,11,8,10,1,8,7,13,4,1,132,15,12,0,130,1,4,135,6,11,1,6,11,4,1,9,7,6,13]

theorem envBound61063 : H12AffineFastState.Bounded env61063 := by
  intro p hp
  have h : env61063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61062_61063 : H12AffineEnvironment.transform 3 7 env61062 = env61063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env61062 == env61063) = true)

theorem identity61063 : scanCanonicalize (H12AffineFastState.compose env61063 (packedSelected [0,1,4] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound61063 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env61064 : List Nat := [2,4,8,7,12,6,9,9,11,8,10,1,8,7,13,4,1,13,15,12,0,11,1,4,14,6,11,1,6,11,4,1,9,7,6,13]

theorem envBound61064 : H12AffineFastState.Bounded env61064 := by
  intro p hp
  have h : env61064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61063_61064 : H12AffineEnvironment.transform 6 9 env61063 = env61064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env61063 == env61064) = true)

theorem identity61064 : scanCanonicalize (H12AffineFastState.compose env61064 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound61064 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env61065 : List Nat := [2,2,8,1,10,0,9,9,11,8,10,1,8,1,11,2,1,11,9,10,0,11,1,2,8,0,11,1,0,11,2,1,9,1,0,11]

theorem envBound61065 : H12AffineFastState.Bounded env61065 := by
  intro p hp
  have h : env61065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61064_61065 : H12AffineEnvironment.transform 1 2 env61064 = env61065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env61064 == env61065) = true)

theorem identity61065 : scanCanonicalize (H12AffineFastState.compose env61065 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound61065 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env61066 : List Nat := [2,2,3,1,1,0,2,2,0,3,1,1,3,1,0,2,1,0,2,1,0,0,1,2,3,0,0,1,0,0,2,1,2,1,0,0]

theorem envBound61066 : H12AffineFastState.Bounded env61066 := by
  intro p hp
  have h : env61066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61065_61066 : H12AffineEnvironment.transform 2 3 env61065 = env61066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env61065 == env61066) = true)

def env61067 : List Nat := [2,4,8,16,32,64,128,89,512,9,2048,540,533,65,529,110,541,238,516,528,541,649,541,110,144,65,119,588,64,2172,537,80,89,17,17,12]

theorem envBound61067 : H12AffineFastState.Bounded env61067 := by
  intro p hp
  have h : env61067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61057_61067 : H12AffineEnvironment.transform 7 89 env61057 = env61067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 89 env61057 == env61067) = true)

theorem identity61067 : scanCanonicalize (H12AffineFastState.compose env61067 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(8+1) ^^^ 12) := by decide +kernel

theorem selectedBound61067 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env61068 : List Nat := [2,4,8,16,32,64,128,89,12,9,2048,16,25,65,29,110,17,238,8,28,17,133,17,110,144,65,119,64,64,2172,21,80,89,17,17,12]

theorem envBound61068 : H12AffineFastState.Bounded env61068 := by
  intro p hp
  have h : env61068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61067_61068 : H12AffineEnvironment.transform 8 12 env61067 = env61068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 12 env61067 == env61068) = true)

theorem identity61068 : scanCanonicalize (H12AffineFastState.compose env61068 (packedSelected [4,9,16] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound61068 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env61069 : List Nat := [2,4,8,13,32,64,128,68,12,9,2048,13,4,65,0,110,12,238,8,1,12,133,12,110,141,65,106,64,64,2145,8,77,68,12,12,12]

theorem envBound61069 : H12AffineFastState.Bounded env61069 := by
  intro p hp
  have h : env61069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61068_61069 : H12AffineEnvironment.transform 3 13 env61068 = env61069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env61068 == env61069) = true)

theorem identity61069 : scanCanonicalize (H12AffineFastState.compose env61069 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound61069 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env61070 : List Nat := [2,4,8,13,32,64,4,68,12,9,2048,13,4,65,0,110,12,106,8,1,12,1,12,110,9,65,106,64,64,2145,8,77,68,12,12,12]

theorem envBound61070 : H12AffineFastState.Bounded env61070 := by
  intro p hp
  have h : env61070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61069_61070 : H12AffineEnvironment.transform 6 4 env61069 = env61070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env61069 == env61070) = true)

theorem identity61070 : scanCanonicalize (H12AffineFastState.compose env61070 (packedSelected [2,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound61070 : packedSelected [2,7,8] rootPS < 2^1333 := by decide +kernel

def env61071 : List Nat := [2,4,8,13,32,64,4,68,12,9,11,13,4,65,0,110,12,106,8,1,12,1,12,110,9,65,106,64,64,106,8,77,68,12,12,12]

theorem envBound61071 : H12AffineFastState.Bounded env61071 := by
  intro p hp
  have h : env61071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61070_61071 : H12AffineEnvironment.transform 10 11 env61070 = env61071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env61070 == env61071) = true)

theorem identity61071 : scanCanonicalize (H12AffineFastState.compose env61071 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(5+1) ^^^ 12) := by decide +kernel

theorem selectedBound61071 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env61072 : List Nat := [2,4,8,13,32,12,4,8,12,9,11,13,4,13,0,34,12,38,8,1,12,1,12,34,9,13,38,12,12,38,8,1,8,12,12,12]

theorem envBound61072 : H12AffineFastState.Bounded env61072 := by
  intro p hp
  have h : env61072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61071_61072 : H12AffineEnvironment.transform 5 12 env61071 = env61072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 12 env61071 == env61072) = true)

theorem identity61072 : scanCanonicalize (H12AffineFastState.compose env61072 (packedSelected [1,2] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound61072 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env61073 : List Nat := [2,4,5,0,32,1,4,5,1,4,6,0,4,0,0,34,1,38,5,1,1,1,1,34,4,0,38,1,1,38,5,1,5,1,1,1]

theorem envBound61073 : H12AffineFastState.Bounded env61073 := by
  intro p hp
  have h : env61073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61072_61073 : H12AffineEnvironment.transform 2 5 env61072 = env61073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env61072 == env61073) = true)

theorem identity61073 : scanCanonicalize (H12AffineFastState.compose env61073 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound61073 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env61074 : List Nat := [2,2,3,0,32,1,2,3,1,2,0,0,2,0,0,34,1,32,3,1,1,1,1,34,2,0,32,1,1,32,3,1,3,1,1,1]

theorem envBound61074 : H12AffineFastState.Bounded env61074 := by
  intro p hp
  have h : env61074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61073_61074 : H12AffineEnvironment.transform 1 2 env61073 = env61074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env61073 == env61074) = true)

def env61075 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,836,844,64,529,65536,66162,65664,517,528,837,649,66163,65537,144,65910,303,66083,65,67602,832,81,256,65830,16,341]

theorem envBound61075 : H12AffineFastState.Bounded env61075 := by
  intro p hp
  have h : env61075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61055_61075 : H12AffineEnvironment.transform 9 337 env61055 = env61075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 337 env61055 == env61075) = true)

theorem identity61075 : scanCanonicalize (H12AffineFastState.compose env61075 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 890) := by decide +kernel

theorem selectedBound61075 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env61076 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,836,844,64,529,890,264,1018,517,528,837,649,265,891,144,524,303,345,65,2920,832,81,256,604,16,341]

theorem envBound61076 : H12AffineFastState.Bounded env61076 := by
  intro p hp
  have h : env61076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61075_61076 : H12AffineEnvironment.transform 15 890 env61075 = env61076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 890 env61075 == env61076) = true)

def env61077 : List Nat := [2,4,8,16,32,64,128,256,276,337,2048,80,88,64,261,110,264,238,273,260,81,413,265,111,144,280,303,345,65,2172,84,81,256,328,16,341]

theorem envBound61077 : H12AffineFastState.Bounded env61077 := by
  intro p hp
  have h : env61077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61076_61077 : H12AffineEnvironment.transform 8 276 env61076 = env61077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env61076 == env61077) = true)

theorem identity61077 : scanCanonicalize (H12AffineFastState.compose env61077 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound61077 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env61078 : List Nat := [2,4,8,16,32,64,128,68,80,21,2048,80,88,64,65,110,76,238,85,64,81,217,77,111,144,92,107,29,65,2172,84,81,68,12,16,17]

theorem envBound61078 : H12AffineFastState.Bounded env61078 := by
  intro p hp
  have h : env61078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61077_61078 : H12AffineEnvironment.transform 7 68 env61077 = env61078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env61077 == env61078) = true)

theorem identity61078 : scanCanonicalize (H12AffineFastState.compose env61078 (packedSelected [0,5,7,10,11,15,18,20] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound61078 : packedSelected [0,5,7,10,11,15,18,20] rootPS < 2^1333 := by decide +kernel

def env61079 : List Nat := [2,4,8,12,32,64,128,68,76,9,2048,76,68,64,65,110,76,238,73,64,77,197,77,111,140,64,107,1,65,2144,72,77,68,12,12,13]

theorem envBound61079 : H12AffineFastState.Bounded env61079 := by
  intro p hp
  have h : env61079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61078_61079 : H12AffineEnvironment.transform 3 12 env61078 = env61079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env61078 == env61079) = true)

theorem identity61079 : scanCanonicalize (H12AffineFastState.compose env61079 (packedSelected [1,2,5,12,17] rootPS)) = affineNative (2^(5+1) ^^^ 44) := by decide +kernel

theorem selectedBound61079 : packedSelected [1,2,5,12,17] rootPS < 2^1333 := by decide +kernel

def env61080 : List Nat := [2,4,8,12,32,44,128,40,32,9,2048,32,40,44,45,2,32,130,37,44,33,169,33,3,140,44,7,1,45,2060,36,33,40,12,12,13]

theorem envBound61080 : H12AffineFastState.Bounded env61080 := by
  intro p hp
  have h : env61080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61079_61080 : H12AffineEnvironment.transform 5 44 env61079 = env61080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 44 env61079 == env61080) = true)

theorem identity61080 : scanCanonicalize (H12AffineFastState.compose env61080 (packedSelected [1,2,3,5,10,12] rootPS)) = affineNative (2^(10+1) ^^^ 163) := by decide +kernel

theorem selectedBound61080 : packedSelected [1,2,3,5,10,12] rootPS < 2^1333 := by decide +kernel

def env61081 : List Nat := [2,4,8,12,32,44,128,40,32,9,163,32,40,44,45,2,32,130,37,44,33,169,33,3,140,44,7,1,45,175,36,33,40,12,12,13]

theorem envBound61081 : H12AffineFastState.Bounded env61081 := by
  intro p hp
  have h : env61081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61080_61081 : H12AffineEnvironment.transform 10 163 env61080 = env61081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 163 env61080 == env61081) = true)

theorem identity61081 : scanCanonicalize (H12AffineFastState.compose env61081 (packedSelected [0,1,3,4,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound61081 : packedSelected [0,1,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env61082 : List Nat := [2,4,8,12,32,44,9,40,32,9,42,32,40,44,45,2,32,11,37,44,33,32,33,3,5,44,7,1,45,38,36,33,40,12,12,13]

theorem envBound61082 : H12AffineFastState.Bounded env61082 := by
  intro p hp
  have h : env61082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61081_61082 : H12AffineEnvironment.transform 6 9 env61081 = env61082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env61081 == env61082) = true)

theorem identity61082 : scanCanonicalize (H12AffineFastState.compose env61082 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound61082 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env61083 : List Nat := [2,4,8,12,12,0,9,4,12,9,6,12,4,0,1,2,12,11,9,0,13,12,13,3,5,0,7,1,1,10,8,13,4,12,12,13]

theorem envBound61083 : H12AffineFastState.Bounded env61083 := by
  intro p hp
  have h : env61083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61082_61083 : H12AffineEnvironment.transform 4 12 env61082 = env61083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env61082 == env61083) = true)

theorem identity61083 : scanCanonicalize (H12AffineFastState.compose env61083 (packedSelected [0,1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound61083 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env61084 : List Nat := [2,1,8,9,9,0,9,1,9,9,3,9,1,0,1,2,9,11,9,0,8,9,8,3,0,0,2,1,1,10,8,8,1,9,9,8]

theorem envBound61084 : H12AffineFastState.Bounded env61084 := by
  intro p hp
  have h : env61084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61083_61084 : H12AffineEnvironment.transform 1 1 env61083 = env61084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env61083 == env61084) = true)

theorem identity61084 : scanCanonicalize (H12AffineFastState.compose env61084 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound61084 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env61085 : List Nat := [2,1,1,0,0,0,0,1,0,0,3,0,1,0,1,2,0,2,0,0,1,0,1,3,0,0,2,1,1,3,1,1,1,0,0,1]

theorem envBound61085 : H12AffineFastState.Bounded env61085 := by
  intro p hp
  have h : env61085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61084_61085 : H12AffineEnvironment.transform 2 1 env61084 = env61085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env61084 == env61085) = true)

theorem identity61085 : scanCanonicalize (H12AffineFastState.compose env61085 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound61085 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env61086 : List Nat := [0,1,1,0,0,0,0,1,0,0,1,0,1,0,1,0,0,0,0,0,1,0,1,1,0,0,0,1,1,1,1,1,1,0,0,1]

theorem envBound61086 : H12AffineFastState.Bounded env61086 := by
  intro p hp
  have h : env61086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61085_61086 : H12AffineEnvironment.transform 0 0 env61085 = env61086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env61085 == env61086) = true)

def env61087 : List Nat := [2,4,8,16,32,64,128,256,277,337,2048,81,89,64,260,111,264,239,272,261,80,412,265,110,144,281,303,345,65,2173,85,81,256,329,16,341]

theorem envBound61087 : H12AffineFastState.Bounded env61087 := by
  intro p hp
  have h : env61087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61076_61087 : H12AffineEnvironment.transform 8 277 env61076 = env61087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env61076 == env61087) = true)

theorem identity61087 : scanCanonicalize (H12AffineFastState.compose env61087 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound61087 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env61088 : List Nat := [2,4,8,16,32,64,128,4,17,85,2048,81,89,64,0,111,12,239,20,1,80,152,13,110,144,29,43,93,65,2173,85,81,4,77,16,81]

theorem envBound61088 : H12AffineFastState.Bounded env61088 := by
  intro p hp
  have h : env61088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61087_61088 : H12AffineEnvironment.transform 7 4 env61087 = env61088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env61087 == env61088) = true)

theorem identity61088 : scanCanonicalize (H12AffineFastState.compose env61088 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound61088 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env61089 : List Nat := [2,4,8,16,32,16,128,4,17,5,2048,1,9,16,0,63,12,191,20,1,0,152,13,62,144,29,43,13,17,2093,5,1,4,29,16,1]

theorem envBound61089 : H12AffineFastState.Bounded env61089 := by
  intro p hp
  have h : env61089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61088_61089 : H12AffineEnvironment.transform 5 16 env61088 = env61089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env61088 == env61089) = true)

theorem identity61089 : scanCanonicalize (H12AffineFastState.compose env61089 (packedSelected [0,2,3,7,8,11,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 191) := by decide +kernel

theorem selectedBound61089 : packedSelected [0,2,3,7,8,11,12,15] rootPS < 2^1333 := by decide +kernel

def env61090 : List Nat := [2,4,8,16,32,16,128,4,17,5,191,1,9,16,0,63,12,191,20,1,0,152,13,62,144,29,43,13,17,146,5,1,4,29,16,1]

theorem envBound61090 : H12AffineFastState.Bounded env61090 := by
  intro p hp
  have h : env61090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61089_61090 : H12AffineEnvironment.transform 10 191 env61089 = env61090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 191 env61089 == env61090) = true)

theorem identity61090 : scanCanonicalize (H12AffineFastState.compose env61090 (packedSelected [0,3,5,7,8,10,11,12] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound61090 : packedSelected [0,3,5,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env61091 : List Nat := [2,4,3,16,32,16,128,4,17,5,180,1,2,16,0,52,7,180,20,1,0,147,6,53,144,22,32,6,17,146,5,1,4,22,16,1]

theorem envBound61091 : H12AffineFastState.Bounded env61091 := by
  intro p hp
  have h : env61091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61090_61091 : H12AffineEnvironment.transform 2 3 env61090 = env61091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env61090 == env61091) = true)

theorem identity61091 : scanCanonicalize (H12AffineFastState.compose env61091 (packedSelected [2,4,7] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound61091 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env61092 : List Nat := [2,3,3,16,32,16,128,3,17,2,179,1,2,16,0,51,0,179,19,1,0,147,1,50,144,17,32,1,17,146,2,1,3,17,16,1]

theorem envBound61092 : H12AffineFastState.Bounded env61092 := by
  intro p hp
  have h : env61092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61091_61092 : H12AffineEnvironment.transform 1 3 env61091 = env61092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env61091 == env61092) = true)

theorem identity61092 : scanCanonicalize (H12AffineFastState.compose env61092 (packedSelected [1,2] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound61092 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env61093 : List Nat := [2,3,3,16,32,16,18,3,17,2,33,1,2,16,0,51,0,33,19,1,0,1,1,50,2,17,32,1,17,0,2,1,3,17,16,1]

theorem envBound61093 : H12AffineFastState.Bounded env61093 := by
  intro p hp
  have h : env61093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61092_61093 : H12AffineEnvironment.transform 6 18 env61092 = env61093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env61092 == env61093) = true)

theorem identity61093 : scanCanonicalize (H12AffineFastState.compose env61093 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound61093 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env61094 : List Nat := [2,3,3,1,32,1,3,3,0,2,33,1,2,1,0,34,0,33,2,1,0,1,1,35,2,0,32,1,0,0,2,1,3,0,1,1]

theorem envBound61094 : H12AffineFastState.Bounded env61094 := by
  intro p hp
  have h : env61094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61093_61094 : H12AffineEnvironment.transform 3 1 env61093 = env61094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env61093 == env61094) = true)

theorem identity61094 : scanCanonicalize (H12AffineFastState.compose env61094 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound61094 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env61095 : List Nat := [0,1,1,1,32,1,1,1,0,0,33,1,0,1,0,32,0,33,0,1,0,1,1,33,0,0,32,1,0,0,0,1,1,0,1,1]

theorem envBound61095 : H12AffineFastState.Bounded env61095 := by
  intro p hp
  have h : env61095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61094_61095 : H12AffineEnvironment.transform 0 0 env61094 = env61095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env61094 == env61095) = true)

theorem identity61095 : scanCanonicalize (H12AffineFastState.compose env61095 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound61095 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env61096 : List Nat := [0,1,1,1,1,1,1,1,0,0,0,1,0,1,0,1,0,0,0,1,0,1,1,0,0,0,1,1,0,0,0,1,1,0,1,1]

theorem envBound61096 : H12AffineFastState.Bounded env61096 := by
  intro p hp
  have h : env61096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61095_61096 : H12AffineEnvironment.transform 4 1 env61095 = env61096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env61095 == env61096) = true)

def env61097 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74863,65665,4417,8540,4097,5276,74047,66896,13769,78895,1151,74814,1296,81227,8204,1280,256,65830,1345,5952]

theorem envBound61097 : H12AffineFastState.Bounded env61097 := by
  intro p hp
  have h : env61097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61020_61097 : H12AffineEnvironment.transform 17 65665 env61020 = env61097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env61020 == env61097) = true)

theorem identity61097 : scanCanonicalize (H12AffineFastState.compose env61097 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound61097 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env61098 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,24,1297,325,65536,66679,65665,4417,324,4097,5276,65831,66896,5585,70711,1151,66598,1296,73043,20,1280,256,65830,1345,5952]

theorem envBound61098 : H12AffineFastState.Bounded env61098 := by
  intro p hp
  have h : env61098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61097_61098 : H12AffineEnvironment.transform 12 24 env61097 = env61098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env61097 == env61098) = true)

def env61099 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1556,24,1297,325,65536,66679,65665,1877,324,1557,648,65831,66896,965,66083,1151,66598,1296,68423,20,1280,256,65830,1345,340]

theorem envBound61099 : H12AffineFastState.Bounded env61099 := by
  intro p hp
  have h : env61099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61098_61099 : H12AffineEnvironment.transform 11 1556 env61098 = env61099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1556 env61098 == env61099) = true)

def env61100 : List Nat := [2,4,8,16,32,0,128,256,512,1024,2048,1556,24,1297,261,65536,66615,65665,1813,260,1557,648,65831,66832,901,66083,1087,66598,1296,68359,20,1280,256,65830,1281,276]

theorem envBound61100 : H12AffineFastState.Bounded env61100 := by
  intro p hp
  have h : env61100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61099_61100 : H12AffineEnvironment.transform 5 0 env61099 = env61100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env61099 == env61100) = true)

theorem identity61100 : scanCanonicalize (H12AffineFastState.compose env61100 (packedSelected [1,8,28] rootPS)) = affineNative (2^(7+1) ^^^ 24) := by decide +kernel

theorem selectedBound61100 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env61101 : List Nat := [2,4,8,16,32,0,128,24,512,1024,2048,1556,24,1033,29,65536,66615,65665,1549,28,1557,648,65599,66568,669,66083,1087,66598,1032,68127,20,1048,24,65598,1049,12]

theorem envBound61101 : H12AffineFastState.Bounded env61101 := by
  intro p hp
  have h : env61101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61100_61101 : H12AffineEnvironment.transform 7 24 env61100 = env61101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 24 env61100 == env61101) = true)

def env61102 : List Nat := [2,4,8,12,32,0,128,4,512,1024,2048,1544,4,1033,1,65536,66603,65665,1549,0,1545,648,65571,66568,641,66083,1059,66598,1032,68099,8,1028,4,65570,1029,12]

theorem envBound61102 : H12AffineFastState.Bounded env61102 := by
  intro p hp
  have h : env61102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61101_61102 : H12AffineEnvironment.transform 3 12 env61101 = env61102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env61101 == env61102) = true)

theorem identity61102 : scanCanonicalize (H12AffineFastState.compose env61102 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 1067) := by decide +kernel

theorem selectedBound61102 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env61103 : List Nat := [2,4,8,12,32,0,128,4,512,1024,2048,1544,4,1033,1,1067,0,1194,1549,0,1545,648,1032,35,641,1544,1059,13,1032,3624,8,1028,4,1033,1029,12]

theorem envBound61103 : H12AffineFastState.Bounded env61103 := by
  intro p hp
  have h : env61103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61102_61103 : H12AffineEnvironment.transform 15 1067 env61102 = env61103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1067 env61102 == env61103) = true)

theorem identity61103 : scanCanonicalize (H12AffineFastState.compose env61103 (packedSelected [1,4,8,9,12,13,15,23] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound61103 : packedSelected [1,4,8,9,12,13,15,23] rootPS < 2^1333 := by decide +kernel

def env61104 : List Nat := [2,4,8,12,32,0,128,4,512,517,2048,13,4,524,1,558,0,687,8,0,12,648,525,35,641,13,550,13,525,2093,8,513,4,524,512,12]

theorem envBound61104 : H12AffineFastState.Bounded env61104 := by
  intro p hp
  have h : env61104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61103_61104 : H12AffineEnvironment.transform 9 517 env61103 = env61104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env61103 == env61104) = true)

theorem identity61104 : scanCanonicalize (H12AffineFastState.compose env61104 (packedSelected [1,3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 7) := by decide +kernel

theorem selectedBound61104 : packedSelected [1,3,5,10] rootPS < 2^1333 := by decide +kernel

def env61105 : List Nat := [2,4,8,12,32,0,128,4,512,517,7,13,4,524,1,558,0,687,8,0,12,648,525,35,641,13,550,13,525,42,8,513,4,524,512,12]

theorem envBound61105 : H12AffineFastState.Bounded env61105 := by
  intro p hp
  have h : env61105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61104_61105 : H12AffineEnvironment.transform 10 7 env61104 = env61105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 7 env61104 == env61105) = true)

theorem identity61105 : scanCanonicalize (H12AffineFastState.compose env61105 (packedSelected [1,3,5,12] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound61105 : packedSelected [1,3,5,12] rootPS < 2^1333 := by decide +kernel

def env61106 : List Nat := [2,4,8,12,11,0,128,4,512,517,7,13,4,524,1,517,0,644,8,0,12,648,525,8,641,13,525,13,525,1,8,513,4,524,512,12]

theorem envBound61106 : H12AffineFastState.Bounded env61106 := by
  intro p hp
  have h : env61106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61105_61106 : H12AffineEnvironment.transform 4 11 env61105 = env61106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env61105 == env61106) = true)

theorem identity61106 : scanCanonicalize (H12AffineFastState.compose env61106 (packedSelected [0,1,3,5,7] rootPS)) = affineNative (2^(8+1) ^^^ 133) := by decide +kernel

theorem selectedBound61106 : packedSelected [0,1,3,5,7] rootPS < 2^1333 := by decide +kernel

def env61107 : List Nat := [2,4,8,12,11,0,128,4,133,128,7,13,4,137,1,128,0,1,8,0,12,13,136,8,4,13,136,13,136,1,8,132,4,137,133,12]

theorem envBound61107 : H12AffineFastState.Bounded env61107 := by
  intro p hp
  have h : env61107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61106_61107 : H12AffineEnvironment.transform 8 133 env61106 = env61107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 133 env61106 == env61107) = true)

theorem identity61107 : scanCanonicalize (H12AffineFastState.compose env61107 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound61107 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env61108 : List Nat := [2,4,8,12,11,0,4,4,1,4,7,13,4,13,1,4,0,1,8,0,12,13,12,8,4,13,12,13,12,1,8,0,4,13,1,12]

theorem envBound61108 : H12AffineFastState.Bounded env61108 := by
  intro p hp
  have h : env61108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61107_61108 : H12AffineEnvironment.transform 6 4 env61107 = env61108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env61107 == env61108) = true)

theorem identity61108 : scanCanonicalize (H12AffineFastState.compose env61108 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound61108 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env61109 : List Nat := [2,4,4,0,7,0,4,4,1,4,7,1,4,1,1,4,0,1,4,0,0,1,0,4,4,1,0,1,0,1,4,0,4,1,1,0]

theorem envBound61109 : H12AffineFastState.Bounded env61109 := by
  intro p hp
  have h : env61109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61108_61109 : H12AffineEnvironment.transform 2 4 env61108 = env61109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env61108 == env61109) = true)

theorem identity61109 : scanCanonicalize (H12AffineFastState.compose env61109 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound61109 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env61110 : List Nat := [0,4,4,0,5,0,4,4,1,4,5,1,4,1,1,4,0,1,4,0,0,1,0,4,4,1,0,1,0,1,4,0,4,1,1,0]

theorem envBound61110 : H12AffineFastState.Bounded env61110 := by
  intro p hp
  have h : env61110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61109_61110 : H12AffineEnvironment.transform 0 0 env61109 = env61110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env61109 == env61110) = true)

def env61111 : List Nat := [2,4,8,13,32,0,128,5,512,1024,2048,1545,5,1033,0,65536,66602,65665,1549,1,1544,648,65570,66568,640,66083,1058,66598,1032,68098,9,1029,5,65571,1028,12]

theorem envBound61111 : H12AffineFastState.Bounded env61111 := by
  intro p hp
  have h : env61111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61101_61111 : H12AffineEnvironment.transform 3 13 env61101 = env61111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env61101 == env61111) = true)

theorem identity61111 : scanCanonicalize (H12AffineFastState.compose env61111 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound61111 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env61112 : List Nat := [2,4,5,0,32,0,128,5,512,1024,2048,1540,5,1028,0,65536,66599,65665,1536,1,1541,645,65570,66565,640,66083,1058,66598,1029,68098,4,1029,5,65571,1028,1]

theorem envBound61112 : H12AffineFastState.Bounded env61112 := by
  intro p hp
  have h : env61112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61111_61112 : H12AffineEnvironment.transform 2 5 env61111 = env61112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env61111 == env61112) = true)

theorem identity61112 : scanCanonicalize (H12AffineFastState.compose env61112 (packedSelected [0,1,3,4,7,9,11,13,16,17,19] rootPS)) = affineNative (2^(15+1) ^^^ 2214) := by decide +kernel

theorem selectedBound61112 : packedSelected [0,1,3,4,7,9,11,13,16,17,19] rootPS < 2^1333 := by decide +kernel

def env61113 : List Nat := [2,4,5,0,32,0,128,5,512,1024,2048,1540,5,1028,0,2214,3201,2087,1536,1,1541,645,2180,3235,640,2693,1058,3200,1029,676,4,1029,5,2181,1028,1]

theorem envBound61113 : H12AffineFastState.Bounded env61113 := by
  intro p hp
  have h : env61113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61112_61113 : H12AffineEnvironment.transform 15 2214 env61112 = env61113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2214 env61112 == env61113) = true)

theorem identity61113 : scanCanonicalize (H12AffineFastState.compose env61113 (packedSelected [0,1,2,7,8,13,15,18,21] rootPS)) = affineNative (2^(9+1) ^^^ 546) := by decide +kernel

theorem selectedBound61113 : packedSelected [0,1,2,7,8,13,15,18,21] rootPS < 2^1333 := by decide +kernel

def env61114 : List Nat := [2,4,5,0,32,0,128,5,512,546,2048,38,5,550,0,2214,2723,2087,34,1,39,645,2180,2689,640,2693,512,2722,551,676,4,551,5,2181,550,1]

theorem envBound61114 : H12AffineFastState.Bounded env61114 := by
  intro p hp
  have h : env61114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61113_61114 : H12AffineEnvironment.transform 9 546 env61113 = env61114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 546 env61113 == env61114) = true)

theorem identity61114 : scanCanonicalize (H12AffineFastState.compose env61114 (packedSelected [0,4,5,7,9,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound61114 : packedSelected [0,4,5,7,9,11,12] rootPS < 2^1333 := by decide +kernel

def env61115 : List Nat := [2,4,5,0,32,0,128,5,512,546,32,38,5,550,0,134,643,7,34,1,39,645,164,673,640,677,512,642,551,676,4,551,5,165,550,1]

theorem envBound61115 : H12AffineFastState.Bounded env61115 := by
  intro p hp
  have h : env61115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61114_61115 : H12AffineEnvironment.transform 10 32 env61114 = env61115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env61114 == env61115) = true)

theorem identity61115 : scanCanonicalize (H12AffineFastState.compose env61115 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 37) := by decide +kernel

theorem selectedBound61115 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env61116 : List Nat := [2,4,5,0,32,0,37,5,512,546,32,38,5,550,0,35,550,7,34,1,39,544,1,516,549,512,512,551,551,513,4,551,5,0,550,1]

theorem envBound61116 : H12AffineFastState.Bounded env61116 := by
  intro p hp
  have h : env61116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61115_61116 : H12AffineEnvironment.transform 6 37 env61115 = env61116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 37 env61115 == env61116) = true)

theorem identity61116 : scanCanonicalize (H12AffineFastState.compose env61116 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound61116 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env61117 : List Nat := [2,4,5,0,1,0,4,5,512,515,1,7,5,519,0,2,519,7,3,1,6,513,1,516,516,512,512,518,518,513,4,518,5,0,519,1]

theorem envBound61117 : H12AffineFastState.Bounded env61117 := by
  intro p hp
  have h : env61117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61116_61117 : H12AffineEnvironment.transform 4 1 env61116 = env61117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env61116 == env61117) = true)

theorem identity61117 : scanCanonicalize (H12AffineFastState.compose env61117 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 6) := by decide +kernel

theorem selectedBound61117 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env61118 : List Nat := [2,4,5,0,1,0,4,5,6,5,1,7,5,1,0,2,1,7,3,1,6,7,1,2,2,6,6,0,0,7,4,0,5,0,1,1]

theorem envBound61118 : H12AffineFastState.Bounded env61118 := by
  intro p hp
  have h : env61118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61117_61118 : H12AffineEnvironment.transform 8 6 env61117 = env61118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 6 env61117 == env61118) = true)

theorem identity61118 : scanCanonicalize (H12AffineFastState.compose env61118 (packedSelected [5] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound61118 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env61119 : List Nat := [2,3,2,0,1,0,3,2,1,2,1,0,2,1,0,2,1,0,3,1,1,0,1,2,2,1,1,0,0,0,3,0,2,0,1,1]

theorem envBound61119 : H12AffineFastState.Bounded env61119 := by
  intro p hp
  have h : env61119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61118_61119 : H12AffineEnvironment.transform 1 3 env61118 = env61119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env61118 == env61119) = true)

def env61120 : List Nat := [2,4,8,16,32,1,128,256,512,1024,2048,1556,24,1297,260,65536,66614,65665,1812,261,1557,648,65831,66833,900,66083,1086,66598,1296,68358,20,1280,256,65830,1280,277]

theorem envBound61120 : H12AffineFastState.Bounded env61120 := by
  intro p hp
  have h : env61120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61099_61120 : H12AffineEnvironment.transform 5 1 env61099 = env61120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env61099 == env61120) = true)

theorem identity61120 : scanCanonicalize (H12AffineFastState.compose env61120 (packedSelected [1,8,28] rootPS)) = affineNative (2^(9+1) ^^^ 8) := by decide +kernel

theorem selectedBound61120 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env61121 : List Nat := [2,4,8,16,32,1,128,256,512,8,2048,540,24,281,260,65536,65598,65665,796,261,541,648,65831,65817,900,66083,54,65582,280,68358,20,264,256,65830,264,277]

theorem envBound61121 : H12AffineFastState.Bounded env61121 := by
  intro p hp
  have h : env61121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61120_61121 : H12AffineEnvironment.transform 9 8 env61120 = env61121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 8 env61120 == env61121) = true)

def env61122 : List Nat := [2,4,8,16,32,1,128,24,512,8,2048,540,24,1,28,65536,65598,65665,516,29,541,648,65599,65537,668,66083,54,65582,0,68126,20,16,24,65598,16,13]

theorem envBound61122 : H12AffineFastState.Bounded env61122 := by
  intro p hp
  have h : env61122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61121_61122 : H12AffineEnvironment.transform 7 24 env61121 = env61122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 24 env61121 == env61122) = true)

theorem identity61122 : scanCanonicalize (H12AffineFastState.compose env61122 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound61122 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env61123 : List Nat := [2,4,8,12,32,1,128,4,512,8,2048,512,4,1,0,65536,65570,65665,516,1,513,648,65571,65537,640,66083,42,65582,0,68098,8,12,4,65570,12,13]

theorem envBound61123 : H12AffineFastState.Bounded env61123 := by
  intro p hp
  have h : env61123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61122_61123 : H12AffineEnvironment.transform 3 12 env61122 = env61123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env61122 == env61123) = true)

theorem identity61123 : scanCanonicalize (H12AffineFastState.compose env61123 (packedSelected [3,11,15,18] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound61123 : packedSelected [3,11,15,18] rootPS < 2^1333 := by decide +kernel

def env61124 : List Nat := [2,4,8,12,32,1,2,4,512,8,2048,512,4,1,0,65536,65570,65539,516,1,513,522,65571,65537,514,66083,42,65582,0,68098,8,12,4,65570,12,13]

theorem envBound61124 : H12AffineFastState.Bounded env61124 := by
  intro p hp
  have h : env61124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61123_61124 : H12AffineEnvironment.transform 6 2 env61123 = env61124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env61123 == env61124) = true)

theorem identity61124 : scanCanonicalize (H12AffineFastState.compose env61124 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound61124 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env61125 : List Nat := [2,4,5,1,32,1,2,4,512,5,2048,512,4,1,0,65536,65570,65539,516,1,513,519,65571,65537,514,66083,39,65571,0,68098,5,1,4,65570,1,0]

theorem envBound61125 : H12AffineFastState.Bounded env61125 := by
  intro p hp
  have h : env61125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61124_61125 : H12AffineEnvironment.transform 2 5 env61124 = env61125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env61124 == env61125) = true)

theorem identity61125 : scanCanonicalize (H12AffineFastState.compose env61125 (packedSelected [1,2,5,8] rootPS)) = affineNative (2^(15+1) ^^^ 2564) := by decide +kernel

theorem selectedBound61125 : packedSelected [1,2,5,8] rootPS < 2^1333 := by decide +kernel

def env61126 : List Nat := [2,4,5,1,32,1,2,4,512,5,2048,512,4,1,0,2564,2598,2567,516,1,513,519,2599,2565,514,2087,39,2599,0,6,5,1,4,2598,1,0]

theorem envBound61126 : H12AffineFastState.Bounded env61126 := by
  intro p hp
  have h : env61126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61125_61126 : H12AffineEnvironment.transform 15 2564 env61125 = env61126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2564 env61125 == env61126) = true)

theorem identity61126 : scanCanonicalize (H12AffineFastState.compose env61126 (packedSelected [0,1,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound61126 : packedSelected [0,1,2,7] rootPS < 2^1333 := by decide +kernel

def env61127 : List Nat := [2,4,5,1,32,1,2,4,512,5,512,512,4,1,0,4,38,7,516,1,513,519,39,5,514,551,39,39,0,6,5,1,4,38,1,0]

theorem envBound61127 : H12AffineFastState.Bounded env61127 := by
  intro p hp
  have h : env61127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61126_61127 : H12AffineEnvironment.transform 10 512 env61126 = env61127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env61126 == env61127) = true)

theorem identity61127 : scanCanonicalize (H12AffineFastState.compose env61127 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound61127 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env61128 : List Nat := [2,4,5,1,0,1,2,4,512,5,512,512,4,1,0,4,6,7,516,1,513,519,7,5,514,519,7,7,0,6,5,1,4,6,1,0]

theorem envBound61128 : H12AffineFastState.Bounded env61128 := by
  intro p hp
  have h : env61128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61127_61128 : H12AffineEnvironment.transform 4 0 env61127 = env61128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env61127 == env61128) = true)

def env61129 : List Nat := [2,4,8,16,32,1,128,25,512,8,2048,540,24,0,29,65536,65598,65665,517,28,541,648,65598,65536,669,66083,54,65582,1,68127,20,17,25,65599,17,12]

theorem envBound61129 : H12AffineFastState.Bounded env61129 := by
  intro p hp
  have h : env61129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61121_61129 : H12AffineEnvironment.transform 7 25 env61121 = env61129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 25 env61121 == env61129) = true)

theorem identity61129 : scanCanonicalize (H12AffineFastState.compose env61129 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound61129 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env61130 : List Nat := [2,4,8,16,32,1,128,25,17,8,2048,13,24,0,29,65536,65598,65665,20,28,12,153,65598,65536,140,65586,54,65582,1,67598,20,17,25,65599,17,12]

theorem envBound61130 : H12AffineFastState.Bounded env61130 := by
  intro p hp
  have h : env61130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61129_61130 : H12AffineEnvironment.transform 8 17 env61129 = env61130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env61129 == env61130) = true)

theorem identity61130 : scanCanonicalize (H12AffineFastState.compose env61130 (packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS)) = affineNative (2^(15+1) ^^^ 2110) := by decide +kernel

theorem selectedBound61130 : packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS < 2^1333 := by decide +kernel

def env61131 : List Nat := [2,4,8,16,32,1,128,25,17,8,2048,13,24,0,29,2110,2048,2239,20,28,12,153,2048,2110,140,2060,54,2064,1,48,20,17,25,2049,17,12]

theorem envBound61131 : H12AffineFastState.Bounded env61131 := by
  intro p hp
  have h : env61131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61130_61131 : H12AffineEnvironment.transform 15 2110 env61130 = env61131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2110 env61130 == env61131) = true)

theorem identity61131 : scanCanonicalize (H12AffineFastState.compose env61131 (packedSelected [0,1,2,3,4,7,8,9,10,11,12,13,15,16] rootPS)) = affineNative (2^(10+1) ^^^ 130) := by decide +kernel

theorem selectedBound61131 : packedSelected [0,1,2,3,4,7,8,9,10,11,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env61132 : List Nat := [2,4,8,16,32,1,128,25,17,8,130,13,24,0,29,188,130,61,20,28,12,153,130,188,140,142,54,146,1,48,20,17,25,131,17,12]

theorem envBound61132 : H12AffineFastState.Bounded env61132 := by
  intro p hp
  have h : env61132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61131_61132 : H12AffineEnvironment.transform 10 130 env61131 = env61132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 130 env61131 == env61132) = true)

theorem identity61132 : scanCanonicalize (H12AffineFastState.compose env61132 (packedSelected [0,1,2,3,4,7,8,9,10,12] rootPS)) = affineNative (2^(6+1) ^^^ 37) := by decide +kernel

theorem selectedBound61132 : packedSelected [0,1,2,3,4,7,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env61133 : List Nat := [2,4,8,16,32,1,37,25,17,8,39,13,24,0,29,25,39,61,20,28,12,60,39,25,41,43,54,55,1,48,20,17,25,38,17,12]

theorem envBound61133 : H12AffineFastState.Bounded env61133 := by
  intro p hp
  have h : env61133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61132_61133 : H12AffineEnvironment.transform 6 37 env61132 = env61133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 37 env61132 == env61133) = true)

theorem identity61133 : scanCanonicalize (H12AffineFastState.compose env61133 (packedSelected [0,3,7,8] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound61133 : packedSelected [0,3,7,8] rootPS < 2^1333 := by decide +kernel

def env61134 : List Nat := [2,4,2,16,32,1,37,19,17,2,39,7,18,0,23,19,39,55,20,22,6,54,39,19,35,33,54,55,1,48,20,17,19,38,17,6]

theorem envBound61134 : H12AffineFastState.Bounded env61134 := by
  intro p hp
  have h : env61134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61133_61134 : H12AffineEnvironment.transform 2 2 env61133 = env61134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env61133 == env61134) = true)

theorem identity61134 : scanCanonicalize (H12AffineFastState.compose env61134 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 23) := by decide +kernel

theorem selectedBound61134 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env61135 : List Nat := [2,4,2,16,23,1,18,19,17,2,16,7,18,0,23,19,16,0,20,22,6,1,16,19,20,22,1,0,1,7,20,17,19,17,17,6]

theorem envBound61135 : H12AffineFastState.Bounded env61135 := by
  intro p hp
  have h : env61135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61134_61135 : H12AffineEnvironment.transform 4 23 env61134 = env61135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 23 env61134 == env61135) = true)

theorem identity61135 : scanCanonicalize (H12AffineFastState.compose env61135 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound61135 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env61136 : List Nat := [2,4,2,0,7,1,2,3,1,2,0,7,2,0,7,3,0,0,4,6,6,1,0,3,4,6,1,0,1,7,4,1,3,1,1,6]

theorem envBound61136 : H12AffineFastState.Bounded env61136 := by
  intro p hp
  have h : env61136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61135_61136 : H12AffineEnvironment.transform 3 0 env61135 = env61136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env61135 == env61136) = true)

def env61137 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1557,24,1297,325,65536,66679,65665,1876,324,1556,649,65831,66896,964,66082,1151,66598,1296,68422,20,1280,256,65830,1345,341]

theorem envBound61137 : H12AffineFastState.Bounded env61137 := by
  intro p hp
  have h : env61137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61098_61137 : H12AffineEnvironment.transform 11 1557 env61098 = env61137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1557 env61098 == env61137) = true)

def env61138 : List Nat := [2,4,8,16,32,0,128,256,512,1024,2048,1557,24,1297,261,65536,66615,65665,1812,260,1556,649,65831,66832,900,66082,1087,66598,1296,68358,20,1280,256,65830,1281,277]

theorem envBound61138 : H12AffineFastState.Bounded env61138 := by
  intro p hp
  have h : env61138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61137_61138 : H12AffineEnvironment.transform 5 0 env61137 = env61138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env61137 == env61138) = true)

theorem identity61138 : scanCanonicalize (H12AffineFastState.compose env61138 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 46) := by decide +kernel

theorem selectedBound61138 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env61139 : List Nat := [2,4,8,16,32,0,128,256,512,1024,2048,1557,24,1297,261,46,1049,175,1812,260,1556,649,265,1342,900,524,1087,1032,1296,2856,20,1280,256,264,1281,277]

theorem envBound61139 : H12AffineFastState.Bounded env61139 := by
  intro p hp
  have h : env61139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61138_61139 : H12AffineEnvironment.transform 15 46 env61138 = env61139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 46 env61138 == env61139) = true)

def env61140 : List Nat := [2,4,8,16,32,0,128,256,512,272,2048,773,24,1,261,46,265,175,516,260,772,649,265,46,900,524,303,280,0,2856,20,16,256,264,17,277]

theorem envBound61140 : H12AffineFastState.Bounded env61140 := by
  intro p hp
  have h : env61140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61139_61140 : H12AffineEnvironment.transform 9 272 env61139 = env61140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env61139 == env61140) = true)

theorem identity61140 : scanCanonicalize (H12AffineFastState.compose env61140 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound61140 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env61141 : List Nat := [2,4,8,16,32,0,128,5,512,21,2048,512,24,1,0,46,12,175,516,1,513,649,12,46,641,524,42,29,0,2605,20,16,5,13,17,16]

theorem envBound61141 : H12AffineFastState.Bounded env61141 := by
  intro p hp
  have h : env61141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61140_61141 : H12AffineEnvironment.transform 7 5 env61140 = env61141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env61140 == env61141) = true)

theorem identity61141 : scanCanonicalize (H12AffineFastState.compose env61141 (packedSelected [3,11,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 147) := by decide +kernel

theorem selectedBound61141 : packedSelected [3,11,15,18] rootPS < 2^1333 := by decide +kernel

def env61142 : List Nat := [2,4,8,16,32,0,128,5,147,21,2048,147,24,1,0,46,12,175,151,1,146,26,12,46,18,159,42,29,0,2238,20,16,5,13,17,16]

theorem envBound61142 : H12AffineFastState.Bounded env61142 := by
  intro p hp
  have h : env61142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61141_61142 : H12AffineEnvironment.transform 8 147 env61141 = env61142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 147 env61141 == env61142) = true)

theorem identity61142 : scanCanonicalize (H12AffineFastState.compose env61142 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound61142 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env61143 : List Nat := [2,4,8,0,32,0,128,5,131,5,2048,131,8,1,0,46,12,175,135,1,130,10,12,46,2,143,42,13,0,2222,4,0,5,13,1,0]

theorem envBound61143 : H12AffineFastState.Bounded env61143 := by
  intro p hp
  have h : env61143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61142_61143 : H12AffineEnvironment.transform 3 0 env61142 = env61143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env61142 == env61143) = true)

theorem identity61143 : scanCanonicalize (H12AffineFastState.compose env61143 (packedSelected [1,2,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 39) := by decide +kernel

theorem selectedBound61143 : packedSelected [1,2,5,8] rootPS < 2^1333 := by decide +kernel

def env61144 : List Nat := [2,4,8,0,32,0,128,5,131,5,39,131,8,1,0,46,12,175,135,1,130,10,12,46,2,143,42,13,0,137,4,0,5,13,1,0]

theorem envBound61144 : H12AffineFastState.Bounded env61144 := by
  intro p hp
  have h : env61144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61143_61144 : H12AffineEnvironment.transform 10 39 env61143 = env61144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 39 env61143 == env61144) = true)

theorem identity61144 : scanCanonicalize (H12AffineFastState.compose env61144 (packedSelected [1,4,9] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound61144 : packedSelected [1,4,9] rootPS < 2^1333 := by decide +kernel

def env61145 : List Nat := [2,4,8,0,32,0,2,5,1,5,39,1,8,1,0,46,12,45,5,1,0,10,12,46,2,13,42,13,0,11,4,0,5,13,1,0]

theorem envBound61145 : H12AffineFastState.Bounded env61145 := by
  intro p hp
  have h : env61145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61144_61145 : H12AffineEnvironment.transform 6 2 env61144 = env61145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env61144 == env61145) = true)

theorem identity61145 : scanCanonicalize (H12AffineFastState.compose env61145 (packedSelected [2,3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound61145 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env61146 : List Nat := [2,3,8,0,32,0,2,2,1,2,32,1,8,1,0,41,11,42,2,1,0,10,11,41,2,10,42,10,0,11,3,0,2,10,1,0]

theorem envBound61146 : H12AffineFastState.Bounded env61146 := by
  intro p hp
  have h : env61146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61145_61146 : H12AffineEnvironment.transform 1 3 env61145 = env61146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env61145 == env61146) = true)

theorem identity61146 : scanCanonicalize (H12AffineFastState.compose env61146 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound61146 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env61147 : List Nat := [2,3,8,0,0,0,2,2,1,2,0,1,8,1,0,9,11,10,2,1,0,10,11,9,2,10,10,10,0,11,3,0,2,10,1,0]

theorem envBound61147 : H12AffineFastState.Bounded env61147 := by
  intro p hp
  have h : env61147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61146_61147 : H12AffineEnvironment.transform 4 0 env61146 = env61147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env61146 == env61147) = true)

theorem identity61147 : scanCanonicalize (H12AffineFastState.compose env61147 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound61147 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env61148 : List Nat := [0,1,8,0,0,0,0,0,1,0,0,1,8,1,0,9,9,8,0,1,0,8,9,9,0,8,8,8,0,9,1,0,0,8,1,0]

theorem envBound61148 : H12AffineFastState.Bounded env61148 := by
  intro p hp
  have h : env61148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61147_61148 : H12AffineEnvironment.transform 0 0 env61147 = env61148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env61147 == env61148) = true)

theorem identity61148 : scanCanonicalize (H12AffineFastState.compose env61148 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound61148 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env61149 : List Nat := [0,1,0,0,0,0,0,0,1,0,0,1,0,1,0,1,1,0,0,1,0,0,1,1,0,0,0,0,0,1,1,0,0,0,1,0]

theorem envBound61149 : H12AffineFastState.Bounded env61149 := by
  intro p hp
  have h : env61149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61148_61149 : H12AffineEnvironment.transform 2 0 env61148 = env61149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env61148 == env61149) = true)

def env61150 : List Nat := [2,4,8,16,32,0,128,256,512,273,2048,772,24,0,261,46,264,175,517,260,773,649,265,47,900,524,302,281,1,2856,20,17,256,264,16,277]

theorem envBound61150 : H12AffineFastState.Bounded env61150 := by
  intro p hp
  have h : env61150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61139_61150 : H12AffineEnvironment.transform 9 273 env61139 = env61150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env61139 == env61150) = true)

theorem identity61150 : scanCanonicalize (H12AffineFastState.compose env61150 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound61150 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env61151 : List Nat := [2,4,8,16,32,0,128,256,16,273,2048,276,24,0,261,46,264,175,21,260,277,153,265,47,404,28,302,281,1,2360,20,17,256,264,16,277]

theorem envBound61151 : H12AffineFastState.Bounded env61151 := by
  intro p hp
  have h : env61151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61150_61151 : H12AffineEnvironment.transform 8 16 env61150 = env61151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env61150 == env61151) = true)

theorem identity61151 : scanCanonicalize (H12AffineFastState.compose env61151 (packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS)) = affineNative (2^(10+1) ^^^ 264) := by decide +kernel

theorem selectedBound61151 : packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS < 2^1333 := by decide +kernel

def env61152 : List Nat := [2,4,8,16,32,0,128,256,16,273,264,276,24,0,261,46,264,175,21,260,277,153,265,47,404,28,302,281,1,48,20,17,256,264,16,277]

theorem envBound61152 : H12AffineFastState.Bounded env61152 := by
  intro p hp
  have h : env61152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61151_61152 : H12AffineEnvironment.transform 10 264 env61151 = env61152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 264 env61151 == env61152) = true)

theorem identity61152 : scanCanonicalize (H12AffineFastState.compose env61152 (packedSelected [0,1,2,3,4,7,8,9,10,11,12,13,15,16] rootPS)) = affineNative (2^(6+1) ^^^ 14) := by decide +kernel

theorem selectedBound61152 : packedSelected [0,1,2,3,4,7,8,9,10,11,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env61153 : List Nat := [2,4,8,16,32,0,14,256,16,273,264,276,24,0,261,46,264,33,21,260,277,23,265,47,282,28,302,281,1,48,20,17,256,264,16,277]

theorem envBound61153 : H12AffineFastState.Bounded env61153 := by
  intro p hp
  have h : env61153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61152_61153 : H12AffineEnvironment.transform 6 14 env61152 = env61153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 14 env61152 == env61153) = true)

theorem identity61153 : scanCanonicalize (H12AffineFastState.compose env61153 (packedSelected [0,3,4,7,9] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound61153 : packedSelected [0,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env61154 : List Nat := [2,4,8,12,32,0,14,256,12,269,264,264,4,0,261,46,264,33,9,260,265,11,265,47,262,0,302,261,1,44,8,13,256,264,12,265]

theorem envBound61154 : H12AffineFastState.Bounded env61154 := by
  intro p hp
  have h : env61154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans61153_61154 : H12AffineEnvironment.transform 3 12 env61153 = env61154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env61153 == env61154) = true)

theorem identity61154 : scanCanonicalize (H12AffineFastState.compose env61154 (packedSelected [1,2] rootPS)) = affineNative (2^(7+1) ^^^ 9) := by decide +kernel

end H12CloudChart2