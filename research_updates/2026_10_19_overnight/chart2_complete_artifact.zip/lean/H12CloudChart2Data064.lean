import H12CloudChart2Data063

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env15660 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,2208,4097,130,7358,1297,7609,1024,131,4097,2091,5376,7480,2088,5376,5270,4096,1297,5434,1285,7570,256,2091,1296,136]

theorem envBound15660 : H12AffineFastState.Bounded env15660 := by
  intro p hp
  have h : env15660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15659_15660 : H12AffineEnvironment.transform 14 130 env15659 = env15660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 130 env15659 == env15660) = true)

theorem identity15660 : scanCanonicalize (H12AffineFastState.compose env15660 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 302) := by decide +kernel

theorem selectedBound15660 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env15661 : List Nat := [2,4,8,16,32,16,128,256,136,1024,302,4096,398,4097,130,5520,1297,5271,1024,131,4097,261,5376,5142,262,5376,5270,4096,1297,5434,1285,5308,256,261,1296,136]

theorem envBound15661 : H12AffineFastState.Bounded env15661 := by
  intro p hp
  have h : env15661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15660_15661 : H12AffineEnvironment.transform 10 302 env15660 = env15661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 302 env15660 == env15661) = true)

def env15662 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,8192,4097,32768,46236,1297,13593,1024,32769,4097,4194304,5376,13721,8328,5376,4207645,4096,1297,15770,1284,4232506,256,40969,1297,136]

theorem envBound15662 : H12AffineFastState.Bounded env15662 := by
  intro p hp
  have h : env15662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15656_15662 : H12AffineEnvironment.transform 23 13721 env15656 = env15662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 13721 env15656 == env15662) = true)

theorem identity15662 : scanCanonicalize (H12AffineFastState.compose env15662 (packedSelected [1,12,13] rootPS)) = affineNative (2^(21+1) ^^^ 41089) := by decide +kernel

theorem selectedBound15662 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env15663 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,8192,4097,32768,46236,1297,13593,1024,32769,4097,41089,5376,13721,8328,5376,38044,4096,1297,15770,1284,13755,256,40969,1297,136]

theorem envBound15663 : H12AffineFastState.Bounded env15663 := by
  intro p hp
  have h : env15663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15662_15663 : H12AffineEnvironment.transform 21 41089 env15662 = env15663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env15662 == env15663) = true)

theorem identity15663 : scanCanonicalize (H12AffineFastState.compose env15663 (packedSelected [1,5,8,12,17] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound15663 : packedSelected [1,5,8,12,17] rootPS < 2^1333 := by decide +kernel

def env15664 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,8192,4097,8461,5521,1297,13593,1024,8460,4097,396,5376,13721,8328,5376,13713,4096,1297,15770,1284,13755,256,260,1297,136]

theorem envBound15664 : H12AffineFastState.Bounded env15664 := by
  intro p hp
  have h : env15664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15663_15664 : H12AffineEnvironment.transform 14 8461 env15663 = env15664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env15663 == env15664) = true)

theorem identity15664 : scanCanonicalize (H12AffineFastState.compose env15664 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 1045) := by decide +kernel

theorem selectedBound15664 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env15665 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,1045,8192,1044,8461,388,1297,8460,1024,8460,1044,396,277,8588,8328,277,8580,1045,1297,10639,1284,8622,256,260,1297,136]

theorem envBound15665 : H12AffineFastState.Bounded env15665 := by
  intro p hp
  have h : env15665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15664_15665 : H12AffineEnvironment.transform 11 1045 env15664 = env15665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1045 env15664 == env15665) = true)

theorem identity15665 : scanCanonicalize (H12AffineFastState.compose env15665 (packedSelected [7] rootPS)) = affineNative (2^(7+1) ^^^ 140) := by decide +kernel

theorem selectedBound15665 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env15666 : List Nat := [2,4,8,16,32,16,128,140,136,1024,2048,1045,8192,1044,8321,8,1181,8320,1024,8320,1044,0,153,8192,8328,153,8200,1045,1181,10243,1160,8226,140,136,1181,136]

theorem envBound15666 : H12AffineFastState.Bounded env15666 := by
  intro p hp
  have h : env15666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15665_15666 : H12AffineEnvironment.transform 7 140 env15665 = env15666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 140 env15665 == env15666) = true)

theorem identity15666 : scanCanonicalize (H12AffineFastState.compose env15666 (packedSelected [1,2,3,4,5,9] rootPS)) = affineNative (2^(12+1) ^^^ 2209) := by decide +kernel

theorem selectedBound15666 : packedSelected [1,2,3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env15667 : List Nat := [2,4,8,16,32,16,128,140,136,1024,2048,1045,2209,1044,2080,8,1181,2081,1024,2081,1044,0,153,2209,2089,153,2217,1045,1181,162,1160,2179,140,136,1181,136]

theorem envBound15667 : H12AffineFastState.Bounded env15667 := by
  intro p hp
  have h : env15667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15666_15667 : H12AffineEnvironment.transform 12 2209 env15666 = env15667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2209 env15666 == env15667) = true)

theorem identity15667 : scanCanonicalize (H12AffineFastState.compose env15667 (packedSelected [1,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound15667 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env15668 : List Nat := [2,4,8,16,32,16,8,4,0,1024,2048,1045,2089,1044,2080,8,1045,2081,1024,2081,1044,0,17,2089,2089,17,2081,1045,1045,42,1024,2059,4,0,1045,0]

theorem envBound15668 : H12AffineFastState.Bounded env15668 := by
  intro p hp
  have h : env15668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15667_15668 : H12AffineEnvironment.transform 6 8 env15667 = env15668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env15667 == env15668) = true)

theorem identity15668 : scanCanonicalize (H12AffineFastState.compose env15668 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1087) := by decide +kernel

theorem selectedBound15668 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15669 : List Nat := [2,4,8,16,32,16,8,4,0,1024,1087,1045,1046,1044,1055,8,1045,1054,1024,1054,1044,0,17,1046,1046,17,1054,1045,1045,42,1024,1076,4,0,1045,0]

theorem envBound15669 : H12AffineFastState.Bounded env15669 := by
  intro p hp
  have h : env15669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15668_15669 : H12AffineEnvironment.transform 10 1087 env15668 = env15669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1087 env15668 == env15669) = true)

theorem identity15669 : scanCanonicalize (H12AffineFastState.compose env15669 (packedSelected [4] rootPS)) = affineNative (2^(9+1) ^^^ 30) := by decide +kernel

theorem selectedBound15669 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env15670 : List Nat := [2,4,8,16,32,16,8,4,0,30,33,11,8,10,1,8,11,0,30,0,10,0,17,8,8,17,0,11,11,42,30,42,4,0,11,0]

theorem envBound15670 : H12AffineFastState.Bounded env15670 := by
  intro p hp
  have h : env15670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15669_15670 : H12AffineEnvironment.transform 9 30 env15669 = env15670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 30 env15669 == env15670) = true)

theorem identity15670 : scanCanonicalize (H12AffineFastState.compose env15670 (packedSelected [8] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound15670 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env15671 : List Nat := [2,4,3,16,32,16,3,4,0,21,33,0,3,1,1,3,0,0,21,0,1,0,17,3,3,17,0,0,0,33,21,33,4,0,0,0]

theorem envBound15671 : H12AffineFastState.Bounded env15671 := by
  intro p hp
  have h : env15671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15670_15671 : H12AffineEnvironment.transform 2 3 env15670 = env15671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env15670 == env15671) = true)

def env15672 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,4096,8192,4097,32768,65536,1297,262144,1024,32769,4097,4194304,5376,16777216,8328,5376,4456708,4096,1297,1073741824,16876545,1094789541,256,1073817871,16876564,137]

theorem envBound15672 : H12AffineFastState.Bounded env15672 := by
  intro p hp
  have h : env15672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15622_15672 : H12AffineEnvironment.transform 8 137 env15622 = env15672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env15622 == env15672) = true)

theorem identity15672 : scanCanonicalize (H12AffineFastState.compose env15672 (packedSelected [1,3,8,10,12,13,17,28,38] rootPS)) = affineNative (2^(29+1) ^^^ 16779267) := by decide +kernel

theorem selectedBound15672 : packedSelected [1,3,8,10,12,13,17,28,38] rootPS < 2^1333 := by decide +kernel

def env15673 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,4096,8192,4097,32768,65536,1297,262144,1024,32769,4097,4194304,5376,16777216,8328,5376,4456708,4096,1297,16779267,16876545,4268454,256,16851212,16876564,137]

theorem envBound15673 : H12AffineFastState.Bounded env15673 := by
  intro p hp
  have h : env15673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15672_15673 : H12AffineEnvironment.transform 29 16779267 env15672 = env15673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 16779267 env15672 == env15673) = true)

def env15674 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,4096,8192,4097,32768,65536,1297,13592,1024,32769,4097,4194304,5376,16777216,8328,5376,4207644,4096,1297,16779267,16876545,4268454,256,16851212,16876564,137]

theorem envBound15674 : H12AffineFastState.Bounded env15674 := by
  intro p hp
  have h : env15674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15673_15674 : H12AffineEnvironment.transform 17 13592 env15673 = env15674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 13592 env15673 == env15674) = true)

theorem identity15674 : scanCanonicalize (H12AffineFastState.compose env15674 (packedSelected [3,5,24] rootPS)) = affineNative (2^(15+1) ^^^ 41357) := by decide +kernel

theorem selectedBound15674 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env15675 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,4096,8192,4097,32768,41357,1297,13592,1024,32769,4097,4194304,5376,16777216,8328,5376,4207644,4096,1297,16779267,16786828,4227115,256,16810113,16786841,137]

theorem envBound15675 : H12AffineFastState.Bounded env15675 := by
  intro p hp
  have h : env15675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15674_15675 : H12AffineEnvironment.transform 15 41357 env15674 = env15675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41357 env15674 == env15675) = true)

def env15676 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,4096,8192,4097,32768,41357,1297,13592,1024,32769,4097,4194304,5376,8328,8328,5376,4207644,4096,1297,10379,1284,4227115,256,40969,1297,137]

theorem envBound15676 : H12AffineFastState.Bounded env15676 := by
  intro p hp
  have h : env15676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15675_15676 : H12AffineEnvironment.transform 23 8328 env15675 = env15676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8328 env15675 == env15676) = true)

theorem identity15676 : scanCanonicalize (H12AffineFastState.compose env15676 (packedSelected [1,12,13] rootPS)) = affineNative (2^(21+1) ^^^ 41089) := by decide +kernel

theorem selectedBound15676 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env15677 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,4096,8192,4097,32768,41357,1297,13592,1024,32769,4097,41089,5376,8328,8328,5376,38045,4096,1297,10379,1284,8362,256,40969,1297,137]

theorem envBound15677 : H12AffineFastState.Bounded env15677 := by
  intro p hp
  have h : env15677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15676_15677 : H12AffineEnvironment.transform 21 41089 env15676 = env15677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env15676 == env15677) = true)

theorem identity15677 : scanCanonicalize (H12AffineFastState.compose env15677 (packedSelected [1,5,8,12,17] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound15677 : packedSelected [1,5,8,12,17] rootPS < 2^1333 := by decide +kernel

def env15678 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,4096,8192,4097,8461,128,1297,13592,1024,8460,4097,396,5376,8328,8328,5376,13712,4096,1297,10379,1284,8362,256,260,1297,137]

theorem envBound15678 : H12AffineFastState.Bounded env15678 := by
  intro p hp
  have h : env15678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15677_15678 : H12AffineEnvironment.transform 14 8461 env15677 = env15678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env15677 == env15678) = true)

theorem identity15678 : scanCanonicalize (H12AffineFastState.compose env15678 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 1045) := by decide +kernel

theorem selectedBound15678 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env15679 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1045,8192,1044,8461,128,1297,8461,1024,8460,1044,396,277,8328,8328,277,8581,1045,1297,10379,1284,8362,256,260,1297,137]

theorem envBound15679 : H12AffineFastState.Bounded env15679 := by
  intro p hp
  have h : env15679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15678_15679 : H12AffineEnvironment.transform 11 1045 env15678 = env15679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1045 env15678 == env15679) = true)

theorem identity15679 : scanCanonicalize (H12AffineFastState.compose env15679 (packedSelected [7] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound15679 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env15680 : List Nat := [2,4,8,16,32,16,128,5,137,1024,2048,1045,8192,1044,8200,128,1044,8200,1024,8201,1044,137,16,8328,8328,16,8320,1045,1044,10379,1025,8362,5,1,1044,137]

theorem envBound15680 : H12AffineFastState.Bounded env15680 := by
  intro p hp
  have h : env15680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15679_15680 : H12AffineEnvironment.transform 7 5 env15679 = env15680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env15679 == env15680) = true)

def env15681 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,4096,8192,4097,32768,41357,1297,13592,1024,32769,4097,4194304,5376,8329,8328,5376,4207644,4096,1297,10378,1285,4227115,256,40968,1296,137]

theorem envBound15681 : H12AffineFastState.Bounded env15681 := by
  intro p hp
  have h : env15681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15675_15681 : H12AffineEnvironment.transform 23 8329 env15675 = env15681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8329 env15675 == env15681) = true)

theorem identity15681 : scanCanonicalize (H12AffineFastState.compose env15681 (packedSelected [1,12,13] rootPS)) = affineNative (2^(21+1) ^^^ 7482) := by decide +kernel

theorem selectedBound15681 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env15682 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,4096,8192,4097,32768,41357,1297,13592,1024,32769,4097,7482,5376,8329,8328,5376,10534,4096,1297,10378,1285,40209,256,40968,1296,137]

theorem envBound15682 : H12AffineFastState.Bounded env15682 := by
  intro p hp
  have h : env15682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15681_15682 : H12AffineEnvironment.transform 21 7482 env15681 = env15682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 7482 env15681 == env15682) = true)

theorem identity15682 : scanCanonicalize (H12AffineFastState.compose env15682 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 2208) := by decide +kernel

theorem selectedBound15682 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env15683 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,4096,2208,4097,32768,35117,1297,7608,1024,32769,4097,7482,5376,2089,2088,5376,390,4096,1297,42,1285,40209,256,34984,1296,137]

theorem envBound15683 : H12AffineFastState.Bounded env15683 := by
  intro p hp
  have h : env15683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15682_15683 : H12AffineEnvironment.transform 12 2208 env15682 = env15683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2208 env15682 == env15683) = true)

theorem identity15683 : scanCanonicalize (H12AffineFastState.compose env15683 (packedSelected [1,5,8,12,17] rootPS)) = affineNative (2^(14+1) ^^^ 5522) := by decide +kernel

theorem selectedBound15683 : packedSelected [1,5,8,12,17] rootPS < 2^1333 := by decide +kernel

def env15684 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,4096,2208,4097,5522,7359,1297,7608,1024,5523,4097,7482,5376,2089,2088,5376,390,4096,1297,42,1285,2179,256,7482,1296,137]

theorem envBound15684 : H12AffineFastState.Bounded env15684 := by
  intro p hp
  have h : env15684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15683_15684 : H12AffineEnvironment.transform 14 5522 env15683 = env15684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 5522 env15683 == env15684) = true)

theorem identity15684 : scanCanonicalize (H12AffineFastState.compose env15684 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 3135) := by decide +kernel

theorem selectedBound15684 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env15685 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,3135,2208,3134,2477,128,1297,391,1024,2476,3134,261,2367,2089,2088,2367,390,3135,1297,42,1285,2179,256,261,1296,137]

theorem envBound15685 : H12AffineFastState.Bounded env15685 := by
  intro p hp
  have h : env15685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15684_15685 : H12AffineEnvironment.transform 11 3135 env15684 = env15685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3135 env15684 == env15685) = true)

def env15686 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,4096,8192,4097,32768,65536,1297,13593,1024,32769,4097,4194304,5376,16777216,8328,5376,4207645,4096,1297,16779267,16876545,4268454,256,16851212,16876564,137]

theorem envBound15686 : H12AffineFastState.Bounded env15686 := by
  intro p hp
  have h : env15686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15673_15686 : H12AffineEnvironment.transform 17 13593 env15673 = env15686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 13593 env15673 == env15686) = true)

theorem identity15686 : scanCanonicalize (H12AffineFastState.compose env15686 (packedSelected [3,5,24] rootPS)) = affineNative (2^(23+1) ^^^ 8329) := by decide +kernel

theorem selectedBound15686 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env15687 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,4096,8192,4097,32768,65536,1297,13593,1024,32769,4097,4194304,5376,8329,8328,5376,4207645,4096,1297,10378,107656,4268454,256,65925,107677,137]

theorem envBound15687 : H12AffineFastState.Bounded env15687 := by
  intro p hp
  have h : env15687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15686_15687 : H12AffineEnvironment.transform 23 8329 env15686 = env15687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8329 env15686 == env15687) = true)

def env15688 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,4096,8192,4097,32768,46488,1297,13593,1024,32769,4097,4194304,5376,8329,8328,5376,4207645,4096,1297,10378,4368,4232254,256,46109,4357,137]

theorem envBound15688 : H12AffineFastState.Bounded env15688 := by
  intro p hp
  have h : env15688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15687_15688 : H12AffineEnvironment.transform 15 46488 env15687 = env15688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 46488 env15687 == env15688) = true)

theorem identity15688 : scanCanonicalize (H12AffineFastState.compose env15688 (packedSelected [1,8,28] rootPS)) = affineNative (2^(21+1) ^^^ 396) := by decide +kernel

theorem selectedBound15688 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env15689 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,4096,8192,4097,32768,46488,1297,13593,1024,32769,4097,396,5376,8329,8328,5376,13713,4096,1297,10378,4368,38322,256,46109,4357,137]

theorem envBound15689 : H12AffineFastState.Bounded env15689 := by
  intro p hp
  have h : env15689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15688_15689 : H12AffineEnvironment.transform 21 396 env15688 = env15689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 396 env15688 == env15689) = true)

theorem identity15689 : scanCanonicalize (H12AffineFastState.compose env15689 (packedSelected [3,6,7,15,17] rootPS)) = affineNative (2^(14+1) ^^^ 8200) := by decide +kernel

theorem selectedBound15689 : packedSelected [3,6,7,15,17] rootPS < 2^1333 := by decide +kernel

def env15690 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,4096,8192,4097,8200,5520,1297,13593,1024,8201,4097,396,5376,8329,8328,5376,13713,4096,1297,10378,4368,13754,256,5141,4357,137]

theorem envBound15690 : H12AffineFastState.Bounded env15690 := by
  intro p hp
  have h : env15690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15689_15690 : H12AffineEnvironment.transform 14 8200 env15689 = env15690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8200 env15689 == env15690) = true)

def env15691 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,16,8192,17,8200,1408,1297,9481,1024,8201,17,396,1296,8329,8328,1296,9601,16,1297,10378,256,9642,256,1029,277,137]

theorem envBound15691 : H12AffineFastState.Bounded env15691 := by
  intro p hp
  have h : env15691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15690_15691 : H12AffineEnvironment.transform 11 16 env15690 = env15691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env15690 == env15691) = true)

theorem identity15691 : scanCanonicalize (H12AffineFastState.compose env15691 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 256) := by decide +kernel

theorem selectedBound15691 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env15692 : List Nat := [2,4,8,16,32,16,128,256,137,256,2048,16,8192,17,8200,128,17,8201,256,8201,17,396,16,8329,8328,16,8321,16,17,10378,256,8362,256,261,277,137]

theorem envBound15692 : H12AffineFastState.Bounded env15692 := by
  intro p hp
  have h : env15692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15691_15692 : H12AffineEnvironment.transform 9 256 env15691 = env15692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env15691 == env15692) = true)

def env15693 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,17,8192,16,8200,1409,1297,9480,1024,8201,16,396,1297,8329,8328,1297,9600,17,1297,10378,257,9643,256,1028,276,137]

theorem envBound15693 : H12AffineFastState.Bounded env15693 := by
  intro p hp
  have h : env15693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15690_15693 : H12AffineEnvironment.transform 11 17 env15690 = env15693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env15690 == env15693) = true)

theorem identity15693 : scanCanonicalize (H12AffineFastState.compose env15693 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound15693 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env15694 : List Nat := [2,4,8,16,32,16,128,4,137,1024,2048,17,8192,16,8200,1157,1045,9228,1024,8201,16,136,1045,8329,8328,1045,9348,17,1045,10378,5,9391,4,1028,16,137]

theorem envBound15694 : H12AffineFastState.Bounded env15694 := by
  intro p hp
  have h : env15694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15693_15694 : H12AffineEnvironment.transform 7 4 env15693 = env15694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env15693 == env15694) = true)

def env15695 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,4096,8192,4097,32768,46489,1297,13593,1024,32769,4097,4194304,5376,8329,8328,5376,4207645,4096,1297,10378,4369,4232255,256,46108,4356,137]

theorem envBound15695 : H12AffineFastState.Bounded env15695 := by
  intro p hp
  have h : env15695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15687_15695 : H12AffineEnvironment.transform 15 46489 env15687 = env15695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 46489 env15687 == env15695) = true)

theorem identity15695 : scanCanonicalize (H12AffineFastState.compose env15695 (packedSelected [1,8,28] rootPS)) = affineNative (2^(21+1) ^^^ 5529) := by decide +kernel

theorem selectedBound15695 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env15696 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,4096,8192,4097,32768,46489,1297,13593,1024,32769,4097,5529,5376,8329,8328,5376,8580,4096,1297,10378,4369,33190,256,46108,4356,137]

theorem envBound15696 : H12AffineFastState.Bounded env15696 := by
  intro p hp
  have h : env15696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15695_15696 : H12AffineEnvironment.transform 21 5529 env15695 = env15696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 5529 env15695 == env15696) = true)

def env15697 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,4096,4120,4097,32768,34177,1297,1281,1024,32769,4097,5529,5376,4241,4240,5376,4508,4096,1297,6290,4369,33190,256,33796,4356,137]

theorem envBound15697 : H12AffineFastState.Bounded env15697 := by
  intro p hp
  have h : env15697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15696_15697 : H12AffineEnvironment.transform 12 4120 env15696 = env15697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4120 env15696 == env15697) = true)

theorem identity15697 : scanCanonicalize (H12AffineFastState.compose env15697 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 4373) := by decide +kernel

theorem selectedBound15697 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env15698 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,4096,4120,4097,4373,5268,1297,1281,1024,4372,4097,5529,5376,4241,4240,5376,4508,4096,1297,6290,4369,4275,256,5393,4356,137]

theorem envBound15698 : H12AffineFastState.Bounded env15698 := by
  intro p hp
  have h : env15698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15697_15698 : H12AffineEnvironment.transform 14 4373 env15697 = env15698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 4373 env15697 == env15698) = true)

theorem identity15698 : scanCanonicalize (H12AffineFastState.compose env15698 (packedSelected [2,7,10,15,23,32] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound15698 : packedSelected [2,7,10,15,23,32] rootPS < 2^1333 := by decide +kernel

def env15699 : List Nat := [2,4,8,16,32,16,9,256,0,1024,2048,4096,4120,4097,4373,5149,1297,1281,1024,4372,4097,5392,5376,4120,4121,5376,4373,4096,1297,6171,4369,4154,256,5393,4356,0]

theorem envBound15699 : H12AffineFastState.Bounded env15699 := by
  intro p hp
  have h : env15699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15698_15699 : H12AffineEnvironment.transform 6 9 env15698 = env15699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env15698 == env15699) = true)

theorem identity15699 : scanCanonicalize (H12AffineFastState.compose env15699 (packedSelected [1,2,4,7,9,10,12,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 2096) := by decide +kernel

theorem selectedBound15699 : packedSelected [1,2,4,7,9,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env15700 : List Nat := [2,4,8,16,32,16,9,256,0,1024,2048,2096,2088,2097,2341,3117,1297,1281,1024,2340,2097,3360,3376,2088,2089,3376,2341,2096,1297,43,2337,2058,256,3361,2356,0]

theorem envBound15700 : H12AffineFastState.Bounded env15700 := by
  intro p hp
  have h : env15700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15699_15700 : H12AffineEnvironment.transform 11 2096 env15699 = env15700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2096 env15699 == env15700) = true)

theorem identity15700 : scanCanonicalize (H12AffineFastState.compose env15700 (packedSelected [3,4,8] rootPS)) = affineNative (2^(9+1) ^^^ 267) := by decide +kernel

theorem selectedBound15700 : packedSelected [3,4,8] rootPS < 2^1333 := by decide +kernel

def env15701 : List Nat := [2,4,8,16,32,16,9,256,0,267,2048,2096,2088,2097,2341,2342,26,10,267,2340,2097,2091,2107,2088,2089,2107,2341,2096,26,43,2337,2058,256,2090,2356,0]

theorem envBound15701 : H12AffineFastState.Bounded env15701 := by
  intro p hp
  have h : env15701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15700_15701 : H12AffineEnvironment.transform 9 267 env15700 = env15701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 267 env15700 == env15701) = true)

theorem identity15701 : scanCanonicalize (H12AffineFastState.compose env15701 (packedSelected [1,4,7] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound15701 : packedSelected [1,4,7] rootPS < 2^1333 := by decide +kernel

def env15702 : List Nat := [2,4,8,16,32,16,9,4,0,15,2048,2096,2088,2097,2081,2082,26,10,15,2080,2097,2091,2107,2088,2089,2107,2081,2096,26,43,2085,2058,4,2090,2096,0]

theorem envBound15702 : H12AffineFastState.Bounded env15702 := by
  intro p hp
  have h : env15702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15701_15702 : H12AffineEnvironment.transform 7 4 env15701 = env15702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env15701 == env15702) = true)

theorem identity15702 : scanCanonicalize (H12AffineFastState.compose env15702 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound15702 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env15703 : List Nat := [2,4,8,16,1,16,9,4,0,15,2048,2065,2057,2064,2048,2051,26,10,15,2049,2064,2058,2074,2057,2056,2074,2048,2065,26,10,2052,2058,4,2059,2065,0]

theorem envBound15703 : H12AffineFastState.Bounded env15703 := by
  intro p hp
  have h : env15703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15702_15703 : H12AffineEnvironment.transform 4 1 env15702 = env15703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env15702 == env15703) = true)

theorem identity15703 : scanCanonicalize (H12AffineFastState.compose env15703 (packedSelected [0,1,2] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound15703 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env15704 : List Nat := [2,4,8,16,1,16,9,4,0,15,10,27,3,26,10,9,26,10,15,11,26,0,16,3,2,16,10,27,26,10,14,0,4,1,27,0]

theorem envBound15704 : H12AffineFastState.Bounded env15704 := by
  intro p hp
  have h : env15704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15703_15704 : H12AffineEnvironment.transform 10 10 env15703 = env15704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env15703 == env15704) = true)

theorem identity15704 : scanCanonicalize (H12AffineFastState.compose env15704 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound15704 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15705 : List Nat := [2,4,8,10,1,10,9,4,0,15,10,1,3,0,10,9,0,10,15,11,0,0,10,3,2,10,10,1,0,10,14,0,4,1,1,0]

theorem envBound15705 : H12AffineFastState.Bounded env15705 := by
  intro p hp
  have h : env15705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15704_15705 : H12AffineEnvironment.transform 3 10 env15704 = env15705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env15704 == env15705) = true)

theorem identity15705 : scanCanonicalize (H12AffineFastState.compose env15705 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound15705 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15706 : List Nat := [2,4,3,1,1,1,2,4,0,4,1,1,3,0,1,2,0,1,4,0,0,0,1,3,2,1,1,1,0,1,5,0,4,1,1,0]

theorem envBound15706 : H12AffineFastState.Bounded env15706 := by
  intro p hp
  have h : env15706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15705_15706 : H12AffineEnvironment.transform 2 3 env15705 = env15706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env15705 == env15706) = true)

def env15707 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,4096,4121,4097,32768,34176,1297,1280,1024,32769,4097,5529,5376,4240,4241,5376,4509,4096,1297,6291,4369,33190,256,33797,4356,137]

theorem envBound15707 : H12AffineFastState.Bounded env15707 := by
  intro p hp
  have h : env15707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15696_15707 : H12AffineEnvironment.transform 12 4121 env15696 = env15707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4121 env15696 == env15707) = true)

theorem identity15707 : scanCanonicalize (H12AffineFastState.compose env15707 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 1281) := by decide +kernel

theorem selectedBound15707 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env15708 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,4096,4121,4097,1281,129,1297,1280,1024,1280,4097,5529,5376,4240,4241,5376,4509,4096,1297,6291,4369,1191,256,260,4356,137]

theorem envBound15708 : H12AffineFastState.Bounded env15708 := by
  intro p hp
  have h : env15708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15707_15708 : H12AffineEnvironment.transform 14 1281 env15707 = env15708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1281 env15707 == env15708) = true)

theorem identity15708 : scanCanonicalize (H12AffineFastState.compose env15708 (packedSelected [2,3,5,7,15,23,32] rootPS)) = affineNative (2^(11+1) ^^^ 1181) := by decide +kernel

theorem selectedBound15708 : packedSelected [2,3,5,7,15,23,32] rootPS < 2^1333 := by decide +kernel

def env15709 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1181,1156,1180,1281,129,1297,1280,1024,1280,1180,260,413,1037,1036,413,1280,1181,1297,3086,1420,1191,256,260,1433,137]

theorem envBound15709 : H12AffineFastState.Bounded env15709 := by
  intro p hp
  have h : env15709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15708_15709 : H12AffineEnvironment.transform 11 1181 env15708 = env15709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1181 env15708 == env15709) = true)

theorem identity15709 : scanCanonicalize (H12AffineFastState.compose env15709 (packedSelected [1,2,4,7,8,9,12] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound15709 : packedSelected [1,2,4,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env15710 : List Nat := [2,4,8,16,32,16,8,256,1,1024,2048,1045,1036,1044,1281,9,1297,1280,1024,1280,1044,260,277,1037,1036,277,1280,1045,1297,3086,1284,1071,256,260,1297,1]

theorem envBound15710 : H12AffineFastState.Bounded env15710 := by
  intro p hp
  have h : env15710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15709_15710 : H12AffineEnvironment.transform 6 8 env15709 = env15710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env15709 == env15710) = true)

theorem identity15710 : scanCanonicalize (H12AffineFastState.compose env15710 (packedSelected [7] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound15710 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env15711 : List Nat := [2,4,8,16,32,16,8,4,1,1024,2048,1045,1036,1044,1029,9,1045,1028,1024,1028,1044,0,17,1037,1036,17,1028,1045,1045,3086,1024,1071,4,0,1045,1]

theorem envBound15711 : H12AffineFastState.Bounded env15711 := by
  intro p hp
  have h : env15711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15710_15711 : H12AffineEnvironment.transform 7 4 env15710 = env15711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env15710 == env15711) = true)

theorem identity15711 : scanCanonicalize (H12AffineFastState.compose env15711 (packedSelected [1,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 1061) := by decide +kernel

theorem selectedBound15711 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env15712 : List Nat := [2,4,8,16,32,16,8,4,1,1024,1061,1045,1036,1044,1029,9,1045,1028,1024,1028,1044,0,17,1037,1036,17,1028,1045,1045,43,1024,1071,4,0,1045,1]

theorem envBound15712 : H12AffineFastState.Bounded env15712 := by
  intro p hp
  have h : env15712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15711_15712 : H12AffineEnvironment.transform 10 1061 env15711 = env15712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1061 env15711 == env15712) = true)

theorem identity15712 : scanCanonicalize (H12AffineFastState.compose env15712 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound15712 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15713 : List Nat := [2,4,8,11,32,11,8,4,1,1024,1061,1038,1036,1039,1029,9,1038,1028,1024,1028,1039,0,10,1037,1036,10,1028,1038,1038,43,1024,1071,4,0,1038,1]

theorem envBound15713 : H12AffineFastState.Bounded env15713 := by
  intro p hp
  have h : env15713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15712_15713 : H12AffineEnvironment.transform 3 11 env15712 = env15713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env15712 == env15713) = true)

theorem identity15713 : scanCanonicalize (H12AffineFastState.compose env15713 (packedSelected [4] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound15713 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env15714 : List Nat := [2,4,8,11,32,11,8,4,1,5,32,11,9,10,0,9,11,1,5,1,10,0,10,8,9,10,1,11,11,43,5,42,4,0,11,1]

theorem envBound15714 : H12AffineFastState.Bounded env15714 := by
  intro p hp
  have h : env15714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15713_15714 : H12AffineEnvironment.transform 9 5 env15713 = env15714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env15713 == env15714) = true)

theorem identity15714 : scanCanonicalize (H12AffineFastState.compose env15714 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound15714 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15715 : List Nat := [2,4,2,1,32,1,2,4,1,5,32,1,3,0,0,3,1,1,5,1,0,0,0,2,3,0,1,1,1,33,5,32,4,0,1,1]

theorem envBound15715 : H12AffineFastState.Bounded env15715 := by
  intro p hp
  have h : env15715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15714_15715 : H12AffineEnvironment.transform 2 2 env15714 = env15715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env15714 == env15715) = true)

theorem identity15715 : scanCanonicalize (H12AffineFastState.compose env15715 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound15715 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15716 : List Nat := [2,4,2,1,0,1,2,4,1,5,0,1,3,0,0,3,1,1,5,1,0,0,0,2,3,0,1,1,1,1,5,0,4,0,1,1]

theorem envBound15716 : H12AffineFastState.Bounded env15716 := by
  intro p hp
  have h : env15716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15715_15716 : H12AffineEnvironment.transform 4 0 env15715 = env15716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15715 == env15716) = true)

def env15717 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,8914000,134217728,8519745,2769921,1073741824,27513921,4294967296,10637632,4315938986,164610305,512]

theorem envBound15717 : H12AffineFastState.Bounded env15717 := by
  intro p hp
  have h : env15717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15272_15717 : H12AffineEnvironment.transform 28 2769921 env15272 = env15717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 28 2769921 env15272 == env15717) = true)

def env15718 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,4194304,8388608,16777216,8328,8914000,134217728,8519745,676865,1073741824,25412673,4294967296,8536384,4315938986,164610305,512]

theorem envBound15718 : H12AffineFastState.Bounded env15718 := by
  intro p hp
  have h : env15718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15717_15718 : H12AffineEnvironment.transform 20 4096 env15717 = env15718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env15717 == env15718) = true)

theorem identity15718 : scanCanonicalize (H12AffineFastState.compose env15718 (packedSelected [14] rootPS)) = affineNative (2^(23+1) ^^^ 9015381) := by decide +kernel

theorem selectedBound15718 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env15719 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,4194304,8388608,9015381,8328,8914000,134217728,8519745,676865,1073741824,676884,4294967296,8536384,4308177151,138826068,512]

theorem envBound15719 : H12AffineFastState.Bounded env15719 := by
  intro p hp
  have h : env15719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15718_15719 : H12AffineEnvironment.transform 23 9015381 env15718 = env15719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 9015381 env15718 == env15719) = true)

def env15720 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,524288,32769,4096,4194304,8388608,9015381,8328,8914000,134217728,8389889,545089,1073741824,545108,4294967296,8406016,4308177151,138695700,512]

theorem envBound15720 : H12AffineFastState.Bounded env15720 := by
  intro p hp
  have h : env15720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15719_15720 : H12AffineEnvironment.transform 16 1344 env15719 = env15720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env15719 == env15720) = true)

def env15721 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,524288,32769,4096,4194304,17664,644437,8328,541008,134217728,16385,545089,1073741824,545108,4294967296,256,4299806207,138695700,512]

theorem envBound15721 : H12AffineFastState.Bounded env15721 := by
  intro p hp
  have h : env15721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15720_15721 : H12AffineEnvironment.transform 22 17664 env15720 = env15721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17664 env15720 == env15721) = true)

theorem identity15721 : scanCanonicalize (H12AffineFastState.compose env15721 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(26+1) ^^^ 4982020) := by decide +kernel

theorem selectedBound15721 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env15722 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,524288,32769,4096,4194304,17664,644437,8328,541008,4982020,16385,545089,1073741824,545108,4294967296,256,4299806207,545040,512]

theorem envBound15722 : H12AffineFastState.Bounded env15722 := by
  intro p hp
  have h : env15722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15721_15722 : H12AffineEnvironment.transform 26 4982020 env15721 = env15722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 4982020 env15721 == env15722) = true)

theorem identity15722 : scanCanonicalize (H12AffineFastState.compose env15722 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(18+1) ^^^ 1024) := by decide +kernel

theorem selectedBound15722 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env15723 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,1024,32769,4096,4194304,17664,119125,8328,17744,4456708,16385,21825,1073741824,21844,4294967296,256,4299280895,21776,512]

theorem envBound15723 : H12AffineFastState.Bounded env15723 := by
  intro p hp
  have h : env15723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15722_15723 : H12AffineEnvironment.transform 18 1024 env15722 = env15723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env15722 == env15723) = true)

def env15724 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,65536,1344,262144,1024,32769,4096,4194304,64,103445,8328,16,4456708,1345,4097,1073741824,4116,4294967296,256,4299265215,4176,512]

theorem envBound15724 : H12AffineFastState.Bounded env15724 := by
  intro p hp
  have h : env15724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15723_15724 : H12AffineEnvironment.transform 13 1344 env15723 = env15724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env15723 == env15724) = true)

theorem identity15724 : scanCanonicalize (H12AffineFastState.compose env15724 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound15724 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env15725 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,1296,32768,65536,1296,262144,1024,32769,4096,4194304,16,103445,8328,16,4456708,1297,4097,1073741824,4116,4294967296,256,4299265215,4096,512]

theorem envBound15725 : H12AffineFastState.Bounded env15725 := by
  intro p hp
  have h : env15725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15724_15725 : H12AffineEnvironment.transform 5 16 env15724 = env15725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env15724 == env15725) = true)

def env15726 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,65536,1344,262144,1024,32769,4096,4194304,65,103444,8328,17,4456708,1344,4096,1073741824,4117,4294967296,256,4299265214,4177,512]

theorem envBound15726 : H12AffineFastState.Bounded env15726 := by
  intro p hp
  have h : env15726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15723_15726 : H12AffineEnvironment.transform 13 1345 env15723 = env15726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env15723 == env15726) = true)

theorem identity15726 : scanCanonicalize (H12AffineFastState.compose env15726 (packedSelected [0,7,20] rootPS)) = affineNative (2^(11+1) ^^^ 1344) := by decide +kernel

theorem selectedBound15726 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env15727 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,32768,65536,1344,262144,1024,32769,1344,4194304,65,98644,8328,17,4456708,1344,1344,1073741824,1365,4294967296,256,4299260414,1297,512]

theorem envBound15727 : H12AffineFastState.Bounded env15727 := by
  intro p hp
  have h : env15727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15726_15727 : H12AffineEnvironment.transform 11 1344 env15726 = env15727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env15726 == env15727) = true)

theorem identity15727 : scanCanonicalize (H12AffineFastState.compose env15727 (packedSelected [17,21] rootPS)) = affineNative (2^(15+1) ^^^ 33246) := by decide +kernel

theorem selectedBound15727 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env15728 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,32768,33246,1344,262144,1024,32769,1344,4194304,65,138,8328,17,4456708,1344,1344,1073741824,1365,4294967296,256,4299161632,1297,512]

theorem envBound15728 : H12AffineFastState.Bounded env15728 := by
  intro p hp
  have h : env15728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15727_15728 : H12AffineEnvironment.transform 15 33246 env15727 = env15728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33246 env15727 == env15728) = true)

theorem identity15728 : scanCanonicalize (H12AffineFastState.compose env15728 (packedSelected [1,5,10,13,15,17,24,28,38] rootPS)) = affineNative (2^(31+1) ^^^ 1074045428) := by decide +kernel

theorem selectedBound15728 : packedSelected [1,5,10,13,15,17,24,28,38] rootPS < 2^1333 := by decide +kernel

def env15729 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,32768,33246,1344,262144,1024,32769,1344,4194304,65,138,8328,17,4456708,1344,1344,1073741824,1365,1074045428,256,1078239700,1297,512]

theorem envBound15729 : H12AffineFastState.Bounded env15729 := by
  intro p hp
  have h : env15729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15728_15729 : H12AffineEnvironment.transform 31 1074045428 env15728 = env15729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1074045428 env15728 == env15729) = true)

theorem identity15729 : scanCanonicalize (H12AffineFastState.compose env15729 (packedSelected [1,5,10,24,28] rootPS)) = affineNative (2^(17+1) ^^^ 43128) := by decide +kernel

theorem selectedBound15729 : packedSelected [1,5,10,24,28] rootPS < 2^1333 := by decide +kernel

def env15730 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,32768,33246,1344,43128,1024,32769,1344,4194304,65,138,8328,17,4237692,1344,1344,1073741824,1365,1073744268,256,1077938604,1297,512]

theorem envBound15730 : H12AffineFastState.Bounded env15730 := by
  intro p hp
  have h : env15730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15729_15730 : H12AffineEnvironment.transform 17 43128 env15729 = env15730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43128 env15729 == env15730) = true)

theorem identity15730 : scanCanonicalize (H12AffineFastState.compose env15730 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(14+1) ^^^ 2421) := by decide +kernel

theorem selectedBound15730 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env15731 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,2421,2219,1344,8461,1024,2420,1344,4194304,65,138,8328,17,4202505,1344,1344,1073741824,1365,1073744268,256,1077938604,1297,512]

theorem envBound15731 : H12AffineFastState.Bounded env15731 := by
  intro p hp
  have h : env15731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15730_15731 : H12AffineEnvironment.transform 14 2421 env15730 = env15731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2421 env15730 == env15731) = true)

theorem identity15731 : scanCanonicalize (H12AffineFastState.compose env15731 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 8460) := by decide +kernel

theorem selectedBound15731 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env15732 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,2421,2219,1344,8461,1024,2420,1344,4194304,65,138,8328,17,4202505,1344,1344,8460,1365,10368,256,4204704,1297,512]

theorem envBound15732 : H12AffineFastState.Bounded env15732 := by
  intro p hp
  have h : env15732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15731_15732 : H12AffineEnvironment.transform 29 8460 env15731 = env15732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 8460 env15731 == env15732) = true)

theorem identity15732 : scanCanonicalize (H12AffineFastState.compose env15732 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 3037) := by decide +kernel

theorem selectedBound15732 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env15733 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,2421,2219,1344,8461,1024,2420,1344,3037,65,138,8328,17,11220,1344,1344,8460,1365,10368,256,9085,1297,512]

theorem envBound15733 : H12AffineFastState.Bounded env15733 := by
  intro p hp
  have h : env15733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15732_15733 : H12AffineEnvironment.transform 21 3037 env15732 = env15733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 3037 env15732 == env15733) = true)

theorem identity15733 : scanCanonicalize (H12AffineFastState.compose env15733 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 981) := by decide +kernel

theorem selectedBound15733 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env15734 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,981,1345,2421,2219,1344,728,1024,2420,1344,3037,65,138,861,17,2049,1344,1344,729,1365,2901,256,168,1297,512]

theorem envBound15734 : H12AffineFastState.Bounded env15734 := by
  intro p hp
  have h : env15734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15733_15734 : H12AffineEnvironment.transform 12 981 env15733 = env15734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 981 env15733 == env15734) = true)

theorem identity15734 : scanCanonicalize (H12AffineFastState.compose env15734 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 217) := by decide +kernel

theorem selectedBound15734 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env15735 : List Nat := [2,4,8,16,32,64,128,256,217,1024,2048,1344,268,1345,2421,2219,1344,1,1024,2420,1344,2308,65,138,388,17,2049,1344,1344,0,1365,2444,256,168,1297,217]

theorem envBound15735 : H12AffineFastState.Bounded env15735 := by
  intro p hp
  have h : env15735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15734_15735 : H12AffineEnvironment.transform 8 217 env15734 = env15735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env15734 == env15735) = true)

theorem identity15735 : scanCanonicalize (H12AffineFastState.compose env15735 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound15735 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env15736 : List Nat := [2,4,8,16,32,64,128,256,217,1024,1,1344,268,1345,372,170,1344,1,1024,373,1344,261,65,138,388,17,0,1344,1344,0,1365,397,256,168,1297,217]

theorem envBound15736 : H12AffineFastState.Bounded env15736 := by
  intro p hp
  have h : env15736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15735_15736 : H12AffineEnvironment.transform 10 1 env15735 = env15736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env15735 == env15736) = true)

theorem identity15736 : scanCanonicalize (H12AffineFastState.compose env15736 (packedSelected [3,5] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound15736 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env15737 : List Nat := [2,4,8,16,32,64,128,256,217,273,1,81,268,80,372,170,81,1,273,373,81,261,65,138,388,17,0,81,81,0,68,397,256,168,0,217]

theorem envBound15737 : H12AffineFastState.Bounded env15737 := by
  intro p hp
  have h : env15737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15736_15737 : H12AffineEnvironment.transform 9 273 env15736 = env15737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env15736 == env15737) = true)

theorem identity15737 : scanCanonicalize (H12AffineFastState.compose env15737 (packedSelected [1,3,13] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound15737 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env15738 : List Nat := [2,4,8,16,32,64,128,37,217,52,1,81,41,80,81,170,81,1,52,80,81,32,65,138,161,17,0,81,81,0,68,168,37,168,0,217]

theorem envBound15738 : H12AffineFastState.Bounded env15738 := by
  intro p hp
  have h : env15738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15737_15738 : H12AffineEnvironment.transform 7 37 env15737 = env15738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env15737 == env15738) = true)

theorem identity15738 : scanCanonicalize (H12AffineFastState.compose env15738 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound15738 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env15739 : List Nat := [2,4,8,16,32,64,8,37,81,52,1,81,41,80,81,34,81,1,52,80,81,32,65,2,41,17,0,81,81,0,68,32,37,32,0,81]

theorem envBound15739 : H12AffineFastState.Bounded env15739 := by
  intro p hp
  have h : env15739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15738_15739 : H12AffineEnvironment.transform 6 8 env15738 = env15739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env15738 == env15739) = true)

def env15740 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,524288,32769,4096,4194304,17665,644436,8328,541009,134217728,16384,545089,1073741824,545108,4294967296,257,4299806206,138695700,512]

theorem envBound15740 : H12AffineFastState.Bounded env15740 := by
  intro p hp
  have h : env15740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15720_15740 : H12AffineEnvironment.transform 22 17665 env15720 = env15740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17665 env15720 == env15740) = true)

theorem identity15740 : scanCanonicalize (H12AffineFastState.compose env15740 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(26+1) ^^^ 4477269) := by decide +kernel

theorem selectedBound15740 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env15741 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,524288,32769,4096,4194304,17665,644436,8328,541009,4477269,16384,545089,1073741824,545108,4294967296,257,4299806206,1345,512]

theorem envBound15741 : H12AffineFastState.Bounded env15741 := by
  intro p hp
  have h : env15741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15740_15741 : H12AffineEnvironment.transform 26 4477269 env15740 = env15741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 4477269 env15740 == env15741) = true)

theorem identity15741 : scanCanonicalize (H12AffineFastState.compose env15741 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(18+1) ^^^ 1025) := by decide +kernel

theorem selectedBound15741 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env15742 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,1025,32769,4096,4194304,17665,119125,8328,17744,4477269,16384,21824,1073741824,21845,4294967296,257,4299280895,1345,512]

theorem envBound15742 : H12AffineFastState.Bounded env15742 := by
  intro p hp
  have h : env15742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15741_15742 : H12AffineEnvironment.transform 18 1025 env15741 = env15742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env15741 == env15742) = true)

def env15743 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4096,32768,65536,1344,262144,1025,32769,4096,4194304,5377,98645,8328,5456,4456789,4096,1344,1073741824,1365,4294967296,257,4299260415,1345,512]

theorem envBound15743 : H12AffineFastState.Bounded env15743 := by
  intro p hp
  have h : env15743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15742_15743 : H12AffineEnvironment.transform 13 4096 env15742 = env15743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4096 env15742 == env15743) = true)

theorem identity15743 : scanCanonicalize (H12AffineFastState.compose env15743 (packedSelected [0,7,20] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound15743 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env15744 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1296,8192,1296,32768,65536,1344,262144,1025,32769,1296,4194304,17,98645,8328,64,4456789,1296,1344,1073741824,1365,4294967296,257,4299260415,1345,512]

theorem envBound15744 : H12AffineFastState.Bounded env15744 := by
  intro p hp
  have h : env15744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15743_15744 : H12AffineEnvironment.transform 11 1296 env15743 = env15744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env15743 == env15744) = true)

theorem identity15744 : scanCanonicalize (H12AffineFastState.compose env15744 (packedSelected [13,17] rootPS)) = affineNative (2^(31+1) ^^^ 1077979296) := by decide +kernel

theorem selectedBound15744 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env15745 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1296,8192,1296,32768,65536,1344,262144,1025,32769,1296,4194304,17,98645,8328,64,4456789,1296,1344,1073741824,1365,1077979296,257,1073817951,1345,512]

theorem envBound15745 : H12AffineFastState.Bounded env15745 := by
  intro p hp
  have h : env15745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15744_15745 : H12AffineEnvironment.transform 31 1077979296 env15744 = env15745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1077979296 env15744 == env15745) = true)

theorem identity15745 : scanCanonicalize (H12AffineFastState.compose env15745 (packedSelected [13,21] rootPS)) = affineNative (2^(29+1) ^^^ 43128) := by decide +kernel

theorem selectedBound15745 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env15746 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1296,8192,1296,32768,65536,1344,262144,1025,32769,1296,4194304,17,98645,8328,64,4456789,1296,1344,43128,1365,4194520,257,98599,1345,512]

theorem envBound15746 : H12AffineFastState.Bounded env15746 := by
  intro p hp
  have h : env15746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15745_15746 : H12AffineEnvironment.transform 29 43128 env15745 = env15746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 43128 env15745 == env15746) = true)

theorem identity15746 : scanCanonicalize (H12AffineFastState.compose env15746 (packedSelected [1,3,15,24,28,38] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound15746 : packedSelected [1,3,15,24,28,38] rootPS < 2^1333 := by decide +kernel

def env15747 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1296,32768,65536,1297,262144,1025,32769,1296,4194304,17,98564,8328,17,4456708,1296,1297,43049,1284,4194441,257,98599,1296,512]

theorem envBound15747 : H12AffineFastState.Bounded env15747 := by
  intro p hp
  have h : env15747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15746_15747 : H12AffineEnvironment.transform 5 17 env15746 = env15747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env15746 == env15747) = true)

theorem identity15747 : scanCanonicalize (H12AffineFastState.compose env15747 (packedSelected [1,3,5] rootPS)) = affineNative (2^(21+1) ^^^ 328320) := by decide +kernel

theorem selectedBound15747 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env15748 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1296,32768,65536,1297,262144,1025,32769,1296,328320,17,98564,8328,17,66436,1296,1297,43049,1284,328201,257,98599,1296,512]

theorem envBound15748 : H12AffineFastState.Bounded env15748 := by
  intro p hp
  have h : env15748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15747_15748 : H12AffineEnvironment.transform 21 328320 env15747 = env15748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 328320 env15747 == env15748) = true)

theorem identity15748 : scanCanonicalize (H12AffineFastState.compose env15748 (packedSelected [1,3,8] rootPS)) = affineNative (2^(14+1) ^^^ 9093) := by decide +kernel

theorem selectedBound15748 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env15749 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1296,9093,65536,1297,262144,1025,9092,1296,328320,17,74369,8328,17,66436,1296,1297,2988,1284,328201,257,74402,1296,512]

theorem envBound15749 : H12AffineFastState.Bounded env15749 := by
  intro p hp
  have h : env15749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15748_15749 : H12AffineEnvironment.transform 14 9093 env15748 = env15749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9093 env15748 == env15749) = true)

theorem identity15749 : scanCanonicalize (H12AffineFastState.compose env15749 (packedSelected [1,12,13] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound15749 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env15750 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,1296,8192,1296,8460,65536,1297,262144,1025,8461,1296,327689,17,73736,8328,17,65805,1296,1297,2341,1284,327808,257,73771,1296,137]

theorem envBound15750 : H12AffineFastState.Bounded env15750 := by
  intro p hp
  have h : env15750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15749_15750 : H12AffineEnvironment.transform 8 137 env15749 = env15750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env15749 == env15750) = true)

theorem identity15750 : scanCanonicalize (H12AffineFastState.compose env15750 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 8363) := by decide +kernel

theorem selectedBound15750 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env15751 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,1296,8192,1296,8460,65536,1297,8363,1025,8461,1296,73890,17,73736,8328,17,65805,1296,1297,2341,1284,73771,257,73771,1296,137]

theorem envBound15751 : H12AffineFastState.Bounded env15751 := by
  intro p hp
  have h : env15751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15750_15751 : H12AffineEnvironment.transform 17 8363 env15750 = env15751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8363 env15750 == env15751) = true)

theorem identity15751 : scanCanonicalize (H12AffineFastState.compose env15751 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound15751 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env15752 : List Nat := [2,4,8,16,32,17,128,256,137,4,2048,276,8192,276,8460,65536,277,8363,5,8461,276,73890,17,73736,8328,17,65805,276,277,2341,256,73771,257,73771,276,137]

theorem envBound15752 : H12AffineFastState.Bounded env15752 := by
  intro p hp
  have h : env15752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15751_15752 : H12AffineEnvironment.transform 9 4 env15751 = env15752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env15751 == env15752) = true)

theorem identity15752 : scanCanonicalize (H12AffineFastState.compose env15752 (packedSelected [3,12] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound15752 : packedSelected [3,12] rootPS < 2^1333 := by decide +kernel

def env15753 : List Nat := [2,4,8,16,32,17,128,256,137,4,2048,276,269,276,1,65536,277,422,5,0,276,65967,17,65797,389,17,65805,276,277,2341,256,65830,257,65830,276,137]

theorem envBound15753 : H12AffineFastState.Bounded env15753 := by
  intro p hp
  have h : env15753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15752_15753 : H12AffineEnvironment.transform 12 269 env15752 = env15753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env15752 == env15753) = true)

theorem identity15753 : scanCanonicalize (H12AffineFastState.compose env15753 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 155) := by decide +kernel

theorem selectedBound15753 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15754 : List Nat := [2,4,8,16,32,17,128,256,137,4,2048,276,269,276,1,155,277,422,5,0,276,308,17,414,389,17,406,276,277,2341,256,445,257,445,276,137]

theorem envBound15754 : H12AffineFastState.Bounded env15754 := by
  intro p hp
  have h : env15754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15753_15754 : H12AffineEnvironment.transform 15 155 env15753 = env15754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 155 env15753 == env15754) = true)

theorem identity15754 : scanCanonicalize (H12AffineFastState.compose env15754 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound15754 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env15755 : List Nat := [2,4,8,16,32,17,128,21,137,4,2048,1,24,1,1,155,0,179,5,0,1,33,17,139,144,17,131,1,0,2096,21,168,20,168,1,137]

theorem envBound15755 : H12AffineFastState.Bounded env15755 := by
  intro p hp
  have h : env15755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15754_15755 : H12AffineEnvironment.transform 7 21 env15754 = env15755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env15754 == env15755) = true)

theorem identity15755 : scanCanonicalize (H12AffineFastState.compose env15755 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 130) := by decide +kernel

theorem selectedBound15755 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env15756 : List Nat := [2,4,8,16,32,17,128,21,137,4,130,1,24,1,1,155,0,179,5,0,1,33,17,139,144,17,131,1,0,178,21,168,20,168,1,137]

theorem envBound15756 : H12AffineFastState.Bounded env15756 := by
  intro p hp
  have h : env15756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15755_15756 : H12AffineEnvironment.transform 10 130 env15755 = env15756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 130 env15755 == env15756) = true)

def env15757 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4097,32768,65536,1344,262144,1025,32769,4096,4194304,5376,98644,8328,5457,4456788,4097,1345,1073741824,1364,4294967296,257,4299260414,1345,512]

theorem envBound15757 : H12AffineFastState.Bounded env15757 := by
  intro p hp
  have h : env15757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15742_15757 : H12AffineEnvironment.transform 13 4097 env15742 = env15757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4097 env15742 == env15757) = true)

theorem identity15757 : scanCanonicalize (H12AffineFastState.compose env15757 (packedSelected [0,7,20] rootPS)) = affineNative (2^(11+1) ^^^ 1344) := by decide +kernel

theorem selectedBound15757 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env15758 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,32768,65536,1344,262144,1025,32769,1344,4194304,64,98644,8328,17,4456788,1345,1345,1073741824,1364,4294967296,257,4299260414,1345,512]

theorem envBound15758 : H12AffineFastState.Bounded env15758 := by
  intro p hp
  have h : env15758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15757_15758 : H12AffineEnvironment.transform 11 1344 env15757 = env15758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env15757 == env15758) = true)

theorem identity15758 : scanCanonicalize (H12AffineFastState.compose env15758 (packedSelected [12,13,15,17,38,41] rootPS)) = affineNative (2^(31+1) ^^^ 73771) := by decide +kernel

theorem selectedBound15758 : packedSelected [12,13,15,17,38,41] rootPS < 2^1333 := by decide +kernel

def env15759 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,32768,65536,1344,262144,1025,32769,1344,4194304,64,98644,8328,17,4456788,1345,1345,1073741824,1364,73771,257,4235733,1345,512]

theorem envBound15759 : H12AffineFastState.Bounded env15759 := by
  intro p hp
  have h : env15759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15758_15759 : H12AffineEnvironment.transform 31 73771 env15758 = env15759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 73771 env15758 == env15759) = true)

def env15760 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1297,32768,65536,1296,262144,1025,32769,1296,4194304,16,98564,8328,17,4456708,1297,1297,1073741824,1284,73771,257,4235653,1297,512]

theorem envBound15760 : H12AffineFastState.Bounded env15760 := by
  intro p hp
  have h : env15760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15759_15760 : H12AffineEnvironment.transform 5 16 env15759 = env15760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env15759 == env15760) = true)

theorem identity15760 : scanCanonicalize (H12AffineFastState.compose env15760 (packedSelected [1,3,5] rootPS)) = affineNative (2^(29+1) ^^^ 4565024) := by decide +kernel

theorem selectedBound15760 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env15761 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1297,32768,65536,1296,262144,1025,32769,1296,4194304,16,98564,8328,17,4456708,1297,1297,4565024,1284,73771,257,4235653,1297,512]

theorem envBound15761 : H12AffineFastState.Bounded env15761 := by
  intro p hp
  have h : env15761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15760_15761 : H12AffineEnvironment.transform 29 4565024 env15760 = env15761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4565024 env15760 == env15761) = true)

theorem identity15761 : scanCanonicalize (H12AffineFastState.compose env15761 (packedSelected [1,3,8] rootPS)) = affineNative (2^(14+1) ^^^ 9093) := by decide +kernel

theorem selectedBound15761 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env15762 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1297,9093,65536,1296,262144,1025,9092,1296,4194304,16,74369,8328,17,4456708,1297,1297,4524965,1284,73771,257,4194816,1297,512]

theorem envBound15762 : H12AffineFastState.Bounded env15762 := by
  intro p hp
  have h : env15762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15761_15762 : H12AffineEnvironment.transform 14 9093 env15761 = env15762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9093 env15761 == env15762) = true)

theorem identity15762 : scanCanonicalize (H12AffineFastState.compose env15762 (packedSelected [1,12,13] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound15762 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env15763 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,8192,1297,8460,65536,1296,262144,1025,8461,1296,4194304,16,73736,8328,17,4456708,1297,1297,4524332,1284,73771,257,4194441,1297,137]

theorem envBound15763 : H12AffineFastState.Bounded env15763 := by
  intro p hp
  have h : env15763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15762_15763 : H12AffineEnvironment.transform 8 137 env15762 = env15763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env15762 == env15763) = true)

theorem identity15763 : scanCanonicalize (H12AffineFastState.compose env15763 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 8363) := by decide +kernel

theorem selectedBound15763 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env15764 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,8192,1297,8460,65536,1296,8363,1025,8461,1296,4194304,16,73736,8328,17,4202927,1297,1297,4270471,1284,73771,257,4194441,1297,137]

theorem envBound15764 : H12AffineFastState.Bounded env15764 := by
  intro p hp
  have h : env15764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15763_15764 : H12AffineEnvironment.transform 17 8363 env15763 = env15764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8363 env15763 == env15764) = true)

theorem identity15764 : scanCanonicalize (H12AffineFastState.compose env15764 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound15764 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env15765 : List Nat := [2,4,8,16,32,16,128,256,137,4,2048,276,8192,277,8460,65536,276,8363,5,8461,276,4194304,16,73736,8328,17,4202927,277,277,4270471,256,73771,257,4194441,277,137]

theorem envBound15765 : H12AffineFastState.Bounded env15765 := by
  intro p hp
  have h : env15765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15764_15765 : H12AffineEnvironment.transform 9 4 env15764 = env15765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env15764 == env15765) = true)

theorem identity15765 : scanCanonicalize (H12AffineFastState.compose env15765 (packedSelected [3,12] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound15765 : packedSelected [3,12] rootPS < 2^1333 := by decide +kernel

def env15766 : List Nat := [2,4,8,16,32,16,128,256,137,4,2048,276,269,277,1,65536,276,422,5,0,276,4194304,16,65797,389,17,4194466,277,277,4262026,256,65830,257,4194441,277,137]

theorem envBound15766 : H12AffineFastState.Bounded env15766 := by
  intro p hp
  have h : env15766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15765_15766 : H12AffineEnvironment.transform 12 269 env15765 = env15766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env15765 == env15766) = true)

theorem identity15766 : scanCanonicalize (H12AffineFastState.compose env15766 (packedSelected [1,3,21] rootPS)) = affineNative (2^(21+1) ^^^ 65967) := by decide +kernel

theorem selectedBound15766 : packedSelected [1,3,21] rootPS < 2^1333 := by decide +kernel

def env15767 : List Nat := [2,4,8,16,32,16,128,256,137,4,2048,276,269,277,1,65536,276,422,5,0,276,65967,16,65797,389,17,65805,277,277,2341,256,65830,257,65830,277,137]

theorem envBound15767 : H12AffineFastState.Bounded env15767 := by
  intro p hp
  have h : env15767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15766_15767 : H12AffineEnvironment.transform 21 65967 env15766 = env15767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 65967 env15766 == env15767) = true)

theorem identity15767 : scanCanonicalize (H12AffineFastState.compose env15767 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 154) := by decide +kernel

theorem selectedBound15767 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15768 : List Nat := [2,4,8,16,32,16,128,256,137,4,2048,276,269,277,1,154,276,422,5,0,276,309,16,415,389,17,407,277,277,2341,256,444,257,444,277,137]

theorem envBound15768 : H12AffineFastState.Bounded env15768 := by
  intro p hp
  have h : env15768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15767_15768 : H12AffineEnvironment.transform 15 154 env15767 = env15768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 154 env15767 == env15768) = true)

theorem identity15768 : scanCanonicalize (H12AffineFastState.compose env15768 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 130) := by decide +kernel

theorem selectedBound15768 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env15769 : List Nat := [2,4,8,16,32,16,128,256,137,4,130,276,269,277,1,154,276,422,5,0,276,309,16,415,389,17,407,277,277,423,256,444,257,444,277,137]

theorem envBound15769 : H12AffineFastState.Bounded env15769 := by
  intro p hp
  have h : env15769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15768_15769 : H12AffineEnvironment.transform 10 130 env15768 = env15769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 130 env15768 == env15769) = true)

theorem identity15769 : scanCanonicalize (H12AffineFastState.compose env15769 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound15769 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15770 : List Nat := [2,4,8,16,32,16,128,20,137,4,130,0,25,1,1,154,0,178,5,0,0,33,16,139,145,17,131,1,1,179,20,168,21,168,1,137]

theorem envBound15770 : H12AffineFastState.Bounded env15770 := by
  intro p hp
  have h : env15770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15769_15770 : H12AffineEnvironment.transform 7 20 env15769 = env15770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env15769 == env15770) = true)

def env15771 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1296,32768,65536,1297,262144,1025,32769,1297,4194304,17,98565,8328,17,4456709,1296,1296,1073741824,1285,73771,257,4235652,1296,512]

theorem envBound15771 : H12AffineFastState.Bounded env15771 := by
  intro p hp
  have h : env15771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15759_15771 : H12AffineEnvironment.transform 5 17 env15759 = env15771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env15759 == env15771) = true)

theorem identity15771 : scanCanonicalize (H12AffineFastState.compose env15771 (packedSelected [1,3,5] rootPS)) = affineNative (2^(29+1) ^^^ 4458893) := by decide +kernel

theorem selectedBound15771 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env15772 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1296,32768,65536,1297,262144,1025,32769,1297,4194304,17,98565,8328,17,4456709,1296,1296,4458893,1285,73771,257,4235652,1296,512]

theorem envBound15772 : H12AffineFastState.Bounded env15772 := by
  intro p hp
  have h : env15772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15771_15772 : H12AffineEnvironment.transform 29 4458893 env15771 = env15772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4458893 env15771 == env15772) = true)

theorem identity15772 : scanCanonicalize (H12AffineFastState.compose env15772 (packedSelected [1,3,8] rootPS)) = affineNative (2^(14+1) ^^^ 8972) := by decide +kernel

theorem selectedBound15772 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env15773 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1296,8972,65536,1297,262144,1025,8973,1297,4194304,17,74249,8328,17,4456709,1296,1296,4458893,1285,73771,257,4194952,1296,512]

theorem envBound15773 : H12AffineFastState.Bounded env15773 := by
  intro p hp
  have h : env15773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15772_15773 : H12AffineEnvironment.transform 14 8972 env15772 = env15773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8972 env15772 == env15773) = true)

theorem identity15773 : scanCanonicalize (H12AffineFastState.compose env15773 (packedSelected [1,12,13] rootPS)) = affineNative (2^(15+1) ^^^ 2822) := by decide +kernel

theorem selectedBound15773 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env15774 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1296,8972,2822,1297,262144,1025,8973,1297,4194304,17,10511,8328,17,4456709,1296,1296,4458893,1285,11053,257,4194952,1296,512]

theorem envBound15774 : H12AffineFastState.Bounded env15774 := by
  intro p hp
  have h : env15774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15773_15774 : H12AffineEnvironment.transform 15 2822 env15773 = env15774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2822 env15773 == env15774) = true)

theorem identity15774 : scanCanonicalize (H12AffineFastState.compose env15774 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(21+1) ^^^ 272393) := by decide +kernel

theorem selectedBound15774 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env15775 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1296,8972,2822,1297,262144,1025,8973,1297,272393,17,10511,8328,17,10508,1296,1296,8580,1285,11053,257,273025,1296,512]

theorem envBound15775 : H12AffineFastState.Bounded env15775 := by
  intro p hp
  have h : env15775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15774_15775 : H12AffineEnvironment.transform 21 272393 env15774 = env15775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272393 env15774 == env15775) = true)

theorem identity15775 : scanCanonicalize (H12AffineFastState.compose env15775 (packedSelected [1,12,17] rootPS)) = affineNative (2^(17+1) ^^^ 136) := by decide +kernel

theorem selectedBound15775 : packedSelected [1,12,17] rootPS < 2^1333 := by decide +kernel

def env15776 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1296,8972,2822,1297,136,1025,8973,1297,10369,17,10511,8328,17,10508,1296,1296,8580,1285,11053,257,10761,1296,512]

theorem envBound15776 : H12AffineFastState.Bounded env15776 := by
  intro p hp
  have h : env15776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15775_15776 : H12AffineEnvironment.transform 17 136 env15775 = env15776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 136 env15775 == env15776) = true)

theorem identity15776 : scanCanonicalize (H12AffineFastState.compose env15776 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 552) := by decide +kernel

theorem selectedBound15776 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env15777 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,552,1296,292,2822,1297,136,1025,293,1297,2729,17,2855,672,17,2852,1296,1296,940,1285,2309,257,2081,1296,512]

theorem envBound15777 : H12AffineFastState.Bounded env15777 := by
  intro p hp
  have h : env15777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15776_15777 : H12AffineEnvironment.transform 12 552 env15776 = env15777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 552 env15776 == env15777) = true)

theorem identity15777 : scanCanonicalize (H12AffineFastState.compose env15777 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound15777 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15778 : List Nat := [2,4,8,16,32,17,128,256,292,1024,2048,1297,268,1296,292,2082,1297,136,1025,293,1297,2445,17,2051,388,17,2048,1296,1296,136,1285,2309,257,2081,1296,292]

theorem envBound15778 : H12AffineFastState.Bounded env15778 := by
  intro p hp
  have h : env15778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15777_15778 : H12AffineEnvironment.transform 8 292 env15777 = env15778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env15777 == env15778) = true)

theorem identity15778 : scanCanonicalize (H12AffineFastState.compose env15778 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound15778 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env15779 : List Nat := [2,4,8,16,32,17,9,256,292,1024,2048,1297,268,1296,292,2082,1297,1,1025,293,1297,2308,17,2051,269,17,2048,1296,1296,1,1285,2309,257,2081,1296,292]

theorem envBound15779 : H12AffineFastState.Bounded env15779 := by
  intro p hp
  have h : env15779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15778_15779 : H12AffineEnvironment.transform 6 9 env15778 = env15779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env15778 == env15779) = true)

theorem identity15779 : scanCanonicalize (H12AffineFastState.compose env15779 (packedSelected [0,2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound15779 : packedSelected [0,2,6] rootPS < 2^1333 := by decide +kernel

def env15780 : List Nat := [2,4,8,16,1,17,9,256,261,1024,2048,1297,268,1296,261,2051,1297,1,1025,260,1297,2308,17,2051,269,17,2048,1296,1296,1,1285,2309,257,2048,1296,261]

theorem envBound15780 : H12AffineFastState.Bounded env15780 := by
  intro p hp
  have h : env15780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15779_15780 : H12AffineEnvironment.transform 4 1 env15779 = env15780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env15779 == env15780) = true)

theorem identity15780 : scanCanonicalize (H12AffineFastState.compose env15780 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound15780 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15781 : List Nat := [2,4,8,16,1,17,9,21,16,1024,2048,1028,25,1029,16,2051,1028,1,1025,17,1028,2065,17,2051,24,17,2048,1029,1029,1,1040,2064,20,2048,1029,16]

theorem envBound15781 : H12AffineFastState.Bounded env15781 := by
  intro p hp
  have h : env15781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15780_15781 : H12AffineEnvironment.transform 7 21 env15780 = env15781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env15780 == env15781) = true)

theorem identity15781 : scanCanonicalize (H12AffineFastState.compose env15781 (packedSelected [0,9] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound15781 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env15782 : List Nat := [2,4,8,16,1,17,9,21,16,1024,0,1028,25,1029,16,3,1028,1,1025,17,1028,17,17,3,24,17,0,1029,1029,1,1040,16,20,0,1029,16]

theorem envBound15782 : H12AffineFastState.Bounded env15782 := by
  intro p hp
  have h : env15782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15781_15782 : H12AffineEnvironment.transform 10 0 env15781 = env15782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env15781 == env15782) = true)

theorem identity15782 : scanCanonicalize (H12AffineFastState.compose env15782 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound15782 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15783 : List Nat := [2,4,8,16,1,17,9,21,16,21,0,17,25,16,16,3,17,1,20,17,17,17,17,3,24,17,0,16,16,1,5,16,20,0,16,16]

theorem envBound15783 : H12AffineFastState.Bounded env15783 := by
  intro p hp
  have h : env15783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15782_15783 : H12AffineEnvironment.transform 9 21 env15782 = env15783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env15782 == env15783) = true)

theorem identity15783 : scanCanonicalize (H12AffineFastState.compose env15783 (packedSelected [11] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound15783 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env15784 : List Nat := [2,4,8,1,1,0,9,4,1,4,0,0,8,1,1,3,0,1,5,0,0,0,0,3,9,0,0,1,1,1,5,1,5,0,1,1]

theorem envBound15784 : H12AffineFastState.Bounded env15784 := by
  intro p hp
  have h : env15784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15783_15784 : H12AffineEnvironment.transform 3 1 env15783 = env15784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env15783 == env15784) = true)

def env15785 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32769,4096,4194304,8388608,9015381,8328,8914000,134217728,8389888,545088,1073741824,545109,4294967296,8406017,4308177151,138695701,512]

theorem envBound15785 : H12AffineFastState.Bounded env15785 := by
  intro p hp
  have h : env15785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15719_15785 : H12AffineEnvironment.transform 16 1345 env15719 = env15785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env15719 == env15785) = true)

def env15786 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32769,4096,4194304,17664,644437,8328,541008,134217728,16384,545088,1073741824,545109,4294967296,257,4299806207,138695701,512]

theorem envBound15786 : H12AffineFastState.Bounded env15786 := by
  intro p hp
  have h : env15786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15785_15786 : H12AffineEnvironment.transform 22 17664 env15785 = env15786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17664 env15785 == env15786) = true)

def env15787 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32769,4096,4194304,17665,644436,8328,541009,134217728,16385,545088,1073741824,545109,4294967296,256,4299806206,138695701,512]

theorem envBound15787 : H12AffineFastState.Bounded env15787 := by
  intro p hp
  have h : env15787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15785_15787 : H12AffineEnvironment.transform 22 17665 env15785 = env15787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17665 env15785 == env15787) = true)

theorem identity15787 : scanCanonicalize (H12AffineFastState.compose env15787 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(18+1) ^^^ 21584) := by decide +kernel

theorem selectedBound15787 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env15788 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,21584,32769,4096,4194304,17665,98564,8328,5377,134217728,16385,1296,1073741824,1285,4294967296,256,4299260334,138695701,512]

theorem envBound15788 : H12AffineFastState.Bounded env15788 := by
  intro p hp
  have h : env15788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15787_15788 : H12AffineEnvironment.transform 18 21584 env15787 = env15788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21584 env15787 == env15788) = true)

def env15789 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,16384,32768,65536,1345,262144,16656,32769,1344,4194304,17665,98564,8328,65,134217728,16385,1296,1073741824,1285,4294967296,256,4299260334,138690901,512]

theorem envBound15789 : H12AffineFastState.Bounded env15789 := by
  intro p hp
  have h : env15789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15788_15789 : H12AffineEnvironment.transform 11 1344 env15788 = env15789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env15788 == env15789) = true)

theorem identity15789 : scanCanonicalize (H12AffineFastState.compose env15789 (packedSelected [9,22] rootPS)) = affineNative (2^(26+1) ^^^ 4456709) := by decide +kernel

theorem selectedBound15789 : packedSelected [9,22] rootPS < 2^1333 := by decide +kernel

def env15790 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,16384,32768,65536,1345,262144,16656,32769,1344,4194304,17665,98564,8328,65,4456709,16385,1296,1073741824,1285,4294967296,256,4299260334,16464,512]

theorem envBound15790 : H12AffineFastState.Bounded env15790 := by
  intro p hp
  have h : env15790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15789_15790 : H12AffineEnvironment.transform 26 4456709 env15789 = env15790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 4456709 env15789 == env15790) = true)

theorem identity15790 : scanCanonicalize (H12AffineFastState.compose env15790 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 1296) := by decide +kernel

theorem selectedBound15790 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env15791 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,65536,1345,262144,1024,32769,1344,4194304,17,98564,8328,65,4456709,1297,1296,1073741824,1285,4294967296,256,4299260334,1344,512]

theorem envBound15791 : H12AffineFastState.Bounded env15791 := by
  intro p hp
  have h : env15791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15790_15791 : H12AffineEnvironment.transform 13 1296 env15790 = env15791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env15790 == env15791) = true)

theorem identity15791 : scanCanonicalize (H12AffineFastState.compose env15791 (packedSelected [3,5,10] rootPS)) = affineNative (2^(29+1) ^^^ 4294794) := by decide +kernel

theorem selectedBound15791 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env15792 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,65536,1345,262144,1024,32769,1344,4194304,17,98564,8328,65,4456709,1297,1296,4294794,1285,4294967296,256,4299260334,1344,512]

theorem envBound15792 : H12AffineFastState.Bounded env15792 := by
  intro p hp
  have h : env15792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15791_15792 : H12AffineEnvironment.transform 29 4294794 env15791 = env15792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4294794 env15791 == env15792) = true)

theorem identity15792 : scanCanonicalize (H12AffineFastState.compose env15792 (packedSelected [1,12,13] rootPS)) = affineNative (2^(17+1) ^^^ 65798) := by decide +kernel

theorem selectedBound15792 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env15793 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,65536,1345,65798,1024,32769,1344,4194304,17,98564,8328,65,4259843,1297,1296,4294794,1285,4294967296,256,4299260334,1344,512]

theorem envBound15793 : H12AffineFastState.Bounded env15793 := by
  intro p hp
  have h : env15793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15792_15793 : H12AffineEnvironment.transform 17 65798 env15792 = env15793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65798 env15792 == env15793) = true)

theorem identity15793 : scanCanonicalize (H12AffineFastState.compose env15793 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 2208) := by decide +kernel

theorem selectedBound15793 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env15794 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,2208,1296,32768,65536,1345,65798,1024,32769,1344,4194304,17,98564,2088,65,4259843,1297,1296,4294794,1285,4294967296,256,4299260334,1344,512]

theorem envBound15794 : H12AffineFastState.Bounded env15794 := by
  intro p hp
  have h : env15794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15793_15794 : H12AffineEnvironment.transform 12 2208 env15793 = env15794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2208 env15793 == env15794) = true)

theorem identity15794 : scanCanonicalize (H12AffineFastState.compose env15794 (packedSelected [1,3,8] rootPS)) = affineNative (2^(15+1) ^^^ 33167) := by decide +kernel

theorem selectedBound15794 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env15795 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,2208,1296,32768,33167,1345,32905,1024,32769,1344,4194304,17,139,2088,65,4227468,1297,1296,4196613,1285,4294967296,256,4299161633,1344,512]

theorem envBound15795 : H12AffineFastState.Bounded env15795 := by
  intro p hp
  have h : env15795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15794_15795 : H12AffineEnvironment.transform 15 33167 env15794 = env15795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33167 env15794 == env15795) = true)

def env15796 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,2208,1296,32768,33167,1297,32905,1024,32769,1296,4194304,17,139,2088,17,4227468,1297,1296,4196613,1285,4294967296,256,4299161633,1296,512]

theorem envBound15796 : H12AffineFastState.Bounded env15796 := by
  intro p hp
  have h : env15796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15795_15796 : H12AffineEnvironment.transform 5 16 env15795 = env15796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env15795 == env15796) = true)

theorem identity15796 : scanCanonicalize (H12AffineFastState.compose env15796 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 4229413) := by decide +kernel

theorem selectedBound15796 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15797 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,2208,1296,32768,33167,1297,32905,1024,32769,1296,4194304,17,139,2088,17,4227468,1297,1296,4196613,1285,4229413,256,35076,1296,512]

theorem envBound15797 : H12AffineFastState.Bounded env15797 := by
  intro p hp
  have h : env15797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15796_15797 : H12AffineEnvironment.transform 31 4229413 env15796 = env15797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 4229413 env15796 == env15797) = true)

theorem identity15797 : scanCanonicalize (H12AffineFastState.compose env15797 (packedSelected [3] rootPS)) = affineNative (2^(21+1) ^^^ 35213) := by decide +kernel

theorem selectedBound15797 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env15798 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,2208,1296,32768,33167,1297,32905,1024,32769,1296,35213,17,139,2088,17,2049,1297,1296,32904,1285,168,256,35076,1296,512]

theorem envBound15798 : H12AffineFastState.Bounded env15798 := by
  intro p hp
  have h : env15798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15797_15798 : H12AffineEnvironment.transform 21 35213 env15797 = env15798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 35213 env15797 == env15798) = true)

theorem identity15798 : scanCanonicalize (H12AffineFastState.compose env15798 (packedSelected [0,4] rootPS)) = affineNative (2^(14+1) ^^^ 2852) := by decide +kernel

theorem selectedBound15798 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env15799 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,2208,1296,2852,2731,1297,2989,1024,2853,1296,681,17,139,2088,17,2049,1297,1296,2988,1285,168,256,544,1296,512]

theorem envBound15799 : H12AffineFastState.Bounded env15799 := by
  intro p hp
  have h : env15799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15798_15799 : H12AffineEnvironment.transform 14 2852 env15798 = env15799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2852 env15798 == env15799) = true)

def env15800 : List Nat := [2,4,8,16,32,16,128,256,0,1024,2048,1296,2208,1296,2340,2219,1297,2477,1024,2341,1296,169,17,139,2088,17,2049,1297,1296,2476,1285,168,256,32,1296,0]

theorem envBound15800 : H12AffineFastState.Bounded env15800 := by
  intro p hp
  have h : env15800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15799_15800 : H12AffineEnvironment.transform 8 0 env15799 = env15800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env15799 == env15800) = true)

theorem identity15800 : scanCanonicalize (H12AffineFastState.compose env15800 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound15800 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15801 : List Nat := [2,4,8,16,32,16,40,256,0,1024,2048,1296,2056,1296,2340,2051,1297,2309,1024,2341,1296,1,17,35,2088,17,2049,1297,1296,2308,1285,0,256,32,1296,0]

theorem envBound15801 : H12AffineFastState.Bounded env15801 := by
  intro p hp
  have h : env15801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15800_15801 : H12AffineEnvironment.transform 6 40 env15800 = env15801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env15800 == env15801) = true)

def env15802 : List Nat := [2,4,8,16,0,16,8,256,0,1024,2048,1296,2056,1296,2308,2051,1297,2309,1024,2309,1296,1,17,3,2056,17,2049,1297,1296,2308,1285,0,256,0,1296,0]

theorem envBound15802 : H12AffineFastState.Bounded env15802 := by
  intro p hp
  have h : env15802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15801_15802 : H12AffineEnvironment.transform 4 0 env15801 = env15802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15801 == env15802) = true)

theorem identity15802 : scanCanonicalize (H12AffineFastState.compose env15802 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound15802 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15803 : List Nat := [2,4,8,16,0,16,8,4,0,1024,2048,1044,2056,1044,2048,2051,1045,2049,1024,2049,1044,1,17,3,2056,17,2049,1045,1044,2048,1025,0,4,0,1044,0]

theorem envBound15803 : H12AffineFastState.Bounded env15803 := by
  intro p hp
  have h : env15803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15802_15803 : H12AffineEnvironment.transform 7 4 env15802 = env15803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env15802 == env15803) = true)

def leafEnv15803 : List Nat := [2,4,8,16,0,16,8,4,0,1024,2048,1044,2056,1044,2048,2051,1045,2049,1024,2049,1044,1,17,3,1025,2056,1,17,2049,1045,1044,2048,1025,0,4,0,4,2050,1044,0,0,1044,1]

def active15803 : List Nat := [0,1,2,3,9,10]

def tree15803 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15803 : H12WitnessSearch.Good tree15803 := H12GlobalWitnessIndex.good

theorem leafIdentity15803 : H12AffineFastState.composeSystem env15803 rootObs = leafEnv15803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15803 rootObs == leafEnv15803) = true)

theorem terminalChecked15803 : H12PackedTerminal.terminalCheckFast leafEnv15803 active15803 tree15803 = true := by decide +kernel

def env15804 : List Nat := [2,4,8,16,1,16,9,256,0,1024,2048,1296,2056,1296,2309,2051,1297,2309,1024,2308,1296,1,17,2,2057,17,2049,1297,1296,2308,1285,0,256,1,1296,0]

theorem envBound15804 : H12AffineFastState.Bounded env15804 := by
  intro p hp
  have h : env15804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15801_15804 : H12AffineEnvironment.transform 4 1 env15801 = env15804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env15801 == env15804) = true)

def env15805 : List Nat := [2,4,8,16,32,16,128,256,1,1024,2048,1296,2208,1296,2341,2218,1297,2476,1024,2340,1296,168,17,139,2088,17,2049,1297,1296,2477,1285,168,256,33,1296,1]

theorem envBound15805 : H12AffineFastState.Bounded env15805 := by
  intro p hp
  have h : env15805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15799_15805 : H12AffineEnvironment.transform 8 1 env15799 = env15805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env15799 == env15805) = true)

theorem identity15805 : scanCanonicalize (H12AffineFastState.compose env15805 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound15805 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15806 : List Nat := [2,4,8,16,32,16,128,5,1,1024,2048,1045,2208,1045,2080,2218,1044,2217,1024,2081,1045,168,17,139,2088,17,2049,1044,1045,2216,1024,168,5,33,1045,1]

theorem envBound15806 : H12AffineFastState.Bounded env15806 := by
  intro p hp
  have h : env15806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15805_15806 : H12AffineEnvironment.transform 7 5 env15805 = env15806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env15805 == env15806) = true)

def env15807 : List Nat := [2,4,8,16,0,16,128,5,1,1024,2048,1045,2176,1045,2048,2186,1044,2185,1024,2049,1045,136,17,139,2056,17,2049,1044,1045,2184,1024,136,5,1,1045,1]

theorem envBound15807 : H12AffineFastState.Bounded env15807 := by
  intro p hp
  have h : env15807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15806_15807 : H12AffineEnvironment.transform 4 0 env15806 = env15807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15806 == env15807) = true)

def env15808 : List Nat := [2,4,8,16,1,16,128,5,1,1024,2048,1045,2177,1045,2049,2187,1044,2184,1024,2048,1045,137,17,139,2057,17,2049,1044,1045,2185,1024,137,5,0,1045,1]

theorem envBound15808 : H12AffineFastState.Bounded env15808 := by
  intro p hp
  have h : env15808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15806_15808 : H12AffineEnvironment.transform 4 1 env15806 = env15808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env15806 == env15808) = true)

theorem identity15808 : scanCanonicalize (H12AffineFastState.compose env15808 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound15808 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15809 : List Nat := [2,4,8,16,1,16,8,5,1,1024,2048,1045,2057,1045,2049,2051,1044,2048,1024,2048,1045,1,17,3,2057,17,2049,1044,1045,2049,1024,1,5,0,1045,1]

theorem envBound15809 : H12AffineFastState.Bounded env15809 := by
  intro p hp
  have h : env15809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15808_15809 : H12AffineEnvironment.transform 6 8 env15808 = env15809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env15808 == env15809) = true)

def leafEnv15809 : List Nat := [2,4,8,16,1,16,8,5,1,1024,2048,1045,2057,1045,2049,2051,1044,2048,1024,2048,1045,1,17,3,1024,2057,1,17,2049,1044,1045,2049,1024,1,5,0,4,2050,1045,1,0,1045,1]

def active15809 : List Nat := [0,1,2,3,9,10]

def tree15809 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15809 : H12WitnessSearch.Good tree15809 := H12GlobalWitnessIndex.good

theorem leafIdentity15809 : H12AffineFastState.composeSystem env15809 rootObs = leafEnv15809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15809 rootObs == leafEnv15809) = true)

theorem terminalChecked15809 : H12PackedTerminal.terminalCheckFast leafEnv15809 active15809 tree15809 = true := by decide +kernel

def env15810 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,2208,1296,32768,33167,1296,32905,1024,32769,1297,4194304,17,139,2088,16,4227468,1297,1296,4196613,1285,4294967296,256,4299161633,1297,512]

theorem envBound15810 : H12AffineFastState.Bounded env15810 := by
  intro p hp
  have h : env15810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15795_15810 : H12AffineEnvironment.transform 5 17 env15795 = env15810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env15795 == env15810) = true)

theorem identity15810 : scanCanonicalize (H12AffineFastState.compose env15810 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 396) := by decide +kernel

theorem selectedBound15810 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15811 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,2208,1296,32768,33167,1296,32905,1024,32769,1297,4194304,17,139,2088,16,4227468,1297,1296,4196613,1285,396,256,4194733,1297,512]

theorem envBound15811 : H12AffineFastState.Bounded env15811 := by
  intro p hp
  have h : env15811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15810_15811 : H12AffineEnvironment.transform 31 396 env15810 = env15811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 396 env15810 == env15811) = true)

theorem identity15811 : scanCanonicalize (H12AffineFastState.compose env15811 (packedSelected [3] rootPS)) = affineNative (2^(14+1) ^^^ 2184) := by decide +kernel

theorem selectedBound15811 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env15812 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,2208,1296,2184,2311,1296,2049,1024,2185,1297,4194304,17,139,2088,16,4196612,1297,1296,4196613,1285,396,256,4194733,1297,512]

theorem envBound15812 : H12AffineFastState.Bounded env15812 := by
  intro p hp
  have h : env15812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15811_15812 : H12AffineEnvironment.transform 14 2184 env15811 = env15812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2184 env15811 == env15812) = true)

theorem identity15812 : scanCanonicalize (H12AffineFastState.compose env15812 (packedSelected [0,4] rootPS)) = affineNative (2^(21+1) ^^^ 909) := by decide +kernel

theorem selectedBound15812 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env15813 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,2208,1296,2184,2311,1296,2049,1024,2185,1297,909,17,139,2088,16,2697,1297,1296,2696,1285,396,256,544,1297,512]

theorem envBound15813 : H12AffineFastState.Bounded env15813 := by
  intro p hp
  have h : env15813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15812_15813 : H12AffineEnvironment.transform 21 909 env15812 = env15813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 909 env15812 == env15813) = true)

theorem identity15813 : scanCanonicalize (H12AffineFastState.compose env15813 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound15813 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env15814 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,1297,2208,1296,2184,2311,1296,2049,1024,2185,1297,260,17,139,2088,16,2048,1297,1296,2049,1285,396,256,169,1297,137]

theorem envBound15814 : H12AffineFastState.Bounded env15814 := by
  intro p hp
  have h : env15814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15813_15814 : H12AffineEnvironment.transform 8 137 env15813 = env15814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env15813 == env15814) = true)

theorem identity15814 : scanCanonicalize (H12AffineFastState.compose env15814 (packedSelected [0,2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound15814 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env15815 : List Nat := [2,4,8,16,32,17,128,36,137,1024,2048,1077,2208,1076,2184,2083,1076,2049,1024,2185,1077,32,17,139,2088,16,2048,1077,1076,2049,1057,168,36,169,1077,137]

theorem envBound15815 : H12AffineFastState.Bounded env15815 := by
  intro p hp
  have h : env15815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15814_15815 : H12AffineEnvironment.transform 7 36 env15814 = env15815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env15814 == env15815) = true)

theorem identity15815 : scanCanonicalize (H12AffineFastState.compose env15815 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound15815 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15816 : List Nat := [2,4,8,16,32,17,41,36,32,1024,2048,1077,2057,1076,2081,2083,1076,2049,1024,2080,1077,32,17,34,2088,16,2048,1077,1076,2049,1057,1,36,0,1077,32]

theorem envBound15816 : H12AffineFastState.Bounded env15816 := by
  intro p hp
  have h : env15816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15815_15816 : H12AffineEnvironment.transform 6 41 env15815 = env15816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env15815 == env15816) = true)

theorem identity15816 : scanCanonicalize (H12AffineFastState.compose env15816 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound15816 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env15817 : List Nat := [2,4,8,16,0,17,9,4,0,1024,2048,1045,2057,1044,2049,2051,1044,2049,1024,2048,1045,0,17,2,2056,16,2048,1045,1044,2049,1025,1,4,0,1045,0]

theorem envBound15817 : H12AffineFastState.Bounded env15817 := by
  intro p hp
  have h : env15817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15816_15817 : H12AffineEnvironment.transform 4 0 env15816 = env15817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15816 == env15817) = true)

def leafEnv15817 : List Nat := [2,4,8,16,0,17,9,4,0,1024,2048,1045,2057,1044,2049,2051,1044,2049,1024,2048,1045,0,17,2,1025,2056,1,16,2048,1045,1044,2049,1025,1,4,0,4,2051,1045,0,0,1044,1]

def active15817 : List Nat := [0,1,2,3,9,10]

def tree15817 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15817 : H12WitnessSearch.Good tree15817 := H12GlobalWitnessIndex.good

theorem leafIdentity15817 : H12AffineFastState.composeSystem env15817 rootObs = leafEnv15817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15817 rootObs == leafEnv15817) = true)

theorem terminalChecked15817 : H12PackedTerminal.terminalCheckFast leafEnv15817 active15817 tree15817 = true := by decide +kernel

def env15818 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,16384,32768,65536,1345,262144,16657,32769,1345,4194304,17665,98564,8328,64,134217728,16385,1296,1073741824,1285,4294967296,256,4299260334,138690900,512]

theorem envBound15818 : H12AffineFastState.Bounded env15818 := by
  intro p hp
  have h : env15818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15788_15818 : H12AffineEnvironment.transform 11 1345 env15788 = env15818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env15788 == env15818) = true)

theorem identity15818 : scanCanonicalize (H12AffineFastState.compose env15818 (packedSelected [9,22] rootPS)) = affineNative (2^(13+1) ^^^ 1297) := by decide +kernel

theorem selectedBound15818 : packedSelected [9,22] rootPS < 2^1333 := by decide +kernel

def env15819 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,65536,1345,262144,1024,32769,1345,4194304,16,98564,8328,64,134217728,1296,1296,1073741824,1285,4294967296,256,4299260334,138675269,512]

theorem envBound15819 : H12AffineFastState.Bounded env15819 := by
  intro p hp
  have h : env15819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15818_15819 : H12AffineEnvironment.transform 13 1297 env15818 = env15819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env15818 == env15819) = true)

def env15820 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,65536,1345,512,1024,32769,1345,4194304,16,98564,8328,64,134217728,1296,1296,1073741824,1285,4294967296,256,4299260334,138413637,512]

theorem envBound15820 : H12AffineFastState.Bounded env15820 := by
  intro p hp
  have h : env15820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15819_15820 : H12AffineEnvironment.transform 17 512 env15819 = env15820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 512 env15819 == env15820) = true)

theorem identity15820 : scanCanonicalize (H12AffineFastState.compose env15820 (packedSelected [3,5,24] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound15820 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env15821 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,1,65536,1345,512,1024,0,1345,4194304,16,65797,8328,64,134217728,1296,1296,1073741824,1285,4294967296,256,4299227567,138413637,512]

theorem envBound15821 : H12AffineFastState.Bounded env15821 := by
  intro p hp
  have h : env15821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15820_15821 : H12AffineEnvironment.transform 14 1 env15820 = env15821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env15820 == env15821) = true)

def env15822 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1297,1,65536,1297,512,1024,0,1297,4194304,16,65797,8328,16,134217728,1296,1296,1073741824,1285,4294967296,256,4299227567,138413589,512]

theorem envBound15822 : H12AffineFastState.Bounded env15822 := by
  intro p hp
  have h : env15822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15821_15822 : H12AffineEnvironment.transform 5 16 env15821 = env15822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env15821 == env15822) = true)

theorem identity15822 : scanCanonicalize (H12AffineFastState.compose env15822 (packedSelected [1,3,5] rootPS)) = affineNative (2^(29+1) ^^^ 134291878) := by decide +kernel

theorem selectedBound15822 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env15823 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1297,1,65536,1297,512,1024,0,1297,4194304,16,65797,8328,16,134217728,1296,1296,134291878,1285,4294967296,256,4299227567,138413589,512]

theorem envBound15823 : H12AffineFastState.Bounded env15823 := by
  intro p hp
  have h : env15823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15822_15823 : H12AffineEnvironment.transform 29 134291878 env15822 = env15823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 134291878 env15822 == env15823) = true)

theorem identity15823 : scanCanonicalize (H12AffineFastState.compose env15823 (packedSelected [1,3,8,15,17,21,38] rootPS)) = affineNative (2^(26+1) ^^^ 4195077) := by decide +kernel

theorem selectedBound15823 : packedSelected [1,3,8,15,17,21,38] rootPS < 2^1333 := by decide +kernel

def env15824 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1297,1,65536,1297,512,1024,0,1297,4194304,16,65797,8328,16,4195077,1296,1296,4268707,1285,4294967296,256,4299227567,1296,512]

theorem envBound15824 : H12AffineFastState.Bounded env15824 := by
  intro p hp
  have h : env15824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15823_15824 : H12AffineEnvironment.transform 26 4195077 env15823 = env15824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 4195077 env15823 == env15824) = true)

theorem identity15824 : scanCanonicalize (H12AffineFastState.compose env15824 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 8713) := by decide +kernel

theorem selectedBound15824 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15825 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1297,1,65536,1297,512,1024,0,1297,4194304,16,65797,8328,16,4195077,1296,1296,4268707,1285,8713,256,4268966,1296,512]

theorem envBound15825 : H12AffineFastState.Bounded env15825 := by
  intro p hp
  have h : env15825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15824_15825 : H12AffineEnvironment.transform 31 8713 env15824 = env15825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 8713 env15824 == env15825) = true)

theorem identity15825 : scanCanonicalize (H12AffineFastState.compose env15825 (packedSelected [3,8] rootPS)) = affineNative (2^(15+1) ^^^ 11174) := by decide +kernel

theorem selectedBound15825 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env15826 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1297,1,11174,1297,512,1024,0,1297,4194304,16,10915,8328,16,4195077,1296,1296,4196613,1285,8713,256,4196352,1296,512]

theorem envBound15826 : H12AffineFastState.Bounded env15826 := by
  intro p hp
  have h : env15826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15825_15826 : H12AffineEnvironment.transform 15 11174 env15825 = env15826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 11174 env15825 == env15826) = true)

theorem identity15826 : scanCanonicalize (H12AffineFastState.compose env15826 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound15826 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env15827 : List Nat := [2,4,8,16,32,16,128,256,512,1024,513,1297,8192,1297,1,8615,1297,512,1024,0,1297,4194304,16,8354,8328,16,4195077,1296,1296,4195076,1285,8713,256,4194817,1296,512]

theorem envBound15827 : H12AffineFastState.Bounded env15827 := by
  intro p hp
  have h : env15827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15826_15827 : H12AffineEnvironment.transform 10 513 env15826 = env15827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env15826 == env15827) = true)

theorem identity15827 : scanCanonicalize (H12AffineFastState.compose env15827 (packedSelected [0,7] rootPS)) = affineNative (2^(21+1) ^^^ 8493) := by decide +kernel

theorem selectedBound15827 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env15828 : List Nat := [2,4,8,16,32,16,128,256,512,1024,513,1297,8192,1297,1,8615,1297,512,1024,0,1297,8493,16,8354,8328,16,8744,1296,1296,8745,1285,8713,256,9004,1296,512]

theorem envBound15828 : H12AffineFastState.Bounded env15828 := by
  intro p hp
  have h : env15828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15827_15828 : H12AffineEnvironment.transform 21 8493 env15827 = env15828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8493 env15827 == env15828) = true)

theorem identity15828 : scanCanonicalize (H12AffineFastState.compose env15828 (packedSelected [4,9] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound15828 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env15829 : List Nat := [2,4,8,16,32,16,128,256,512,1024,513,1297,41,1297,1,398,1297,512,1024,0,1297,260,16,139,161,16,513,1296,1296,512,1285,544,256,773,1296,512]

theorem envBound15829 : H12AffineFastState.Bounded env15829 := by
  intro p hp
  have h : env15829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15828_15829 : H12AffineEnvironment.transform 12 41 env15828 = env15829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env15828 == env15829) = true)

theorem identity15829 : scanCanonicalize (H12AffineFastState.compose env15829 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound15829 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env15830 : List Nat := [2,4,8,16,32,16,128,256,293,1024,292,1297,41,1297,1,398,1297,293,1024,0,1297,260,16,139,161,16,292,1296,1296,293,1285,261,256,32,1296,293]

theorem envBound15830 : H12AffineFastState.Bounded env15830 := by
  intro p hp
  have h : env15830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15829_15830 : H12AffineEnvironment.transform 8 293 env15829 = env15830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env15829 == env15830) = true)

theorem identity15830 : scanCanonicalize (H12AffineFastState.compose env15830 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound15830 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15831 : List Nat := [2,4,8,16,0,16,128,256,261,1024,260,1297,9,1297,1,398,1297,261,1024,0,1297,260,16,139,129,16,260,1296,1296,261,1285,261,256,0,1296,261]

theorem envBound15831 : H12AffineFastState.Bounded env15831 := by
  intro p hp
  have h : env15831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15830_15831 : H12AffineEnvironment.transform 4 0 env15830 = env15831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15830 == env15831) = true)

def env15832 : List Nat := [2,4,8,16,0,16,8,256,261,1024,260,1297,9,1297,1,262,1297,261,1024,0,1297,260,16,3,9,16,260,1296,1296,261,1285,261,256,0,1296,261]

theorem envBound15832 : H12AffineFastState.Bounded env15832 := by
  intro p hp
  have h : env15832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15831_15832 : H12AffineEnvironment.transform 6 8 env15831 = env15832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env15831 == env15832) = true)

theorem identity15832 : scanCanonicalize (H12AffineFastState.compose env15832 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound15832 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env15833 : List Nat := [2,4,8,16,0,16,8,4,1,1024,0,1045,9,1045,1,2,1045,1,1024,0,1045,0,16,3,9,16,0,1044,1044,1,1025,1,4,0,1044,1]

theorem envBound15833 : H12AffineFastState.Bounded env15833 := by
  intro p hp
  have h : env15833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15832_15833 : H12AffineEnvironment.transform 7 4 env15832 = env15833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env15832 == env15833) = true)

def leafEnv15833 : List Nat := [2,4,8,16,0,16,8,4,1,1024,0,1045,9,1045,1,2,1045,1,1024,0,1045,0,16,3,1025,9,1,16,0,1044,1044,1,1025,1,4,0,4,3,1044,1,0,1044,1]

def active15833 : List Nat := [0,1,2,3,9]

def tree15833 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15833 : H12WitnessSearch.Good tree15833 := H12GlobalWitnessIndex.good

theorem leafIdentity15833 : H12AffineFastState.composeSystem env15833 rootObs = leafEnv15833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15833 rootObs == leafEnv15833) = true)

theorem terminalChecked15833 : H12PackedTerminal.terminalCheckFast leafEnv15833 active15833 tree15833 = true := by decide +kernel

def env15834 : List Nat := [2,4,8,16,0,16,9,256,261,1024,260,1297,9,1297,1,263,1297,261,1024,0,1297,260,16,2,8,16,260,1296,1296,261,1285,261,256,0,1296,261]

theorem envBound15834 : H12AffineFastState.Bounded env15834 := by
  intro p hp
  have h : env15834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15831_15834 : H12AffineEnvironment.transform 6 9 env15831 = env15834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env15831 == env15834) = true)

def env15835 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1297,1,65536,1296,512,1024,0,1296,4194304,16,65797,8328,17,134217728,1296,1296,1073741824,1285,4294967296,256,4299227567,138413588,512]

theorem envBound15835 : H12AffineFastState.Bounded env15835 := by
  intro p hp
  have h : env15835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15821_15835 : H12AffineEnvironment.transform 5 17 env15821 = env15835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env15821 == env15835) = true)

theorem identity15835 : scanCanonicalize (H12AffineFastState.compose env15835 (packedSelected [1,3,5] rootPS)) = affineNative (2^(26+1) ^^^ 4195077) := by decide +kernel

theorem selectedBound15835 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env15836 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1297,1,65536,1296,512,1024,0,1296,4194304,16,65797,8328,17,4195077,1296,1296,1073741824,1285,4294967296,256,4299227567,1297,512]

theorem envBound15836 : H12AffineFastState.Bounded env15836 := by
  intro p hp
  have h : env15836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15835_15836 : H12AffineEnvironment.transform 26 4195077 env15835 = env15836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 4195077 env15835 == env15836) = true)

theorem identity15836 : scanCanonicalize (H12AffineFastState.compose env15836 (packedSelected [1,12,13] rootPS)) = affineNative (2^(15+1) ^^^ 398) := by decide +kernel

theorem selectedBound15836 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env15837 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1297,1,398,1296,512,1024,0,1296,4194304,16,139,8328,17,4195077,1296,1296,1073741824,1285,4294967296,256,4299161633,1297,512]

theorem envBound15837 : H12AffineFastState.Bounded env15837 := by
  intro p hp
  have h : env15837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15836_15837 : H12AffineEnvironment.transform 15 398 env15836 = env15837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 398 env15836 == env15837) = true)

theorem identity15837 : scanCanonicalize (H12AffineFastState.compose env15837 (packedSelected [1,12] rootPS)) = affineNative (2^(31+1) ^^^ 4194441) := by decide +kernel

theorem selectedBound15837 : packedSelected [1,12] rootPS < 2^1333 := by decide +kernel

def env15838 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1297,1,398,1296,512,1024,0,1296,4194304,16,139,8328,17,4195077,1296,1296,1073741824,1285,4194441,256,168,1297,512]

theorem envBound15838 : H12AffineFastState.Bounded env15838 := by
  intro p hp
  have h : env15838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15837_15838 : H12AffineEnvironment.transform 31 4194441 env15837 = env15838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 4194441 env15837 == env15838) = true)

theorem identity15838 : scanCanonicalize (H12AffineFastState.compose env15838 (packedSelected [3,15] rootPS)) = affineNative (2^(29+1) ^^^ 4203309) := by decide +kernel

theorem selectedBound15838 : packedSelected [3,15] rootPS < 2^1333 := by decide +kernel

def env15839 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1297,1,398,1296,512,1024,0,1296,4194304,16,139,8328,17,4195077,1296,1296,4203309,1285,4194441,256,168,1297,512]

theorem envBound15839 : H12AffineFastState.Bounded env15839 := by
  intro p hp
  have h : env15839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15838_15839 : H12AffineEnvironment.transform 29 4203309 env15838 = env15839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4203309 env15838 == env15839) = true)

theorem identity15839 : scanCanonicalize (H12AffineFastState.compose env15839 (packedSelected [18,23] rootPS)) = affineNative (2^(12+1) ^^^ 2600) := by decide +kernel

theorem selectedBound15839 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env15840 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,2600,1297,1,398,1296,512,1024,0,1296,4194304,16,139,2720,17,4195077,1296,1296,4196613,1285,4194441,256,168,1297,512]

theorem envBound15840 : H12AffineFastState.Bounded env15840 := by
  intro p hp
  have h : env15840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15839_15840 : H12AffineEnvironment.transform 12 2600 env15839 = env15840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2600 env15839 == env15840) = true)

theorem identity15840 : scanCanonicalize (H12AffineFastState.compose env15840 (packedSelected [3] rootPS)) = affineNative (2^(21+1) ^^^ 2820) := by decide +kernel

theorem selectedBound15840 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env15841 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,2600,1297,1,398,1296,512,1024,0,1296,2820,16,139,2720,17,2049,1296,1296,513,1285,2957,256,168,1297,512]

theorem envBound15841 : H12AffineFastState.Bounded env15841 := by
  intro p hp
  have h : env15841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15840_15841 : H12AffineEnvironment.transform 21 2820 env15840 = env15841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2820 env15840 == env15841) = true)

theorem identity15841 : scanCanonicalize (H12AffineFastState.compose env15841 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound15841 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env15842 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,1296,2209,1297,1,398,1296,137,1024,0,1296,2445,16,139,2089,17,2049,1296,1296,136,1285,2308,256,168,1297,137]

theorem envBound15842 : H12AffineFastState.Bounded env15842 := by
  intro p hp
  have h : env15842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15841_15842 : H12AffineEnvironment.transform 8 137 env15841 = env15842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env15841 == env15842) = true)

def env15843 : List Nat := [2,4,8,16,32,17,8,256,1,1024,2048,1296,2089,1297,1,262,1296,1,1024,0,1296,2309,16,3,2089,17,2049,1296,1296,0,1285,2308,256,32,1297,1]

theorem envBound15843 : H12AffineFastState.Bounded env15843 := by
  intro p hp
  have h : env15843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15842_15843 : H12AffineEnvironment.transform 6 8 env15842 = env15843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env15842 == env15843) = true)

theorem identity15843 : scanCanonicalize (H12AffineFastState.compose env15843 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 261) := by decide +kernel

theorem selectedBound15843 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15844 : List Nat := [2,4,8,16,32,17,8,256,1,1024,261,1296,300,1297,1,262,1296,1,1024,0,1296,0,16,3,300,17,260,1296,1296,0,1285,1,256,32,1297,1]

theorem envBound15844 : H12AffineFastState.Bounded env15844 := by
  intro p hp
  have h : env15844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15843_15844 : H12AffineEnvironment.transform 10 261 env15843 = env15844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 261 env15843 == env15844) = true)

def env15845 : List Nat := [2,4,8,16,0,17,8,256,1,1024,261,1296,268,1297,1,262,1296,1,1024,0,1296,0,16,3,268,17,260,1296,1296,0,1285,1,256,0,1297,1]

theorem envBound15845 : H12AffineFastState.Bounded env15845 := by
  intro p hp
  have h : env15845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15844_15845 : H12AffineEnvironment.transform 4 0 env15844 = env15845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15844 == env15845) = true)

def env15846 : List Nat := [2,4,8,16,1,17,8,256,1,1024,261,1296,269,1297,1,262,1296,1,1024,0,1296,0,16,3,269,17,260,1296,1296,0,1285,1,256,1,1297,1]

theorem envBound15846 : H12AffineFastState.Bounded env15846 := by
  intro p hp
  have h : env15846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15844_15846 : H12AffineEnvironment.transform 4 1 env15844 = env15846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env15844 == env15846) = true)

theorem identity15846 : scanCanonicalize (H12AffineFastState.compose env15846 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound15846 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15847 : List Nat := [2,4,8,16,1,17,8,5,1,1024,0,1045,8,1044,1,3,1045,1,1024,0,1045,0,16,3,8,17,1,1045,1045,0,1024,1,5,1,1044,1]

theorem envBound15847 : H12AffineFastState.Bounded env15847 := by
  intro p hp
  have h : env15847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15846_15847 : H12AffineEnvironment.transform 7 5 env15846 = env15847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env15846 == env15847) = true)

def leafEnv15847 : List Nat := [2,4,8,16,1,17,8,5,1,1024,0,1045,8,1044,1,3,1045,1,1024,0,1045,0,16,3,1024,8,1,17,1,1045,1045,0,1024,1,5,1,4,2,1044,1,0,1045,1]

def active15847 : List Nat := [0,1,2,3,9]

def tree15847 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15847 : H12WitnessSearch.Good tree15847 := H12GlobalWitnessIndex.good

theorem leafIdentity15847 : H12AffineFastState.composeSystem env15847 rootObs = leafEnv15847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15847 rootObs == leafEnv15847) = true)

theorem terminalChecked15847 : H12PackedTerminal.terminalCheckFast leafEnv15847 active15847 tree15847 = true := by decide +kernel

def env15848 : List Nat := [2,4,8,16,32,17,9,256,0,1024,2048,1296,2088,1297,1,263,1296,0,1024,0,1296,2308,16,2,2089,17,2049,1296,1296,1,1285,2308,256,33,1297,0]

theorem envBound15848 : H12AffineFastState.Bounded env15848 := by
  intro p hp
  have h : env15848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15842_15848 : H12AffineEnvironment.transform 6 9 env15842 = env15848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env15842 == env15848) = true)

theorem identity15848 : scanCanonicalize (H12AffineFastState.compose env15848 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound15848 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15849 : List Nat := [2,4,8,16,32,17,9,256,0,1024,32,1296,8,1297,1,263,1296,0,1024,0,1296,292,16,2,9,17,33,1296,1296,1,1285,292,256,33,1297,0]

theorem envBound15849 : H12AffineFastState.Bounded env15849 := by
  intro p hp
  have h : env15849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15848_15849 : H12AffineEnvironment.transform 10 32 env15848 = env15849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env15848 == env15849) = true)

def env15850 : List Nat := [2,4,8,16,0,17,9,256,0,1024,0,1296,8,1297,1,263,1296,0,1024,0,1296,260,16,2,9,17,1,1296,1296,1,1285,260,256,1,1297,0]

theorem envBound15850 : H12AffineFastState.Bounded env15850 := by
  intro p hp
  have h : env15850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15849_15850 : H12AffineEnvironment.transform 4 0 env15849 = env15850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15849 == env15850) = true)

def leafEnv15850 : List Nat := [2,4,8,16,0,17,9,256,0,1024,0,1296,8,1297,1,263,1296,0,1024,0,1296,260,16,2,1285,9,1,17,1,1296,1296,1,1285,260,256,1,4,263,1297,0,0,1296,1]

def active15850 : List Nat := [0,1,2,3,7,9]

def tree15850 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15850 : H12WitnessSearch.Good tree15850 := H12GlobalWitnessIndex.good

theorem leafIdentity15850 : H12AffineFastState.composeSystem env15850 rootObs = leafEnv15850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15850 rootObs == leafEnv15850) = true)

theorem terminalChecked15850 : H12PackedTerminal.terminalCheckFast leafEnv15850 active15850 tree15850 = true := by decide +kernel

def env15851 : List Nat := [2,4,8,16,1,17,9,256,0,1024,1,1296,8,1297,1,263,1296,0,1024,0,1296,261,16,2,9,17,0,1296,1296,1,1285,261,256,0,1297,0]

theorem envBound15851 : H12AffineFastState.Bounded env15851 := by
  intro p hp
  have h : env15851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15849_15851 : H12AffineEnvironment.transform 4 1 env15849 = env15851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env15849 == env15851) = true)

theorem identity15851 : scanCanonicalize (H12AffineFastState.compose env15851 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound15851 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15852 : List Nat := [2,4,8,16,1,17,9,5,0,1024,1,1045,8,1044,1,2,1045,0,1024,0,1045,0,16,2,9,17,0,1045,1045,1,1024,0,5,0,1044,0]

theorem envBound15852 : H12AffineFastState.Bounded env15852 := by
  intro p hp
  have h : env15852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15851_15852 : H12AffineEnvironment.transform 7 5 env15851 = env15852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env15851 == env15852) = true)

def leafEnv15852 : List Nat := [2,4,8,16,1,17,9,5,0,1024,1,1045,8,1044,1,2,1045,0,1024,0,1045,0,16,2,1024,9,1,17,0,1045,1045,1,1024,0,5,0,4,2,1044,0,0,1045,1]

def active15852 : List Nat := [0,1,2,3,9]

def tree15852 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15852 : H12WitnessSearch.Good tree15852 := H12GlobalWitnessIndex.good

theorem leafIdentity15852 : H12AffineFastState.composeSystem env15852 rootObs = leafEnv15852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15852 rootObs == leafEnv15852) = true)

theorem terminalChecked15852 : H12PackedTerminal.terminalCheckFast leafEnv15852 active15852 tree15852 = true := by decide +kernel

def env15853 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,65536,1345,513,1024,32769,1345,4194304,16,98564,8328,64,134217728,1296,1296,1073741824,1285,4294967296,256,4299260334,138413636,512]

theorem envBound15853 : H12AffineFastState.Bounded env15853 := by
  intro p hp
  have h : env15853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15819_15853 : H12AffineEnvironment.transform 17 513 env15819 = env15853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 513 env15819 == env15853) = true)

theorem identity15853 : scanCanonicalize (H12AffineFastState.compose env15853 (packedSelected [3,5,24] rootPS)) = affineNative (2^(26+1) ^^^ 4227844) := by decide +kernel

theorem selectedBound15853 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env15854 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,65536,1345,513,1024,32769,1345,4194304,16,98564,8328,64,4227844,1296,1296,1073741824,1285,4294967296,256,4299260334,34112,512]

theorem envBound15854 : H12AffineFastState.Bounded env15854 := by
  intro p hp
  have h : env15854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15853_15854 : H12AffineEnvironment.transform 26 4227844 env15853 = env15854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 4227844 env15853 == env15854) = true)

theorem identity15854 : scanCanonicalize (H12AffineFastState.compose env15854 (packedSelected [1,8,28] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound15854 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env15855 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,0,65536,1345,513,1024,1,1345,4194304,16,65796,8328,64,4195076,1296,1296,1073741824,1285,4294967296,256,4299227566,1344,512]

theorem envBound15855 : H12AffineFastState.Bounded env15855 := by
  intro p hp
  have h : env15855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15854_15855 : H12AffineEnvironment.transform 14 0 env15854 = env15855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env15854 == env15855) = true)

theorem identity15855 : scanCanonicalize (H12AffineFastState.compose env15855 (packedSelected [1,12,13] rootPS)) = affineNative (2^(15+1) ^^^ 399) := by decide +kernel

theorem selectedBound15855 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env15856 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,0,399,1345,513,1024,1,1345,4194304,16,139,8328,64,4195076,1296,1296,1073741824,1285,4294967296,256,4299161633,1344,512]

theorem envBound15856 : H12AffineFastState.Bounded env15856 := by
  intro p hp
  have h : env15856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15855_15856 : H12AffineEnvironment.transform 15 399 env15855 = env15856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 399 env15855 == env15856) = true)

theorem identity15856 : scanCanonicalize (H12AffineFastState.compose env15856 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(29+1) ^^^ 4203309) := by decide +kernel

theorem selectedBound15856 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env15857 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,0,399,1345,513,1024,1,1345,4194304,16,139,8328,64,4195076,1296,1296,4203309,1285,4294967296,256,4299161633,1344,512]

theorem envBound15857 : H12AffineFastState.Bounded env15857 := by
  intro p hp
  have h : env15857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15856_15857 : H12AffineEnvironment.transform 29 4203309 env15856 = env15857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4203309 env15856 == env15857) = true)

theorem identity15857 : scanCanonicalize (H12AffineFastState.compose env15857 (packedSelected [18,23] rootPS)) = affineNative (2^(12+1) ^^^ 2600) := by decide +kernel

theorem selectedBound15857 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env15858 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,2600,1297,0,399,1345,513,1024,1,1345,4194304,16,139,2720,64,4195076,1296,1296,4196613,1285,4294967296,256,4299161633,1344,512]

theorem envBound15858 : H12AffineFastState.Bounded env15858 := by
  intro p hp
  have h : env15858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15857_15858 : H12AffineEnvironment.transform 12 2600 env15857 = env15858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2600 env15857 == env15858) = true)

def env15859 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,2600,1297,0,399,1297,513,1024,1,1297,4194304,16,139,2720,16,4195076,1296,1296,4196613,1285,4294967296,256,4299161633,1296,512]

theorem envBound15859 : H12AffineFastState.Bounded env15859 := by
  intro p hp
  have h : env15859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15858_15859 : H12AffineEnvironment.transform 5 16 env15858 = env15859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env15858 == env15859) = true)

theorem identity15859 : scanCanonicalize (H12AffineFastState.compose env15859 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 2080) := by decide +kernel

theorem selectedBound15859 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15860 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,2600,1297,0,399,1297,513,1024,1,1297,4194304,16,139,2720,16,4195076,1296,1296,4196613,1285,2080,256,4196353,1296,512]

theorem envBound15860 : H12AffineFastState.Bounded env15860 := by
  intro p hp
  have h : env15860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15859_15860 : H12AffineEnvironment.transform 31 2080 env15859 = env15860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 2080 env15859 == env15860) = true)

theorem identity15860 : scanCanonicalize (H12AffineFastState.compose env15860 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound15860 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env15861 : List Nat := [2,4,8,16,32,16,128,256,512,1024,512,1297,40,1297,0,399,1297,513,1024,1,1297,4194304,16,139,160,16,4195076,1296,1296,4195077,1285,544,256,4194817,1296,512]

theorem envBound15861 : H12AffineFastState.Bounded env15861 := by
  intro p hp
  have h : env15861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15860_15861 : H12AffineEnvironment.transform 10 512 env15860 = env15861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env15860 == env15861) = true)

theorem identity15861 : scanCanonicalize (H12AffineFastState.compose env15861 (packedSelected [0,7] rootPS)) = affineNative (2^(21+1) ^^^ 260) := by decide +kernel

theorem selectedBound15861 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env15862 : List Nat := [2,4,8,16,32,16,128,256,512,1024,512,1297,40,1297,0,399,1297,513,1024,1,1297,260,16,139,160,16,512,1296,1296,513,1285,544,256,773,1296,512]

theorem envBound15862 : H12AffineFastState.Bounded env15862 := by
  intro p hp
  have h : env15862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15861_15862 : H12AffineEnvironment.transform 21 260 env15861 = env15862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 260 env15861 == env15862) = true)

theorem identity15862 : scanCanonicalize (H12AffineFastState.compose env15862 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound15862 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env15863 : List Nat := [2,4,8,16,32,16,128,256,293,1024,293,1297,40,1297,0,399,1297,292,1024,1,1297,260,16,139,160,16,293,1296,1296,292,1285,261,256,32,1296,293]

theorem envBound15863 : H12AffineFastState.Bounded env15863 := by
  intro p hp
  have h : env15863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15862_15863 : H12AffineEnvironment.transform 8 293 env15862 = env15863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env15862 == env15863) = true)

theorem identity15863 : scanCanonicalize (H12AffineFastState.compose env15863 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound15863 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15864 : List Nat := [2,4,8,16,0,16,128,256,261,1024,261,1297,8,1297,0,399,1297,260,1024,1,1297,260,16,139,128,16,261,1296,1296,260,1285,261,256,0,1296,261]

theorem envBound15864 : H12AffineFastState.Bounded env15864 := by
  intro p hp
  have h : env15864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15863_15864 : H12AffineEnvironment.transform 4 0 env15863 = env15864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15863 == env15864) = true)

def env15865 : List Nat := [2,4,8,16,0,16,8,256,261,1024,261,1297,8,1297,0,263,1297,260,1024,1,1297,260,16,3,8,16,261,1296,1296,260,1285,261,256,0,1296,261]

theorem envBound15865 : H12AffineFastState.Bounded env15865 := by
  intro p hp
  have h : env15865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15864_15865 : H12AffineEnvironment.transform 6 8 env15864 = env15865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env15864 == env15865) = true)

theorem identity15865 : scanCanonicalize (H12AffineFastState.compose env15865 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound15865 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env15866 : List Nat := [2,4,8,16,0,16,8,4,1,1024,1,1045,8,1045,0,3,1045,0,1024,1,1045,0,16,3,8,16,1,1044,1044,0,1025,1,4,0,1044,1]

theorem envBound15866 : H12AffineFastState.Bounded env15866 := by
  intro p hp
  have h : env15866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15865_15866 : H12AffineEnvironment.transform 7 4 env15865 = env15866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env15865 == env15866) = true)

def leafEnv15866 : List Nat := [2,4,8,16,0,16,8,4,1,1024,1,1045,8,1045,0,3,1045,0,1024,1,1045,0,16,3,1025,8,1,16,1,1044,1044,0,1025,1,4,0,4,2,1044,1,0,1044,1]

def active15866 : List Nat := [0,1,2,3,9]

def tree15866 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15866 : H12WitnessSearch.Good tree15866 := H12GlobalWitnessIndex.good

theorem leafIdentity15866 : H12AffineFastState.composeSystem env15866 rootObs = leafEnv15866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15866 rootObs == leafEnv15866) = true)

theorem terminalChecked15866 : H12PackedTerminal.terminalCheckFast leafEnv15866 active15866 tree15866 = true := by decide +kernel

def env15867 : List Nat := [2,4,8,16,0,16,9,256,261,1024,261,1297,8,1297,0,262,1297,260,1024,1,1297,260,16,2,9,16,261,1296,1296,260,1285,261,256,0,1296,261]

theorem envBound15867 : H12AffineFastState.Bounded env15867 := by
  intro p hp
  have h : env15867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15864_15867 : H12AffineEnvironment.transform 6 9 env15864 = env15867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env15864 == env15867) = true)

def env15868 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,2600,1297,0,399,1296,513,1024,1,1296,4194304,16,139,2720,17,4195076,1296,1296,4196613,1285,4294967296,256,4299161633,1297,512]

theorem envBound15868 : H12AffineFastState.Bounded env15868 := by
  intro p hp
  have h : env15868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15858_15868 : H12AffineEnvironment.transform 5 17 env15858 = env15868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env15858 == env15868) = true)

theorem identity15868 : scanCanonicalize (H12AffineFastState.compose env15868 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 4194441) := by decide +kernel

theorem selectedBound15868 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15869 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,2600,1297,0,399,1296,513,1024,1,1296,4194304,16,139,2720,17,4195076,1296,1296,4196613,1285,4194441,256,168,1297,512]

theorem envBound15869 : H12AffineFastState.Bounded env15869 := by
  intro p hp
  have h : env15869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15868_15869 : H12AffineEnvironment.transform 31 4194441 env15868 = env15869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 4194441 env15868 == env15869) = true)

theorem identity15869 : scanCanonicalize (H12AffineFastState.compose env15869 (packedSelected [3] rootPS)) = affineNative (2^(21+1) ^^^ 2821) := by decide +kernel

theorem selectedBound15869 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env15870 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,2600,1297,0,399,1296,513,1024,1,1296,2821,16,139,2720,17,2049,1296,1296,512,1285,2956,256,168,1297,512]

theorem envBound15870 : H12AffineFastState.Bounded env15870 := by
  intro p hp
  have h : env15870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15869_15870 : H12AffineEnvironment.transform 21 2821 env15869 = env15870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2821 env15869 == env15870) = true)

theorem identity15870 : scanCanonicalize (H12AffineFastState.compose env15870 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound15870 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env15871 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,1296,2209,1297,0,399,1296,136,1024,1,1296,2444,16,139,2089,17,2049,1296,1296,137,1285,2309,256,168,1297,137]

theorem envBound15871 : H12AffineFastState.Bounded env15871 := by
  intro p hp
  have h : env15871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15870_15871 : H12AffineEnvironment.transform 8 137 env15870 = env15871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env15870 == env15871) = true)

def env15872 : List Nat := [2,4,8,16,32,17,8,256,1,1024,2048,1296,2089,1297,0,263,1296,0,1024,1,1296,2308,16,3,2089,17,2049,1296,1296,1,1285,2309,256,32,1297,1]

theorem envBound15872 : H12AffineFastState.Bounded env15872 := by
  intro p hp
  have h : env15872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15871_15872 : H12AffineEnvironment.transform 6 8 env15871 = env15872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env15871 == env15872) = true)

theorem identity15872 : scanCanonicalize (H12AffineFastState.compose env15872 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 260) := by decide +kernel

theorem selectedBound15872 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15873 : List Nat := [2,4,8,16,32,17,8,256,1,1024,260,1296,301,1297,0,263,1296,0,1024,1,1296,0,16,3,301,17,261,1296,1296,1,1285,1,256,32,1297,1]

theorem envBound15873 : H12AffineFastState.Bounded env15873 := by
  intro p hp
  have h : env15873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15872_15873 : H12AffineEnvironment.transform 10 260 env15872 = env15873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env15872 == env15873) = true)

def env15874 : List Nat := [2,4,8,16,0,17,8,256,1,1024,260,1296,269,1297,0,263,1296,0,1024,1,1296,0,16,3,269,17,261,1296,1296,1,1285,1,256,0,1297,1]

theorem envBound15874 : H12AffineFastState.Bounded env15874 := by
  intro p hp
  have h : env15874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15873_15874 : H12AffineEnvironment.transform 4 0 env15873 = env15874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15873 == env15874) = true)

def env15875 : List Nat := [2,4,8,16,1,17,8,256,1,1024,260,1296,268,1297,0,263,1296,0,1024,1,1296,0,16,3,268,17,261,1296,1296,1,1285,1,256,1,1297,1]

theorem envBound15875 : H12AffineFastState.Bounded env15875 := by
  intro p hp
  have h : env15875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15873_15875 : H12AffineEnvironment.transform 4 1 env15873 = env15875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env15873 == env15875) = true)

theorem identity15875 : scanCanonicalize (H12AffineFastState.compose env15875 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound15875 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15876 : List Nat := [2,4,8,16,1,17,8,5,1,1024,1,1045,9,1044,0,2,1045,0,1024,1,1045,0,16,3,9,17,0,1045,1045,1,1024,1,5,1,1044,1]

theorem envBound15876 : H12AffineFastState.Bounded env15876 := by
  intro p hp
  have h : env15876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15875_15876 : H12AffineEnvironment.transform 7 5 env15875 = env15876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env15875 == env15876) = true)

def leafEnv15876 : List Nat := [2,4,8,16,1,17,8,5,1,1024,1,1045,9,1044,0,2,1045,0,1024,1,1045,0,16,3,1024,9,1,17,0,1045,1045,1,1024,1,5,1,4,3,1044,1,0,1045,1]

def active15876 : List Nat := [0,1,2,3,9]

def tree15876 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15876 : H12WitnessSearch.Good tree15876 := H12GlobalWitnessIndex.good

theorem leafIdentity15876 : H12AffineFastState.composeSystem env15876 rootObs = leafEnv15876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15876 rootObs == leafEnv15876) = true)

theorem terminalChecked15876 : H12PackedTerminal.terminalCheckFast leafEnv15876 active15876 tree15876 = true := by decide +kernel

def env15877 : List Nat := [2,4,8,16,32,17,9,256,0,1024,2048,1296,2088,1297,0,262,1296,1,1024,1,1296,2309,16,2,2089,17,2049,1296,1296,0,1285,2309,256,33,1297,0]

theorem envBound15877 : H12AffineFastState.Bounded env15877 := by
  intro p hp
  have h : env15877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15871_15877 : H12AffineEnvironment.transform 6 9 env15871 = env15877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env15871 == env15877) = true)

theorem identity15877 : scanCanonicalize (H12AffineFastState.compose env15877 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound15877 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15878 : List Nat := [2,4,8,16,32,17,9,256,0,1024,33,1296,9,1297,0,262,1296,1,1024,1,1296,292,16,2,8,17,32,1296,1296,0,1285,292,256,33,1297,0]

theorem envBound15878 : H12AffineFastState.Bounded env15878 := by
  intro p hp
  have h : env15878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15877_15878 : H12AffineEnvironment.transform 10 33 env15877 = env15878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env15877 == env15878) = true)

def env15879 : List Nat := [2,4,8,16,0,17,9,256,0,1024,1,1296,9,1297,0,262,1296,1,1024,1,1296,260,16,2,8,17,0,1296,1296,0,1285,260,256,1,1297,0]

theorem envBound15879 : H12AffineFastState.Bounded env15879 := by
  intro p hp
  have h : env15879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15878_15879 : H12AffineEnvironment.transform 4 0 env15878 = env15879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15878 == env15879) = true)

def leafEnv15879 : List Nat := [2,4,8,16,0,17,9,256,0,1024,1,1296,9,1297,0,262,1296,1,1024,1,1296,260,16,2,1285,8,1,17,0,1296,1296,0,1285,260,256,1,4,262,1297,0,0,1296,1]

def active15879 : List Nat := [0,1,2,3,7,9]

def tree15879 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15879 : H12WitnessSearch.Good tree15879 := H12GlobalWitnessIndex.good

theorem leafIdentity15879 : H12AffineFastState.composeSystem env15879 rootObs = leafEnv15879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15879 rootObs == leafEnv15879) = true)

theorem terminalChecked15879 : H12PackedTerminal.terminalCheckFast leafEnv15879 active15879 tree15879 = true := by decide +kernel

def env15880 : List Nat := [2,4,8,16,1,17,9,256,0,1024,0,1296,9,1297,0,262,1296,1,1024,1,1296,261,16,2,8,17,1,1296,1296,0,1285,261,256,0,1297,0]

theorem envBound15880 : H12AffineFastState.Bounded env15880 := by
  intro p hp
  have h : env15880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15878_15880 : H12AffineEnvironment.transform 4 1 env15878 = env15880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env15878 == env15880) = true)

theorem identity15880 : scanCanonicalize (H12AffineFastState.compose env15880 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound15880 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15881 : List Nat := [2,4,8,16,1,17,9,5,0,1024,0,1045,9,1044,0,3,1045,1,1024,1,1045,0,16,2,8,17,1,1045,1045,0,1024,0,5,0,1044,0]

theorem envBound15881 : H12AffineFastState.Bounded env15881 := by
  intro p hp
  have h : env15881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15880_15881 : H12AffineEnvironment.transform 7 5 env15880 = env15881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env15880 == env15881) = true)

def leafEnv15881 : List Nat := [2,4,8,16,1,17,9,5,0,1024,0,1045,9,1044,0,3,1045,1,1024,1,1045,0,16,2,1024,8,1,17,1,1045,1045,0,1024,0,5,0,4,3,1044,0,0,1045,1]

def active15881 : List Nat := [0,1,2,3,9]

def tree15881 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15881 : H12WitnessSearch.Good tree15881 := H12GlobalWitnessIndex.good

theorem leafIdentity15881 : H12AffineFastState.composeSystem env15881 rootObs = leafEnv15881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15881 rootObs == leafEnv15881) = true)

theorem terminalChecked15881 : H12PackedTerminal.terminalCheckFast leafEnv15881 active15881 tree15881 = true := by decide +kernel

def env15882 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,4194304,8388608,16777216,8328,8914000,134217728,8519745,676864,1073741824,25412672,4294967296,8536385,4315938986,164610305,512]

theorem envBound15882 : H12AffineFastState.Bounded env15882 := by
  intro p hp
  have h : env15882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15717_15882 : H12AffineEnvironment.transform 20 4097 env15717 = env15882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env15717 == env15882) = true)

theorem identity15882 : scanCanonicalize (H12AffineFastState.compose env15882 (packedSelected [14] rootPS)) = affineNative (2^(26+1) ^^^ 12850260) := by decide +kernel

theorem selectedBound15882 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env15883 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,4194304,8388608,16777216,8328,8914000,12850260,8519745,676864,1073741824,25412672,4294967296,8536385,4315938986,17552725,512]

theorem envBound15883 : H12AffineFastState.Bounded env15883 := by
  intro p hp
  have h : env15883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15882_15883 : H12AffineEnvironment.transform 26 12850260 env15882 = env15883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 12850260 env15882 == env15883) = true)

def env15884 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,4194304,17664,16777216,8328,541008,4477268,148801,676864,1073741824,17006912,4294967296,132161,4315938986,17552725,512]

theorem envBound15884 : H12AffineFastState.Bounded env15884 := by
  intro p hp
  have h : env15884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15883_15884 : H12AffineEnvironment.transform 22 17664 env15883 = env15884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17664 env15883 == env15884) = true)

def env15885 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,524288,32769,4097,4194304,17664,16777216,8328,541008,4477268,16385,545088,1073741824,16876544,4294967296,257,4315938986,17420309,512]

theorem envBound15885 : H12AffineFastState.Bounded env15885 := by
  intro p hp
  have h : env15885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15884_15885 : H12AffineEnvironment.transform 16 1344 env15884 = env15885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env15884 == env15885) = true)

theorem identity15885 : scanCanonicalize (H12AffineFastState.compose env15885 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(23+1) ^^^ 644437) := by decide +kernel

theorem selectedBound15885 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env15886 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,524288,32769,4097,4194304,17664,644437,8328,541008,4477268,16385,545088,1073741824,545109,4294967296,257,4299806207,1344,512]

theorem envBound15886 : H12AffineFastState.Bounded env15886 := by
  intro p hp
  have h : env15886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15885_15886 : H12AffineEnvironment.transform 23 644437 env15885 = env15886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 644437 env15885 == env15886) = true)

theorem identity15886 : scanCanonicalize (H12AffineFastState.compose env15886 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(18+1) ^^^ 1025) := by decide +kernel

theorem selectedBound15886 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env15887 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,1025,32769,4097,4194304,17664,119124,8328,17745,4477268,16385,21825,1073741824,21844,4294967296,257,4299280894,1344,512]

theorem envBound15887 : H12AffineFastState.Bounded env15887 := by
  intro p hp
  have h : env15887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15886_15887 : H12AffineEnvironment.transform 18 1025 env15886 = env15887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env15886 == env15887) = true)

def env15888 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4096,32768,65536,1344,262144,1025,32769,4097,4194304,5376,98644,8328,5457,4456788,4097,1345,1073741824,1364,4294967296,257,4299260414,1344,512]

theorem envBound15888 : H12AffineFastState.Bounded env15888 := by
  intro p hp
  have h : env15888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15887_15888 : H12AffineEnvironment.transform 13 4096 env15887 = env15888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4096 env15887 == env15888) = true)

theorem identity15888 : scanCanonicalize (H12AffineFastState.compose env15888 (packedSelected [0,7,20] rootPS)) = affineNative (2^(11+1) ^^^ 1344) := by decide +kernel

theorem selectedBound15888 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env15889 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,32768,65536,1344,262144,1025,32769,1345,4194304,64,98644,8328,17,4456788,1345,1345,1073741824,1364,4294967296,257,4299260414,1344,512]

theorem envBound15889 : H12AffineFastState.Bounded env15889 := by
  intro p hp
  have h : env15889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15888_15889 : H12AffineEnvironment.transform 11 1344 env15888 = env15889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env15888 == env15889) = true)

theorem identity15889 : scanCanonicalize (H12AffineFastState.compose env15889 (packedSelected [12,13,15,17,38,41] rootPS)) = affineNative (2^(31+1) ^^^ 73771) := by decide +kernel

theorem selectedBound15889 : packedSelected [12,13,15,17,38,41] rootPS < 2^1333 := by decide +kernel

def env15890 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,32768,65536,1344,262144,1025,32769,1345,4194304,64,98644,8328,17,4456788,1345,1345,1073741824,1364,73771,257,4235733,1344,512]

theorem envBound15890 : H12AffineFastState.Bounded env15890 := by
  intro p hp
  have h : env15890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15889_15890 : H12AffineEnvironment.transform 31 73771 env15889 = env15890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 73771 env15889 == env15890) = true)

def env15891 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1296,32768,65536,1296,262144,1025,32769,1297,4194304,16,98564,8328,17,4456708,1297,1297,1073741824,1284,73771,257,4235653,1296,512]

theorem envBound15891 : H12AffineFastState.Bounded env15891 := by
  intro p hp
  have h : env15891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15890_15891 : H12AffineEnvironment.transform 5 16 env15890 = env15891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env15890 == env15891) = true)

theorem identity15891 : scanCanonicalize (H12AffineFastState.compose env15891 (packedSelected [1,3,5] rootPS)) = affineNative (2^(29+1) ^^^ 370980) := by decide +kernel

theorem selectedBound15891 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env15892 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1296,32768,65536,1296,262144,1025,32769,1297,4194304,16,98564,8328,17,4456708,1297,1297,370980,1284,73771,257,4235653,1296,512]

theorem envBound15892 : H12AffineFastState.Bounded env15892 := by
  intro p hp
  have h : env15892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15891_15892 : H12AffineEnvironment.transform 29 370980 env15891 = env15892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 370980 env15891 == env15892) = true)

theorem identity15892 : scanCanonicalize (H12AffineFastState.compose env15892 (packedSelected [1,3,8] rootPS)) = affineNative (2^(14+1) ^^^ 9093) := by decide +kernel

theorem selectedBound15892 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env15893 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1296,9093,65536,1296,262144,1025,9092,1297,4194304,16,74369,8328,17,4456708,1297,1297,330401,1284,73771,257,4194816,1296,512]

theorem envBound15893 : H12AffineFastState.Bounded env15893 := by
  intro p hp
  have h : env15893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15892_15893 : H12AffineEnvironment.transform 14 9093 env15892 = env15893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9093 env15892 == env15893) = true)

theorem identity15893 : scanCanonicalize (H12AffineFastState.compose env15893 (packedSelected [1,12,13] rootPS)) = affineNative (2^(17+1) ^^^ 2340) := by decide +kernel

theorem selectedBound15893 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env15894 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1296,9093,65536,1296,2340,1025,9092,1297,4194304,16,74369,8328,17,4196384,1297,1297,66437,1284,73771,257,4194816,1296,512]

theorem envBound15894 : H12AffineFastState.Bounded env15894 := by
  intro p hp
  have h : env15894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15893_15894 : H12AffineEnvironment.transform 17 2340 env15893 = env15894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2340 env15893 == env15894) = true)

theorem identity15894 : scanCanonicalize (H12AffineFastState.compose env15894 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 8714) := by decide +kernel

theorem selectedBound15894 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env15895 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1296,9093,8714,1296,2340,1025,9092,1297,4194304,16,139,8328,17,4196384,1297,1297,8591,1284,545,257,4194816,1296,512]

theorem envBound15895 : H12AffineFastState.Bounded env15895 := by
  intro p hp
  have h : env15895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15894_15895 : H12AffineEnvironment.transform 15 8714 env15894 = env15895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8714 env15894 == env15895) = true)

theorem identity15895 : scanCanonicalize (H12AffineFastState.compose env15895 (packedSelected [1,12] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound15895 : packedSelected [1,12] rootPS < 2^1333 := by decide +kernel

def env15896 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,269,1296,648,775,1296,2340,1025,649,1297,4194304,16,139,389,17,4196384,1297,1297,130,1284,545,257,4194816,1296,512]

theorem envBound15896 : H12AffineFastState.Bounded env15896 := by
  intro p hp
  have h : env15896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15895_15896 : H12AffineEnvironment.transform 12 269 env15895 = env15896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env15895 == env15896) = true)

theorem identity15896 : scanCanonicalize (H12AffineFastState.compose env15896 (packedSelected [21] rootPS)) = affineNative (2^(10+1) ^^^ 814) := by decide +kernel

theorem selectedBound15896 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env15897 : List Nat := [2,4,8,16,32,16,128,256,512,1024,814,1296,269,1296,648,775,1296,522,1025,649,1297,4194304,16,139,389,17,4195086,1297,1297,130,1284,545,257,4194816,1296,512]

theorem envBound15897 : H12AffineFastState.Bounded env15897 := by
  intro p hp
  have h : env15897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15896_15897 : H12AffineEnvironment.transform 10 814 env15896 = env15897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 814 env15896 == env15897) = true)

theorem identity15897 : scanCanonicalize (H12AffineFastState.compose env15897 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 1329) := by decide +kernel

theorem selectedBound15897 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env15898 : List Nat := [2,4,8,16,32,16,128,256,512,1024,814,1296,269,1296,648,775,1296,522,1025,649,1297,1329,16,139,389,17,1599,1297,1297,130,1284,545,257,1841,1296,512]

theorem envBound15898 : H12AffineFastState.Bounded env15898 := by
  intro p hp
  have h : env15898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15897_15898 : H12AffineEnvironment.transform 21 1329 env15897 = env15898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 1329 env15897 == env15898) = true)

theorem identity15898 : scanCanonicalize (H12AffineFastState.compose env15898 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 921) := by decide +kernel

theorem selectedBound15898 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15899 : List Nat := [2,4,8,16,32,16,128,256,512,921,814,649,269,649,648,775,649,522,920,649,648,680,16,139,389,17,422,648,648,130,669,545,257,168,649,512]

theorem envBound15899 : H12AffineFastState.Bounded env15899 := by
  intro p hp
  have h : env15899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15898_15899 : H12AffineEnvironment.transform 9 921 env15898 = env15899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 921 env15898 == env15899) = true)

theorem identity15899 : scanCanonicalize (H12AffineFastState.compose env15899 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound15899 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env15900 : List Nat := [2,4,8,16,32,16,128,256,137,272,423,0,269,0,1,398,0,131,273,0,1,33,16,139,389,17,422,1,1,130,20,168,257,168,0,137]

theorem envBound15900 : H12AffineFastState.Bounded env15900 := by
  intro p hp
  have h : env15900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15899_15900 : H12AffineEnvironment.transform 8 137 env15899 = env15900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env15899 == env15900) = true)

theorem identity15900 : scanCanonicalize (H12AffineFastState.compose env15900 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound15900 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15901 : List Nat := [2,4,8,16,32,16,128,21,137,5,178,0,24,0,1,155,0,131,4,0,1,33,16,139,144,17,179,1,1,130,20,168,20,168,0,137]

theorem envBound15901 : H12AffineFastState.Bounded env15901 := by
  intro p hp
  have h : env15901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15900_15901 : H12AffineEnvironment.transform 7 21 env15900 = env15901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env15900 == env15901) = true)

def env15902 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1297,32768,65536,1297,262144,1025,32769,1296,4194304,17,98565,8328,17,4456709,1296,1296,1073741824,1285,73771,257,4235652,1297,512]

theorem envBound15902 : H12AffineFastState.Bounded env15902 := by
  intro p hp
  have h : env15902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15890_15902 : H12AffineEnvironment.transform 5 17 env15890 = env15902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env15890 == env15902) = true)

theorem identity15902 : scanCanonicalize (H12AffineFastState.compose env15902 (packedSelected [1,3,5] rootPS)) = affineNative (2^(29+1) ^^^ 264328) := by decide +kernel

theorem selectedBound15902 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env15903 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1297,32768,65536,1297,262144,1025,32769,1296,4194304,17,98565,8328,17,4456709,1296,1296,264328,1285,73771,257,4235652,1297,512]

theorem envBound15903 : H12AffineFastState.Bounded env15903 := by
  intro p hp
  have h : env15903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15902_15903 : H12AffineEnvironment.transform 29 264328 env15902 = env15903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 264328 env15902 == env15903) = true)

theorem identity15903 : scanCanonicalize (H12AffineFastState.compose env15903 (packedSelected [1,3,8] rootPS)) = affineNative (2^(14+1) ^^^ 8972) := by decide +kernel

theorem selectedBound15903 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env15904 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1297,8972,65536,1297,262144,1025,8973,1296,4194304,17,74249,8328,17,4456709,1296,1296,264328,1285,73771,257,4194952,1297,512]

theorem envBound15904 : H12AffineFastState.Bounded env15904 := by
  intro p hp
  have h : env15904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15903_15904 : H12AffineEnvironment.transform 14 8972 env15903 = env15904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8972 env15903 == env15904) = true)

theorem identity15904 : scanCanonicalize (H12AffineFastState.compose env15904 (packedSelected [1,12,13] rootPS)) = affineNative (2^(17+1) ^^^ 65570) := by decide +kernel

theorem selectedBound15904 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env15905 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1297,8972,65536,1297,65570,1025,8973,1296,4194304,17,74249,8328,17,4260135,1296,1296,67754,1285,73771,257,4194952,1297,512]

theorem envBound15905 : H12AffineFastState.Bounded env15905 := by
  intro p hp
  have h : env15905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15904_15905 : H12AffineEnvironment.transform 17 65570 env15904 = env15905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65570 env15904 == env15905) = true)

theorem identity15905 : scanCanonicalize (H12AffineFastState.compose env15905 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(21+1) ^^^ 74631) := by decide +kernel

theorem selectedBound15905 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env15906 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1297,8972,65536,1297,65570,1025,8973,1296,74631,17,74249,8328,17,8864,1296,1296,67754,1285,73771,257,73999,1297,512]

theorem envBound15906 : H12AffineFastState.Bounded env15906 := by
  intro p hp
  have h : env15906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15905_15906 : H12AffineEnvironment.transform 21 74631 env15905 = env15906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 74631 env15905 == env15906) = true)

theorem identity15906 : scanCanonicalize (H12AffineFastState.compose env15906 (packedSelected [1,12,17] rootPS)) = affineNative (2^(12+1) ^^^ 552) := by decide +kernel

theorem selectedBound15906 : packedSelected [1,12,17] rootPS < 2^1333 := by decide +kernel

def env15907 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,552,1297,292,65536,1297,65570,1025,293,1296,65967,17,65569,672,17,136,1296,1296,67754,1285,66051,257,66343,1297,512]

theorem envBound15907 : H12AffineFastState.Bounded env15907 := by
  intro p hp
  have h : env15907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15906_15907 : H12AffineEnvironment.transform 12 552 env15906 = env15907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 552 env15906 == env15907) = true)

theorem identity15907 : scanCanonicalize (H12AffineFastState.compose env15907 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 940) := by decide +kernel

theorem selectedBound15907 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env15908 : List Nat := [2,4,8,16,32,17,128,256,512,1024,940,1297,552,1297,292,65536,1297,65570,1025,293,1296,65967,17,65569,672,17,136,1296,1296,66310,1285,66051,257,66343,1297,512]

theorem envBound15908 : H12AffineFastState.Bounded env15908 := by
  intro p hp
  have h : env15908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15907_15908 : H12AffineEnvironment.transform 10 940 env15907 = env15908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 940 env15907 == env15908) = true)

def env15909 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4097,32768,65536,1344,262144,1025,32769,4097,4194304,5377,98645,8328,5456,4456789,4096,1344,1073741824,1365,4294967296,257,4299260415,1344,512]

theorem envBound15909 : H12AffineFastState.Bounded env15909 := by
  intro p hp
  have h : env15909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15887_15909 : H12AffineEnvironment.transform 13 4097 env15887 = env15909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4097 env15887 == env15909) = true)

theorem identity15909 : scanCanonicalize (H12AffineFastState.compose env15909 (packedSelected [0,7,20] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound15909 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env15910 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1296,8192,1297,32768,65536,1344,262144,1025,32769,1297,4194304,17,98645,8328,64,4456789,1296,1344,1073741824,1365,4294967296,257,4299260415,1344,512]

theorem envBound15910 : H12AffineFastState.Bounded env15910 := by
  intro p hp
  have h : env15910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15909_15910 : H12AffineEnvironment.transform 11 1296 env15909 = env15910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env15909 == env15910) = true)

theorem identity15910 : scanCanonicalize (H12AffineFastState.compose env15910 (packedSelected [13,17] rootPS)) = affineNative (2^(31+1) ^^^ 1077979296) := by decide +kernel

theorem selectedBound15910 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env15911 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1296,8192,1297,32768,65536,1344,262144,1025,32769,1297,4194304,17,98645,8328,64,4456789,1296,1344,1073741824,1365,1077979296,257,1073817951,1344,512]

theorem envBound15911 : H12AffineFastState.Bounded env15911 := by
  intro p hp
  have h : env15911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15910_15911 : H12AffineEnvironment.transform 31 1077979296 env15910 = env15911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1077979296 env15910 == env15911) = true)

theorem identity15911 : scanCanonicalize (H12AffineFastState.compose env15911 (packedSelected [13,21] rootPS)) = affineNative (2^(29+1) ^^^ 43128) := by decide +kernel

theorem selectedBound15911 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env15912 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1296,8192,1297,32768,65536,1344,262144,1025,32769,1297,4194304,17,98645,8328,64,4456789,1296,1344,43128,1365,4194520,257,98599,1344,512]

theorem envBound15912 : H12AffineFastState.Bounded env15912 := by
  intro p hp
  have h : env15912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15911_15912 : H12AffineEnvironment.transform 29 43128 env15911 = env15912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 43128 env15911 == env15912) = true)

theorem identity15912 : scanCanonicalize (H12AffineFastState.compose env15912 (packedSelected [1,3,15,24,28,38] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

end H12CloudChart2