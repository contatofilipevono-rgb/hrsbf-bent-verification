import H12CloudChart2Data099

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env24534 : List Nat := [2,4,8,16,32,48,128,140,136,1024,2048,136,8,2049,1076,138,137,3093,1160,1077,3092,1213,152,1215,128,184,2216,32,33,3261,1024,1181,5,1076,2216,136]

theorem envBound24534 : H12AffineFastState.Bounded env24534 := by
  intro p hp
  have h : env24534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24533_24534 : H12AffineEnvironment.transform 11 136 env24533 = env24534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 136 env24533 == env24534) = true)

theorem identity24534 : scanCanonicalize (H12AffineFastState.compose env24534 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound24534 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24535 : List Nat := [2,4,8,16,26,10,128,140,136,1024,2048,136,8,2049,1038,138,137,3093,1160,1039,3092,1159,152,1157,128,130,2194,26,27,3207,1024,1181,5,1038,2194,136]

theorem envBound24535 : H12AffineFastState.Bounded env24535 := by
  intro p hp
  have h : env24535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24534_24535 : H12AffineEnvironment.transform 4 26 env24534 = env24535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env24534 == env24535) = true)

def env24536 : List Nat := [2,4,8,16,26,10,128,140,136,156,2048,136,8,2049,146,138,137,2185,20,147,2184,27,152,25,128,130,2194,26,27,2075,156,1,5,146,2194,136]

theorem envBound24536 : H12AffineFastState.Bounded env24536 := by
  intro p hp
  have h : env24536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24535_24536 : H12AffineEnvironment.transform 9 156 env24535 = env24536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 156 env24535 == env24536) = true)

theorem identity24536 : scanCanonicalize (H12AffineFastState.compose env24536 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound24536 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env24537 : List Nat := [2,4,8,16,26,10,18,30,26,14,2048,26,8,2049,0,24,27,2075,20,1,2074,27,10,25,18,16,2048,26,27,2075,14,1,5,0,2048,26]

theorem envBound24537 : H12AffineFastState.Bounded env24537 := by
  intro p hp
  have h : env24537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24536_24537 : H12AffineEnvironment.transform 6 18 env24536 = env24537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env24536 == env24537) = true)

def leafEnv24537 : List Nat := [2,4,8,16,26,10,18,30,26,14,2048,26,8,2049,0,24,27,2075,20,1,2074,27,10,25,20,18,1,16,2048,26,27,2075,14,1,5,0,31,3,2048,26,0,2075,1]

def active24537 : List Nat := [0,1,2,3,10]

def tree24537 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24537 : H12WitnessSearch.Good tree24537 := H12GlobalWitnessIndex.good

theorem leafIdentity24537 : H12AffineFastState.composeSystem env24537 rootObs = leafEnv24537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24537 rootObs == leafEnv24537) = true)

theorem terminalChecked24537 : H12PackedTerminal.terminalCheckFast leafEnv24537 active24537 tree24537 = true := by decide +kernel

def env24538 : List Nat := [2,4,8,16,26,10,128,140,136,157,2048,136,8,2049,147,138,137,2184,21,146,2185,26,152,24,128,130,2194,26,27,2074,157,0,5,147,2194,136]

theorem envBound24538 : H12AffineFastState.Bounded env24538 := by
  intro p hp
  have h : env24538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24535_24538 : H12AffineEnvironment.transform 9 157 env24535 = env24538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 157 env24535 == env24538) = true)

def leafEnv24538 : List Nat := [2,4,8,16,26,10,128,140,136,157,2048,136,8,2049,147,138,137,2184,21,146,2185,26,152,24,21,128,1,130,2194,26,27,2074,157,0,5,147,141,144,2194,136,0,2074,1]

def active24538 : List Nat := [0,1,2,3,6,10]

def tree24538 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24538 : H12WitnessSearch.Good tree24538 := H12GlobalWitnessIndex.good

theorem leafIdentity24538 : H12AffineFastState.composeSystem env24538 rootObs = leafEnv24538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24538 rootObs == leafEnv24538) = true)

theorem terminalChecked24538 : H12PackedTerminal.terminalCheckFast leafEnv24538 active24538 tree24538 = true := by decide +kernel

def env24539 : List Nat := [2,4,8,16,32,48,128,140,136,1024,2048,137,8,2048,1077,138,136,3092,1160,1076,3092,1212,152,1214,128,184,2216,33,32,3260,1024,1180,5,1077,2217,136]

theorem envBound24539 : H12AffineFastState.Bounded env24539 := by
  intro p hp
  have h : env24539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24533_24539 : H12AffineEnvironment.transform 11 137 env24533 = env24539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 137 env24533 == env24539) = true)

theorem identity24539 : scanCanonicalize (H12AffineFastState.compose env24539 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 14) := by decide +kernel

theorem selectedBound24539 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24540 : List Nat := [2,4,8,16,32,48,128,140,136,14,2048,137,8,2048,59,138,136,2074,134,58,2074,178,152,176,128,184,2216,33,32,2226,14,146,5,59,2217,136]

theorem envBound24540 : H12AffineFastState.Bounded env24540 := by
  intro p hp
  have h : env24540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24539_24540 : H12AffineEnvironment.transform 9 14 env24539 = env24540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 14 env24539 == env24540) = true)

def env24541 : List Nat := [2,4,8,16,32,48,40,36,32,14,2048,33,8,2048,59,34,32,2074,46,58,2074,26,48,24,40,16,2048,33,32,2074,14,58,5,59,2049,32]

theorem envBound24541 : H12AffineFastState.Bounded env24541 := by
  intro p hp
  have h : env24541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24540_24541 : H12AffineEnvironment.transform 6 40 env24540 = env24541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env24540 == env24541) = true)

def leafEnv24541 : List Nat := [2,4,8,16,32,48,40,36,32,14,2048,33,8,2048,59,34,32,2074,46,58,2074,26,48,24,46,40,1,16,2048,33,32,2074,14,58,5,59,37,56,2049,32,0,2075,1]

def active24541 : List Nat := [0,1,2,3,4,10]

def tree24541 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24541 : H12WitnessSearch.Good tree24541 := H12GlobalWitnessIndex.good

theorem leafIdentity24541 : H12AffineFastState.composeSystem env24541 rootObs = leafEnv24541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24541 rootObs == leafEnv24541) = true)

theorem terminalChecked24541 : H12PackedTerminal.terminalCheckFast leafEnv24541 active24541 tree24541 = true := by decide +kernel

def env24542 : List Nat := [2,4,8,16,32,48,41,37,33,14,2048,32,8,2048,59,35,33,2074,47,58,2074,27,49,25,41,17,2049,33,32,2075,14,59,5,59,2048,33]

theorem envBound24542 : H12AffineFastState.Bounded env24542 := by
  intro p hp
  have h : env24542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24540_24542 : H12AffineEnvironment.transform 6 41 env24540 = env24542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env24540 == env24542) = true)

theorem identity24542 : scanCanonicalize (H12AffineFastState.compose env24542 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound24542 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env24543 : List Nat := [2,4,8,16,27,11,18,30,26,14,2048,27,8,2048,0,24,26,2074,20,1,2074,27,10,25,18,17,2049,26,27,2075,14,0,5,0,2048,26]

theorem envBound24543 : H12AffineFastState.Bounded env24543 := by
  intro p hp
  have h : env24543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24542_24543 : H12AffineEnvironment.transform 4 27 env24542 = env24543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env24542 == env24543) = true)

def leafEnv24543 : List Nat := [2,4,8,16,27,11,18,30,26,14,2048,27,8,2048,0,24,26,2074,20,1,2074,27,10,25,20,18,1,17,2049,26,27,2075,14,0,5,0,31,3,2048,26,0,2074,1]

def active24543 : List Nat := [0,1,2,3,10]

def tree24543 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24543 : H12WitnessSearch.Good tree24543 := H12GlobalWitnessIndex.good

theorem leafIdentity24543 : H12AffineFastState.composeSystem env24543 rootObs = leafEnv24543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24543 rootObs == leafEnv24543) = true)

theorem terminalChecked24543 : H12PackedTerminal.terminalCheckFast leafEnv24543 active24543 tree24543 = true := by decide +kernel

def env24544 : List Nat := [2,4,8,16,32,64,128,253,136,1024,2048,4096,8192,16384,32768,65536,4097,262144,524288,32769,21740,41089,525328,70844,8328,525376,275516,33812,33813,634098,37053,602223,525564,558329,54293,136]

theorem envBound24544 : H12AffineFastState.Bounded env24544 := by
  intro p hp
  have h : env24544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24518_24544 : H12AffineEnvironment.transform 7 253 env24518 = env24544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env24518 == env24544) = true)

theorem identity24544 : scanCanonicalize (H12AffineFastState.compose env24544 (packedSelected [1,13,17,18,23,24] rootPS)) = affineNative (2^(18+1) ^^^ 102606) := by decide +kernel

theorem selectedBound24544 : packedSelected [1,13,17,18,23,24] rootPS < 2^1333 := by decide +kernel

def env24545 : List Nat := [2,4,8,16,32,64,128,253,136,1024,2048,4096,8192,16384,32768,65536,4097,262144,102606,32769,21740,41089,103646,70844,8328,103566,275516,33812,33813,15420,37053,41121,103474,70711,54293,136]

theorem envBound24545 : H12AffineFastState.Bounded env24545 := by
  intro p hp
  have h : env24545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24544_24545 : H12AffineEnvironment.transform 18 102606 env24544 = env24545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 102606 env24544 == env24545) = true)

theorem identity24545 : scanCanonicalize (H12AffineFastState.compose env24545 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound24545 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env24546 : List Nat := [2,4,8,16,32,64,128,253,136,1024,2048,4096,8192,16384,32768,65536,4097,43049,102606,32769,21740,41089,103646,70844,8328,103566,39957,33812,33813,15420,37053,41121,103474,70711,54293,136]

theorem envBound24546 : H12AffineFastState.Bounded env24546 := by
  intro p hp
  have h : env24546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24545_24546 : H12AffineEnvironment.transform 17 43049 env24545 = env24546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env24545 == env24546) = true)

def env24547 : List Nat := [2,4,8,16,32,64,128,253,136,1024,2048,4096,8192,16384,5140,65536,4097,15421,66778,5141,21740,13461,65738,70844,8328,65690,2049,4096,4097,15420,1193,13493,65574,70711,16385,136]

theorem envBound24547 : H12AffineFastState.Bounded env24547 := by
  intro p hp
  have h : env24547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24546_24547 : H12AffineEnvironment.transform 14 5140 env24546 = env24547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 5140 env24546 == env24547) = true)

theorem identity24547 : scanCanonicalize (H12AffineFastState.compose env24547 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 5348) := by decide +kernel

theorem selectedBound24547 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24548 : List Nat := [2,4,8,16,32,64,128,253,136,1024,2048,4096,5348,16384,5140,65536,4097,2265,66778,5141,21740,113,65738,70844,5228,65690,2049,4096,4097,2264,1193,81,65574,70711,16385,136]

theorem envBound24548 : H12AffineFastState.Bounded env24548 := by
  intro p hp
  have h : env24548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24547_24548 : H12AffineEnvironment.transform 12 5348 env24547 = env24548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5348 env24547 == env24548) = true)

theorem identity24548 : scanCanonicalize (H12AffineFastState.compose env24548 (packedSelected [0,2,4] rootPS)) = affineNative (2^(15+1) ^^^ 17463) := by decide +kernel

theorem selectedBound24548 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env24549 : List Nat := [2,4,8,16,32,64,128,253,136,1024,2048,4096,5348,16384,5140,17463,4097,2265,16621,5141,21740,113,17661,20619,5228,17581,2049,4096,4097,2264,1193,81,17425,20480,16385,136]

theorem envBound24549 : H12AffineFastState.Bounded env24549 := by
  intro p hp
  have h : env24549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24548_24549 : H12AffineEnvironment.transform 15 17463 env24548 = env24549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 17463 env24548 == env24549) = true)

theorem identity24549 : scanCanonicalize (H12AffineFastState.compose env24549 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1260) := by decide +kernel

theorem selectedBound24549 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env24550 : List Nat := [2,4,8,16,32,64,128,253,136,1024,2048,1260,8,16384,248,17463,1261,2265,16621,249,16384,113,17661,17511,128,17581,2049,1260,1261,2264,1193,81,17425,17644,16385,136]

theorem envBound24550 : H12AffineFastState.Bounded env24550 := by
  intro p hp
  have h : env24550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24549_24550 : H12AffineEnvironment.transform 11 1260 env24549 = env24550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1260 env24549 == env24550) = true)

theorem identity24550 : scanCanonicalize (H12AffineFastState.compose env24550 (packedSelected [5] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound24550 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env24551 : List Nat := [2,4,8,16,32,64,41,84,33,1024,2048,1093,8,16384,81,17463,1092,2160,16452,80,16384,113,17492,17511,41,17412,2049,1093,1092,2161,1024,81,17425,17477,16385,33]

theorem envBound24551 : H12AffineFastState.Bounded env24551 := by
  intro p hp
  have h : env24551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24550_24551 : H12AffineEnvironment.transform 6 41 env24550 = env24551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env24550 == env24551) = true)

def env24552 : List Nat := [2,4,8,16,32,64,41,84,33,1024,0,1093,8,16384,81,17463,1092,112,16452,80,16384,113,17492,17511,41,17412,1,1093,1092,113,1024,81,17425,17477,16385,33]

theorem envBound24552 : H12AffineFastState.Bounded env24552 := by
  intro p hp
  have h : env24552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24551_24552 : H12AffineEnvironment.transform 10 0 env24551 = env24552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env24551 == env24552) = true)

def env24553 : List Nat := [2,4,8,16,32,64,41,84,33,1024,1,1093,8,16384,81,17463,1092,113,16452,80,16384,113,17492,17511,41,17412,0,1093,1092,112,1024,81,17425,17477,16385,33]

theorem envBound24553 : H12AffineFastState.Bounded env24553 := by
  intro p hp
  have h : env24553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24551_24553 : H12AffineEnvironment.transform 10 1 env24551 = env24553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env24551 == env24553) = true)

theorem identity24553 : scanCanonicalize (H12AffineFastState.compose env24553 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound24553 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24554 : List Nat := [2,4,8,16,32,49,41,37,33,1024,1,1076,8,16384,32,17463,1077,0,16437,33,16384,0,17445,17430,41,17412,0,1076,1077,1,1024,32,17425,17460,16385,33]

theorem envBound24554 : H12AffineFastState.Bounded env24554 := by
  intro p hp
  have h : env24554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24553_24554 : H12AffineEnvironment.transform 5 49 env24553 = env24554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env24553 == env24554) = true)

def env24555 : List Nat := [2,4,8,16,32,49,41,37,33,1024,1,1076,8,0,32,1079,1077,0,53,33,0,0,1061,1046,41,1028,0,1076,1077,1,1024,32,1041,1076,1,33]

theorem envBound24555 : H12AffineFastState.Bounded env24555 := by
  intro p hp
  have h : env24555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24554_24555 : H12AffineEnvironment.transform 13 0 env24554 = env24555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 0 env24554 == env24555) = true)

theorem identity24555 : scanCanonicalize (H12AffineFastState.compose env24555 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound24555 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24556 : List Nat := [2,4,8,16,27,10,18,30,26,1024,1,1039,8,0,27,1036,1038,0,14,26,0,0,1054,1046,18,1028,0,1039,1038,1,1024,27,1041,1039,1,26]

theorem envBound24556 : H12AffineFastState.Bounded env24556 := by
  intro p hp
  have h : env24556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24555_24556 : H12AffineEnvironment.transform 4 27 env24555 = env24556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env24555 == env24556) = true)

def env24557 : List Nat := [2,4,8,16,27,10,18,30,26,20,1,27,8,0,27,24,26,0,14,26,0,0,10,2,18,16,0,27,26,1,20,27,5,27,1,26]

theorem envBound24557 : H12AffineFastState.Bounded env24557 := by
  intro p hp
  have h : env24557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24556_24557 : H12AffineEnvironment.transform 9 20 env24556 = env24557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env24556 == env24557) = true)

theorem identity24557 : scanCanonicalize (H12AffineFastState.compose env24557 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound24557 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24558 : List Nat := [2,4,8,11,0,10,9,5,1,15,1,0,8,0,0,3,1,0,14,1,0,0,10,2,9,11,0,0,1,1,15,0,5,0,1,1]

theorem envBound24558 : H12AffineFastState.Bounded env24558 := by
  intro p hp
  have h : env24558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24557_24558 : H12AffineEnvironment.transform 3 11 env24557 = env24558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env24557 == env24558) = true)

def leafEnv24558 : List Nat := [2,4,8,11,0,10,9,5,1,15,1,0,8,0,0,3,1,0,14,1,0,0,10,2,14,9,1,11,0,0,1,1,15,0,5,0,4,3,1,1,0,1,1]

def active24558 : List Nat := [0,1,2]

def tree24558 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24558 : H12WitnessSearch.Good tree24558 := H12GlobalWitnessIndex.good

theorem leafIdentity24558 : H12AffineFastState.composeSystem env24558 rootObs = leafEnv24558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24558 rootObs == leafEnv24558) = true)

theorem terminalChecked24558 : H12PackedTerminal.terminalCheckFast leafEnv24558 active24558 tree24558 = true := by decide +kernel

def env24559 : List Nat := [2,4,8,16,27,10,18,30,26,21,1,26,8,0,27,25,27,0,14,26,0,0,11,3,18,17,0,26,27,1,21,27,4,26,1,26]

theorem envBound24559 : H12AffineFastState.Bounded env24559 := by
  intro p hp
  have h : env24559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24556_24559 : H12AffineEnvironment.transform 9 21 env24556 = env24559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env24556 == env24559) = true)

def leafEnv24559 : List Nat := [2,4,8,16,27,10,18,30,26,21,1,26,8,0,27,25,27,0,14,26,0,0,11,3,14,18,1,17,0,26,27,1,21,27,4,26,30,24,1,26,0,1,1]

def active24559 : List Nat := [0,1,2,3]

def tree24559 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24559 : H12WitnessSearch.Good tree24559 := H12GlobalWitnessIndex.good

theorem leafIdentity24559 : H12AffineFastState.composeSystem env24559 rootObs = leafEnv24559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24559 rootObs == leafEnv24559) = true)

theorem terminalChecked24559 : H12PackedTerminal.terminalCheckFast leafEnv24559 active24559 tree24559 = true := by decide +kernel

def env24560 : List Nat := [2,4,8,16,32,49,41,37,33,1024,1,1076,8,1,32,1078,1077,0,52,33,1,0,1060,1047,41,1029,0,1076,1077,1,1024,32,1040,1077,0,33]

theorem envBound24560 : H12AffineFastState.Bounded env24560 := by
  intro p hp
  have h : env24560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24554_24560 : H12AffineEnvironment.transform 13 1 env24554 = env24560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1 env24554 == env24560) = true)

theorem identity24560 : scanCanonicalize (H12AffineFastState.compose env24560 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 15) := by decide +kernel

theorem selectedBound24560 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24561 : List Nat := [2,4,8,16,32,49,41,37,33,15,1,59,8,1,32,57,58,0,52,33,1,0,43,24,41,10,0,59,58,1,15,32,31,58,0,33]

theorem envBound24561 : H12AffineFastState.Bounded env24561 := by
  intro p hp
  have h : env24561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24560_24561 : H12AffineEnvironment.transform 9 15 env24560 = env24561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 15 env24560 == env24561) = true)

def env24562 : List Nat := [2,4,8,16,0,17,9,5,1,15,1,27,8,1,0,25,26,0,20,1,1,0,11,24,9,10,0,27,26,1,15,0,31,26,0,1]

theorem envBound24562 : H12AffineFastState.Bounded env24562 := by
  intro p hp
  have h : env24562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24561_24562 : H12AffineEnvironment.transform 4 0 env24561 = env24562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env24561 == env24562) = true)

def leafEnv24562 : List Nat := [2,4,8,16,0,17,9,5,1,15,1,27,8,1,0,25,26,0,20,1,1,0,11,24,20,9,1,10,0,27,26,1,15,0,31,26,30,3,0,1,0,0,1]

def active24562 : List Nat := [0,1,2,3]

def tree24562 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24562 : H12WitnessSearch.Good tree24562 := H12GlobalWitnessIndex.good

theorem leafIdentity24562 : H12AffineFastState.composeSystem env24562 rootObs = leafEnv24562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24562 rootObs == leafEnv24562) = true)

theorem terminalChecked24562 : H12PackedTerminal.terminalCheckFast leafEnv24562 active24562 tree24562 = true := by decide +kernel

def env24563 : List Nat := [2,4,8,16,1,16,8,4,0,15,1,26,8,1,1,24,27,0,21,0,1,0,10,24,8,10,0,26,27,1,15,1,31,27,0,0]

theorem envBound24563 : H12AffineFastState.Bounded env24563 := by
  intro p hp
  have h : env24563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24561_24563 : H12AffineEnvironment.transform 4 1 env24561 = env24563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env24561 == env24563) = true)

theorem identity24563 : scanCanonicalize (H12AffineFastState.compose env24563 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound24563 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24564 : List Nat := [2,4,8,11,1,11,8,4,0,15,1,1,8,1,1,3,0,0,14,0,1,0,10,3,8,10,0,1,0,1,15,1,4,0,0,0]

theorem envBound24564 : H12AffineFastState.Bounded env24564 := by
  intro p hp
  have h : env24564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24563_24564 : H12AffineEnvironment.transform 3 11 env24563 = env24564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env24563 == env24564) = true)

def leafEnv24564 : List Nat := [2,4,8,11,1,11,8,4,0,15,1,1,8,1,1,3,0,0,14,0,1,0,10,3,14,8,1,10,0,1,0,1,15,1,4,0,4,2,0,0,0,0,1]

def active24564 : List Nat := [0,1,2]

def tree24564 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24564 : H12WitnessSearch.Good tree24564 := H12GlobalWitnessIndex.good

theorem leafIdentity24564 : H12AffineFastState.composeSystem env24564 rootObs = leafEnv24564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24564 rootObs == leafEnv24564) = true)

theorem terminalChecked24564 : H12PackedTerminal.terminalCheckFast leafEnv24564 active24564 tree24564 = true := by decide +kernel

def env24565 : List Nat := [2,4,8,16,32,64,128,253,136,1024,2048,4096,8192,16384,5141,65536,4097,15420,66779,5140,21740,13460,65739,70844,8328,65691,2048,4097,4096,15420,1192,13492,65575,70711,16384,136]

theorem envBound24565 : H12AffineFastState.Bounded env24565 := by
  intro p hp
  have h : env24565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24546_24565 : H12AffineEnvironment.transform 14 5141 env24546 = env24565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 5141 env24546 == env24565) = true)

theorem identity24565 : scanCanonicalize (H12AffineFastState.compose env24565 (packedSelected [1,3] rootPS)) = affineNative (2^(15+1) ^^^ 3) := by decide +kernel

theorem selectedBound24565 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24566 : List Nat := [2,4,8,16,32,64,128,253,136,1024,2048,4096,8192,16384,5141,3,4097,15420,1240,5140,21740,13460,200,5311,8328,152,2048,4097,4096,15420,1192,13492,36,5172,16384,136]

theorem envBound24566 : H12AffineFastState.Bounded env24566 := by
  intro p hp
  have h : env24566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24565_24566 : H12AffineEnvironment.transform 15 3 env24565 = env24566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3 env24565 == env24566) = true)

theorem identity24566 : scanCanonicalize (H12AffineFastState.compose env24566 (packedSelected [0,2,4] rootPS)) = affineNative (2^(11+1) ^^^ 3228) := by decide +kernel

theorem selectedBound24566 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env24567 : List Nat := [2,4,8,16,32,64,128,253,136,1024,2048,3228,8192,16384,2185,3,3229,8352,1240,2184,18544,10248,200,2083,8328,152,2048,3229,3228,8352,1192,10280,36,2216,16384,136]

theorem envBound24567 : H12AffineFastState.Bounded env24567 := by
  intro p hp
  have h : env24567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24566_24567 : H12AffineEnvironment.transform 11 3228 env24566 = env24567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3228 env24566 == env24567) = true)

theorem identity24567 : scanCanonicalize (H12AffineFastState.compose env24567 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 2208) := by decide +kernel

theorem selectedBound24567 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env24568 : List Nat := [2,4,8,16,32,64,128,253,136,1024,2048,3228,2208,16384,2185,3,3229,2048,1240,2184,18544,168,200,2083,2088,152,2048,3229,3228,2048,1192,136,36,2216,16384,136]

theorem envBound24568 : H12AffineFastState.Bounded env24568 := by
  intro p hp
  have h : env24568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24567_24568 : H12AffineEnvironment.transform 12 2208 env24567 = env24568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2208 env24567 == env24568) = true)

theorem identity24568 : scanCanonicalize (H12AffineFastState.compose env24568 (packedSelected [5] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound24568 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env24569 : List Nat := [2,4,8,16,32,64,40,85,32,1024,2048,3124,2056,16384,2081,3,3125,2048,1136,2080,18544,0,96,2083,2088,48,2048,3125,3124,2048,1024,32,36,2048,16384,32]

theorem envBound24569 : H12AffineFastState.Bounded env24569 := by
  intro p hp
  have h : env24569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24568_24569 : H12AffineEnvironment.transform 6 40 env24568 = env24569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env24568 == env24569) = true)

def env24570 : List Nat := [2,4,8,16,32,64,40,85,32,1024,112,1092,120,16384,81,3,1093,112,1136,80,16384,0,96,83,88,48,112,1093,1092,112,1024,32,36,112,16384,32]

theorem envBound24570 : H12AffineFastState.Bounded env24570 := by
  intro p hp
  have h : env24570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24569_24570 : H12AffineEnvironment.transform 10 112 env24569 = env24570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 112 env24569 == env24570) = true)

def env24571 : List Nat := [2,4,8,16,32,64,40,85,32,1024,113,1093,121,16384,80,3,1092,113,1136,81,16385,0,96,82,89,48,113,1092,1093,113,1024,32,36,113,16384,32]

theorem envBound24571 : H12AffineFastState.Bounded env24571 := by
  intro p hp
  have h : env24571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24569_24571 : H12AffineEnvironment.transform 10 113 env24569 = env24571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 113 env24569 == env24571) = true)

theorem identity24571 : scanCanonicalize (H12AffineFastState.compose env24571 (packedSelected [0] rootPS)) = affineNative (2^(13+1) ^^^ 1077) := by decide +kernel

theorem selectedBound24571 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24572 : List Nat := [2,4,8,16,32,64,40,85,32,1024,113,1093,121,1077,80,3,1092,113,1136,81,1076,0,96,82,89,48,113,1092,1093,113,1024,32,36,113,1077,32]

theorem envBound24572 : H12AffineFastState.Bounded env24572 := by
  intro p hp
  have h : env24572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24571_24572 : H12AffineEnvironment.transform 13 1077 env24571 = env24572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1077 env24571 == env24572) = true)

def env24573 : List Nat := [2,4,8,16,32,48,40,37,32,1024,1,1077,9,1077,32,3,1076,1,1024,33,1076,0,16,34,41,48,1,1076,1077,1,1024,32,36,1,1077,32]

theorem envBound24573 : H12AffineFastState.Bounded env24573 := by
  intro p hp
  have h : env24573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24572_24573 : H12AffineEnvironment.transform 5 48 env24572 = env24573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env24572 == env24573) = true)

theorem identity24573 : scanCanonicalize (H12AffineFastState.compose env24573 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound24573 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24574 : List Nat := [2,4,8,16,27,11,19,30,27,1024,1,1038,9,1038,27,3,1039,1,1024,26,1039,0,16,25,18,11,1,1039,1038,1,1024,27,31,1,1038,27]

theorem envBound24574 : H12AffineFastState.Bounded env24574 := by
  intro p hp
  have h : env24574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24573_24574 : H12AffineEnvironment.transform 4 27 env24573 = env24574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env24573 == env24574) = true)

theorem identity24574 : scanCanonicalize (H12AffineFastState.compose env24574 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound24574 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24575 : List Nat := [2,4,8,10,1,11,9,4,1,1024,1,1038,9,1038,1,3,1039,1,1024,0,1039,0,10,3,8,11,1,1039,1038,1,1024,1,5,1,1038,1]

theorem envBound24575 : H12AffineFastState.Bounded env24575 := by
  intro p hp
  have h : env24575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24574_24575 : H12AffineEnvironment.transform 3 10 env24574 = env24575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env24574 == env24575) = true)

def leafEnv24575 : List Nat := [2,4,8,10,1,11,9,4,1,1024,1,1038,9,1038,1,3,1039,1,1024,0,1039,0,10,3,1024,8,1,11,1,1039,1038,1,1024,1,5,1,5,2,1038,1,0,1039,1]

def active24575 : List Nat := [0,1,2,9]

def tree24575 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24575 : H12WitnessSearch.Good tree24575 := H12GlobalWitnessIndex.good

theorem leafIdentity24575 : H12AffineFastState.composeSystem env24575 rootObs = leafEnv24575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24575 rootObs == leafEnv24575) = true)

theorem terminalChecked24575 : H12PackedTerminal.terminalCheckFast leafEnv24575 active24575 tree24575 = true := by decide +kernel

def env24576 : List Nat := [2,4,8,16,32,49,40,36,32,1024,0,1076,8,1077,33,3,1077,0,1025,32,1076,0,17,35,40,48,0,1077,1076,0,1024,32,36,0,1077,32]

theorem envBound24576 : H12AffineFastState.Bounded env24576 := by
  intro p hp
  have h : env24576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24572_24576 : H12AffineEnvironment.transform 5 49 env24572 = env24576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env24572 == env24576) = true)

theorem identity24576 : scanCanonicalize (H12AffineFastState.compose env24576 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 15) := by decide +kernel

theorem selectedBound24576 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24577 : List Nat := [2,4,8,16,32,49,40,36,32,15,0,59,8,58,33,3,58,0,14,32,59,0,17,35,40,48,0,58,59,0,15,32,36,0,58,32]

theorem envBound24577 : H12AffineFastState.Bounded env24577 := by
  intro p hp
  have h : env24577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24576_24577 : H12AffineEnvironment.transform 9 15 env24576 = env24577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 15 env24576 == env24577) = true)

def leafEnv24577 : List Nat := [2,4,8,16,32,49,40,36,32,15,0,59,8,58,33,3,58,0,14,32,59,0,17,35,14,40,1,48,0,58,59,0,15,32,36,0,4,34,58,32,0,59,1]

def active24577 : List Nat := [0,1,2,3,4]

def tree24577 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24577 : H12WitnessSearch.Good tree24577 := H12GlobalWitnessIndex.good

theorem leafIdentity24577 : H12AffineFastState.composeSystem env24577 rootObs = leafEnv24577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24577 rootObs == leafEnv24577) = true)

theorem terminalChecked24577 : H12PackedTerminal.terminalCheckFast leafEnv24577 active24577 tree24577 = true := by decide +kernel

def env24578 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,660497,16777216,8328,67108864,134217728,138678612,536870912,1073741824,760058132,4294967296,676201557,4315938987,34359738368,137]

theorem envBound24578 : H12AffineFastState.Bounded env24578 := by
  intro p hp
  have h : env24578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24074_24578 : H12AffineEnvironment.transform 8 137 env24074 = env24578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env24074 == env24578) = true)

theorem identity24578 : scanCanonicalize (H12AffineFastState.compose env24578 (packedSelected [1,4,8,9,13,14,16,19,21] rootPS)) = affineNative (2^(34+1) ^^^ 762151249) := by decide +kernel

theorem selectedBound24578 : packedSelected [1,4,8,9,13,14,16,19,21] rootPS < 2^1333 := by decide +kernel

def env24579 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,660497,16777216,8328,67108864,134217728,138678612,536870912,1073741824,760058132,4294967296,676201557,4315938987,762151249,137]

theorem envBound24579 : H12AffineFastState.Bounded env24579 := by
  intro p hp
  have h : env24579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24578_24579 : H12AffineEnvironment.transform 34 762151249 env24578 = env24579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 762151249 env24578 == env24579) = true)

theorem identity24579 : scanCanonicalize (H12AffineFastState.compose env24579 (packedSelected [0,4,7,9,14,16,20] rootPS)) = affineNative (2^(28+1) ^^^ 138805588) := by decide +kernel

theorem selectedBound24579 : packedSelected [0,4,7,9,14,16,20] rootPS < 2^1333 := by decide +kernel

def env24580 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,660497,16777216,8328,67108864,134217728,138678612,138805588,1073741824,84643904,4294967296,525569,4315938987,86736901,137]

theorem envBound24580 : H12AffineFastState.Bounded env24580 := by
  intro p hp
  have h : env24580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24579_24580 : H12AffineEnvironment.transform 28 138805588 env24579 = env24580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 28 138805588 env24579 == env24580) = true)

theorem identity24580 : scanCanonicalize (H12AffineFastState.compose env24580 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(26+1) ^^^ 21331969) := by decide +kernel

theorem selectedBound24580 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env24581 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,660497,16777216,8328,67108864,21331969,16879957,17006933,1073741824,84643904,4294967296,525569,4315938987,86736901,137]

theorem envBound24581 : H12AffineFastState.Bounded env24581 := by
  intro p hp
  have h : env24581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24580_24581 : H12AffineEnvironment.transform 26 21331969 env24580 = env24581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 21331969 env24580 == env24581) = true)

def env24582 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,16384,32768,65536,4096,262144,524288,32769,2097152,4194304,525329,16777216,8328,67108864,21331969,16879957,16879957,1073741824,84508736,4294967296,525569,4315938987,86609925,137]

theorem envBound24582 : H12AffineFastState.Bounded env24582 := by
  intro p hp
  have h : env24582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24581_24582 : H12AffineEnvironment.transform 16 4096 env24581 = env24582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4096 env24581 == env24582) = true)

theorem identity24582 : scanCanonicalize (H12AffineFastState.compose env24582 (packedSelected [3,5,10] rootPS)) = affineNative (2^(23+1) ^^^ 4796612) := by decide +kernel

theorem selectedBound24582 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env24583 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,16384,32768,65536,4096,262144,524288,32769,2097152,4194304,525329,4796612,8328,67108864,831685,4759953,4759953,1073741824,71348356,4294967296,525569,4295569519,73441473,137]

theorem envBound24583 : H12AffineFastState.Bounded env24583 := by
  intro p hp
  have h : env24583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24582_24583 : H12AffineEnvironment.transform 23 4796612 env24582 = env24583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 4796612 env24582 == env24583) = true)

def env24584 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,16384,32768,65536,4096,262144,524288,32769,2097152,566400,525329,103492,8328,67108864,831685,1297,1297,1073741824,67638276,4294967296,525569,4295569519,69731393,137]

theorem envBound24584 : H12AffineFastState.Bounded env24584 := by
  intro p hp
  have h : env24584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24583_24584 : H12AffineEnvironment.transform 21 566400 env24583 = env24584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 566400 env24583 == env24584) = true)

def env24585 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,16384,32768,65536,4096,262144,524288,32769,529408,566400,525329,103492,8328,67108864,831685,1297,1297,1073741824,67638276,4294967296,525569,4295569519,67113025,137]

theorem envBound24585 : H12AffineFastState.Bounded env24585 := by
  intro p hp
  have h : env24585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24584_24585 : H12AffineEnvironment.transform 20 529408 env24584 = env24585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 529408 env24584 == env24585) = true)

theorem identity24585 : scanCanonicalize (H12AffineFastState.compose env24585 (packedSelected [14] rootPS)) = affineNative (2^(25+1) ^^^ 17744) := by decide +kernel

theorem selectedBound24585 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env24586 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,16384,32768,65536,4096,262144,524288,32769,529408,566400,525329,103492,8328,17744,831685,1297,1297,1073741824,545108,4294967296,525569,4295569519,21777,137]

theorem envBound24586 : H12AffineFastState.Bounded env24586 := by
  intro p hp
  have h : env24586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24585_24586 : H12AffineEnvironment.transform 25 17744 env24585 = env24586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 17744 env24585 == env24586) = true)

theorem identity24586 : scanCanonicalize (H12AffineFastState.compose env24586 (packedSelected [0,27] rootPS)) = affineNative (2^(18+1) ^^^ 16657) := by decide +kernel

theorem selectedBound24586 : packedSelected [0,27] rootPS < 2^1333 := by decide +kernel

def env24587 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,16384,32768,65536,4096,262144,16657,32769,21777,58769,17664,103492,8328,17744,324052,1297,1297,1073741824,4165,4294967296,17424,4295061886,21777,137]

theorem envBound24587 : H12AffineFastState.Bounded env24587 := by
  intro p hp
  have h : env24587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24586_24587 : H12AffineEnvironment.transform 18 16657 env24586 = env24587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 16657 env24586 == env24587) = true)

theorem identity24587 : scanCanonicalize (H12AffineFastState.compose env24587 (packedSelected [1,12,13] rootPS)) = affineNative (2^(29+1) ^^^ 96607) := by decide +kernel

theorem selectedBound24587 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env24588 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,16384,32768,65536,4096,262144,16657,32769,21777,58769,17664,103492,8328,17744,324052,1297,1297,96607,4165,4294967296,17424,4295061886,21777,137]

theorem envBound24588 : H12AffineFastState.Bounded env24588 := by
  intro p hp
  have h : env24588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24587_24588 : H12AffineEnvironment.transform 29 96607 env24587 = env24588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 96607 env24587 == env24588) = true)

theorem identity24588 : scanCanonicalize (H12AffineFastState.compose env24588 (packedSelected [3,5,24] rootPS)) = affineNative (2^(11+1) ^^^ 1093) := by decide +kernel

theorem selectedBound24588 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env24589 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1093,8192,16384,32768,65536,1093,262144,16657,32769,16724,58769,17664,98305,8328,17744,320913,1297,1297,93466,1024,4294967296,17424,4295058747,16724,137]

theorem envBound24589 : H12AffineFastState.Bounded env24589 := by
  intro p hp
  have h : env24589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24588_24589 : H12AffineEnvironment.transform 11 1093 env24588 = env24589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1093 env24588 == env24589) = true)

theorem identity24589 : scanCanonicalize (H12AffineFastState.compose env24589 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 25929) := by decide +kernel

theorem selectedBound24589 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env24590 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1093,8192,16384,25929,65536,1093,262144,16657,25928,16724,216,17664,91464,8328,17744,262360,1297,1297,93466,1024,4294967296,17424,4295058747,16724,137]

theorem envBound24590 : H12AffineFastState.Bounded env24590 := by
  intro p hp
  have h : env24590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24589_24590 : H12AffineEnvironment.transform 14 25929 env24589 = env24590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25929 env24589 == env24590) = true)

def env24591 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1093,8192,1296,8281,65536,1093,262144,1025,8280,1092,216,16,73816,8328,64,262360,1297,1297,75786,1024,4294967296,256,4295041067,1092,137]

theorem envBound24591 : H12AffineFastState.Bounded env24591 := by
  intro p hp
  have h : env24591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24590_24591 : H12AffineEnvironment.transform 13 1296 env24590 = env24591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env24590 == env24591) = true)

theorem identity24591 : scanCanonicalize (H12AffineFastState.compose env24591 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 65650) := by decide +kernel

theorem selectedBound24591 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env24592 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1093,8192,1296,8281,65536,1093,262144,1025,8280,1092,216,16,73816,8328,64,262360,1297,1297,75786,1024,65650,256,8281,1092,137]

theorem envBound24592 : H12AffineFastState.Bounded env24592 := by
  intro p hp
  have h : env24592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24591_24592 : H12AffineEnvironment.transform 31 65650 env24591 = env24592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 65650 env24591 == env24592) = true)

def env24593 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1093,8192,1296,8281,65536,1093,8400,1025,8280,1092,216,16,73816,8328,64,8200,1297,1297,75786,1024,65650,256,8281,1092,137]

theorem envBound24593 : H12AffineFastState.Bounded env24593 := by
  intro p hp
  have h : env24593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24592_24593 : H12AffineEnvironment.transform 17 8400 env24592 = env24593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8400 env24592 == env24593) = true)

theorem identity24593 : scanCanonicalize (H12AffineFastState.compose env24593 (packedSelected [7] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound24593 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env24594 : List Nat := [2,4,8,16,32,64,88,256,81,1024,2048,1093,8192,1296,8281,65536,1093,8200,1025,8280,1092,0,16,73816,8272,64,8200,1297,1297,75786,1024,65650,256,8281,1092,81]

theorem envBound24594 : H12AffineFastState.Bounded env24594 := by
  intro p hp
  have h : env24594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24593_24594 : H12AffineEnvironment.transform 6 88 env24593 = env24594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env24593 == env24594) = true)

def env24595 : List Nat := [2,4,8,16,32,64,88,256,81,1024,0,1093,8192,1296,8281,65536,1093,8200,1025,8280,1092,0,16,73816,8272,64,8200,1297,1297,73738,1024,65650,256,8281,1092,81]

theorem envBound24595 : H12AffineFastState.Bounded env24595 := by
  intro p hp
  have h : env24595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24594_24595 : H12AffineEnvironment.transform 10 0 env24594 = env24595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env24594 == env24595) = true)

theorem identity24595 : scanCanonicalize (H12AffineFastState.compose env24595 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound24595 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24596 : List Nat := [2,4,8,16,32,64,88,256,81,1024,0,1093,8192,1296,8281,114,1093,8200,1025,8280,1092,0,16,8234,8272,64,8200,1297,1297,8312,1024,0,256,8281,1092,81]

theorem envBound24596 : H12AffineFastState.Bounded env24596 := by
  intro p hp
  have h : env24596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24595_24596 : H12AffineEnvironment.transform 15 114 env24595 = env24596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env24595 == env24596) = true)

theorem identity24596 : scanCanonicalize (H12AffineFastState.compose env24596 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound24596 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env24597 : List Nat := [2,4,8,16,27,64,88,256,81,1024,0,1093,8192,1296,8281,73,1093,8200,1025,8280,1092,0,16,8209,8272,64,8200,1297,1297,8259,1024,0,256,8281,1092,81]

theorem envBound24597 : H12AffineFastState.Bounded env24597 := by
  intro p hp
  have h : env24597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24596_24597 : H12AffineEnvironment.transform 4 27 env24596 = env24597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env24596 == env24597) = true)

theorem identity24597 : scanCanonicalize (H12AffineFastState.compose env24597 (packedSelected [9] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound24597 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env24598 : List Nat := [2,4,8,16,27,64,88,85,81,1024,0,1093,8192,1093,8281,73,1093,8200,1025,8280,1092,0,16,8209,8272,64,8200,1092,1092,8259,1024,0,85,8281,1092,81]

theorem envBound24598 : H12AffineFastState.Bounded env24598 := by
  intro p hp
  have h : env24598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24597_24598 : H12AffineEnvironment.transform 7 85 env24597 = env24598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env24597 == env24598) = true)

theorem identity24598 : scanCanonicalize (H12AffineFastState.compose env24598 (packedSelected [1,5] rootPS)) = affineNative (2^(12+1) ^^^ 67) := by decide +kernel

theorem selectedBound24598 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env24599 : List Nat := [2,4,8,16,27,64,88,85,81,1024,0,1093,67,1093,26,73,1093,75,1025,27,1092,0,16,82,19,64,75,1092,1092,0,1024,0,85,26,1092,81]

theorem envBound24599 : H12AffineFastState.Bounded env24599 := by
  intro p hp
  have h : env24599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24598_24599 : H12AffineEnvironment.transform 12 67 env24598 = env24599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 67 env24598 == env24599) = true)

def leafEnv24599 : List Nat := [2,4,8,16,27,64,88,85,81,1024,0,1093,67,1093,26,73,1093,75,1025,27,1092,0,16,82,1025,19,1,64,75,1092,1092,0,1024,0,85,26,4,25,1092,81,0,1093,1]

def active24599 : List Nat := [0,1,2,3,5,9]

def tree24599 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24599 : H12WitnessSearch.Good tree24599 := H12GlobalWitnessIndex.good

theorem leafIdentity24599 : H12AffineFastState.composeSystem env24599 rootObs = leafEnv24599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24599 rootObs == leafEnv24599) = true)

theorem terminalChecked24599 : H12PackedTerminal.terminalCheckFast leafEnv24599 active24599 tree24599 = true := by decide +kernel

def env24600 : List Nat := [2,4,8,16,32,64,88,256,81,1024,1,1093,8192,1296,8281,65536,1093,8200,1025,8280,1092,0,16,73816,8272,64,8200,1297,1297,73739,1024,65650,256,8281,1092,81]

theorem envBound24600 : H12AffineFastState.Bounded env24600 := by
  intro p hp
  have h : env24600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24594_24600 : H12AffineEnvironment.transform 10 1 env24594 = env24600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env24594 == env24600) = true)

theorem identity24600 : scanCanonicalize (H12AffineFastState.compose env24600 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound24600 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24601 : List Nat := [2,4,8,16,32,64,88,256,81,1024,1,1093,121,1296,32,65536,1093,113,1025,33,1092,0,16,65569,41,64,113,1297,1297,65650,1024,65650,256,32,1092,81]

theorem envBound24601 : H12AffineFastState.Bounded env24601 := by
  intro p hp
  have h : env24601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24600_24601 : H12AffineEnvironment.transform 12 121 env24600 = env24601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env24600 == env24601) = true)

theorem identity24601 : scanCanonicalize (H12AffineFastState.compose env24601 (packedSelected [2,3,8] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound24601 : packedSelected [2,3,8] rootPS < 2^1333 := by decide +kernel

def env24602 : List Nat := [2,4,8,16,32,11,19,256,26,1024,1,1038,50,1296,32,65536,1038,58,1025,33,1039,0,16,65569,41,11,58,1297,1297,65593,1024,65593,256,32,1039,26]

theorem envBound24602 : H12AffineFastState.Bounded env24602 := by
  intro p hp
  have h : env24602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24601_24602 : H12AffineEnvironment.transform 5 11 env24601 = env24602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env24601 == env24602) = true)

theorem identity24602 : scanCanonicalize (H12AffineFastState.compose env24602 (packedSelected [11] rootPS)) = affineNative (2^(15+1) ^^^ 56) := by decide +kernel

theorem selectedBound24602 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env24603 : List Nat := [2,4,8,16,32,11,19,256,26,1024,1,1038,50,1296,32,56,1038,58,1025,33,1039,0,16,25,41,11,58,1297,1297,1,1024,1,256,32,1039,26]

theorem envBound24603 : H12AffineFastState.Bounded env24603 := by
  intro p hp
  have h : env24603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24602_24603 : H12AffineEnvironment.transform 15 56 env24602 = env24603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 56 env24602 == env24603) = true)

theorem identity24603 : scanCanonicalize (H12AffineFastState.compose env24603 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 62) := by decide +kernel

theorem selectedBound24603 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24604 : List Nat := [2,4,8,16,32,11,19,62,26,1024,1,1038,50,1070,32,56,1038,58,1025,33,1039,0,16,25,41,11,58,1071,1071,1,1024,1,62,32,1039,26]

theorem envBound24604 : H12AffineFastState.Bounded env24604 := by
  intro p hp
  have h : env24604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24603_24604 : H12AffineEnvironment.transform 7 62 env24603 = env24604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 62 env24603 == env24604) = true)

def leafEnv24604 : List Nat := [2,4,8,16,32,11,19,62,26,1024,1,1038,50,1070,32,56,1038,58,1025,33,1039,0,16,25,1025,41,1,11,58,1071,1071,1,1024,1,62,32,4,35,1039,26,0,1070,1]

def active24604 : List Nat := [0,1,2,3,4,9]

def tree24604 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24604 : H12WitnessSearch.Good tree24604 := H12GlobalWitnessIndex.good

theorem leafIdentity24604 : H12AffineFastState.composeSystem env24604 rootObs = leafEnv24604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24604 rootObs == leafEnv24604) = true)

theorem terminalChecked24604 : H12PackedTerminal.terminalCheckFast leafEnv24604 active24604 tree24604 = true := by decide +kernel

def env24605 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1093,8192,1296,8281,65536,1093,8401,1025,8280,1092,216,16,73816,8328,64,8201,1297,1297,75786,1024,65650,256,8281,1092,137]

theorem envBound24605 : H12AffineFastState.Bounded env24605 := by
  intro p hp
  have h : env24605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24592_24605 : H12AffineEnvironment.transform 17 8401 env24592 = env24605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8401 env24592 == env24605) = true)

def env24606 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1093,8192,1297,8280,65536,1093,262144,1024,8281,1093,216,17,73817,8328,65,262360,1297,1297,75787,1024,4294967296,257,4295041066,1093,137]

theorem envBound24606 : H12AffineFastState.Bounded env24606 := by
  intro p hp
  have h : env24606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24590_24606 : H12AffineEnvironment.transform 13 1297 env24590 = env24606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env24590 == env24606) = true)

theorem identity24606 : scanCanonicalize (H12AffineFastState.compose env24606 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 65831) := by decide +kernel

theorem selectedBound24606 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env24607 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1093,8192,1297,8280,65536,1093,262144,1024,8281,1093,216,17,73817,8328,65,262360,1297,1297,75787,1024,65831,257,8461,1093,137]

theorem envBound24607 : H12AffineFastState.Bounded env24607 := by
  intro p hp
  have h : env24607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24606_24607 : H12AffineEnvironment.transform 31 65831 env24606 = env24607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 65831 env24606 == env24607) = true)

def env24608 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1093,8192,1297,8280,65536,1093,8400,1024,8281,1093,216,17,73817,8328,65,8200,1297,1297,75787,1024,65831,257,8461,1093,137]

theorem envBound24608 : H12AffineFastState.Bounded env24608 := by
  intro p hp
  have h : env24608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24607_24608 : H12AffineEnvironment.transform 17 8400 env24607 = env24608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8400 env24607 == env24608) = true)

theorem identity24608 : scanCanonicalize (H12AffineFastState.compose env24608 (packedSelected [7] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound24608 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env24609 : List Nat := [2,4,8,16,32,64,88,256,81,1024,2048,1093,8192,1297,8280,65536,1093,8200,1024,8281,1093,0,17,73817,8272,65,8200,1297,1297,75787,1024,65831,257,8461,1093,81]

theorem envBound24609 : H12AffineFastState.Bounded env24609 := by
  intro p hp
  have h : env24609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24608_24609 : H12AffineEnvironment.transform 6 88 env24608 = env24609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env24608 == env24609) = true)

def env24610 : List Nat := [2,4,8,16,32,64,88,256,81,1024,0,1093,8192,1297,8280,65536,1093,8200,1024,8281,1093,0,17,73817,8272,65,8200,1297,1297,73739,1024,65831,257,8461,1093,81]

theorem envBound24610 : H12AffineFastState.Bounded env24610 := by
  intro p hp
  have h : env24610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24609_24610 : H12AffineEnvironment.transform 10 0 env24609 = env24610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env24609 == env24610) = true)

theorem identity24610 : scanCanonicalize (H12AffineFastState.compose env24610 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound24610 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24611 : List Nat := [2,4,8,16,32,64,88,256,81,1024,0,1093,8192,1297,8280,114,1093,8200,1024,8281,1093,0,17,8235,8272,65,8200,1297,1297,8313,1024,341,257,8461,1093,81]

theorem envBound24611 : H12AffineFastState.Bounded env24611 := by
  intro p hp
  have h : env24611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24610_24611 : H12AffineEnvironment.transform 15 114 env24610 = env24611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env24610 == env24611) = true)

theorem identity24611 : scanCanonicalize (H12AffineFastState.compose env24611 (packedSelected [18] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound24611 : packedSelected [18] rootPS < 2^1333 := by decide +kernel

def env24612 : List Nat := [2,4,8,16,32,64,88,256,81,1024,0,1093,121,1297,33,114,1093,113,1024,32,1093,0,17,82,41,65,113,1297,1297,0,1024,341,257,372,1093,81]

theorem envBound24612 : H12AffineFastState.Bounded env24612 := by
  intro p hp
  have h : env24612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24611_24612 : H12AffineEnvironment.transform 12 121 env24611 = env24612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env24611 == env24612) = true)

def env24613 : List Nat := [2,4,8,16,32,16,8,256,1,1024,0,1045,41,1297,33,34,1045,33,1024,32,1045,0,17,2,41,17,33,1297,1297,0,1024,261,257,292,1045,1]

theorem envBound24613 : H12AffineFastState.Bounded env24613 := by
  intro p hp
  have h : env24613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24612_24613 : H12AffineEnvironment.transform 5 16 env24612 = env24613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env24612 == env24613) = true)

theorem identity24613 : scanCanonicalize (H12AffineFastState.compose env24613 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 31) := by decide +kernel

theorem selectedBound24613 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24614 : List Nat := [2,4,8,16,32,16,8,31,1,1024,0,1045,41,1038,33,34,1045,33,1024,32,1045,0,17,2,41,17,33,1038,1038,0,1024,26,30,59,1045,1]

theorem envBound24614 : H12AffineFastState.Bounded env24614 := by
  intro p hp
  have h : env24614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24613_24614 : H12AffineEnvironment.transform 7 31 env24613 = env24614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 31 env24613 == env24614) = true)

def env24615 : List Nat := [2,4,8,16,0,16,8,31,1,1024,0,1045,9,1038,1,2,1045,1,1024,0,1045,0,17,2,9,17,1,1038,1038,0,1024,26,30,27,1045,1]

theorem envBound24615 : H12AffineFastState.Bounded env24615 := by
  intro p hp
  have h : env24615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24614_24615 : H12AffineEnvironment.transform 4 0 env24614 = env24615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env24614 == env24615) = true)

theorem identity24615 : scanCanonicalize (H12AffineFastState.compose env24615 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound24615 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24616 : List Nat := [2,4,8,10,0,10,8,5,1,1024,0,1039,9,1038,1,2,1039,1,1024,0,1039,0,11,2,9,11,1,1038,1038,0,1024,0,4,1,1039,1]

theorem envBound24616 : H12AffineFastState.Bounded env24616 := by
  intro p hp
  have h : env24616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24615_24616 : H12AffineEnvironment.transform 3 10 env24615 = env24616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env24615 == env24616) = true)

def leafEnv24616 : List Nat := [2,4,8,10,0,10,8,5,1,1024,0,1039,9,1038,1,2,1039,1,1024,0,1039,0,11,2,1024,9,1,11,1,1038,1038,0,1024,0,4,1,5,2,1039,1,0,1038,1]

def active24616 : List Nat := [0,1,2,9]

def tree24616 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24616 : H12WitnessSearch.Good tree24616 := H12GlobalWitnessIndex.good

theorem leafIdentity24616 : H12AffineFastState.composeSystem env24616 rootObs = leafEnv24616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24616 rootObs == leafEnv24616) = true)

theorem terminalChecked24616 : H12PackedTerminal.terminalCheckFast leafEnv24616 active24616 tree24616 = true := by decide +kernel

def env24617 : List Nat := [2,4,8,16,1,16,8,31,1,1024,0,1045,8,1038,0,3,1045,0,1024,1,1045,0,17,2,8,17,0,1038,1038,0,1024,26,30,26,1045,1]

theorem envBound24617 : H12AffineFastState.Bounded env24617 := by
  intro p hp
  have h : env24617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24614_24617 : H12AffineEnvironment.transform 4 1 env24614 = env24617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env24614 == env24617) = true)

def leafEnv24617 : List Nat := [2,4,8,16,1,16,8,31,1,1024,0,1045,8,1038,0,3,1045,0,1024,1,1045,0,17,2,1024,8,1,17,0,1038,1038,0,1024,26,30,26,5,3,1045,1,0,1038,1]

def active24617 : List Nat := [0,1,2,3,9]

def tree24617 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24617 : H12WitnessSearch.Good tree24617 := H12GlobalWitnessIndex.good

theorem leafIdentity24617 : H12AffineFastState.composeSystem env24617 rootObs = leafEnv24617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24617 rootObs == leafEnv24617) = true)

theorem terminalChecked24617 : H12PackedTerminal.terminalCheckFast leafEnv24617 active24617 tree24617 = true := by decide +kernel

def env24618 : List Nat := [2,4,8,16,32,17,9,256,0,1024,0,1044,40,1297,33,35,1044,32,1024,32,1044,0,17,3,41,16,32,1297,1297,0,1024,260,257,293,1044,0]

theorem envBound24618 : H12AffineFastState.Bounded env24618 := by
  intro p hp
  have h : env24618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24612_24618 : H12AffineEnvironment.transform 5 17 env24612 = env24618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env24612 == env24618) = true)

theorem identity24618 : scanCanonicalize (H12AffineFastState.compose env24618 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound24618 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24619 : List Nat := [2,4,8,10,32,11,9,256,0,1024,0,1038,40,1291,33,35,1038,32,1024,32,1038,0,11,3,41,10,32,1291,1291,0,1024,260,257,293,1038,0]

theorem envBound24619 : H12AffineFastState.Bounded env24619 := by
  intro p hp
  have h : env24619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24618_24619 : H12AffineEnvironment.transform 3 10 env24618 = env24619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env24618 == env24619) = true)

def env24620 : List Nat := [2,4,8,10,0,11,9,256,0,1024,0,1038,8,1291,1,3,1038,0,1024,0,1038,0,11,3,9,10,0,1291,1291,0,1024,260,257,261,1038,0]

theorem envBound24620 : H12AffineFastState.Bounded env24620 := by
  intro p hp
  have h : env24620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24619_24620 : H12AffineEnvironment.transform 4 0 env24619 = env24620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env24619 == env24620) = true)

theorem identity24620 : scanCanonicalize (H12AffineFastState.compose env24620 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound24620 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24621 : List Nat := [2,4,8,10,0,11,9,5,0,1024,0,1038,8,1038,1,3,1038,0,1024,0,1038,0,11,3,9,10,0,1038,1038,0,1024,1,4,0,1038,0]

theorem envBound24621 : H12AffineFastState.Bounded env24621 := by
  intro p hp
  have h : env24621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24620_24621 : H12AffineEnvironment.transform 7 5 env24620 = env24621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env24620 == env24621) = true)

def leafEnv24621 : List Nat := [2,4,8,10,0,11,9,5,0,1024,0,1038,8,1038,1,3,1038,0,1024,0,1038,0,11,3,1024,9,1,10,0,1038,1038,0,1024,1,4,0,5,2,1038,0,0,1038,1]

def active24621 : List Nat := [0,1,2,9]

def tree24621 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24621 : H12WitnessSearch.Good tree24621 := H12GlobalWitnessIndex.good

theorem leafIdentity24621 : H12AffineFastState.composeSystem env24621 rootObs = leafEnv24621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24621 rootObs == leafEnv24621) = true)

theorem terminalChecked24621 : H12PackedTerminal.terminalCheckFast leafEnv24621 active24621 tree24621 = true := by decide +kernel

def env24622 : List Nat := [2,4,8,10,1,11,9,256,0,1024,0,1038,9,1291,0,2,1038,1,1024,1,1038,0,11,3,8,10,1,1291,1291,0,1024,260,257,260,1038,0]

theorem envBound24622 : H12AffineFastState.Bounded env24622 := by
  intro p hp
  have h : env24622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24619_24622 : H12AffineEnvironment.transform 4 1 env24619 = env24622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env24619 == env24622) = true)

def env24623 : List Nat := [2,4,8,16,32,64,88,256,81,1024,1,1093,8192,1297,8280,65536,1093,8200,1024,8281,1093,0,17,73817,8272,65,8200,1297,1297,73738,1024,65831,257,8461,1093,81]

theorem envBound24623 : H12AffineFastState.Bounded env24623 := by
  intro p hp
  have h : env24623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24609_24623 : H12AffineEnvironment.transform 10 1 env24609 = env24623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env24609 == env24623) = true)

theorem identity24623 : scanCanonicalize (H12AffineFastState.compose env24623 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound24623 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24624 : List Nat := [2,4,8,16,32,64,88,256,81,1024,1,1093,120,1297,32,65536,1093,112,1024,33,1093,0,17,65569,40,65,112,1297,1297,65650,1024,65831,257,373,1093,81]

theorem envBound24624 : H12AffineFastState.Bounded env24624 := by
  intro p hp
  have h : env24624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24623_24624 : H12AffineEnvironment.transform 12 120 env24623 = env24624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env24623 == env24624) = true)

theorem identity24624 : scanCanonicalize (H12AffineFastState.compose env24624 (packedSelected [11] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound24624 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env24625 : List Nat := [2,4,8,16,32,64,88,256,81,1024,1,1093,120,1297,32,115,1093,112,1024,33,1093,0,17,82,40,65,112,1297,1297,1,1024,340,257,373,1093,81]

theorem envBound24625 : H12AffineFastState.Bounded env24625 := by
  intro p hp
  have h : env24625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24624_24625 : H12AffineEnvironment.transform 15 115 env24624 = env24625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env24624 == env24625) = true)

def env24626 : List Nat := [2,4,8,16,32,16,8,256,1,1024,1,1045,40,1297,32,35,1045,32,1024,33,1045,0,17,2,40,17,32,1297,1297,1,1024,260,257,293,1045,1]

theorem envBound24626 : H12AffineFastState.Bounded env24626 := by
  intro p hp
  have h : env24626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24625_24626 : H12AffineEnvironment.transform 5 16 env24625 = env24626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env24625 == env24626) = true)

theorem identity24626 : scanCanonicalize (H12AffineFastState.compose env24626 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound24626 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24627 : List Nat := [2,4,8,11,32,11,8,256,1,1024,1,1038,40,1290,32,35,1038,32,1024,33,1038,0,10,2,40,10,32,1290,1290,1,1024,260,257,293,1038,1]

theorem envBound24627 : H12AffineFastState.Bounded env24627 := by
  intro p hp
  have h : env24627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24626_24627 : H12AffineEnvironment.transform 3 11 env24626 = env24627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env24626 == env24627) = true)

def env24628 : List Nat := [2,4,8,11,0,11,8,256,1,1024,1,1038,8,1290,0,3,1038,0,1024,1,1038,0,10,2,8,10,0,1290,1290,1,1024,260,257,261,1038,1]

theorem envBound24628 : H12AffineFastState.Bounded env24628 := by
  intro p hp
  have h : env24628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24627_24628 : H12AffineEnvironment.transform 4 0 env24627 = env24628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env24627 == env24628) = true)

theorem identity24628 : scanCanonicalize (H12AffineFastState.compose env24628 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound24628 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24629 : List Nat := [2,4,8,11,0,11,8,5,1,1024,1,1038,8,1039,0,3,1038,0,1024,1,1038,0,10,2,8,10,0,1039,1039,1,1024,1,4,0,1038,1]

theorem envBound24629 : H12AffineFastState.Bounded env24629 := by
  intro p hp
  have h : env24629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24628_24629 : H12AffineEnvironment.transform 7 5 env24628 = env24629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env24628 == env24629) = true)

def leafEnv24629 : List Nat := [2,4,8,11,0,11,8,5,1,1024,1,1038,8,1039,0,3,1038,0,1024,1,1038,0,10,2,1024,8,1,10,0,1039,1039,1,1024,1,4,0,5,3,1038,1,0,1039,1]

def active24629 : List Nat := [0,1,2,9]

def tree24629 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24629 : H12WitnessSearch.Good tree24629 := H12GlobalWitnessIndex.good

theorem leafIdentity24629 : H12AffineFastState.composeSystem env24629 rootObs = leafEnv24629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24629 rootObs == leafEnv24629) = true)

theorem terminalChecked24629 : H12PackedTerminal.terminalCheckFast leafEnv24629 active24629 tree24629 = true := by decide +kernel

def env24630 : List Nat := [2,4,8,11,1,11,8,256,1,1024,1,1038,9,1290,1,2,1038,1,1024,0,1038,0,10,2,9,10,1,1290,1290,1,1024,260,257,260,1038,1]

theorem envBound24630 : H12AffineFastState.Bounded env24630 := by
  intro p hp
  have h : env24630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24627_24630 : H12AffineEnvironment.transform 4 1 env24627 = env24630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env24627 == env24630) = true)

def env24631 : List Nat := [2,4,8,16,32,17,9,256,0,1024,1,1044,41,1297,32,34,1044,33,1024,33,1044,0,17,3,40,16,33,1297,1297,1,1024,261,257,292,1044,0]

theorem envBound24631 : H12AffineFastState.Bounded env24631 := by
  intro p hp
  have h : env24631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24625_24631 : H12AffineEnvironment.transform 5 17 env24625 = env24631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env24625 == env24631) = true)

theorem identity24631 : scanCanonicalize (H12AffineFastState.compose env24631 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 30) := by decide +kernel

theorem selectedBound24631 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24632 : List Nat := [2,4,8,16,32,17,9,30,0,1024,1,1044,41,1039,32,34,1044,33,1024,33,1044,0,17,3,40,16,33,1039,1039,1,1024,27,31,58,1044,0]

theorem envBound24632 : H12AffineFastState.Bounded env24632 := by
  intro p hp
  have h : env24632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24631_24632 : H12AffineEnvironment.transform 7 30 env24631 = env24632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 30 env24631 == env24632) = true)

def env24633 : List Nat := [2,4,8,16,0,17,9,30,0,1024,1,1044,9,1039,0,2,1044,1,1024,1,1044,0,17,3,8,16,1,1039,1039,1,1024,27,31,26,1044,0]

theorem envBound24633 : H12AffineFastState.Bounded env24633 := by
  intro p hp
  have h : env24633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24632_24633 : H12AffineEnvironment.transform 4 0 env24632 = env24633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env24632 == env24633) = true)

theorem identity24633 : scanCanonicalize (H12AffineFastState.compose env24633 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound24633 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24634 : List Nat := [2,4,8,11,0,10,9,5,0,1024,1,1039,9,1039,0,2,1039,1,1024,1,1039,0,10,3,8,11,1,1039,1039,1,1024,0,4,1,1039,0]

theorem envBound24634 : H12AffineFastState.Bounded env24634 := by
  intro p hp
  have h : env24634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24633_24634 : H12AffineEnvironment.transform 3 11 env24633 = env24634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env24633 == env24634) = true)

def leafEnv24634 : List Nat := [2,4,8,11,0,10,9,5,0,1024,1,1039,9,1039,0,2,1039,1,1024,1,1039,0,10,3,1024,8,1,11,1,1039,1039,1,1024,0,4,1,5,3,1039,0,0,1039,1]

def active24634 : List Nat := [0,1,2,9]

def tree24634 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24634 : H12WitnessSearch.Good tree24634 := H12GlobalWitnessIndex.good

theorem leafIdentity24634 : H12AffineFastState.composeSystem env24634 rootObs = leafEnv24634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24634 rootObs == leafEnv24634) = true)

theorem terminalChecked24634 : H12PackedTerminal.terminalCheckFast leafEnv24634 active24634 tree24634 = true := by decide +kernel

def env24635 : List Nat := [2,4,8,16,1,17,9,30,0,1024,1,1044,8,1039,1,3,1044,0,1024,0,1044,0,17,3,9,16,0,1039,1039,1,1024,27,31,27,1044,0]

theorem envBound24635 : H12AffineFastState.Bounded env24635 := by
  intro p hp
  have h : env24635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24632_24635 : H12AffineEnvironment.transform 4 1 env24632 = env24635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env24632 == env24635) = true)

def leafEnv24635 : List Nat := [2,4,8,16,1,17,9,30,0,1024,1,1044,8,1039,1,3,1044,0,1024,0,1044,0,17,3,1024,9,1,16,0,1039,1039,1,1024,27,31,27,5,2,1044,0,0,1039,1]

def active24635 : List Nat := [0,1,2,3,9]

def tree24635 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24635 : H12WitnessSearch.Good tree24635 := H12GlobalWitnessIndex.good

theorem leafIdentity24635 : H12AffineFastState.composeSystem env24635 rootObs = leafEnv24635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24635 rootObs == leafEnv24635) = true)

theorem terminalChecked24635 : H12PackedTerminal.terminalCheckFast leafEnv24635 active24635 tree24635 = true := by decide +kernel

def env24636 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1093,8192,1297,8280,65536,1093,8401,1024,8281,1093,216,17,73817,8328,65,8201,1297,1297,75787,1024,65831,257,8461,1093,137]

theorem envBound24636 : H12AffineFastState.Bounded env24636 := by
  intro p hp
  have h : env24636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24607_24636 : H12AffineEnvironment.transform 17 8401 env24607 = env24636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8401 env24607 == env24636) = true)

def env24637 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,16384,32768,65536,4096,262144,524288,32769,529409,566400,525329,103492,8328,67108864,831685,1297,1297,1073741824,67638276,4294967296,525569,4295569519,67113024,137]

theorem envBound24637 : H12AffineFastState.Bounded env24637 := by
  intro p hp
  have h : env24637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24584_24637 : H12AffineEnvironment.transform 20 529409 env24584 = env24637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 529409 env24584 == env24637) = true)

theorem identity24637 : scanCanonicalize (H12AffineFastState.compose env24637 (packedSelected [14] rootPS)) = affineNative (2^(18+1) ^^^ 16656) := by decide +kernel

theorem selectedBound24637 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env24638 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,16384,32768,65536,4096,262144,16656,32769,21777,58768,17665,103492,8328,67108864,324053,1297,1297,1073741824,67130644,4294967296,17425,4295061887,67113024,137]

theorem envBound24638 : H12AffineFastState.Bounded env24638 := by
  intro p hp
  have h : env24638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24637_24638 : H12AffineEnvironment.transform 18 16656 env24637 = env24638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 16656 env24637 == env24638) = true)

theorem identity24638 : scanCanonicalize (H12AffineFastState.compose env24638 (packedSelected [0,27] rootPS)) = affineNative (2^(25+1) ^^^ 17745) := by decide +kernel

theorem selectedBound24638 : packedSelected [0,27] rootPS < 2^1333 := by decide +kernel

def env24639 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,16384,32768,65536,4096,262144,16656,32769,21777,58768,17665,103492,8328,17745,324053,1297,1297,1073741824,4165,4294967296,17425,4295061887,21777,137]

theorem envBound24639 : H12AffineFastState.Bounded env24639 := by
  intro p hp
  have h : env24639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24638_24639 : H12AffineEnvironment.transform 25 17745 env24638 = env24639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 17745 env24638 == env24639) = true)

theorem identity24639 : scanCanonicalize (H12AffineFastState.compose env24639 (packedSelected [1,12,13] rootPS)) = affineNative (2^(29+1) ^^^ 336034) := by decide +kernel

theorem selectedBound24639 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env24640 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,16384,32768,65536,4096,262144,16656,32769,21777,58768,17665,103492,8328,17745,324053,1297,1297,336034,4165,4294967296,17425,4295061887,21777,137]

theorem envBound24640 : H12AffineFastState.Bounded env24640 := by
  intro p hp
  have h : env24640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24639_24640 : H12AffineEnvironment.transform 29 336034 env24639 = env24640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 336034 env24639 == env24640) = true)

theorem identity24640 : scanCanonicalize (H12AffineFastState.compose env24640 (packedSelected [3,15,17] rootPS)) = affineNative (2^(17+1) ^^^ 121207) := by decide +kernel

theorem selectedBound24640 : packedSelected [3,15,17] rootPS < 2^1333 := by decide +kernel

def env24641 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,16384,32768,65536,4096,121207,16656,32769,21777,58768,17665,103492,8328,17745,75938,1297,1297,63957,4165,4294967296,17425,4295061887,21777,137]

theorem envBound24641 : H12AffineFastState.Bounded env24641 := by
  intro p hp
  have h : env24641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24640_24641 : H12AffineEnvironment.transform 17 121207 env24640 = env24641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 121207 env24640 == env24641) = true)

theorem identity24641 : scanCanonicalize (H12AffineFastState.compose env24641 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 29022) := by decide +kernel

theorem selectedBound24641 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env24642 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,16384,32768,29022,4096,43049,16656,32769,21777,58768,17665,58650,8328,17745,23036,1297,1297,63957,4165,4294967296,17425,4294967329,21777,137]

theorem envBound24642 : H12AffineFastState.Bounded env24642 := by
  intro p hp
  have h : env24642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24641_24642 : H12AffineEnvironment.transform 15 29022 env24641 = env24642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29022 env24641 == env24642) = true)

theorem identity24642 : scanCanonicalize (H12AffineFastState.compose env24642 (packedSelected [0,2,4,6,11] rootPS)) = affineNative (2^(14+1) ^^^ 26000) := by decide +kernel

theorem selectedBound24642 : packedSelected [0,2,4,6,11] rootPS < 2^1333 := by decide +kernel

def env24643 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,16384,26000,29022,4096,19897,16656,26001,21777,0,17665,138,8328,17745,23036,1297,1297,7237,4165,4294967296,17425,4294967329,21777,137]

theorem envBound24643 : H12AffineFastState.Bounded env24643 := by
  intro p hp
  have h : env24643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24642_24643 : H12AffineEnvironment.transform 14 26000 env24642 = env24643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26000 env24642 == env24643) = true)

theorem identity24643 : scanCanonicalize (H12AffineFastState.compose env24643 (packedSelected [1,3,5] rootPS)) = affineNative (2^(11+1) ^^^ 1181) := by decide +kernel

theorem selectedBound24643 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env24644 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1181,8192,16384,26000,26051,1181,19897,16656,26001,16780,0,17665,138,8328,17745,19809,1297,1297,2264,1240,4294967296,17425,4294967329,16780,137]

theorem envBound24644 : H12AffineFastState.Bounded env24644 := by
  intro p hp
  have h : env24644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24643_24644 : H12AffineEnvironment.transform 11 1181 env24643 = env24644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1181 env24643 == env24644) = true)

def env24645 : List Nat := [2,4,8,16,32,64,88,256,81,1024,2048,1093,8192,16384,25928,25883,1093,19809,16656,25929,16724,0,17665,82,8272,17745,19809,1297,1297,2048,1024,4294967296,17425,4294967329,16724,81]

theorem envBound24645 : H12AffineFastState.Bounded env24645 := by
  intro p hp
  have h : env24645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24644_24645 : H12AffineEnvironment.transform 6 88 env24644 = env24645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env24644 == env24645) = true)

theorem identity24645 : scanCanonicalize (H12AffineFastState.compose env24645 (packedSelected [0,6] rootPS)) = affineNative (2^(13+1) ^^^ 11624) := by decide +kernel

theorem selectedBound24645 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env24646 : List Nat := [2,4,8,16,32,64,88,256,81,1024,2048,1093,8192,11624,2080,2163,1093,8201,11384,2081,11324,0,10345,82,8272,10297,8201,1297,1297,2048,1024,4294967296,10617,4294967329,11324,81]

theorem envBound24646 : H12AffineFastState.Bounded env24646 := by
  intro p hp
  have h : env24646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24645_24646 : H12AffineEnvironment.transform 13 11624 env24645 = env24646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11624 env24645 == env24646) = true)

theorem identity24646 : scanCanonicalize (H12AffineFastState.compose env24646 (packedSelected [2,4] rootPS)) = affineNative (2^(12+1) ^^^ 2396) := by decide +kernel

theorem selectedBound24646 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env24647 : List Nat := [2,4,8,16,32,64,88,256,81,1024,2048,1093,2396,1076,2080,2163,1093,2389,1316,2081,1376,0,309,82,2316,357,2389,1297,1297,2048,1024,4294967296,37,4294967329,1376,81]

theorem envBound24647 : H12AffineFastState.Bounded env24647 := by
  intro p hp
  have h : env24647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24646_24647 : H12AffineEnvironment.transform 12 2396 env24646 = env24647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2396 env24646 == env24647) = true)

theorem identity24647 : scanCanonicalize (H12AffineFastState.compose env24647 (packedSelected [0,1,2] rootPS)) = affineNative (2^(7+1) ^^^ 110) := by decide +kernel

theorem selectedBound24647 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env24648 : List Nat := [2,4,8,16,32,64,88,110,81,1024,2048,1093,2098,1076,2080,2163,1093,2107,1098,2081,1038,0,91,82,2146,11,2107,1151,1151,2048,1024,4294967296,37,4294967329,1038,81]

theorem envBound24648 : H12AffineFastState.Bounded env24648 := by
  intro p hp
  have h : env24648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24647_24648 : H12AffineEnvironment.transform 7 110 env24647 = env24648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 110 env24647 == env24648) = true)

def env24649 : List Nat := [2,4,8,16,32,48,40,30,33,1024,2048,1077,2098,1076,2080,2051,1077,2107,1082,2081,1038,0,43,34,2066,11,2107,1039,1039,2048,1024,4294967296,37,4294967329,1038,33]

theorem envBound24649 : H12AffineFastState.Bounded env24649 := by
  intro p hp
  have h : env24649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24648_24649 : H12AffineEnvironment.transform 5 48 env24648 = env24649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env24648 == env24649) = true)

theorem identity24649 : scanCanonicalize (H12AffineFastState.compose env24649 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 2106) := by decide +kernel

theorem selectedBound24649 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24650 : List Nat := [2,4,8,16,32,48,40,30,33,1024,2048,1077,2098,1076,2080,2051,1077,2107,1082,2081,1038,0,43,34,2066,11,2107,1039,1039,2048,1024,2106,37,2075,1038,33]

theorem envBound24650 : H12AffineFastState.Bounded env24650 := by
  intro p hp
  have h : env24650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24649_24650 : H12AffineEnvironment.transform 31 2106 env24649 = env24650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 2106 env24649 == env24650) = true)

def env24651 : List Nat := [2,4,8,16,32,48,40,30,33,1024,0,1077,50,1076,32,3,1077,59,1082,33,1038,0,43,34,18,11,59,1039,1039,0,1024,58,37,27,1038,33]

theorem envBound24651 : H12AffineFastState.Bounded env24651 := by
  intro p hp
  have h : env24651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24650_24651 : H12AffineEnvironment.transform 10 0 env24650 = env24651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env24650 == env24651) = true)

theorem identity24651 : scanCanonicalize (H12AffineFastState.compose env24651 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound24651 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24652 : List Nat := [2,4,8,11,32,43,40,5,33,1024,0,1070,41,1071,32,3,1070,32,1057,33,1038,0,43,34,9,11,32,1039,1039,0,1024,33,37,0,1038,33]

theorem envBound24652 : H12AffineFastState.Bounded env24652 := by
  intro p hp
  have h : env24652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24651_24652 : H12AffineEnvironment.transform 3 11 env24651 = env24652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env24651 == env24652) = true)

def leafEnv24652 : List Nat := [2,4,8,11,32,43,40,5,33,1024,0,1070,41,1071,32,3,1070,32,1057,33,1038,0,43,34,1057,9,1,11,32,1039,1039,0,1024,33,37,0,36,35,1038,33,0,1071,1]

def active24652 : List Nat := [0,1,2,4,9]

def tree24652 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24652 : H12WitnessSearch.Good tree24652 := H12GlobalWitnessIndex.good

theorem leafIdentity24652 : H12AffineFastState.composeSystem env24652 rootObs = leafEnv24652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24652 rootObs == leafEnv24652) = true)

theorem terminalChecked24652 : H12PackedTerminal.terminalCheckFast leafEnv24652 active24652 tree24652 = true := by decide +kernel

def env24653 : List Nat := [2,4,8,16,32,48,40,30,33,1024,1,1077,51,1076,33,2,1077,58,1082,32,1038,0,43,34,19,11,58,1039,1039,1,1024,59,37,26,1038,33]

theorem envBound24653 : H12AffineFastState.Bounded env24653 := by
  intro p hp
  have h : env24653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24650_24653 : H12AffineEnvironment.transform 10 1 env24650 = env24653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env24650 == env24653) = true)

theorem identity24653 : scanCanonicalize (H12AffineFastState.compose env24653 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound24653 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24654 : List Nat := [2,4,8,16,27,11,19,30,26,1024,1,1038,8,1039,26,2,1038,1,1025,27,1038,0,16,25,19,11,1,1039,1039,1,1024,0,30,26,1038,26]

theorem envBound24654 : H12AffineFastState.Bounded env24654 := by
  intro p hp
  have h : env24654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24653_24654 : H12AffineEnvironment.transform 4 27 env24653 = env24654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env24653 == env24654) = true)

def leafEnv24654 : List Nat := [2,4,8,16,27,11,19,30,26,1024,1,1038,8,1039,26,2,1038,1,1025,27,1038,0,16,25,1025,19,1,11,1,1039,1039,1,1024,0,30,26,4,25,1038,26,0,1039,1]

def active24654 : List Nat := [0,1,2,3,9]

def tree24654 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24654 : H12WitnessSearch.Good tree24654 := H12GlobalWitnessIndex.good

theorem leafIdentity24654 : H12AffineFastState.composeSystem env24654 rootObs = leafEnv24654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24654 rootObs == leafEnv24654) = true)

theorem terminalChecked24654 : H12PackedTerminal.terminalCheckFast leafEnv24654 active24654 tree24654 = true := by decide +kernel

def env24655 : List Nat := [2,4,8,16,32,49,41,31,32,1024,2048,1076,2098,1076,2080,2050,1076,2107,1083,2081,1038,0,42,35,2067,11,2107,1038,1038,2048,1024,4294967296,37,4294967329,1038,32]

theorem envBound24655 : H12AffineFastState.Bounded env24655 := by
  intro p hp
  have h : env24655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24648_24655 : H12AffineEnvironment.transform 5 49 env24648 = env24655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env24648 == env24655) = true)

theorem identity24655 : scanCanonicalize (H12AffineFastState.compose env24655 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 2049) := by decide +kernel

theorem selectedBound24655 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24656 : List Nat := [2,4,8,16,32,49,41,31,32,1024,2048,1076,2098,1076,2080,2050,1076,2107,1083,2081,1038,0,42,35,2067,11,2107,1038,1038,2048,1024,2049,37,2080,1038,32]

theorem envBound24656 : H12AffineFastState.Bounded env24656 := by
  intro p hp
  have h : env24656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24655_24656 : H12AffineEnvironment.transform 31 2049 env24655 = env24656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 2049 env24655 == env24656) = true)

def env24657 : List Nat := [2,4,8,16,0,17,9,31,0,1024,2048,1044,2066,1044,2048,2050,1044,2075,1051,2049,1038,0,10,3,2067,11,2075,1038,1038,2048,1024,2049,5,2048,1038,0]

theorem envBound24657 : H12AffineFastState.Bounded env24657 := by
  intro p hp
  have h : env24657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24656_24657 : H12AffineEnvironment.transform 4 0 env24656 = env24657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env24656 == env24657) = true)

def env24658 : List Nat := [2,4,8,16,1,16,8,31,1,1024,2048,1045,2067,1045,2049,2050,1045,2074,1050,2048,1038,0,11,2,2067,11,2074,1038,1038,2048,1024,2049,4,2049,1038,1]

theorem envBound24658 : H12AffineFastState.Bounded env24658 := by
  intro p hp
  have h : env24658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24656_24658 : H12AffineEnvironment.transform 4 1 env24656 = env24658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env24656 == env24658) = true)

theorem identity24658 : scanCanonicalize (H12AffineFastState.compose env24658 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 27) := by decide +kernel

theorem selectedBound24658 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24659 : List Nat := [2,4,8,16,1,16,8,31,1,1024,27,1045,8,1045,26,25,1045,1,1050,27,1038,0,11,2,8,11,1,1038,1038,27,1024,26,4,26,1038,1]

theorem envBound24659 : H12AffineFastState.Bounded env24659 := by
  intro p hp
  have h : env24659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24658_24659 : H12AffineEnvironment.transform 10 27 env24658 = env24659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 27 env24658 == env24659) = true)

def leafEnv24659 : List Nat := [2,4,8,16,1,16,8,31,1,1024,27,1045,8,1045,26,25,1045,1,1050,27,1038,0,11,2,1050,8,1,11,1,1038,1038,27,1024,26,4,26,31,25,1038,1,0,1045,1]

def active24659 : List Nat := [0,1,2,3,9]

def tree24659 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24659 : H12WitnessSearch.Good tree24659 := H12GlobalWitnessIndex.good

theorem leafIdentity24659 : H12AffineFastState.composeSystem env24659 rootObs = leafEnv24659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24659 rootObs == leafEnv24659) = true)

theorem terminalChecked24659 : H12PackedTerminal.terminalCheckFast leafEnv24659 active24659 tree24659 = true := by decide +kernel

def env24660 : List Nat := [2,4,8,16,32,64,89,256,80,1024,2048,1092,8192,16384,25929,25882,1092,19808,16656,25928,16725,0,17665,83,8273,17745,19809,1297,1297,2049,1025,4294967296,17425,4294967329,16725,80]

theorem envBound24660 : H12AffineFastState.Bounded env24660 := by
  intro p hp
  have h : env24660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24644_24660 : H12AffineEnvironment.transform 6 89 env24644 = env24660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env24644 == env24660) = true)

theorem identity24660 : scanCanonicalize (H12AffineFastState.compose env24660 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound24660 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24661 : List Nat := [2,4,8,16,32,64,89,84,80,1024,2048,1092,8192,16384,25629,25678,1092,19508,16452,25628,16385,0,17493,83,8273,17413,19509,1093,1093,2049,1025,4294967296,17425,4294967329,16385,80]

theorem envBound24661 : H12AffineFastState.Bounded env24661 := by
  intro p hp
  have h : env24661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24660_24661 : H12AffineEnvironment.transform 7 84 env24660 = env24661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env24660 == env24661) = true)

theorem identity24661 : scanCanonicalize (H12AffineFastState.compose env24661 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 8200) := by decide +kernel

theorem selectedBound24661 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24662 : List Nat := [2,4,8,16,32,64,89,84,80,1024,2048,1092,8192,16384,25629,25678,1092,19508,16452,25628,16385,0,17493,83,8273,17413,19509,1093,1093,2049,1025,8200,17425,8233,16385,80]

theorem envBound24662 : H12AffineFastState.Bounded env24662 := by
  intro p hp
  have h : env24662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24661_24662 : H12AffineEnvironment.transform 31 8200 env24661 = env24662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 8200 env24661 == env24662) = true)

theorem identity24662 : scanCanonicalize (H12AffineFastState.compose env24662 (packedSelected [6] rootPS)) = affineNative (2^(13+1) ^^^ 1077) := by decide +kernel

theorem selectedBound24662 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env24663 : List Nat := [2,4,8,16,32,64,89,84,80,1024,2048,1092,8192,1077,8232,8315,1092,2049,1137,8233,1076,0,96,83,8273,48,2048,1093,1093,2049,1025,8200,36,8233,1076,80]

theorem envBound24663 : H12AffineFastState.Bounded env24663 := by
  intro p hp
  have h : env24663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24662_24663 : H12AffineEnvironment.transform 13 1077 env24662 = env24663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1077 env24662 == env24663) = true)

theorem identity24663 : scanCanonicalize (H12AffineFastState.compose env24663 (packedSelected [1,2] rootPS)) = affineNative (2^(12+1) ^^^ 2099) := by decide +kernel

theorem selectedBound24663 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env24664 : List Nat := [2,4,8,16,32,64,89,84,80,1024,2048,1092,2099,1077,2075,2120,1092,2049,1137,2074,1076,0,96,83,2146,48,2048,1093,1093,2049,1025,2107,36,2074,1076,80]

theorem envBound24664 : H12AffineFastState.Bounded env24664 := by
  intro p hp
  have h : env24664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24663_24664 : H12AffineEnvironment.transform 12 2099 env24663 = env24664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2099 env24663 == env24664) = true)

theorem identity24664 : scanCanonicalize (H12AffineFastState.compose env24664 (packedSelected [1,4] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound24664 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env24665 : List Nat := [2,4,8,16,26,64,89,84,80,1024,2048,1092,2057,1039,2075,2120,1092,2049,1099,2074,1038,0,90,83,2136,10,2048,1093,1093,2049,1025,2049,30,2074,1038,80]

theorem envBound24665 : H12AffineFastState.Bounded env24665 := by
  intro p hp
  have h : env24665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24664_24665 : H12AffineEnvironment.transform 4 26 env24664 = env24665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env24664 == env24665) = true)

def env24666 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,16384,32768,65536,4096,262144,524288,32769,2097152,566401,525329,103493,8328,67108864,831685,1296,1296,1073741824,67638277,4294967296,525569,4295569519,69731392,137]

theorem envBound24666 : H12AffineFastState.Bounded env24666 := by
  intro p hp
  have h : env24666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24583_24666 : H12AffineEnvironment.transform 21 566401 env24583 = env24666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 566401 env24583 == env24666) = true)

def env24667 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,16384,32768,65536,4096,262144,524288,32769,529408,566401,525329,103493,8328,67108864,831685,1296,1296,1073741824,67638277,4294967296,525569,4295569519,67113024,137]

theorem envBound24667 : H12AffineFastState.Bounded env24667 := by
  intro p hp
  have h : env24667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24666_24667 : H12AffineEnvironment.transform 20 529408 env24666 = env24667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 529408 env24666 == env24667) = true)

def env24668 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,16384,32768,65536,4096,262144,524288,32769,529408,566401,525329,103493,8328,525376,831685,1296,1296,1073741824,4165,4294967296,525569,4295569519,529408,137]

theorem envBound24668 : H12AffineFastState.Bounded env24668 := by
  intro p hp
  have h : env24668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24667_24668 : H12AffineEnvironment.transform 25 525376 env24667 = env24668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 525376 env24667 == env24668) = true)

theorem identity24668 : scanCanonicalize (H12AffineFastState.compose env24668 (packedSelected [3,5,24] rootPS)) = affineNative (2^(18+1) ^^^ 42113) := by decide +kernel

theorem selectedBound24668 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env24669 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,16384,32768,65536,4096,262144,42113,32769,45185,0,41104,103493,8328,41153,267332,1296,1296,1073741824,4165,4294967296,41344,4295070958,45185,137]

theorem envBound24669 : H12AffineFastState.Bounded env24669 := by
  intro p hp
  have h : env24669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24668_24669 : H12AffineEnvironment.transform 18 42113 env24668 = env24669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 42113 env24668 == env24669) = true)

def env24670 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,16384,32768,65536,4096,262144,524288,32769,529408,566401,525329,103493,8328,525377,831685,1296,1296,1073741824,4164,4294967296,525569,4295569519,529409,137]

theorem envBound24670 : H12AffineFastState.Bounded env24670 := by
  intro p hp
  have h : env24670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24667_24670 : H12AffineEnvironment.transform 25 525377 env24667 = env24670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 525377 env24667 == env24670) = true)

theorem identity24670 : scanCanonicalize (H12AffineFastState.compose env24670 (packedSelected [3,5,24] rootPS)) = affineNative (2^(17+1) ^^^ 8200) := by decide +kernel

theorem selectedBound24670 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env24671 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,16384,32768,65536,4096,8200,524288,32769,529408,566401,525329,103493,8328,525377,561357,1296,1296,1073741824,4164,4294967296,525569,4295569519,529409,137]

theorem envBound24671 : H12AffineFastState.Bounded env24671 := by
  intro p hp
  have h : env24671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24670_24671 : H12AffineEnvironment.transform 17 8200 env24670 = env24671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8200 env24670 == env24671) = true)

theorem identity24671 : scanCanonicalize (H12AffineFastState.compose env24671 (packedSelected [0,27] rootPS)) = affineNative (2^(18+1) ^^^ 16657) := by decide +kernel

theorem selectedBound24671 : packedSelected [0,27] rootPS < 2^1333 := by decide +kernel

def env24672 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,16384,32768,65536,4096,8200,16657,32769,21777,58768,17664,103493,8328,17744,53724,1296,1296,1073741824,4164,4294967296,17424,4295061886,21776,137]

theorem envBound24672 : H12AffineFastState.Bounded env24672 := by
  intro p hp
  have h : env24672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24671_24672 : H12AffineEnvironment.transform 18 16657 env24671 = env24672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 16657 env24671 == env24672) = true)

theorem identity24672 : scanCanonicalize (H12AffineFastState.compose env24672 (packedSelected [1,12,13] rootPS)) = affineNative (2^(15+1) ^^^ 7406) := by decide +kernel

theorem selectedBound24672 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env24673 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,16384,32768,7406,4096,8200,16657,32769,21777,58768,17664,34987,8328,17744,53724,1296,1296,1073741824,4164,4294967296,17424,4294995344,21776,137]

theorem envBound24673 : H12AffineFastState.Bounded env24673 := by
  intro p hp
  have h : env24673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24672_24673 : H12AffineEnvironment.transform 15 7406 env24672 = env24673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 7406 env24672 == env24673) = true)

theorem identity24673 : scanCanonicalize (H12AffineFastState.compose env24673 (packedSelected [1,3,8] rootPS)) = affineNative (2^(14+1) ^^^ 28941) := by decide +kernel

theorem selectedBound24673 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env24674 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,16384,28941,7406,4096,8200,16657,28940,21777,5277,17664,31142,8328,17744,8401,1296,1296,1073741824,4164,4294967296,17424,4294995344,21776,137]

theorem envBound24674 : H12AffineFastState.Bounded env24674 := by
  intro p hp
  have h : env24674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24673_24674 : H12AffineEnvironment.transform 14 28941 env24673 = env24674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 28941 env24673 == env24674) = true)

theorem identity24674 : scanCanonicalize (H12AffineFastState.compose env24674 (packedSelected [3,15,17] rootPS)) = affineNative (2^(13+1) ^^^ 14636) := by decide +kernel

theorem selectedBound24674 : packedSelected [3,15,17] rootPS < 2^1333 := by decide +kernel

def env24675 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,14636,2081,7406,4096,8200,14397,2080,11325,5277,15404,138,8328,15484,8401,1296,1296,1073741824,4164,4294967296,15676,4294972604,11324,137]

theorem envBound24675 : H12AffineFastState.Bounded env24675 := by
  intro p hp
  have h : env24675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24674_24675 : H12AffineEnvironment.transform 13 14636 env24674 = env24675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 14636 env24674 == env24675) = true)

theorem identity24675 : scanCanonicalize (H12AffineFastState.compose env24675 (packedSelected [11,32] rootPS)) = affineNative (2^(29+1) ^^^ 2265) := by decide +kernel

theorem selectedBound24675 : packedSelected [11,32] rootPS < 2^1333 := by decide +kernel

def env24676 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,14636,2081,7406,4096,8200,14397,2080,11325,5277,15404,138,8328,15484,8401,1296,1296,2265,4164,4294967296,15676,4294972604,11324,137]

theorem envBound24676 : H12AffineFastState.Bounded env24676 := by
  intro p hp
  have h : env24676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24675_24676 : H12AffineEnvironment.transform 29 2265 env24675 = env24676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 2265 env24675 == env24676) = true)

def env24677 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1296,8192,11324,2081,2558,1296,8200,11565,2080,11325,397,10556,138,8328,10604,8401,1296,1296,2265,1364,4294967296,10284,4294967724,11324,137]

theorem envBound24677 : H12AffineFastState.Bounded env24677 := by
  intro p hp
  have h : env24677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24676_24677 : H12AffineEnvironment.transform 11 1296 env24676 = env24677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env24676 == env24677) = true)

theorem identity24677 : scanCanonicalize (H12AffineFastState.compose env24677 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 2056) := by decide +kernel

theorem selectedBound24677 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24678 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1296,2056,1076,2081,2558,1296,2048,1317,2080,1077,397,308,138,2176,356,2265,1296,1296,2265,1364,4294967296,36,4294967724,1076,137]

theorem envBound24678 : H12AffineFastState.Bounded env24678 := by
  intro p hp
  have h : env24678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24677_24678 : H12AffineEnvironment.transform 12 2056 env24677 = env24678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2056 env24677 == env24678) = true)

theorem identity24678 : scanCanonicalize (H12AffineFastState.compose env24678 (packedSelected [2,4] rootPS)) = affineNative (2^(7+1) ^^^ 140) := by decide +kernel

theorem selectedBound24678 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env24679 : List Nat := [2,4,8,16,32,64,128,140,137,1024,2048,1180,2056,1076,2081,2162,1180,2048,1193,2080,1077,1,184,138,2176,232,2265,1180,1180,2265,1240,4294967296,36,4294967328,1076,137]

theorem envBound24679 : H12AffineFastState.Bounded env24679 := by
  intro p hp
  have h : env24679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24678_24679 : H12AffineEnvironment.transform 7 140 env24678 = env24679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 140 env24678 == env24679) = true)

theorem identity24679 : scanCanonicalize (H12AffineFastState.compose env24679 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 2216) := by decide +kernel

theorem selectedBound24679 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24680 : List Nat := [2,4,8,16,32,64,128,140,137,1024,2048,1180,2056,1076,2081,2162,1180,2048,1193,2080,1077,1,184,138,2176,232,2265,1180,1180,2265,1240,2216,36,2184,1076,137]

theorem envBound24680 : H12AffineFastState.Bounded env24680 := by
  intro p hp
  have h : env24680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24679_24680 : H12AffineEnvironment.transform 31 2216 env24679 = env24680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 2216 env24679 == env24680) = true)

theorem identity24680 : scanCanonicalize (H12AffineFastState.compose env24680 (packedSelected [6] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound24680 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env24681 : List Nat := [2,4,8,16,32,64,88,84,81,1024,2048,1092,2056,1076,2081,2162,1092,2048,1137,2080,1077,1,96,82,2136,48,2049,1092,1092,2049,1024,2160,36,2128,1076,81]

theorem envBound24681 : H12AffineFastState.Bounded env24681 := by
  intro p hp
  have h : env24681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24680_24681 : H12AffineEnvironment.transform 6 88 env24680 = env24681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env24680 == env24681) = true)

theorem identity24681 : scanCanonicalize (H12AffineFastState.compose env24681 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound24681 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env24682 : List Nat := [2,4,8,16,26,64,88,84,81,1024,2048,1092,2056,1038,2075,2120,1092,2048,1099,2074,1039,1,90,82,2136,10,2049,1092,1092,2049,1024,2122,30,2128,1038,81]

theorem envBound24682 : H12AffineFastState.Bounded env24682 := by
  intro p hp
  have h : env24682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24681_24682 : H12AffineEnvironment.transform 4 26 env24681 = env24682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env24681 == env24682) = true)

def env24683 : List Nat := [2,4,8,16,26,64,88,84,81,1024,0,1092,8,1038,27,72,1092,0,1099,26,1039,1,90,82,88,10,1,1092,1092,1,1024,74,30,80,1038,81]

theorem envBound24683 : H12AffineFastState.Bounded env24683 := by
  intro p hp
  have h : env24683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24682_24683 : H12AffineEnvironment.transform 10 0 env24682 = env24683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env24682 == env24683) = true)

theorem identity24683 : scanCanonicalize (H12AffineFastState.compose env24683 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound24683 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24684 : List Nat := [2,4,8,10,0,64,66,78,75,1024,0,1092,8,1038,1,72,1092,0,1099,0,1039,1,64,72,66,10,1,1092,1092,1,1024,74,4,74,1038,75]

theorem envBound24684 : H12AffineFastState.Bounded env24684 := by
  intro p hp
  have h : env24684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24683_24684 : H12AffineEnvironment.transform 3 10 env24683 = env24684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env24683 == env24684) = true)

def leafEnv24684 : List Nat := [2,4,8,10,0,64,66,78,75,1024,0,1092,8,1038,1,72,1092,0,1099,0,1039,1,64,72,1099,66,1,10,1,1092,1092,1,1024,74,4,74,78,2,1038,75,0,1039,1]

def active24684 : List Nat := [0,1,2,5,9]

def tree24684 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24684 : H12WitnessSearch.Good tree24684 := H12GlobalWitnessIndex.good

theorem leafIdentity24684 : H12AffineFastState.composeSystem env24684 rootObs = leafEnv24684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24684 rootObs == leafEnv24684) = true)

theorem terminalChecked24684 : H12PackedTerminal.terminalCheckFast leafEnv24684 active24684 tree24684 = true := by decide +kernel

def env24685 : List Nat := [2,4,8,16,26,64,88,84,81,1024,1,1092,9,1038,26,73,1092,1,1099,27,1039,1,90,82,89,10,0,1092,1092,0,1024,75,30,81,1038,81]

theorem envBound24685 : H12AffineFastState.Bounded env24685 := by
  intro p hp
  have h : env24685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24682_24685 : H12AffineEnvironment.transform 10 1 env24682 = env24685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env24682 == env24685) = true)

def env24686 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1297,8192,11325,2081,2559,1297,8200,11564,2080,11325,396,10557,138,8328,10605,8401,1296,1296,2265,1365,4294967296,10285,4294967725,11324,137]

theorem envBound24686 : H12AffineFastState.Bounded env24686 := by
  intro p hp
  have h : env24686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24676_24686 : H12AffineEnvironment.transform 11 1297 env24676 = env24686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env24676 == env24686) = true)

theorem identity24686 : scanCanonicalize (H12AffineFastState.compose env24686 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 2257) := by decide +kernel

theorem selectedBound24686 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24687 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1297,2257,1260,2081,2559,1297,2265,1533,2080,1260,396,492,138,2137,444,2048,1296,1296,2265,1365,4294967296,252,4294967725,1261,137]

theorem envBound24687 : H12AffineFastState.Bounded env24687 := by
  intro p hp
  have h : env24687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24686_24687 : H12AffineEnvironment.transform 12 2257 env24686 = env24687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2257 env24686 == env24687) = true)

theorem identity24687 : scanCanonicalize (H12AffineFastState.compose env24687 (packedSelected [1,2] rootPS)) = affineNative (2^(31+1) ^^^ 2274) := by decide +kernel

theorem selectedBound24687 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env24688 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1297,2257,1260,2081,2559,1297,2265,1533,2080,1260,396,492,138,2137,444,2048,1296,1296,2265,1365,2274,252,2383,1261,137]

theorem envBound24688 : H12AffineFastState.Bounded env24688 := by
  intro p hp
  have h : env24688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24687_24688 : H12AffineEnvironment.transform 31 2274 env24687 = env24688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 2274 env24687 == env24688) = true)

theorem identity24688 : scanCanonicalize (H12AffineFastState.compose env24688 (packedSelected [0,1,4] rootPS)) = affineNative (2^(7+1) ^^^ 110) := by decide +kernel

theorem selectedBound24688 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env24689 : List Nat := [2,4,8,16,32,64,128,110,137,1024,2048,1151,2257,1260,2081,2193,1151,2265,1171,2080,1260,226,130,138,2137,210,2048,1150,1150,2265,1083,2274,252,2081,1261,137]

theorem envBound24689 : H12AffineFastState.Bounded env24689 := by
  intro p hp
  have h : env24689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24688_24689 : H12AffineEnvironment.transform 7 110 env24688 = env24689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 110 env24688 == env24689) = true)

theorem identity24689 : scanCanonicalize (H12AffineFastState.compose env24689 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound24689 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env24690 : List Nat := [2,4,8,16,27,64,128,85,137,1024,2048,1092,2257,1239,2074,2193,1092,2265,1171,2075,1239,217,130,138,2137,210,2048,1093,1093,2265,1024,2265,199,2074,1238,137]

theorem envBound24690 : H12AffineFastState.Bounded env24690 := by
  intro p hp
  have h : env24690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24689_24690 : H12AffineEnvironment.transform 4 27 env24689 = env24690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env24689 == env24690) = true)

theorem identity24690 : scanCanonicalize (H12AffineFastState.compose env24690 (packedSelected [7] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound24690 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env24691 : List Nat := [2,4,8,16,27,64,88,85,81,1024,2048,1092,2057,1039,2074,2121,1092,2049,1099,2075,1039,1,90,82,2137,10,2048,1093,1093,2049,1024,2049,31,2074,1038,81]

theorem envBound24691 : H12AffineFastState.Bounded env24691 := by
  intro p hp
  have h : env24691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24690_24691 : H12AffineEnvironment.transform 6 88 env24690 = env24691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env24690 == env24691) = true)

def env24692 : List Nat := [2,4,8,16,27,64,88,85,81,1024,80,1092,89,1039,74,25,1092,81,1099,75,1039,1,90,82,9,10,80,1093,1093,81,1024,81,31,74,1038,81]

theorem envBound24692 : H12AffineFastState.Bounded env24692 := by
  intro p hp
  have h : env24692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24691_24692 : H12AffineEnvironment.transform 10 80 env24691 = env24692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env24691 == env24692) = true)

theorem identity24692 : scanCanonicalize (H12AffineFastState.compose env24692 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound24692 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24693 : List Nat := [2,4,8,16,27,17,9,4,0,1024,1,1045,8,1039,27,25,1045,0,1050,26,1039,1,11,3,9,10,1,1044,1044,0,1024,0,31,27,1038,0]

theorem envBound24693 : H12AffineFastState.Bounded env24693 := by
  intro p hp
  have h : env24693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24692_24693 : H12AffineEnvironment.transform 5 17 env24692 = env24693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env24692 == env24693) = true)

def leafEnv24693 : List Nat := [2,4,8,16,27,17,9,4,0,1024,1,1045,8,1039,27,25,1045,0,1050,26,1039,1,11,3,1050,9,1,10,1,1044,1044,0,1024,0,31,27,31,24,1038,0,0,1038,1]

def active24693 : List Nat := [0,1,2,3,9]

def tree24693 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24693 : H12WitnessSearch.Good tree24693 := H12GlobalWitnessIndex.good

theorem leafIdentity24693 : H12AffineFastState.composeSystem env24693 rootObs = leafEnv24693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24693 rootObs == leafEnv24693) = true)

theorem terminalChecked24693 : H12PackedTerminal.terminalCheckFast leafEnv24693 active24693 tree24693 = true := by decide +kernel

def env24694 : List Nat := [2,4,8,16,27,64,88,85,81,1024,81,1092,88,1039,75,24,1092,80,1099,74,1039,1,90,82,8,10,81,1093,1093,80,1024,80,31,75,1038,81]

theorem envBound24694 : H12AffineFastState.Bounded env24694 := by
  intro p hp
  have h : env24694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24691_24694 : H12AffineEnvironment.transform 10 81 env24691 = env24694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env24691 == env24694) = true)

theorem identity24694 : scanCanonicalize (H12AffineFastState.compose env24694 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound24694 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24695 : List Nat := [2,4,8,16,27,11,19,30,26,1024,26,1039,19,1039,0,24,1039,27,1024,1,1039,1,17,25,8,10,26,1038,1038,27,1024,27,31,0,1038,26]

theorem envBound24695 : H12AffineFastState.Bounded env24695 := by
  intro p hp
  have h : env24695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24694_24695 : H12AffineEnvironment.transform 5 11 env24694 = env24695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env24694 == env24695) = true)

def leafEnv24695 : List Nat := [2,4,8,16,27,11,19,30,26,1024,26,1039,19,1039,0,24,1039,27,1024,1,1039,1,17,25,1024,8,1,10,26,1038,1038,27,1024,27,31,0,5,3,1038,26,0,1038,1]

def active24695 : List Nat := [0,1,2,3,9]

def tree24695 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24695 : H12WitnessSearch.Good tree24695 := H12GlobalWitnessIndex.good

theorem leafIdentity24695 : H12AffineFastState.composeSystem env24695 rootObs = leafEnv24695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24695 rootObs == leafEnv24695) = true)

theorem terminalChecked24695 : H12PackedTerminal.terminalCheckFast leafEnv24695 active24695 tree24695 = true := by decide +kernel

def env24696 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,16384,32768,65536,4096,262144,524288,32769,529409,566401,525329,103493,8328,67108864,831685,1296,1296,1073741824,67638277,4294967296,525569,4295569519,67113025,137]

theorem envBound24696 : H12AffineFastState.Bounded env24696 := by
  intro p hp
  have h : env24696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24666_24696 : H12AffineEnvironment.transform 20 529409 env24666 = env24696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 529409 env24666 == env24696) = true)

theorem identity24696 : scanCanonicalize (H12AffineFastState.compose env24696 (packedSelected [14] rootPS)) = affineNative (2^(25+1) ^^^ 525377) := by decide +kernel

theorem selectedBound24696 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env24697 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,16384,32768,65536,4096,262144,524288,32769,529409,566401,525329,103493,8328,525377,831685,1296,1296,1073741824,4164,4294967296,525569,4295569519,529408,137]

theorem envBound24697 : H12AffineFastState.Bounded env24697 := by
  intro p hp
  have h : env24697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24696_24697 : H12AffineEnvironment.transform 25 525377 env24696 = env24697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 525377 env24696 == env24697) = true)

theorem identity24697 : scanCanonicalize (H12AffineFastState.compose env24697 (packedSelected [3,5,24] rootPS)) = affineNative (2^(18+1) ^^^ 299213) := by decide +kernel

theorem selectedBound24697 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env24698 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,16384,32768,65536,4096,262144,299213,32769,296140,275532,300252,103493,8328,300172,8200,1296,1296,1073741824,4164,4294967296,300492,4295336098,296141,137]

theorem envBound24698 : H12AffineFastState.Bounded env24698 := by
  intro p hp
  have h : env24698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24697_24698 : H12AffineEnvironment.transform 18 299213 env24697 = env24698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 299213 env24697 == env24698) = true)

theorem identity24698 : scanCanonicalize (H12AffineFastState.compose env24698 (packedSelected [0,27] rootPS)) = affineNative (2^(17+1) ^^^ 53725) := by decide +kernel

theorem selectedBound24698 : packedSelected [0,27] rootPS < 2^1333 := by decide +kernel

def env24699 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,16384,32768,65536,4096,53725,16656,32769,21777,58769,17665,103493,8328,17745,8200,1296,1296,1073741824,4164,4294967296,17425,4295061887,21776,137]

theorem envBound24699 : H12AffineFastState.Bounded env24699 := by
  intro p hp
  have h : env24699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24698_24699 : H12AffineEnvironment.transform 17 53725 env24698 = env24699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 53725 env24698 == env24699) = true)

theorem identity24699 : scanCanonicalize (H12AffineFastState.compose env24699 (packedSelected [1,12,13] rootPS)) = affineNative (2^(15+1) ^^^ 38095) := by decide +kernel

theorem selectedBound24699 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env24700 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,16384,32768,38095,4096,53725,16656,32769,21777,58769,17665,138,8328,17745,8200,1296,1296,1073741824,4164,4294967296,17425,4295026096,21776,137]

theorem envBound24700 : H12AffineFastState.Bounded env24700 := by
  intro p hp
  have h : env24700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24699_24700 : H12AffineEnvironment.transform 15 38095 env24699 = env24700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38095 env24699 == env24700) = true)

theorem identity24700 : scanCanonicalize (H12AffineFastState.compose env24700 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(29+1) ^^^ 28973) := by decide +kernel

theorem selectedBound24700 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env24701 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,16384,32768,38095,4096,53725,16656,32769,21777,58769,17665,138,8328,17745,8200,1296,1296,28973,4164,4294967296,17425,4295026096,21776,137]

theorem envBound24701 : H12AffineFastState.Bounded env24701 := by
  intro p hp
  have h : env24701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24700_24701 : H12AffineEnvironment.transform 29 28973 env24700 = env24701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 28973 env24700 == env24701) = true)

theorem identity24701 : scanCanonicalize (H12AffineFastState.compose env24701 (packedSelected [1,12,17] rootPS)) = affineNative (2^(14+1) ^^^ 28940) := by decide +kernel

theorem selectedBound24701 : packedSelected [1,12,17] rootPS < 2^1333 := by decide +kernel

def env24702 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,16384,28940,26051,4096,8401,16656,28941,21777,5277,17665,138,8328,17745,8200,1296,1296,28973,4164,4294967296,17425,4294972604,21776,137]

theorem envBound24702 : H12AffineFastState.Bounded env24702 := by
  intro p hp
  have h : env24702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24701_24702 : H12AffineEnvironment.transform 14 28940 env24701 = env24702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 28940 env24701 == env24702) = true)

theorem identity24702 : scanCanonicalize (H12AffineFastState.compose env24702 (packedSelected [18,23] rootPS)) = affineNative (2^(13+1) ^^^ 14836) := by decide +kernel

theorem selectedBound24702 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env24703 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,14836,2296,7223,4096,8401,14564,2297,11493,5277,15605,138,8328,15525,8200,1296,1296,2265,4164,4294967296,15845,4294972604,11492,137]

theorem envBound24703 : H12AffineFastState.Bounded env24703 := by
  intro p hp
  have h : env24703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24702_24703 : H12AffineEnvironment.transform 13 14836 env24702 = env24703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 14836 env24702 == env24703) = true)

def env24704 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1296,8192,11492,2296,2343,1296,8401,11764,2297,11493,397,10725,138,8328,10677,8200,1296,1296,2265,1364,4294967296,10485,4294967724,11492,137]

theorem envBound24704 : H12AffineFastState.Bounded env24704 := by
  intro p hp
  have h : env24704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24703_24704 : H12AffineEnvironment.transform 11 1296 env24703 = env24704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env24703 == env24704) = true)

theorem identity24704 : scanCanonicalize (H12AffineFastState.compose env24704 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 2257) := by decide +kernel

theorem selectedBound24704 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24705 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1296,2257,1077,2296,2343,1296,2048,1317,2297,1076,397,308,138,2137,356,2265,1296,1296,2265,1364,4294967296,36,4294967724,1077,137]

theorem envBound24705 : H12AffineFastState.Bounded env24705 := by
  intro p hp
  have h : env24705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24704_24705 : H12AffineEnvironment.transform 12 2257 env24704 = env24705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2257 env24704 == env24705) = true)

theorem identity24705 : scanCanonicalize (H12AffineFastState.compose env24705 (packedSelected [2,4] rootPS)) = affineNative (2^(7+1) ^^^ 140) := by decide +kernel

theorem selectedBound24705 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env24706 : List Nat := [2,4,8,16,32,64,128,140,137,1024,2048,1180,2257,1077,2296,2219,1180,2048,1193,2297,1076,1,184,138,2137,232,2265,1180,1180,2265,1240,4294967296,36,4294967328,1077,137]

theorem envBound24706 : H12AffineFastState.Bounded env24706 := by
  intro p hp
  have h : env24706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24705_24706 : H12AffineEnvironment.transform 7 140 env24705 = env24706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 140 env24705 == env24706) = true)

theorem identity24706 : scanCanonicalize (H12AffineFastState.compose env24706 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 2161) := by decide +kernel

theorem selectedBound24706 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24707 : List Nat := [2,4,8,16,32,64,128,140,137,1024,2048,1180,2257,1077,2296,2219,1180,2048,1193,2297,1076,1,184,138,2137,232,2265,1180,1180,2265,1240,2161,36,2129,1077,137]

theorem envBound24707 : H12AffineFastState.Bounded env24707 := by
  intro p hp
  have h : env24707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24706_24707 : H12AffineEnvironment.transform 31 2161 env24706 = env24707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 2161 env24706 == env24707) = true)

theorem identity24707 : scanCanonicalize (H12AffineFastState.compose env24707 (packedSelected [6] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound24707 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env24708 : List Nat := [2,4,8,16,32,64,88,84,81,1024,2048,1092,2057,1077,2080,2163,1092,2048,1137,2081,1076,1,96,82,2137,48,2049,1092,1092,2049,1024,2161,36,2129,1077,81]

theorem envBound24708 : H12AffineFastState.Bounded env24708 := by
  intro p hp
  have h : env24708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24707_24708 : H12AffineEnvironment.transform 6 88 env24707 = env24708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env24707 == env24708) = true)

theorem identity24708 : scanCanonicalize (H12AffineFastState.compose env24708 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound24708 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env24709 : List Nat := [2,4,8,16,26,64,88,84,81,1024,2048,1092,2057,1039,2074,2121,1092,2048,1099,2075,1038,1,90,82,2137,10,2049,1092,1092,2049,1024,2123,30,2129,1039,81]

theorem envBound24709 : H12AffineFastState.Bounded env24709 := by
  intro p hp
  have h : env24709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24708_24709 : H12AffineEnvironment.transform 4 26 env24708 = env24709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env24708 == env24709) = true)

def env24710 : List Nat := [2,4,8,16,26,64,88,84,81,1024,0,1092,9,1039,26,73,1092,0,1099,27,1038,1,90,82,89,10,1,1092,1092,1,1024,75,30,81,1039,81]

theorem envBound24710 : H12AffineFastState.Bounded env24710 := by
  intro p hp
  have h : env24710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24709_24710 : H12AffineEnvironment.transform 10 0 env24709 = env24710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env24709 == env24710) = true)

def env24711 : List Nat := [2,4,8,16,26,64,88,84,81,1024,1,1092,8,1039,27,72,1092,1,1099,26,1038,1,90,82,88,10,0,1092,1092,0,1024,74,30,80,1039,81]

theorem envBound24711 : H12AffineFastState.Bounded env24711 := by
  intro p hp
  have h : env24711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24709_24711 : H12AffineEnvironment.transform 10 1 env24709 = env24711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env24709 == env24711) = true)

theorem identity24711 : scanCanonicalize (H12AffineFastState.compose env24711 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound24711 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24712 : List Nat := [2,4,8,10,0,64,66,78,75,1024,1,1092,8,1039,1,72,1092,1,1099,0,1038,1,64,72,66,10,0,1092,1092,0,1024,74,4,74,1039,75]

theorem envBound24712 : H12AffineFastState.Bounded env24712 := by
  intro p hp
  have h : env24712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24711_24712 : H12AffineEnvironment.transform 3 10 env24711 = env24712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env24711 == env24712) = true)

def leafEnv24712 : List Nat := [2,4,8,10,0,64,66,78,75,1024,1,1092,8,1039,1,72,1092,1,1099,0,1038,1,64,72,1099,66,1,10,0,1092,1092,0,1024,74,4,74,78,2,1039,75,0,1038,1]

def active24712 : List Nat := [0,1,2,5,9]

def tree24712 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24712 : H12WitnessSearch.Good tree24712 := H12GlobalWitnessIndex.good

theorem leafIdentity24712 : H12AffineFastState.composeSystem env24712 rootObs = leafEnv24712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24712 rootObs == leafEnv24712) = true)

theorem terminalChecked24712 : H12PackedTerminal.terminalCheckFast leafEnv24712 active24712 tree24712 = true := by decide +kernel

def env24713 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1297,8192,11493,2296,2342,1297,8401,11765,2297,11493,396,10724,138,8328,10676,8200,1296,1296,2265,1365,4294967296,10484,4294967725,11492,137]

theorem envBound24713 : H12AffineFastState.Bounded env24713 := by
  intro p hp
  have h : env24713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24703_24713 : H12AffineEnvironment.transform 11 1297 env24703 = env24713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env24703 == env24713) = true)

theorem identity24713 : scanCanonicalize (H12AffineFastState.compose env24713 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 2056) := by decide +kernel

theorem selectedBound24713 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24714 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1297,2056,1261,2296,2342,1297,2265,1533,2297,1261,396,492,138,2176,444,2048,1296,1296,2265,1365,4294967296,252,4294967725,1260,137]

theorem envBound24714 : H12AffineFastState.Bounded env24714 := by
  intro p hp
  have h : env24714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24713_24714 : H12AffineEnvironment.transform 12 2056 env24713 = env24714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2056 env24713 == env24714) = true)

theorem identity24714 : scanCanonicalize (H12AffineFastState.compose env24714 (packedSelected [1,2] rootPS)) = affineNative (2^(31+1) ^^^ 2275) := by decide +kernel

theorem selectedBound24714 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env24715 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1297,2056,1261,2296,2342,1297,2265,1533,2297,1261,396,492,138,2176,444,2048,1296,1296,2265,1365,2275,252,2382,1260,137]

theorem envBound24715 : H12AffineFastState.Bounded env24715 := by
  intro p hp
  have h : env24715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24714_24715 : H12AffineEnvironment.transform 31 2275 env24714 = env24715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 2275 env24714 == env24715) = true)

theorem identity24715 : scanCanonicalize (H12AffineFastState.compose env24715 (packedSelected [0,1,4] rootPS)) = affineNative (2^(7+1) ^^^ 110) := by decide +kernel

theorem selectedBound24715 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env24716 : List Nat := [2,4,8,16,32,64,128,110,137,1024,2048,1151,2056,1261,2296,2120,1151,2265,1171,2297,1261,226,130,138,2176,210,2048,1150,1150,2265,1083,2275,252,2080,1260,137]

theorem envBound24716 : H12AffineFastState.Bounded env24716 := by
  intro p hp
  have h : env24716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24715_24716 : H12AffineEnvironment.transform 7 110 env24715 = env24716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 110 env24715 == env24716) = true)

theorem identity24716 : scanCanonicalize (H12AffineFastState.compose env24716 (packedSelected [6] rootPS)) = affineNative (2^(6+1) ^^^ 99) := by decide +kernel

theorem selectedBound24716 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env24717 : List Nat := [2,4,8,16,32,64,99,110,106,1024,2048,1151,2056,1038,2075,2120,1151,2106,1136,2074,1038,1,97,105,2147,49,2048,1150,1150,2106,1083,2048,31,2080,1039,106]

theorem envBound24717 : H12AffineFastState.Bounded env24717 := by
  intro p hp
  have h : env24717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24716_24717 : H12AffineEnvironment.transform 6 99 env24716 = env24717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 99 env24716 == env24717) = true)

theorem identity24717 : scanCanonicalize (H12AffineFastState.compose env24717 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound24717 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env24718 : List Nat := [2,4,8,16,27,64,88,85,81,1024,2048,1092,2056,1038,2075,2120,1092,2049,1099,2074,1038,1,90,82,2136,10,2048,1093,1093,2049,1024,2048,31,2075,1039,81]

theorem envBound24718 : H12AffineFastState.Bounded env24718 := by
  intro p hp
  have h : env24718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24717_24718 : H12AffineEnvironment.transform 4 27 env24717 = env24718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env24717 == env24718) = true)

def env24719 : List Nat := [2,4,8,16,27,64,88,85,81,1024,80,1092,88,1038,75,24,1092,81,1099,74,1038,1,90,82,8,10,80,1093,1093,81,1024,80,31,75,1039,81]

theorem envBound24719 : H12AffineFastState.Bounded env24719 := by
  intro p hp
  have h : env24719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24718_24719 : H12AffineEnvironment.transform 10 80 env24718 = env24719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env24718 == env24719) = true)

theorem identity24719 : scanCanonicalize (H12AffineFastState.compose env24719 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound24719 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24720 : List Nat := [2,4,8,16,27,11,19,30,26,1024,27,1039,19,1038,0,24,1039,26,1024,1,1038,1,17,25,8,10,27,1038,1038,26,1024,27,31,0,1039,26]

theorem envBound24720 : H12AffineFastState.Bounded env24720 := by
  intro p hp
  have h : env24720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24719_24720 : H12AffineEnvironment.transform 5 11 env24719 = env24720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env24719 == env24720) = true)

def leafEnv24720 : List Nat := [2,4,8,16,27,11,19,30,26,1024,27,1039,19,1038,0,24,1039,26,1024,1,1038,1,17,25,1024,8,1,10,27,1038,1038,26,1024,27,31,0,5,3,1039,26,0,1039,1]

def active24720 : List Nat := [0,1,2,3,9]

def tree24720 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24720 : H12WitnessSearch.Good tree24720 := H12GlobalWitnessIndex.good

theorem leafIdentity24720 : H12AffineFastState.composeSystem env24720 rootObs = leafEnv24720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24720 rootObs == leafEnv24720) = true)

theorem terminalChecked24720 : H12PackedTerminal.terminalCheckFast leafEnv24720 active24720 tree24720 = true := by decide +kernel

def env24721 : List Nat := [2,4,8,16,27,64,88,85,81,1024,81,1092,89,1038,74,25,1092,80,1099,75,1038,1,90,82,9,10,81,1093,1093,80,1024,81,31,74,1039,81]

theorem envBound24721 : H12AffineFastState.Bounded env24721 := by
  intro p hp
  have h : env24721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24718_24721 : H12AffineEnvironment.transform 10 81 env24718 = env24721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env24718 == env24721) = true)

theorem identity24721 : scanCanonicalize (H12AffineFastState.compose env24721 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound24721 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24722 : List Nat := [2,4,8,16,27,17,9,4,0,1024,0,1045,8,1038,27,25,1045,1,1050,26,1038,1,11,3,9,10,0,1044,1044,1,1024,0,31,27,1039,0]

theorem envBound24722 : H12AffineFastState.Bounded env24722 := by
  intro p hp
  have h : env24722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24721_24722 : H12AffineEnvironment.transform 5 17 env24721 = env24722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env24721 == env24722) = true)

def leafEnv24722 : List Nat := [2,4,8,16,27,17,9,4,0,1024,0,1045,8,1038,27,25,1045,1,1050,26,1038,1,11,3,1050,9,1,10,0,1044,1044,1,1024,0,31,27,31,24,1039,0,0,1039,1]

def active24722 : List Nat := [0,1,2,3,9]

def tree24722 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24722 : H12WitnessSearch.Good tree24722 := H12GlobalWitnessIndex.good

theorem leafIdentity24722 : H12AffineFastState.composeSystem env24722 rootObs = leafEnv24722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24722 rootObs == leafEnv24722) = true)

theorem terminalChecked24722 : H12PackedTerminal.terminalCheckFast leafEnv24722 active24722 tree24722 = true := by decide +kernel

def env24723 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,16384,32768,65536,4097,262144,524288,32769,2097152,4194304,525328,16777216,8328,67108864,21331969,16879957,16879956,1073741824,84508737,4294967296,525569,4315938987,86609924,137]

theorem envBound24723 : H12AffineFastState.Bounded env24723 := by
  intro p hp
  have h : env24723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24581_24723 : H12AffineEnvironment.transform 16 4097 env24581 = env24723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4097 env24581 == env24723) = true)

theorem identity24723 : scanCanonicalize (H12AffineFastState.compose env24723 (packedSelected [3,5,10] rootPS)) = affineNative (2^(29+1) ^^^ 17348687) := by decide +kernel

theorem selectedBound24723 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env24724 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,16384,32768,65536,4097,262144,524288,32769,2097152,4194304,525328,16777216,8328,67108864,21331969,16879957,16879956,17348687,84508737,4294967296,525569,4315938987,86609924,137]

theorem envBound24724 : H12AffineFastState.Bounded env24724 := by
  intro p hp
  have h : env24724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24723_24724 : H12AffineEnvironment.transform 29 17348687 env24723 = env24724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 17348687 env24723 == env24724) = true)

def env24725 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,16384,32768,65536,4097,262144,524288,32769,2097152,4194304,525328,16777216,8328,2642256,21331969,16879957,16879956,17348687,18993425,4294967296,525569,4315938987,16892244,137]

theorem envBound24725 : H12AffineFastState.Bounded env24725 := by
  intro p hp
  have h : env24725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24724_24725 : H12AffineEnvironment.transform 25 2642256 env24724 = env24725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 2642256 env24724 == env24725) = true)

theorem identity24725 : scanCanonicalize (H12AffineFastState.compose env24725 (packedSelected [0,14,27] rootPS)) = affineNative (2^(20+1) ^^^ 21776) := by decide +kernel

theorem selectedBound24725 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env24726 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,16384,32768,65536,4097,262144,524288,32769,21776,4194304,525328,16777216,8328,525376,21331969,16879957,16879956,17348687,16876545,4294967296,525569,4315938987,16892244,137]

theorem envBound24726 : H12AffineFastState.Bounded env24726 := by
  intro p hp
  have h : env24726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24725_24726 : H12AffineEnvironment.transform 20 21776 env24725 = env24726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 21776 env24725 == env24726) = true)

def env24727 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,16384,32768,65536,4097,262144,524288,32769,21776,4194304,525328,70976,8328,525376,4494657,33813,33812,634127,37185,4294967296,525569,4299232747,54292,137]

theorem envBound24727 : H12AffineFastState.Bounded env24727 := by
  intro p hp
  have h : env24727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24726_24727 : H12AffineEnvironment.transform 23 70976 env24726 = env24727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 70976 env24726 == env24727) = true)

def env24728 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,16384,32768,65536,4097,262144,524288,32769,21776,41088,525328,70976,8328,525376,275905,33813,33812,634127,37185,4294967296,525569,4295079275,54292,137]

theorem envBound24728 : H12AffineFastState.Bounded env24728 := by
  intro p hp
  have h : env24728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24727_24728 : H12AffineEnvironment.transform 21 41088 env24727 = env24728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env24727 == env24728) = true)

theorem identity24728 : scanCanonicalize (H12AffineFastState.compose env24728 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 594022) := by decide +kernel

theorem selectedBound24728 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env24729 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,16384,32768,65536,4097,262144,524288,32769,21776,41088,525328,70976,8328,525376,275905,33813,33812,634127,37185,594022,525569,566541,54292,137]

theorem envBound24729 : H12AffineFastState.Bounded env24729 := by
  intro p hp
  have h : env24729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24728_24729 : H12AffineEnvironment.transform 31 594022 env24728 = env24729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 594022 env24728 == env24729) = true)

def env24730 : List Nat := [2,4,8,16,32,64,128,252,137,1024,2048,4096,8192,16384,32768,65536,4097,262144,524288,32769,21740,41088,525328,70844,8328,525376,275517,33813,33812,634099,37053,594022,525565,566513,54292,137]

theorem envBound24730 : H12AffineFastState.Bounded env24730 := by
  intro p hp
  have h : env24730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24729_24730 : H12AffineEnvironment.transform 7 252 env24729 = env24730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env24729 == env24730) = true)

theorem identity24730 : scanCanonicalize (H12AffineFastState.compose env24730 (packedSelected [1,13,17,18,23,24] rootPS)) = affineNative (2^(18+1) ^^^ 102606) := by decide +kernel

theorem selectedBound24730 : packedSelected [1,13,17,18,23,24] rootPS < 2^1333 := by decide +kernel

def env24731 : List Nat := [2,4,8,16,32,64,128,252,137,1024,2048,4096,8192,16384,32768,65536,4097,262144,102606,32769,21740,41088,103646,70844,8328,103566,275517,33813,33812,15421,37053,32936,103475,78911,54292,137]

theorem envBound24731 : H12AffineFastState.Bounded env24731 := by
  intro p hp
  have h : env24731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24730_24731 : H12AffineEnvironment.transform 18 102606 env24730 = env24731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 102606 env24730 == env24731) = true)

theorem identity24731 : scanCanonicalize (H12AffineFastState.compose env24731 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound24731 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env24732 : List Nat := [2,4,8,16,32,64,128,252,137,1024,2048,4096,8192,16384,32768,65536,4097,43049,102606,32769,21740,41088,103646,70844,8328,103566,39956,33813,33812,15421,37053,32936,103475,78911,54292,137]

theorem envBound24732 : H12AffineFastState.Bounded env24732 := by
  intro p hp
  have h : env24732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24731_24732 : H12AffineEnvironment.transform 17 43049 env24731 = env24732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env24731 == env24732) = true)

theorem identity24732 : scanCanonicalize (H12AffineFastState.compose env24732 (packedSelected [0,2,4,11] rootPS)) = affineNative (2^(15+1) ^^^ 5174) := by decide +kernel

theorem selectedBound24732 : packedSelected [0,2,4,11] rootPS < 2^1333 := by decide +kernel

def env24733 : List Nat := [2,4,8,16,32,64,128,252,137,1024,2048,4096,8192,16384,32768,5174,4097,43049,34040,32769,21740,41088,33000,138,8328,32952,39956,33813,33812,15421,37053,32936,32773,8201,54292,137]

theorem envBound24733 : H12AffineFastState.Bounded env24733 := by
  intro p hp
  have h : env24733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24732_24733 : H12AffineEnvironment.transform 15 5174 env24732 = env24733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5174 env24732 == env24733) = true)

theorem identity24733 : scanCanonicalize (H12AffineFastState.compose env24733 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound24733 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env24734 : List Nat := [2,4,8,16,32,64,128,252,137,1024,2048,4096,8192,16384,13340,5174,4097,7221,12516,13341,21740,5276,13556,138,8328,13476,10248,12297,12296,15421,9377,13492,13337,8201,24584,137]

theorem envBound24734 : H12AffineFastState.Bounded env24734 := by
  intro p hp
  have h : env24734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24733_24734 : H12AffineEnvironment.transform 14 13340 env24733 = env24734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env24733 == env24734) = true)

theorem identity24734 : scanCanonicalize (H12AffineFastState.compose env24734 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(13+1) ^^^ 14539) := by decide +kernel

theorem selectedBound24734 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env24735 : List Nat := [2,4,8,16,32,64,128,252,137,1024,2048,4096,8192,14539,13340,5174,4097,7221,12516,13341,11303,5276,13556,138,8328,13476,10248,12297,12296,15421,9377,13492,13337,8201,6339,137]

theorem envBound24735 : H12AffineFastState.Bounded env24735 := by
  intro p hp
  have h : env24735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24734_24735 : H12AffineEnvironment.transform 13 14539 env24734 = env24735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 14539 env24734 == env24735) = true)

def env24736 : List Nat := [2,4,8,16,32,64,128,252,137,1024,2048,4096,8,6339,5140,5174,4097,7221,4332,5141,3119,5276,5372,138,128,5292,2048,4097,4096,7221,1193,5308,5137,1,6339,137]

theorem envBound24736 : H12AffineFastState.Bounded env24736 := by
  intro p hp
  have h : env24736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24735_24736 : H12AffineEnvironment.transform 12 8 env24735 = env24736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env24735 == env24736) = true)

theorem identity24736 : scanCanonicalize (H12AffineFastState.compose env24736 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1077) := by decide +kernel

theorem selectedBound24736 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24737 : List Nat := [2,4,8,16,32,64,128,252,137,1024,2048,1077,8,3318,33,3,1076,2048,1241,32,3119,169,201,138,128,153,2048,1076,1077,2048,1193,137,36,1,3318,137]

theorem envBound24737 : H12AffineFastState.Bounded env24737 := by
  intro p hp
  have h : env24737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24736_24737 : H12AffineEnvironment.transform 11 1077 env24736 = env24737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1077 env24736 == env24737) = true)

theorem identity24737 : scanCanonicalize (H12AffineFastState.compose env24737 (packedSelected [0,2,4] rootPS)) = affineNative (2^(10+1) ^^^ 169) := by decide +kernel

theorem selectedBound24737 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env24738 : List Nat := [2,4,8,16,32,64,128,252,137,1024,169,1077,8,1119,33,3,1076,169,1241,32,1158,169,201,138,128,153,169,1076,1077,169,1193,137,36,1,1119,137]

theorem envBound24738 : H12AffineFastState.Bounded env24738 := by
  intro p hp
  have h : env24738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24737_24738 : H12AffineEnvironment.transform 10 169 env24737 = env24738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 169 env24737 == env24738) = true)

theorem identity24738 : scanCanonicalize (H12AffineFastState.compose env24738 (packedSelected [1,2] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound24738 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env24739 : List Nat := [2,4,8,16,32,64,41,85,32,1024,0,1077,8,1119,33,3,1076,0,1136,32,1071,0,96,35,41,48,0,1076,1077,0,1024,32,36,1,1119,32]

theorem envBound24739 : H12AffineFastState.Bounded env24739 := by
  intro p hp
  have h : env24739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24738_24739 : H12AffineEnvironment.transform 6 41 env24738 = env24739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env24738 == env24739) = true)

def env24740 : List Nat := [2,4,8,16,32,64,128,252,137,1024,2048,4096,9,6338,5141,5174,4097,7221,4333,5140,3118,5276,5373,138,129,5293,2049,4096,4097,7220,1192,5309,5136,0,6339,137]

theorem envBound24740 : H12AffineFastState.Bounded env24740 := by
  intro p hp
  have h : env24740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24735_24740 : H12AffineEnvironment.transform 12 9 env24735 = env24740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env24735 == env24740) = true)

theorem identity24740 : scanCanonicalize (H12AffineFastState.compose env24740 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1260) := by decide +kernel

theorem selectedBound24740 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24741 : List Nat := [2,4,8,16,32,64,128,252,137,1024,2048,1260,9,3118,249,218,1261,2265,1025,248,3118,112,17,138,129,65,2049,1260,1261,2264,1192,81,252,0,3119,137]

theorem envBound24741 : H12AffineFastState.Bounded env24741 := by
  intro p hp
  have h : env24741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24740_24741 : H12AffineEnvironment.transform 11 1260 env24740 = env24741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1260 env24740 == env24741) = true)

theorem identity24741 : scanCanonicalize (H12AffineFastState.compose env24741 (packedSelected [0,2,4] rootPS)) = affineNative (2^(10+1) ^^^ 195) := by decide +kernel

theorem selectedBound24741 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env24742 : List Nat := [2,4,8,16,32,64,128,252,137,1024,195,1260,9,1261,249,218,1261,26,1025,248,1261,112,17,138,129,65,194,1260,1261,27,1192,81,252,0,1260,137]

theorem envBound24742 : H12AffineFastState.Bounded env24742 := by
  intro p hp
  have h : env24742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24741_24742 : H12AffineEnvironment.transform 10 195 env24741 = env24742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 195 env24741 == env24742) = true)

theorem identity24742 : scanCanonicalize (H12AffineFastState.compose env24742 (packedSelected [1,2] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound24742 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env24743 : List Nat := [2,4,8,16,32,64,40,84,33,1024,107,1092,9,1093,81,114,1093,26,1025,80,1093,112,17,34,41,65,106,1092,1093,27,1024,81,84,0,1092,33]

theorem envBound24743 : H12AffineFastState.Bounded env24743 := by
  intro p hp
  have h : env24743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24742_24743 : H12AffineEnvironment.transform 6 40 env24742 = env24743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env24742 == env24743) = true)

theorem identity24743 : scanCanonicalize (H12AffineFastState.compose env24743 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound24743 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24744 : List Nat := [2,4,8,16,32,17,40,5,33,1024,58,1045,9,1044,0,35,1044,26,1025,1,1044,33,17,34,41,16,59,1045,1044,27,1024,0,5,0,1045,33]

theorem envBound24744 : H12AffineFastState.Bounded env24744 := by
  intro p hp
  have h : env24744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24743_24744 : H12AffineEnvironment.transform 5 17 env24743 = env24744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env24743 == env24744) = true)

def env24745 : List Nat := [2,4,8,16,0,17,8,5,1,1024,26,1045,9,1044,0,3,1044,26,1025,1,1044,1,17,2,9,16,27,1045,1044,27,1024,0,5,0,1045,1]

theorem envBound24745 : H12AffineFastState.Bounded env24745 := by
  intro p hp
  have h : env24745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24744_24745 : H12AffineEnvironment.transform 4 0 env24744 = env24745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env24744 == env24745) = true)

def env24746 : List Nat := [2,4,8,16,1,17,9,5,0,1024,27,1045,9,1044,0,2,1044,26,1025,1,1044,0,17,3,8,16,26,1045,1044,27,1024,0,5,0,1045,0]

theorem envBound24746 : H12AffineFastState.Bounded env24746 := by
  intro p hp
  have h : env24746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24744_24746 : H12AffineEnvironment.transform 4 1 env24744 = env24746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env24744 == env24746) = true)

theorem identity24746 : scanCanonicalize (H12AffineFastState.compose env24746 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound24746 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24747 : List Nat := [2,4,8,11,1,10,9,5,0,1024,0,1038,9,1039,0,2,1039,1,1025,1,1039,0,10,3,8,11,1,1038,1039,0,1024,0,5,0,1038,0]

theorem envBound24747 : H12AffineFastState.Bounded env24747 := by
  intro p hp
  have h : env24747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24746_24747 : H12AffineEnvironment.transform 3 11 env24746 = env24747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env24746 == env24747) = true)

def leafEnv24747 : List Nat := [2,4,8,11,1,10,9,5,0,1024,0,1038,9,1039,0,2,1039,1,1025,1,1039,0,10,3,1025,8,1,11,1,1038,1039,0,1024,0,5,0,4,3,1038,0,0,1038,1]

def active24747 : List Nat := [0,1,2,9]

def tree24747 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24747 : H12WitnessSearch.Good tree24747 := H12GlobalWitnessIndex.good

theorem leafIdentity24747 : H12AffineFastState.composeSystem env24747 rootObs = leafEnv24747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24747 rootObs == leafEnv24747) = true)

theorem terminalChecked24747 : H12PackedTerminal.terminalCheckFast leafEnv24747 active24747 tree24747 = true := by decide +kernel

def env24748 : List Nat := [2,4,8,16,32,64,128,253,137,1024,2048,4096,8192,16384,32768,65536,4097,262144,524288,32769,21741,41088,525328,70845,8328,525376,275516,33813,33812,634098,37052,594022,525564,566512,54292,137]

theorem envBound24748 : H12AffineFastState.Bounded env24748 := by
  intro p hp
  have h : env24748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24729_24748 : H12AffineEnvironment.transform 7 253 env24729 = env24748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env24729 == env24748) = true)

theorem identity24748 : scanCanonicalize (H12AffineFastState.compose env24748 (packedSelected [1,13,17,18,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound24748 : packedSelected [1,13,17,18,23,24] rootPS < 2^1333 := by decide +kernel

def env24749 : List Nat := [2,4,8,16,32,64,128,253,137,1024,2048,4096,8192,16384,32768,65536,4097,43049,524288,32769,21741,41088,525328,70845,8328,525376,39957,33813,33812,634098,37052,594022,525564,566512,54292,137]

theorem envBound24749 : H12AffineFastState.Bounded env24749 := by
  intro p hp
  have h : env24749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24748_24749 : H12AffineEnvironment.transform 17 43049 env24748 = env24749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env24748 == env24749) = true)

theorem identity24749 : scanCanonicalize (H12AffineFastState.compose env24749 (packedSelected [11,15] rootPS)) = affineNative (2^(18+1) ^^^ 23664) := by decide +kernel

theorem selectedBound24749 : packedSelected [11,15] rootPS < 2^1333 := by decide +kernel

def env24750 : List Nat := [2,4,8,16,32,64,128,253,137,1024,2048,4096,8192,16384,32768,65536,4097,43049,23664,32769,21741,41088,22624,70845,8328,22576,39957,33813,33812,127106,37052,85014,22668,63616,54292,137]

theorem envBound24750 : H12AffineFastState.Bounded env24750 := by
  intro p hp
  have h : env24750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24749_24750 : H12AffineEnvironment.transform 18 23664 env24749 = env24750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 23664 env24749 == env24750) = true)

theorem identity24750 : scanCanonicalize (H12AffineFastState.compose env24750 (packedSelected [11] rootPS)) = affineNative (2^(15+1) ^^^ 52414) := by decide +kernel

theorem selectedBound24750 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env24751 : List Nat := [2,4,8,16,32,64,128,253,137,1024,2048,4096,8192,16384,32768,52414,4097,43049,23664,32769,21741,41088,22624,55299,8328,22576,39957,33813,33812,15420,37052,32936,22668,63616,54292,137]

theorem envBound24751 : H12AffineFastState.Bounded env24751 := by
  intro p hp
  have h : env24751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24750_24751 : H12AffineEnvironment.transform 15 52414 env24750 = env24751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 52414 env24750 == env24751) = true)

theorem identity24751 : scanCanonicalize (H12AffineFastState.compose env24751 (packedSelected [0,2,4] rootPS)) = affineNative (2^(14+1) ^^^ 22665) := by decide +kernel

theorem selectedBound24751 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env24752 : List Nat := [2,4,8,16,32,64,128,253,137,1024,2048,4096,8192,16384,22665,5175,4097,28832,23664,22664,21741,30729,22624,138,8328,22576,17564,23708,23709,15420,18485,22561,22668,8201,3229,137]

theorem envBound24752 : H12AffineFastState.Bounded env24752 := by
  intro p hp
  have h : env24752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24751_24752 : H12AffineEnvironment.transform 14 22665 env24751 = env24752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 22665 env24751 == env24752) = true)

theorem identity24752 : scanCanonicalize (H12AffineFastState.compose env24752 (packedSelected [0,5] rootPS)) = affineNative (2^(13+1) ^^^ 11413) := by decide +kernel

theorem selectedBound24752 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env24753 : List Nat := [2,4,8,16,32,64,128,253,137,1024,2048,4096,8192,11413,13340,5175,4097,7221,12517,13341,14456,5276,13557,138,8328,13477,10249,12297,12296,15420,9376,13492,13337,8201,3229,137]

theorem envBound24753 : H12AffineFastState.Bounded env24753 := by
  intro p hp
  have h : env24753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24752_24753 : H12AffineEnvironment.transform 13 11413 env24752 = env24753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11413 env24752 == env24753) = true)

theorem identity24753 : scanCanonicalize (H12AffineFastState.compose env24753 (packedSelected [0,1,2] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound24753 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env24754 : List Nat := [2,4,8,16,32,64,19,110,26,1024,2048,4096,8192,11270,13340,5175,4097,7221,12406,13341,14456,5135,13414,25,8219,13366,10249,12297,12296,15420,9267,13351,13337,8201,3086,26]

theorem envBound24754 : H12AffineFastState.Bounded env24754 := by
  intro p hp
  have h : env24754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24753_24754 : H12AffineEnvironment.transform 6 19 env24753 = env24754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env24753 == env24754) = true)

theorem identity24754 : scanCanonicalize (H12AffineFastState.compose env24754 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound24754 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env24755 : List Nat := [2,4,8,16,32,11,19,37,26,1024,2048,4096,8192,11270,13340,5175,4097,7221,12349,13341,14387,5135,13357,25,8219,13366,10249,12297,12296,15420,9267,13351,13337,8201,3086,26]

theorem envBound24755 : H12AffineFastState.Bounded env24755 := by
  intro p hp
  have h : env24755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24754_24755 : H12AffineEnvironment.transform 5 11 env24754 = env24755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env24754 == env24755) = true)

theorem identity24755 : scanCanonicalize (H12AffineFastState.compose env24755 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 51) := by decide +kernel

theorem selectedBound24755 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24756 : List Nat := [2,4,8,16,32,11,19,37,26,1024,2048,4096,51,3125,5167,5175,4097,7221,4110,5166,6144,5135,5150,25,40,5125,2106,4154,4155,7183,1024,5140,5162,58,3086,26]

theorem envBound24756 : H12AffineFastState.Bounded env24756 := by
  intro p hp
  have h : env24756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24755_24756 : H12AffineEnvironment.transform 12 51 env24755 = env24756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 51 env24755 == env24756) = true)

def env24757 : List Nat := [2,4,8,16,32,11,19,37,26,1024,2048,1044,51,3125,59,35,1045,2081,1050,58,3092,27,10,25,40,17,2106,1070,1071,2075,1024,0,62,58,3086,26]

theorem envBound24757 : H12AffineFastState.Bounded env24757 := by
  intro p hp
  have h : env24757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24756_24757 : H12AffineEnvironment.transform 11 1044 env24756 = env24757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1044 env24756 == env24757) = true)

theorem identity24757 : scanCanonicalize (H12AffineFastState.compose env24757 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound24757 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24758 : List Nat := [2,4,8,16,27,11,19,30,26,1024,2048,1044,8,3086,0,24,1045,2074,1050,1,3092,27,10,25,19,17,2049,1045,1044,2075,1024,0,5,1,3086,26]

theorem envBound24758 : H12AffineFastState.Bounded env24758 := by
  intro p hp
  have h : env24758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24757_24758 : H12AffineEnvironment.transform 4 27 env24757 = env24758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env24757 == env24758) = true)

def leafEnv24758 : List Nat := [2,4,8,16,27,11,19,30,26,1024,2048,1044,8,3086,0,24,1045,2074,1050,1,3092,27,10,25,1050,19,1,17,2049,1045,1044,2075,1024,0,5,1,31,3,3086,26,0,3092,1]

def active24758 : List Nat := [0,1,2,3,9,10]

def tree24758 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24758 : H12WitnessSearch.Good tree24758 := H12GlobalWitnessIndex.good

theorem leafIdentity24758 : H12AffineFastState.composeSystem env24758 rootObs = leafEnv24758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24758 rootObs == leafEnv24758) = true)

theorem terminalChecked24758 : H12PackedTerminal.terminalCheckFast leafEnv24758 active24758 tree24758 = true := by decide +kernel

def env24759 : List Nat := [2,4,8,16,32,11,19,37,26,1024,2048,1045,51,3125,58,34,1044,2080,1051,59,3093,26,11,25,40,16,2106,1071,1070,2074,1024,1,63,58,3086,26]

theorem envBound24759 : H12AffineFastState.Bounded env24759 := by
  intro p hp
  have h : env24759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24756_24759 : H12AffineEnvironment.transform 11 1045 env24756 = env24759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1045 env24756 == env24759) = true)

def leafEnv24759 : List Nat := [2,4,8,16,32,11,19,37,26,1024,2048,1045,51,3125,58,34,1044,2080,1051,59,3093,26,11,25,1051,40,1,16,2106,1071,1070,2074,1024,1,63,58,30,57,3086,26,0,3118,1]

def active24759 : List Nat := [0,1,2,3,4,9,10]

def tree24759 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24759 : H12WitnessSearch.Good tree24759 := H12GlobalWitnessIndex.good

theorem leafIdentity24759 : H12AffineFastState.composeSystem env24759 rootObs = leafEnv24759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24759 rootObs == leafEnv24759) = true)

theorem terminalChecked24759 : H12PackedTerminal.terminalCheckFast leafEnv24759 active24759 tree24759 = true := by decide +kernel

def env24760 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,16384,32768,65536,4097,262144,524288,32769,21776,41089,525328,70976,8328,525376,275904,33813,33812,634127,37185,4294967296,525569,4295079274,54292,137]

theorem envBound24760 : H12AffineFastState.Bounded env24760 := by
  intro p hp
  have h : env24760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24727_24760 : H12AffineEnvironment.transform 21 41089 env24727 = env24760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env24727 == env24760) = true)

theorem identity24760 : scanCanonicalize (H12AffineFastState.compose env24760 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 602222) := by decide +kernel

theorem selectedBound24760 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env24761 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,16384,32768,65536,4097,262144,524288,32769,21776,41089,525328,70976,8328,525376,275904,33813,33812,634127,37185,602222,525569,558340,54292,137]

theorem envBound24761 : H12AffineFastState.Bounded env24761 := by
  intro p hp
  have h : env24761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24760_24761 : H12AffineEnvironment.transform 31 602222 env24760 = env24761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 602222 env24760 == env24761) = true)

def env24762 : List Nat := [2,4,8,16,32,64,128,252,137,1024,2048,4096,8192,16384,32768,65536,4097,262144,524288,32769,21740,41089,525328,70844,8328,525376,275516,33813,33812,634099,37053,602222,525565,558328,54292,137]

theorem envBound24762 : H12AffineFastState.Bounded env24762 := by
  intro p hp
  have h : env24762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24761_24762 : H12AffineEnvironment.transform 7 252 env24761 = env24762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env24761 == env24762) = true)

theorem identity24762 : scanCanonicalize (H12AffineFastState.compose env24762 (packedSelected [1,13,17,18,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound24762 : packedSelected [1,13,17,18,23,24] rootPS < 2^1333 := by decide +kernel

def env24763 : List Nat := [2,4,8,16,32,64,128,252,137,1024,2048,4096,8192,16384,32768,65536,4097,43049,524288,32769,21740,41089,525328,70844,8328,525376,39957,33813,33812,634099,37053,602222,525565,558328,54292,137]

theorem envBound24763 : H12AffineFastState.Bounded env24763 := by
  intro p hp
  have h : env24763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24762_24763 : H12AffineEnvironment.transform 17 43049 env24762 = env24763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env24762 == env24763) = true)

theorem identity24763 : scanCanonicalize (H12AffineFastState.compose env24763 (packedSelected [11,15] rootPS)) = affineNative (2^(18+1) ^^^ 23664) := by decide +kernel

theorem selectedBound24763 : packedSelected [11,15] rootPS < 2^1333 := by decide +kernel

def env24764 : List Nat := [2,4,8,16,32,64,128,252,137,1024,2048,4096,8192,16384,32768,65536,4097,43049,23664,32769,21740,41089,22624,70844,8328,22576,39957,33813,33812,127107,37053,93214,22669,55432,54292,137]

theorem envBound24764 : H12AffineFastState.Bounded env24764 := by
  intro p hp
  have h : env24764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24763_24764 : H12AffineEnvironment.transform 18 23664 env24763 = env24764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 23664 env24763 == env24764) = true)

theorem identity24764 : scanCanonicalize (H12AffineFastState.compose env24764 (packedSelected [11] rootPS)) = affineNative (2^(15+1) ^^^ 52415) := by decide +kernel

theorem selectedBound24764 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env24765 : List Nat := [2,4,8,16,32,64,128,252,137,1024,2048,4096,8192,16384,32768,52415,4097,43049,23664,32769,21740,41089,22624,55299,8328,22576,39957,33813,33812,15420,37053,41121,22669,55432,54292,137]

theorem envBound24765 : H12AffineFastState.Bounded env24765 := by
  intro p hp
  have h : env24765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24764_24765 : H12AffineEnvironment.transform 15 52415 env24764 = env24765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 52415 env24764 == env24765) = true)

theorem identity24765 : scanCanonicalize (H12AffineFastState.compose env24765 (packedSelected [0,2,4] rootPS)) = affineNative (2^(14+1) ^^^ 22665) := by decide +kernel

theorem selectedBound24765 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env24766 : List Nat := [2,4,8,16,32,64,128,252,137,1024,2048,4096,8192,16384,22665,5174,4097,28832,23664,22664,21740,30728,22624,138,8328,22576,17564,23708,23709,15420,18484,30760,22669,1,3229,137]

theorem envBound24766 : H12AffineFastState.Bounded env24766 := by
  intro p hp
  have h : env24766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24765_24766 : H12AffineEnvironment.transform 14 22665 env24765 = env24766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 22665 env24765 == env24766) = true)

theorem identity24766 : scanCanonicalize (H12AffineFastState.compose env24766 (packedSelected [0,5] rootPS)) = affineNative (2^(13+1) ^^^ 11412) := by decide +kernel

theorem selectedBound24766 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env24767 : List Nat := [2,4,8,16,32,64,128,252,137,1024,2048,4096,8192,11412,13341,5174,4097,7220,12516,13340,14456,5276,13556,138,8328,13476,10248,12296,12297,15420,9376,5308,13337,1,3229,137]

theorem envBound24767 : H12AffineFastState.Bounded env24767 := by
  intro p hp
  have h : env24767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24766_24767 : H12AffineEnvironment.transform 13 11412 env24766 = env24767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11412 env24766 == env24767) = true)

theorem identity24767 : scanCanonicalize (H12AffineFastState.compose env24767 (packedSelected [0,1,2] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound24767 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env24768 : List Nat := [2,4,8,16,32,64,18,110,27,1024,2048,4096,8192,11270,13341,5174,4097,7220,12406,13340,14456,5134,13414,24,8218,13366,10248,12296,12297,15420,9266,5166,13337,1,3087,27]

theorem envBound24768 : H12AffineFastState.Bounded env24768 := by
  intro p hp
  have h : env24768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24767_24768 : H12AffineEnvironment.transform 6 18 env24767 = env24768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env24767 == env24768) = true)

theorem identity24768 : scanCanonicalize (H12AffineFastState.compose env24768 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound24768 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env24769 : List Nat := [2,4,8,16,32,10,18,36,27,1024,2048,4096,8192,11270,13341,5174,4097,7220,12348,13340,14386,5134,13356,24,8218,13366,10248,12296,12297,15420,9266,5166,13337,1,3087,27]

theorem envBound24769 : H12AffineFastState.Bounded env24769 := by
  intro p hp
  have h : env24769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24768_24769 : H12AffineEnvironment.transform 5 10 env24768 = env24769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env24768 == env24769) = true)

theorem identity24769 : scanCanonicalize (H12AffineFastState.compose env24769 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 50) := by decide +kernel

theorem selectedBound24769 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24770 : List Nat := [2,4,8,16,32,10,18,36,27,1024,2048,4096,50,3124,5167,5174,4097,7220,4110,5166,6144,5134,5150,24,40,5124,2106,4154,4155,7182,1024,5166,5163,1,3087,27]

theorem envBound24770 : H12AffineFastState.Bounded env24770 := by
  intro p hp
  have h : env24770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24769_24770 : H12AffineEnvironment.transform 12 50 env24769 = env24770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 50 env24769 == env24770) = true)

theorem identity24770 : scanCanonicalize (H12AffineFastState.compose env24770 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 1045) := by decide +kernel

theorem selectedBound24770 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24771 : List Nat := [2,4,8,16,32,10,18,36,27,1024,2048,1045,50,3124,58,35,1044,2081,1051,59,3093,27,11,24,40,17,2106,1071,1070,2075,1024,59,62,1,3087,27]

theorem envBound24771 : H12AffineFastState.Bounded env24771 := by
  intro p hp
  have h : env24771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24770_24771 : H12AffineEnvironment.transform 11 1045 env24770 = env24771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1045 env24770 == env24771) = true)

def leafEnv24771 : List Nat := [2,4,8,16,32,10,18,36,27,1024,2048,1045,50,3124,58,35,1044,2081,1051,59,3093,27,11,24,1051,40,1,17,2106,1071,1070,2075,1024,59,62,1,30,57,3087,27,0,3118,1]

def active24771 : List Nat := [0,1,2,3,4,9,10]

def tree24771 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24771 : H12WitnessSearch.Good tree24771 := H12GlobalWitnessIndex.good

end H12CloudChart2