import H12CloudChart2Data184

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env46430 : List Nat := [2,4,8,10,32,10,34,14,512,46,1,42,514,512,1,520,513,554,516,0,42,10,11,2,3,544,43,43,43,554,549,545,15,11,42,42]

theorem envBound46430 : H12AffineFastState.Bounded env46430 := by
  intro p hp
  have h : env46430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46429_46430 : H12AffineEnvironment.transform 6 34 env46429 = env46430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env46429 == env46430) = true)

theorem identity46430 : scanCanonicalize (H12AffineFastState.compose env46430 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound46430 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env46431 : List Nat := [2,4,8,10,11,10,9,14,512,5,1,1,514,512,1,520,513,513,516,0,1,10,11,2,3,523,0,0,0,513,526,522,15,11,1,1]

theorem envBound46431 : H12AffineFastState.Bounded env46431 := by
  intro p hp
  have h : env46431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46430_46431 : H12AffineEnvironment.transform 4 11 env46430 = env46431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env46430 == env46431) = true)

theorem identity46431 : scanCanonicalize (H12AffineFastState.compose env46431 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound46431 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46432 : List Nat := [2,2,8,10,11,10,9,8,512,3,1,1,514,512,1,520,513,513,514,0,1,10,11,2,3,523,0,0,0,513,520,522,9,11,1,1]

theorem envBound46432 : H12AffineFastState.Bounded env46432 := by
  intro p hp
  have h : env46432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46431_46432 : H12AffineEnvironment.transform 1 2 env46431 = env46432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env46431 == env46432) = true)

theorem identity46432 : scanCanonicalize (H12AffineFastState.compose env46432 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound46432 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46433 : List Nat := [2,2,8,10,11,10,9,8,0,3,1,1,2,0,1,8,1,1,2,0,1,10,11,2,3,11,0,0,0,1,8,10,9,11,1,1]

theorem envBound46433 : H12AffineFastState.Bounded env46433 := by
  intro p hp
  have h : env46433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46432_46433 : H12AffineEnvironment.transform 8 0 env46432 = env46433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env46432 == env46433) = true)

theorem identity46433 : scanCanonicalize (H12AffineFastState.compose env46433 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound46433 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46434 : List Nat := [2,2,1,3,2,3,0,1,0,3,1,1,2,0,1,1,1,1,2,0,1,3,2,2,3,2,0,0,0,1,1,3,0,2,1,1]

theorem envBound46434 : H12AffineFastState.Bounded env46434 := by
  intro p hp
  have h : env46434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46433_46434 : H12AffineEnvironment.transform 2 1 env46433 = env46434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env46433 == env46434) = true)

theorem identity46434 : scanCanonicalize (H12AffineFastState.compose env46434 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound46434 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env46435 : List Nat := [0,0,1,1,0,1,0,1,0,1,1,1,0,0,1,1,1,1,0,0,1,1,0,0,1,0,0,0,0,1,1,1,0,0,1,1]

theorem envBound46435 : H12AffineFastState.Bounded env46435 := by
  intro p hp
  have h : env46435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46434_46435 : H12AffineEnvironment.transform 0 0 env46434 = env46435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env46434 == env46435) = true)

def env46436 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61568,147473,58519,143496,20496,508074,148669,148669,96266,90263,90259,173,222255,1213,135681]

theorem envBound46436 : H12AffineFastState.Bounded env46436 := by
  intro p hp
  have h : env46436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46418_46436 : H12AffineEnvironment.transform 5 17 env46418 = env46436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env46418 == env46436) = true)

theorem identity46436 : scanCanonicalize (H12AffineFastState.compose env46436 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 99487) := by decide +kernel

theorem selectedBound46436 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env46437 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,99487,262144,102558,32769,4096,61568,115854,58519,111639,20496,279605,114722,114722,96266,90263,90259,173,57520,1213,104094]

theorem envBound46437 : H12AffineFastState.Bounded env46437 := by
  intro p hp
  have h : env46437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46436_46437 : H12AffineEnvironment.transform 16 99487 env46436 = env46437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 99487 env46436 == env46437) = true)

theorem identity46437 : scanCanonicalize (H12AffineFastState.compose env46437 (packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS)) = affineNative (2^(14+1) ^^^ 9381) := by decide +kernel

theorem selectedBound46437 : packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS < 2^1333 := by decide +kernel

def env46438 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,9381,65536,73786,262144,78907,9380,4096,21541,90155,16434,69810,20496,279605,91271,91271,96266,90263,90259,173,17429,1213,78395]

theorem envBound46438 : H12AffineFastState.Bounded env46438 := by
  intro p hp
  have h : env46438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46437_46438 : H12AffineEnvironment.transform 14 9381 env46437 = env46438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9381 env46437 == env46438) = true)

theorem identity46438 : scanCanonicalize (H12AffineFastState.compose env46438 (packedSelected [3,7,10,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 12347) := by decide +kernel

theorem selectedBound46438 : packedSelected [3,7,10,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env46439 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,9381,12347,4097,262144,1024,9380,4096,21541,20496,16434,8329,20496,279605,21692,21692,18481,20652,20648,173,17429,1213,512]

theorem envBound46439 : H12AffineFastState.Bounded env46439 := by
  intro p hp
  have h : env46439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46438_46439 : H12AffineEnvironment.transform 15 12347 env46438 = env46439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12347 env46438 == env46439) = true)

theorem identity46439 : scanCanonicalize (H12AffineFastState.compose env46439 (packedSelected [4,9,16] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound46439 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env46440 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1212,9381,12347,4097,262144,1024,9380,4096,4249,5292,1166,8329,5292,262281,4096,4096,3213,5136,5140,173,169,1213,512]

theorem envBound46440 : H12AffineFastState.Bounded env46440 := by
  intro p hp
  have h : env46440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46439_46440 : H12AffineEnvironment.transform 13 1212 env46439 = env46440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env46439 == env46440) = true)

theorem identity46440 : scanCanonicalize (H12AffineFastState.compose env46440 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 5677) := by decide +kernel

theorem selectedBound46440 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env46441 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,5677,1212,4744,1558,4097,262144,1024,4745,4096,4249,5292,1166,5796,5292,262281,4096,4096,3213,5136,5140,173,169,1213,512]

theorem envBound46441 : H12AffineFastState.Bounded env46441 := by
  intro p hp
  have h : env46441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46440_46441 : H12AffineEnvironment.transform 12 5677 env46440 = env46441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5677 env46440 == env46441) = true)

theorem identity46441 : scanCanonicalize (H12AffineFastState.compose env46441 (packedSelected [1,3,13] rootPS)) = affineNative (2^(11+1) ^^^ 1212) := by decide +kernel

theorem selectedBound46441 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env46442 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,1212,657,1212,1588,1558,1213,262144,1024,1589,1212,1061,16,1166,536,16,262281,1212,1212,3213,172,168,173,169,1213,512]

theorem envBound46442 : H12AffineFastState.Bounded env46442 := by
  intro p hp
  have h : env46442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46441_46442 : H12AffineEnvironment.transform 11 1212 env46441 = env46442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1212 env46441 == env46442) = true)

theorem identity46442 : scanCanonicalize (H12AffineFastState.compose env46442 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 554) := by decide +kernel

theorem selectedBound46442 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env46443 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,1212,657,1212,1588,1558,1213,554,1024,1589,1212,1061,16,1166,536,16,675,1212,1212,3213,172,168,173,169,1213,512]

theorem envBound46443 : H12AffineFastState.Bounded env46443 := by
  intro p hp
  have h : env46443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46442_46443 : H12AffineEnvironment.transform 17 554 env46442 = env46443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 554 env46442 == env46443) = true)

theorem identity46443 : scanCanonicalize (H12AffineFastState.compose env46443 (packedSelected [0,1,3,4,7,9,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound46443 : packedSelected [0,1,3,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env46444 : List Nat := [2,4,8,16,32,17,128,172,512,5,2048,185,657,185,561,531,184,554,5,560,185,32,16,139,536,16,675,185,185,2184,172,168,173,169,184,512]

theorem envBound46444 : H12AffineFastState.Bounded env46444 := by
  intro p hp
  have h : env46444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46443_46444 : H12AffineEnvironment.transform 9 5 env46443 = env46444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env46443 == env46444) = true)

theorem identity46444 : scanCanonicalize (H12AffineFastState.compose env46444 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound46444 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46445 : List Nat := [2,4,8,16,32,17,128,172,512,5,48,185,657,185,561,531,184,554,5,560,185,32,16,139,536,16,675,185,185,184,172,168,173,169,184,512]

theorem envBound46445 : H12AffineFastState.Bounded env46445 := by
  intro p hp
  have h : env46445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46444_46445 : H12AffineEnvironment.transform 10 48 env46444 = env46445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env46444 == env46445) = true)

theorem identity46445 : scanCanonicalize (H12AffineFastState.compose env46445 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound46445 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env46446 : List Nat := [2,4,8,16,32,17,128,172,27,5,48,185,138,185,42,8,184,49,5,43,185,32,16,139,3,16,184,185,185,184,172,168,173,169,184,27]

theorem envBound46446 : H12AffineFastState.Bounded env46446 := by
  intro p hp
  have h : env46446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46445_46446 : H12AffineEnvironment.transform 8 27 env46445 = env46446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env46445 == env46446) = true)

theorem identity46446 : scanCanonicalize (H12AffineFastState.compose env46446 (packedSelected [0,1,4] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound46446 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env46447 : List Nat := [2,4,8,16,13,17,128,129,27,5,29,148,138,148,7,8,149,28,5,6,148,13,16,139,3,16,149,148,148,149,129,133,128,132,149,27]

theorem envBound46447 : H12AffineFastState.Bounded env46447 := by
  intro p hp
  have h : env46447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46446_46447 : H12AffineEnvironment.transform 4 13 env46446 = env46447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env46446 == env46447) = true)

theorem identity46447 : scanCanonicalize (H12AffineFastState.compose env46447 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound46447 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env46448 : List Nat := [2,4,8,11,13,10,128,129,0,5,6,143,138,143,7,8,142,7,5,6,143,13,11,139,3,11,142,143,143,142,129,133,128,132,142,0]

theorem envBound46448 : H12AffineFastState.Bounded env46448 := by
  intro p hp
  have h : env46448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46447_46448 : H12AffineEnvironment.transform 3 11 env46447 = env46448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env46447 == env46448) = true)

def env46449 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147520,58518,143496,20496,508155,148717,148717,96347,90262,90258,172,222334,1261,135681]

theorem envBound46449 : H12AffineFastState.Bounded env46449 := by
  intro p hp
  have h : env46449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46417_46449 : H12AffineEnvironment.transform 7 173 env46417 = env46449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env46417 == env46449) = true)

def env46450 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61569,147472,58518,143496,20496,508075,148669,148669,96267,90262,90258,172,222254,1213,135681]

theorem envBound46450 : H12AffineFastState.Bounded env46450 := by
  intro p hp
  have h : env46450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46449_46450 : H12AffineEnvironment.transform 5 16 env46449 = env46450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env46449 == env46450) = true)

theorem identity46450 : scanCanonicalize (H12AffineFastState.compose env46450 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 137352) := by decide +kernel

theorem selectedBound46450 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env46451 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,137352,136193,32769,4096,61569,147472,58518,143496,20496,120867,148669,148669,96267,90262,90258,172,222254,1213,135681]

theorem envBound46451 : H12AffineFastState.Bounded env46451 := by
  intro p hp
  have h : env46451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46450_46451 : H12AffineEnvironment.transform 17 137352 env46450 = env46451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137352 env46450 == env46451) = true)

theorem identity46451 : scanCanonicalize (H12AffineFastState.compose env46451 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(16+1) ^^^ 62492) := by decide +kernel

theorem selectedBound46451 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env46452 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,62492,60564,57373,32769,4096,61569,46092,58518,50324,20496,120867,45217,45217,96267,90262,90258,172,102450,1213,58909]

theorem envBound46452 : H12AffineFastState.Bounded env46452 := by
  intro p hp
  have h : env46452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46451_46452 : H12AffineEnvironment.transform 16 62492 env46451 = env46452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 62492 env46451 == env46452) = true)

theorem identity46452 : scanCanonicalize (H12AffineFastState.compose env46452 (packedSelected [4,9,16] rootPS)) = affineNative (2^(14+1) ^^^ 24601) := by decide +kernel

theorem selectedBound46452 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env46453 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,24601,65536,5125,3213,4,24600,4096,4248,21525,1167,9357,20496,79930,20664,20664,96267,90262,90258,172,94251,1213,1540]

theorem envBound46453 : H12AffineFastState.Bounded env46453 := by
  intro p hp
  have h : env46453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46452_46453 : H12AffineEnvironment.transform 14 24601 env46452 = env46453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 24601 env46452 == env46453) = true)

theorem identity46453 : scanCanonicalize (H12AffineFastState.compose env46453 (packedSelected [0,1,2,6,7,8,13,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 18963) := by decide +kernel

theorem selectedBound46453 : packedSelected [0,1,2,6,7,8,13,19,20] rootPS < 2^1333 := by decide +kernel

def env46454 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,24601,18963,5125,3213,4,24600,4096,4248,21525,1167,9357,20496,29225,20664,20664,12824,10885,10881,172,14904,1213,1540]

theorem envBound46454 : H12AffineFastState.Bounded env46454 := by
  intro p hp
  have h : env46454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46453_46454 : H12AffineEnvironment.transform 15 18963 env46453 = env46454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 18963 env46453 == env46454) = true)

theorem identity46454 : scanCanonicalize (H12AffineFastState.compose env46454 (packedSelected [17,18,19,21,23,26] rootPS)) = affineNative (2^(13+1) ^^^ 14888) := by decide +kernel

theorem selectedBound46454 : packedSelected [17,18,19,21,23,26] rootPS < 2^1333 := by decide +kernel

def env46455 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,14888,6705,12347,5125,3213,4,6704,4096,4248,11837,1167,9357,10808,2049,10896,10896,12824,10885,10881,172,14904,1213,1540]

theorem envBound46455 : H12AffineFastState.Bounded env46455 := by
  intro p hp
  have h : env46455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46454_46455 : H12AffineEnvironment.transform 13 14888 env46454 = env46455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 14888 env46454 == env46455) = true)

theorem identity46455 : scanCanonicalize (H12AffineFastState.compose env46455 (packedSelected [3,5,6,10,11,12,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 3749) := by decide +kernel

theorem selectedBound46455 : packedSelected [3,5,6,10,11,12,15,17] rootPS < 2^1333 := by decide +kernel

def env46456 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,3749,5261,6705,7838,5125,3213,4,6704,4096,4248,152,1167,2600,1181,2049,1077,1077,7357,1056,1060,172,5277,1213,1540]

theorem envBound46456 : H12AffineFastState.Bounded env46456 := by
  intro p hp
  have h : env46456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46455_46456 : H12AffineEnvironment.transform 12 3749 env46455 = env46456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3749 env46455 == env46456) = true)

theorem identity46456 : scanCanonicalize (H12AffineFastState.compose env46456 (packedSelected [0,2,3,4,6,7,8,9,12] rootPS)) = affineNative (2^(11+1) ^^^ 1582) := by decide +kernel

theorem selectedBound46456 : packedSelected [0,2,3,4,6,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env46457 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,1582,3749,675,3103,2224,555,3213,4,3102,1582,1718,152,1167,2600,1181,2049,1077,1077,2707,1056,1060,172,691,1213,1540]

theorem envBound46457 : H12AffineFastState.Bounded env46457 := by
  intro p hp
  have h : env46457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46456_46457 : H12AffineEnvironment.transform 11 1582 env46456 = env46457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1582 env46456 == env46457) = true)

theorem identity46457 : scanCanonicalize (H12AffineFastState.compose env46457 (packedSelected [0,1,3,9,10,13] rootPS)) = affineNative (2^(9+1) ^^^ 30) := by decide +kernel

theorem selectedBound46457 : packedSelected [0,1,3,9,10,13] rootPS < 2^1333 := by decide +kernel

def env46458 : List Nat := [2,4,8,16,32,16,128,173,512,30,2048,560,2747,675,2049,2224,555,2195,4,2048,560,680,152,145,2600,131,2049,43,43,2707,62,58,172,691,163,538]

theorem envBound46458 : H12AffineFastState.Bounded env46458 := by
  intro p hp
  have h : env46458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46457_46458 : H12AffineEnvironment.transform 9 30 env46457 = env46458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 30 env46457 == env46458) = true)

theorem identity46458 : scanCanonicalize (H12AffineFastState.compose env46458 (packedSelected [0,1,2,3,4,7,9,10] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound46458 : packedSelected [0,1,2,3,4,7,9,10] rootPS < 2^1333 := by decide +kernel

def env46459 : List Nat := [2,4,8,11,32,11,128,173,512,5,2048,555,2720,675,2049,2219,555,2184,4,2048,555,680,131,138,2600,131,2049,43,43,2696,37,33,172,680,163,513]

theorem envBound46459 : H12AffineFastState.Bounded env46459 := by
  intro p hp
  have h : env46459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46458_46459 : H12AffineEnvironment.transform 3 11 env46458 = env46459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env46458 == env46459) = true)

theorem identity46459 : scanCanonicalize (H12AffineFastState.compose env46459 (packedSelected [2,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 40) := by decide +kernel

theorem selectedBound46459 : packedSelected [2,3,4] rootPS < 2^1333 := by decide +kernel

def env46460 : List Nat := [2,4,8,11,32,11,128,173,512,5,40,555,648,675,41,131,555,160,4,40,555,680,131,138,512,131,41,43,43,672,37,33,172,680,163,513]

theorem envBound46460 : H12AffineFastState.Bounded env46460 := by
  intro p hp
  have h : env46460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46459_46460 : H12AffineEnvironment.transform 10 40 env46459 = env46460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 40 env46459 == env46460) = true)

theorem identity46460 : scanCanonicalize (H12AffineFastState.compose env46460 (packedSelected [0,2,5] rootPS)) = affineNative (2^(8+1) ^^^ 34) := by decide +kernel

theorem selectedBound46460 : packedSelected [0,2,5] rootPS < 2^1333 := by decide +kernel

def env46461 : List Nat := [2,4,8,11,32,11,128,173,34,5,40,9,170,129,41,131,9,160,4,40,9,138,131,138,34,131,41,43,43,130,37,33,172,138,163,35]

theorem envBound46461 : H12AffineFastState.Bounded env46461 := by
  intro p hp
  have h : env46461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46460_46461 : H12AffineEnvironment.transform 8 34 env46460 = env46461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 34 env46460 == env46461) = true)

theorem identity46461 : scanCanonicalize (H12AffineFastState.compose env46461 (packedSelected [2,6] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound46461 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env46462 : List Nat := [2,4,3,0,32,0,128,166,34,5,35,2,161,129,34,131,2,160,4,35,2,129,131,129,34,131,34,32,32,130,37,33,167,129,163,35]

theorem envBound46462 : H12AffineFastState.Bounded env46462 := by
  intro p hp
  have h : env46462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46461_46462 : H12AffineEnvironment.transform 2 3 env46461 = env46462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env46461 == env46462) = true)

theorem identity46462 : scanCanonicalize (H12AffineFastState.compose env46462 (packedSelected [0,1,2] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound46462 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env46463 : List Nat := [2,4,3,0,32,0,35,5,34,5,35,2,2,34,34,32,2,3,4,35,2,34,32,34,34,32,34,32,32,33,37,33,4,34,0,35]

theorem envBound46463 : H12AffineFastState.Bounded env46463 := by
  intro p hp
  have h : env46463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46462_46463 : H12AffineEnvironment.transform 6 35 env46462 = env46463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env46462 == env46463) = true)

theorem identity46463 : scanCanonicalize (H12AffineFastState.compose env46463 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound46463 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46464 : List Nat := [2,1,3,0,32,0,35,0,34,0,35,2,2,34,34,32,2,3,1,35,2,34,32,34,34,32,34,32,32,33,32,33,1,34,0,35]

theorem envBound46464 : H12AffineFastState.Bounded env46464 := by
  intro p hp
  have h : env46464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46463_46464 : H12AffineEnvironment.transform 1 1 env46463 = env46464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env46463 == env46464) = true)

theorem identity46464 : scanCanonicalize (H12AffineFastState.compose env46464 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound46464 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env46465 : List Nat := [2,1,3,0,3,0,0,0,1,0,0,2,2,1,1,3,2,3,1,0,2,1,3,1,1,3,1,3,3,2,3,2,1,1,0,0]

theorem envBound46465 : H12AffineFastState.Bounded env46465 := by
  intro p hp
  have h : env46465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46464_46465 : H12AffineEnvironment.transform 4 3 env46464 = env46465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env46464 == env46465) = true)

def env46466 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61568,147473,58518,143496,20496,508074,148668,148668,96266,90262,90258,172,222255,1212,135681]

theorem envBound46466 : H12AffineFastState.Bounded env46466 := by
  intro p hp
  have h : env46466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46449_46466 : H12AffineEnvironment.transform 5 17 env46449 = env46466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env46449 == env46466) = true)

theorem identity46466 : scanCanonicalize (H12AffineFastState.compose env46466 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 45216) := by decide +kernel

theorem selectedBound46466 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env46467 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,45216,262144,42145,32769,4096,61568,61617,58518,32808,20496,356362,62492,62492,96266,90262,90258,172,119951,1212,41633]

theorem envBound46467 : H12AffineFastState.Bounded env46467 := by
  intro p hp
  have h : env46467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46466_46467 : H12AffineEnvironment.transform 16 45216 env46466 = env46467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45216 env46466 == env46467) = true)

theorem identity46467 : scanCanonicalize (H12AffineFastState.compose env46467 (packedSelected [16,20] rootPS)) = affineNative (2^(17+1) ^^^ 2184) := by decide +kernel

theorem selectedBound46467 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env46468 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,45216,2184,42145,32769,4096,61568,61617,58518,32808,20496,96386,62492,62492,96266,90262,90258,172,119951,1212,41633]

theorem envBound46468 : H12AffineFastState.Bounded env46468 := by
  intro p hp
  have h : env46468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46467_46468 : H12AffineEnvironment.transform 17 2184 env46467 = env46468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2184 env46467 == env46468) = true)

theorem identity46468 : scanCanonicalize (H12AffineFastState.compose env46468 (packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS)) = affineNative (2^(15+1) ^^^ 29831) := by decide +kernel

theorem selectedBound46468 : packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env46469 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,29831,45216,2184,42145,32769,4096,61568,61617,58518,32808,20496,3077,62492,62492,3213,5137,5141,172,40968,1212,41633]

theorem envBound46469 : H12AffineFastState.Bounded env46469 := by
  intro p hp
  have h : env46469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46468_46469 : H12AffineEnvironment.transform 15 29831 env46468 = env46469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29831 env46468 == env46469) = true)

theorem identity46469 : scanCanonicalize (H12AffineFastState.compose env46469 (packedSelected [1,4,5,8,9,16,17,21,24] rootPS)) = affineNative (2^(13+1) ^^^ 184) := by decide +kernel

theorem selectedBound46469 : packedSelected [1,4,5,8,9,16,17,21,24] rootPS < 2^1333 := by decide +kernel

def env46470 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,184,32768,13375,45216,2184,42145,32769,4096,45112,45065,42030,32808,4264,3077,46244,46244,3213,5137,5141,172,40968,1212,41633]

theorem envBound46470 : H12AffineFastState.Bounded env46470 := by
  intro p hp
  have h : env46470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46469_46470 : H12AffineEnvironment.transform 13 184 env46469 = env46470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 184 env46469 == env46470) = true)

theorem identity46470 : scanCanonicalize (H12AffineFastState.compose env46470 (packedSelected [2,3,5,6,10,15,17] rootPS)) = affineNative (2^(14+1) ^^^ 3772) := by decide +kernel

theorem selectedBound46470 : packedSelected [2,3,5,6,10,15,17] rootPS < 2^1333 := by decide +kernel

def env46471 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,184,3772,13375,15900,2184,10781,3773,4096,16004,16053,10898,3732,4264,3077,14872,14872,3213,5137,5141,172,11956,1212,11293]

theorem envBound46471 : H12AffineFastState.Bounded env46471 := by
  intro p hp
  have h : env46471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46470_46471 : H12AffineEnvironment.transform 14 3772 env46470 = env46471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 3772 env46470 == env46471) = true)

theorem identity46471 : scanCanonicalize (H12AffineFastState.compose env46471 (packedSelected [2,4,7,10,12,13,16] rootPS)) = affineNative (2^(11+1) ^^^ 2745) := by decide +kernel

theorem selectedBound46471 : packedSelected [2,4,7,10,12,13,16] rootPS < 2^1333 := by decide +kernel

def env46472 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,2745,8192,184,3772,11910,9381,2184,10781,3773,2745,9277,9228,10898,3732,2577,3077,8353,8353,3213,3752,3756,172,11956,1212,11293]

theorem envBound46472 : H12AffineFastState.Bounded env46472 := by
  intro p hp
  have h : env46472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46471_46472 : H12AffineEnvironment.transform 11 2745 env46471 = env46472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2745 env46471 == env46472) = true)

theorem identity46472 : scanCanonicalize (H12AffineFastState.compose env46472 (packedSelected [0,2,3,4,7,8,9,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 2099) := by decide +kernel

theorem selectedBound46472 : packedSelected [0,2,3,4,7,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env46473 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,2745,2099,184,3772,1717,3222,2184,558,3773,2745,3086,3135,673,3732,2577,3077,2194,2194,3213,3752,3756,172,1671,1212,1070]

theorem envBound46473 : H12AffineFastState.Bounded env46473 := by
  intro p hp
  have h : env46473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46472_46473 : H12AffineEnvironment.transform 12 2099 env46472 = env46473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2099 env46472 == env46473) = true)

theorem identity46473 : scanCanonicalize (H12AffineFastState.compose env46473 (packedSelected [6,7,9,13] rootPS)) = affineNative (2^(9+1) ^^^ 678) := by decide +kernel

theorem selectedBound46473 : packedSelected [6,7,9,13] rootPS < 2^1333 := by decide +kernel

def env46474 : List Nat := [2,4,8,16,32,17,128,173,512,678,2048,2745,2099,184,2074,19,2608,2184,558,2075,2745,2728,2713,673,2098,2577,2723,2194,2194,2603,2062,2058,172,33,538,648]

theorem envBound46474 : H12AffineFastState.Bounded env46474 := by
  intro p hp
  have h : env46474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46473_46474 : H12AffineEnvironment.transform 9 678 env46473 = env46474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 678 env46473 == env46474) = true)

theorem identity46474 : scanCanonicalize (H12AffineFastState.compose env46474 (packedSelected [2,5,6,8] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound46474 : packedSelected [2,5,6,8] rootPS < 2^1333 := by decide +kernel

def env46475 : List Nat := [2,4,8,16,32,17,128,173,0,166,2048,2233,2099,184,2074,19,2096,2184,46,2075,2233,2216,2201,161,2098,2065,2211,2194,2194,2091,2062,2058,172,33,26,136]

theorem envBound46475 : H12AffineFastState.Bounded env46475 := by
  intro p hp
  have h : env46475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46474_46475 : H12AffineEnvironment.transform 8 0 env46474 = env46475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env46474 == env46475) = true)

theorem identity46475 : scanCanonicalize (H12AffineFastState.compose env46475 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound46475 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env46476 : List Nat := [2,4,8,16,32,17,18,63,0,52,2048,2091,2099,42,2074,19,2096,2074,46,2075,2091,2106,2059,51,2098,2065,2097,2048,2048,2091,2062,2058,62,33,26,26]

theorem envBound46476 : H12AffineFastState.Bounded env46476 := by
  intro p hp
  have h : env46476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46475_46476 : H12AffineEnvironment.transform 6 18 env46475 = env46476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env46475 == env46476) = true)

theorem identity46476 : scanCanonicalize (H12AffineFastState.compose env46476 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound46476 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env46477 : List Nat := [2,4,8,16,32,17,18,63,0,52,49,26,2,42,43,19,1,43,46,42,26,11,58,51,3,32,0,49,49,26,63,59,62,33,26,26]

theorem envBound46477 : H12AffineFastState.Bounded env46477 := by
  intro p hp
  have h : env46477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46476_46477 : H12AffineEnvironment.transform 10 49 env46476 = env46477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env46476 == env46477) = true)

def env46478 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,16777216,533641,672785,17245633,148800,545089,96347,16876544,750910,257,17006917,1345,525824]

theorem envBound46478 : H12AffineFastState.Bounded env46478 := by
  intro p hp
  have h : env46478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46349_46478 : H12AffineEnvironment.transform 26 17245633 env46349 = env46478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245633 env46349 == env46478) = true)

theorem identity46478 : scanCanonicalize (H12AffineFastState.compose env46478 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 41002) := by decide +kernel

theorem selectedBound46478 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env46479 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,41002,533641,672785,493035,148800,545089,96347,74794,750910,257,205167,1345,525824]

theorem envBound46479 : H12AffineFastState.Bounded env46479 := by
  intro p hp
  have h : env46479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46478_46479 : H12AffineEnvironment.transform 23 41002 env46478 = env46479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41002 env46478 == env46479) = true)

def env46480 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147520,41002,143497,20497,493035,148800,148801,96347,74794,90430,257,205167,1345,135680]

theorem envBound46480 : H12AffineFastState.Bounded env46480 := by
  intro p hp
  have h : env46480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46479_46480 : H12AffineEnvironment.transform 18 136192 env46479 = env46480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136192 env46479 == env46480) = true)

def env46481 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147520,41002,143497,20497,492615,148716,148717,96347,74794,90258,173,204995,1261,135680]

theorem envBound46481 : H12AffineFastState.Bounded env46481 := by
  intro p hp
  have h : env46481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46480_46481 : H12AffineEnvironment.transform 7 172 env46480 = env46481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env46480 == env46481) = true)

def env46482 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61569,147472,41002,143497,20497,492567,148668,148669,96267,74794,90258,173,204947,1213,135680]

theorem envBound46482 : H12AffineFastState.Bounded env46482 := by
  intro p hp
  have h : env46482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46481_46482 : H12AffineEnvironment.transform 5 16 env46481 = env46482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env46481 == env46482) = true)

theorem identity46482 : scanCanonicalize (H12AffineFastState.compose env46482 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 114722) := by decide +kernel

theorem selectedBound46482 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env46483 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,114722,262144,119842,32769,4096,61569,98354,41002,127147,20497,279605,99486,99487,96267,74794,90258,173,57521,1213,119330]

theorem envBound46483 : H12AffineFastState.Bounded env46483 := by
  intro p hp
  have h : env46483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46482_46483 : H12AffineEnvironment.transform 16 114722 env46482 = env46483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114722 env46482 == env46483) = true)

theorem identity46483 : scanCanonicalize (H12AffineFastState.compose env46483 (packedSelected [3,10,16,18,19,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 18481) := by decide +kernel

theorem selectedBound46483 : packedSelected [3,10,16,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env46484 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,114722,18481,119842,32769,4096,61569,98354,41002,127147,20497,3076,99486,99487,96267,74794,90258,173,57521,1213,119330]

theorem envBound46484 : H12AffineFastState.Bounded env46484 := by
  intro p hp
  have h : env46484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46483_46484 : H12AffineEnvironment.transform 17 18481 env46483 = env46484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 18481 env46483 == env46484) = true)

theorem identity46484 : scanCanonicalize (H12AffineFastState.compose env46484 (packedSelected [7,16,18,19,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53282) := by decide +kernel

theorem selectedBound46484 : packedSelected [7,16,18,19,23,26,27] rootPS < 2^1333 := by decide +kernel

def env46485 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,53282,4096,18481,1024,32769,4096,61569,20496,41002,8329,20497,3076,21692,21693,43049,62472,45232,173,57521,1213,512]

theorem envBound46485 : H12AffineFastState.Bounded env46485 := by
  intro p hp
  have h : env46485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46484_46485 : H12AffineEnvironment.transform 15 53282 env46484 = env46485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53282 env46484 == env46485) = true)

theorem identity46485 : scanCanonicalize (H12AffineFastState.compose env46485 (packedSelected [4,9,16] rootPS)) = affineNative (2^(14+1) ^^^ 9381) := by decide +kernel

theorem selectedBound46485 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env46486 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,9381,29831,4096,18481,1024,9380,4096,21540,20496,1167,8329,20497,3076,21692,21693,3212,20653,5141,173,17428,1213,512]

theorem envBound46486 : H12AffineFastState.Bounded env46486 := by
  intro p hp
  have h : env46486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46485_46486 : H12AffineEnvironment.transform 14 9381 env46485 = env46486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9381 env46485 == env46486) = true)

theorem identity46486 : scanCanonicalize (H12AffineFastState.compose env46486 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 8744) := by decide +kernel

theorem selectedBound46486 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env46487 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,8744,9381,5807,4096,10777,1024,9380,4096,13836,12856,1167,8329,12857,3076,13972,13973,3212,12933,5141,173,9788,1213,512]

theorem envBound46487 : H12AffineFastState.Bounded env46487 := by
  intro p hp
  have h : env46487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46486_46487 : H12AffineEnvironment.transform 13 8744 env46486 = env46487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8744 env46486 == env46487) = true)

theorem identity46487 : scanCanonicalize (H12AffineFastState.compose env46487 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound46487 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env46488 : List Nat := [2,4,8,16,32,16,128,172,26,1024,2048,4096,8192,8242,9381,5301,4096,10243,1024,9380,4096,13334,12322,1167,8329,12323,3076,13454,13455,3212,12447,5141,173,9254,1213,26]

theorem envBound46488 : H12AffineFastState.Bounded env46488 := by
  intro p hp
  have h : env46488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46487_46488 : H12AffineEnvironment.transform 8 26 env46487 = env46488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env46487 == env46488) = true)

theorem identity46488 : scanCanonicalize (H12AffineFastState.compose env46488 (packedSelected [1,3,13] rootPS)) = affineNative (2^(12+1) ^^^ 139) := by decide +kernel

theorem selectedBound46488 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env46489 : List Nat := [2,4,8,16,32,16,128,172,26,1024,2048,4096,139,185,1070,5301,4096,2184,1024,1071,4096,5277,4265,1167,2,4264,3076,5125,5124,3212,4116,5141,173,1197,1213,26]

theorem envBound46489 : H12AffineFastState.Bounded env46489 := by
  intro p hp
  have h : env46489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46488_46489 : H12AffineEnvironment.transform 12 139 env46488 = env46489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 139 env46488 == env46489) = true)

theorem identity46489 : scanCanonicalize (H12AffineFastState.compose env46489 (packedSelected [1,2,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound46489 : packedSelected [1,2,5,6] rootPS < 2^1333 := by decide +kernel

def env46490 : List Nat := [2,4,8,16,32,16,128,172,26,1024,1,4096,139,185,1070,5301,4096,137,1024,1071,4096,5277,4265,1167,2,4264,1029,5125,5124,1165,4116,5141,173,1197,1213,26]

theorem envBound46490 : H12AffineFastState.Bounded env46490 := by
  intro p hp
  have h : env46490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46489_46490 : H12AffineEnvironment.transform 10 1 env46489 = env46490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env46489 == env46490) = true)

theorem identity46490 : scanCanonicalize (H12AffineFastState.compose env46490 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 166) := by decide +kernel

theorem selectedBound46490 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env46491 : List Nat := [2,4,8,16,32,16,128,172,26,166,1,4096,139,185,136,4115,4096,137,166,137,4096,4155,4265,41,2,4264,163,4259,4258,43,4116,4275,173,11,27,26]

theorem envBound46491 : H12AffineFastState.Bounded env46491 := by
  intro p hp
  have h : env46491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46490_46491 : H12AffineEnvironment.transform 9 166 env46490 = env46491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 166 env46490 == env46491) = true)

theorem identity46491 : scanCanonicalize (H12AffineFastState.compose env46491 (packedSelected [2,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound46491 : packedSelected [2,3,4] rootPS < 2^1333 := by decide +kernel

def env46492 : List Nat := [2,4,8,16,32,16,128,172,26,166,1,1,139,185,136,18,1,137,166,137,1,58,168,41,2,169,163,162,163,43,21,178,173,11,27,26]

theorem envBound46492 : H12AffineFastState.Bounded env46492 := by
  intro p hp
  have h : env46492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46491_46492 : H12AffineEnvironment.transform 11 1 env46491 = env46492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env46491 == env46492) = true)

theorem identity46492 : scanCanonicalize (H12AffineFastState.compose env46492 (packedSelected [0,3] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound46492 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env46493 : List Nat := [2,4,8,16,32,16,35,15,26,5,1,1,40,26,43,18,1,42,5,42,1,58,11,41,2,10,0,1,0,43,21,17,14,11,27,26]

theorem envBound46493 : H12AffineFastState.Bounded env46493 := by
  intro p hp
  have h : env46493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46492_46493 : H12AffineEnvironment.transform 6 35 env46492 = env46493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env46492 == env46493) = true)

theorem identity46493 : scanCanonicalize (H12AffineFastState.compose env46493 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound46493 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env46494 : List Nat := [2,4,8,16,17,16,18,15,26,5,1,1,25,26,26,18,1,27,5,27,1,11,11,24,2,10,0,1,0,26,21,17,14,11,27,26]

theorem envBound46494 : H12AffineFastState.Bounded env46494 := by
  intro p hp
  have h : env46494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46493_46494 : H12AffineEnvironment.transform 4 17 env46493 = env46494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env46493 == env46494) = true)

theorem identity46494 : scanCanonicalize (H12AffineFastState.compose env46494 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound46494 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46495 : List Nat := [2,4,8,6,7,6,4,15,12,5,1,1,15,12,12,4,1,13,5,13,1,11,11,14,2,10,0,1,0,12,3,7,14,11,13,12]

theorem envBound46495 : H12AffineFastState.Bounded env46495 := by
  intro p hp
  have h : env46495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46494_46495 : H12AffineEnvironment.transform 3 6 env46494 = env46495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env46494 == env46495) = true)

theorem identity46495 : scanCanonicalize (H12AffineFastState.compose env46495 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound46495 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46496 : List Nat := [2,4,5,6,7,6,4,2,1,5,1,1,2,1,1,4,1,0,5,0,1,6,6,3,2,7,0,1,0,1,3,7,3,6,0,1]

theorem envBound46496 : H12AffineFastState.Bounded env46496 := by
  intro p hp
  have h : env46496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46495_46496 : H12AffineEnvironment.transform 2 5 env46495 = env46496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env46495 == env46496) = true)

def env46497 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61568,147473,41002,143497,20497,492566,148669,148668,96266,74794,90258,173,204946,1212,135680]

theorem envBound46497 : H12AffineFastState.Bounded env46497 := by
  intro p hp
  have h : env46497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46481_46497 : H12AffineEnvironment.transform 5 17 env46481 = env46497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env46481 == env46497) = true)

theorem identity46497 : scanCanonicalize (H12AffineFastState.compose env46497 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 223243) := by decide +kernel

theorem selectedBound46497 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env46498 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,223243,136192,32769,4096,61568,147473,41002,143497,20497,60445,148669,148668,96266,74794,90258,173,204946,1212,135680]

theorem envBound46498 : H12AffineFastState.Bounded env46498 := by
  intro p hp
  have h : env46498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46497_46498 : H12AffineEnvironment.transform 17 223243 env46497 = env46498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223243 env46497 == env46498) = true)

theorem identity46498 : scanCanonicalize (H12AffineFastState.compose env46498 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 28803) := by decide +kernel

theorem selectedBound46498 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env46499 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,28803,131072,137352,136192,32769,4096,61568,147473,41002,143497,20497,60445,148669,148668,2185,21673,4113,173,151569,1212,135680]

theorem envBound46499 : H12AffineFastState.Bounded env46499 := by
  intro p hp
  have h : env46499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46498_46499 : H12AffineEnvironment.transform 15 28803 env46498 = env46499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28803 env46498 == env46499) = true)

theorem identity46499 : scanCanonicalize (H12AffineFastState.compose env46499 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(14+1) ^^^ 24601) := by decide +kernel

theorem selectedBound46499 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env46500 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,24601,28803,131072,137352,136192,24600,4096,4249,147473,16435,143497,20497,3076,148669,148668,2185,21673,4113,173,151569,1212,135680]

theorem envBound46500 : H12AffineFastState.Bounded env46500 := by
  intro p hp
  have h : env46500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46499_46500 : H12AffineEnvironment.transform 14 24601 env46499 = env46500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 24601 env46499 == env46500) = true)

theorem identity46500 : scanCanonicalize (H12AffineFastState.compose env46500 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound46500 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env46501 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1212,9381,13375,131072,137352,136192,9380,4096,4249,132269,1167,143497,5293,3076,131073,131072,2185,4117,4113,173,136365,1212,135680]

theorem envBound46501 : H12AffineFastState.Bounded env46501 := by
  intro p hp
  have h : env46501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46500_46501 : H12AffineEnvironment.transform 13 1212 env46500 = env46501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env46500 == env46501) = true)

theorem identity46501 : scanCanonicalize (H12AffineFastState.compose env46501 (packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 7310) := by decide +kernel

theorem selectedBound46501 : packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env46502 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,7310,1212,6187,2225,131072,137352,136192,6186,4096,4249,132269,1167,134151,5293,3076,131073,131072,2185,4117,4113,173,136365,1212,135680]

theorem envBound46502 : H12AffineFastState.Bounded env46502 := by
  intro p hp
  have h : env46502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46501_46502 : H12AffineEnvironment.transform 12 7310 env46501 = env46502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7310 env46501 == env46502) = true)

theorem identity46502 : scanCanonicalize (H12AffineFastState.compose env46502 (packedSelected [13,17] rootPS)) = affineNative (2^(11+1) ^^^ 185) := by decide +kernel

theorem selectedBound46502 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env46503 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,185,3127,1212,2194,2225,131072,133169,132281,2195,185,32,132269,1167,134151,1044,3076,131073,131072,2185,172,168,173,132116,1212,131769]

theorem envBound46503 : H12AffineFastState.Bounded env46503 := by
  intro p hp
  have h : env46503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46502_46503 : H12AffineEnvironment.transform 11 185 env46502 = env46503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 185 env46502 == env46503) = true)

theorem identity46503 : scanCanonicalize (H12AffineFastState.compose env46503 (packedSelected [0,1,2,3,4,5,6,7,8,9,11,13] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound46503 : packedSelected [0,1,2,3,4,5,6,7,8,9,11,13] rootPS < 2^1333 := by decide +kernel

def env46504 : List Nat := [2,4,8,16,32,17,128,172,1,1024,2048,185,3127,1212,2194,2225,131072,133169,132281,2195,185,32,132269,1167,134151,1044,3076,131073,131072,2185,172,168,173,132116,1212,131256]

theorem envBound46504 : H12AffineFastState.Bounded env46504 := by
  intro p hp
  have h : env46504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46503_46504 : H12AffineEnvironment.transform 8 1 env46503 = env46504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env46503 == env46504) = true)

theorem identity46504 : scanCanonicalize (H12AffineFastState.compose env46504 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 162) := by decide +kernel

theorem selectedBound46504 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env46505 : List Nat := [2,4,8,16,32,17,128,172,1,1024,162,185,1173,1212,48,19,131072,131219,132281,49,185,32,132269,1167,132261,1044,1190,131073,131072,43,172,168,173,132116,1212,131256]

theorem envBound46505 : H12AffineFastState.Bounded env46505 := by
  intro p hp
  have h : env46505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46504_46505 : H12AffineEnvironment.transform 10 162 env46504 = env46505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 162 env46504 == env46505) = true)

theorem identity46505 : scanCanonicalize (H12AffineFastState.compose env46505 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(16+1) ^^^ 1071) := by decide +kernel

theorem selectedBound46505 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env46506 : List Nat := [2,4,8,16,32,17,128,172,1,1024,162,185,1173,1212,48,19,1071,1212,150,49,185,32,130,1167,138,1044,1190,1070,1071,43,172,168,173,59,1212,1175]

theorem envBound46506 : H12AffineFastState.Bounded env46506 := by
  intro p hp
  have h : env46506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46505_46506 : H12AffineEnvironment.transform 16 1071 env46505 = env46506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1071 env46505 == env46506) = true)

theorem identity46506 : scanCanonicalize (H12AffineFastState.compose env46506 (packedSelected [0,1,2,3,4,5] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound46506 : packedSelected [0,1,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env46507 : List Nat := [2,4,4,16,32,17,128,160,1,1024,162,181,1173,1200,48,19,1059,1200,150,49,181,32,130,1155,134,1044,1190,1058,1059,39,160,164,161,55,1200,1175]

theorem envBound46507 : H12AffineFastState.Bounded env46507 := by
  intro p hp
  have h : env46507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46506_46507 : H12AffineEnvironment.transform 2 4 env46506 = env46507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env46506 == env46507) = true)

theorem identity46507 : scanCanonicalize (H12AffineFastState.compose env46507 (packedSelected [0,1,2,9] rootPS)) = affineNative (2^(9+1) ^^^ 19) := by decide +kernel

theorem selectedBound46507 : packedSelected [0,1,2,9] rootPS < 2^1333 := by decide +kernel

def env46508 : List Nat := [2,4,4,16,32,17,128,160,1,19,162,181,134,163,48,19,48,163,150,49,181,32,130,144,134,7,181,49,48,39,160,164,161,55,163,132]

theorem envBound46508 : H12AffineFastState.Bounded env46508 := by
  intro p hp
  have h : env46508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46507_46508 : H12AffineEnvironment.transform 9 19 env46507 = env46508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 19 env46507 == env46508) = true)

theorem identity46508 : scanCanonicalize (H12AffineFastState.compose env46508 (packedSelected [0,1,2,7] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound46508 : packedSelected [0,1,2,7] rootPS < 2^1333 := by decide +kernel

def env46509 : List Nat := [2,4,4,16,32,17,19,51,1,19,49,38,21,48,48,19,48,48,5,49,38,32,17,3,21,7,38,49,48,39,51,55,50,55,48,23]

theorem envBound46509 : H12AffineFastState.Bounded env46509 := by
  intro p hp
  have h : env46509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46508_46509 : H12AffineEnvironment.transform 6 19 env46508 = env46509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env46508 == env46509) = true)

theorem identity46509 : scanCanonicalize (H12AffineFastState.compose env46509 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound46509 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46510 : List Nat := [2,4,4,16,16,17,19,3,1,19,1,22,21,0,0,19,0,0,5,1,22,16,17,3,21,7,22,1,0,23,3,7,2,7,0,23]

theorem envBound46510 : H12AffineFastState.Bounded env46510 := by
  intro p hp
  have h : env46510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46509_46510 : H12AffineEnvironment.transform 4 16 env46509 = env46510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env46509 == env46510) = true)

theorem identity46510 : scanCanonicalize (H12AffineFastState.compose env46510 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound46510 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env46511 : List Nat := [2,4,4,7,7,6,4,3,1,4,1,1,2,0,0,4,0,0,5,1,1,7,6,3,2,7,1,1,0,0,3,7,2,7,0,0]

theorem envBound46511 : H12AffineFastState.Bounded env46511 := by
  intro p hp
  have h : env46511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46510_46511 : H12AffineEnvironment.transform 3 7 env46510 = env46511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env46510 == env46511) = true)

theorem identity46511 : scanCanonicalize (H12AffineFastState.compose env46511 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound46511 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46512 : List Nat := [0,4,4,5,5,4,4,1,1,4,1,1,0,0,0,4,0,0,5,1,1,5,4,1,0,5,1,1,0,0,1,5,0,5,0,0]

theorem envBound46512 : H12AffineFastState.Bounded env46512 := by
  intro p hp
  have h : env46512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46511_46512 : H12AffineEnvironment.transform 0 0 env46511 = env46512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env46511 == env46512) = true)

theorem identity46512 : scanCanonicalize (H12AffineFastState.compose env46512 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound46512 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46513 : List Nat := [0,0,0,1,1,0,0,1,1,0,1,1,0,0,0,0,0,0,1,1,1,1,0,1,0,1,1,1,0,0,1,1,0,1,0,0]

theorem envBound46513 : H12AffineFastState.Bounded env46513 := by
  intro p hp
  have h : env46513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46512_46513 : H12AffineEnvironment.transform 1 0 env46512 = env46513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env46512 == env46513) = true)

def env46514 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147520,41002,143497,20497,492614,148717,148716,96347,74794,90259,172,204994,1260,135680]

theorem envBound46514 : H12AffineFastState.Bounded env46514 := by
  intro p hp
  have h : env46514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46480_46514 : H12AffineEnvironment.transform 7 173 env46480 = env46514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env46480 == env46514) = true)

def env46515 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61569,147472,41002,143497,20497,492566,148669,148668,96267,74794,90259,172,204946,1212,135680]

theorem envBound46515 : H12AffineFastState.Bounded env46515 := by
  intro p hp
  have h : env46515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46514_46515 : H12AffineEnvironment.transform 5 16 env46514 = env46515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env46514 == env46515) = true)

theorem identity46515 : scanCanonicalize (H12AffineFastState.compose env46515 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 45217) := by decide +kernel

theorem selectedBound46515 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env46516 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,45217,262144,42145,32769,4096,61569,61617,41002,32808,20497,341175,62492,62493,96267,74794,90259,172,102451,1212,41633]

theorem envBound46516 : H12AffineFastState.Bounded env46516 := by
  intro p hp
  have h : env46516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46515_46516 : H12AffineEnvironment.transform 16 45217 env46515 = env46516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45217 env46515 == env46516) = true)

theorem identity46516 : scanCanonicalize (H12AffineFastState.compose env46516 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound46516 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env46517 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1213,32768,65536,45217,262144,42145,32769,4096,46140,46092,41002,32808,5292,341175,45217,45216,81078,74794,74798,172,102451,1212,41633]

theorem envBound46517 : H12AffineFastState.Bounded env46517 := by
  intro p hp
  have h : env46517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46516_46517 : H12AffineEnvironment.transform 13 1213 env46516 = env46517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env46516 == env46517) = true)

theorem identity46517 : scanCanonicalize (H12AffineFastState.compose env46517 (packedSelected [4,9,16] rootPS)) = affineNative (2^(14+1) ^^^ 9380) := by decide +kernel

theorem selectedBound46517 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env46518 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1213,9380,65536,5125,262144,5,9381,4096,4248,4264,1166,9356,5292,341175,5125,5124,81078,74794,74798,172,78999,1212,1541]

theorem envBound46518 : H12AffineFastState.Bounded env46518 := by
  intro p hp
  have h : env46518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46517_46518 : H12AffineEnvironment.transform 14 9380 env46517 = env46518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9380 env46517 == env46518) = true)

theorem identity46518 : scanCanonicalize (H12AffineFastState.compose env46518 (packedSelected [4,9,20] rootPS)) = affineNative (2^(15+1) ^^^ 12347) := by decide +kernel

theorem selectedBound46518 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env46519 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1213,9380,12347,5125,262144,5,9381,4096,4248,4264,1166,9356,5292,263308,5125,5124,3213,5137,5141,172,1196,1212,1541]

theorem envBound46519 : H12AffineFastState.Bounded env46519 := by
  intro p hp
  have h : env46519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46518_46519 : H12AffineEnvironment.transform 15 12347 env46518 = env46519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12347 env46518 == env46519) = true)

theorem identity46519 : scanCanonicalize (H12AffineFastState.compose env46519 (packedSelected [1,3,6,10,12,13,17] rootPS)) = affineNative (2^(17+1) ^^^ 12291) := by decide +kernel

theorem selectedBound46519 : packedSelected [1,3,6,10,12,13,17] rootPS < 2^1333 := by decide +kernel

def env46520 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1213,9380,12347,5125,12291,5,9381,4096,4248,4264,1166,9356,5292,13455,5125,5124,3213,5137,5141,172,1196,1212,1541]

theorem envBound46520 : H12AffineFastState.Bounded env46520 := by
  intro p hp
  have h : env46520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46519_46520 : H12AffineEnvironment.transform 17 12291 env46519 = env46520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 12291 env46519 == env46520) = true)

theorem identity46520 : scanCanonicalize (H12AffineFastState.compose env46520 (packedSelected [2,5,6,8,10,11,12,13,18] rootPS)) = affineNative (2^(12+1) ^^^ 3775) := by decide +kernel

theorem selectedBound46520 : packedSelected [2,5,6,8,10,11,12,13,18] rootPS < 2^1333 := by decide +kernel

def env46521 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,3775,1213,2587,7812,5125,7868,5,2586,4096,4248,4264,1166,2611,5292,6704,5125,5124,3213,5137,5141,172,1196,1212,1541]

theorem envBound46521 : H12AffineFastState.Bounded env46521 := by
  intro p hp
  have h : env46521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46520_46521 : H12AffineEnvironment.transform 12 3775 env46520 = env46521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3775 env46520 == env46521) = true)

theorem identity46521 : scanCanonicalize (H12AffineFastState.compose env46521 (packedSelected [5,8] rootPS)) = affineNative (2^(11+1) ^^^ 2194) := by decide +kernel

theorem selectedBound46521 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env46522 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,2194,3775,1213,2587,1558,3223,1582,5,2586,2194,2058,2106,1166,2611,3134,674,3223,3222,3213,3203,3207,172,1196,1212,1541]

theorem envBound46522 : H12AffineFastState.Bounded env46522 := by
  intro p hp
  have h : env46522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46521_46522 : H12AffineEnvironment.transform 11 2194 env46521 = env46522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2194 env46521 == env46522) = true)

theorem identity46522 : scanCanonicalize (H12AffineFastState.compose env46522 (packedSelected [0,1,4,5,7,9,12] rootPS)) = affineNative (2^(10+1) ^^^ 1071) := by decide +kernel

theorem selectedBound46522 : packedSelected [0,1,4,5,7,9,12] rootPS < 2^1333 := by decide +kernel

def env46523 : List Nat := [2,4,8,16,32,16,128,173,512,1024,1071,1213,656,1213,1588,1558,184,1582,5,1589,1213,1061,1045,1166,1564,17,674,184,185,162,172,168,172,1196,1212,1541]

theorem envBound46523 : H12AffineFastState.Bounded env46523 := by
  intro p hp
  have h : env46523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46522_46523 : H12AffineEnvironment.transform 10 1071 env46522 = env46523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1071 env46522 == env46523) = true)

theorem identity46523 : scanCanonicalize (H12AffineFastState.compose env46523 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(8+1) ^^^ 146) := by decide +kernel

theorem selectedBound46523 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env46524 : List Nat := [2,4,8,16,32,16,128,173,146,1024,1071,1213,2,1213,1190,1156,184,1212,5,1191,1213,1061,1045,1166,1166,17,48,184,185,162,172,168,172,1196,1212,1175]

theorem envBound46524 : H12AffineFastState.Bounded env46524 := by
  intro p hp
  have h : env46524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46523_46524 : H12AffineEnvironment.transform 8 146 env46523 = env46524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 146 env46523 == env46524) = true)

theorem identity46524 : scanCanonicalize (H12AffineFastState.compose env46524 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound46524 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env46525 : List Nat := [2,4,5,16,32,16,128,160,146,1024,1058,1200,2,1200,1190,1156,181,1201,5,1191,1200,1061,1045,1155,1155,17,48,181,180,162,161,165,161,1185,1201,1175]

theorem envBound46525 : H12AffineFastState.Bounded env46525 := by
  intro p hp
  have h : env46525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46524_46525 : H12AffineEnvironment.transform 2 5 env46524 = env46525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env46524 == env46525) = true)

theorem identity46525 : scanCanonicalize (H12AffineFastState.compose env46525 (packedSelected [0,1,4,7,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 150) := by decide +kernel

theorem selectedBound46525 : packedSelected [0,1,4,7,9,10] rootPS < 2^1333 := by decide +kernel

def env46526 : List Nat := [2,4,5,16,32,16,128,160,146,150,180,38,2,38,48,18,181,39,5,49,38,179,131,21,21,17,48,181,180,162,161,165,161,55,39,1]

theorem envBound46526 : H12AffineFastState.Bounded env46526 := by
  intro p hp
  have h : env46526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46525_46526 : H12AffineEnvironment.transform 9 150 env46525 = env46526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 150 env46525 == env46526) = true)

theorem identity46526 : scanCanonicalize (H12AffineFastState.compose env46526 (packedSelected [2,3,4,7] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound46526 : packedSelected [2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env46527 : List Nat := [2,4,5,16,32,16,19,51,1,5,39,38,2,38,48,18,38,39,5,49,38,32,16,21,21,17,48,38,39,49,50,54,50,55,39,1]

theorem envBound46527 : H12AffineFastState.Bounded env46527 := by
  intro p hp
  have h : env46527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46526_46527 : H12AffineEnvironment.transform 6 19 env46526 = env46527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env46526 == env46527) = true)

def env46528 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61568,147473,41002,143497,20497,492567,148668,148669,96266,74794,90259,172,204947,1213,135680]

theorem envBound46528 : H12AffineFastState.Bounded env46528 := by
  intro p hp
  have h : env46528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46514_46528 : H12AffineEnvironment.transform 5 17 env46514 = env46528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env46514 == env46528) = true)

theorem identity46528 : scanCanonicalize (H12AffineFastState.compose env46528 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 137353) := by decide +kernel

theorem selectedBound46528 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env46529 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,137353,136192,32769,4096,61568,147473,41002,143497,20497,105630,148668,148669,96266,74794,90259,172,204947,1213,135680]

theorem envBound46529 : H12AffineFastState.Bounded env46529 := by
  intro p hp
  have h : env46529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46528_46529 : H12AffineEnvironment.transform 17 137353 env46528 = env46529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137353 env46528 == env46529) = true)

theorem identity46529 : scanCanonicalize (H12AffineFastState.compose env46529 (packedSelected [1,5,8,18,19,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 13374) := by decide +kernel

theorem selectedBound46529 : packedSelected [1,5,8,18,19,23,24,26] rootPS < 2^1333 := by decide +kernel

def env46530 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,13374,131072,137353,136192,32769,4096,61568,147473,41002,143497,20497,43168,148668,148669,19508,4116,21677,172,136365,1213,135680]

theorem envBound46530 : H12AffineFastState.Bounded env46530 := by
  intro p hp
  have h : env46530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46529_46530 : H12AffineEnvironment.transform 15 13374 env46529 = env46530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13374 env46529 == env46530) = true)

theorem identity46530 : scanCanonicalize (H12AffineFastState.compose env46530 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound46530 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env46531 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1213,32768,13374,131072,137353,136192,32769,4096,46141,132268,41002,143497,5292,43168,131073,131072,2185,4116,4112,172,136365,1213,135680]

theorem envBound46531 : H12AffineFastState.Bounded env46531 := by
  intro p hp
  have h : env46531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46530_46531 : H12AffineEnvironment.transform 13 1213 env46530 = env46531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env46530 == env46531) = true)

theorem identity46531 : scanCanonicalize (H12AffineFastState.compose env46531 (packedSelected [13,17] rootPS)) = affineNative (2^(16+1) ^^^ 40984) := by decide +kernel

theorem selectedBound46531 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env46532 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1213,32768,13374,40984,47249,46104,32769,4096,46141,42164,41002,37009,5292,43168,40985,40984,2185,4116,4112,172,46261,1213,45592]

theorem envBound46532 : H12AffineFastState.Bounded env46532 := by
  intro p hp
  have h : env46532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46531_46532 : H12AffineEnvironment.transform 16 40984 env46531 = env46532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 40984 env46531 == env46532) = true)

theorem identity46532 : scanCanonicalize (H12AffineFastState.compose env46532 (packedSelected [0,4,5,7,8,9,10,13] rootPS)) = affineNative (2^(11+1) ^^^ 3103) := by decide +kernel

theorem selectedBound46532 : packedSelected [0,4,5,7,8,9,10,13] rootPS < 2^1333 := by decide +kernel

def env46533 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,3103,8192,1213,32768,10273,40984,42126,43015,32769,3103,43042,42164,41002,35982,2227,43168,40985,40984,2185,3083,3087,172,43178,1213,44551]

theorem envBound46533 : H12AffineFastState.Bounded env46533 := by
  intro p hp
  have h : env46533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46532_46533 : H12AffineEnvironment.transform 11 3103 env46532 = env46533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3103 env46532 == env46533) = true)

theorem identity46533 : scanCanonicalize (H12AffineFastState.compose env46533 (packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 1191) := by decide +kernel

theorem selectedBound46533 : packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env46534 : List Nat := [2,4,8,16,32,17,128,173,512,1024,1191,184,8192,1213,32768,9350,40984,42126,42144,32769,184,42117,42164,41002,32809,1044,41991,40985,40984,1070,172,168,172,41997,1213,41632]

theorem envBound46534 : H12AffineFastState.Bounded env46534 := by
  intro p hp
  have h : env46534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46533_46534 : H12AffineEnvironment.transform 10 1191 env46533 = env46534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1191 env46533 == env46534) = true)

theorem identity46534 : scanCanonicalize (H12AffineFastState.compose env46534 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(14+1) ^^^ 675) := by decide +kernel

theorem selectedBound46534 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env46535 : List Nat := [2,4,8,16,32,17,128,173,512,1024,1191,184,8192,1213,675,9350,8891,9773,9731,674,184,9766,9751,8841,650,1044,9892,8890,8891,1070,172,168,172,9902,1213,8195]

theorem envBound46535 : H12AffineFastState.Bounded env46535 := by
  intro p hp
  have h : env46535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46534_46535 : H12AffineEnvironment.transform 14 675 env46534 = env46535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 675 env46534 == env46535) = true)

theorem identity46535 : scanCanonicalize (H12AffineFastState.compose env46535 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 1678) := by decide +kernel

theorem selectedBound46535 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env46536 : List Nat := [2,4,8,16,32,17,128,173,512,1024,1191,184,1678,1213,675,520,1077,163,141,674,184,168,153,1031,650,1044,42,1076,1077,1070,172,168,172,32,1213,1677]

theorem envBound46536 : H12AffineFastState.Bounded env46536 := by
  intro p hp
  have h : env46536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46535_46536 : H12AffineEnvironment.transform 12 1678 env46535 = env46536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1678 env46535 == env46536) = true)

theorem identity46536 : scanCanonicalize (H12AffineFastState.compose env46536 (packedSelected [4,6,7] rootPS)) = affineNative (2^(8+1) ^^^ 162) := by decide +kernel

theorem selectedBound46536 : packedSelected [4,6,7] rootPS < 2^1333 := by decide +kernel

def env46537 : List Nat := [2,4,8,16,32,17,128,173,162,1024,1191,184,1068,1213,1,170,1077,163,141,0,184,168,153,1031,40,1044,42,1076,1077,1070,172,168,172,32,1213,1071]

theorem envBound46537 : H12AffineFastState.Bounded env46537 := by
  intro p hp
  have h : env46537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46536_46537 : H12AffineEnvironment.transform 8 162 env46536 = env46537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 162 env46536 == env46537) = true)

def env46538 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147520,41002,143496,20496,493035,148800,148800,96347,74794,90431,257,205167,1345,135681]

theorem envBound46538 : H12AffineFastState.Bounded env46538 := by
  intro p hp
  have h : env46538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46479_46538 : H12AffineEnvironment.transform 18 136193 env46479 = env46538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136193 env46479 == env46538) = true)

def env46539 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147520,41002,143496,20496,492615,148716,148716,96347,74794,90259,173,204995,1261,135681]

theorem envBound46539 : H12AffineFastState.Bounded env46539 := by
  intro p hp
  have h : env46539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46538_46539 : H12AffineEnvironment.transform 7 172 env46538 = env46539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env46538 == env46539) = true)

def env46540 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61569,147472,41002,143496,20496,492567,148668,148668,96267,74794,90259,173,204947,1213,135681]

theorem envBound46540 : H12AffineFastState.Bounded env46540 := by
  intro p hp
  have h : env46540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46539_46540 : H12AffineEnvironment.transform 5 16 env46539 = env46540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env46539 == env46540) = true)

theorem identity46540 : scanCanonicalize (H12AffineFastState.compose env46540 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 223243) := by decide +kernel

theorem selectedBound46540 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env46541 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,223243,136193,32769,4096,61569,147472,41002,143496,20496,60444,148668,148668,96267,74794,90259,173,204947,1213,135681]

theorem envBound46541 : H12AffineFastState.Bounded env46541 := by
  intro p hp
  have h : env46541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46540_46541 : H12AffineEnvironment.transform 17 223243 env46540 = env46541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223243 env46540 == env46541) = true)

theorem identity46541 : scanCanonicalize (H12AffineFastState.compose env46541 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 28802) := by decide +kernel

theorem selectedBound46541 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env46542 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,28802,131072,137353,136193,32769,4096,61569,147472,41002,143496,20496,60444,148668,148668,2185,21672,4113,173,151569,1213,135681]

theorem envBound46542 : H12AffineFastState.Bounded env46542 := by
  intro p hp
  have h : env46542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46541_46542 : H12AffineEnvironment.transform 15 28802 env46541 = env46542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28802 env46541 == env46542) = true)

theorem identity46542 : scanCanonicalize (H12AffineFastState.compose env46542 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(14+1) ^^^ 24601) := by decide +kernel

theorem selectedBound46542 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env46543 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,24601,28802,131072,137353,136193,24600,4096,4248,147472,16435,143496,20496,3077,148668,148668,2185,21672,4113,173,151569,1213,135681]

theorem envBound46543 : H12AffineFastState.Bounded env46543 := by
  intro p hp
  have h : env46543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46542_46543 : H12AffineEnvironment.transform 14 24601 env46542 = env46543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 24601 env46542 == env46543) = true)

theorem identity46543 : scanCanonicalize (H12AffineFastState.compose env46543 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound46543 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env46544 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1213,9380,13375,131072,137353,136193,9381,4096,4248,132269,1166,143496,5293,3077,131073,131073,2185,4117,4113,173,136364,1213,135681]

theorem envBound46544 : H12AffineFastState.Bounded env46544 := by
  intro p hp
  have h : env46544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46543_46544 : H12AffineEnvironment.transform 13 1213 env46543 = env46544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env46543 == env46544) = true)

theorem identity46544 : scanCanonicalize (H12AffineFastState.compose env46544 (packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS)) = affineNative (2^(16+1) ^^^ 11407) := by decide +kernel

theorem selectedBound46544 : packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env46545 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1213,9380,13375,11407,13318,14478,9381,4096,4248,10274,1166,7175,5293,3077,11406,11406,2185,4117,4113,173,14371,1213,16014]

theorem envBound46545 : H12AffineFastState.Bounded env46545 := by
  intro p hp
  have h : env46545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46544_46545 : H12AffineEnvironment.transform 16 11407 env46544 = env46545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 11407 env46544 == env46545) = true)

theorem identity46545 : scanCanonicalize (H12AffineFastState.compose env46545 (packedSelected [13,17] rootPS)) = affineNative (2^(12+1) ^^^ 3127) := by decide +kernel

theorem selectedBound46545 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env46546 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,3127,1213,2195,6152,184,6193,5305,2194,4096,4248,1045,1166,7175,5293,3077,185,185,2185,4117,4113,173,5140,1213,4793]

theorem envBound46546 : H12AffineFastState.Bounded env46546 := by
  intro p hp
  have h : env46546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46545_46546 : H12AffineEnvironment.transform 12 3127 env46545 = env46546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3127 env46545 == env46546) = true)

theorem identity46546 : scanCanonicalize (H12AffineFastState.compose env46546 (packedSelected [1,2,3,6,10,11] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound46546 : packedSelected [1,2,3,6,10,11] rootPS < 2^1333 := by decide +kernel

def env46547 : List Nat := [2,4,8,16,32,16,128,172,512,517,2048,4096,2610,696,2195,6152,184,6193,4796,2194,4096,4248,528,651,6658,4776,2560,185,185,2185,4117,4113,173,4625,696,4793]

theorem envBound46547 : H12AffineFastState.Bounded env46547 := by
  intro p hp
  have h : env46547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46546_46547 : H12AffineEnvironment.transform 9 517 env46546 = env46547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env46546 == env46547) = true)

theorem identity46547 : scanCanonicalize (H12AffineFastState.compose env46547 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 163) := by decide +kernel

theorem selectedBound46547 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env46548 : List Nat := [2,4,8,16,32,16,128,172,512,517,163,4096,657,696,48,4267,184,4242,4796,49,4096,4248,528,651,4769,4776,675,185,185,42,4117,4113,173,4625,696,4793]

theorem envBound46548 : H12AffineFastState.Bounded env46548 := by
  intro p hp
  have h : env46548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46547_46548 : H12AffineEnvironment.transform 10 163 env46547 = env46548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 163 env46547 == env46548) = true)

theorem identity46548 : scanCanonicalize (H12AffineFastState.compose env46548 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(11+1) ^^^ 42) := by decide +kernel

theorem selectedBound46548 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env46549 : List Nat := [2,4,8,16,32,16,128,172,512,517,163,42,657,696,48,129,184,184,662,49,42,178,528,651,651,642,675,185,185,42,63,59,173,571,696,659]

theorem envBound46549 : H12AffineFastState.Bounded env46549 := by
  intro p hp
  have h : env46549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46548_46549 : H12AffineEnvironment.transform 11 42 env46548 = env46549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 42 env46548 == env46549) = true)

theorem identity46549 : scanCanonicalize (H12AffineFastState.compose env46549 (packedSelected [1,3,4,9] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound46549 : packedSelected [1,3,4,9] rootPS < 2^1333 := by decide +kernel

def env46550 : List Nat := [2,4,8,16,32,16,128,172,27,30,163,42,138,163,48,129,184,184,141,49,42,178,11,144,144,153,184,185,185,42,63,59,173,32,163,136]

theorem envBound46550 : H12AffineFastState.Bounded env46550 := by
  intro p hp
  have h : env46550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46549_46550 : H12AffineEnvironment.transform 8 27 env46549 = env46550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env46549 == env46550) = true)

theorem identity46550 : scanCanonicalize (H12AffineFastState.compose env46550 (packedSelected [0,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 47) := by decide +kernel

theorem selectedBound46550 : packedSelected [0,4,5] rootPS < 2^1333 := by decide +kernel

def env46551 : List Nat := [2,4,8,16,32,16,47,3,27,30,12,42,37,12,48,46,23,23,34,49,42,29,11,63,63,54,23,22,22,42,63,59,2,32,12,39]

theorem envBound46551 : H12AffineFastState.Bounded env46551 := by
  intro p hp
  have h : env46551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46550_46551 : H12AffineEnvironment.transform 6 47 env46550 = env46551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 47 env46550 == env46551) = true)

theorem identity46551 : scanCanonicalize (H12AffineFastState.compose env46551 (packedSelected [0,3,7] rootPS)) = affineNative (2^(4+1) ^^^ 28) := by decide +kernel

theorem selectedBound46551 : packedSelected [0,3,7] rootPS < 2^1333 := by decide +kernel

def env46552 : List Nat := [2,4,8,16,28,16,19,3,27,30,12,22,25,12,12,18,23,23,30,13,22,29,11,3,3,10,23,22,22,22,3,7,2,28,12,27]

theorem envBound46552 : H12AffineFastState.Bounded env46552 := by
  intro p hp
  have h : env46552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46551_46552 : H12AffineEnvironment.transform 4 28 env46551 = env46552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 28 env46551 == env46552) = true)

theorem identity46552 : scanCanonicalize (H12AffineFastState.compose env46552 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound46552 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46553 : List Nat := [2,4,8,10,6,10,9,3,1,4,12,12,3,12,12,8,13,13,4,13,12,7,11,3,3,10,13,12,12,12,3,7,2,6,12,1]

theorem envBound46553 : H12AffineFastState.Bounded env46553 := by
  intro p hp
  have h : env46553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46552_46553 : H12AffineEnvironment.transform 3 10 env46552 = env46553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env46552 == env46553) = true)

def env46554 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61568,147473,41002,143496,20496,492566,148669,148669,96266,74794,90259,173,204946,1212,135681]

theorem envBound46554 : H12AffineFastState.Bounded env46554 := by
  intro p hp
  have h : env46554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46539_46554 : H12AffineEnvironment.transform 5 17 env46539 = env46554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env46539 == env46554) = true)

theorem identity46554 : scanCanonicalize (H12AffineFastState.compose env46554 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 114722) := by decide +kernel

theorem selectedBound46554 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env46555 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,114722,262144,119843,32769,4096,61568,98355,41002,127146,20496,279604,99487,99487,96266,74794,90259,173,57520,1212,119331]

theorem envBound46555 : H12AffineFastState.Bounded env46555 := by
  intro p hp
  have h : env46555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46554_46555 : H12AffineEnvironment.transform 16 114722 env46554 = env46555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114722 env46554 == env46555) = true)

theorem identity46555 : scanCanonicalize (H12AffineFastState.compose env46555 (packedSelected [3,10,16,18,19,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 18481) := by decide +kernel

theorem selectedBound46555 : packedSelected [3,10,16,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env46556 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,114722,18481,119843,32769,4096,61568,98355,41002,127146,20496,3077,99487,99487,96266,74794,90259,173,57520,1212,119331]

theorem envBound46556 : H12AffineFastState.Bounded env46556 := by
  intro p hp
  have h : env46556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46555_46556 : H12AffineEnvironment.transform 17 18481 env46555 = env46556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 18481 env46555 == env46556) = true)

theorem identity46556 : scanCanonicalize (H12AffineFastState.compose env46556 (packedSelected [7,16,18,19,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53283) := by decide +kernel

theorem selectedBound46556 : packedSelected [7,16,18,19,23,26,27] rootPS < 2^1333 := by decide +kernel

def env46557 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,53283,4097,18481,1024,32769,4096,61568,20496,41002,8329,20496,3077,21692,21692,43049,62473,45232,173,57520,1212,512]

theorem envBound46557 : H12AffineFastState.Bounded env46557 := by
  intro p hp
  have h : env46557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46556_46557 : H12AffineEnvironment.transform 15 53283 env46556 = env46557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53283 env46556 == env46557) = true)

theorem identity46557 : scanCanonicalize (H12AffineFastState.compose env46557 (packedSelected [4,9,16] rootPS)) = affineNative (2^(14+1) ^^^ 9380) := by decide +kernel

theorem selectedBound46557 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env46558 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,9380,29831,4097,18481,1024,9381,4096,21540,20496,1166,8329,20496,3077,21692,21692,3213,20653,5140,173,17428,1212,512]

theorem envBound46558 : H12AffineFastState.Bounded env46558 := by
  intro p hp
  have h : env46558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46557_46558 : H12AffineEnvironment.transform 14 9380 env46557 = env46558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9380 env46557 == env46558) = true)

theorem identity46558 : scanCanonicalize (H12AffineFastState.compose env46558 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 9772) := by decide +kernel

theorem selectedBound46558 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env46559 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,9772,9380,4779,4097,11805,1024,9381,4096,12808,13884,1166,8329,13884,3077,12944,12944,3213,13953,5140,173,8760,1212,512]

theorem envBound46559 : H12AffineFastState.Bounded env46559 := by
  intro p hp
  have h : env46559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46558_46559 : H12AffineEnvironment.transform 13 9772 env46558 = env46559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 9772 env46558 == env46559) = true)

theorem identity46559 : scanCanonicalize (H12AffineFastState.compose env46559 (packedSelected [0,3,4,8,13] rootPS)) = affineNative (2^(12+1) ^^^ 1167) := by decide +kernel

theorem selectedBound46559 : packedSelected [0,3,4,8,13] rootPS < 2^1333 := by decide +kernel

def env46560 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,1167,675,43,4779,4097,2706,1024,42,4096,5767,4787,1166,1030,4787,3077,5663,5663,3213,4622,5140,173,1719,1212,512]

theorem envBound46560 : H12AffineFastState.Bounded env46560 := by
  intro p hp
  have h : env46560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46559_46560 : H12AffineEnvironment.transform 12 1167 env46559 = env46560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1167 env46559 == env46560) = true)

theorem identity46560 : scanCanonicalize (H12AffineFastState.compose env46560 (packedSelected [0,2,5,7,8,11,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 3076) := by decide +kernel

theorem selectedBound46560 : packedSelected [0,2,5,7,8,11,12,15] rootPS < 2^1333 := by decide +kernel

def env46561 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,3076,1167,675,43,3759,3077,2706,1024,42,3076,2691,3767,1166,1030,3767,3077,2587,2587,3213,3594,2064,173,1719,1212,512]

theorem envBound46561 : H12AffineFastState.Bounded env46561 := by
  intro p hp
  have h : env46561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46560_46561 : H12AffineEnvironment.transform 11 3076 env46560 = env46561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3076 env46560 == env46561) = true)

theorem identity46561 : scanCanonicalize (H12AffineFastState.compose env46561 (packedSelected [1,2,4,5,6,9,12] rootPS)) = affineNative (2^(10+1) ^^^ 675) := by decide +kernel

theorem selectedBound46561 : packedSelected [1,2,4,5,6,9,12] rootPS < 2^1333 := by decide +kernel

def env46562 : List Nat := [2,4,8,16,32,17,128,172,512,1024,675,1703,1167,675,43,1036,1702,49,1024,42,1703,32,1044,1166,1030,1044,1702,184,184,1582,1193,691,173,1719,1212,512]

theorem envBound46562 : H12AffineFastState.Bounded env46562 := by
  intro p hp
  have h : env46562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46561_46562 : H12AffineEnvironment.transform 10 675 env46561 = env46562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 675 env46561 == env46562) = true)

theorem identity46562 : scanCanonicalize (H12AffineFastState.compose env46562 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound46562 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env46563 : List Nat := [2,4,8,16,32,17,128,172,512,4,675,675,139,675,43,8,674,49,4,42,675,32,16,138,2,16,674,184,184,554,173,691,173,691,184,512]

theorem envBound46563 : H12AffineFastState.Bounded env46563 := by
  intro p hp
  have h : env46563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46562_46563 : H12AffineEnvironment.transform 9 4 env46562 = env46563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env46562 == env46563) = true)

theorem identity46563 : scanCanonicalize (H12AffineFastState.compose env46563 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound46563 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env46564 : List Nat := [2,4,8,16,32,17,128,172,27,4,184,184,139,184,43,8,185,49,4,42,184,32,16,138,2,16,185,184,184,49,173,168,173,168,184,27]

theorem envBound46564 : H12AffineFastState.Bounded env46564 := by
  intro p hp
  have h : env46564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46563_46564 : H12AffineEnvironment.transform 8 27 env46563 = env46564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env46563 == env46564) = true)

theorem identity46564 : scanCanonicalize (H12AffineFastState.compose env46564 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound46564 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46565 : List Nat := [2,4,8,12,32,13,128,172,7,4,164,164,139,164,43,8,165,45,4,42,164,32,12,138,2,12,165,164,164,45,173,168,173,168,164,7]

theorem envBound46565 : H12AffineFastState.Bounded env46565 := by
  intro p hp
  have h : env46565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46564_46565 : H12AffineEnvironment.transform 3 12 env46564 = env46565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env46564 == env46565) = true)

theorem identity46565 : scanCanonicalize (H12AffineFastState.compose env46565 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound46565 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46566 : List Nat := [2,4,8,12,32,13,9,37,7,4,45,45,2,45,43,8,44,45,4,42,45,32,12,3,2,12,44,45,45,45,36,33,36,33,45,7]

theorem envBound46566 : H12AffineFastState.Bounded env46566 := by
  intro p hp
  have h : env46566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46565_46566 : H12AffineEnvironment.transform 6 9 env46565 = env46566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env46565 == env46566) = true)

theorem identity46566 : scanCanonicalize (H12AffineFastState.compose env46566 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound46566 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46567 : List Nat := [2,2,8,10,32,11,9,35,1,2,43,43,2,43,43,8,42,43,2,42,43,32,10,3,2,10,42,43,43,43,34,33,34,33,43,1]

theorem envBound46567 : H12AffineFastState.Bounded env46567 := by
  intro p hp
  have h : env46567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46566_46567 : H12AffineEnvironment.transform 1 2 env46566 = env46567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env46566 == env46567) = true)

theorem identity46567 : scanCanonicalize (H12AffineFastState.compose env46567 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound46567 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env46568 : List Nat := [2,2,8,10,11,11,9,8,1,2,0,0,2,0,0,8,1,0,2,1,0,11,10,3,2,10,1,0,0,0,9,10,9,10,0,1]

theorem envBound46568 : H12AffineFastState.Bounded env46568 := by
  intro p hp
  have h : env46568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46567_46568 : H12AffineEnvironment.transform 4 11 env46567 = env46568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env46567 == env46568) = true)

def env46569 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147520,41002,143496,20496,492614,148717,148717,96347,74794,90258,172,204994,1260,135681]

theorem envBound46569 : H12AffineFastState.Bounded env46569 := by
  intro p hp
  have h : env46569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46538_46569 : H12AffineEnvironment.transform 7 173 env46538 = env46569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env46538 == env46569) = true)

def env46570 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61569,147472,41002,143496,20496,492566,148669,148669,96267,74794,90258,172,204946,1212,135681]

theorem envBound46570 : H12AffineFastState.Bounded env46570 := by
  intro p hp
  have h : env46570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46569_46570 : H12AffineEnvironment.transform 5 16 env46569 = env46570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env46569 == env46570) = true)

theorem identity46570 : scanCanonicalize (H12AffineFastState.compose env46570 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 137352) := by decide +kernel

theorem selectedBound46570 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env46571 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,137352,136193,32769,4096,61569,147472,41002,143496,20496,105630,148669,148669,96267,74794,90258,172,204946,1212,135681]

theorem envBound46571 : H12AffineFastState.Bounded env46571 := by
  intro p hp
  have h : env46571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46570_46571 : H12AffineEnvironment.transform 17 137352 env46570 = env46571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137352 env46570 == env46571) = true)

theorem identity46571 : scanCanonicalize (H12AffineFastState.compose env46571 (packedSelected [1,5,8,18,19,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 13374) := by decide +kernel

theorem selectedBound46571 : packedSelected [1,5,8,18,19,23,24,26] rootPS < 2^1333 := by decide +kernel

def env46572 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,13374,131072,137352,136193,32769,4096,61569,147472,41002,143496,20496,43168,148669,148669,19509,4116,21676,172,136364,1212,135681]

theorem envBound46572 : H12AffineFastState.Bounded env46572 := by
  intro p hp
  have h : env46572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46571_46572 : H12AffineEnvironment.transform 15 13374 env46571 = env46572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13374 env46571 == env46572) = true)

theorem identity46572 : scanCanonicalize (H12AffineFastState.compose env46572 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound46572 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env46573 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1212,32768,13374,131072,137352,136193,32769,4096,46141,132268,41002,143496,5292,43168,131073,131073,2185,4116,4112,172,136364,1212,135681]

theorem envBound46573 : H12AffineFastState.Bounded env46573 := by
  intro p hp
  have h : env46573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46572_46573 : H12AffineEnvironment.transform 13 1212 env46572 = env46573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env46572 == env46573) = true)

theorem identity46573 : scanCanonicalize (H12AffineFastState.compose env46573 (packedSelected [13,17] rootPS)) = affineNative (2^(14+1) ^^^ 12312) := by decide +kernel

theorem selectedBound46573 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env46574 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1212,12312,13374,131072,137352,136193,12313,4096,1061,132268,4146,143496,5292,6328,131073,131073,2185,4116,4112,172,136364,1212,135681]

theorem envBound46574 : H12AffineFastState.Bounded env46574 := by
  intro p hp
  have h : env46574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46573_46574 : H12AffineEnvironment.transform 14 12312 env46573 = env46574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12312 env46573 == env46574) = true)

theorem identity46574 : scanCanonicalize (H12AffineFastState.compose env46574 (packedSelected [0,4,5,7,8,9,10,13] rootPS)) = affineNative (2^(16+1) ^^^ 7335) := by decide +kernel

theorem selectedBound46574 : packedSelected [0,4,5,7,8,9,10,13] rootPS < 2^1333 := by decide +kernel

def env46575 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1212,12312,13374,7335,1071,2214,12313,4096,1061,6155,4146,11311,5292,6328,7334,7334,2185,4116,4112,172,2059,1212,3750]

theorem envBound46575 : H12AffineFastState.Bounded env46575 := by
  intro p hp
  have h : env46575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46574_46575 : H12AffineEnvironment.transform 16 7335 env46574 = env46575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 7335 env46574 == env46575) = true)

theorem identity46575 : scanCanonicalize (H12AffineFastState.compose env46575 (packedSelected [1,5] rootPS)) = affineNative (2^(12+1) ^^^ 7175) := by decide +kernel

theorem selectedBound46575 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env46576 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,7175,1212,3103,2105,7335,1071,2214,3102,4096,1061,6155,4146,4136,5292,6328,7334,7334,2185,4116,4112,172,2059,1212,3750]

theorem envBound46576 : H12AffineFastState.Bounded env46576 := by
  intro p hp
  have h : env46576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46575_46576 : H12AffineEnvironment.transform 12 7175 env46575 = env46576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7175 env46575 == env46576) = true)

theorem identity46576 : scanCanonicalize (H12AffineFastState.compose env46576 (packedSelected [1,4,7,8,10,11,16] rootPS)) = affineNative (2^(11+1) ^^^ 560) := by decide +kernel

theorem selectedBound46576 : packedSelected [1,4,7,8,10,11,16] rootPS < 2^1333 := by decide +kernel

def env46577 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,560,3639,1212,3103,2105,3735,1071,2214,3102,560,1061,2619,514,536,1692,2696,3734,3734,2185,548,544,172,2059,1212,3750]

theorem envBound46577 : H12AffineFastState.Bounded env46577 := by
  intro p hp
  have h : env46577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46576_46577 : H12AffineEnvironment.transform 11 560 env46576 = env46577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 560 env46576 == env46577) = true)

theorem identity46577 : scanCanonicalize (H12AffineFastState.compose env46577 (packedSelected [1,2,6,7,8,9,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 1583) := by decide +kernel

theorem selectedBound46577 : packedSelected [1,2,6,7,8,9,12,15] rootPS < 2^1333 := by decide +kernel

def env46578 : List Nat := [2,4,8,16,32,16,128,173,512,1024,1583,560,24,1212,560,1558,184,1071,1673,561,560,1061,1044,514,536,1692,1191,185,185,1702,548,544,172,1572,1212,137]

theorem envBound46578 : H12AffineFastState.Bounded env46578 := by
  intro p hp
  have h : env46578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46577_46578 : H12AffineEnvironment.transform 10 1583 env46577 = env46578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1583 env46577 == env46578) = true)

theorem identity46578 : scanCanonicalize (H12AffineFastState.compose env46578 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(9+1) ^^^ 30) := by decide +kernel

theorem selectedBound46578 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env46579 : List Nat := [2,4,8,16,32,16,128,173,512,30,561,560,24,162,560,520,184,49,663,561,560,59,10,514,536,642,185,185,185,696,548,544,172,570,162,137]

theorem envBound46579 : H12AffineFastState.Bounded env46579 := by
  intro p hp
  have h : env46579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46578_46579 : H12AffineEnvironment.transform 9 30 env46578 = env46579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 30 env46578 == env46579) = true)

theorem identity46579 : scanCanonicalize (H12AffineFastState.compose env46579 (packedSelected [3,6,8] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound46579 : packedSelected [3,6,8] rootPS < 2^1333 := by decide +kernel

def env46580 : List Nat := [2,4,8,16,32,16,19,62,512,30,561,560,24,49,560,520,43,49,516,561,560,59,10,514,536,529,42,42,42,555,548,544,63,570,49,26]

theorem envBound46580 : H12AffineFastState.Bounded env46580 := by
  intro p hp
  have h : env46580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46579_46580 : H12AffineEnvironment.transform 6 19 env46579 = env46580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env46579 == env46580) = true)

theorem identity46580 : scanCanonicalize (H12AffineFastState.compose env46580 (packedSelected [1,3,6] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound46580 : packedSelected [1,3,6] rootPS < 2^1333 := by decide +kernel

def env46581 : List Nat := [2,4,8,10,32,10,9,36,512,4,555,554,2,43,554,520,43,43,516,555,554,33,10,514,514,523,42,42,42,555,548,544,37,544,43,0]

theorem envBound46581 : H12AffineFastState.Bounded env46581 := by
  intro p hp
  have h : env46581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46580_46581 : H12AffineEnvironment.transform 3 10 env46580 = env46581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env46580 == env46581) = true)

theorem identity46581 : scanCanonicalize (H12AffineFastState.compose env46581 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound46581 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46582 : List Nat := [2,4,8,10,32,10,9,36,1,4,42,43,2,43,43,9,43,43,5,42,43,33,10,3,3,10,42,42,42,42,37,33,37,33,43,0]

theorem envBound46582 : H12AffineFastState.Bounded env46582 := by
  intro p hp
  have h : env46582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46581_46582 : H12AffineEnvironment.transform 8 1 env46581 = env46582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env46581 == env46582) = true)

theorem identity46582 : scanCanonicalize (H12AffineFastState.compose env46582 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 15) := by decide +kernel

theorem selectedBound46582 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46583 : List Nat := [2,4,8,10,15,10,9,11,1,4,5,4,2,4,4,9,4,4,5,5,4,14,10,3,3,10,5,5,5,5,10,14,10,14,4,0]

theorem envBound46583 : H12AffineFastState.Bounded env46583 := by
  intro p hp
  have h : env46583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46582_46583 : H12AffineEnvironment.transform 4 15 env46582 = env46583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 15 env46582 == env46583) = true)

theorem identity46583 : scanCanonicalize (H12AffineFastState.compose env46583 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound46583 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46584 : List Nat := [2,4,4,6,3,6,5,7,1,4,5,4,2,4,4,5,4,4,5,5,4,2,6,3,3,6,5,5,5,5,6,2,6,2,4,0]

theorem envBound46584 : H12AffineFastState.Bounded env46584 := by
  intro p hp
  have h : env46584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46583_46584 : H12AffineEnvironment.transform 2 4 env46583 = env46584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env46583 == env46584) = true)

theorem identity46584 : scanCanonicalize (H12AffineFastState.compose env46584 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound46584 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env46585 : List Nat := [2,1,1,3,3,3,0,2,1,1,0,1,2,1,1,0,1,1,0,0,1,2,3,3,3,3,0,0,0,0,3,2,3,2,1,0]

theorem envBound46585 : H12AffineFastState.Bounded env46585 := by
  intro p hp
  have h : env46585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46584_46585 : H12AffineEnvironment.transform 1 1 env46584 = env46585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env46584 == env46585) = true)

theorem identity46585 : scanCanonicalize (H12AffineFastState.compose env46585 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound46585 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env46586 : List Nat := [0,1,1,1,1,1,0,0,1,1,0,1,0,1,1,0,1,1,0,0,1,0,1,1,1,1,0,0,0,0,1,0,1,0,1,0]

theorem envBound46586 : H12AffineFastState.Bounded env46586 := by
  intro p hp
  have h : env46586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46585_46586 : H12AffineEnvironment.transform 0 0 env46585 = env46586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env46585 == env46586) = true)

def env46587 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61568,147473,41002,143496,20496,492567,148668,148668,96266,74794,90258,172,204947,1213,135681]

theorem envBound46587 : H12AffineFastState.Bounded env46587 := by
  intro p hp
  have h : env46587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46569_46587 : H12AffineEnvironment.transform 5 17 env46569 = env46587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env46569 == env46587) = true)

theorem identity46587 : scanCanonicalize (H12AffineFastState.compose env46587 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 45216) := by decide +kernel

theorem selectedBound46587 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env46588 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,45216,262144,42145,32769,4096,61568,61617,41002,32808,20496,341175,62492,62492,96266,74794,90258,172,102451,1213,41633]

theorem envBound46588 : H12AffineFastState.Bounded env46588 := by
  intro p hp
  have h : env46588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46587_46588 : H12AffineEnvironment.transform 16 45216 env46587 = env46588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45216 env46587 == env46588) = true)

theorem identity46588 : scanCanonicalize (H12AffineFastState.compose env46588 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound46588 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env46589 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1212,32768,65536,45216,262144,42145,32769,4096,46140,46093,41002,32808,5292,341175,45216,45216,81078,74794,74798,172,102451,1213,41633]

theorem envBound46589 : H12AffineFastState.Bounded env46589 := by
  intro p hp
  have h : env46589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46588_46589 : H12AffineEnvironment.transform 13 1212 env46588 = env46589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env46588 == env46589) = true)

theorem identity46589 : scanCanonicalize (H12AffineFastState.compose env46589 (packedSelected [4,9,16] rootPS)) = affineNative (2^(14+1) ^^^ 9381) := by decide +kernel

theorem selectedBound46589 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env46590 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1212,9381,65536,5125,262144,4,9380,4096,4249,4264,1167,9357,5292,341175,5125,5125,81078,74794,74798,172,78998,1213,1540]

theorem envBound46590 : H12AffineFastState.Bounded env46590 := by
  intro p hp
  have h : env46590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46589_46590 : H12AffineEnvironment.transform 14 9381 env46589 = env46590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9381 env46589 == env46590) = true)

theorem identity46590 : scanCanonicalize (H12AffineFastState.compose env46590 (packedSelected [4,9,20] rootPS)) = affineNative (2^(15+1) ^^^ 12346) := by decide +kernel

theorem selectedBound46590 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env46591 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1212,9381,12346,5125,262144,4,9380,4096,4249,4264,1167,9357,5292,263309,5125,5125,3212,5136,5140,172,1196,1213,1540]

theorem envBound46591 : H12AffineFastState.Bounded env46591 := by
  intro p hp
  have h : env46591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46590_46591 : H12AffineEnvironment.transform 15 12346 env46590 = env46591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12346 env46590 == env46591) = true)

theorem identity46591 : scanCanonicalize (H12AffineFastState.compose env46591 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound46591 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env46592 : List Nat := [2,4,8,16,32,17,128,173,512,4,2048,4096,8192,184,8353,12346,4097,262144,4,8352,4096,4249,4264,139,8329,4264,262281,4097,4097,2184,4116,4112,172,168,185,512]

theorem envBound46592 : H12AffineFastState.Bounded env46592 := by
  intro p hp
  have h : env46592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46591_46592 : H12AffineEnvironment.transform 9 4 env46591 = env46592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env46591 == env46592) = true)

theorem identity46592 : scanCanonicalize (H12AffineFastState.compose env46592 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 2601) := by decide +kernel

theorem selectedBound46592 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46593 : List Nat := [2,4,8,16,32,17,128,173,512,4,2048,4096,2601,184,2696,6675,4097,262144,4,2697,4096,4249,4264,139,2720,4264,262281,4097,4097,2184,4116,4112,172,168,185,512]

theorem envBound46593 : H12AffineFastState.Bounded env46593 := by
  intro p hp
  have h : env46593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46592_46593 : H12AffineEnvironment.transform 12 2601 env46592 = env46593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2601 env46592 == env46593) = true)

theorem identity46593 : scanCanonicalize (H12AffineFastState.compose env46593 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 2706) := by decide +kernel

theorem selectedBound46593 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env46594 : List Nat := [2,4,8,16,32,17,128,173,512,4,2048,4096,2601,184,2696,6675,4097,2706,4,2697,4096,4249,4264,139,2720,4264,2587,4097,4097,2184,4116,4112,172,168,185,512]

theorem envBound46594 : H12AffineFastState.Bounded env46594 := by
  intro p hp
  have h : env46594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46593_46594 : H12AffineEnvironment.transform 17 2706 env46593 = env46594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2706 env46593 == env46594) = true)

theorem identity46594 : scanCanonicalize (H12AffineFastState.compose env46594 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 184) := by decide +kernel

theorem selectedBound46594 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env46595 : List Nat := [2,4,8,16,32,17,128,173,512,4,184,4096,657,184,560,4779,4097,554,4,561,4096,4249,4264,139,536,4264,675,4097,4097,48,4116,4112,172,168,185,512]

theorem envBound46595 : H12AffineFastState.Bounded env46595 := by
  intro p hp
  have h : env46595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46594_46595 : H12AffineEnvironment.transform 10 184 env46594 = env46595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 184 env46594 == env46595) = true)

theorem identity46595 : scanCanonicalize (H12AffineFastState.compose env46595 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound46595 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env46596 : List Nat := [2,4,8,16,32,17,128,173,0,4,184,4096,145,184,48,4267,4097,42,4,49,4096,4249,4264,139,24,4264,163,4097,4097,48,4116,4112,172,168,185,0]

theorem envBound46596 : H12AffineFastState.Bounded env46596 := by
  intro p hp
  have h : env46596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46595_46596 : H12AffineEnvironment.transform 8 0 env46595 = env46596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env46595 == env46596) = true)

theorem identity46596 : scanCanonicalize (H12AffineFastState.compose env46596 (packedSelected [3,4] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound46596 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env46597 : List Nat := [2,4,8,16,32,17,19,62,0,4,43,4096,2,43,48,4152,4097,42,4,49,4096,4106,4155,24,24,4155,48,4097,4097,48,4116,4112,63,59,42,0]

theorem envBound46597 : H12AffineFastState.Bounded env46597 := by
  intro p hp
  have h : env46597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46596_46597 : H12AffineEnvironment.transform 6 19 env46596 = env46597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env46596 == env46597) = true)

theorem identity46597 : scanCanonicalize (H12AffineFastState.compose env46597 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 48) := by decide +kernel

theorem selectedBound46597 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env46598 : List Nat := [2,4,8,16,32,17,19,62,0,4,43,48,2,43,48,8,49,42,4,49,48,58,11,24,24,11,48,49,49,48,36,32,63,59,42,0]

theorem envBound46598 : H12AffineFastState.Bounded env46598 := by
  intro p hp
  have h : env46598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46597_46598 : H12AffineEnvironment.transform 11 48 env46597 = env46598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env46597 == env46598) = true)

theorem identity46598 : scanCanonicalize (H12AffineFastState.compose env46598 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound46598 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46599 : List Nat := [2,4,5,16,32,17,19,51,0,4,38,48,2,38,48,5,49,39,4,49,48,55,6,21,21,6,48,49,49,48,36,32,50,54,39,0]

theorem envBound46599 : H12AffineFastState.Bounded env46599 := by
  intro p hp
  have h : env46599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46598_46599 : H12AffineEnvironment.transform 2 5 env46598 = env46599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env46598 == env46599) = true)

def env46600 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,16777216,33554432,672785,134217728,148800,33584584,96346,50962569,4294967296,34088328,4345352435,151462016,33563273]

theorem envBound46600 : H12AffineFastState.Bounded env46600 := by
  intro p hp
  have h : env46600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45453_46600 : H12AffineEnvironment.transform 20 4097 env45453 = env46600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env45453 == env46600) = true)

theorem identity46600 : scanCanonicalize (H12AffineFastState.compose env46600 (packedSelected [14] rootPS)) = affineNative (2^(31+1) ^^^ 184971574) := by decide +kernel

theorem selectedBound46600 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env46601 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,16777216,33554432,672785,134217728,148800,33584584,96346,50962569,184971574,34088328,134652357,151462016,33563273]

theorem envBound46601 : H12AffineFastState.Bounded env46601 := by
  intro p hp
  have h : env46601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46600_46601 : H12AffineEnvironment.transform 31 184971574 env46600 = env46601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 184971574 env46600 == env46601) = true)

def env46602 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,16777216,533640,672785,134217728,148800,545088,96346,16876545,151934398,256,134652357,151462016,525825]

theorem envBound46602 : H12AffineFastState.Bounded env46602 := by
  intro p hp
  have h : env46602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46601_46602 : H12AffineEnvironment.transform 24 533640 env46601 = env46602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 533640 env46601 == env46602) = true)

def env46603 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,16777216,533640,672785,17245632,148800,545088,96346,16876545,618622,256,16876549,1344,525825]

theorem envBound46603 : H12AffineFastState.Bounded env46603 := by
  intro p hp
  have h : env46603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46602_46603 : H12AffineEnvironment.transform 26 17245632 env46602 = env46603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245632 env46602 == env46603) = true)

theorem identity46603 : scanCanonicalize (H12AffineFastState.compose env46603 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(18+1) ^^^ 95614) := by decide +kernel

theorem selectedBound46603 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env46604 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95614,32769,4097,61648,147520,16777216,86518,209263,17245632,148800,74814,96346,16876545,1280,256,16876549,1344,95103]

theorem envBound46604 : H12AffineFastState.Bounded env46604 := by
  intro p hp
  have h : env46604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46603_46604 : H12AffineEnvironment.transform 18 95614 env46603 = env46604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 95614 env46603 == env46604) = true)

def env46605 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95614,32769,4097,61648,147520,284032,86518,209263,225344,148800,74814,96346,381313,1280,256,381317,1344,95103]

theorem envBound46605 : H12AffineFastState.Bounded env46605 := by
  intro p hp
  have h : env46605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46604_46605 : H12AffineEnvironment.transform 23 284032 env46604 = env46605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 284032 env46604 == env46605) = true)

def env46606 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16464,262144,95614,32769,4097,61648,16,284032,86518,94527,77840,1296,74814,96346,381313,1280,256,381317,1344,95103]

theorem envBound46606 : H12AffineFastState.Bounded env46606 := by
  intro p hp
  have h : env46606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46605_46606 : H12AffineEnvironment.transform 16 16464 env46605 = env46606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16464 env46605 == env46606) = true)

def env46607 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1344,262144,77934,32769,4097,46528,16,266384,70886,78895,77840,1296,74814,81226,365713,1280,256,365717,1344,79471]

theorem envBound46607 : H12AffineFastState.Bounded env46607 := by
  intro p hp
  have h : env46607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46606_46607 : H12AffineEnvironment.transform 13 1296 env46606 = env46607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env46606 == env46607) = true)

theorem identity46607 : scanCanonicalize (H12AffineFastState.compose env46607 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound46607 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env46608 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1344,262144,77934,13340,4097,477,16,266384,70886,78895,77840,1296,74814,81226,336012,1280,256,336008,1344,79471]

theorem envBound46608 : H12AffineFastState.Bounded env46608 := by
  intro p hp
  have h : env46608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46607_46608 : H12AffineEnvironment.transform 14 13341 env46607 = env46608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env46607 == env46608) = true)

def env46609 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1344,65664,77934,13340,4097,477,16,69648,70886,78895,77840,1296,74814,81226,8204,1280,256,8200,1344,79471]

theorem envBound46609 : H12AffineFastState.Bounded env46609 := by
  intro p hp
  have h : env46609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46608_46609 : H12AffineEnvironment.transform 17 65664 env46608 = env46609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env46608 == env46609) = true)

theorem identity46609 : scanCanonicalize (H12AffineFastState.compose env46609 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 358) := by decide +kernel

theorem selectedBound46609 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env46610 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,358,1344,486,12552,13340,4097,477,16,4470,5504,13641,12662,1296,9560,15404,8204,1280,256,8200,1344,14089]

theorem envBound46610 : H12AffineFastState.Bounded env46610 := by
  intro p hp
  have h : env46610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46609_46610 : H12AffineEnvironment.transform 15 358 env46609 = env46610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 358 env46609 == env46610) = true)

def env46611 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,7632,1296,2509,358,1344,486,3288,2508,4097,477,16,4470,5504,2201,3238,1296,6280,508,7644,1280,256,7640,1344,2777]

theorem envBound46611 : H12AffineFastState.Bounded env46611 := by
  intro p hp
  have h : env46611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46610_46611 : H12AffineEnvironment.transform 12 7632 env46610 = env46611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7632 env46610 == env46611) = true)

def env46612 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1344,4096,4240,1296,1165,358,1344,486,408,1164,4097,477,16,4470,5504,1497,486,1296,5576,508,4252,1280,256,4248,1344,1945]

theorem envBound46612 : H12AffineFastState.Bounded env46612 := by
  intro p hp
  have h : env46612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46611_46612 : H12AffineEnvironment.transform 10 1344 env46611 = env46612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1344 env46611 == env46612) = true)

theorem identity46612 : scanCanonicalize (H12AffineFastState.compose env46612 (packedSelected [13] rootPS)) = affineNative (2^(9+1) ^^^ 140) := by decide +kernel

theorem selectedBound46612 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env46613 : List Nat := [2,4,8,16,32,64,128,256,512,140,460,4096,4240,412,1,358,460,486,408,0,4097,477,16,4470,4364,341,486,412,4420,508,4252,396,256,4248,460,789]

theorem envBound46613 : H12AffineFastState.Bounded env46613 := by
  intro p hp
  have h : env46613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46612_46613 : H12AffineEnvironment.transform 9 140 env46612 = env46613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 140 env46612 == env46613) = true)

theorem identity46613 : scanCanonicalize (H12AffineFastState.compose env46613 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 157) := by decide +kernel

theorem selectedBound46613 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env46614 : List Nat := [2,4,8,16,32,64,128,157,512,140,81,4096,4240,1,1,251,81,123,5,0,4097,64,16,4331,4241,200,123,1,4313,97,4252,17,157,4248,81,648]

theorem envBound46614 : H12AffineFastState.Bounded env46614 := by
  intro p hp
  have h : env46614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46613_46614 : H12AffineEnvironment.transform 7 157 env46613 = env46614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 157 env46613 == env46614) = true)

theorem identity46614 : scanCanonicalize (H12AffineFastState.compose env46614 (packedSelected [15,18] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound46614 : packedSelected [15,18] rootPS < 2^1333 := by decide +kernel

def env46615 : List Nat := [2,4,8,16,11,64,128,157,512,140,81,4096,4240,1,1,208,81,80,5,0,4097,64,16,4288,4241,200,80,1,4313,74,4252,17,157,4248,81,648]

theorem envBound46615 : H12AffineFastState.Bounded env46615 := by
  intro p hp
  have h : env46615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46614_46615 : H12AffineEnvironment.transform 4 11 env46614 = env46615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env46614 == env46615) = true)

theorem identity46615 : scanCanonicalize (H12AffineFastState.compose env46615 (packedSelected [1,3,7,9,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 728) := by decide +kernel

theorem selectedBound46615 : packedSelected [1,3,7,9,10,12] rootPS < 2^1333 := by decide +kernel

def env46616 : List Nat := [2,4,8,16,11,64,128,157,512,140,81,728,584,1,1,208,81,80,5,0,729,64,16,536,585,200,80,1,513,74,580,17,157,576,81,648]

theorem envBound46616 : H12AffineFastState.Bounded env46616 := by
  intro p hp
  have h : env46616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46615_46616 : H12AffineEnvironment.transform 11 728 env46615 = env46616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 728 env46615 == env46616) = true)

theorem identity46616 : scanCanonicalize (H12AffineFastState.compose env46616 (packedSelected [0,2,3,5,9,10] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound46616 : packedSelected [0,2,3,5,9,10] rootPS < 2^1333 := by decide +kernel

def env46617 : List Nat := [2,4,8,16,11,64,128,157,0,140,81,216,72,1,1,208,81,80,5,0,217,64,16,24,73,200,80,1,1,74,68,17,157,64,81,136]

theorem envBound46617 : H12AffineFastState.Bounded env46617 := by
  intro p hp
  have h : env46617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46616_46617 : H12AffineEnvironment.transform 8 0 env46616 = env46617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env46616 == env46617) = true)

def env46618 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1345,4096,4241,1296,1164,358,1344,486,409,1165,4097,477,16,4470,5504,1496,487,1296,5577,508,4253,1280,256,4249,1344,1944]

theorem envBound46618 : H12AffineFastState.Bounded env46618 := by
  intro p hp
  have h : env46618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46611_46618 : H12AffineEnvironment.transform 10 1345 env46611 = env46618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1345 env46611 == env46618) = true)

theorem identity46618 : scanCanonicalize (H12AffineFastState.compose env46618 (packedSelected [13] rootPS)) = affineNative (2^(7+1) ^^^ 156) := by decide +kernel

theorem selectedBound46618 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env46619 : List Nat := [2,4,8,16,32,64,128,156,512,1024,1245,4096,4241,1164,1164,250,1244,122,5,1165,4097,65,16,4330,5148,1092,123,1164,5205,96,4253,1180,156,4249,1244,1540]

theorem envBound46619 : H12AffineFastState.Bounded env46619 := by
  intro p hp
  have h : env46619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46618_46619 : H12AffineEnvironment.transform 7 156 env46618 = env46619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 156 env46618 == env46619) = true)

theorem identity46619 : scanCanonicalize (H12AffineFastState.compose env46619 (packedSelected [2,11,15,17,20,21] rootPS)) = affineNative (2^(11+1) ^^^ 1663) := by decide +kernel

theorem selectedBound46619 : packedSelected [2,11,15,17,20,21] rootPS < 2^1333 := by decide +kernel

def env46620 : List Nat := [2,4,8,16,32,64,128,156,512,1024,1245,1663,1774,1164,1164,250,1244,122,5,1165,1662,65,16,1685,611,1092,123,1164,554,96,1762,1180,156,1766,1244,1540]

theorem envBound46620 : H12AffineFastState.Bounded env46620 := by
  intro p hp
  have h : env46620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46619_46620 : H12AffineEnvironment.transform 11 1663 env46619 = env46620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1663 env46619 == env46620) = true)

theorem identity46620 : scanCanonicalize (H12AffineFastState.compose env46620 (packedSelected [0,2,4,10,11,12,15,19] rootPS)) = affineNative (2^(6+1) ^^^ 104) := by decide +kernel

theorem selectedBound46620 : packedSelected [0,2,4,10,11,12,15,19] rootPS < 2^1333 := by decide +kernel

def env46621 : List Nat := [2,4,8,16,32,64,104,116,512,1024,1077,1663,1542,1124,1124,18,1076,122,5,1125,1662,65,16,1661,611,1092,123,1124,554,96,1546,1140,116,1550,1076,1540]

theorem envBound46621 : H12AffineFastState.Bounded env46621 := by
  intro p hp
  have h : env46621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46620_46621 : H12AffineEnvironment.transform 6 104 env46620 = env46621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 104 env46620 == env46621) = true)

theorem identity46621 : scanCanonicalize (H12AffineFastState.compose env46621 (packedSelected [2,3,4,8,9,11,12] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound46621 : packedSelected [2,3,4,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env46622 : List Nat := [2,4,8,16,32,64,104,116,42,1024,1077,1109,1068,1124,1124,18,1076,122,5,1125,1108,65,16,1111,73,1092,123,1124,0,96,1056,1140,116,1060,1076,1070]

theorem envBound46622 : H12AffineFastState.Bounded env46622 := by
  intro p hp
  have h : env46622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46621_46622 : H12AffineEnvironment.transform 8 42 env46621 = env46622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env46621 == env46622) = true)

theorem identity46622 : scanCanonicalize (H12AffineFastState.compose env46622 (packedSelected [1,2,8] rootPS)) = affineNative (2^(9+1) ^^^ 46) := by decide +kernel

theorem selectedBound46622 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env46623 : List Nat := [2,4,8,16,32,64,104,116,42,46,27,123,2,74,74,18,26,122,5,75,122,65,16,121,73,106,123,74,0,96,14,90,116,10,26,0]

theorem envBound46623 : H12AffineFastState.Bounded env46623 := by
  intro p hp
  have h : env46623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46622_46623 : H12AffineEnvironment.transform 9 46 env46622 = env46623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 46 env46622 == env46623) = true)

theorem identity46623 : scanCanonicalize (H12AffineFastState.compose env46623 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound46623 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env46624 : List Nat := [2,4,8,16,32,59,19,15,42,46,27,0,2,49,49,18,26,1,5,48,1,58,16,2,50,17,0,49,0,27,14,33,15,10,26,0]

theorem envBound46624 : H12AffineFastState.Bounded env46624 := by
  intro p hp
  have h : env46624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46623_46624 : H12AffineEnvironment.transform 5 59 env46623 = env46624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env46623 == env46624) = true)

theorem identity46624 : scanCanonicalize (H12AffineFastState.compose env46624 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound46624 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env46625 : List Nat := [2,4,8,16,17,10,19,15,27,31,27,0,2,0,0,18,26,1,5,1,1,11,16,2,3,17,0,0,0,27,14,16,15,10,26,0]

theorem envBound46625 : H12AffineFastState.Bounded env46625 := by
  intro p hp
  have h : env46625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46624_46625 : H12AffineEnvironment.transform 4 17 env46624 = env46625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env46624 == env46625) = true)

theorem identity46625 : scanCanonicalize (H12AffineFastState.compose env46625 (packedSelected [0,1,4] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound46625 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env46626 : List Nat := [2,4,8,12,13,10,15,15,7,3,7,0,2,0,0,14,6,1,5,1,1,11,12,2,3,13,0,0,0,7,14,12,15,10,6,0]

theorem envBound46626 : H12AffineFastState.Bounded env46626 := by
  intro p hp
  have h : env46626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46625_46626 : H12AffineEnvironment.transform 3 12 env46625 = env46626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env46625 == env46626) = true)

theorem identity46626 : scanCanonicalize (H12AffineFastState.compose env46626 (packedSelected [1,10] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound46626 : packedSelected [1,10] rootPS < 2^1333 := by decide +kernel

def env46627 : List Nat := [2,2,8,10,11,10,9,9,1,3,1,0,2,0,0,8,0,1,3,1,1,11,10,2,3,11,0,0,0,1,8,10,9,10,0,0]

theorem envBound46627 : H12AffineFastState.Bounded env46627 := by
  intro p hp
  have h : env46627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46626_46627 : H12AffineEnvironment.transform 1 2 env46626 = env46627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env46626 == env46627) = true)

theorem identity46627 : scanCanonicalize (H12AffineFastState.compose env46627 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound46627 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46628 : List Nat := [0,0,8,8,9,8,9,9,1,1,1,0,0,0,0,8,0,1,1,1,1,9,8,0,1,9,0,0,0,1,8,8,9,8,0,0]

theorem envBound46628 : H12AffineFastState.Bounded env46628 := by
  intro p hp
  have h : env46628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46627_46628 : H12AffineEnvironment.transform 0 0 env46627 = env46628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env46627 == env46628) = true)

theorem identity46628 : scanCanonicalize (H12AffineFastState.compose env46628 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound46628 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46629 : List Nat := [0,0,1,1,0,1,0,0,1,1,1,0,0,0,0,1,0,1,1,1,1,0,1,0,1,0,0,0,0,1,1,1,0,1,0,0]

theorem envBound46629 : H12AffineFastState.Bounded env46629 := by
  intro p hp
  have h : env46629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46628_46629 : H12AffineEnvironment.transform 2 1 env46628 = env46629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env46628 == env46629) = true)

def env46630 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,7633,1296,2508,358,1344,486,3289,2509,4097,477,16,4470,5504,2200,3239,1296,6281,509,7645,1280,256,7641,1344,2776]

theorem envBound46630 : H12AffineFastState.Bounded env46630 := by
  intro p hp
  have h : env46630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46610_46630 : H12AffineEnvironment.transform 12 7633 env46610 = env46630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7633 env46610 == env46630) = true)

def env46631 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1344,4096,4241,1296,1164,358,1344,486,409,1165,4097,477,16,4470,5504,1496,487,1296,5577,509,4253,1280,256,4249,1344,1944]

theorem envBound46631 : H12AffineFastState.Bounded env46631 := by
  intro p hp
  have h : env46631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46630_46631 : H12AffineEnvironment.transform 10 1344 env46630 = env46631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1344 env46630 == env46631) = true)

theorem identity46631 : scanCanonicalize (H12AffineFastState.compose env46631 (packedSelected [13] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound46631 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env46632 : List Nat := [2,4,8,16,32,64,128,256,512,4,324,4096,4241,276,136,358,324,486,409,137,4097,477,16,4470,4484,476,487,276,4557,509,4253,260,256,4249,324,924]

theorem envBound46632 : H12AffineFastState.Bounded env46632 := by
  intro p hp
  have h : env46632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46631_46632 : H12AffineEnvironment.transform 9 4 env46631 = env46632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env46631 == env46632) = true)

theorem identity46632 : scanCanonicalize (H12AffineFastState.compose env46632 (packedSelected [1,2,4,7,15,19,20,21,24] rootPS)) = affineNative (2^(11+1) ^^^ 136) := by decide +kernel

theorem selectedBound46632 : packedSelected [1,2,4,7,15,19,20,21,24] rootPS < 2^1333 := by decide +kernel

def env46633 : List Nat := [2,4,8,16,32,64,128,256,512,4,324,136,25,276,136,358,324,486,409,137,137,477,16,510,268,476,487,276,325,509,21,260,256,17,324,924]

theorem envBound46633 : H12AffineFastState.Bounded env46633 := by
  intro p hp
  have h : env46633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46632_46633 : H12AffineEnvironment.transform 11 136 env46632 = env46633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 136 env46632 == env46633) = true)

theorem identity46633 : scanCanonicalize (H12AffineFastState.compose env46633 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(8+1) ^^^ 324) := by decide +kernel

theorem selectedBound46633 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env46634 : List Nat := [2,4,8,16,32,64,128,256,324,4,324,136,25,276,136,358,324,486,409,137,137,477,16,510,268,476,487,276,325,509,21,260,256,17,324,216]

theorem envBound46634 : H12AffineFastState.Bounded env46634 := by
  intro p hp
  have h : env46634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46633_46634 : H12AffineEnvironment.transform 8 324 env46633 = env46634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 324 env46633 == env46634) = true)

theorem identity46634 : scanCanonicalize (H12AffineFastState.compose env46634 (packedSelected [4,9,11,15,16] rootPS)) = affineNative (2^(6+1) ^^^ 66) := by decide +kernel

theorem selectedBound46634 : packedSelected [4,9,11,15,16] rootPS < 2^1333 := by decide +kernel

def env46635 : List Nat := [2,4,8,16,32,64,66,256,324,4,324,74,25,276,74,358,324,292,347,75,75,287,16,316,268,286,293,276,325,319,21,260,256,17,324,26]

theorem envBound46635 : H12AffineFastState.Bounded env46635 := by
  intro p hp
  have h : env46635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46634_46635 : H12AffineEnvironment.transform 6 66 env46634 = env46635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 66 env46634 == env46635) = true)

theorem identity46635 : scanCanonicalize (H12AffineFastState.compose env46635 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound46635 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env46636 : List Nat := [2,4,8,16,32,64,66,68,0,4,0,74,25,80,74,34,0,96,31,75,75,91,16,120,72,90,97,80,1,123,21,64,68,17,0,26]

theorem envBound46636 : H12AffineFastState.Bounded env46636 := by
  intro p hp
  have h : env46636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46635_46636 : H12AffineEnvironment.transform 7 68 env46635 = env46636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env46635 == env46636) = true)

theorem identity46636 : scanCanonicalize (H12AffineFastState.compose env46636 (packedSelected [1,2,5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound46636 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env46637 : List Nat := [2,4,8,16,17,64,66,68,0,4,0,74,25,80,74,19,0,81,31,75,75,91,16,73,72,90,80,80,1,74,21,64,68,17,0,26]

theorem envBound46637 : H12AffineFastState.Bounded env46637 := by
  intro p hp
  have h : env46637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46636_46637 : H12AffineEnvironment.transform 4 17 env46636 = env46637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env46636 == env46637) = true)

def env46638 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1345,4096,4240,1296,1165,358,1344,486,408,1164,4097,477,16,4470,5504,1497,486,1296,5576,509,4252,1280,256,4248,1344,1945]

theorem envBound46638 : H12AffineFastState.Bounded env46638 := by
  intro p hp
  have h : env46638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46630_46638 : H12AffineEnvironment.transform 10 1345 env46630 = env46638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1345 env46630 == env46638) = true)

theorem identity46638 : scanCanonicalize (H12AffineFastState.compose env46638 (packedSelected [13] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound46638 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env46639 : List Nat := [2,4,8,16,32,64,128,21,512,1024,1108,4096,4240,1029,1165,115,1109,243,141,1164,4097,200,16,4195,5269,1228,243,1029,5341,232,4252,1045,21,4248,1109,1676]

theorem envBound46639 : H12AffineFastState.Bounded env46639 := by
  intro p hp
  have h : env46639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46638_46639 : H12AffineEnvironment.transform 7 21 env46638 = env46639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env46638 == env46639) = true)

theorem identity46639 : scanCanonicalize (H12AffineFastState.compose env46639 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound46639 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env46640 : List Nat := [2,4,8,16,32,64,9,21,512,1024,1108,4096,4121,1029,1028,115,1109,122,4,1029,4097,65,16,4195,5148,1093,122,1029,5204,97,4117,1045,21,4113,1109,1541]

theorem envBound46640 : H12AffineFastState.Bounded env46640 := by
  intro p hp
  have h : env46640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46639_46640 : H12AffineEnvironment.transform 6 9 env46639 = env46640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env46639 == env46640) = true)

theorem identity46640 : scanCanonicalize (H12AffineFastState.compose env46640 (packedSelected [0,2,4,5,8,10] rootPS)) = affineNative (2^(9+1) ^^^ 85) := by decide +kernel

theorem selectedBound46640 : packedSelected [0,2,4,5,8,10] rootPS < 2^1333 := by decide +kernel

def env46641 : List Nat := [2,4,8,16,32,64,9,21,512,85,1,4096,4121,80,81,115,0,122,4,80,4097,65,16,4195,4169,16,122,80,4097,97,4117,64,21,4113,0,592]

theorem envBound46641 : H12AffineFastState.Bounded env46641 := by
  intro p hp
  have h : env46641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46640_46641 : H12AffineEnvironment.transform 9 85 env46640 = env46641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env46640 == env46641) = true)

theorem identity46641 : scanCanonicalize (H12AffineFastState.compose env46641 (packedSelected [2,3,4,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 74) := by decide +kernel

theorem selectedBound46641 : packedSelected [2,3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env46642 : List Nat := [2,4,8,16,32,64,9,21,512,85,1,74,83,80,81,115,0,122,4,80,75,65,16,41,3,16,122,80,75,97,95,64,21,91,0,592]

theorem envBound46642 : H12AffineFastState.Bounded env46642 := by
  intro p hp
  have h : env46642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46641_46642 : H12AffineEnvironment.transform 11 74 env46641 = env46642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 74 env46641 == env46642) = true)

theorem identity46642 : scanCanonicalize (H12AffineFastState.compose env46642 (packedSelected [0,1,2,4,5,12] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound46642 : packedSelected [0,1,2,4,5,12] rootPS < 2^1333 := by decide +kernel

def env46643 : List Nat := [2,4,8,10,32,64,9,15,512,79,1,74,73,74,75,105,0,96,4,74,75,65,10,41,3,10,96,74,75,97,69,64,15,65,0,586]

theorem envBound46643 : H12AffineFastState.Bounded env46643 := by
  intro p hp
  have h : env46643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46642_46643 : H12AffineEnvironment.transform 3 10 env46642 = env46643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env46642 == env46643) = true)

theorem identity46643 : scanCanonicalize (H12AffineFastState.compose env46643 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound46643 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46644 : List Nat := [2,4,8,10,32,64,9,15,1,79,1,74,73,74,75,105,0,96,4,74,75,65,10,41,3,10,96,74,75,97,69,64,15,65,0,75]

theorem envBound46644 : H12AffineFastState.Bounded env46644 := by
  intro p hp
  have h : env46644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46643_46644 : H12AffineEnvironment.transform 8 1 env46643 = env46644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env46643 == env46644) = true)

theorem identity46644 : scanCanonicalize (H12AffineFastState.compose env46644 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 13) := by decide +kernel

theorem selectedBound46644 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env46645 : List Nat := [2,4,8,10,32,13,9,15,1,2,1,7,4,7,6,36,0,45,4,7,6,12,10,41,3,10,45,7,6,44,8,13,15,12,0,6]

theorem envBound46645 : H12AffineFastState.Bounded env46645 := by
  intro p hp
  have h : env46645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46644_46645 : H12AffineEnvironment.transform 5 13 env46644 = env46645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 13 env46644 == env46645) = true)

theorem identity46645 : scanCanonicalize (H12AffineFastState.compose env46645 (packedSelected [5] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound46645 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env46646 : List Nat := [2,3,8,10,32,10,9,8,1,2,1,0,3,0,1,35,0,42,3,0,1,11,10,41,3,10,42,0,1,43,8,10,8,11,0,1]

theorem envBound46646 : H12AffineFastState.Bounded env46646 := by
  intro p hp
  have h : env46646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46645_46646 : H12AffineEnvironment.transform 1 3 env46645 = env46646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env46645 == env46646) = true)

theorem identity46646 : scanCanonicalize (H12AffineFastState.compose env46646 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound46646 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46647 : List Nat := [2,3,8,10,11,10,9,8,1,2,1,0,3,0,1,8,0,1,3,0,1,11,10,2,3,10,1,0,1,0,8,10,8,11,0,1]

theorem envBound46647 : H12AffineFastState.Bounded env46647 := by
  intro p hp
  have h : env46647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46646_46647 : H12AffineEnvironment.transform 4 11 env46646 = env46647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env46646 == env46647) = true)

def env46648 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1344,65665,77934,13340,4097,477,16,69649,70886,78895,77840,1296,74814,81226,8205,1280,256,8201,1344,79471]

theorem envBound46648 : H12AffineFastState.Bounded env46648 := by
  intro p hp
  have h : env46648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46608_46648 : H12AffineEnvironment.transform 17 65665 env46608 = env46648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env46608 == env46648) = true)

theorem identity46648 : scanCanonicalize (H12AffineFastState.compose env46648 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5158) := by decide +kernel

theorem selectedBound46648 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env46649 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,5158,1344,5287,9288,13340,4097,477,16,1079,192,8201,9270,1296,12312,10604,8205,1280,256,8201,1344,8777]

theorem envBound46649 : H12AffineFastState.Bounded env46649 := by
  intro p hp
  have h : env46649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46648_46649 : H12AffineEnvironment.transform 15 5158 env46648 = env46649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5158 env46648 == env46649) = true)

def env46650 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,1296,13341,5158,1296,5287,9240,13340,4097,397,16,1079,144,8201,9270,1296,12312,10556,8205,1280,256,8201,1296,8729]

theorem envBound46650 : H12AffineFastState.Bounded env46650 := by
  intro p hp
  have h : env46650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46649_46650 : H12AffineEnvironment.transform 5 16 env46649 = env46650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env46649 == env46650) = true)

theorem identity46650 : scanCanonicalize (H12AffineFastState.compose env46650 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound46650 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env46651 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1029,8192,1296,8216,35,1296,162,9240,8217,1028,397,16,1079,144,8201,9270,1296,9245,10556,8205,1280,256,8201,1296,8729]

theorem envBound46651 : H12AffineFastState.Bounded env46651 := by
  intro p hp
  have h : env46651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46650_46651 : H12AffineEnvironment.transform 11 1029 env46650 = env46651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env46650 == env46651) = true)

theorem identity46651 : scanCanonicalize (H12AffineFastState.compose env46651 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound46651 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env46652 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1029,269,1296,277,35,1296,162,1301,276,1028,397,16,1079,144,260,1339,1296,1296,2097,256,1280,256,260,1296,788]

theorem envBound46652 : H12AffineFastState.Bounded env46652 := by
  intro p hp
  have h : env46652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46651_46652 : H12AffineEnvironment.transform 12 269 env46651 = env46652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env46651 == env46652) = true)

theorem identity46652 : scanCanonicalize (H12AffineFastState.compose env46652 (packedSelected [0,1,2,5,7,10,11,19] rootPS)) = affineNative (2^(7+1) ^^^ 62) := by decide +kernel

theorem selectedBound46652 : packedSelected [0,1,2,5,7,10,11,19] rootPS < 2^1333 := by decide +kernel

def env46653 : List Nat := [2,4,8,16,32,16,128,62,512,1024,2048,1029,51,1070,43,35,1070,162,1067,42,1028,179,16,1079,144,58,1029,1070,1070,2097,62,1086,62,58,1070,554]

theorem envBound46653 : H12AffineFastState.Bounded env46653 := by
  intro p hp
  have h : env46653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46652_46653 : H12AffineEnvironment.transform 7 62 env46652 = env46653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 62 env46652 == env46653) = true)

theorem identity46653 : scanCanonicalize (H12AffineFastState.compose env46653 (packedSelected [3,5,10,12,17] rootPS)) = affineNative (2^(9+1) ^^^ 188) := by decide +kernel

theorem selectedBound46653 : packedSelected [3,5,10,12,17] rootPS < 2^1333 := by decide +kernel

def env46654 : List Nat := [2,4,8,16,32,16,128,62,512,188,2048,185,51,146,43,35,146,162,151,42,184,179,16,139,144,58,185,146,146,2097,62,130,62,58,146,554]

theorem envBound46654 : H12AffineFastState.Bounded env46654 := by
  intro p hp
  have h : env46654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46653_46654 : H12AffineEnvironment.transform 9 188 env46653 = env46654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 188 env46653 == env46654) = true)

theorem identity46654 : scanCanonicalize (H12AffineFastState.compose env46654 (packedSelected [2,3,7,8,9] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound46654 : packedSelected [2,3,7,8,9] rootPS < 2^1333 := by decide +kernel

def env46655 : List Nat := [2,4,8,10,32,10,128,36,512,166,2048,163,41,136,43,35,136,162,141,42,162,169,10,139,138,32,163,136,136,2091,36,130,36,32,136,554]

theorem envBound46655 : H12AffineFastState.Bounded env46655 := by
  intro p hp
  have h : env46655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46654_46655 : H12AffineEnvironment.transform 3 10 env46654 = env46655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env46654 == env46655) = true)

theorem identity46655 : scanCanonicalize (H12AffineFastState.compose env46655 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 649) := by decide +kernel

theorem selectedBound46655 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env46656 : List Nat := [2,4,8,10,32,10,128,36,512,166,649,163,41,136,43,35,136,162,141,42,162,169,10,139,138,32,163,136,136,674,36,130,36,32,136,554]

theorem envBound46656 : H12AffineFastState.Bounded env46656 := by
  intro p hp
  have h : env46656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46655_46656 : H12AffineEnvironment.transform 10 649 env46655 = env46656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 649 env46655 == env46656) = true)

theorem identity46656 : scanCanonicalize (H12AffineFastState.compose env46656 (packedSelected [1,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound46656 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env46657 : List Nat := [2,4,8,10,32,10,128,36,1,166,136,163,41,136,43,35,136,162,141,42,162,169,10,139,138,32,163,136,136,163,36,130,36,32,136,43]

theorem envBound46657 : H12AffineFastState.Bounded env46657 := by
  intro p hp
  have h : env46657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46656_46657 : H12AffineEnvironment.transform 8 1 env46656 = env46657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env46656 == env46657) = true)

theorem identity46657 : scanCanonicalize (H12AffineFastState.compose env46657 (packedSelected [1,5] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound46657 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env46658 : List Nat := [2,4,8,10,32,10,35,36,1,5,43,0,41,43,43,35,43,1,46,42,1,10,10,40,41,32,0,43,43,0,36,33,36,32,43,43]

theorem envBound46658 : H12AffineFastState.Bounded env46658 := by
  intro p hp
  have h : env46658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46657_46658 : H12AffineEnvironment.transform 6 35 env46657 = env46658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env46657 == env46658) = true)

theorem identity46658 : scanCanonicalize (H12AffineFastState.compose env46658 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound46658 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46659 : List Nat := [2,2,8,10,32,10,35,34,1,3,43,0,41,43,43,35,43,1,40,42,1,10,10,40,41,32,0,43,43,0,34,33,34,32,43,43]

theorem envBound46659 : H12AffineFastState.Bounded env46659 := by
  intro p hp
  have h : env46659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46658_46659 : H12AffineEnvironment.transform 1 2 env46658 = env46659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env46658 == env46659) = true)

theorem identity46659 : scanCanonicalize (H12AffineFastState.compose env46659 (packedSelected [8] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound46659 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env46660 : List Nat := [2,2,8,10,10,10,9,8,1,3,1,0,3,1,1,9,1,1,2,0,1,10,10,2,3,10,0,1,1,0,8,11,8,10,1,1]

theorem envBound46660 : H12AffineFastState.Bounded env46660 := by
  intro p hp
  have h : env46660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46659_46660 : H12AffineEnvironment.transform 4 10 env46659 = env46660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env46659 == env46660) = true)

def env46661 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,1296,13341,5158,1297,5287,9241,13340,4097,396,16,1079,145,8201,9270,1296,12312,10557,8205,1280,256,8201,1297,8728]

theorem envBound46661 : H12AffineFastState.Bounded env46661 := by
  intro p hp
  have h : env46661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46649_46661 : H12AffineEnvironment.transform 5 17 env46649 = env46661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env46649 == env46661) = true)

theorem identity46661 : scanCanonicalize (H12AffineFastState.compose env46661 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 5148) := by decide +kernel

theorem selectedBound46661 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env46662 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,5148,1296,1,5158,1297,5287,4101,0,4097,396,16,1079,145,5141,4138,1296,1028,7457,5137,1280,256,5141,1297,5636]

theorem envBound46662 : H12AffineFastState.Bounded env46662 := by
  intro p hp
  have h : env46662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46661_46662 : H12AffineEnvironment.transform 12 5148 env46661 = env46662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5148 env46661 == env46662) = true)

theorem identity46662 : scanCanonicalize (H12AffineFastState.compose env46662 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound46662 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env46663 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,269,1296,1,311,1297,438,1300,0,1296,396,16,1079,145,260,1339,1296,1028,2096,256,1280,256,260,1297,789]

theorem envBound46663 : H12AffineFastState.Bounded env46663 := by
  intro p hp
  have h : env46663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46662_46663 : H12AffineEnvironment.transform 11 1297 env46662 = env46663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env46662 == env46663) = true)

theorem identity46663 : scanCanonicalize (H12AffineFastState.compose env46663 (packedSelected [0,2,7,10,12,13,15,18,19] rootPS)) = affineNative (2^(10+1) ^^^ 951) := by decide +kernel

theorem selectedBound46663 : packedSelected [0,2,7,10,12,13,15,18,19] rootPS < 2^1333 := by decide +kernel

def env46664 : List Nat := [2,4,8,16,32,17,128,256,512,1024,951,1297,269,1296,1,311,1297,438,1300,0,1296,396,16,1079,145,260,1339,1296,1028,903,256,1280,256,260,1297,789]

theorem envBound46664 : H12AffineFastState.Bounded env46664 := by
  intro p hp
  have h : env46664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46663_46664 : H12AffineEnvironment.transform 10 951 env46663 = env46664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 951 env46663 == env46664) = true)

theorem identity46664 : scanCanonicalize (H12AffineFastState.compose env46664 (packedSelected [0,1,5,7,18] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound46664 : packedSelected [0,1,5,7,18] rootPS < 2^1333 := by decide +kernel

def env46665 : List Nat := [2,4,8,16,32,17,128,172,512,1024,539,1213,161,1212,1,155,1213,26,1208,0,1212,32,16,1079,145,168,1175,1212,1028,555,172,1196,172,168,1213,697]

theorem envBound46665 : H12AffineFastState.Bounded env46665 := by
  intro p hp
  have h : env46665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46664_46665 : H12AffineEnvironment.transform 7 172 env46664 = env46665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env46664 == env46665) = true)

theorem identity46665 : scanCanonicalize (H12AffineFastState.compose env46665 (packedSelected [1,4,8,9,10,11] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound46665 : packedSelected [1,4,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env46666 : List Nat := [2,4,8,16,32,17,56,20,512,1024,539,1029,25,1028,1,35,1029,26,1024,0,1028,32,16,1079,41,16,1071,1028,1028,555,20,1044,20,16,1029,513]

theorem envBound46666 : H12AffineFastState.Bounded env46666 := by
  intro p hp
  have h : env46666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46665_46666 : H12AffineEnvironment.transform 6 56 env46665 = env46666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env46665 == env46666) = true)

theorem identity46666 : scanCanonicalize (H12AffineFastState.compose env46666 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound46666 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46667 : List Nat := [2,4,8,16,32,17,56,20,512,517,539,512,25,513,1,35,512,26,517,0,513,32,16,562,41,16,554,513,513,555,20,529,20,16,512,513]

theorem envBound46667 : H12AffineFastState.Bounded env46667 := by
  intro p hp
  have h : env46667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46666_46667 : H12AffineEnvironment.transform 9 517 env46666 = env46667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env46666 == env46667) = true)

theorem identity46667 : scanCanonicalize (H12AffineFastState.compose env46667 (packedSelected [3,5] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound46667 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env46668 : List Nat := [2,4,8,16,32,17,56,20,1,4,26,1,25,0,1,35,1,26,4,0,0,32,16,51,41,16,43,0,0,42,20,16,20,16,1,0]

theorem envBound46668 : H12AffineFastState.Bounded env46668 := by
  intro p hp
  have h : env46668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46667_46668 : H12AffineEnvironment.transform 8 1 env46667 = env46668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env46667 == env46668) = true)

theorem identity46668 : scanCanonicalize (H12AffineFastState.compose env46668 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound46668 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46669 : List Nat := [2,4,8,16,6,17,30,20,1,4,26,1,25,0,1,5,1,26,4,0,0,6,16,21,15,16,13,0,0,12,20,16,20,16,1,0]

theorem envBound46669 : H12AffineFastState.Bounded env46669 := by
  intro p hp
  have h : env46669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46668_46669 : H12AffineEnvironment.transform 4 6 env46668 = env46669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env46668 == env46669) = true)

theorem identity46669 : scanCanonicalize (H12AffineFastState.compose env46669 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound46669 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env46670 : List Nat := [2,4,4,16,6,17,18,20,1,4,22,1,21,0,1,5,1,22,4,0,0,6,16,21,3,16,1,0,0,0,20,16,20,16,1,0]

theorem envBound46670 : H12AffineFastState.Bounded env46670 := by
  intro p hp
  have h : env46670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46669_46670 : H12AffineEnvironment.transform 2 4 env46669 = env46670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env46669 == env46670) = true)

theorem identity46670 : scanCanonicalize (H12AffineFastState.compose env46670 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound46670 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46671 : List Nat := [2,4,4,2,6,3,0,6,1,4,4,1,7,0,1,5,1,4,4,0,0,6,2,7,3,2,1,0,0,0,6,2,6,2,1,0]

theorem envBound46671 : H12AffineFastState.Bounded env46671 := by
  intro p hp
  have h : env46671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46670_46671 : H12AffineEnvironment.transform 3 2 env46670 = env46671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env46670 == env46671) = true)

theorem identity46671 : scanCanonicalize (H12AffineFastState.compose env46671 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound46671 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env46672 : List Nat := [2,3,3,2,1,3,0,1,1,3,3,1,0,0,1,2,1,3,3,0,0,1,2,0,3,2,1,0,0,0,1,2,1,2,1,0]

theorem envBound46672 : H12AffineFastState.Bounded env46672 := by
  intro p hp
  have h : env46672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46671_46672 : H12AffineEnvironment.transform 1 3 env46671 = env46672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env46671 == env46672) = true)

def env46673 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1345,262144,77935,32769,4097,46529,16,266385,70887,78894,77840,1296,74814,81227,365712,1280,256,365716,1344,79470]

theorem envBound46673 : H12AffineFastState.Bounded env46673 := by
  intro p hp
  have h : env46673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46606_46673 : H12AffineEnvironment.transform 13 1297 env46606 = env46673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env46606 == env46673) = true)

theorem identity46673 : scanCanonicalize (H12AffineFastState.compose env46673 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32882) := by decide +kernel

theorem selectedBound46673 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env46674 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,32882,1345,262144,45085,32769,4097,46529,16,266385,38037,46172,45154,1296,42060,48441,267490,1280,256,267494,1344,46620]

theorem envBound46674 : H12AffineFastState.Bounded env46674 := by
  intro p hp
  have h : env46674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46673_46674 : H12AffineEnvironment.transform 15 32882 env46673 = env46674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32882 env46673 == env46674) = true)

def env46675 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32882,1345,262144,42333,32769,1345,41089,16,263633,33237,41244,42274,1296,42060,43129,262562,1280,256,262566,1344,41820]

theorem envBound46675 : H12AffineFastState.Bounded env46675 := by
  intro p hp
  have h : env46675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46674_46675 : H12AffineEnvironment.transform 11 1344 env46674 = env46675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env46674 == env46675) = true)

theorem identity46675 : scanCanonicalize (H12AffineFastState.compose env46675 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 34227) := by decide +kernel

theorem selectedBound46675 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env46676 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32882,1345,34227,42333,32769,1345,41089,16,32866,33237,41244,42274,1296,42060,43129,33809,1280,256,33813,1344,41820]

theorem envBound46676 : H12AffineFastState.Bounded env46676 := by
  intro p hp
  have h : env46676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46675_46676 : H12AffineEnvironment.transform 17 34227 env46675 = env46676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 34227 env46675 == env46676) = true)

theorem identity46676 : scanCanonicalize (H12AffineFastState.compose env46676 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(14+1) ^^^ 11782) := by decide +kernel

theorem selectedBound46676 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env46677 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,11782,11892,1345,11189,2907,11783,1345,3719,16,11876,12243,3866,2852,1296,2634,1663,10775,1280,256,10771,1344,3418]

theorem envBound46677 : H12AffineFastState.Bounded env46677 := by
  intro p hp
  have h : env46677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46676_46677 : H12AffineEnvironment.transform 14 11782 env46676 = env46677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 11782 env46676 == env46677) = true)

def env46678 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32882,1345,262144,42332,32769,1344,41088,16,263632,33236,41245,42275,1296,42060,43128,262563,1280,256,262567,1344,41821]

theorem envBound46678 : H12AffineFastState.Bounded env46678 := by
  intro p hp
  have h : env46678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46674_46678 : H12AffineEnvironment.transform 11 1345 env46674 = env46678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env46674 == env46678) = true)

theorem identity46678 : scanCanonicalize (H12AffineFastState.compose env46678 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound46678 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env46679 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,0,8192,80,32768,32882,0,262144,40989,32769,1,41088,16,262289,33236,41245,41058,81,41229,43128,262563,65,256,262567,1,41821]

theorem envBound46679 : H12AffineFastState.Bounded env46679 := by
  intro p hp
  have h : env46679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46678_46679 : H12AffineEnvironment.transform 9 321 env46678 = env46679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env46678 == env46679) = true)

theorem identity46679 : scanCanonicalize (H12AffineFastState.compose env46679 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound46679 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env46680 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,0,8192,80,8541,8495,0,262144,320,8540,1,477,16,262289,8329,64,319,81,80,2341,262563,65,256,262567,1,512]

theorem envBound46680 : H12AffineFastState.Bounded env46680 := by
  intro p hp
  have h : env46680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46679_46680 : H12AffineEnvironment.transform 14 8541 env46679 = env46680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env46679 == env46680) = true)

theorem identity46680 : scanCanonicalize (H12AffineFastState.compose env46680 (packedSelected [4,9,16] rootPS)) = affineNative (2^(17+1) ^^^ 243) := by decide +kernel

theorem selectedBound46680 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env46681 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,0,8192,80,8541,8495,0,243,320,8540,1,477,16,98,8329,64,319,81,80,2341,336,65,256,340,1,512]

theorem envBound46681 : H12AffineFastState.Bounded env46681 := by
  intro p hp
  have h : env46681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46680_46681 : H12AffineEnvironment.transform 17 243 env46680 = env46681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 243 env46680 == env46681) = true)

theorem identity46681 : scanCanonicalize (H12AffineFastState.compose env46681 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 901) := by decide +kernel

theorem selectedBound46681 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env46682 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,0,901,80,728,682,0,243,320,729,1,477,16,98,780,64,319,81,80,2341,336,65,256,340,1,512]

theorem envBound46682 : H12AffineFastState.Bounded env46682 := by
  intro p hp
  have h : env46682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46681_46682 : H12AffineEnvironment.transform 12 901 env46681 = env46682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 901 env46681 == env46682) = true)

theorem identity46682 : scanCanonicalize (H12AffineFastState.compose env46682 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound46682 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env46683 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,0,901,0,648,682,0,163,272,649,1,397,16,50,780,16,319,1,0,2341,256,17,256,260,1,512]

theorem envBound46683 : H12AffineFastState.Bounded env46683 := by
  intro p hp
  have h : env46683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46682_46683 : H12AffineEnvironment.transform 5 16 env46682 = env46683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env46682 == env46683) = true)

def env46684 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16465,262144,95614,32769,4097,61648,17,284032,86518,94526,77841,1297,74814,96346,381313,1280,256,381317,1344,95103]

theorem envBound46684 : H12AffineFastState.Bounded env46684 := by
  intro p hp
  have h : env46684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46605_46684 : H12AffineEnvironment.transform 16 16465 env46605 = env46684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16465 env46605 == env46684) = true)

def env46685 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1345,262144,77934,32769,4097,46528,17,266384,70886,78894,77841,1297,74814,81226,365713,1280,256,365717,1344,79471]

theorem envBound46685 : H12AffineFastState.Bounded env46685 := by
  intro p hp
  have h : env46685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46684_46685 : H12AffineEnvironment.transform 13 1296 env46684 = env46685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env46684 == env46685) = true)

theorem identity46685 : scanCanonicalize (H12AffineFastState.compose env46685 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32883) := by decide +kernel

theorem selectedBound46685 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

end H12CloudChart2