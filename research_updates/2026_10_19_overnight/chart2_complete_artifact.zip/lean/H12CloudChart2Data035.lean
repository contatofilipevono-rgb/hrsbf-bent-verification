import H12CloudChart2Data034

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound8545 : H12AffineFastState.Bounded env8545 := by
  intro p hp
  have h : env8545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8544_8545 : H12AffineEnvironment.transform 31 211 env8544 = env8545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 211 env8544 == env8545) = true)

theorem identity8545 : scanCanonicalize (H12AffineFastState.compose env8545 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound8545 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env8546 : List Nat := [2,4,8,16,1,64,128,4,137,1024,1,4096,5148,4176,5140,5279,1093,0,1025,5140,4097,5140,5204,139,5269,5124,5140,4176,1045,5140,1024,211,5,5318,1093,136]

theorem envBound8546 : H12AffineFastState.Bounded env8546 := by
  intro p hp
  have h : env8546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8545_8546 : H12AffineEnvironment.transform 4 1 env8545 = env8546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env8545 == env8546) = true)

theorem identity8546 : scanCanonicalize (H12AffineFastState.compose env8546 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 1045) := by decide +kernel

theorem selectedBound8546 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8547 : List Nat := [2,4,8,16,1,64,128,4,137,1024,1,1045,9,1093,1,138,1093,0,1025,1,1044,1,65,139,128,17,1,1093,1045,1,1024,211,5,211,1093,136]

theorem envBound8547 : H12AffineFastState.Bounded env8547 := by
  intro p hp
  have h : env8547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8546_8547 : H12AffineEnvironment.transform 11 1045 env8546 = env8547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1045 env8546 == env8547) = true)

theorem identity8547 : scanCanonicalize (H12AffineFastState.compose env8547 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound8547 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8548 : List Nat := [2,4,8,16,1,11,128,4,137,1024,1,1045,9,1038,1,138,1038,0,1025,1,1044,1,10,139,128,17,1,1038,1045,1,1024,152,5,152,1038,136]

theorem envBound8548 : H12AffineFastState.Bounded env8548 := by
  intro p hp
  have h : env8548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8547_8548 : H12AffineEnvironment.transform 5 11 env8547 = env8548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env8547 == env8548) = true)

theorem identity8548 : scanCanonicalize (H12AffineFastState.compose env8548 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound8548 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8549 : List Nat := [2,4,8,16,1,11,24,4,17,1024,1,1045,9,1038,1,18,1038,0,1025,1,1044,1,10,19,24,17,1,1038,1045,1,1024,0,5,0,1038,16]

theorem envBound8549 : H12AffineFastState.Bounded env8549 := by
  intro p hp
  have h : env8549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8548_8549 : H12AffineEnvironment.transform 6 24 env8548 = env8549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env8548 == env8549) = true)

def env8550 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,4096,8192,16384,8200,65536,1125,0,1025,8200,16496,8200,17664,73768,65547,5376,8201,16384,1077,86266,1056,4294967296,257,4294996057,1125,73738]

theorem envBound8550 : H12AffineFastState.Bounded env8550 := by
  intro p hp
  have h : env8550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8539_8550 : H12AffineEnvironment.transform 16 1125 env8539 = env8550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1125 env8539 == env8550) = true)

theorem identity8550 : scanCanonicalize (H12AffineFastState.compose env8550 (packedSelected [6,16,18,20,23,25] rootPS)) = affineNative (2^(15+1) ^^^ 28915) := by decide +kernel

theorem selectedBound8550 : packedSelected [6,16,18,20,23,25] rootPS < 2^1333 := by decide +kernel

def env8551 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,4096,8192,16384,8200,28915,1125,0,1025,8200,16496,8200,17664,20699,28920,5376,8201,16384,1077,8201,1056,4294967296,257,4294996057,1125,20729]

theorem envBound8551 : H12AffineFastState.Bounded env8551 := by
  intro p hp
  have h : env8551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8550_8551 : H12AffineEnvironment.transform 15 28915 env8550 = env8551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28915 env8550 == env8551) = true)

theorem identity8551 : scanCanonicalize (H12AffineFastState.compose env8551 (packedSelected [4,5,8,9,18] rootPS)) = affineNative (2^(13+1) ^^^ 4176) := by decide +kernel

theorem selectedBound8551 : packedSelected [4,5,8,9,18] rootPS < 2^1333 := by decide +kernel

def env8552 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,4096,8192,4176,8200,8355,1125,0,1025,8200,4128,8200,5456,139,8360,5376,8201,4176,1077,8201,1056,4294967296,257,4294975497,1125,169]

theorem envBound8552 : H12AffineFastState.Bounded env8552 := by
  intro p hp
  have h : env8552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8551_8552 : H12AffineEnvironment.transform 13 4176 env8551 = env8552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env8551 == env8552) = true)

theorem identity8552 : scanCanonicalize (H12AffineFastState.compose env8552 (packedSelected [0,3,4,7,8,9,13,20] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound8552 : packedSelected [0,3,4,7,8,9,13,20] rootPS < 2^1333 := by decide +kernel

def env8553 : List Nat := [2,4,8,16,32,64,128,37,137,1024,1,4096,8192,4176,8200,8355,1125,0,1025,8200,4128,8200,5237,139,8360,5157,8201,4176,1077,8201,1056,4294967296,36,4294975497,1125,169]

theorem envBound8553 : H12AffineFastState.Bounded env8553 := by
  intro p hp
  have h : env8553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8552_8553 : H12AffineEnvironment.transform 7 37 env8552 = env8553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env8552 == env8553) = true)

theorem identity8553 : scanCanonicalize (H12AffineFastState.compose env8553 (packedSelected [1,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound8553 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env8554 : List Nat := [2,4,8,16,10,64,128,15,137,1024,1,4096,8192,4176,8200,8329,1103,0,1025,8200,4106,8200,5215,139,8322,5135,8201,4176,1055,8201,1034,4294967296,14,4294975497,1103,131]

theorem envBound8554 : H12AffineFastState.Bounded env8554 := by
  intro p hp
  have h : env8554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8553_8554 : H12AffineEnvironment.transform 4 10 env8553 = env8554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env8553 == env8554) = true)

theorem identity8554 : scanCanonicalize (H12AffineFastState.compose env8554 (packedSelected [3,4,9,10,15] rootPS)) = affineNative (2^(11+1) ^^^ 1044) := by decide +kernel

theorem selectedBound8554 : packedSelected [3,4,9,10,15] rootPS < 2^1333 := by decide +kernel

def env8555 : List Nat := [2,4,8,16,10,64,128,15,137,1024,1,1044,8192,1092,8200,8329,1103,0,1025,8200,1054,8200,75,139,8322,27,8201,1092,1055,8201,1034,4294967296,14,4294975497,1103,131]

theorem envBound8555 : H12AffineFastState.Bounded env8555 := by
  intro p hp
  have h : env8555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8554_8555 : H12AffineEnvironment.transform 11 1044 env8554 = env8555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1044 env8554 == env8555) = true)

theorem identity8555 : scanCanonicalize (H12AffineFastState.compose env8555 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(31+1) ^^^ 26) := by decide +kernel

theorem selectedBound8555 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env8556 : List Nat := [2,4,8,16,10,64,128,15,137,1024,1,1044,8192,1092,8200,8329,1103,0,1025,8200,1054,8200,75,139,8322,27,8201,1092,1055,8201,1034,26,14,8211,1103,131]

theorem envBound8556 : H12AffineFastState.Bounded env8556 := by
  intro p hp
  have h : env8556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8555_8556 : H12AffineEnvironment.transform 31 26 env8555 = env8556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 26 env8555 == env8556) = true)

theorem identity8556 : scanCanonicalize (H12AffineFastState.compose env8556 (packedSelected [0,1,3,4,7,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 66) := by decide +kernel

theorem selectedBound8556 : packedSelected [0,1,3,4,7,9,10] rootPS < 2^1333 := by decide +kernel

def env8557 : List Nat := [2,4,8,16,10,64,128,15,137,1024,1,1044,66,1092,74,203,1103,0,1025,74,1054,74,75,139,192,27,75,1092,1055,75,1034,26,14,81,1103,131]

theorem envBound8557 : H12AffineFastState.Bounded env8557 := by
  intro p hp
  have h : env8557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8556_8557 : H12AffineEnvironment.transform 12 66 env8556 = env8557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 66 env8556 == env8557) = true)

theorem identity8557 : scanCanonicalize (H12AffineFastState.compose env8557 (packedSelected [1,2,4,7,12] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound8557 : packedSelected [1,2,4,7,12] rootPS < 2^1333 := by decide +kernel

def env8558 : List Nat := [2,4,8,16,10,0,128,15,137,1024,1,1044,2,1028,10,139,1039,0,1025,10,1054,10,11,139,128,27,11,1028,1055,11,1034,26,14,17,1039,131]

theorem envBound8558 : H12AffineFastState.Bounded env8558 := by
  intro p hp
  have h : env8558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8557_8558 : H12AffineEnvironment.transform 5 0 env8557 = env8558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env8557 == env8558) = true)

theorem identity8558 : scanCanonicalize (H12AffineFastState.compose env8558 (packedSelected [2,3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound8558 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env8559 : List Nat := [2,4,2,16,0,0,128,5,131,1024,1,1044,2,1028,0,129,1029,0,1025,0,1044,0,1,129,128,17,1,1028,1045,1,1024,16,4,17,1029,131]

theorem envBound8559 : H12AffineFastState.Bounded env8559 := by
  intro p hp
  have h : env8559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8558_8559 : H12AffineEnvironment.transform 2 2 env8558 = env8559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env8558 == env8559) = true)

theorem identity8559 : scanCanonicalize (H12AffineFastState.compose env8559 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 16) := by decide +kernel

theorem selectedBound8559 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8560 : List Nat := [2,4,2,16,0,0,16,5,19,1024,1,1044,2,1028,0,17,1029,0,1025,0,1044,0,1,17,16,17,1,1028,1045,1,1024,16,4,17,1029,19]

theorem envBound8560 : H12AffineFastState.Bounded env8560 := by
  intro p hp
  have h : env8560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8559_8560 : H12AffineEnvironment.transform 6 16 env8559 = env8560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 16 env8559 == env8560) = true)

theorem identity8560 : scanCanonicalize (H12AffineFastState.compose env8560 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound8560 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8561 : List Nat := [0,4,0,16,0,0,16,5,17,1024,1,1044,0,1028,0,17,1029,0,1025,0,1044,0,1,17,16,17,1,1028,1045,1,1024,16,4,17,1029,17]

theorem envBound8561 : H12AffineFastState.Bounded env8561 := by
  intro p hp
  have h : env8561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8560_8561 : H12AffineEnvironment.transform 0 0 env8560 = env8561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env8560 == env8561) = true)

theorem identity8561 : scanCanonicalize (H12AffineFastState.compose env8561 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound8561 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8562 : List Nat := [0,4,0,16,0,0,16,5,17,5,1,17,0,1,0,17,0,0,4,0,17,0,1,17,16,17,1,1,16,1,5,16,4,17,0,17]

theorem envBound8562 : H12AffineFastState.Bounded env8562 := by
  intro p hp
  have h : env8562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8561_8562 : H12AffineEnvironment.transform 9 5 env8561 = env8562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env8561 == env8562) = true)

theorem identity8562 : scanCanonicalize (H12AffineFastState.compose env8562 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound8562 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env8563 : List Nat := [0,4,0,1,0,0,1,5,0,5,1,0,0,1,0,0,0,0,4,0,0,0,1,0,1,0,1,1,1,1,5,1,4,0,0,0]

theorem envBound8563 : H12AffineFastState.Bounded env8563 := by
  intro p hp
  have h : env8563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8562_8563 : H12AffineEnvironment.transform 3 1 env8562 = env8563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env8562 == env8563) = true)

def env8564 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8833,65536,131072,0,524288,8833,16497,8200,17664,206532,33554432,5376,140397,16384,131152,33707549,131141,4294967296,257,4329271999,131072,33563272]

theorem envBound8564 : H12AffineFastState.Bounded env8564 := by
  intro p hp
  have h : env8564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8520_8564 : H12AffineEnvironment.transform 20 16497 env8520 = env8564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 16497 env8520 == env8564) = true)

def env8565 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8833,65536,131072,1,524288,8833,2097152,8200,17664,206532,33554432,5376,2253853,16384,131152,33707548,131141,4294967296,257,4329271999,131072,33563272]

theorem envBound8565 : H12AffineFastState.Bounded env8565 := by
  intro p hp
  have h : env8565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8519_8565 : H12AffineEnvironment.transform 17 1 env8519 = env8565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1 env8519 == env8565) = true)

def env8566 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8833,65536,131072,1,524288,8833,16496,8200,17664,206532,33554432,5376,140397,16384,131152,33707548,131141,4294967296,257,4329271999,131072,33563272]

theorem envBound8566 : H12AffineFastState.Bounded env8566 := by
  intro p hp
  have h : env8566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8565_8566 : H12AffineEnvironment.transform 20 16496 env8565 = env8566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 16496 env8565 == env8566) = true)

theorem identity8566 : scanCanonicalize (H12AffineFastState.compose env8566 (packedSelected [6,10,12,13,15,16,17,18,19,20,21,23,25,26,31,32,33,38,41] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound8566 : packedSelected [6,10,12,13,15,16,17,18,19,20,21,23,25,26,31,32,33,38,41] rootPS < 2^1333 := by decide +kernel

def env8567 : List Nat := [2,4,8,16,32,64,128,256,136,1024,1,4096,8192,16384,8201,65536,131072,1,524288,8201,16496,8200,17664,205900,33554432,5376,140397,16384,131152,33707156,131141,4294967296,257,4329271351,131072,33562624]

theorem envBound8567 : H12AffineFastState.Bounded env8567 := by
  intro p hp
  have h : env8567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8566_8567 : H12AffineEnvironment.transform 8 136 env8566 = env8567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env8566 == env8567) = true)

def env8568 : List Nat := [2,4,8,16,32,64,128,256,136,1024,1,4096,8192,16384,8201,65536,131072,1,1024,8201,16496,8200,17664,205900,33554432,5376,140397,16384,131152,33707156,131141,4294967296,257,4328748087,131072,33562624]

theorem envBound8568 : H12AffineFastState.Bounded env8568 := by
  intro p hp
  have h : env8568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8567_8568 : H12AffineEnvironment.transform 18 1024 env8567 = env8568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env8567 == env8568) = true)

theorem identity8568 : scanCanonicalize (H12AffineFastState.compose env8568 (packedSelected [4,6,7,9,16,20,25,27] rootPS)) = affineNative (2^(24+1) ^^^ 197710) := by decide +kernel

theorem selectedBound8568 : packedSelected [4,6,7,9,16,20,25,27] rootPS < 2^1333 := by decide +kernel

def env8569 : List Nat := [2,4,8,16,32,64,128,256,136,1024,1,4096,8192,16384,8201,65536,131072,1,1024,8201,16496,8200,17664,205900,197710,5376,140397,16384,131152,86234,131141,4294967296,257,4294996089,131072,205902]

theorem envBound8569 : H12AffineFastState.Bounded env8569 := by
  intro p hp
  have h : env8569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8568_8569 : H12AffineEnvironment.transform 24 197710 env8568 = env8569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 197710 env8568 == env8569) = true)

theorem identity8569 : scanCanonicalize (H12AffineFastState.compose env8569 (packedSelected [0,1,4,5,6,7,8,17,18,21,22,23,24,25] rootPS)) = affineNative (2^(16+1) ^^^ 95382) := by decide +kernel

theorem selectedBound8569 : packedSelected [0,1,4,5,6,7,8,17,18,21,22,23,24,25] rootPS < 2^1333 := by decide +kernel

def env8570 : List Nat := [2,4,8,16,32,64,128,256,136,1024,1,4096,8192,16384,8201,65536,95382,1,1024,8201,16496,8200,17664,20698,28888,5376,86267,16384,95430,86234,95443,4294967296,257,4294996089,95382,20696]

theorem envBound8570 : H12AffineFastState.Bounded env8570 := by
  intro p hp
  have h : env8570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8569_8570 : H12AffineEnvironment.transform 16 95382 env8569 = env8570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 95382 env8569 == env8570) = true)

theorem identity8570 : scanCanonicalize (H12AffineFastState.compose env8570 (packedSelected [1,3,5,8,10,17,21,26] rootPS)) = affineNative (2^(13+1) ^^^ 4209) := by decide +kernel

theorem selectedBound8570 : packedSelected [1,3,5,8,10,17,21,26] rootPS < 2^1333 := by decide +kernel

def env8571 : List Nat := [2,4,8,16,32,64,128,256,136,1024,1,4096,8192,4209,8201,65536,74983,1,1024,8201,4097,8200,5489,171,8361,5376,65674,4209,74935,65707,74914,4294967296,257,4294975496,74983,169]

theorem envBound8571 : H12AffineFastState.Bounded env8571 := by
  intro p hp
  have h : env8571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8570_8571 : H12AffineEnvironment.transform 13 4209 env8570 = env8571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4209 env8570 == env8571) = true)

theorem identity8571 : scanCanonicalize (H12AffineFastState.compose env8571 (packedSelected [0,1,4,7,8,9,10,13,15,16,17] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound8571 : packedSelected [0,1,4,7,8,9,10,13,15,16,17] rootPS < 2^1333 := by decide +kernel

def env8572 : List Nat := [2,4,8,16,0,64,128,256,136,1024,1,4096,8192,4177,8201,65536,74951,1,1024,8201,4097,8200,5457,139,8329,5376,65674,4177,74903,65675,74882,4294967296,257,4294975496,74951,137]

theorem envBound8572 : H12AffineFastState.Bounded env8572 := by
  intro p hp
  have h : env8572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8571_8572 : H12AffineEnvironment.transform 4 0 env8571 = env8572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env8571 == env8572) = true)

theorem identity8572 : scanCanonicalize (H12AffineFastState.compose env8572 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound8572 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env8573 : List Nat := [2,4,8,16,0,64,128,256,136,1024,1,1297,8192,1344,8201,65536,74951,1,1024,8201,1296,8200,64,139,8329,17,65674,1344,74903,65675,74882,4294967296,257,4294975496,74951,137]

theorem envBound8573 : H12AffineFastState.Bounded env8573 := by
  intro p hp
  have h : env8573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8572_8573 : H12AffineEnvironment.transform 11 1297 env8572 = env8573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env8572 == env8573) = true)

theorem identity8573 : scanCanonicalize (H12AffineFastState.compose env8573 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound8573 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env8574 : List Nat := [2,4,8,16,0,64,128,256,136,1024,1,1297,9,1344,0,65536,66766,1,1024,0,1296,1,64,139,128,17,65674,1344,66718,65675,66699,4294967296,257,4294967297,66766,137]

theorem envBound8574 : H12AffineFastState.Bounded env8574 := by
  intro p hp
  have h : env8574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8573_8574 : H12AffineEnvironment.transform 12 9 env8573 = env8574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env8573 == env8574) = true)

theorem identity8574 : scanCanonicalize (H12AffineFastState.compose env8574 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 462) := by decide +kernel

theorem selectedBound8574 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8575 : List Nat := [2,4,8,16,0,64,128,256,136,1024,1,1297,9,1344,0,462,1280,1,1024,0,1296,1,64,139,128,17,324,1344,1360,325,1349,4294967296,257,4294967297,1280,137]

theorem envBound8575 : H12AffineFastState.Bounded env8575 := by
  intro p hp
  have h : env8575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8574_8575 : H12AffineEnvironment.transform 15 462 env8574 = env8575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 462 env8574 == env8575) = true)

theorem identity8575 : scanCanonicalize (H12AffineFastState.compose env8575 (packedSelected [1,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound8575 : packedSelected [1,5,10] rootPS < 2^1333 := by decide +kernel

def env8576 : List Nat := [2,4,8,16,0,64,128,69,136,1024,1,1108,9,1029,0,139,1093,1,1024,0,1109,1,64,139,128,17,1,1029,1045,0,1024,4294967296,68,4294967297,1093,137]

theorem envBound8576 : H12AffineFastState.Bounded env8576 := by
  intro p hp
  have h : env8576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8575_8576 : H12AffineEnvironment.transform 7 69 env8575 = env8576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env8575 == env8576) = true)

theorem identity8576 : scanCanonicalize (H12AffineFastState.compose env8576 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 11) := by decide +kernel

theorem selectedBound8576 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8577 : List Nat := [2,4,8,16,0,64,128,69,136,1024,1,1108,9,1029,0,139,1093,1,1024,0,1109,1,64,139,128,17,1,1029,1045,0,1024,11,68,10,1093,137]

theorem envBound8577 : H12AffineFastState.Bounded env8577 := by
  intro p hp
  have h : env8577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8576_8577 : H12AffineEnvironment.transform 31 11 env8576 = env8577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 11 env8576 == env8577) = true)

theorem identity8577 : scanCanonicalize (H12AffineFastState.compose env8577 (packedSelected [5,13] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound8577 : packedSelected [5,13] rootPS < 2^1333 := by decide +kernel

def env8578 : List Nat := [2,4,8,16,0,1,128,4,136,1024,1,1045,9,1029,0,139,1028,1,1024,0,1044,1,1,139,128,17,1,1029,1045,0,1024,11,5,10,1028,137]

theorem envBound8578 : H12AffineFastState.Bounded env8578 := by
  intro p hp
  have h : env8578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8577_8578 : H12AffineEnvironment.transform 5 1 env8577 = env8578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env8577 == env8578) = true)

def leafEnv8578 : List Nat := [2,4,8,16,0,1,128,4,136,1024,1,1045,9,1029,0,139,1028,1,1024,0,1044,1,1,139,1024,128,1,17,1,1029,1045,0,1024,11,5,10,5,3,1028,137,0,1044,1]

def active8578 : List Nat := [0,1,2,3,6,9]

def tree8578 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood8578 : H12WitnessSearch.Good tree8578 := H12GlobalWitnessIndex.good

theorem leafIdentity8578 : H12AffineFastState.composeSystem env8578 rootObs = leafEnv8578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env8578 rootObs == leafEnv8578) = true)

theorem terminalChecked8578 : H12PackedTerminal.terminalCheckFast leafEnv8578 active8578 tree8578 = true := by decide +kernel

def env8579 : List Nat := [2,4,8,16,32,64,128,256,136,1024,1,4096,8192,16384,8201,65536,131072,1,1025,8201,16496,8200,17664,205900,33554432,5376,140397,16384,131152,33707156,131141,4294967296,257,4328748086,131072,33562624]

theorem envBound8579 : H12AffineFastState.Bounded env8579 := by
  intro p hp
  have h : env8579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8567_8579 : H12AffineEnvironment.transform 18 1025 env8567 = env8579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env8567 == env8579) = true)

theorem identity8579 : scanCanonicalize (H12AffineFastState.compose env8579 (packedSelected [4,6,7,9,16,20,25,27] rootPS)) = affineNative (2^(24+1) ^^^ 197743) := by decide +kernel

theorem selectedBound8579 : packedSelected [4,6,7,9,16,20,25,27] rootPS < 2^1333 := by decide +kernel

def env8580 : List Nat := [2,4,8,16,32,64,128,256,136,1024,1,4096,8192,16384,8201,65536,131072,1,1025,8201,16496,8200,17664,205900,197743,5376,140397,16384,131152,86267,131141,4294967296,257,4294996057,131072,205935]

theorem envBound8580 : H12AffineFastState.Bounded env8580 := by
  intro p hp
  have h : env8580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8579_8580 : H12AffineEnvironment.transform 24 197743 env8579 = env8580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 197743 env8579 == env8580) = true)

def env8581 : List Nat := [2,4,8,16,32,64,128,256,136,1024,1,4096,8192,16384,8201,65536,1124,1,1025,8201,16496,8200,17664,73768,65547,5376,8201,16384,1076,86267,1057,4294967296,257,4294996057,1124,73739]

theorem envBound8581 : H12AffineFastState.Bounded env8581 := by
  intro p hp
  have h : env8581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8580_8581 : H12AffineEnvironment.transform 16 1124 env8580 = env8581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1124 env8580 == env8581) = true)

theorem identity8581 : scanCanonicalize (H12AffineFastState.compose env8581 (packedSelected [6,16,18,20,23,25] rootPS)) = affineNative (2^(15+1) ^^^ 28915) := by decide +kernel

theorem selectedBound8581 : packedSelected [6,16,18,20,23,25] rootPS < 2^1333 := by decide +kernel

def env8582 : List Nat := [2,4,8,16,32,64,128,256,136,1024,1,4096,8192,16384,8201,28915,1124,1,1025,8201,16496,8200,17664,20699,28920,5376,8201,16384,1076,8200,1057,4294967296,257,4294996057,1124,20728]

theorem envBound8582 : H12AffineFastState.Bounded env8582 := by
  intro p hp
  have h : env8582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8581_8582 : H12AffineEnvironment.transform 15 28915 env8581 = env8582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28915 env8581 == env8582) = true)

theorem identity8582 : scanCanonicalize (H12AffineFastState.compose env8582 (packedSelected [4,5,8,9,18] rootPS)) = affineNative (2^(13+1) ^^^ 4209) := by decide +kernel

theorem selectedBound8582 : packedSelected [4,5,8,9,18] rootPS < 2^1333 := by decide +kernel

def env8583 : List Nat := [2,4,8,16,32,64,128,256,136,1024,1,4096,8192,4209,8201,8322,1124,1,1025,8201,4097,8200,5489,170,8329,5376,8201,4209,1076,8200,1057,4294967296,257,4294975528,1124,137]

theorem envBound8583 : H12AffineFastState.Bounded env8583 := by
  intro p hp
  have h : env8583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8582_8583 : H12AffineEnvironment.transform 13 4209 env8582 = env8583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4209 env8582 == env8583) = true)

theorem identity8583 : scanCanonicalize (H12AffineFastState.compose env8583 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1076) := by decide +kernel

theorem selectedBound8583 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env8584 : List Nat := [2,4,8,16,32,64,128,256,136,1024,1,1076,8192,1093,8201,8322,1124,1,1025,8201,1077,8200,325,170,8329,308,8201,1093,1076,8200,1057,4294967296,257,4294975528,1124,137]

theorem envBound8584 : H12AffineFastState.Bounded env8584 := by
  intro p hp
  have h : env8584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8583_8584 : H12AffineEnvironment.transform 11 1076 env8583 = env8584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1076 env8583 == env8584) = true)

theorem identity8584 : scanCanonicalize (H12AffineFastState.compose env8584 (packedSelected [0,2,6,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound8584 : packedSelected [0,2,6,9] rootPS < 2^1333 := by decide +kernel

def env8585 : List Nat := [2,4,8,16,0,64,128,256,136,1024,1,1044,8192,1093,8201,8322,1092,1,1025,8201,1045,8200,325,138,8329,276,8201,1093,1044,8200,1025,4294967296,257,4294975496,1092,137]

theorem envBound8585 : H12AffineFastState.Bounded env8585 := by
  intro p hp
  have h : env8585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8584_8585 : H12AffineEnvironment.transform 4 0 env8584 = env8585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env8584 == env8585) = true)

theorem identity8585 : scanCanonicalize (H12AffineFastState.compose env8585 (packedSelected [0,2,4] rootPS)) = affineNative (2^(31+1) ^^^ 131) := by decide +kernel

theorem selectedBound8585 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env8586 : List Nat := [2,4,8,16,0,64,128,256,136,1024,1,1044,8192,1093,8201,8322,1092,1,1025,8201,1045,8200,325,138,8329,276,8201,1093,1044,8200,1025,131,257,8331,1092,137]

theorem envBound8586 : H12AffineFastState.Bounded env8586 := by
  intro p hp
  have h : env8586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8585_8586 : H12AffineEnvironment.transform 31 131 env8585 = env8586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 131 env8585 == env8586) = true)

theorem identity8586 : scanCanonicalize (H12AffineFastState.compose env8586 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 215) := by decide +kernel

theorem selectedBound8586 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8587 : List Nat := [2,4,8,16,0,64,128,215,136,1024,1,1044,8192,1093,8201,8322,1092,1,1025,8201,1045,8200,146,138,8329,195,8201,1093,1044,8200,1025,131,214,8331,1092,137]

theorem envBound8587 : H12AffineFastState.Bounded env8587 := by
  intro p hp
  have h : env8587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8586_8587 : H12AffineEnvironment.transform 7 215 env8586 = env8587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 215 env8586 == env8587) = true)

theorem identity8587 : scanCanonicalize (H12AffineFastState.compose env8587 (packedSelected [6] rootPS)) = affineNative (2^(6+1) ^^^ 82) := by decide +kernel

theorem selectedBound8587 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env8588 : List Nat := [2,4,8,16,0,64,82,5,90,1024,1,1044,8192,1093,8201,8272,1092,1,1025,8201,1045,8200,64,88,8283,17,8201,1093,1044,8200,1025,81,4,8281,1092,91]

theorem envBound8588 : H12AffineFastState.Bounded env8588 := by
  intro p hp
  have h : env8588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8587_8588 : H12AffineEnvironment.transform 6 82 env8587 = env8588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 82 env8587 == env8588) = true)

def env8589 : List Nat := [2,4,8,16,32,64,128,256,136,1024,1,4096,8192,16384,8201,65536,1125,1,1025,8201,16496,8200,17664,73769,65546,5376,8200,16384,1077,86267,1056,4294967296,257,4294996057,1125,73738]

theorem envBound8589 : H12AffineFastState.Bounded env8589 := by
  intro p hp
  have h : env8589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8580_8589 : H12AffineEnvironment.transform 16 1125 env8580 = env8589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1125 env8580 == env8589) = true)

theorem identity8589 : scanCanonicalize (H12AffineFastState.compose env8589 (packedSelected [6,16,18,20,23,25] rootPS)) = affineNative (2^(13+1) ^^^ 4209) := by decide +kernel

theorem selectedBound8589 : packedSelected [6,16,18,20,23,25] rootPS < 2^1333 := by decide +kernel

def env8590 : List Nat := [2,4,8,16,32,64,128,256,136,1024,1,4096,8192,4209,8201,65536,1125,1,1025,8201,4097,8200,5489,73769,65546,5376,8200,4209,1077,65674,1056,4294967296,257,4294975528,1125,73738]

theorem envBound8590 : H12AffineFastState.Bounded env8590 := by
  intro p hp
  have h : env8590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8589_8590 : H12AffineEnvironment.transform 13 4209 env8589 = env8590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4209 env8589 == env8590) = true)

theorem identity8590 : scanCanonicalize (H12AffineFastState.compose env8590 (packedSelected [1,3,5,8,12,13,15,16,17,18] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound8590 : packedSelected [1,3,5,8,12,13,15,16,17,18] rootPS < 2^1333 := by decide +kernel

def env8591 : List Nat := [2,4,8,16,32,64,128,256,136,1024,1,4096,8192,4209,8201,8323,1125,1,1025,8201,4097,8200,5489,170,8329,5376,8200,4209,1077,8201,1056,4294967296,257,4294975528,1125,137]

theorem envBound8591 : H12AffineFastState.Bounded env8591 := by
  intro p hp
  have h : env8591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8590_8591 : H12AffineEnvironment.transform 15 8323 env8590 = env8591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env8590 == env8591) = true)

theorem identity8591 : scanCanonicalize (H12AffineFastState.compose env8591 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1077) := by decide +kernel

theorem selectedBound8591 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env8592 : List Nat := [2,4,8,16,32,64,128,256,136,1024,1,1077,8192,1092,8201,8323,1125,1,1025,8201,1076,8200,324,170,8329,309,8200,1092,1077,8201,1056,4294967296,257,4294975528,1125,137]

theorem envBound8592 : H12AffineFastState.Bounded env8592 := by
  intro p hp
  have h : env8592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8591_8592 : H12AffineEnvironment.transform 11 1077 env8591 = env8592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1077 env8591 == env8592) = true)

theorem identity8592 : scanCanonicalize (H12AffineFastState.compose env8592 (packedSelected [0,2,4,5,6,8] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound8592 : packedSelected [0,2,4,5,6,8] rootPS < 2^1333 := by decide +kernel

def env8593 : List Nat := [2,4,8,16,32,64,128,36,136,1024,1,1077,8192,1092,8201,8323,1125,1,1025,8201,1076,8200,96,170,8329,17,8200,1092,1077,8201,1056,4294967296,37,4294975528,1125,137]

theorem envBound8593 : H12AffineFastState.Bounded env8593 := by
  intro p hp
  have h : env8593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8592_8593 : H12AffineEnvironment.transform 7 36 env8592 = env8593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env8592 == env8593) = true)

theorem identity8593 : scanCanonicalize (H12AffineFastState.compose env8593 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(31+1) ^^^ 210) := by decide +kernel

theorem selectedBound8593 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env8594 : List Nat := [2,4,8,16,32,64,128,36,136,1024,1,1077,8192,1092,8201,8323,1125,1,1025,8201,1076,8200,96,170,8329,17,8200,1092,1077,8201,1056,210,37,8442,1125,137]

theorem envBound8594 : H12AffineFastState.Bounded env8594 := by
  intro p hp
  have h : env8594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8593_8594 : H12AffineEnvironment.transform 31 210 env8593 = env8594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 210 env8593 == env8594) = true)

theorem identity8594 : scanCanonicalize (H12AffineFastState.compose env8594 (packedSelected [0,1,2,3,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound8594 : packedSelected [0,1,2,3,9] rootPS < 2^1333 := by decide +kernel

def env8595 : List Nat := [2,4,8,16,0,64,128,4,136,1024,1,1045,8192,1092,8201,8323,1093,1,1025,8201,1044,8200,64,138,8329,17,8200,1092,1045,8201,1024,210,5,8410,1093,137]

theorem envBound8595 : H12AffineFastState.Bounded env8595 := by
  intro p hp
  have h : env8595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8594_8595 : H12AffineEnvironment.transform 4 0 env8594 = env8595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env8594 == env8595) = true)

theorem identity8595 : scanCanonicalize (H12AffineFastState.compose env8595 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 209) := by decide +kernel

theorem selectedBound8595 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8596 : List Nat := [2,4,8,16,0,64,128,4,136,1024,1,1045,209,1092,216,82,1093,1,1025,216,1044,217,64,138,88,17,217,1092,1045,216,1024,210,5,11,1093,137]

theorem envBound8596 : H12AffineFastState.Bounded env8596 := by
  intro p hp
  have h : env8596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8595_8596 : H12AffineEnvironment.transform 12 209 env8595 = env8596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 209 env8595 == env8596) = true)

theorem identity8596 : scanCanonicalize (H12AffineFastState.compose env8596 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 83) := by decide +kernel

theorem selectedBound8596 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8597 : List Nat := [2,4,8,16,0,64,83,4,91,1024,1,1045,2,1092,11,82,1093,1,1025,11,1044,10,64,89,88,17,10,1092,1045,11,1024,1,5,11,1093,90]

theorem envBound8597 : H12AffineFastState.Bounded env8597 := by
  intro p hp
  have h : env8597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8596_8597 : H12AffineEnvironment.transform 6 83 env8596 = env8597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 83 env8596 == env8597) = true)

theorem identity8597 : scanCanonicalize (H12AffineFastState.compose env8597 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound8597 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8598 : List Nat := [2,4,8,16,0,1,18,4,26,1024,1,1045,2,1029,11,19,1028,1,1025,11,1044,10,1,24,25,17,10,1029,1045,11,1024,1,5,11,1028,27]

theorem envBound8598 : H12AffineFastState.Bounded env8598 := by
  intro p hp
  have h : env8598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8597_8598 : H12AffineEnvironment.transform 5 1 env8597 = env8598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env8597 == env8598) = true)

theorem identity8598 : scanCanonicalize (H12AffineFastState.compose env8598 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound8598 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env8599 : List Nat := [2,4,3,16,0,1,18,4,17,1024,1,1045,2,1029,0,19,1028,1,1025,0,1044,1,1,19,18,17,1,1029,1045,0,1024,1,5,0,1028,16]

theorem envBound8599 : H12AffineFastState.Bounded env8599 := by
  intro p hp
  have h : env8599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8598_8599 : H12AffineEnvironment.transform 2 3 env8598 = env8599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env8598 == env8599) = true)

def leafEnv8599 : List Nat := [2,4,3,16,0,1,18,4,17,1024,1,1045,2,1029,0,19,1028,1,1025,0,1044,1,1,19,1025,18,1,17,1,1029,1045,0,1024,1,5,0,5,3,1028,16,0,1044,1]

def active8599 : List Nat := [0,1,3,9]

def tree8599 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood8599 : H12WitnessSearch.Good tree8599 := H12GlobalWitnessIndex.good

theorem leafIdentity8599 : H12AffineFastState.composeSystem env8599 rootObs = leafEnv8599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env8599 rootObs == leafEnv8599) = true)

theorem terminalChecked8599 : H12PackedTerminal.terminalCheckFast leafEnv8599 active8599 tree8599 = true := by decide +kernel

def env8600 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8833,65536,131072,1,524288,8833,16497,8200,17664,206532,33554432,5376,140396,16384,131152,33707548,131141,4294967296,257,4329271999,131072,33563272]

theorem envBound8600 : H12AffineFastState.Bounded env8600 := by
  intro p hp
  have h : env8600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8565_8600 : H12AffineEnvironment.transform 20 16497 env8565 = env8600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 16497 env8565 == env8600) = true)

def env8601 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,17664,16777216,33554432,5377,23445584,16385,131153,1073741824,16876545,4294967296,256,4350047346,131072,33563272]

theorem envBound8601 : H12AffineFastState.Bounded env8601 := by
  intro p hp
  have h : env8601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8057_8601 : H12AffineEnvironment.transform 25 5377 env8057 = env8601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 5377 env8057 == env8601) = true)

theorem identity8601 : scanCanonicalize (H12AffineFastState.compose env8601 (packedSelected [35] rootPS)) = affineNative (2^(20+1) ^^^ 4097) := by decide +kernel

theorem selectedBound8601 : packedSelected [35] rootPS < 2^1333 := by decide +kernel

def env8602 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,4097,4194304,17664,16777216,33554432,5377,21352529,16385,131153,1073741824,16876545,4294967296,256,4350047346,131072,33563272]

theorem envBound8602 : H12AffineFastState.Bounded env8602 := by
  intro p hp
  have h : env8602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8601_8602 : H12AffineEnvironment.transform 20 4097 env8601 = env8602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env8601 == env8602) = true)

theorem identity8602 : scanCanonicalize (H12AffineFastState.compose env8602 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(24+1) ^^^ 8329) := by decide +kernel

theorem selectedBound8602 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env8603 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,4097,4194304,17664,16777216,8329,5377,21352529,16385,131153,1073741824,16876545,4294967296,256,4316484859,131072,513]

theorem envBound8603 : H12AffineFastState.Bounded env8603 := by
  intro p hp
  have h : env8603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8602_8603 : H12AffineEnvironment.transform 24 8329 env8602 = env8603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8329 env8602 == env8603) = true)

def env8604 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,524288,32768,4097,4194304,5456,16777216,8329,5377,21331969,4177,131153,1073741824,16876545,4294967296,256,4316464299,131072,513]

theorem envBound8604 : H12AffineFastState.Bounded env8604 := by
  intro p hp
  have h : env8604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8603_8604 : H12AffineEnvironment.transform 13 4176 env8603 = env8604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env8603 == env8604) = true)

theorem identity8604 : scanCanonicalize (H12AffineFastState.compose env8604 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(29+1) ^^^ 21629134) := by decide +kernel

theorem selectedBound8604 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env8605 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,524288,32768,4097,4194304,5456,16777216,8329,5377,21331969,4177,131153,21629134,16876545,4294967296,256,4316464299,131072,513]

theorem envBound8605 : H12AffineFastState.Bounded env8605 := by
  intro p hp
  have h : env8605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8604_8605 : H12AffineEnvironment.transform 29 21629134 env8604 = env8605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 21629134 env8604 == env8605) = true)

theorem identity8605 : scanCanonicalize (H12AffineFastState.compose env8605 (packedSelected [6,25] rootPS)) = affineNative (2^(23+1) ^^^ 230469) := by decide +kernel

theorem selectedBound8605 : packedSelected [6,25] rootPS < 2^1333 := by decide +kernel

def env8606 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,524288,32768,4097,4194304,5456,230469,8329,5377,4588612,4177,131153,4820107,131140,4294967296,256,4299915502,131072,513]

theorem envBound8606 : H12AffineFastState.Bounded env8606 := by
  intro p hp
  have h : env8606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8605_8606 : H12AffineEnvironment.transform 23 230469 env8605 = env8606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 230469 env8605 == env8606) = true)

theorem identity8606 : scanCanonicalize (H12AffineFastState.compose env8606 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(18+1) ^^^ 1024) := by decide +kernel

theorem selectedBound8606 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env8607 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1024,32768,4097,4194304,5456,230469,8329,5377,4588612,4177,131153,4294795,131140,4294967296,256,4299392238,131072,513]

theorem envBound8607 : H12AffineFastState.Bounded env8607 := by
  intro p hp
  have h : env8607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8606_8607 : H12AffineEnvironment.transform 18 1024 env8606 = env8607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env8606 == env8607) = true)

theorem identity8607 : scanCanonicalize (H12AffineFastState.compose env8607 (packedSelected [13,21] rootPS)) = affineNative (2^(31+1) ^^^ 4329688) := by decide +kernel

theorem selectedBound8607 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env8608 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1024,32768,4097,4194304,5456,230469,8329,5377,4588612,4177,131153,4294795,131140,4329688,256,103478,131072,513]

theorem envBound8608 : H12AffineFastState.Bounded env8608 := by
  intro p hp
  have h : env8608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8607_8608 : H12AffineEnvironment.transform 31 4329688 env8607 = env8608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 4329688 env8607 == env8608) = true)

def env8609 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,524288,32768,4097,4194304,5457,16777216,8329,5377,21331968,4176,131153,1073741824,16876545,4294967296,256,4316464298,131072,513]

theorem envBound8609 : H12AffineFastState.Bounded env8609 := by
  intro p hp
  have h : env8609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8603_8609 : H12AffineEnvironment.transform 13 4177 env8603 = env8609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env8603 == env8609) = true)

theorem identity8609 : scanCanonicalize (H12AffineFastState.compose env8609 (packedSelected [6,25] rootPS)) = affineNative (2^(29+1) ^^^ 4294795) := by decide +kernel

theorem selectedBound8609 : packedSelected [6,25] rootPS < 2^1333 := by decide +kernel

def env8610 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,524288,32768,4097,4194304,5457,16777216,8329,5377,21331968,4176,131153,4294795,16876545,4294967296,256,4316464298,131072,513]

theorem envBound8610 : H12AffineFastState.Bounded env8610 := by
  intro p hp
  have h : env8610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8609_8610 : H12AffineEnvironment.transform 29 4294795 env8609 = env8610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4294795 env8609 == env8610) = true)

def env8611 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,4096,262144,524288,32768,4097,4194304,5457,16777216,8329,5377,21331968,4176,4177,4294795,16876545,4294967296,256,4316464298,4096,513]

theorem envBound8611 : H12AffineFastState.Bounded env8611 := by
  intro p hp
  have h : env8611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8610_8611 : H12AffineEnvironment.transform 16 4096 env8610 = env8611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4096 env8610 == env8611) = true)

def env8612 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,65536,1344,262144,524288,32768,1345,4194304,17,16777216,8329,65,21331968,1296,1297,4294795,16876545,4294967296,256,4316464298,1344,513]

theorem envBound8612 : H12AffineFastState.Bounded env8612 := by
  intro p hp
  have h : env8612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8611_8612 : H12AffineEnvironment.transform 11 1344 env8611 = env8612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env8611 == env8612) = true)

theorem identity8612 : scanCanonicalize (H12AffineFastState.compose env8612 (packedSelected [0,4,7,9,16,20] rootPS)) = affineNative (2^(23+1) ^^^ 99213) := by decide +kernel

theorem selectedBound8612 : packedSelected [0,4,7,9,16,20] rootPS < 2^1333 := by decide +kernel

def env8613 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,65536,1344,262144,524288,32768,1345,4194304,17,99213,8329,65,4457357,1296,1297,4294795,1932,4294967296,256,4299786023,1344,513]

theorem envBound8613 : H12AffineFastState.Bounded env8613 := by
  intro p hp
  have h : env8613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8612_8613 : H12AffineEnvironment.transform 23 99213 env8612 = env8613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 99213 env8612 == env8613) = true)

theorem identity8613 : scanCanonicalize (H12AffineFastState.compose env8613 (packedSelected [4,16,22] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound8613 : packedSelected [4,16,22] rootPS < 2^1333 := by decide +kernel

def env8614 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1344,8192,1297,32768,65536,1344,262144,524288,32768,1345,4194304,17,98564,8329,65,4456708,1296,1297,4294795,1285,4294967296,256,4299785646,1344,136]

theorem envBound8614 : H12AffineFastState.Bounded env8614 := by
  intro p hp
  have h : env8614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8613_8614 : H12AffineEnvironment.transform 8 137 env8613 = env8614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env8613 == env8614) = true)

theorem identity8614 : scanCanonicalize (H12AffineFastState.compose env8614 (packedSelected [1,3,12,13,15,17] rootPS)) = affineNative (2^(17+1) ^^^ 43048) := by decide +kernel

theorem selectedBound8614 : packedSelected [1,3,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env8615 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1344,8192,1297,32768,65536,1344,43048,524288,32768,1345,4194304,17,98564,8329,65,4237612,1296,1297,4294795,1285,4294967296,256,4299785646,1344,136]

theorem envBound8615 : H12AffineFastState.Bounded env8615 := by
  intro p hp
  have h : env8615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8614_8615 : H12AffineEnvironment.transform 17 43048 env8614 = env8615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43048 env8614 == env8615) = true)

theorem identity8615 : scanCanonicalize (H12AffineFastState.compose env8615 (packedSelected [0,4,7,9,18,23] rootPS)) = affineNative (2^(15+1) ^^^ 33166) := by decide +kernel

theorem selectedBound8615 : packedSelected [0,4,7,9,18,23] rootPS < 2^1333 := by decide +kernel

def env8616 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1344,8192,1297,32768,33166,1344,43048,524288,32768,1345,4194304,17,138,8329,65,4237612,1296,1297,4196613,1285,4294967296,256,4299686944,1344,136]

theorem envBound8616 : H12AffineFastState.Bounded env8616 := by
  intro p hp
  have h : env8616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8615_8616 : H12AffineEnvironment.transform 15 33166 env8615 = env8616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33166 env8615 == env8616) = true)

def env8617 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1344,8192,1297,32768,33166,1344,43048,524288,32768,1345,41088,17,138,8329,65,2476,1296,1297,43397,1285,4294967296,256,4295533728,1344,136]

theorem envBound8617 : H12AffineFastState.Bounded env8617 := by
  intro p hp
  have h : env8617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8616_8617 : H12AffineEnvironment.transform 21 41088 env8616 = env8617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env8616 == env8617) = true)

theorem identity8617 : scanCanonicalize (H12AffineFastState.compose env8617 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 3458) := by decide +kernel

theorem selectedBound8617 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env8618 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1344,8192,1297,32768,33166,1344,43048,524288,32768,1345,41088,17,138,8329,65,2476,1296,1297,43397,1285,3458,256,567586,1344,136]

theorem envBound8618 : H12AffineFastState.Bounded env8618 := by
  intro p hp
  have h : env8618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8617_8618 : H12AffineEnvironment.transform 31 3458 env8617 = env8618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 3458 env8617 == env8618) = true)

theorem identity8618 : scanCanonicalize (H12AffineFastState.compose env8618 (packedSelected [3,5,10] rootPS)) = affineNative (2^(18+1) ^^^ 2262) := by decide +kernel

theorem selectedBound8618 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env8619 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1344,8192,1297,32768,33166,1344,43048,2262,32768,1345,41088,17,138,8329,65,2476,1296,1297,43397,1285,3458,256,41460,1344,136]

theorem envBound8619 : H12AffineFastState.Bounded env8619 := by
  intro p hp
  have h : env8619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8618_8619 : H12AffineEnvironment.transform 18 2262 env8618 = env8619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 2262 env8618 == env8619) = true)

def env8620 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1344,8192,1297,2184,2310,1344,8352,2262,2184,1345,10248,17,138,8329,65,2476,1296,1297,8461,1285,3458,256,10620,1344,136]

theorem envBound8620 : H12AffineFastState.Bounded env8620 := by
  intro p hp
  have h : env8620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8619_8620 : H12AffineEnvironment.transform 14 2184 env8619 = env8620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2184 env8619 == env8620) = true)

theorem identity8620 : scanCanonicalize (H12AffineFastState.compose env8620 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 2137) := by decide +kernel

theorem selectedBound8620 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8621 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1344,2137,1297,2184,2310,1344,2297,2262,2184,1345,81,17,138,2256,65,2476,1296,1297,2388,1285,3458,256,293,1344,136]

theorem envBound8621 : H12AffineFastState.Bounded env8621 := by
  intro p hp
  have h : env8621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8620_8621 : H12AffineEnvironment.transform 12 2137 env8620 = env8621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2137 env8620 == env8621) = true)

theorem identity8621 : scanCanonicalize (H12AffineFastState.compose env8621 (packedSelected [2,4] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound8621 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env8622 : List Nat := [2,4,8,16,32,64,128,85,137,1024,2048,1045,2137,1092,2184,2131,1045,2297,2262,2184,1044,81,17,138,2256,65,2297,1093,1092,2049,1104,3287,85,112,1045,136]

theorem envBound8622 : H12AffineFastState.Bounded env8622 := by
  intro p hp
  have h : env8622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8621_8622 : H12AffineEnvironment.transform 7 85 env8621 = env8622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env8621 == env8622) = true)

theorem identity8622 : scanCanonicalize (H12AffineFastState.compose env8622 (packedSelected [7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound8622 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env8623 : List Nat := [2,4,8,16,32,17,128,4,137,1024,2048,1045,2056,1045,2184,2050,1045,2216,2183,2184,1044,0,17,138,2177,16,2216,1044,1045,2049,1025,3206,4,33,1045,136]

theorem envBound8623 : H12AffineFastState.Bounded env8623 := by
  intro p hp
  have h : env8623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8622_8623 : H12AffineEnvironment.transform 5 17 env8622 = env8623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env8622 == env8623) = true)

theorem identity8623 : scanCanonicalize (H12AffineFastState.compose env8623 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1191) := by decide +kernel

theorem selectedBound8623 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8624 : List Nat := [2,4,8,16,32,17,128,4,137,1024,1191,1045,1199,1045,1071,1189,1045,1039,1056,1071,1044,0,17,138,1062,16,1039,1044,1045,1190,1025,33,4,33,1045,136]

theorem envBound8624 : H12AffineFastState.Bounded env8624 := by
  intro p hp
  have h : env8624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8623_8624 : H12AffineEnvironment.transform 10 1191 env8623 = env8624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1191 env8623 == env8624) = true)

theorem identity8624 : scanCanonicalize (H12AffineFastState.compose env8624 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound8624 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8625 : List Nat := [2,4,8,16,32,17,8,4,1,1024,1071,1045,1063,1045,1071,1069,1045,1039,1056,1071,1044,0,17,2,1062,16,1039,1044,1045,1070,1025,33,4,33,1045,0]

theorem envBound8625 : H12AffineFastState.Bounded env8625 := by
  intro p hp
  have h : env8625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8624_8625 : H12AffineEnvironment.transform 6 8 env8624 = env8625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env8624 == env8625) = true)

theorem identity8625 : scanCanonicalize (H12AffineFastState.compose env8625 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound8625 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env8626 : List Nat := [2,4,8,16,1,17,8,4,1,1024,1038,1045,1030,1045,1038,1036,1045,1039,1025,1038,1044,0,17,2,1031,16,1039,1044,1045,1039,1025,0,4,0,1045,0]

theorem envBound8626 : H12AffineFastState.Bounded env8626 := by
  intro p hp
  have h : env8626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8625_8626 : H12AffineEnvironment.transform 4 1 env8625 = env8626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env8625 == env8626) = true)

def leafEnv8626 : List Nat := [2,4,8,16,1,17,8,4,1,1024,1038,1045,1030,1045,1038,1036,1045,1039,1025,1038,1044,0,17,2,1025,1031,1,16,1039,1044,1045,1039,1025,0,4,0,5,1037,1045,0,0,1045,1]

def active8626 : List Nat := [0,1,2,3,9]

def tree8626 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood8626 : H12WitnessSearch.Good tree8626 := H12GlobalWitnessIndex.good

theorem leafIdentity8626 : H12AffineFastState.composeSystem env8626 rootObs = leafEnv8626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env8626 rootObs == leafEnv8626) = true)

theorem terminalChecked8626 : H12PackedTerminal.terminalCheckFast leafEnv8626 active8626 tree8626 = true := by decide +kernel

def env8627 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1344,8192,1297,2185,2311,1344,8353,2262,2185,1345,10249,17,138,8329,65,2476,1296,1297,8460,1285,3458,256,10621,1344,136]

theorem envBound8627 : H12AffineFastState.Bounded env8627 := by
  intro p hp
  have h : env8627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8619_8627 : H12AffineEnvironment.transform 14 2185 env8619 = env8627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2185 env8619 == env8627) = true)

theorem identity8627 : scanCanonicalize (H12AffineFastState.compose env8627 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound8627 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8628 : List Nat := [2,4,8,16,32,64,128,84,137,1024,2048,1044,8192,1093,2185,2131,1044,8353,2262,2185,1045,10249,17,138,8329,65,2296,1092,1093,8280,1105,3286,84,10281,1044,136]

theorem envBound8628 : H12AffineFastState.Bounded env8628 := by
  intro p hp
  have h : env8628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8627_8628 : H12AffineEnvironment.transform 7 84 env8627 = env8628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env8627 == env8628) = true)

theorem identity8628 : scanCanonicalize (H12AffineFastState.compose env8628 (packedSelected [2,4] rootPS)) = affineNative (2^(12+1) ^^^ 2209) := by decide +kernel

theorem selectedBound8628 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env8629 : List Nat := [2,4,8,16,32,64,128,84,137,1024,2048,1044,2209,1093,2185,2131,1044,2048,2262,2185,1045,168,17,138,2088,65,2296,1092,1093,2297,1105,3286,84,136,1044,136]

theorem envBound8629 : H12AffineFastState.Bounded env8629 := by
  intro p hp
  have h : env8629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8628_8629 : H12AffineEnvironment.transform 12 2209 env8628 = env8629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2209 env8628 == env8629) = true)

theorem identity8629 : scanCanonicalize (H12AffineFastState.compose env8629 (packedSelected [7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound8629 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env8630 : List Nat := [2,4,8,16,32,16,128,4,137,1024,2048,1044,2209,1045,2185,2051,1044,2048,2182,2185,1045,168,17,138,2088,17,2216,1044,1045,2217,1025,3206,4,136,1044,136]

theorem envBound8630 : H12AffineFastState.Bounded env8630 := by
  intro p hp
  have h : env8630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8629_8630 : H12AffineEnvironment.transform 5 16 env8629 = env8630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env8629 == env8630) = true)

theorem identity8630 : scanCanonicalize (H12AffineFastState.compose env8630 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1070) := by decide +kernel

theorem selectedBound8630 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8631 : List Nat := [2,4,8,16,32,16,128,4,137,1024,1070,1044,1167,1045,1191,1069,1044,1070,1192,1191,1045,168,17,138,1030,17,1158,1044,1045,1159,1025,168,4,136,1044,136]

theorem envBound8631 : H12AffineFastState.Bounded env8631 := by
  intro p hp
  have h : env8631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8630_8631 : H12AffineEnvironment.transform 10 1070 env8630 = env8631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1070 env8630 == env8631) = true)

theorem identity8631 : scanCanonicalize (H12AffineFastState.compose env8631 (packedSelected [2,3] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound8631 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env8632 : List Nat := [2,4,8,16,32,16,41,4,32,1024,1070,1044,1062,1045,1038,1069,1044,1070,1025,1038,1045,1,17,35,1030,17,1071,1044,1045,1070,1025,1,4,33,1044,33]

theorem envBound8632 : H12AffineFastState.Bounded env8632 := by
  intro p hp
  have h : env8632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8631_8632 : H12AffineEnvironment.transform 6 41 env8631 = env8632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env8631 == env8632) = true)

def env8633 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1344,8192,1297,32768,33166,1344,43048,524288,32768,1345,41089,17,138,8329,65,2477,1296,1297,43396,1285,4294967296,256,4295533729,1344,136]

theorem envBound8633 : H12AffineFastState.Bounded env8633 := by
  intro p hp
  have h : env8633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8616_8633 : H12AffineEnvironment.transform 21 41089 env8616 = env8633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env8616 == env8633) = true)

theorem identity8633 : scanCanonicalize (H12AffineFastState.compose env8633 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 44174) := by decide +kernel

theorem selectedBound8633 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env8634 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1344,8192,1297,32768,33166,1344,43048,524288,32768,1345,41089,17,138,8329,65,2477,1296,1297,43396,1285,44174,256,526383,1344,136]

theorem envBound8634 : H12AffineFastState.Bounded env8634 := by
  intro p hp
  have h : env8634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8633_8634 : H12AffineEnvironment.transform 31 44174 env8633 = env8634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 44174 env8633 == env8634) = true)

theorem identity8634 : scanCanonicalize (H12AffineFastState.compose env8634 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 11738) := by decide +kernel

theorem selectedBound8634 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env8635 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1344,8192,1297,11738,11348,1344,1522,524288,11738,1345,3419,17,138,8329,65,2477,1296,1297,1118,1285,340,256,526383,1344,136]

theorem envBound8635 : H12AffineFastState.Bounded env8635 := by
  intro p hp
  have h : env8635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8634_8635 : H12AffineEnvironment.transform 14 11738 env8634 = env8635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 11738 env8634 == env8635) = true)

def env8636 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1344,2316,1297,1238,1368,1344,1522,524288,1238,1345,3419,17,138,2437,65,2477,1296,1297,1118,1285,340,256,526383,1344,136]

theorem envBound8636 : H12AffineFastState.Bounded env8636 := by
  intro p hp
  have h : env8636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8635_8636 : H12AffineEnvironment.transform 12 2316 env8635 = env8636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2316 env8635 == env8636) = true)

theorem identity8636 : scanCanonicalize (H12AffineFastState.compose env8636 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1290) := by decide +kernel

theorem selectedBound8636 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8637 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1290,1344,1030,1297,1238,1368,1344,1522,524288,1238,1345,81,17,138,1167,65,1191,1296,1297,1118,1285,340,256,525605,1344,136]

theorem envBound8637 : H12AffineFastState.Bounded env8637 := by
  intro p hp
  have h : env8637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8636_8637 : H12AffineEnvironment.transform 10 1290 env8636 = env8637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1290 env8636 == env8637) = true)

theorem identity8637 : scanCanonicalize (H12AffineFastState.compose env8637 (packedSelected [2,4,7] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound8637 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env8638 : List Nat := [2,4,8,16,32,64,128,4,137,1024,1038,1092,1030,1045,1238,1116,1092,1270,524288,1238,1093,81,17,138,1167,65,1191,1044,1045,1118,1025,80,4,525345,1092,136]

theorem envBound8638 : H12AffineFastState.Bounded env8638 := by
  intro p hp
  have h : env8638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8637_8638 : H12AffineEnvironment.transform 7 4 env8637 = env8638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env8637 == env8638) = true)

theorem identity8638 : scanCanonicalize (H12AffineFastState.compose env8638 (packedSelected [3,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound8638 : packedSelected [3,4,5] rootPS < 2^1333 := by decide +kernel

def env8639 : List Nat := [2,4,8,16,32,17,128,4,137,1024,1038,1045,1030,1045,1159,1037,1045,1191,524288,1159,1044,0,17,138,1167,16,1191,1044,1045,1039,1025,1,4,525345,1045,136]

theorem envBound8639 : H12AffineFastState.Bounded env8639 := by
  intro p hp
  have h : env8639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8638_8639 : H12AffineEnvironment.transform 5 17 env8638 = env8639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env8638 == env8639) = true)

theorem identity8639 : scanCanonicalize (H12AffineFastState.compose env8639 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound8639 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8640 : List Nat := [2,4,8,16,32,17,40,4,33,1024,1038,1045,1030,1045,1071,1037,1045,1039,524288,1071,1044,0,17,34,1063,16,1039,1044,1045,1039,1025,1,4,525345,1045,32]

theorem envBound8640 : H12AffineFastState.Bounded env8640 := by
  intro p hp
  have h : env8640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8639_8640 : H12AffineEnvironment.transform 6 40 env8639 = env8640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env8639 == env8640) = true)

def env8641 : List Nat := [2,4,8,16,32,17,40,4,33,1024,1038,1045,1030,1045,1071,1037,1045,1039,1024,1071,1044,0,17,34,1063,16,1039,1044,1045,1039,1025,1,4,33,1045,32]

theorem envBound8641 : H12AffineFastState.Bounded env8641 := by
  intro p hp
  have h : env8641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8640_8641 : H12AffineEnvironment.transform 18 1024 env8640 = env8641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env8640 == env8641) = true)

theorem identity8641 : scanCanonicalize (H12AffineFastState.compose env8641 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound8641 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8642 : List Nat := [2,4,8,16,1,17,9,4,0,1024,1038,1045,1030,1045,1038,1037,1045,1039,1024,1038,1044,0,17,3,1030,16,1039,1044,1045,1039,1025,1,4,0,1045,1]

theorem envBound8642 : H12AffineFastState.Bounded env8642 := by
  intro p hp
  have h : env8642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8641_8642 : H12AffineEnvironment.transform 4 1 env8641 = env8642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env8641 == env8642) = true)

def leafEnv8642 : List Nat := [2,4,8,16,1,17,9,4,0,1024,1038,1045,1030,1045,1038,1037,1045,1039,1024,1038,1044,0,17,3,1024,1030,1,16,1039,1044,1045,1039,1025,1,4,0,5,1037,1045,1,0,1045,1]

def active8642 : List Nat := [0,1,2,3,9]

def tree8642 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood8642 : H12WitnessSearch.Good tree8642 := H12GlobalWitnessIndex.good

theorem leafIdentity8642 : H12AffineFastState.composeSystem env8642 rootObs = leafEnv8642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env8642 rootObs == leafEnv8642) = true)

theorem terminalChecked8642 : H12PackedTerminal.terminalCheckFast leafEnv8642 active8642 tree8642 = true := by decide +kernel

def env8643 : List Nat := [2,4,8,16,32,17,40,4,33,1024,1038,1045,1030,1045,1071,1037,1045,1039,1025,1071,1044,0,17,34,1063,16,1039,1044,1045,1039,1025,1,4,32,1045,32]

theorem envBound8643 : H12AffineFastState.Bounded env8643 := by
  intro p hp
  have h : env8643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8640_8643 : H12AffineEnvironment.transform 18 1025 env8640 = env8643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env8640 == env8643) = true)

def leafEnv8643 : List Nat := [2,4,8,16,32,17,40,4,33,1024,1038,1045,1030,1045,1071,1037,1045,1039,1025,1071,1044,0,17,34,1025,1063,1,16,1039,1044,1045,1039,1025,1,4,32,5,1068,1045,32,0,1045,1]

def active8643 : List Nat := [0,1,2,3,4,9]

def tree8643 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood8643 : H12WitnessSearch.Good tree8643 := H12GlobalWitnessIndex.good

theorem leafIdentity8643 : H12AffineFastState.composeSystem env8643 rootObs = leafEnv8643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env8643 rootObs == leafEnv8643) = true)

theorem terminalChecked8643 : H12PackedTerminal.terminalCheckFast leafEnv8643 active8643 tree8643 = true := by decide +kernel

def env8644 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1344,2317,1297,1239,1369,1344,1522,524288,1239,1345,3419,17,138,2436,65,2477,1296,1297,1118,1285,340,256,526383,1344,136]

theorem envBound8644 : H12AffineFastState.Bounded env8644 := by
  intro p hp
  have h : env8644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8635_8644 : H12AffineEnvironment.transform 12 2317 env8635 = env8644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2317 env8635 == env8644) = true)

theorem identity8644 : scanCanonicalize (H12AffineFastState.compose env8644 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound8644 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8645 : List Nat := [2,4,8,16,32,64,128,84,137,1024,2048,1044,2137,1093,1239,1037,1044,1190,524288,1239,1045,3087,17,138,2256,65,2297,1092,1093,1118,1105,0,84,526383,1044,136]

theorem envBound8645 : H12AffineFastState.Bounded env8645 := by
  intro p hp
  have h : env8645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8644_8645 : H12AffineEnvironment.transform 7 84 env8644 = env8645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env8644 == env8645) = true)

theorem identity8645 : scanCanonicalize (H12AffineFastState.compose env8645 (packedSelected [2,4,7] rootPS)) = affineNative (2^(10+1) ^^^ 1270) := by decide +kernel

theorem selectedBound8645 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env8646 : List Nat := [2,4,8,16,32,64,128,84,137,1024,1270,1044,1199,1093,1239,1037,1044,1190,524288,1239,1045,249,17,138,1062,65,1039,1092,1093,1118,1105,0,84,525529,1044,136]

theorem envBound8646 : H12AffineFastState.Bounded env8646 := by
  intro p hp
  have h : env8646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8645_8646 : H12AffineEnvironment.transform 10 1270 env8645 = env8646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1270 env8645 == env8646) = true)

theorem identity8646 : scanCanonicalize (H12AffineFastState.compose env8646 (packedSelected [5,12] rootPS)) = affineNative (2^(6+1) ^^^ 121) := by decide +kernel

theorem selectedBound8646 : packedSelected [5,12] rootPS < 2^1333 := by decide +kernel

def env8647 : List Nat := [2,4,8,16,32,64,121,84,112,1024,1039,1044,1110,1093,1070,1037,1044,1119,524288,1070,1045,0,17,115,1062,65,1039,1092,1093,1118,1105,0,84,525344,1044,113]

theorem envBound8647 : H12AffineFastState.Bounded env8647 := by
  intro p hp
  have h : env8647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8646_8647 : H12AffineEnvironment.transform 6 121 env8646 = env8647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env8646 == env8647) = true)

theorem identity8647 : scanCanonicalize (H12AffineFastState.compose env8647 (packedSelected [2,4] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound8647 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env8648 : List Nat := [2,4,8,16,32,16,41,4,32,1024,1039,1044,1030,1045,1070,1037,1044,1039,524288,1070,1045,0,17,35,1062,17,1039,1044,1045,1038,1025,0,4,525344,1044,33]

theorem envBound8648 : H12AffineFastState.Bounded env8648 := by
  intro p hp
  have h : env8648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8647_8648 : H12AffineEnvironment.transform 5 16 env8647 = env8648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env8647 == env8648) = true)

theorem identity8648 : scanCanonicalize (H12AffineFastState.compose env8648 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound8648 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8649 : List Nat := [2,4,8,16,0,16,9,4,0,1024,1039,1044,1030,1045,1038,1037,1044,1039,524288,1038,1045,0,17,3,1030,17,1039,1044,1045,1038,1025,0,4,525312,1044,1]

theorem envBound8649 : H12AffineFastState.Bounded env8649 := by
  intro p hp
  have h : env8649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8648_8649 : H12AffineEnvironment.transform 4 0 env8648 = env8649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env8648 == env8649) = true)

def leafEnv8649 : List Nat := [2,4,8,16,0,16,9,4,0,1024,1039,1044,1030,1045,1038,1037,1044,1039,524288,1038,1045,0,17,3,524288,1030,1,17,1039,1044,1045,1038,1025,0,4,525312,5,1037,1044,1,0,1045,1]

def active8649 : List Nat := [0,1,2,3,9,18]

def tree8649 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood8649 : H12WitnessSearch.Good tree8649 := H12GlobalWitnessIndex.good

theorem leafIdentity8649 : H12AffineFastState.composeSystem env8649 rootObs = leafEnv8649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env8649 rootObs == leafEnv8649) = true)

theorem terminalChecked8649 : H12PackedTerminal.terminalCheckFast leafEnv8649 active8649 tree8649 = true := by decide +kernel

def env8650 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,65536,1345,262144,524288,32768,1344,4194304,16,16777216,8329,64,21331968,1297,1296,4294795,16876545,4294967296,256,4316464298,1345,513]

theorem envBound8650 : H12AffineFastState.Bounded env8650 := by
  intro p hp
  have h : env8650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8611_8650 : H12AffineEnvironment.transform 11 1345 env8611 = env8650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env8611 == env8650) = true)

theorem identity8650 : scanCanonicalize (H12AffineFastState.compose env8650 (packedSelected [0,4,7,9,16,20] rootPS)) = affineNative (2^(23+1) ^^^ 99293) := by decide +kernel

theorem selectedBound8650 : packedSelected [0,4,7,9,16,20] rootPS < 2^1333 := by decide +kernel

def env8651 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,65536,1345,262144,524288,32768,1344,4194304,16,99293,8329,64,4457437,1297,1296,4294795,2012,4294967296,256,4299786103,1345,513]

theorem envBound8651 : H12AffineFastState.Bounded env8651 := by
  intro p hp
  have h : env8651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8650_8651 : H12AffineEnvironment.transform 23 99293 env8650 = env8651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 99293 env8650 == env8651) = true)

theorem identity8651 : scanCanonicalize (H12AffineFastState.compose env8651 (packedSelected [4,16,22] rootPS)) = affineNative (2^(18+1) ^^^ 1753) := by decide +kernel

theorem selectedBound8651 : packedSelected [4,16,22] rootPS < 2^1333 := by decide +kernel

def env8652 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,65536,1345,262144,1753,32768,1344,4194304,16,99293,8329,64,4457437,1297,1296,4294795,2012,4294967296,256,4299260334,1345,513]

theorem envBound8652 : H12AffineFastState.Bounded env8652 := by
  intro p hp
  have h : env8652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8651_8652 : H12AffineEnvironment.transform 18 1753 env8651 = env8652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1753 env8651 == env8652) = true)

theorem identity8652 : scanCanonicalize (H12AffineFastState.compose env8652 (packedSelected [4,9,16] rootPS)) = affineNative (2^(8+1) ^^^ 216) := by decide +kernel

theorem selectedBound8652 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env8653 : List Nat := [2,4,8,16,32,64,128,256,216,1024,2048,1345,8192,1296,32768,65536,1345,262144,1025,32768,1344,4194304,16,98565,8329,64,4456709,1297,1296,4294795,1284,4294967296,256,4299260334,1345,217]

theorem envBound8653 : H12AffineFastState.Bounded env8653 := by
  intro p hp
  have h : env8653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8652_8653 : H12AffineEnvironment.transform 8 216 env8652 = env8653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env8652 == env8653) = true)

theorem identity8653 : scanCanonicalize (H12AffineFastState.compose env8653 (packedSelected [3,5,10] rootPS)) = affineNative (2^(31+1) ^^^ 98599) := by decide +kernel

theorem selectedBound8653 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env8654 : List Nat := [2,4,8,16,32,64,128,256,216,1024,2048,1345,8192,1296,32768,65536,1345,262144,1025,32768,1344,4194304,16,98565,8329,64,4456709,1297,1296,4294795,1284,98599,256,4194441,1345,217]

theorem envBound8654 : H12AffineFastState.Bounded env8654 := by
  intro p hp
  have h : env8654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8653_8654 : H12AffineEnvironment.transform 31 98599 env8653 = env8654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 98599 env8653 == env8654) = true)

theorem identity8654 : scanCanonicalize (H12AffineFastState.compose env8654 (packedSelected [1,12,13] rootPS)) = affineNative (2^(14+1) ^^^ 2058) := by decide +kernel

theorem selectedBound8654 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env8655 : List Nat := [2,4,8,16,32,64,128,256,216,1024,2048,1345,8192,1296,2058,65536,1345,262144,1025,2058,1344,4194304,16,67855,8329,64,4456709,1297,1296,4259969,1284,67885,256,4194441,1345,217]

theorem envBound8655 : H12AffineFastState.Bounded env8655 := by
  intro p hp
  have h : env8655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8654_8655 : H12AffineEnvironment.transform 14 2058 env8654 = env8655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2058 env8654 == env8655) = true)

theorem identity8655 : scanCanonicalize (H12AffineFastState.compose env8655 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 2436) := by decide +kernel

theorem selectedBound8655 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env8656 : List Nat := [2,4,8,16,32,64,128,256,216,1024,2048,1345,8192,1296,2058,2436,1345,262144,1025,2058,1344,4194304,16,139,8329,64,4456709,1297,1296,4196613,1284,169,256,4194441,1345,217]

theorem envBound8656 : H12AffineFastState.Bounded env8656 := by
  intro p hp
  have h : env8656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8655_8656 : H12AffineEnvironment.transform 15 2436 env8655 = env8656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2436 env8655 == env8656) = true)

theorem identity8656 : scanCanonicalize (H12AffineFastState.compose env8656 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 2420) := by decide +kernel

theorem selectedBound8656 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env8657 : List Nat := [2,4,8,16,32,64,128,256,216,1024,2048,1345,8192,1296,2058,2436,1345,2420,1025,2058,1344,4194304,16,139,8329,64,4196465,1297,1296,4196613,1284,169,256,4194441,1345,217]

theorem envBound8657 : H12AffineFastState.Bounded env8657 := by
  intro p hp
  have h : env8657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8656_8657 : H12AffineEnvironment.transform 17 2420 env8656 = env8657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2420 env8656 == env8657) = true)

theorem identity8657 : scanCanonicalize (H12AffineFastState.compose env8657 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(21+1) ^^^ 113) := by decide +kernel

theorem selectedBound8657 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env8658 : List Nat := [2,4,8,16,32,64,128,256,216,1024,2048,1345,8192,1296,2058,2436,1345,2420,1025,2058,1344,113,16,139,8329,64,2048,1297,1296,2420,1284,169,256,248,1345,217]

theorem envBound8658 : H12AffineFastState.Bounded env8658 := by
  intro p hp
  have h : env8658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8657_8658 : H12AffineEnvironment.transform 21 113 env8657 = env8658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 113 env8657 == env8658) = true)

theorem identity8658 : scanCanonicalize (H12AffineFastState.compose env8658 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 90) := by decide +kernel

theorem selectedBound8658 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env8659 : List Nat := [2,4,8,16,32,64,128,256,216,1024,90,1345,8192,1296,80,478,1345,302,1025,80,1344,113,16,139,8329,64,90,1297,1296,302,1284,169,256,248,1345,217]

theorem envBound8659 : H12AffineFastState.Bounded env8659 := by
  intro p hp
  have h : env8659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8658_8659 : H12AffineEnvironment.transform 10 90 env8658 = env8659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 90 env8658 == env8659) = true)

theorem identity8659 : scanCanonicalize (H12AffineFastState.compose env8659 (packedSelected [0,1,4,5,6,12] rootPS)) = affineNative (2^(9+1) ^^^ 369) := by decide +kernel

theorem selectedBound8659 : packedSelected [0,1,4,5,6,12] rootPS < 2^1333 := by decide +kernel

def env8660 : List Nat := [2,4,8,16,32,64,128,256,216,369,90,48,8192,97,80,478,48,302,368,80,49,113,16,139,8329,64,90,96,97,302,117,169,256,248,48,217]

theorem envBound8660 : H12AffineFastState.Bounded env8660 := by
  intro p hp
  have h : env8660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8659_8660 : H12AffineEnvironment.transform 9 369 env8659 = env8660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 369 env8659 == env8660) = true)

theorem identity8660 : scanCanonicalize (H12AffineFastState.compose env8660 (packedSelected [0,4,5,6,17] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound8660 : packedSelected [0,4,5,6,17] rootPS < 2^1333 := by decide +kernel

def env8661 : List Nat := [2,4,8,16,32,64,128,256,216,369,90,48,348,97,80,478,48,302,368,80,49,113,16,139,469,64,90,96,97,302,117,169,256,248,48,217]

theorem envBound8661 : H12AffineFastState.Bounded env8661 := by
  intro p hp
  have h : env8661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8660_8661 : H12AffineEnvironment.transform 12 348 env8660 = env8661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env8660 == env8661) = true)

theorem identity8661 : scanCanonicalize (H12AffineFastState.compose env8661 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 104) := by decide +kernel

theorem selectedBound8661 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env8662 : List Nat := [2,4,8,16,32,64,104,256,48,369,90,48,348,97,80,310,48,302,368,80,49,113,16,99,317,64,90,96,97,302,117,65,256,16,48,49]

theorem envBound8662 : H12AffineFastState.Bounded env8662 := by
  intro p hp
  have h : env8662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8661_8662 : H12AffineEnvironment.transform 6 104 env8661 = env8662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 104 env8661 == env8662) = true)

def env8663 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,4097,262144,524288,32768,4097,4194304,5457,16777216,8329,5377,21331968,4176,4176,4294795,16876545,4294967296,256,4316464298,4097,513]

theorem envBound8663 : H12AffineFastState.Bounded env8663 := by
  intro p hp
  have h : env8663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8610_8663 : H12AffineEnvironment.transform 16 4097 env8610 = env8663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4097 env8610 == env8663) = true)

def env8664 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,65536,1345,262144,524288,32768,1345,4194304,17,16777216,8329,65,21331968,1296,1296,4294795,16876545,4294967296,256,4316464298,1345,513]

theorem envBound8664 : H12AffineFastState.Bounded env8664 := by
  intro p hp
  have h : env8664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8663_8664 : H12AffineEnvironment.transform 11 1344 env8663 = env8664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env8663 == env8664) = true)

theorem identity8664 : scanCanonicalize (H12AffineFastState.compose env8664 (packedSelected [0,4,7,9,16,20] rootPS)) = affineNative (2^(8+1) ^^^ 217) := by decide +kernel

theorem selectedBound8664 : packedSelected [0,4,7,9,16,20] rootPS < 2^1333 := by decide +kernel

def env8665 : List Nat := [2,4,8,16,32,64,128,256,217,1024,2048,1344,8192,1297,32768,65536,1345,262144,524288,32768,1345,4194304,17,16777216,8329,65,21331968,1296,1296,4294795,16876545,4294967296,256,4316464298,1345,216]

theorem envBound8665 : H12AffineFastState.Bounded env8665 := by
  intro p hp
  have h : env8665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8664_8665 : H12AffineEnvironment.transform 8 217 env8664 = env8665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env8664 == env8665) = true)

theorem identity8665 : scanCanonicalize (H12AffineFastState.compose env8665 (packedSelected [4,16,22] rootPS)) = affineNative (2^(23+1) ^^^ 623876) := by decide +kernel

theorem selectedBound8665 : packedSelected [4,16,22] rootPS < 2^1333 := by decide +kernel

def env8666 : List Nat := [2,4,8,16,32,64,128,256,217,1024,2048,1344,8192,1297,32768,65536,1345,262144,524288,32768,1345,4194304,17,623876,8329,65,4982020,1296,1296,4294795,524549,4294967296,256,4299260334,1345,216]

theorem envBound8666 : H12AffineFastState.Bounded env8666 := by
  intro p hp
  have h : env8666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8665_8666 : H12AffineEnvironment.transform 23 623876 env8665 = env8666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 623876 env8665 == env8666) = true)

theorem identity8666 : scanCanonicalize (H12AffineFastState.compose env8666 (packedSelected [4,9,16] rootPS)) = affineNative (2^(18+1) ^^^ 1025) := by decide +kernel

theorem selectedBound8666 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env8667 : List Nat := [2,4,8,16,32,64,128,256,217,1024,2048,1344,8192,1297,32768,65536,1345,262144,1025,32768,1345,4194304,17,98565,8329,65,4456709,1296,1296,4294795,1284,4294967296,256,4299260334,1345,216]

theorem envBound8667 : H12AffineFastState.Bounded env8667 := by
  intro p hp
  have h : env8667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8666_8667 : H12AffineEnvironment.transform 18 1025 env8666 = env8667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env8666 == env8667) = true)

theorem identity8667 : scanCanonicalize (H12AffineFastState.compose env8667 (packedSelected [3,5,10] rootPS)) = affineNative (2^(31+1) ^^^ 98598) := by decide +kernel

theorem selectedBound8667 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env8668 : List Nat := [2,4,8,16,32,64,128,256,217,1024,2048,1344,8192,1297,32768,65536,1345,262144,1025,32768,1345,4194304,17,98565,8329,65,4456709,1296,1296,4294795,1284,98598,256,4194440,1345,216]

theorem envBound8668 : H12AffineFastState.Bounded env8668 := by
  intro p hp
  have h : env8668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8667_8668 : H12AffineEnvironment.transform 31 98598 env8667 = env8668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 98598 env8667 == env8668) = true)

theorem identity8668 : scanCanonicalize (H12AffineFastState.compose env8668 (packedSelected [1,12,13] rootPS)) = affineNative (2^(14+1) ^^^ 2138) := by decide +kernel

theorem selectedBound8668 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env8669 : List Nat := [2,4,8,16,32,64,128,256,217,1024,2048,1344,8192,1297,2138,65536,1345,262144,1025,2138,1345,4194304,17,67935,8329,65,4456709,1296,1296,4260049,1284,67964,256,4194440,1345,216]

theorem envBound8669 : H12AffineFastState.Bounded env8669 := by
  intro p hp
  have h : env8669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8668_8669 : H12AffineEnvironment.transform 14 2138 env8668 = env8669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2138 env8668 == env8669) = true)

theorem identity8669 : scanCanonicalize (H12AffineFastState.compose env8669 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 2516) := by decide +kernel

theorem selectedBound8669 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env8670 : List Nat := [2,4,8,16,32,64,128,256,217,1024,2048,1344,8192,1297,2138,2516,1345,262144,1025,2138,1345,4194304,17,139,8329,65,4456709,1296,1296,4196613,1284,168,256,4194440,1345,216]

theorem envBound8670 : H12AffineFastState.Bounded env8670 := by
  intro p hp
  have h : env8670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8669_8670 : H12AffineEnvironment.transform 15 2516 env8669 = env8670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2516 env8669 == env8670) = true)

theorem identity8670 : scanCanonicalize (H12AffineFastState.compose env8670 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound8670 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env8671 : List Nat := [2,4,8,16,32,64,128,256,217,1024,2048,1344,8192,1297,2138,2516,1345,2421,1025,2138,1345,4194304,17,139,8329,65,4196464,1296,1296,4196613,1284,168,256,4194440,1345,216]

theorem envBound8671 : H12AffineFastState.Bounded env8671 := by
  intro p hp
  have h : env8671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8670_8671 : H12AffineEnvironment.transform 17 2421 env8670 = env8671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env8670 == env8671) = true)

theorem identity8671 : scanCanonicalize (H12AffineFastState.compose env8671 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(21+1) ^^^ 112) := by decide +kernel

theorem selectedBound8671 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env8672 : List Nat := [2,4,8,16,32,64,128,256,217,1024,2048,1344,8192,1297,2138,2516,1345,2421,1025,2138,1345,112,17,139,8329,65,2048,1296,1296,2421,1284,168,256,248,1345,216]

theorem envBound8672 : H12AffineFastState.Bounded env8672 := by
  intro p hp
  have h : env8672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8671_8672 : H12AffineEnvironment.transform 21 112 env8671 = env8672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 112 env8671 == env8672) = true)

theorem identity8672 : scanCanonicalize (H12AffineFastState.compose env8672 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound8672 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env8673 : List Nat := [2,4,8,16,32,64,128,256,217,1024,11,1344,8192,1297,81,479,1345,382,1025,81,1345,112,17,139,8329,65,11,1296,1296,382,1284,168,256,248,1345,216]

theorem envBound8673 : H12AffineFastState.Bounded env8673 := by
  intro p hp
  have h : env8673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8672_8673 : H12AffineEnvironment.transform 10 11 env8672 = env8673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env8672 == env8673) = true)

theorem identity8673 : scanCanonicalize (H12AffineFastState.compose env8673 (packedSelected [0,1,4,5,6,12] rootPS)) = affineNative (2^(12+1) ^^^ 1148) := by decide +kernel

theorem selectedBound8673 : packedSelected [0,1,4,5,6,12] rootPS < 2^1333 := by decide +kernel

def env8674 : List Nat := [2,4,8,16,32,64,128,256,217,1024,11,1344,1148,1297,81,479,1345,382,1025,81,1345,112,17,139,1269,65,11,1296,1296,382,1284,168,256,248,1345,216]

theorem envBound8674 : H12AffineFastState.Bounded env8674 := by
  intro p hp
  have h : env8674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8673_8674 : H12AffineEnvironment.transform 12 1148 env8673 = env8674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1148 env8673 == env8674) = true)

theorem identity8674 : scanCanonicalize (H12AffineFastState.compose env8674 (packedSelected [0,4,5,6,17] rootPS)) = affineNative (2^(9+1) ^^^ 289) := by decide +kernel

theorem selectedBound8674 : packedSelected [0,4,5,6,17] rootPS < 2^1333 := by decide +kernel

def env8675 : List Nat := [2,4,8,16,32,64,128,256,217,289,11,97,349,48,81,479,96,382,288,81,96,112,17,139,468,65,11,49,49,382,37,168,256,248,96,216]

theorem envBound8675 : H12AffineFastState.Bounded env8675 := by
  intro p hp
  have h : env8675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8674_8675 : H12AffineEnvironment.transform 9 289 env8674 = env8675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 289 env8674 == env8675) = true)

theorem identity8675 : scanCanonicalize (H12AffineFastState.compose env8675 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 104) := by decide +kernel

theorem selectedBound8675 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env8676 : List Nat := [2,4,8,16,32,64,104,256,49,289,11,97,349,48,81,311,96,382,288,81,96,112,17,99,316,65,11,49,49,382,37,64,256,16,96,48]

theorem envBound8676 : H12AffineFastState.Bounded env8676 := by
  intro p hp
  have h : env8676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8675_8676 : H12AffineEnvironment.transform 6 104 env8675 = env8676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 104 env8675 == env8676) = true)

def env8677 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,65536,1344,262144,524288,32768,1344,4194304,16,16777216,8329,64,21331968,1297,1297,4294795,16876545,4294967296,256,4316464298,1344,513]

theorem envBound8677 : H12AffineFastState.Bounded env8677 := by
  intro p hp
  have h : env8677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8663_8677 : H12AffineEnvironment.transform 11 1345 env8663 = env8677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env8663 == env8677) = true)

theorem identity8677 : scanCanonicalize (H12AffineFastState.compose env8677 (packedSelected [0,4,7,9,16,20] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound8677 : packedSelected [0,4,7,9,16,20] rootPS < 2^1333 := by decide +kernel

def env8678 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,8192,1296,32768,65536,1344,262144,524288,32768,1344,4194304,16,16777216,8329,64,21331968,1297,1297,4294795,16876545,4294967296,256,4316464298,1344,136]

theorem envBound8678 : H12AffineFastState.Bounded env8678 := by
  intro p hp
  have h : env8678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8677_8678 : H12AffineEnvironment.transform 8 137 env8677 = env8678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env8677 == env8678) = true)

theorem identity8678 : scanCanonicalize (H12AffineFastState.compose env8678 (packedSelected [4,16,22] rootPS)) = affineNative (2^(23+1) ^^^ 98564) := by decide +kernel

theorem selectedBound8678 : packedSelected [4,16,22] rootPS < 2^1333 := by decide +kernel

def env8679 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,8192,1296,32768,65536,1344,262144,524288,32768,1344,4194304,16,98564,8329,64,4456708,1297,1297,4294795,1285,4294967296,256,4299785646,1344,136]

theorem envBound8679 : H12AffineFastState.Bounded env8679 := by
  intro p hp
  have h : env8679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8678_8679 : H12AffineEnvironment.transform 23 98564 env8678 = env8679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98564 env8678 == env8679) = true)

theorem identity8679 : scanCanonicalize (H12AffineFastState.compose env8679 (packedSelected [1,3,12,13,15,17] rootPS)) = affineNative (2^(17+1) ^^^ 43048) := by decide +kernel

theorem selectedBound8679 : packedSelected [1,3,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env8680 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,8192,1296,32768,65536,1344,43048,524288,32768,1344,4194304,16,98564,8329,64,4237612,1297,1297,4294795,1285,4294967296,256,4299785646,1344,136]

theorem envBound8680 : H12AffineFastState.Bounded env8680 := by
  intro p hp
  have h : env8680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8679_8680 : H12AffineEnvironment.transform 17 43048 env8679 = env8680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43048 env8679 == env8680) = true)

theorem identity8680 : scanCanonicalize (H12AffineFastState.compose env8680 (packedSelected [0,4,7,9,18,23] rootPS)) = affineNative (2^(15+1) ^^^ 33166) := by decide +kernel

theorem selectedBound8680 : packedSelected [0,4,7,9,18,23] rootPS < 2^1333 := by decide +kernel

def env8681 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,8192,1296,32768,33166,1344,43048,524288,32768,1344,4194304,16,138,8329,64,4237612,1297,1297,4196613,1285,4294967296,256,4299686944,1344,136]

theorem envBound8681 : H12AffineFastState.Bounded env8681 := by
  intro p hp
  have h : env8681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8680_8681 : H12AffineEnvironment.transform 15 33166 env8680 = env8681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33166 env8680 == env8681) = true)

def env8682 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,8192,1296,32768,33166,1344,43048,524288,32768,1344,41088,16,138,8329,64,2476,1297,1297,43397,1285,4294967296,256,4295533728,1344,136]

theorem envBound8682 : H12AffineFastState.Bounded env8682 := by
  intro p hp
  have h : env8682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8681_8682 : H12AffineEnvironment.transform 21 41088 env8681 = env8682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env8681 == env8682) = true)

theorem identity8682 : scanCanonicalize (H12AffineFastState.compose env8682 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 3459) := by decide +kernel

theorem selectedBound8682 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env8683 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,8192,1296,32768,33166,1344,43048,524288,32768,1344,41088,16,138,8329,64,2476,1297,1297,43397,1285,3459,256,567587,1344,136]

theorem envBound8683 : H12AffineFastState.Bounded env8683 := by
  intro p hp
  have h : env8683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8682_8683 : H12AffineEnvironment.transform 31 3459 env8682 = env8683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 3459 env8682 == env8683) = true)

theorem identity8683 : scanCanonicalize (H12AffineFastState.compose env8683 (packedSelected [3,5,10] rootPS)) = affineNative (2^(18+1) ^^^ 2263) := by decide +kernel

theorem selectedBound8683 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env8684 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,8192,1296,32768,33166,1344,43048,2263,32768,1344,41088,16,138,8329,64,2476,1297,1297,43397,1285,3459,256,41460,1344,136]

theorem envBound8684 : H12AffineFastState.Bounded env8684 := by
  intro p hp
  have h : env8684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8683_8684 : H12AffineEnvironment.transform 18 2263 env8683 = env8684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 2263 env8683 == env8684) = true)

def env8685 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,8192,1296,2184,2310,1344,8352,2263,2184,1344,10248,16,138,8329,64,2476,1297,1297,8461,1285,3459,256,10620,1344,136]

theorem envBound8685 : H12AffineFastState.Bounded env8685 := by
  intro p hp
  have h : env8685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8684_8685 : H12AffineEnvironment.transform 14 2184 env8684 = env8685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2184 env8684 == env8685) = true)

theorem identity8685 : scanCanonicalize (H12AffineFastState.compose env8685 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 2136) := by decide +kernel

theorem selectedBound8685 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8686 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,2136,1296,2184,2310,1344,2296,2263,2184,1344,80,16,138,2257,64,2476,1297,1297,2389,1285,3459,256,292,1344,136]

theorem envBound8686 : H12AffineFastState.Bounded env8686 := by
  intro p hp
  have h : env8686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8685_8686 : H12AffineEnvironment.transform 12 2136 env8685 = env8686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2136 env8685 == env8686) = true)

theorem identity8686 : scanCanonicalize (H12AffineFastState.compose env8686 (packedSelected [2,4] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound8686 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env8687 : List Nat := [2,4,8,16,32,64,128,84,137,1024,2048,1045,2136,1092,2184,2130,1044,2296,2263,2184,1044,80,16,138,2257,64,2296,1093,1093,2049,1105,3287,84,112,1044,136]

theorem envBound8687 : H12AffineFastState.Bounded env8687 := by
  intro p hp
  have h : env8687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8686_8687 : H12AffineEnvironment.transform 7 84 env8686 = env8687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env8686 == env8687) = true)

theorem identity8687 : scanCanonicalize (H12AffineFastState.compose env8687 (packedSelected [7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound8687 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env8688 : List Nat := [2,4,8,16,32,16,128,4,137,1024,2048,1045,2056,1044,2184,2050,1044,2216,2183,2184,1044,0,16,138,2177,16,2216,1045,1045,2049,1025,3207,4,32,1044,136]

theorem envBound8688 : H12AffineFastState.Bounded env8688 := by
  intro p hp
  have h : env8688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8687_8688 : H12AffineEnvironment.transform 5 16 env8687 = env8688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env8687 == env8688) = true)

theorem identity8688 : scanCanonicalize (H12AffineFastState.compose env8688 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1071) := by decide +kernel

theorem selectedBound8688 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8689 : List Nat := [2,4,8,16,32,16,128,4,137,1024,1071,1045,1063,1044,1191,1069,1044,1159,1192,1191,1044,0,16,138,1198,16,1159,1045,1045,1070,1025,168,4,32,1044,136]

theorem envBound8689 : H12AffineFastState.Bounded env8689 := by
  intro p hp
  have h : env8689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8688_8689 : H12AffineEnvironment.transform 10 1071 env8688 = env8689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1071 env8688 == env8689) = true)

theorem identity8689 : scanCanonicalize (H12AffineFastState.compose env8689 (packedSelected [5] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound8689 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env8690 : List Nat := [2,4,8,16,32,16,41,4,32,1024,1071,1045,1063,1044,1038,1069,1044,1070,1025,1038,1044,0,16,35,1031,16,1070,1045,1045,1070,1025,1,4,32,1044,33]

theorem envBound8690 : H12AffineFastState.Bounded env8690 := by
  intro p hp
  have h : env8690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8689_8690 : H12AffineEnvironment.transform 6 41 env8689 = env8690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env8689 == env8690) = true)

def leafEnv8690 : List Nat := [2,4,8,16,32,16,41,4,32,1024,1071,1045,1063,1044,1038,1069,1044,1070,1025,1038,1044,0,16,35,1025,1031,1,16,1070,1045,1045,1070,1025,1,4,32,5,1037,1044,33,0,1045,1]

def active8690 : List Nat := [0,1,2,3,4,9]

def tree8690 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood8690 : H12WitnessSearch.Good tree8690 := H12GlobalWitnessIndex.good

theorem leafIdentity8690 : H12AffineFastState.composeSystem env8690 rootObs = leafEnv8690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env8690 rootObs == leafEnv8690) = true)

theorem terminalChecked8690 : H12PackedTerminal.terminalCheckFast leafEnv8690 active8690 tree8690 = true := by decide +kernel

def env8691 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,8192,1296,2185,2311,1344,8353,2263,2185,1344,10249,16,138,8329,64,2476,1297,1297,8460,1285,3459,256,10621,1344,136]

theorem envBound8691 : H12AffineFastState.Bounded env8691 := by
  intro p hp
  have h : env8691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8684_8691 : H12AffineEnvironment.transform 14 2185 env8684 = env8691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2185 env8684 == env8691) = true)

theorem identity8691 : scanCanonicalize (H12AffineFastState.compose env8691 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound8691 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8692 : List Nat := [2,4,8,16,32,64,128,85,137,1024,2048,1044,8192,1093,2185,2130,1045,8353,2263,2185,1045,10249,16,138,8329,64,2297,1092,1092,8281,1104,3286,85,10280,1045,136]

theorem envBound8692 : H12AffineFastState.Bounded env8692 := by
  intro p hp
  have h : env8692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8691_8692 : H12AffineEnvironment.transform 7 85 env8691 = env8692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env8691 == env8692) = true)

theorem identity8692 : scanCanonicalize (H12AffineFastState.compose env8692 (packedSelected [2,4] rootPS)) = affineNative (2^(12+1) ^^^ 2209) := by decide +kernel

theorem selectedBound8692 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env8693 : List Nat := [2,4,8,16,32,64,128,85,137,1024,2048,1044,2209,1093,2185,2130,1045,2048,2263,2185,1045,168,16,138,2088,64,2297,1092,1092,2296,1104,3286,85,137,1045,136]

theorem envBound8693 : H12AffineFastState.Bounded env8693 := by
  intro p hp
  have h : env8693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8692_8693 : H12AffineEnvironment.transform 12 2209 env8692 = env8693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2209 env8692 == env8693) = true)

theorem identity8693 : scanCanonicalize (H12AffineFastState.compose env8693 (packedSelected [7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound8693 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env8694 : List Nat := [2,4,8,16,32,17,128,4,137,1024,2048,1044,2209,1044,2185,2051,1045,2048,2182,2185,1045,168,16,138,2088,17,2216,1045,1045,2217,1025,3207,4,137,1045,136]

theorem envBound8694 : H12AffineFastState.Bounded env8694 := by
  intro p hp
  have h : env8694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8693_8694 : H12AffineEnvironment.transform 5 17 env8693 = env8694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env8693 == env8694) = true)

theorem identity8694 : scanCanonicalize (H12AffineFastState.compose env8694 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1038) := by decide +kernel

theorem selectedBound8694 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8695 : List Nat := [2,4,8,16,32,17,128,4,137,1024,1038,1044,1199,1044,1159,1037,1045,1038,1160,1159,1045,168,16,138,1062,17,1190,1045,1045,1191,1025,137,4,137,1045,136]

theorem envBound8695 : H12AffineFastState.Bounded env8695 := by
  intro p hp
  have h : env8695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8694_8695 : H12AffineEnvironment.transform 10 1038 env8694 = env8695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1038 env8694 == env8695) = true)

theorem identity8695 : scanCanonicalize (H12AffineFastState.compose env8695 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound8695 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8696 : List Nat := [2,4,8,16,1,17,128,4,137,1024,1038,1044,1166,1044,1159,1037,1045,1038,1160,1159,1045,137,16,138,1031,17,1159,1045,1045,1158,1025,137,4,137,1045,136]

theorem envBound8696 : H12AffineFastState.Bounded env8696 := by
  intro p hp
  have h : env8696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8695_8696 : H12AffineEnvironment.transform 4 1 env8695 = env8696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env8695 == env8696) = true)

theorem identity8696 : scanCanonicalize (H12AffineFastState.compose env8696 (packedSelected [5] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound8696 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env8697 : List Nat := [2,4,8,16,1,17,9,4,0,1024,1038,1044,1031,1044,1038,1037,1045,1038,1025,1038,1045,0,16,3,1031,17,1038,1045,1045,1039,1025,0,4,0,1045,1]

theorem envBound8697 : H12AffineFastState.Bounded env8697 := by
  intro p hp
  have h : env8697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8696_8697 : H12AffineEnvironment.transform 6 9 env8696 = env8697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env8696 == env8697) = true)

def leafEnv8697 : List Nat := [2,4,8,16,1,17,9,4,0,1024,1038,1044,1031,1044,1038,1037,1045,1038,1025,1038,1045,0,16,3,1025,1031,1,17,1038,1045,1045,1039,1025,0,4,0,5,1037,1045,1,0,1045,1]

def active8697 : List Nat := [0,1,2,3,9]

def tree8697 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood8697 : H12WitnessSearch.Good tree8697 := H12GlobalWitnessIndex.good

theorem leafIdentity8697 : H12AffineFastState.composeSystem env8697 rootObs = leafEnv8697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env8697 rootObs == leafEnv8697) = true)

theorem terminalChecked8697 : H12PackedTerminal.terminalCheckFast leafEnv8697 active8697 tree8697 = true := by decide +kernel

def env8698 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,8192,1296,32768,33166,1344,43048,524288,32768,1344,41089,16,138,8329,64,2477,1297,1297,43396,1285,4294967296,256,4295533729,1344,136]

theorem envBound8698 : H12AffineFastState.Bounded env8698 := by
  intro p hp
  have h : env8698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8681_8698 : H12AffineEnvironment.transform 21 41089 env8681 = env8698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env8681 == env8698) = true)

theorem identity8698 : scanCanonicalize (H12AffineFastState.compose env8698 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 44175) := by decide +kernel

theorem selectedBound8698 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env8699 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,8192,1296,32768,33166,1344,43048,524288,32768,1344,41089,16,138,8329,64,2477,1297,1297,43396,1285,44175,256,526382,1344,136]

theorem envBound8699 : H12AffineFastState.Bounded env8699 := by
  intro p hp
  have h : env8699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8698_8699 : H12AffineEnvironment.transform 31 44175 env8698 = env8699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 44175 env8698 == env8699) = true)

theorem identity8699 : scanCanonicalize (H12AffineFastState.compose env8699 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 11739) := by decide +kernel

theorem selectedBound8699 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env8700 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,8192,1296,11739,11349,1344,1523,524288,11739,1344,3418,16,138,8329,64,2477,1297,1297,1119,1285,340,256,526382,1344,136]

theorem envBound8700 : H12AffineFastState.Bounded env8700 := by
  intro p hp
  have h : env8700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8699_8700 : H12AffineEnvironment.transform 14 11739 env8699 = env8700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 11739 env8699 == env8700) = true)

def env8701 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,2316,1296,1239,1369,1344,1523,524288,1239,1344,3418,16,138,2437,64,2477,1297,1297,1119,1285,340,256,526382,1344,136]

theorem envBound8701 : H12AffineFastState.Bounded env8701 := by
  intro p hp
  have h : env8701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8700_8701 : H12AffineEnvironment.transform 12 2316 env8700 = env8701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2316 env8700 == env8701) = true)

theorem identity8701 : scanCanonicalize (H12AffineFastState.compose env8701 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1290) := by decide +kernel

theorem selectedBound8701 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8702 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1290,1345,1030,1296,1239,1369,1344,1523,524288,1239,1344,80,16,138,1167,64,1191,1297,1297,1119,1285,340,256,525604,1344,136]

theorem envBound8702 : H12AffineFastState.Bounded env8702 := by
  intro p hp
  have h : env8702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8701_8702 : H12AffineEnvironment.transform 10 1290 env8701 = env8702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1290 env8701 == env8702) = true)

theorem identity8702 : scanCanonicalize (H12AffineFastState.compose env8702 (packedSelected [2,4,7] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound8702 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env8703 : List Nat := [2,4,8,16,32,64,128,4,137,1024,1038,1093,1030,1044,1239,1117,1092,1271,524288,1239,1092,80,16,138,1167,64,1191,1045,1045,1119,1025,80,4,525344,1092,136]

theorem envBound8703 : H12AffineFastState.Bounded env8703 := by
  intro p hp
  have h : env8703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8702_8703 : H12AffineEnvironment.transform 7 4 env8702 = env8703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env8702 == env8703) = true)

theorem identity8703 : scanCanonicalize (H12AffineFastState.compose env8703 (packedSelected [3,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound8703 : packedSelected [3,4,5] rootPS < 2^1333 := by decide +kernel

def env8704 : List Nat := [2,4,8,16,32,64,40,4,33,1024,1038,1093,1030,1044,1151,1117,1092,1119,524288,1151,1092,80,16,34,1063,64,1039,1045,1045,1119,1025,80,4,525344,1092,32]

theorem envBound8704 : H12AffineFastState.Bounded env8704 := by
  intro p hp
  have h : env8704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8703_8704 : H12AffineEnvironment.transform 6 40 env8703 = env8704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env8703 == env8704) = true)

theorem identity8704 : scanCanonicalize (H12AffineFastState.compose env8704 (packedSelected [1,13] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound8704 : packedSelected [1,13] rootPS < 2^1333 := by decide +kernel

def env8705 : List Nat := [2,4,8,16,32,16,40,4,33,1024,1038,1045,1030,1044,1071,1037,1044,1039,524288,1071,1044,0,16,34,1063,16,1039,1045,1045,1039,1025,0,4,525344,1044,32]

theorem envBound8705 : H12AffineFastState.Bounded env8705 := by
  intro p hp
  have h : env8705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8704_8705 : H12AffineEnvironment.transform 5 16 env8704 = env8705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env8704 == env8705) = true)

theorem identity8705 : scanCanonicalize (H12AffineFastState.compose env8705 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound8705 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8706 : List Nat := [2,4,8,16,1,16,9,4,0,1024,1038,1045,1030,1044,1038,1037,1044,1039,524288,1038,1044,0,16,3,1030,16,1039,1045,1045,1039,1025,0,4,525313,1044,1]

theorem envBound8706 : H12AffineFastState.Bounded env8706 := by
  intro p hp
  have h : env8706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8705_8706 : H12AffineEnvironment.transform 4 1 env8705 = env8706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env8705 == env8706) = true)

def leafEnv8706 : List Nat := [2,4,8,16,1,16,9,4,0,1024,1038,1045,1030,1044,1038,1037,1044,1039,524288,1038,1044,0,16,3,524288,1030,1,16,1039,1045,1045,1039,1025,0,4,525313,5,1037,1044,1,0,1045,1]

def active8706 : List Nat := [0,1,2,3,9,18]

def tree8706 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood8706 : H12WitnessSearch.Good tree8706 := H12GlobalWitnessIndex.good

theorem leafIdentity8706 : H12AffineFastState.composeSystem env8706 rootObs = leafEnv8706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env8706 rootObs == leafEnv8706) = true)

theorem terminalChecked8706 : H12PackedTerminal.terminalCheckFast leafEnv8706 active8706 tree8706 = true := by decide +kernel

def env8707 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,2317,1296,1238,1368,1344,1523,524288,1238,1344,3418,16,138,2436,64,2477,1297,1297,1119,1285,340,256,526382,1344,136]

theorem envBound8707 : H12AffineFastState.Bounded env8707 := by
  intro p hp
  have h : env8707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8700_8707 : H12AffineEnvironment.transform 12 2317 env8700 = env8707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2317 env8700 == env8707) = true)

theorem identity8707 : scanCanonicalize (H12AffineFastState.compose env8707 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound8707 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8708 : List Nat := [2,4,8,16,32,64,128,85,137,1024,2048,1044,2136,1093,1238,1037,1045,1190,524288,1238,1045,3087,16,138,2257,64,2296,1092,1092,1119,1104,1,85,526382,1045,136]

theorem envBound8708 : H12AffineFastState.Bounded env8708 := by
  intro p hp
  have h : env8708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8707_8708 : H12AffineEnvironment.transform 7 85 env8707 = env8708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env8707 == env8708) = true)

theorem identity8708 : scanCanonicalize (H12AffineFastState.compose env8708 (packedSelected [2,4,7] rootPS)) = affineNative (2^(10+1) ^^^ 1271) := by decide +kernel

theorem selectedBound8708 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env8709 : List Nat := [2,4,8,16,32,64,128,85,137,1024,1271,1044,1199,1093,1238,1037,1045,1190,524288,1238,1045,248,16,138,1062,64,1039,1092,1092,1119,1104,1,85,525529,1045,136]

theorem envBound8709 : H12AffineFastState.Bounded env8709 := by
  intro p hp
  have h : env8709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8708_8709 : H12AffineEnvironment.transform 10 1271 env8708 = env8709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1271 env8708 == env8709) = true)

theorem identity8709 : scanCanonicalize (H12AffineFastState.compose env8709 (packedSelected [5,12] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound8709 : packedSelected [5,12] rootPS < 2^1333 := by decide +kernel

def env8710 : List Nat := [2,4,8,16,32,64,120,85,113,1024,1039,1044,1111,1093,1070,1037,1045,1118,524288,1070,1045,0,16,114,1062,64,1039,1092,1092,1119,1104,1,85,525345,1045,112]

theorem envBound8710 : H12AffineFastState.Bounded env8710 := by
  intro p hp
  have h : env8710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8709_8710 : H12AffineEnvironment.transform 6 120 env8709 = env8710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env8709 == env8710) = true)

theorem identity8710 : scanCanonicalize (H12AffineFastState.compose env8710 (packedSelected [2,4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound8710 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env8711 : List Nat := [2,4,8,16,32,17,41,4,32,1024,1039,1044,1030,1044,1070,1037,1045,1039,524288,1070,1045,0,16,35,1062,17,1039,1045,1045,1038,1025,1,4,525345,1045,33]

theorem envBound8711 : H12AffineFastState.Bounded env8711 := by
  intro p hp
  have h : env8711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8710_8711 : H12AffineEnvironment.transform 5 17 env8710 = env8711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env8710 == env8711) = true)

def env8712 : List Nat := [2,4,8,16,32,17,41,4,32,1024,1039,1044,1030,1044,1070,1037,1045,1039,1024,1070,1045,0,16,35,1062,17,1039,1045,1045,1038,1025,1,4,33,1045,33]

theorem envBound8712 : H12AffineFastState.Bounded env8712 := by
  intro p hp
  have h : env8712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8711_8712 : H12AffineEnvironment.transform 18 1024 env8711 = env8712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env8711 == env8712) = true)

theorem identity8712 : scanCanonicalize (H12AffineFastState.compose env8712 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound8712 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8713 : List Nat := [2,4,8,16,0,17,9,4,0,1024,1039,1044,1030,1044,1038,1037,1045,1039,1024,1038,1045,0,16,3,1030,17,1039,1045,1045,1038,1025,1,4,1,1045,1]

theorem envBound8713 : H12AffineFastState.Bounded env8713 := by
  intro p hp
  have h : env8713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8712_8713 : H12AffineEnvironment.transform 4 0 env8712 = env8713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env8712 == env8713) = true)

def leafEnv8713 : List Nat := [2,4,8,16,0,17,9,4,0,1024,1039,1044,1030,1044,1038,1037,1045,1039,1024,1038,1045,0,16,3,1024,1030,1,17,1039,1045,1045,1038,1025,1,4,1,5,1037,1045,1,0,1045,1]

def active8713 : List Nat := [0,1,2,3,9]

def tree8713 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood8713 : H12WitnessSearch.Good tree8713 := H12GlobalWitnessIndex.good

theorem leafIdentity8713 : H12AffineFastState.composeSystem env8713 rootObs = leafEnv8713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env8713 rootObs == leafEnv8713) = true)

theorem terminalChecked8713 : H12PackedTerminal.terminalCheckFast leafEnv8713 active8713 tree8713 = true := by decide +kernel

def env8714 : List Nat := [2,4,8,16,32,17,41,4,32,1024,1039,1044,1030,1044,1070,1037,1045,1039,1025,1070,1045,0,16,35,1062,17,1039,1045,1045,1038,1025,1,4,32,1045,33]

theorem envBound8714 : H12AffineFastState.Bounded env8714 := by
  intro p hp
  have h : env8714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8711_8714 : H12AffineEnvironment.transform 18 1025 env8711 = env8714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env8711 == env8714) = true)

def leafEnv8714 : List Nat := [2,4,8,16,32,17,41,4,32,1024,1039,1044,1030,1044,1070,1037,1045,1039,1025,1070,1045,0,16,35,1025,1062,1,17,1039,1045,1045,1038,1025,1,4,32,5,1069,1045,33,0,1045,1]

def active8714 : List Nat := [0,1,2,3,4,9]

def tree8714 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood8714 : H12WitnessSearch.Good tree8714 := H12GlobalWitnessIndex.good

theorem leafIdentity8714 : H12AffineFastState.composeSystem env8714 rootObs = leafEnv8714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env8714 rootObs == leafEnv8714) = true)

theorem terminalChecked8714 : H12PackedTerminal.terminalCheckFast leafEnv8714 active8714 tree8714 = true := by decide +kernel

def env8715 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,17664,16777216,33554432,67108864,134217728,67130625,536870912,1073741824,553878609,4294967296,537002320,4417151347,34359738368,33563272]

theorem envBound8715 : H12AffineFastState.Bounded env8715 := by
  intro p hp
  have h : env8715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6394_8715 : H12AffineEnvironment.transform 27 67130625 env6394 = env8715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 67130625 env6394 == env8715) = true)

def env8716 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,17664,16777216,33554432,67108864,134217728,67130625,536870912,1073741824,553878609,4294967296,537002320,4417151347,694534144,33563272]

theorem envBound8716 : H12AffineFastState.Bounded env8716 := by
  intro p hp
  have h : env8716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8715_8716 : H12AffineEnvironment.transform 34 694534144 env8715 = env8716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 694534144 env8715 == env8716) = true)

def env8717 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,17664,16777216,33554432,67108864,134217728,67130625,157794304,1073741824,140788817,4294967296,157663568,4417151347,131072,33563272]

theorem envBound8717 : H12AffineFastState.Bounded env8717 := by
  intro p hp
  have h : env8717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8716_8717 : H12AffineEnvironment.transform 28 157794304 env8716 = env8717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 28 157794304 env8716 == env8717) = true)

theorem identity8717 : scanCanonicalize (H12AffineFastState.compose env8717 (packedSelected [14] rootPS)) = affineNative (2^(26+1) ^^^ 90689552) := by decide +kernel

theorem selectedBound8717 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env8718 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,17664,16777216,33554432,67108864,90689552,67130625,67112976,1073741824,84120641,4294967296,67244352,4417151347,131072,33563272]

theorem envBound8718 : H12AffineFastState.Bounded env8718 := by
  intro p hp
  have h : env8718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8717_8718 : H12AffineEnvironment.transform 26 90689552 env8717 = env8718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 90689552 env8717 == env8718) = true)

def env8719 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,17664,16777216,33554432,135232,23445584,148801,131152,1073741824,16876545,4294967296,256,4350177587,131072,33563272]

theorem envBound8719 : H12AffineFastState.Bounded env8719 := by
  intro p hp
  have h : env8719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8718_8719 : H12AffineEnvironment.transform 25 135232 env8718 = env8719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 135232 env8718 == env8719) = true)

def env8720 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,4096,4194304,17664,16777216,33554432,135232,21352528,148801,131152,1073741824,16876545,4294967296,256,4350177587,131072,33563272]

theorem envBound8720 : H12AffineFastState.Bounded env8720 := by
  intro p hp
  have h : env8720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8719_8720 : H12AffineEnvironment.transform 20 4096 env8719 = env8720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env8719 == env8720) = true)

theorem identity8720 : scanCanonicalize (H12AffineFastState.compose env8720 (packedSelected [35] rootPS)) = affineNative (2^(16+1) ^^^ 1344) := by decide +kernel

theorem selectedBound8720 : packedSelected [35] rootPS < 2^1333 := by decide +kernel

def env8721 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,524288,32768,4096,4194304,17664,16777216,33554432,5376,21352528,16385,1296,1073741824,16876545,4294967296,256,4350047347,1344,33563272]

theorem envBound8721 : H12AffineFastState.Bounded env8721 := by
  intro p hp
  have h : env8721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8720_8721 : H12AffineEnvironment.transform 16 1344 env8720 = env8721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env8720 == env8721) = true)

theorem identity8721 : scanCanonicalize (H12AffineFastState.compose env8721 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(24+1) ^^^ 8329) := by decide +kernel

theorem selectedBound8721 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env8722 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,524288,32768,4096,4194304,17664,16777216,8329,5376,21352528,16385,1296,1073741824,16876545,4294967296,256,4316484858,1344,513]

theorem envBound8722 : H12AffineFastState.Bounded env8722 := by
  intro p hp
  have h : env8722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8721_8722 : H12AffineEnvironment.transform 24 8329 env8721 = env8722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8329 env8721 == env8722) = true)

theorem identity8722 : scanCanonicalize (H12AffineFastState.compose env8722 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(23+1) ^^^ 644437) := by decide +kernel

theorem selectedBound8722 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env8723 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,524288,32768,4096,4194304,17664,644437,8329,5376,4982021,16385,1296,1073741824,545108,4294967296,256,4299260335,1344,513]

theorem envBound8723 : H12AffineFastState.Bounded env8723 := by
  intro p hp
  have h : env8723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8722_8723 : H12AffineEnvironment.transform 23 644437 env8722 = env8723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 644437 env8722 == env8723) = true)

theorem identity8723 : scanCanonicalize (H12AffineFastState.compose env8723 (packedSelected [4,9,16] rootPS)) = affineNative (2^(29+1) ^^^ 4840666) := by decide +kernel

theorem selectedBound8723 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env8724 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,524288,32768,4096,4194304,17664,644437,8329,5376,4982021,16385,1296,4840666,545108,4294967296,256,4299260335,1344,513]

theorem envBound8724 : H12AffineFastState.Bounded env8724 := by
  intro p hp
  have h : env8724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8723_8724 : H12AffineEnvironment.transform 29 4840666 env8723 = env8724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4840666 env8723 == env8724) = true)

theorem identity8724 : scanCanonicalize (H12AffineFastState.compose env8724 (packedSelected [0,1,3,5,7,8,9,10,19,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 4176) := by decide +kernel

theorem selectedBound8724 : packedSelected [0,1,3,5,7,8,9,10,19,20,22] rootPS < 2^1333 := by decide +kernel

def env8725 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,1344,262144,524288,32768,4096,4194304,5456,623877,8329,5376,4982021,4177,1296,4820106,524548,4294967296,256,4299260335,1344,513]

theorem envBound8725 : H12AffineFastState.Bounded env8725 := by
  intro p hp
  have h : env8725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8724_8725 : H12AffineEnvironment.transform 13 4176 env8724 = env8725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env8724 == env8725) = true)

theorem identity8725 : scanCanonicalize (H12AffineFastState.compose env8725 (packedSelected [6,25] rootPS)) = affineNative (2^(18+1) ^^^ 1025) := by decide +kernel

theorem selectedBound8725 : packedSelected [6,25] rootPS < 2^1333 := by decide +kernel

def env8726 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,1344,262144,1025,32768,4096,4194304,5456,98564,8329,5376,4456708,4177,1296,4294795,1285,4294967296,256,4299260335,1344,513]

theorem envBound8726 : H12AffineFastState.Bounded env8726 := by
  intro p hp
  have h : env8726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8725_8726 : H12AffineEnvironment.transform 18 1025 env8725 = env8726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env8725 == env8726) = true)

theorem identity8726 : scanCanonicalize (H12AffineFastState.compose env8726 (packedSelected [3,5,10] rootPS)) = affineNative (2^(31+1) ^^^ 99327) := by decide +kernel

theorem selectedBound8726 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env8727 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,1344,262144,1025,32768,4096,4194304,5456,98564,8329,5376,4456708,4177,1296,4294795,1285,99327,256,4194896,1344,513]

theorem envBound8727 : H12AffineFastState.Bounded env8727 := by
  intro p hp
  have h : env8727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8726_8727 : H12AffineEnvironment.transform 31 99327 env8726 = env8727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 99327 env8726 == env8727) = true)

theorem identity8727 : scanCanonicalize (H12AffineFastState.compose env8727 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 81471) := by decide +kernel

theorem selectedBound8727 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env8728 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,1344,81471,1025,32768,4096,4194304,5456,98564,8329,5376,4276027,4177,1296,4294795,1285,99327,256,4194896,1344,513]

theorem envBound8728 : H12AffineFastState.Bounded env8728 := by
  intro p hp
  have h : env8728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8727_8728 : H12AffineEnvironment.transform 17 81471 env8727 = env8728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 81471 env8727 == env8728) = true)

theorem identity8728 : scanCanonicalize (H12AffineFastState.compose env8728 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(14+1) ^^^ 13972) := by decide +kernel

theorem selectedBound8728 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env8729 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,13972,65536,1344,81471,1025,13972,4096,4194304,5456,79760,8329,5376,4276027,4177,1296,4275743,1285,79211,256,4194896,1344,513]

theorem envBound8729 : H12AffineFastState.Bounded env8729 := by
  intro p hp
  have h : env8729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8728_8729 : H12AffineEnvironment.transform 14 13972 env8728 = env8729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13972 env8728 == env8729) = true)

theorem identity8729 : scanCanonicalize (H12AffineFastState.compose env8729 (packedSelected [0,7,20] rootPS)) = affineNative (2^(11+1) ^^^ 1944) := by decide +kernel

theorem selectedBound8729 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env8730 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1944,8192,1992,8460,65536,1344,76199,1025,8460,1944,4194304,712,73736,8329,664,4270243,1993,1296,4270471,1285,74483,256,4194896,1344,513]

theorem envBound8730 : H12AffineFastState.Bounded env8730 := by
  intro p hp
  have h : env8730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8729_8730 : H12AffineEnvironment.transform 11 1944 env8729 = env8730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1944 env8729 == env8730) = true)

theorem identity8730 : scanCanonicalize (H12AffineFastState.compose env8730 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 1954) := by decide +kernel

theorem selectedBound8730 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env8731 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1954,1944,8192,1992,8460,65536,1344,75269,1025,8460,1944,4194304,712,73736,8329,664,4269825,1993,1296,4269605,1285,74483,256,4194896,1344,513]

theorem envBound8731 : H12AffineFastState.Bounded env8731 := by
  intro p hp
  have h : env8731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8730_8731 : H12AffineEnvironment.transform 10 1954 env8730 = env8731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1954 env8730 == env8731) = true)

theorem identity8731 : scanCanonicalize (H12AffineFastState.compose env8731 (packedSelected [3,8,12,21] rootPS)) = affineNative (2^(21+1) ^^^ 74283) := by decide +kernel

theorem selectedBound8731 : packedSelected [3,8,12,21] rootPS < 2^1333 := by decide +kernel

def env8732 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1954,1944,8192,1992,8460,65536,1344,75269,1025,8460,1944,74283,712,73736,8329,664,1322,1993,1296,1038,1285,74483,256,73851,1344,513]

theorem envBound8732 : H12AffineFastState.Bounded env8732 := by
  intro p hp
  have h : env8732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8731_8732 : H12AffineEnvironment.transform 21 74283 env8731 = env8732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 74283 env8731 == env8732) = true)

def env8733 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,4097,4194304,17664,16777216,33554432,135232,21352529,148801,131152,1073741824,16876545,4294967296,256,4350177587,131072,33563272]

theorem envBound8733 : H12AffineFastState.Bounded env8733 := by
  intro p hp
  have h : env8733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8719_8733 : H12AffineEnvironment.transform 20 4097 env8719 = env8733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env8719 == env8733) = true)

def env8734 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,17664,16777216,33554432,135233,23445585,148800,131153,1073741824,16876544,4294967296,257,4350177586,131072,33563272]

theorem envBound8734 : H12AffineFastState.Bounded env8734 := by
  intro p hp
  have h : env8734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8718_8734 : H12AffineEnvironment.transform 25 135233 env8718 = env8734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 135233 env8718 == env8734) = true)

def env8735 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,4096,4194304,17664,16777216,33554432,135233,21352529,148800,131153,1073741824,16876544,4294967296,257,4350177586,131072,33563272]

theorem envBound8735 : H12AffineFastState.Bounded env8735 := by
  intro p hp
  have h : env8735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8734_8735 : H12AffineEnvironment.transform 20 4096 env8734 = env8735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env8734 == env8735) = true)

theorem identity8735 : scanCanonicalize (H12AffineFastState.compose env8735 (packedSelected [35] rootPS)) = affineNative (2^(23+1) ^^^ 98565) := by decide +kernel

theorem selectedBound8735 : packedSelected [35] rootPS < 2^1333 := by decide +kernel

def env8736 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,4096,4194304,17664,98565,33554432,135233,4477268,148800,131153,1073741824,1285,4294967296,257,4333498423,131072,33563272]

theorem envBound8736 : H12AffineFastState.Bounded env8736 := by
  intro p hp
  have h : env8736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8735_8736 : H12AffineEnvironment.transform 23 98565 env8735 = env8736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98565 env8735 == env8736) = true)

theorem identity8736 : scanCanonicalize (H12AffineFastState.compose env8736 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(24+1) ^^^ 140745) := by decide +kernel

theorem selectedBound8736 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env8737 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,4096,4194304,17664,98565,140745,135233,4477268,148800,131153,1073741824,1285,4294967296,257,4299806206,131072,132929]

theorem envBound8737 : H12AffineFastState.Bounded env8737 := by
  intro p hp
  have h : env8737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8736_8737 : H12AffineEnvironment.transform 24 140745 env8736 = env8737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 140745 env8736 == env8737) = true)

theorem identity8737 : scanCanonicalize (H12AffineFastState.compose env8737 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 1344) := by decide +kernel

theorem selectedBound8737 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env8738 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,524288,32768,4096,4194304,17664,98565,8329,5377,4477268,16384,1297,1073741824,1285,4294967296,257,4299806206,1344,513]

theorem envBound8738 : H12AffineFastState.Bounded env8738 := by
  intro p hp
  have h : env8738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8737_8738 : H12AffineEnvironment.transform 16 1344 env8737 = env8738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env8737 == env8738) = true)

theorem identity8738 : scanCanonicalize (H12AffineFastState.compose env8738 (packedSelected [0,4,7,9,16,20] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound8738 : packedSelected [0,4,7,9,16,20] rootPS < 2^1333 := by decide +kernel

def env8739 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,16384,32768,65536,1344,262144,524288,32768,4096,4194304,17664,98565,8329,5377,4477268,16384,1297,1073741824,1285,4294967296,257,4299806206,1344,136]

theorem envBound8739 : H12AffineFastState.Bounded env8739 := by
  intro p hp
  have h : env8739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8738_8739 : H12AffineEnvironment.transform 8 137 env8738 = env8739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env8738 == env8739) = true)

theorem identity8739 : scanCanonicalize (H12AffineFastState.compose env8739 (packedSelected [1,3,12,13,15,17] rootPS)) = affineNative (2^(13+1) ^^^ 4176) := by decide +kernel

theorem selectedBound8739 : packedSelected [1,3,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env8740 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,4176,32768,65536,1344,262144,524288,32768,4096,4194304,5456,98565,8329,5377,4456708,4176,1297,1073741824,1285,4294967296,257,4299785646,1344,136]

theorem envBound8740 : H12AffineFastState.Bounded env8740 := by
  intro p hp
  have h : env8740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8739_8740 : H12AffineEnvironment.transform 13 4176 env8739 = env8740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env8739 == env8740) = true)

theorem identity8740 : scanCanonicalize (H12AffineFastState.compose env8740 (packedSelected [4,9,16] rootPS)) = affineNative (2^(29+1) ^^^ 4820107) := by decide +kernel

theorem selectedBound8740 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env8741 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,4176,32768,65536,1344,262144,524288,32768,4096,4194304,5456,98565,8329,5377,4456708,4176,1297,4820107,1285,4294967296,257,4299785646,1344,136]

theorem envBound8741 : H12AffineFastState.Bounded env8741 := by
  intro p hp
  have h : env8741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8740_8741 : H12AffineEnvironment.transform 29 4820107 env8740 = env8741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4820107 env8740 == env8741) = true)

def env8742 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,4176,32768,65536,1344,262144,1024,32768,4096,4194304,5456,98565,8329,5377,4456708,4176,1297,4294795,1285,4294967296,257,4299260334,1344,136]

theorem envBound8742 : H12AffineFastState.Bounded env8742 := by
  intro p hp
  have h : env8742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8741_8742 : H12AffineEnvironment.transform 18 1024 env8741 = env8742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env8741 == env8742) = true)

theorem identity8742 : scanCanonicalize (H12AffineFastState.compose env8742 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound8742 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env8743 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,4176,13340,65536,1344,262144,1024,13340,4096,4194304,5456,79129,8329,5377,4456708,4176,1297,4275351,1285,4294967296,257,4299240882,1344,136]

theorem envBound8743 : H12AffineFastState.Bounded env8743 := by
  intro p hp
  have h : env8743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8742_8743 : H12AffineEnvironment.transform 14 13340 env8742 = env8743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env8742 == env8743) = true)

theorem identity8743 : scanCanonicalize (H12AffineFastState.compose env8743 (packedSelected [1,12,13] rootPS)) = affineNative (2^(21+1) ^^^ 476) := by decide +kernel

theorem selectedBound8743 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env8744 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,4176,13340,65536,1344,262144,1024,13340,4096,476,5456,79129,8329,5377,262360,4176,1297,81227,1285,4294967296,257,4295046254,1344,136]

theorem envBound8744 : H12AffineFastState.Bounded env8744 := by
  intro p hp
  have h : env8744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8743_8744 : H12AffineEnvironment.transform 21 476 env8743 = env8744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 476 env8743 == env8744) = true)

theorem identity8744 : scanCanonicalize (H12AffineFastState.compose env8744 (packedSelected [1,8,12] rootPS)) = affineNative (2^(17+1) ^^^ 13738) := by decide +kernel

theorem selectedBound8744 : packedSelected [1,8,12] rootPS < 2^1333 := by decide +kernel

def env8745 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,4176,13340,65536,1344,13738,1024,13340,4096,476,5456,79129,8329,5377,13682,4176,1297,81227,1285,4294967296,257,4295046254,1344,136]

theorem envBound8745 : H12AffineFastState.Bounded env8745 := by
  intro p hp
  have h : env8745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8744_8745 : H12AffineEnvironment.transform 17 13738 env8744 = env8745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 13738 env8744 == env8745) = true)

def env8746 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1344,8192,1296,8540,65536,1344,8426,1024,8540,1344,476,16,73817,8329,65,8242,1296,1297,75787,1285,4294967296,257,4295041326,1344,136]

theorem envBound8746 : H12AffineFastState.Bounded env8746 := by
  intro p hp
  have h : env8746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8745_8746 : H12AffineEnvironment.transform 11 1344 env8745 = env8746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env8745 == env8746) = true)

theorem identity8746 : scanCanonicalize (H12AffineFastState.compose env8746 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 276) := by decide +kernel

theorem selectedBound8746 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env8747 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1344,8192,1296,8540,65536,1344,8426,1024,8540,1344,476,16,73817,8329,65,8242,1296,1297,75787,1285,276,257,73786,1344,136]

theorem envBound8747 : H12AffineFastState.Bounded env8747 := by
  intro p hp
  have h : env8747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8746_8747 : H12AffineEnvironment.transform 31 276 env8746 = env8747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 276 env8746 == env8747) = true)

def env8748 : List Nat := [2,4,8,16,32,64,88,256,81,1024,2048,1344,8192,1296,8540,65536,1344,8242,1024,8540,1344,260,16,73817,8273,65,8242,1296,1297,75787,1285,276,257,73786,1344,80]

theorem envBound8748 : H12AffineFastState.Bounded env8748 := by
  intro p hp
  have h : env8748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8747_8748 : H12AffineEnvironment.transform 6 88 env8747 = env8748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env8747 == env8748) = true)

def env8749 : List Nat := [2,4,8,16,32,64,89,256,80,1024,2048,1344,8192,1296,8540,65536,1344,8243,1024,8540,1344,261,16,73817,8272,65,8242,1296,1297,75787,1285,276,257,73786,1344,81]

theorem envBound8749 : H12AffineFastState.Bounded env8749 := by
  intro p hp
  have h : env8749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8747_8749 : H12AffineEnvironment.transform 6 89 env8747 = env8749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env8747 == env8749) = true)

theorem identity8749 : scanCanonicalize (H12AffineFastState.compose env8749 (packedSelected [7] rootPS)) = affineNative (2^(7+1) ^^^ 62) := by decide +kernel

theorem selectedBound8749 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env8750 : List Nat := [2,4,8,16,32,64,89,62,80,1024,2048,1150,8192,1070,8290,65536,1150,8243,1024,8290,1150,59,16,73817,8272,65,8242,1070,1071,75787,1083,42,63,73786,1150,81]

theorem envBound8750 : H12AffineFastState.Bounded env8750 := by
  intro p hp
  have h : env8750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8749_8750 : H12AffineEnvironment.transform 7 62 env8749 = env8750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 62 env8749 == env8750) = true)

def env8751 : List Nat := [2,4,8,16,32,64,89,62,80,1024,0,1150,8192,1070,8290,65536,1150,8243,1024,8290,1150,59,16,73817,8272,65,8242,1070,1071,73739,1083,42,63,73786,1150,81]

theorem envBound8751 : H12AffineFastState.Bounded env8751 := by
  intro p hp
  have h : env8751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8750_8751 : H12AffineEnvironment.transform 10 0 env8750 = env8751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env8750 == env8751) = true)

theorem identity8751 : scanCanonicalize (H12AffineFastState.compose env8751 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound8751 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8752 : List Nat := [2,4,8,16,32,64,89,62,80,1024,0,1150,8192,1070,8290,115,1150,8243,1024,8290,1150,59,16,8234,8272,65,8242,1070,1071,8312,1083,42,63,8265,1150,81]

theorem envBound8752 : H12AffineFastState.Bounded env8752 := by
  intro p hp
  have h : env8752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8751_8752 : H12AffineEnvironment.transform 15 115 env8751 = env8752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env8751 == env8752) = true)

theorem identity8752 : scanCanonicalize (H12AffineFastState.compose env8752 (packedSelected [3] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound8752 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env8753 : List Nat := [2,4,8,16,32,64,89,62,80,1024,0,1150,120,1070,26,115,1150,75,1024,26,1150,59,16,82,40,65,74,1070,1071,0,1083,42,63,49,1150,81]

theorem envBound8753 : H12AffineFastState.Bounded env8753 := by
  intro p hp
  have h : env8753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8752_8753 : H12AffineEnvironment.transform 12 120 env8752 = env8753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env8752 == env8753) = true)

def env8754 : List Nat := [2,4,8,0,32,64,73,46,64,1024,0,1134,104,1070,10,99,1134,75,1024,10,1134,43,0,66,40,65,74,1070,1071,0,1067,42,47,33,1134,65]

theorem envBound8754 : H12AffineFastState.Bounded env8754 := by
  intro p hp
  have h : env8754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8753_8754 : H12AffineEnvironment.transform 3 0 env8753 = env8754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env8753 == env8754) = true)

def leafEnv8754 : List Nat := [2,4,8,0,32,64,73,46,64,1024,0,1134,104,1070,10,99,1134,75,1024,10,1134,43,0,66,1067,40,1,65,74,1070,1071,0,1067,42,47,33,5,34,1134,65,0,1071,1]

def active8754 : List Nat := [0,1,2,4,5,9]

def tree8754 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood8754 : H12WitnessSearch.Good tree8754 := H12GlobalWitnessIndex.good

theorem leafIdentity8754 : H12AffineFastState.composeSystem env8754 rootObs = leafEnv8754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env8754 rootObs == leafEnv8754) = true)

theorem terminalChecked8754 : H12PackedTerminal.terminalCheckFast leafEnv8754 active8754 tree8754 = true := by decide +kernel

def env8755 : List Nat := [2,4,8,1,32,64,72,47,65,1024,0,1135,105,1070,11,98,1135,75,1024,11,1135,42,1,67,40,65,74,1070,1071,0,1066,42,46,32,1135,64]

theorem envBound8755 : H12AffineFastState.Bounded env8755 := by
  intro p hp
  have h : env8755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8753_8755 : H12AffineEnvironment.transform 3 1 env8753 = env8755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env8753 == env8755) = true)

theorem identity8755 : scanCanonicalize (H12AffineFastState.compose env8755 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound8755 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8756 : List Nat := [2,4,2,1,32,64,66,37,65,1024,0,1125,99,1060,1,98,1125,65,1024,1,1125,32,1,67,34,65,64,1060,1061,0,1056,32,36,32,1125,64]

theorem envBound8756 : H12AffineFastState.Bounded env8756 := by
  intro p hp
  have h : env8756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8755_8756 : H12AffineEnvironment.transform 2 2 env8755 = env8756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env8755 == env8756) = true)

def leafEnv8756 : List Nat := [2,4,2,1,32,64,66,37,65,1024,0,1125,99,1060,1,98,1125,65,1024,1,1125,32,1,67,1056,34,1,65,64,1060,1061,0,1056,32,36,32,5,34,1125,64,0,1061,1]

def active8756 : List Nat := [0,1,4,5,9]

def tree8756 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood8756 : H12WitnessSearch.Good tree8756 := H12GlobalWitnessIndex.good

theorem leafIdentity8756 : H12AffineFastState.composeSystem env8756 rootObs = leafEnv8756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env8756 rootObs == leafEnv8756) = true)

theorem terminalChecked8756 : H12PackedTerminal.terminalCheckFast leafEnv8756 active8756 tree8756 = true := by decide +kernel

def env8757 : List Nat := [2,4,8,16,32,64,89,62,80,1024,1,1150,8192,1070,8290,65536,1150,8243,1024,8290,1150,59,16,73817,8272,65,8242,1070,1071,73738,1083,42,63,73786,1150,81]

theorem envBound8757 : H12AffineFastState.Bounded env8757 := by
  intro p hp
  have h : env8757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8750_8757 : H12AffineEnvironment.transform 10 1 env8750 = env8757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env8750 == env8757) = true)

theorem identity8757 : scanCanonicalize (H12AffineFastState.compose env8757 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound8757 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8758 : List Nat := [2,4,8,16,32,64,89,62,80,1024,1,1150,121,1070,27,65536,1150,74,1024,27,1150,59,16,65568,41,65,75,1070,1071,65651,1083,42,63,65603,1150,81]

theorem envBound8758 : H12AffineFastState.Bounded env8758 := by
  intro p hp
  have h : env8758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8757_8758 : H12AffineEnvironment.transform 12 121 env8757 = env8758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env8757 == env8758) = true)

theorem identity8758 : scanCanonicalize (H12AffineFastState.compose env8758 (packedSelected [3,5] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound8758 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env8759 : List Nat := [2,4,8,16,32,64,89,62,80,1024,1,1150,121,1070,27,114,1150,74,1024,27,1150,59,16,82,41,65,75,1070,1071,1,1083,42,63,49,1150,81]

theorem envBound8759 : H12AffineFastState.Bounded env8759 := by
  intro p hp
  have h : env8759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8758_8759 : H12AffineEnvironment.transform 15 114 env8758 = env8759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env8758 == env8759) = true)

def env8760 : List Nat := [2,4,8,0,32,64,73,46,64,1024,1,1134,105,1070,11,98,1134,74,1024,11,1134,43,0,66,41,65,75,1070,1071,1,1067,42,47,33,1134,65]

theorem envBound8760 : H12AffineFastState.Bounded env8760 := by
  intro p hp
  have h : env8760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8759_8760 : H12AffineEnvironment.transform 3 0 env8759 = env8760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env8759 == env8760) = true)

def leafEnv8760 : List Nat := [2,4,8,0,32,64,73,46,64,1024,1,1134,105,1070,11,98,1134,74,1024,11,1134,43,0,66,1067,41,1,65,75,1070,1071,1,1067,42,47,33,5,35,1134,65,0,1071,1]

def active8760 : List Nat := [0,1,2,4,5,9]

def tree8760 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood8760 : H12WitnessSearch.Good tree8760 := H12GlobalWitnessIndex.good

theorem leafIdentity8760 : H12AffineFastState.composeSystem env8760 rootObs = leafEnv8760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env8760 rootObs == leafEnv8760) = true)

theorem terminalChecked8760 : H12PackedTerminal.terminalCheckFast leafEnv8760 active8760 tree8760 = true := by decide +kernel

def env8761 : List Nat := [2,4,8,1,32,64,72,47,65,1024,1,1135,104,1070,10,99,1135,74,1024,10,1135,42,1,67,41,65,75,1070,1071,1,1066,42,46,32,1135,64]

theorem envBound8761 : H12AffineFastState.Bounded env8761 := by
  intro p hp
  have h : env8761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8759_8761 : H12AffineEnvironment.transform 3 1 env8759 = env8761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env8759 == env8761) = true)

theorem identity8761 : scanCanonicalize (H12AffineFastState.compose env8761 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound8761 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8762 : List Nat := [2,4,2,1,32,64,66,37,65,1024,1,1125,98,1060,0,99,1125,64,1024,0,1125,32,1,67,35,65,65,1060,1061,1,1056,32,36,32,1125,64]

theorem envBound8762 : H12AffineFastState.Bounded env8762 := by
  intro p hp
  have h : env8762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8761_8762 : H12AffineEnvironment.transform 2 2 env8761 = env8762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env8761 == env8762) = true)

def leafEnv8762 : List Nat := [2,4,2,1,32,64,66,37,65,1024,1,1125,98,1060,0,99,1125,64,1024,0,1125,32,1,67,1056,35,1,65,65,1060,1061,1,1056,32,36,32,5,35,1125,64,0,1061,1]

def active8762 : List Nat := [0,1,4,5,9]

def tree8762 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood8762 : H12WitnessSearch.Good tree8762 := H12GlobalWitnessIndex.good

theorem leafIdentity8762 : H12AffineFastState.composeSystem env8762 rootObs = leafEnv8762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env8762 rootObs == leafEnv8762) = true)

theorem terminalChecked8762 : H12PackedTerminal.terminalCheckFast leafEnv8762 active8762 tree8762 = true := by decide +kernel

def env8763 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,8192,1297,8541,65536,1344,8427,1024,8541,1345,476,17,73816,8329,64,8243,1297,1297,75786,1285,4294967296,257,4295041327,1344,136]

theorem envBound8763 : H12AffineFastState.Bounded env8763 := by
  intro p hp
  have h : env8763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8745_8763 : H12AffineEnvironment.transform 11 1345 env8745 = env8763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env8745 == env8763) = true)

theorem identity8763 : scanCanonicalize (H12AffineFastState.compose env8763 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 324) := by decide +kernel

theorem selectedBound8763 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env8764 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,8192,1297,8541,65536,1344,8427,1024,8541,1345,476,17,73816,8329,64,8243,1297,1297,75786,1285,324,257,73835,1344,136]

theorem envBound8764 : H12AffineFastState.Bounded env8764 := by
  intro p hp
  have h : env8764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8763_8764 : H12AffineEnvironment.transform 31 324 env8763 = env8764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 324 env8763 == env8764) = true)

def env8765 : List Nat := [2,4,8,16,32,64,88,256,81,1024,2048,1345,8192,1297,8541,65536,1344,8243,1024,8541,1345,260,17,73816,8273,64,8243,1297,1297,75786,1285,324,257,73835,1344,80]

theorem envBound8765 : H12AffineFastState.Bounded env8765 := by
  intro p hp
  have h : env8765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8764_8765 : H12AffineEnvironment.transform 6 88 env8764 = env8765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env8764 == env8765) = true)

def env8766 : List Nat := [2,4,8,16,32,64,89,256,80,1024,2048,1345,8192,1297,8541,65536,1344,8242,1024,8541,1345,261,17,73816,8272,64,8243,1297,1297,75786,1285,324,257,73835,1344,81]

theorem envBound8766 : H12AffineFastState.Bounded env8766 := by
  intro p hp
  have h : env8766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8764_8766 : H12AffineEnvironment.transform 6 89 env8764 = env8766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env8764 == env8766) = true)

theorem identity8766 : scanCanonicalize (H12AffineFastState.compose env8766 (packedSelected [7] rootPS)) = affineNative (2^(7+1) ^^^ 63) := by decide +kernel

theorem selectedBound8766 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env8767 : List Nat := [2,4,8,16,32,64,89,63,80,1024,2048,1150,8192,1070,8290,65536,1151,8242,1024,8290,1150,58,17,73816,8272,64,8243,1070,1070,75786,1082,123,62,73835,1151,81]

theorem envBound8767 : H12AffineFastState.Bounded env8767 := by
  intro p hp
  have h : env8767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8766_8767 : H12AffineEnvironment.transform 7 63 env8766 = env8767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 63 env8766 == env8767) = true)

def env8768 : List Nat := [2,4,8,16,32,64,89,63,80,1024,0,1150,8192,1070,8290,65536,1151,8242,1024,8290,1150,58,17,73816,8272,64,8243,1070,1070,73738,1082,123,62,73835,1151,81]

theorem envBound8768 : H12AffineFastState.Bounded env8768 := by
  intro p hp
  have h : env8768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8767_8768 : H12AffineEnvironment.transform 10 0 env8767 = env8768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env8767 == env8768) = true)

theorem identity8768 : scanCanonicalize (H12AffineFastState.compose env8768 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound8768 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8769 : List Nat := [2,4,8,16,32,64,89,63,80,1024,0,1150,8192,1070,8290,115,1151,8242,1024,8290,1150,58,17,8235,8272,64,8243,1070,1070,8313,1082,123,62,8216,1151,81]

theorem envBound8769 : H12AffineFastState.Bounded env8769 := by
  intro p hp
  have h : env8769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8768_8769 : H12AffineEnvironment.transform 15 115 env8768 = env8769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env8768 == env8769) = true)

theorem identity8769 : scanCanonicalize (H12AffineFastState.compose env8769 (packedSelected [2,4] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound8769 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env8770 : List Nat := [2,4,8,16,32,64,89,63,80,1024,0,1150,121,1070,27,115,1151,75,1024,27,1150,58,17,82,41,64,74,1070,1070,0,1082,123,62,97,1151,81]

theorem envBound8770 : H12AffineFastState.Bounded env8770 := by
  intro p hp
  have h : env8770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8769_8770 : H12AffineEnvironment.transform 12 121 env8769 = env8770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env8769 == env8770) = true)

def env8771 : List Nat := [2,4,8,16,32,0,25,63,16,1024,0,1086,57,1070,27,51,1087,11,1024,27,1086,58,17,18,41,0,10,1070,1070,0,1082,59,62,33,1087,17]

theorem envBound8771 : H12AffineFastState.Bounded env8771 := by
  intro p hp
  have h : env8771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8770_8771 : H12AffineEnvironment.transform 5 0 env8770 = env8771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env8770 == env8771) = true)

def leafEnv8771 : List Nat := [2,4,8,16,32,0,25,63,16,1024,0,1086,57,1070,27,51,1087,11,1024,27,1086,58,17,18,1082,41,1,0,10,1070,1070,0,1082,59,62,33,5,34,1087,17,0,1070,1]

def active8771 : List Nat := [0,1,2,3,4,9]

def tree8771 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood8771 : H12WitnessSearch.Good tree8771 := H12GlobalWitnessIndex.good

theorem leafIdentity8771 : H12AffineFastState.composeSystem env8771 rootObs = leafEnv8771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env8771 rootObs == leafEnv8771) = true)

theorem terminalChecked8771 : H12PackedTerminal.terminalCheckFast leafEnv8771 active8771 tree8771 = true := by decide +kernel

def env8772 : List Nat := [2,4,8,16,32,1,24,63,17,1024,0,1087,56,1070,27,50,1086,10,1024,27,1087,58,17,19,41,1,11,1070,1070,0,1082,58,62,32,1086,16]

theorem envBound8772 : H12AffineFastState.Bounded env8772 := by
  intro p hp
  have h : env8772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8770_8772 : H12AffineEnvironment.transform 5 1 env8770 = env8772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env8770 == env8772) = true)

theorem identity8772 : scanCanonicalize (H12AffineFastState.compose env8772 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound8772 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8773 : List Nat := [2,4,8,10,32,1,2,37,11,1024,0,1061,34,1070,1,40,1060,10,1024,1,1061,32,11,9,41,1,11,1070,1070,0,1056,32,36,32,1060,10]

theorem envBound8773 : H12AffineFastState.Bounded env8773 := by
  intro p hp
  have h : env8773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8772_8773 : H12AffineEnvironment.transform 3 10 env8772 = env8773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env8772 == env8773) = true)

def leafEnv8773 : List Nat := [2,4,8,10,32,1,2,37,11,1024,0,1061,34,1070,1,40,1060,10,1024,1,1061,32,11,9,1056,41,1,1,11,1070,1070,0,1056,32,36,32,5,34,1060,10,0,1070,1]

def active8773 : List Nat := [0,1,2,4,9]

def tree8773 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood8773 : H12WitnessSearch.Good tree8773 := H12GlobalWitnessIndex.good

theorem leafIdentity8773 : H12AffineFastState.composeSystem env8773 rootObs = leafEnv8773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env8773 rootObs == leafEnv8773) = true)

theorem terminalChecked8773 : H12PackedTerminal.terminalCheckFast leafEnv8773 active8773 tree8773 = true := by decide +kernel

def env8774 : List Nat := [2,4,8,16,32,64,89,63,80,1024,1,1150,8192,1070,8290,65536,1151,8242,1024,8290,1150,58,17,73816,8272,64,8243,1070,1070,73739,1082,123,62,73835,1151,81]

theorem envBound8774 : H12AffineFastState.Bounded env8774 := by
  intro p hp
  have h : env8774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8767_8774 : H12AffineEnvironment.transform 10 1 env8767 = env8774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env8767 == env8774) = true)

theorem identity8774 : scanCanonicalize (H12AffineFastState.compose env8774 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound8774 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8775 : List Nat := [2,4,8,16,32,64,89,63,80,1024,1,1150,120,1070,26,65536,1151,74,1024,26,1150,58,17,65568,40,64,75,1070,1070,65651,1082,123,62,65555,1151,81]

theorem envBound8775 : H12AffineFastState.Bounded env8775 := by
  intro p hp
  have h : env8775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8774_8775 : H12AffineEnvironment.transform 12 120 env8774 = env8775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env8774 == env8775) = true)

theorem identity8775 : scanCanonicalize (H12AffineFastState.compose env8775 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound8775 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8776 : List Nat := [2,4,8,16,32,64,89,63,80,1024,1,1150,120,1070,26,114,1151,74,1024,26,1150,58,17,82,40,64,75,1070,1070,1,1082,123,62,97,1151,81]

theorem envBound8776 : H12AffineFastState.Bounded env8776 := by
  intro p hp
  have h : env8776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8775_8776 : H12AffineEnvironment.transform 15 114 env8775 = env8776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env8775 == env8776) = true)

def env8777 : List Nat := [2,4,8,16,32,0,25,63,16,1024,1,1086,56,1070,26,50,1087,10,1024,26,1086,58,17,18,40,0,11,1070,1070,1,1082,59,62,33,1087,17]

theorem envBound8777 : H12AffineFastState.Bounded env8777 := by
  intro p hp
  have h : env8777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8776_8777 : H12AffineEnvironment.transform 5 0 env8776 = env8777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env8776 == env8777) = true)

def leafEnv8777 : List Nat := [2,4,8,16,32,0,25,63,16,1024,1,1086,56,1070,26,50,1087,10,1024,26,1086,58,17,18,1082,40,1,0,11,1070,1070,1,1082,59,62,33,5,35,1087,17,0,1070,1]

def active8777 : List Nat := [0,1,2,3,4,9]

def tree8777 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood8777 : H12WitnessSearch.Good tree8777 := H12GlobalWitnessIndex.good

theorem leafIdentity8777 : H12AffineFastState.composeSystem env8777 rootObs = leafEnv8777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env8777 rootObs == leafEnv8777) = true)

theorem terminalChecked8777 : H12PackedTerminal.terminalCheckFast leafEnv8777 active8777 tree8777 = true := by decide +kernel

def env8778 : List Nat := [2,4,8,16,32,1,24,63,17,1024,1,1087,57,1070,26,51,1086,11,1024,26,1087,58,17,19,40,1,10,1070,1070,1,1082,58,62,32,1086,16]

theorem envBound8778 : H12AffineFastState.Bounded env8778 := by
  intro p hp
  have h : env8778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8776_8778 : H12AffineEnvironment.transform 5 1 env8776 = env8778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env8776 == env8778) = true)

theorem identity8778 : scanCanonicalize (H12AffineFastState.compose env8778 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound8778 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8779 : List Nat := [2,4,8,10,32,1,2,37,11,1024,1,1061,35,1070,0,41,1060,11,1024,0,1061,32,11,9,40,1,10,1070,1070,1,1056,32,36,32,1060,10]

theorem envBound8779 : H12AffineFastState.Bounded env8779 := by
  intro p hp
  have h : env8779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8778_8779 : H12AffineEnvironment.transform 3 10 env8778 = env8779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env8778 == env8779) = true)

def leafEnv8779 : List Nat := [2,4,8,10,32,1,2,37,11,1024,1,1061,35,1070,0,41,1060,11,1024,0,1061,32,11,9,1056,40,1,1,10,1070,1070,1,1056,32,36,32,5,35,1060,10,0,1070,1]

def active8779 : List Nat := [0,1,2,4,9]

def tree8779 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood8779 : H12WitnessSearch.Good tree8779 := H12GlobalWitnessIndex.good

theorem leafIdentity8779 : H12AffineFastState.composeSystem env8779 rootObs = leafEnv8779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env8779 rootObs == leafEnv8779) = true)

theorem terminalChecked8779 : H12PackedTerminal.terminalCheckFast leafEnv8779 active8779 tree8779 = true := by decide +kernel

def env8780 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,4176,32768,65536,1344,262144,1025,32768,4096,4194304,5456,98565,8329,5377,4456708,4176,1297,4294794,1285,4294967296,257,4299260335,1344,136]

theorem envBound8780 : H12AffineFastState.Bounded env8780 := by
  intro p hp
  have h : env8780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8741_8780 : H12AffineEnvironment.transform 18 1025 env8741 = env8780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env8741 == env8780) = true)

theorem identity8780 : scanCanonicalize (H12AffineFastState.compose env8780 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 477) := by decide +kernel

theorem selectedBound8780 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env8781 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,4176,32768,65536,1344,262144,1025,32768,4096,477,5456,98565,8329,5377,262361,4176,1297,100695,1285,4294967296,257,4295065714,1344,136]

theorem envBound8781 : H12AffineFastState.Bounded env8781 := by
  intro p hp
  have h : env8781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8780_8781 : H12AffineEnvironment.transform 21 477 env8780 = env8781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 477 env8780 == env8781) = true)

theorem identity8781 : scanCanonicalize (H12AffineFastState.compose env8781 (packedSelected [1,12,13] rootPS)) = affineNative (2^(14+1) ^^^ 13592) := by decide +kernel

theorem selectedBound8781 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env8782 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,4176,13592,65536,1344,262144,1025,13592,4096,477,5456,78877,8329,5377,262361,4176,1297,80975,1285,4294967296,257,4295046506,1344,136]

theorem envBound8782 : H12AffineFastState.Bounded env8782 := by
  intro p hp
  have h : env8782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8781_8782 : H12AffineEnvironment.transform 14 13592 env8781 = env8782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13592 env8781 == env8782) = true)

theorem identity8782 : scanCanonicalize (H12AffineFastState.compose env8782 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound8782 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env8783 : List Nat := [2,4,8,16,32,64,128,4,137,1024,2048,4096,8192,4176,13340,65536,1092,262144,1025,13340,4096,217,5204,78877,8329,5125,262361,4176,1045,80975,1025,4294967296,5,4295046254,1092,136]

theorem envBound8783 : H12AffineFastState.Bounded env8783 := by
  intro p hp
  have h : env8783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8782_8783 : H12AffineEnvironment.transform 7 4 env8782 = env8783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env8782 == env8783) = true)

theorem identity8783 : scanCanonicalize (H12AffineFastState.compose env8783 (packedSelected [1,8,12] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound8783 : packedSelected [1,8,12] rootPS < 2^1333 := by decide +kernel

def env8784 : List Nat := [2,4,8,16,32,64,128,4,137,1024,2048,4096,8192,4176,13340,115,1092,262144,1025,13340,4096,217,5204,13422,8329,5125,262361,4176,1045,15420,1025,4294967296,5,4294980637,1092,136]

theorem envBound8784 : H12AffineFastState.Bounded env8784 := by
  intro p hp
  have h : env8784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8783_8784 : H12AffineEnvironment.transform 15 115 env8783 = env8784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env8783 == env8784) = true)

def env8785 : List Nat := [2,4,8,16,32,16,128,4,137,1024,2048,4096,8192,4096,13340,35,1044,262144,1025,13340,4096,137,5124,13374,8329,5125,262281,4096,1045,15420,1025,4294967296,5,4294980637,1044,136]

theorem envBound8785 : H12AffineFastState.Bounded env8785 := by
  intro p hp
  have h : env8785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8784_8785 : H12AffineEnvironment.transform 5 16 env8784 = env8785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env8784 == env8785) = true)

theorem identity8785 : scanCanonicalize (H12AffineFastState.compose env8785 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 267447) := by decide +kernel

theorem selectedBound8785 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env8786 : List Nat := [2,4,8,16,32,16,128,4,137,1024,2048,4096,8192,4096,13340,35,1044,262144,1025,13340,4096,137,5124,13374,8329,5125,262281,4096,1045,15420,1025,267447,5,270506,1044,136]

theorem envBound8786 : H12AffineFastState.Bounded env8786 := by
  intro p hp
  have h : env8786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8785_8786 : H12AffineEnvironment.transform 31 267447 env8785 = env8786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 267447 env8785 == env8786) = true)

def env8787 : List Nat := [2,4,8,16,32,16,128,4,137,1024,2048,4096,8192,4096,13340,35,1044,8320,1025,13340,4096,137,5124,13374,8329,5125,8201,4096,1045,15420,1025,13367,5,42,1044,136]

theorem envBound8787 : H12AffineFastState.Bounded env8787 := by
  intro p hp
  have h : env8787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8786_8787 : H12AffineEnvironment.transform 17 8320 env8786 = env8787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8320 env8786 == env8787) = true)

def env8788 : List Nat := [2,4,8,16,32,16,128,4,137,1024,2048,4096,8192,4096,13340,35,1044,8321,1025,13340,4096,137,5124,13374,8329,5125,8200,4096,1045,15420,1025,13366,5,43,1044,136]

theorem envBound8788 : H12AffineFastState.Bounded env8788 := by
  intro p hp
  have h : env8788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart2