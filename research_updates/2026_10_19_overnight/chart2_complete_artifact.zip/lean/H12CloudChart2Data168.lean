import H12CloudChart2Data167

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env42030 : List Nat := [2,4,8,11,7,11,128,139,0,5,0,133,139,132,12,8,132,12,4,13,132,6,10,138,2,11,132,133,133,136,139,143,139,142,133,0]

theorem envBound42030 : H12AffineFastState.Bounded env42030 := by
  intro p hp
  have h : env42030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42029_42030 : H12AffineEnvironment.transform 8 0 env42029 = env42030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env42029 == env42030) = true)

theorem identity42030 : scanCanonicalize (H12AffineFastState.compose env42030 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound42030 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env42031 : List Nat := [2,4,8,11,7,11,5,14,0,5,0,0,14,1,12,8,1,12,4,13,1,6,10,15,2,11,1,0,0,13,14,10,14,11,0,0]

theorem envBound42031 : H12AffineFastState.Bounded env42031 := by
  intro p hp
  have h : env42031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42030_42031 : H12AffineEnvironment.transform 6 5 env42030 = env42031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env42030 == env42031) = true)

def env42032 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61569,147472,58519,143496,20497,508074,148669,148669,96267,90263,148652,172,16401,1213,135681]

theorem envBound42032 : H12AffineFastState.Bounded env42032 := by
  intro p hp
  have h : env42032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42017_42032 : H12AffineEnvironment.transform 5 17 env42017 = env42032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env42017 == env42032) = true)

theorem identity42032 : scanCanonicalize (H12AffineFastState.compose env42032 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 208055) := by decide +kernel

theorem selectedBound42032 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env42033 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,208055,136192,32769,4097,61569,147472,58519,143496,20497,60445,148669,148669,96267,90263,148652,172,16401,1213,135681]

theorem envBound42033 : H12AffineFastState.Bounded env42033 := by
  intro p hp
  have h : env42033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42032_42033 : H12AffineEnvironment.transform 17 208055 env42032 = env42033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 208055 env42032 == env42033) = true)

theorem identity42033 : scanCanonicalize (H12AffineFastState.compose env42033 (packedSelected [1,3,5,7,8,10,20,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53283) := by decide +kernel

theorem selectedBound42033 : packedSelected [1,3,5,7,8,10,20,26,27] rootPS < 2^1333 := by decide +kernel

def env42034 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,53283,131072,195732,136192,32769,4097,61569,147472,58519,143496,20497,60445,148669,148669,43048,45236,148652,172,16401,1213,135681]

theorem envBound42034 : H12AffineFastState.Bounded env42034 := by
  intro p hp
  have h : env42034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42033_42034 : H12AffineEnvironment.transform 15 53283 env42033 = env42034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53283 env42033 == env42034) = true)

theorem identity42034 : scanCanonicalize (H12AffineFastState.compose env42034 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(16+1) ^^^ 21692) := by decide +kernel

theorem selectedBound42034 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env42035 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,53283,21692,43048,16572,32769,4097,61569,5292,58519,25652,20497,60445,4097,4097,43048,45236,4112,172,16401,1213,18109]

theorem envBound42035 : H12AffineFastState.Bounded env42035 := by
  intro p hp
  have h : env42035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42034_42035 : H12AffineEnvironment.transform 16 21692 env42034 = env42035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 21692 env42034 == env42035) = true)

theorem identity42035 : scanCanonicalize (H12AffineFastState.compose env42035 (packedSelected [4,9,20] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound42035 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env42036 : List Nat := [2,4,8,16,32,17,128,172,512,5,2048,4096,8192,16384,32768,53283,20665,43048,16572,32769,4097,61569,4265,57490,24625,20497,59416,4097,4097,43048,45236,4112,172,16401,184,17080]

theorem envBound42036 : H12AffineFastState.Bounded env42036 := by
  intro p hp
  have h : env42036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42035_42036 : H12AffineEnvironment.transform 9 5 env42035 = env42036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env42035 == env42036) = true)

theorem identity42036 : scanCanonicalize (H12AffineFastState.compose env42036 (packedSelected [0,2,3,5,6,9,11,13,17] rootPS)) = affineNative (2^(12+1) ^^^ 673) := by decide +kernel

theorem selectedBound42036 : packedSelected [0,2,3,5,6,9,11,13,17] rootPS < 2^1333 := by decide +kernel

def env42037 : List Nat := [2,4,8,16,32,17,128,172,512,5,2048,4096,673,16384,32768,53283,20665,35465,16572,32769,4097,53792,4265,49715,17040,20497,51897,4097,4097,35465,37397,4112,172,16401,184,17080]

theorem envBound42037 : H12AffineFastState.Bounded env42037 := by
  intro p hp
  have h : env42037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42036_42037 : H12AffineEnvironment.transform 12 673 env42036 = env42037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 673 env42036 == env42037) = true)

theorem identity42037 : scanCanonicalize (H12AffineFastState.compose env42037 (packedSelected [1,3,6,7,9,11,13,15] rootPS)) = affineNative (2^(14+1) ^^^ 6699) := by decide +kernel

theorem selectedBound42037 : packedSelected [1,3,6,7,9,11,13,15] rootPS < 2^1333 := by decide +kernel

def env42038 : List Nat := [2,4,8,16,32,17,128,172,512,5,2048,4096,673,16384,6699,18952,20665,4258,16572,6698,4097,18443,4265,22552,17040,20497,20626,4097,4097,4258,2110,4112,172,16401,184,17080]

theorem envBound42038 : H12AffineFastState.Bounded env42038 := by
  intro p hp
  have h : env42038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42037_42038 : H12AffineEnvironment.transform 14 6699 env42037 = env42038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 6699 env42037 == env42038) = true)

theorem identity42038 : scanCanonicalize (H12AffineFastState.compose env42038 (packedSelected [0,1,2,5,6,9,11,13] rootPS)) = affineNative (2^(11+1) ^^^ 136) := by decide +kernel

theorem selectedBound42038 : packedSelected [0,1,2,5,6,9,11,13] rootPS < 2^1333 := by decide +kernel

def env42039 : List Nat := [2,4,8,16,32,17,128,172,512,5,2048,136,673,16384,2723,18952,16433,42,16572,2722,137,18443,33,18576,17040,16537,16410,137,137,42,2110,152,172,16401,184,17080]

theorem envBound42039 : H12AffineFastState.Bounded env42039 := by
  intro p hp
  have h : env42039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42038_42039 : H12AffineEnvironment.transform 11 136 env42038 = env42039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 136 env42038 == env42039) = true)

theorem identity42039 : scanCanonicalize (H12AffineFastState.compose env42039 (packedSelected [0,4,5,7,8,9,10,11,12] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound42039 : packedSelected [0,4,5,7,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env42040 : List Nat := [2,4,8,16,11,17,128,135,512,5,2048,136,650,16384,2696,18952,16410,1,16535,2697,137,18443,10,18576,17040,16537,16410,137,137,1,2069,152,135,16401,147,17043]

theorem envBound42040 : H12AffineFastState.Bounded env42040 := by
  intro p hp
  have h : env42040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42039_42040 : H12AffineEnvironment.transform 4 11 env42039 = env42040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env42039 == env42040) = true)

theorem identity42040 : scanCanonicalize (H12AffineFastState.compose env42040 (packedSelected [0,4,5,8,10] rootPS)) = affineNative (2^(13+1) ^^^ 659) := by decide +kernel

theorem selectedBound42040 : packedSelected [0,4,5,8,10] rootPS < 2^1333 := by decide +kernel

def env42041 : List Nat := [2,4,8,16,11,17,128,135,512,5,2048,136,650,659,2696,2203,649,1,516,2697,137,2712,10,2563,3,522,649,137,137,1,2069,152,135,642,147,0]

theorem envBound42041 : H12AffineFastState.Bounded env42041 := by
  intro p hp
  have h : env42041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42040_42041 : H12AffineEnvironment.transform 13 659 env42040 = env42041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 659 env42040 == env42041) = true)

theorem identity42041 : scanCanonicalize (H12AffineFastState.compose env42041 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(8+1) ^^^ 146) := by decide +kernel

theorem selectedBound42041 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env42042 : List Nat := [2,4,8,16,11,17,128,135,146,5,2048,136,24,1,2074,2203,27,1,150,2075,137,2058,10,2193,3,152,27,137,137,1,2069,152,135,16,147,0]

theorem envBound42042 : H12AffineFastState.Bounded env42042 := by
  intro p hp
  have h : env42042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42041_42042 : H12AffineEnvironment.transform 8 146 env42041 = env42042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 146 env42041 == env42042) = true)

theorem identity42042 : scanCanonicalize (H12AffineFastState.compose env42042 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound42042 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env42043 : List Nat := [2,4,8,16,11,17,18,21,0,5,2048,26,24,1,2074,2057,27,1,4,2075,27,2058,10,2051,3,10,27,27,27,1,2069,10,21,16,1,0]

theorem envBound42043 : H12AffineFastState.Bounded env42043 := by
  intro p hp
  have h : env42043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42042_42043 : H12AffineEnvironment.transform 6 18 env42042 = env42043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env42042 == env42043) = true)

theorem identity42043 : scanCanonicalize (H12AffineFastState.compose env42043 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound42043 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env42044 : List Nat := [2,4,8,16,11,17,18,21,0,5,26,26,24,1,0,19,27,1,4,1,27,16,10,25,3,10,27,27,27,1,15,10,21,16,1,0]

theorem envBound42044 : H12AffineFastState.Bounded env42044 := by
  intro p hp
  have h : env42044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42043_42044 : H12AffineEnvironment.transform 10 26 env42043 = env42044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env42043 == env42044) = true)

theorem identity42044 : scanCanonicalize (H12AffineFastState.compose env42044 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound42044 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42045 : List Nat := [2,3,8,16,11,17,18,18,0,2,26,26,24,1,0,19,27,1,3,1,27,16,10,25,3,10,27,27,27,1,8,10,18,16,1,0]

theorem envBound42045 : H12AffineFastState.Bounded env42045 := by
  intro p hp
  have h : env42045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42044_42045 : H12AffineEnvironment.transform 1 3 env42044 = env42045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env42044 == env42045) = true)

def env42046 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147521,58518,143496,20497,508155,148717,148717,96346,90262,148732,173,16401,1261,135681]

theorem envBound42046 : H12AffineFastState.Bounded env42046 := by
  intro p hp
  have h : env42046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42016_42046 : H12AffineEnvironment.transform 7 173 env42016 = env42046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env42016 == env42046) = true)

def env42047 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61568,147473,58518,143496,20497,508075,148669,148669,96266,90262,148652,173,16401,1213,135681]

theorem envBound42047 : H12AffineFastState.Bounded env42047 := by
  intro p hp
  have h : env42047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42046_42047 : H12AffineEnvironment.transform 5 16 env42046 = env42047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env42046 == env42047) = true)

theorem identity42047 : scanCanonicalize (H12AffineFastState.compose env42047 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 45217) := by decide +kernel

theorem selectedBound42047 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env42048 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,45217,262144,42145,32769,4097,61568,61616,58518,32809,20497,356362,62492,62492,96266,90262,62477,173,16401,1213,41632]

theorem envBound42048 : H12AffineFastState.Bounded env42048 := by
  intro p hp
  have h : env42048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42047_42048 : H12AffineEnvironment.transform 16 45217 env42047 = env42048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45217 env42047 == env42048) = true)

theorem identity42048 : scanCanonicalize (H12AffineFastState.compose env42048 (packedSelected [16,20] rootPS)) = affineNative (2^(17+1) ^^^ 2185) := by decide +kernel

theorem selectedBound42048 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env42049 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,45217,2185,42145,32769,4097,61568,61616,58518,32809,20497,96387,62492,62492,96266,90262,62477,173,16401,1213,41632]

theorem envBound42049 : H12AffineFastState.Bounded env42049 := by
  intro p hp
  have h : env42049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42048_42049 : H12AffineEnvironment.transform 17 2185 env42048 = env42049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2185 env42048 == env42049) = true)

theorem identity42049 : scanCanonicalize (H12AffineFastState.compose env42049 (packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 184) := by decide +kernel

theorem selectedBound42049 : packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env42050 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,184,32768,65536,45217,2185,42145,32769,4097,45112,45064,42030,32809,4265,79931,46244,46244,80050,73774,46261,173,169,1213,41632]

theorem envBound42050 : H12AffineFastState.Bounded env42050 := by
  intro p hp
  have h : env42050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42049_42050 : H12AffineEnvironment.transform 13 184 env42049 = env42050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 184 env42049 == env42050) = true)

theorem identity42050 : scanCanonicalize (H12AffineFastState.compose env42050 (packedSelected [1,4,5,8,9,16,17,21,24] rootPS)) = affineNative (2^(15+1) ^^^ 13375) := by decide +kernel

theorem selectedBound42050 : packedSelected [1,4,5,8,9,16,17,21,24] rootPS < 2^1333 := by decide +kernel

def env42051 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,184,32768,13375,45217,2185,42145,32769,4097,45112,45064,42030,32809,4265,3076,46244,46244,3213,5137,46261,173,169,1213,41632]

theorem envBound42051 : H12AffineFastState.Bounded env42051 := by
  intro p hp
  have h : env42051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42050_42051 : H12AffineEnvironment.transform 15 13375 env42050 = env42051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13375 env42050 == env42051) = true)

theorem identity42051 : scanCanonicalize (H12AffineFastState.compose env42051 (packedSelected [0,2,3,5,7,10,11,15,16] rootPS)) = affineNative (2^(9+1) ^^^ 700) := by decide +kernel

theorem selectedBound42051 : packedSelected [0,2,3,5,7,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env42052 : List Nat := [2,4,8,16,32,16,128,173,512,700,2048,4096,8192,184,32768,12931,45217,2185,41501,32769,4097,45112,45064,41618,32809,4265,2744,45592,45592,2609,4781,45577,173,169,513,41632]

theorem envBound42052 : H12AffineFastState.Bounded env42052 := by
  intro p hp
  have h : env42052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42051_42052 : H12AffineEnvironment.transform 9 700 env42051 = env42052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 700 env42051 == env42052) = true)

theorem identity42052 : scanCanonicalize (H12AffineFastState.compose env42052 (packedSelected [2,5,6,7,8,9,12,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 2195) := by decide +kernel

theorem selectedBound42052 : packedSelected [2,5,6,7,8,9,12,13,15] rootPS < 2^1333 := by decide +kernel

def env42053 : List Nat := [2,4,8,16,32,16,128,173,512,700,2048,2195,8192,184,32768,10768,43058,2185,41501,32769,2194,43179,43163,41618,32809,2106,2744,43659,43659,2609,2622,43674,173,169,513,41632]

theorem envBound42053 : H12AffineFastState.Bounded env42053 := by
  intro p hp
  have h : env42053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42052_42053 : H12AffineEnvironment.transform 11 2195 env42052 = env42053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2195 env42052 == env42053) = true)

theorem identity42053 : scanCanonicalize (H12AffineFastState.compose env42053 (packedSelected [3,7,8,9,10,12,13,17] rootPS)) = affineNative (2^(12+1) ^^^ 2208) := by decide +kernel

theorem selectedBound42053 : packedSelected [3,7,8,9,10,12,13,17] rootPS < 2^1333 := by decide +kernel

def env42054 : List Nat := [2,4,8,16,32,16,128,173,512,700,2048,2195,2208,184,32768,688,32914,2185,35517,32769,2194,32779,32827,35378,32809,2106,2744,33323,33323,2609,2622,33338,173,169,513,35328]

theorem envBound42054 : H12AffineFastState.Bounded env42054 := by
  intro p hp
  have h : env42054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42053_42054 : H12AffineEnvironment.transform 12 2208 env42053 = env42054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2208 env42053 == env42054) = true)

theorem identity42054 : scanCanonicalize (H12AffineFastState.compose env42054 (packedSelected [0,1,5,6,9,10] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound42054 : packedSelected [0,1,5,6,9,10] rootPS < 2^1333 := by decide +kernel

def env42055 : List Nat := [2,4,8,16,32,16,128,173,512,700,49,162,145,184,32768,688,32914,184,33420,32769,163,32779,32827,33283,32809,11,649,33323,33323,512,527,33338,173,169,513,33329]

theorem envBound42055 : H12AffineFastState.Bounded env42055 := by
  intro p hp
  have h : env42055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42054_42055 : H12AffineEnvironment.transform 10 49 env42054 = env42055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env42054 == env42055) = true)

theorem identity42055 : scanCanonicalize (H12AffineFastState.compose env42055 (packedSelected [1,2,6,7,8,9] rootPS)) = affineNative (2^(8+1) ^^^ 163) := by decide +kernel

theorem selectedBound42055 : packedSelected [1,2,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env42056 : List Nat := [2,4,8,16,32,16,128,173,163,31,49,162,145,184,32768,19,32914,184,32815,32769,163,32779,32827,32928,32809,11,42,32904,32904,163,172,32921,173,169,162,32914]

theorem envBound42056 : H12AffineFastState.Bounded env42056 := by
  intro p hp
  have h : env42056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42055_42056 : H12AffineEnvironment.transform 8 163 env42055 = env42056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 163 env42055 == env42056) = true)

theorem identity42056 : scanCanonicalize (H12AffineFastState.compose env42056 (packedSelected [1,2,4,5,6,7] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound42056 : packedSelected [1,2,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env42057 : List Nat := [2,4,8,11,32,11,128,173,163,4,42,162,138,163,32768,8,32905,163,32815,32769,163,32779,32800,32928,32809,11,42,32904,32904,163,172,32898,173,169,162,32905]

theorem envBound42057 : H12AffineFastState.Bounded env42057 := by
  intro p hp
  have h : env42057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42056_42057 : H12AffineEnvironment.transform 3 11 env42056 = env42057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env42056 == env42057) = true)

theorem identity42057 : scanCanonicalize (H12AffineFastState.compose env42057 (packedSelected [1,2,3] rootPS)) = affineNative (2^(14+1) ^^^ 162) := by decide +kernel

theorem selectedBound42057 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env42058 : List Nat := [2,4,8,11,32,11,128,173,163,4,42,162,138,163,162,8,43,163,141,163,163,169,130,2,139,11,42,42,42,163,172,32,173,169,162,43]

theorem envBound42058 : H12AffineFastState.Bounded env42058 := by
  intro p hp
  have h : env42058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42057_42058 : H12AffineEnvironment.transform 14 162 env42057 = env42058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 162 env42057 == env42058) = true)

theorem identity42058 : scanCanonicalize (H12AffineFastState.compose env42058 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound42058 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42059 : List Nat := [2,4,8,11,32,11,8,37,43,4,42,42,2,43,42,8,43,43,5,43,43,33,10,2,3,11,42,42,42,43,36,32,37,33,42,43]

theorem envBound42059 : H12AffineFastState.Bounded env42059 := by
  intro p hp
  have h : env42059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42058_42059 : H12AffineEnvironment.transform 6 8 env42058 = env42059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env42058 == env42059) = true)

theorem identity42059 : scanCanonicalize (H12AffineFastState.compose env42059 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound42059 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42060 : List Nat := [2,4,8,11,6,11,8,3,13,4,12,12,2,13,12,8,13,13,5,13,13,7,10,2,3,11,12,12,12,13,2,6,3,7,12,13]

theorem envBound42060 : H12AffineFastState.Bounded env42060 := by
  intro p hp
  have h : env42060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42059_42060 : H12AffineEnvironment.transform 4 6 env42059 = env42060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env42059 == env42060) = true)

theorem identity42060 : scanCanonicalize (H12AffineFastState.compose env42060 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound42060 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42061 : List Nat := [2,4,5,6,6,6,5,3,0,4,1,1,2,0,1,5,0,0,5,0,0,7,7,2,3,6,1,1,1,0,2,6,3,7,1,0]

theorem envBound42061 : H12AffineFastState.Bounded env42061 := by
  intro p hp
  have h : env42061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42060_42061 : H12AffineEnvironment.transform 2 5 env42060 = env42061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env42060 == env42061) = true)

def env42062 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61569,147472,58518,143496,20497,508074,148668,148668,96267,90262,148653,173,16401,1212,135681]

theorem envBound42062 : H12AffineFastState.Bounded env42062 := by
  intro p hp
  have h : env42062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42046_42062 : H12AffineEnvironment.transform 5 17 env42046 = env42062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env42046 == env42062) = true)

theorem identity42062 : scanCanonicalize (H12AffineFastState.compose env42062 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 137353) := by decide +kernel

theorem selectedBound42062 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env42063 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,137353,136192,32769,4097,61569,147472,58518,143496,20497,120867,148668,148668,96267,90262,148653,173,16401,1212,135681]

theorem envBound42063 : H12AffineFastState.Bounded env42063 := by
  intro p hp
  have h : env42063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42062_42063 : H12AffineEnvironment.transform 17 137353 env42062 = env42063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137353 env42062 == env42063) = true)

theorem identity42063 : scanCanonicalize (H12AffineFastState.compose env42063 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(16+1) ^^^ 62492) := by decide +kernel

theorem selectedBound42063 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env42064 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,62492,60565,57372,32769,4097,61569,46092,58518,50324,20497,120867,45216,45216,96267,90262,45233,173,16401,1212,58909]

theorem envBound42064 : H12AffineFastState.Bounded env42064 := by
  intro p hp
  have h : env42064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42063_42064 : H12AffineEnvironment.transform 16 62492 env42063 = env42064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 62492 env42063 == env42064) = true)

theorem identity42064 : scanCanonicalize (H12AffineFastState.compose env42064 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 54310) := by decide +kernel

theorem selectedBound42064 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env42065 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,54310,62492,60565,57372,32769,4097,61569,46092,58518,50324,20497,3077,45216,45216,44077,46256,45233,173,16401,1212,58909]

theorem envBound42065 : H12AffineFastState.Bounded env42065 := by
  intro p hp
  have h : env42065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42064_42065 : H12AffineEnvironment.transform 15 54310 env42064 = env42065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54310 env42064 == env42065) = true)

theorem identity42065 : scanCanonicalize (H12AffineFastState.compose env42065 (packedSelected [0,1,2,6,7,8,13,17,19,20,21] rootPS)) = affineNative (2^(14+1) ^^^ 6705) := by decide +kernel

theorem selectedBound42065 : packedSelected [0,1,2,6,7,8,13,17,19,20,21] rootPS < 2^1333 := by decide +kernel

def env42066 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,6705,19991,28205,30372,31277,6704,4097,27312,11837,32423,24229,20497,3077,10897,10897,13852,11905,10880,173,16401,1212,31788]

theorem envBound42066 : H12AffineFastState.Bounded env42066 := by
  intro p hp
  have h : env42066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42065_42066 : H12AffineEnvironment.transform 14 6705 env42065 = env42066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 6705 env42065 == env42066) = true)

theorem identity42066 : scanCanonicalize (H12AffineFastState.compose env42066 (packedSelected [0,1,2,6,7,8,13,18,20,23,26] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound42066 : packedSelected [0,1,2,6,7,8,13,18,20,23,26] rootPS < 2^1333 := by decide +kernel

def env42067 : List Nat := [2,4,8,16,32,17,128,173,512,4,2048,4096,8192,16384,6705,18963,27177,29344,31277,6704,4097,27312,10809,31395,23201,20497,2049,10897,10897,12824,10885,10880,173,16401,184,30760]

theorem envBound42067 : H12AffineFastState.Bounded env42067 := by
  intro p hp
  have h : env42067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42066_42067 : H12AffineEnvironment.transform 9 4 env42066 = env42067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env42066 == env42067) = true)

theorem identity42067 : scanCanonicalize (H12AffineFastState.compose env42067 (packedSelected [1,2,4,6,7,8,10,11,17] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound42067 : packedSelected [1,2,4,6,7,8,10,11,17] rootPS < 2^1333 := by decide +kernel

def env42068 : List Nat := [2,4,8,16,32,17,128,173,137,4,2048,4096,8192,16384,6328,18586,26784,28713,30884,6329,4097,26681,10416,30762,22568,20497,2049,10264,10264,12433,10252,10249,173,16401,184,30760]

theorem envBound42068 : H12AffineFastState.Bounded env42068 := by
  intro p hp
  have h : env42068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42067_42068 : H12AffineEnvironment.transform 8 137 env42067 = env42068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env42067 == env42068) = true)

theorem identity42068 : scanCanonicalize (H12AffineFastState.compose env42068 (packedSelected [0,1,3,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 8242) := by decide +kernel

theorem selectedBound42068 : packedSelected [0,1,3,9,11] rootPS < 2^1333 := by decide +kernel

def env42069 : List Nat := [2,4,8,16,32,17,128,173,137,4,2048,4096,8192,8242,6328,10408,2194,4123,6294,6329,4097,2059,10416,6168,14362,12323,2049,10264,10264,12433,10252,10249,173,8227,184,6170]

theorem envBound42069 : H12AffineFastState.Bounded env42069 := by
  intro p hp
  have h : env42069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42068_42069 : H12AffineEnvironment.transform 13 8242 env42068 = env42069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8242 env42068 == env42069) = true)

theorem identity42069 : scanCanonicalize (H12AffineFastState.compose env42069 (packedSelected [2,3,6,7,8,9,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 163) := by decide +kernel

theorem selectedBound42069 : packedSelected [2,3,6,7,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env42070 : List Nat := [2,4,8,16,32,17,128,173,137,4,2048,163,8192,8242,2075,10408,2194,184,2101,2074,162,2059,10416,2235,10425,8320,2049,10264,10264,8242,10252,10249,173,8227,184,2233]

theorem envBound42070 : H12AffineFastState.Bounded env42070 := by
  intro p hp
  have h : env42070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42069_42070 : H12AffineEnvironment.transform 11 163 env42069 = env42070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 163 env42069 == env42070) = true)

theorem identity42070 : scanCanonicalize (H12AffineFastState.compose env42070 (packedSelected [0,1,3,5,6,7,8,10] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound42070 : packedSelected [0,1,3,5,6,7,8,10] rootPS < 2^1333 := by decide +kernel

def env42071 : List Nat := [2,4,8,16,32,17,128,173,137,4,2048,163,25,43,2075,2225,2194,184,2101,2074,162,2059,2217,2235,2208,153,2049,2049,2049,43,2069,2064,173,58,184,2233]

theorem envBound42071 : H12AffineFastState.Bounded env42071 := by
  intro p hp
  have h : env42071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42070_42071 : H12AffineEnvironment.transform 12 25 env42070 = env42071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env42070 == env42071) = true)

theorem identity42071 : scanCanonicalize (H12AffineFastState.compose env42071 (packedSelected [1,2,4,5,6,7] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound42071 : packedSelected [1,2,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env42072 : List Nat := [2,4,8,16,32,17,9,36,0,4,2048,42,25,43,2075,2104,2075,49,2101,2074,43,2059,2080,2098,2089,16,2049,2049,2049,43,2069,2064,36,58,49,2096]

theorem envBound42072 : H12AffineFastState.Bounded env42072 := by
  intro p hp
  have h : env42072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42071_42072 : H12AffineEnvironment.transform 6 9 env42071 = env42072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env42071 == env42072) = true)

theorem identity42072 : scanCanonicalize (H12AffineFastState.compose env42072 (packedSelected [2,3,5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound42072 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env42073 : List Nat := [2,4,8,11,32,10,9,36,0,4,2048,42,2,43,2048,2083,2048,42,2094,2049,43,2059,2080,2089,2089,11,2049,2049,2049,43,2062,2059,36,33,42,2091]

theorem envBound42073 : H12AffineFastState.Bounded env42073 := by
  intro p hp
  have h : env42073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42072_42073 : H12AffineEnvironment.transform 3 11 env42072 = env42073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env42072 == env42073) = true)

theorem identity42073 : scanCanonicalize (H12AffineFastState.compose env42073 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound42073 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42074 : List Nat := [2,4,8,11,11,10,9,15,0,4,2048,1,2,0,2048,2056,2048,1,2053,2049,0,2059,2059,2050,2050,11,2049,2049,2049,0,2062,2059,15,10,1,2048]

theorem envBound42074 : H12AffineFastState.Bounded env42074 := by
  intro p hp
  have h : env42074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42073_42074 : H12AffineEnvironment.transform 4 11 env42073 = env42074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env42073 == env42074) = true)

theorem identity42074 : scanCanonicalize (H12AffineFastState.compose env42074 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound42074 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42075 : List Nat := [2,4,4,7,7,6,5,3,0,4,2048,1,2,0,2048,2052,2048,1,2053,2049,0,2055,2055,2050,2050,7,2049,2049,2049,0,2050,2055,3,6,1,2048]

theorem envBound42075 : H12AffineFastState.Bounded env42075 := by
  intro p hp
  have h : env42075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42074_42075 : H12AffineEnvironment.transform 2 4 env42074 = env42075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env42074 == env42075) = true)

theorem identity42075 : scanCanonicalize (H12AffineFastState.compose env42075 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound42075 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env42076 : List Nat := [2,4,4,7,7,6,5,3,0,4,0,1,2,0,0,4,0,1,5,1,0,7,7,2,2,7,1,1,1,0,2,7,3,6,1,0]

theorem envBound42076 : H12AffineFastState.Bounded env42076 := by
  intro p hp
  have h : env42076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42075_42076 : H12AffineEnvironment.transform 10 0 env42075 = env42076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env42075 == env42076) = true)

def env42077 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147521,58682,143497,20496,508154,148800,148801,96346,90426,148816,256,16400,1344,135680]

theorem envBound42077 : H12AffineFastState.Bounded env42077 := by
  intro p hp
  have h : env42077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42015_42077 : H12AffineEnvironment.transform 18 136193 env42015 = env42077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136193 env42015 == env42077) = true)

def env42078 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147521,58518,143497,20496,508154,148716,148717,96346,90262,148732,172,16400,1260,135680]

theorem envBound42078 : H12AffineFastState.Bounded env42078 := by
  intro p hp
  have h : env42078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42077_42078 : H12AffineEnvironment.transform 7 172 env42077 = env42078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env42077 == env42078) = true)

def env42079 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61568,147473,58518,143497,20496,508074,148668,148669,96266,90262,148652,172,16400,1212,135680]

theorem envBound42079 : H12AffineFastState.Bounded env42079 := by
  intro p hp
  have h : env42079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42078_42079 : H12AffineEnvironment.transform 5 16 env42078 = env42079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env42078 == env42079) = true)

theorem identity42079 : scanCanonicalize (H12AffineFastState.compose env42079 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 208054) := by decide +kernel

theorem selectedBound42079 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env42080 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,208054,136193,32769,4097,61568,147473,58518,143497,20496,60444,148668,148669,96266,90262,148652,172,16400,1212,135680]

theorem envBound42080 : H12AffineFastState.Bounded env42080 := by
  intro p hp
  have h : env42080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42079_42080 : H12AffineEnvironment.transform 17 208054 env42079 = env42080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 208054 env42079 == env42080) = true)

theorem identity42080 : scanCanonicalize (H12AffineFastState.compose env42080 (packedSelected [1,3,5,7,8,10,20,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53282) := by decide +kernel

theorem selectedBound42080 : packedSelected [1,3,5,7,8,10,20,26,27] rootPS < 2^1333 := by decide +kernel

def env42081 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,53282,131072,195732,136193,32769,4097,61568,147473,58518,143497,20496,60444,148668,148669,43048,45236,148652,172,16400,1212,135680]

theorem envBound42081 : H12AffineFastState.Bounded env42081 := by
  intro p hp
  have h : env42081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42080_42081 : H12AffineEnvironment.transform 15 53282 env42080 = env42081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53282 env42080 == env42081) = true)

theorem identity42081 : scanCanonicalize (H12AffineFastState.compose env42081 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(16+1) ^^^ 21692) := by decide +kernel

theorem selectedBound42081 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env42082 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,53282,21692,43048,16573,32769,4097,61568,5293,58518,25653,20496,60444,4096,4097,43048,45236,4112,172,16400,1212,18108]

theorem envBound42082 : H12AffineFastState.Bounded env42082 := by
  intro p hp
  have h : env42082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42081_42082 : H12AffineEnvironment.transform 16 21692 env42081 = env42082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 21692 env42081 == env42082) = true)

theorem identity42082 : scanCanonicalize (H12AffineFastState.compose env42082 (packedSelected [4,9,20] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound42082 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env42083 : List Nat := [2,4,8,16,32,16,128,172,512,4,2048,4096,8192,16384,32768,53282,20664,43048,16573,32769,4097,61568,4265,57490,24625,20496,59416,4096,4097,43048,45236,4112,172,16400,184,17080]

theorem envBound42083 : H12AffineFastState.Bounded env42083 := by
  intro p hp
  have h : env42083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42082_42083 : H12AffineEnvironment.transform 9 4 env42082 = env42083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env42082 == env42083) = true)

theorem identity42083 : scanCanonicalize (H12AffineFastState.compose env42083 (packedSelected [0,2,3,5,6,9,11,13,17] rootPS)) = affineNative (2^(14+1) ^^^ 513) := by decide +kernel

theorem selectedBound42083 : packedSelected [0,2,3,5,6,9,11,13,17] rootPS < 2^1333 := by decide +kernel

def env42084 : List Nat := [2,4,8,16,32,16,128,172,512,4,2048,4096,8192,16384,513,21027,20664,10793,16573,512,4097,29313,4265,25235,24625,20496,27161,4096,4097,10793,12981,4112,172,16400,184,17080]

theorem envBound42084 : H12AffineFastState.Bounded env42084 := by
  intro p hp
  have h : env42084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42083_42084 : H12AffineEnvironment.transform 14 513 env42083 = env42084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 513 env42083 == env42084) = true)

theorem identity42084 : scanCanonicalize (H12AffineFastState.compose env42084 (packedSelected [1,3,4,6,7,11,13,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 6291) := by decide +kernel

theorem selectedBound42084 : packedSelected [1,3,4,6,7,11,13,15,16] rootPS < 2^1333 := by decide +kernel

def env42085 : List Nat := [2,4,8,16,32,16,128,172,512,4,2048,4096,8192,6291,513,2736,2091,10793,6190,512,4097,10770,4265,14848,14498,2179,12938,4096,4097,10793,12981,4112,172,6275,184,6699]

theorem envBound42085 : H12AffineFastState.Bounded env42085 := by
  intro p hp
  have h : env42085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42084_42085 : H12AffineEnvironment.transform 13 6291 env42084 = env42085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6291 env42084 == env42085) = true)

theorem identity42085 : scanCanonicalize (H12AffineFastState.compose env42085 (packedSelected [0,2,3,5,7,15] rootPS)) = affineNative (2^(12+1) ^^^ 4649) := by decide +kernel

theorem selectedBound42085 : packedSelected [0,2,3,5,7,15] rootPS < 2^1333 := by decide +kernel

def env42086 : List Nat := [2,4,8,16,32,16,128,172,512,4,2048,4096,4649,6291,513,2736,2091,6144,6190,512,4097,6203,4265,2089,2699,2179,163,4096,4097,6144,156,4112,172,6275,184,6699]

theorem envBound42086 : H12AffineFastState.Bounded env42086 := by
  intro p hp
  have h : env42086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42085_42086 : H12AffineEnvironment.transform 12 4649 env42085 = env42086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4649 env42085 == env42086) = true)

theorem identity42086 : scanCanonicalize (H12AffineFastState.compose env42086 (packedSelected [0,2,4,5,6,8,10,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 162) := by decide +kernel

theorem selectedBound42086 : packedSelected [0,2,4,5,6,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env42087 : List Nat := [2,4,8,16,32,16,128,172,512,4,2048,162,651,2097,513,2736,2091,2210,2188,512,163,2201,11,2089,2699,2179,163,162,163,2210,156,178,172,2081,184,2697]

theorem envBound42087 : H12AffineFastState.Bounded env42087 := by
  intro p hp
  have h : env42087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42086_42087 : H12AffineEnvironment.transform 11 162 env42086 = env42087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 162 env42086 == env42087) = true)

theorem identity42087 : scanCanonicalize (H12AffineFastState.compose env42087 (packedSelected [0,4,5,8,10] rootPS)) = affineNative (2^(10+1) ^^^ 648) := by decide +kernel

theorem selectedBound42087 : packedSelected [0,4,5,8,10] rootPS < 2^1333 := by decide +kernel

def env42088 : List Nat := [2,4,8,16,32,16,128,172,512,4,648,162,651,697,513,56,675,554,516,512,163,529,11,673,3,523,163,162,163,554,156,178,172,681,184,1]

theorem envBound42088 : H12AffineFastState.Bounded env42088 := by
  intro p hp
  have h : env42088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42087_42088 : H12AffineEnvironment.transform 10 648 env42087 = env42088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 648 env42087 == env42088) = true)

theorem identity42088 : scanCanonicalize (H12AffineFastState.compose env42088 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound42088 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env42089 : List Nat := [2,4,8,16,32,16,56,20,512,4,560,26,563,513,513,56,539,554,516,512,27,529,11,537,3,523,27,26,27,554,36,10,20,529,0,1]

theorem envBound42089 : H12AffineFastState.Bounded env42089 := by
  intro p hp
  have h : env42089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42088_42089 : H12AffineEnvironment.transform 6 56 env42088 = env42089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env42088 == env42089) = true)

theorem identity42089 : scanCanonicalize (H12AffineFastState.compose env42089 (packedSelected [2,4,7] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound42089 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env42090 : List Nat := [2,4,8,16,32,16,56,20,27,4,43,26,40,26,26,56,0,49,31,27,27,10,11,2,3,16,27,26,27,49,36,10,20,10,0,1]

theorem envBound42090 : H12AffineFastState.Bounded env42090 := by
  intro p hp
  have h : env42090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42089_42090 : H12AffineEnvironment.transform 8 27 env42089 = env42090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env42089 == env42090) = true)

def env42091 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61569,147472,58518,143497,20496,508075,148669,148668,96267,90262,148653,172,16400,1213,135680]

theorem envBound42091 : H12AffineFastState.Bounded env42091 := by
  intro p hp
  have h : env42091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42078_42091 : H12AffineEnvironment.transform 5 17 env42078 = env42091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env42078 == env42091) = true)

theorem identity42091 : scanCanonicalize (H12AffineFastState.compose env42091 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 99487) := by decide +kernel

theorem selectedBound42091 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env42092 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,99487,262144,102558,32769,4097,61569,115855,58518,111638,20496,279604,114722,114723,96267,90262,114738,172,16400,1213,104095]

theorem envBound42092 : H12AffineFastState.Bounded env42092 := by
  intro p hp
  have h : env42092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42091_42092 : H12AffineEnvironment.transform 16 99487 env42091 = env42092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 99487 env42091 == env42092) = true)

theorem identity42092 : scanCanonicalize (H12AffineFastState.compose env42092 (packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS)) = affineNative (2^(15+1) ^^^ 37019) := by decide +kernel

theorem selectedBound42092 : packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS < 2^1333 := by decide +kernel

def env42093 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,37019,5124,262144,5,32769,4097,61569,21524,58518,9357,20496,279604,20665,20664,59536,61453,20649,172,16400,1213,1540]

theorem envBound42093 : H12AffineFastState.Bounded env42093 := by
  intro p hp
  have h : env42093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42092_42093 : H12AffineEnvironment.transform 15 37019 env42092 = env42093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 37019 env42092 == env42093) = true)

theorem identity42093 : scanCanonicalize (H12AffineFastState.compose env42093 (packedSelected [3,7,10,20,24,26,27] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound42093 : packedSelected [3,7,10,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env42094 : List Nat := [2,4,8,16,32,17,128,172,512,4,2048,4096,8192,16384,32768,37019,4096,262144,5,32769,4097,61569,20496,57490,8329,20496,278576,20665,20664,59536,61453,20649,172,16400,185,512]

theorem envBound42094 : H12AffineFastState.Bounded env42094 := by
  intro p hp
  have h : env42094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42093_42094 : H12AffineEnvironment.transform 9 4 env42093 = env42094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env42093 == env42094) = true)

theorem identity42094 : scanCanonicalize (H12AffineFastState.compose env42094 (packedSelected [4,9,16] rootPS)) = affineNative (2^(13+1) ^^^ 184) := by decide +kernel

theorem selectedBound42094 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env42095 : List Nat := [2,4,8,16,32,17,128,172,512,4,2048,4096,8192,184,32768,37019,4096,262144,5,32769,4097,45113,4264,41002,8329,4264,262280,4097,4096,43048,45237,4113,172,168,185,512]

theorem envBound42095 : H12AffineFastState.Bounded env42095 := by
  intro p hp
  have h : env42095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42094_42095 : H12AffineEnvironment.transform 13 184 env42094 = env42095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 184 env42094 == env42095) = true)

theorem identity42095 : scanCanonicalize (H12AffineFastState.compose env42095 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 4648) := by decide +kernel

theorem selectedBound42095 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env42096 : List Nat := [2,4,8,16,32,17,128,172,512,4,2048,4096,4648,184,32768,37019,4096,262144,5,32769,4097,33297,4264,37378,4769,4264,262280,4097,4096,39424,33437,4113,172,168,185,512]

theorem envBound42096 : H12AffineFastState.Bounded env42096 := by
  intro p hp
  have h : env42096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42095_42096 : H12AffineEnvironment.transform 12 4648 env42095 = env42096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4648 env42095 == env42096) = true)

theorem identity42096 : scanCanonicalize (H12AffineFastState.compose env42096 (packedSelected [1,3,13] rootPS)) = affineNative (2^(14+1) ^^^ 560) := by decide +kernel

theorem selectedBound42096 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env42097 : List Nat := [2,4,8,16,32,17,128,172,512,4,2048,4096,4648,184,560,4779,4096,262144,5,561,4097,33,4264,4146,4769,4264,262280,4097,4096,6192,173,4113,172,168,185,512]

theorem envBound42097 : H12AffineFastState.Bounded env42097 := by
  intro p hp
  have h : env42097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42096_42097 : H12AffineEnvironment.transform 14 560 env42096 = env42097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 560 env42096 == env42097) = true)

theorem identity42097 : scanCanonicalize (H12AffineFastState.compose env42097 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 554) := by decide +kernel

theorem selectedBound42097 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env42098 : List Nat := [2,4,8,16,32,17,128,172,512,4,2048,4096,4648,184,560,4779,4096,554,5,561,4097,33,4264,4146,4769,4264,674,4097,4096,6192,173,4113,172,168,185,512]

theorem envBound42098 : H12AffineFastState.Bounded env42098 := by
  intro p hp
  have h : env42098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42097_42098 : H12AffineEnvironment.transform 17 554 env42097 = env42098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 554 env42097 == env42098) = true)

def env42099 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147521,58519,143497,20496,508154,148717,148716,96346,90263,148733,173,16400,1261,135680]

theorem envBound42099 : H12AffineFastState.Bounded env42099 := by
  intro p hp
  have h : env42099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42077_42099 : H12AffineEnvironment.transform 7 173 env42077 = env42099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env42077 == env42099) = true)

def env42100 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61568,147473,58519,143497,20496,508074,148669,148668,96266,90263,148653,173,16400,1213,135680]

theorem envBound42100 : H12AffineFastState.Bounded env42100 := by
  intro p hp
  have h : env42100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42099_42100 : H12AffineEnvironment.transform 5 16 env42099 = env42100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env42099 == env42100) = true)

theorem identity42100 : scanCanonicalize (H12AffineFastState.compose env42100 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 137352) := by decide +kernel

theorem selectedBound42100 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env42101 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,137352,136193,32769,4097,61568,147473,58519,143497,20496,120866,148669,148668,96266,90263,148653,173,16400,1213,135680]

theorem envBound42101 : H12AffineFastState.Bounded env42101 := by
  intro p hp
  have h : env42101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42100_42101 : H12AffineEnvironment.transform 17 137352 env42100 = env42101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137352 env42100 == env42101) = true)

theorem identity42101 : scanCanonicalize (H12AffineFastState.compose env42101 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(16+1) ^^^ 62492) := by decide +kernel

theorem selectedBound42101 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env42102 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,62492,60564,57373,32769,4097,61568,46093,58519,50325,20496,120866,45217,45216,96266,90263,45233,173,16400,1213,58908]

theorem envBound42102 : H12AffineFastState.Bounded env42102 := by
  intro p hp
  have h : env42102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42101_42102 : H12AffineEnvironment.transform 16 62492 env42101 = env42102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 62492 env42101 == env42102) = true)

theorem identity42102 : scanCanonicalize (H12AffineFastState.compose env42102 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 54310) := by decide +kernel

theorem selectedBound42102 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env42103 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,54310,62492,60564,57373,32769,4097,61568,46093,58519,50325,20496,3076,45217,45216,44076,46257,45233,173,16400,1213,58908]

theorem envBound42103 : H12AffineFastState.Bounded env42103 := by
  intro p hp
  have h : env42103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42102_42103 : H12AffineEnvironment.transform 15 54310 env42102 = env42103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54310 env42102 == env42103) = true)

theorem identity42103 : scanCanonicalize (H12AffineFastState.compose env42103 (packedSelected [0,1,2,6,7,8,13,17,19,20,21] rootPS)) = affineNative (2^(12+1) ^^^ 7829) := by decide +kernel

theorem selectedBound42103 : packedSelected [0,1,2,6,7,8,13,17,19,20,21] rootPS < 2^1333 := by decide +kernel

def env42104 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,7829,16384,32768,54310,51849,53761,56968,32769,4097,52757,35480,55810,50325,20496,3076,36404,36405,37561,35364,36388,173,16400,1213,55433]

theorem envBound42104 : H12AffineFastState.Bounded env42104 := by
  intro p hp
  have h : env42104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42103_42104 : H12AffineEnvironment.transform 12 7829 env42103 = env42104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7829 env42103 == env42104) = true)

theorem identity42104 : scanCanonicalize (H12AffineFastState.compose env42104 (packedSelected [0,1,2,6,7,8,13,18,20,23,26] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound42104 : packedSelected [0,1,2,6,7,8,13,18,20,23,26] rootPS < 2^1333 := by decide +kernel

def env42105 : List Nat := [2,4,8,16,32,16,128,173,512,5,2048,4096,6800,16384,32768,53283,51849,53761,55949,32769,4097,51728,35480,55810,49296,20496,2049,35377,35376,37561,35364,35361,173,16400,184,55433]

theorem envBound42105 : H12AffineFastState.Bounded env42105 := by
  intro p hp
  have h : env42105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42104_42105 : H12AffineEnvironment.transform 9 5 env42104 = env42105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env42104 == env42105) = true)

theorem identity42105 : scanCanonicalize (H12AffineFastState.compose env42105 (packedSelected [0,1,6,8,9,10,12,13,15] rootPS)) = affineNative (2^(14+1) ^^^ 2184) := by decide +kernel

theorem selectedBound42105 : packedSelected [0,1,6,8,9,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env42106 : List Nat := [2,4,8,16,32,16,128,173,512,5,2048,4096,6800,16384,2184,22699,16897,23177,20997,2185,4097,17048,528,21130,18456,20496,2049,697,696,6705,684,681,173,16400,184,20481]

theorem envBound42106 : H12AffineFastState.Bounded env42106 := by
  intro p hp
  have h : env42106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42105_42106 : H12AffineEnvironment.transform 14 2184 env42105 = env42106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2184 env42105 == env42106) = true)

theorem identity42106 : scanCanonicalize (H12AffineFastState.compose env42106 (packedSelected [2,4,5,7,8,10,12,13] rootPS)) = affineNative (2^(13+1) ^^^ 4122) := by decide +kernel

theorem selectedBound42106 : packedSelected [2,4,5,7,8,10,12,13] rootPS < 2^1333 := by decide +kernel

def env42107 : List Nat := [2,4,8,16,32,16,128,173,512,5,2048,4096,6800,4122,2184,2225,4635,2707,543,2185,4097,4738,528,656,6146,10,2049,697,696,6705,684,681,173,4106,184,27]

theorem envBound42107 : H12AffineFastState.Bounded env42107 := by
  intro p hp
  have h : env42107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42106_42107 : H12AffineEnvironment.transform 13 4122 env42106 = env42107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4122 env42106 == env42107) = true)

theorem identity42107 : scanCanonicalize (H12AffineFastState.compose env42107 (packedSelected [1,6,8,10,11] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound42107 : packedSelected [1,6,8,10,11] rootPS < 2^1333 := by decide +kernel

def env42108 : List Nat := [2,4,8,16,32,16,18,63,512,5,2048,4096,6658,4122,2074,2083,4635,2561,543,2075,4097,4624,528,514,6146,10,2049,555,554,6705,574,571,63,4106,42,27]

theorem envBound42108 : H12AffineFastState.Bounded env42108 := by
  intro p hp
  have h : env42108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42107_42108 : H12AffineEnvironment.transform 6 18 env42107 = env42108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env42107 == env42108) = true)

theorem identity42108 : scanCanonicalize (H12AffineFastState.compose env42108 (packedSelected [1,2,4,5,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 43) := by decide +kernel

theorem selectedBound42108 : packedSelected [1,2,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env42109 : List Nat := [2,4,8,16,32,16,18,63,512,5,2048,43,2601,49,2074,2083,560,2561,543,2075,42,571,528,514,2089,10,2049,555,554,2586,574,571,63,33,42,27]

theorem envBound42109 : H12AffineFastState.Bounded env42109 := by
  intro p hp
  have h : env42109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42108_42109 : H12AffineEnvironment.transform 11 43 env42108 = env42109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 43 env42108 == env42109) = true)

theorem identity42109 : scanCanonicalize (H12AffineFastState.compose env42109 (packedSelected [1,5,6] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound42109 : packedSelected [1,5,6] rootPS < 2^1333 := by decide +kernel

def env42110 : List Nat := [2,4,8,16,32,16,18,63,27,5,2048,43,2098,49,2074,2083,43,2074,4,2075,42,32,11,25,2089,10,2049,48,49,2049,37,32,63,33,42,27]

theorem envBound42110 : H12AffineFastState.Bounded env42110 := by
  intro p hp
  have h : env42110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42109_42110 : H12AffineEnvironment.transform 8 27 env42109 = env42110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env42109 == env42110) = true)

theorem identity42110 : scanCanonicalize (H12AffineFastState.compose env42110 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound42110 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env42111 : List Nat := [2,4,8,16,32,16,18,63,27,5,42,43,24,49,48,9,43,48,4,49,42,32,11,25,3,10,43,48,49,43,37,32,63,33,42,27]

theorem envBound42111 : H12AffineFastState.Bounded env42111 := by
  intro p hp
  have h : env42111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42110_42111 : H12AffineEnvironment.transform 10 42 env42110 = env42111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env42110 == env42111) = true)

def env42112 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61569,147472,58519,143497,20496,508075,148668,148669,96267,90263,148652,173,16400,1212,135680]

theorem envBound42112 : H12AffineFastState.Bounded env42112 := by
  intro p hp
  have h : env42112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42099_42112 : H12AffineEnvironment.transform 5 17 env42099 = env42112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env42099 == env42112) = true)

theorem identity42112 : scanCanonicalize (H12AffineFastState.compose env42112 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 45216) := by decide +kernel

theorem selectedBound42112 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env42113 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,45216,262144,42145,32769,4097,61569,61616,58519,32809,20496,356363,62492,62493,96267,90263,62476,173,16400,1212,41632]

theorem envBound42113 : H12AffineFastState.Bounded env42113 := by
  intro p hp
  have h : env42113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42112_42113 : H12AffineEnvironment.transform 16 45216 env42112 = env42113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45216 env42112 == env42113) = true)

theorem identity42113 : scanCanonicalize (H12AffineFastState.compose env42113 (packedSelected [16,20] rootPS)) = affineNative (2^(17+1) ^^^ 2185) := by decide +kernel

theorem selectedBound42113 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env42114 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,45216,2185,42145,32769,4097,61569,61616,58519,32809,20496,96386,62492,62493,96267,90263,62476,173,16400,1212,41632]

theorem envBound42114 : H12AffineFastState.Bounded env42114 := by
  intro p hp
  have h : env42114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42113_42114 : H12AffineEnvironment.transform 17 2185 env42113 = env42114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2185 env42113 == env42114) = true)

theorem identity42114 : scanCanonicalize (H12AffineFastState.compose env42114 (packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 184) := by decide +kernel

theorem selectedBound42114 : packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env42115 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,184,32768,65536,45216,2185,42145,32769,4097,45113,45064,42031,32809,4264,79930,46244,46245,80051,73775,46260,173,168,1212,41632]

theorem envBound42115 : H12AffineFastState.Bounded env42115 := by
  intro p hp
  have h : env42115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42114_42115 : H12AffineEnvironment.transform 13 184 env42114 = env42115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 184 env42114 == env42115) = true)

theorem identity42115 : scanCanonicalize (H12AffineFastState.compose env42115 (packedSelected [1,4,5,8,9,16,17,21,24] rootPS)) = affineNative (2^(15+1) ^^^ 13375) := by decide +kernel

theorem selectedBound42115 : packedSelected [1,4,5,8,9,16,17,21,24] rootPS < 2^1333 := by decide +kernel

def env42116 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,184,32768,13375,45216,2185,42145,32769,4097,45113,45064,42031,32809,4264,3077,46244,46245,3212,5136,46260,173,168,1212,41632]

theorem envBound42116 : H12AffineFastState.Bounded env42116 := by
  intro p hp
  have h : env42116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42115_42116 : H12AffineEnvironment.transform 15 13375 env42115 = env42116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13375 env42115 == env42116) = true)

theorem identity42116 : scanCanonicalize (H12AffineFastState.compose env42116 (packedSelected [0,2,3,5,7,10,11,15,16] rootPS)) = affineNative (2^(9+1) ^^^ 700) := by decide +kernel

theorem selectedBound42116 : packedSelected [0,2,3,5,7,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env42117 : List Nat := [2,4,8,16,32,17,128,173,512,700,2048,4096,8192,184,32768,12931,45216,2185,41501,32769,4097,45113,45064,41619,32809,4264,2745,45592,45593,2608,4780,45576,173,168,512,41632]

theorem envBound42117 : H12AffineFastState.Bounded env42117 := by
  intro p hp
  have h : env42117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42116_42117 : H12AffineEnvironment.transform 9 700 env42116 = env42117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 700 env42116 == env42117) = true)

theorem identity42117 : scanCanonicalize (H12AffineFastState.compose env42117 (packedSelected [2,5,6,7,8,9,12,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 2602) := by decide +kernel

theorem selectedBound42117 : packedSelected [2,5,6,7,8,9,12,13,15] rootPS < 2^1333 := by decide +kernel

def env42118 : List Nat := [2,4,8,16,32,17,128,173,512,700,2048,2602,8192,184,32768,10409,43658,2185,41501,32769,2603,43539,43554,41619,32809,2690,2745,43058,43059,2608,2182,43042,173,168,512,41632]

theorem envBound42118 : H12AffineFastState.Bounded env42118 := by
  intro p hp
  have h : env42118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42117_42118 : H12AffineEnvironment.transform 11 2602 env42117 = env42118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2602 env42117 == env42118) = true)

theorem identity42118 : scanCanonicalize (H12AffineFastState.compose env42118 (packedSelected [3,7,8,9,10,12,13,17] rootPS)) = affineNative (2^(14+1) ^^^ 2744) := by decide +kernel

theorem selectedBound42118 : packedSelected [3,7,8,9,10,12,13,17] rootPS < 2^1333 := by decide +kernel

def env42119 : List Nat := [2,4,8,16,32,17,128,173,512,700,2048,2602,8192,184,2744,10409,8242,2185,10405,2745,2603,8363,8346,10283,2705,2690,2745,8842,8843,2608,2182,8858,173,168,512,10264]

theorem envBound42119 : H12AffineFastState.Bounded env42119 := by
  intro p hp
  have h : env42119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42118_42119 : H12AffineEnvironment.transform 14 2744 env42118 = env42119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2744 env42118 == env42119) = true)

theorem identity42119 : scanCanonicalize (H12AffineFastState.compose env42119 (packedSelected [0,1,5,6,9,10] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound42119 : packedSelected [0,1,5,6,9,10] rootPS < 2^1333 := by decide +kernel

def env42120 : List Nat := [2,4,8,16,32,17,128,173,512,700,49,539,8192,184,649,8344,8242,184,8340,648,538,8363,8346,8218,672,691,648,8842,8843,513,183,8858,173,168,512,8233]

theorem envBound42120 : H12AffineFastState.Bounded env42120 := by
  intro p hp
  have h : env42120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42119_42120 : H12AffineEnvironment.transform 10 49 env42119 = env42120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env42119 == env42120) = true)

theorem identity42120 : scanCanonicalize (H12AffineFastState.compose env42120 (packedSelected [0,2,3,4,6,7,8,9,11] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound42120 : packedSelected [0,2,3,4,6,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env42121 : List Nat := [2,4,8,16,32,17,128,173,43,151,49,48,8192,184,162,8344,8242,184,8340,163,49,8363,8346,8218,139,152,163,8353,8352,42,183,8369,173,168,43,8233]

theorem envBound42121 : H12AffineFastState.Bounded env42121 := by
  intro p hp
  have h : env42121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42120_42121 : H12AffineEnvironment.transform 8 43 env42120 = env42121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env42120 == env42121) = true)

theorem identity42121 : scanCanonicalize (H12AffineFastState.compose env42121 (packedSelected [1,3,5,6,8] rootPS)) = affineNative (2^(12+1) ^^^ 51) := by decide +kernel

theorem selectedBound42121 : packedSelected [1,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env42122 : List Nat := [2,4,8,16,32,17,128,173,43,151,49,48,51,184,162,171,1,184,167,163,49,152,169,41,139,152,163,146,147,42,183,130,173,168,43,26]

theorem envBound42122 : H12AffineFastState.Bounded env42122 := by
  intro p hp
  have h : env42122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42121_42122 : H12AffineEnvironment.transform 12 51 env42121 = env42122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 51 env42121 == env42122) = true)

theorem identity42122 : scanCanonicalize (H12AffineFastState.compose env42122 (packedSelected [2,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound42122 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env42123 : List Nat := [2,4,8,16,32,17,18,63,43,5,49,48,51,42,48,57,1,42,53,49,49,10,59,41,25,10,49,0,1,42,37,16,63,58,43,26]

theorem envBound42123 : H12AffineFastState.Bounded env42123 := by
  intro p hp
  have h : env42123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42122_42123 : H12AffineEnvironment.transform 6 18 env42122 = env42123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env42122 == env42123) = true)

theorem identity42123 : scanCanonicalize (H12AffineFastState.compose env42123 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound42123 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env42124 : List Nat := [2,4,8,10,32,11,8,37,43,5,43,42,41,42,42,35,1,42,47,43,43,10,33,41,3,10,43,0,1,42,37,10,37,32,43,0]

theorem envBound42124 : H12AffineFastState.Bounded env42124 := by
  intro p hp
  have h : env42124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42123_42124 : H12AffineEnvironment.transform 3 10 env42123 = env42124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env42123 == env42124) = true)

theorem identity42124 : scanCanonicalize (H12AffineFastState.compose env42124 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound42124 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42125 : List Nat := [2,4,8,10,10,11,8,15,1,5,1,0,3,0,0,9,1,0,5,1,1,10,11,3,3,10,1,0,1,0,15,10,15,10,1,0]

theorem envBound42125 : H12AffineFastState.Bounded env42125 := by
  intro p hp
  have h : env42125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42124_42125 : H12AffineEnvironment.transform 4 10 env42124 = env42125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env42124 == env42125) = true)

theorem identity42125 : scanCanonicalize (H12AffineFastState.compose env42125 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound42125 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42126 : List Nat := [2,4,6,4,4,5,6,1,1,5,1,0,3,0,0,7,1,0,5,1,1,4,5,3,3,4,1,0,1,0,1,4,1,4,1,0]

theorem envBound42126 : H12AffineFastState.Bounded env42126 := by
  intro p hp
  have h : env42126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42125_42126 : H12AffineEnvironment.transform 2 6 env42125 = env42126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env42125 == env42126) = true)

theorem identity42126 : scanCanonicalize (H12AffineFastState.compose env42126 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound42126 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42127 : List Nat := [2,3,1,3,3,2,1,1,1,2,1,0,3,0,0,0,1,0,2,1,1,3,2,3,3,3,1,0,1,0,1,3,1,3,1,0]

theorem envBound42127 : H12AffineFastState.Bounded env42127 := by
  intro p hp
  have h : env42127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42126_42127 : H12AffineEnvironment.transform 1 3 env42126 = env42127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env42126 == env42127) = true)

theorem identity42127 : scanCanonicalize (H12AffineFastState.compose env42127 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound42127 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env42128 : List Nat := [0,1,1,1,1,0,1,1,1,0,1,0,1,0,0,0,1,0,0,1,1,1,0,1,1,1,1,0,1,0,1,1,1,1,1,0]

theorem envBound42128 : H12AffineFastState.Bounded env42128 := by
  intro p hp
  have h : env42128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42127_42128 : H12AffineEnvironment.transform 0 0 env42127 = env42128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env42127 == env42128) = true)

def env42129 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147521,16777216,533640,672785,17245633,148800,545088,96346,16876544,16949355,256,676880,1345,525825]

theorem envBound42129 : H12AffineFastState.Bounded env42129 := by
  intro p hp
  have h : env42129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42013_42129 : H12AffineEnvironment.transform 26 17245633 env42013 = env42129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245633 env42013 == env42129) = true)

theorem identity42129 : scanCanonicalize (H12AffineFastState.compose env42129 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 41003) := by decide +kernel

theorem selectedBound42129 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env42130 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147521,41003,533640,672785,493034,148800,545088,96346,74795,131136,256,676880,1345,525825]

theorem envBound42130 : H12AffineFastState.Bounded env42130 := by
  intro p hp
  have h : env42130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42129_42130 : H12AffineEnvironment.transform 23 41003 env42129 = env42130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41003 env42129 == env42130) = true)

def env42131 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147521,41003,143496,20497,493034,148800,148800,96346,74795,131136,256,16400,1345,135681]

theorem envBound42131 : H12AffineFastState.Bounded env42131 := by
  intro p hp
  have h : env42131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42130_42131 : H12AffineEnvironment.transform 18 136192 env42130 = env42131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136192 env42130 == env42131) = true)

def env42132 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147521,41003,143496,20497,492614,148716,148716,96346,74795,131136,172,16400,1261,135681]

theorem envBound42132 : H12AffineFastState.Bounded env42132 := by
  intro p hp
  have h : env42132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42131_42132 : H12AffineEnvironment.transform 7 172 env42131 = env42132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env42131 == env42132) = true)

def env42133 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61568,147473,41003,143496,20497,492566,148668,148668,96266,74795,131088,172,16400,1213,135681]

theorem envBound42133 : H12AffineFastState.Bounded env42133 := by
  intro p hp
  have h : env42133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42132_42133 : H12AffineEnvironment.transform 5 16 env42132 = env42133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env42132 == env42133) = true)

theorem identity42133 : scanCanonicalize (H12AffineFastState.compose env42133 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 114722) := by decide +kernel

theorem selectedBound42133 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env42134 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,114722,262144,119842,32769,4097,61568,98355,41003,127146,20497,279604,99486,99486,96266,74795,114738,172,16400,1213,119331]

theorem envBound42134 : H12AffineFastState.Bounded env42134 := by
  intro p hp
  have h : env42134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42133_42134 : H12AffineEnvironment.transform 16 114722 env42133 = env42134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114722 env42133 == env42134) = true)

theorem identity42134 : scanCanonicalize (H12AffineFastState.compose env42134 (packedSelected [3,10,16,18,19,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 80050) := by decide +kernel

theorem selectedBound42134 : packedSelected [3,10,16,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env42135 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,114722,80050,119842,32769,4097,61568,98355,41003,127146,20497,97414,99486,99486,96266,74795,114738,172,16400,1213,119331]

theorem envBound42135 : H12AffineFastState.Bounded env42135 := by
  intro p hp
  have h : env42135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42134_42135 : H12AffineEnvironment.transform 17 80050 env42134 = env42135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 80050 env42134 == env42135) = true)

theorem identity42135 : scanCanonicalize (H12AffineFastState.compose env42135 (packedSelected [7,16,18,19,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53283) := by decide +kernel

theorem selectedBound42135 : packedSelected [7,16,18,19,23,26,27] rootPS < 2^1333 := by decide +kernel

def env42136 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,53283,4097,59537,1025,32769,4097,61568,20496,41003,8329,20497,44197,21693,21693,43049,62472,4113,172,16400,1213,512]

theorem envBound42136 : H12AffineFastState.Bounded env42136 := by
  intro p hp
  have h : env42136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42135_42136 : H12AffineEnvironment.transform 15 53283 env42135 = env42136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53283 env42135 == env42136) = true)

theorem identity42136 : scanCanonicalize (H12AffineFastState.compose env42136 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound42136 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env42137 : List Nat := [2,4,8,16,32,16,128,172,512,5,2048,4096,8192,16384,32768,53283,4097,59537,4,32769,4097,61568,20496,41003,8329,20497,43168,20664,20664,43049,61453,4113,172,16400,184,512]

theorem envBound42137 : H12AffineFastState.Bounded env42137 := by
  intro p hp
  have h : env42137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42136_42137 : H12AffineEnvironment.transform 9 5 env42136 = env42137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env42136 == env42137) = true)

theorem identity42137 : scanCanonicalize (H12AffineFastState.compose env42137 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 17032) := by decide +kernel

theorem selectedBound42137 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env42138 : List Nat := [2,4,8,16,32,16,128,172,512,5,2048,4096,8192,16384,17032,4779,4097,10777,4,17033,4097,12808,20496,25251,8329,20497,27176,20664,20664,27297,12933,4113,172,16400,184,512]

theorem envBound42138 : H12AffineFastState.Bounded env42138 := by
  intro p hp
  have h : env42138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42137_42138 : H12AffineEnvironment.transform 14 17032 env42137 = env42138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 17032 env42137 == env42138) = true)

theorem identity42138 : scanCanonicalize (H12AffineFastState.compose env42138 (packedSelected [0,3,4,8,13] rootPS)) = affineNative (2^(12+1) ^^^ 139) := by decide +kernel

theorem selectedBound42138 : packedSelected [0,3,4,8,13] rootPS < 2^1333 := by decide +kernel

def env42139 : List Nat := [2,4,8,16,32,16,128,172,512,5,2048,4096,139,16384,17032,4779,4097,2706,4,17033,4097,4739,20496,16936,2,20497,19107,20664,20664,18986,4622,4113,172,16400,184,512]

theorem envBound42139 : H12AffineFastState.Bounded env42139 := by
  intro p hp
  have h : env42139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42138_42139 : H12AffineEnvironment.transform 12 139 env42138 = env42139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 139 env42138 == env42139) = true)

theorem identity42139 : scanCanonicalize (H12AffineFastState.compose env42139 (packedSelected [1,2,4,5,7,11,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 6818) := by decide +kernel

theorem selectedBound42139 : packedSelected [1,2,4,5,7,11,12,15] rootPS < 2^1333 := by decide +kernel

def env42140 : List Nat := [2,4,8,16,32,16,128,172,512,5,2048,4096,139,6818,6186,4779,4097,2706,4,6187,4097,4739,2738,6282,2,2739,4097,2586,2586,4232,4622,4113,172,6834,184,512]

theorem envBound42140 : H12AffineFastState.Bounded env42140 := by
  intro p hp
  have h : env42140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42139_42140 : H12AffineEnvironment.transform 13 6818 env42139 = env42140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6818 env42139 == env42140) = true)

theorem identity42140 : scanCanonicalize (H12AffineFastState.compose env42140 (packedSelected [1,2,4,5,6,9,12] rootPS)) = affineNative (2^(10+1) ^^^ 184) := by decide +kernel

theorem selectedBound42140 : packedSelected [1,2,4,5,6,9,12] rootPS < 2^1333 := by decide +kernel

def env42141 : List Nat := [2,4,8,16,32,16,128,172,512,5,184,4096,139,4634,4242,4779,4097,554,4,4243,4097,4739,522,4146,2,523,4097,674,674,4232,4622,4113,172,4618,184,512]

theorem envBound42141 : H12AffineFastState.Bounded env42141 := by
  intro p hp
  have h : env42141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42140_42141 : H12AffineEnvironment.transform 10 184 env42140 = env42141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 184 env42140 == env42141) = true)

theorem identity42141 : scanCanonicalize (H12AffineFastState.compose env42141 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound42141 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env42142 : List Nat := [2,4,8,16,32,16,128,172,512,5,184,184,139,674,42,531,185,554,4,43,185,571,522,138,2,523,185,674,674,48,694,169,172,690,184,512]

theorem envBound42142 : H12AffineFastState.Bounded env42142 := by
  intro p hp
  have h : env42142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42141_42142 : H12AffineEnvironment.transform 11 184 env42141 = env42142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env42141 == env42142) = true)

theorem identity42142 : scanCanonicalize (H12AffineFastState.compose env42142 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound42142 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env42143 : List Nat := [2,4,8,16,32,16,128,172,27,5,184,184,139,185,42,8,185,49,4,43,185,32,17,138,2,16,185,185,185,48,173,169,172,169,184,27]

theorem envBound42143 : H12AffineFastState.Bounded env42143 := by
  intro p hp
  have h : env42143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42142_42143 : H12AffineEnvironment.transform 8 27 env42142 = env42143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env42142 == env42143) = true)

theorem identity42143 : scanCanonicalize (H12AffineFastState.compose env42143 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound42143 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42144 : List Nat := [2,4,8,7,32,7,128,172,12,5,175,175,139,174,42,8,174,38,4,43,174,32,6,138,2,7,174,174,174,39,173,169,172,169,175,12]

theorem envBound42144 : H12AffineFastState.Bounded env42144 := by
  intro p hp
  have h : env42144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42143_42144 : H12AffineEnvironment.transform 3 7 env42143 = env42144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env42143 == env42144) = true)

theorem identity42144 : scanCanonicalize (H12AffineFastState.compose env42144 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound42144 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42145 : List Nat := [2,4,8,7,11,7,128,135,12,5,132,132,139,133,1,8,133,13,4,0,133,11,6,138,2,7,133,133,133,12,134,130,135,130,132,12]

theorem envBound42145 : H12AffineFastState.Bounded env42145 := by
  intro p hp
  have h : env42145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42144_42145 : H12AffineEnvironment.transform 4 11 env42144 = env42145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env42144 == env42145) = true)

theorem identity42145 : scanCanonicalize (H12AffineFastState.compose env42145 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound42145 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env42146 : List Nat := [2,4,5,7,6,7,128,135,1,5,132,132,134,133,1,5,133,0,4,0,133,6,6,135,2,7,133,133,133,1,134,130,135,130,132,1]

theorem envBound42146 : H12AffineFastState.Bounded env42146 := by
  intro p hp
  have h : env42146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42145_42146 : H12AffineEnvironment.transform 2 5 env42145 = env42146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env42145 == env42146) = true)

def env42147 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61569,147472,41003,143496,20497,492567,148669,148669,96267,74795,131089,172,16400,1212,135681]

theorem envBound42147 : H12AffineFastState.Bounded env42147 := by
  intro p hp
  have h : env42147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42132_42147 : H12AffineEnvironment.transform 5 17 env42132 = env42147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env42132 == env42147) = true)

theorem identity42147 : scanCanonicalize (H12AffineFastState.compose env42147 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 223243) := by decide +kernel

theorem selectedBound42147 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env42148 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,223243,136192,32769,4097,61569,147472,41003,143496,20497,60444,148669,148669,96267,74795,131089,172,16400,1212,135681]

theorem envBound42148 : H12AffineFastState.Bounded env42148 := by
  intro p hp
  have h : env42148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42147_42148 : H12AffineEnvironment.transform 17 223243 env42147 = env42148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223243 env42147 == env42148) = true)

theorem identity42148 : scanCanonicalize (H12AffineFastState.compose env42148 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 28803) := by decide +kernel

theorem selectedBound42148 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env42149 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,28803,131072,137352,136192,32769,4097,61569,147472,41003,143496,20497,60444,148669,148669,2184,21672,131089,172,16400,1212,135681]

theorem envBound42149 : H12AffineFastState.Bounded env42149 := by
  intro p hp
  have h : env42149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42148_42149 : H12AffineEnvironment.transform 15 28803 env42148 = env42149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28803 env42148 == env42149) = true)

theorem identity42149 : scanCanonicalize (H12AffineFastState.compose env42149 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(14+1) ^^^ 24600) := by decide +kernel

theorem selectedBound42149 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env42150 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,24600,28803,131072,137352,136192,24601,4097,4249,147472,16435,143496,20497,3076,148669,148669,2184,21672,131089,172,16400,1212,135681]

theorem envBound42150 : H12AffineFastState.Bounded env42150 := by
  intro p hp
  have h : env42150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42149_42150 : H12AffineEnvironment.transform 14 24600 env42149 = env42150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 24600 env42149 == env42150) = true)

theorem identity42150 : scanCanonicalize (H12AffineFastState.compose env42150 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound42150 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env42151 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1212,9380,13375,131072,137352,136192,9381,4097,4249,132268,1167,143496,5293,3076,131073,131073,2184,4116,131089,172,1196,1212,135681]

theorem envBound42151 : H12AffineFastState.Bounded env42151 := by
  intro p hp
  have h : env42151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42150_42151 : H12AffineEnvironment.transform 13 1212 env42150 = env42151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env42150 == env42151) = true)

theorem identity42151 : scanCanonicalize (H12AffineFastState.compose env42151 (packedSelected [6,12,13,15] rootPS)) = affineNative (2^(16+1) ^^^ 1212) := by decide +kernel

theorem selectedBound42151 : packedSelected [6,12,13,15] rootPS < 2^1333 := by decide +kernel

def env42152 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1212,9380,13375,1212,7220,4284,9381,4097,4249,16,1167,13364,5293,3076,1213,1213,2184,4116,1197,172,1196,1212,5821]

theorem envBound42152 : H12AffineFastState.Bounded env42152 := by
  intro p hp
  have h : env42152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42151_42152 : H12AffineEnvironment.transform 16 1212 env42151 = env42152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1212 env42151 == env42152) = true)

theorem identity42152 : scanCanonicalize (H12AffineFastState.compose env42152 (packedSelected [6,8,10] rootPS)) = affineNative (2^(11+1) ^^^ 38) := by decide +kernel

theorem selectedBound42152 : packedSelected [6,8,10] rootPS < 2^1333 := by decide +kernel

def env42153 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,38,8192,1212,9380,9241,1212,3090,154,9381,39,191,16,1167,9234,1163,3076,1213,1213,2184,50,1197,172,1196,1212,1691]

theorem envBound42153 : H12AffineFastState.Bounded env42153 := by
  intro p hp
  have h : env42153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42152_42153 : H12AffineEnvironment.transform 11 38 env42152 = env42153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 38 env42152 == env42153) = true)

theorem identity42153 : scanCanonicalize (H12AffineFastState.compose env42153 (packedSelected [0,4,5,6,7,9,13] rootPS)) = affineNative (2^(12+1) ^^^ 2099) := by decide +kernel

theorem selectedBound42153 : packedSelected [0,4,5,6,7,9,13] rootPS < 2^1333 := by decide +kernel

def env42154 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,38,2099,1212,3223,3114,1212,3090,154,3222,39,191,16,1167,3105,1163,3076,1213,1213,2184,50,1197,172,1196,1212,1691]

theorem envBound42154 : H12AffineFastState.Bounded env42154 := by
  intro p hp
  have h : env42154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42153_42154 : H12AffineEnvironment.transform 12 2099 env42153 = env42154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2099 env42153 == env42154) = true)

theorem identity42154 : scanCanonicalize (H12AffineFastState.compose env42154 (packedSelected [1,2,3,4,8,9,11,16] rootPS)) = affineNative (2^(9+1) ^^^ 667) := by decide +kernel

theorem selectedBound42154 : packedSelected [1,2,3,4,8,9,11,16] rootPS < 2^1333 := by decide +kernel

def env42155 : List Nat := [2,4,8,16,32,17,128,172,512,667,2048,38,2099,551,2572,2737,551,2697,154,2573,39,191,16,532,2746,528,2719,550,550,2184,50,566,172,567,551,0]

theorem envBound42155 : H12AffineFastState.Bounded env42155 := by
  intro p hp
  have h : env42155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42154_42155 : H12AffineEnvironment.transform 9 667 env42154 = env42155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 667 env42154 == env42155) = true)

theorem identity42155 : scanCanonicalize (H12AffineFastState.compose env42155 (packedSelected [1,2,3,5,11] rootPS)) = affineNative (2^(10+1) ^^^ 163) := by decide +kernel

theorem selectedBound42155 : packedSelected [1,2,3,5,11] rootPS < 2^1333 := by decide +kernel

def env42156 : List Nat := [2,4,8,16,32,17,128,172,512,667,163,38,144,551,687,530,551,554,154,686,39,191,16,532,537,528,572,550,550,43,50,566,172,567,551,0]

theorem envBound42156 : H12AffineFastState.Bounded env42156 := by
  intro p hp
  have h : env42156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42155_42156 : H12AffineEnvironment.transform 10 163 env42155 = env42156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 163 env42155 == env42156) = true)

theorem identity42156 : scanCanonicalize (H12AffineFastState.compose env42156 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(8+1) ^^^ 13) := by decide +kernel

theorem selectedBound42156 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env42157 : List Nat := [2,4,8,16,32,17,128,172,13,150,163,38,144,42,162,31,42,39,154,163,39,191,16,25,20,29,49,43,43,43,50,59,172,58,42,0]

theorem envBound42157 : H12AffineFastState.Bounded env42157 := by
  intro p hp
  have h : env42157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42156_42157 : H12AffineEnvironment.transform 8 13 env42156 = env42157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 13 env42156 == env42157) = true)

theorem identity42157 : scanCanonicalize (H12AffineFastState.compose env42157 (packedSelected [1,8] rootPS)) = affineNative (2^(6+1) ^^^ 31) := by decide +kernel

theorem selectedBound42157 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env42158 : List Nat := [2,4,8,16,32,17,31,51,13,9,60,38,15,42,61,31,42,39,5,60,39,32,16,25,20,29,49,43,43,43,50,59,51,58,42,0]

theorem envBound42158 : H12AffineFastState.Bounded env42158 := by
  intro p hp
  have h : env42158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42157_42158 : H12AffineEnvironment.transform 6 31 env42157 = env42158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 31 env42157 == env42158) = true)

theorem identity42158 : scanCanonicalize (H12AffineFastState.compose env42158 (packedSelected [1,5] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound42158 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env42159 : List Nat := [2,4,5,16,32,17,18,51,0,4,49,38,2,39,48,18,39,39,5,49,39,32,16,20,20,16,49,38,38,38,50,54,51,55,39,0]

theorem envBound42159 : H12AffineFastState.Bounded env42159 := by
  intro p hp
  have h : env42159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42158_42159 : H12AffineEnvironment.transform 2 5 env42158 = env42159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env42158 == env42159) = true)

theorem identity42159 : scanCanonicalize (H12AffineFastState.compose env42159 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound42159 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42160 : List Nat := [2,4,5,7,32,6,5,36,0,4,38,38,2,39,39,5,39,39,5,38,39,32,7,3,3,7,38,38,38,38,37,33,36,32,39,0]

theorem envBound42160 : H12AffineFastState.Bounded env42160 := by
  intro p hp
  have h : env42160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42159_42160 : H12AffineEnvironment.transform 3 7 env42159 = env42160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env42159 == env42160) = true)

def env42161 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147521,41003,143496,20497,492615,148717,148717,96346,74795,131136,173,16400,1260,135681]

theorem envBound42161 : H12AffineFastState.Bounded env42161 := by
  intro p hp
  have h : env42161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42131_42161 : H12AffineEnvironment.transform 7 173 env42131 = env42161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env42131 == env42161) = true)

def env42162 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61568,147473,41003,143496,20497,492567,148669,148669,96266,74795,131088,173,16400,1212,135681]

theorem envBound42162 : H12AffineFastState.Bounded env42162 := by
  intro p hp
  have h : env42162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42161_42162 : H12AffineEnvironment.transform 5 16 env42161 = env42162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env42161 == env42162) = true)

theorem identity42162 : scanCanonicalize (H12AffineFastState.compose env42162 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 45217) := by decide +kernel

theorem selectedBound42162 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env42163 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,45217,262144,42145,32769,4097,61568,61616,41003,32809,20497,341174,62492,62492,96266,74795,45233,173,16400,1212,41632]

theorem envBound42163 : H12AffineFastState.Bounded env42163 := by
  intro p hp
  have h : env42163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42162_42163 : H12AffineEnvironment.transform 16 45217 env42162 = env42163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45217 env42162 == env42163) = true)

theorem identity42163 : scanCanonicalize (H12AffineFastState.compose env42163 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound42163 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env42164 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1213,32768,65536,45217,262144,42145,32769,4097,46141,46093,41003,32809,5292,341174,45217,45217,81079,74795,45233,173,1197,1212,41632]

theorem envBound42164 : H12AffineFastState.Bounded env42164 := by
  intro p hp
  have h : env42164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42163_42164 : H12AffineEnvironment.transform 13 1213 env42163 = env42164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env42163 == env42164) = true)

theorem identity42164 : scanCanonicalize (H12AffineFastState.compose env42164 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 37019) := by decide +kernel

theorem selectedBound42164 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env42165 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1213,32768,37019,45217,262144,42145,32769,4097,46141,46093,41003,32809,5292,304173,45217,45217,44076,46256,45233,173,1197,1212,41632]

theorem envBound42165 : H12AffineFastState.Bounded env42165 := by
  intro p hp
  have h : env42165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42164_42165 : H12AffineEnvironment.transform 15 37019 env42164 = env42165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 37019 env42164 == env42165) = true)

theorem identity42165 : scanCanonicalize (H12AffineFastState.compose env42165 (packedSelected [4,9,20] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound42165 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env42166 : List Nat := [2,4,8,16,32,16,128,173,512,5,2048,4096,8192,184,32768,37019,45217,262144,41124,32769,4097,45112,45064,41003,32809,4265,303144,45217,45217,43049,45237,45233,173,168,185,41632]

theorem envBound42166 : H12AffineFastState.Bounded env42166 := by
  intro p hp
  have h : env42166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42165_42166 : H12AffineEnvironment.transform 9 5 env42165 = env42166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env42165 == env42166) = true)

def env42167 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61569,147472,41003,143496,20497,492566,148668,148668,96267,74795,131089,173,16400,1213,135681]

theorem envBound42167 : H12AffineFastState.Bounded env42167 := by
  intro p hp
  have h : env42167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42161_42167 : H12AffineEnvironment.transform 5 17 env42161 = env42167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env42161 == env42167) = true)

theorem identity42167 : scanCanonicalize (H12AffineFastState.compose env42167 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 137353) := by decide +kernel

theorem selectedBound42167 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env42168 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,137353,136192,32769,4097,61569,147472,41003,143496,20497,105631,148668,148668,96267,74795,131089,173,16400,1213,135681]

theorem envBound42168 : H12AffineFastState.Bounded env42168 := by
  intro p hp
  have h : env42168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42167_42168 : H12AffineEnvironment.transform 17 137353 env42167 = env42168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137353 env42167 == env42168) = true)

theorem identity42168 : scanCanonicalize (H12AffineFastState.compose env42168 (packedSelected [1,5,8,18,19,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 13374) := by decide +kernel

theorem selectedBound42168 : packedSelected [1,5,8,18,19,23,24,26] rootPS < 2^1333 := by decide +kernel

def env42169 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,13374,131072,137353,136192,32769,4097,61569,147472,41003,143496,20497,43169,148668,148668,19509,4117,131089,173,16400,1213,135681]

theorem envBound42169 : H12AffineFastState.Bounded env42169 := by
  intro p hp
  have h : env42169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42168_42169 : H12AffineEnvironment.transform 15 13374 env42168 = env42169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13374 env42168 == env42169) = true)

theorem identity42169 : scanCanonicalize (H12AffineFastState.compose env42169 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound42169 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env42170 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1213,32768,13374,131072,137353,136192,32769,4097,46140,132269,41003,143496,5292,43169,131073,131073,2184,4117,131089,173,1197,1213,135681]

theorem envBound42170 : H12AffineFastState.Bounded env42170 := by
  intro p hp
  have h : env42170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42169_42170 : H12AffineEnvironment.transform 13 1213 env42169 = env42170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env42169 == env42170) = true)

theorem identity42170 : scanCanonicalize (H12AffineFastState.compose env42170 (packedSelected [13,17] rootPS)) = affineNative (2^(16+1) ^^^ 40984) := by decide +kernel

theorem selectedBound42170 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env42171 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1213,32768,13374,40984,47249,46104,32769,4097,46140,42165,41003,37008,5292,43169,40985,40985,2184,4117,40969,173,1197,1213,45593]

theorem envBound42171 : H12AffineFastState.Bounded env42171 := by
  intro p hp
  have h : env42171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42170_42171 : H12AffineEnvironment.transform 16 40984 env42170 = env42171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 40984 env42170 == env42171) = true)

theorem identity42171 : scanCanonicalize (H12AffineFastState.compose env42171 (packedSelected [0,4,5,7,8,9,10,13] rootPS)) = affineNative (2^(10+1) ^^^ 1191) := by decide +kernel

theorem selectedBound42171 : packedSelected [0,4,5,7,8,9,10,13] rootPS < 2^1333 := by decide +kernel

def env42172 : List Nat := [2,4,8,16,32,17,128,173,512,1024,1191,4096,8192,1213,32768,13374,40984,46134,46104,32769,4097,46140,42165,41003,37008,5292,41990,40985,40985,1071,4117,40969,173,1197,1213,45593]

theorem envBound42172 : H12AffineFastState.Bounded env42172 := by
  intro p hp
  have h : env42172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42171_42172 : H12AffineEnvironment.transform 10 1191 env42171 = env42172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1191 env42171 == env42172) = true)

theorem identity42172 : scanCanonicalize (H12AffineFastState.compose env42172 (packedSelected [1,5] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound42172 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env42173 : List Nat := [2,4,8,16,32,17,128,173,512,1024,1191,4096,24,1213,32768,5158,32768,37934,37888,32769,4097,37924,33965,32819,37008,5292,33822,32769,32769,1071,4117,32785,173,1197,1213,37377]

theorem envBound42173 : H12AffineFastState.Bounded env42173 := by
  intro p hp
  have h : env42173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42172_42173 : H12AffineEnvironment.transform 12 24 env42172 = env42173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env42172 == env42173) = true)

theorem identity42173 : scanCanonicalize (H12AffineFastState.compose env42173 (packedSelected [1,7,8,9,10,11] rootPS)) = affineNative (2^(9+1) ^^^ 653) := by decide +kernel

theorem selectedBound42173 : packedSelected [1,7,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env42174 : List Nat := [2,4,8,16,32,17,128,173,512,653,554,4096,24,560,32768,4779,32768,37539,37517,32769,4097,37545,33312,32819,37008,4641,33427,32769,32769,674,4117,32785,173,544,560,37377]

theorem envBound42174 : H12AffineFastState.Bounded env42174 := by
  intro p hp
  have h : env42174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42173_42174 : H12AffineEnvironment.transform 9 653 env42173 = env42174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 653 env42173 == env42174) = true)

theorem identity42174 : scanCanonicalize (H12AffineFastState.compose env42174 (packedSelected [0,2,9,10,16] rootPS)) = affineNative (2^(11+1) ^^^ 560) := by decide +kernel

theorem selectedBound42174 : packedSelected [0,2,9,10,16] rootPS < 2^1333 := by decide +kernel

def env42175 : List Nat := [2,4,8,16,32,17,128,173,512,653,554,560,24,560,32768,155,32768,32915,32957,32769,561,32921,33312,32819,33440,17,33427,32769,32769,674,549,32785,173,544,560,32817]

theorem envBound42175 : H12AffineFastState.Bounded env42175 := by
  intro p hp
  have h : env42175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42174_42175 : H12AffineEnvironment.transform 11 560 env42174 = env42175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 560 env42174 == env42175) = true)

theorem identity42175 : scanCanonicalize (H12AffineFastState.compose env42175 (packedSelected [2,3,6,7,8,9] rootPS)) = affineNative (2^(14+1) ^^^ 697) := by decide +kernel

theorem selectedBound42175 : packedSelected [2,3,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env42176 : List Nat := [2,4,8,16,32,17,128,173,512,653,554,560,24,560,697,155,697,554,516,696,561,544,153,650,25,17,42,696,696,674,549,680,173,544,560,648]

theorem envBound42176 : H12AffineFastState.Bounded env42176 := by
  intro p hp
  have h : env42176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42175_42176 : H12AffineEnvironment.transform 14 697 env42175 = env42176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 697 env42175 == env42176) = true)

theorem identity42176 : scanCanonicalize (H12AffineFastState.compose env42176 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(8+1) ^^^ 190) := by decide +kernel

theorem selectedBound42176 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env42177 : List Nat := [2,4,8,16,32,17,128,173,190,51,148,142,24,142,7,155,7,148,186,6,143,158,153,52,25,17,42,6,6,28,155,22,173,158,142,54]

theorem envBound42177 : H12AffineFastState.Bounded env42177 := by
  intro p hp
  have h : env42177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42176_42177 : H12AffineEnvironment.transform 8 190 env42176 = env42177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 190 env42176 == env42177) = true)

theorem identity42177 : scanCanonicalize (H12AffineFastState.compose env42177 (packedSelected [2,3,6,8] rootPS)) = affineNative (2^(6+1) ^^^ 36) := by decide +kernel

theorem selectedBound42177 : packedSelected [2,3,6,8] rootPS < 2^1333 := by decide +kernel

def env42178 : List Nat := [2,4,8,16,32,17,36,9,26,51,48,42,24,42,7,63,7,48,30,6,43,58,61,52,25,17,42,6,6,28,63,22,9,58,42,54]

theorem envBound42178 : H12AffineFastState.Bounded env42178 := by
  intro p hp
  have h : env42178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42177_42178 : H12AffineEnvironment.transform 6 36 env42177 = env42178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 36 env42177 == env42178) = true)

theorem identity42178 : scanCanonicalize (H12AffineFastState.compose env42178 (packedSelected [0,2,3,7] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound42178 : packedSelected [0,2,3,7] rootPS < 2^1333 := by decide +kernel

def env42179 : List Nat := [2,4,8,10,32,11,36,9,0,41,42,42,2,42,7,37,7,42,4,6,43,32,39,46,3,11,42,6,6,6,37,12,9,32,42,44]

theorem envBound42179 : H12AffineFastState.Bounded env42179 := by
  intro p hp
  have h : env42179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42178_42179 : H12AffineEnvironment.transform 3 10 env42178 = env42179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env42178 == env42179) = true)

theorem identity42179 : scanCanonicalize (H12AffineFastState.compose env42179 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound42179 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env42180 : List Nat := [2,4,8,10,10,11,14,9,0,3,0,0,2,0,7,15,7,0,4,6,1,10,13,4,3,11,0,6,6,6,15,12,9,10,0,6]

theorem envBound42180 : H12AffineFastState.Bounded env42180 := by
  intro p hp
  have h : env42180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42179_42180 : H12AffineEnvironment.transform 4 10 env42179 = env42180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env42179 == env42180) = true)

theorem identity42180 : scanCanonicalize (H12AffineFastState.compose env42180 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound42180 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42181 : List Nat := [2,2,8,10,10,11,8,9,0,3,0,0,2,0,1,9,1,0,2,0,1,10,11,2,3,11,0,0,0,0,9,10,9,10,0,0]

theorem envBound42181 : H12AffineFastState.Bounded env42181 := by
  intro p hp
  have h : env42181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42180_42181 : H12AffineEnvironment.transform 1 2 env42180 = env42181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env42180 == env42181) = true)

def env42182 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147521,41003,143497,20496,493034,148800,148801,96346,74795,131136,256,16401,1345,135680]

theorem envBound42182 : H12AffineFastState.Bounded env42182 := by
  intro p hp
  have h : env42182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42130_42182 : H12AffineEnvironment.transform 18 136193 env42130 = env42182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136193 env42130 == env42182) = true)

def env42183 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147521,41003,143497,20496,492614,148716,148717,96346,74795,131136,172,16401,1261,135680]

theorem envBound42183 : H12AffineFastState.Bounded env42183 := by
  intro p hp
  have h : env42183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42182_42183 : H12AffineEnvironment.transform 7 172 env42182 = env42183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env42182 == env42183) = true)

def env42184 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61568,147473,41003,143497,20496,492566,148668,148669,96266,74795,131088,172,16401,1213,135680]

theorem envBound42184 : H12AffineFastState.Bounded env42184 := by
  intro p hp
  have h : env42184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42183_42184 : H12AffineEnvironment.transform 5 16 env42183 = env42184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env42183 == env42184) = true)

theorem identity42184 : scanCanonicalize (H12AffineFastState.compose env42184 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 223243) := by decide +kernel

theorem selectedBound42184 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env42185 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,223243,136193,32769,4097,61568,147473,41003,143497,20496,60445,148668,148669,96266,74795,131088,172,16401,1213,135680]

theorem envBound42185 : H12AffineFastState.Bounded env42185 := by
  intro p hp
  have h : env42185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42184_42185 : H12AffineEnvironment.transform 17 223243 env42184 = env42185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223243 env42184 == env42185) = true)

theorem identity42185 : scanCanonicalize (H12AffineFastState.compose env42185 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 28802) := by decide +kernel

theorem selectedBound42185 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env42186 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,28802,131072,137353,136193,32769,4097,61568,147473,41003,143497,20496,60445,148668,148669,2184,21673,131088,172,16401,1213,135680]

theorem envBound42186 : H12AffineFastState.Bounded env42186 := by
  intro p hp
  have h : env42186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42185_42186 : H12AffineEnvironment.transform 15 28802 env42185 = env42186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28802 env42185 == env42186) = true)

theorem identity42186 : scanCanonicalize (H12AffineFastState.compose env42186 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(14+1) ^^^ 24600) := by decide +kernel

theorem selectedBound42186 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env42187 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,24600,28802,131072,137353,136193,24601,4097,4248,147473,16435,143497,20496,3077,148668,148669,2184,21673,131088,172,16401,1213,135680]

theorem envBound42187 : H12AffineFastState.Bounded env42187 := by
  intro p hp
  have h : env42187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42186_42187 : H12AffineEnvironment.transform 14 24600 env42186 = env42187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 24600 env42186 == env42187) = true)

theorem identity42187 : scanCanonicalize (H12AffineFastState.compose env42187 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound42187 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env42188 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1213,9381,13375,131072,137353,136193,9380,4097,4248,132268,1166,143497,5293,3077,131073,131072,2184,4116,131088,172,1196,1213,135680]

theorem envBound42188 : H12AffineFastState.Bounded env42188 := by
  intro p hp
  have h : env42188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42187_42188 : H12AffineEnvironment.transform 13 1213 env42187 = env42188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env42187 == env42188) = true)

theorem identity42188 : scanCanonicalize (H12AffineFastState.compose env42188 (packedSelected [6,12,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 185) := by decide +kernel

theorem selectedBound42188 : packedSelected [6,12,13,15] rootPS < 2^1333 := by decide +kernel

def env42189 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,185,8192,1213,9381,9350,131072,133168,132280,9380,184,33,132268,1166,139312,1044,3077,131073,131072,2184,173,131088,172,1196,1213,131769]

theorem envBound42189 : H12AffineFastState.Bounded env42189 := by
  intro p hp
  have h : env42189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42188_42189 : H12AffineEnvironment.transform 11 185 env42188 = env42189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 185 env42188 == env42189) = true)

theorem identity42189 : scanCanonicalize (H12AffineFastState.compose env42189 (packedSelected [0,1,2,3,4,5,6,7,8,9,11,13] rootPS)) = affineNative (2^(16+1) ^^^ 1724) := by decide +kernel

theorem selectedBound42189 : packedSelected [0,1,2,3,4,5,6,7,8,9,11,13] rootPS < 2^1333 := by decide +kernel

def env42190 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,185,8192,1213,9381,9350,1724,3724,516,9380,184,33,528,1166,9868,1044,3077,1725,1724,2184,173,1708,172,1196,1213,1029]

theorem envBound42190 : H12AffineFastState.Bounded env42190 := by
  intro p hp
  have h : env42190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42189_42190 : H12AffineEnvironment.transform 16 1724 env42189 = env42190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1724 env42189 == env42190) = true)

theorem identity42190 : scanCanonicalize (H12AffineFastState.compose env42190 (packedSelected [1,2,3,5,6,8,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 657) := by decide +kernel

theorem selectedBound42190 : packedSelected [1,2,3,5,6,8,10,11] rootPS < 2^1333 := by decide +kernel

def env42191 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,185,657,1213,1588,1559,1724,3724,516,1589,184,33,528,1166,1053,1044,3077,1725,1724,2184,173,1708,172,1196,1213,1029]

theorem envBound42191 : H12AffineFastState.Bounded env42191 := by
  intro p hp
  have h : env42191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42190_42191 : H12AffineEnvironment.transform 12 657 env42190 = env42191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 657 env42190 == env42191) = true)

theorem identity42191 : scanCanonicalize (H12AffineFastState.compose env42191 (packedSelected [2,3,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 663) := by decide +kernel

theorem selectedBound42191 : packedSelected [2,3,6,8] rootPS < 2^1333 := by decide +kernel

def env42192 : List Nat := [2,4,8,16,32,16,128,172,512,663,2048,185,657,554,163,128,43,2075,516,162,184,33,528,537,650,643,2706,42,43,2184,173,59,172,571,554,658]

theorem envBound42192 : H12AffineFastState.Bounded env42192 := by
  intro p hp
  have h : env42192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42191_42192 : H12AffineEnvironment.transform 9 663 env42191 = env42192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 663 env42191 == env42192) = true)

theorem identity42192 : scanCanonicalize (H12AffineFastState.compose env42192 (packedSelected [0,2,5,9] rootPS)) = affineNative (2^(8+1) ^^^ 60) := by decide +kernel

theorem selectedBound42192 : packedSelected [0,2,5,9] rootPS < 2^1333 := by decide +kernel

def env42193 : List Nat := [2,4,8,16,32,16,128,172,60,171,2048,185,173,22,163,128,43,2075,56,162,184,33,44,37,182,191,2222,42,43,2184,173,59,172,7,22,174]

theorem envBound42193 : H12AffineFastState.Bounded env42193 := by
  intro p hp
  have h : env42193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42192_42193 : H12AffineEnvironment.transform 8 60 env42192 = env42193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 60 env42192 == env42193) = true)

theorem identity42193 : scanCanonicalize (H12AffineFastState.compose env42193 (packedSelected [1,2,4,7,12] rootPS)) = affineNative (2^(6+1) ^^^ 47) := by decide +kernel

theorem selectedBound42193 : packedSelected [1,2,4,7,12] rootPS < 2^1333 := by decide +kernel

def env42194 : List Nat := [2,4,8,16,32,16,47,3,60,4,2048,22,2,22,12,47,43,2075,56,13,23,33,44,37,25,16,2049,42,43,2087,2,59,3,7,22,1]

theorem envBound42194 : H12AffineFastState.Bounded env42194 := by
  intro p hp
  have h : env42194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42193_42194 : H12AffineEnvironment.transform 6 47 env42193 = env42194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 47 env42193 == env42194) = true)

theorem identity42194 : scanCanonicalize (H12AffineFastState.compose env42194 (packedSelected [0,1,2,3,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 23) := by decide +kernel

theorem selectedBound42194 : packedSelected [0,1,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env42195 : List Nat := [2,4,8,16,32,16,47,3,60,4,23,22,2,22,12,47,43,12,56,13,23,33,44,37,25,16,22,42,43,48,2,59,3,7,22,1]

theorem envBound42195 : H12AffineFastState.Bounded env42195 := by
  intro p hp
  have h : env42195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42194_42195 : H12AffineEnvironment.transform 10 23 env42194 = env42195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 23 env42194 == env42195) = true)

theorem identity42195 : scanCanonicalize (H12AffineFastState.compose env42195 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound42195 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env42196 : List Nat := [2,4,8,16,16,16,31,3,12,4,23,22,2,22,12,31,27,12,8,13,23,17,28,21,25,16,22,26,27,0,2,11,3,7,22,1]

theorem envBound42196 : H12AffineFastState.Bounded env42196 := by
  intro p hp
  have h : env42196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42195_42196 : H12AffineEnvironment.transform 4 16 env42195 = env42196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env42195 == env42196) = true)

theorem identity42196 : scanCanonicalize (H12AffineFastState.compose env42196 (packedSelected [6] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound42196 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env42197 : List Nat := [2,4,8,11,11,11,4,3,12,4,12,13,2,13,12,4,0,12,8,13,12,10,7,14,2,11,13,1,0,0,2,11,3,7,13,1]

theorem envBound42197 : H12AffineFastState.Bounded env42197 := by
  intro p hp
  have h : env42197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42196_42197 : H12AffineEnvironment.transform 3 11 env42196 = env42197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env42196 == env42197) = true)

def env42198 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61569,147472,41003,143497,20496,492567,148669,148668,96267,74795,131089,172,16401,1212,135680]

theorem envBound42198 : H12AffineFastState.Bounded env42198 := by
  intro p hp
  have h : env42198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42183_42198 : H12AffineEnvironment.transform 5 17 env42183 = env42198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env42183 == env42198) = true)

theorem identity42198 : scanCanonicalize (H12AffineFastState.compose env42198 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 114722) := by decide +kernel

theorem selectedBound42198 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env42199 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,114722,262144,119843,32769,4097,61569,98354,41003,127147,20496,279605,99487,99486,96267,74795,114739,172,16401,1212,119330]

theorem envBound42199 : H12AffineFastState.Bounded env42199 := by
  intro p hp
  have h : env42199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42198_42199 : H12AffineEnvironment.transform 16 114722 env42198 = env42199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114722 env42198 == env42199) = true)

theorem identity42199 : scanCanonicalize (H12AffineFastState.compose env42199 (packedSelected [3,10,16,18,19,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 80051) := by decide +kernel

theorem selectedBound42199 : packedSelected [3,10,16,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env42200 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,114722,80051,119843,32769,4097,61569,98354,41003,127147,20496,97414,99487,99486,96267,74795,114739,172,16401,1212,119330]

theorem envBound42200 : H12AffineFastState.Bounded env42200 := by
  intro p hp
  have h : env42200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42199_42200 : H12AffineEnvironment.transform 17 80051 env42199 = env42200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 80051 env42199 == env42200) = true)

theorem identity42200 : scanCanonicalize (H12AffineFastState.compose env42200 (packedSelected [7,16,18,19,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53282) := by decide +kernel

theorem selectedBound42200 : packedSelected [7,16,18,19,23,26,27] rootPS < 2^1333 := by decide +kernel

def env42201 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,53282,4096,59537,1025,32769,4097,61569,20496,41003,8329,20496,44196,21693,21692,43049,62473,4113,172,16401,1212,512]

theorem envBound42201 : H12AffineFastState.Bounded env42201 := by
  intro p hp
  have h : env42201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42200_42201 : H12AffineEnvironment.transform 15 53282 env42200 = env42201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53282 env42200 == env42201) = true)

theorem identity42201 : scanCanonicalize (H12AffineFastState.compose env42201 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound42201 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env42202 : List Nat := [2,4,8,16,32,17,128,172,512,4,2048,4096,8192,16384,32768,53282,4096,59537,5,32769,4097,61569,20496,41003,8329,20496,43168,20665,20664,43049,61453,4113,172,16401,184,512]

theorem envBound42202 : H12AffineFastState.Bounded env42202 := by
  intro p hp
  have h : env42202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42201_42202 : H12AffineEnvironment.transform 9 4 env42201 = env42202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env42201 == env42202) = true)

theorem identity42202 : scanCanonicalize (H12AffineFastState.compose env42202 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 8745) := by decide +kernel

theorem selectedBound42202 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env42203 : List Nat := [2,4,8,16,32,17,128,172,512,4,2048,4096,8192,8745,32768,45579,4096,35512,5,32769,4097,37544,12857,41003,8329,12857,43168,12944,12945,43049,37412,4113,172,8760,184,512]

theorem envBound42203 : H12AffineFastState.Bounded env42203 := by
  intro p hp
  have h : env42203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42202_42203 : H12AffineEnvironment.transform 13 8745 env42202 = env42203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8745 env42202 == env42203) = true)

theorem identity42203 : scanCanonicalize (H12AffineFastState.compose env42203 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound42203 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env42204 : List Nat := [2,4,8,16,32,17,128,172,27,4,2048,4096,8192,8242,32768,45072,4096,34979,5,32769,4097,37043,12322,41003,8329,12322,43168,12427,12426,43049,36927,4113,172,8227,184,27]

theorem envBound42204 : H12AffineFastState.Bounded env42204 := by
  intro p hp
  have h : env42204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42203_42204 : H12AffineEnvironment.transform 8 27 env42203 = env42204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env42203 == env42204) = true)

theorem identity42204 : scanCanonicalize (H12AffineFastState.compose env42204 (packedSelected [1,3,13] rootPS)) = affineNative (2^(14+1) ^^^ 42) := by decide +kernel

theorem selectedBound42204 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env42205 : List Nat := [2,4,8,16,32,17,128,172,27,4,2048,4096,8192,8242,42,12346,4096,2185,5,43,4097,4249,12322,8193,8329,12322,10378,12427,12426,10243,4117,4113,172,8227,184,27]

theorem envBound42205 : H12AffineFastState.Bounded env42205 := by
  intro p hp
  have h : env42205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42204_42205 : H12AffineEnvironment.transform 14 42 env42204 = env42205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 42 env42204 == env42205) = true)

theorem identity42205 : scanCanonicalize (H12AffineFastState.compose env42205 (packedSelected [1,2,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound42205 : packedSelected [1,2,5,6] rootPS < 2^1333 := by decide +kernel

def env42206 : List Nat := [2,4,8,16,32,17,128,172,27,4,1,4096,8192,8242,42,12346,4096,136,5,43,4097,4249,12322,8193,8329,12322,8331,12427,12426,8194,4117,4113,172,8227,184,27]

theorem envBound42206 : H12AffineFastState.Bounded env42206 := by
  intro p hp
  have h : env42206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42205_42206 : H12AffineEnvironment.transform 10 1 env42205 = env42206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env42205 == env42206) = true)

theorem identity42206 : scanCanonicalize (H12AffineFastState.compose env42206 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound42206 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env42207 : List Nat := [2,4,8,16,32,17,128,172,27,4,1,4096,41,27,42,4115,4096,136,5,43,4097,4249,4107,40,160,4107,162,4258,4259,43,4117,4113,172,10,184,27]

theorem envBound42207 : H12AffineFastState.Bounded env42207 := by
  intro p hp
  have h : env42207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42206_42207 : H12AffineEnvironment.transform 12 41 env42206 = env42207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env42206 == env42207) = true)

theorem identity42207 : scanCanonicalize (H12AffineFastState.compose env42207 (packedSelected [0,1,2] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound42207 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env42208 : List Nat := [2,4,8,16,10,17,128,134,27,4,1,4096,3,27,0,4115,4096,136,5,1,4097,4249,4107,2,138,4107,136,4232,4233,1,4117,4113,134,10,146,27]

theorem envBound42208 : H12AffineFastState.Bounded env42208 := by
  intro p hp
  have h : env42208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42207_42208 : H12AffineEnvironment.transform 4 10 env42207 = env42208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env42207 == env42208) = true)

theorem identity42208 : scanCanonicalize (H12AffineFastState.compose env42208 (packedSelected [0,1] rootPS)) = affineNative (2^(11+1) ^^^ 136) := by decide +kernel

theorem selectedBound42208 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env42209 : List Nat := [2,4,8,16,10,17,128,134,27,4,1,136,3,27,0,155,136,136,5,1,137,17,131,2,138,131,136,0,1,1,157,153,134,10,146,27]

theorem envBound42209 : H12AffineFastState.Bounded env42209 := by
  intro p hp
  have h : env42209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42208_42209 : H12AffineEnvironment.transform 11 136 env42208 = env42209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 136 env42208 == env42209) = true)

theorem identity42209 : scanCanonicalize (H12AffineFastState.compose env42209 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound42209 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42210 : List Nat := [2,4,8,7,10,6,128,134,12,4,1,136,3,12,0,140,136,136,5,1,137,6,131,2,138,131,136,0,1,1,138,142,134,10,133,12]

theorem envBound42210 : H12AffineFastState.Bounded env42210 := by
  intro p hp
  have h : env42210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42209_42210 : H12AffineEnvironment.transform 3 7 env42209 = env42210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env42209 == env42210) = true)

theorem identity42210 : scanCanonicalize (H12AffineFastState.compose env42210 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound42210 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env42211 : List Nat := [2,4,8,7,10,6,9,15,12,4,1,1,3,12,0,5,1,1,5,1,0,6,10,2,3,10,1,0,1,1,3,7,15,10,12,12]

theorem envBound42211 : H12AffineFastState.Bounded env42211 := by
  intro p hp
  have h : env42211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42210_42211 : H12AffineEnvironment.transform 6 9 env42210 = env42211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env42210 == env42211) = true)

theorem identity42211 : scanCanonicalize (H12AffineFastState.compose env42211 (packedSelected [7] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound42211 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env42212 : List Nat := [2,4,4,7,6,6,5,3,0,4,1,1,3,0,0,5,1,1,5,1,0,6,6,2,3,6,1,0,1,1,3,7,3,6,0,0]

theorem envBound42212 : H12AffineFastState.Bounded env42212 := by
  intro p hp
  have h : env42212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42211_42212 : H12AffineEnvironment.transform 2 4 env42211 = env42212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env42211 == env42212) = true)

def env42213 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147521,41003,143497,20496,492615,148717,148716,96346,74795,131136,173,16401,1260,135680]

theorem envBound42213 : H12AffineFastState.Bounded env42213 := by
  intro p hp
  have h : env42213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42182_42213 : H12AffineEnvironment.transform 7 173 env42182 = env42213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env42182 == env42213) = true)

def env42214 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61568,147473,41003,143497,20496,492567,148669,148668,96266,74795,131088,173,16401,1212,135680]

theorem envBound42214 : H12AffineFastState.Bounded env42214 := by
  intro p hp
  have h : env42214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42213_42214 : H12AffineEnvironment.transform 5 16 env42213 = env42214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env42213 == env42214) = true)

theorem identity42214 : scanCanonicalize (H12AffineFastState.compose env42214 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 137352) := by decide +kernel

theorem selectedBound42214 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env42215 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,137352,136193,32769,4097,61568,147473,41003,143497,20496,105631,148669,148668,96266,74795,131088,173,16401,1212,135680]

theorem envBound42215 : H12AffineFastState.Bounded env42215 := by
  intro p hp
  have h : env42215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42214_42215 : H12AffineEnvironment.transform 17 137352 env42214 = env42215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137352 env42214 == env42215) = true)

theorem identity42215 : scanCanonicalize (H12AffineFastState.compose env42215 (packedSelected [1,5,8,18,19,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 13374) := by decide +kernel

theorem selectedBound42215 : packedSelected [1,5,8,18,19,23,24,26] rootPS < 2^1333 := by decide +kernel

def env42216 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,13374,131072,137352,136193,32769,4097,61568,147473,41003,143497,20496,43169,148669,148668,19508,4117,131088,173,16401,1212,135680]

theorem envBound42216 : H12AffineFastState.Bounded env42216 := by
  intro p hp
  have h : env42216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42215_42216 : H12AffineEnvironment.transform 15 13374 env42215 = env42216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13374 env42215 == env42216) = true)

theorem identity42216 : scanCanonicalize (H12AffineFastState.compose env42216 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound42216 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env42217 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1212,32768,13374,131072,137352,136193,32769,4097,46140,132269,41003,143497,5292,43169,131073,131072,2184,4117,131088,173,1197,1212,135680]

theorem envBound42217 : H12AffineFastState.Bounded env42217 := by
  intro p hp
  have h : env42217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42216_42217 : H12AffineEnvironment.transform 13 1212 env42216 = env42217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env42216 == env42217) = true)

theorem identity42217 : scanCanonicalize (H12AffineFastState.compose env42217 (packedSelected [13,17] rootPS)) = affineNative (2^(14+1) ^^^ 12313) := by decide +kernel

theorem selectedBound42217 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env42218 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1212,12313,13374,131072,137352,136193,12312,4097,1061,132269,4146,143497,5292,6328,131073,131072,2184,4117,131088,173,1197,1212,135680]

theorem envBound42218 : H12AffineFastState.Bounded env42218 := by
  intro p hp
  have h : env42218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42217_42218 : H12AffineEnvironment.transform 14 12313 env42217 = env42218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12313 env42217 == env42218) = true)

theorem identity42218 : scanCanonicalize (H12AffineFastState.compose env42218 (packedSelected [0,4,5,7,8,9,10,13] rootPS)) = affineNative (2^(11+1) ^^^ 3102) := by decide +kernel

theorem selectedBound42218 : packedSelected [0,4,5,7,8,9,10,13] rootPS < 2^1333 := by decide +kernel

def env42219 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,3102,8192,1212,11271,10272,131072,132246,133151,11270,3103,1061,132269,3116,142487,2226,1190,131073,131072,2184,3083,131088,173,1197,1212,134686]

theorem envBound42219 : H12AffineFastState.Bounded env42219 := by
  intro p hp
  have h : env42219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42218_42219 : H12AffineEnvironment.transform 11 3102 env42218 = env42219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3102 env42218 == env42219) = true)

theorem identity42219 : scanCanonicalize (H12AffineFastState.compose env42219 (packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 1190) := by decide +kernel

theorem selectedBound42219 : packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env42220 : List Nat := [2,4,8,16,32,16,128,173,512,1024,1190,184,8192,1212,8353,9350,131072,132246,132281,8352,185,1061,132269,138,139313,1044,1190,131073,131072,1070,173,131088,173,1197,1212,131768]

theorem envBound42220 : H12AffineFastState.Bounded env42220 := by
  intro p hp
  have h : env42220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42219_42220 : H12AffineEnvironment.transform 10 1190 env42219 = env42220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1190 env42219 == env42220) = true)

theorem identity42220 : scanCanonicalize (H12AffineFastState.compose env42220 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(16+1) ^^^ 9260) := by decide +kernel

theorem selectedBound42220 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env42221 : List Nat := [2,4,8,16,32,16,128,173,512,1024,1190,184,8192,1212,8353,9350,9260,8378,8341,8352,185,1061,8321,138,1053,1044,1190,9261,9260,1070,173,9276,173,1197,1212,9876]

theorem envBound42221 : H12AffineFastState.Bounded env42221 := by
  intro p hp
  have h : env42221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42220_42221 : H12AffineEnvironment.transform 16 9260 env42220 = env42221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 9260 env42220 == env42221) = true)

theorem identity42221 : scanCanonicalize (H12AffineFastState.compose env42221 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(12+1) ^^^ 515) := by decide +kernel

theorem selectedBound42221 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env42222 : List Nat := [2,4,8,16,32,16,128,173,512,1024,1190,184,515,1212,674,1669,1583,697,662,675,185,1061,642,138,1053,1044,1190,1582,1583,1070,173,1599,173,1197,1212,1175]

theorem envBound42222 : H12AffineFastState.Bounded env42222 := by
  intro p hp
  have h : env42222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42221_42222 : H12AffineEnvironment.transform 12 515 env42221 = env42222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 515 env42221 == env42222) = true)

theorem identity42222 : scanCanonicalize (H12AffineFastState.compose env42222 (packedSelected [1,2,3,4,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 565) := by decide +kernel

theorem selectedBound42222 : packedSelected [1,2,3,4,6,7] rootPS < 2^1333 := by decide +kernel

def env42223 : List Nat := [2,4,8,16,32,16,128,173,512,565,659,184,515,649,674,176,26,697,662,675,185,528,642,138,552,545,659,27,26,539,173,10,173,664,649,674]

theorem envBound42223 : H12AffineFastState.Bounded env42223 := by
  intro p hp
  have h : env42223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42222_42223 : H12AffineEnvironment.transform 9 565 env42222 = env42223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 565 env42222 == env42223) = true)

theorem identity42223 : scanCanonicalize (H12AffineFastState.compose env42223 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound42223 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42224 : List Nat := [2,4,8,16,32,16,128,173,42,31,185,184,41,163,136,176,26,147,188,137,185,58,168,138,2,11,185,27,26,49,173,10,173,178,163,136]

theorem envBound42224 : H12AffineFastState.Bounded env42224 := by
  intro p hp
  have h : env42224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42223_42224 : H12AffineEnvironment.transform 8 42 env42223 = env42224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env42223 == env42224) = true)

theorem identity42224 : scanCanonicalize (H12AffineFastState.compose env42224 (packedSelected [0,1,4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound42224 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env42225 : List Nat := [2,3,8,16,32,16,128,170,42,24,185,184,41,163,136,176,26,147,187,137,185,58,168,138,2,11,185,27,26,49,170,10,170,178,163,136]

theorem envBound42225 : H12AffineFastState.Bounded env42225 := by
  intro p hp
  have h : env42225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42224_42225 : H12AffineEnvironment.transform 1 3 env42224 = env42225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env42224 == env42225) = true)

theorem identity42225 : scanCanonicalize (H12AffineFastState.compose env42225 (packedSelected [1,5,6] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound42225 : packedSelected [1,5,6] rootPS < 2^1333 := by decide +kernel

def env42226 : List Nat := [2,3,8,16,32,16,18,56,42,24,43,42,41,49,26,34,26,1,41,27,43,58,58,24,2,11,43,27,26,49,56,10,56,32,49,26]

theorem envBound42226 : H12AffineFastState.Bounded env42226 := by
  intro p hp
  have h : env42226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42225_42226 : H12AffineEnvironment.transform 6 18 env42225 = env42226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env42225 == env42226) = true)

theorem identity42226 : scanCanonicalize (H12AffineFastState.compose env42226 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound42226 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env42227 : List Nat := [2,3,8,11,32,11,9,35,42,3,43,42,41,42,1,34,1,1,41,0,43,33,33,3,2,11,43,0,1,42,35,10,35,32,42,1]

theorem envBound42227 : H12AffineFastState.Bounded env42227 := by
  intro p hp
  have h : env42227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42226_42227 : H12AffineEnvironment.transform 3 11 env42226 = env42227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env42226 == env42227) = true)

theorem identity42227 : scanCanonicalize (H12AffineFastState.compose env42227 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound42227 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env42228 : List Nat := [2,3,8,11,11,11,9,8,1,3,0,1,2,1,1,9,1,1,2,0,0,10,10,3,2,11,0,0,1,1,8,10,8,11,1,1]

theorem envBound42228 : H12AffineFastState.Bounded env42228 := by
  intro p hp
  have h : env42228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42227_42228 : H12AffineEnvironment.transform 4 11 env42227 = env42228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env42227 == env42228) = true)

def env42229 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61569,147472,41003,143497,20496,492566,148668,148669,96267,74795,131089,173,16401,1213,135680]

theorem envBound42229 : H12AffineFastState.Bounded env42229 := by
  intro p hp
  have h : env42229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42213_42229 : H12AffineEnvironment.transform 5 17 env42213 = env42229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env42213 == env42229) = true)

theorem identity42229 : scanCanonicalize (H12AffineFastState.compose env42229 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 45216) := by decide +kernel

theorem selectedBound42229 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env42230 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,45216,262144,42145,32769,4097,61569,61616,41003,32809,20496,341174,62492,62493,96267,74795,45233,173,16401,1213,41632]

theorem envBound42230 : H12AffineFastState.Bounded env42230 := by
  intro p hp
  have h : env42230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42229_42230 : H12AffineEnvironment.transform 16 45216 env42229 = env42230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45216 env42229 == env42230) = true)

theorem identity42230 : scanCanonicalize (H12AffineFastState.compose env42230 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound42230 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env42231 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1212,32768,65536,45216,262144,42145,32769,4097,46141,46092,41003,32809,5292,341174,45216,45217,81079,74795,45233,173,1197,1213,41632]

theorem envBound42231 : H12AffineFastState.Bounded env42231 := by
  intro p hp
  have h : env42231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42230_42231 : H12AffineEnvironment.transform 13 1212 env42230 = env42231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env42230 == env42231) = true)

theorem identity42231 : scanCanonicalize (H12AffineFastState.compose env42231 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 37018) := by decide +kernel

theorem selectedBound42231 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env42232 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1212,32768,37018,45216,262144,42145,32769,4097,46141,46092,41003,32809,5292,304172,45216,45217,44077,46257,45233,173,1197,1213,41632]

theorem envBound42232 : H12AffineFastState.Bounded env42232 := by
  intro p hp
  have h : env42232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42231_42232 : H12AffineEnvironment.transform 15 37018 env42231 = env42232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 37018 env42231 == env42232) = true)

theorem identity42232 : scanCanonicalize (H12AffineFastState.compose env42232 (packedSelected [4,9,20] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound42232 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env42233 : List Nat := [2,4,8,16,32,17,128,173,512,4,2048,4096,8192,184,32768,37018,45216,262144,41125,32769,4097,45113,45064,41003,32809,4264,303144,45216,45217,43049,45237,45233,173,169,185,41632]

theorem envBound42233 : H12AffineFastState.Bounded env42233 := by
  intro p hp
  have h : env42233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42232_42233 : H12AffineEnvironment.transform 9 4 env42232 = env42233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env42232 == env42233) = true)

theorem identity42233 : scanCanonicalize (H12AffineFastState.compose env42233 (packedSelected [1,3,5,6,8,13] rootPS)) = affineNative (2^(14+1) ^^^ 8353) := by decide +kernel

theorem selectedBound42233 : packedSelected [1,3,5,6,8,13] rootPS < 2^1333 := by decide +kernel

def env42234 : List Nat := [2,4,8,16,32,17,128,173,512,4,2048,4096,8192,184,8353,12347,4097,262144,4,8352,4097,4248,4265,138,8328,4264,262281,4097,4096,2184,4116,4112,173,169,185,513]

theorem envBound42234 : H12AffineFastState.Bounded env42234 := by
  intro p hp
  have h : env42234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42233_42234 : H12AffineEnvironment.transform 14 8353 env42233 = env42234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8353 env42233 == env42234) = true)

theorem identity42234 : scanCanonicalize (H12AffineFastState.compose env42234 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 536) := by decide +kernel

theorem selectedBound42234 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42235 : List Nat := [2,4,8,16,32,17,128,173,512,4,2048,4096,536,184,697,4643,4097,262144,4,696,4097,4248,4265,138,656,4264,262281,4097,4096,2184,4116,4112,173,169,185,513]

theorem envBound42235 : H12AffineFastState.Bounded env42235 := by
  intro p hp
  have h : env42235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42234_42235 : H12AffineEnvironment.transform 12 536 env42234 = env42235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 536 env42234 == env42235) = true)

theorem identity42235 : scanCanonicalize (H12AffineFastState.compose env42235 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound42235 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env42236 : List Nat := [2,4,8,16,32,17,128,173,512,4,2048,1,536,184,697,546,0,262144,4,696,0,153,168,138,656,169,262281,0,1,2184,21,17,173,169,185,513]

theorem envBound42236 : H12AffineFastState.Bounded env42236 := by
  intro p hp
  have h : env42236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42235_42236 : H12AffineEnvironment.transform 11 1 env42235 = env42236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env42235 == env42236) = true)

theorem identity42236 : scanCanonicalize (H12AffineFastState.compose env42236 (packedSelected [3,5] rootPS)) = affineNative (2^(17+1) ^^^ 2744) := by decide +kernel

theorem selectedBound42236 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env42237 : List Nat := [2,4,8,16,32,17,128,173,512,4,2048,1,536,184,697,546,0,2744,4,696,0,153,168,138,656,169,2609,0,1,2184,21,17,173,169,185,513]

theorem envBound42237 : H12AffineFastState.Bounded env42237 := by
  intro p hp
  have h : env42237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42236_42237 : H12AffineEnvironment.transform 17 2744 env42236 = env42237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2744 env42236 == env42237) = true)

theorem identity42237 : scanCanonicalize (H12AffineFastState.compose env42237 (packedSelected [3,8] rootPS)) = affineNative (2^(10+1) ^^^ 146) := by decide +kernel

theorem selectedBound42237 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env42238 : List Nat := [2,4,8,16,32,17,128,173,512,4,146,1,536,184,697,546,0,554,4,696,0,153,168,138,656,169,675,0,1,26,21,17,173,169,185,513]

theorem envBound42238 : H12AffineFastState.Bounded env42238 := by
  intro p hp
  have h : env42238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42237_42238 : H12AffineEnvironment.transform 10 146 env42237 = env42238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 146 env42237 == env42238) = true)

theorem identity42238 : scanCanonicalize (H12AffineFastState.compose env42238 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound42238 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env42239 : List Nat := [2,4,8,16,32,17,40,5,512,4,58,1,536,16,529,546,0,554,4,528,0,49,0,34,568,1,523,0,1,26,21,17,5,1,17,513]

theorem envBound42239 : H12AffineFastState.Bounded env42239 := by
  intro p hp
  have h : env42239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42238_42239 : H12AffineEnvironment.transform 6 40 env42238 = env42239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env42238 == env42239) = true)

theorem identity42239 : scanCanonicalize (H12AffineFastState.compose env42239 (packedSelected [10] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound42239 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env42240 : List Nat := [2,4,8,16,32,17,40,5,0,4,58,1,24,16,17,34,0,42,4,16,0,49,0,34,56,1,11,0,1,26,21,17,5,1,17,1]

theorem envBound42240 : H12AffineFastState.Bounded env42240 := by
  intro p hp
  have h : env42240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42239_42240 : H12AffineEnvironment.transform 8 0 env42239 = env42240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env42239 == env42240) = true)

theorem identity42240 : scanCanonicalize (H12AffineFastState.compose env42240 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound42240 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42241 : List Nat := [2,2,8,16,32,17,40,3,0,2,58,1,24,16,17,34,0,42,2,16,0,49,0,34,56,1,11,0,1,26,19,17,3,1,17,1]

theorem envBound42241 : H12AffineFastState.Bounded env42241 := by
  intro p hp
  have h : env42241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42240_42241 : H12AffineEnvironment.transform 1 2 env42240 = env42241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env42240 == env42241) = true)

theorem identity42241 : scanCanonicalize (H12AffineFastState.compose env42241 (packedSelected [0,3,7] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound42241 : packedSelected [0,3,7] rootPS < 2^1333 := by decide +kernel

def env42242 : List Nat := [2,2,8,1,32,0,40,3,0,2,43,1,9,1,0,34,0,42,2,1,0,32,0,34,41,1,11,0,1,11,2,0,3,1,0,1]

theorem envBound42242 : H12AffineFastState.Bounded env42242 := by
  intro p hp
  have h : env42242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42241_42242 : H12AffineEnvironment.transform 3 1 env42241 = env42242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env42241 == env42242) = true)

theorem identity42242 : scanCanonicalize (H12AffineFastState.compose env42242 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound42242 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env42243 : List Nat := [2,2,2,1,32,0,34,3,0,2,33,1,3,1,0,34,0,32,2,1,0,32,0,34,35,1,1,0,1,1,2,0,3,1,0,1]

theorem envBound42243 : H12AffineFastState.Bounded env42243 := by
  intro p hp
  have h : env42243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42242_42243 : H12AffineEnvironment.transform 2 2 env42242 = env42243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env42242 == env42243) = true)

theorem identity42243 : scanCanonicalize (H12AffineFastState.compose env42243 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound42243 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42244 : List Nat := [1,1,1,1,32,0,33,0,0,1,33,1,0,1,0,33,0,32,1,1,0,32,0,33,32,1,1,0,1,1,1,0,0,1,0,1]

theorem envBound42244 : H12AffineFastState.Bounded env42244 := by
  intro p hp
  have h : env42244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42243_42244 : H12AffineEnvironment.transform 0 1 env42243 = env42244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env42243 == env42244) = true)

def env42245 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147521,16777216,533641,672785,134217728,148800,545089,96346,16876545,134579627,257,151876049,151462016,525824]

theorem envBound42245 : H12AffineFastState.Bounded env42245 := by
  intro p hp
  have h : env42245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42012_42245 : H12AffineEnvironment.transform 24 533641 env42012 = env42245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 533641 env42012 == env42245) = true)

def env42246 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147521,16777216,533641,672785,17245632,148800,545089,96346,16876545,16949355,257,676881,1344,525824]

theorem envBound42246 : H12AffineFastState.Bounded env42246 := by
  intro p hp
  have h : env42246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42245_42246 : H12AffineEnvironment.transform 26 17245632 env42245 = env42246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245632 env42245 == env42246) = true)

theorem identity42246 : scanCanonicalize (H12AffineFastState.compose env42246 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(18+1) ^^^ 95614) := by decide +kernel

theorem selectedBound42246 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env42247 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95614,32769,4097,61648,147521,16777216,86519,209263,17245632,148800,74815,96346,16876545,16949355,257,205167,1344,95102]

theorem envBound42247 : H12AffineFastState.Bounded env42247 := by
  intro p hp
  have h : env42247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42246_42247 : H12AffineEnvironment.transform 18 95614 env42246 = env42247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 95614 env42246 == env42247) = true)

def env42248 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95614,32769,4097,61648,147521,284032,86519,209263,225344,148800,74815,96346,381313,456171,257,205167,1344,95102]

theorem envBound42248 : H12AffineFastState.Bounded env42248 := by
  intro p hp
  have h : env42248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42247_42248 : H12AffineEnvironment.transform 23 284032 env42247 = env42248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 284032 env42247 == env42248) = true)

def env42249 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16464,262144,95614,32769,4097,61648,17,284032,86519,94527,77840,1296,74815,96346,381313,308667,257,90431,1344,95102]

theorem envBound42249 : H12AffineFastState.Bounded env42249 := by
  intro p hp
  have h : env42249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42248_42249 : H12AffineEnvironment.transform 16 16464 env42248 = env42249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16464 env42248 == env42249) = true)

def env42250 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1344,262144,77934,32769,4097,46528,17,266384,70887,78895,77840,1296,74815,81226,365713,308667,257,74799,1344,79470]

theorem envBound42250 : H12AffineFastState.Bounded env42250 := by
  intro p hp
  have h : env42250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42249_42250 : H12AffineEnvironment.transform 13 1296 env42249 = env42250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env42249 == env42250) = true)

theorem identity42250 : scanCanonicalize (H12AffineFastState.compose env42250 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32882) := by decide +kernel

theorem selectedBound42250 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env42251 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,32882,1344,262144,45084,32769,4097,46528,17,266384,38037,46173,45154,1296,42061,48440,267491,308667,257,42077,1344,46620]

theorem envBound42251 : H12AffineFastState.Bounded env42251 := by
  intro p hp
  have h : env42251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42250_42251 : H12AffineEnvironment.transform 15 32882 env42250 = env42251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32882 env42250 == env42251) = true)

def env42252 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32882,1344,262144,42332,32769,1345,41088,17,263632,33237,41245,42274,1296,42061,43128,262563,303355,257,42077,1344,41820]

theorem envBound42252 : H12AffineFastState.Bounded env42252 := by
  intro p hp
  have h : env42252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42251_42252 : H12AffineEnvironment.transform 11 1344 env42251 = env42252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env42251 == env42252) = true)

theorem identity42252 : scanCanonicalize (H12AffineFastState.compose env42252 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 34226) := by decide +kernel

theorem selectedBound42252 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env42253 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32882,1344,34226,42332,32769,1345,41088,17,32866,33237,41245,42274,1296,42061,43128,33809,9545,257,42077,1344,41820]

theorem envBound42253 : H12AffineFastState.Bounded env42253 := by
  intro p hp
  have h : env42253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42252_42253 : H12AffineEnvironment.transform 17 34226 env42252 = env42253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 34226 env42252 == env42253) = true)

theorem identity42253 : scanCanonicalize (H12AffineFastState.compose env42253 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(10+1) ^^^ 1782) := by decide +kernel

theorem selectedBound42253 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env42254 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1782,1344,8192,1296,32768,32882,1344,34226,42332,32769,1345,41088,17,32866,33237,41245,42274,1296,42061,42638,33809,9545,257,42077,1344,41820]

theorem envBound42254 : H12AffineFastState.Bounded env42254 := by
  intro p hp
  have h : env42254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42253_42254 : H12AffineEnvironment.transform 10 1782 env42253 = env42254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1782 env42253 == env42254) = true)

def env42255 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32882,1344,262144,42333,32769,1344,41089,17,263633,33236,41244,42275,1296,42061,43129,262562,303354,257,42077,1344,41821]

theorem envBound42255 : H12AffineFastState.Bounded env42255 := by
  intro p hp
  have h : env42255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42251_42255 : H12AffineEnvironment.transform 11 1345 env42251 = env42255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env42251 == env42255) = true)

theorem identity42255 : scanCanonicalize (H12AffineFastState.compose env42255 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound42255 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env42256 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,0,8192,81,32768,32882,1,262144,40988,32769,1,41089,17,262288,33236,41244,41058,81,41228,43129,262562,303354,257,41244,1,41821]

theorem envBound42256 : H12AffineFastState.Bounded env42256 := by
  intro p hp
  have h : env42256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42255_42256 : H12AffineEnvironment.transform 9 321 env42255 = env42256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env42255 == env42256) = true)

theorem identity42256 : scanCanonicalize (H12AffineFastState.compose env42256 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound42256 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env42257 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,0,8192,81,8541,8495,1,262144,321,8540,1,476,17,262288,8329,65,319,81,81,2340,262562,262567,257,65,1,512]

theorem envBound42257 : H12AffineFastState.Bounded env42257 := by
  intro p hp
  have h : env42257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42256_42257 : H12AffineEnvironment.transform 14 8541 env42256 = env42257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env42256 == env42257) = true)

theorem identity42257 : scanCanonicalize (H12AffineFastState.compose env42257 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound42257 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env42258 : List Nat := [2,4,8,16,32,64,128,21,512,84,2048,0,8192,81,8264,8250,1,262144,84,8265,1,201,17,262288,8329,65,42,81,81,2097,262327,262322,20,65,1,512]

theorem envBound42258 : H12AffineFastState.Bounded env42258 := by
  intro p hp
  have h : env42258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42257_42258 : H12AffineEnvironment.transform 7 21 env42257 = env42258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env42257 == env42258) = true)

theorem identity42258 : scanCanonicalize (H12AffineFastState.compose env42258 (packedSelected [3,5,10] rootPS)) = affineNative (2^(17+1) ^^^ 8755) := by decide +kernel

theorem selectedBound42258 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env42259 : List Nat := [2,4,8,16,32,64,128,21,512,84,2048,0,8192,81,8264,8250,1,8755,84,8265,1,201,17,8867,8329,65,42,81,81,2097,8836,8833,20,65,1,512]

theorem envBound42259 : H12AffineFastState.Bounded env42259 := by
  intro p hp
  have h : env42259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42258_42259 : H12AffineEnvironment.transform 17 8755 env42258 = env42259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8755 env42258 == env42259) = true)

theorem identity42259 : scanCanonicalize (H12AffineFastState.compose env42259 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound42259 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env42260 : List Nat := [2,4,8,16,32,16,128,21,512,4,2048,0,8192,1,8216,8250,1,8755,4,8217,1,153,17,8867,8329,17,42,1,1,2097,8836,8833,20,17,1,512]

theorem envBound42260 : H12AffineFastState.Bounded env42260 := by
  intro p hp
  have h : env42260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42259_42260 : H12AffineEnvironment.transform 5 16 env42259 = env42260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env42259 == env42260) = true)

theorem identity42260 : scanCanonicalize (H12AffineFastState.compose env42260 (packedSelected [1,3,13] rootPS)) = affineNative (2^(12+1) ^^^ 2563) := by decide +kernel

theorem selectedBound42260 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env42261 : List Nat := [2,4,8,16,32,16,128,21,512,4,2048,0,2563,1,2587,2617,1,2096,4,2586,1,153,17,2208,2698,17,42,1,1,2097,2183,2178,20,17,1,512]

theorem envBound42261 : H12AffineFastState.Bounded env42261 := by
  intro p hp
  have h : env42261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42260_42261 : H12AffineEnvironment.transform 12 2563 env42260 = env42261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2563 env42260 == env42261) = true)

theorem identity42261 : scanCanonicalize (H12AffineFastState.compose env42261 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 147) := by decide +kernel

theorem selectedBound42261 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env42262 : List Nat := [2,4,8,16,32,16,128,21,512,4,147,0,656,1,648,682,1,163,4,649,1,153,17,51,537,17,42,1,1,162,20,17,20,17,1,512]

theorem envBound42262 : H12AffineFastState.Bounded env42262 := by
  intro p hp
  have h : env42262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42261_42262 : H12AffineEnvironment.transform 10 147 env42261 = env42262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 147 env42261 == env42262) = true)

theorem identity42262 : scanCanonicalize (H12AffineFastState.compose env42262 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 143) := by decide +kernel

theorem selectedBound42262 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42263 : List Nat := [2,4,8,16,32,16,128,21,143,4,147,0,31,1,7,37,1,163,4,6,1,153,17,51,150,17,42,1,1,162,20,17,20,17,1,143]

theorem envBound42263 : H12AffineFastState.Bounded env42263 := by
  intro p hp
  have h : env42263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42262_42263 : H12AffineEnvironment.transform 8 143 env42262 = env42263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 143 env42262 == env42263) = true)

theorem identity42263 : scanCanonicalize (H12AffineFastState.compose env42263 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound42263 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env42264 : List Nat := [2,4,8,16,32,16,56,21,55,4,43,0,31,1,7,37,1,27,4,6,1,33,17,51,46,17,42,1,1,26,20,17,20,17,1,55]

theorem envBound42264 : H12AffineFastState.Bounded env42264 := by
  intro p hp
  have h : env42264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42263_42264 : H12AffineEnvironment.transform 6 56 env42263 = env42264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env42263 == env42264) = true)

theorem identity42264 : scanCanonicalize (H12AffineFastState.compose env42264 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound42264 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42265 : List Nat := [2,4,8,12,32,12,36,9,43,4,43,0,3,1,7,37,1,7,4,6,1,33,13,47,46,13,42,1,1,6,8,13,8,13,1,43]

theorem envBound42265 : H12AffineFastState.Bounded env42265 := by
  intro p hp
  have h : env42265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42264_42265 : H12AffineEnvironment.transform 3 12 env42264 = env42265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env42264 == env42265) = true)

def env42266 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1345,262144,77935,32769,4097,46529,17,266385,70886,78894,77840,1296,74815,81227,365712,308667,257,74798,1344,79471]

theorem envBound42266 : H12AffineFastState.Bounded env42266 := by
  intro p hp
  have h : env42266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42249_42266 : H12AffineEnvironment.transform 13 1297 env42249 = env42266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env42249 == env42266) = true)

theorem identity42266 : scanCanonicalize (H12AffineFastState.compose env42266 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound42266 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env42267 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1345,262144,77935,13340,4097,476,17,266385,70886,78894,77840,1296,74815,81227,336013,262566,257,74798,1344,79471]

theorem envBound42267 : H12AffineFastState.Bounded env42267 := by
  intro p hp
  have h : env42267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42266_42267 : H12AffineEnvironment.transform 14 13341 env42266 = env42267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env42266 == env42267) = true)

def env42268 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1345,65664,77935,13340,4097,476,17,69649,70886,78894,77840,1296,74815,81227,8205,65830,257,74798,1344,79471]

theorem envBound42268 : H12AffineFastState.Bounded env42268 := by
  intro p hp
  have h : env42268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42267_42268 : H12AffineEnvironment.transform 17 65664 env42267 = env42268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env42267 == env42268) = true)

theorem identity42268 : scanCanonicalize (H12AffineFastState.compose env42268 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 73) := by decide +kernel

theorem selectedBound42268 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env42269 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,73,1297,5204,65536,1345,65664,69670,5205,4097,476,17,69649,70886,70759,69721,1296,66678,72962,68,65830,257,66663,1344,71206]

theorem envBound42269 : H12AffineFastState.Bounded env42269 := by
  intro p hp
  have h : env42269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42268_42269 : H12AffineEnvironment.transform 12 73 env42268 = env42269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env42268 == env42269) = true)

def env42270 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,25,1297,5124,65536,1297,65664,69670,5125,4097,396,17,69649,70838,70711,69641,1296,66598,72962,20,65830,257,66615,1296,71206]

theorem envBound42270 : H12AffineFastState.Bounded env42270 := by
  intro p hp
  have h : env42270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42269_42270 : H12AffineEnvironment.transform 5 16 env42269 = env42270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env42269 == env42270) = true)

theorem identity42270 : scanCanonicalize (H12AffineFastState.compose env42270 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound42270 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env42271 : List Nat := [2,4,8,16,32,16,128,256,512,4,2048,4096,25,277,4096,65536,277,65664,69670,4097,4097,396,17,69649,69810,69683,69641,276,65570,71942,20,65830,257,65587,276,70178]

theorem envBound42271 : H12AffineFastState.Bounded env42271 := by
  intro p hp
  have h : env42271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42270_42271 : H12AffineEnvironment.transform 9 4 env42270 = env42271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env42270 == env42271) = true)

theorem identity42271 : scanCanonicalize (H12AffineFastState.compose env42271 (packedSelected [1,2,3,5,8,10,13,19,21,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 959) := by decide +kernel

theorem selectedBound42271 : packedSelected [1,2,3,5,8,10,13,19,21,23,32] rootPS < 2^1333 := by decide +kernel

def env42272 : List Nat := [2,4,8,16,32,16,128,256,512,4,2048,4096,25,277,4096,959,277,831,5017,4097,4097,396,17,5038,4877,5004,5046,276,925,6841,20,665,257,908,276,4509]

theorem envBound42272 : H12AffineFastState.Bounded env42272 := by
  intro p hp
  have h : env42272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42271_42272 : H12AffineEnvironment.transform 15 959 env42271 = env42272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 959 env42271 == env42272) = true)

theorem identity42272 : scanCanonicalize (H12AffineFastState.compose env42272 (packedSelected [0,1,3,4,7,8,9,10,13,18,19,23,26,28] rootPS)) = affineNative (2^(10+1) ^^^ 390) := by decide +kernel

theorem selectedBound42272 : packedSelected [0,1,3,4,7,8,9,10,13,18,19,23,26,28] rootPS < 2^1333 := by decide +kernel

def env42273 : List Nat := [2,4,8,16,32,16,128,256,512,4,390,4096,25,277,4096,959,277,831,5017,4097,4097,396,17,5038,4877,5004,5046,276,925,4927,20,665,257,908,276,4509]

theorem envBound42273 : H12AffineFastState.Bounded env42273 := by
  intro p hp
  have h : env42273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42272_42273 : H12AffineEnvironment.transform 10 390 env42272 = env42273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 390 env42272 == env42273) = true)

theorem identity42273 : scanCanonicalize (H12AffineFastState.compose env42273 (packedSelected [0,1,4,5,7,9,10,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 185) := by decide +kernel

theorem selectedBound42273 : packedSelected [0,1,4,5,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env42274 : List Nat := [2,4,8,16,32,16,128,256,512,4,390,185,25,277,185,959,277,831,800,184,184,396,17,791,948,821,783,276,925,902,20,665,257,908,276,292]

theorem envBound42274 : H12AffineFastState.Bounded env42274 := by
  intro p hp
  have h : env42274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42273_42274 : H12AffineEnvironment.transform 11 185 env42273 = env42274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 185 env42273 == env42274) = true)

theorem identity42274 : scanCanonicalize (H12AffineFastState.compose env42274 (packedSelected [0,1,3,9,10,11,12] rootPS)) = affineNative (2^(8+1) ^^^ 319) := by decide +kernel

theorem selectedBound42274 : packedSelected [0,1,3,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env42275 : List Nat := [2,4,8,16,32,16,128,256,319,4,390,185,25,277,185,128,277,0,31,184,184,396,17,40,139,10,48,276,162,185,20,422,257,179,276,292]

theorem envBound42275 : H12AffineFastState.Bounded env42275 := by
  intro p hp
  have h : env42275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42274_42275 : H12AffineEnvironment.transform 8 319 env42274 = env42275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 319 env42274 == env42275) = true)

theorem identity42275 : scanCanonicalize (H12AffineFastState.compose env42275 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound42275 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env42276 : List Nat := [2,4,8,11,32,11,128,256,292,4,390,162,2,270,162,128,270,0,4,163,163,396,10,40,139,10,43,271,162,162,15,422,257,168,271,292]

theorem envBound42276 : H12AffineFastState.Bounded env42276 := by
  intro p hp
  have h : env42276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42275_42276 : H12AffineEnvironment.transform 3 11 env42275 = env42276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env42275 == env42276) = true)

theorem identity42276 : scanCanonicalize (H12AffineFastState.compose env42276 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 134) := by decide +kernel

theorem selectedBound42276 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env42277 : List Nat := [2,4,8,11,32,11,128,134,162,4,0,162,2,136,162,128,136,0,4,163,163,10,10,40,139,10,43,137,162,162,15,32,135,168,137,162]

theorem envBound42277 : H12AffineFastState.Bounded env42277 := by
  intro p hp
  have h : env42277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42276_42277 : H12AffineEnvironment.transform 7 134 env42276 = env42277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 134 env42276 == env42277) = true)

def env42278 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,24,1297,5125,65536,1296,65664,69670,5124,4097,397,17,69649,70839,70710,69640,1296,66599,72962,21,65830,257,66614,1297,71206]

theorem envBound42278 : H12AffineFastState.Bounded env42278 := by
  intro p hp
  have h : env42278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42269_42278 : H12AffineEnvironment.transform 5 17 env42269 = env42278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env42269 == env42278) = true)

theorem identity42278 : scanCanonicalize (H12AffineFastState.compose env42278 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 4131) := by decide +kernel

theorem selectedBound42278 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env42279 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,24,1297,5125,4131,1296,4259,5,5124,4097,397,17,50,1172,1045,43,1296,5124,3361,21,4357,257,5141,1297,1541]

theorem envBound42279 : H12AffineFastState.Bounded env42279 := by
  intro p hp
  have h : env42279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42278_42279 : H12AffineEnvironment.transform 15 4131 env42278 = env42279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4131 env42278 == env42279) = true)

def env42280 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1345,65665,77935,13340,4097,476,17,69648,70886,78894,77840,1296,74815,81227,8204,65831,257,74798,1344,79471]

theorem envBound42280 : H12AffineFastState.Bounded env42280 := by
  intro p hp
  have h : env42280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42267_42280 : H12AffineEnvironment.transform 17 65665 env42267 = env42280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env42267 == env42280) = true)

theorem identity42280 : scanCanonicalize (H12AffineFastState.compose env42280 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5385) := by decide +kernel

theorem selectedBound42280 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env42281 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5385,1297,276,65536,1345,65665,66918,277,4097,476,17,69648,70886,65831,66841,1296,69942,67650,5381,65831,257,69927,1344,66406]

theorem envBound42281 : H12AffineFastState.Bounded env42281 := by
  intro p hp
  have h : env42281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42280_42281 : H12AffineEnvironment.transform 12 5385 env42280 = env42281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5385 env42280 == env42281) = true)

def env42282 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,5385,1297,276,65536,1297,65665,66870,277,4097,396,17,69648,70838,65831,66841,1296,69942,67602,5381,65831,257,69927,1296,66358]

theorem envBound42282 : H12AffineFastState.Bounded env42282 := by
  intro p hp
  have h : env42282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42281_42282 : H12AffineEnvironment.transform 5 16 env42281 = env42282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env42281 == env42282) = true)

theorem identity42282 : scanCanonicalize (H12AffineFastState.compose env42282 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound42282 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env42283 : List Nat := [2,4,8,16,32,16,128,256,512,4,2048,4096,4365,277,276,65536,277,65665,65842,277,4097,396,17,69648,69810,65831,65821,276,69942,67602,4353,65831,257,69927,276,66358]

theorem envBound42283 : H12AffineFastState.Bounded env42283 := by
  intro p hp
  have h : env42283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42282_42283 : H12AffineEnvironment.transform 9 4 env42282 = env42283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env42282 == env42283) = true)

theorem identity42283 : scanCanonicalize (H12AffineFastState.compose env42283 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 310) := by decide +kernel

theorem selectedBound42283 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env42284 : List Nat := [2,4,8,16,32,16,128,256,512,4,2048,4096,4365,277,276,310,277,439,4,277,4097,396,17,4390,4484,17,43,276,4096,2340,4353,17,257,4113,276,512]

theorem envBound42284 : H12AffineFastState.Bounded env42284 := by
  intro p hp
  have h : env42284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42283_42284 : H12AffineEnvironment.transform 15 310 env42283 = env42284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 310 env42283 == env42284) = true)

theorem identity42284 : scanCanonicalize (H12AffineFastState.compose env42284 (packedSelected [2,11,18] rootPS)) = affineNative (2^(11+1) ^^^ 2587) := by decide +kernel

theorem selectedBound42284 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env42285 : List Nat := [2,4,8,16,32,16,128,256,512,4,2048,2587,2838,277,276,310,277,439,4,277,2586,396,17,2877,2975,17,43,276,2587,2340,2842,17,257,2570,276,512]

theorem envBound42285 : H12AffineFastState.Bounded env42285 := by
  intro p hp
  have h : env42285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42284_42285 : H12AffineEnvironment.transform 11 2587 env42284 = env42285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2587 env42284 == env42285) = true)

end H12CloudChart2