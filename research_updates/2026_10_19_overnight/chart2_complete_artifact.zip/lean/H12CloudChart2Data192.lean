import H12CloudChart2Data191

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound48237 : H12AffineFastState.Bounded env48237 := by
  intro p hp
  have h : env48237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48236_48237 : H12AffineEnvironment.transform 7 128 env48236 = env48237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 128 env48236 == env48237) = true)

theorem identity48237 : scanCanonicalize (H12AffineFastState.compose env48237 (packedSelected [5,8,10,13,15,17] rootPS)) = affineNative (2^(9+1) ^^^ 160) := by decide +kernel

theorem selectedBound48237 : packedSelected [5,8,10,13,15,17] rootPS < 2^1333 := by decide +kernel

def env48238 : List Nat := [2,4,8,16,32,1,128,128,148,160,2048,181,140,49,132,135,132,7,53,133,181,28,180,35,145,49,10,148,48,2197,129,132,128,133,32,0]

theorem envBound48238 : H12AffineFastState.Bounded env48238 := by
  intro p hp
  have h : env48238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48237_48238 : H12AffineEnvironment.transform 9 160 env48237 = env48238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 160 env48237 == env48238) = true)

theorem identity48238 : scanCanonicalize (H12AffineFastState.compose env48238 (packedSelected [0,1,3,4,5,7,8,9,10,12,13,16,18,19] rootPS)) = affineNative (2^(10+1) ^^^ 142) := by decide +kernel

theorem selectedBound48238 : packedSelected [0,1,3,4,5,7,8,9,10,12,13,16,18,19] rootPS < 2^1333 := by decide +kernel

def env48239 : List Nat := [2,4,8,16,32,1,128,128,148,160,142,181,140,49,132,135,132,7,53,133,181,28,180,35,145,49,10,148,48,27,129,132,128,133,32,0]

theorem envBound48239 : H12AffineFastState.Bounded env48239 := by
  intro p hp
  have h : env48239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48238_48239 : H12AffineEnvironment.transform 10 142 env48238 = env48239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 142 env48238 == env48239) = true)

theorem identity48239 : scanCanonicalize (H12AffineFastState.compose env48239 (packedSelected [0,1,2,4,5,10,11] rootPS)) = affineNative (2^(4+1) ^^^ 29) := by decide +kernel

theorem selectedBound48239 : packedSelected [0,1,2,4,5,10,11] rootPS < 2^1333 := by decide +kernel

def env48240 : List Nat := [2,4,8,16,29,1,128,128,148,157,142,136,140,12,132,135,132,7,8,133,136,28,137,30,145,12,10,148,13,27,129,132,128,133,29,0]

theorem envBound48240 : H12AffineFastState.Bounded env48240 := by
  intro p hp
  have h : env48240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48239_48240 : H12AffineEnvironment.transform 4 29 env48239 = env48240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 29 env48239 == env48240) = true)

theorem identity48240 : scanCanonicalize (H12AffineFastState.compose env48240 (packedSelected [0,1,3,7,8] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound48240 : packedSelected [0,1,3,7,8] rootPS < 2^1333 := by decide +kernel

def env48241 : List Nat := [2,4,2,16,23,1,128,128,148,151,132,130,134,6,132,135,132,7,2,133,130,22,131,20,145,6,0,148,7,17,129,132,128,133,23,0]

theorem envBound48241 : H12AffineFastState.Bounded env48241 := by
  intro p hp
  have h : env48241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48240_48241 : H12AffineEnvironment.transform 2 2 env48240 = env48241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env48240 == env48241) = true)

theorem identity48241 : scanCanonicalize (H12AffineFastState.compose env48241 (packedSelected [0,2,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound48241 : packedSelected [0,2,3,4] rootPS < 2^1333 := by decide +kernel

def env48242 : List Nat := [2,4,2,16,23,1,5,5,17,18,1,7,3,6,1,2,1,7,2,0,7,22,6,20,20,6,0,17,7,17,4,1,5,0,23,0]

theorem envBound48242 : H12AffineFastState.Bounded env48242 := by
  intro p hp
  have h : env48242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48241_48242 : H12AffineEnvironment.transform 6 5 env48241 = env48242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env48241 == env48242) = true)

theorem identity48242 : scanCanonicalize (H12AffineFastState.compose env48242 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound48242 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48243 : List Nat := [2,2,2,16,17,1,3,3,17,18,1,1,3,0,1,2,1,1,2,0,1,16,0,18,18,0,0,17,1,17,2,1,3,0,17,0]

theorem envBound48243 : H12AffineFastState.Bounded env48243 := by
  intro p hp
  have h : env48243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48242_48243 : H12AffineEnvironment.transform 1 2 env48242 = env48243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env48242 == env48243) = true)

def env48244 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74862,65665,4417,13340,4096,477,74047,69649,13769,78895,4414,74815,1296,81226,8205,74799,256,8201,1345,5952]

theorem envBound48244 : H12AffineFastState.Bounded env48244 := by
  intro p hp
  have h : env48244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48138_48244 : H12AffineEnvironment.transform 17 65665 env48138 = env48244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env48138 == env48244) = true)

theorem identity48244 : scanCanonicalize (H12AffineFastState.compose env48244 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound48244 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env48245 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,25,1297,5124,65536,66679,65665,4417,5125,4096,477,65830,69649,5584,70710,4414,66598,1296,73043,20,66614,256,16,1345,5952]

theorem envBound48245 : H12AffineFastState.Bounded env48245 := by
  intro p hp
  have h : env48245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48244_48245 : H12AffineEnvironment.transform 12 25 env48244 = env48245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env48244 == env48245) = true)

def env48246 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,4096,25,1297,5124,65536,66679,65665,4417,5125,4096,477,65830,69649,5584,70710,4414,66598,1296,73043,20,66614,256,16,1345,5140]

theorem envBound48246 : H12AffineFastState.Bounded env48246 := by
  intro p hp
  have h : env48246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48245_48246 : H12AffineEnvironment.transform 8 340 env48245 = env48246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env48245 == env48246) = true)

def env48247 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,1280,25,1297,260,65536,66679,65665,1089,261,1280,477,65830,66833,208,65846,1086,66598,1296,67667,20,66614,256,16,1345,276]

theorem envBound48247 : H12AffineFastState.Bounded env48247 := by
  intro p hp
  have h : env48247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48246_48247 : H12AffineEnvironment.transform 11 1280 env48246 = env48247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env48246 == env48247) = true)

theorem identity48247 : scanCanonicalize (H12AffineFastState.compose env48247 (packedSelected [1,8,28] rootPS)) = affineNative (2^(9+1) ^^^ 453) := by decide +kernel

theorem selectedBound48247 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env48248 : List Nat := [2,4,8,16,32,64,128,256,340,453,2048,197,25,212,260,65536,65970,65665,388,261,197,477,65830,65748,208,65846,507,66019,213,67667,20,66035,256,16,132,276]

theorem envBound48248 : H12AffineFastState.Bounded env48248 := by
  intro p hp
  have h : env48248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48247_48248 : H12AffineEnvironment.transform 9 453 env48247 = env48248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 453 env48247 == env48248) = true)

def env48249 : List Nat := [2,4,8,16,32,64,128,256,340,453,2048,197,25,212,260,304,130,433,388,261,197,477,22,484,208,6,507,211,213,2403,20,195,256,16,132,276]

theorem envBound48249 : H12AffineFastState.Bounded env48249 := by
  intro p hp
  have h : env48249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48248_48249 : H12AffineEnvironment.transform 15 304 env48248 = env48249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 304 env48248 == env48249) = true)

def env48250 : List Nat := [2,4,8,16,32,64,128,116,32,177,2048,197,25,212,112,68,130,197,240,113,197,169,22,144,208,6,143,211,213,2071,20,195,116,16,132,96]

theorem envBound48250 : H12AffineFastState.Bounded env48250 := by
  intro p hp
  have h : env48250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48249_48250 : H12AffineEnvironment.transform 7 116 env48249 = env48250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env48249 == env48250) = true)

theorem identity48250 : scanCanonicalize (H12AffineFastState.compose env48250 (packedSelected [1,10,13,15,19] rootPS)) = affineNative (2^(10+1) ^^^ 71) := by decide +kernel

theorem selectedBound48250 : packedSelected [1,10,13,15,19] rootPS < 2^1333 := by decide +kernel

def env48251 : List Nat := [2,4,8,16,32,64,128,116,32,177,71,197,25,212,112,68,130,197,240,113,197,169,22,144,208,6,143,211,213,80,20,195,116,16,132,96]

theorem envBound48251 : H12AffineFastState.Bounded env48251 := by
  intro p hp
  have h : env48251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48250_48251 : H12AffineEnvironment.transform 10 71 env48250 = env48251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 71 env48250 == env48251) = true)

theorem identity48251 : scanCanonicalize (H12AffineFastState.compose env48251 (packedSelected [0,1,3,4,11,12,13,16] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound48251 : packedSelected [0,1,3,4,11,12,13,16] rootPS < 2^1333 := by decide +kernel

def env48252 : List Nat := [2,4,4,16,32,64,128,116,32,177,71,197,21,212,112,68,130,197,240,113,197,165,22,144,208,6,131,211,213,80,20,195,116,16,132,96]

theorem envBound48252 : H12AffineFastState.Bounded env48252 := by
  intro p hp
  have h : env48252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48251_48252 : H12AffineEnvironment.transform 2 4 env48251 = env48252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env48251 == env48252) = true)

theorem identity48252 : scanCanonicalize (H12AffineFastState.compose env48252 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 54) := by decide +kernel

theorem selectedBound48252 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env48253 : List Nat := [2,4,4,16,32,54,128,2,32,177,49,179,21,162,6,50,130,179,134,7,179,165,22,144,166,6,131,165,163,38,20,181,2,16,132,22]

theorem envBound48253 : H12AffineFastState.Bounded env48253 := by
  intro p hp
  have h : env48253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48252_48253 : H12AffineEnvironment.transform 5 54 env48252 = env48253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 54 env48252 == env48253) = true)

theorem identity48253 : scanCanonicalize (H12AffineFastState.compose env48253 (packedSelected [0,1,4,5,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound48253 : packedSelected [0,1,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env48254 : List Nat := [2,4,4,16,32,54,18,2,32,35,49,33,21,48,6,50,16,33,20,7,33,55,22,2,52,6,17,55,49,38,20,39,2,16,22,22]

theorem envBound48254 : H12AffineFastState.Bounded env48254 := by
  intro p hp
  have h : env48254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48253_48254 : H12AffineEnvironment.transform 6 18 env48253 = env48254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env48253 == env48254) = true)

def env48255 : List Nat := [2,4,8,16,32,64,128,117,33,176,2048,197,25,212,113,69,130,196,241,112,197,168,22,145,208,6,142,211,213,2070,20,195,117,16,132,97]

theorem envBound48255 : H12AffineFastState.Bounded env48255 := by
  intro p hp
  have h : env48255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48249_48255 : H12AffineEnvironment.transform 7 117 env48249 = env48255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env48249 == env48255) = true)

theorem identity48255 : scanCanonicalize (H12AffineFastState.compose env48255 (packedSelected [1,10,13,15,19] rootPS)) = affineNative (2^(10+1) ^^^ 65) := by decide +kernel

theorem selectedBound48255 : packedSelected [1,10,13,15,19] rootPS < 2^1333 := by decide +kernel

def env48256 : List Nat := [2,4,8,16,32,64,128,117,33,176,65,197,25,212,113,69,130,196,241,112,197,168,22,145,208,6,142,211,213,87,20,195,117,16,132,97]

theorem envBound48256 : H12AffineFastState.Bounded env48256 := by
  intro p hp
  have h : env48256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48255_48256 : H12AffineEnvironment.transform 10 65 env48255 = env48256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 65 env48255 == env48256) = true)

theorem identity48256 : scanCanonicalize (H12AffineFastState.compose env48256 (packedSelected [2,4,5,9,11,12,13,15] rootPS)) = affineNative (2^(6+1) ^^^ 53) := by decide +kernel

theorem selectedBound48256 : packedSelected [2,4,5,9,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env48257 : List Nat := [2,4,8,16,32,64,53,117,33,5,65,112,25,97,113,69,55,113,68,112,112,29,22,36,101,6,59,102,96,87,20,118,117,16,49,97]

theorem envBound48257 : H12AffineFastState.Bounded env48257 := by
  intro p hp
  have h : env48257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48256_48257 : H12AffineEnvironment.transform 6 53 env48256 = env48257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 53 env48256 == env48257) = true)

theorem identity48257 : scanCanonicalize (H12AffineFastState.compose env48257 (packedSelected [0,1,2,7,8,10,12] rootPS)) = affineNative (2^(5+1) ^^^ 44) := by decide +kernel

theorem selectedBound48257 : packedSelected [0,1,2,7,8,10,12] rootPS < 2^1333 := by decide +kernel

def env48258 : List Nat := [2,4,8,16,32,44,53,25,33,5,45,28,25,13,29,41,55,29,40,28,28,29,22,36,9,6,59,10,12,59,20,26,25,16,49,13]

theorem envBound48258 : H12AffineFastState.Bounded env48258 := by
  intro p hp
  have h : env48258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48257_48258 : H12AffineEnvironment.transform 5 44 env48257 = env48258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 44 env48257 == env48258) = true)

theorem identity48258 : scanCanonicalize (H12AffineFastState.compose env48258 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 28) := by decide +kernel

theorem selectedBound48258 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env48259 : List Nat := [2,4,8,16,28,16,9,25,29,5,17,28,25,13,29,21,11,29,20,28,28,29,22,24,9,6,7,10,12,7,20,26,25,16,13,13]

theorem envBound48259 : H12AffineFastState.Bounded env48259 := by
  intro p hp
  have h : env48259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48258_48259 : H12AffineEnvironment.transform 4 28 env48258 = env48259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 28 env48258 == env48259) = true)

theorem identity48259 : scanCanonicalize (H12AffineFastState.compose env48259 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound48259 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48260 : List Nat := [2,4,8,13,1,13,9,4,0,5,12,1,4,13,0,8,11,0,9,1,1,0,11,5,9,6,7,10,12,7,9,7,4,13,13,13]

theorem envBound48260 : H12AffineFastState.Bounded env48260 := by
  intro p hp
  have h : env48260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48259_48260 : H12AffineEnvironment.transform 3 13 env48259 = env48260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env48259 == env48260) = true)

theorem identity48260 : scanCanonicalize (H12AffineFastState.compose env48260 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound48260 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48261 : List Nat := [2,4,3,6,1,6,2,4,0,5,7,1,4,6,0,3,0,0,2,1,1,0,0,5,2,6,7,1,7,7,2,7,4,6,6,6]

theorem envBound48261 : H12AffineFastState.Bounded env48261 := by
  intro p hp
  have h : env48261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48260_48261 : H12AffineEnvironment.transform 2 3 env48260 = env48261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env48260 == env48261) = true)

theorem identity48261 : scanCanonicalize (H12AffineFastState.compose env48261 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound48261 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env48262 : List Nat := [2,2,3,0,1,0,2,2,0,3,1,1,2,0,0,3,0,0,2,1,1,0,0,3,2,0,1,1,1,1,2,1,2,0,0,0]

theorem envBound48262 : H12AffineFastState.Bounded env48262 := by
  intro p hp
  have h : env48262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48261_48262 : H12AffineEnvironment.transform 1 2 env48261 = env48262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env48261 == env48262) = true)

def env48263 : List Nat := [2,4,8,16,32,64,128,256,340,453,2048,197,25,212,260,305,131,432,388,261,197,477,23,485,208,7,507,210,213,2402,20,194,256,16,132,276]

theorem envBound48263 : H12AffineFastState.Bounded env48263 := by
  intro p hp
  have h : env48263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48248_48263 : H12AffineEnvironment.transform 15 305 env48248 = env48263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 305 env48248 == env48263) = true)

def env48264 : List Nat := [2,4,8,16,32,64,128,116,32,177,2048,197,25,212,112,69,131,196,240,113,197,169,23,145,208,7,143,210,213,2070,20,194,116,16,132,96]

theorem envBound48264 : H12AffineFastState.Bounded env48264 := by
  intro p hp
  have h : env48264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48263_48264 : H12AffineEnvironment.transform 7 116 env48263 = env48264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env48263 == env48264) = true)

theorem identity48264 : scanCanonicalize (H12AffineFastState.compose env48264 (packedSelected [1,10,13,15,19] rootPS)) = affineNative (2^(10+1) ^^^ 148) := by decide +kernel

theorem selectedBound48264 : packedSelected [1,10,13,15,19] rootPS < 2^1333 := by decide +kernel

def env48265 : List Nat := [2,4,8,16,32,64,128,116,32,177,148,197,25,212,112,69,131,196,240,113,197,169,23,145,208,7,143,210,213,130,20,194,116,16,132,96]

theorem envBound48265 : H12AffineFastState.Bounded env48265 := by
  intro p hp
  have h : env48265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48264_48265 : H12AffineEnvironment.transform 10 148 env48264 = env48265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 148 env48264 == env48265) = true)

theorem identity48265 : scanCanonicalize (H12AffineFastState.compose env48265 (packedSelected [0,3,9,10,11,13,15] rootPS)) = affineNative (2^(5+1) ^^^ 44) := by decide +kernel

theorem selectedBound48265 : packedSelected [0,3,9,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env48266 : List Nat := [2,4,8,16,32,44,128,24,32,177,148,169,25,184,28,41,131,168,156,29,169,169,23,145,188,7,143,190,185,130,20,174,24,16,132,12]

theorem envBound48266 : H12AffineFastState.Bounded env48266 := by
  intro p hp
  have h : env48266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48265_48266 : H12AffineEnvironment.transform 5 44 env48265 = env48266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 44 env48265 == env48266) = true)

theorem identity48266 : scanCanonicalize (H12AffineFastState.compose env48266 (packedSelected [0,2,4,5,7,9,10] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound48266 : packedSelected [0,2,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env48267 : List Nat := [2,4,8,16,13,1,128,24,13,156,148,132,25,149,28,4,131,133,156,29,132,132,23,145,145,7,143,147,148,130,20,131,24,16,132,12]

theorem envBound48267 : H12AffineFastState.Bounded env48267 := by
  intro p hp
  have h : env48267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48266_48267 : H12AffineEnvironment.transform 4 13 env48266 = env48267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env48266 == env48267) = true)

theorem identity48267 : scanCanonicalize (H12AffineFastState.compose env48267 (packedSelected [1,7] rootPS)) = affineNative (2^(3+1) ^^^ 8) := by decide +kernel

theorem selectedBound48267 : packedSelected [1,7] rootPS < 2^1333 := by decide +kernel

def env48268 : List Nat := [2,4,8,8,13,1,128,0,13,132,140,132,1,141,4,4,131,133,132,5,132,132,15,137,137,7,143,139,140,130,12,131,0,8,132,12]

theorem envBound48268 : H12AffineFastState.Bounded env48268 := by
  intro p hp
  have h : env48268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48267_48268 : H12AffineEnvironment.transform 3 8 env48267 = env48268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 8 env48267 == env48268) = true)

theorem identity48268 : scanCanonicalize (H12AffineFastState.compose env48268 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 12) := by decide +kernel

theorem selectedBound48268 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env48269 : List Nat := [2,4,8,8,13,1,12,0,13,8,0,8,1,1,4,4,15,9,8,5,8,8,15,5,5,7,3,7,0,14,12,15,0,8,8,12]

theorem envBound48269 : H12AffineFastState.Bounded env48269 := by
  intro p hp
  have h : env48269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48268_48269 : H12AffineEnvironment.transform 6 12 env48268 = env48269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 12 env48268 == env48269) = true)

theorem identity48269 : scanCanonicalize (H12AffineFastState.compose env48269 (packedSelected [0,3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound48269 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env48270 : List Nat := [2,4,2,2,7,1,6,0,7,2,0,2,1,1,4,4,5,3,2,5,2,2,5,5,5,7,3,7,0,4,6,5,0,2,2,6]

theorem envBound48270 : H12AffineFastState.Bounded env48270 := by
  intro p hp
  have h : env48270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48269_48270 : H12AffineEnvironment.transform 2 2 env48269 = env48270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env48269 == env48270) = true)

theorem identity48270 : scanCanonicalize (H12AffineFastState.compose env48270 (packedSelected [0,1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound48270 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env48271 : List Nat := [0,4,0,0,5,1,4,0,5,0,0,0,1,1,4,4,5,1,0,5,0,0,5,5,5,5,1,5,0,4,4,5,0,0,0,4]

theorem envBound48271 : H12AffineFastState.Bounded env48271 := by
  intro p hp
  have h : env48271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48270_48271 : H12AffineEnvironment.transform 0 0 env48270 = env48271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env48270 == env48271) = true)

theorem identity48271 : scanCanonicalize (H12AffineFastState.compose env48271 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound48271 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48272 : List Nat := [0,0,0,0,1,1,0,0,1,0,0,0,1,1,0,0,1,1,0,1,0,0,1,1,1,1,1,1,0,0,0,1,0,0,0,0]

theorem envBound48272 : H12AffineFastState.Bounded env48272 := by
  intro p hp
  have h : env48272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48271_48272 : H12AffineEnvironment.transform 1 0 env48271 = env48272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env48271 == env48272) = true)

def env48273 : List Nat := [2,4,8,16,32,64,128,117,33,176,2048,197,25,212,113,68,131,197,241,112,197,168,23,144,208,7,142,210,213,2071,20,194,117,16,132,97]

theorem envBound48273 : H12AffineFastState.Bounded env48273 := by
  intro p hp
  have h : env48273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48263_48273 : H12AffineEnvironment.transform 7 117 env48263 = env48273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env48263 == env48273) = true)

theorem identity48273 : scanCanonicalize (H12AffineFastState.compose env48273 (packedSelected [1,10,13,15,19] rootPS)) = affineNative (2^(10+1) ^^^ 147) := by decide +kernel

theorem selectedBound48273 : packedSelected [1,10,13,15,19] rootPS < 2^1333 := by decide +kernel

def env48274 : List Nat := [2,4,8,16,32,64,128,117,33,176,147,197,25,212,113,68,131,197,241,112,197,168,23,144,208,7,142,210,213,132,20,194,117,16,132,97]

theorem envBound48274 : H12AffineFastState.Bounded env48274 := by
  intro p hp
  have h : env48274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48273_48274 : H12AffineEnvironment.transform 10 147 env48273 = env48274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 147 env48273 == env48274) = true)

theorem identity48274 : scanCanonicalize (H12AffineFastState.compose env48274 (packedSelected [3,5,7,8,9,10,11,15,17,18] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound48274 : packedSelected [3,5,7,8,9,10,11,15,17,18] rootPS < 2^1333 := by decide +kernel

def env48275 : List Nat := [2,4,8,16,32,64,24,117,33,40,11,93,25,76,113,68,27,93,105,112,93,48,23,8,72,7,22,74,77,28,20,90,117,16,28,97]

theorem envBound48275 : H12AffineFastState.Bounded env48275 := by
  intro p hp
  have h : env48275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48274_48275 : H12AffineEnvironment.transform 6 24 env48274 = env48275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env48274 == env48275) = true)

theorem identity48275 : scanCanonicalize (H12AffineFastState.compose env48275 (packedSelected [2,3,5,7,9,10,11] rootPS)) = affineNative (2^(4+1) ^^^ 28) := by decide +kernel

theorem selectedBound48275 : packedSelected [2,3,5,7,9,10,11] rootPS < 2^1333 := by decide +kernel

def env48276 : List Nat := [2,4,8,16,28,64,24,73,29,20,11,93,25,76,77,68,27,93,85,76,93,12,23,8,72,7,22,74,77,28,20,90,73,16,28,93]

theorem envBound48276 : H12AffineFastState.Bounded env48276 := by
  intro p hp
  have h : env48276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48275_48276 : H12AffineEnvironment.transform 4 28 env48275 = env48276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 28 env48275 == env48276) = true)

theorem identity48276 : scanCanonicalize (H12AffineFastState.compose env48276 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound48276 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env48277 : List Nat := [2,4,8,12,0,64,4,73,1,8,11,65,5,76,77,68,7,65,73,76,65,12,11,8,72,7,10,74,77,0,8,70,73,12,0,65]

theorem envBound48277 : H12AffineFastState.Bounded env48277 := by
  intro p hp
  have h : env48277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48276_48277 : H12AffineEnvironment.transform 3 12 env48276 = env48277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env48276 == env48277) = true)

theorem identity48277 : scanCanonicalize (H12AffineFastState.compose env48277 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound48277 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48278 : List Nat := [2,4,8,12,0,10,4,3,1,8,11,11,5,6,7,14,7,11,3,6,11,12,11,8,2,7,10,0,7,0,8,12,3,12,0,11]

theorem envBound48278 : H12AffineFastState.Bounded env48278 := by
  intro p hp
  have h : env48278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48277_48278 : H12AffineEnvironment.transform 5 10 env48277 = env48278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env48277 == env48278) = true)

theorem identity48278 : scanCanonicalize (H12AffineFastState.compose env48278 (packedSelected [1,3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound48278 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env48279 : List Nat := [2,2,8,10,0,10,2,3,1,8,11,11,3,0,1,8,1,11,3,0,11,10,11,8,2,1,10,0,1,0,8,10,3,10,0,11]

theorem envBound48279 : H12AffineFastState.Bounded env48279 := by
  intro p hp
  have h : env48279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48278_48279 : H12AffineEnvironment.transform 1 2 env48278 = env48279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env48278 == env48279) = true)

theorem identity48279 : scanCanonicalize (H12AffineFastState.compose env48279 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound48279 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48280 : List Nat := [2,2,3,1,0,1,2,3,1,3,0,0,3,0,1,3,1,0,3,0,0,1,0,3,2,1,1,0,1,0,3,1,3,1,0,0]

theorem envBound48280 : H12AffineFastState.Bounded env48280 := by
  intro p hp
  have h : env48280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48279_48280 : H12AffineEnvironment.transform 2 3 env48279 = env48280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env48279 == env48280) = true)

theorem identity48280 : scanCanonicalize (H12AffineFastState.compose env48280 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound48280 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48281 : List Nat := [1,1,0,1,0,1,1,0,1,0,0,0,0,0,1,0,1,0,0,0,0,1,0,0,1,1,1,0,1,0,0,1,0,1,0,0]

theorem envBound48281 : H12AffineFastState.Bounded env48281 := by
  intro p hp
  have h : env48281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48280_48281 : H12AffineEnvironment.transform 0 1 env48280 = env48281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env48280 == env48281) = true)

def env48282 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,1281,25,1297,261,65536,66679,65665,1088,260,1281,477,65830,66832,209,65847,1087,66598,1296,67666,20,66614,256,16,1345,277]

theorem envBound48282 : H12AffineFastState.Bounded env48282 := by
  intro p hp
  have h : env48282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48246_48282 : H12AffineEnvironment.transform 11 1281 env48246 = env48282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1281 env48246 == env48282) = true)

theorem identity48282 : scanCanonicalize (H12AffineFastState.compose env48282 (packedSelected [1,8,28] rootPS)) = affineNative (2^(6+1) ^^^ 85) := by decide +kernel

theorem selectedBound48282 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env48283 : List Nat := [2,4,8,16,32,64,85,256,340,1024,2048,1281,25,1297,261,65536,66679,65620,1088,260,1281,264,65830,66832,4,65847,1087,66598,1296,67666,20,66614,256,16,1345,277]

theorem envBound48283 : H12AffineFastState.Bounded env48283 := by
  intro p hp
  have h : env48283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48282_48283 : H12AffineEnvironment.transform 6 85 env48282 = env48283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 85 env48282 == env48283) = true)

def env48284 : List Nat := [2,4,8,16,32,64,85,256,340,1024,2048,1281,25,1297,261,1056,87,1140,1088,260,1281,264,1286,304,4,1303,1087,6,1296,3186,20,22,256,16,1345,277]

theorem envBound48284 : H12AffineFastState.Bounded env48284 := by
  intro p hp
  have h : env48284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48283_48284 : H12AffineEnvironment.transform 15 1056 env48283 = env48284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1056 env48283 == env48284) = true)

def env48285 : List Nat := [2,4,8,16,32,64,85,256,340,1024,372,1281,25,1297,261,1056,87,1140,1088,260,1281,264,1286,304,4,1303,1087,6,1296,1286,20,22,256,16,1345,277]

theorem envBound48285 : H12AffineFastState.Bounded env48285 := by
  intro p hp
  have h : env48285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48284_48285 : H12AffineEnvironment.transform 10 372 env48284 = env48285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 372 env48284 == env48285) = true)

theorem identity48285 : scanCanonicalize (H12AffineFastState.compose env48285 (packedSelected [1,4,9,12,13,16] rootPS)) = affineNative (2^(9+1) ^^^ 365) := by decide +kernel

theorem selectedBound48285 : packedSelected [1,4,9,12,13,16] rootPS < 2^1333 := by decide +kernel

def env48286 : List Nat := [2,4,8,16,32,64,85,256,340,365,372,108,25,124,261,333,87,281,301,260,108,264,107,304,4,122,338,6,125,107,20,22,256,16,44,277]

theorem envBound48286 : H12AffineFastState.Bounded env48286 := by
  intro p hp
  have h : env48286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48285_48286 : H12AffineEnvironment.transform 9 365 env48285 = env48286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 365 env48285 == env48286) = true)

theorem identity48286 : scanCanonicalize (H12AffineFastState.compose env48286 (packedSelected [2,7,9,10,15,19] rootPS)) = affineNative (2^(7+1) ^^^ 115) := by decide +kernel

theorem selectedBound48286 : packedSelected [2,7,9,10,15,19] rootPS < 2^1333 := by decide +kernel

def env48287 : List Nat := [2,4,8,16,32,64,85,115,39,30,7,108,25,124,118,62,87,106,94,119,108,123,107,67,4,122,33,6,125,107,20,22,115,16,44,102]

theorem envBound48287 : H12AffineFastState.Bounded env48287 := by
  intro p hp
  have h : env48287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48286_48287 : H12AffineEnvironment.transform 7 115 env48286 = env48287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 115 env48286 == env48287) = true)

theorem identity48287 : scanCanonicalize (H12AffineFastState.compose env48287 (packedSelected [0,1,5,8,9,10] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound48287 : packedSelected [0,1,5,8,9,10] rootPS < 2^1333 := by decide +kernel

def env48288 : List Nat := [2,4,8,16,13,64,85,94,10,30,7,65,25,81,91,19,87,71,94,90,65,86,70,67,4,87,12,6,80,70,20,22,94,16,1,75]

theorem envBound48288 : H12AffineFastState.Bounded env48288 := by
  intro p hp
  have h : env48288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48287_48288 : H12AffineEnvironment.transform 4 13 env48287 = env48288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env48287 == env48288) = true)

theorem identity48288 : scanCanonicalize (H12AffineFastState.compose env48288 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound48288 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env48289 : List Nat := [2,4,4,16,1,64,85,82,6,18,7,65,21,81,87,19,87,71,82,86,65,86,70,67,4,87,0,6,80,70,20,22,82,16,1,71]

theorem envBound48289 : H12AffineFastState.Bounded env48289 := by
  intro p hp
  have h : env48289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48288_48289 : H12AffineEnvironment.transform 2 4 env48288 = env48289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env48288 == env48289) = true)

theorem identity48289 : scanCanonicalize (H12AffineFastState.compose env48289 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound48289 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env48290 : List Nat := [2,4,4,16,1,17,4,3,6,18,7,16,21,0,6,19,6,22,3,7,16,7,23,18,4,6,0,6,1,23,20,22,3,16,1,22]

theorem envBound48290 : H12AffineFastState.Bounded env48290 := by
  intro p hp
  have h : env48290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48289_48290 : H12AffineEnvironment.transform 5 17 env48289 = env48290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env48289 == env48290) = true)

theorem identity48290 : scanCanonicalize (H12AffineFastState.compose env48290 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound48290 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48291 : List Nat := [2,4,4,6,1,7,4,3,6,4,7,6,3,0,6,5,6,0,3,7,6,7,1,4,4,6,0,6,1,1,2,0,3,6,1,0]

theorem envBound48291 : H12AffineFastState.Bounded env48291 := by
  intro p hp
  have h : env48291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48290_48291 : H12AffineEnvironment.transform 3 6 env48290 = env48291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env48290 == env48291) = true)

theorem identity48291 : scanCanonicalize (H12AffineFastState.compose env48291 (packedSelected [0,4] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound48291 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env48292 : List Nat := [2,2,2,0,1,1,2,3,0,2,1,0,3,0,0,3,0,0,3,1,0,1,1,2,2,0,0,0,1,1,2,0,3,0,1,0]

theorem envBound48292 : H12AffineFastState.Bounded env48292 := by
  intro p hp
  have h : env48292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48291_48292 : H12AffineEnvironment.transform 1 2 env48291 = env48292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env48291 == env48292) = true)

def env48293 : List Nat := [2,4,8,16,32,64,85,256,340,1024,373,1281,25,1297,261,1056,87,1140,1088,260,1281,264,1286,304,4,1303,1087,6,1296,1287,20,22,256,16,1345,277]

theorem envBound48293 : H12AffineFastState.Bounded env48293 := by
  intro p hp
  have h : env48293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48284_48293 : H12AffineEnvironment.transform 10 373 env48284 = env48293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 373 env48284 == env48293) = true)

theorem identity48293 : scanCanonicalize (H12AffineFastState.compose env48293 (packedSelected [1,4,9,12,13,16] rootPS)) = affineNative (2^(9+1) ^^^ 362) := by decide +kernel

theorem selectedBound48293 : packedSelected [1,4,9,12,13,16] rootPS < 2^1333 := by decide +kernel

def env48294 : List Nat := [2,4,8,16,32,64,85,256,340,362,373,107,25,123,261,330,87,286,298,260,107,264,108,304,4,125,341,6,122,109,20,22,256,16,43,277]

theorem envBound48294 : H12AffineFastState.Bounded env48294 := by
  intro p hp
  have h : env48294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48293_48294 : H12AffineEnvironment.transform 9 362 env48293 = env48294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 362 env48293 == env48294) = true)

theorem identity48294 : scanCanonicalize (H12AffineFastState.compose env48294 (packedSelected [2,3,4,8,9,11,12] rootPS)) = affineNative (2^(4+1) ^^^ 28) := by decide +kernel

theorem selectedBound48294 : packedSelected [2,3,4,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env48295 : List Nat := [2,4,8,16,28,64,85,256,340,342,329,87,25,71,261,330,87,286,278,260,87,264,80,268,4,65,341,6,70,81,20,22,256,16,23,277]

theorem envBound48295 : H12AffineFastState.Bounded env48295 := by
  intro p hp
  have h : env48295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48294_48295 : H12AffineEnvironment.transform 4 28 env48294 = env48295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 28 env48294 == env48295) = true)

theorem identity48295 : scanCanonicalize (H12AffineFastState.compose env48295 (packedSelected [4,8,9,10,13] rootPS)) = affineNative (2^(7+1) ^^^ 89) := by decide +kernel

theorem selectedBound48295 : packedSelected [4,8,9,10,13] rootPS < 2^1333 := by decide +kernel

def env48296 : List Nat := [2,4,8,16,28,64,85,89,13,15,16,87,25,71,92,19,87,71,79,93,87,81,80,85,4,65,12,6,70,81,20,22,89,16,23,76]

theorem envBound48296 : H12AffineFastState.Bounded env48296 := by
  intro p hp
  have h : env48296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48295_48296 : H12AffineEnvironment.transform 7 89 env48295 = env48296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 89 env48295 == env48296) = true)

theorem identity48296 : scanCanonicalize (H12AffineFastState.compose env48296 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound48296 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env48297 : List Nat := [2,4,8,16,28,1,20,24,13,15,16,22,25,6,29,19,22,6,14,28,22,16,17,20,4,0,12,6,7,16,20,22,24,16,23,13]

theorem envBound48297 : H12AffineFastState.Bounded env48297 := by
  intro p hp
  have h : env48297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48296_48297 : H12AffineEnvironment.transform 5 1 env48296 = env48297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env48296 == env48297) = true)

theorem identity48297 : scanCanonicalize (H12AffineFastState.compose env48297 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound48297 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48298 : List Nat := [2,4,8,7,11,1,3,15,13,15,7,1,14,6,10,4,1,6,14,11,1,7,6,3,4,0,12,6,7,7,3,1,15,7,0,13]

theorem envBound48298 : H12AffineFastState.Bounded env48298 := by
  intro p hp
  have h : env48298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48297_48298 : H12AffineEnvironment.transform 3 7 env48297 = env48298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env48297 == env48298) = true)

theorem identity48298 : scanCanonicalize (H12AffineFastState.compose env48298 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound48298 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48299 : List Nat := [2,3,8,0,11,1,3,8,10,8,0,1,9,1,10,3,1,1,9,11,1,0,1,3,3,0,11,1,0,0,3,1,8,0,0,10]

theorem envBound48299 : H12AffineFastState.Bounded env48299 := by
  intro p hp
  have h : env48299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48298_48299 : H12AffineEnvironment.transform 1 3 env48298 = env48299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env48298 == env48299) = true)

theorem identity48299 : scanCanonicalize (H12AffineFastState.compose env48299 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound48299 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env48300 : List Nat := [2,3,2,0,1,1,3,2,0,2,0,1,3,1,0,3,1,1,3,1,1,0,1,3,3,0,1,1,0,0,3,1,2,0,0,0]

theorem envBound48300 : H12AffineFastState.Bounded env48300 := by
  intro p hp
  have h : env48300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48299_48300 : H12AffineEnvironment.transform 2 2 env48299 = env48300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env48299 == env48300) = true)

def env48301 : List Nat := [2,4,8,16,32,64,85,256,340,1024,2048,1281,25,1297,261,1057,86,1141,1088,260,1281,264,1287,305,4,1302,1087,7,1296,3187,20,23,256,16,1345,277]

theorem envBound48301 : H12AffineFastState.Bounded env48301 := by
  intro p hp
  have h : env48301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48283_48301 : H12AffineEnvironment.transform 15 1057 env48283 = env48301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1057 env48283 == env48301) = true)

def env48302 : List Nat := [2,4,8,16,32,64,85,256,340,1024,372,1281,25,1297,261,1057,86,1141,1088,260,1281,264,1287,305,4,1302,1087,7,1296,1287,20,23,256,16,1345,277]

theorem envBound48302 : H12AffineFastState.Bounded env48302 := by
  intro p hp
  have h : env48302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48301_48302 : H12AffineEnvironment.transform 10 372 env48301 = env48302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 372 env48301 == env48302) = true)

theorem identity48302 : scanCanonicalize (H12AffineFastState.compose env48302 (packedSelected [1,4,9,12,13,16] rootPS)) = affineNative (2^(5+1) ^^^ 58) := by decide +kernel

theorem selectedBound48302 : packedSelected [1,4,9,12,13,16] rootPS < 2^1333 := by decide +kernel

def env48303 : List Nat := [2,4,8,16,32,58,47,256,302,1024,270,1281,25,1297,261,1057,44,1039,1082,260,1281,264,1287,305,4,1302,1087,7,1296,1287,20,23,256,16,1339,277]

theorem envBound48303 : H12AffineFastState.Bounded env48303 := by
  intro p hp
  have h : env48303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48302_48303 : H12AffineEnvironment.transform 5 58 env48302 = env48303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 58 env48302 == env48303) = true)

theorem identity48303 : scanCanonicalize (H12AffineFastState.compose env48303 (packedSelected [2,3,4,5,7,8,10,12,13,15,17,18] rootPS)) = affineNative (2^(9+1) ^^^ 57) := by decide +kernel

theorem selectedBound48303 : packedSelected [2,3,4,5,7,8,10,12,13,15,17,18] rootPS < 2^1333 := by decide +kernel

def env48304 : List Nat := [2,4,8,16,32,58,47,256,302,57,270,312,25,296,261,24,44,54,3,260,312,264,318,305,4,303,6,7,297,318,20,23,256,16,258,277]

theorem envBound48304 : H12AffineFastState.Bounded env48304 := by
  intro p hp
  have h : env48304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48303_48304 : H12AffineEnvironment.transform 9 57 env48303 = env48304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 57 env48303 == env48304) = true)

theorem identity48304 : scanCanonicalize (H12AffineFastState.compose env48304 (packedSelected [0,1,5,7] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound48304 : packedSelected [0,1,5,7] rootPS < 2^1333 := by decide +kernel

def env48305 : List Nat := [2,4,2,16,32,48,37,256,292,51,260,306,19,290,261,18,38,54,3,260,306,258,308,305,4,293,6,7,291,308,20,23,256,16,258,277]

theorem envBound48305 : H12AffineFastState.Bounded env48305 := by
  intro p hp
  have h : env48305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48304_48305 : H12AffineEnvironment.transform 2 2 env48304 = env48305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env48304 == env48305) = true)

theorem identity48305 : scanCanonicalize (H12AffineFastState.compose env48305 (packedSelected [3,5] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound48305 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env48306 : List Nat := [2,4,2,16,6,22,3,256,258,21,260,276,19,260,261,18,0,16,3,260,276,258,274,279,4,259,6,7,261,274,20,23,256,16,258,277]

theorem envBound48306 : H12AffineFastState.Bounded env48306 := by
  intro p hp
  have h : env48306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48305_48306 : H12AffineEnvironment.transform 4 6 env48305 = env48306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env48305 == env48306) = true)

theorem identity48306 : scanCanonicalize (H12AffineFastState.compose env48306 (packedSelected [1,2] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound48306 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env48307 : List Nat := [2,4,2,16,6,22,3,20,22,21,16,0,19,16,17,18,0,16,3,16,0,22,6,3,4,23,6,7,17,6,20,23,20,16,22,1]

theorem envBound48307 : H12AffineFastState.Bounded env48307 := by
  intro p hp
  have h : env48307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48306_48307 : H12AffineEnvironment.transform 7 20 env48306 = env48307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env48306 == env48307) = true)

theorem identity48307 : scanCanonicalize (H12AffineFastState.compose env48307 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound48307 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env48308 : List Nat := [2,4,2,1,6,7,3,5,7,4,1,0,2,1,0,3,0,1,3,1,0,7,6,3,4,6,6,7,0,6,5,6,5,1,7,1]

theorem envBound48308 : H12AffineFastState.Bounded env48308 := by
  intro p hp
  have h : env48308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48307_48308 : H12AffineEnvironment.transform 3 1 env48307 = env48308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env48307 == env48308) = true)

theorem identity48308 : scanCanonicalize (H12AffineFastState.compose env48308 (packedSelected [0,4] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound48308 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env48309 : List Nat := [2,2,2,1,0,1,3,3,1,2,1,0,2,1,0,3,0,1,3,1,0,1,0,3,2,0,0,1,0,0,3,0,3,1,1,1]

theorem envBound48309 : H12AffineFastState.Bounded env48309 := by
  intro p hp
  have h : env48309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48308_48309 : H12AffineEnvironment.transform 1 2 env48308 = env48309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env48308 == env48309) = true)

def env48310 : List Nat := [2,4,8,16,32,64,85,256,340,1024,373,1281,25,1297,261,1057,86,1141,1088,260,1281,264,1287,305,4,1302,1087,7,1296,1286,20,23,256,16,1345,277]

theorem envBound48310 : H12AffineFastState.Bounded env48310 := by
  intro p hp
  have h : env48310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48301_48310 : H12AffineEnvironment.transform 10 373 env48301 = env48310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 373 env48301 == env48310) = true)

theorem identity48310 : scanCanonicalize (H12AffineFastState.compose env48310 (packedSelected [1,4,9,12,13,16] rootPS)) = affineNative (2^(5+1) ^^^ 60) := by decide +kernel

theorem selectedBound48310 : packedSelected [1,4,9,12,13,16] rootPS < 2^1333 := by decide +kernel

def env48311 : List Nat := [2,4,8,16,32,60,41,256,296,1024,265,1281,25,1297,261,1057,42,1033,1084,260,1281,264,1287,305,4,1302,1087,7,1296,1286,20,23,256,16,1341,277]

theorem envBound48311 : H12AffineFastState.Bounded env48311 := by
  intro p hp
  have h : env48311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48310_48311 : H12AffineEnvironment.transform 5 60 env48310 = env48311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 60 env48310 == env48311) = true)

theorem identity48311 : scanCanonicalize (H12AffineFastState.compose env48311 (packedSelected [1,2,4,8,9,10,11,12,13,17,18] rootPS)) = affineNative (2^(7+1) ^^^ 56) := by decide +kernel

theorem selectedBound48311 : packedSelected [1,2,4,8,9,10,11,12,13,17,18] rootPS < 2^1333 := by decide +kernel

def env48312 : List Nat := [2,4,8,16,32,60,41,56,16,1024,49,1081,25,1065,61,1057,42,1033,1084,60,1081,48,1087,9,4,1070,1087,7,1064,1086,20,23,56,16,1029,45]

theorem envBound48312 : H12AffineFastState.Bounded env48312 := by
  intro p hp
  have h : env48312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48311_48312 : H12AffineEnvironment.transform 7 56 env48311 = env48312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 56 env48311 == env48312) = true)

theorem identity48312 : scanCanonicalize (H12AffineFastState.compose env48312 (packedSelected [2,3,7,9,10] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound48312 : packedSelected [2,3,7,9,10] rootPS < 2^1333 := by decide +kernel

def env48313 : List Nat := [2,4,8,16,27,7,18,3,16,1024,10,1026,25,1042,6,1050,17,1033,1031,7,1026,11,1028,9,4,1045,1028,7,1043,1029,20,23,3,16,1029,22]

theorem envBound48313 : H12AffineFastState.Bounded env48313 := by
  intro p hp
  have h : env48313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48312_48313 : H12AffineEnvironment.transform 4 27 env48312 = env48313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env48312 == env48313) = true)

theorem identity48313 : scanCanonicalize (H12AffineFastState.compose env48313 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound48313 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env48314 : List Nat := [2,4,2,16,17,7,18,3,16,1024,0,1026,19,1042,6,1040,17,1027,1031,7,1026,1,1028,3,4,1045,1028,7,1043,1029,20,23,3,16,1029,22]

theorem envBound48314 : H12AffineFastState.Bounded env48314 := by
  intro p hp
  have h : env48314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48313_48314 : H12AffineEnvironment.transform 2 2 env48313 = env48314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env48313 == env48314) = true)

theorem identity48314 : scanCanonicalize (H12AffineFastState.compose env48314 (packedSelected [0,1,4] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound48314 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env48315 : List Nat := [2,4,2,6,7,7,4,3,6,1024,0,1026,5,1028,6,1030,7,1027,1031,7,1026,1,1028,3,4,1027,1028,7,1029,1029,2,1,3,6,1029,0]

theorem envBound48315 : H12AffineFastState.Bounded env48315 := by
  intro p hp
  have h : env48315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48314_48315 : H12AffineEnvironment.transform 3 6 env48314 = env48315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env48314 == env48315) = true)

theorem identity48315 : scanCanonicalize (H12AffineFastState.compose env48315 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound48315 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48316 : List Nat := [2,2,2,0,1,1,2,3,0,1024,0,1026,3,1026,0,1024,1,1027,1025,1,1026,1,1026,3,2,1027,1026,1,1027,1027,2,1,3,0,1027,0]

theorem envBound48316 : H12AffineFastState.Bounded env48316 := by
  intro p hp
  have h : env48316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48315_48316 : H12AffineEnvironment.transform 1 2 env48315 = env48316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env48315 == env48316) = true)

theorem identity48316 : scanCanonicalize (H12AffineFastState.compose env48316 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 3) := by decide +kernel

theorem selectedBound48316 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48317 : List Nat := [2,2,2,0,1,1,2,3,0,3,0,1,3,1,0,3,1,0,2,1,1,1,1,3,2,0,1,1,0,0,2,1,3,0,0,0]

theorem envBound48317 : H12AffineFastState.Bounded env48317 := by
  intro p hp
  have h : env48317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48316_48317 : H12AffineEnvironment.transform 9 3 env48316 = env48317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 3 env48316 == env48317) = true)

def env48318 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,4096,25,1297,5124,65536,66679,65665,4417,5125,4096,477,65830,69649,5584,70710,4414,66598,1296,73043,20,66614,256,16,1345,5141]

theorem envBound48318 : H12AffineFastState.Bounded env48318 := by
  intro p hp
  have h : env48318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48245_48318 : H12AffineEnvironment.transform 8 341 env48245 = env48318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env48245 == env48318) = true)

def env48319 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,1280,25,1297,260,65536,66679,65665,1089,261,1280,477,65830,66833,208,65846,1086,66598,1296,67667,20,66614,256,16,1345,277]

theorem envBound48319 : H12AffineFastState.Bounded env48319 := by
  intro p hp
  have h : env48319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48318_48319 : H12AffineEnvironment.transform 11 1280 env48318 = env48319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env48318 == env48319) = true)

theorem identity48319 : scanCanonicalize (H12AffineFastState.compose env48319 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 1266) := by decide +kernel

theorem selectedBound48319 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env48320 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,1280,25,1297,260,1266,133,1139,1089,261,1280,477,1492,483,208,1476,1086,212,1296,3233,20,196,256,16,1345,277]

theorem envBound48320 : H12AffineFastState.Bounded env48320 := by
  intro p hp
  have h : env48320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48319_48320 : H12AffineEnvironment.transform 15 1266 env48319 = env48320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1266 env48319 == env48320) = true)

def env48321 : List Nat := [2,4,8,16,32,64,128,256,341,456,2048,200,25,217,260,314,133,443,393,261,200,477,28,483,208,12,502,212,216,2409,20,196,256,16,137,277]

theorem envBound48321 : H12AffineFastState.Bounded env48321 := by
  intro p hp
  have h : env48321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48320_48321 : H12AffineEnvironment.transform 9 456 env48320 = env48321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 456 env48320 == env48321) = true)

theorem identity48321 : scanCanonicalize (H12AffineFastState.compose env48321 (packedSelected [0,1,4,8,9,15,17,18,20,21,23,24,27,41] rootPS)) = affineNative (2^(10+1) ^^^ 223) := by decide +kernel

theorem selectedBound48321 : packedSelected [0,1,4,8,9,15,17,18,20,21,23,24,27,41] rootPS < 2^1333 := by decide +kernel

def env48322 : List Nat := [2,4,8,16,32,64,128,256,341,456,223,200,25,217,260,314,133,443,393,261,200,477,28,483,208,12,502,212,216,438,20,196,256,16,137,277]

theorem envBound48322 : H12AffineFastState.Bounded env48322 := by
  intro p hp
  have h : env48322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48321_48322 : H12AffineEnvironment.transform 10 223 env48321 = env48322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 223 env48321 == env48322) = true)

theorem identity48322 : scanCanonicalize (H12AffineFastState.compose env48322 (packedSelected [1,3,4,8,9,10,17,19,20] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound48322 : packedSelected [1,3,4,8,9,10,17,19,20] rootPS < 2^1333 := by decide +kernel

def env48323 : List Nat := [2,4,8,16,32,64,128,116,33,188,223,200,25,217,112,78,133,207,253,113,200,169,28,151,208,12,130,212,216,194,20,196,116,16,137,97]

theorem envBound48323 : H12AffineFastState.Bounded env48323 := by
  intro p hp
  have h : env48323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48322_48323 : H12AffineEnvironment.transform 7 116 env48322 = env48323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env48322 == env48323) = true)

theorem identity48323 : scanCanonicalize (H12AffineFastState.compose env48323 (packedSelected [0,1,2,4,5,16] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound48323 : packedSelected [0,1,2,4,5,16] rootPS < 2^1333 := by decide +kernel

def env48324 : List Nat := [2,4,8,16,32,64,34,116,33,30,125,106,25,123,112,78,39,109,95,113,106,11,28,53,114,12,32,118,122,96,20,102,116,16,43,97]

theorem envBound48324 : H12AffineFastState.Bounded env48324 := by
  intro p hp
  have h : env48324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48323_48324 : H12AffineEnvironment.transform 6 34 env48323 = env48324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env48323 == env48324) = true)

theorem identity48324 : scanCanonicalize (H12AffineFastState.compose env48324 (packedSelected [1,2,3,7,8,9,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound48324 : packedSelected [1,2,3,7,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env48325 : List Nat := [2,4,8,16,32,32,34,20,33,30,29,10,25,27,16,46,39,13,63,17,10,11,28,53,18,12,32,22,26,0,20,6,20,16,43,1]

theorem envBound48325 : H12AffineFastState.Bounded env48325 := by
  intro p hp
  have h : env48325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48324_48325 : H12AffineEnvironment.transform 5 32 env48324 = env48325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env48324 == env48325) = true)

theorem identity48325 : scanCanonicalize (H12AffineFastState.compose env48325 (packedSelected [5,8] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound48325 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env48326 : List Nat := [2,4,3,16,32,32,34,20,33,21,22,1,18,16,16,37,39,6,52,17,1,0,23,53,18,7,32,22,17,0,20,6,20,16,32,1]

theorem envBound48326 : H12AffineFastState.Bounded env48326 := by
  intro p hp
  have h : env48326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48325_48326 : H12AffineEnvironment.transform 2 3 env48325 = env48326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env48325 == env48326) = true)

theorem identity48326 : scanCanonicalize (H12AffineFastState.compose env48326 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound48326 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env48327 : List Nat := [2,4,3,6,32,32,34,2,33,3,0,1,4,6,6,37,39,6,34,7,1,0,1,35,4,7,32,0,7,0,2,6,2,6,32,1]

theorem envBound48327 : H12AffineFastState.Bounded env48327 := by
  intro p hp
  have h : env48327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48326_48327 : H12AffineEnvironment.transform 3 6 env48326 = env48327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env48326 == env48327) = true)

theorem identity48327 : scanCanonicalize (H12AffineFastState.compose env48327 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound48327 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48328 : List Nat := [2,4,3,6,7,7,5,2,6,3,0,1,4,6,6,2,0,6,5,7,1,0,1,4,4,7,7,0,7,0,2,6,2,6,7,1]

theorem envBound48328 : H12AffineFastState.Bounded env48328 := by
  intro p hp
  have h : env48328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48327_48328 : H12AffineEnvironment.transform 4 7 env48327 = env48328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env48327 == env48328) = true)

def env48329 : List Nat := [2,4,8,16,32,64,128,256,341,457,2048,201,25,216,260,315,133,442,392,261,201,477,29,483,208,13,503,212,217,2408,20,196,256,16,136,277]

theorem envBound48329 : H12AffineFastState.Bounded env48329 := by
  intro p hp
  have h : env48329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48320_48329 : H12AffineEnvironment.transform 9 457 env48320 = env48329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 457 env48320 == env48329) = true)

theorem identity48329 : scanCanonicalize (H12AffineFastState.compose env48329 (packedSelected [0,1,4,8,9,15,17,18,20,21,23,24,27,41] rootPS)) = affineNative (2^(10+1) ^^^ 210) := by decide +kernel

theorem selectedBound48329 : packedSelected [0,1,4,8,9,15,17,18,20,21,23,24,27,41] rootPS < 2^1333 := by decide +kernel

def env48330 : List Nat := [2,4,8,16,32,64,128,256,341,457,210,201,25,216,260,315,133,442,392,261,201,477,29,483,208,13,503,212,217,442,20,196,256,16,136,277]

theorem envBound48330 : H12AffineFastState.Bounded env48330 := by
  intro p hp
  have h : env48330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48329_48330 : H12AffineEnvironment.transform 10 210 env48329 = env48330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 210 env48329 == env48330) = true)

theorem identity48330 : scanCanonicalize (H12AffineFastState.compose env48330 (packedSelected [2,3,4,7,10,16,17,18,19,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 89) := by decide +kernel

theorem selectedBound48330 : packedSelected [2,3,4,7,10,16,17,18,19,20,21] rootPS < 2^1333 := by decide +kernel

def env48331 : List Nat := [2,4,8,16,32,64,128,89,12,144,210,201,25,216,93,98,133,227,209,92,201,132,29,186,208,13,174,212,217,227,20,196,89,16,136,76]

theorem envBound48331 : H12AffineFastState.Bounded env48331 := by
  intro p hp
  have h : env48331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48330_48331 : H12AffineEnvironment.transform 7 89 env48330 = env48331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 89 env48330 == env48331) = true)

theorem identity48331 : scanCanonicalize (H12AffineFastState.compose env48331 (packedSelected [0,3,4,10] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound48331 : packedSelected [0,3,4,10] rootPS < 2^1333 := by decide +kernel

def env48332 : List Nat := [2,4,8,16,32,11,128,18,12,144,153,130,25,147,22,41,133,168,154,23,130,132,29,186,155,13,174,159,146,168,20,143,18,16,136,7]

theorem envBound48332 : H12AffineFastState.Bounded env48332 := by
  intro p hp
  have h : env48332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48331_48332 : H12AffineEnvironment.transform 5 11 env48331 = env48332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env48331 == env48332) = true)

theorem identity48332 : scanCanonicalize (H12AffineFastState.compose env48332 (packedSelected [0,3,4,5,8,11,12] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound48332 : packedSelected [0,3,4,5,8,11,12] rootPS < 2^1333 := by decide +kernel

def env48333 : List Nat := [2,4,8,16,17,11,128,18,12,144,153,130,25,147,22,24,133,153,154,23,130,132,29,139,155,13,159,159,146,153,20,143,18,16,136,7]

theorem envBound48333 : H12AffineFastState.Bounded env48333 := by
  intro p hp
  have h : env48333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48332_48333 : H12AffineEnvironment.transform 4 17 env48332 = env48333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env48332 == env48333) = true)

theorem identity48333 : scanCanonicalize (H12AffineFastState.compose env48333 (packedSelected [3,4,7] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound48333 : packedSelected [3,4,7] rootPS < 2^1333 := by decide +kernel

def env48334 : List Nat := [2,4,8,1,0,11,128,3,12,129,136,130,8,130,7,9,133,136,139,6,130,132,12,139,138,13,142,142,131,136,5,143,3,1,136,7]

theorem envBound48334 : H12AffineFastState.Bounded env48334 := by
  intro p hp
  have h : env48334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48333_48334 : H12AffineEnvironment.transform 3 1 env48333 = env48334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env48333 == env48334) = true)

theorem identity48334 : scanCanonicalize (H12AffineFastState.compose env48334 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound48334 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env48335 : List Nat := [2,4,8,1,0,11,3,3,12,2,11,1,8,1,7,9,6,11,8,6,1,7,12,8,9,13,13,13,0,11,5,12,3,1,11,7]

theorem envBound48335 : H12AffineFastState.Bounded env48335 := by
  intro p hp
  have h : env48335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48334_48335 : H12AffineEnvironment.transform 6 3 env48334 = env48335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env48334 == env48335) = true)

theorem identity48335 : scanCanonicalize (H12AffineFastState.compose env48335 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound48335 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48336 : List Nat := [2,2,8,1,0,11,3,3,10,2,11,1,8,1,1,9,0,11,8,0,1,1,10,8,9,11,11,11,0,11,3,10,3,1,11,1]

theorem envBound48336 : H12AffineFastState.Bounded env48336 := by
  intro p hp
  have h : env48336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48335_48336 : H12AffineEnvironment.transform 1 2 env48335 = env48336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env48335 == env48336) = true)

theorem identity48336 : scanCanonicalize (H12AffineFastState.compose env48336 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound48336 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48337 : List Nat := [2,2,3,1,0,0,3,3,1,2,0,1,3,1,1,2,0,0,3,0,1,1,1,3,2,0,0,0,0,0,3,1,3,1,0,1]

theorem envBound48337 : H12AffineFastState.Bounded env48337 := by
  intro p hp
  have h : env48337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48336_48337 : H12AffineEnvironment.transform 2 3 env48336 = env48337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env48336 == env48337) = true)

def env48338 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,1281,25,1297,261,65536,66679,65665,1088,260,1281,477,65830,66832,209,65847,1087,66598,1296,67666,20,66614,256,16,1345,276]

theorem envBound48338 : H12AffineFastState.Bounded env48338 := by
  intro p hp
  have h : env48338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48318_48338 : H12AffineEnvironment.transform 11 1281 env48318 = env48338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1281 env48318 == env48338) = true)

theorem identity48338 : scanCanonicalize (H12AffineFastState.compose env48338 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 482) := by decide +kernel

theorem selectedBound48338 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env48339 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,1281,25,1297,261,482,1429,355,1088,260,1281,477,196,1266,209,213,1087,1476,1296,2480,20,1492,256,16,1345,276]

theorem envBound48339 : H12AffineFastState.Bounded env48339 := by
  intro p hp
  have h : env48339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48338_48339 : H12AffineEnvironment.transform 15 482 env48338 = env48339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 482 env48338 == env48339) = true)

def env48340 : List Nat := [2,4,8,16,32,64,88,256,341,1024,2048,1281,25,1297,261,314,1357,355,1088,260,1281,261,28,1066,9,13,1087,1308,1296,2408,20,1292,256,16,1345,276]

theorem envBound48340 : H12AffineFastState.Bounded env48340 := by
  intro p hp
  have h : env48340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48339_48340 : H12AffineEnvironment.transform 6 88 env48339 = env48340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env48339 == env48340) = true)

theorem identity48340 : scanCanonicalize (H12AffineFastState.compose env48340 (packedSelected [0,1,4,7,8,9,12,18,23,24,38] rootPS)) = affineNative (2^(10+1) ^^^ 258) := by decide +kernel

theorem selectedBound48340 : packedSelected [0,1,4,7,8,9,12,18,23,24,38] rootPS < 2^1333 := by decide +kernel

def env48341 : List Nat := [2,4,8,16,32,64,88,256,341,1024,258,1281,25,1297,261,314,1357,355,1088,260,1281,261,28,1066,9,13,1087,1308,1296,106,20,1292,256,16,1345,276]

theorem envBound48341 : H12AffineFastState.Bounded env48341 := by
  intro p hp
  have h : env48341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48340_48341 : H12AffineEnvironment.transform 10 258 env48340 = env48341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 258 env48340 == env48341) = true)

theorem identity48341 : scanCanonicalize (H12AffineFastState.compose env48341 (packedSelected [2,5,7,11,12,13,15,16,21,23,27] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound48341 : packedSelected [2,5,7,11,12,13,15,16,21,23,27] rootPS < 2^1333 := by decide +kernel

def env48342 : List Nat := [2,4,8,16,32,64,88,37,112,1024,39,1060,25,1076,32,31,1128,70,1088,33,1060,32,28,1066,9,13,1087,1081,1077,106,20,1065,37,16,1124,49]

theorem envBound48342 : H12AffineFastState.Bounded env48342 := by
  intro p hp
  have h : env48342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48341_48342 : H12AffineEnvironment.transform 7 37 env48341 = env48342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env48341 == env48342) = true)

theorem identity48342 : scanCanonicalize (H12AffineFastState.compose env48342 (packedSelected [0,2,3,4,5,7,9,10,17] rootPS)) = affineNative (2^(5+1) ^^^ 22) := by decide +kernel

theorem selectedBound48342 : packedSelected [0,2,3,4,5,7,9,10,17] rootPS < 2^1333 := by decide +kernel

def env48343 : List Nat := [2,4,8,16,32,22,14,37,38,1024,39,1060,25,1076,32,31,1086,16,1046,33,1060,32,28,1066,9,13,1087,1081,1077,60,20,1065,37,16,1074,49]

theorem envBound48343 : H12AffineFastState.Bounded env48343 := by
  intro p hp
  have h : env48343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48342_48343 : H12AffineEnvironment.transform 5 22 env48342 = env48343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 22 env48342 == env48343) = true)

theorem identity48343 : scanCanonicalize (H12AffineFastState.compose env48343 (packedSelected [4,7,8,11] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound48343 : packedSelected [4,7,8,11] rootPS < 2^1333 := by decide +kernel

def env48344 : List Nat := [2,4,8,16,32,22,14,37,38,53,39,17,25,1,32,31,11,16,35,33,17,32,28,31,9,13,10,12,0,60,20,28,37,16,7,49]

theorem envBound48344 : H12AffineFastState.Bounded env48344 := by
  intro p hp
  have h : env48344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48343_48344 : H12AffineEnvironment.transform 9 53 env48343 = env48344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env48343 == env48344) = true)

theorem identity48344 : scanCanonicalize (H12AffineFastState.compose env48344 (packedSelected [0,1,2,5,7,8] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound48344 : packedSelected [0,1,2,5,7,8] rootPS < 2^1333 := by decide +kernel

def env48345 : List Nat := [2,4,5,16,32,22,3,37,38,53,39,17,20,1,32,18,6,16,35,33,17,32,17,18,4,0,7,1,0,49,20,17,37,16,7,49]

theorem envBound48345 : H12AffineFastState.Bounded env48345 := by
  intro p hp
  have h : env48345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48344_48345 : H12AffineEnvironment.transform 2 5 env48344 = env48345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env48344 == env48345) = true)

theorem identity48345 : scanCanonicalize (H12AffineFastState.compose env48345 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 23) := by decide +kernel

theorem selectedBound48345 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env48346 : List Nat := [2,4,5,16,23,22,3,18,17,2,16,17,20,1,23,18,6,16,20,22,17,23,17,18,4,0,7,1,0,6,20,17,18,16,7,6]

theorem envBound48346 : H12AffineFastState.Bounded env48346 := by
  intro p hp
  have h : env48346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48345_48346 : H12AffineEnvironment.transform 4 23 env48345 = env48346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 23 env48345 == env48346) = true)

theorem identity48346 : scanCanonicalize (H12AffineFastState.compose env48346 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound48346 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48347 : List Nat := [2,4,5,7,0,1,3,5,6,2,7,6,3,1,0,5,6,7,3,1,6,0,6,5,4,0,7,1,0,6,3,6,5,7,7,6]

theorem envBound48347 : H12AffineFastState.Bounded env48347 := by
  intro p hp
  have h : env48347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48346_48347 : H12AffineEnvironment.transform 3 7 env48346 = env48347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env48346 == env48347) = true)

theorem identity48347 : scanCanonicalize (H12AffineFastState.compose env48347 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound48347 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48348 : List Nat := [2,2,3,1,0,1,3,3,0,2,1,0,3,1,0,3,0,1,3,1,0,0,0,3,2,0,1,1,0,0,3,0,3,1,1,0]

theorem envBound48348 : H12AffineFastState.Bounded env48348 := by
  intro p hp
  have h : env48348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48347_48348 : H12AffineEnvironment.transform 1 2 env48347 = env48348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env48347 == env48348) = true)

def env48349 : List Nat := [2,4,8,16,32,64,89,256,341,1024,2048,1281,25,1297,261,315,1356,355,1088,260,1281,260,29,1067,8,12,1087,1309,1296,2409,20,1293,256,16,1345,276]

theorem envBound48349 : H12AffineFastState.Bounded env48349 := by
  intro p hp
  have h : env48349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48339_48349 : H12AffineEnvironment.transform 6 89 env48339 = env48349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env48339 == env48349) = true)

theorem identity48349 : scanCanonicalize (H12AffineFastState.compose env48349 (packedSelected [0,1,4,7,8,9,12,18,23,24,38] rootPS)) = affineNative (2^(10+1) ^^^ 270) := by decide +kernel

theorem selectedBound48349 : packedSelected [0,1,4,7,8,9,12,18,23,24,38] rootPS < 2^1333 := by decide +kernel

def env48350 : List Nat := [2,4,8,16,32,64,89,256,341,1024,270,1281,25,1297,261,315,1356,355,1088,260,1281,260,29,1067,8,12,1087,1309,1296,103,20,1293,256,16,1345,276]

theorem envBound48350 : H12AffineFastState.Bounded env48350 := by
  intro p hp
  have h : env48350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48349_48350 : H12AffineEnvironment.transform 10 270 env48349 = env48350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 270 env48349 == env48350) = true)

theorem identity48350 : scanCanonicalize (H12AffineFastState.compose env48350 (packedSelected [1,2,7,8,12,15,16,21,24,27] rootPS)) = affineNative (2^(9+1) ^^^ 331) := by decide +kernel

theorem selectedBound48350 : packedSelected [1,2,7,8,12,15,16,21,24,27] rootPS < 2^1333 := by decide +kernel

def env48351 : List Nat := [2,4,8,16,32,64,89,256,341,331,270,74,25,90,261,315,7,355,267,260,74,260,29,352,8,12,372,86,91,103,20,70,256,16,10,276]

theorem envBound48351 : H12AffineFastState.Bounded env48351 := by
  intro p hp
  have h : env48351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48350_48351 : H12AffineEnvironment.transform 9 331 env48350 = env48351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 331 env48350 == env48351) = true)

theorem identity48351 : scanCanonicalize (H12AffineFastState.compose env48351 (packedSelected [1,3,7,9,10,11,17] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound48351 : packedSelected [1,3,7,9,10,11,17] rootPS < 2^1333 := by decide +kernel

def env48352 : List Nat := [2,4,8,16,32,17,8,256,260,282,270,27,25,11,261,315,7,306,267,260,27,260,29,305,8,12,293,7,10,54,20,23,256,16,10,276]

theorem envBound48352 : H12AffineFastState.Bounded env48352 := by
  intro p hp
  have h : env48352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48351_48352 : H12AffineEnvironment.transform 5 17 env48351 = env48352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env48351 == env48352) = true)

theorem identity48352 : scanCanonicalize (H12AffineFastState.compose env48352 (packedSelected [0,1,2,3,5,7,8,10,11] rootPS)) = affineNative (2^(7+1) ^^^ 2) := by decide +kernel

theorem selectedBound48352 : packedSelected [0,1,2,3,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env48353 : List Nat := [2,4,8,16,32,17,8,2,6,24,12,27,25,11,7,57,7,48,9,6,27,6,29,51,8,12,39,7,10,54,20,23,2,16,10,22]

theorem envBound48353 : H12AffineFastState.Bounded env48353 := by
  intro p hp
  have h : env48353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48352_48353 : H12AffineEnvironment.transform 7 2 env48352 = env48353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 2 env48352 == env48353) = true)

theorem identity48353 : scanCanonicalize (H12AffineFastState.compose env48353 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound48353 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48354 : List Nat := [2,3,8,16,32,17,8,2,1,24,11,27,25,11,0,57,0,48,9,1,27,1,26,51,8,11,32,0,10,49,19,16,2,16,10,17]

theorem envBound48354 : H12AffineFastState.Bounded env48354 := by
  intro p hp
  have h : env48354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48353_48354 : H12AffineEnvironment.transform 1 3 env48353 = env48354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env48353 == env48354) = true)

theorem identity48354 : scanCanonicalize (H12AffineFastState.compose env48354 (packedSelected [0,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound48354 : packedSelected [0,4,5] rootPS < 2^1333 := by decide +kernel

def env48355 : List Nat := [2,3,8,16,0,17,8,2,1,24,11,27,25,11,0,25,0,16,9,1,27,1,26,19,8,11,0,0,10,17,19,16,2,16,10,17]

theorem envBound48355 : H12AffineFastState.Bounded env48355 := by
  intro p hp
  have h : env48355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48354_48355 : H12AffineEnvironment.transform 4 0 env48354 = env48355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env48354 == env48355) = true)

theorem identity48355 : scanCanonicalize (H12AffineFastState.compose env48355 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound48355 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env48356 : List Nat := [2,3,8,0,0,1,8,2,1,8,11,11,9,11,0,9,0,0,9,1,11,1,10,3,8,11,0,0,10,1,3,0,2,0,10,1]

theorem envBound48356 : H12AffineFastState.Bounded env48356 := by
  intro p hp
  have h : env48356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48355_48356 : H12AffineEnvironment.transform 3 0 env48355 = env48356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env48355 == env48356) = true)

theorem identity48356 : scanCanonicalize (H12AffineFastState.compose env48356 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound48356 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48357 : List Nat := [2,3,2,0,0,1,2,2,1,2,1,1,3,1,0,3,0,0,3,1,1,1,0,3,2,1,0,0,0,1,3,0,2,0,0,1]

theorem envBound48357 : H12AffineFastState.Bounded env48357 := by
  intro p hp
  have h : env48357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48356_48357 : H12AffineEnvironment.transform 2 2 env48356 = env48357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env48356 == env48357) = true)

def env48358 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,21585,32769,4096,61649,91182,123165,28889,78894,385203,90414,1297,96347,25884,74798,256,25880,1345,21072]

theorem envBound48358 : H12AffineFastState.Bounded env48358 := by
  intro p hp
  have h : env48358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47974_48358 : H12AffineEnvironment.transform 18 21585 env47974 = env48358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21585 env47974 == env48358) = true)

theorem identity48358 : scanCanonicalize (H12AffineFastState.compose env48358 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 25676) := by decide +kernel

theorem selectedBound48358 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env48359 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,25676,65536,74862,262144,21585,25677,4096,5277,91182,66897,28889,78894,328959,90414,1297,96347,25884,74798,256,25880,1345,21072]

theorem envBound48359 : H12AffineFastState.Bounded env48359 := by
  intro p hp
  have h : env48359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48358_48359 : H12AffineEnvironment.transform 14 25676 env48358 = env48359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25676 env48358 == env48359) = true)

def env48360 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74862,262144,4417,8541,4096,5277,74046,66897,13769,78894,328959,74814,1297,81227,8204,74798,256,8200,1345,5952]

theorem envBound48360 : H12AffineFastState.Bounded env48360 := by
  intro p hp
  have h : env48360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48359_48360 : H12AffineEnvironment.transform 13 1296 env48359 = env48360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env48359 == env48360) = true)

def env48361 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74862,65664,4417,8541,4096,5277,74046,66897,13769,78894,1151,74814,1297,81227,8204,74798,256,8200,1345,5952]

theorem envBound48361 : H12AffineFastState.Bounded env48361 := by
  intro p hp
  have h : env48361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48360_48361 : H12AffineEnvironment.transform 17 65664 env48360 = env48361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env48360 == env48361) = true)

theorem identity48361 : scanCanonicalize (H12AffineFastState.compose env48361 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound48361 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env48362 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,8192,1296,8540,65536,74862,65664,273,8541,80,1229,74046,66897,9625,74878,1151,74814,1297,77083,8204,74798,256,8200,1345,1808]

theorem envBound48362 : H12AffineFastState.Bounded env48362 := by
  intro p hp
  have h : env48362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48361_48362 : H12AffineEnvironment.transform 11 80 env48361 = env48362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env48361 == env48362) = true)

def env48363 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,80,8192,80,8540,65536,74030,65664,273,8541,80,397,74046,65553,8409,74046,319,74110,81,75867,8204,74094,256,8200,1,592]

theorem envBound48363 : H12AffineFastState.Bounded env48363 := by
  intro p hp
  have h : env48363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48362_48363 : H12AffineEnvironment.transform 9 320 env48362 = env48363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env48362 == env48363) = true)

theorem identity48363 : scanCanonicalize (H12AffineFastState.compose env48363 (packedSelected [7,20,27] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound48363 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env48364 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,80,8192,80,8540,35,8461,163,273,8541,80,397,8477,50,8409,8477,319,8541,81,10360,8204,8525,256,8200,1,592]

theorem envBound48364 : H12AffineFastState.Bounded env48364 := by
  intro p hp
  have h : env48364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48363_48364 : H12AffineEnvironment.transform 15 35 env48363 = env48364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env48363 == env48364) = true)

theorem identity48364 : scanCanonicalize (H12AffineFastState.compose env48364 (packedSelected [0,1,4,7,8,9,16,19,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound48364 : packedSelected [0,1,4,7,8,9,16,19,20] rootPS < 2^1333 := by decide +kernel

def env48365 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,0,8192,0,8460,35,8461,163,273,8461,0,397,8477,50,8329,8477,319,8461,1,10280,8204,8477,256,8200,1,512]

theorem envBound48365 : H12AffineFastState.Bounded env48365 := by
  intro p hp
  have h : env48365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48364_48365 : H12AffineEnvironment.transform 5 16 env48364 = env48365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env48364 == env48365) = true)

theorem identity48365 : scanCanonicalize (H12AffineFastState.compose env48365 (packedSelected [2,13,17] rootPS)) = affineNative (2^(12+1) ^^^ 2721) := by decide +kernel

theorem selectedBound48365 : packedSelected [2,13,17] rootPS < 2^1333 := by decide +kernel

def env48366 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,0,2721,0,2989,35,2988,163,273,2988,0,397,3004,50,2600,3004,319,2988,1,649,2733,3004,256,2729,1,512]

theorem envBound48366 : H12AffineFastState.Bounded env48366 := by
  intro p hp
  have h : env48366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48365_48366 : H12AffineEnvironment.transform 12 2721 env48365 = env48366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2721 env48365 == env48366) = true)

theorem identity48366 : scanCanonicalize (H12AffineFastState.compose env48366 (packedSelected [0,1,2,5,7,11,12,13,15] rootPS)) = affineNative (2^(8+1) ^^^ 147) := by decide +kernel

theorem selectedBound48366 : packedSelected [0,1,2,5,7,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env48367 : List Nat := [2,4,8,16,32,16,128,256,147,272,2048,0,2098,0,2366,35,2367,163,273,2367,0,397,2351,50,2235,2351,319,2367,1,26,2110,2351,256,2106,1,147]

theorem envBound48367 : H12AffineFastState.Bounded env48367 := by
  intro p hp
  have h : env48367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48366_48367 : H12AffineEnvironment.transform 8 147 env48366 = env48367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 147 env48366 == env48367) = true)

theorem identity48367 : scanCanonicalize (H12AffineFastState.compose env48367 (packedSelected [1,2,5] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound48367 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env48368 : List Nat := [2,4,8,16,32,16,9,256,26,272,2048,0,2098,0,2366,35,2367,42,273,2367,0,260,2351,50,2098,2351,319,2367,1,26,2110,2351,256,2106,1,26]

theorem envBound48368 : H12AffineFastState.Bounded env48368 := by
  intro p hp
  have h : env48368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48367_48368 : H12AffineEnvironment.transform 6 9 env48367 = env48368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env48367 == env48368) = true)

theorem identity48368 : scanCanonicalize (H12AffineFastState.compose env48368 (packedSelected [2,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 319) := by decide +kernel

theorem selectedBound48368 : packedSelected [2,7,8] rootPS < 2^1333 := by decide +kernel

def env48369 : List Nat := [2,4,8,16,32,16,9,256,26,272,319,0,269,0,1,35,0,42,273,0,0,260,16,50,269,16,319,0,1,26,257,16,256,261,1,26]

theorem envBound48369 : H12AffineFastState.Bounded env48369 := by
  intro p hp
  have h : env48369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48368_48369 : H12AffineEnvironment.transform 10 319 env48368 = env48369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 319 env48368 == env48369) = true)

theorem identity48369 : scanCanonicalize (H12AffineFastState.compose env48369 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound48369 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env48370 : List Nat := [2,4,8,16,16,16,9,256,26,272,271,0,269,0,1,19,0,26,273,0,0,260,16,2,269,16,271,0,1,26,257,16,256,261,1,26]

theorem envBound48370 : H12AffineFastState.Bounded env48370 := by
  intro p hp
  have h : env48370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48369_48370 : H12AffineEnvironment.transform 4 16 env48369 = env48370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env48369 == env48370) = true)

theorem identity48370 : scanCanonicalize (H12AffineFastState.compose env48370 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound48370 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env48371 : List Nat := [2,4,8,16,16,16,9,15,26,31,0,0,2,0,1,19,0,26,30,0,0,11,16,2,2,16,0,0,1,26,14,16,15,10,1,26]

theorem envBound48371 : H12AffineFastState.Bounded env48371 := by
  intro p hp
  have h : env48371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48370_48371 : H12AffineEnvironment.transform 7 15 env48370 = env48371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env48370 == env48371) = true)

def env48372 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,80,8192,81,8540,65536,74031,65664,273,8541,80,396,74046,65552,8408,74047,318,74111,80,75866,8204,74095,256,8200,0,593]

theorem envBound48372 : H12AffineFastState.Bounded env48372 := by
  intro p hp
  have h : env48372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48362_48372 : H12AffineEnvironment.transform 9 321 env48362 = env48372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env48362 == env48372) = true)

theorem identity48372 : scanCanonicalize (H12AffineFastState.compose env48372 (packedSelected [7,20,27] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound48372 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env48373 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,80,8192,81,8540,115,8540,243,273,8541,80,396,8525,99,8408,8524,318,8460,80,10281,8204,8476,256,8200,0,593]

theorem envBound48373 : H12AffineFastState.Bounded env48373 := by
  intro p hp
  have h : env48373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48372_48373 : H12AffineEnvironment.transform 15 115 env48372 = env48373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env48372 == env48373) = true)

theorem identity48373 : scanCanonicalize (H12AffineFastState.compose env48373 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound48373 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env48374 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,0,8192,1,8460,35,8460,163,273,8461,0,396,8477,51,8328,8476,318,8460,0,10281,8204,8476,256,8200,0,513]

theorem envBound48374 : H12AffineFastState.Bounded env48374 := by
  intro p hp
  have h : env48374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48373_48374 : H12AffineEnvironment.transform 5 16 env48373 = env48374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env48373 == env48374) = true)

theorem identity48374 : scanCanonicalize (H12AffineFastState.compose env48374 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound48374 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env48375 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,0,269,1,1,35,1,163,273,0,0,396,16,51,389,17,318,1,0,2340,257,17,256,261,0,513]

theorem envBound48375 : H12AffineFastState.Bounded env48375 := by
  intro p hp
  have h : env48375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48374_48375 : H12AffineEnvironment.transform 12 269 env48374 = env48375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env48374 == env48375) = true)

theorem identity48375 : scanCanonicalize (H12AffineFastState.compose env48375 (packedSelected [1,2,5] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound48375 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env48376 : List Nat := [2,4,8,16,11,16,128,256,512,273,2048,0,269,1,1,8,1,136,273,0,0,396,16,24,389,17,277,1,0,2319,257,17,256,261,0,513]

theorem envBound48376 : H12AffineFastState.Bounded env48376 := by
  intro p hp
  have h : env48376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48375_48376 : H12AffineEnvironment.transform 4 11 env48375 = env48376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env48375 == env48376) = true)

theorem identity48376 : scanCanonicalize (H12AffineFastState.compose env48376 (packedSelected [3,8] rootPS)) = affineNative (2^(8+1) ^^^ 390) := by decide +kernel

theorem selectedBound48376 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env48377 : List Nat := [2,4,8,16,11,16,128,256,390,273,2048,0,269,1,1,8,1,136,273,0,0,396,16,24,389,17,277,1,0,2319,257,17,256,261,0,391]

theorem envBound48377 : H12AffineFastState.Bounded env48377 := by
  intro p hp
  have h : env48377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48376_48377 : H12AffineEnvironment.transform 8 390 env48376 = env48377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 390 env48376 == env48377) = true)

theorem identity48377 : scanCanonicalize (H12AffineFastState.compose env48377 (packedSelected [1,7] rootPS)) = affineNative (2^(10+1) ^^^ 268) := by decide +kernel

theorem selectedBound48377 : packedSelected [1,7] rootPS < 2^1333 := by decide +kernel

def env48378 : List Nat := [2,4,8,16,11,16,128,256,390,273,268,0,269,1,1,8,1,136,273,0,0,396,16,24,389,17,277,1,0,3,257,17,256,261,0,391]

theorem envBound48378 : H12AffineFastState.Bounded env48378 := by
  intro p hp
  have h : env48378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48377_48378 : H12AffineEnvironment.transform 10 268 env48377 = env48378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 268 env48377 == env48378) = true)

theorem identity48378 : scanCanonicalize (H12AffineFastState.compose env48378 (packedSelected [1,2,3,10] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound48378 : packedSelected [1,2,3,10] rootPS < 2^1333 := by decide +kernel

def env48379 : List Nat := [2,4,8,0,11,0,128,256,390,257,268,0,269,1,1,8,1,136,257,0,0,396,0,8,389,1,261,1,0,3,257,1,256,261,0,391]

theorem envBound48379 : H12AffineFastState.Bounded env48379 := by
  intro p hp
  have h : env48379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48378_48379 : H12AffineEnvironment.transform 3 0 env48378 = env48379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env48378 == env48379) = true)

theorem identity48379 : scanCanonicalize (H12AffineFastState.compose env48379 (packedSelected [3] rootPS)) = affineNative (2^(7+1) ^^^ 3) := by decide +kernel

theorem selectedBound48379 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env48380 : List Nat := [2,4,8,0,11,0,128,3,133,2,15,0,14,1,1,8,1,136,2,0,0,143,0,8,134,1,6,1,0,3,2,1,3,6,0,132]

theorem envBound48380 : H12AffineFastState.Bounded env48380 := by
  intro p hp
  have h : env48380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48379_48380 : H12AffineEnvironment.transform 7 3 env48379 = env48380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 3 env48379 == env48380) = true)

theorem identity48380 : scanCanonicalize (H12AffineFastState.compose env48380 (packedSelected [0,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound48380 : packedSelected [0,11,12] rootPS < 2^1333 := by decide +kernel

def env48381 : List Nat := [2,4,8,0,11,0,4,3,1,2,15,0,14,1,1,8,1,12,2,0,0,11,0,8,2,1,6,1,0,3,2,1,3,6,0,0]

theorem envBound48381 : H12AffineFastState.Bounded env48381 := by
  intro p hp
  have h : env48381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48380_48381 : H12AffineEnvironment.transform 6 4 env48380 = env48381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env48380 == env48381) = true)

theorem identity48381 : scanCanonicalize (H12AffineFastState.compose env48381 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound48381 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48382 : List Nat := [2,3,8,0,11,0,3,3,1,2,8,0,9,1,1,8,1,11,2,0,0,11,0,8,2,1,1,1,0,3,2,1,3,1,0,0]

theorem envBound48382 : H12AffineFastState.Bounded env48382 := by
  intro p hp
  have h : env48382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48381_48382 : H12AffineEnvironment.transform 1 3 env48381 = env48382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env48381 == env48382) = true)

theorem identity48382 : scanCanonicalize (H12AffineFastState.compose env48382 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound48382 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48383 : List Nat := [1,0,8,0,8,0,0,0,1,1,8,0,9,1,1,8,1,8,1,0,0,8,0,8,1,1,1,1,0,0,1,1,0,1,0,0]

theorem envBound48383 : H12AffineFastState.Bounded env48383 := by
  intro p hp
  have h : env48383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48382_48383 : H12AffineEnvironment.transform 0 1 env48382 = env48383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env48382 == env48383) = true)

theorem identity48383 : scanCanonicalize (H12AffineFastState.compose env48383 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound48383 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48384 : List Nat := [1,0,0,0,0,0,0,0,1,1,0,0,1,1,1,0,1,0,1,0,0,0,0,0,1,1,1,1,0,0,1,1,0,1,0,0]

theorem envBound48384 : H12AffineFastState.Bounded env48384 := by
  intro p hp
  have h : env48384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48383_48384 : H12AffineEnvironment.transform 2 0 env48383 = env48384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env48383 == env48384) = true)

def env48385 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74862,65665,4417,8541,4096,5277,74046,66897,13769,78894,1150,74814,1297,81227,8204,74798,256,8200,1345,5952]

theorem envBound48385 : H12AffineFastState.Bounded env48385 := by
  intro p hp
  have h : env48385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48360_48385 : H12AffineEnvironment.transform 17 65665 env48360 = env48385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env48360 == env48385) = true)

theorem identity48385 : scanCanonicalize (H12AffineFastState.compose env48385 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound48385 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env48386 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,8192,1,8540,65536,74111,65665,4417,8541,4096,4492,74046,65600,12504,78143,367,74031,0,79962,8204,74047,256,8200,80,4689]

theorem envBound48386 : H12AffineFastState.Bounded env48386 := by
  intro p hp
  have h : env48386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48385_48386 : H12AffineEnvironment.transform 9 273 env48385 = env48386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env48385 == env48386) = true)

def env48387 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,772,8192,1,8540,65536,74111,65665,581,8541,772,648,74046,65600,9180,74299,367,74031,0,76638,8204,74047,256,8200,80,341]

theorem envBound48387 : H12AffineFastState.Bounded env48387 := by
  intro p hp
  have h : env48387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48386_48387 : H12AffineEnvironment.transform 11 772 env48386 = env48387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 772 env48386 == env48387) = true)

def env48388 : List Nat := [2,4,8,16,32,0,128,256,512,273,2048,772,8192,1,8476,65536,74047,65665,517,8477,772,648,74046,65536,9116,74299,303,74031,0,76574,8204,74047,256,8200,16,277]

theorem envBound48388 : H12AffineFastState.Bounded env48388 := by
  intro p hp
  have h : env48388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48387_48388 : H12AffineEnvironment.transform 5 0 env48387 = env48388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env48387 == env48388) = true)

theorem identity48388 : scanCanonicalize (H12AffineFastState.compose env48388 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 156) := by decide +kernel

theorem selectedBound48388 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env48389 : List Nat := [2,4,8,16,32,0,128,256,512,273,2048,772,156,1,384,65536,65955,65665,517,385,772,648,65954,65536,768,66215,303,65971,0,68482,144,65955,256,148,16,277]

theorem envBound48389 : H12AffineFastState.Bounded env48389 := by
  intro p hp
  have h : env48389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48388_48389 : H12AffineEnvironment.transform 12 156 env48388 = env48389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 156 env48388 == env48389) = true)

def env48390 : List Nat := [2,4,8,16,32,0,4,256,512,273,2048,772,24,1,260,65536,65831,65541,517,261,772,524,65830,65536,768,66083,303,65847,0,68358,20,65831,256,16,16,277]

theorem envBound48390 : H12AffineFastState.Bounded env48390 := by
  intro p hp
  have h : env48390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48389_48390 : H12AffineEnvironment.transform 6 4 env48389 = env48390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env48389 == env48390) = true)

theorem identity48390 : scanCanonicalize (H12AffineFastState.compose env48390 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 806) := by decide +kernel

theorem selectedBound48390 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env48391 : List Nat := [2,4,8,16,32,0,4,256,512,273,2048,772,24,1,260,806,513,803,517,261,772,524,512,806,768,261,303,529,0,2080,20,513,256,16,16,277]

theorem envBound48391 : H12AffineFastState.Bounded env48391 := by
  intro p hp
  have h : env48391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48390_48391 : H12AffineEnvironment.transform 15 806 env48390 = env48391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 806 env48390 == env48391) = true)

theorem identity48391 : scanCanonicalize (H12AffineFastState.compose env48391 (packedSelected [0,1,2,3,7,10,12,17,20] rootPS)) = affineNative (2^(10+1) ^^^ 538) := by decide +kernel

theorem selectedBound48391 : packedSelected [0,1,2,3,7,10,12,17,20] rootPS < 2^1333 := by decide +kernel

def env48392 : List Nat := [2,4,8,16,32,0,4,256,512,273,538,772,24,1,260,806,513,803,517,261,772,524,512,806,768,261,303,529,0,570,20,513,256,16,16,277]

theorem envBound48392 : H12AffineFastState.Bounded env48392 := by
  intro p hp
  have h : env48392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48391_48392 : H12AffineEnvironment.transform 10 538 env48391 = env48392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 538 env48391 == env48392) = true)

theorem identity48392 : scanCanonicalize (H12AffineFastState.compose env48392 (packedSelected [3,5,15] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound48392 : packedSelected [3,5,15] rootPS < 2^1333 := by decide +kernel

def env48393 : List Nat := [2,4,8,16,32,0,4,256,11,273,17,271,24,1,260,301,10,296,14,261,271,7,11,301,267,261,303,26,0,49,20,10,256,16,16,277]

theorem envBound48393 : H12AffineFastState.Bounded env48393 := by
  intro p hp
  have h : env48393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48392_48393 : H12AffineEnvironment.transform 8 11 env48392 = env48393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env48392 == env48393) = true)

theorem identity48393 : scanCanonicalize (H12AffineFastState.compose env48393 (packedSelected [3,5,10,12] rootPS)) = affineNative (2^(7+1) ^^^ 62) := by decide +kernel

theorem selectedBound48393 : packedSelected [3,5,10,12] rootPS < 2^1333 := by decide +kernel

def env48394 : List Nat := [2,4,8,16,32,0,4,62,11,47,17,49,24,1,58,19,10,22,14,59,49,7,11,19,53,59,17,26,0,49,20,10,62,16,16,43]

theorem envBound48394 : H12AffineFastState.Bounded env48394 := by
  intro p hp
  have h : env48394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48393_48394 : H12AffineEnvironment.transform 7 62 env48393 = env48394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 62 env48393 == env48394) = true)

theorem identity48394 : scanCanonicalize (H12AffineFastState.compose env48394 (packedSelected [1,2,4,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 23) := by decide +kernel

theorem selectedBound48394 : packedSelected [1,2,4,5,7] rootPS < 2^1333 := by decide +kernel

def env48395 : List Nat := [2,4,8,16,23,0,4,9,11,24,17,6,24,1,13,19,10,22,14,12,6,7,11,19,2,12,17,26,0,6,20,10,9,16,16,28]

theorem envBound48395 : H12AffineFastState.Bounded env48395 := by
  intro p hp
  have h : env48395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48394_48395 : H12AffineEnvironment.transform 4 23 env48394 = env48395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 23 env48394 == env48395) = true)

theorem identity48395 : scanCanonicalize (H12AffineFastState.compose env48395 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound48395 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env48396 : List Nat := [2,4,2,16,23,0,4,3,1,18,17,6,18,1,7,19,0,22,4,6,6,7,1,19,2,6,17,16,0,6,20,0,3,16,16,22]

theorem envBound48396 : H12AffineFastState.Bounded env48396 := by
  intro p hp
  have h : env48396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48395_48396 : H12AffineEnvironment.transform 2 2 env48395 = env48396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env48395 == env48396) = true)

theorem identity48396 : scanCanonicalize (H12AffineFastState.compose env48396 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound48396 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48397 : List Nat := [2,4,2,0,7,0,4,3,1,2,1,6,2,1,7,3,0,6,4,6,6,7,1,3,2,6,1,0,0,6,4,0,3,0,0,6]

theorem envBound48397 : H12AffineFastState.Bounded env48397 := by
  intro p hp
  have h : env48397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48396_48397 : H12AffineEnvironment.transform 3 0 env48396 = env48397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env48396 == env48397) = true)

def env48398 : List Nat := [2,4,8,16,32,0,5,256,512,273,2048,772,25,1,261,65536,65830,65540,517,260,772,525,65831,65536,768,66082,303,65846,0,68359,21,65830,256,17,16,277]

theorem envBound48398 : H12AffineFastState.Bounded env48398 := by
  intro p hp
  have h : env48398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48389_48398 : H12AffineEnvironment.transform 6 5 env48389 = env48398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env48389 == env48398) = true)

theorem identity48398 : scanCanonicalize (H12AffineFastState.compose env48398 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 51) := by decide +kernel

theorem selectedBound48398 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env48399 : List Nat := [2,4,8,16,32,0,5,256,512,273,2048,772,25,1,261,51,277,55,517,260,772,525,276,51,768,529,303,261,0,2868,21,277,256,17,16,277]

theorem envBound48399 : H12AffineFastState.Bounded env48399 := by
  intro p hp
  have h : env48399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48398_48399 : H12AffineEnvironment.transform 15 51 env48398 = env48399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 51 env48398 == env48399) = true)

theorem identity48399 : scanCanonicalize (H12AffineFastState.compose env48399 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound48399 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env48400 : List Nat := [2,4,8,0,32,0,5,256,512,257,2048,772,9,1,261,35,261,39,517,260,772,525,260,35,768,513,303,261,0,2852,5,261,256,1,0,261]

theorem envBound48400 : H12AffineFastState.Bounded env48400 := by
  intro p hp
  have h : env48400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48399_48400 : H12AffineEnvironment.transform 3 0 env48399 = env48400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env48399 == env48400) = true)

theorem identity48400 : scanCanonicalize (H12AffineFastState.compose env48400 (packedSelected [0,2,3,7,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 12) := by decide +kernel

theorem selectedBound48400 : packedSelected [0,2,3,7,11,12] rootPS < 2^1333 := by decide +kernel

def env48401 : List Nat := [2,4,8,0,32,0,5,256,512,257,12,772,9,1,261,35,261,39,517,260,772,525,260,35,768,513,303,261,0,808,5,261,256,1,0,261]

theorem envBound48401 : H12AffineFastState.Bounded env48401 := by
  intro p hp
  have h : env48401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48400_48401 : H12AffineEnvironment.transform 10 12 env48400 = env48401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 12 env48400 == env48401) = true)

theorem identity48401 : scanCanonicalize (H12AffineFastState.compose env48401 (packedSelected [0,3,7,8,10,11] rootPS)) = affineNative (2^(8+1) ^^^ 38) := by decide +kernel

theorem selectedBound48401 : packedSelected [0,3,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env48402 : List Nat := [2,4,8,0,32,0,5,256,38,257,12,290,9,1,261,35,261,39,35,260,290,43,260,35,294,39,303,261,0,270,5,261,256,1,0,261]

theorem envBound48402 : H12AffineFastState.Bounded env48402 := by
  intro p hp
  have h : env48402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48401_48402 : H12AffineEnvironment.transform 8 38 env48401 = env48402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 38 env48401 == env48402) = true)

theorem identity48402 : scanCanonicalize (H12AffineFastState.compose env48402 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound48402 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env48403 : List Nat := [2,4,8,0,1,0,5,256,7,257,12,259,9,1,261,2,261,6,2,260,259,10,260,2,263,6,270,261,0,270,5,261,256,1,0,261]

theorem envBound48403 : H12AffineFastState.Bounded env48403 := by
  intro p hp
  have h : env48403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48402_48403 : H12AffineEnvironment.transform 4 1 env48402 = env48403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env48402 == env48403) = true)

def env48404 : List Nat := [2,4,8,16,32,1,128,256,512,273,2048,772,8192,1,8477,65536,74046,65665,516,8476,772,648,74046,65537,9117,74299,302,74031,0,76575,8204,74047,256,8200,17,276]

theorem envBound48404 : H12AffineFastState.Bounded env48404 := by
  intro p hp
  have h : env48404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48387_48404 : H12AffineEnvironment.transform 5 1 env48387 = env48404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env48387 == env48404) = true)

theorem identity48404 : scanCanonicalize (H12AffineFastState.compose env48404 (packedSelected [1,8,28] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound48404 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env48405 : List Nat := [2,4,8,16,32,1,4,256,512,273,2048,772,8192,1,8477,65536,74046,65541,516,8476,772,524,74046,65537,8985,74299,302,74031,0,76575,8204,74047,256,8200,17,276]

theorem envBound48405 : H12AffineFastState.Bounded env48405 := by
  intro p hp
  have h : env48405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48404_48405 : H12AffineEnvironment.transform 6 4 env48404 = env48405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env48404 == env48405) = true)

def env48406 : List Nat := [2,4,8,16,32,1,4,256,512,273,2048,772,24,1,261,65536,65830,65541,516,260,772,524,65830,65537,769,66083,302,65847,0,68359,20,65831,256,16,17,276]

theorem envBound48406 : H12AffineFastState.Bounded env48406 := by
  intro p hp
  have h : env48406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48405_48406 : H12AffineEnvironment.transform 12 24 env48405 = env48406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env48405 == env48406) = true)

theorem identity48406 : scanCanonicalize (H12AffineFastState.compose env48406 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 806) := by decide +kernel

theorem selectedBound48406 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env48407 : List Nat := [2,4,8,16,32,1,4,256,512,273,2048,772,24,1,261,806,512,803,516,260,772,524,512,807,769,261,302,529,0,2081,20,513,256,16,17,276]

theorem envBound48407 : H12AffineFastState.Bounded env48407 := by
  intro p hp
  have h : env48407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48406_48407 : H12AffineEnvironment.transform 15 806 env48406 = env48407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 806 env48406 == env48407) = true)

theorem identity48407 : scanCanonicalize (H12AffineFastState.compose env48407 (packedSelected [0,1,2,3,7,10,12,17,20] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound48407 : packedSelected [0,1,2,3,7,10,12,17,20] rootPS < 2^1333 := by decide +kernel

def env48408 : List Nat := [2,4,8,16,32,1,4,256,512,273,10,772,24,1,261,806,512,803,516,260,772,524,512,807,769,261,302,529,0,43,20,513,256,16,17,276]

theorem envBound48408 : H12AffineFastState.Bounded env48408 := by
  intro p hp
  have h : env48408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48407_48408 : H12AffineEnvironment.transform 10 10 env48407 = env48408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env48407 == env48408) = true)

theorem identity48408 : scanCanonicalize (H12AffineFastState.compose env48408 (packedSelected [3,5,15] rootPS)) = affineNative (2^(7+1) ^^^ 31) := by decide +kernel

theorem selectedBound48408 : packedSelected [3,5,15] rootPS < 2^1333 := by decide +kernel

def env48409 : List Nat := [2,4,8,16,32,1,4,31,512,14,10,539,24,1,26,569,512,572,516,27,539,524,512,568,542,26,49,529,0,43,20,513,31,16,17,11]

theorem envBound48409 : H12AffineFastState.Bounded env48409 := by
  intro p hp
  have h : env48409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48408_48409 : H12AffineEnvironment.transform 7 31 env48408 = env48409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 31 env48408 == env48409) = true)

theorem identity48409 : scanCanonicalize (H12AffineFastState.compose env48409 (packedSelected [1,2,5,8,10,12] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound48409 : packedSelected [1,2,5,8,10,12] rootPS < 2^1333 := by decide +kernel

def env48410 : List Nat := [2,4,8,1,32,1,4,14,512,14,10,522,9,1,11,552,512,557,516,10,522,524,512,553,527,11,32,512,0,43,5,513,14,1,0,11]

theorem envBound48410 : H12AffineFastState.Bounded env48410 := by
  intro p hp
  have h : env48410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48409_48410 : H12AffineEnvironment.transform 3 1 env48409 = env48410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env48409 == env48410) = true)

theorem identity48410 : scanCanonicalize (H12AffineFastState.compose env48410 (packedSelected [1,3,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound48410 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env48411 : List Nat := [2,4,8,1,1,1,4,14,512,14,10,522,9,1,11,521,512,524,516,10,522,524,512,520,527,11,1,512,0,10,5,513,14,1,0,11]

theorem envBound48411 : H12AffineFastState.Bounded env48411 := by
  intro p hp
  have h : env48411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48410_48411 : H12AffineEnvironment.transform 4 1 env48410 = env48411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env48410 == env48411) = true)

theorem identity48411 : scanCanonicalize (H12AffineFastState.compose env48411 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound48411 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48412 : List Nat := [2,4,4,1,1,1,4,2,512,2,6,518,5,1,7,517,512,512,516,6,518,512,512,516,515,7,1,512,0,6,5,513,2,1,0,7]

theorem envBound48412 : H12AffineFastState.Bounded env48412 := by
  intro p hp
  have h : env48412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48411_48412 : H12AffineEnvironment.transform 2 4 env48411 = env48412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env48411 == env48412) = true)

theorem identity48412 : scanCanonicalize (H12AffineFastState.compose env48412 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 7) := by decide +kernel

theorem selectedBound48412 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env48413 : List Nat := [2,4,4,1,1,1,4,2,7,2,6,1,5,1,7,2,7,7,3,6,1,7,7,3,4,7,1,7,0,6,5,6,2,1,0,7]

theorem envBound48413 : H12AffineFastState.Bounded env48413 := by
  intro p hp
  have h : env48413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48412_48413 : H12AffineEnvironment.transform 8 7 env48412 = env48413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 7 env48412 == env48413) = true)

theorem identity48413 : scanCanonicalize (H12AffineFastState.compose env48413 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound48413 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48414 : List Nat := [2,3,3,1,1,1,3,2,0,2,1,1,2,1,0,2,0,0,3,1,1,0,0,3,3,0,1,0,0,1,2,1,2,1,0,0]

theorem envBound48414 : H12AffineFastState.Bounded env48414 := by
  intro p hp
  have h : env48414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48413_48414 : H12AffineEnvironment.transform 1 3 env48413 = env48414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env48413 == env48414) = true)

def env48415 : List Nat := [2,4,8,16,32,1,4,256,512,273,2048,772,25,1,260,65536,65831,65541,516,261,772,524,65831,65537,768,66082,302,65846,0,68358,21,65830,256,17,17,276]

theorem envBound48415 : H12AffineFastState.Bounded env48415 := by
  intro p hp
  have h : env48415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48405_48415 : H12AffineEnvironment.transform 12 25 env48405 = env48415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env48405 == env48415) = true)

theorem identity48415 : scanCanonicalize (H12AffineFastState.compose env48415 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 50) := by decide +kernel

theorem selectedBound48415 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env48416 : List Nat := [2,4,8,16,32,1,4,256,512,273,2048,772,25,1,260,50,277,55,516,261,772,524,277,51,768,528,302,260,0,2868,21,276,256,17,17,276]

theorem envBound48416 : H12AffineFastState.Bounded env48416 := by
  intro p hp
  have h : env48416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48415_48416 : H12AffineEnvironment.transform 15 50 env48415 = env48416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 50 env48415 == env48416) = true)

theorem identity48416 : scanCanonicalize (H12AffineFastState.compose env48416 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound48416 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env48417 : List Nat := [2,4,8,1,32,1,4,256,512,256,2048,772,8,1,260,35,260,38,516,261,772,524,260,34,768,513,302,260,0,2853,4,261,256,0,0,261]

theorem envBound48417 : H12AffineFastState.Bounded env48417 := by
  intro p hp
  have h : env48417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48416_48417 : H12AffineEnvironment.transform 3 1 env48416 = env48417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env48416 == env48417) = true)

theorem identity48417 : scanCanonicalize (H12AffineFastState.compose env48417 (packedSelected [0,2,3,7,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 265) := by decide +kernel

theorem selectedBound48417 : packedSelected [0,2,3,7,11,12] rootPS < 2^1333 := by decide +kernel

def env48418 : List Nat := [2,4,8,1,32,1,4,256,512,256,265,772,8,1,260,35,260,38,516,261,772,524,260,34,768,513,302,260,0,556,4,261,256,0,0,261]

theorem envBound48418 : H12AffineFastState.Bounded env48418 := by
  intro p hp
  have h : env48418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48417_48418 : H12AffineEnvironment.transform 10 265 env48417 = env48418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 265 env48417 == env48418) = true)

theorem identity48418 : scanCanonicalize (H12AffineFastState.compose env48418 (packedSelected [1,2,10,13] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound48418 : packedSelected [1,2,10,13] rootPS < 2^1333 := by decide +kernel

def env48419 : List Nat := [2,4,8,1,32,1,4,256,32,256,265,292,8,1,260,35,260,38,36,261,292,44,260,34,288,33,302,260,0,12,4,261,256,0,0,261]

theorem envBound48419 : H12AffineFastState.Bounded env48419 := by
  intro p hp
  have h : env48419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48418_48419 : H12AffineEnvironment.transform 8 32 env48418 = env48419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env48418 == env48419) = true)

theorem identity48419 : scanCanonicalize (H12AffineFastState.compose env48419 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound48419 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48420 : List Nat := [2,4,8,1,32,1,4,36,32,36,45,0,8,1,32,35,32,38,36,33,0,44,32,34,4,33,10,32,0,12,4,33,36,0,0,33]

theorem envBound48420 : H12AffineFastState.Bounded env48420 := by
  intro p hp
  have h : env48420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48419_48420 : H12AffineEnvironment.transform 7 36 env48419 = env48420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env48419 == env48420) = true)

theorem identity48420 : scanCanonicalize (H12AffineFastState.compose env48420 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound48420 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48421 : List Nat := [2,0,8,1,32,1,0,32,32,32,41,0,8,1,32,35,32,34,32,33,0,40,32,34,0,33,10,32,0,8,0,33,32,0,0,33]

theorem envBound48421 : H12AffineFastState.Bounded env48421 := by
  intro p hp
  have h : env48421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48420_48421 : H12AffineEnvironment.transform 1 0 env48420 = env48421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env48420 == env48421) = true)

theorem identity48421 : scanCanonicalize (H12AffineFastState.compose env48421 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound48421 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env48422 : List Nat := [2,0,1,1,32,1,0,32,32,32,32,0,1,1,32,35,32,34,32,33,0,33,32,34,0,33,3,32,0,1,0,33,32,0,0,33]

theorem envBound48422 : H12AffineFastState.Bounded env48422 := by
  intro p hp
  have h : env48422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48421_48422 : H12AffineEnvironment.transform 2 1 env48421 = env48422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env48421 == env48422) = true)

theorem identity48422 : scanCanonicalize (H12AffineFastState.compose env48422 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound48422 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48423 : List Nat := [0,0,1,1,32,1,0,32,32,32,32,0,1,1,32,33,32,32,32,33,0,33,32,32,0,33,1,32,0,1,0,33,32,0,0,33]

theorem envBound48423 : H12AffineFastState.Bounded env48423 := by
  intro p hp
  have h : env48423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48422_48423 : H12AffineEnvironment.transform 0 0 env48422 = env48423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env48422 == env48423) = true)

theorem identity48423 : scanCanonicalize (H12AffineFastState.compose env48423 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound48423 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env48424 : List Nat := [0,0,1,1,0,1,0,0,0,0,0,0,1,1,0,1,0,0,0,1,0,1,0,0,0,1,1,0,0,1,0,1,0,0,0,1]

theorem envBound48424 : H12AffineFastState.Bounded env48424 := by
  intro p hp
  have h : env48424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48423_48424 : H12AffineEnvironment.transform 4 0 env48423 = env48424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env48423 == env48424) = true)

def env48425 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,773,8192,1,8540,65536,74111,65665,580,8541,773,649,74046,65600,9181,74298,367,74031,0,76639,8204,74047,256,8200,80,340]

theorem envBound48425 : H12AffineFastState.Bounded env48425 := by
  intro p hp
  have h : env48425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48386_48425 : H12AffineEnvironment.transform 11 773 env48386 = env48425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 773 env48386 == env48425) = true)

def env48426 : List Nat := [2,4,8,16,32,0,128,256,512,273,2048,773,8192,1,8476,65536,74047,65665,516,8477,773,649,74046,65536,9117,74298,303,74031,0,76575,8204,74047,256,8200,16,276]

theorem envBound48426 : H12AffineFastState.Bounded env48426 := by
  intro p hp
  have h : env48426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48425_48426 : H12AffineEnvironment.transform 5 0 env48425 = env48426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env48425 == env48426) = true)

theorem identity48426 : scanCanonicalize (H12AffineFastState.compose env48426 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 435) := by decide +kernel

theorem selectedBound48426 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env48427 : List Nat := [2,4,8,16,32,0,128,256,512,273,2048,773,8192,1,8476,435,8332,306,516,8477,773,649,8333,435,9117,9097,303,8348,0,10924,8204,8332,256,8200,16,276]

theorem envBound48427 : H12AffineFastState.Bounded env48427 := by
  intro p hp
  have h : env48427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48426_48427 : H12AffineEnvironment.transform 15 435 env48426 = env48427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 435 env48426 == env48427) = true)

def env48428 : List Nat := [2,4,8,16,32,0,128,256,512,273,2048,773,24,1,260,435,148,306,516,261,773,649,149,435,901,913,303,132,0,2740,20,148,256,16,16,276]

theorem envBound48428 : H12AffineFastState.Bounded env48428 := by
  intro p hp
  have h : env48428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48427_48428 : H12AffineEnvironment.transform 12 24 env48427 = env48428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env48427 == env48428) = true)

theorem identity48428 : scanCanonicalize (H12AffineFastState.compose env48428 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 148) := by decide +kernel

theorem selectedBound48428 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env48429 : List Nat := [2,4,8,16,32,0,128,256,148,273,2048,401,24,1,260,435,148,306,144,261,401,29,149,435,273,261,303,132,0,2080,20,148,256,16,16,276]

theorem envBound48429 : H12AffineFastState.Bounded env48429 := by
  intro p hp
  have h : env48429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48428_48429 : H12AffineEnvironment.transform 8 148 env48428 = env48429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 148 env48428 == env48429) = true)

theorem identity48429 : scanCanonicalize (H12AffineFastState.compose env48429 (packedSelected [0,1,2,3,7,10,12,17,20] rootPS)) = affineNative (2^(10+1) ^^^ 395) := by decide +kernel

theorem selectedBound48429 : packedSelected [0,1,2,3,7,10,12,17,20] rootPS < 2^1333 := by decide +kernel

def env48430 : List Nat := [2,4,8,16,32,0,128,256,148,273,395,401,24,1,260,435,148,306,144,261,401,29,149,435,273,261,303,132,0,427,20,148,256,16,16,276]

theorem envBound48430 : H12AffineFastState.Bounded env48430 := by
  intro p hp
  have h : env48430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48429_48430 : H12AffineEnvironment.transform 10 395 env48429 = env48430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 395 env48429 == env48430) = true)

theorem identity48430 : scanCanonicalize (H12AffineFastState.compose env48430 (packedSelected [1,2,3,12,15,17] rootPS)) = affineNative (2^(6+1) ^^^ 14) := by decide +kernel

theorem selectedBound48430 : packedSelected [1,2,3,12,15,17] rootPS < 2^1333 := by decide +kernel

def env48431 : List Nat := [2,4,8,16,32,0,14,256,26,273,261,287,24,1,260,317,26,306,30,261,287,29,27,317,273,261,303,10,0,293,20,26,256,16,16,276]

theorem envBound48431 : H12AffineFastState.Bounded env48431 := by
  intro p hp
  have h : env48431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48430_48431 : H12AffineEnvironment.transform 6 14 env48430 = env48431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 14 env48430 == env48431) = true)

theorem identity48431 : scanCanonicalize (H12AffineFastState.compose env48431 (packedSelected [1,3,5,8,10] rootPS)) = affineNative (2^(7+1) ^^^ 35) := by decide +kernel

theorem selectedBound48431 : packedSelected [1,3,5,8,10] rootPS < 2^1333 := by decide +kernel

def env48432 : List Nat := [2,4,8,16,32,0,14,35,26,50,38,60,24,1,39,30,26,17,30,38,60,29,27,30,50,38,12,10,0,6,20,26,35,16,16,55]

theorem envBound48432 : H12AffineFastState.Bounded env48432 := by
  intro p hp
  have h : env48432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48431_48432 : H12AffineEnvironment.transform 7 35 env48431 = env48432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 35 env48431 == env48432) = true)

theorem identity48432 : scanCanonicalize (H12AffineFastState.compose env48432 (packedSelected [0,3,5,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 29) := by decide +kernel

theorem selectedBound48432 : packedSelected [0,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env48433 : List Nat := [2,4,8,16,29,0,14,30,26,15,27,1,24,1,26,30,26,17,30,27,1,29,27,30,15,27,12,10,0,6,20,26,30,16,16,10]

theorem envBound48433 : H12AffineFastState.Bounded env48433 := by
  intro p hp
  have h : env48433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48432_48433 : H12AffineEnvironment.transform 4 29 env48432 = env48433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 29 env48432 == env48433) = true)

theorem identity48433 : scanCanonicalize (H12AffineFastState.compose env48433 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound48433 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env48434 : List Nat := [2,4,8,0,13,0,14,14,10,15,11,1,8,1,10,14,10,1,14,11,1,13,11,14,15,11,12,10,0,6,4,10,14,0,0,10]

theorem envBound48434 : H12AffineFastState.Bounded env48434 := by
  intro p hp
  have h : env48434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48433_48434 : H12AffineEnvironment.transform 3 0 env48433 = env48434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env48433 == env48434) = true)

def env48435 : List Nat := [2,4,8,16,32,0,128,256,512,273,2048,773,25,1,261,435,149,306,516,260,773,649,148,435,900,912,303,133,0,2741,21,149,256,17,16,276]

theorem envBound48435 : H12AffineFastState.Bounded env48435 := by
  intro p hp
  have h : env48435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48427_48435 : H12AffineEnvironment.transform 12 25 env48427 = env48435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env48427 == env48435) = true)

theorem identity48435 : scanCanonicalize (H12AffineFastState.compose env48435 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 128) := by decide +kernel

theorem selectedBound48435 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env48436 : List Nat := [2,4,8,16,32,0,128,128,512,145,2048,645,25,1,133,51,149,178,516,132,645,649,148,51,516,528,175,133,0,2741,21,149,128,17,16,148]

theorem envBound48436 : H12AffineFastState.Bounded env48436 := by
  intro p hp
  have h : env48436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48435_48436 : H12AffineEnvironment.transform 7 128 env48435 = env48436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 128 env48435 == env48436) = true)

theorem identity48436 : scanCanonicalize (H12AffineFastState.compose env48436 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound48436 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env48437 : List Nat := [2,4,8,0,32,0,128,128,512,129,2048,645,9,1,133,35,133,162,516,132,645,649,132,35,516,512,175,133,0,2725,5,133,128,1,0,132]

theorem envBound48437 : H12AffineFastState.Bounded env48437 := by
  intro p hp
  have h : env48437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48436_48437 : H12AffineEnvironment.transform 3 0 env48436 = env48437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env48436 == env48437) = true)

theorem identity48437 : scanCanonicalize (H12AffineFastState.compose env48437 (packedSelected [0,2,3,7,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 648) := by decide +kernel

theorem selectedBound48437 : packedSelected [0,2,3,7,11,12] rootPS < 2^1333 := by decide +kernel

def env48438 : List Nat := [2,4,8,0,32,0,128,128,512,129,648,645,9,1,133,35,133,162,516,132,645,649,132,35,516,512,175,133,0,45,5,133,128,1,0,132]

theorem envBound48438 : H12AffineFastState.Bounded env48438 := by
  intro p hp
  have h : env48438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48437_48438 : H12AffineEnvironment.transform 10 648 env48437 = env48438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 648 env48437 == env48438) = true)

theorem identity48438 : scanCanonicalize (H12AffineFastState.compose env48438 (packedSelected [0,3,7,8,10,11] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound48438 : packedSelected [0,3,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env48439 : List Nat := [2,4,8,0,6,0,128,128,512,129,648,645,9,1,133,5,133,132,516,132,645,649,132,5,516,512,137,133,0,11,5,133,128,1,0,132]

theorem envBound48439 : H12AffineFastState.Bounded env48439 := by
  intro p hp
  have h : env48439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48438_48439 : H12AffineEnvironment.transform 4 6 env48438 = env48439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env48438 == env48439) = true)

theorem identity48439 : scanCanonicalize (H12AffineFastState.compose env48439 (packedSelected [3,5] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound48439 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env48440 : List Nat := [2,4,8,0,6,0,3,3,512,2,523,518,9,1,6,5,6,7,516,7,518,522,7,5,516,512,10,6,0,11,5,6,3,1,0,7]

theorem envBound48440 : H12AffineFastState.Bounded env48440 := by
  intro p hp
  have h : env48440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48439_48440 : H12AffineEnvironment.transform 6 3 env48439 = env48440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env48439 == env48440) = true)

theorem identity48440 : scanCanonicalize (H12AffineFastState.compose env48440 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 6) := by decide +kernel

theorem selectedBound48440 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48441 : List Nat := [2,4,8,0,6,0,3,3,6,2,13,0,9,1,6,5,6,7,2,7,0,12,7,5,2,6,10,6,0,11,5,6,3,1,0,7]

theorem envBound48441 : H12AffineFastState.Bounded env48441 := by
  intro p hp
  have h : env48441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48440_48441 : H12AffineEnvironment.transform 8 6 env48440 = env48441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 6 env48440 == env48441) = true)

theorem identity48441 : scanCanonicalize (H12AffineFastState.compose env48441 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound48441 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48442 : List Nat := [2,4,0,0,6,0,3,3,6,2,5,0,1,1,6,5,6,7,2,7,0,4,7,5,2,6,2,6,0,3,5,6,3,1,0,7]

theorem envBound48442 : H12AffineFastState.Bounded env48442 := by
  intro p hp
  have h : env48442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48441_48442 : H12AffineEnvironment.transform 2 0 env48441 = env48442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env48441 == env48442) = true)

theorem identity48442 : scanCanonicalize (H12AffineFastState.compose env48442 (packedSelected [1,3] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound48442 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env48443 : List Nat := [2,1,0,0,3,0,3,3,3,2,0,0,1,1,3,0,3,2,2,2,0,1,2,0,2,3,2,3,0,3,0,3,3,1,0,2]

theorem envBound48443 : H12AffineFastState.Bounded env48443 := by
  intro p hp
  have h : env48443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48442_48443 : H12AffineEnvironment.transform 1 1 env48442 = env48443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env48442 == env48443) = true)

theorem identity48443 : scanCanonicalize (H12AffineFastState.compose env48443 (packedSelected [7] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound48443 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env48444 : List Nat := [0,1,0,0,1,0,1,1,1,0,0,0,1,1,1,0,1,0,0,0,0,1,0,0,0,1,0,1,0,1,0,1,1,1,0,0]

theorem envBound48444 : H12AffineFastState.Bounded env48444 := by
  intro p hp
  have h : env48444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48443_48444 : H12AffineEnvironment.transform 0 0 env48443 = env48444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env48443 == env48444) = true)

def env48445 : List Nat := [2,4,8,16,32,1,128,256,512,273,2048,773,8192,1,8477,65536,74046,65665,517,8476,773,649,74046,65537,9116,74298,302,74031,0,76574,8204,74047,256,8200,17,277]

theorem envBound48445 : H12AffineFastState.Bounded env48445 := by
  intro p hp
  have h : env48445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48425_48445 : H12AffineEnvironment.transform 5 1 env48425 = env48445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env48425 == env48445) = true)

theorem identity48445 : scanCanonicalize (H12AffineFastState.compose env48445 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 8619) := by decide +kernel

theorem selectedBound48445 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env48446 : List Nat := [2,4,8,16,32,1,128,256,512,273,2048,773,8192,1,8477,8619,149,8490,517,8476,773,649,149,8618,9116,913,302,132,0,2741,8204,148,256,8200,17,277]

theorem envBound48446 : H12AffineFastState.Bounded env48446 := by
  intro p hp
  have h : env48446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48445_48446 : H12AffineEnvironment.transform 15 8619 env48445 = env48446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8619 env48445 == env48446) = true)

def env48447 : List Nat := [2,4,8,16,32,1,128,256,512,273,2048,773,24,1,261,435,149,306,517,260,773,649,149,434,900,913,302,132,0,2741,20,148,256,16,17,277]

theorem envBound48447 : H12AffineFastState.Bounded env48447 := by
  intro p hp
  have h : env48447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48446_48447 : H12AffineEnvironment.transform 12 24 env48446 = env48447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env48446 == env48447) = true)

theorem identity48447 : scanCanonicalize (H12AffineFastState.compose env48447 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 148) := by decide +kernel

theorem selectedBound48447 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env48448 : List Nat := [2,4,8,16,32,1,128,256,148,273,2048,401,24,1,261,435,149,306,145,260,401,29,149,434,272,261,302,132,0,2081,20,148,256,16,17,277]

theorem envBound48448 : H12AffineFastState.Bounded env48448 := by
  intro p hp
  have h : env48448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48447_48448 : H12AffineEnvironment.transform 8 148 env48447 = env48448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 148 env48447 == env48448) = true)

theorem identity48448 : scanCanonicalize (H12AffineFastState.compose env48448 (packedSelected [0,1,2,3,7,10,12,17,20] rootPS)) = affineNative (2^(10+1) ^^^ 271) := by decide +kernel

theorem selectedBound48448 : packedSelected [0,1,2,3,7,10,12,17,20] rootPS < 2^1333 := by decide +kernel

def env48449 : List Nat := [2,4,8,16,32,1,128,256,148,273,271,401,24,1,261,435,149,306,145,260,401,29,149,434,272,261,302,132,0,302,20,148,256,16,17,277]

theorem envBound48449 : H12AffineFastState.Bounded env48449 := by
  intro p hp
  have h : env48449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48448_48449 : H12AffineEnvironment.transform 10 271 env48448 = env48449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 271 env48448 == env48449) = true)

theorem identity48449 : scanCanonicalize (H12AffineFastState.compose env48449 (packedSelected [0,1,2,3,4,5,7,8,9,11,15,16] rootPS)) = affineNative (2^(6+1) ^^^ 50) := by decide +kernel

theorem selectedBound48449 : packedSelected [0,1,2,3,4,5,7,8,9,11,15,16] rootPS < 2^1333 := by decide +kernel

def env48450 : List Nat := [2,4,8,16,32,1,50,256,38,273,271,291,24,1,261,257,39,306,35,260,291,29,39,256,272,261,302,54,0,302,20,38,256,16,17,277]

theorem envBound48450 : H12AffineFastState.Bounded env48450 := by
  intro p hp
  have h : env48450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48449_48450 : H12AffineEnvironment.transform 6 50 env48449 = env48450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 50 env48449 == env48450) = true)

theorem identity48450 : scanCanonicalize (H12AffineFastState.compose env48450 (packedSelected [0,1,2,3,5,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 63) := by decide +kernel

theorem selectedBound48450 : packedSelected [0,1,2,3,5,9,10] rootPS < 2^1333 := by decide +kernel

def env48451 : List Nat := [2,4,8,16,32,1,50,63,38,46,48,28,24,1,58,62,39,13,35,59,28,29,39,63,47,58,17,54,0,17,20,38,63,16,17,42]

theorem envBound48451 : H12AffineFastState.Bounded env48451 := by
  intro p hp
  have h : env48451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48450_48451 : H12AffineEnvironment.transform 7 63 env48450 = env48451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 63 env48450 == env48451) = true)

theorem identity48451 : scanCanonicalize (H12AffineFastState.compose env48451 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound48451 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env48452 : List Nat := [2,4,8,16,16,1,2,15,22,30,0,28,24,1,10,14,23,13,19,11,28,29,23,15,31,10,17,6,0,17,20,22,15,16,17,26]

theorem envBound48452 : H12AffineFastState.Bounded env48452 := by
  intro p hp
  have h : env48452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48451_48452 : H12AffineEnvironment.transform 4 16 env48451 = env48452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env48451 == env48452) = true)

theorem identity48452 : scanCanonicalize (H12AffineFastState.compose env48452 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound48452 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env48453 : List Nat := [2,4,8,1,1,1,2,15,7,15,0,13,9,1,10,14,6,13,2,11,13,12,6,15,14,10,0,6,0,0,5,7,15,1,0,11]

theorem envBound48453 : H12AffineFastState.Bounded env48453 := by
  intro p hp
  have h : env48453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48452_48453 : H12AffineEnvironment.transform 3 1 env48452 = env48453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env48452 == env48453) = true)

def env48454 : List Nat := [2,4,8,16,32,1,128,256,512,273,2048,773,25,1,260,434,149,307,517,261,773,649,149,435,901,913,302,132,0,2741,21,148,256,17,17,277]

theorem envBound48454 : H12AffineFastState.Bounded env48454 := by
  intro p hp
  have h : env48454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48446_48454 : H12AffineEnvironment.transform 12 25 env48446 = env48454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env48446 == env48454) = true)

theorem identity48454 : scanCanonicalize (H12AffineFastState.compose env48454 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 128) := by decide +kernel

theorem selectedBound48454 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env48455 : List Nat := [2,4,8,16,32,1,128,128,512,145,2048,645,25,1,132,50,149,179,517,133,645,649,149,51,517,529,174,132,0,2741,21,148,128,17,17,149]

theorem envBound48455 : H12AffineFastState.Bounded env48455 := by
  intro p hp
  have h : env48455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48454_48455 : H12AffineEnvironment.transform 7 128 env48454 = env48455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 128 env48454 == env48455) = true)

theorem identity48455 : scanCanonicalize (H12AffineFastState.compose env48455 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound48455 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env48456 : List Nat := [2,4,8,1,32,1,128,128,512,128,2048,645,8,1,132,35,132,162,517,133,645,649,132,34,517,512,174,132,0,2724,4,133,128,0,0,132]

theorem envBound48456 : H12AffineFastState.Bounded env48456 := by
  intro p hp
  have h : env48456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48455_48456 : H12AffineEnvironment.transform 3 1 env48455 = env48456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env48455 == env48456) = true)

theorem identity48456 : scanCanonicalize (H12AffineFastState.compose env48456 (packedSelected [0,2,3,7,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 525) := by decide +kernel

theorem selectedBound48456 : packedSelected [0,2,3,7,11,12] rootPS < 2^1333 := by decide +kernel

def env48457 : List Nat := [2,4,8,1,32,1,128,128,512,128,525,645,8,1,132,35,132,162,517,133,645,649,132,34,517,512,174,132,0,169,4,133,128,0,0,132]

theorem envBound48457 : H12AffineFastState.Bounded env48457 := by
  intro p hp
  have h : env48457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48456_48457 : H12AffineEnvironment.transform 10 525 env48456 = env48457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 525 env48456 == env48457) = true)

theorem identity48457 : scanCanonicalize (H12AffineFastState.compose env48457 (packedSelected [1,2,10,13] rootPS)) = affineNative (2^(8+1) ^^^ 165) := by decide +kernel

theorem selectedBound48457 : packedSelected [1,2,10,13] rootPS < 2^1333 := by decide +kernel

def env48458 : List Nat := [2,4,8,1,32,1,128,128,165,128,168,32,8,1,132,35,132,162,160,133,32,44,132,34,160,165,174,132,0,169,4,133,128,0,0,132]

theorem envBound48458 : H12AffineFastState.Bounded env48458 := by
  intro p hp
  have h : env48458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48457_48458 : H12AffineEnvironment.transform 8 165 env48457 = env48458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 165 env48457 == env48458) = true)

theorem identity48458 : scanCanonicalize (H12AffineFastState.compose env48458 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound48458 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48459 : List Nat := [2,4,8,1,1,1,128,128,132,128,137,1,8,1,132,2,132,131,129,133,1,13,132,3,129,132,143,132,0,136,4,133,128,0,0,132]

theorem envBound48459 : H12AffineFastState.Bounded env48459 := by
  intro p hp
  have h : env48459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48458_48459 : H12AffineEnvironment.transform 4 1 env48458 = env48459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env48458 == env48459) = true)

theorem identity48459 : scanCanonicalize (H12AffineFastState.compose env48459 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound48459 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env48460 : List Nat := [2,4,8,1,1,1,4,4,0,4,13,1,8,1,0,2,0,7,5,1,1,13,0,3,5,0,11,0,0,12,4,1,4,0,0,0]

theorem envBound48460 : H12AffineFastState.Bounded env48460 := by
  intro p hp
  have h : env48460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48459_48460 : H12AffineEnvironment.transform 6 4 env48459 = env48460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env48459 == env48460) = true)

theorem identity48460 : scanCanonicalize (H12AffineFastState.compose env48460 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound48460 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48461 : List Nat := [2,4,5,1,1,1,4,4,0,4,0,1,5,1,0,2,0,7,5,1,1,0,0,3,5,0,6,0,0,1,4,1,4,0,0,0]

theorem envBound48461 : H12AffineFastState.Bounded env48461 := by
  intro p hp
  have h : env48461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48460_48461 : H12AffineEnvironment.transform 2 5 env48460 = env48461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env48460 == env48461) = true)

theorem identity48461 : scanCanonicalize (H12AffineFastState.compose env48461 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound48461 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env48462 : List Nat := [2,2,3,1,1,1,2,2,0,2,0,1,3,1,0,2,0,1,3,1,1,0,0,3,3,0,0,0,0,1,2,1,2,0,0,0]

theorem envBound48462 : H12AffineFastState.Bounded env48462 := by
  intro p hp
  have h : env48462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48461_48462 : H12AffineEnvironment.transform 1 2 env48461 = env48462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env48461 == env48462) = true)

def env48463 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74862,262144,4416,8540,4096,5277,74047,66897,13768,78894,328959,74815,1297,81226,8205,74798,256,8201,1345,5953]

theorem envBound48463 : H12AffineFastState.Bounded env48463 := by
  intro p hp
  have h : env48463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48359_48463 : H12AffineEnvironment.transform 13 1297 env48359 = env48463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env48359 == env48463) = true)

def env48464 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74862,65664,4416,8540,4096,5277,74047,66897,13768,78894,1151,74815,1297,81226,8205,74798,256,8201,1345,5953]

theorem envBound48464 : H12AffineFastState.Bounded env48464 := by
  intro p hp
  have h : env48464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48463_48464 : H12AffineEnvironment.transform 17 65664 env48463 = env48464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env48463 == env48464) = true)

theorem identity48464 : scanCanonicalize (H12AffineFastState.compose env48464 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound48464 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env48465 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,24,1297,325,65536,66678,65664,4416,324,4096,5277,65831,66897,5584,70710,1151,66599,1297,73042,21,66614,256,17,1345,5953]

theorem envBound48465 : H12AffineFastState.Bounded env48465 := by
  intro p hp
  have h : env48465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48464_48465 : H12AffineEnvironment.transform 12 24 env48464 = env48465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env48464 == env48465) = true)

def env48466 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,24,1297,325,65536,66678,65664,1024,324,1344,477,65831,66897,144,65910,1151,66599,1297,67602,21,66614,256,17,1345,513]

theorem envBound48466 : H12AffineFastState.Bounded env48466 := by
  intro p hp
  have h : env48466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48465_48466 : H12AffineEnvironment.transform 11 1344 env48465 = env48466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env48465 == env48466) = true)

theorem identity48466 : scanCanonicalize (H12AffineFastState.compose env48466 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound48466 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env48467 : List Nat := [2,4,8,16,32,64,128,21,512,1024,2048,1109,24,1028,80,65536,66678,65664,1024,81,1109,200,65586,66628,144,65635,1151,66599,1028,67602,21,66614,21,17,1108,513]

theorem envBound48467 : H12AffineFastState.Bounded env48467 := by
  intro p hp
  have h : env48467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48466_48467 : H12AffineEnvironment.transform 7 21 env48466 = env48467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env48466 == env48467) = true)

theorem identity48467 : scanCanonicalize (H12AffineFastState.compose env48467 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 1142) := by decide +kernel

theorem selectedBound48467 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env48468 : List Nat := [2,4,8,16,32,64,128,21,512,1024,2048,1109,24,1028,80,1142,0,1270,1024,81,1109,200,1092,50,144,1045,1151,81,1028,3172,21,64,21,17,1108,513]

theorem envBound48468 : H12AffineFastState.Bounded env48468 := by
  intro p hp
  have h : env48468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48467_48468 : H12AffineEnvironment.transform 15 1142 env48467 = env48468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1142 env48467 == env48468) = true)

theorem identity48468 : scanCanonicalize (H12AffineFastState.compose env48468 (packedSelected [3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound48468 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env48469 : List Nat := [2,4,8,0,32,64,128,5,512,1024,2048,1093,8,1028,64,1126,0,1254,1024,65,1093,200,1092,34,128,1029,1135,65,1028,3172,5,64,5,1,1092,513]

theorem envBound48469 : H12AffineFastState.Bounded env48469 := by
  intro p hp
  have h : env48469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48468_48469 : H12AffineEnvironment.transform 3 0 env48468 = env48469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env48468 == env48469) = true)

theorem identity48469 : scanCanonicalize (H12AffineFastState.compose env48469 (packedSelected [2,11,12,13,15,18] rootPS)) = affineNative (2^(9+1) ^^^ 717) := by decide +kernel

theorem selectedBound48469 : packedSelected [2,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env48470 : List Nat := [2,4,8,0,32,64,128,5,512,717,2048,648,8,713,64,683,0,555,717,65,648,200,649,34,128,712,674,65,713,2729,5,64,5,1,649,513]

theorem envBound48470 : H12AffineFastState.Bounded env48470 := by
  intro p hp
  have h : env48470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48469_48470 : H12AffineEnvironment.transform 9 717 env48469 = env48470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 717 env48469 == env48470) = true)

theorem identity48470 : scanCanonicalize (H12AffineFastState.compose env48470 (packedSelected [1,2,3,5,12,13,17] rootPS)) = affineNative (2^(10+1) ^^^ 557) := by decide +kernel

theorem selectedBound48470 : packedSelected [1,2,3,5,12,13,17] rootPS < 2^1333 := by decide +kernel

def env48471 : List Nat := [2,4,8,0,32,64,128,5,512,717,557,648,8,713,64,683,0,555,717,65,648,200,649,34,128,712,674,65,713,132,5,64,5,1,649,513]

theorem envBound48471 : H12AffineFastState.Bounded env48471 := by
  intro p hp
  have h : env48471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48470_48471 : H12AffineEnvironment.transform 10 557 env48470 = env48471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 557 env48470 == env48471) = true)

theorem identity48471 : scanCanonicalize (H12AffineFastState.compose env48471 (packedSelected [1,2,8,11,20] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound48471 : packedSelected [1,2,8,11,20] rootPS < 2^1333 := by decide +kernel

def env48472 : List Nat := [2,4,8,0,32,64,128,5,33,236,12,169,8,232,64,138,0,10,236,65,169,200,168,34,128,233,131,65,232,132,5,64,5,1,168,32]

theorem envBound48472 : H12AffineFastState.Bounded env48472 := by
  intro p hp
  have h : env48472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48471_48472 : H12AffineEnvironment.transform 8 33 env48471 = env48472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env48471 == env48472) = true)

theorem identity48472 : scanCanonicalize (H12AffineFastState.compose env48472 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound48472 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env48473 : List Nat := [2,4,8,0,32,64,41,5,33,69,12,0,8,65,64,35,0,10,69,65,0,97,1,34,41,64,42,65,65,45,5,64,5,1,1,32]

theorem envBound48473 : H12AffineFastState.Bounded env48473 := by
  intro p hp
  have h : env48473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48472_48473 : H12AffineEnvironment.transform 6 41 env48472 = env48473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env48472 == env48473) = true)

theorem identity48473 : scanCanonicalize (H12AffineFastState.compose env48473 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound48473 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env48474 : List Nat := [2,4,8,0,7,64,14,5,6,69,12,0,8,65,64,4,0,10,69,65,0,70,1,5,14,64,13,65,65,10,5,64,5,1,1,7]

theorem envBound48474 : H12AffineFastState.Bounded env48474 := by
  intro p hp
  have h : env48474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48473_48474 : H12AffineEnvironment.transform 4 7 env48473 = env48474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env48473 == env48474) = true)

theorem identity48474 : scanCanonicalize (H12AffineFastState.compose env48474 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 13) := by decide +kernel

theorem selectedBound48474 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env48475 : List Nat := [2,4,8,0,7,13,14,5,6,8,12,0,8,12,13,4,0,10,8,12,0,11,1,5,14,13,13,12,12,10,5,13,5,1,1,7]

theorem envBound48475 : H12AffineFastState.Bounded env48475 := by
  intro p hp
  have h : env48475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48474_48475 : H12AffineEnvironment.transform 5 13 env48474 = env48475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 13 env48474 == env48475) = true)

theorem identity48475 : scanCanonicalize (H12AffineFastState.compose env48475 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound48475 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48476 : List Nat := [2,4,1,0,7,4,7,5,6,1,5,0,1,5,4,4,0,3,1,5,0,2,1,5,7,4,4,5,5,3,5,4,5,1,1,7]

theorem envBound48476 : H12AffineFastState.Bounded env48476 := by
  intro p hp
  have h : env48476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48475_48476 : H12AffineEnvironment.transform 2 1 env48475 = env48476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env48475 == env48476) = true)

theorem identity48476 : scanCanonicalize (H12AffineFastState.compose env48476 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound48476 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48477 : List Nat := [2,3,1,0,0,3,0,2,1,1,2,0,1,2,3,3,0,3,1,2,0,2,1,2,0,3,3,2,2,3,2,3,2,1,1,0]

theorem envBound48477 : H12AffineFastState.Bounded env48477 := by
  intro p hp
  have h : env48477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48476_48477 : H12AffineEnvironment.transform 1 3 env48476 = env48477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env48476 == env48477) = true)

theorem identity48477 : scanCanonicalize (H12AffineFastState.compose env48477 (packedSelected [2] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound48477 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48478 : List Nat := [1,0,1,0,0,0,0,1,1,1,1,0,1,1,0,0,0,0,1,1,0,1,1,1,0,0,0,1,1,0,1,0,1,1,1,0]

theorem envBound48478 : H12AffineFastState.Bounded env48478 := by
  intro p hp
  have h : env48478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48477_48478 : H12AffineEnvironment.transform 0 1 env48477 = env48478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env48477 == env48478) = true)

def env48479 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,24,1297,325,65536,66678,65664,1025,324,1345,476,65831,66897,145,65911,1151,66599,1297,67603,21,66614,256,17,1345,512]

theorem envBound48479 : H12AffineFastState.Bounded env48479 := by
  intro p hp
  have h : env48479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48465_48479 : H12AffineEnvironment.transform 11 1345 env48465 = env48479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env48465 == env48479) = true)

theorem identity48479 : scanCanonicalize (H12AffineFastState.compose env48479 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound48479 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env48480 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,24,1297,325,114,1028,242,1025,324,1345,476,341,1315,145,261,1151,1109,1297,2145,21,1092,256,17,1345,512]

theorem envBound48480 : H12AffineFastState.Bounded env48480 := by
  intro p hp
  have h : env48480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48479_48480 : H12AffineEnvironment.transform 15 114 env48479 = env48480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env48479 == env48480) = true)

theorem identity48480 : scanCanonicalize (H12AffineFastState.compose env48480 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound48480 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env48481 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,24,1297,277,34,1028,162,1025,276,1297,396,261,1315,145,261,1071,1029,1297,2097,21,1044,256,17,1297,512]

theorem envBound48481 : H12AffineFastState.Bounded env48481 := by
  intro p hp
  have h : env48481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48480_48481 : H12AffineEnvironment.transform 5 16 env48480 = env48481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env48480 == env48481) = true)

theorem identity48481 : scanCanonicalize (H12AffineFastState.compose env48481 (packedSelected [2,13,17] rootPS)) = affineNative (2^(10+1) ^^^ 1825) := by decide +kernel

theorem selectedBound48481 : packedSelected [2,13,17] rootPS < 2^1333 := by decide +kernel

def env48482 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1825,1297,24,1297,277,34,1028,162,1025,276,1297,396,261,1315,145,261,1071,1029,1297,1808,21,1044,256,17,1297,512]

theorem envBound48482 : H12AffineFastState.Bounded env48482 := by
  intro p hp
  have h : env48482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48481_48482 : H12AffineEnvironment.transform 10 1825 env48481 = env48482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1825 env48481 == env48482) = true)

theorem identity48482 : scanCanonicalize (H12AffineFastState.compose env48482 (packedSelected [0,5,7,8,11,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 701) := by decide +kernel

theorem selectedBound48482 : packedSelected [0,5,7,8,11,12,15] rootPS < 2^1333 := by decide +kernel

def env48483 : List Nat := [2,4,8,16,32,16,128,256,512,701,412,940,24,940,277,34,697,162,700,276,940,396,261,926,145,261,658,696,940,429,21,681,256,17,940,512]

theorem envBound48483 : H12AffineFastState.Bounded env48483 := by
  intro p hp
  have h : env48483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48482_48483 : H12AffineEnvironment.transform 9 701 env48482 = env48483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 701 env48482 == env48483) = true)

theorem identity48483 : scanCanonicalize (H12AffineFastState.compose env48483 (packedSelected [0,1,2,4,7] rootPS)) = affineNative (2^(8+1) ^^^ 271) := by decide +kernel

theorem selectedBound48483 : packedSelected [0,1,2,4,7] rootPS < 2^1333 := by decide +kernel

def env48484 : List Nat := [2,4,8,16,32,16,128,256,271,434,412,163,24,163,277,34,438,162,435,276,163,396,261,145,145,261,413,439,163,429,21,422,256,17,163,271]

theorem envBound48484 : H12AffineFastState.Bounded env48484 := by
  intro p hp
  have h : env48484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48483_48484 : H12AffineEnvironment.transform 8 271 env48483 = env48484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 271 env48483 == env48484) = true)

theorem identity48484 : scanCanonicalize (H12AffineFastState.compose env48484 (packedSelected [0,1,3,4,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound48484 : packedSelected [0,1,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env48485 : List Nat := [2,4,8,16,32,16,8,256,271,314,276,43,24,43,277,34,318,42,315,276,43,260,261,25,25,261,277,319,43,293,21,302,256,17,43,271]

theorem envBound48485 : H12AffineFastState.Bounded env48485 := by
  intro p hp
  have h : env48485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48484_48485 : H12AffineEnvironment.transform 6 8 env48484 = env48485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env48484 == env48485) = true)

theorem identity48485 : scanCanonicalize (H12AffineFastState.compose env48485 (packedSelected [0,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound48485 : packedSelected [0,2,3] rootPS < 2^1333 := by decide +kernel

def env48486 : List Nat := [2,4,8,16,10,16,8,256,271,272,276,1,24,1,277,8,276,0,273,276,1,260,261,25,25,261,277,277,1,271,21,260,256,17,1,271]

theorem envBound48486 : H12AffineFastState.Bounded env48486 := by
  intro p hp
  have h : env48486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48485_48486 : H12AffineEnvironment.transform 4 10 env48485 = env48486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env48485 == env48486) = true)

theorem identity48486 : scanCanonicalize (H12AffineFastState.compose env48486 (packedSelected [0,5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound48486 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env48487 : List Nat := [2,4,8,11,10,11,8,256,271,267,271,1,3,1,270,8,271,0,266,271,1,260,261,2,2,261,270,270,1,271,14,260,256,10,1,271]

theorem envBound48487 : H12AffineFastState.Bounded env48487 := by
  intro p hp
  have h : env48487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48486_48487 : H12AffineEnvironment.transform 3 11 env48486 = env48487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env48486 == env48487) = true)

def env48488 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74862,65665,4416,8540,4096,5277,74047,66897,13768,78894,1150,74815,1297,81226,8205,74798,256,8201,1345,5953]

theorem envBound48488 : H12AffineFastState.Bounded env48488 := by
  intro p hp
  have h : env48488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48463_48488 : H12AffineEnvironment.transform 17 65665 env48463 = env48488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env48463 == env48488) = true)

theorem identity48488 : scanCanonicalize (H12AffineFastState.compose env48488 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5464) := by decide +kernel

theorem selectedBound48488 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env48489 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5464,1297,5125,65536,69942,65665,4416,5124,4096,5277,70759,66897,144,65910,1150,69991,1297,67602,5461,70006,256,5457,1345,5953]

theorem envBound48489 : H12AffineFastState.Bounded env48489 := by
  intro p hp
  have h : env48489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48488_48489 : H12AffineEnvironment.transform 12 5464 env48488 = env48489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5464 env48488 == env48489) = true)

def env48490 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1556,844,1297,529,65536,67362,65665,1876,528,1556,649,66163,66897,144,65910,1150,67443,1297,67602,833,67426,256,837,1345,341]

theorem envBound48490 : H12AffineFastState.Bounded env48490 := by
  intro p hp
  have h : env48490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48489_48490 : H12AffineEnvironment.transform 11 1556 env48489 = env48490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1556 env48489 == env48490) = true)

def env48491 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,836,844,65,529,65536,66162,65665,516,528,836,649,66163,65537,144,65910,302,66083,65,67602,833,66098,256,837,17,341]

theorem envBound48491 : H12AffineFastState.Bounded env48491 := by
  intro p hp
  have h : env48491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48490_48491 : H12AffineEnvironment.transform 9 336 env48490 = env48491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 336 env48490 == env48491) = true)

theorem identity48491 : scanCanonicalize (H12AffineFastState.compose env48491 (packedSelected [1,8,28] rootPS)) = affineNative (2^(8+1) ^^^ 77) := by decide +kernel

theorem selectedBound48491 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env48492 : List Nat := [2,4,8,16,32,64,128,256,77,336,2048,265,257,65,92,65536,65599,65665,73,93,265,196,65598,65537,144,65910,302,65646,65,67602,268,65663,256,264,17,341]

theorem envBound48492 : H12AffineFastState.Bounded env48492 := by
  intro p hp
  have h : env48492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48491_48492 : H12AffineEnvironment.transform 8 77 env48491 = env48492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 77 env48491 == env48492) = true)

def env48493 : List Nat := [2,4,8,16,32,64,128,88,77,8,2048,81,89,65,92,65536,65599,65665,73,93,81,196,65598,65537,144,65582,118,65646,65,67602,84,65663,88,80,17,13]

theorem envBound48493 : H12AffineFastState.Bounded env48493 := by
  intro p hp
  have h : env48493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48492_48493 : H12AffineEnvironment.transform 7 88 env48492 = env48493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 88 env48492 == env48493) = true)

theorem identity48493 : scanCanonicalize (H12AffineFastState.compose env48493 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound48493 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env48494 : List Nat := [2,4,8,16,32,64,128,88,77,8,2048,81,89,65,92,114,77,243,73,93,81,196,76,115,144,92,118,28,65,2144,84,13,88,80,17,13]

theorem envBound48494 : H12AffineFastState.Bounded env48494 := by
  intro p hp
  have h : env48494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48493_48494 : H12AffineEnvironment.transform 15 114 env48493 = env48494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env48493 == env48494) = true)

theorem identity48494 : scanCanonicalize (H12AffineFastState.compose env48494 (packedSelected [1,2,5,12,17] rootPS)) = affineNative (2^(10+1) ^^^ 200) := by decide +kernel

theorem selectedBound48494 : packedSelected [1,2,5,12,17] rootPS < 2^1333 := by decide +kernel

def env48495 : List Nat := [2,4,8,16,32,64,128,88,77,8,200,81,89,65,92,114,77,243,73,93,81,196,76,115,144,92,118,28,65,168,84,13,88,80,17,13]

theorem envBound48495 : H12AffineFastState.Bounded env48495 := by
  intro p hp
  have h : env48495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48494_48495 : H12AffineEnvironment.transform 10 200 env48494 = env48495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 200 env48494 == env48495) = true)

theorem identity48495 : scanCanonicalize (H12AffineFastState.compose env48495 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound48495 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env48496 : List Nat := [2,4,8,0,32,64,128,72,77,8,200,65,73,65,76,98,77,227,73,77,65,196,76,99,128,76,102,12,65,168,68,13,72,64,1,13]

theorem envBound48496 : H12AffineFastState.Bounded env48496 := by
  intro p hp
  have h : env48496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48495_48496 : H12AffineEnvironment.transform 3 0 env48495 = env48496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env48495 == env48496) = true)

theorem identity48496 : scanCanonicalize (H12AffineFastState.compose env48496 (packedSelected [0,3,5,7,10,11] rootPS)) = affineNative (2^(6+1) ^^^ 73) := by decide +kernel

theorem selectedBound48496 : packedSelected [0,3,5,7,10,11] rootPS < 2^1333 := by decide +kernel

def env48497 : List Nat := [2,4,8,0,32,64,73,72,77,8,1,65,73,65,76,98,77,42,73,77,65,13,76,99,73,76,102,12,65,97,68,13,72,64,1,13]

theorem envBound48497 : H12AffineFastState.Bounded env48497 := by
  intro p hp
  have h : env48497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48496_48497 : H12AffineEnvironment.transform 6 73 env48496 = env48497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 73 env48496 == env48497) = true)

end H12CloudChart2