import H12CloudChart2Data094

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def active23312 : List Nat := [0,1,2,3,9,10]

def tree23312 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood23312 : H12WitnessSearch.Good tree23312 := H12GlobalWitnessIndex.good

theorem leafIdentity23312 : H12AffineFastState.composeSystem env23312 rootObs = leafEnv23312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env23312 rootObs == leafEnv23312) = true)

theorem terminalChecked23312 : H12PackedTerminal.terminalCheckFast leafEnv23312 active23312 tree23312 = true := by decide +kernel

def env23313 : List Nat := [2,4,8,16,1,17,8,256,1,1024,2048,1296,2056,1297,2308,2050,1297,2308,1025,2309,1297,1,16,3,2056,17,2049,1297,1296,2309,1284,1,257,0,1297,1]

theorem envBound23313 : H12AffineFastState.Bounded env23313 := by
  intro p hp
  have h : env23313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23310_23313 : H12AffineEnvironment.transform 4 1 env23310 = env23313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env23310 == env23313) = true)

def env23314 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,1296,2600,1297,2340,2083,1297,2853,1025,2341,1297,544,16,2,2601,17,2049,1297,1296,2852,1284,33,257,544,1297,512]

theorem envBound23314 : H12AffineFastState.Bounded env23314 := by
  intro p hp
  have h : env23314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23308_23314 : H12AffineEnvironment.transform 6 9 env23308 = env23314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env23308 == env23314) = true)

theorem identity23314 : scanCanonicalize (H12AffineFastState.compose env23314 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound23314 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23315 : List Nat := [2,4,8,16,32,17,9,4,512,1024,2048,1044,2600,1045,2080,2083,1045,2593,1025,2081,1045,544,16,2,2601,17,2049,1045,1044,2592,1024,33,5,544,1045,512]

theorem envBound23315 : H12AffineFastState.Bounded env23315 := by
  intro p hp
  have h : env23315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23314_23315 : H12AffineEnvironment.transform 7 4 env23314 = env23315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env23314 == env23315) = true)

def env23316 : List Nat := [2,4,8,16,32,17,9,4,0,1024,2048,1044,2088,1045,2080,2083,1045,2081,1025,2081,1045,32,16,2,2089,17,2049,1045,1044,2080,1024,33,5,32,1045,0]

theorem envBound23316 : H12AffineFastState.Bounded env23316 := by
  intro p hp
  have h : env23316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23315_23316 : H12AffineEnvironment.transform 8 0 env23315 = env23316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env23315 == env23316) = true)

theorem identity23316 : scanCanonicalize (H12AffineFastState.compose env23316 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound23316 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23317 : List Nat := [2,4,8,16,1,17,9,4,0,1024,2048,1044,2057,1045,2049,2050,1045,2048,1025,2048,1045,1,16,2,2056,17,2049,1045,1044,2049,1024,0,5,1,1045,0]

theorem envBound23317 : H12AffineFastState.Bounded env23317 := by
  intro p hp
  have h : env23317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23316_23317 : H12AffineEnvironment.transform 4 1 env23316 = env23317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env23316 == env23317) = true)

def leafEnv23317 : List Nat := [2,4,8,16,1,17,9,4,0,1024,2048,1044,2057,1045,2049,2050,1045,2048,1025,2048,1045,1,16,2,1025,2056,1,17,2049,1045,1044,2049,1024,0,5,1,5,2050,1045,0,0,1045,1]

def active23317 : List Nat := [0,1,2,3,9,10]

def tree23317 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood23317 : H12WitnessSearch.Good tree23317 := H12GlobalWitnessIndex.good

theorem leafIdentity23317 : H12AffineFastState.composeSystem env23317 rootObs = leafEnv23317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env23317 rootObs == leafEnv23317) = true)

theorem terminalChecked23317 : H12PackedTerminal.terminalCheckFast leafEnv23317 active23317 tree23317 = true := by decide +kernel

def env23318 : List Nat := [2,4,8,16,32,17,9,4,1,1024,2048,1044,2089,1045,2080,2083,1045,2080,1025,2081,1045,33,16,2,2088,17,2049,1045,1044,2081,1024,33,5,33,1045,1]

theorem envBound23318 : H12AffineFastState.Bounded env23318 := by
  intro p hp
  have h : env23318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23315_23318 : H12AffineEnvironment.transform 8 1 env23315 = env23318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env23315 == env23318) = true)

def leafEnv23318 : List Nat := [2,4,8,16,32,17,9,4,1,1024,2048,1044,2089,1045,2080,2083,1045,2080,1025,2081,1045,33,16,2,1025,2088,1,17,2049,1045,1044,2081,1024,33,5,33,5,2083,1045,1,0,1045,1]

def active23318 : List Nat := [0,1,2,3,4,9,10]

def tree23318 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood23318 : H12WitnessSearch.Good tree23318 := H12GlobalWitnessIndex.good

theorem leafIdentity23318 : H12AffineFastState.composeSystem env23318 rootObs = leafEnv23318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env23318 rootObs == leafEnv23318) = true)

theorem terminalChecked23318 : H12PackedTerminal.terminalCheckFast leafEnv23318 active23318 tree23318 = true := by decide +kernel

def env23319 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1296,32768,33166,1297,43049,1025,32769,1296,4194304,17,139,8328,16,4237613,1296,1296,4196612,1284,4294967296,257,4299161633,1297,512]

theorem envBound23319 : H12AffineFastState.Bounded env23319 := by
  intro p hp
  have h : env23319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23303_23319 : H12AffineEnvironment.transform 11 1297 env23303 = env23319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env23303 == env23319) = true)

theorem identity23319 : scanCanonicalize (H12AffineFastState.compose env23319 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 4194732) := by decide +kernel

theorem selectedBound23319 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23320 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1296,32768,33166,1297,43049,1025,32769,1296,4194304,17,139,8328,16,4237613,1296,1296,4196612,1284,4194732,257,397,1297,512]

theorem envBound23320 : H12AffineFastState.Bounded env23320 := by
  intro p hp
  have h : env23320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23319_23320 : H12AffineEnvironment.transform 31 4194732 env23319 = env23320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 4194732 env23319 == env23320) = true)

theorem identity23320 : scanCanonicalize (H12AffineFastState.compose env23320 (packedSelected [3] rootPS)) = affineNative (2^(14+1) ^^^ 8232) := by decide +kernel

theorem selectedBound23320 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env23321 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1296,8232,8614,1297,2049,1025,8233,1296,4194304,17,139,8328,16,4196613,1296,1296,4196612,1284,4194732,257,397,1297,512]

theorem envBound23321 : H12AffineFastState.Bounded env23321 := by
  intro p hp
  have h : env23321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23320_23321 : H12AffineEnvironment.transform 14 8232 env23320 = env23321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env23320 == env23321) = true)

theorem identity23321 : scanCanonicalize (H12AffineFastState.compose env23321 (packedSelected [5] rootPS)) = affineNative (2^(12+1) ^^^ 2208) := by decide +kernel

theorem selectedBound23321 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env23322 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,2208,1296,2184,2310,1297,2049,1025,2185,1296,4194304,17,139,2088,16,4196613,1296,1296,4196612,1284,4194732,257,397,1297,512]

theorem envBound23322 : H12AffineFastState.Bounded env23322 := by
  intro p hp
  have h : env23322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23321_23322 : H12AffineEnvironment.transform 12 2208 env23321 = env23322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2208 env23321 == env23322) = true)

theorem identity23322 : scanCanonicalize (H12AffineFastState.compose env23322 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 428) := by decide +kernel

theorem selectedBound23322 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env23323 : List Nat := [2,4,8,16,32,17,128,256,428,1024,2048,1297,2208,1296,2184,2310,1297,2049,1025,2185,1296,4194304,17,139,2088,16,4196613,1296,1296,4196612,1284,4194732,257,397,1297,428]

theorem envBound23323 : H12AffineFastState.Bounded env23323 := by
  intro p hp
  have h : env23323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23322_23323 : H12AffineEnvironment.transform 8 428 env23322 = env23323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 428 env23322 == env23323) = true)

theorem identity23323 : scanCanonicalize (H12AffineFastState.compose env23323 (packedSelected [0,2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound23323 : packedSelected [0,2,6] rootPS < 2^1333 := by decide +kernel

def env23324 : List Nat := [2,4,8,16,1,17,128,256,397,1024,2048,1297,2177,1296,2184,2310,1297,2049,1025,2185,1296,4194304,17,139,2057,16,4196613,1296,1296,4196612,1284,4194701,257,397,1297,397]

theorem envBound23324 : H12AffineFastState.Bounded env23324 := by
  intro p hp
  have h : env23324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23323_23324 : H12AffineEnvironment.transform 4 1 env23323 = env23324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env23323 == env23324) = true)

theorem identity23324 : scanCanonicalize (H12AffineFastState.compose env23324 (packedSelected [0,7] rootPS)) = affineNative (2^(21+1) ^^^ 261) := by decide +kernel

theorem selectedBound23324 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env23325 : List Nat := [2,4,8,16,1,17,128,256,397,1024,2048,1297,2177,1296,2184,2310,1297,2049,1025,2185,1296,261,17,139,2057,16,2048,1296,1296,2049,1284,136,257,397,1297,397]

theorem envBound23325 : H12AffineFastState.Bounded env23325 := by
  intro p hp
  have h : env23325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23324_23325 : H12AffineEnvironment.transform 21 261 env23324 = env23325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 261 env23324 == env23325) = true)

theorem identity23325 : scanCanonicalize (H12AffineFastState.compose env23325 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 141) := by decide +kernel

theorem selectedBound23325 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23326 : List Nat := [2,4,8,16,1,17,128,141,0,1024,2048,1180,2177,1181,2184,2187,1180,2049,1025,2185,1181,136,17,139,2057,16,2048,1181,1181,2049,1161,136,140,0,1180,0]

theorem envBound23326 : H12AffineFastState.Bounded env23326 := by
  intro p hp
  have h : env23326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23325_23326 : H12AffineEnvironment.transform 7 141 env23325 = env23326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 141 env23325 == env23326) = true)

def leafEnv23326 : List Nat := [2,4,8,16,1,17,128,141,0,1024,2048,1180,2177,1181,2184,2187,1180,2049,1025,2185,1181,136,17,139,1160,2057,1,16,2048,1181,1181,2049,1161,136,140,0,5,2050,1180,0,0,1180,1]

def active23326 : List Nat := [0,1,2,3,6,9,10]

def tree23326 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood23326 : H12WitnessSearch.Good tree23326 := H12GlobalWitnessIndex.good

theorem leafIdentity23326 : H12AffineFastState.composeSystem env23326 rootObs = leafEnv23326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env23326 rootObs == leafEnv23326) = true)

theorem terminalChecked23326 : H12PackedTerminal.terminalCheckFast leafEnv23326 active23326 tree23326 = true := by decide +kernel

def env23327 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,21505,32769,4097,4194304,17665,98565,8328,5457,4477268,16384,1344,1073741824,1284,4294967296,257,4299260335,1296,512]

theorem envBound23327 : H12AffineFastState.Bounded env23327 := by
  intro p hp
  have h : env23327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23297_23327 : H12AffineEnvironment.transform 18 21505 env23297 = env23327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21505 env23297 == env23327) = true)

theorem identity23327 : scanCanonicalize (H12AffineFastState.compose env23327 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 4096) := by decide +kernel

theorem selectedBound23327 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env23328 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4096,32768,65536,1344,262144,1025,32769,4097,4194304,5377,98565,8328,5457,4456788,4096,1344,1073741824,1284,4294967296,257,4299260335,1296,512]

theorem envBound23328 : H12AffineFastState.Bounded env23328 := by
  intro p hp
  have h : env23328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23327_23328 : H12AffineEnvironment.transform 13 4096 env23327 = env23328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4096 env23327 == env23328) = true)

def env23329 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,65536,1296,262144,1025,32769,4097,4194304,5377,98565,8328,5377,4456708,4096,1296,1073741824,1284,4294967296,257,4299260335,1296,512]

theorem envBound23329 : H12AffineFastState.Bounded env23329 := by
  intro p hp
  have h : env23329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23328_23329 : H12AffineEnvironment.transform 5 16 env23328 = env23329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env23328 == env23329) = true)

theorem identity23329 : scanCanonicalize (H12AffineFastState.compose env23329 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(29+1) ^^^ 4497709) := by decide +kernel

theorem selectedBound23329 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env23330 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,65536,1296,262144,1025,32769,4097,4194304,5377,98565,8328,5377,4456708,4096,1296,4497709,1284,4294967296,257,4299260335,1296,512]

theorem envBound23330 : H12AffineFastState.Bounded env23330 := by
  intro p hp
  have h : env23330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23329_23330 : H12AffineEnvironment.transform 29 4497709 env23329 = env23330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4497709 env23329 == env23330) = true)

theorem identity23330 : scanCanonicalize (H12AffineFastState.compose env23330 (packedSelected [5,8,10,12,13] rootPS)) = affineNative (2^(15+1) ^^^ 33166) := by decide +kernel

theorem selectedBound23330 : packedSelected [5,8,10,12,13] rootPS < 2^1333 := by decide +kernel

def env23331 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,33166,1296,262144,1025,32769,4097,4194304,5377,139,8328,5377,4456708,4096,1296,4497709,1284,4294967296,257,4299161633,1296,512]

theorem envBound23331 : H12AffineFastState.Bounded env23331 := by
  intro p hp
  have h : env23331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23330_23331 : H12AffineEnvironment.transform 15 33166 env23330 = env23331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33166 env23330 == env23331) = true)

theorem identity23331 : scanCanonicalize (H12AffineFastState.compose env23331 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound23331 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env23332 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,33166,1296,43049,1025,32769,4097,4194304,5377,139,8328,5377,4237613,4096,1296,4196612,1284,4294967296,257,4299161633,1296,512]

theorem envBound23332 : H12AffineFastState.Bounded env23332 := by
  intro p hp
  have h : env23332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23331_23332 : H12AffineEnvironment.transform 17 43049 env23331 = env23332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env23331 == env23332) = true)

def env23333 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1296,32768,33166,1296,43049,1025,32769,1297,4194304,17,139,8328,17,4237613,1296,1296,4196612,1284,4294967296,257,4299161633,1296,512]

theorem envBound23333 : H12AffineFastState.Bounded env23333 := by
  intro p hp
  have h : env23333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23332_23333 : H12AffineEnvironment.transform 11 1296 env23332 = env23333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env23332 == env23333) = true)

theorem identity23333 : scanCanonicalize (H12AffineFastState.compose env23333 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 35077) := by decide +kernel

theorem selectedBound23333 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23334 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1296,32768,33166,1296,43049,1025,32769,1297,4194304,17,139,8328,17,4237613,1296,1296,4196612,1284,35077,257,4229412,1296,512]

theorem envBound23334 : H12AffineFastState.Bounded env23334 := by
  intro p hp
  have h : env23334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23333_23334 : H12AffineEnvironment.transform 31 35077 env23333 = env23334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 35077 env23333 == env23334) = true)

theorem identity23334 : scanCanonicalize (H12AffineFastState.compose env23334 (packedSelected [3] rootPS)) = affineNative (2^(21+1) ^^^ 41260) := by decide +kernel

theorem selectedBound23334 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env23335 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1296,32768,33166,1296,43049,1025,32769,1297,41260,17,139,8328,17,2049,1296,1296,43048,1284,35077,257,10248,1296,512]

theorem envBound23335 : H12AffineFastState.Bounded env23335 := by
  intro p hp
  have h : env23335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23334_23335 : H12AffineEnvironment.transform 21 41260 env23334 = env23335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41260 env23334 == env23335) = true)

theorem identity23335 : scanCanonicalize (H12AffineFastState.compose env23335 (packedSelected [5] rootPS)) = affineNative (2^(12+1) ^^^ 2208) := by decide +kernel

theorem selectedBound23335 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env23336 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,2208,1296,32768,33166,1296,32905,1025,32769,1297,35212,17,139,2088,17,2049,1296,1296,32904,1284,35077,257,168,1296,512]

theorem envBound23336 : H12AffineFastState.Bounded env23336 := by
  intro p hp
  have h : env23336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23335_23336 : H12AffineEnvironment.transform 12 2208 env23335 = env23336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2208 env23335 == env23336) = true)

theorem identity23336 : scanCanonicalize (H12AffineFastState.compose env23336 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound23336 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env23337 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,2208,1296,32768,33166,1296,32905,1025,32769,1297,35212,17,139,2088,17,2049,1296,1296,32904,1284,35077,257,168,1296,137]

theorem envBound23337 : H12AffineFastState.Bounded env23337 := by
  intro p hp
  have h : env23337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23336_23337 : H12AffineEnvironment.transform 8 137 env23336 = env23337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env23336 == env23337) = true)

def env23338 : List Nat := [2,4,8,16,32,16,8,256,1,1024,2048,1296,2088,1296,32768,33030,1296,32769,1025,32769,1297,35076,17,3,2088,17,2049,1296,1296,32768,1284,35077,257,32,1296,1]

theorem envBound23338 : H12AffineFastState.Bounded env23338 := by
  intro p hp
  have h : env23338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23337_23338 : H12AffineEnvironment.transform 6 8 env23337 = env23338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env23337 == env23338) = true)

theorem identity23338 : scanCanonicalize (H12AffineFastState.compose env23338 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound23338 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23339 : List Nat := [2,4,8,16,32,16,8,5,1,1024,2048,1045,2088,1045,32768,32771,1045,32769,1025,32769,1044,34817,17,3,2088,17,2049,1045,1045,32768,1025,34816,4,32,1045,1]

theorem envBound23339 : H12AffineFastState.Bounded env23339 := by
  intro p hp
  have h : env23339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23338_23339 : H12AffineEnvironment.transform 7 5 env23338 = env23339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env23338 == env23339) = true)

def env23340 : List Nat := [2,4,8,16,32,16,8,5,1,1024,2048,1045,2088,1045,2048,2051,1045,2049,1025,2049,1044,1,17,3,2088,17,2049,1045,1045,2048,1025,0,4,32,1045,1]

theorem envBound23340 : H12AffineFastState.Bounded env23340 := by
  intro p hp
  have h : env23340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23339_23340 : H12AffineEnvironment.transform 14 2048 env23339 = env23340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2048 env23339 == env23340) = true)

theorem identity23340 : scanCanonicalize (H12AffineFastState.compose env23340 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound23340 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23341 : List Nat := [2,4,8,16,0,16,8,5,1,1024,2048,1045,2056,1045,2048,2051,1045,2049,1025,2049,1044,1,17,3,2056,17,2049,1045,1045,2048,1025,0,4,0,1045,1]

theorem envBound23341 : H12AffineFastState.Bounded env23341 := by
  intro p hp
  have h : env23341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23340_23341 : H12AffineEnvironment.transform 4 0 env23340 = env23341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env23340 == env23341) = true)

def leafEnv23341 : List Nat := [2,4,8,16,0,16,8,5,1,1024,2048,1045,2056,1045,2048,2051,1045,2049,1025,2049,1044,1,17,3,1024,2056,1,17,2049,1045,1045,2048,1025,0,4,0,5,2050,1045,1,0,1044,1]

def active23341 : List Nat := [0,1,2,3,9,10]

def tree23341 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood23341 : H12WitnessSearch.Good tree23341 := H12GlobalWitnessIndex.good

theorem leafIdentity23341 : H12AffineFastState.composeSystem env23341 rootObs = leafEnv23341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env23341 rootObs == leafEnv23341) = true)

theorem terminalChecked23341 : H12PackedTerminal.terminalCheckFast leafEnv23341 active23341 tree23341 = true := by decide +kernel

def env23342 : List Nat := [2,4,8,16,32,16,8,5,1,1024,2048,1045,2088,1045,2049,2050,1045,2048,1025,2048,1044,0,17,3,2088,17,2049,1045,1045,2049,1025,1,4,32,1045,1]

theorem envBound23342 : H12AffineFastState.Bounded env23342 := by
  intro p hp
  have h : env23342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23339_23342 : H12AffineEnvironment.transform 14 2049 env23339 = env23342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2049 env23339 == env23342) = true)

def leafEnv23342 : List Nat := [2,4,8,16,32,16,8,5,1,1024,2048,1045,2088,1045,2049,2050,1045,2048,1025,2048,1044,0,17,3,1024,2088,1,17,2049,1045,1045,2049,1025,1,4,32,5,2051,1045,1,0,1044,1]

def active23342 : List Nat := [0,1,2,3,4,9,10]

def tree23342 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood23342 : H12WitnessSearch.Good tree23342 := H12GlobalWitnessIndex.good

theorem leafIdentity23342 : H12AffineFastState.composeSystem env23342 rootObs = leafEnv23342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env23342 rootObs == leafEnv23342) = true)

theorem terminalChecked23342 : H12PackedTerminal.terminalCheckFast leafEnv23342 active23342 tree23342 = true := by decide +kernel

def env23343 : List Nat := [2,4,8,16,32,16,9,256,0,1024,2048,1296,2089,1296,32768,33031,1296,32768,1025,32769,1297,35077,17,2,2088,17,2049,1296,1296,32769,1284,35077,257,33,1296,0]

theorem envBound23343 : H12AffineFastState.Bounded env23343 := by
  intro p hp
  have h : env23343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23337_23343 : H12AffineEnvironment.transform 6 9 env23337 = env23343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env23337 == env23343) = true)

theorem identity23343 : scanCanonicalize (H12AffineFastState.compose env23343 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound23343 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23344 : List Nat := [2,4,8,16,0,16,9,256,0,1024,2048,1296,2057,1296,32768,33031,1296,32768,1025,32769,1297,35077,17,2,2056,17,2049,1296,1296,32769,1284,35077,257,1,1296,0]

theorem envBound23344 : H12AffineFastState.Bounded env23344 := by
  intro p hp
  have h : env23344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23343_23344 : H12AffineEnvironment.transform 4 0 env23343 = env23344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env23343 == env23344) = true)

def env23345 : List Nat := [2,4,8,16,0,16,9,256,0,1024,2048,1296,2057,1296,2048,2311,1296,2048,1025,2049,1297,261,17,2,2056,17,2049,1296,1296,2049,1284,261,257,1,1296,0]

theorem envBound23345 : H12AffineFastState.Bounded env23345 := by
  intro p hp
  have h : env23345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23344_23345 : H12AffineEnvironment.transform 14 2048 env23344 = env23345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2048 env23344 == env23345) = true)

def env23346 : List Nat := [2,4,8,16,0,16,9,256,0,1024,2048,1296,2057,1296,2049,2310,1296,2049,1025,2048,1297,260,17,2,2056,17,2049,1296,1296,2048,1284,260,257,1,1296,0]

theorem envBound23346 : H12AffineFastState.Bounded env23346 := by
  intro p hp
  have h : env23346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23344_23346 : H12AffineEnvironment.transform 14 2049 env23344 = env23346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2049 env23344 == env23346) = true)

theorem identity23346 : scanCanonicalize (H12AffineFastState.compose env23346 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound23346 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23347 : List Nat := [2,4,8,16,0,16,9,5,0,1024,2048,1045,2057,1045,2049,2051,1045,2049,1025,2048,1044,1,17,2,2056,17,2049,1045,1045,2048,1025,1,4,1,1045,0]

theorem envBound23347 : H12AffineFastState.Bounded env23347 := by
  intro p hp
  have h : env23347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23346_23347 : H12AffineEnvironment.transform 7 5 env23346 = env23347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env23346 == env23347) = true)

def leafEnv23347 : List Nat := [2,4,8,16,0,16,9,5,0,1024,2048,1045,2057,1045,2049,2051,1045,2049,1025,2048,1044,1,17,2,1024,2056,1,17,2049,1045,1045,2048,1025,1,4,1,5,2051,1045,0,0,1044,1]

def active23347 : List Nat := [0,1,2,3,9,10]

def tree23347 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood23347 : H12WitnessSearch.Good tree23347 := H12GlobalWitnessIndex.good

theorem leafIdentity23347 : H12AffineFastState.composeSystem env23347 rootObs = leafEnv23347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env23347 rootObs == leafEnv23347) = true)

theorem terminalChecked23347 : H12PackedTerminal.terminalCheckFast leafEnv23347 active23347 tree23347 = true := by decide +kernel

def env23348 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1297,32768,33166,1296,43049,1025,32769,1296,4194304,16,139,8328,16,4237613,1297,1296,4196612,1284,4294967296,257,4299161633,1296,512]

theorem envBound23348 : H12AffineFastState.Bounded env23348 := by
  intro p hp
  have h : env23348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23332_23348 : H12AffineEnvironment.transform 11 1297 env23332 = env23348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env23332 == env23348) = true)

theorem identity23348 : scanCanonicalize (H12AffineFastState.compose env23348 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 4235817) := by decide +kernel

theorem selectedBound23348 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23349 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1297,32768,33166,1296,43049,1025,32769,1296,4194304,16,139,8328,16,4237613,1297,1296,4196612,1284,4235817,257,41480,1296,512]

theorem envBound23349 : H12AffineFastState.Bounded env23349 := by
  intro p hp
  have h : env23349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23348_23349 : H12AffineEnvironment.transform 31 4235817 env23348 = env23349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 4235817 env23348 == env23349) = true)

theorem identity23349 : scanCanonicalize (H12AffineFastState.compose env23349 (packedSelected [3] rootPS)) = affineNative (2^(14+1) ^^^ 8232) := by decide +kernel

theorem selectedBound23349 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env23350 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1297,8232,8614,1296,2049,1025,8233,1296,4194304,16,139,8328,16,4196613,1297,1296,4196612,1284,4194817,257,544,1296,512]

theorem envBound23350 : H12AffineFastState.Bounded env23350 := by
  intro p hp
  have h : env23350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23349_23350 : H12AffineEnvironment.transform 14 8232 env23349 = env23350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env23349 == env23350) = true)

theorem identity23350 : scanCanonicalize (H12AffineFastState.compose env23350 (packedSelected [5] rootPS)) = affineNative (2^(12+1) ^^^ 2600) := by decide +kernel

theorem selectedBound23350 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env23351 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,2600,1297,2560,2958,1296,2049,1025,2561,1296,4194304,16,139,2720,16,4196613,1297,1296,4196612,1284,4194817,257,544,1296,512]

theorem envBound23351 : H12AffineFastState.Bounded env23351 := by
  intro p hp
  have h : env23351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23350_23351 : H12AffineEnvironment.transform 12 2600 env23350 = env23351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2600 env23350 == env23351) = true)

theorem identity23351 : scanCanonicalize (H12AffineFastState.compose env23351 (packedSelected [0,7] rootPS)) = affineNative (2^(21+1) ^^^ 261) := by decide +kernel

theorem selectedBound23351 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env23352 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,2600,1297,2560,2958,1296,2049,1025,2561,1296,261,16,139,2720,16,2048,1297,1296,2049,1284,772,257,544,1296,512]

theorem envBound23352 : H12AffineFastState.Bounded env23352 := by
  intro p hp
  have h : env23352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23351_23352 : H12AffineEnvironment.transform 21 261 env23351 = env23352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 261 env23351 == env23352) = true)

theorem identity23352 : scanCanonicalize (H12AffineFastState.compose env23352 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound23352 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env23353 : List Nat := [2,4,8,16,32,16,128,256,292,1024,2048,1297,2316,1297,2340,2218,1296,2049,1025,2341,1296,261,16,139,2436,16,2048,1297,1296,2049,1284,32,257,260,1296,292]

theorem envBound23353 : H12AffineFastState.Bounded env23353 := by
  intro p hp
  have h : env23353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23352_23353 : H12AffineEnvironment.transform 8 292 env23352 = env23353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env23352 == env23353) = true)

theorem identity23353 : scanCanonicalize (H12AffineFastState.compose env23353 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound23353 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23354 : List Nat := [2,4,8,16,32,16,128,4,32,1024,2048,1045,2056,1045,2080,2218,1044,2049,1025,2081,1044,1,16,139,2176,16,2048,1045,1044,2049,1024,32,5,0,1044,32]

theorem envBound23354 : H12AffineFastState.Bounded env23354 := by
  intro p hp
  have h : env23354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23353_23354 : H12AffineEnvironment.transform 7 4 env23353 = env23354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env23353 == env23354) = true)

theorem identity23354 : scanCanonicalize (H12AffineFastState.compose env23354 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound23354 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23355 : List Nat := [2,4,8,16,1,16,128,4,1,1024,2048,1045,2056,1045,2049,2187,1044,2049,1025,2048,1044,1,16,139,2176,16,2048,1045,1044,2049,1024,1,5,0,1044,1]

theorem envBound23355 : H12AffineFastState.Bounded env23355 := by
  intro p hp
  have h : env23355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23354_23355 : H12AffineEnvironment.transform 4 1 env23354 = env23355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env23354 == env23355) = true)

theorem identity23355 : scanCanonicalize (H12AffineFastState.compose env23355 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound23355 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env23356 : List Nat := [2,4,8,16,1,16,8,4,1,1024,2048,1045,2056,1045,2049,2051,1044,2049,1025,2048,1044,1,16,3,2056,16,2048,1045,1044,2049,1024,1,5,0,1044,1]

theorem envBound23356 : H12AffineFastState.Bounded env23356 := by
  intro p hp
  have h : env23356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23355_23356 : H12AffineEnvironment.transform 6 8 env23355 = env23356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env23355 == env23356) = true)

def leafEnv23356 : List Nat := [2,4,8,16,1,16,8,4,1,1024,2048,1045,2056,1045,2049,2051,1044,2049,1025,2048,1044,1,16,3,1025,2056,1,16,2048,1045,1044,2049,1024,1,5,0,5,2050,1044,1,0,1045,1]

def active23356 : List Nat := [0,1,2,3,9,10]

def tree23356 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood23356 : H12WitnessSearch.Good tree23356 := H12GlobalWitnessIndex.good

theorem leafIdentity23356 : H12AffineFastState.composeSystem env23356 rootObs = leafEnv23356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env23356 rootObs == leafEnv23356) = true)

theorem terminalChecked23356 : H12PackedTerminal.terminalCheckFast leafEnv23356 active23356 tree23356 = true := by decide +kernel

def env23357 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,32768,65536,1297,262144,1025,32769,4097,4194304,5377,98565,8328,5376,4456709,4096,1297,1073741824,1284,4294967296,257,4299260335,1296,512]

theorem envBound23357 : H12AffineFastState.Bounded env23357 := by
  intro p hp
  have h : env23357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23328_23357 : H12AffineEnvironment.transform 5 17 env23328 = env23357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23328 == env23357) = true)

theorem identity23357 : scanCanonicalize (H12AffineFastState.compose env23357 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(31+1) ^^^ 1073750145) := by decide +kernel

theorem selectedBound23357 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env23358 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,32768,65536,1297,262144,1025,32769,4097,4194304,5377,98565,8328,5376,4456709,4096,1297,1073741824,1284,1073750145,257,1078042926,1296,512]

theorem envBound23358 : H12AffineFastState.Bounded env23358 := by
  intro p hp
  have h : env23358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23357_23358 : H12AffineEnvironment.transform 31 1073750145 env23357 = env23358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1073750145 env23357 == env23358) = true)

theorem identity23358 : scanCanonicalize (H12AffineFastState.compose env23358 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(29+1) ^^^ 2561) := by decide +kernel

theorem selectedBound23358 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env23359 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,32768,65536,1297,262144,1025,32769,4097,4194304,5377,98565,8328,5376,4456709,4096,1297,2561,1284,10880,257,4303663,1296,512]

theorem envBound23359 : H12AffineFastState.Bounded env23359 := by
  intro p hp
  have h : env23359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23358_23359 : H12AffineEnvironment.transform 29 2561 env23358 = env23359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 2561 env23358 == env23359) = true)

theorem identity23359 : scanCanonicalize (H12AffineFastState.compose env23359 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(21+1) ^^^ 34848) := by decide +kernel

theorem selectedBound23359 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env23360 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,32768,65536,1297,262144,1025,32769,4097,34848,5377,98565,8328,5376,297253,4096,1297,2561,1284,10880,257,74511,1296,512]

theorem envBound23360 : H12AffineFastState.Bounded env23360 := by
  intro p hp
  have h : env23360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23359_23360 : H12AffineEnvironment.transform 21 34848 env23359 = env23360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 34848 env23359 == env23360) = true)

theorem identity23360 : scanCanonicalize (H12AffineFastState.compose env23360 (packedSelected [1,3,5,12,13,24] rootPS)) = affineNative (2^(17+1) ^^^ 66311) := by decide +kernel

theorem selectedBound23360 : packedSelected [1,3,5,12,13,24] rootPS < 2^1333 := by decide +kernel

def env23361 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,32768,65536,1297,66311,1025,32769,4097,34848,5377,98565,8328,5376,100898,4096,1297,2561,1284,10880,257,74511,1296,512]

theorem envBound23361 : H12AffineFastState.Bounded env23361 := by
  intro p hp
  have h : env23361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23360_23361 : H12AffineEnvironment.transform 17 66311 env23360 = env23361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 66311 env23360 == env23361) = true)

theorem identity23361 : scanCanonicalize (H12AffineFastState.compose env23361 (packedSelected [8,12,13,28] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound23361 : packedSelected [8,12,13,28] rootPS < 2^1333 := by decide +kernel

def env23362 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,32768,8203,1297,8972,1025,32769,4097,34848,5377,41230,8328,5376,43561,4096,1297,2561,1284,10880,257,772,1296,512]

theorem envBound23362 : H12AffineFastState.Bounded env23362 := by
  intro p hp
  have h : env23362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23361_23362 : H12AffineEnvironment.transform 15 8203 env23361 = env23362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env23361 == env23362) = true)

theorem identity23362 : scanCanonicalize (H12AffineFastState.compose env23362 (packedSelected [4,9,11] rootPS)) = affineNative (2^(14+1) ^^^ 2853) := by decide +kernel

theorem selectedBound23362 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env23363 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,2853,8203,1297,8972,1025,2852,4097,773,5377,10795,8328,5376,8460,4096,1297,2561,1284,10880,257,772,1296,512]

theorem envBound23363 : H12AffineFastState.Bounded env23363 := by
  intro p hp
  have h : env23363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23362_23363 : H12AffineEnvironment.transform 14 2853 env23362 = env23363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2853 env23362 == env23363) = true)

theorem identity23363 : scanCanonicalize (H12AffineFastState.compose env23363 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 7197) := by decide +kernel

theorem selectedBound23363 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env23364 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,7197,4096,2853,7190,1297,7953,1025,2852,4097,773,5377,5686,7317,5376,7441,4096,1297,2561,1284,5789,257,772,1296,512]

theorem envBound23364 : H12AffineFastState.Bounded env23364 := by
  intro p hp
  have h : env23364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23363_23364 : H12AffineEnvironment.transform 12 7197 env23363 = env23364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7197 env23363 == env23364) = true)

theorem identity23364 : scanCanonicalize (H12AffineFastState.compose env23364 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound23364 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env23365 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,2316,1297,2853,2311,1297,2560,1025,2852,1296,773,16,807,2436,17,2048,1297,1297,2561,1284,908,257,772,1296,512]

theorem envBound23365 : H12AffineFastState.Bounded env23365 := by
  intro p hp
  have h : env23365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23364_23365 : H12AffineEnvironment.transform 11 1297 env23364 = env23365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env23364 == env23365) = true)

theorem identity23365 : scanCanonicalize (H12AffineFastState.compose env23365 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1808) := by decide +kernel

theorem selectedBound23365 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env23366 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1808,1297,1564,1297,1077,1559,1297,1296,1025,1076,1296,773,16,807,1684,17,1808,1297,1297,1297,1284,908,257,772,1296,512]

theorem envBound23366 : H12AffineFastState.Bounded env23366 := by
  intro p hp
  have h : env23366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23365_23366 : H12AffineEnvironment.transform 10 1808 env23365 = env23366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1808 env23365 == env23366) = true)

theorem identity23366 : scanCanonicalize (H12AffineFastState.compose env23366 (packedSelected [0,1,4] rootPS)) = affineNative (2^(9+1) ^^^ 150) := by decide +kernel

theorem selectedBound23366 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env23367 : List Nat := [2,4,8,16,32,17,128,256,512,150,902,391,650,391,163,641,391,390,151,162,390,773,16,807,514,17,902,391,391,391,402,908,257,772,390,512]

theorem envBound23367 : H12AffineFastState.Bounded env23367 := by
  intro p hp
  have h : env23367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23366_23367 : H12AffineEnvironment.transform 9 150 env23366 = env23367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 150 env23366 == env23367) = true)

theorem identity23367 : scanCanonicalize (H12AffineFastState.compose env23367 (packedSelected [5] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound23367 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env23368 : List Nat := [2,4,8,16,32,17,128,172,512,150,554,43,650,43,163,641,43,42,151,162,42,681,16,651,514,17,554,43,43,43,62,544,173,680,42,512]

theorem envBound23368 : H12AffineFastState.Bounded env23368 := by
  intro p hp
  have h : env23368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23367_23368 : H12AffineEnvironment.transform 7 172 env23367 = env23368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env23367 == env23368) = true)

theorem identity23368 : scanCanonicalize (H12AffineFastState.compose env23368 (packedSelected [0,2,6] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound23368 : packedSelected [0,2,6] rootPS < 2^1333 := by decide +kernel

def env23369 : List Nat := [2,4,8,0,32,1,128,172,512,134,554,43,650,43,163,641,43,42,135,162,42,681,0,651,514,1,554,43,43,43,46,544,173,680,42,512]

theorem envBound23369 : H12AffineFastState.Bounded env23369 := by
  intro p hp
  have h : env23369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23368_23369 : H12AffineEnvironment.transform 3 0 env23368 = env23369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env23368 == env23369) = true)

theorem identity23369 : scanCanonicalize (H12AffineFastState.compose env23369 (packedSelected [1,10] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound23369 : packedSelected [1,10] rootPS < 2^1333 := by decide +kernel

def env23370 : List Nat := [2,4,8,0,32,1,128,172,1,134,43,43,139,43,163,128,43,42,135,162,42,168,0,138,3,1,43,43,43,43,46,33,173,169,42,1]

theorem envBound23370 : H12AffineFastState.Bounded env23370 := by
  intro p hp
  have h : env23370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23369_23370 : H12AffineEnvironment.transform 8 1 env23369 = env23370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env23369 == env23370) = true)

theorem identity23370 : scanCanonicalize (H12AffineFastState.compose env23370 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound23370 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23371 : List Nat := [2,4,8,0,10,1,128,134,1,134,1,1,139,1,137,128,1,0,135,136,0,130,0,138,3,1,1,1,1,1,4,11,135,131,0,1]

theorem envBound23371 : H12AffineFastState.Bounded env23371 := by
  intro p hp
  have h : env23371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23370_23371 : H12AffineEnvironment.transform 4 10 env23370 = env23371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env23370 == env23371) = true)

def env23372 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32769,4097,4194304,17664,16777216,8328,541009,21352528,16384,545088,1073741824,16876545,4294967296,257,4315938986,545040,512]

theorem envBound23372 : H12AffineFastState.Bounded env23372 := by
  intro p hp
  have h : env23372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23295_23372 : H12AffineEnvironment.transform 16 1345 env23295 = env23372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env23295 == env23372) = true)

theorem identity23372 : scanCanonicalize (H12AffineFastState.compose env23372 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(23+1) ^^^ 644436) := by decide +kernel

theorem selectedBound23372 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env23373 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32769,4097,4194304,17664,644436,8328,541009,4982020,16384,545088,1073741824,545109,4294967296,257,4299806206,545040,512]

theorem envBound23373 : H12AffineFastState.Bounded env23373 := by
  intro p hp
  have h : env23373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23372_23373 : H12AffineEnvironment.transform 23 644436 env23372 = env23373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 644436 env23372 == env23373) = true)

theorem identity23373 : scanCanonicalize (H12AffineFastState.compose env23373 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(18+1) ^^^ 1025) := by decide +kernel

theorem selectedBound23373 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env23374 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,1025,32769,4097,4194304,17664,119125,8328,17744,4456709,16384,21825,1073741824,21844,4294967296,257,4299280895,21777,512]

theorem envBound23374 : H12AffineFastState.Bounded env23374 := by
  intro p hp
  have h : env23374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23373_23374 : H12AffineEnvironment.transform 18 1025 env23373 = env23374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env23373 == env23374) = true)

def env23375 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,65536,1345,262144,1025,32769,4097,4194304,64,103445,8328,16,4456709,1344,4097,1073741824,4116,4294967296,257,4299265215,4177,512]

theorem envBound23375 : H12AffineFastState.Bounded env23375 := by
  intro p hp
  have h : env23375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23374_23375 : H12AffineEnvironment.transform 13 1344 env23374 = env23375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env23374 == env23375) = true)

theorem identity23375 : scanCanonicalize (H12AffineFastState.compose env23375 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound23375 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env23376 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,1297,32768,65536,1296,262144,1025,32769,4097,4194304,17,103445,8328,16,4456709,1297,4097,1073741824,4116,4294967296,257,4299265215,4096,512]

theorem envBound23376 : H12AffineFastState.Bounded env23376 := by
  intro p hp
  have h : env23376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23375_23376 : H12AffineEnvironment.transform 5 17 env23375 = env23376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23375 == env23376) = true)

def env23377 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,65536,1345,262144,1025,32769,4097,4194304,65,103444,8328,17,4456709,1345,4096,1073741824,4117,4294967296,257,4299265214,4176,512]

theorem envBound23377 : H12AffineFastState.Bounded env23377 := by
  intro p hp
  have h : env23377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23374_23377 : H12AffineEnvironment.transform 13 1345 env23374 = env23377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env23374 == env23377) = true)

theorem identity23377 : scanCanonicalize (H12AffineFastState.compose env23377 (packedSelected [0,7,20] rootPS)) = affineNative (2^(11+1) ^^^ 1345) := by decide +kernel

theorem selectedBound23377 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env23378 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,32768,65536,1345,262144,1025,32769,1344,4194304,65,98645,8328,17,4456709,1345,1345,1073741824,1364,4294967296,257,4299260415,1297,512]

theorem envBound23378 : H12AffineFastState.Bounded env23378 := by
  intro p hp
  have h : env23378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23377_23378 : H12AffineEnvironment.transform 11 1345 env23377 = env23378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env23377 == env23378) = true)

theorem identity23378 : scanCanonicalize (H12AffineFastState.compose env23378 (packedSelected [17,21] rootPS)) = affineNative (2^(15+1) ^^^ 33247) := by decide +kernel

theorem selectedBound23378 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env23379 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,32768,33247,1345,262144,1025,32769,1344,4194304,65,138,8328,17,4456709,1345,1345,1073741824,1364,4294967296,257,4299161632,1297,512]

theorem envBound23379 : H12AffineFastState.Bounded env23379 := by
  intro p hp
  have h : env23379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23378_23379 : H12AffineEnvironment.transform 15 33247 env23378 = env23379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33247 env23378 == env23379) = true)

theorem identity23379 : scanCanonicalize (H12AffineFastState.compose env23379 (packedSelected [1,5,10,13,15,17,24,28,38] rootPS)) = affineNative (2^(31+1) ^^^ 264588) := by decide +kernel

theorem selectedBound23379 : packedSelected [1,5,10,13,15,17,24,28,38] rootPS < 2^1333 := by decide +kernel

def env23380 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,32768,33247,1345,262144,1025,32769,1344,4194304,65,138,8328,17,4456709,1345,1345,1073741824,1364,264588,257,4458924,1297,512]

theorem envBound23380 : H12AffineFastState.Bounded env23380 := by
  intro p hp
  have h : env23380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23379_23380 : H12AffineEnvironment.transform 31 264588 env23379 = env23380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 264588 env23379 == env23380) = true)

theorem identity23380 : scanCanonicalize (H12AffineFastState.compose env23380 (packedSelected [12,13,17,41] rootPS)) = affineNative (2^(17+1) ^^^ 43128) := by decide +kernel

theorem selectedBound23380 : packedSelected [12,13,17,41] rootPS < 2^1333 := by decide +kernel

def env23381 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,32768,33247,1345,43128,1025,32769,1344,4194304,65,138,8328,17,4237693,1345,1345,1073741824,1364,41460,257,4235732,1297,512]

theorem envBound23381 : H12AffineFastState.Bounded env23381 := by
  intro p hp
  have h : env23381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23380_23381 : H12AffineEnvironment.transform 17 43128 env23380 = env23381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43128 env23380 == env23381) = true)

theorem identity23381 : scanCanonicalize (H12AffineFastState.compose env23381 (packedSelected [1,3,5,8,12,13,17] rootPS)) = affineNative (2^(21+1) ^^^ 10248) := by decide +kernel

theorem selectedBound23381 : packedSelected [1,3,5,8,12,13,17] rootPS < 2^1333 := by decide +kernel

def env23382 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,32768,33247,1345,43128,1025,32769,1344,10248,65,138,8328,17,33141,1345,1345,1073741824,1364,41460,257,35292,1297,512]

theorem envBound23382 : H12AffineFastState.Bounded env23382 := by
  intro p hp
  have h : env23382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23381_23382 : H12AffineEnvironment.transform 21 10248 env23381 = env23382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10248 env23381 == env23382) = true)

theorem identity23382 : scanCanonicalize (H12AffineFastState.compose env23382 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 8541) := by decide +kernel

theorem selectedBound23382 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env23383 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,32768,33247,1345,43128,1025,32769,1344,10248,65,138,8328,17,33141,1345,1345,8541,1364,41460,257,35292,1297,512]

theorem envBound23383 : H12AffineFastState.Bounded env23383 := by
  intro p hp
  have h : env23383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23382_23383 : H12AffineEnvironment.transform 29 8541 env23382 = env23383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 8541 env23382 == env23383) = true)

theorem identity23383 : scanCanonicalize (H12AffineFastState.compose env23383 (packedSelected [0,1,3,4,5,7,8,9,12] rootPS)) = affineNative (2^(14+1) ^^^ 2340) := by decide +kernel

theorem selectedBound23383 : packedSelected [0,1,3,4,5,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env23384 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,2340,2299,1345,8540,1025,2341,1344,10248,65,138,8328,17,2129,1345,1345,8541,1364,10448,257,248,1297,512]

theorem envBound23384 : H12AffineFastState.Bounded env23384 := by
  intro p hp
  have h : env23384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23383_23384 : H12AffineEnvironment.transform 14 2340 env23383 = env23384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2340 env23383 == env23384) = true)

theorem identity23384 : scanCanonicalize (H12AffineFastState.compose env23384 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 900) := by decide +kernel

theorem selectedBound23384 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env23385 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,900,1345,2340,2299,1345,728,1025,2341,1344,2956,65,138,780,17,2129,1345,1345,729,1364,2900,257,248,1297,512]

theorem envBound23385 : H12AffineFastState.Bounded env23385 := by
  intro p hp
  have h : env23385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23384_23385 : H12AffineEnvironment.transform 12 900 env23384 = env23385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 900 env23384 == env23385) = true)

theorem identity23385 : scanCanonicalize (H12AffineFastState.compose env23385 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 1345) := by decide +kernel

theorem selectedBound23385 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env23386 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1345,1345,900,1345,1125,1466,1345,728,1025,1124,1344,1741,65,138,780,17,1296,1345,1345,729,1364,1557,257,248,1297,512]

theorem envBound23386 : H12AffineFastState.Bounded env23386 := by
  intro p hp
  have h : env23386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23385_23386 : H12AffineEnvironment.transform 10 1345 env23385 = env23386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1345 env23385 == env23386) = true)

def env23387 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,8914001,134217728,8519745,2769921,1073741824,27513920,4294967296,10637632,4315938986,164610304,512]

theorem envBound23387 : H12AffineFastState.Bounded env23387 := by
  intro p hp
  have h : env23387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22965_23387 : H12AffineEnvironment.transform 28 2769921 env22965 = env23387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 28 2769921 env22965 == env23387) = true)

def env23388 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,4194304,8388608,16777216,8328,8914001,134217728,8519745,676865,1073741824,25412672,4294967296,8536384,4315938986,164610304,512]

theorem envBound23388 : H12AffineFastState.Bounded env23388 := by
  intro p hp
  have h : env23388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23387_23388 : H12AffineEnvironment.transform 20 4096 env23387 = env23388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env23387 == env23388) = true)

theorem identity23388 : scanCanonicalize (H12AffineFastState.compose env23388 (packedSelected [14] rootPS)) = affineNative (2^(18+1) ^^^ 21585) := by decide +kernel

theorem selectedBound23388 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env23389 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,21585,32769,4096,4194304,8388608,16777216,8328,8409088,134217728,8519745,131152,1073741824,25412672,4294967296,8536384,4315938986,164074833,512]

theorem envBound23389 : H12AffineFastState.Bounded env23389 := by
  intro p hp
  have h : env23389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23388_23389 : H12AffineEnvironment.transform 18 21585 env23388 = env23389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21585 env23388 == env23389) = true)

def env23390 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,21585,32769,4096,4194304,147520,16777216,8328,135232,134217728,16385,131152,1073741824,16876544,4294967296,256,4315938986,155571473,512]

theorem envBound23390 : H12AffineFastState.Bounded env23390 := by
  intro p hp
  have h : env23390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23389_23390 : H12AffineEnvironment.transform 22 147520 env23389 = env23390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147520 env23389 == env23390) = true)

def env23391 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,21585,32769,4096,4194304,17664,16777216,8328,5376,134217728,16385,1296,1073741824,16876544,4294967296,256,4315938986,155571473,512]

theorem envBound23391 : H12AffineFastState.Bounded env23391 := by
  intro p hp
  have h : env23391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23390_23391 : H12AffineEnvironment.transform 16 1344 env23390 = env23391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env23390 == env23391) = true)

theorem identity23391 : scanCanonicalize (H12AffineFastState.compose env23391 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(26+1) ^^^ 21352529) := by decide +kernel

theorem selectedBound23391 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env23392 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,21585,32769,4096,4194304,17664,16777216,8328,5376,21352529,16385,1296,1073741824,16876544,4294967296,256,4315938986,1344,512]

theorem envBound23392 : H12AffineFastState.Bounded env23392 := by
  intro p hp
  have h : env23392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23391_23392 : H12AffineEnvironment.transform 26 21352529 env23391 = env23392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 21352529 env23391 == env23392) = true)

theorem identity23392 : scanCanonicalize (H12AffineFastState.compose env23392 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 4177) := by decide +kernel

theorem selectedBound23392 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env23393 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,1344,262144,1024,32769,4096,4194304,5457,16777216,8328,5376,21331968,4176,1296,1073741824,16876544,4294967296,256,4315938986,1344,512]

theorem envBound23393 : H12AffineFastState.Bounded env23393 := by
  intro p hp
  have h : env23393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23392_23393 : H12AffineEnvironment.transform 13 4177 env23392 = env23393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env23392 == env23393) = true)

def env23394 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,65536,1344,262144,1024,32769,1344,4194304,17,16777216,8328,64,21331968,1296,1296,1073741824,16876544,4294967296,256,4315938986,1344,512]

theorem envBound23394 : H12AffineFastState.Bounded env23394 := by
  intro p hp
  have h : env23394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23393_23394 : H12AffineEnvironment.transform 11 1344 env23393 = env23394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env23393 == env23394) = true)

theorem identity23394 : scanCanonicalize (H12AffineFastState.compose env23394 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound23394 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env23395 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1297,32768,65536,1297,262144,1024,32769,1297,4194304,17,16777216,8328,17,21331968,1296,1296,1073741824,16876544,4294967296,256,4315938986,1297,512]

theorem envBound23395 : H12AffineFastState.Bounded env23395 := by
  intro p hp
  have h : env23395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23394_23395 : H12AffineEnvironment.transform 5 17 env23394 = env23395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23394 == env23395) = true)

theorem identity23395 : scanCanonicalize (H12AffineFastState.compose env23395 (packedSelected [13,21] rootPS)) = affineNative (2^(31+1) ^^^ 1073842178) := by decide +kernel

theorem selectedBound23395 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env23396 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1297,32768,65536,1297,262144,1024,32769,1297,4194304,17,16777216,8328,17,21331968,1296,1296,1073741824,16876544,1073842178,256,1094813864,1297,512]

theorem envBound23396 : H12AffineFastState.Bounded env23396 := by
  intro p hp
  have h : env23396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23395_23396 : H12AffineEnvironment.transform 31 1073842178 env23395 = env23396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1073842178 env23395 == env23396) = true)

def env23397 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,128,1297,32768,65536,1297,262144,1024,32769,1297,4194304,17,16777216,8,17,21331968,1296,1296,1073741824,16876544,1073842178,256,1094813864,1297,512]

theorem envBound23397 : H12AffineFastState.Bounded env23397 := by
  intro p hp
  have h : env23397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23396_23397 : H12AffineEnvironment.transform 12 128 env23396 = env23397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 128 env23396 == env23397) = true)

theorem identity23397 : scanCanonicalize (H12AffineFastState.compose env23397 (packedSelected [3,5,24] rootPS)) = affineNative (2^(23+1) ^^^ 640) := by decide +kernel

theorem selectedBound23397 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env23398 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,128,1297,32768,65536,1297,262144,1024,32769,1297,4194304,17,640,8,17,4555392,1296,1296,1073741824,99968,1073842178,256,1078037032,1297,512]

theorem envBound23398 : H12AffineFastState.Bounded env23398 := by
  intro p hp
  have h : env23398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23397_23398 : H12AffineEnvironment.transform 23 640 env23397 = env23398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 640 env23397 == env23398) = true)

def env23399 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,128,1297,32768,65536,1297,262144,1024,32769,1297,4194304,17,640,8,17,4555392,1296,1296,4295296,99968,4194946,256,168,1297,512]

theorem envBound23399 : H12AffineFastState.Bounded env23399 := by
  intro p hp
  have h : env23399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23398_23399 : H12AffineEnvironment.transform 29 4295296 env23398 = env23399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4295296 env23398 == env23399) = true)

theorem identity23399 : scanCanonicalize (H12AffineFastState.compose env23399 (packedSelected [5] rootPS)) = affineNative (2^(21+1) ^^^ 65570) := by decide +kernel

theorem selectedBound23399 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env23400 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,128,1297,32768,65536,1297,262144,1024,32769,1297,65570,17,640,8,17,295586,1296,1296,35490,99968,66208,256,168,1297,512]

theorem envBound23400 : H12AffineFastState.Bounded env23400 := by
  intro p hp
  have h : env23400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23399_23400 : H12AffineEnvironment.transform 21 65570 env23399 = env23400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 65570 env23399 == env23400) = true)

theorem identity23400 : scanCanonicalize (H12AffineFastState.compose env23400 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 68397) := by decide +kernel

theorem selectedBound23400 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env23401 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,128,1297,32768,65536,1297,68397,1024,32769,1297,65570,17,640,8,17,100751,1296,1296,35490,99968,66208,256,168,1297,512]

theorem envBound23401 : H12AffineFastState.Bounded env23401 := by
  intro p hp
  have h : env23401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23400_23401 : H12AffineEnvironment.transform 17 68397 env23400 = env23401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 68397 env23400 == env23401) = true)

theorem identity23401 : scanCanonicalize (H12AffineFastState.compose env23401 (packedSelected [0,1,3,7,8,11,12,15,18] rootPS)) = affineNative (2^(15+1) ^^^ 33668) := by decide +kernel

theorem selectedBound23401 : packedSelected [0,1,3,7,8,11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env23402 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,128,1297,32768,33668,1297,34985,1024,32769,1297,33702,17,640,8,17,2571,1296,1296,35490,1284,33060,256,168,1297,512]

theorem envBound23402 : H12AffineFastState.Bounded env23402 := by
  intro p hp
  have h : env23402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23401_23402 : H12AffineEnvironment.transform 15 33668 env23401 = env23402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33668 env23401 == env23402) = true)

theorem identity23402 : scanCanonicalize (H12AffineFastState.compose env23402 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound23402 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env23403 : List Nat := [2,4,8,16,32,17,128,256,0,1024,2048,1297,128,1297,32768,33156,1297,34985,1024,32769,1297,33190,17,128,8,17,2059,1296,1296,34978,1284,33060,256,168,1297,0]

theorem envBound23403 : H12AffineFastState.Bounded env23403 := by
  intro p hp
  have h : env23403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23402_23403 : H12AffineEnvironment.transform 8 0 env23402 = env23403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env23402 == env23403) = true)

def env23404 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,128,1297,32768,65536,1297,262144,1024,32769,1297,4194304,17,640,8,17,4555392,1296,1296,4295297,99968,4194947,256,169,1297,512]

theorem envBound23404 : H12AffineFastState.Bounded env23404 := by
  intro p hp
  have h : env23404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23398_23404 : H12AffineEnvironment.transform 29 4295297 env23398 = env23404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4295297 env23398 == env23404) = true)

theorem identity23404 : scanCanonicalize (H12AffineFastState.compose env23404 (packedSelected [5] rootPS)) = affineNative (2^(21+1) ^^^ 66866) := by decide +kernel

theorem selectedBound23404 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env23405 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,128,1297,32768,65536,1297,262144,1024,32769,1297,66866,17,640,8,17,296882,1296,1296,36787,99968,67505,256,169,1297,512]

theorem envBound23405 : H12AffineFastState.Bounded env23405 := by
  intro p hp
  have h : env23405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23404_23405 : H12AffineEnvironment.transform 21 66866 env23404 = env23405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 66866 env23404 == env23405) = true)

theorem identity23405 : scanCanonicalize (H12AffineFastState.compose env23405 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 33950) := by decide +kernel

theorem selectedBound23405 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env23406 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,128,1297,32768,33950,1297,262144,1024,32769,1297,33196,17,640,8,17,296882,1296,1296,36787,542,33583,256,169,1297,512]

theorem envBound23406 : H12AffineFastState.Bounded env23406 := by
  intro p hp
  have h : env23406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23405_23406 : H12AffineEnvironment.transform 15 33950 env23405 = env23406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33950 env23405 == env23406) = true)

theorem identity23406 : scanCanonicalize (H12AffineFastState.compose env23406 (packedSelected [1,3,8] rootPS)) = affineNative (2^(9+1) ^^^ 794) := by decide +kernel

theorem selectedBound23406 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env23407 : List Nat := [2,4,8,16,32,17,128,256,512,794,2048,523,128,523,32768,33668,523,262144,794,32769,523,33196,17,640,8,17,295080,522,522,34985,542,33583,256,169,523,512]

theorem envBound23407 : H12AffineFastState.Bounded env23407 := by
  intro p hp
  have h : env23407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23406_23407 : H12AffineEnvironment.transform 9 794 env23406 = env23407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 794 env23406 == env23407) = true)

theorem identity23407 : scanCanonicalize (H12AffineFastState.compose env23407 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound23407 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env23408 : List Nat := [2,4,8,16,32,17,128,256,1,283,2048,10,128,10,32768,33157,10,262144,283,32769,10,33196,17,129,8,17,295080,11,11,34985,31,33070,256,169,10,1]

theorem envBound23408 : H12AffineFastState.Bounded env23408 := by
  intro p hp
  have h : env23408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23407_23408 : H12AffineEnvironment.transform 8 1 env23407 = env23408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env23407 == env23408) = true)

theorem identity23408 : scanCanonicalize (H12AffineFastState.compose env23408 (packedSelected [1,10] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound23408 : packedSelected [1,10] rootPS < 2^1333 := by decide +kernel

def env23409 : List Nat := [2,4,2,16,32,17,128,256,1,273,2048,0,128,0,32768,33157,0,262144,273,32769,0,33190,17,129,2,17,295074,1,1,34979,21,33060,256,163,0,1]

theorem envBound23409 : H12AffineFastState.Bounded env23409 := by
  intro p hp
  have h : env23409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23408_23409 : H12AffineEnvironment.transform 2 2 env23408 = env23409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env23408 == env23409) = true)

theorem identity23409 : scanCanonicalize (H12AffineFastState.compose env23409 (packedSelected [1] rootPS)) = affineNative (2^(14+1) ^^^ 163) := by decide +kernel

theorem selectedBound23409 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23410 : List Nat := [2,4,2,16,32,17,128,256,1,273,2048,0,128,0,163,294,0,262144,273,162,0,261,17,129,2,17,262145,1,1,2048,21,391,256,163,0,1]

theorem envBound23410 : H12AffineFastState.Bounded env23410 := by
  intro p hp
  have h : env23410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23409_23410 : H12AffineEnvironment.transform 14 163 env23409 = env23410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 163 env23409 == env23410) = true)

theorem identity23410 : scanCanonicalize (H12AffineFastState.compose env23410 (packedSelected [0,2] rootPS)) = affineNative (2^(10+1) ^^^ 131) := by decide +kernel

theorem selectedBound23410 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env23411 : List Nat := [2,4,2,16,32,17,128,256,1,273,131,0,128,0,163,294,0,262144,273,162,0,261,17,129,2,17,262145,1,1,131,21,391,256,163,0,1]

theorem envBound23411 : H12AffineFastState.Bounded env23411 := by
  intro p hp
  have h : env23411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23410_23411 : H12AffineEnvironment.transform 10 131 env23410 = env23411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 131 env23410 == env23411) = true)

theorem identity23411 : scanCanonicalize (H12AffineFastState.compose env23411 (packedSelected [0,6] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound23411 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env23412 : List Nat := [2,4,2,16,32,17,3,256,1,273,0,0,3,0,32,294,0,262144,273,33,0,261,17,2,2,17,262145,1,1,0,21,260,256,32,0,1]

theorem envBound23412 : H12AffineFastState.Bounded env23412 := by
  intro p hp
  have h : env23412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23411_23412 : H12AffineEnvironment.transform 6 3 env23411 = env23412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env23411 == env23412) = true)

theorem identity23412 : scanCanonicalize (H12AffineFastState.compose env23412 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound23412 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23413 : List Nat := [2,4,2,16,32,17,3,20,1,5,0,0,3,0,32,50,0,262144,5,33,0,17,17,2,2,17,262145,1,1,0,21,16,20,32,0,1]

theorem envBound23413 : H12AffineFastState.Bounded env23413 := by
  intro p hp
  have h : env23413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23412_23413 : H12AffineEnvironment.transform 7 20 env23412 = env23413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env23412 == env23413) = true)

theorem identity23413 : scanCanonicalize (H12AffineFastState.compose env23413 (packedSelected [4] rootPS)) = affineNative (2^(17+1) ^^^ 0) := by decide +kernel

theorem selectedBound23413 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env23414 : List Nat := [2,4,2,16,32,17,3,20,1,5,0,0,3,0,32,50,0,0,5,33,0,17,17,2,2,17,1,1,1,0,21,16,20,32,0,1]

theorem envBound23414 : H12AffineFastState.Bounded env23414 := by
  intro p hp
  have h : env23414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23413_23414 : H12AffineEnvironment.transform 17 0 env23413 = env23414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 0 env23413 == env23414) = true)

def env23415 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,129,1297,32768,65536,1297,262144,1024,32769,1297,4194304,17,16777216,9,17,21331968,1296,1296,1073741824,16876544,1073842178,256,1094813864,1297,512]

theorem envBound23415 : H12AffineFastState.Bounded env23415 := by
  intro p hp
  have h : env23415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23396_23415 : H12AffineEnvironment.transform 12 129 env23396 = env23415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 129 env23396 == env23415) = true)

theorem identity23415 : scanCanonicalize (H12AffineFastState.compose env23415 (packedSelected [3,5,24] rootPS)) = affineNative (2^(15+1) ^^^ 33669) := by decide +kernel

theorem selectedBound23415 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env23416 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,129,1297,32768,33669,1297,262144,1024,32769,1297,4194304,17,16777216,9,17,21234565,1296,1296,1073741824,16779141,1073744775,256,1094716205,1297,512]

theorem envBound23416 : H12AffineFastState.Bounded env23416 := by
  intro p hp
  have h : env23416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23415_23416 : H12AffineEnvironment.transform 15 33669 env23415 = env23416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33669 env23415 == env23416) = true)

def env23417 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,1,129,1,32768,33669,1,262144,272,32769,1,4194304,17,16777216,9,17,21234565,0,0,1073741824,16777877,1073744775,256,1094716205,1,512]

theorem envBound23417 : H12AffineFastState.Bounded env23417 := by
  intro p hp
  have h : env23417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23416_23417 : H12AffineEnvironment.transform 9 272 env23416 = env23417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env23416 == env23417) = true)

theorem identity23417 : scanCanonicalize (H12AffineFastState.compose env23417 (packedSelected [5] rootPS)) = affineNative (2^(21+1) ^^^ 33702) := by decide +kernel

theorem selectedBound23417 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env23418 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,1,129,1,32768,33669,1,262144,272,32769,1,33702,17,16777216,9,17,17072163,0,0,1073741824,16777877,1073744775,256,1090553995,1,512]

theorem envBound23418 : H12AffineFastState.Bounded env23418 := by
  intro p hp
  have h : env23418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23417_23418 : H12AffineEnvironment.transform 21 33702 env23417 = env23418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33702 env23417 == env23418) = true)

def env23419 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,1,129,1,32768,33669,1,262144,272,32769,1,33702,17,640,9,17,295587,0,0,1073741824,21,1073744775,256,1073777163,1,512]

theorem envBound23419 : H12AffineFastState.Bounded env23419 := by
  intro p hp
  have h : env23419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23418_23419 : H12AffineEnvironment.transform 23 640 env23418 = env23419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 640 env23418 == env23419) = true)

theorem identity23419 : scanCanonicalize (H12AffineFastState.compose env23419 (packedSelected [1] rootPS)) = affineNative (2^(17+1) ^^^ 2090) := by decide +kernel

theorem selectedBound23419 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23420 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,1,129,1,32768,33669,1,2090,272,32769,1,33702,17,640,9,17,35465,0,0,1073741824,21,1073744775,256,1073777163,1,512]

theorem envBound23420 : H12AffineFastState.Bounded env23420 := by
  intro p hp
  have h : env23420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23419_23420 : H12AffineEnvironment.transform 17 2090 env23419 = env23420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2090 env23419 == env23420) = true)

theorem identity23420 : scanCanonicalize (H12AffineFastState.compose env23420 (packedSelected [3] rootPS)) = affineNative (2^(29+1) ^^^ 2989) := by decide +kernel

theorem selectedBound23420 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env23421 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,1,129,1,32768,33669,1,2090,272,32769,1,33702,17,640,9,17,35465,0,0,2989,21,42,256,33190,1,512]

theorem envBound23421 : H12AffineFastState.Bounded env23421 := by
  intro p hp
  have h : env23421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23420_23421 : H12AffineEnvironment.transform 29 2989 env23420 = env23421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 2989 env23420 == env23421) = true)

theorem identity23421 : scanCanonicalize (H12AffineFastState.compose env23421 (packedSelected [8] rootPS)) = affineNative (2^(14+1) ^^^ 773) := by decide +kernel

theorem selectedBound23421 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env23422 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,1,129,1,773,128,1,2090,272,772,1,163,17,640,9,17,2444,0,0,2989,21,42,256,675,1,512]

theorem envBound23422 : H12AffineFastState.Bounded env23422 := by
  intro p hp
  have h : env23422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23421_23422 : H12AffineEnvironment.transform 14 773 env23421 = env23422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 773 env23421 == env23422) = true)

theorem identity23422 : scanCanonicalize (H12AffineFastState.compose env23422 (packedSelected [0,2,4,6,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound23422 : packedSelected [0,2,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env23423 : List Nat := [2,4,8,16,32,17,128,256,260,272,2048,1,129,1,1,128,1,2090,272,0,1,163,17,388,9,17,2444,0,0,2217,21,42,256,423,1,260]

theorem envBound23423 : H12AffineFastState.Bounded env23423 := by
  intro p hp
  have h : env23423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23422_23423 : H12AffineEnvironment.transform 8 260 env23422 = env23423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env23422 == env23423) = true)

theorem identity23423 : scanCanonicalize (H12AffineFastState.compose env23423 (packedSelected [12] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound23423 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env23424 : List Nat := [2,4,8,16,32,17,128,15,11,31,2048,1,129,1,1,128,1,2090,31,0,1,163,17,139,9,17,2179,0,0,2217,21,42,15,168,1,11]

theorem envBound23424 : H12AffineFastState.Bounded env23424 := by
  intro p hp
  have h : env23424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23423_23424 : H12AffineEnvironment.transform 7 15 env23423 = env23424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env23423 == env23424) = true)

theorem identity23424 : scanCanonicalize (H12AffineFastState.compose env23424 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound23424 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env23425 : List Nat := [2,4,8,16,32,17,2,15,11,31,2048,1,3,1,1,2,1,2090,31,0,1,33,17,9,9,17,2049,0,0,2091,21,42,15,42,1,11]

theorem envBound23425 : H12AffineFastState.Bounded env23425 := by
  intro p hp
  have h : env23425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23424_23425 : H12AffineEnvironment.transform 6 2 env23424 = env23425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env23424 == env23425) = true)

theorem identity23425 : scanCanonicalize (H12AffineFastState.compose env23425 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound23425 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23426 : List Nat := [2,4,8,10,32,11,2,15,11,5,2048,1,3,1,1,2,1,2090,5,0,1,33,11,9,9,11,2049,0,0,2091,15,42,15,42,1,11]

theorem envBound23426 : H12AffineFastState.Bounded env23426 := by
  intro p hp
  have h : env23426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23425_23426 : H12AffineEnvironment.transform 3 10 env23425 = env23426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env23425 == env23426) = true)

def env23427 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,1,129,1,32768,33669,1,262144,272,32769,1,33702,17,641,9,17,295586,0,0,1073741824,20,1073744775,256,1073777162,1,512]

theorem envBound23427 : H12AffineFastState.Bounded env23427 := by
  intro p hp
  have h : env23427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23418_23427 : H12AffineEnvironment.transform 23 641 env23418 = env23427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 641 env23418 == env23427) = true)

theorem identity23427 : scanCanonicalize (H12AffineFastState.compose env23427 (packedSelected [1] rootPS)) = affineNative (2^(29+1) ^^^ 295075) := by decide +kernel

theorem selectedBound23427 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23428 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,1,129,1,32768,33669,1,262144,272,32769,1,33702,17,641,9,17,295586,0,0,295075,20,297764,256,264873,1,512]

theorem envBound23428 : H12AffineFastState.Bounded env23428 := by
  intro p hp
  have h : env23428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23427_23428 : H12AffineEnvironment.transform 29 295075 env23427 = env23428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 295075 env23427 == env23428) = true)

theorem identity23428 : scanCanonicalize (H12AffineFastState.compose env23428 (packedSelected [3] rootPS)) = affineNative (2^(17+1) ^^^ 2049) := by decide +kernel

theorem selectedBound23428 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env23429 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,1,129,1,32768,33669,1,2049,272,32769,1,33702,17,641,9,17,35491,0,0,34978,20,33573,256,680,1,512]

theorem envBound23429 : H12AffineFastState.Bounded env23429 := by
  intro p hp
  have h : env23429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23428_23429 : H12AffineEnvironment.transform 17 2049 env23428 = env23429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2049 env23428 == env23429) = true)

theorem identity23429 : scanCanonicalize (H12AffineFastState.compose env23429 (packedSelected [8] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound23429 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env23430 : List Nat := [2,4,8,16,32,17,128,256,1,272,2048,1,129,1,32768,33156,1,2049,272,32769,1,33191,17,128,9,17,34978,0,0,34978,20,33060,256,169,1,1]

theorem envBound23430 : H12AffineFastState.Bounded env23430 := by
  intro p hp
  have h : env23430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23429_23430 : H12AffineEnvironment.transform 8 1 env23429 = env23430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env23429 == env23430) = true)

theorem identity23430 : scanCanonicalize (H12AffineFastState.compose env23430 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound23430 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env23431 : List Nat := [2,4,8,16,32,17,128,256,1,272,10,1,129,1,32768,33156,1,11,272,32769,1,33191,17,128,9,17,32936,0,0,32936,20,33060,256,169,1,1]

theorem envBound23431 : H12AffineFastState.Bounded env23431 := by
  intro p hp
  have h : env23431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23430_23431 : H12AffineEnvironment.transform 10 10 env23430 = env23431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env23430 == env23431) = true)

theorem identity23431 : scanCanonicalize (H12AffineFastState.compose env23431 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound23431 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env23432 : List Nat := [2,4,8,16,32,17,128,5,1,21,10,1,129,1,32768,32897,1,11,21,32769,1,32930,17,128,9,17,32936,0,0,32936,20,32801,5,169,1,1]

theorem envBound23432 : H12AffineFastState.Bounded env23432 := by
  intro p hp
  have h : env23432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23431_23432 : H12AffineEnvironment.transform 7 5 env23431 = env23432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env23431 == env23432) = true)

def env23433 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,0,129,0,32768,33669,0,262144,273,32769,0,4194304,17,16777216,9,17,21234565,1,1,1073741824,16777876,1073744775,256,1094716205,0,512]

theorem envBound23433 : H12AffineFastState.Bounded env23433 := by
  intro p hp
  have h : env23433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23416_23433 : H12AffineEnvironment.transform 9 273 env23416 = env23433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env23416 == env23433) = true)

theorem identity23433 : scanCanonicalize (H12AffineFastState.compose env23433 (packedSelected [5] rootPS)) = affineNative (2^(29+1) ^^^ 16812067) := by decide +kernel

theorem selectedBound23433 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env23434 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,0,129,0,32768,33669,0,262144,273,32769,0,4194304,17,16777216,9,17,21234565,1,1,16812067,16777876,16810916,256,4227854,0,512]

theorem envBound23434 : H12AffineFastState.Bounded env23434 := by
  intro p hp
  have h : env23434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23433_23434 : H12AffineEnvironment.transform 29 16812067 env23433 = env23434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 16812067 env23433 == env23434) = true)

def env23435 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,0,129,0,32768,33669,0,262144,273,32769,0,4194304,17,640,9,17,4456709,1,1,35491,20,33060,256,4227854,0,512]

theorem envBound23435 : H12AffineFastState.Bounded env23435 := by
  intro p hp
  have h : env23435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23434_23435 : H12AffineEnvironment.transform 23 640 env23434 = env23435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 640 env23434 == env23435) = true)

theorem identity23435 : scanCanonicalize (H12AffineFastState.compose env23435 (packedSelected [1] rootPS)) = affineNative (2^(14+1) ^^^ 648) := by decide +kernel

theorem selectedBound23435 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23436 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,0,129,0,648,269,0,262144,273,649,0,4194304,17,640,9,17,4456709,1,1,2091,20,940,256,4194694,0,512]

theorem envBound23436 : H12AffineFastState.Bounded env23436 := by
  intro p hp
  have h : env23436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23435_23436 : H12AffineEnvironment.transform 14 648 env23435 = env23436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 648 env23435 == env23436) = true)

theorem identity23436 : scanCanonicalize (H12AffineFastState.compose env23436 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 390) := by decide +kernel

theorem selectedBound23436 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env23437 : List Nat := [2,4,8,16,32,17,128,256,390,273,2048,0,129,0,270,269,0,262144,273,271,0,4194304,17,262,9,17,4456709,1,1,2091,20,42,256,4194694,0,390]

theorem envBound23437 : H12AffineFastState.Bounded env23437 := by
  intro p hp
  have h : env23437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23436_23437 : H12AffineEnvironment.transform 8 390 env23436 = env23437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 390 env23436 == env23437) = true)

theorem identity23437 : scanCanonicalize (H12AffineFastState.compose env23437 (packedSelected [8] rootPS)) = affineNative (2^(7+1) ^^^ 141) := by decide +kernel

theorem selectedBound23437 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env23438 : List Nat := [2,4,8,16,32,17,128,141,11,156,2048,0,129,0,131,128,0,262144,156,130,0,4194304,17,139,9,17,4456584,1,1,2091,20,42,141,4194315,0,11]

theorem envBound23438 : H12AffineFastState.Bounded env23438 := by
  intro p hp
  have h : env23438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23437_23438 : H12AffineEnvironment.transform 7 141 env23437 = env23438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 141 env23437 == env23438) = true)

theorem identity23438 : scanCanonicalize (H12AffineFastState.compose env23438 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound23438 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env23439 : List Nat := [2,4,8,16,32,17,128,141,11,156,2048,0,129,0,131,128,0,262144,156,130,0,32,17,139,9,17,262312,1,1,2091,20,42,141,43,0,11]

theorem envBound23439 : H12AffineFastState.Bounded env23439 := by
  intro p hp
  have h : env23439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23438_23439 : H12AffineEnvironment.transform 21 32 env23438 = env23439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env23438 == env23439) = true)

theorem identity23439 : scanCanonicalize (H12AffineFastState.compose env23439 (packedSelected [0,7,11] rootPS)) = affineNative (2^(17+1) ^^^ 2217) := by decide +kernel

theorem selectedBound23439 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env23440 : List Nat := [2,4,8,16,32,17,128,141,11,156,2048,0,129,0,131,128,0,2217,156,130,0,32,17,139,9,17,2049,1,1,2091,20,42,141,43,0,11]

theorem envBound23440 : H12AffineFastState.Bounded env23440 := by
  intro p hp
  have h : env23440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23439_23440 : H12AffineEnvironment.transform 17 2217 env23439 = env23440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2217 env23439 == env23440) = true)

theorem identity23440 : scanCanonicalize (H12AffineFastState.compose env23440 (packedSelected [2,4,7] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound23440 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env23441 : List Nat := [2,4,8,16,32,17,57,52,11,37,2048,0,56,0,58,57,0,2064,37,59,0,32,17,50,9,17,2049,1,1,2091,20,42,52,43,0,11]

theorem envBound23441 : H12AffineFastState.Bounded env23441 := by
  intro p hp
  have h : env23441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23440_23441 : H12AffineEnvironment.transform 6 57 env23440 = env23441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env23440 == env23441) = true)

theorem identity23441 : scanCanonicalize (H12AffineFastState.compose env23441 (packedSelected [0,2,9] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound23441 : packedSelected [0,2,9] rootPS < 2^1333 := by decide +kernel

def env23442 : List Nat := [2,4,8,16,26,17,3,14,11,31,2048,0,2,0,0,3,0,2064,31,1,0,26,17,8,9,17,2049,1,1,2065,20,16,14,17,0,11]

theorem envBound23442 : H12AffineFastState.Bounded env23442 := by
  intro p hp
  have h : env23442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23441_23442 : H12AffineEnvironment.transform 4 26 env23441 = env23442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env23441 == env23442) = true)

def env23443 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,0,129,0,32768,33669,0,262144,273,32769,0,4194304,17,641,9,17,4456708,1,1,35490,21,33061,256,4227854,0,512]

theorem envBound23443 : H12AffineFastState.Bounded env23443 := by
  intro p hp
  have h : env23443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23434_23443 : H12AffineEnvironment.transform 23 641 env23434 = env23443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 641 env23434 == env23443) = true)

theorem identity23443 : scanCanonicalize (H12AffineFastState.compose env23443 (packedSelected [1] rootPS)) = affineNative (2^(21+1) ^^^ 772) := by decide +kernel

theorem selectedBound23443 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23444 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,0,129,0,32768,33669,0,262144,273,32769,0,772,17,641,9,17,262656,1,1,35490,21,33061,256,32778,0,512]

theorem envBound23444 : H12AffineFastState.Bounded env23444 := by
  intro p hp
  have h : env23444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23443_23444 : H12AffineEnvironment.transform 21 772 env23443 = env23444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 772 env23443 == env23444) = true)

theorem identity23444 : scanCanonicalize (H12AffineFastState.compose env23444 (packedSelected [3] rootPS)) = affineNative (2^(14+1) ^^^ 674) := by decide +kernel

theorem selectedBound23444 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env23445 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,0,129,0,674,295,0,262144,273,675,0,772,17,641,9,17,262656,1,1,2048,21,903,256,680,0,512]

theorem envBound23445 : H12AffineFastState.Bounded env23445 := by
  intro p hp
  have h : env23445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23444_23445 : H12AffineEnvironment.transform 14 674 env23444 = env23445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 674 env23444 == env23445) = true)

theorem identity23445 : scanCanonicalize (H12AffineFastState.compose env23445 (packedSelected [8] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound23445 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env23446 : List Nat := [2,4,8,16,32,17,128,256,1,273,2048,0,129,0,163,295,0,262144,273,162,0,261,17,128,9,17,262145,1,1,2048,21,390,256,169,0,1]

theorem envBound23446 : H12AffineFastState.Bounded env23446 := by
  intro p hp
  have h : env23446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23445_23446 : H12AffineEnvironment.transform 8 1 env23445 = env23446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env23445 == env23446) = true)

theorem identity23446 : scanCanonicalize (H12AffineFastState.compose env23446 (packedSelected [0,2] rootPS)) = affineNative (2^(10+1) ^^^ 137) := by decide +kernel

theorem selectedBound23446 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env23447 : List Nat := [2,4,8,16,32,17,128,256,1,273,137,0,129,0,163,295,0,262144,273,162,0,261,17,128,9,17,262145,1,1,137,21,390,256,169,0,1]

theorem envBound23447 : H12AffineFastState.Bounded env23447 := by
  intro p hp
  have h : env23447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23446_23447 : H12AffineEnvironment.transform 10 137 env23446 = env23447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 137 env23446 == env23447) = true)

theorem identity23447 : scanCanonicalize (H12AffineFastState.compose env23447 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound23447 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env23448 : List Nat := [2,4,8,16,32,17,2,256,1,273,11,0,3,0,33,295,0,262144,273,32,0,261,17,2,9,17,262145,1,1,11,21,260,256,43,0,1]

theorem envBound23448 : H12AffineFastState.Bounded env23448 := by
  intro p hp
  have h : env23448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23447_23448 : H12AffineEnvironment.transform 6 2 env23447 = env23448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env23447 == env23448) = true)

theorem identity23448 : scanCanonicalize (H12AffineFastState.compose env23448 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 30) := by decide +kernel

theorem selectedBound23448 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env23449 : List Nat := [2,4,8,16,32,17,2,30,1,15,11,0,3,0,33,57,0,262144,15,32,0,27,17,2,9,17,262145,1,1,11,21,26,30,43,0,1]

theorem envBound23449 : H12AffineFastState.Bounded env23449 := by
  intro p hp
  have h : env23449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23448_23449 : H12AffineEnvironment.transform 7 30 env23448 = env23449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 30 env23448 == env23449) = true)

theorem identity23449 : scanCanonicalize (H12AffineFastState.compose env23449 (packedSelected [4,9] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound23449 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env23450 : List Nat := [2,4,3,16,32,17,2,21,1,4,0,0,3,0,33,50,0,262144,4,32,0,16,17,2,2,17,262145,1,1,0,21,17,21,32,0,1]

theorem envBound23450 : H12AffineFastState.Bounded env23450 := by
  intro p hp
  have h : env23450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23449_23450 : H12AffineEnvironment.transform 2 3 env23449 = env23450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env23449 == env23450) = true)

theorem identity23450 : scanCanonicalize (H12AffineFastState.compose env23450 (packedSelected [4] rootPS)) = affineNative (2^(17+1) ^^^ 0) := by decide +kernel

theorem selectedBound23450 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env23451 : List Nat := [2,4,3,16,32,17,2,21,1,4,0,0,3,0,33,50,0,0,4,32,0,16,17,2,2,17,1,1,1,0,21,17,21,32,0,1]

theorem envBound23451 : H12AffineFastState.Bounded env23451 := by
  intro p hp
  have h : env23451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23450_23451 : H12AffineEnvironment.transform 17 0 env23450 = env23451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 0 env23450 == env23451) = true)

def env23452 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,65536,1344,262144,1024,32769,1345,4194304,16,16777216,8328,65,21331968,1297,1296,1073741824,16876544,4294967296,256,4315938986,1344,512]

theorem envBound23452 : H12AffineFastState.Bounded env23452 := by
  intro p hp
  have h : env23452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23393_23452 : H12AffineEnvironment.transform 11 1345 env23393 = env23452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env23393 == env23452) = true)

theorem identity23452 : scanCanonicalize (H12AffineFastState.compose env23452 (packedSelected [0,7,20] rootPS)) = affineNative (2^(23+1) ^^^ 98645) := by decide +kernel

theorem selectedBound23452 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env23453 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,65536,1344,262144,1024,32769,1345,4194304,16,98645,8328,65,4456789,1297,1296,1073741824,1365,4294967296,256,4299260415,1344,512]

theorem envBound23453 : H12AffineFastState.Bounded env23453 := by
  intro p hp
  have h : env23453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23452_23453 : H12AffineEnvironment.transform 23 98645 env23452 = env23453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98645 env23452 == env23453) = true)

theorem identity23453 : scanCanonicalize (H12AffineFastState.compose env23453 (packedSelected [13,17] rootPS)) = affineNative (2^(31+1) ^^^ 1077979376) := by decide +kernel

theorem selectedBound23453 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env23454 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,65536,1344,262144,1024,32769,1345,4194304,16,98645,8328,65,4456789,1297,1296,1073741824,1365,1077979376,256,1073817871,1344,512]

theorem envBound23454 : H12AffineFastState.Bounded env23454 := by
  intro p hp
  have h : env23454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23453_23454 : H12AffineEnvironment.transform 31 1077979376 env23453 = env23454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1077979376 env23453 == env23454) = true)

theorem identity23454 : scanCanonicalize (H12AffineFastState.compose env23454 (packedSelected [13,21] rootPS)) = affineNative (2^(29+1) ^^^ 43129) := by decide +kernel

theorem selectedBound23454 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env23455 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,65536,1344,262144,1024,32769,1345,4194304,16,98645,8328,65,4456789,1297,1296,43129,1365,4194441,256,98678,1344,512]

theorem envBound23455 : H12AffineFastState.Bounded env23455 := by
  intro p hp
  have h : env23455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23454_23455 : H12AffineEnvironment.transform 29 43129 env23454 = env23455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 43129 env23454 == env23455) = true)

theorem identity23455 : scanCanonicalize (H12AffineFastState.compose env23455 (packedSelected [1,3,15,24,28,38] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound23455 : packedSelected [1,3,15,24,28,38] rootPS < 2^1333 := by decide +kernel

def env23456 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1296,32768,65536,1296,262144,1024,32769,1297,4194304,16,98565,8328,17,4456709,1297,1296,43049,1285,4194441,256,98598,1296,512]

theorem envBound23456 : H12AffineFastState.Bounded env23456 := by
  intro p hp
  have h : env23456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23455_23456 : H12AffineEnvironment.transform 5 16 env23455 = env23456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env23455 == env23456) = true)

theorem identity23456 : scanCanonicalize (H12AffineFastState.compose env23456 (packedSelected [1,3,5] rootPS)) = affineNative (2^(15+1) ^^^ 8840) := by decide +kernel

theorem selectedBound23456 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env23457 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1296,32768,8840,1296,262144,1024,32769,1297,4194304,16,41869,8328,17,4456709,1297,1296,43049,1285,4194441,256,41902,1296,512]

theorem envBound23457 : H12AffineFastState.Bounded env23457 := by
  intro p hp
  have h : env23457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23456_23457 : H12AffineEnvironment.transform 15 8840 env23456 = env23457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8840 env23456 == env23457) = true)

theorem identity23457 : scanCanonicalize (H12AffineFastState.compose env23457 (packedSelected [1,3,8] rootPS)) = affineNative (2^(14+1) ^^^ 9092) := by decide +kernel

theorem selectedBound23457 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env23458 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1296,9092,8840,1296,262144,1024,9093,1297,4194304,16,9,8328,17,4456709,1297,1296,2989,1285,4194441,256,42,1296,512]

theorem envBound23458 : H12AffineFastState.Bounded env23458 := by
  intro p hp
  have h : env23458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23457_23458 : H12AffineEnvironment.transform 14 9092 env23457 = env23458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9092 env23457 == env23458) = true)

theorem identity23458 : scanCanonicalize (H12AffineFastState.compose env23458 (packedSelected [1,12,13] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound23458 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env23459 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1296,9092,8840,1296,262144,1024,9093,1297,33,16,9,8328,17,262436,1297,1296,2989,1285,168,256,42,1296,512]

theorem envBound23459 : H12AffineFastState.Bounded env23459 := by
  intro p hp
  have h : env23459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23458_23459 : H12AffineEnvironment.transform 21 33 env23458 = env23459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env23458 == env23459) = true)

theorem identity23459 : scanCanonicalize (H12AffineFastState.compose env23459 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 2862) := by decide +kernel

theorem selectedBound23459 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env23460 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1296,9092,8840,1296,2862,1024,9093,1297,33,16,9,8328,17,2570,1297,1296,2989,1285,168,256,42,1296,512]

theorem envBound23460 : H12AffineFastState.Bounded env23460 := by
  intro p hp
  have h : env23460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23459_23460 : H12AffineEnvironment.transform 17 2862 env23459 = env23460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2862 env23459 == env23460) = true)

theorem identity23460 : scanCanonicalize (H12AffineFastState.compose env23460 (packedSelected [3] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound23460 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env23461 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,268,1296,648,900,1296,2862,1024,649,1297,33,16,9,388,17,2570,1297,1296,2989,1285,168,256,42,1296,512]

theorem envBound23461 : H12AffineFastState.Bounded env23461 := by
  intro p hp
  have h : env23461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23460_23461 : H12AffineEnvironment.transform 12 268 env23460 = env23461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env23460 == env23461) = true)

theorem identity23461 : scanCanonicalize (H12AffineFastState.compose env23461 (packedSelected [0,2,4,6,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 920) := by decide +kernel

theorem selectedBound23461 : packedSelected [0,2,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env23462 : List Nat := [2,4,8,16,32,16,128,256,512,920,2048,649,268,648,648,900,648,2862,920,649,649,33,16,9,388,17,2570,649,648,2989,669,168,256,42,648,512]

theorem envBound23462 : H12AffineFastState.Bounded env23462 := by
  intro p hp
  have h : env23462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23461_23462 : H12AffineEnvironment.transform 9 920 env23461 = env23462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 920 env23461 == env23462) = true)

theorem identity23462 : scanCanonicalize (H12AffineFastState.compose env23462 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound23462 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23463 : List Nat := [2,4,8,16,32,16,128,256,137,273,2048,0,268,1,1,269,1,2471,273,0,0,33,16,9,388,17,2179,0,1,2340,20,168,256,42,1,137]

theorem envBound23463 : H12AffineFastState.Bounded env23463 := by
  intro p hp
  have h : env23463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23462_23463 : H12AffineEnvironment.transform 8 137 env23462 = env23463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env23462 == env23463) = true)

theorem identity23463 : scanCanonicalize (H12AffineFastState.compose env23463 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound23463 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env23464 : List Nat := [2,4,8,16,32,16,2,256,11,273,2048,0,268,1,1,269,1,2341,273,0,0,33,16,9,262,17,2049,0,1,2340,20,42,256,42,1,11]

theorem envBound23464 : H12AffineFastState.Bounded env23464 := by
  intro p hp
  have h : env23464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23463_23464 : H12AffineEnvironment.transform 6 2 env23463 = env23464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env23463 == env23464) = true)

theorem identity23464 : scanCanonicalize (H12AffineFastState.compose env23464 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound23464 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23465 : List Nat := [2,4,8,16,32,16,2,20,11,5,2048,0,24,1,1,25,1,2097,5,0,0,33,16,9,18,17,2049,0,1,2096,20,42,20,42,1,11]

theorem envBound23465 : H12AffineFastState.Bounded env23465 := by
  intro p hp
  have h : env23465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23464_23465 : H12AffineEnvironment.transform 7 20 env23464 = env23465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env23464 == env23465) = true)

def env23466 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,21585,32769,4096,4194304,17665,16777216,8328,5377,134217728,16385,1297,1073741824,16876544,4294967296,256,4315938986,155571473,512]

theorem envBound23466 : H12AffineFastState.Bounded env23466 := by
  intro p hp
  have h : env23466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23390_23466 : H12AffineEnvironment.transform 16 1345 env23390 = env23466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env23390 == env23466) = true)

def env23467 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,21585,32769,4096,4194304,147521,16777216,8328,135233,134217728,16384,131152,1073741824,16876545,4294967296,257,4315938986,155571472,512]

theorem envBound23467 : H12AffineFastState.Bounded env23467 := by
  intro p hp
  have h : env23467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23389_23467 : H12AffineEnvironment.transform 22 147521 env23389 = env23467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147521 env23389 == env23467) = true)

def env23468 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,21585,32769,4096,4194304,17665,16777216,8328,5377,134217728,16384,1296,1073741824,16876545,4294967296,257,4315938986,155571472,512]

theorem envBound23468 : H12AffineFastState.Bounded env23468 := by
  intro p hp
  have h : env23468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23467_23468 : H12AffineEnvironment.transform 16 1344 env23467 = env23468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env23467 == env23468) = true)

theorem identity23468 : scanCanonicalize (H12AffineFastState.compose env23468 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(26+1) ^^^ 4477269) := by decide +kernel

theorem selectedBound23468 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env23469 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,21585,32769,4096,4194304,17665,16777216,8328,5377,4477269,16384,1296,1073741824,16876545,4294967296,257,4315938986,16876613,512]

theorem envBound23469 : H12AffineFastState.Bounded env23469 := by
  intro p hp
  have h : env23469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23468_23469 : H12AffineEnvironment.transform 26 4477269 env23468 = env23469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 4477269 env23468 == env23469) = true)

theorem identity23469 : scanCanonicalize (H12AffineFastState.compose env23469 (packedSelected [0,4,7,9,16,20] rootPS)) = affineNative (2^(11+1) ^^^ 1344) := by decide +kernel

theorem selectedBound23469 : packedSelected [0,4,7,9,16,20] rootPS < 2^1333 := by decide +kernel

def env23470 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,16384,32768,65536,1344,262144,16657,32769,1344,4194304,17665,16777216,8328,65,4473877,16384,1296,1073741824,16876545,4294967296,257,4315938986,16876613,512]

theorem envBound23470 : H12AffineFastState.Bounded env23470 := by
  intro p hp
  have h : env23470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23469_23470 : H12AffineEnvironment.transform 11 1344 env23469 = env23470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env23469 == env23470) = true)

theorem identity23470 : scanCanonicalize (H12AffineFastState.compose env23470 (packedSelected [4,16,22] rootPS)) = affineNative (2^(13+1) ^^^ 1296) := by decide +kernel

theorem selectedBound23470 : packedSelected [4,16,22] rootPS < 2^1333 := by decide +kernel

def env23471 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,65536,1344,262144,1025,32769,1344,4194304,17,16777216,8328,65,4456709,1296,1296,1073741824,16876545,4294967296,257,4315938986,16876613,512]

theorem envBound23471 : H12AffineFastState.Bounded env23471 := by
  intro p hp
  have h : env23471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23470_23471 : H12AffineEnvironment.transform 13 1296 env23470 = env23471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env23470 == env23471) = true)

theorem identity23471 : scanCanonicalize (H12AffineFastState.compose env23471 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(31+1) ^^^ 4194440) := by decide +kernel

theorem selectedBound23471 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env23472 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,65536,1344,262144,1025,32769,1344,4194304,17,16777216,8328,65,4456709,1296,1296,1073741824,16876545,4194440,257,16777250,16876613,512]

theorem envBound23472 : H12AffineFastState.Bounded env23472 := by
  intro p hp
  have h : env23472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23471_23472 : H12AffineEnvironment.transform 31 4194440 env23471 = env23472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 4194440 env23471 == env23472) = true)

def env23473 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,65536,1344,8832,1025,32769,1344,4194304,17,16777216,8328,65,4203397,1296,1296,1073741824,16876545,4194440,257,16777250,16876613,512]

theorem envBound23473 : H12AffineFastState.Bounded env23473 := by
  intro p hp
  have h : env23473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23472_23473 : H12AffineEnvironment.transform 17 8832 env23472 = env23473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8832 env23472 == env23473) = true)

theorem identity23473 : scanCanonicalize (H12AffineFastState.compose env23473 (packedSelected [3,5,24] rootPS)) = affineNative (2^(23+1) ^^^ 4260488) := by decide +kernel

theorem selectedBound23473 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env23474 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,65536,1344,8832,1025,32769,1344,4194304,17,4260488,8328,65,4203397,1296,1296,1073741824,4228745,4194440,257,4260522,4228813,512]

theorem envBound23474 : H12AffineFastState.Bounded env23474 := by
  intro p hp
  have h : env23474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23473_23474 : H12AffineEnvironment.transform 23 4260488 env23473 = env23474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 4260488 env23473 == env23474) = true)

def env23475 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,65536,1344,8832,1025,32769,1344,33416,17,98304,8328,65,41229,1296,1296,1073741824,1025,33280,257,98338,1093,512]

theorem envBound23475 : H12AffineFastState.Bounded env23475 := by
  intro p hp
  have h : env23475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23474_23475 : H12AffineEnvironment.transform 21 33416 env23474 = env23475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33416 env23474 == env23475) = true)

theorem identity23475 : scanCanonicalize (H12AffineFastState.compose env23475 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 521) := by decide +kernel

theorem selectedBound23475 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env23476 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,521,1296,32768,65536,1344,137,1025,32769,1344,33416,17,98304,641,65,33540,1296,1296,1073741824,1025,33280,257,98338,1093,512]

theorem envBound23476 : H12AffineFastState.Bounded env23476 := by
  intro p hp
  have h : env23476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23475_23476 : H12AffineEnvironment.transform 12 521 env23475 = env23476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 521 env23475 == env23476) = true)

def env23477 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1344,521,1296,32768,65536,1344,1,1025,32769,1344,33280,17,98304,521,65,33540,1296,1296,1073741824,1025,33280,257,98338,1093,512]

theorem envBound23477 : H12AffineFastState.Bounded env23477 := by
  intro p hp
  have h : env23477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23476_23477 : H12AffineEnvironment.transform 6 8 env23476 = env23477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env23476 == env23477) = true)

theorem identity23477 : scanCanonicalize (H12AffineFastState.compose env23477 (packedSelected [6,7] rootPS)) = affineNative (2^(29+1) ^^^ 67911) := by decide +kernel

theorem selectedBound23477 : packedSelected [6,7] rootPS < 2^1333 := by decide +kernel

def env23478 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1344,521,1296,32768,65536,1344,1,1025,32769,1344,33280,17,98304,521,65,33540,1296,1296,67911,1025,33280,257,98338,1093,512]

theorem envBound23478 : H12AffineFastState.Bounded env23478 := by
  intro p hp
  have h : env23478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23477_23478 : H12AffineEnvironment.transform 29 67911 env23477 = env23478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 67911 env23477 == env23478) = true)

def env23479 : List Nat := [2,4,8,16,32,64,8,256,512,320,2048,0,521,80,32768,65536,0,1,321,32769,0,33280,17,98304,521,65,33540,80,80,67911,321,33280,257,98338,261,512]

theorem envBound23479 : H12AffineFastState.Bounded env23479 := by
  intro p hp
  have h : env23479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23478_23479 : H12AffineEnvironment.transform 9 320 env23478 = env23479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env23478 == env23479) = true)

theorem identity23479 : scanCanonicalize (H12AffineFastState.compose env23479 (packedSelected [13] rootPS)) = affineNative (2^(8+1) ^^^ 97) := by decide +kernel

theorem selectedBound23479 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env23480 : List Nat := [2,4,8,16,32,64,8,256,97,320,2048,0,104,80,32768,65536,0,1,321,32769,0,32865,17,98304,104,65,33125,80,80,67911,321,32865,257,98338,261,97]

theorem envBound23480 : H12AffineFastState.Bounded env23480 := by
  intro p hp
  have h : env23480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23479_23480 : H12AffineEnvironment.transform 8 97 env23479 = env23480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 97 env23479 == env23480) = true)

def env23481 : List Nat := [2,4,8,16,32,16,8,256,49,272,2048,0,56,0,32768,65536,0,1,273,32769,0,32817,17,98304,56,17,33077,0,0,67863,273,32817,257,98338,261,49]

theorem envBound23481 : H12AffineFastState.Bounded env23481 := by
  intro p hp
  have h : env23481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23480_23481 : H12AffineEnvironment.transform 5 16 env23480 = env23481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env23480 == env23481) = true)

theorem identity23481 : scanCanonicalize (H12AffineFastState.compose env23481 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 260) := by decide +kernel

theorem selectedBound23481 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env23482 : List Nat := [2,4,8,16,32,16,8,256,49,272,260,0,56,0,32768,65536,0,1,273,32769,0,32817,17,98304,56,17,33077,0,0,65555,273,32817,257,98338,261,49]

theorem envBound23482 : H12AffineFastState.Bounded env23482 := by
  intro p hp
  have h : env23482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23481_23482 : H12AffineEnvironment.transform 10 260 env23481 = env23482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env23481 == env23482) = true)

theorem identity23482 : scanCanonicalize (H12AffineFastState.compose env23482 (packedSelected [0,6,8] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound23482 : packedSelected [0,6,8] rootPS < 2^1333 := by decide +kernel

def env23483 : List Nat := [2,4,8,16,32,16,8,37,49,53,33,0,56,0,32768,65536,0,1,52,32769,0,32817,17,98304,56,17,32784,0,0,65555,52,32817,36,98338,32,49]

theorem envBound23483 : H12AffineFastState.Bounded env23483 := by
  intro p hp
  have h : env23483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23482_23483 : H12AffineEnvironment.transform 7 37 env23482 = env23483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env23482 == env23483) = true)

theorem identity23483 : scanCanonicalize (H12AffineFastState.compose env23483 (packedSelected [1,3] rootPS)) = affineNative (2^(14+1) ^^^ 17) := by decide +kernel

theorem selectedBound23483 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env23484 : List Nat := [2,4,8,16,32,16,8,37,49,53,33,0,56,0,17,65536,0,1,52,16,0,32,17,65553,56,17,1,0,0,65555,52,32,36,65587,32,49]

theorem envBound23484 : H12AffineFastState.Bounded env23484 := by
  intro p hp
  have h : env23484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23483_23484 : H12AffineEnvironment.transform 14 17 env23483 = env23484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 17 env23483 == env23484) = true)

theorem identity23484 : scanCanonicalize (H12AffineFastState.compose env23484 (packedSelected [1,4] rootPS)) = affineNative (2^(15+1) ^^^ 51) := by decide +kernel

theorem selectedBound23484 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env23485 : List Nat := [2,4,8,16,32,16,8,37,49,53,33,0,56,0,17,51,0,1,52,16,0,32,17,34,56,17,1,0,0,32,52,32,36,0,32,49]

theorem envBound23485 : H12AffineFastState.Bounded env23485 := by
  intro p hp
  have h : env23485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23484_23485 : H12AffineEnvironment.transform 15 51 env23484 = env23485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 51 env23484 == env23485) = true)

theorem identity23485 : scanCanonicalize (H12AffineFastState.compose env23485 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound23485 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23486 : List Nat := [2,4,8,16,17,16,8,20,0,4,16,0,9,0,17,2,0,1,5,16,0,17,17,19,9,17,1,0,0,17,5,17,21,0,17,0]

theorem envBound23486 : H12AffineFastState.Bounded env23486 := by
  intro p hp
  have h : env23486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23485_23486 : H12AffineEnvironment.transform 4 17 env23485 = env23486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env23485 == env23486) = true)

def env23487 : List Nat := [2,4,8,16,32,17,8,256,48,273,2048,0,57,1,32768,65536,0,1,272,32769,0,32816,17,98304,57,16,33076,1,1,67862,272,32816,257,98338,261,48]

theorem envBound23487 : H12AffineFastState.Bounded env23487 := by
  intro p hp
  have h : env23487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23480_23487 : H12AffineEnvironment.transform 5 17 env23480 = env23487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23480 == env23487) = true)

theorem identity23487 : scanCanonicalize (H12AffineFastState.compose env23487 (packedSelected [5] rootPS)) = affineNative (2^(15+1) ^^^ 2066) := by decide +kernel

theorem selectedBound23487 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env23488 : List Nat := [2,4,8,16,32,17,8,256,48,273,2048,0,57,1,32768,2066,0,1,272,32769,0,32816,17,34834,57,16,33076,1,1,260,272,32816,257,34864,261,48]

theorem envBound23488 : H12AffineFastState.Bounded env23488 := by
  intro p hp
  have h : env23488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23487_23488 : H12AffineEnvironment.transform 15 2066 env23487 = env23488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2066 env23487 == env23488) = true)

theorem identity23488 : scanCanonicalize (H12AffineFastState.compose env23488 (packedSelected [8] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound23488 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env23489 : List Nat := [2,4,8,16,32,17,8,4,48,21,2048,0,57,1,32768,2066,0,1,20,32769,0,32816,17,34834,57,16,32816,1,1,0,20,32816,5,34864,1,48]

theorem envBound23489 : H12AffineFastState.Bounded env23489 := by
  intro p hp
  have h : env23489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23488_23489 : H12AffineEnvironment.transform 7 4 env23488 = env23489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env23488 == env23489) = true)

theorem identity23489 : scanCanonicalize (H12AffineFastState.compose env23489 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound23489 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23490 : List Nat := [2,4,8,16,32,17,8,4,48,21,0,0,57,1,32768,18,0,1,20,32769,0,32816,17,32786,57,16,32816,1,1,0,20,32816,5,32816,1,48]

theorem envBound23490 : H12AffineFastState.Bounded env23490 := by
  intro p hp
  have h : env23490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23489_23490 : H12AffineEnvironment.transform 10 0 env23489 = env23490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env23489 == env23490) = true)

theorem identity23490 : scanCanonicalize (H12AffineFastState.compose env23490 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound23490 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env23491 : List Nat := [2,4,8,16,1,17,8,4,17,21,0,0,24,1,32768,18,0,1,20,32769,0,32785,17,32786,24,16,32785,1,1,0,20,32785,5,32785,1,17]

theorem envBound23491 : H12AffineFastState.Bounded env23491 := by
  intro p hp
  have h : env23491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23490_23491 : H12AffineEnvironment.transform 4 1 env23490 = env23491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env23490 == env23491) = true)

theorem identity23491 : scanCanonicalize (H12AffineFastState.compose env23491 (packedSelected [0] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound23491 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23492 : List Nat := [2,4,8,16,1,17,8,4,17,21,0,0,24,1,0,18,0,1,20,1,0,17,17,18,24,16,17,1,1,0,20,17,5,17,1,17]

theorem envBound23492 : H12AffineFastState.Bounded env23492 := by
  intro p hp
  have h : env23492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23491_23492 : H12AffineEnvironment.transform 14 0 env23491 = env23492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env23491 == env23492) = true)

def env23493 : List Nat := [2,4,8,16,32,64,8,256,512,321,2048,1,521,81,32768,65536,1,1,320,32769,1,33280,17,98304,521,65,33540,81,81,67911,320,33280,257,98338,260,512]

theorem envBound23493 : H12AffineFastState.Bounded env23493 := by
  intro p hp
  have h : env23493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23478_23493 : H12AffineEnvironment.transform 9 321 env23478 = env23493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env23478 == env23493) = true)

theorem identity23493 : scanCanonicalize (H12AffineFastState.compose env23493 (packedSelected [13] rootPS)) = affineNative (2^(15+1) ^^^ 33378) := by decide +kernel

theorem selectedBound23493 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env23494 : List Nat := [2,4,8,16,32,64,8,256,512,321,2048,1,521,81,32768,33378,1,1,320,32769,1,33280,17,610,521,65,33540,81,81,35621,320,33280,257,576,260,512]

theorem envBound23494 : H12AffineFastState.Bounded env23494 := by
  intro p hp
  have h : env23494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23493_23494 : H12AffineEnvironment.transform 15 33378 env23493 = env23494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33378 env23493 == env23494) = true)

theorem identity23494 : scanCanonicalize (H12AffineFastState.compose env23494 (packedSelected [0,2,3,4,5,6,9,17,18,32,41] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound23494 : packedSelected [0,2,3,4,5,6,9,17,18,32,41] rootPS < 2^1333 := by decide +kernel

def env23495 : List Nat := [2,4,8,16,32,64,8,256,292,321,2048,1,301,81,32768,33094,1,1,320,32769,1,33060,17,326,301,65,32800,81,81,34817,320,33060,257,356,260,292]

theorem envBound23495 : H12AffineFastState.Bounded env23495 := by
  intro p hp
  have h : env23495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23494_23495 : H12AffineEnvironment.transform 8 292 env23494 = env23495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env23494 == env23495) = true)

theorem identity23495 : scanCanonicalize (H12AffineFastState.compose env23495 (packedSelected [4,9,11] rootPS)) = affineNative (2^(14+1) ^^^ 2309) := by decide +kernel

theorem selectedBound23495 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env23496 : List Nat := [2,4,8,16,32,64,8,256,292,321,2048,1,301,81,2309,2115,1,1,320,2308,1,2081,17,326,301,65,2341,81,81,260,320,2081,257,356,260,292]

theorem envBound23496 : H12AffineFastState.Bounded env23496 := by
  intro p hp
  have h : env23496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23495_23496 : H12AffineEnvironment.transform 14 2309 env23495 = env23496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2309 env23495 == env23496) = true)

theorem identity23496 : scanCanonicalize (H12AffineFastState.compose env23496 (packedSelected [1,4,5,9] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound23496 : packedSelected [1,4,5,9] rootPS < 2^1333 := by decide +kernel

def env23497 : List Nat := [2,4,8,16,32,64,8,256,292,321,32,1,301,81,293,99,1,1,320,292,1,1,17,326,301,65,261,81,81,260,320,1,257,356,260,292]

theorem envBound23497 : H12AffineFastState.Bounded env23497 := by
  intro p hp
  have h : env23497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23496_23497 : H12AffineEnvironment.transform 10 32 env23496 = env23497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env23496 == env23497) = true)

theorem identity23497 : scanCanonicalize (H12AffineFastState.compose env23497 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound23497 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env23498 : List Nat := [2,4,8,16,32,64,8,117,81,52,32,1,88,81,80,99,1,1,53,81,1,1,17,51,88,65,112,81,81,113,53,1,116,17,113,81]

theorem envBound23498 : H12AffineFastState.Bounded env23498 := by
  intro p hp
  have h : env23498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23497_23498 : H12AffineEnvironment.transform 7 117 env23497 = env23498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env23497 == env23498) = true)

theorem identity23498 : scanCanonicalize (H12AffineFastState.compose env23498 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound23498 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23499 : List Nat := [2,4,8,16,32,49,8,4,32,52,32,1,41,32,33,18,1,1,53,32,1,1,17,51,41,48,1,32,32,0,53,1,5,17,0,32]

theorem envBound23499 : H12AffineFastState.Bounded env23499 := by
  intro p hp
  have h : env23499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23498_23499 : H12AffineEnvironment.transform 5 49 env23498 = env23499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env23498 == env23499) = true)

theorem identity23499 : scanCanonicalize (H12AffineFastState.compose env23499 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound23499 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23500 : List Nat := [2,4,8,16,16,1,8,4,16,4,16,1,25,16,17,18,1,1,5,16,1,1,17,3,25,0,1,16,16,0,5,1,5,17,0,16]

theorem envBound23500 : H12AffineFastState.Bounded env23500 := by
  intro p hp
  have h : env23500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23499_23500 : H12AffineEnvironment.transform 4 16 env23499 = env23500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env23499 == env23500) = true)

def env23501 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1344,521,1296,32768,65536,1344,0,1025,32769,1344,33281,17,98304,520,65,33540,1296,1296,1073741824,1025,33280,257,98338,1093,512]

theorem envBound23501 : H12AffineFastState.Bounded env23501 := by
  intro p hp
  have h : env23501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23476_23501 : H12AffineEnvironment.transform 6 9 env23476 = env23501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env23476 == env23501) = true)

theorem identity23501 : scanCanonicalize (H12AffineFastState.compose env23501 (packedSelected [6,7] rootPS)) = affineNative (2^(29+1) ^^^ 68163) := by decide +kernel

theorem selectedBound23501 : packedSelected [6,7] rootPS < 2^1333 := by decide +kernel

def env23502 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1344,521,1296,32768,65536,1344,0,1025,32769,1344,33281,17,98304,520,65,33540,1296,1296,68163,1025,33280,257,98338,1093,512]

theorem envBound23502 : H12AffineFastState.Bounded env23502 := by
  intro p hp
  have h : env23502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23501_23502 : H12AffineEnvironment.transform 29 68163 env23501 = env23502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 68163 env23501 == env23502) = true)

def env23503 : List Nat := [2,4,8,16,32,64,9,256,512,320,2048,0,521,80,32768,65536,0,0,321,32769,0,33281,17,98304,520,65,33540,80,80,68163,321,33280,257,98338,261,512]

theorem envBound23503 : H12AffineFastState.Bounded env23503 := by
  intro p hp
  have h : env23503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23502_23503 : H12AffineEnvironment.transform 9 320 env23502 = env23503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env23502 == env23503) = true)

theorem identity23503 : scanCanonicalize (H12AffineFastState.compose env23503 (packedSelected [13] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound23503 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env23504 : List Nat := [2,4,8,16,32,64,9,53,512,117,2048,0,521,80,32768,65536,0,0,116,32769,0,33281,17,98304,520,65,33329,80,80,68163,116,33280,52,98338,48,512]

theorem envBound23504 : H12AffineFastState.Bounded env23504 := by
  intro p hp
  have h : env23504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23503_23504 : H12AffineEnvironment.transform 7 53 env23503 = env23504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env23503 == env23504) = true)

def env23505 : List Nat := [2,4,8,16,32,16,9,53,512,37,2048,0,521,0,32768,65536,0,0,36,32769,0,33281,17,98304,520,17,33329,0,0,68115,36,33280,52,98338,48,512]

theorem envBound23505 : H12AffineFastState.Bounded env23505 := by
  intro p hp
  have h : env23505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23504_23505 : H12AffineEnvironment.transform 5 16 env23504 = env23505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env23504 == env23505) = true)

theorem identity23505 : scanCanonicalize (H12AffineFastState.compose env23505 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound23505 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env23506 : List Nat := [2,4,8,16,32,16,9,53,512,37,1,0,521,0,32768,65536,0,0,36,32769,0,33281,17,98304,520,17,33329,0,0,66066,36,33280,52,98338,48,512]

theorem envBound23506 : H12AffineFastState.Bounded env23506 := by
  intro p hp
  have h : env23506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23505_23506 : H12AffineEnvironment.transform 10 1 env23505 = env23506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env23505 == env23506) = true)

theorem identity23506 : scanCanonicalize (H12AffineFastState.compose env23506 (packedSelected [0,6] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound23506 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env23507 : List Nat := [2,4,8,1,32,1,9,36,512,37,1,0,521,0,32768,65536,0,0,36,32769,0,33281,0,98304,520,0,33312,0,0,66051,36,33280,37,98338,33,512]

theorem envBound23507 : H12AffineFastState.Bounded env23507 := by
  intro p hp
  have h : env23507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23506_23507 : H12AffineEnvironment.transform 3 1 env23506 = env23507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env23506 == env23507) = true)

theorem identity23507 : scanCanonicalize (H12AffineFastState.compose env23507 (packedSelected [1,3] rootPS)) = affineNative (2^(14+1) ^^^ 512) := by decide +kernel

theorem selectedBound23507 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env23508 : List Nat := [2,4,8,1,32,1,9,36,512,37,1,0,521,0,512,65536,0,0,36,513,0,1,0,66048,520,0,32,0,0,66051,36,0,37,66082,33,512]

theorem envBound23508 : H12AffineFastState.Bounded env23508 := by
  intro p hp
  have h : env23508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23507_23508 : H12AffineEnvironment.transform 14 512 env23507 = env23508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 512 env23507 == env23508) = true)

theorem identity23508 : scanCanonicalize (H12AffineFastState.compose env23508 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound23508 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env23509 : List Nat := [2,4,8,1,32,1,9,36,1,37,1,0,8,0,1,65536,0,0,36,0,0,1,0,65537,9,0,32,0,0,65538,36,0,37,65571,33,1]

theorem envBound23509 : H12AffineFastState.Bounded env23509 := by
  intro p hp
  have h : env23509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23508_23509 : H12AffineEnvironment.transform 8 1 env23508 = env23509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env23508 == env23509) = true)

theorem identity23509 : scanCanonicalize (H12AffineFastState.compose env23509 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound23509 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23510 : List Nat := [2,4,8,1,32,1,9,36,1,37,1,0,8,0,1,35,0,0,36,0,0,1,0,34,9,0,32,0,0,33,36,0,37,0,33,1]

theorem envBound23510 : H12AffineFastState.Bounded env23510 := by
  intro p hp
  have h : env23510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23509_23510 : H12AffineEnvironment.transform 15 35 env23509 = env23510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env23509 == env23510) = true)

def env23511 : List Nat := [2,4,8,16,32,17,9,53,512,36,2048,0,521,1,32768,65536,0,0,37,32769,0,33281,17,98304,520,16,33329,1,1,68114,37,33280,52,98338,48,512]

theorem envBound23511 : H12AffineFastState.Bounded env23511 := by
  intro p hp
  have h : env23511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23504_23511 : H12AffineEnvironment.transform 5 17 env23504 = env23511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23504 == env23511) = true)

theorem identity23511 : scanCanonicalize (H12AffineFastState.compose env23511 (packedSelected [5] rootPS)) = affineNative (2^(15+1) ^^^ 2579) := by decide +kernel

theorem selectedBound23511 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env23512 : List Nat := [2,4,8,16,32,17,9,53,512,36,2048,0,521,1,32768,2579,0,0,37,32769,0,33281,17,35347,520,16,33329,1,1,1,37,33280,52,35377,48,512]

theorem envBound23512 : H12AffineFastState.Bounded env23512 := by
  intro p hp
  have h : env23512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23511_23512 : H12AffineEnvironment.transform 15 2579 env23511 = env23512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2579 env23511 == env23512) = true)

theorem identity23512 : scanCanonicalize (H12AffineFastState.compose env23512 (packedSelected [0,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound23512 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env23513 : List Nat := [2,4,8,16,1,17,9,20,512,5,2048,0,521,1,32768,2579,0,0,4,32769,0,33281,17,35347,520,16,33296,1,1,1,4,33280,21,35344,17,512]

theorem envBound23513 : H12AffineFastState.Bounded env23513 := by
  intro p hp
  have h : env23513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23512_23513 : H12AffineEnvironment.transform 4 1 env23512 = env23513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env23512 == env23513) = true)

def env23514 : List Nat := [2,4,8,16,32,64,9,256,512,321,2048,1,521,81,32768,65536,1,0,320,32769,1,33281,17,98304,520,65,33540,81,81,68163,320,33280,257,98338,260,512]

theorem envBound23514 : H12AffineFastState.Bounded env23514 := by
  intro p hp
  have h : env23514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23502_23514 : H12AffineEnvironment.transform 9 321 env23502 = env23514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env23502 == env23514) = true)

theorem identity23514 : scanCanonicalize (H12AffineFastState.compose env23514 (packedSelected [13] rootPS)) = affineNative (2^(15+1) ^^^ 33079) := by decide +kernel

theorem selectedBound23514 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env23515 : List Nat := [2,4,8,16,32,64,9,256,512,321,2048,1,521,81,32768,33079,1,0,320,32769,1,33281,17,311,520,65,33540,81,81,35700,320,33280,257,277,260,512]

theorem envBound23515 : H12AffineFastState.Bounded env23515 := by
  intro p hp
  have h : env23515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23514_23515 : H12AffineEnvironment.transform 15 33079 env23514 = env23515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33079 env23514 == env23515) = true)

def env23516 : List Nat := [2,4,8,16,32,16,9,256,512,273,2048,1,521,1,32768,33079,1,0,272,32769,1,33281,17,311,520,17,33540,1,1,35620,272,33280,257,277,260,512]

theorem envBound23516 : H12AffineFastState.Bounded env23516 := by
  intro p hp
  have h : env23516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23515_23516 : H12AffineEnvironment.transform 5 16 env23515 = env23516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env23515 == env23516) = true)

theorem identity23516 : scanCanonicalize (H12AffineFastState.compose env23516 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound23516 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env23517 : List Nat := [2,4,8,16,32,16,9,256,512,273,33,1,521,1,32768,33079,1,0,272,32769,1,33281,17,311,520,17,33540,1,1,33541,272,33280,257,277,260,512]

theorem envBound23517 : H12AffineFastState.Bounded env23517 := by
  intro p hp
  have h : env23517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23516_23517 : H12AffineEnvironment.transform 10 33 env23516 = env23517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env23516 == env23517) = true)

theorem identity23517 : scanCanonicalize (H12AffineFastState.compose env23517 (packedSelected [4,9] rootPS)) = affineNative (2^(14+1) ^^^ 773) := by decide +kernel

theorem selectedBound23517 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env23518 : List Nat := [2,4,8,16,32,16,9,256,512,273,33,1,521,1,773,562,1,0,272,772,1,260,17,311,520,17,1,1,1,0,272,261,257,277,260,512]

theorem envBound23518 : H12AffineFastState.Bounded env23518 := by
  intro p hp
  have h : env23518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23517_23518 : H12AffineEnvironment.transform 14 773 env23517 = env23518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 773 env23517 == env23518) = true)

theorem identity23518 : scanCanonicalize (H12AffineFastState.compose env23518 (packedSelected [8] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound23518 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env23519 : List Nat := [2,4,8,16,32,16,9,36,512,53,33,1,521,1,545,562,1,0,52,544,1,32,17,19,520,17,1,1,1,0,52,33,37,49,32,512]

theorem envBound23519 : H12AffineFastState.Bounded env23519 := by
  intro p hp
  have h : env23519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23518_23519 : H12AffineEnvironment.transform 7 36 env23518 = env23519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env23518 == env23519) = true)

theorem identity23519 : scanCanonicalize (H12AffineFastState.compose env23519 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound23519 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env23520 : List Nat := [2,4,8,16,17,16,9,21,512,4,16,1,521,1,528,515,1,0,5,529,1,17,17,19,520,17,1,1,1,0,5,16,20,0,17,512]

theorem envBound23520 : H12AffineFastState.Bounded env23520 := by
  intro p hp
  have h : env23520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23519_23520 : H12AffineEnvironment.transform 4 17 env23519 = env23520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env23519 == env23520) = true)

theorem identity23520 : scanCanonicalize (H12AffineFastState.compose env23520 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound23520 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23521 : List Nat := [2,4,8,1,0,1,9,4,512,4,1,1,521,1,513,515,1,0,5,512,1,0,0,2,520,0,1,1,1,0,5,1,5,0,0,512]

theorem envBound23521 : H12AffineFastState.Bounded env23521 := by
  intro p hp
  have h : env23521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23520_23521 : H12AffineEnvironment.transform 3 1 env23520 = env23521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env23520 == env23521) = true)

theorem identity23521 : scanCanonicalize (H12AffineFastState.compose env23521 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound23521 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23522 : List Nat := [2,4,8,1,0,1,9,4,1,4,1,1,8,1,0,2,1,0,5,1,1,0,0,2,9,0,1,1,1,0,5,1,5,0,0,1]

theorem envBound23522 : H12AffineFastState.Bounded env23522 := by
  intro p hp
  have h : env23522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23521_23522 : H12AffineEnvironment.transform 8 1 env23521 = env23522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env23521 == env23522) = true)

def env23523 : List Nat := [2,4,8,16,32,17,9,256,512,272,2048,1,521,0,32768,33079,1,0,273,32769,1,33281,17,311,520,16,33540,0,0,35621,273,33280,257,277,260,512]

theorem envBound23523 : H12AffineFastState.Bounded env23523 := by
  intro p hp
  have h : env23523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23515_23523 : H12AffineEnvironment.transform 5 17 env23515 = env23523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23515 == env23523) = true)

theorem identity23523 : scanCanonicalize (H12AffineFastState.compose env23523 (packedSelected [5] rootPS)) = affineNative (2^(14+1) ^^^ 2821) := by decide +kernel

theorem selectedBound23523 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env23524 : List Nat := [2,4,8,16,32,17,9,256,512,272,2048,1,521,0,2821,2610,1,0,273,2820,1,2308,17,311,520,16,2049,0,0,32,273,2309,257,277,260,512]

theorem envBound23524 : H12AffineFastState.Bounded env23524 := by
  intro p hp
  have h : env23524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23523_23524 : H12AffineEnvironment.transform 14 2821 env23523 = env23524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2821 env23523 == env23524) = true)

theorem identity23524 : scanCanonicalize (H12AffineFastState.compose env23524 (packedSelected [1,3,8] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound23524 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env23525 : List Nat := [2,4,8,16,32,17,9,21,512,5,2048,1,521,0,2576,2610,1,0,4,2577,1,2065,17,34,520,16,2049,0,0,32,4,2064,20,0,17,512]

theorem envBound23525 : H12AffineFastState.Bounded env23525 := by
  intro p hp
  have h : env23525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23524_23525 : H12AffineEnvironment.transform 7 21 env23524 = env23525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env23524 == env23525) = true)

theorem identity23525 : scanCanonicalize (H12AffineFastState.compose env23525 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound23525 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env23526 : List Nat := [2,4,8,16,32,17,9,21,48,5,2048,1,57,0,2080,2050,1,0,4,2081,1,2065,17,34,56,16,2049,0,0,32,4,2064,20,0,17,48]

theorem envBound23526 : H12AffineFastState.Bounded env23526 := by
  intro p hp
  have h : env23526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23525_23526 : H12AffineEnvironment.transform 8 48 env23525 = env23526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env23525 == env23526) = true)

theorem identity23526 : scanCanonicalize (H12AffineFastState.compose env23526 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound23526 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env23527 : List Nat := [2,4,8,16,1,17,9,21,17,5,2048,1,24,0,2049,2050,1,0,4,2048,1,2065,17,3,25,16,2049,0,0,1,4,2064,20,0,17,17]

theorem envBound23527 : H12AffineFastState.Bounded env23527 := by
  intro p hp
  have h : env23527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23526_23527 : H12AffineEnvironment.transform 4 1 env23526 = env23527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env23526 == env23527) = true)

def env23528 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,65536,1344,8832,1025,32769,1344,33417,17,98305,8328,65,41228,1296,1296,1073741824,1024,33281,257,98339,1092,512]

theorem envBound23528 : H12AffineFastState.Bounded env23528 := by
  intro p hp
  have h : env23528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23474_23528 : H12AffineEnvironment.transform 21 33417 env23474 = env23528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33417 env23474 == env23528) = true)

theorem identity23528 : scanCanonicalize (H12AffineFastState.compose env23528 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 781) := by decide +kernel

theorem selectedBound23528 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env23529 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,781,1296,32768,65536,1344,397,1025,32769,1344,33417,17,98305,901,65,33281,1296,1296,1073741824,1024,33281,257,98339,1092,512]

theorem envBound23529 : H12AffineFastState.Bounded env23529 := by
  intro p hp
  have h : env23529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23528_23529 : H12AffineEnvironment.transform 12 781 env23528 = env23529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 781 env23528 == env23529) = true)

def env23530 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1344,781,1296,32768,65536,1344,261,1025,32769,1344,33281,17,98305,781,65,33281,1296,1296,1073741824,1024,33281,257,98339,1092,512]

theorem envBound23530 : H12AffineFastState.Bounded env23530 := by
  intro p hp
  have h : env23530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23529_23530 : H12AffineEnvironment.transform 6 8 env23529 = env23530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env23529 == env23530) = true)

theorem identity23530 : scanCanonicalize (H12AffineFastState.compose env23530 (packedSelected [6,7] rootPS)) = affineNative (2^(14+1) ^^^ 324) := by decide +kernel

theorem selectedBound23530 : packedSelected [6,7] rootPS < 2^1333 := by decide +kernel

def env23531 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1344,781,1296,324,65536,1344,261,1025,325,1344,837,17,65861,781,65,837,1296,1296,1073741824,1024,837,257,65895,1092,512]

theorem envBound23531 : H12AffineFastState.Bounded env23531 := by
  intro p hp
  have h : env23531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23530_23531 : H12AffineEnvironment.transform 14 324 env23530 = env23531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 324 env23530 == env23531) = true)

def env23532 : List Nat := [2,4,8,16,32,64,8,256,512,320,2048,0,781,80,324,65536,0,261,321,325,0,837,17,65861,781,65,837,80,80,1073741824,320,837,257,65895,260,512]

theorem envBound23532 : H12AffineFastState.Bounded env23532 := by
  intro p hp
  have h : env23532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23531_23532 : H12AffineEnvironment.transform 9 320 env23531 = env23532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env23531 == env23532) = true)

theorem identity23532 : scanCanonicalize (H12AffineFastState.compose env23532 (packedSelected [13] rootPS)) = affineNative (2^(29+1) ^^^ 68130) := by decide +kernel

theorem selectedBound23532 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env23533 : List Nat := [2,4,8,16,32,64,8,256,512,320,2048,0,781,80,324,65536,0,261,321,325,0,837,17,65861,781,65,837,80,80,68130,320,837,257,65895,260,512]

theorem envBound23533 : H12AffineFastState.Bounded env23533 := by
  intro p hp
  have h : env23533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23532_23533 : H12AffineEnvironment.transform 29 68130 env23532 = env23533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 68130 env23532 == env23533) = true)

def env23534 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,0,781,0,276,65536,0,261,273,277,0,789,17,65813,781,17,789,0,0,68130,272,789,257,65847,260,512]

theorem envBound23534 : H12AffineFastState.Bounded env23534 := by
  intro p hp
  have h : env23534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23533_23534 : H12AffineEnvironment.transform 5 16 env23533 = env23534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env23533 == env23534) = true)

theorem identity23534 : scanCanonicalize (H12AffineFastState.compose env23534 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound23534 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env23535 : List Nat := [2,4,8,16,32,16,8,256,512,272,1,0,781,0,276,65536,0,261,273,277,0,789,17,65813,781,17,789,0,0,66083,272,789,257,65847,260,512]

theorem envBound23535 : H12AffineFastState.Bounded env23535 := by
  intro p hp
  have h : env23535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23534_23535 : H12AffineEnvironment.transform 10 1 env23534 = env23535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env23534 == env23535) = true)

theorem identity23535 : scanCanonicalize (H12AffineFastState.compose env23535 (packedSelected [8,12] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound23535 : packedSelected [8,12] rootPS < 2^1333 := by decide +kernel

def env23536 : List Nat := [2,4,8,16,32,16,8,256,512,272,1,0,781,0,276,34,0,261,273,277,0,789,17,311,781,17,789,0,0,513,272,789,257,277,260,512]

theorem envBound23536 : H12AffineFastState.Bounded env23536 := by
  intro p hp
  have h : env23536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23535_23536 : H12AffineEnvironment.transform 15 34 env23535 = env23536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env23535 == env23536) = true)

theorem identity23536 : scanCanonicalize (H12AffineFastState.compose env23536 (packedSelected [0,3,6,8] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound23536 : packedSelected [0,3,6,8] rootPS < 2^1333 := by decide +kernel

def env23537 : List Nat := [2,4,8,16,32,16,8,21,512,5,1,0,536,0,1,34,0,16,4,0,0,512,17,34,536,17,512,0,0,513,5,512,20,0,17,512]

theorem envBound23537 : H12AffineFastState.Bounded env23537 := by
  intro p hp
  have h : env23537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23536_23537 : H12AffineEnvironment.transform 7 21 env23536 = env23537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env23536 == env23537) = true)

theorem identity23537 : scanCanonicalize (H12AffineFastState.compose env23537 (packedSelected [0,1,2] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound23537 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env23538 : List Nat := [2,4,8,16,32,16,8,21,48,5,1,0,40,0,1,34,0,16,4,0,0,48,17,34,40,17,48,0,0,49,5,48,20,0,17,48]

theorem envBound23538 : H12AffineFastState.Bounded env23538 := by
  intro p hp
  have h : env23538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23537_23538 : H12AffineEnvironment.transform 8 48 env23537 = env23538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env23537 == env23538) = true)

theorem identity23538 : scanCanonicalize (H12AffineFastState.compose env23538 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound23538 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env23539 : List Nat := [2,4,8,16,0,16,8,21,16,5,1,0,8,0,1,2,0,16,4,0,0,16,17,2,8,17,16,0,0,17,5,16,20,0,17,16]

theorem envBound23539 : H12AffineFastState.Bounded env23539 := by
  intro p hp
  have h : env23539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23538_23539 : H12AffineEnvironment.transform 4 0 env23538 = env23539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env23538 == env23539) = true)

theorem identity23539 : scanCanonicalize (H12AffineFastState.compose env23539 (packedSelected [6] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound23539 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env23540 : List Nat := [2,4,8,0,0,0,8,5,0,5,1,0,8,0,1,2,0,0,4,0,0,0,1,2,8,1,0,0,0,1,5,0,4,0,1,0]

theorem envBound23540 : H12AffineFastState.Bounded env23540 := by
  intro p hp
  have h : env23540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23539_23540 : H12AffineEnvironment.transform 3 0 env23539 = env23540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env23539 == env23540) = true)

def env23541 : List Nat := [2,4,8,16,32,17,8,256,512,273,2048,0,781,1,277,65536,0,261,272,276,0,788,17,65812,781,16,788,1,1,68130,273,788,257,65846,260,512]

theorem envBound23541 : H12AffineFastState.Bounded env23541 := by
  intro p hp
  have h : env23541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23533_23541 : H12AffineEnvironment.transform 5 17 env23533 = env23541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23533 == env23541) = true)

theorem identity23541 : scanCanonicalize (H12AffineFastState.compose env23541 (packedSelected [5] rootPS)) = affineNative (2^(15+1) ^^^ 2595) := by decide +kernel

theorem selectedBound23541 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env23542 : List Nat := [2,4,8,16,32,17,8,256,512,273,2048,0,781,1,277,2595,0,261,272,276,0,788,17,2871,781,16,788,1,1,1,273,788,257,2837,260,512]

theorem envBound23542 : H12AffineFastState.Bounded env23542 := by
  intro p hp
  have h : env23542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23541_23542 : H12AffineEnvironment.transform 15 2595 env23541 = env23542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2595 env23541 == env23542) = true)

theorem identity23542 : scanCanonicalize (H12AffineFastState.compose env23542 (packedSelected [8] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound23542 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env23543 : List Nat := [2,4,8,16,32,17,8,5,512,20,2048,0,520,1,16,2595,0,0,21,17,0,529,17,2610,520,16,529,1,1,1,20,529,4,2576,1,512]

theorem envBound23543 : H12AffineFastState.Bounded env23543 := by
  intro p hp
  have h : env23543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23542_23543 : H12AffineEnvironment.transform 7 5 env23542 = env23543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env23542 == env23543) = true)

theorem identity23543 : scanCanonicalize (H12AffineFastState.compose env23543 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound23543 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23544 : List Nat := [2,4,8,16,32,17,8,5,512,20,1,0,520,1,16,546,0,0,21,17,0,529,17,563,520,16,529,1,1,1,20,529,4,529,1,512]

theorem envBound23544 : H12AffineFastState.Bounded env23544 := by
  intro p hp
  have h : env23544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23543_23544 : H12AffineEnvironment.transform 10 1 env23543 = env23544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env23543 == env23544) = true)

theorem identity23544 : scanCanonicalize (H12AffineFastState.compose env23544 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound23544 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env23545 : List Nat := [2,4,8,16,0,17,8,5,512,20,1,0,520,1,16,514,0,0,21,17,0,529,17,531,520,16,529,1,1,1,20,529,4,529,1,512]

theorem envBound23545 : H12AffineFastState.Bounded env23545 := by
  intro p hp
  have h : env23545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23544_23545 : H12AffineEnvironment.transform 4 0 env23544 = env23545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env23544 == env23545) = true)

theorem identity23545 : scanCanonicalize (H12AffineFastState.compose env23545 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound23545 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23546 : List Nat := [2,4,8,16,0,17,8,5,1,20,1,0,9,1,16,3,0,0,21,17,0,16,17,18,9,16,16,1,1,1,20,16,4,16,1,1]

theorem envBound23546 : H12AffineFastState.Bounded env23546 := by
  intro p hp
  have h : env23546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23545_23546 : H12AffineEnvironment.transform 8 1 env23545 = env23546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env23545 == env23546) = true)

def env23547 : List Nat := [2,4,8,16,32,64,8,256,512,321,2048,1,781,81,324,65536,1,261,320,325,1,837,17,65861,781,65,837,81,81,1073741824,321,837,257,65895,261,512]

theorem envBound23547 : H12AffineFastState.Bounded env23547 := by
  intro p hp
  have h : env23547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23531_23547 : H12AffineEnvironment.transform 9 321 env23531 = env23547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env23531 == env23547) = true)

theorem identity23547 : scanCanonicalize (H12AffineFastState.compose env23547 (packedSelected [13] rootPS)) = affineNative (2^(29+1) ^^^ 2916) := by decide +kernel

theorem selectedBound23547 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env23548 : List Nat := [2,4,8,16,32,64,8,256,512,321,2048,1,781,81,324,65536,1,261,320,325,1,837,17,65861,781,65,837,81,81,2916,321,837,257,65895,261,512]

theorem envBound23548 : H12AffineFastState.Bounded env23548 := by
  intro p hp
  have h : env23548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23547_23548 : H12AffineEnvironment.transform 29 2916 env23547 = env23548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 2916 env23547 == env23548) = true)

def env23549 : List Nat := [2,4,8,16,32,16,8,256,512,273,2048,1,781,1,276,65536,1,261,272,277,1,789,17,65813,781,17,789,1,1,2868,273,789,257,65847,261,512]

theorem envBound23549 : H12AffineFastState.Bounded env23549 := by
  intro p hp
  have h : env23549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23548_23549 : H12AffineEnvironment.transform 5 16 env23548 = env23549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env23548 == env23549) = true)

theorem identity23549 : scanCanonicalize (H12AffineFastState.compose env23549 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound23549 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env23550 : List Nat := [2,4,8,16,32,16,8,256,512,273,293,1,781,1,276,65536,1,261,272,277,1,789,17,65813,781,17,789,1,1,529,273,789,257,65847,261,512]

theorem envBound23550 : H12AffineFastState.Bounded env23550 := by
  intro p hp
  have h : env23550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23549_23550 : H12AffineEnvironment.transform 10 293 env23549 = env23550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env23549 == env23550) = true)

theorem identity23550 : scanCanonicalize (H12AffineFastState.compose env23550 (packedSelected [1,3,4,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound23550 : packedSelected [1,3,4,8,9] rootPS < 2^1333 := by decide +kernel

def env23551 : List Nat := [2,4,8,16,32,16,8,36,512,53,1,1,553,1,48,65536,1,33,52,49,1,561,17,65585,553,17,561,1,1,529,53,561,37,65555,33,512]

theorem envBound23551 : H12AffineFastState.Bounded env23551 := by
  intro p hp
  have h : env23551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23550_23551 : H12AffineEnvironment.transform 7 36 env23550 = env23551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env23550 == env23551) = true)

theorem identity23551 : scanCanonicalize (H12AffineFastState.compose env23551 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound23551 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env23552 : List Nat := [2,4,8,16,32,16,8,36,48,53,1,1,25,1,48,65536,1,33,52,49,1,1,17,65585,25,17,1,1,1,33,53,1,37,65555,33,48]

theorem envBound23552 : H12AffineFastState.Bounded env23552 := by
  intro p hp
  have h : env23552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23551_23552 : H12AffineEnvironment.transform 8 48 env23551 = env23552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env23551 == env23552) = true)

theorem identity23552 : scanCanonicalize (H12AffineFastState.compose env23552 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound23552 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env23553 : List Nat := [2,4,8,16,16,16,8,20,0,5,1,1,25,1,0,65536,1,17,4,1,1,1,17,65537,25,17,1,1,1,17,5,1,21,65555,17,0]

theorem envBound23553 : H12AffineFastState.Bounded env23553 := by
  intro p hp
  have h : env23553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23552_23553 : H12AffineEnvironment.transform 4 16 env23552 = env23553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env23552 == env23553) = true)

theorem identity23553 : scanCanonicalize (H12AffineFastState.compose env23553 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound23553 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23554 : List Nat := [2,4,8,0,0,0,8,4,0,5,1,1,9,1,0,65536,1,1,4,1,1,1,1,65537,9,1,1,1,1,1,5,1,5,65539,1,0]

theorem envBound23554 : H12AffineFastState.Bounded env23554 := by
  intro p hp
  have h : env23554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23553_23554 : H12AffineEnvironment.transform 3 0 env23553 = env23554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env23553 == env23554) = true)

theorem identity23554 : scanCanonicalize (H12AffineFastState.compose env23554 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 2) := by decide +kernel

theorem selectedBound23554 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23555 : List Nat := [2,4,8,0,0,0,8,4,0,5,1,1,9,1,0,2,1,1,4,1,1,1,1,3,9,1,1,1,1,1,5,1,5,1,1,0]

theorem envBound23555 : H12AffineFastState.Bounded env23555 := by
  intro p hp
  have h : env23555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23554_23555 : H12AffineEnvironment.transform 15 2 env23554 = env23555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2 env23554 == env23555) = true)

def env23556 : List Nat := [2,4,8,16,32,17,8,256,512,272,2048,1,781,0,277,65536,1,261,273,276,1,788,17,65812,781,16,788,0,0,2869,272,788,257,65846,261,512]

theorem envBound23556 : H12AffineFastState.Bounded env23556 := by
  intro p hp
  have h : env23556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23548_23556 : H12AffineEnvironment.transform 5 17 env23548 = env23556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23548 == env23556) = true)

theorem identity23556 : scanCanonicalize (H12AffineFastState.compose env23556 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound23556 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env23557 : List Nat := [2,4,8,16,32,17,8,256,512,272,528,1,781,0,277,65536,1,261,273,276,1,788,17,65812,781,16,788,0,0,293,272,788,257,65846,261,512]

theorem envBound23557 : H12AffineFastState.Bounded env23557 := by
  intro p hp
  have h : env23557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23556_23557 : H12AffineEnvironment.transform 10 528 env23556 = env23557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env23556 == env23557) = true)

theorem identity23557 : scanCanonicalize (H12AffineFastState.compose env23557 (packedSelected [1,3,8] rootPS)) = affineNative (2^(15+1) ^^^ 311) := by decide +kernel

theorem selectedBound23557 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env23558 : List Nat := [2,4,8,16,32,17,8,256,512,272,528,1,781,0,277,311,1,261,273,276,1,788,17,35,781,16,788,0,0,293,272,788,257,1,261,512]

theorem envBound23558 : H12AffineFastState.Bounded env23558 := by
  intro p hp
  have h : env23558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23557_23558 : H12AffineEnvironment.transform 15 311 env23557 = env23558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 311 env23557 == env23558) = true)

theorem identity23558 : scanCanonicalize (H12AffineFastState.compose env23558 (packedSelected [0,2,3,4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound23558 : packedSelected [0,2,3,4] rootPS < 2^1333 := by decide +kernel

def env23559 : List Nat := [2,4,8,16,32,17,8,5,512,21,528,1,520,0,16,50,1,0,20,17,1,529,17,35,520,16,529,0,0,32,21,529,4,1,0,512]

theorem envBound23559 : H12AffineFastState.Bounded env23559 := by
  intro p hp
  have h : env23559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23558_23559 : H12AffineEnvironment.transform 7 5 env23558 = env23559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env23558 == env23559) = true)

theorem identity23559 : scanCanonicalize (H12AffineFastState.compose env23559 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound23559 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23560 : List Nat := [2,4,8,16,32,17,8,5,48,21,32,1,56,0,16,50,1,0,20,17,1,33,17,35,56,16,33,0,0,32,21,33,4,1,0,48]

theorem envBound23560 : H12AffineFastState.Bounded env23560 := by
  intro p hp
  have h : env23560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23559_23560 : H12AffineEnvironment.transform 8 48 env23559 = env23560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env23559 == env23560) = true)

theorem identity23560 : scanCanonicalize (H12AffineFastState.compose env23560 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound23560 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23561 : List Nat := [2,4,8,0,32,1,8,5,32,5,32,1,40,0,0,34,1,0,4,1,1,33,1,35,40,0,33,0,0,32,5,33,4,1,0,32]

theorem envBound23561 : H12AffineFastState.Bounded env23561 := by
  intro p hp
  have h : env23561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23560_23561 : H12AffineEnvironment.transform 3 0 env23560 = env23561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env23560 == env23561) = true)

theorem identity23561 : scanCanonicalize (H12AffineFastState.compose env23561 (packedSelected [9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound23561 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env23562 : List Nat := [2,4,8,0,1,1,8,5,1,5,1,1,9,0,0,3,1,0,4,1,1,0,1,2,9,0,0,0,0,1,5,0,4,1,0,1]

theorem envBound23562 : H12AffineFastState.Bounded env23562 := by
  intro p hp
  have h : env23562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23561_23562 : H12AffineEnvironment.transform 4 1 env23561 = env23562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env23561 == env23562) = true)

def env23563 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1344,781,1296,32768,65536,1344,260,1025,32769,1344,33280,17,98305,780,65,33281,1296,1296,1073741824,1024,33281,257,98339,1092,512]

theorem envBound23563 : H12AffineFastState.Bounded env23563 := by
  intro p hp
  have h : env23563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23529_23563 : H12AffineEnvironment.transform 6 9 env23529 = env23563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env23529 == env23563) = true)

theorem identity23563 : scanCanonicalize (H12AffineFastState.compose env23563 (packedSelected [6,7] rootPS)) = affineNative (2^(14+1) ^^^ 576) := by decide +kernel

theorem selectedBound23563 : packedSelected [6,7] rootPS < 2^1333 := by decide +kernel

def env23564 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1344,781,1296,576,65536,1344,260,1025,577,1344,64,17,66113,780,65,65,1296,1296,1073741824,1024,65,257,66147,1092,512]

theorem envBound23564 : H12AffineFastState.Bounded env23564 := by
  intro p hp
  have h : env23564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23563_23564 : H12AffineEnvironment.transform 14 576 env23563 = env23564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 576 env23563 == env23564) = true)

def env23565 : List Nat := [2,4,8,16,32,64,9,256,512,320,2048,0,781,80,576,65536,0,260,321,577,0,64,17,66113,780,65,65,80,80,1073741824,320,65,257,66147,260,512]

theorem envBound23565 : H12AffineFastState.Bounded env23565 := by
  intro p hp
  have h : env23565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23564_23565 : H12AffineEnvironment.transform 9 320 env23564 = env23565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env23564 == env23565) = true)

theorem identity23565 : scanCanonicalize (H12AffineFastState.compose env23565 (packedSelected [13] rootPS)) = affineNative (2^(29+1) ^^^ 68210) := by decide +kernel

theorem selectedBound23565 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env23566 : List Nat := [2,4,8,16,32,64,9,256,512,320,2048,0,781,80,576,65536,0,260,321,577,0,64,17,66113,780,65,65,80,80,68210,320,65,257,66147,260,512]

theorem envBound23566 : H12AffineFastState.Bounded env23566 := by
  intro p hp
  have h : env23566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23565_23566 : H12AffineEnvironment.transform 29 68210 env23565 = env23566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 68210 env23565 == env23566) = true)

def env23567 : List Nat := [2,4,8,16,32,16,9,256,512,272,2048,0,781,0,528,65536,0,260,273,529,0,16,17,66065,780,17,17,0,0,68130,272,17,257,66099,260,512]

theorem envBound23567 : H12AffineFastState.Bounded env23567 := by
  intro p hp
  have h : env23567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23566_23567 : H12AffineEnvironment.transform 5 16 env23566 = env23567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env23566 == env23567) = true)

theorem identity23567 : scanCanonicalize (H12AffineFastState.compose env23567 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 261) := by decide +kernel

theorem selectedBound23567 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env23568 : List Nat := [2,4,8,16,32,16,9,256,512,272,261,0,781,0,528,65536,0,260,273,529,0,16,17,66065,780,17,17,0,0,66343,272,17,257,66099,260,512]

theorem envBound23568 : H12AffineFastState.Bounded env23568 := by
  intro p hp
  have h : env23568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart2