import H12CloudChart2Data093

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env23060 : List Nat := [2,4,8,16,32,17,128,188,48,172,130,0,129,1,153,187,0,162,172,152,0,169,17,155,9,17,178,1,1,163,21,1,188,153,1,48]

theorem envBound23060 : H12AffineFastState.Bounded env23060 := by
  intro p hp
  have h : env23060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23059_23060 : H12AffineEnvironment.transform 7 188 env23059 = env23060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 188 env23059 == env23060) = true)

theorem identity23060 : scanCanonicalize (H12AffineFastState.compose env23060 (packedSelected [8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound23060 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env23061 : List Nat := [2,4,8,0,32,1,128,172,32,172,130,0,129,1,137,171,0,162,172,136,0,169,1,139,9,1,162,1,1,163,5,1,172,137,1,32]

theorem envBound23061 : H12AffineFastState.Bounded env23061 := by
  intro p hp
  have h : env23061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23060_23061 : H12AffineEnvironment.transform 3 0 env23060 = env23061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env23060 == env23061) = true)

theorem identity23061 : scanCanonicalize (H12AffineFastState.compose env23061 (packedSelected [0,2,4] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound23061 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env23062 : List Nat := [2,4,8,0,32,1,9,37,32,37,11,0,8,1,0,34,0,43,37,1,0,32,1,2,9,1,43,1,1,42,5,1,37,0,1,32]

theorem envBound23062 : H12AffineFastState.Bounded env23062 := by
  intro p hp
  have h : env23062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23061_23062 : H12AffineEnvironment.transform 6 9 env23061 = env23062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env23061 == env23062) = true)

theorem identity23062 : scanCanonicalize (H12AffineFastState.compose env23062 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound23062 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23063 : List Nat := [2,4,8,0,1,1,9,4,1,4,11,0,8,1,0,3,0,10,4,1,0,1,1,2,9,1,10,1,1,11,5,1,4,0,1,1]

theorem envBound23063 : H12AffineFastState.Bounded env23063 := by
  intro p hp
  have h : env23063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23062_23063 : H12AffineEnvironment.transform 4 1 env23062 = env23063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env23062 == env23063) = true)

theorem identity23063 : scanCanonicalize (H12AffineFastState.compose env23063 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound23063 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23064 : List Nat := [2,4,2,0,1,1,3,4,1,4,1,0,2,1,0,3,0,0,4,1,0,1,1,2,3,1,0,1,1,1,5,1,4,0,1,1]

theorem envBound23064 : H12AffineFastState.Bounded env23064 := by
  intro p hp
  have h : env23064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23063_23064 : H12AffineEnvironment.transform 2 2 env23063 = env23064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env23063 == env23064) = true)

def env23065 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,129,0,32768,65536,1,262144,273,32769,1,4194304,17,262533,9,17,4292997,0,0,1073741824,360596,1073842178,256,1078298925,0,512]

theorem envBound23065 : H12AffineFastState.Bounded env23065 := by
  intro p hp
  have h : env23065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23026_23065 : H12AffineEnvironment.transform 9 273 env23026 = env23065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env23026 == env23065) = true)

theorem identity23065 : scanCanonicalize (H12AffineFastState.compose env23065 (packedSelected [5] rootPS)) = affineNative (2^(29+1) ^^^ 4522018) := by decide +kernel

theorem selectedBound23065 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env23066 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,129,0,32768,65536,1,262144,273,32769,1,4194304,17,262533,9,17,4292997,0,0,4522018,360596,4491296,256,35087,0,512]

theorem envBound23066 : H12AffineFastState.Bounded env23066 := by
  intro p hp
  have h : env23066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23065_23066 : H12AffineEnvironment.transform 29 4522018 env23065 = env23066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4522018 env23065 == env23066) = true)

def env23067 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,129,0,32768,65536,1,98432,273,32769,1,4194304,17,98565,9,17,4292997,0,0,4227234,20,4262048,256,35087,0,512]

theorem envBound23067 : H12AffineFastState.Bounded env23067 := by
  intro p hp
  have h : env23067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23066_23067 : H12AffineEnvironment.transform 17 98432 env23066 = env23067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 98432 env23066 == env23067) = true)

theorem identity23067 : scanCanonicalize (H12AffineFastState.compose env23067 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 35489) := by decide +kernel

theorem selectedBound23067 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23068 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,129,0,32768,35489,1,2593,273,32769,1,4194304,17,2980,9,17,4197156,0,0,4227234,20,4227585,256,35087,0,512]

theorem envBound23068 : H12AffineFastState.Bounded env23068 := by
  intro p hp
  have h : env23068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23067_23068 : H12AffineEnvironment.transform 15 35489 env23067 = env23068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35489 env23067 == env23068) = true)

theorem identity23068 : scanCanonicalize (H12AffineFastState.compose env23068 (packedSelected [3] rootPS)) = affineNative (2^(21+1) ^^^ 35599) := by decide +kernel

theorem selectedBound23068 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env23069 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,129,0,32768,35489,1,2593,273,32769,1,35599,17,2980,9,17,32811,0,0,2989,20,2318,256,35087,0,512]

theorem envBound23069 : H12AffineFastState.Bounded env23069 := by
  intro p hp
  have h : env23069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23068_23069 : H12AffineEnvironment.transform 21 35599 env23068 = env23069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 35599 env23068 == env23069) = true)

theorem identity23069 : scanCanonicalize (H12AffineFastState.compose env23069 (packedSelected [8] rootPS)) = affineNative (2^(14+1) ^^^ 773) := by decide +kernel

theorem selectedBound23069 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env23070 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,129,0,773,2468,1,2593,273,772,1,2058,17,2980,9,17,814,0,0,2989,20,2318,256,2570,0,512]

theorem envBound23070 : H12AffineFastState.Bounded env23070 := by
  intro p hp
  have h : env23070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23069_23070 : H12AffineEnvironment.transform 14 773 env23069 = env23070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 773 env23069 == env23070) = true)

theorem identity23070 : scanCanonicalize (H12AffineFastState.compose env23070 (packedSelected [0,2,4,6,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound23070 : packedSelected [0,2,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env23071 : List Nat := [2,4,8,16,32,17,128,256,137,273,2048,1,129,0,396,2468,1,2216,273,397,1,2058,17,2349,9,17,423,0,0,2340,20,2318,256,2179,0,137]

theorem envBound23071 : H12AffineFastState.Bounded env23071 := by
  intro p hp
  have h : env23071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23070_23071 : H12AffineEnvironment.transform 8 137 env23070 = env23071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env23070 == env23071) = true)

theorem identity23071 : scanCanonicalize (H12AffineFastState.compose env23071 (packedSelected [0,2,6,7,11] rootPS)) = affineNative (2^(7+1) ^^^ 141) := by decide +kernel

theorem selectedBound23071 : packedSelected [0,2,6,7,11] rootPS < 2^1333 := by decide +kernel

def env23072 : List Nat := [2,4,8,16,32,17,128,141,137,156,2048,1,129,0,1,2089,1,2216,156,0,1,2058,17,2208,9,17,42,0,0,2217,20,2179,141,2179,0,137]

theorem envBound23072 : H12AffineFastState.Bounded env23072 := by
  intro p hp
  have h : env23072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23071_23072 : H12AffineEnvironment.transform 7 141 env23071 = env23072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 141 env23071 == env23072) = true)

theorem identity23072 : scanCanonicalize (H12AffineFastState.compose env23072 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 179) := by decide +kernel

theorem selectedBound23072 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23073 : List Nat := [2,4,8,16,32,17,128,141,137,156,179,1,129,0,1,154,1,27,156,0,1,185,17,19,9,17,42,0,0,26,20,48,141,48,0,137]

theorem envBound23073 : H12AffineFastState.Bounded env23073 := by
  intro p hp
  have h : env23073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23072_23073 : H12AffineEnvironment.transform 10 179 env23072 = env23073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 179 env23072 == env23073) = true)

theorem identity23073 : scanCanonicalize (H12AffineFastState.compose env23073 (packedSelected [6] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound23073 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env23074 : List Nat := [2,4,8,16,32,17,24,21,17,4,43,1,25,0,1,2,1,27,4,0,1,33,17,19,9,17,42,0,0,26,20,48,21,48,0,17]

theorem envBound23074 : H12AffineFastState.Bounded env23074 := by
  intro p hp
  have h : env23074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23073_23074 : H12AffineEnvironment.transform 6 24 env23073 = env23074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env23073 == env23074) = true)

def env23075 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,129,0,32768,65536,1,98433,273,32769,1,4194304,17,98564,9,17,4292997,0,0,4227235,21,4262049,256,35087,0,512]

theorem envBound23075 : H12AffineFastState.Bounded env23075 := by
  intro p hp
  have h : env23075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23066_23075 : H12AffineEnvironment.transform 17 98433 env23066 = env23075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 98433 env23066 == env23075) = true)

theorem identity23075 : scanCanonicalize (H12AffineFastState.compose env23075 (packedSelected [1] rootPS)) = affineNative (2^(14+1) ^^^ 680) := by decide +kernel

theorem selectedBound23075 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23076 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,129,0,680,65536,1,66089,273,681,1,4194304,17,66476,9,17,4260653,0,0,4194827,21,4262049,256,2983,0,512]

theorem envBound23076 : H12AffineFastState.Bounded env23076 := by
  intro p hp
  have h : env23076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23075_23076 : H12AffineEnvironment.transform 14 680 env23075 = env23076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 680 env23075 == env23076) = true)

theorem identity23076 : scanCanonicalize (H12AffineFastState.compose env23076 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 271) := by decide +kernel

theorem selectedBound23076 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env23077 : List Nat := [2,4,8,16,32,17,128,256,512,273,271,1,129,0,680,65536,1,66089,273,681,1,4194304,17,66476,9,17,4260653,0,0,4194827,21,4260270,256,680,0,512]

theorem envBound23077 : H12AffineFastState.Bounded env23077 := by
  intro p hp
  have h : env23077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23076_23077 : H12AffineEnvironment.transform 10 271 env23076 = env23077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 271 env23076 == env23077) = true)

theorem identity23077 : scanCanonicalize (H12AffineFastState.compose env23077 (packedSelected [8] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound23077 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env23078 : List Nat := [2,4,8,16,32,17,128,256,1,273,271,1,129,0,169,65536,1,65576,273,168,1,4194304,17,65965,9,17,4260140,0,0,4194314,21,4260270,256,169,0,1]

theorem envBound23078 : H12AffineFastState.Bounded env23078 := by
  intro p hp
  have h : env23078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23077_23078 : H12AffineEnvironment.transform 8 1 env23077 = env23078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env23077 == env23078) = true)

theorem identity23078 : scanCanonicalize (H12AffineFastState.compose env23078 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(21+1) ^^^ 260) := by decide +kernel

theorem selectedBound23078 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env23079 : List Nat := [2,4,8,16,32,17,128,256,1,273,271,1,129,0,169,65536,1,65576,273,168,1,260,17,65965,9,17,65576,0,0,270,21,65706,256,169,0,1]

theorem envBound23079 : H12AffineFastState.Bounded env23079 := by
  intro p hp
  have h : env23079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23078_23079 : H12AffineEnvironment.transform 21 260 env23078 = env23079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 260 env23078 == env23079) = true)

theorem identity23079 : scanCanonicalize (H12AffineFastState.compose env23079 (packedSelected [0,7] rootPS)) = affineNative (2^(15+1) ^^^ 41) := by decide +kernel

theorem selectedBound23079 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env23080 : List Nat := [2,4,8,16,32,17,128,256,1,273,271,1,129,0,169,41,1,1,273,168,1,260,17,388,9,17,1,0,0,270,21,131,256,169,0,1]

theorem envBound23080 : H12AffineFastState.Bounded env23080 := by
  intro p hp
  have h : env23080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23079_23080 : H12AffineEnvironment.transform 15 41 env23079 = env23080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41 env23079 == env23080) = true)

theorem identity23080 : scanCanonicalize (H12AffineFastState.compose env23080 (packedSelected [4,6] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound23080 : packedSelected [4,6] rootPS < 2^1333 := by decide +kernel

def env23081 : List Nat := [2,4,8,16,32,17,128,5,1,20,10,1,129,0,169,41,1,1,20,168,1,1,17,129,9,17,1,0,0,11,21,131,5,169,0,1]

theorem envBound23081 : H12AffineFastState.Bounded env23081 := by
  intro p hp
  have h : env23081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23080_23081 : H12AffineEnvironment.transform 7 5 env23080 = env23081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env23080 == env23081) = true)

theorem identity23081 : scanCanonicalize (H12AffineFastState.compose env23081 (packedSelected [10] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound23081 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env23082 : List Nat := [2,4,2,16,32,17,128,5,1,20,0,1,129,0,163,35,1,1,20,162,1,1,17,129,3,17,1,0,0,1,21,131,5,163,0,1]

theorem envBound23082 : H12AffineFastState.Bounded env23082 := by
  intro p hp
  have h : env23082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23081_23082 : H12AffineEnvironment.transform 2 2 env23081 = env23082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env23081 == env23082) = true)

theorem identity23082 : scanCanonicalize (H12AffineFastState.compose env23082 (packedSelected [0,2] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound23082 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env23083 : List Nat := [2,4,2,16,32,17,2,5,1,20,0,1,3,0,33,35,1,1,20,32,1,1,17,3,3,17,1,0,0,1,21,1,5,33,0,1]

theorem envBound23083 : H12AffineFastState.Bounded env23083 := by
  intro p hp
  have h : env23083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23082_23083 : H12AffineEnvironment.transform 6 2 env23082 = env23083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env23082 == env23083) = true)

theorem identity23083 : scanCanonicalize (H12AffineFastState.compose env23083 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound23083 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23084 : List Nat := [2,4,2,1,32,0,2,5,1,5,0,1,3,0,33,35,1,1,5,32,1,1,0,3,3,0,1,0,0,1,4,1,5,33,0,1]

theorem envBound23084 : H12AffineFastState.Bounded env23084 := by
  intro p hp
  have h : env23084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23083_23084 : H12AffineEnvironment.transform 3 1 env23083 = env23084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env23083 == env23084) = true)

def env23085 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,21777,262144,1024,32769,4096,4194304,5456,16777216,8328,5377,21331969,16384,1297,1073741824,16876544,4294967296,256,4315938986,1345,512]

theorem envBound23085 : H12AffineFastState.Bounded env23085 := by
  intro p hp
  have h : env23085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22983_23085 : H12AffineEnvironment.transform 26 21331969 env22983 = env23085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 21331969 env22983 == env23085) = true)

def env23086 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,21777,262144,1025,32769,4096,4194304,5457,16777216,8328,5377,134217728,16385,1296,1073741824,16876545,4294967296,257,4315938986,155551040,512]

theorem envBound23086 : H12AffineFastState.Bounded env23086 := by
  intro p hp
  have h : env23086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22982_23086 : H12AffineEnvironment.transform 18 1025 env22982 = env23086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env22982 == env23086) = true)

def env23087 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,21777,262144,1025,32769,4096,4194304,5457,16777216,8328,5377,21331968,16385,1296,1073741824,16876545,4294967296,257,4315938986,1344,512]

theorem envBound23087 : H12AffineFastState.Bounded env23087 := by
  intro p hp
  have h : env23087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23086_23087 : H12AffineEnvironment.transform 26 21331968 env23086 = env23087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 21331968 env23086 == env23087) = true)

theorem identity23087 : scanCanonicalize (H12AffineFastState.compose env23087 (packedSelected [7,20,27] rootPS)) = affineNative (2^(23+1) ^^^ 98565) := by decide +kernel

theorem selectedBound23087 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env23088 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,21777,262144,1025,32769,4096,4194304,5457,98565,8328,5377,4456709,16385,1296,1073741824,1284,4294967296,257,4299260335,1344,512]

theorem envBound23088 : H12AffineFastState.Bounded env23088 := by
  intro p hp
  have h : env23088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23087_23088 : H12AffineEnvironment.transform 23 98565 env23087 = env23088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98565 env23087 == env23088) = true)

def env23089 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,65536,4177,262144,1025,32769,4096,4194304,5457,98565,8328,5377,4456709,1345,1296,1073741824,1284,4294967296,257,4299260335,1344,512]

theorem envBound23089 : H12AffineFastState.Bounded env23089 := by
  intro p hp
  have h : env23089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23088_23089 : H12AffineEnvironment.transform 13 1344 env23088 = env23089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env23088 == env23089) = true)

theorem identity23089 : scanCanonicalize (H12AffineFastState.compose env23089 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound23089 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env23090 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,1297,32768,65536,4096,262144,1025,32769,4096,4194304,5376,98565,8328,5377,4456709,1296,1296,1073741824,1284,4294967296,257,4299260335,1297,512]

theorem envBound23090 : H12AffineFastState.Bounded env23090 := by
  intro p hp
  have h : env23090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23089_23090 : H12AffineEnvironment.transform 5 17 env23089 = env23090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23089 == env23090) = true)

theorem identity23090 : scanCanonicalize (H12AffineFastState.compose env23090 (packedSelected [1,3,8,10,13,17,24] rootPS)) = affineNative (2^(31+1) ^^^ 1078012207) := by decide +kernel

theorem selectedBound23090 : packedSelected [1,3,8,10,13,17,24] rootPS < 2^1333 := by decide +kernel

def env23091 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,1297,32768,65536,4096,262144,1025,32769,4096,4194304,5376,98565,8328,5377,4456709,1296,1296,1073741824,1284,1078012207,257,1073784960,1297,512]

theorem envBound23091 : H12AffineFastState.Bounded env23091 := by
  intro p hp
  have h : env23091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23090_23091 : H12AffineEnvironment.transform 31 1078012207 env23090 = env23091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1078012207 env23090 == env23091) = true)

theorem identity23091 : scanCanonicalize (H12AffineFastState.compose env23091 (packedSelected [8,10,13,17,28] rootPS)) = affineNative (2^(21+1) ^^^ 264452) := by decide +kernel

theorem selectedBound23091 : packedSelected [8,10,13,17,28] rootPS < 2^1333 := by decide +kernel

def env23092 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,1297,32768,65536,4096,262144,1025,32769,4096,264452,5376,98565,8328,5377,2049,1296,1296,1073741824,1284,1074077739,257,1073784960,1297,512]

theorem envBound23092 : H12AffineFastState.Bounded env23092 := by
  intro p hp
  have h : env23092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23091_23092 : H12AffineEnvironment.transform 21 264452 env23091 = env23092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 264452 env23091 == env23092) = true)

theorem identity23092 : scanCanonicalize (H12AffineFastState.compose env23092 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 48440) := by decide +kernel

theorem selectedBound23092 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env23093 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,1297,32768,65536,4096,48440,1025,32769,4096,46140,5376,98565,8328,5377,2049,1296,1296,1073741824,1284,1073847571,257,1073784960,1297,512]

theorem envBound23093 : H12AffineFastState.Bounded env23093 := by
  intro p hp
  have h : env23093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23092_23093 : H12AffineEnvironment.transform 17 48440 env23092 = env23093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 48440 env23092 == env23093) = true)

theorem identity23093 : scanCanonicalize (H12AffineFastState.compose env23093 (packedSelected [3,5,10,11,13,15,17] rootPS)) = affineNative (2^(29+1) ^^^ 43049) := by decide +kernel

theorem selectedBound23093 : packedSelected [3,5,10,11,13,15,17] rootPS < 2^1333 := by decide +kernel

def env23094 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,1297,32768,65536,4096,48440,1025,32769,4096,46140,5376,98565,8328,5377,2049,1296,1296,43049,1284,79162,257,169,1297,512]

theorem envBound23094 : H12AffineFastState.Bounded env23094 := by
  intro p hp
  have h : env23094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23093_23094 : H12AffineEnvironment.transform 29 43049 env23093 = env23094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 43049 env23093 == env23094) = true)

theorem identity23094 : scanCanonicalize (H12AffineFastState.compose env23094 (packedSelected [0,1,7,8,10,11] rootPS)) = affineNative (2^(15+1) ^^^ 35999) := by decide +kernel

theorem selectedBound23094 : packedSelected [0,1,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env23095 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,1297,32768,35999,4096,48440,1025,32769,4096,46140,5376,3482,8328,5377,2049,1296,1296,43049,1284,47525,257,169,1297,512]

theorem envBound23095 : H12AffineFastState.Bounded env23095 := by
  intro p hp
  have h : env23095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23094_23095 : H12AffineEnvironment.transform 15 35999 env23094 = env23095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35999 env23094 == env23095) = true)

theorem identity23095 : scanCanonicalize (H12AffineFastState.compose env23095 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2048) := by decide +kernel

theorem selectedBound23095 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env23096 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,2048,8192,1297,32768,35999,2048,42296,1025,32769,2048,44092,3328,3482,8328,3329,2049,1296,1296,43049,1284,41381,257,169,1297,512]

theorem envBound23096 : H12AffineFastState.Bounded env23096 := by
  intro p hp
  have h : env23096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23095_23096 : H12AffineEnvironment.transform 11 2048 env23095 = env23096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2048 env23095 == env23096) = true)

theorem identity23096 : scanCanonicalize (H12AffineFastState.compose env23096 (packedSelected [2,4,6,7,12] rootPS)) = affineNative (2^(14+1) ^^^ 1725) := by decide +kernel

theorem selectedBound23096 : packedSelected [2,4,6,7,12] rootPS < 2^1333 := by decide +kernel

def env23097 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,2048,8192,1297,1725,2594,2048,9093,1025,1724,2048,10881,3328,3482,8328,3329,2049,1296,1296,11924,1284,10008,257,169,1297,512]

theorem envBound23097 : H12AffineFastState.Bounded env23097 := by
  intro p hp
  have h : env23097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23096_23097 : H12AffineEnvironment.transform 14 1725 env23096 = env23097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1725 env23096 == env23097) = true)

theorem identity23097 : scanCanonicalize (H12AffineFastState.compose env23097 (packedSelected [2,3,5,6,13] rootPS)) = affineNative (2^(12+1) ^^^ 1564) := by decide +kernel

theorem selectedBound23097 : packedSelected [2,3,5,6,13] rootPS < 2^1333 := by decide +kernel

def env23098 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,2048,1564,1297,1725,2594,2048,1433,1025,1724,2048,3229,3328,3482,1684,3329,2049,1296,1296,2184,1284,260,257,169,1297,512]

theorem envBound23098 : H12AffineFastState.Bounded env23098 := by
  intro p hp
  have h : env23098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23097_23098 : H12AffineEnvironment.transform 12 1564 env23097 = env23098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1564 env23097 == env23098) = true)

theorem identity23098 : scanCanonicalize (H12AffineFastState.compose env23098 (packedSelected [1,2,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound23098 : packedSelected [1,2,5,6] rootPS < 2^1333 := by decide +kernel

def env23099 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1076,1076,1564,1297,1725,1558,1076,1433,1025,1724,1076,169,308,430,1684,309,1077,1296,1296,1212,1284,260,257,169,1297,512]

theorem envBound23099 : H12AffineFastState.Bounded env23099 := by
  intro p hp
  have h : env23099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23098_23099 : H12AffineEnvironment.transform 10 1076 env23098 = env23099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env23098 == env23099) = true)

theorem identity23099 : scanCanonicalize (H12AffineFastState.compose env23099 (packedSelected [0,2,4] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound23099 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env23100 : List Nat := [2,4,8,16,32,17,24,256,512,1024,1076,1076,1564,1297,1573,1558,1076,1281,1025,1572,1076,49,308,310,1548,309,1077,1296,1296,1060,1284,260,257,49,1297,512]

theorem envBound23100 : H12AffineFastState.Bounded env23100 := by
  intro p hp
  have h : env23100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23099_23100 : H12AffineEnvironment.transform 6 24 env23099 = env23100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env23099 == env23100) = true)

theorem identity23100 : scanCanonicalize (H12AffineFastState.compose env23100 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound23100 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env23101 : List Nat := [2,4,8,16,32,17,24,37,512,1024,1076,1076,1564,1076,1573,1558,1076,1060,1025,1572,1076,49,17,19,1548,16,1077,1077,1077,1060,1057,33,36,49,1076,512]

theorem envBound23101 : H12AffineFastState.Bounded env23101 := by
  intro p hp
  have h : env23101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23100_23101 : H12AffineEnvironment.transform 7 37 env23100 = env23101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env23100 == env23101) = true)

theorem identity23101 : scanCanonicalize (H12AffineFastState.compose env23101 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 565) := by decide +kernel

theorem selectedBound23101 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23102 : List Nat := [2,4,8,16,32,17,24,37,512,565,513,513,41,513,16,35,513,529,564,17,513,49,17,19,57,16,512,512,512,529,532,33,36,49,513,512]

theorem envBound23102 : H12AffineFastState.Bounded env23102 := by
  intro p hp
  have h : env23102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23101_23102 : H12AffineEnvironment.transform 9 565 env23101 = env23102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 565 env23101 == env23102) = true)

theorem identity23102 : scanCanonicalize (H12AffineFastState.compose env23102 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound23102 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23103 : List Nat := [2,4,8,0,32,1,8,37,512,549,513,513,41,513,0,35,513,513,548,1,513,33,1,3,41,0,512,512,512,513,516,33,36,33,513,512]

theorem envBound23103 : H12AffineFastState.Bounded env23103 := by
  intro p hp
  have h : env23103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23102_23103 : H12AffineEnvironment.transform 3 0 env23102 = env23103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env23102 == env23103) = true)

theorem identity23103 : scanCanonicalize (H12AffineFastState.compose env23103 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound23103 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23104 : List Nat := [2,4,8,0,0,1,8,5,512,517,513,513,9,513,0,3,513,513,516,1,513,1,1,3,9,0,512,512,512,513,516,1,4,1,513,512]

theorem envBound23104 : H12AffineFastState.Bounded env23104 := by
  intro p hp
  have h : env23104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23103_23104 : H12AffineEnvironment.transform 4 0 env23103 = env23104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env23103 == env23104) = true)

theorem identity23104 : scanCanonicalize (H12AffineFastState.compose env23104 (packedSelected [5] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound23104 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env23105 : List Nat := [2,4,8,0,0,1,8,5,0,5,1,1,9,1,0,3,1,1,4,1,1,1,1,3,9,0,0,0,0,1,4,1,4,1,1,0]

theorem envBound23105 : H12AffineFastState.Bounded env23105 := by
  intro p hp
  have h : env23105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23104_23105 : H12AffineEnvironment.transform 8 0 env23104 = env23105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env23104 == env23105) = true)

def env23106 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,65536,4176,262144,1025,32769,4096,4194304,5457,98565,8328,5377,4456709,1344,1296,1073741824,1284,4294967296,257,4299260335,1344,512]

theorem envBound23106 : H12AffineFastState.Bounded env23106 := by
  intro p hp
  have h : env23106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23088_23106 : H12AffineEnvironment.transform 13 1345 env23088 = env23106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env23088 == env23106) = true)

theorem identity23106 : scanCanonicalize (H12AffineFastState.compose env23106 (packedSelected [0,7,20] rootPS)) = affineNative (2^(11+1) ^^^ 1344) := by decide +kernel

theorem selectedBound23106 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env23107 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,32768,65536,1296,262144,1025,32769,1344,4194304,17,98565,8328,65,4456709,1344,1296,1073741824,1284,4294967296,257,4299260335,1344,512]

theorem envBound23107 : H12AffineFastState.Bounded env23107 := by
  intro p hp
  have h : env23107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23106_23107 : H12AffineEnvironment.transform 11 1344 env23106 = env23107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env23106 == env23107) = true)

theorem identity23107 : scanCanonicalize (H12AffineFastState.compose env23107 (packedSelected [13,21] rootPS)) = affineNative (2^(31+1) ^^^ 4194520) := by decide +kernel

theorem selectedBound23107 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env23108 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,32768,65536,1296,262144,1025,32769,1344,4194304,17,98565,8328,65,4456709,1344,1296,1073741824,1284,4194520,257,98679,1344,512]

theorem envBound23108 : H12AffineFastState.Bounded env23108 := by
  intro p hp
  have h : env23108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23107_23108 : H12AffineEnvironment.transform 31 4194520 env23107 = env23108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 4194520 env23107 == env23108) = true)

theorem identity23108 : scanCanonicalize (H12AffineFastState.compose env23108 (packedSelected [1,3,8,10,13,17,24] rootPS)) = affineNative (2^(29+1) ^^^ 360927) := by decide +kernel

theorem selectedBound23108 : packedSelected [1,3,8,10,13,17,24] rootPS < 2^1333 := by decide +kernel

def env23109 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,32768,65536,1296,262144,1025,32769,1344,4194304,17,98565,8328,65,4456709,1344,1296,360927,1284,4194520,257,98679,1344,512]

theorem envBound23109 : H12AffineFastState.Bounded env23109 := by
  intro p hp
  have h : env23109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23108_23109 : H12AffineEnvironment.transform 29 360927 env23108 = env23109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 360927 env23108 == env23109) = true)

theorem identity23109 : scanCanonicalize (H12AffineFastState.compose env23109 (packedSelected [8,10,13,17,28] rootPS)) = affineNative (2^(15+1) ^^^ 33246) := by decide +kernel

theorem selectedBound23109 : packedSelected [8,10,13,17,28] rootPS < 2^1333 := by decide +kernel

def env23110 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,32768,33246,1296,262144,1025,32769,1344,4194304,17,219,8328,65,4456709,1344,1296,262145,1284,4194520,257,169,1344,512]

theorem envBound23110 : H12AffineFastState.Bounded env23110 := by
  intro p hp
  have h : env23110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23109_23110 : H12AffineEnvironment.transform 15 33246 env23109 = env23110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33246 env23109 == env23110) = true)

theorem identity23110 : scanCanonicalize (H12AffineFastState.compose env23110 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(21+1) ^^^ 41340) := by decide +kernel

theorem selectedBound23110 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env23111 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,32768,33246,1296,262144,1025,32769,1344,41340,17,219,8328,65,303225,1344,1296,262145,1284,41380,257,169,1344,512]

theorem envBound23111 : H12AffineFastState.Bounded env23111 := by
  intro p hp
  have h : env23111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23110_23111 : H12AffineEnvironment.transform 21 41340 env23110 = env23111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41340 env23110 == env23111) = true)

def env23112 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,21777,262144,1025,32769,4096,4194304,5457,16777216,8328,5377,21331969,16385,1296,1073741824,16876545,4294967296,257,4315938986,1345,512]

theorem envBound23112 : H12AffineFastState.Bounded env23112 := by
  intro p hp
  have h : env23112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23086_23112 : H12AffineEnvironment.transform 26 21331969 env23086 = env23112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 21331969 env23086 == env23112) = true)

theorem identity23112 : scanCanonicalize (H12AffineFastState.compose env23112 (packedSelected [7,20,27] rootPS)) = affineNative (2^(23+1) ^^^ 119124) := by decide +kernel

theorem selectedBound23112 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env23113 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,21777,262144,1025,32769,4096,4194304,5457,119124,8328,5377,4477269,16385,1296,1073741824,21845,4294967296,257,4299280894,1345,512]

theorem envBound23113 : H12AffineFastState.Bounded env23113 := by
  intro p hp
  have h : env23113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23112_23113 : H12AffineEnvironment.transform 23 119124 env23112 = env23113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 119124 env23112 == env23113) = true)

theorem identity23113 : scanCanonicalize (H12AffineFastState.compose env23113 (packedSelected [5,8,12,13,15,17,24,28] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound23113 : packedSelected [5,8,12,13,15,17,24,28] rootPS < 2^1333 := by decide +kernel

def env23114 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,21777,43049,1025,32769,4096,4194304,5457,119124,8328,5377,4258172,16385,1296,1073741824,21845,4294967296,257,4299280894,1345,512]

theorem envBound23114 : H12AffineFastState.Bounded env23114 := by
  intro p hp
  have h : env23114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23113_23114 : H12AffineEnvironment.transform 17 43049 env23113 = env23114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env23113 == env23114) = true)

theorem identity23114 : scanCanonicalize (H12AffineFastState.compose env23114 (packedSelected [11,32] rootPS)) = affineNative (2^(29+1) ^^^ 4217173) := by decide +kernel

theorem selectedBound23114 : packedSelected [11,32] rootPS < 2^1333 := by decide +kernel

def env23115 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,21777,43049,1025,32769,4096,4194304,5457,119124,8328,5377,4258172,16385,1296,4217173,21845,4294967296,257,4299280894,1345,512]

theorem envBound23115 : H12AffineFastState.Bounded env23115 := by
  intro p hp
  have h : env23115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23114_23115 : H12AffineEnvironment.transform 29 4217173 env23114 = env23115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4217173 env23114 == env23115) = true)

def env23116 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8232,65536,21777,2049,1025,8233,4096,4194304,5457,94588,8328,5377,4217172,16385,1296,4217173,21845,4294967296,257,4299256278,1345,512]

theorem envBound23116 : H12AffineFastState.Bounded env23116 := by
  intro p hp
  have h : env23116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23115_23116 : H12AffineEnvironment.transform 14 8232 env23115 = env23116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env23115 == env23116) = true)

theorem identity23116 : scanCanonicalize (H12AffineFastState.compose env23116 (packedSelected [4,9] rootPS)) = affineNative (2^(21+1) ^^^ 5140) := by decide +kernel

theorem selectedBound23116 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env23117 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8232,65536,21777,2049,1025,8233,4096,5140,5457,94588,8328,5377,19776,16385,1296,19777,21845,4294967296,257,4295058882,1345,512]

theorem envBound23117 : H12AffineFastState.Bounded env23117 := by
  intro p hp
  have h : env23117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23116_23117 : H12AffineEnvironment.transform 21 5140 env23116 = env23117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 5140 env23116 == env23117) = true)

def env23118 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4096,8232,65536,1297,2049,1025,8233,4096,5140,5457,74108,8328,5377,7488,4097,1296,7489,1365,4294967296,257,4295046594,1345,512]

theorem envBound23118 : H12AffineFastState.Bounded env23118 := by
  intro p hp
  have h : env23118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23117_23118 : H12AffineEnvironment.transform 13 4096 env23117 = env23118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4096 env23117 == env23118) = true)

theorem identity23118 : scanCanonicalize (H12AffineFastState.compose env23118 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound23118 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env23119 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,8232,65536,1297,2049,1025,8233,4096,5140,5376,74029,8328,5377,7441,4097,1296,7440,1284,4294967296,257,4295046547,1296,512]

theorem envBound23119 : H12AffineFastState.Bounded env23119 := by
  intro p hp
  have h : env23119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23118_23119 : H12AffineEnvironment.transform 5 17 env23118 = env23119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23118 == env23119) = true)

theorem identity23119 : scanCanonicalize (H12AffineFastState.compose env23119 (packedSelected [1,3] rootPS)) = affineNative (2^(15+1) ^^^ 8614) := by decide +kernel

theorem selectedBound23119 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env23120 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,8232,8614,1297,2049,1025,8233,4096,5140,5376,139,8328,5377,7441,4097,1296,7440,1284,4294967296,257,4294972469,1296,512]

theorem envBound23120 : H12AffineFastState.Bounded env23120 := by
  intro p hp
  have h : env23120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23119_23120 : H12AffineEnvironment.transform 15 8614 env23119 = env23120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8614 env23119 == env23120) = true)

def env23121 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1296,8232,8614,1297,2049,1025,8233,1296,260,16,139,8328,17,2049,1297,1296,2048,1284,4294967296,257,4294967589,1296,512]

theorem envBound23121 : H12AffineFastState.Bounded env23121 := by
  intro p hp
  have h : env23121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23120_23121 : H12AffineEnvironment.transform 11 1296 env23120 = env23121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env23120 == env23121) = true)

theorem identity23121 : scanCanonicalize (H12AffineFastState.compose env23121 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 10880) := by decide +kernel

theorem selectedBound23121 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23122 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1296,8232,8614,1297,2049,1025,8233,1296,260,16,139,8328,17,2049,1297,1296,2048,1284,10880,257,11173,1296,512]

theorem envBound23122 : H12AffineFastState.Bounded env23122 := by
  intro p hp
  have h : env23122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23121_23122 : H12AffineEnvironment.transform 31 10880 env23121 = env23122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 10880 env23121 == env23122) = true)

theorem identity23122 : scanCanonicalize (H12AffineFastState.compose env23122 (packedSelected [5] rootPS)) = affineNative (2^(12+1) ^^^ 2600) := by decide +kernel

theorem selectedBound23122 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env23123 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,2600,1296,2560,2958,1297,2049,1025,2561,1296,260,16,139,2720,17,2049,1297,1296,2048,1284,168,257,397,1296,512]

theorem envBound23123 : H12AffineFastState.Bounded env23123 := by
  intro p hp
  have h : env23123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23122_23123 : H12AffineEnvironment.transform 12 2600 env23122 = env23123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2600 env23122 == env23123) = true)

theorem identity23123 : scanCanonicalize (H12AffineFastState.compose env23123 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 429) := by decide +kernel

theorem selectedBound23123 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env23124 : List Nat := [2,4,8,16,32,17,128,256,429,1024,2048,1296,2437,1296,2477,2083,1297,2049,1025,2476,1296,260,16,139,2317,17,2049,1297,1296,2048,1284,168,257,397,1296,429]

theorem envBound23124 : H12AffineFastState.Bounded env23124 := by
  intro p hp
  have h : env23124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23123_23124 : H12AffineEnvironment.transform 8 429 env23123 = env23124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 429 env23123 == env23124) = true)

theorem identity23124 : scanCanonicalize (H12AffineFastState.compose env23124 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 141) := by decide +kernel

theorem selectedBound23124 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23125 : List Nat := [2,4,8,16,32,17,128,141,32,1024,2048,1181,2056,1181,2080,2083,1180,2049,1025,2081,1181,137,16,139,2176,17,2049,1180,1181,2048,1161,168,140,0,1181,32]

theorem envBound23125 : H12AffineFastState.Bounded env23125 := by
  intro p hp
  have h : env23125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23124_23125 : H12AffineEnvironment.transform 7 141 env23124 = env23125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 141 env23124 == env23125) = true)

def env23126 : List Nat := [2,4,8,16,0,17,128,141,0,1024,2048,1181,2056,1181,2048,2051,1180,2049,1025,2049,1181,137,16,139,2176,17,2049,1180,1181,2048,1161,136,140,0,1181,0]

theorem envBound23126 : H12AffineFastState.Bounded env23126 := by
  intro p hp
  have h : env23126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23125_23126 : H12AffineEnvironment.transform 4 0 env23125 = env23126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env23125 == env23126) = true)

def env23127 : List Nat := [2,4,8,16,1,17,128,141,1,1024,2048,1181,2056,1181,2049,2050,1180,2049,1025,2048,1181,137,16,139,2176,17,2049,1180,1181,2048,1161,137,140,0,1181,1]

theorem envBound23127 : H12AffineFastState.Bounded env23127 := by
  intro p hp
  have h : env23127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23125_23127 : H12AffineEnvironment.transform 4 1 env23125 = env23127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env23125 == env23127) = true)

theorem identity23127 : scanCanonicalize (H12AffineFastState.compose env23127 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound23127 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23128 : List Nat := [2,4,8,16,1,17,9,4,1,1024,2048,1044,2056,1044,2049,2050,1045,2049,1025,2048,1044,0,16,2,2057,17,2049,1045,1044,2048,1024,0,5,0,1044,1]

theorem envBound23128 : H12AffineFastState.Bounded env23128 := by
  intro p hp
  have h : env23128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23127_23128 : H12AffineEnvironment.transform 6 9 env23127 = env23128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env23127 == env23128) = true)

def leafEnv23128 : List Nat := [2,4,8,16,1,17,9,4,1,1024,2048,1044,2056,1044,2049,2050,1045,2049,1025,2048,1044,0,16,2,1025,2057,1,17,2049,1045,1044,2048,1024,0,5,0,5,2050,1044,1,0,1044,1]

def active23128 : List Nat := [0,1,2,3,9,10]

def tree23128 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood23128 : H12WitnessSearch.Good tree23128 := H12GlobalWitnessIndex.good

theorem leafIdentity23128 : H12AffineFastState.composeSystem env23128 rootObs = leafEnv23128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env23128 rootObs == leafEnv23128) = true)

theorem terminalChecked23128 : H12PackedTerminal.terminalCheckFast leafEnv23128 active23128 tree23128 = true := by decide +kernel

def env23129 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1297,8232,8614,1297,2049,1025,8233,1297,261,17,139,8328,16,2048,1296,1296,2049,1284,4294967296,257,4294967588,1296,512]

theorem envBound23129 : H12AffineFastState.Bounded env23129 := by
  intro p hp
  have h : env23129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23120_23129 : H12AffineEnvironment.transform 11 1297 env23120 = env23129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env23120 == env23129) = true)

theorem identity23129 : scanCanonicalize (H12AffineFastState.compose env23129 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 169) := by decide +kernel

theorem selectedBound23129 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23130 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1297,8232,8614,1297,2049,1025,8233,1297,261,17,139,8328,16,2048,1296,1296,2049,1284,169,257,397,1296,512]

theorem envBound23130 : H12AffineFastState.Bounded env23130 := by
  intro p hp
  have h : env23130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23129_23130 : H12AffineEnvironment.transform 31 169 env23129 = env23130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 169 env23129 == env23130) = true)

theorem identity23130 : scanCanonicalize (H12AffineFastState.compose env23130 (packedSelected [0,4] rootPS)) = affineNative (2^(12+1) ^^^ 2829) := by decide +kernel

theorem selectedBound23130 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env23131 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,2829,1297,2853,2731,1297,2049,1025,2852,1297,261,17,139,2949,16,2048,1296,1296,2049,1284,169,257,397,1296,512]

theorem envBound23131 : H12AffineFastState.Bounded env23131 := by
  intro p hp
  have h : env23131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23130_23131 : H12AffineEnvironment.transform 12 2829 env23130 = env23131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2829 env23130 == env23131) = true)

theorem identity23131 : scanCanonicalize (H12AffineFastState.compose env23131 (packedSelected [5] rootPS)) = affineNative (2^(8+1) ^^^ 428) := by decide +kernel

theorem selectedBound23131 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env23132 : List Nat := [2,4,8,16,32,17,128,256,428,1024,2048,1297,2209,1297,2185,2311,1297,2049,1025,2184,1297,261,17,139,2089,16,2048,1296,1296,2049,1284,169,257,397,1296,428]

theorem envBound23132 : H12AffineFastState.Bounded env23132 := by
  intro p hp
  have h : env23132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23131_23132 : H12AffineEnvironment.transform 8 428 env23131 = env23132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 428 env23131 == env23132) = true)

theorem identity23132 : scanCanonicalize (H12AffineFastState.compose env23132 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 141) := by decide +kernel

theorem selectedBound23132 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23133 : List Nat := [2,4,8,16,32,17,128,141,33,1024,2048,1180,2209,1180,2185,2186,1180,2049,1025,2184,1180,136,17,139,2089,16,2048,1181,1181,2049,1161,169,140,0,1181,33]

theorem envBound23133 : H12AffineFastState.Bounded env23133 := by
  intro p hp
  have h : env23133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23132_23133 : H12AffineEnvironment.transform 7 141 env23132 = env23133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 141 env23132 == env23133) = true)

theorem identity23133 : scanCanonicalize (H12AffineFastState.compose env23133 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound23133 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env23134 : List Nat := [2,4,8,16,1,17,128,141,0,1024,2048,1180,2176,1180,2185,2186,1180,2049,1025,2184,1180,136,17,139,2056,16,2048,1181,1181,2049,1161,136,140,0,1181,0]

theorem envBound23134 : H12AffineFastState.Bounded env23134 := by
  intro p hp
  have h : env23134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23133_23134 : H12AffineEnvironment.transform 4 1 env23133 = env23134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env23133 == env23134) = true)

def leafEnv23134 : List Nat := [2,4,8,16,1,17,128,141,0,1024,2048,1180,2176,1180,2185,2186,1180,2049,1025,2184,1180,136,17,139,1160,2056,1,16,2048,1181,1181,2049,1161,136,140,0,5,2051,1181,0,0,1181,1]

def active23134 : List Nat := [0,1,2,3,6,9,10]

def tree23134 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood23134 : H12WitnessSearch.Good tree23134 := H12GlobalWitnessIndex.good

theorem leafIdentity23134 : H12AffineFastState.composeSystem env23134 rootObs = leafEnv23134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env23134 rootObs == leafEnv23134) = true)

theorem terminalChecked23134 : H12PackedTerminal.terminalCheckFast leafEnv23134 active23134 tree23134 = true := by decide +kernel

def env23135 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4097,8232,65536,1296,2049,1025,8233,4096,5140,5457,74109,8328,5377,7489,4096,1296,7488,1364,4294967296,257,4295046595,1345,512]

theorem envBound23135 : H12AffineFastState.Bounded env23135 := by
  intro p hp
  have h : env23135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23117_23135 : H12AffineEnvironment.transform 13 4097 env23117 = env23135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4097 env23117 == env23135) = true)

def env23136 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,8232,65536,1296,2049,1025,8233,1344,340,17,74109,8328,65,2049,1344,1296,2048,1364,4294967296,257,4295041155,1345,512]

theorem envBound23136 : H12AffineFastState.Bounded env23136 := by
  intro p hp
  have h : env23136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23135_23136 : H12AffineEnvironment.transform 11 1344 env23135 = env23136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env23135 == env23136) = true)

theorem identity23136 : scanCanonicalize (H12AffineFastState.compose env23136 (packedSelected [13,21] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound23136 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env23137 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1297,8232,65536,1296,2049,1025,8233,1296,260,17,74029,8328,17,2049,1296,1296,2048,1284,4294967296,257,4295041155,1297,512]

theorem envBound23137 : H12AffineFastState.Bounded env23137 := by
  intro p hp
  have h : env23137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23136_23137 : H12AffineEnvironment.transform 5 16 env23136 = env23137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env23136 == env23137) = true)

theorem identity23137 : scanCanonicalize (H12AffineFastState.compose env23137 (packedSelected [5] rootPS)) = affineNative (2^(12+1) ^^^ 2208) := by decide +kernel

theorem selectedBound23137 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env23138 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,2208,1297,2184,65536,1296,2049,1025,2185,1296,260,17,67981,2088,17,2049,1296,1296,2048,1284,4294967296,257,4295034915,1297,512]

theorem envBound23138 : H12AffineFastState.Bounded env23138 := by
  intro p hp
  have h : env23138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23137_23138 : H12AffineEnvironment.transform 12 2208 env23137 = env23138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2208 env23137 == env23138) = true)

theorem identity23138 : scanCanonicalize (H12AffineFastState.compose env23138 (packedSelected [1,13] rootPS)) = affineNative (2^(15+1) ^^^ 2310) := by decide +kernel

theorem selectedBound23138 : packedSelected [1,13] rootPS < 2^1333 := by decide +kernel

def env23139 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,2208,1297,2184,2310,1296,2049,1025,2185,1296,260,17,139,2088,17,2049,1296,1296,2048,1284,4294967296,257,4294967589,1297,512]

theorem envBound23139 : H12AffineFastState.Bounded env23139 := by
  intro p hp
  have h : env23139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23138_23139 : H12AffineEnvironment.transform 15 2310 env23138 = env23139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2310 env23138 == env23139) = true)

theorem identity23139 : scanCanonicalize (H12AffineFastState.compose env23139 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 397) := by decide +kernel

theorem selectedBound23139 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23140 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,2208,1297,2184,2310,1296,2049,1025,2185,1296,260,17,139,2088,17,2049,1296,1296,2048,1284,397,257,168,1297,512]

theorem envBound23140 : H12AffineFastState.Bounded env23140 := by
  intro p hp
  have h : env23140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23139_23140 : H12AffineEnvironment.transform 31 397 env23139 = env23140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 397 env23139 == env23140) = true)

theorem identity23140 : scanCanonicalize (H12AffineFastState.compose env23140 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound23140 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env23141 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,2208,1297,2184,2310,1296,2049,1025,2185,1296,260,17,139,2088,17,2049,1296,1296,2048,1284,397,257,168,1297,137]

theorem envBound23141 : H12AffineFastState.Bounded env23141 := by
  intro p hp
  have h : env23141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23140_23141 : H12AffineEnvironment.transform 8 137 env23140 = env23141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env23140 == env23141) = true)

theorem identity23141 : scanCanonicalize (H12AffineFastState.compose env23141 (packedSelected [0,2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound23141 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env23142 : List Nat := [2,4,8,16,32,16,128,37,137,1024,2048,1077,2208,1076,2184,2083,1077,2049,1025,2185,1077,33,17,139,2088,17,2049,1077,1077,2048,1057,168,36,168,1076,137]

theorem envBound23142 : H12AffineFastState.Bounded env23142 := by
  intro p hp
  have h : env23142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23141_23142 : H12AffineEnvironment.transform 7 37 env23141 = env23142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env23141 == env23142) = true)

theorem identity23142 : scanCanonicalize (H12AffineFastState.compose env23142 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound23142 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23143 : List Nat := [2,4,8,16,0,16,128,5,137,1024,2048,1045,2176,1044,2184,2051,1045,2049,1025,2185,1045,1,17,139,2056,17,2049,1045,1045,2048,1025,136,4,136,1044,137]

theorem envBound23143 : H12AffineFastState.Bounded env23143 := by
  intro p hp
  have h : env23143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23142_23143 : H12AffineEnvironment.transform 4 0 env23142 = env23143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env23142 == env23143) = true)

def leafEnv23143 : List Nat := [2,4,8,16,0,16,128,5,137,1024,2048,1045,2176,1044,2184,2051,1045,2049,1025,2185,1045,1,17,139,1024,2056,1,17,2049,1045,1045,2048,1025,136,4,136,5,2186,1044,137,0,1045,1]

def active23143 : List Nat := [0,1,2,3,6,9,10]

def tree23143 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood23143 : H12WitnessSearch.Good tree23143 := H12GlobalWitnessIndex.good

theorem leafIdentity23143 : H12AffineFastState.composeSystem env23143 rootObs = leafEnv23143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env23143 rootObs == leafEnv23143) = true)

theorem terminalChecked23143 : H12PackedTerminal.terminalCheckFast leafEnv23143 active23143 tree23143 = true := by decide +kernel

def env23144 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,8232,65536,1296,2049,1025,8233,1345,341,16,74109,8328,64,2048,1345,1296,2049,1364,4294967296,257,4295041154,1345,512]

theorem envBound23144 : H12AffineFastState.Bounded env23144 := by
  intro p hp
  have h : env23144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23135_23144 : H12AffineEnvironment.transform 11 1345 env23135 = env23144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env23135 == env23144) = true)

theorem identity23144 : scanCanonicalize (H12AffineFastState.compose env23144 (packedSelected [11] rootPS)) = affineNative (2^(12+1) ^^^ 2397) := by decide +kernel

theorem selectedBound23144 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env23145 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,2397,1344,2421,65536,1296,2049,1025,2420,1345,341,16,67616,2517,64,2048,1345,1296,2049,1364,4294967296,257,4295035359,1345,512]

theorem envBound23145 : H12AffineFastState.Bounded env23145 := by
  intro p hp
  have h : env23145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23144_23145 : H12AffineEnvironment.transform 12 2397 env23144 = env23145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2397 env23144 == env23145) = true)

theorem identity23145 : scanCanonicalize (H12AffineFastState.compose env23145 (packedSelected [13,21] rootPS)) = affineNative (2^(15+1) ^^^ 2299) := by decide +kernel

theorem selectedBound23145 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env23146 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,2397,1344,2421,2299,1296,2049,1025,2420,1345,341,16,219,2517,64,2048,1345,1296,2049,1364,4294967296,257,4294967588,1345,512]

theorem envBound23146 : H12AffineFastState.Bounded env23146 := by
  intro p hp
  have h : env23146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23145_23146 : H12AffineEnvironment.transform 15 2299 env23145 = env23146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2299 env23145 == env23146) = true)

theorem identity23146 : scanCanonicalize (H12AffineFastState.compose env23146 (packedSelected [3,5,10,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound23146 : packedSelected [3,5,10,12] rootPS < 2^1333 := by decide +kernel

def env23147 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,2317,1296,2341,2219,1296,2049,1025,2340,1297,261,16,139,2437,16,2048,1297,1296,2049,1284,4294967296,257,4294967588,1297,512]

theorem envBound23147 : H12AffineFastState.Bounded env23147 := by
  intro p hp
  have h : env23147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23146_23147 : H12AffineEnvironment.transform 5 16 env23146 = env23147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env23146 == env23147) = true)

theorem identity23147 : scanCanonicalize (H12AffineFastState.compose env23147 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 772) := by decide +kernel

theorem selectedBound23147 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23148 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,2317,1296,2341,2219,1296,2049,1025,2340,1297,261,16,139,2437,16,2048,1297,1296,2049,1284,772,257,544,1297,512]

theorem envBound23148 : H12AffineFastState.Bounded env23148 := by
  intro p hp
  have h : env23148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23147_23148 : H12AffineEnvironment.transform 31 772 env23147 = env23148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 772 env23147 == env23148) = true)

theorem identity23148 : scanCanonicalize (H12AffineFastState.compose env23148 (packedSelected [5] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound23148 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env23149 : List Nat := [2,4,8,16,32,16,128,256,292,1024,2048,1297,2317,1296,2341,2219,1296,2049,1025,2340,1297,261,16,139,2437,16,2048,1297,1296,2049,1284,32,257,260,1297,292]

theorem envBound23149 : H12AffineFastState.Bounded env23149 := by
  intro p hp
  have h : env23149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23148_23149 : H12AffineEnvironment.transform 8 292 env23148 = env23149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env23148 == env23149) = true)

theorem identity23149 : scanCanonicalize (H12AffineFastState.compose env23149 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound23149 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23150 : List Nat := [2,4,8,16,32,16,128,4,32,1024,2048,1045,2057,1044,2081,2219,1044,2049,1025,2080,1045,1,16,139,2177,16,2048,1045,1044,2049,1024,32,5,0,1045,32]

theorem envBound23150 : H12AffineFastState.Bounded env23150 := by
  intro p hp
  have h : env23150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23149_23150 : H12AffineEnvironment.transform 7 4 env23149 = env23150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env23149 == env23150) = true)

theorem identity23150 : scanCanonicalize (H12AffineFastState.compose env23150 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound23150 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23151 : List Nat := [2,4,8,16,1,16,128,4,1,1024,2048,1045,2057,1044,2048,2186,1044,2049,1025,2049,1045,1,16,139,2177,16,2048,1045,1044,2049,1024,1,5,0,1045,1]

theorem envBound23151 : H12AffineFastState.Bounded env23151 := by
  intro p hp
  have h : env23151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23150_23151 : H12AffineEnvironment.transform 4 1 env23150 = env23151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env23150 == env23151) = true)

theorem identity23151 : scanCanonicalize (H12AffineFastState.compose env23151 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound23151 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env23152 : List Nat := [2,4,8,16,1,16,8,4,1,1024,2048,1045,2057,1044,2048,2050,1044,2049,1025,2049,1045,1,16,3,2057,16,2048,1045,1044,2049,1024,1,5,0,1045,1]

theorem envBound23152 : H12AffineFastState.Bounded env23152 := by
  intro p hp
  have h : env23152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23151_23152 : H12AffineEnvironment.transform 6 8 env23151 = env23152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env23151 == env23152) = true)

def leafEnv23152 : List Nat := [2,4,8,16,1,16,8,4,1,1024,2048,1045,2057,1044,2048,2050,1044,2049,1025,2049,1045,1,16,3,1025,2057,1,16,2048,1045,1044,2049,1024,1,5,0,5,2051,1045,1,0,1044,1]

def active23152 : List Nat := [0,1,2,3,9,10]

def tree23152 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood23152 : H12WitnessSearch.Good tree23152 := H12GlobalWitnessIndex.good

theorem leafIdentity23152 : H12AffineFastState.composeSystem env23152 rootObs = leafEnv23152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env23152 rootObs == leafEnv23152) = true)

theorem terminalChecked23152 : H12PackedTerminal.terminalCheckFast leafEnv23152 active23152 tree23152 = true := by decide +kernel

def env23153 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8233,65536,21777,2048,1025,8232,4096,4194304,5457,94589,8328,5377,4217173,16385,1296,4217173,21845,4294967296,257,4299256279,1345,512]

theorem envBound23153 : H12AffineFastState.Bounded env23153 := by
  intro p hp
  have h : env23153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23115_23153 : H12AffineEnvironment.transform 14 8233 env23115 = env23153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env23115 == env23153) = true)

theorem identity23153 : scanCanonicalize (H12AffineFastState.compose env23153 (packedSelected [4,9] rootPS)) = affineNative (2^(13+1) ^^^ 1345) := by decide +kernel

theorem selectedBound23153 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env23154 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,8233,65536,4176,2048,1025,8232,4096,4194304,5457,78908,8328,5377,4201492,1344,1296,4201492,4116,4294967296,257,4299240598,1345,512]

theorem envBound23154 : H12AffineFastState.Bounded env23154 := by
  intro p hp
  have h : env23154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23153_23154 : H12AffineEnvironment.transform 13 1345 env23153 = env23154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env23153 == env23154) = true)

theorem identity23154 : scanCanonicalize (H12AffineFastState.compose env23154 (packedSelected [12,15] rootPS)) = affineNative (2^(21+1) ^^^ 5141) := by decide +kernel

theorem selectedBound23154 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env23155 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,8233,65536,4176,2048,1025,8232,4096,5141,5457,78908,8328,5377,2049,1344,1296,2049,4116,4294967296,257,4295041155,1345,512]

theorem envBound23155 : H12AffineFastState.Bounded env23155 := by
  intro p hp
  have h : env23155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23154_23155 : H12AffineEnvironment.transform 21 5141 env23154 = env23155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 5141 env23154 == env23155) = true)

theorem identity23155 : scanCanonicalize (H12AffineFastState.compose env23155 (packedSelected [1,3,5,8,13,21] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound23155 : packedSelected [1,3,5,8,13,21] rootPS < 2^1333 := by decide +kernel

def env23156 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1296,8192,1345,8233,65536,1344,2048,1025,8232,1296,261,65,74028,8328,17,2049,1344,1296,2049,1284,4294967296,257,4295041155,1345,512]

theorem envBound23156 : H12AffineFastState.Bounded env23156 := by
  intro p hp
  have h : env23156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23155_23156 : H12AffineEnvironment.transform 11 1296 env23155 = env23156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env23155 == env23156) = true)

theorem identity23156 : scanCanonicalize (H12AffineFastState.compose env23156 (packedSelected [1,5,13] rootPS)) = affineNative (2^(15+1) ^^^ 8615) := by decide +kernel

theorem selectedBound23156 : packedSelected [1,5,13] rootPS < 2^1333 := by decide +kernel

def env23157 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1296,8192,1345,8233,8615,1344,2048,1025,8232,1296,261,65,139,8328,17,2049,1344,1296,2049,1284,4294967296,257,4294967588,1345,512]

theorem envBound23157 : H12AffineFastState.Bounded env23157 := by
  intro p hp
  have h : env23157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23156_23157 : H12AffineEnvironment.transform 15 8615 env23156 = env23157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8615 env23156 == env23157) = true)

def env23158 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1296,8192,1345,8233,8495,1344,2048,1025,8232,1296,261,65,3,8192,17,2049,1344,1296,2049,1284,4294967296,257,4294967588,1345,512]

theorem envBound23158 : H12AffineFastState.Bounded env23158 := by
  intro p hp
  have h : env23158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23157_23158 : H12AffineEnvironment.transform 6 8 env23157 = env23158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env23157 == env23158) = true)

theorem identity23158 : scanCanonicalize (H12AffineFastState.compose env23158 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 512) := by decide +kernel

theorem selectedBound23158 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23159 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1296,8192,1345,8233,8495,1344,2048,1025,8232,1296,261,65,3,8192,17,2049,1344,1296,2049,1284,512,257,804,1345,512]

theorem envBound23159 : H12AffineFastState.Bounded env23159 := by
  intro p hp
  have h : env23159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23158_23159 : H12AffineEnvironment.transform 31 512 env23158 = env23159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 512 env23158 == env23159) = true)

theorem identity23159 : scanCanonicalize (H12AffineFastState.compose env23159 (packedSelected [2,4] rootPS)) = affineNative (2^(8+1) ^^^ 81) := by decide +kernel

theorem selectedBound23159 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env23160 : List Nat := [2,4,8,16,32,64,8,256,81,1024,2048,1296,8192,1345,8233,8495,1344,2048,1025,8232,1296,261,65,3,8192,17,2049,1344,1296,2049,1284,81,257,373,1345,81]

theorem envBound23160 : H12AffineFastState.Bounded env23160 := by
  intro p hp
  have h : env23160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23159_23160 : H12AffineEnvironment.transform 8 81 env23159 = env23160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env23159 == env23160) = true)

theorem identity23160 : scanCanonicalize (H12AffineFastState.compose env23160 (packedSelected [5] rootPS)) = affineNative (2^(12+1) ^^^ 2089) := by decide +kernel

theorem selectedBound23160 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env23161 : List Nat := [2,4,8,16,32,64,8,256,81,1024,2048,1296,2089,1345,2048,2310,1344,2048,1025,2049,1296,261,65,3,2089,17,2049,1344,1296,2049,1284,81,257,373,1345,81]

theorem envBound23161 : H12AffineFastState.Bounded env23161 := by
  intro p hp
  have h : env23161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23160_23161 : H12AffineEnvironment.transform 12 2089 env23160 = env23161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2089 env23160 == env23161) = true)

def env23162 : List Nat := [2,4,8,16,32,16,8,256,1,1024,2048,1296,2089,1297,2048,2310,1296,2048,1025,2049,1296,261,17,3,2089,17,2049,1296,1296,2049,1284,1,257,293,1297,1]

theorem envBound23162 : H12AffineFastState.Bounded env23162 := by
  intro p hp
  have h : env23162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23161_23162 : H12AffineEnvironment.transform 5 16 env23161 = env23162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env23161 == env23162) = true)

theorem identity23162 : scanCanonicalize (H12AffineFastState.compose env23162 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound23162 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23163 : List Nat := [2,4,8,16,32,16,8,5,1,1024,2048,1045,2089,1044,2048,2051,1045,2048,1025,2049,1045,0,17,3,2089,17,2049,1045,1045,2049,1025,1,4,32,1044,1]

theorem envBound23163 : H12AffineFastState.Bounded env23163 := by
  intro p hp
  have h : env23163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23162_23163 : H12AffineEnvironment.transform 7 5 env23162 = env23163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env23162 == env23163) = true)

def leafEnv23163 : List Nat := [2,4,8,16,32,16,8,5,1,1024,2048,1045,2089,1044,2048,2051,1045,2048,1025,2049,1045,0,17,3,1024,2089,1,17,2049,1045,1045,2049,1025,1,4,32,5,2050,1044,1,0,1045,1]

def active23163 : List Nat := [0,1,2,3,4,9,10]

def tree23163 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood23163 : H12WitnessSearch.Good tree23163 := H12GlobalWitnessIndex.good

theorem leafIdentity23163 : H12AffineFastState.composeSystem env23163 rootObs = leafEnv23163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env23163 rootObs == leafEnv23163) = true)

theorem terminalChecked23163 : H12PackedTerminal.terminalCheckFast leafEnv23163 active23163 tree23163 = true := by decide +kernel

def env23164 : List Nat := [2,4,8,16,32,17,8,256,0,1024,2048,1296,2089,1296,2048,2310,1297,2048,1025,2049,1296,261,16,3,2089,17,2049,1297,1296,2049,1284,0,257,292,1296,0]

theorem envBound23164 : H12AffineFastState.Bounded env23164 := by
  intro p hp
  have h : env23164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23161_23164 : H12AffineEnvironment.transform 5 17 env23161 = env23164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23161 == env23164) = true)

theorem identity23164 : scanCanonicalize (H12AffineFastState.compose env23164 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound23164 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23165 : List Nat := [2,4,8,16,0,17,8,256,0,1024,2048,1296,2057,1296,2048,2310,1297,2048,1025,2049,1296,261,16,3,2057,17,2049,1297,1296,2049,1284,0,257,260,1296,0]

theorem envBound23165 : H12AffineFastState.Bounded env23165 := by
  intro p hp
  have h : env23165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23164_23165 : H12AffineEnvironment.transform 4 0 env23164 = env23165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env23164 == env23165) = true)

theorem identity23165 : scanCanonicalize (H12AffineFastState.compose env23165 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound23165 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23166 : List Nat := [2,4,8,16,0,17,8,4,0,1024,2048,1044,2057,1044,2048,2050,1045,2048,1025,2049,1044,1,16,3,2057,17,2049,1045,1044,2049,1024,0,5,0,1044,0]

theorem envBound23166 : H12AffineFastState.Bounded env23166 := by
  intro p hp
  have h : env23166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23165_23166 : H12AffineEnvironment.transform 7 4 env23165 = env23166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env23165 == env23166) = true)

def leafEnv23166 : List Nat := [2,4,8,16,0,17,8,4,0,1024,2048,1044,2057,1044,2048,2050,1045,2048,1025,2049,1044,1,16,3,1025,2057,1,17,2049,1045,1044,2049,1024,0,5,0,5,2051,1044,0,0,1044,1]

def active23166 : List Nat := [0,1,2,3,9,10]

def tree23166 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood23166 : H12WitnessSearch.Good tree23166 := H12GlobalWitnessIndex.good

theorem leafIdentity23166 : H12AffineFastState.composeSystem env23166 rootObs = leafEnv23166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env23166 rootObs == leafEnv23166) = true)

theorem terminalChecked23166 : H12PackedTerminal.terminalCheckFast leafEnv23166 active23166 tree23166 = true := by decide +kernel

def env23167 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1296,8192,1345,8233,8494,1344,2048,1025,8232,1296,261,65,2,8193,17,2049,1344,1296,2049,1284,4294967296,257,4294967588,1345,512]

theorem envBound23167 : H12AffineFastState.Bounded env23167 := by
  intro p hp
  have h : env23167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23157_23167 : H12AffineEnvironment.transform 6 9 env23157 = env23167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env23157 == env23167) = true)

theorem identity23167 : scanCanonicalize (H12AffineFastState.compose env23167 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 293) := by decide +kernel

theorem selectedBound23167 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23168 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1296,8192,1345,8233,8494,1344,2048,1025,8232,1296,261,65,2,8193,17,2049,1344,1296,2049,1284,293,257,1,1345,512]

theorem envBound23168 : H12AffineFastState.Bounded env23168 := by
  intro p hp
  have h : env23168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23167_23168 : H12AffineEnvironment.transform 31 293 env23167 = env23168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 293 env23167 == env23168) = true)

theorem identity23168 : scanCanonicalize (H12AffineFastState.compose env23168 (packedSelected [2,4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound23168 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env23169 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,1296,8192,1296,8233,8494,1297,2048,1025,8232,1296,261,16,2,8193,17,2049,1297,1296,2049,1284,293,257,1,1296,512]

theorem envBound23169 : H12AffineFastState.Bounded env23169 := by
  intro p hp
  have h : env23169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23168_23169 : H12AffineEnvironment.transform 5 17 env23168 = env23169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23168 == env23169) = true)

theorem identity23169 : scanCanonicalize (H12AffineFastState.compose env23169 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 2861) := by decide +kernel

theorem selectedBound23169 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23170 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,1296,2861,1296,2820,2563,1297,2048,1025,2821,1296,261,16,2,2860,17,2049,1297,1296,2049,1284,293,257,1,1296,512]

theorem envBound23170 : H12AffineFastState.Bounded env23170 := by
  intro p hp
  have h : env23170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23169_23170 : H12AffineEnvironment.transform 12 2861 env23169 = env23170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2861 env23169 == env23170) = true)

theorem identity23170 : scanCanonicalize (H12AffineFastState.compose env23170 (packedSelected [5] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound23170 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env23171 : List Nat := [2,4,8,16,32,17,9,4,512,1024,2048,1044,2601,1044,2560,2563,1045,2048,1025,2561,1044,1,16,2,2600,17,2049,1045,1044,2049,1024,33,5,1,1044,512]

theorem envBound23171 : H12AffineFastState.Bounded env23171 := by
  intro p hp
  have h : env23171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23170_23171 : H12AffineEnvironment.transform 7 4 env23170 = env23171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env23170 == env23171) = true)

theorem identity23171 : scanCanonicalize (H12AffineFastState.compose env23171 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound23171 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23172 : List Nat := [2,4,8,16,32,17,9,4,33,1024,2048,1044,2056,1044,2081,2082,1045,2048,1025,2080,1044,1,16,2,2057,17,2049,1045,1044,2049,1024,33,5,1,1044,33]

theorem envBound23172 : H12AffineFastState.Bounded env23172 := by
  intro p hp
  have h : env23172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23171_23172 : H12AffineEnvironment.transform 8 33 env23171 = env23172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env23171 == env23172) = true)

def leafEnv23172 : List Nat := [2,4,8,16,32,17,9,4,33,1024,2048,1044,2056,1044,2081,2082,1045,2048,1025,2080,1044,1,16,2,1025,2057,1,17,2049,1045,1044,2049,1024,33,5,1,5,2082,1044,33,0,1044,1]

def active23172 : List Nat := [0,1,2,3,4,9,10]

def tree23172 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood23172 : H12WitnessSearch.Good tree23172 := H12GlobalWitnessIndex.good

theorem leafIdentity23172 : H12AffineFastState.composeSystem env23172 rootObs = leafEnv23172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env23172 rootObs == leafEnv23172) = true)

theorem terminalChecked23172 : H12PackedTerminal.terminalCheckFast leafEnv23172 active23172 tree23172 = true := by decide +kernel

def env23173 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,4194304,8388608,16777216,8328,8914001,134217728,8519745,676865,1073741824,25412672,4294967296,8536384,4315938986,164610305,512]

theorem envBound23173 : H12AffineFastState.Bounded env23173 := by
  intro p hp
  have h : env23173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22966_23173 : H12AffineEnvironment.transform 20 4097 env22966 = env23173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env22966 == env23173) = true)

theorem identity23173 : scanCanonicalize (H12AffineFastState.compose env23173 (packedSelected [14] rootPS)) = affineNative (2^(26+1) ^^^ 29726032) := by decide +kernel

theorem selectedBound23173 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env23174 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,4194304,8388608,16777216,8328,8914001,29726032,8519745,676865,1073741824,25412672,4294967296,8536384,4315938986,676945,512]

theorem envBound23174 : H12AffineFastState.Bounded env23174 := by
  intro p hp
  have h : env23174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23173_23174 : H12AffineEnvironment.transform 26 29726032 env23173 = env23174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 29726032 env23173 == env23174) = true)

def env23175 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,4194304,147520,16777216,8328,672785,21484816,16385,676865,1073741824,16876544,4294967296,256,4315938986,676945,512]

theorem envBound23175 : H12AffineFastState.Bounded env23175 := by
  intro p hp
  have h : env23175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23174_23175 : H12AffineEnvironment.transform 22 147520 env23174 = env23175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147520 env23174 == env23175) = true)

def env23176 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,524288,32769,4097,4194304,17664,16777216,8328,541009,21352528,16385,545089,1073741824,16876544,4294967296,256,4315938986,545041,512]

theorem envBound23176 : H12AffineFastState.Bounded env23176 := by
  intro p hp
  have h : env23176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23175_23176 : H12AffineEnvironment.transform 16 1344 env23175 = env23176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env23175 == env23176) = true)

def env23177 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32769,4097,4194304,17665,16777216,8328,541008,21352529,16385,545088,1073741824,16876544,4294967296,256,4315938986,545040,512]

theorem envBound23177 : H12AffineFastState.Bounded env23177 := by
  intro p hp
  have h : env23177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23175_23177 : H12AffineEnvironment.transform 16 1345 env23175 = env23177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env23175 == env23177) = true)

theorem identity23177 : scanCanonicalize (H12AffineFastState.compose env23177 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(18+1) ^^^ 21585) := by decide +kernel

theorem selectedBound23177 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env23178 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,21585,32769,4097,4194304,17665,16777216,8328,5377,21352529,16385,1297,1073741824,16876544,4294967296,256,4315938986,1345,512]

theorem envBound23178 : H12AffineFastState.Bounded env23178 := by
  intro p hp
  have h : env23178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23177_23178 : H12AffineEnvironment.transform 18 21585 env23177 = env23178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21585 env23177 == env23178) = true)

theorem identity23178 : scanCanonicalize (H12AffineFastState.compose env23178 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 4177) := by decide +kernel

theorem selectedBound23178 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env23179 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,1345,262144,1024,32769,4097,4194304,5456,16777216,8328,5377,21331968,4176,1297,1073741824,16876544,4294967296,256,4315938986,1345,512]

theorem envBound23179 : H12AffineFastState.Bounded env23179 := by
  intro p hp
  have h : env23179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23178_23179 : H12AffineEnvironment.transform 13 4177 env23178 = env23179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env23178 == env23179) = true)

def env23180 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,65536,1345,262144,1024,32769,1345,4194304,16,16777216,8328,65,21331968,1296,1297,1073741824,16876544,4294967296,256,4315938986,1345,512]

theorem envBound23180 : H12AffineFastState.Bounded env23180 := by
  intro p hp
  have h : env23180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23179_23180 : H12AffineEnvironment.transform 11 1344 env23179 = env23180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env23179 == env23180) = true)

theorem identity23180 : scanCanonicalize (H12AffineFastState.compose env23180 (packedSelected [0,7,20] rootPS)) = affineNative (2^(23+1) ^^^ 98645) := by decide +kernel

theorem selectedBound23180 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env23181 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,65536,1345,262144,1024,32769,1345,4194304,16,98645,8328,65,4456789,1296,1297,1073741824,1365,4294967296,256,4299260415,1345,512]

theorem envBound23181 : H12AffineFastState.Bounded env23181 := by
  intro p hp
  have h : env23181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23180_23181 : H12AffineEnvironment.transform 23 98645 env23180 = env23181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98645 env23180 == env23181) = true)

theorem identity23181 : scanCanonicalize (H12AffineFastState.compose env23181 (packedSelected [13,17] rootPS)) = affineNative (2^(31+1) ^^^ 1077979376) := by decide +kernel

theorem selectedBound23181 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env23182 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,65536,1345,262144,1024,32769,1345,4194304,16,98645,8328,65,4456789,1296,1297,1073741824,1365,1077979376,256,1073817871,1345,512]

theorem envBound23182 : H12AffineFastState.Bounded env23182 := by
  intro p hp
  have h : env23182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23181_23182 : H12AffineEnvironment.transform 31 1077979376 env23181 = env23182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1077979376 env23181 == env23182) = true)

theorem identity23182 : scanCanonicalize (H12AffineFastState.compose env23182 (packedSelected [13,21] rootPS)) = affineNative (2^(29+1) ^^^ 43129) := by decide +kernel

theorem selectedBound23182 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env23183 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,65536,1345,262144,1024,32769,1345,4194304,16,98645,8328,65,4456789,1296,1297,43129,1365,4194441,256,98678,1345,512]

theorem envBound23183 : H12AffineFastState.Bounded env23183 := by
  intro p hp
  have h : env23183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23182_23183 : H12AffineEnvironment.transform 29 43129 env23182 = env23183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 43129 env23182 == env23183) = true)

theorem identity23183 : scanCanonicalize (H12AffineFastState.compose env23183 (packedSelected [1,3,15,24,28,38] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound23183 : packedSelected [1,3,15,24,28,38] rootPS < 2^1333 := by decide +kernel

def env23184 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1297,32768,65536,1297,262144,1024,32769,1297,4194304,16,98565,8328,17,4456709,1296,1297,43049,1285,4194441,256,98598,1297,512]

theorem envBound23184 : H12AffineFastState.Bounded env23184 := by
  intro p hp
  have h : env23184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23183_23184 : H12AffineEnvironment.transform 5 16 env23183 = env23184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env23183 == env23184) = true)

theorem identity23184 : scanCanonicalize (H12AffineFastState.compose env23184 (packedSelected [1,3,5] rootPS)) = affineNative (2^(21+1) ^^^ 327689) := by decide +kernel

theorem selectedBound23184 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env23185 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1297,32768,65536,1297,262144,1024,32769,1297,327689,16,98565,8328,17,65804,1296,1297,43049,1285,327808,256,98598,1297,512]

theorem envBound23185 : H12AffineFastState.Bounded env23185 := by
  intro p hp
  have h : env23185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23184_23185 : H12AffineEnvironment.transform 21 327689 env23184 = env23185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 327689 env23184 == env23185) = true)

theorem identity23185 : scanCanonicalize (H12AffineFastState.compose env23185 (packedSelected [1,3,8] rootPS)) = affineNative (2^(14+1) ^^^ 9092) := by decide +kernel

theorem selectedBound23185 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env23186 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1297,9092,65536,1297,262144,1024,9093,1297,327689,16,74369,8328,17,65804,1296,1297,2989,1285,327808,256,74402,1297,512]

theorem envBound23186 : H12AffineFastState.Bounded env23186 := by
  intro p hp
  have h : env23186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23185_23186 : H12AffineEnvironment.transform 14 9092 env23185 = env23186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9092 env23185 == env23186) = true)

theorem identity23186 : scanCanonicalize (H12AffineFastState.compose env23186 (packedSelected [1,12,13] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound23186 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env23187 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,8192,1297,8461,65536,1297,262144,1024,8460,1297,327689,16,73736,8328,17,65804,1296,1297,2340,1285,327808,256,73771,1297,137]

theorem envBound23187 : H12AffineFastState.Bounded env23187 := by
  intro p hp
  have h : env23187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23186_23187 : H12AffineEnvironment.transform 8 137 env23186 = env23187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env23186 == env23187) = true)

theorem identity23187 : scanCanonicalize (H12AffineFastState.compose env23187 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 8363) := by decide +kernel

theorem selectedBound23187 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env23188 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,8192,1297,8461,65536,1297,8363,1024,8460,1297,73890,16,73736,8328,17,65804,1296,1297,2340,1285,73771,256,73771,1297,137]

theorem envBound23188 : H12AffineFastState.Bounded env23188 := by
  intro p hp
  have h : env23188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23187_23188 : H12AffineEnvironment.transform 17 8363 env23187 = env23188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8363 env23187 == env23188) = true)

theorem identity23188 : scanCanonicalize (H12AffineFastState.compose env23188 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound23188 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env23189 : List Nat := [2,4,8,16,32,16,128,256,137,5,2048,277,8192,276,8461,65536,276,8363,5,8460,276,73890,16,73736,8328,17,65804,277,276,2340,256,73771,256,73771,276,137]

theorem envBound23189 : H12AffineFastState.Bounded env23189 := by
  intro p hp
  have h : env23189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23188_23189 : H12AffineEnvironment.transform 9 5 env23188 = env23189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env23188 == env23189) = true)

theorem identity23189 : scanCanonicalize (H12AffineFastState.compose env23189 (packedSelected [3,12] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound23189 : packedSelected [3,12] rootPS < 2^1333 := by decide +kernel

def env23190 : List Nat := [2,4,8,16,32,16,128,256,137,5,2048,277,268,276,1,65536,276,423,5,0,276,65966,16,65796,388,17,65804,277,276,2340,256,65831,256,65831,276,137]

theorem envBound23190 : H12AffineFastState.Bounded env23190 := by
  intro p hp
  have h : env23190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23189_23190 : H12AffineEnvironment.transform 12 268 env23189 = env23190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env23189 == env23190) = true)

theorem identity23190 : scanCanonicalize (H12AffineFastState.compose env23190 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 154) := by decide +kernel

theorem selectedBound23190 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23191 : List Nat := [2,4,8,16,32,16,128,256,137,5,2048,277,268,276,1,154,276,423,5,0,276,308,16,414,388,17,406,277,276,2340,256,445,256,445,276,137]

theorem envBound23191 : H12AffineFastState.Bounded env23191 := by
  intro p hp
  have h : env23191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23190_23191 : H12AffineEnvironment.transform 15 154 env23190 = env23191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 154 env23190 == env23191) = true)

theorem identity23191 : scanCanonicalize (H12AffineFastState.compose env23191 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound23191 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env23192 : List Nat := [2,4,8,16,32,16,128,21,137,5,2048,0,25,1,1,154,1,178,5,0,1,33,16,139,145,17,131,0,1,2097,21,168,21,168,1,137]

theorem envBound23192 : H12AffineFastState.Bounded env23192 := by
  intro p hp
  have h : env23192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23191_23192 : H12AffineEnvironment.transform 7 21 env23191 = env23192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env23191 == env23192) = true)

theorem identity23192 : scanCanonicalize (H12AffineFastState.compose env23192 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 130) := by decide +kernel

theorem selectedBound23192 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env23193 : List Nat := [2,4,8,16,32,16,128,21,137,5,130,0,25,1,1,154,1,178,5,0,1,33,16,139,145,17,131,0,1,179,21,168,21,168,1,137]

theorem envBound23193 : H12AffineFastState.Bounded env23193 := by
  intro p hp
  have h : env23193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23192_23193 : H12AffineEnvironment.transform 10 130 env23192 = env23193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 130 env23192 == env23193) = true)

def env23194 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,65536,1345,262144,1024,32769,1344,4194304,17,16777216,8328,64,21331968,1297,1297,1073741824,16876544,4294967296,256,4315938986,1345,512]

theorem envBound23194 : H12AffineFastState.Bounded env23194 := by
  intro p hp
  have h : env23194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23179_23194 : H12AffineEnvironment.transform 11 1345 env23179 = env23194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env23179 == env23194) = true)

theorem identity23194 : scanCanonicalize (H12AffineFastState.compose env23194 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound23194 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env23195 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1296,32768,65536,1296,262144,1024,32769,1297,4194304,17,16777216,8328,17,21331968,1297,1297,1073741824,16876544,4294967296,256,4315938986,1296,512]

theorem envBound23195 : H12AffineFastState.Bounded env23195 := by
  intro p hp
  have h : env23195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23194_23195 : H12AffineEnvironment.transform 5 17 env23194 = env23195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23194 == env23195) = true)

theorem identity23195 : scanCanonicalize (H12AffineFastState.compose env23195 (packedSelected [13,21] rootPS)) = affineNative (2^(31+1) ^^^ 1073842178) := by decide +kernel

theorem selectedBound23195 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env23196 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1296,32768,65536,1296,262144,1024,32769,1297,4194304,17,16777216,8328,17,21331968,1297,1297,1073741824,16876544,1073842178,256,1094813864,1296,512]

theorem envBound23196 : H12AffineFastState.Bounded env23196 := by
  intro p hp
  have h : env23196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23195_23196 : H12AffineEnvironment.transform 31 1073842178 env23195 = env23196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1073842178 env23195 == env23196) = true)

def env23197 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,128,1296,32768,65536,1296,262144,1024,32769,1297,4194304,17,16777216,8,17,21331968,1297,1297,1073741824,16876544,1073842178,256,1094813864,1296,512]

theorem envBound23197 : H12AffineFastState.Bounded env23197 := by
  intro p hp
  have h : env23197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23196_23197 : H12AffineEnvironment.transform 12 128 env23196 = env23197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 128 env23196 == env23197) = true)

theorem identity23197 : scanCanonicalize (H12AffineFastState.compose env23197 (packedSelected [3,5,24] rootPS)) = affineNative (2^(23+1) ^^^ 4456577) := by decide +kernel

theorem selectedBound23197 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env23198 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,128,1296,32768,65536,1296,262144,1024,32769,1297,4194304,17,4456577,8,17,98433,1297,1297,1073741824,4555905,1073842178,256,1074104361,1296,512]

theorem envBound23198 : H12AffineFastState.Bounded env23198 := by
  intro p hp
  have h : env23198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23197_23198 : H12AffineEnvironment.transform 23 4456577 env23197 = env23198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 4456577 env23197 == env23198) = true)

def env23199 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,128,1296,32768,65536,1296,262144,1024,32769,1297,4194304,17,4456577,8,17,98433,1297,1297,362624,4555905,262274,256,169,1296,512]

theorem envBound23199 : H12AffineFastState.Bounded env23199 := by
  intro p hp
  have h : env23199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23198_23199 : H12AffineEnvironment.transform 29 362624 env23198 = env23199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 362624 env23198 == env23199) = true)

theorem identity23199 : scanCanonicalize (H12AffineFastState.compose env23199 (packedSelected [5] rootPS)) = affineNative (2^(21+1) ^^^ 36275) := by decide +kernel

theorem selectedBound23199 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env23200 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,128,1296,32768,65536,1296,262144,1024,32769,1297,36275,17,298290,8,17,98433,1297,1297,362624,330034,262274,256,169,1296,512]

theorem envBound23200 : H12AffineFastState.Bounded env23200 := by
  intro p hp
  have h : env23200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23199_23200 : H12AffineEnvironment.transform 21 36275 env23199 = env23200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 36275 env23199 == env23200) = true)

theorem identity23200 : scanCanonicalize (H12AffineFastState.compose env23200 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 1055) := by decide +kernel

theorem selectedBound23200 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env23201 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1055,1296,128,1296,32768,65536,1296,262144,1024,32769,1297,33196,17,295213,8,17,98433,1297,1297,361631,329005,262274,256,169,1296,512]

theorem envBound23201 : H12AffineFastState.Bounded env23201 := by
  intro p hp
  have h : env23201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23200_23201 : H12AffineEnvironment.transform 10 1055 env23200 = env23201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1055 env23200 == env23201) = true)

theorem identity23201 : scanCanonicalize (H12AffineFastState.compose env23201 (packedSelected [1,3,8] rootPS)) = affineNative (2^(17+1) ^^^ 65577) := by decide +kernel

theorem selectedBound23201 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env23202 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1055,1296,128,1296,32768,65536,1296,65577,1024,32769,1297,33196,17,98564,8,17,98433,1297,1297,33974,1284,65707,256,169,1296,512]

theorem envBound23202 : H12AffineFastState.Bounded env23202 := by
  intro p hp
  have h : env23202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23201_23202 : H12AffineEnvironment.transform 17 65577 env23201 = env23202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65577 env23201 == env23202) = true)

theorem identity23202 : scanCanonicalize (H12AffineFastState.compose env23202 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 806) := by decide +kernel

theorem selectedBound23202 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23203 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1055,1296,128,1296,32768,806,1296,783,1024,32769,1297,33196,17,33314,8,17,33703,1297,1297,33974,1284,909,256,169,1296,512]

theorem envBound23203 : H12AffineFastState.Bounded env23203 := by
  intro p hp
  have h : env23203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23202_23203 : H12AffineEnvironment.transform 15 806 env23202 = env23203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 806 env23202 == env23203) = true)

theorem identity23203 : scanCanonicalize (H12AffineFastState.compose env23203 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound23203 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env23204 : List Nat := [2,4,8,16,32,17,128,256,1,1024,1055,1296,128,1296,32768,295,1296,270,1024,32769,1297,33196,17,32803,8,17,33190,1297,1297,33974,1284,396,256,169,1296,1]

theorem envBound23204 : H12AffineFastState.Bounded env23204 := by
  intro p hp
  have h : env23204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23203_23204 : H12AffineEnvironment.transform 8 1 env23203 = env23204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env23203 == env23204) = true)

theorem identity23204 : scanCanonicalize (H12AffineFastState.compose env23204 (packedSelected [10] rootPS)) = affineNative (2^(14+1) ^^^ 168) := by decide +kernel

theorem selectedBound23204 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env23205 : List Nat := [2,4,8,16,32,17,128,256,1,1024,1055,1296,128,1296,168,295,1296,270,1024,169,1297,260,17,139,8,17,270,1297,1297,1054,1284,396,256,169,1296,1]

theorem envBound23205 : H12AffineFastState.Bounded env23205 := by
  intro p hp
  have h : env23205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23204_23205 : H12AffineEnvironment.transform 14 168 env23204 = env23205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 168 env23204 == env23205) = true)

theorem identity23205 : scanCanonicalize (H12AffineFastState.compose env23205 (packedSelected [0,2] rootPS)) = affineNative (2^(9+1) ^^^ 157) := by decide +kernel

theorem selectedBound23205 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env23206 : List Nat := [2,4,8,16,32,17,128,256,1,157,130,397,128,397,168,295,397,270,157,169,396,260,17,139,8,17,270,396,396,131,409,396,256,169,397,1]

theorem envBound23206 : H12AffineFastState.Bounded env23206 := by
  intro p hp
  have h : env23206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23205_23206 : H12AffineEnvironment.transform 9 157 env23205 = env23206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 157 env23205 == env23206) = true)

theorem identity23206 : scanCanonicalize (H12AffineFastState.compose env23206 (packedSelected [0,6] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound23206 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env23207 : List Nat := [2,4,8,16,32,17,128,4,1,157,130,137,128,137,168,35,137,10,157,169,136,0,17,139,8,17,10,136,136,131,157,136,4,169,137,1]

theorem envBound23207 : H12AffineFastState.Bounded env23207 := by
  intro p hp
  have h : env23207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23206_23207 : H12AffineEnvironment.transform 7 4 env23206 = env23207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env23206 == env23207) = true)

theorem identity23207 : scanCanonicalize (H12AffineFastState.compose env23207 (packedSelected [0,7] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound23207 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env23208 : List Nat := [2,4,3,16,32,17,128,4,1,150,130,130,128,130,163,35,130,1,150,162,131,0,17,128,3,17,1,131,131,131,150,131,4,162,130,1]

theorem envBound23208 : H12AffineFastState.Bounded env23208 := by
  intro p hp
  have h : env23208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23207_23208 : H12AffineEnvironment.transform 2 3 env23207 = env23208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env23207 == env23208) = true)

theorem identity23208 : scanCanonicalize (H12AffineFastState.compose env23208 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound23208 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env23209 : List Nat := [2,4,3,16,32,17,2,4,1,20,0,0,2,0,33,35,0,1,20,32,1,0,17,2,3,17,1,1,1,1,20,1,4,32,0,1]

theorem envBound23209 : H12AffineFastState.Bounded env23209 := by
  intro p hp
  have h : env23209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23208_23209 : H12AffineEnvironment.transform 6 2 env23208 = env23209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env23208 == env23209) = true)

theorem identity23209 : scanCanonicalize (H12AffineFastState.compose env23209 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound23209 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23210 : List Nat := [2,4,3,16,16,17,2,4,1,20,0,0,2,0,17,19,0,1,20,16,1,0,17,2,3,17,1,1,1,1,20,1,4,16,0,1]

theorem envBound23210 : H12AffineFastState.Bounded env23210 := by
  intro p hp
  have h : env23210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23209_23210 : H12AffineEnvironment.transform 4 16 env23209 = env23210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env23209 == env23210) = true)

def env23211 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,128,1296,32768,65536,1296,262144,1024,32769,1297,4194304,17,4456577,8,17,98433,1297,1297,362625,4555905,262275,256,168,1296,512]

theorem envBound23211 : H12AffineFastState.Bounded env23211 := by
  intro p hp
  have h : env23211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23198_23211 : H12AffineEnvironment.transform 29 362625 env23198 = env23211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 362625 env23198 == env23211) = true)

theorem identity23211 : scanCanonicalize (H12AffineFastState.compose env23211 (packedSelected [5] rootPS)) = affineNative (2^(21+1) ^^^ 34978) := by decide +kernel

theorem selectedBound23211 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env23212 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,128,1296,32768,65536,1296,262144,1024,32769,1297,34978,17,296995,8,17,98433,1297,1297,362625,330787,262275,256,168,1296,512]

theorem envBound23212 : H12AffineFastState.Bounded env23212 := by
  intro p hp
  have h : env23212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23211_23212 : H12AffineEnvironment.transform 21 34978 env23211 = env23212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 34978 env23211 == env23212) = true)

theorem identity23212 : scanCanonicalize (H12AffineFastState.compose env23212 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 33166) := by decide +kernel

theorem selectedBound23212 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env23213 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,128,1296,32768,33166,1296,262144,1024,32769,1297,34978,17,296995,8,17,271,1297,1297,264463,298413,262275,256,168,1296,512]

theorem envBound23213 : H12AffineFastState.Bounded env23213 := by
  intro p hp
  have h : env23213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23212_23213 : H12AffineEnvironment.transform 15 33166 env23212 = env23213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33166 env23212 == env23213) = true)

theorem identity23213 : scanCanonicalize (H12AffineFastState.compose env23213 (packedSelected [3,10] rootPS)) = affineNative (2^(17+1) ^^^ 33190) := by decide +kernel

theorem selectedBound23213 : packedSelected [3,10] rootPS < 2^1333 := by decide +kernel

def env23214 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,128,1296,32768,33166,1296,33190,1024,32769,1297,34978,17,2437,8,17,271,1297,1297,34985,3083,33061,256,168,1296,512]

theorem envBound23214 : H12AffineFastState.Bounded env23214 := by
  intro p hp
  have h : env23214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23213_23214 : H12AffineEnvironment.transform 17 33190 env23213 = env23214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 33190 env23213 == env23214) = true)

theorem identity23214 : scanCanonicalize (H12AffineFastState.compose env23214 (packedSelected [0,2,3,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 1819) := by decide +kernel

theorem selectedBound23214 : packedSelected [0,2,3,6,7] rootPS < 2^1333 := by decide +kernel

def env23215 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1819,1296,128,1296,32768,33166,1296,33190,1024,32769,1297,34745,17,1694,8,17,271,1297,1297,34738,784,33061,256,168,1296,512]

theorem envBound23215 : H12AffineFastState.Bounded env23215 := by
  intro p hp
  have h : env23215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23214_23215 : H12AffineEnvironment.transform 10 1819 env23214 = env23215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1819 env23214 == env23215) = true)

theorem identity23215 : scanCanonicalize (H12AffineFastState.compose env23215 (packedSelected [1,3,8] rootPS)) = affineNative (2^(9+1) ^^^ 533) := by decide +kernel

theorem selectedBound23215 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env23216 : List Nat := [2,4,8,16,32,17,128,256,512,533,270,773,128,773,32768,33166,773,33190,533,32769,772,33196,17,139,8,17,271,772,772,33191,784,33061,256,168,773,512]

theorem envBound23216 : H12AffineFastState.Bounded env23216 := by
  intro p hp
  have h : env23216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23215_23216 : H12AffineEnvironment.transform 9 533 env23215 = env23216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 533 env23215 == env23216) = true)

theorem identity23216 : scanCanonicalize (H12AffineFastState.compose env23216 (packedSelected [1] rootPS)) = affineNative (2^(14+1) ^^^ 648) := by decide +kernel

theorem selectedBound23216 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23217 : List Nat := [2,4,8,16,32,17,128,256,512,533,270,773,128,773,648,774,773,814,533,649,772,804,17,139,8,17,271,772,772,815,784,941,256,168,773,512]

theorem envBound23217 : H12AffineFastState.Bounded env23217 := by
  intro p hp
  have h : env23217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23216_23217 : H12AffineEnvironment.transform 14 648 env23216 = env23217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 648 env23216 == env23217) = true)

theorem identity23217 : scanCanonicalize (H12AffineFastState.compose env23217 (packedSelected [3] rootPS)) = affineNative (2^(7+1) ^^^ 140) := by decide +kernel

theorem selectedBound23217 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env23218 : List Nat := [2,4,8,16,32,17,128,140,512,533,130,649,128,649,648,650,649,674,533,649,648,680,17,139,8,17,131,648,648,675,668,545,140,168,649,512]

theorem envBound23218 : H12AffineFastState.Bounded env23218 := by
  intro p hp
  have h : env23218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23217_23218 : H12AffineEnvironment.transform 7 140 env23217 = env23218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 140 env23217 == env23218) = true)

def env23219 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,129,1296,32768,65536,1296,262144,1024,32769,1297,4194304,17,16777216,9,17,21331968,1297,1297,1073741824,16876544,1073842178,256,1094813864,1296,512]

theorem envBound23219 : H12AffineFastState.Bounded env23219 := by
  intro p hp
  have h : env23219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23196_23219 : H12AffineEnvironment.transform 12 129 env23196 = env23219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 129 env23196 == env23219) = true)

theorem identity23219 : scanCanonicalize (H12AffineFastState.compose env23219 (packedSelected [3,5,24] rootPS)) = affineNative (2^(21+1) ^^^ 360837) := by decide +kernel

theorem selectedBound23219 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env23220 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,129,1296,32768,65536,1296,262144,1024,32769,1297,360837,17,16777216,9,17,16777605,1297,1297,1073741824,16876544,1073842178,256,1090783533,1296,512]

theorem envBound23220 : H12AffineFastState.Bounded env23220 := by
  intro p hp
  have h : env23220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23219_23220 : H12AffineEnvironment.transform 21 360837 env23219 = env23220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 360837 env23219 == env23220) = true)

def env23221 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,129,0,32768,65536,0,262144,272,32769,1,360837,17,16777216,9,17,16777605,1,1,1073741824,16875792,1073842178,256,1090783533,0,512]

theorem envBound23221 : H12AffineFastState.Bounded env23221 := by
  intro p hp
  have h : env23221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23220_23221 : H12AffineEnvironment.transform 9 272 env23220 = env23221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env23220 == env23221) = true)

theorem identity23221 : scanCanonicalize (H12AffineFastState.compose env23221 (packedSelected [5] rootPS)) = affineNative (2^(29+1) ^^^ 33191) := by decide +kernel

theorem selectedBound23221 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env23222 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,129,0,32768,65536,0,262144,272,32769,1,360837,17,16777216,9,17,16777605,1,1,33191,16875792,68005,256,17074314,0,512]

theorem envBound23222 : H12AffineFastState.Bounded env23222 := by
  intro p hp
  have h : env23222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23221_23222 : H12AffineEnvironment.transform 29 33191 env23221 = env23222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 33191 env23221 == env23222) = true)

def env23223 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,129,0,32768,65536,0,34952,272,32769,1,67853,17,16777216,9,17,16777605,1,1,33191,16875792,68005,256,16777218,0,512]

theorem envBound23223 : H12AffineFastState.Bounded env23223 := by
  intro p hp
  have h : env23223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23222_23223 : H12AffineEnvironment.transform 17 34952 env23222 = env23223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 34952 env23222 == env23223) = true)

theorem identity23223 : scanCanonicalize (H12AffineFastState.compose env23223 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 2600) := by decide +kernel

theorem selectedBound23223 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23224 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,129,0,32768,2600,0,34952,272,32769,1,805,17,16777216,9,17,16777605,1,1,33191,16812856,909,256,16777218,0,512]

theorem envBound23224 : H12AffineFastState.Bounded env23224 := by
  intro p hp
  have h : env23224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23223_23224 : H12AffineEnvironment.transform 15 2600 env23223 = env23224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2600 env23223 == env23224) = true)

def env23225 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,129,0,32768,2600,0,34952,272,32769,1,805,17,34976,9,17,35109,1,1,33191,920,909,256,34978,0,512]

theorem envBound23225 : H12AffineFastState.Bounded env23225 := by
  intro p hp
  have h : env23225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23224_23225 : H12AffineEnvironment.transform 23 34976 env23224 = env23225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 34976 env23224 == env23225) = true)

theorem identity23225 : scanCanonicalize (H12AffineFastState.compose env23225 (packedSelected [3] rootPS)) = affineNative (2^(14+1) ^^^ 2570) := by decide +kernel

theorem selectedBound23225 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env23226 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,129,0,2570,2600,0,642,272,2571,1,805,17,682,9,17,815,1,1,2989,920,909,256,680,0,512]

theorem envBound23226 : H12AffineFastState.Bounded env23226 := by
  intro p hp
  have h : env23226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23225_23226 : H12AffineEnvironment.transform 14 2570 env23225 = env23226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2570 env23225 == env23226) = true)

theorem identity23226 : scanCanonicalize (H12AffineFastState.compose env23226 (packedSelected [8,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 675) := by decide +kernel

theorem selectedBound23226 : packedSelected [8,12,15] rootPS < 2^1333 := by decide +kernel

def env23227 : List Nat := [2,4,8,16,32,17,128,256,512,272,675,0,129,0,169,139,0,642,272,168,1,805,17,682,9,17,815,1,1,270,920,909,256,680,0,512]

theorem envBound23227 : H12AffineFastState.Bounded env23227 := by
  intro p hp
  have h : env23227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23226_23227 : H12AffineEnvironment.transform 10 675 env23226 = env23227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 675 env23226 == env23227) = true)

theorem identity23227 : scanCanonicalize (H12AffineFastState.compose env23227 (packedSelected [0,4,7,8,9,10] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound23227 : packedSelected [0,4,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env23228 : List Nat := [2,4,8,16,32,17,128,256,33,272,130,0,129,0,169,139,0,163,272,168,1,260,17,139,9,17,270,1,1,270,441,428,256,137,0,33]

theorem envBound23228 : H12AffineFastState.Bounded env23228 := by
  intro p hp
  have h : env23228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23227_23228 : H12AffineEnvironment.transform 8 33 env23227 = env23228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env23227 == env23228) = true)

theorem identity23228 : scanCanonicalize (H12AffineFastState.compose env23228 (packedSelected [8] rootPS)) = affineNative (2^(7+1) ^^^ 141) := by decide +kernel

theorem selectedBound23228 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env23229 : List Nat := [2,4,8,16,32,17,128,141,33,157,130,0,129,0,169,139,0,163,157,168,1,137,17,139,9,17,131,1,1,131,52,33,141,137,0,33]

theorem envBound23229 : H12AffineFastState.Bounded env23229 := by
  intro p hp
  have h : env23229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23228_23229 : H12AffineEnvironment.transform 7 141 env23228 = env23229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 141 env23228 == env23229) = true)

theorem identity23229 : scanCanonicalize (H12AffineFastState.compose env23229 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound23229 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env23230 : List Nat := [2,4,8,16,32,17,41,36,33,52,43,0,40,0,0,34,0,10,52,1,1,32,17,34,9,17,42,1,1,42,52,33,36,32,0,33]

theorem envBound23230 : H12AffineFastState.Bounded env23230 := by
  intro p hp
  have h : env23230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23229_23230 : H12AffineEnvironment.transform 6 41 env23229 = env23230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env23229 == env23230) = true)

theorem identity23230 : scanCanonicalize (H12AffineFastState.compose env23230 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound23230 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23231 : List Nat := [2,4,8,16,17,17,24,21,16,5,26,0,25,0,0,19,0,10,5,1,1,17,17,19,9,17,27,1,1,27,5,16,21,17,0,16]

theorem envBound23231 : H12AffineFastState.Bounded env23231 := by
  intro p hp
  have h : env23231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23230_23231 : H12AffineEnvironment.transform 4 17 env23230 = env23231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env23230 == env23231) = true)

def env23232 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,129,0,32768,2600,0,34952,272,32769,1,805,17,34977,9,17,35108,1,1,33191,921,909,256,34979,0,512]

theorem envBound23232 : H12AffineFastState.Bounded env23232 := by
  intro p hp
  have h : env23232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23224_23232 : H12AffineEnvironment.transform 23 34977 env23224 = env23232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 34977 env23224 == env23232) = true)

theorem identity23232 : scanCanonicalize (H12AffineFastState.compose env23232 (packedSelected [3] rootPS)) = affineNative (2^(14+1) ^^^ 2438) := by decide +kernel

theorem selectedBound23232 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env23233 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,129,0,2438,2600,0,270,272,2439,1,805,17,295,9,17,162,1,1,2081,921,909,256,293,0,512]

theorem envBound23233 : H12AffineFastState.Bounded env23233 := by
  intro p hp
  have h : env23233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23232_23233 : H12AffineEnvironment.transform 14 2438 env23232 = env23233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2438 env23232 == env23233) = true)

theorem identity23233 : scanCanonicalize (H12AffineFastState.compose env23233 (packedSelected [8,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 674) := by decide +kernel

theorem selectedBound23233 : packedSelected [8,12,15] rootPS < 2^1333 := by decide +kernel

def env23234 : List Nat := [2,4,8,16,32,17,128,256,512,272,674,0,129,0,804,138,0,270,272,805,1,805,17,295,9,17,162,1,1,643,921,909,256,293,0,512]

theorem envBound23234 : H12AffineFastState.Bounded env23234 := by
  intro p hp
  have h : env23234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23233_23234 : H12AffineEnvironment.transform 10 674 env23233 = env23234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 674 env23233 == env23234) = true)

theorem identity23234 : scanCanonicalize (H12AffineFastState.compose env23234 (packedSelected [0,4,7,8,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound23234 : packedSelected [0,4,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env23235 : List Nat := [2,4,8,16,32,17,128,172,512,188,674,0,129,0,648,138,0,162,188,649,1,649,17,139,9,17,162,1,1,643,565,545,172,137,0,512]

theorem envBound23235 : H12AffineFastState.Bounded env23235 := by
  intro p hp
  have h : env23235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23234_23235 : H12AffineEnvironment.transform 7 172 env23234 = env23235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env23234 == env23235) = true)

theorem identity23235 : scanCanonicalize (H12AffineFastState.compose env23235 (packedSelected [6] rootPS)) = affineNative (2^(8+1) ^^^ 153) := by decide +kernel

theorem selectedBound23235 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env23236 : List Nat := [2,4,8,16,32,17,128,172,153,188,59,0,129,0,17,138,0,162,188,16,1,16,17,139,9,17,162,1,1,26,172,184,172,137,0,153]

theorem envBound23236 : H12AffineFastState.Bounded env23236 := by
  intro p hp
  have h : env23236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23235_23236 : H12AffineEnvironment.transform 8 153 env23235 = env23236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 153 env23235 == env23236) = true)

theorem identity23236 : scanCanonicalize (H12AffineFastState.compose env23236 (packedSelected [7] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound23236 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env23237 : List Nat := [2,4,2,16,32,17,128,166,147,182,49,0,129,0,17,128,0,162,182,16,1,16,17,129,3,17,162,1,1,16,166,178,166,131,0,147]

theorem envBound23237 : H12AffineFastState.Bounded env23237 := by
  intro p hp
  have h : env23237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23236_23237 : H12AffineEnvironment.transform 2 2 env23236 = env23237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env23236 == env23237) = true)

theorem identity23237 : scanCanonicalize (H12AffineFastState.compose env23237 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound23237 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env23238 : List Nat := [2,4,2,16,32,17,3,37,16,53,49,0,2,0,17,3,0,33,53,16,1,16,17,2,3,17,33,1,1,16,37,49,37,0,0,16]

theorem envBound23238 : H12AffineFastState.Bounded env23238 := by
  intro p hp
  have h : env23238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23237_23238 : H12AffineEnvironment.transform 6 3 env23237 = env23238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env23237 == env23238) = true)

theorem identity23238 : scanCanonicalize (H12AffineFastState.compose env23238 (packedSelected [0,2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound23238 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env23239 : List Nat := [2,4,2,16,0,17,3,5,16,21,17,0,2,0,17,3,0,1,21,16,1,16,17,2,3,17,1,1,1,16,5,17,5,0,0,16]

theorem envBound23239 : H12AffineFastState.Bounded env23239 := by
  intro p hp
  have h : env23239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23238_23239 : H12AffineEnvironment.transform 4 0 env23238 = env23239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env23238 == env23239) = true)

theorem identity23239 : scanCanonicalize (H12AffineFastState.compose env23239 (packedSelected [8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound23239 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env23240 : List Nat := [2,4,2,1,0,0,3,5,1,4,0,0,2,0,0,3,0,1,4,1,1,1,0,2,3,0,1,1,1,1,5,0,5,0,0,1]

theorem envBound23240 : H12AffineFastState.Bounded env23240 := by
  intro p hp
  have h : env23240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23239_23240 : H12AffineEnvironment.transform 3 1 env23239 = env23240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env23239 == env23240) = true)

def env23241 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,129,0,32768,65536,0,34953,272,32769,1,67852,17,16777216,9,17,16777605,1,1,33191,16875792,68005,256,16777219,0,512]

theorem envBound23241 : H12AffineFastState.Bounded env23241 := by
  intro p hp
  have h : env23241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23222_23241 : H12AffineEnvironment.transform 17 34953 env23222 = env23241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 34953 env23222 == env23241) = true)

theorem identity23241 : scanCanonicalize (H12AffineFastState.compose env23241 (packedSelected [1] rootPS)) = affineNative (2^(23+1) ^^^ 35628) := by decide +kernel

theorem selectedBound23241 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23242 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,129,0,32768,65536,0,34953,272,32769,1,67852,17,35628,9,17,35497,1,1,33191,68156,68005,256,35631,0,512]

theorem envBound23242 : H12AffineFastState.Bounded env23242 := by
  intro p hp
  have h : env23242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23241_23242 : H12AffineEnvironment.transform 23 35628 env23241 = env23242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 35628 env23241 == env23242) = true)

def env23243 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,129,0,32768,2600,0,34953,272,32769,1,804,17,35628,9,17,35497,1,1,33191,20,909,256,35631,0,512]

theorem envBound23243 : H12AffineFastState.Bounded env23243 := by
  intro p hp
  have h : env23243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23242_23243 : H12AffineEnvironment.transform 15 2600 env23242 = env23243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2600 env23242 == env23243) = true)

theorem identity23243 : scanCanonicalize (H12AffineFastState.compose env23243 (packedSelected [3] rootPS)) = affineNative (2^(14+1) ^^^ 2439) := by decide +kernel

theorem selectedBound23243 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env23244 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,129,0,2439,2600,0,270,272,2438,1,804,17,683,9,17,814,1,1,2080,20,909,256,680,0,512]

theorem envBound23244 : H12AffineFastState.Bounded env23244 := by
  intro p hp
  have h : env23244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23243_23244 : H12AffineEnvironment.transform 14 2439 env23243 = env23244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2439 env23243 == env23244) = true)

theorem identity23244 : scanCanonicalize (H12AffineFastState.compose env23244 (packedSelected [8] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound23244 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env23245 : List Nat := [2,4,8,16,32,17,128,256,1,272,2048,0,129,0,2439,2089,0,270,272,2438,1,293,17,170,9,17,303,1,1,2080,20,396,256,169,0,1]

theorem envBound23245 : H12AffineFastState.Bounded env23245 := by
  intro p hp
  have h : env23245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23244_23245 : H12AffineEnvironment.transform 8 1 env23244 = env23245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env23244 == env23245) = true)

theorem identity23245 : scanCanonicalize (H12AffineFastState.compose env23245 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 271) := by decide +kernel

theorem selectedBound23245 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env23246 : List Nat := [2,4,8,16,32,17,128,256,1,272,271,0,129,0,136,294,0,270,272,137,1,293,17,170,9,17,303,1,1,303,20,396,256,169,0,1]

theorem envBound23246 : H12AffineFastState.Bounded env23246 := by
  intro p hp
  have h : env23246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23245_23246 : H12AffineEnvironment.transform 10 271 env23245 = env23246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 271 env23245 == env23246) = true)

theorem identity23246 : scanCanonicalize (H12AffineFastState.compose env23246 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound23246 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env23247 : List Nat := [2,4,8,16,32,17,128,15,1,31,0,0,129,0,136,41,0,1,31,137,1,42,17,170,9,17,32,1,1,32,20,131,15,169,0,1]

theorem envBound23247 : H12AffineFastState.Bounded env23247 := by
  intro p hp
  have h : env23247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23246_23247 : H12AffineEnvironment.transform 7 15 env23246 = env23247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env23246 == env23247) = true)

theorem identity23247 : scanCanonicalize (H12AffineFastState.compose env23247 (packedSelected [0,6] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound23247 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env23248 : List Nat := [2,4,2,16,32,17,128,5,1,21,0,0,129,0,130,35,0,1,21,131,1,32,17,160,3,17,32,1,1,32,20,131,5,163,0,1]

theorem envBound23248 : H12AffineFastState.Bounded env23248 := by
  intro p hp
  have h : env23248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23247_23248 : H12AffineEnvironment.transform 2 2 env23247 = env23248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env23247 == env23248) = true)

theorem identity23248 : scanCanonicalize (H12AffineFastState.compose env23248 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound23248 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23249 : List Nat := [2,4,2,0,32,1,128,5,1,5,0,0,129,0,130,35,0,1,5,131,1,32,1,160,3,1,32,1,1,32,4,131,5,163,0,1]

theorem envBound23249 : H12AffineFastState.Bounded env23249 := by
  intro p hp
  have h : env23249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23248_23249 : H12AffineEnvironment.transform 3 0 env23248 = env23249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env23248 == env23249) = true)

theorem identity23249 : scanCanonicalize (H12AffineFastState.compose env23249 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound23249 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env23250 : List Nat := [2,4,2,0,1,1,128,5,1,5,0,0,129,0,130,2,0,1,5,131,1,1,1,129,3,1,1,1,1,1,4,131,5,130,0,1]

theorem envBound23250 : H12AffineFastState.Bounded env23250 := by
  intro p hp
  have h : env23250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23249_23250 : H12AffineEnvironment.transform 4 1 env23249 = env23250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env23249 == env23250) = true)

theorem identity23250 : scanCanonicalize (H12AffineFastState.compose env23250 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound23250 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23251 : List Nat := [2,4,2,0,1,1,3,5,1,5,0,0,2,0,1,2,0,1,5,0,1,1,1,2,3,1,1,1,1,1,4,0,5,1,0,1]

theorem envBound23251 : H12AffineFastState.Bounded env23251 := by
  intro p hp
  have h : env23251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23250_23251 : H12AffineEnvironment.transform 6 3 env23250 = env23251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env23250 == env23251) = true)

def env23252 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,129,0,32768,2601,0,34953,272,32769,1,805,17,35628,9,17,35497,1,1,33191,21,908,256,35631,0,512]

theorem envBound23252 : H12AffineFastState.Bounded env23252 := by
  intro p hp
  have h : env23252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23242_23252 : H12AffineEnvironment.transform 15 2601 env23242 = env23252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2601 env23242 == env23252) = true)

theorem identity23252 : scanCanonicalize (H12AffineFastState.compose env23252 (packedSelected [3] rootPS)) = affineNative (2^(14+1) ^^^ 2570) := by decide +kernel

theorem selectedBound23252 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env23253 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,129,0,2570,2601,0,643,272,2571,1,805,17,294,9,17,163,1,1,2989,21,908,256,293,0,512]

theorem envBound23253 : H12AffineFastState.Bounded env23253 := by
  intro p hp
  have h : env23253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23252_23253 : H12AffineEnvironment.transform 14 2570 env23252 = env23253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2570 env23252 == env23253) = true)

theorem identity23253 : scanCanonicalize (H12AffineFastState.compose env23253 (packedSelected [8] rootPS)) = affineNative (2^(10+1) ^^^ 271) := by decide +kernel

theorem selectedBound23253 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env23254 : List Nat := [2,4,8,16,32,17,128,256,512,272,271,0,129,0,773,806,0,643,272,772,1,805,17,294,9,17,163,1,1,674,21,908,256,293,0,512]

theorem envBound23254 : H12AffineFastState.Bounded env23254 := by
  intro p hp
  have h : env23254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23253_23254 : H12AffineEnvironment.transform 10 271 env23253 = env23254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 271 env23253 == env23254) = true)

theorem identity23254 : scanCanonicalize (H12AffineFastState.compose env23254 (packedSelected [0,2,4,6,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound23254 : packedSelected [0,2,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env23255 : List Nat := [2,4,8,16,32,17,128,256,293,272,271,0,129,0,32,3,0,422,272,33,1,0,17,294,9,17,163,1,1,391,21,169,256,293,0,293]

theorem envBound23255 : H12AffineFastState.Bounded env23255 := by
  intro p hp
  have h : env23255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23254_23255 : H12AffineEnvironment.transform 8 293 env23254 = env23255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env23254 == env23255) = true)

theorem identity23255 : scanCanonicalize (H12AffineFastState.compose env23255 (packedSelected [0,2,6,7,11] rootPS)) = affineNative (2^(7+1) ^^^ 141) := by decide +kernel

theorem selectedBound23255 : packedSelected [0,2,6,7,11] rootPS < 2^1333 := by decide +kernel

def env23256 : List Nat := [2,4,8,16,32,17,128,141,168,157,130,0,129,0,32,3,0,43,157,33,1,0,17,171,9,17,163,1,1,10,21,169,141,168,0,168]

theorem envBound23256 : H12AffineFastState.Bounded env23256 := by
  intro p hp
  have h : env23256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23255_23256 : H12AffineEnvironment.transform 7 141 env23255 = env23256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 141 env23255 == env23256) = true)

theorem identity23256 : scanCanonicalize (H12AffineFastState.compose env23256 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound23256 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env23257 : List Nat := [2,4,8,16,0,17,128,141,136,157,130,0,129,0,0,3,0,11,157,1,1,0,17,139,9,17,131,1,1,10,21,137,141,136,0,136]

theorem envBound23257 : H12AffineFastState.Bounded env23257 := by
  intro p hp
  have h : env23257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23256_23257 : H12AffineEnvironment.transform 4 0 env23256 = env23257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env23256 == env23257) = true)

theorem identity23257 : scanCanonicalize (H12AffineFastState.compose env23257 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound23257 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23258 : List Nat := [2,4,8,16,0,17,25,20,17,4,27,0,24,0,0,3,0,11,4,1,1,0,17,18,9,17,26,1,1,10,21,16,20,17,0,17]

theorem envBound23258 : H12AffineFastState.Bounded env23258 := by
  intro p hp
  have h : env23258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23257_23258 : H12AffineEnvironment.transform 6 25 env23257 = env23258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env23257 == env23258) = true)

def env23259 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,129,1,32768,65536,1,262144,273,32769,0,360837,17,16777216,9,17,16777605,0,0,1073741824,16875793,1073842178,256,1090783533,1,512]

theorem envBound23259 : H12AffineFastState.Bounded env23259 := by
  intro p hp
  have h : env23259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23220_23259 : H12AffineEnvironment.transform 9 273 env23220 = env23259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env23220 == env23259) = true)

theorem identity23259 : scanCanonicalize (H12AffineFastState.compose env23259 (packedSelected [5] rootPS)) = affineNative (2^(23+1) ^^^ 296994) := by decide +kernel

theorem selectedBound23259 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env23260 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,129,1,32768,65536,1,262144,273,32769,0,360837,17,296994,9,17,297383,0,0,1073741824,330035,1073842178,256,1073774863,1,512]

theorem envBound23260 : H12AffineFastState.Bounded env23260 := by
  intro p hp
  have h : env23260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23259_23260 : H12AffineEnvironment.transform 23 296994 env23259 = env23260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 296994 env23259 == env23260) = true)

def env23261 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,129,1,32768,65536,1,262144,273,32769,0,360837,17,296994,9,17,297383,0,0,65544,330035,34826,256,98567,1,512]

theorem envBound23261 : H12AffineFastState.Bounded env23261 := by
  intro p hp
  have h : env23261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23260_23261 : H12AffineEnvironment.transform 29 65544 env23260 = env23261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 65544 env23260 == env23261) = true)

theorem identity23261 : scanCanonicalize (H12AffineFastState.compose env23261 (packedSelected [1] rootPS)) = affineNative (2^(14+1) ^^^ 2951) := by decide +kernel

theorem selectedBound23261 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23262 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,129,1,2951,65536,1,262144,273,2950,0,330242,17,263077,9,17,262688,0,0,65544,330035,909,256,68224,1,512]

theorem envBound23262 : H12AffineFastState.Bounded env23262 := by
  intro p hp
  have h : env23262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23261_23262 : H12AffineEnvironment.transform 14 2951 env23261 = env23262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2951 env23261 == env23262) = true)

def env23263 : List Nat := [2,4,8,16,32,17,128,256,396,273,2048,1,129,1,2059,65536,1,262144,273,2058,0,330126,17,262185,9,17,262572,0,0,65544,330035,1,256,67852,1,396]

theorem envBound23263 : H12AffineFastState.Bounded env23263 := by
  intro p hp
  have h : env23263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23262_23263 : H12AffineEnvironment.transform 8 396 env23262 = env23263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 396 env23262 == env23263) = true)

theorem identity23263 : scanCanonicalize (H12AffineFastState.compose env23263 (packedSelected [3] rootPS)) = affineNative (2^(17+1) ^^^ 270) := by decide +kernel

theorem selectedBound23263 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env23264 : List Nat := [2,4,8,16,32,17,128,256,396,273,2048,1,129,1,2059,65536,1,270,273,2058,0,67712,17,295,9,17,162,0,0,65544,67645,1,256,67852,1,396]

theorem envBound23264 : H12AffineFastState.Bounded env23264 := by
  intro p hp
  have h : env23264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23263_23264 : H12AffineEnvironment.transform 17 270 env23263 = env23264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 270 env23263 == env23264) = true)

theorem identity23264 : scanCanonicalize (H12AffineFastState.compose env23264 (packedSelected [8,10,12,13,15,17] rootPS)) = affineNative (2^(15+1) ^^^ 138) := by decide +kernel

theorem selectedBound23264 : packedSelected [8,10,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env23265 : List Nat := [2,4,8,16,32,17,128,256,396,273,2048,1,129,1,2059,138,1,270,273,2058,0,2058,17,295,9,17,162,0,0,130,2231,1,256,2438,1,396]

theorem envBound23265 : H12AffineFastState.Bounded env23265 := by
  intro p hp
  have h : env23265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23264_23265 : H12AffineEnvironment.transform 15 138 env23264 = env23265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 138 env23264 == env23265) = true)

theorem identity23265 : scanCanonicalize (H12AffineFastState.compose env23265 (packedSelected [0,4,7,8,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound23265 : packedSelected [0,4,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env23266 : List Nat := [2,4,8,16,32,17,128,172,32,189,2048,1,129,1,2059,138,1,162,189,2058,0,2058,17,139,9,17,162,0,0,130,2231,1,172,2090,1,32]

theorem envBound23266 : H12AffineFastState.Bounded env23266 := by
  intro p hp
  have h : env23266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23265_23266 : H12AffineEnvironment.transform 7 172 env23265 = env23266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env23265 == env23266) = true)

theorem identity23266 : scanCanonicalize (H12AffineFastState.compose env23266 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 27) := by decide +kernel

theorem selectedBound23266 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env23267 : List Nat := [2,4,8,16,32,17,128,172,32,189,27,1,129,1,16,138,1,162,189,17,0,17,17,139,9,17,162,0,0,130,172,1,172,49,1,32]

theorem envBound23267 : H12AffineFastState.Bounded env23267 := by
  intro p hp
  have h : env23267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23266_23267 : H12AffineEnvironment.transform 10 27 env23266 = env23267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 27 env23266 == env23267) = true)

theorem identity23267 : scanCanonicalize (H12AffineFastState.compose env23267 (packedSelected [8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound23267 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env23268 : List Nat := [2,4,8,16,1,17,128,141,1,156,27,1,129,1,16,138,1,131,156,17,0,17,17,139,9,17,131,0,0,130,141,1,141,16,1,1]

theorem envBound23268 : H12AffineFastState.Bounded env23268 := by
  intro p hp
  have h : env23268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23267_23268 : H12AffineEnvironment.transform 4 1 env23267 = env23268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env23267 == env23268) = true)

theorem identity23268 : scanCanonicalize (H12AffineFastState.compose env23268 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound23268 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23269 : List Nat := [2,4,8,16,1,17,8,5,1,20,27,1,9,1,16,2,1,11,20,17,0,17,17,3,9,17,11,0,0,10,5,1,5,16,1,1]

theorem envBound23269 : H12AffineFastState.Bounded env23269 := by
  intro p hp
  have h : env23269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23268_23269 : H12AffineEnvironment.transform 6 8 env23268 = env23269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env23268 == env23269) = true)

theorem identity23269 : scanCanonicalize (H12AffineFastState.compose env23269 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound23269 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env23270 : List Nat := [2,4,8,1,1,0,8,5,1,5,10,1,9,1,1,2,1,11,5,0,0,0,0,3,9,0,11,0,0,10,5,1,5,1,1,1]

theorem envBound23270 : H12AffineFastState.Bounded env23270 := by
  intro p hp
  have h : env23270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23269_23270 : H12AffineEnvironment.transform 3 1 env23269 = env23270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env23269 == env23270) = true)

theorem identity23270 : scanCanonicalize (H12AffineFastState.compose env23270 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound23270 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23271 : List Nat := [2,4,2,1,1,0,2,5,1,5,0,1,3,1,1,2,1,1,5,0,0,0,0,3,3,0,1,0,0,0,5,1,5,1,1,1]

theorem envBound23271 : H12AffineFastState.Bounded env23271 := by
  intro p hp
  have h : env23271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23270_23271 : H12AffineEnvironment.transform 2 2 env23270 = env23271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env23270 == env23271) = true)

def env23272 : List Nat := [2,4,8,16,32,17,128,256,397,273,2048,1,129,1,2058,65536,1,262144,273,2059,0,330127,17,262184,9,17,262573,0,0,65544,330035,0,256,67853,1,397]

theorem envBound23272 : H12AffineFastState.Bounded env23272 := by
  intro p hp
  have h : env23272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23262_23272 : H12AffineEnvironment.transform 8 397 env23262 = env23272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 397 env23262 == env23272) = true)

theorem identity23272 : scanCanonicalize (H12AffineFastState.compose env23272 (packedSelected [3] rootPS)) = affineNative (2^(15+1) ^^^ 2088) := by decide +kernel

theorem selectedBound23272 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env23273 : List Nat := [2,4,8,16,32,17,128,256,397,273,2048,1,129,1,2058,2088,1,262144,273,2059,0,262567,17,262184,9,17,262573,0,0,2080,262427,0,256,293,1,397]

theorem envBound23273 : H12AffineFastState.Bounded env23273 := by
  intro p hp
  have h : env23273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23272_23273 : H12AffineEnvironment.transform 15 2088 env23272 = env23273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2088 env23272 == env23273) = true)

theorem identity23273 : scanCanonicalize (H12AffineFastState.compose env23273 (packedSelected [8,10,12,13,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 163) := by decide +kernel

theorem selectedBound23273 : packedSelected [8,10,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env23274 : List Nat := [2,4,8,16,32,17,128,256,397,273,163,1,129,1,169,139,1,262144,273,168,0,262567,17,262184,9,17,262573,0,0,131,262427,0,256,293,1,397]

theorem envBound23274 : H12AffineFastState.Bounded env23274 := by
  intro p hp
  have h : env23274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23273_23274 : H12AffineEnvironment.transform 10 163 env23273 = env23274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 163 env23273 == env23274) = true)

theorem identity23274 : scanCanonicalize (H12AffineFastState.compose env23274 (packedSelected [0,4,7,8,9,10] rootPS)) = affineNative (2^(17+1) ^^^ 163) := by decide +kernel

theorem selectedBound23274 : packedSelected [0,4,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env23275 : List Nat := [2,4,8,16,32,17,128,256,397,273,163,1,129,1,169,139,1,163,273,168,0,260,17,139,9,17,270,0,0,131,440,0,256,293,1,397]

theorem envBound23275 : H12AffineFastState.Bounded env23275 := by
  intro p hp
  have h : env23275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23274_23275 : H12AffineEnvironment.transform 17 163 env23274 = env23275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 163 env23274 == env23275) = true)

theorem identity23275 : scanCanonicalize (H12AffineFastState.compose env23275 (packedSelected [8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound23275 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env23276 : List Nat := [2,4,8,16,1,17,128,256,397,273,130,1,129,1,136,139,1,130,273,137,0,260,17,139,9,17,270,0,0,131,409,0,256,260,1,397]

theorem envBound23276 : H12AffineFastState.Bounded env23276 := by
  intro p hp
  have h : env23276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23275_23276 : H12AffineEnvironment.transform 4 1 env23275 = env23276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env23275 == env23276) = true)

theorem identity23276 : scanCanonicalize (H12AffineFastState.compose env23276 (packedSelected [0,2,4] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound23276 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env23277 : List Nat := [2,4,8,16,1,17,128,20,153,5,130,1,129,1,136,139,1,130,5,137,0,16,17,139,9,17,26,0,0,131,141,0,20,16,1,153]

theorem envBound23277 : H12AffineFastState.Bounded env23277 := by
  intro p hp
  have h : env23277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23276_23277 : H12AffineEnvironment.transform 7 20 env23276 = env23277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env23276 == env23277) = true)

def env23278 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,129,1,32768,65536,1,262144,273,32769,0,360837,17,296994,9,17,297383,0,0,65545,330035,34827,256,98566,1,512]

theorem envBound23278 : H12AffineFastState.Bounded env23278 := by
  intro p hp
  have h : env23278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23260_23278 : H12AffineEnvironment.transform 29 65545 env23260 = env23278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 65545 env23260 == env23278) = true)

theorem identity23278 : scanCanonicalize (H12AffineFastState.compose env23278 (packedSelected [1] rootPS)) = affineNative (2^(17+1) ^^^ 98976) := by decide +kernel

theorem selectedBound23278 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23279 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,129,1,32768,65536,1,98976,273,32769,0,805,17,68226,9,17,68359,0,0,65545,35731,34827,256,98566,1,512]

theorem envBound23279 : H12AffineFastState.Bounded env23279 := by
  intro p hp
  have h : env23279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23278_23279 : H12AffineEnvironment.transform 17 98976 env23278 = env23279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 98976 env23278 == env23279) = true)

def env23280 : List Nat := [2,4,8,16,32,17,128,256,396,273,2048,1,129,1,32768,65536,1,98604,273,32769,0,169,17,67854,9,17,67723,0,0,65545,34847,34827,256,98566,1,396]

theorem envBound23280 : H12AffineFastState.Bounded env23280 := by
  intro p hp
  have h : env23280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23279_23280 : H12AffineEnvironment.transform 8 396 env23279 = env23280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 396 env23279 == env23280) = true)

theorem identity23280 : scanCanonicalize (H12AffineFastState.compose env23280 (packedSelected [3] rootPS)) = affineNative (2^(15+1) ^^^ 2088) := by decide +kernel

theorem selectedBound23280 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env23281 : List Nat := [2,4,8,16,32,17,128,256,396,273,2048,1,129,1,32768,2088,1,35076,273,32769,0,169,17,294,9,17,163,0,0,2081,34847,34827,256,35118,1,396]

theorem envBound23281 : H12AffineFastState.Bounded env23281 := by
  intro p hp
  have h : env23281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23280_23281 : H12AffineEnvironment.transform 15 2088 env23280 = env23281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2088 env23280 == env23281) = true)

theorem identity23281 : scanCanonicalize (H12AffineFastState.compose env23281 (packedSelected [8,10,12,13,15,17] rootPS)) = affineNative (2^(14+1) ^^^ 169) := by decide +kernel

theorem selectedBound23281 : packedSelected [8,10,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env23282 : List Nat := [2,4,8,16,32,17,128,256,396,273,2048,1,129,1,169,2088,1,2477,273,168,0,169,17,294,9,17,163,0,0,2081,2230,2210,256,2439,1,396]

theorem envBound23282 : H12AffineFastState.Bounded env23282 := by
  intro p hp
  have h : env23282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23281_23282 : H12AffineEnvironment.transform 14 169 env23281 = env23282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 169 env23281 == env23282) = true)

theorem identity23282 : scanCanonicalize (H12AffineFastState.compose env23282 (packedSelected [0,4,7,8,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound23282 : packedSelected [0,4,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env23283 : List Nat := [2,4,8,16,32,17,128,173,33,188,2048,1,129,1,169,2088,1,2048,188,168,0,169,17,139,9,17,163,0,0,2081,2230,2210,173,2090,1,33]

theorem envBound23283 : H12AffineFastState.Bounded env23283 := by
  intro p hp
  have h : env23283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23282_23283 : H12AffineEnvironment.transform 7 173 env23282 = env23283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env23282 == env23283) = true)

theorem identity23283 : scanCanonicalize (H12AffineFastState.compose env23283 (packedSelected [8] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound23283 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env23284 : List Nat := [2,4,8,16,0,17,128,141,1,156,2048,1,129,1,137,2056,1,2048,156,136,0,137,17,139,9,17,131,0,0,2049,2198,2178,141,2058,1,1]

theorem envBound23284 : H12AffineFastState.Bounded env23284 := by
  intro p hp
  have h : env23284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23283_23284 : H12AffineEnvironment.transform 4 0 env23283 = env23284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env23283 == env23284) = true)

theorem identity23284 : scanCanonicalize (H12AffineFastState.compose env23284 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 27) := by decide +kernel

theorem selectedBound23284 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23285 : List Nat := [2,4,8,16,0,17,128,141,1,156,27,1,129,1,137,19,1,27,156,136,0,137,17,139,9,17,131,0,0,26,141,153,141,17,1,1]

theorem envBound23285 : H12AffineFastState.Bounded env23285 := by
  intro p hp
  have h : env23285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23284_23285 : H12AffineEnvironment.transform 10 27 env23284 = env23285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 27 env23284 == env23285) = true)

def env23286 : List Nat := [2,4,8,16,32,17,128,256,397,273,2048,1,129,1,32768,65536,1,98605,273,32769,0,168,17,67855,9,17,67722,0,0,65545,34846,34827,256,98566,1,397]

theorem envBound23286 : H12AffineFastState.Bounded env23286 := by
  intro p hp
  have h : env23286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23279_23286 : H12AffineEnvironment.transform 8 397 env23279 = env23286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 397 env23279 == env23286) = true)

theorem identity23286 : scanCanonicalize (H12AffineFastState.compose env23286 (packedSelected [3] rootPS)) = affineNative (2^(15+1) ^^^ 32803) := by decide +kernel

theorem selectedBound23286 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env23287 : List Nat := [2,4,8,16,32,17,128,256,397,273,2048,1,129,1,32768,32803,1,270,273,32769,0,168,17,35116,9,17,34985,0,0,32810,34846,34827,256,293,1,397]

theorem envBound23287 : H12AffineFastState.Bounded env23287 := by
  intro p hp
  have h : env23287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23286_23287 : H12AffineEnvironment.transform 15 32803 env23286 = env23287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32803 env23286 == env23287) = true)

theorem identity23287 : scanCanonicalize (H12AffineFastState.compose env23287 (packedSelected [8,10,12,13,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 162) := by decide +kernel

theorem selectedBound23287 : packedSelected [8,10,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env23288 : List Nat := [2,4,8,16,32,17,128,256,397,273,162,1,129,1,32768,32803,1,270,273,32769,0,168,17,33166,9,17,32779,0,0,32810,32956,32937,256,293,1,397]

theorem envBound23288 : H12AffineFastState.Bounded env23288 := by
  intro p hp
  have h : env23288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23287_23288 : H12AffineEnvironment.transform 10 162 env23287 = env23288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 162 env23287 == env23288) = true)

theorem identity23288 : scanCanonicalize (H12AffineFastState.compose env23288 (packedSelected [0,4,7,8,9,10] rootPS)) = affineNative (2^(14+1) ^^^ 261) := by decide +kernel

theorem selectedBound23288 : packedSelected [0,4,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env23289 : List Nat := [2,4,8,16,32,17,128,256,397,273,162,1,129,1,261,294,1,270,273,260,0,168,17,139,9,17,270,0,0,303,441,428,256,293,1,397]

theorem envBound23289 : H12AffineFastState.Bounded env23289 := by
  intro p hp
  have h : env23289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23288_23289 : H12AffineEnvironment.transform 14 261 env23288 = env23289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 261 env23288 == env23289) = true)

theorem identity23289 : scanCanonicalize (H12AffineFastState.compose env23289 (packedSelected [8] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound23289 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env23290 : List Nat := [2,4,8,16,0,17,128,256,397,273,130,1,129,1,261,262,1,270,273,260,0,136,17,139,9,17,270,0,0,271,409,396,256,261,1,397]

theorem envBound23290 : H12AffineFastState.Bounded env23290 := by
  intro p hp
  have h : env23290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23289_23290 : H12AffineEnvironment.transform 4 0 env23289 = env23290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env23289 == env23290) = true)

theorem identity23290 : scanCanonicalize (H12AffineFastState.compose env23290 (packedSelected [0,2,4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound23290 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env23291 : List Nat := [2,4,8,0,0,1,128,256,397,257,130,1,129,1,261,262,1,270,257,260,0,136,1,139,9,1,270,0,0,271,393,396,256,261,1,397]

theorem envBound23291 : H12AffineFastState.Bounded env23291 := by
  intro p hp
  have h : env23291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23290_23291 : H12AffineEnvironment.transform 3 0 env23290 = env23291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env23290 == env23291) = true)

theorem identity23291 : scanCanonicalize (H12AffineFastState.compose env23291 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound23291 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env23292 : List Nat := [2,4,8,0,0,1,128,4,137,5,130,1,129,1,1,2,1,10,5,0,0,136,1,139,9,1,10,0,0,11,141,136,4,1,1,137]

theorem envBound23292 : H12AffineFastState.Bounded env23292 := by
  intro p hp
  have h : env23292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23291_23292 : H12AffineEnvironment.transform 7 4 env23291 = env23292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env23291 == env23292) = true)

theorem identity23292 : scanCanonicalize (H12AffineFastState.compose env23292 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound23292 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23293 : List Nat := [2,4,8,0,0,1,9,4,0,5,11,1,8,1,1,2,1,10,5,0,0,1,1,2,9,1,10,0,0,11,4,1,4,1,1,0]

theorem envBound23293 : H12AffineFastState.Bounded env23293 := by
  intro p hp
  have h : env23293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23292_23293 : H12AffineEnvironment.transform 6 9 env23292 = env23293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env23292 == env23293) = true)

theorem identity23293 : scanCanonicalize (H12AffineFastState.compose env23293 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound23293 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23294 : List Nat := [2,4,3,0,0,1,2,4,0,5,0,1,3,1,1,2,1,1,5,0,0,1,1,2,2,1,1,0,0,0,4,1,4,1,1,0]

theorem envBound23294 : H12AffineFastState.Bounded env23294 := by
  intro p hp
  have h : env23294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23293_23294 : H12AffineEnvironment.transform 2 3 env23293 = env23294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env23293 == env23294) = true)

def env23295 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,4194304,147521,16777216,8328,672784,21484817,16384,676865,1073741824,16876545,4294967296,257,4315938986,676945,512]

theorem envBound23295 : H12AffineFastState.Bounded env23295 := by
  intro p hp
  have h : env23295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23174_23295 : H12AffineEnvironment.transform 22 147521 env23174 = env23295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147521 env23174 == env23295) = true)

def env23296 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,524288,32769,4097,4194304,17665,16777216,8328,541008,21352529,16384,545089,1073741824,16876545,4294967296,257,4315938986,545041,512]

theorem envBound23296 : H12AffineFastState.Bounded env23296 := by
  intro p hp
  have h : env23296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23295_23296 : H12AffineEnvironment.transform 16 1344 env23295 = env23296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env23295 == env23296) = true)

theorem identity23296 : scanCanonicalize (H12AffineFastState.compose env23296 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(23+1) ^^^ 98565) := by decide +kernel

theorem selectedBound23296 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env23297 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,524288,32769,4097,4194304,17665,98565,8328,541008,4477268,16384,545089,1073741824,1284,4294967296,257,4299260335,545041,512]

theorem envBound23297 : H12AffineFastState.Bounded env23297 := by
  intro p hp
  have h : env23297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23296_23297 : H12AffineEnvironment.transform 23 98565 env23296 = env23297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98565 env23296 == env23297) = true)

def env23298 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,21504,32769,4097,4194304,17665,98565,8328,5456,4477268,16384,1345,1073741824,1284,4294967296,257,4299260335,1297,512]

theorem envBound23298 : H12AffineFastState.Bounded env23298 := by
  intro p hp
  have h : env23298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23297_23298 : H12AffineEnvironment.transform 18 21504 env23297 = env23298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21504 env23297 == env23298) = true)

theorem identity23298 : scanCanonicalize (H12AffineFastState.compose env23298 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 4176) := by decide +kernel

theorem selectedBound23298 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env23299 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,1344,262144,1104,32769,4097,4194304,5457,98565,8328,5456,4456708,4176,1345,1073741824,1284,4294967296,257,4299260335,1297,512]

theorem envBound23299 : H12AffineFastState.Bounded env23299 := by
  intro p hp
  have h : env23299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23298_23299 : H12AffineEnvironment.transform 13 4176 env23298 = env23299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env23298 == env23299) = true)

theorem identity23299 : scanCanonicalize (H12AffineFastState.compose env23299 (packedSelected [9,22] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound23299 : packedSelected [9,22] rootPS < 2^1333 := by decide +kernel

def env23300 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,32768,65536,1297,262144,1025,32769,4097,4194304,5376,98565,8328,5377,4456708,4097,1296,1073741824,1284,4294967296,257,4299260335,1297,512]

theorem envBound23300 : H12AffineFastState.Bounded env23300 := by
  intro p hp
  have h : env23300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23299_23300 : H12AffineEnvironment.transform 5 17 env23299 = env23300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23299 == env23300) = true)

theorem identity23300 : scanCanonicalize (H12AffineFastState.compose env23300 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 76199) := by decide +kernel

theorem selectedBound23300 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env23301 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,32768,65536,1297,76199,1025,32769,4097,4194304,5376,98565,8328,5377,4270243,4097,1296,1073741824,1284,4294967296,257,4299260335,1297,512]

theorem envBound23301 : H12AffineFastState.Bounded env23301 := by
  intro p hp
  have h : env23301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23300_23301 : H12AffineEnvironment.transform 17 76199 env23300 = env23301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76199 env23300 == env23301) = true)

theorem identity23301 : scanCanonicalize (H12AffineFastState.compose env23301 (packedSelected [3,8,12,13] rootPS)) = affineNative (2^(15+1) ^^^ 33166) := by decide +kernel

theorem selectedBound23301 : packedSelected [3,8,12,13] rootPS < 2^1333 := by decide +kernel

def env23302 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,32768,33166,1297,43049,1025,32769,4097,4194304,5376,139,8328,5377,4237613,4097,1296,1073741824,1284,4294967296,257,4299161633,1297,512]

theorem envBound23302 : H12AffineFastState.Bounded env23302 := by
  intro p hp
  have h : env23302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23301_23302 : H12AffineEnvironment.transform 15 33166 env23301 = env23302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33166 env23301 == env23302) = true)

theorem identity23302 : scanCanonicalize (H12AffineFastState.compose env23302 (packedSelected [3,8,10] rootPS)) = affineNative (2^(29+1) ^^^ 4196612) := by decide +kernel

theorem selectedBound23302 : packedSelected [3,8,10] rootPS < 2^1333 := by decide +kernel

def env23303 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,32768,33166,1297,43049,1025,32769,4097,4194304,5376,139,8328,5377,4237613,4097,1296,4196612,1284,4294967296,257,4299161633,1297,512]

theorem envBound23303 : H12AffineFastState.Bounded env23303 := by
  intro p hp
  have h : env23303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23302_23303 : H12AffineEnvironment.transform 29 4196612 env23302 = env23303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4196612 env23302 == env23303) = true)

def env23304 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1297,32768,33166,1297,43049,1025,32769,1297,4194304,16,139,8328,17,4237613,1297,1296,4196612,1284,4294967296,257,4299161633,1297,512]

theorem envBound23304 : H12AffineFastState.Bounded env23304 := by
  intro p hp
  have h : env23304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23303_23304 : H12AffineEnvironment.transform 11 1296 env23303 = env23304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env23303 == env23304) = true)

theorem identity23304 : scanCanonicalize (H12AffineFastState.compose env23304 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 10880) := by decide +kernel

theorem selectedBound23304 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23305 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1297,32768,33166,1297,43049,1025,32769,1297,4194304,16,139,8328,17,4237613,1297,1296,4196612,1284,10880,257,4205217,1297,512]

theorem envBound23305 : H12AffineFastState.Bounded env23305 := by
  intro p hp
  have h : env23305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23304_23305 : H12AffineEnvironment.transform 31 10880 env23304 = env23305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 10880 env23304 == env23305) = true)

theorem identity23305 : scanCanonicalize (H12AffineFastState.compose env23305 (packedSelected [3] rootPS)) = affineNative (2^(21+1) ^^^ 41260) := by decide +kernel

theorem selectedBound23305 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env23306 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1297,32768,33166,1297,43049,1025,32769,1297,41260,16,139,8328,17,2049,1297,1296,43048,1284,10880,257,35725,1297,512]

theorem envBound23306 : H12AffineFastState.Bounded env23306 := by
  intro p hp
  have h : env23306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23305_23306 : H12AffineEnvironment.transform 21 41260 env23305 = env23306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41260 env23305 == env23306) = true)

theorem identity23306 : scanCanonicalize (H12AffineFastState.compose env23306 (packedSelected [5] rootPS)) = affineNative (2^(12+1) ^^^ 2600) := by decide +kernel

theorem selectedBound23306 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env23307 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,2600,1297,32768,33166,1297,33281,1025,32769,1297,35588,16,139,2720,17,2049,1297,1296,33280,1284,168,257,35725,1297,512]

theorem envBound23307 : H12AffineFastState.Bounded env23307 := by
  intro p hp
  have h : env23307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23306_23307 : H12AffineEnvironment.transform 12 2600 env23306 = env23307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2600 env23306 == env23307) = true)

theorem identity23307 : scanCanonicalize (H12AffineFastState.compose env23307 (packedSelected [0,4] rootPS)) = affineNative (2^(14+1) ^^^ 2477) := by decide +kernel

theorem selectedBound23307 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env23308 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,2600,1297,2477,2083,1297,2988,1025,2476,1297,681,16,139,2720,17,2049,1297,1296,2989,1284,168,257,544,1297,512]

theorem envBound23308 : H12AffineFastState.Bounded env23308 := by
  intro p hp
  have h : env23308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23307_23308 : H12AffineEnvironment.transform 14 2477 env23307 = env23308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2477 env23307 == env23308) = true)

def env23309 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,1296,2600,1297,2341,2083,1297,2852,1025,2340,1297,545,16,3,2600,17,2049,1297,1296,2853,1284,32,257,544,1297,512]

theorem envBound23309 : H12AffineFastState.Bounded env23309 := by
  intro p hp
  have h : env23309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23308_23309 : H12AffineEnvironment.transform 6 8 env23308 = env23309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env23308 == env23309) = true)

theorem identity23309 : scanCanonicalize (H12AffineFastState.compose env23309 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound23309 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23310 : List Nat := [2,4,8,16,32,17,8,256,32,1024,2048,1296,2056,1297,2341,2083,1297,2308,1025,2340,1297,1,16,3,2056,17,2049,1297,1296,2309,1284,32,257,0,1297,32]

theorem envBound23310 : H12AffineFastState.Bounded env23310 := by
  intro p hp
  have h : env23310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23309_23310 : H12AffineEnvironment.transform 8 32 env23309 = env23310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env23309 == env23310) = true)

def env23311 : List Nat := [2,4,8,16,0,17,8,256,0,1024,2048,1296,2056,1297,2309,2051,1297,2308,1025,2308,1297,1,16,3,2056,17,2049,1297,1296,2309,1284,0,257,0,1297,0]

theorem envBound23311 : H12AffineFastState.Bounded env23311 := by
  intro p hp
  have h : env23311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23310_23311 : H12AffineEnvironment.transform 4 0 env23310 = env23311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env23310 == env23311) = true)

theorem identity23311 : scanCanonicalize (H12AffineFastState.compose env23311 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound23311 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23312 : List Nat := [2,4,8,16,0,17,8,4,0,1024,2048,1044,2056,1045,2049,2051,1045,2048,1025,2048,1045,1,16,3,2056,17,2049,1045,1044,2049,1024,0,5,0,1045,0]

theorem envBound23312 : H12AffineFastState.Bounded env23312 := by
  intro p hp
  have h : env23312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23311_23312 : H12AffineEnvironment.transform 7 4 env23311 = env23312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env23311 == env23312) = true)

def leafEnv23312 : List Nat := [2,4,8,16,0,17,8,4,0,1024,2048,1044,2056,1045,2049,2051,1045,2048,1025,2048,1045,1,16,3,1025,2056,1,17,2049,1045,1044,2049,1024,0,5,0,5,2050,1045,0,0,1045,1]

end H12CloudChart2