import H12CloudChart2Data105

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity26007 : scanCanonicalize (H12AffineFastState.compose env26007 (packedSelected [4,7] rootPS)) = affineNative (2^(9+1) ^^^ 565) := by decide +kernel

theorem selectedBound26007 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env26008 : List Nat := [2,4,8,16,32,64,57,68,512,565,42,80,72,561,0,115,0,75,565,0,608,32,64,50,121,16,42,1,81,75,629,65,68,65,561,513]

theorem envBound26008 : H12AffineFastState.Bounded env26008 := by
  intro p hp
  have h : env26008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26007_26008 : H12AffineEnvironment.transform 9 565 env26007 = env26008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 565 env26007 == env26008) = true)

theorem identity26008 : scanCanonicalize (H12AffineFastState.compose env26008 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound26008 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26009 : List Nat := [2,4,5,16,32,64,52,68,512,565,39,80,69,561,0,115,0,70,565,0,608,32,64,50,116,16,39,1,81,70,629,65,68,65,561,513]

theorem envBound26009 : H12AffineFastState.Bounded env26009 := by
  intro p hp
  have h : env26009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26008_26009 : H12AffineEnvironment.transform 2 5 env26008 = env26009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env26008 == env26009) = true)

theorem identity26009 : scanCanonicalize (H12AffineFastState.compose env26009 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound26009 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env26010 : List Nat := [2,4,5,6,32,64,34,68,512,547,39,70,69,551,0,101,0,70,547,0,608,32,64,36,98,6,39,1,71,70,611,65,68,65,551,513]

theorem envBound26010 : H12AffineFastState.Bounded env26010 := by
  intro p hp
  have h : env26010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26009_26010 : H12AffineEnvironment.transform 3 6 env26009 = env26010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env26009 == env26010) = true)

theorem identity26010 : scanCanonicalize (H12AffineFastState.compose env26010 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 6) := by decide +kernel

theorem selectedBound26010 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env26011 : List Nat := [2,4,5,6,32,6,34,2,512,547,39,0,3,551,0,35,0,0,547,0,550,32,6,36,36,6,39,1,1,0,549,7,2,7,551,513]

theorem envBound26011 : H12AffineFastState.Bounded env26011 := by
  intro p hp
  have h : env26011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26010_26011 : H12AffineEnvironment.transform 5 6 env26010 = env26011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 6 env26010 == env26011) = true)

theorem identity26011 : scanCanonicalize (H12AffineFastState.compose env26011 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound26011 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env26012 : List Nat := [2,4,5,6,7,6,5,2,512,516,0,0,3,512,0,4,0,0,516,0,513,7,6,3,3,6,0,1,1,0,514,7,2,7,512,513]

theorem envBound26012 : H12AffineFastState.Bounded env26012 := by
  intro p hp
  have h : env26012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26011_26012 : H12AffineEnvironment.transform 4 7 env26011 = env26012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env26011 == env26012) = true)

def env26013 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,30041,29994,17413,9783,1024,30041,16464,21896,21524,375,8328,21572,29371,17412,4097,23920,1285,261,256,21841,5205,513]

theorem envBound26013 : H12AffineFastState.Bounded env26013 := by
  intro p hp
  have h : env26013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25992_26013 : H12AffineEnvironment.transform 14 30041 env25992 = env26013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 30041 env25992 == env26013) = true)

theorem identity26013 : scanCanonicalize (H12AffineFastState.compose env26013 (packedSelected [6] rootPS)) = affineNative (2^(13+1) ^^^ 1109) := by decide +kernel

theorem selectedBound26013 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env26014 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1109,12556,12671,80,9783,1024,12556,1029,4573,4161,375,8328,4113,14062,81,4097,6437,1285,261,256,4356,5205,513]

theorem envBound26014 : H12AffineFastState.Bounded env26014 := by
  intro p hp
  have h : env26014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26013_26014 : H12AffineEnvironment.transform 13 1109 env26013 = env26014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1109 env26013 == env26014) = true)

theorem identity26014 : scanCanonicalize (H12AffineFastState.compose env26014 (packedSelected [3,8,10,13,17] rootPS)) = affineNative (2^(11+1) ^^^ 1945) := by decide +kernel

theorem selectedBound26014 : packedSelected [3,8,10,13,17] rootPS < 2^1333 := by decide +kernel

def env26015 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1945,8192,1109,9877,9958,80,9783,1024,9877,1029,1604,2008,375,8328,1928,8567,81,1944,3772,1285,261,256,1693,972,513]

theorem envBound26015 : H12AffineFastState.Bounded env26015 := by
  intro p hp
  have h : env26015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26014_26015 : H12AffineEnvironment.transform 11 1945 env26014 = env26015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1945 env26014 == env26015) = true)

def env26016 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1945,240,1109,1637,1558,80,1735,1024,1637,1029,1604,2008,375,120,1928,391,81,1944,3772,1285,261,256,1693,972,513]

theorem envBound26016 : H12AffineFastState.Bounded env26016 := by
  intro p hp
  have h : env26016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26015_26016 : H12AffineEnvironment.transform 12 240 env26015 = env26016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 240 env26015 == env26016) = true)

theorem identity26016 : scanCanonicalize (H12AffineFastState.compose env26016 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 880) := by decide +kernel

theorem selectedBound26016 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26017 : List Nat := [2,4,8,16,32,64,128,256,512,880,2048,233,240,805,277,358,80,439,880,277,885,308,168,375,120,248,391,81,232,2508,629,261,256,493,972,513]

theorem envBound26017 : H12AffineFastState.Bounded env26017 := by
  intro p hp
  have h : env26017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26016_26017 : H12AffineEnvironment.transform 9 880 env26016 = env26017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 880 env26016 == env26017) = true)

theorem identity26017 : scanCanonicalize (H12AffineFastState.compose env26017 (packedSelected [4,5,8,9,11] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound26017 : packedSelected [4,5,8,9,11] rootPS < 2^1333 := by decide +kernel

def env26018 : List Nat := [2,4,8,16,32,64,128,252,512,652,2048,233,240,729,233,154,80,75,652,233,649,200,168,139,120,248,123,81,232,2096,629,249,252,17,560,513]

theorem envBound26018 : H12AffineFastState.Bounded env26018 := by
  intro p hp
  have h : env26018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26017_26018 : H12AffineEnvironment.transform 7 252 env26017 = env26018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env26017 == env26018) = true)

theorem identity26018 : scanCanonicalize (H12AffineFastState.compose env26018 (packedSelected [3,8,10] rootPS)) = affineNative (2^(10+1) ^^^ 123) := by decide +kernel

theorem selectedBound26018 : packedSelected [3,8,10] rootPS < 2^1333 := by decide +kernel

def env26019 : List Nat := [2,4,8,16,32,64,128,252,512,652,123,233,240,729,233,154,80,75,652,233,649,200,168,139,120,248,123,81,232,75,629,249,252,17,560,513]

theorem envBound26019 : H12AffineFastState.Bounded env26019 := by
  intro p hp
  have h : env26019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26018_26019 : H12AffineEnvironment.transform 10 123 env26018 = env26019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 123 env26018 == env26019) = true)

theorem identity26019 : scanCanonicalize (H12AffineFastState.compose env26019 (packedSelected [4,7] rootPS)) = affineNative (2^(6+1) ^^^ 105) := by decide +kernel

theorem selectedBound26019 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env26020 : List Nat := [2,4,8,16,32,64,105,21,512,613,123,0,25,560,0,115,80,75,613,0,608,33,65,98,120,17,123,81,1,75,629,16,21,17,560,513]

theorem envBound26020 : H12AffineFastState.Bounded env26020 := by
  intro p hp
  have h : env26020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26019_26020 : H12AffineEnvironment.transform 6 105 env26019 = env26020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 105 env26019 == env26020) = true)

theorem identity26020 : scanCanonicalize (H12AffineFastState.compose env26020 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 61) := by decide +kernel

theorem selectedBound26020 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26021 : List Nat := [2,4,8,16,32,64,105,21,61,88,123,0,25,13,0,115,80,75,88,0,93,33,65,98,120,17,123,81,1,75,72,16,21,17,13,60]

theorem envBound26021 : H12AffineFastState.Bounded env26021 := by
  intro p hp
  have h : env26021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26020_26021 : H12AffineEnvironment.transform 8 61 env26020 = env26021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 61 env26020 == env26021) = true)

theorem identity26021 : scanCanonicalize (H12AffineFastState.compose env26021 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound26021 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env26022 : List Nat := [2,4,8,16,32,10,35,21,61,18,49,0,25,13,0,57,26,1,18,0,23,33,11,40,50,17,49,27,1,1,2,16,21,17,13,60]

theorem envBound26022 : H12AffineFastState.Bounded env26022 := by
  intro p hp
  have h : env26022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26021_26022 : H12AffineEnvironment.transform 5 10 env26021 = env26022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env26021 == env26022) = true)

theorem identity26022 : scanCanonicalize (H12AffineFastState.compose env26022 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound26022 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26023 : List Nat := [2,4,8,11,32,10,35,14,38,9,42,0,2,13,0,34,1,1,9,0,12,33,11,40,41,10,42,0,1,1,2,11,14,10,13,39]

theorem envBound26023 : H12AffineFastState.Bounded env26023 := by
  intro p hp
  have h : env26023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26022_26023 : H12AffineEnvironment.transform 3 11 env26022 = env26023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env26022 == env26023) = true)

theorem identity26023 : scanCanonicalize (H12AffineFastState.compose env26023 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound26023 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env26024 : List Nat := [2,4,8,11,11,10,8,14,13,9,1,0,2,13,0,9,1,1,9,0,12,10,11,3,2,10,1,0,1,1,2,11,14,10,13,12]

theorem envBound26024 : H12AffineFastState.Bounded env26024 := by
  intro p hp
  have h : env26024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26023_26024 : H12AffineEnvironment.transform 4 11 env26023 = env26024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env26023 == env26024) = true)

def env26025 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1945,241,1109,1636,1559,80,1734,1024,1636,1029,1604,2008,375,121,1928,390,81,1944,3772,1285,261,256,1693,972,513]

theorem envBound26025 : H12AffineFastState.Bounded env26025 := by
  intro p hp
  have h : env26025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26015_26025 : H12AffineEnvironment.transform 12 241 env26015 = env26025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 241 env26015 == env26025) = true)

theorem identity26025 : scanCanonicalize (H12AffineFastState.compose env26025 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 652) := by decide +kernel

theorem selectedBound26025 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26026 : List Nat := [2,4,8,16,32,64,128,256,512,652,2048,277,241,729,232,155,80,74,652,232,649,200,340,375,121,260,390,81,276,2096,905,261,256,17,972,513]

theorem envBound26026 : H12AffineFastState.Bounded env26026 := by
  intro p hp
  have h : env26026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26025_26026 : H12AffineEnvironment.transform 9 652 env26025 = env26026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 652 env26025 == env26026) = true)

theorem identity26026 : scanCanonicalize (H12AffineFastState.compose env26026 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound26026 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env26027 : List Nat := [2,4,8,16,32,64,128,252,512,652,2048,233,241,729,232,155,80,74,652,232,649,200,168,139,121,248,122,81,232,2096,629,249,252,17,560,513]

theorem envBound26027 : H12AffineFastState.Bounded env26027 := by
  intro p hp
  have h : env26027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26026_26027 : H12AffineEnvironment.transform 7 252 env26026 = env26027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env26026 == env26027) = true)

theorem identity26027 : scanCanonicalize (H12AffineFastState.compose env26027 (packedSelected [3,8,10] rootPS)) = affineNative (2^(10+1) ^^^ 122) := by decide +kernel

theorem selectedBound26027 : packedSelected [3,8,10] rootPS < 2^1333 := by decide +kernel

def env26028 : List Nat := [2,4,8,16,32,64,128,252,512,652,122,233,241,729,232,155,80,74,652,232,649,200,168,139,121,248,122,81,232,74,629,249,252,17,560,513]

theorem envBound26028 : H12AffineFastState.Bounded env26028 := by
  intro p hp
  have h : env26028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26027_26028 : H12AffineEnvironment.transform 10 122 env26027 = env26028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 122 env26027 == env26028) = true)

theorem identity26028 : scanCanonicalize (H12AffineFastState.compose env26028 (packedSelected [4,7] rootPS)) = affineNative (2^(6+1) ^^^ 105) := by decide +kernel

theorem selectedBound26028 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env26029 : List Nat := [2,4,8,16,32,64,105,21,512,613,122,0,24,560,1,114,80,74,613,1,608,33,65,98,121,17,122,81,1,74,629,16,21,17,560,513]

theorem envBound26029 : H12AffineFastState.Bounded env26029 := by
  intro p hp
  have h : env26029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26028_26029 : H12AffineEnvironment.transform 6 105 env26028 = env26029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 105 env26028 == env26029) = true)

theorem identity26029 : scanCanonicalize (H12AffineFastState.compose env26029 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 60) := by decide +kernel

theorem selectedBound26029 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26030 : List Nat := [2,4,8,16,32,64,105,21,60,89,122,0,24,12,1,114,80,74,89,1,92,33,65,98,121,17,122,81,1,74,73,16,21,17,12,61]

theorem envBound26030 : H12AffineFastState.Bounded env26030 := by
  intro p hp
  have h : env26030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26029_26030 : H12AffineEnvironment.transform 8 60 env26029 = env26030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 60 env26029 == env26030) = true)

theorem identity26030 : scanCanonicalize (H12AffineFastState.compose env26030 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound26030 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env26031 : List Nat := [2,4,8,16,32,11,34,21,60,18,49,0,24,12,1,57,27,1,18,1,23,33,10,41,50,17,49,26,1,1,2,16,21,17,12,61]

theorem envBound26031 : H12AffineFastState.Bounded env26031 := by
  intro p hp
  have h : env26031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26030_26031 : H12AffineEnvironment.transform 5 11 env26030 = env26031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env26030 == env26031) = true)

theorem identity26031 : scanCanonicalize (H12AffineFastState.compose env26031 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound26031 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26032 : List Nat := [2,4,8,16,10,11,8,21,22,18,27,0,24,12,1,19,27,1,18,1,23,11,10,3,24,17,27,26,1,1,2,16,21,17,12,23]

theorem envBound26032 : H12AffineFastState.Bounded env26032 := by
  intro p hp
  have h : env26032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26031_26032 : H12AffineEnvironment.transform 4 10 env26031 = env26032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env26031 == env26032) = true)

def env26033 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,2248769,16777216,8328,2248721,21331969,4399266,4272290,4294795,16876545,4329609,256,16912418,151633,513]

theorem envBound26033 : H12AffineFastState.Bounded env26033 := by
  intro p hp
  have h : env26033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25985_26033 : H12AffineEnvironment.transform 26 21331969 env25985 = env26033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 21331969 env25985 == env26033) = true)

theorem identity26033 : scanCanonicalize (H12AffineFastState.compose env26033 (packedSelected [14] rootPS)) = affineNative (2^(23+1) ^^^ 2250099) := by decide +kernel

theorem selectedBound26033 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env26034 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,2248769,2250099,8328,2248721,6804850,4399266,4272290,4294795,2347378,4329609,256,2114897,151633,513]

theorem envBound26034 : H12AffineFastState.Bounded env26034 := by
  intro p hp
  have h : env26034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26033_26034 : H12AffineEnvironment.transform 23 2250099 env26033 = env26034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2250099 env26033 == env26034) = true)

theorem identity26034 : scanCanonicalize (H12AffineFastState.compose env26034 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(20+1) ^^^ 249970) := by decide +kernel

theorem selectedBound26034 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env26035 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,249970,4194304,98355,99585,8328,98403,4457728,4399266,4272290,4294795,256,4329609,256,234787,151633,513]

theorem envBound26035 : H12AffineFastState.Bounded env26035 := by
  intro p hp
  have h : env26035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26034_26035 : H12AffineEnvironment.transform 20 249970 env26034 = env26035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 249970 env26034 == env26035) = true)

theorem identity26035 : scanCanonicalize (H12AffineFastState.compose env26035 (packedSelected [13,21] rootPS)) = affineNative (2^(21+1) ^^^ 136584) := by decide +kernel

theorem selectedBound26035 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env26036 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,249970,136584,98355,99585,8328,98403,397448,79146,206122,236803,256,1281,256,234787,151633,513]

theorem envBound26036 : H12AffineFastState.Bounded env26036 := by
  intro p hp
  have h : env26036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26035_26036 : H12AffineEnvironment.transform 21 136584 env26035 = env26036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 136584 env26035 == env26036) = true)

def env26037 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,2248769,16777216,8328,2248720,134217728,151429282,151302306,4294795,16876544,151490696,257,138907683,155701329,513]

theorem envBound26037 : H12AffineFastState.Bounded env26037 := by
  intro p hp
  have h : env26037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25984_26037 : H12AffineEnvironment.transform 18 1025 env25984 = env26037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env25984 == env26037) = true)

def env26038 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,2248769,16777216,8328,2248720,21331968,4399266,4272290,4294795,16876544,4329608,257,16912419,151633,513]

theorem envBound26038 : H12AffineFastState.Bounded env26038 := by
  intro p hp
  have h : env26038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26037_26038 : H12AffineEnvironment.transform 26 21331968 env26037 = env26038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 21331968 env26037 == env26038) = true)

theorem identity26038 : scanCanonicalize (H12AffineFastState.compose env26038 (packedSelected [14] rootPS)) = affineNative (2^(23+1) ^^^ 2117683) := by decide +kernel

theorem selectedBound26038 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env26039 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,2248769,2117683,8328,2248720,6672435,4399266,4272290,4294795,2217011,4329608,257,2244624,151633,513]

theorem envBound26039 : H12AffineFastState.Bounded env26039 := by
  intro p hp
  have h : env26039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26038_26039 : H12AffineEnvironment.transform 23 2117683 env26038 = env26039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2117683 env26038 == env26039) = true)

theorem identity26039 : scanCanonicalize (H12AffineFastState.compose env26039 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(21+1) ^^^ 78263) := by decide +kernel

theorem selectedBound26039 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env26040 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,78263,2248769,2117683,8328,2248720,2417028,135445,277,47420,2217011,205119,257,2244624,151633,513]

theorem envBound26040 : H12AffineFastState.Bounded env26040 := by
  intro p hp
  have h : env26040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26039_26040 : H12AffineEnvironment.transform 21 78263 env26039 = env26040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 78263 env26039 == env26040) = true)

theorem identity26040 : scanCanonicalize (H12AffineFastState.compose env26040 (packedSelected [13,21] rootPS)) = affineNative (2^(16+1) ^^^ 45404) := by decide +kernel

theorem selectedBound26040 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env26041 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,45404,262144,1025,32768,2097152,78263,2154781,2117683,8328,2154828,2417028,41033,277,47420,2217011,102499,257,2158924,57613,513]

theorem envBound26041 : H12AffineFastState.Bounded env26041 := by
  intro p hp
  have h : env26041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26040_26041 : H12AffineEnvironment.transform 16 45404 env26040 = env26041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45404 env26040 == env26041) = true)

def env26042 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,2248769,16777216,8328,2248720,21331969,4399267,4272291,4294795,16876544,4329609,257,16912418,151632,513]

theorem envBound26042 : H12AffineFastState.Bounded env26042 := by
  intro p hp
  have h : env26042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26037_26042 : H12AffineEnvironment.transform 26 21331969 env26037 = env26042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 21331969 env26037 == env26042) = true)

theorem identity26042 : scanCanonicalize (H12AffineFastState.compose env26042 (packedSelected [14] rootPS)) = affineNative (2^(23+1) ^^^ 16434) := by decide +kernel

theorem selectedBound26042 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env26043 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,2248769,16434,8328,2248720,4571187,4399267,4272291,4294795,115762,4329609,257,151568,151632,513]

theorem envBound26043 : H12AffineFastState.Bounded env26043 := by
  intro p hp
  have h : env26043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26042_26043 : H12AffineEnvironment.transform 23 16434 env26042 = env26043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 16434 env26042 == env26043) = true)

theorem identity26043 : scanCanonicalize (H12AffineFastState.compose env26043 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(20+1) ^^^ 249970) := by decide +kernel

theorem selectedBound26043 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env26044 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,249970,4194304,98355,16434,8328,98402,4571187,4399267,4272291,4294795,115762,4329609,257,151568,151632,513]

theorem envBound26044 : H12AffineFastState.Bounded env26044 := by
  intro p hp
  have h : env26044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26043_26044 : H12AffineEnvironment.transform 20 249970 env26043 = env26044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 249970 env26043 == env26044) = true)

theorem identity26044 : scanCanonicalize (H12AffineFastState.compose env26044 (packedSelected [13,21] rootPS)) = affineNative (2^(21+1) ^^^ 250043) := by decide +kernel

theorem selectedBound26044 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env26045 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,249970,250043,98355,16434,8328,98402,397448,61464,188440,153648,115762,114738,257,151568,151632,513]

theorem envBound26045 : H12AffineFastState.Bounded env26045 := by
  intro p hp
  have h : env26045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26044_26045 : H12AffineEnvironment.transform 21 250043 env26044 = env26045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 250043 env26044 == env26045) = true)

theorem identity26045 : scanCanonicalize (H12AffineFastState.compose env26045 (packedSelected [0,3,5,10,27] rootPS)) = affineNative (2^(16+1) ^^^ 20757) := by decide +kernel

theorem selectedBound26045 : packedSelected [0,3,5,10,27] rootPS < 2^1333 := by decide +kernel

def env26046 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,20757,262144,1025,32768,98663,98734,98355,16434,8328,98402,278941,61464,45325,2341,115762,114738,257,261,325,513]

theorem envBound26046 : H12AffineFastState.Bounded env26046 := by
  intro p hp
  have h : env26046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26045_26046 : H12AffineEnvironment.transform 16 20757 env26045 = env26046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 20757 env26045 == env26046) = true)

def env26047 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,20757,262144,1025,32768,98615,98734,98355,16434,8328,98354,278941,61464,45325,2341,115762,114738,257,261,277,513]

theorem envBound26047 : H12AffineFastState.Bounded env26047 := by
  intro p hp
  have h : env26047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26046_26047 : H12AffineEnvironment.transform 5 16 env26046 = env26047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env26046 == env26047) = true)

theorem identity26047 : scanCanonicalize (H12AffineFastState.compose env26047 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 17447) := by decide +kernel

theorem selectedBound26047 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env26048 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,17447,20757,262144,1025,32768,50448,50569,50196,16434,8328,50197,278941,61464,45325,2341,32789,33813,257,261,277,513]

theorem envBound26048 : H12AffineFastState.Bounded env26048 := by
  intro p hp
  have h : env26048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26047_26048 : H12AffineEnvironment.transform 15 17447 env26047 = env26048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 17447 env26047 == env26048) = true)

def env26049 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,184,32768,1183,4525,262144,1025,32768,34216,34097,33964,138,8328,33965,262437,45216,45325,2341,32789,33813,257,261,277,513]

theorem envBound26049 : H12AffineFastState.Bounded env26049 := by
  intro p hp
  have h : env26049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26048_26049 : H12AffineEnvironment.transform 13 184 env26048 = env26049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 184 env26048 == env26049) = true)

theorem identity26049 : scanCanonicalize (H12AffineFastState.compose env26049 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(17+1) ^^^ 43048) := by decide +kernel

theorem selectedBound26049 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env26050 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,184,32768,1183,4525,43048,1025,32768,34216,34097,33964,138,8328,33965,43277,45216,45325,2341,32789,33813,257,261,277,513]

theorem envBound26050 : H12AffineFastState.Bounded env26050 := by
  intro p hp
  have h : env26050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26049_26050 : H12AffineEnvironment.transform 17 43048 env26049 = env26050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43048 env26049 == env26050) = true)

def env26051 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,184,8232,1183,4525,2048,1025,8232,9600,9497,9348,138,8328,9349,2341,4232,4389,2341,8253,9277,257,261,277,513]

theorem envBound26051 : H12AffineFastState.Bounded env26051 := by
  intro p hp
  have h : env26051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26050_26051 : H12AffineEnvironment.transform 14 8232 env26050 = env26051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env26050 == env26051) = true)

theorem identity26051 : scanCanonicalize (H12AffineFastState.compose env26051 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 62) := by decide +kernel

theorem selectedBound26051 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env26052 : List Nat := [2,4,8,16,32,16,128,62,512,1024,2048,4096,8192,184,8232,1183,4243,2048,1025,8232,9406,9255,9348,138,8328,9349,2075,4232,4123,2075,8253,9277,63,59,43,513]

theorem envBound26052 : H12AffineFastState.Bounded env26052 := by
  intro p hp
  have h : env26052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26051_26052 : H12AffineEnvironment.transform 7 62 env26051 = env26052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 62 env26051 == env26052) = true)

theorem identity26052 : scanCanonicalize (H12AffineFastState.compose env26052 (packedSelected [4,9] rootPS)) = affineNative (2^(9+1) ^^^ 141) := by decide +kernel

theorem selectedBound26052 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env26053 : List Nat := [2,4,8,16,32,16,128,62,512,141,2048,4096,8192,184,8232,18,4243,2048,140,8232,8243,8362,8201,138,8328,8200,2075,4232,4123,2075,8253,8368,63,59,43,513]

theorem envBound26053 : H12AffineFastState.Bounded env26053 := by
  intro p hp
  have h : env26053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26052_26053 : H12AffineEnvironment.transform 9 141 env26052 = env26053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 141 env26052 == env26053) = true)

def env26054 : List Nat := [2,4,8,16,32,16,128,62,512,141,2048,4096,144,184,184,18,4243,2048,140,184,163,58,153,138,24,152,2075,4232,4123,2075,173,32,63,59,43,513]

theorem envBound26054 : H12AffineFastState.Bounded env26054 := by
  intro p hp
  have h : env26054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26053_26054 : H12AffineEnvironment.transform 12 144 env26053 = env26054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 144 env26053 == env26054) = true)

theorem identity26054 : scanCanonicalize (H12AffineFastState.compose env26054 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 146) := by decide +kernel

theorem selectedBound26054 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26055 : List Nat := [2,4,8,16,32,16,128,62,146,141,2048,4096,144,184,184,18,4243,2048,140,184,163,58,153,138,24,152,2075,4232,4123,2075,173,32,63,59,43,147]

theorem envBound26055 : H12AffineFastState.Bounded env26055 := by
  intro p hp
  have h : env26055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26054_26055 : H12AffineEnvironment.transform 8 146 env26054 = env26055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 146 env26054 == env26055) = true)

theorem identity26055 : scanCanonicalize (H12AffineFastState.compose env26055 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2184) := by decide +kernel

theorem selectedBound26055 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env26056 : List Nat := [2,4,8,16,32,16,128,62,146,141,2048,2184,144,184,184,18,2075,2048,140,184,163,58,153,138,24,152,2075,2048,2195,2075,173,32,63,59,43,147]

theorem envBound26056 : H12AffineFastState.Bounded env26056 := by
  intro p hp
  have h : env26056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26055_26056 : H12AffineEnvironment.transform 11 2184 env26055 = env26056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2184 env26055 == env26056) = true)

theorem identity26056 : scanCanonicalize (H12AffineFastState.compose env26056 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound26056 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env26057 : List Nat := [2,4,8,16,32,16,18,62,0,31,2048,2074,2,42,42,18,2075,2048,30,42,49,58,11,24,24,10,2075,2048,2049,2075,63,32,63,59,43,1]

theorem envBound26057 : H12AffineFastState.Bounded env26057 := by
  intro p hp
  have h : env26057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26056_26057 : H12AffineEnvironment.transform 6 18 env26056 = env26057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env26056 == env26057) = true)

theorem identity26057 : scanCanonicalize (H12AffineFastState.compose env26057 (packedSelected [0,5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound26057 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env26058 : List Nat := [2,4,8,11,32,11,9,37,0,4,2048,2049,2,42,42,9,2048,2048,5,42,42,33,11,3,3,10,2048,2048,2049,2048,36,32,36,32,43,1]

theorem envBound26058 : H12AffineFastState.Bounded env26058 := by
  intro p hp
  have h : env26058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26057_26058 : H12AffineEnvironment.transform 3 11 env26057 = env26058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env26057 == env26058) = true)

theorem identity26058 : scanCanonicalize (H12AffineFastState.compose env26058 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound26058 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26059 : List Nat := [2,4,8,11,6,11,9,3,0,4,2048,2049,2,12,12,9,2048,2048,5,12,12,7,11,3,3,10,2048,2048,2049,2048,2,6,2,6,13,1]

theorem envBound26059 : H12AffineFastState.Bounded env26059 := by
  intro p hp
  have h : env26059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26058_26059 : H12AffineEnvironment.transform 4 6 env26058 = env26059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env26058 == env26059) = true)

theorem identity26059 : scanCanonicalize (H12AffineFastState.compose env26059 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 12) := by decide +kernel

theorem selectedBound26059 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env26060 : List Nat := [2,4,8,11,6,11,9,3,0,4,12,13,2,12,12,9,12,12,5,12,12,7,11,3,3,10,12,12,13,12,2,6,2,6,13,1]

theorem envBound26060 : H12AffineFastState.Bounded env26060 := by
  intro p hp
  have h : env26060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26059_26060 : H12AffineEnvironment.transform 10 12 env26059 = env26060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 12 env26059 == env26060) = true)

def env26061 : List Nat := [2,4,8,16,32,16,128,62,512,141,2048,4096,145,184,185,18,4243,2048,140,185,162,59,152,138,25,153,2075,4232,4123,2075,172,33,63,59,43,513]

theorem envBound26061 : H12AffineFastState.Bounded env26061 := by
  intro p hp
  have h : env26061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26053_26061 : H12AffineEnvironment.transform 12 145 env26053 = env26061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 145 env26053 == env26061) = true)

theorem identity26061 : scanCanonicalize (H12AffineFastState.compose env26061 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound26061 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26062 : List Nat := [2,4,8,16,32,16,128,62,1,141,2048,4096,145,184,185,18,4243,2048,140,185,162,59,152,138,25,153,2075,4232,4123,2075,172,33,63,59,43,0]

theorem envBound26062 : H12AffineFastState.Bounded env26062 := by
  intro p hp
  have h : env26062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26061_26062 : H12AffineEnvironment.transform 8 1 env26061 = env26062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env26061 == env26062) = true)

theorem identity26062 : scanCanonicalize (H12AffineFastState.compose env26062 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2194) := by decide +kernel

theorem selectedBound26062 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env26063 : List Nat := [2,4,8,16,32,16,128,62,1,141,2048,2194,145,184,185,18,2049,2048,140,185,162,59,152,138,25,153,2075,2074,2185,2075,172,33,63,59,43,0]

theorem envBound26063 : H12AffineFastState.Bounded env26063 := by
  intro p hp
  have h : env26063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26062_26063 : H12AffineEnvironment.transform 11 2194 env26062 = env26063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2194 env26062 == env26063) = true)

theorem identity26063 : scanCanonicalize (H12AffineFastState.compose env26063 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound26063 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env26064 : List Nat := [2,4,8,16,32,16,18,62,1,31,2048,2048,3,42,43,18,2049,2048,30,43,48,59,10,24,25,11,2075,2074,2075,2075,62,33,63,59,43,0]

theorem envBound26064 : H12AffineFastState.Bounded env26064 := by
  intro p hp
  have h : env26064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26063_26064 : H12AffineEnvironment.transform 6 18 env26063 = env26064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env26063 == env26064) = true)

theorem identity26064 : scanCanonicalize (H12AffineFastState.compose env26064 (packedSelected [0,5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound26064 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env26065 : List Nat := [2,4,8,11,32,11,9,37,1,4,2048,2048,3,42,43,9,2049,2048,5,43,43,32,10,3,2,11,2048,2049,2048,2048,37,33,36,32,43,0]

theorem envBound26065 : H12AffineFastState.Bounded env26065 := by
  intro p hp
  have h : env26065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26064_26065 : H12AffineEnvironment.transform 3 11 env26064 = env26065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env26064 == env26065) = true)

theorem identity26065 : scanCanonicalize (H12AffineFastState.compose env26065 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound26065 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26066 : List Nat := [2,4,5,6,32,6,4,37,1,4,2048,2048,3,39,38,4,2049,2048,5,38,38,32,7,3,2,6,2048,2049,2048,2048,37,33,36,32,38,0]

theorem envBound26066 : H12AffineFastState.Bounded env26066 := by
  intro p hp
  have h : env26066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26065_26066 : H12AffineEnvironment.transform 2 5 env26065 = env26066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env26065 == env26066) = true)

theorem identity26066 : scanCanonicalize (H12AffineFastState.compose env26066 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 39) := by decide +kernel

theorem selectedBound26066 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env26067 : List Nat := [2,4,5,6,32,6,4,37,1,4,39,39,3,39,38,4,38,39,5,38,38,32,7,3,2,6,39,38,39,39,37,33,36,32,38,0]

theorem envBound26067 : H12AffineFastState.Bounded env26067 := by
  intro p hp
  have h : env26067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26066_26067 : H12AffineEnvironment.transform 10 39 env26066 = env26067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 39 env26066 == env26067) = true)

def env26068 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,184,8233,1183,4525,2049,1025,8233,9601,9496,9349,138,8328,9348,2340,4233,4388,2341,8252,9276,257,261,277,513]

theorem envBound26068 : H12AffineFastState.Bounded env26068 := by
  intro p hp
  have h : env26068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26050_26068 : H12AffineEnvironment.transform 14 8233 env26050 = env26068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env26050 == env26068) = true)

theorem identity26068 : scanCanonicalize (H12AffineFastState.compose env26068 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 182) := by decide +kernel

theorem selectedBound26068 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env26069 : List Nat := [2,4,8,16,32,16,128,182,512,1024,2048,4096,8192,184,8233,1183,4123,2049,1025,8233,9271,9390,9349,138,8328,9348,2194,4233,4242,2195,8252,9276,183,179,163,513]

theorem envBound26069 : H12AffineFastState.Bounded env26069 := by
  intro p hp
  have h : env26069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26068_26069 : H12AffineEnvironment.transform 7 182 env26068 = env26069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 182 env26068 == env26069) = true)

theorem identity26069 : scanCanonicalize (H12AffineFastState.compose env26069 (packedSelected [4,9] rootPS)) = affineNative (2^(9+1) ^^^ 30) := by decide +kernel

theorem selectedBound26069 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env26070 : List Nat := [2,4,8,16,32,16,128,182,512,30,2048,4096,8192,184,8233,129,4123,2049,31,8233,8233,8368,8347,138,8328,8346,2194,4233,4242,2195,8252,8226,183,179,163,513]

theorem envBound26070 : H12AffineFastState.Bounded env26070 := by
  intro p hp
  have h : env26070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26069_26070 : H12AffineEnvironment.transform 9 30 env26069 = env26070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 30 env26069 == env26070) = true)

def env26071 : List Nat := [2,4,8,16,32,16,128,182,512,30,2048,4096,24,184,49,129,4123,2049,31,49,49,168,131,138,144,130,2194,4233,4242,2195,36,58,183,179,163,513]

theorem envBound26071 : H12AffineFastState.Bounded env26071 := by
  intro p hp
  have h : env26071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26070_26071 : H12AffineEnvironment.transform 12 24 env26070 = env26071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env26070 == env26071) = true)

theorem identity26071 : scanCanonicalize (H12AffineFastState.compose env26071 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound26071 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26072 : List Nat := [2,4,8,16,32,16,128,182,0,30,2048,4096,24,184,49,129,4123,2049,31,49,49,168,131,138,144,130,2194,4233,4242,2195,36,58,183,179,163,1]

theorem envBound26072 : H12AffineFastState.Bounded env26072 := by
  intro p hp
  have h : env26072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26071_26072 : H12AffineEnvironment.transform 8 0 env26071 = env26072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env26071 == env26072) = true)

theorem identity26072 : scanCanonicalize (H12AffineFastState.compose env26072 (packedSelected [0,1] rootPS)) = affineNative (2^(11+1) ^^^ 49) := by decide +kernel

theorem selectedBound26072 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env26073 : List Nat := [2,4,8,16,32,16,128,182,0,30,2048,49,24,184,49,129,42,2049,31,49,49,168,131,138,144,130,2194,184,163,2195,36,58,183,179,163,1]

theorem envBound26073 : H12AffineFastState.Bounded env26073 := by
  intro p hp
  have h : env26073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26072_26073 : H12AffineEnvironment.transform 11 49 env26072 = env26073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env26072 == env26073) = true)

theorem identity26073 : scanCanonicalize (H12AffineFastState.compose env26073 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound26073 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env26074 : List Nat := [2,4,8,10,32,10,128,172,0,4,2048,43,2,162,43,129,42,2049,5,43,43,168,131,138,138,130,2184,162,163,2185,36,32,173,169,163,1]

theorem envBound26074 : H12AffineFastState.Bounded env26074 := by
  intro p hp
  have h : env26074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26073_26074 : H12AffineEnvironment.transform 3 10 env26073 = env26074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env26073 == env26074) = true)

theorem identity26074 : scanCanonicalize (H12AffineFastState.compose env26074 (packedSelected [0,5] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound26074 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env26075 : List Nat := [2,4,8,10,32,10,9,37,0,4,2048,43,2,43,43,8,42,2049,5,43,43,33,10,3,3,11,2049,43,42,2048,36,32,36,32,42,1]

theorem envBound26075 : H12AffineFastState.Bounded env26075 := by
  intro p hp
  have h : env26075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26074_26075 : H12AffineEnvironment.transform 6 9 env26074 = env26075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env26074 == env26075) = true)

theorem identity26075 : scanCanonicalize (H12AffineFastState.compose env26075 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 6) := by decide +kernel

theorem selectedBound26075 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26076 : List Nat := [2,4,8,10,32,10,9,37,0,4,6,43,2,43,43,8,42,7,5,43,43,33,10,3,3,11,7,43,42,6,36,32,36,32,42,1]

theorem envBound26076 : H12AffineFastState.Bounded env26076 := by
  intro p hp
  have h : env26076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26075_26076 : H12AffineEnvironment.transform 10 6 env26075 = env26076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 6 env26075 == env26076) = true)

def env26077 : List Nat := [2,4,8,16,32,16,128,182,512,30,2048,4096,25,184,48,129,4123,2049,31,48,48,169,130,138,145,131,2194,4233,4242,2195,37,59,183,179,163,513]

theorem envBound26077 : H12AffineFastState.Bounded env26077 := by
  intro p hp
  have h : env26077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26070_26077 : H12AffineEnvironment.transform 12 25 env26070 = env26077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env26070 == env26077) = true)

theorem identity26077 : scanCanonicalize (H12AffineFastState.compose env26077 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound26077 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26078 : List Nat := [2,4,8,16,32,16,128,182,27,30,2048,4096,25,184,48,129,4123,2049,31,48,48,169,130,138,145,131,2194,4233,4242,2195,37,59,183,179,163,26]

theorem envBound26078 : H12AffineFastState.Bounded env26078 := by
  intro p hp
  have h : env26078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26077_26078 : H12AffineEnvironment.transform 8 27 env26077 = env26078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env26077 == env26078) = true)

theorem identity26078 : scanCanonicalize (H12AffineFastState.compose env26078 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound26078 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env26079 : List Nat := [2,4,8,16,32,16,128,182,27,30,2048,184,25,184,48,129,163,2049,31,48,48,169,130,138,145,131,2194,49,42,2195,37,59,183,179,163,26]

theorem envBound26079 : H12AffineFastState.Bounded env26079 := by
  intro p hp
  have h : env26079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26078_26079 : H12AffineEnvironment.transform 11 184 env26078 = env26079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env26078 == env26079) = true)

theorem identity26079 : scanCanonicalize (H12AffineFastState.compose env26079 (packedSelected [0,1,5,8] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound26079 : packedSelected [0,1,5,8] rootPS < 2^1333 := by decide +kernel

def env26080 : List Nat := [2,4,8,10,32,10,128,172,1,4,2048,162,3,162,42,129,163,2049,5,42,42,169,130,138,139,131,2184,43,42,2185,37,33,173,169,163,0]

theorem envBound26080 : H12AffineFastState.Bounded env26080 := by
  intro p hp
  have h : env26080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26079_26080 : H12AffineEnvironment.transform 3 10 env26079 = env26080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env26079 == env26080) = true)

theorem identity26080 : scanCanonicalize (H12AffineFastState.compose env26080 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound26080 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env26081 : List Nat := [2,4,8,10,32,10,128,172,1,4,43,162,3,162,42,129,163,42,5,42,42,169,130,138,139,131,163,43,42,162,37,33,173,169,163,0]

theorem envBound26081 : H12AffineFastState.Bounded env26081 := by
  intro p hp
  have h : env26081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26080_26081 : H12AffineEnvironment.transform 10 43 env26080 = env26081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env26080 == env26081) = true)

def env26082 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,185,32768,1182,4524,262144,1025,32768,34217,34096,33965,139,8328,33964,262436,45217,45325,2341,32789,33813,257,261,277,513]

theorem envBound26082 : H12AffineFastState.Bounded env26082 := by
  intro p hp
  have h : env26082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26048_26082 : H12AffineEnvironment.transform 13 185 env26048 = env26082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 185 env26048 == env26082) = true)

theorem identity26082 : scanCanonicalize (H12AffineFastState.compose env26082 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound26082 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env26083 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,185,8460,1182,4524,262144,1025,8460,9381,9276,9633,139,8328,9632,262436,4525,4097,2341,8473,9497,257,261,277,513]

theorem envBound26083 : H12AffineFastState.Bounded env26083 := by
  intro p hp
  have h : env26083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26082_26083 : H12AffineEnvironment.transform 14 8460 env26082 = env26083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env26082 == env26083) = true)

theorem identity26083 : scanCanonicalize (H12AffineFastState.compose env26083 (packedSelected [2,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 27) := by decide +kernel

theorem selectedBound26083 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env26084 : List Nat := [2,4,8,16,32,16,128,256,512,1024,27,4096,8192,185,8460,1182,4524,262144,1025,8460,9381,9276,9633,139,8328,9632,262436,4525,4097,318,8473,9497,257,261,277,513]

theorem envBound26084 : H12AffineFastState.Bounded env26084 := by
  intro p hp
  have h : env26084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26083_26084 : H12AffineEnvironment.transform 10 27 env26083 = env26084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 27 env26083 == env26084) = true)

theorem identity26084 : scanCanonicalize (H12AffineFastState.compose env26084 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound26084 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env26085 : List Nat := [2,4,8,16,32,16,128,256,512,1024,27,1296,8192,185,8460,1182,1212,262144,1025,8460,9381,9276,9633,139,8328,9632,262436,1213,1297,318,8473,9497,257,261,277,513]

theorem envBound26085 : H12AffineFastState.Bounded env26085 := by
  intro p hp
  have h : env26085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26084_26085 : H12AffineEnvironment.transform 11 1296 env26084 = env26085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env26084 == env26085) = true)

theorem identity26085 : scanCanonicalize (H12AffineFastState.compose env26085 (packedSelected [1,2,3,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 1339) := by decide +kernel

theorem selectedBound26085 : packedSelected [1,2,3,12,15] rootPS < 2^1333 := by decide +kernel

def env26086 : List Nat := [2,4,8,16,32,16,128,256,512,1024,27,1296,8192,185,8460,1182,1212,1339,1025,8460,9381,9276,9633,139,8328,9632,1055,1213,1297,318,8473,9497,257,261,277,513]

theorem envBound26086 : H12AffineFastState.Bounded env26086 := by
  intro p hp
  have h : env26086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26085_26086 : H12AffineEnvironment.transform 17 1339 env26085 = env26086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1339 env26085 == env26086) = true)

def env26087 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,20757,262144,1025,32768,98614,98734,98355,16434,8328,98355,278941,61464,45325,2341,115762,114738,257,261,276,513]

theorem envBound26087 : H12AffineFastState.Bounded env26087 := by
  intro p hp
  have h : env26087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26046_26087 : H12AffineEnvironment.transform 5 17 env26046 = env26087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env26046 == env26087) = true)

theorem identity26087 : scanCanonicalize (H12AffineFastState.compose env26087 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 17413) := by decide +kernel

theorem selectedBound26087 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env26088 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,17413,65536,20757,262144,1025,17413,83251,83371,82998,16434,8328,82998,278941,13341,29960,2341,65591,66615,257,261,276,513]

theorem envBound26088 : H12AffineFastState.Bounded env26088 := by
  intro p hp
  have h : env26088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26087_26088 : H12AffineEnvironment.transform 14 17413 env26087 = env26088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 17413 env26087 == env26088) = true)

def env26089 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,184,1213,65536,4525,262144,1025,1213,66955,66835,66702,138,8328,66702,262437,13341,13744,2341,65591,66615,257,261,276,513]

theorem envBound26089 : H12AffineFastState.Bounded env26089 := by
  intro p hp
  have h : env26089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26088_26089 : H12AffineEnvironment.transform 13 184 env26088 = env26089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 184 env26088 == env26089) = true)

theorem identity26089 : scanCanonicalize (H12AffineFastState.compose env26089 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(17+1) ^^^ 11413) := by decide +kernel

theorem selectedBound26089 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env26090 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,184,1213,65536,4525,11413,1025,1213,66955,66835,66702,138,8328,66702,11696,13341,13744,2341,65591,66615,257,261,276,513]

theorem envBound26090 : H12AffineFastState.Bounded env26090 := by
  intro p hp
  have h : env26090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26089_26090 : H12AffineEnvironment.transform 17 11413 env26089 = env26090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 11413 env26089 == env26090) = true)

def env26091 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,1456,184,1213,65536,4525,2341,1025,1213,66955,66835,66702,138,1336,66702,2048,4525,4096,2341,65591,66615,257,261,276,513]

theorem envBound26091 : H12AffineFastState.Bounded env26091 := by
  intro p hp
  have h : env26091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26090_26091 : H12AffineEnvironment.transform 12 1456 env26090 = env26091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1456 env26090 == env26091) = true)

theorem identity26091 : scanCanonicalize (H12AffineFastState.compose env26091 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound26091 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env26092 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,277,1456,184,1213,65536,184,2341,1025,1213,66955,66835,66702,138,1336,66702,2048,184,277,2341,65591,66615,257,261,276,513]

theorem envBound26092 : H12AffineFastState.Bounded env26092 := by
  intro p hp
  have h : env26092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26091_26092 : H12AffineEnvironment.transform 11 277 env26091 = env26092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env26091 == env26092) = true)

theorem identity26092 : scanCanonicalize (H12AffineFastState.compose env26092 (packedSelected [2,5,8] rootPS)) = affineNative (2^(15+1) ^^^ 2225) := by decide +kernel

theorem selectedBound26092 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env26093 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,277,1456,184,1213,2225,184,2341,1025,1213,3386,3490,3135,138,1336,3135,2048,184,277,2341,2182,3206,257,261,276,513]

theorem envBound26093 : H12AffineFastState.Bounded env26093 := by
  intro p hp
  have h : env26093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26092_26093 : H12AffineEnvironment.transform 15 2225 env26092 = env26093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2225 env26092 == env26093) = true)

theorem identity26093 : scanCanonicalize (H12AffineFastState.compose env26093 (packedSelected [4,9] rootPS)) = affineNative (2^(9+1) ^^^ 425) := by decide +kernel

theorem selectedBound26093 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env26094 : List Nat := [2,4,8,16,32,17,128,256,512,425,2048,277,25,184,276,2225,184,2341,424,276,2195,2059,2454,138,145,2454,2048,184,277,2341,2182,2351,257,261,276,513]

theorem envBound26094 : H12AffineFastState.Bounded env26094 := by
  intro p hp
  have h : env26094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26093_26094 : H12AffineEnvironment.transform 9 425 env26093 = env26094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 425 env26093 == env26094) = true)

def env26095 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,1457,184,1213,65536,4525,2340,1025,1213,66955,66835,66702,138,1337,66702,2049,4524,4097,2341,65591,66615,257,261,276,513]

theorem envBound26095 : H12AffineFastState.Bounded env26095 := by
  intro p hp
  have h : env26095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26090_26095 : H12AffineEnvironment.transform 12 1457 env26090 = env26095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1457 env26090 == env26095) = true)

theorem identity26095 : scanCanonicalize (H12AffineFastState.compose env26095 (packedSelected [0,7] rootPS)) = affineNative (2^(15+1) ^^^ 5294) := by decide +kernel

theorem selectedBound26095 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env26096 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,1457,184,1213,5294,4525,2340,1025,1213,4389,4541,4128,138,1337,4128,2049,4524,4097,2341,5273,4249,257,261,276,513]

theorem envBound26096 : H12AffineFastState.Bounded env26096 := by
  intro p hp
  have h : env26096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26095_26096 : H12AffineEnvironment.transform 15 5294 env26095 = env26096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5294 env26095 == env26096) = true)

theorem identity26096 : scanCanonicalize (H12AffineFastState.compose env26096 (packedSelected [2,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 3223) := by decide +kernel

theorem selectedBound26096 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env26097 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,3223,1457,184,1213,2105,3386,2340,1025,1213,3506,3370,3255,138,1337,3255,2049,3387,3222,2341,2062,3086,257,261,276,513]

theorem envBound26097 : H12AffineFastState.Bounded env26097 := by
  intro p hp
  have h : env26097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26096_26097 : H12AffineEnvironment.transform 11 3223 env26096 = env26097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3223 env26096 == env26097) = true)

theorem identity26097 : scanCanonicalize (H12AffineFastState.compose env26097 (packedSelected [4,9] rootPS)) = affineNative (2^(9+1) ^^^ 140) := by decide +kernel

theorem selectedBound26097 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env26098 : List Nat := [2,4,8,16,32,17,128,256,512,140,2048,2075,317,184,49,2105,2486,2340,141,49,2366,2470,2107,138,437,2107,2049,2487,2074,2341,2062,2178,257,261,276,513]

theorem envBound26098 : H12AffineFastState.Bounded env26098 := by
  intro p hp
  have h : env26098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26097_26098 : H12AffineEnvironment.transform 9 140 env26097 = env26098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 140 env26097 == env26098) = true)

def env26099 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,185,1212,65536,4524,262144,1025,1212,66954,66834,66703,139,8328,66703,262436,13341,13745,2341,65591,66615,257,261,276,513]

theorem envBound26099 : H12AffineFastState.Bounded env26099 := by
  intro p hp
  have h : env26099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26088_26099 : H12AffineEnvironment.transform 13 185 env26088 = env26099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 185 env26088 == env26099) = true)

theorem identity26099 : scanCanonicalize (H12AffineFastState.compose env26099 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 1456) := by decide +kernel

theorem selectedBound26099 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env26100 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,1456,185,1212,65536,4524,262144,1025,1212,66954,66834,66703,139,1336,66703,262436,4525,4097,2341,65591,66615,257,261,276,513]

theorem envBound26100 : H12AffineFastState.Bounded env26100 := by
  intro p hp
  have h : env26100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26099_26100 : H12AffineEnvironment.transform 12 1456 env26099 = env26100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1456 env26099 == env26100) = true)

theorem identity26100 : scanCanonicalize (H12AffineFastState.compose env26100 (packedSelected [2,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound26100 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env26101 : List Nat := [2,4,8,16,32,17,128,256,512,1024,26,4096,1456,185,1212,65536,4524,262144,1025,1212,66954,66834,66703,139,1336,66703,262436,4525,4097,319,65591,66615,257,261,276,513]

theorem envBound26101 : H12AffineFastState.Bounded env26101 := by
  intro p hp
  have h : env26101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26100_26101 : H12AffineEnvironment.transform 10 26 env26100 = env26101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env26100 == env26101) = true)

theorem identity26101 : scanCanonicalize (H12AffineFastState.compose env26101 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 4130) := by decide +kernel

theorem selectedBound26101 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env26102 : List Nat := [2,4,8,16,32,17,128,256,512,1024,26,4096,1456,185,1212,4130,4524,262144,1025,1212,5544,5424,5293,139,1336,5293,262436,4525,4097,319,4117,5141,257,261,276,513]

theorem envBound26102 : H12AffineFastState.Bounded env26102 := by
  intro p hp
  have h : env26102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26101_26102 : H12AffineEnvironment.transform 15 4130 env26101 = env26102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4130 env26101 == env26102) = true)

theorem identity26102 : scanCanonicalize (H12AffineFastState.compose env26102 (packedSelected [1,2,3,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 1338) := by decide +kernel

theorem selectedBound26102 : packedSelected [1,2,3,12,15] rootPS < 2^1333 := by decide +kernel

def env26103 : List Nat := [2,4,8,16,32,17,128,256,512,1024,26,4096,1456,185,1212,4130,4524,1338,1025,1212,5544,5424,5293,139,1336,5293,1054,4525,4097,319,4117,5141,257,261,276,513]

theorem envBound26103 : H12AffineFastState.Bounded env26103 := by
  intro p hp
  have h : env26103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26102_26103 : H12AffineEnvironment.transform 17 1338 env26102 = env26103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1338 env26102 == env26103) = true)

def env26104 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,8328,8914001,134217728,151954594,151827618,4294795,17399808,151490696,525568,138907683,166560784,513]

theorem envBound26104 : H12AffineFastState.Bounded env26104 := by
  intro p hp
  have h : env26104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25893_26104 : H12AffineEnvironment.transform 25 8914001 env25893 = env26104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 8914001 env25893 == env26104) = true)

def env26105 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,2248768,16777216,8328,2774033,134217728,151954594,151827618,4294795,17399808,151490696,525568,138907683,156226640,513]

theorem envBound26105 : H12AffineFastState.Bounded env26105 := by
  intro p hp
  have h : env26105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26104_26105 : H12AffineEnvironment.transform 22 2248768 env26104 = env26105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2248768 env26104 == env26105) = true)

def env26106 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,2248768,16777216,8328,2248721,134217728,151429282,151302306,4294795,16876544,151490696,256,138907683,155701328,513]

theorem envBound26106 : H12AffineFastState.Bounded env26106 := by
  intro p hp
  have h : env26106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26105_26106 : H12AffineEnvironment.transform 18 1024 env26105 = env26106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env26105 == env26106) = true)

def env26107 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,2248768,16777216,8328,2248721,21331968,4399266,4272290,4294795,16876544,4329608,256,16912419,151632,513]

theorem envBound26107 : H12AffineFastState.Bounded env26107 := by
  intro p hp
  have h : env26107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26106_26107 : H12AffineEnvironment.transform 26 21331968 env26106 = env26107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 21331968 env26106 == env26107) = true)

theorem identity26107 : scanCanonicalize (H12AffineFastState.compose env26107 (packedSelected [14] rootPS)) = affineNative (2^(15+1) ^^^ 37223) := by decide +kernel

theorem selectedBound26107 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env26108 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,37223,131072,262144,1024,32768,2097152,4194304,2248768,16777216,8328,2248721,21238119,4370885,4235717,4200940,16782695,4329608,256,16912419,151632,513]

theorem envBound26108 : H12AffineFastState.Bounded env26108 := by
  intro p hp
  have h : env26108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26107_26108 : H12AffineEnvironment.transform 15 37223 env26107 = env26108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 37223 env26107 == env26108) = true)

theorem identity26108 : scanCanonicalize (H12AffineFastState.compose env26108 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(23+1) ^^^ 6353123) := by decide +kernel

theorem selectedBound26108 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env26109 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,37223,131072,262144,1024,32768,2097152,4194304,2248768,6353123,8328,2248721,2417028,4370885,4235717,4200940,6350212,4329608,256,6480064,151632,513]

theorem envBound26109 : H12AffineFastState.Bounded env26109 := by
  intro p hp
  have h : env26109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26108_26109 : H12AffineEnvironment.transform 23 6353123 env26108 = env26109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 6353123 env26108 == env26109) = true)

theorem identity26109 : scanCanonicalize (H12AffineFastState.compose env26109 (packedSelected [13,21] rootPS)) = affineNative (2^(16+1) ^^^ 45404) := by decide +kernel

theorem selectedBound26109 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env26110 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,37223,45404,262144,1024,32768,2097152,4194304,2154780,6353123,8328,2154829,2417028,4194457,4235717,4200940,6350212,4235732,256,6312348,57612,513]

theorem envBound26110 : H12AffineFastState.Bounded env26110 := by
  intro p hp
  have h : env26110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26109_26110 : H12AffineEnvironment.transform 16 45404 env26109 = env26110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45404 env26109 == env26110) = true)

def env26111 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,2248768,16777216,8328,2248721,21331969,4399267,4272291,4294795,16876544,4329609,256,16912418,151633,513]

theorem envBound26111 : H12AffineFastState.Bounded env26111 := by
  intro p hp
  have h : env26111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26106_26111 : H12AffineEnvironment.transform 26 21331969 env26106 = env26111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 21331969 env26106 == env26111) = true)

theorem identity26111 : scanCanonicalize (H12AffineFastState.compose env26111 (packedSelected [14] rootPS)) = affineNative (2^(20+1) ^^^ 98662) := by decide +kernel

theorem selectedBound26111 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env26112 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,98662,4194304,250150,16777216,8328,250231,21331969,4399267,4272291,4294795,16876544,4329609,256,16912418,151633,513]

theorem envBound26112 : H12AffineFastState.Bounded env26112 := by
  intro p hp
  have h : env26112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26111_26112 : H12AffineEnvironment.transform 20 98662 env26111 = env26112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 98662 env26111 == env26112) = true)

theorem identity26112 : scanCanonicalize (H12AffineFastState.compose env26112 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(16+1) ^^^ 20756) := by decide +kernel

theorem selectedBound26112 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env26113 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,20756,262144,1024,32768,98662,4194304,98354,16777216,8328,98403,21331969,4288951,4272291,4294795,16876544,4211101,256,16793910,325,513]

theorem envBound26113 : H12AffineFastState.Bounded env26113 := by
  intro p hp
  have h : env26113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26112_26113 : H12AffineEnvironment.transform 16 20756 env26112 = env26113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 20756 env26112 == env26113) = true)

theorem identity26113 : scanCanonicalize (H12AffineFastState.compose env26113 (packedSelected [13,21] rootPS)) = affineNative (2^(23+1) ^^^ 4309405) := by decide +kernel

theorem selectedBound26113 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env26114 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,20756,262144,1024,32768,98662,4194304,98354,4309405,8328,98403,278940,4288951,4272291,4294795,4212125,4211101,256,4292779,325,513]

theorem envBound26114 : H12AffineFastState.Bounded env26114 := by
  intro p hp
  have h : env26114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26113_26114 : H12AffineEnvironment.transform 23 4309405 env26113 = env26114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 4309405 env26113 == env26114) = true)

theorem identity26114 : scanCanonicalize (H12AffineFastState.compose env26114 (packedSelected [0,3,5,10,27] rootPS)) = affineNative (2^(21+1) ^^^ 98735) := by decide +kernel

theorem selectedBound26114 : packedSelected [0,3,5,10,27] rootPS < 2^1333 := by decide +kernel

def env26115 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,20756,262144,1024,32768,98662,98735,98354,16434,8328,98403,278940,61464,45324,2340,115762,114738,256,260,325,513]

theorem envBound26115 : H12AffineFastState.Bounded env26115 := by
  intro p hp
  have h : env26115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26114_26115 : H12AffineEnvironment.transform 21 98735 env26114 = env26115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 98735 env26114 == env26115) = true)

def env26116 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,20756,262144,1024,32768,98614,98735,98354,16434,8328,98355,278940,61464,45324,2340,115762,114738,256,260,277,513]

theorem envBound26116 : H12AffineFastState.Bounded env26116 := by
  intro p hp
  have h : env26116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26115_26116 : H12AffineEnvironment.transform 5 16 env26115 = env26116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env26115 == env26116) = true)

theorem identity26116 : scanCanonicalize (H12AffineFastState.compose env26116 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 17412) := by decide +kernel

theorem selectedBound26116 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env26117 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,17412,65536,20756,262144,1024,17412,83250,83371,82998,16434,8328,82999,278940,13340,29960,2340,65590,66614,256,260,277,513]

theorem envBound26117 : H12AffineFastState.Bounded env26117 := by
  intro p hp
  have h : env26117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26116_26117 : H12AffineEnvironment.transform 14 17412 env26116 = env26117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 17412 env26116 == env26117) = true)

def env26118 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,184,1212,65536,4524,262144,1024,1212,66954,66835,66702,138,8328,66703,262436,13340,13744,2340,65590,66614,256,260,277,513]

theorem envBound26118 : H12AffineFastState.Bounded env26118 := by
  intro p hp
  have h : env26118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26117_26118 : H12AffineEnvironment.transform 13 184 env26117 = env26118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 184 env26117 == env26118) = true)

theorem identity26118 : scanCanonicalize (H12AffineFastState.compose env26118 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(17+1) ^^^ 11412) := by decide +kernel

theorem selectedBound26118 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env26119 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,184,1212,65536,4524,11412,1024,1212,66954,66835,66702,138,8328,66703,11696,13340,13744,2340,65590,66614,256,260,277,513]

theorem envBound26119 : H12AffineFastState.Bounded env26119 := by
  intro p hp
  have h : env26119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26118_26119 : H12AffineEnvironment.transform 17 11412 env26118 = env26119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 11412 env26118 == env26119) = true)

def env26120 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,1456,184,1212,65536,4524,2340,1024,1212,66954,66835,66702,138,1336,66703,2048,4524,4096,2340,65590,66614,256,260,277,513]

theorem envBound26120 : H12AffineFastState.Bounded env26120 := by
  intro p hp
  have h : env26120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26119_26120 : H12AffineEnvironment.transform 12 1456 env26119 = env26120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1456 env26119 == env26120) = true)

theorem identity26120 : scanCanonicalize (H12AffineFastState.compose env26120 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound26120 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env26121 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,184,1456,184,1212,65536,276,2340,1024,1212,66954,66835,66702,138,1336,66703,2048,276,184,2340,65590,66614,256,260,277,513]

theorem envBound26121 : H12AffineFastState.Bounded env26121 := by
  intro p hp
  have h : env26121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26120_26121 : H12AffineEnvironment.transform 11 184 env26120 = env26121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env26120 == env26121) = true)

theorem identity26121 : scanCanonicalize (H12AffineFastState.compose env26121 (packedSelected [2,5,8] rootPS)) = affineNative (2^(15+1) ^^^ 2332) := by decide +kernel

theorem selectedBound26121 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env26122 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,184,1456,184,1212,2332,276,2340,1024,1212,3222,3087,3474,138,1336,3475,2048,276,184,2340,2346,3370,256,260,277,513]

theorem envBound26122 : H12AffineFastState.Bounded env26122 := by
  intro p hp
  have h : env26122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26121_26122 : H12AffineEnvironment.transform 15 2332 env26121 = env26122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2332 env26121 == env26122) = true)

theorem identity26122 : scanCanonicalize (H12AffineFastState.compose env26122 (packedSelected [4,9] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound26122 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env26123 : List Nat := [2,4,8,16,32,16,128,256,512,4,2048,184,436,184,184,2332,276,2340,4,184,2194,2059,2454,138,316,2455,2048,276,184,2340,2346,2350,256,260,277,513]

theorem envBound26123 : H12AffineFastState.Bounded env26123 := by
  intro p hp
  have h : env26123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26122_26123 : H12AffineEnvironment.transform 9 4 env26122 = env26123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env26122 == env26123) = true)

def env26124 : List Nat := [2,4,8,16,32,16,128,172,512,4,2048,184,24,184,184,2224,184,2184,4,184,2194,2059,2106,138,144,2107,2048,184,184,2184,2182,2178,172,168,185,513]

theorem envBound26124 : H12AffineFastState.Bounded env26124 := by
  intro p hp
  have h : env26124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26123_26124 : H12AffineEnvironment.transform 7 172 env26123 = env26124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env26123 == env26124) = true)

theorem identity26124 : scanCanonicalize (H12AffineFastState.compose env26124 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound26124 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26125 : List Nat := [2,4,8,16,32,16,128,172,136,4,2048,184,24,184,184,2224,184,2184,4,184,2194,2059,2106,138,144,2107,2048,184,184,2184,2182,2178,172,168,185,137]

theorem envBound26125 : H12AffineFastState.Bounded env26125 := by
  intro p hp
  have h : env26125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26124_26125 : H12AffineEnvironment.transform 8 136 env26124 = env26125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env26124 == env26125) = true)

theorem identity26125 : scanCanonicalize (H12AffineFastState.compose env26125 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound26125 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env26126 : List Nat := [2,4,8,16,32,16,18,62,26,4,2048,42,24,42,42,2082,42,2074,4,42,2048,2059,2106,24,2,2107,2048,42,42,2074,2068,2064,62,58,43,27]

theorem envBound26126 : H12AffineFastState.Bounded env26126 := by
  intro p hp
  have h : env26126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26125_26126 : H12AffineEnvironment.transform 6 18 env26125 = env26126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env26125 == env26126) = true)

theorem identity26126 : scanCanonicalize (H12AffineFastState.compose env26126 (packedSelected [0,5] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound26126 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env26127 : List Nat := [2,4,8,10,32,10,8,36,0,4,2048,42,2,42,42,2082,42,2048,4,42,2048,2059,2080,2,2,2081,2048,42,42,2048,2062,2058,36,32,43,1]

theorem envBound26127 : H12AffineFastState.Bounded env26127 := by
  intro p hp
  have h : env26127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26126_26127 : H12AffineEnvironment.transform 3 10 env26126 = env26127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env26126 == env26127) = true)

def env26128 : List Nat := [2,4,8,10,32,10,8,36,0,4,0,42,2,42,42,34,42,0,4,42,0,11,32,2,2,33,0,42,42,0,14,10,36,32,43,1]

theorem envBound26128 : H12AffineFastState.Bounded env26128 := by
  intro p hp
  have h : env26128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26127_26128 : H12AffineEnvironment.transform 10 0 env26127 = env26128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env26127 == env26128) = true)

theorem identity26128 : scanCanonicalize (H12AffineFastState.compose env26128 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound26128 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26129 : List Nat := [2,4,8,10,6,10,8,2,0,4,0,12,2,12,12,4,12,0,4,12,0,11,6,2,2,7,0,12,12,0,14,10,2,6,13,1]

theorem envBound26129 : H12AffineFastState.Bounded env26129 := by
  intro p hp
  have h : env26129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26128_26129 : H12AffineEnvironment.transform 4 6 env26128 = env26129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env26128 == env26129) = true)

def leafEnv26129 : List Nat := [2,4,8,10,6,10,8,2,0,4,0,12,2,12,12,4,12,0,4,12,0,11,6,2,14,2,1,7,0,12,12,0,14,10,2,6,4,4,13,1,0,0,1]

def active26129 : List Nat := [0,1,2]

def tree26129 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood26129 : H12WitnessSearch.Good tree26129 := H12GlobalWitnessIndex.good

theorem leafIdentity26129 : H12AffineFastState.composeSystem env26129 rootObs = leafEnv26129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env26129 rootObs == leafEnv26129) = true)

theorem terminalChecked26129 : H12PackedTerminal.terminalCheckFast leafEnv26129 active26129 tree26129 = true := by decide +kernel

def env26130 : List Nat := [2,4,8,10,32,10,8,36,0,4,1,42,2,42,42,35,42,1,4,42,1,10,33,2,2,32,1,42,42,1,15,11,36,32,43,1]

theorem envBound26130 : H12AffineFastState.Bounded env26130 := by
  intro p hp
  have h : env26130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26127_26130 : H12AffineEnvironment.transform 10 1 env26127 = env26130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env26127 == env26130) = true)

theorem identity26130 : scanCanonicalize (H12AffineFastState.compose env26130 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound26130 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26131 : List Nat := [2,4,5,7,32,7,5,36,0,4,1,39,2,39,39,35,39,1,4,39,1,7,33,2,2,32,1,39,39,1,2,6,36,32,38,1]

theorem envBound26131 : H12AffineFastState.Bounded env26131 := by
  intro p hp
  have h : env26131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26130_26131 : H12AffineEnvironment.transform 2 5 env26130 = env26131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env26130 == env26131) = true)

def leafEnv26131 : List Nat := [2,4,5,7,32,7,5,36,0,4,1,39,2,39,39,35,39,1,4,39,1,7,33,2,2,2,1,32,1,39,39,1,2,6,36,32,4,35,38,1,0,1,1]

def active26131 : List Nat := [0,1,4]

def tree26131 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood26131 : H12WitnessSearch.Good tree26131 := H12GlobalWitnessIndex.good

theorem leafIdentity26131 : H12AffineFastState.composeSystem env26131 rootObs = leafEnv26131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env26131 rootObs == leafEnv26131) = true)

theorem terminalChecked26131 : H12PackedTerminal.terminalCheckFast leafEnv26131 active26131 tree26131 = true := by decide +kernel

def env26132 : List Nat := [2,4,8,16,32,16,128,173,512,4,2048,184,25,184,184,2225,185,2185,4,184,2194,2059,2107,138,145,2106,2048,185,184,2185,2183,2179,173,169,184,513]

theorem envBound26132 : H12AffineFastState.Bounded env26132 := by
  intro p hp
  have h : env26132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26123_26132 : H12AffineEnvironment.transform 7 173 env26123 = env26132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env26123 == env26132) = true)

theorem identity26132 : scanCanonicalize (H12AffineFastState.compose env26132 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 674) := by decide +kernel

theorem selectedBound26132 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26133 : List Nat := [2,4,8,16,32,16,128,173,512,4,674,184,25,184,184,531,185,555,4,184,560,681,665,138,145,664,674,185,184,555,549,545,173,169,184,513]

theorem envBound26133 : H12AffineFastState.Bounded env26133 := by
  intro p hp
  have h : env26133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26132_26133 : H12AffineEnvironment.transform 10 674 env26132 = env26133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 674 env26132 == env26133) = true)

theorem identity26133 : scanCanonicalize (H12AffineFastState.compose env26133 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound26133 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env26134 : List Nat := [2,4,8,11,32,11,128,173,512,4,674,163,2,163,163,520,162,555,4,163,555,681,642,138,138,643,674,162,163,555,549,545,173,169,163,513]

theorem envBound26134 : H12AffineFastState.Bounded env26134 := by
  intro p hp
  have h : env26134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26133_26134 : H12AffineEnvironment.transform 3 11 env26133 = env26134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env26133 == env26134) = true)

def env26135 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,1457,184,1212,65536,4524,2341,1024,1212,66954,66835,66702,138,1337,66703,2049,4525,4097,2340,65590,66614,256,260,277,513]

theorem envBound26135 : H12AffineFastState.Bounded env26135 := by
  intro p hp
  have h : env26135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26119_26135 : H12AffineEnvironment.transform 12 1457 env26119 = env26135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1457 env26119 == env26135) = true)

theorem identity26135 : scanCanonicalize (H12AffineFastState.compose env26135 (packedSelected [0,7] rootPS)) = affineNative (2^(15+1) ^^^ 5379) := by decide +kernel

theorem selectedBound26135 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env26136 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,1457,184,1212,5379,4524,2341,1024,1212,4233,4112,4493,138,1337,4492,2049,4525,4097,2340,5429,4405,256,260,277,513]

theorem envBound26136 : H12AffineFastState.Bounded env26136 := by
  intro p hp
  have h : env26136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26135_26136 : H12AffineEnvironment.transform 15 5379 env26135 = env26136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5379 env26135 == env26136) = true)

theorem identity26136 : scanCanonicalize (H12AffineFastState.compose env26136 (packedSelected [2,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 3223) := by decide +kernel

theorem selectedBound26136 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env26137 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,3223,1457,184,1212,2452,3387,2341,1024,1212,3102,3207,3354,138,1337,3355,2049,3386,3222,2340,2466,3490,256,260,277,513]

theorem envBound26137 : H12AffineFastState.Bounded env26137 := by
  intro p hp
  have h : env26137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26136_26137 : H12AffineEnvironment.transform 11 3223 env26136 = env26137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3223 env26136 == env26137) = true)

theorem identity26137 : scanCanonicalize (H12AffineFastState.compose env26137 (packedSelected [4,9] rootPS)) = affineNative (2^(9+1) ^^^ 288) := by decide +kernel

theorem selectedBound26137 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env26138 : List Nat := [2,4,8,16,32,16,128,256,512,288,2048,2487,145,184,412,2452,2075,2341,288,412,2366,2471,2106,138,25,2107,2049,2074,2486,2340,2466,2178,256,260,277,513]

theorem envBound26138 : H12AffineFastState.Bounded env26138 := by
  intro p hp
  have h : env26138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26137_26138 : H12AffineEnvironment.transform 9 288 env26137 = env26138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 288 env26137 == env26138) = true)

def env26139 : List Nat := [2,4,8,16,32,16,128,172,512,140,2048,2075,145,184,48,2104,2075,2185,140,48,2194,2059,2106,138,25,2107,2049,2074,2074,2184,2062,2178,172,168,185,513]

theorem envBound26139 : H12AffineFastState.Bounded env26139 := by
  intro p hp
  have h : env26139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26138_26139 : H12AffineEnvironment.transform 7 172 env26138 = env26139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env26138 == env26139) = true)

theorem identity26139 : scanCanonicalize (H12AffineFastState.compose env26139 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound26139 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26140 : List Nat := [2,4,8,16,32,16,128,172,137,140,2048,2075,145,184,48,2104,2075,2185,140,48,2194,2059,2106,138,25,2107,2049,2074,2074,2184,2062,2178,172,168,185,136]

theorem envBound26140 : H12AffineFastState.Bounded env26140 := by
  intro p hp
  have h : env26140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26139_26140 : H12AffineEnvironment.transform 8 137 env26139 = env26140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env26139 == env26140) = true)

theorem identity26140 : scanCanonicalize (H12AffineFastState.compose env26140 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound26140 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env26141 : List Nat := [2,4,8,10,32,10,128,172,137,140,2048,2049,139,162,42,2082,2049,2185,140,42,2184,2059,2080,138,3,2081,2049,2048,2048,2184,2062,2178,172,168,163,136]

theorem envBound26141 : H12AffineFastState.Bounded env26141 := by
  intro p hp
  have h : env26141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26140_26141 : H12AffineEnvironment.transform 3 10 env26140 = env26141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env26140 == env26141) = true)

theorem identity26141 : scanCanonicalize (H12AffineFastState.compose env26141 (packedSelected [0,5] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound26141 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env26142 : List Nat := [2,4,8,10,32,10,8,36,1,4,2048,2049,3,42,42,2082,2049,2049,4,42,2048,2059,2080,2,3,2081,2049,2048,2048,2048,2062,2058,36,32,43,0]

theorem envBound26142 : H12AffineFastState.Bounded env26142 := by
  intro p hp
  have h : env26142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26141_26142 : H12AffineEnvironment.transform 6 8 env26141 = env26142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env26141 == env26142) = true)

def env26143 : List Nat := [2,4,8,10,32,10,8,36,1,4,0,1,3,42,42,34,1,1,4,42,0,11,32,2,3,33,1,0,0,0,14,10,36,32,43,0]

theorem envBound26143 : H12AffineFastState.Bounded env26143 := by
  intro p hp
  have h : env26143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26142_26143 : H12AffineEnvironment.transform 10 0 env26142 = env26143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env26142 == env26143) = true)

theorem identity26143 : scanCanonicalize (H12AffineFastState.compose env26143 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound26143 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26144 : List Nat := [2,4,8,10,12,10,8,8,1,4,0,1,3,6,6,14,1,1,4,6,0,11,12,2,3,13,1,0,0,0,14,10,8,12,7,0]

theorem envBound26144 : H12AffineFastState.Bounded env26144 := by
  intro p hp
  have h : env26144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26143_26144 : H12AffineEnvironment.transform 4 12 env26143 = env26144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env26143 == env26144) = true)

def leafEnv26144 : List Nat := [2,4,8,10,12,10,8,8,1,4,0,1,3,6,6,14,1,1,4,6,0,11,12,2,14,3,1,13,1,0,0,0,14,10,8,12,4,14,7,0,0,0,1]

def active26144 : List Nat := [0,1,2]

def tree26144 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood26144 : H12WitnessSearch.Good tree26144 := H12GlobalWitnessIndex.good

theorem leafIdentity26144 : H12AffineFastState.composeSystem env26144 rootObs = leafEnv26144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env26144 rootObs == leafEnv26144) = true)

theorem terminalChecked26144 : H12PackedTerminal.terminalCheckFast leafEnv26144 active26144 tree26144 = true := by decide +kernel

def env26145 : List Nat := [2,4,8,10,32,10,8,36,1,4,1,0,3,42,42,35,0,0,4,42,1,10,33,2,3,32,0,1,1,1,15,11,36,32,43,0]

theorem envBound26145 : H12AffineFastState.Bounded env26145 := by
  intro p hp
  have h : env26145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26142_26145 : H12AffineEnvironment.transform 10 1 env26142 = env26145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env26142 == env26145) = true)

theorem identity26145 : scanCanonicalize (H12AffineFastState.compose env26145 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound26145 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26146 : List Nat := [2,3,8,10,32,10,8,35,1,3,1,0,3,42,42,35,0,0,3,42,1,10,33,2,3,32,0,1,1,1,8,11,35,32,43,0]

theorem envBound26146 : H12AffineFastState.Bounded env26146 := by
  intro p hp
  have h : env26146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26145_26146 : H12AffineEnvironment.transform 1 3 env26145 = env26146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env26145 == env26146) = true)

def leafEnv26146 : List Nat := [2,3,8,10,32,10,8,35,1,3,1,0,3,42,42,35,0,0,3,42,1,10,33,2,8,3,1,32,0,1,1,1,8,11,35,32,3,35,43,0,0,1,1]

def active26146 : List Nat := [0,2,4]

def tree26146 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood26146 : H12WitnessSearch.Good tree26146 := H12GlobalWitnessIndex.good

theorem leafIdentity26146 : H12AffineFastState.composeSystem env26146 rootObs = leafEnv26146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env26146 rootObs == leafEnv26146) = true)

theorem terminalChecked26146 : H12PackedTerminal.terminalCheckFast leafEnv26146 active26146 tree26146 = true := by decide +kernel

def env26147 : List Nat := [2,4,8,16,32,16,128,173,512,141,2048,2074,145,184,49,2105,2075,2184,141,49,2195,2058,2106,138,25,2107,2049,2074,2075,2185,2063,2178,173,169,184,513]

theorem envBound26147 : H12AffineFastState.Bounded env26147 := by
  intro p hp
  have h : env26147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26138_26147 : H12AffineEnvironment.transform 7 173 env26138 = env26147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env26138 == env26147) = true)

theorem identity26147 : scanCanonicalize (H12AffineFastState.compose env26147 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 675) := by decide +kernel

theorem selectedBound26147 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26148 : List Nat := [2,4,8,16,32,16,128,173,512,141,675,697,145,184,49,666,696,555,141,49,560,681,665,138,25,664,674,697,696,554,684,545,173,169,184,513]

theorem envBound26148 : H12AffineFastState.Bounded env26148 := by
  intro p hp
  have h : env26148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26147_26148 : H12AffineEnvironment.transform 10 675 env26147 = env26148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 675 env26147 == env26148) = true)

theorem identity26148 : scanCanonicalize (H12AffineFastState.compose env26148 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound26148 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env26149 : List Nat := [2,4,8,16,32,16,19,62,512,30,560,554,2,43,49,521,555,555,30,49,560,570,522,25,25,523,561,554,555,554,575,545,62,58,43,513]

theorem envBound26149 : H12AffineFastState.Bounded env26149 := by
  intro p hp
  have h : env26149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26148_26149 : H12AffineEnvironment.transform 6 19 env26148 = env26149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env26148 == env26149) = true)

def env26150 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,185,1213,65536,4525,262144,1024,1213,66955,66834,66703,139,8328,66702,262437,13340,13745,2340,65590,66614,256,260,277,513]

theorem envBound26150 : H12AffineFastState.Bounded env26150 := by
  intro p hp
  have h : env26150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26117_26150 : H12AffineEnvironment.transform 13 185 env26117 = env26150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 185 env26117 == env26150) = true)

theorem identity26150 : scanCanonicalize (H12AffineFastState.compose env26150 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 1456) := by decide +kernel

theorem selectedBound26150 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env26151 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,1456,185,1213,65536,4525,262144,1024,1213,66955,66834,66703,139,1336,66702,262437,4524,4097,2340,65590,66614,256,260,277,513]

theorem envBound26151 : H12AffineFastState.Bounded env26151 := by
  intro p hp
  have h : env26151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26150_26151 : H12AffineEnvironment.transform 12 1456 env26150 = env26151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1456 env26150 == env26151) = true)

theorem identity26151 : scanCanonicalize (H12AffineFastState.compose env26151 (packedSelected [2,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 438) := by decide +kernel

theorem selectedBound26151 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env26152 : List Nat := [2,4,8,16,32,16,128,256,512,1024,438,4096,1456,185,1213,65536,4525,262144,1024,1213,66955,66834,66703,139,1336,66702,262437,4524,4097,146,65590,66614,256,260,277,513]

theorem envBound26152 : H12AffineFastState.Bounded env26152 := by
  intro p hp
  have h : env26152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26151_26152 : H12AffineEnvironment.transform 10 438 env26151 = env26152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 438 env26151 == env26152) = true)

theorem identity26152 : scanCanonicalize (H12AffineFastState.compose env26152 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 4131) := by decide +kernel

theorem selectedBound26152 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env26153 : List Nat := [2,4,8,16,32,16,128,256,512,1024,438,4096,1456,185,1213,4131,4525,262144,1024,1213,5544,5425,5292,139,1336,5293,262437,4524,4097,146,4117,5141,256,260,277,513]

theorem envBound26153 : H12AffineFastState.Bounded env26153 := by
  intro p hp
  have h : env26153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26152_26153 : H12AffineEnvironment.transform 15 4131 env26152 = env26153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4131 env26152 == env26153) = true)

theorem identity26153 : scanCanonicalize (H12AffineFastState.compose env26153 (packedSelected [1,2,3,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound26153 : packedSelected [1,2,3,12,15] rootPS < 2^1333 := by decide +kernel

def env26154 : List Nat := [2,4,8,16,32,16,128,256,512,4,438,4096,436,185,185,4131,4525,262144,4,185,4524,4405,4264,139,316,4265,262437,4524,4097,146,4117,4113,256,260,277,513]

theorem envBound26154 : H12AffineFastState.Bounded env26154 := by
  intro p hp
  have h : env26154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26153_26154 : H12AffineEnvironment.transform 9 4 env26153 = env26154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env26153 == env26154) = true)

theorem identity26154 : scanCanonicalize (H12AffineFastState.compose env26154 (packedSelected [13,17] rootPS)) = affineNative (2^(17+1) ^^^ 319) := by decide +kernel

theorem selectedBound26154 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env26155 : List Nat := [2,4,8,16,32,16,128,256,512,4,438,4096,436,185,185,4131,4525,319,4,185,4524,4405,4264,139,316,4265,26,4524,4097,146,4117,4113,256,260,277,513]

theorem envBound26155 : H12AffineFastState.Bounded env26155 := by
  intro p hp
  have h : env26155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26154_26155 : H12AffineEnvironment.transform 17 319 env26154 = env26155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 319 env26154 == env26155) = true)

theorem identity26155 : scanCanonicalize (H12AffineFastState.compose env26155 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 391) := by decide +kernel

theorem selectedBound26155 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env26156 : List Nat := [2,4,8,16,32,16,128,256,391,4,438,4096,436,185,185,4131,4525,319,4,185,4524,4405,4264,139,316,4265,26,4524,4097,146,4117,4113,256,260,277,390]

theorem envBound26156 : H12AffineFastState.Bounded env26156 := by
  intro p hp
  have h : env26156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26155_26156 : H12AffineEnvironment.transform 8 391 env26155 = env26156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 391 env26155 == env26156) = true)

theorem identity26156 : scanCanonicalize (H12AffineFastState.compose env26156 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(11+1) ^^^ 163) := by decide +kernel

theorem selectedBound26156 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env26157 : List Nat := [2,4,8,16,32,16,128,256,391,4,438,163,436,185,185,128,270,319,4,185,271,406,11,139,316,10,26,271,162,146,182,178,256,260,277,390]

theorem envBound26157 : H12AffineFastState.Bounded env26157 := by
  intro p hp
  have h : env26157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26156_26157 : H12AffineEnvironment.transform 11 163 env26156 = env26157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 163 env26156 == env26157) = true)

theorem identity26157 : scanCanonicalize (H12AffineFastState.compose env26157 (packedSelected [0,2,4] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound26157 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env26158 : List Nat := [2,4,8,16,11,16,128,256,391,4,413,136,415,146,146,128,270,276,4,146,271,406,11,139,279,10,26,271,137,146,157,153,256,260,277,390]

theorem envBound26158 : H12AffineFastState.Bounded env26158 := by
  intro p hp
  have h : env26158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26157_26158 : H12AffineEnvironment.transform 4 11 env26157 = env26158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env26157 == env26158) = true)

theorem identity26158 : scanCanonicalize (H12AffineFastState.compose env26158 (packedSelected [0,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound26158 : packedSelected [0,2,3] rootPS < 2^1333 := by decide +kernel

def env26159 : List Nat := [2,4,8,16,11,16,128,21,146,4,136,136,138,146,146,128,27,1,4,146,26,131,11,139,2,10,26,26,137,146,157,153,21,17,0,147]

theorem envBound26159 : H12AffineFastState.Bounded env26159 := by
  intro p hp
  have h : env26159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26158_26159 : H12AffineEnvironment.transform 7 21 env26158 = env26159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env26158 == env26159) = true)

theorem identity26159 : scanCanonicalize (H12AffineFastState.compose env26159 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound26159 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env26160 : List Nat := [2,4,8,10,11,10,128,15,136,4,136,136,138,136,136,128,1,1,4,136,0,131,11,139,2,10,0,0,137,136,135,131,15,11,0,137]

theorem envBound26160 : H12AffineFastState.Bounded env26160 := by
  intro p hp
  have h : env26160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26159_26160 : H12AffineEnvironment.transform 3 10 env26159 = env26160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env26159 == env26160) = true)

theorem identity26160 : scanCanonicalize (H12AffineFastState.compose env26160 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound26160 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26161 : List Nat := [2,4,8,10,11,10,9,15,1,4,1,1,3,1,1,9,1,1,4,1,0,10,11,2,2,10,0,0,0,1,14,10,15,11,0,0]

theorem envBound26161 : H12AffineFastState.Bounded env26161 := by
  intro p hp
  have h : env26161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26160_26161 : H12AffineEnvironment.transform 6 9 env26160 = env26161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env26160 == env26161) = true)

theorem identity26161 : scanCanonicalize (H12AffineFastState.compose env26161 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound26161 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26162 : List Nat := [2,2,8,10,11,10,9,9,1,2,1,1,3,1,1,9,1,1,2,1,0,10,11,2,2,10,0,0,0,1,8,10,9,11,0,0]

theorem envBound26162 : H12AffineFastState.Bounded env26162 := by
  intro p hp
  have h : env26162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26161_26162 : H12AffineEnvironment.transform 1 2 env26161 = env26162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env26161 == env26162) = true)

def env26163 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,20756,262144,1024,32768,98615,98735,98354,16434,8328,98354,278940,61464,45324,2340,115762,114738,256,260,276,513]

theorem envBound26163 : H12AffineFastState.Bounded env26163 := by
  intro p hp
  have h : env26163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26115_26163 : H12AffineEnvironment.transform 5 17 env26115 = env26163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env26115 == env26163) = true)

theorem identity26163 : scanCanonicalize (H12AffineFastState.compose env26163 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 17446) := by decide +kernel

theorem selectedBound26163 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env26164 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,17446,20756,262144,1024,32768,50449,50569,50196,16434,8328,50196,278940,61464,45324,2340,32788,33812,256,260,276,513]

theorem envBound26164 : H12AffineFastState.Bounded env26164 := by
  intro p hp
  have h : env26164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26163_26164 : H12AffineEnvironment.transform 15 17446 env26163 = env26164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 17446 env26163 == env26164) = true)

def env26165 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,184,32768,1182,4524,262144,1024,32768,34217,34097,33964,138,8328,33964,262436,45216,45324,2340,32788,33812,256,260,276,513]

theorem envBound26165 : H12AffineFastState.Bounded env26165 := by
  intro p hp
  have h : env26165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26164_26165 : H12AffineEnvironment.transform 13 184 env26164 = env26165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 184 env26164 == env26165) = true)

theorem identity26165 : scanCanonicalize (H12AffineFastState.compose env26165 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(17+1) ^^^ 43048) := by decide +kernel

theorem selectedBound26165 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env26166 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,184,32768,1182,4524,43048,1024,32768,34217,34097,33964,138,8328,33964,43276,45216,45324,2340,32788,33812,256,260,276,513]

theorem envBound26166 : H12AffineFastState.Bounded env26166 := by
  intro p hp
  have h : env26166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26165_26166 : H12AffineEnvironment.transform 17 43048 env26165 = env26166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43048 env26165 == env26166) = true)

def env26167 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,184,8232,1182,4524,2048,1024,8232,9601,9497,9348,138,8328,9348,2340,4232,4388,2340,8252,9276,256,260,276,513]

theorem envBound26167 : H12AffineFastState.Bounded env26167 := by
  intro p hp
  have h : env26167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26166_26167 : H12AffineEnvironment.transform 14 8232 env26166 = env26167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env26166 == env26167) = true)

theorem identity26167 : scanCanonicalize (H12AffineFastState.compose env26167 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 182) := by decide +kernel

theorem selectedBound26167 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env26168 : List Nat := [2,4,8,16,32,17,128,182,512,1024,2048,4096,8192,184,8232,1182,4122,2048,1024,8232,9271,9391,9348,138,8328,9348,2194,4232,4242,2194,8252,9276,182,178,162,513]

theorem envBound26168 : H12AffineFastState.Bounded env26168 := by
  intro p hp
  have h : env26168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26167_26168 : H12AffineEnvironment.transform 7 182 env26167 = env26168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 182 env26167 == env26168) = true)

theorem identity26168 : scanCanonicalize (H12AffineFastState.compose env26168 (packedSelected [4,9] rootPS)) = affineNative (2^(9+1) ^^^ 150) := by decide +kernel

theorem selectedBound26168 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env26169 : List Nat := [2,4,8,16,32,17,128,182,512,150,2048,4096,8192,184,8232,8,4122,2048,150,8232,8353,8249,8210,138,8328,8210,2194,4232,4242,2194,8252,8362,182,178,162,513]

theorem envBound26169 : H12AffineFastState.Bounded env26169 := by
  intro p hp
  have h : env26169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26168_26169 : H12AffineEnvironment.transform 9 150 env26168 = env26169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 150 env26168 == env26169) = true)

def env26170 : List Nat := [2,4,8,16,32,17,128,182,512,150,2048,4096,144,184,184,8,4122,2048,150,184,49,169,130,138,24,130,2194,4232,4242,2194,172,58,182,178,162,513]

theorem envBound26170 : H12AffineFastState.Bounded env26170 := by
  intro p hp
  have h : env26170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26169_26170 : H12AffineEnvironment.transform 12 144 env26169 = env26170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 144 env26169 == env26170) = true)

theorem identity26170 : scanCanonicalize (H12AffineFastState.compose env26170 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound26170 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26171 : List Nat := [2,4,8,16,32,17,128,182,1,150,2048,4096,144,184,184,8,4122,2048,150,184,49,169,130,138,24,130,2194,4232,4242,2194,172,58,182,178,162,0]

theorem envBound26171 : H12AffineFastState.Bounded env26171 := by
  intro p hp
  have h : env26171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26170_26171 : H12AffineEnvironment.transform 8 1 env26170 = env26171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env26170 == env26171) = true)

theorem identity26171 : scanCanonicalize (H12AffineFastState.compose env26171 (packedSelected [0,1] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound26171 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env26172 : List Nat := [2,4,8,16,32,17,128,182,1,150,2048,184,144,184,184,8,162,2048,150,184,49,169,130,138,24,130,2194,48,42,2194,172,58,182,178,162,0]

theorem envBound26172 : H12AffineFastState.Bounded env26172 := by
  intro p hp
  have h : env26172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26171_26172 : H12AffineEnvironment.transform 11 184 env26171 = env26172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env26171 == env26172) = true)

theorem identity26172 : scanCanonicalize (H12AffineFastState.compose env26172 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound26172 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env26173 : List Nat := [2,4,8,10,32,11,128,172,1,140,2048,162,138,162,162,8,162,2048,140,162,43,169,130,138,2,130,2184,42,42,2184,172,32,172,168,162,0]

theorem envBound26173 : H12AffineFastState.Bounded env26173 := by
  intro p hp
  have h : env26173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26172_26173 : H12AffineEnvironment.transform 3 10 env26172 = env26173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env26172 == env26173) = true)

theorem identity26173 : scanCanonicalize (H12AffineFastState.compose env26173 (packedSelected [0,5] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound26173 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env26174 : List Nat := [2,4,8,10,32,11,128,172,1,140,42,162,138,162,162,8,162,42,140,162,43,169,130,138,2,130,162,42,42,162,172,32,172,168,162,0]

theorem envBound26174 : H12AffineFastState.Bounded env26174 := by
  intro p hp
  have h : env26174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26173_26174 : H12AffineEnvironment.transform 10 42 env26173 = env26174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env26173 == env26174) = true)

theorem identity26174 : scanCanonicalize (H12AffineFastState.compose env26174 (packedSelected [0,8] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound26174 : packedSelected [0,8] rootPS < 2^1333 := by decide +kernel

def env26175 : List Nat := [2,4,8,10,32,11,8,36,1,4,42,42,2,42,42,8,42,42,4,42,43,33,10,2,2,10,42,42,42,42,36,32,36,32,42,0]

theorem envBound26175 : H12AffineFastState.Bounded env26175 := by
  intro p hp
  have h : env26175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26174_26175 : H12AffineEnvironment.transform 6 8 env26174 = env26175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env26174 == env26175) = true)

theorem identity26175 : scanCanonicalize (H12AffineFastState.compose env26175 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound26175 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26176 : List Nat := [2,4,8,10,12,11,8,8,1,4,6,6,2,6,6,8,6,6,4,6,7,13,10,2,2,10,6,6,6,6,8,12,8,12,6,0]

theorem envBound26176 : H12AffineFastState.Bounded env26176 := by
  intro p hp
  have h : env26176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26175_26176 : H12AffineEnvironment.transform 4 12 env26175 = env26176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env26175 == env26176) = true)

def leafEnv26176 : List Nat := [2,4,8,10,12,11,8,8,1,4,6,6,2,6,6,8,6,6,4,6,7,13,10,2,8,2,1,10,6,6,6,6,8,12,8,12,4,8,6,0,0,6,1]

def active26176 : List Nat := [0,1,2]

def tree26176 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood26176 : H12WitnessSearch.Good tree26176 := H12GlobalWitnessIndex.good

theorem leafIdentity26176 : H12AffineFastState.composeSystem env26176 rootObs = leafEnv26176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env26176 rootObs == leafEnv26176) = true)

theorem terminalChecked26176 : H12PackedTerminal.terminalCheckFast leafEnv26176 active26176 tree26176 = true := by decide +kernel

def env26177 : List Nat := [2,4,8,16,32,17,128,182,512,150,2048,4096,145,184,185,8,4122,2048,150,185,48,168,131,138,25,131,2194,4232,4242,2194,173,59,182,178,162,513]

theorem envBound26177 : H12AffineFastState.Bounded env26177 := by
  intro p hp
  have h : env26177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26169_26177 : H12AffineEnvironment.transform 12 145 env26169 = env26177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 145 env26169 == env26177) = true)

theorem identity26177 : scanCanonicalize (H12AffineFastState.compose env26177 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound26177 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26178 : List Nat := [2,4,8,16,32,17,128,182,27,150,2048,4096,145,184,185,8,4122,2048,150,185,48,168,131,138,25,131,2194,4232,4242,2194,173,59,182,178,162,26]

theorem envBound26178 : H12AffineFastState.Bounded env26178 := by
  intro p hp
  have h : env26178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26177_26178 : H12AffineEnvironment.transform 8 27 env26177 = env26178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env26177 == env26178) = true)

theorem identity26178 : scanCanonicalize (H12AffineFastState.compose env26178 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 49) := by decide +kernel

theorem selectedBound26178 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env26179 : List Nat := [2,4,8,16,32,17,128,182,27,150,2048,49,145,184,185,8,43,2048,150,185,48,168,131,138,25,131,2194,185,163,2194,173,59,182,178,162,26]

theorem envBound26179 : H12AffineFastState.Bounded env26179 := by
  intro p hp
  have h : env26179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26178_26179 : H12AffineEnvironment.transform 11 49 env26178 = env26179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env26178 == env26179) = true)

theorem identity26179 : scanCanonicalize (H12AffineFastState.compose env26179 (packedSelected [0,1,5,8] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound26179 : packedSelected [0,1,5,8] rootPS < 2^1333 := by decide +kernel

def env26180 : List Nat := [2,4,8,10,32,11,128,172,1,140,2048,43,139,162,163,8,43,2048,140,163,42,168,131,138,3,131,2184,163,163,2184,173,33,172,168,162,0]

theorem envBound26180 : H12AffineFastState.Bounded env26180 := by
  intro p hp
  have h : env26180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26179_26180 : H12AffineEnvironment.transform 3 10 env26179 = env26180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env26179 == env26180) = true)

theorem identity26180 : scanCanonicalize (H12AffineFastState.compose env26180 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 162) := by decide +kernel

theorem selectedBound26180 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env26181 : List Nat := [2,4,8,10,32,11,128,172,1,140,162,43,139,162,163,8,43,162,140,163,42,168,131,138,3,131,42,163,163,42,173,33,172,168,162,0]

theorem envBound26181 : H12AffineFastState.Bounded env26181 := by
  intro p hp
  have h : env26181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26180_26181 : H12AffineEnvironment.transform 10 162 env26180 = env26181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 162 env26180 == env26181) = true)

theorem identity26181 : scanCanonicalize (H12AffineFastState.compose env26181 (packedSelected [0,5] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound26181 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env26182 : List Nat := [2,4,8,10,32,11,8,36,1,4,42,43,3,42,43,8,43,42,4,43,42,32,11,2,3,11,42,43,43,42,37,33,36,32,42,0]

theorem envBound26182 : H12AffineFastState.Bounded env26182 := by
  intro p hp
  have h : env26182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26181_26182 : H12AffineEnvironment.transform 6 8 env26181 = env26182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env26181 == env26182) = true)

theorem identity26182 : scanCanonicalize (H12AffineFastState.compose env26182 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound26182 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26183 : List Nat := [2,2,8,10,32,11,8,34,1,2,42,43,3,42,43,8,43,42,2,43,42,32,11,2,3,11,42,43,43,42,35,33,34,32,42,0]

theorem envBound26183 : H12AffineFastState.Bounded env26183 := by
  intro p hp
  have h : env26183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26182_26183 : H12AffineEnvironment.transform 1 2 env26182 = env26183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env26182 == env26183) = true)

def leafEnv26183 : List Nat := [2,2,8,10,32,11,8,34,1,2,42,43,3,42,43,8,43,42,2,43,42,32,11,2,35,3,1,11,42,43,43,42,35,33,34,32,2,8,42,0,0,43,1]

def active26183 : List Nat := [0,2,4]

def tree26183 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood26183 : H12WitnessSearch.Good tree26183 := H12GlobalWitnessIndex.good

theorem leafIdentity26183 : H12AffineFastState.composeSystem env26183 rootObs = leafEnv26183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env26183 rootObs == leafEnv26183) = true)

theorem terminalChecked26183 : H12PackedTerminal.terminalCheckFast leafEnv26183 active26183 tree26183 = true := by decide +kernel

def env26184 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,184,8233,1182,4524,2049,1024,8233,9600,9496,9349,138,8328,9349,2341,4233,4389,2340,8253,9277,256,260,276,513]

theorem envBound26184 : H12AffineFastState.Bounded env26184 := by
  intro p hp
  have h : env26184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26166_26184 : H12AffineEnvironment.transform 14 8233 env26166 = env26184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env26166 == env26184) = true)

theorem identity26184 : scanCanonicalize (H12AffineFastState.compose env26184 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 63) := by decide +kernel

theorem selectedBound26184 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env26185 : List Nat := [2,4,8,16,32,17,128,63,512,1024,2048,4096,8192,184,8233,1182,4243,2049,1024,8233,9407,9255,9349,138,8328,9349,2074,4233,4122,2075,8253,9277,63,59,43,513]

theorem envBound26185 : H12AffineFastState.Bounded env26185 := by
  intro p hp
  have h : env26185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26184_26185 : H12AffineEnvironment.transform 7 63 env26184 = env26185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 63 env26184 == env26185) = true)

theorem identity26185 : scanCanonicalize (H12AffineFastState.compose env26185 (packedSelected [4,9] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound26185 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env26186 : List Nat := [2,4,8,16,32,17,128,63,512,4,2048,4096,8192,184,8233,154,4243,2049,4,8233,8379,8227,8321,138,8328,8321,2074,4233,4122,2075,8253,8249,63,59,43,513]

theorem envBound26186 : H12AffineFastState.Bounded env26186 := by
  intro p hp
  have h : env26186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26185_26186 : H12AffineEnvironment.transform 9 4 env26185 = env26186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env26185 == env26186) = true)

def env26187 : List Nat := [2,4,8,16,32,17,128,63,512,4,2048,4096,24,184,49,154,4243,2049,4,49,163,59,153,138,144,153,2074,4233,4122,2075,37,33,63,59,43,513]

theorem envBound26187 : H12AffineFastState.Bounded env26187 := by
  intro p hp
  have h : env26187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26186_26187 : H12AffineEnvironment.transform 12 24 env26186 = env26187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env26186 == env26187) = true)

theorem identity26187 : scanCanonicalize (H12AffineFastState.compose env26187 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 147) := by decide +kernel

theorem selectedBound26187 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26188 : List Nat := [2,4,8,16,32,17,128,63,147,4,2048,4096,24,184,49,154,4243,2049,4,49,163,59,153,138,144,153,2074,4233,4122,2075,37,33,63,59,43,146]

theorem envBound26188 : H12AffineFastState.Bounded env26188 := by
  intro p hp
  have h : env26188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26187_26188 : H12AffineEnvironment.transform 8 147 env26187 = env26188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 147 env26187 == env26188) = true)

theorem identity26188 : scanCanonicalize (H12AffineFastState.compose env26188 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2049) := by decide +kernel

theorem selectedBound26188 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env26189 : List Nat := [2,4,8,16,32,17,128,63,147,4,2048,2049,24,184,49,154,2194,2049,4,49,163,59,153,138,144,153,2074,2184,2075,2075,37,33,63,59,43,146]

theorem envBound26189 : H12AffineFastState.Bounded env26189 := by
  intro p hp
  have h : env26189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26188_26189 : H12AffineEnvironment.transform 11 2049 env26188 = env26189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2049 env26188 == env26189) = true)

theorem identity26189 : scanCanonicalize (H12AffineFastState.compose env26189 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound26189 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env26190 : List Nat := [2,4,8,16,32,17,19,63,0,4,2048,2049,24,43,49,9,2049,2049,4,49,48,59,10,25,3,10,2074,2075,2075,2075,37,33,63,59,43,1]

theorem envBound26190 : H12AffineFastState.Bounded env26190 := by
  intro p hp
  have h : env26190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26189_26190 : H12AffineEnvironment.transform 6 19 env26189 = env26190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env26189 == env26190) = true)

theorem identity26190 : scanCanonicalize (H12AffineFastState.compose env26190 (packedSelected [0,5] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound26190 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env26191 : List Nat := [2,4,8,16,32,17,19,63,0,4,43,42,24,43,49,9,42,42,4,49,48,59,10,25,3,10,49,48,48,48,37,33,63,59,43,1]

theorem envBound26191 : H12AffineFastState.Bounded env26191 := by
  intro p hp
  have h : env26191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26190_26191 : H12AffineEnvironment.transform 10 43 env26190 = env26191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env26190 == env26191) = true)

theorem identity26191 : scanCanonicalize (H12AffineFastState.compose env26191 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound26191 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env26192 : List Nat := [2,4,8,11,32,10,8,36,0,4,43,42,3,43,42,9,42,42,4,42,43,32,10,2,3,10,42,43,43,43,37,33,36,32,43,1]

theorem envBound26192 : H12AffineFastState.Bounded env26192 := by
  intro p hp
  have h : env26192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26191_26192 : H12AffineEnvironment.transform 3 11 env26191 = env26192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env26191 == env26192) = true)

theorem identity26192 : scanCanonicalize (H12AffineFastState.compose env26192 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound26192 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26193 : List Nat := [2,4,4,7,32,6,4,36,0,4,39,38,3,39,38,5,38,38,4,38,39,32,6,2,3,6,38,39,39,39,37,33,36,32,39,1]

theorem envBound26193 : H12AffineFastState.Bounded env26193 := by
  intro p hp
  have h : env26193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26192_26193 : H12AffineEnvironment.transform 2 4 env26192 = env26193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env26192 == env26193) = true)

def leafEnv26193 : List Nat := [2,4,4,7,32,6,4,36,0,4,39,38,3,39,38,5,38,38,4,38,39,32,6,2,37,3,1,6,38,39,39,39,37,33,36,32,4,5,39,1,0,38,1]

def active26193 : List Nat := [0,1,4]

def tree26193 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood26193 : H12WitnessSearch.Good tree26193 := H12GlobalWitnessIndex.good

theorem leafIdentity26193 : H12AffineFastState.composeSystem env26193 rootObs = leafEnv26193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env26193 rootObs == leafEnv26193) = true)

theorem terminalChecked26193 : H12PackedTerminal.terminalCheckFast leafEnv26193 active26193 tree26193 = true := by decide +kernel

def env26194 : List Nat := [2,4,8,16,32,17,128,63,512,4,2048,4096,25,184,48,154,4243,2049,4,48,162,58,152,138,145,152,2074,4233,4122,2075,36,32,63,59,43,513]

theorem envBound26194 : H12AffineFastState.Bounded env26194 := by
  intro p hp
  have h : env26194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26186_26194 : H12AffineEnvironment.transform 12 25 env26186 = env26194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env26186 == env26194) = true)

theorem identity26194 : scanCanonicalize (H12AffineFastState.compose env26194 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound26194 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26195 : List Nat := [2,4,8,16,32,17,128,63,0,4,2048,4096,25,184,48,154,4243,2049,4,48,162,58,152,138,145,152,2074,4233,4122,2075,36,32,63,59,43,1]

theorem envBound26195 : H12AffineFastState.Bounded env26195 := by
  intro p hp
  have h : env26195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26194_26195 : H12AffineEnvironment.transform 8 0 env26194 = env26195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env26194 == env26195) = true)

theorem identity26195 : scanCanonicalize (H12AffineFastState.compose env26195 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2074) := by decide +kernel

theorem selectedBound26195 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env26196 : List Nat := [2,4,8,16,32,17,128,63,0,4,2048,2074,25,184,48,154,2185,2049,4,48,162,58,152,138,145,152,2074,2195,2048,2075,36,32,63,59,43,1]

theorem envBound26196 : H12AffineFastState.Bounded env26196 := by
  intro p hp
  have h : env26196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26195_26196 : H12AffineEnvironment.transform 11 2074 env26195 = env26196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2074 env26195 == env26196) = true)

theorem identity26196 : scanCanonicalize (H12AffineFastState.compose env26196 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound26196 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env26197 : List Nat := [2,4,8,16,32,17,19,63,0,4,2048,2074,25,43,48,9,2074,2049,4,48,49,58,11,25,2,11,2074,2048,2048,2075,36,32,63,59,43,1]

theorem envBound26197 : H12AffineFastState.Bounded env26197 := by
  intro p hp
  have h : env26197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26196_26197 : H12AffineEnvironment.transform 6 19 env26196 = env26197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env26196 == env26197) = true)

theorem identity26197 : scanCanonicalize (H12AffineFastState.compose env26197 (packedSelected [0,5] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound26197 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env26198 : List Nat := [2,4,8,16,32,17,19,63,0,4,43,49,25,43,48,9,49,42,4,48,49,58,11,25,2,11,49,43,43,48,36,32,63,59,43,1]

theorem envBound26198 : H12AffineFastState.Bounded env26198 := by
  intro p hp
  have h : env26198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26197_26198 : H12AffineEnvironment.transform 10 43 env26197 = env26198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env26197 == env26198) = true)

theorem identity26198 : scanCanonicalize (H12AffineFastState.compose env26198 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound26198 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env26199 : List Nat := [2,4,8,11,32,10,8,36,0,4,43,42,2,43,43,9,42,42,4,43,42,33,11,2,2,11,42,43,43,43,36,32,36,32,43,1]

theorem envBound26199 : H12AffineFastState.Bounded env26199 := by
  intro p hp
  have h : env26199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26198_26199 : H12AffineEnvironment.transform 3 11 env26198 = env26199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env26198 == env26199) = true)

theorem identity26199 : scanCanonicalize (H12AffineFastState.compose env26199 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound26199 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26200 : List Nat := [2,4,8,11,6,10,8,2,0,4,13,12,2,13,13,9,12,12,4,13,12,7,11,2,2,11,12,13,13,13,2,6,2,6,13,1]

theorem envBound26200 : H12AffineFastState.Bounded env26200 := by
  intro p hp
  have h : env26200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26199_26200 : H12AffineEnvironment.transform 4 6 env26199 = env26200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env26199 == env26200) = true)

def leafEnv26200 : List Nat := [2,4,8,11,6,10,8,2,0,4,13,12,2,13,13,9,12,12,4,13,12,7,11,2,2,2,1,11,12,13,13,13,2,6,2,6,4,9,13,1,0,13,1]

def active26200 : List Nat := [0,1,2]

def tree26200 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood26200 : H12WitnessSearch.Good tree26200 := H12GlobalWitnessIndex.good

theorem leafIdentity26200 : H12AffineFastState.composeSystem env26200 rootObs = leafEnv26200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env26200 rootObs == leafEnv26200) = true)

theorem terminalChecked26200 : H12PackedTerminal.terminalCheckFast leafEnv26200 active26200 tree26200 = true := by decide +kernel

def env26201 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,185,32768,1183,4525,262144,1024,32768,34216,34096,33965,139,8328,33965,262437,45217,45324,2340,32788,33812,256,260,276,513]

theorem envBound26201 : H12AffineFastState.Bounded env26201 := by
  intro p hp
  have h : env26201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26164_26201 : H12AffineEnvironment.transform 13 185 env26164 = env26201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 185 env26164 == env26201) = true)

theorem identity26201 : scanCanonicalize (H12AffineFastState.compose env26201 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound26201 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env26202 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,185,8461,1183,4525,262144,1024,8461,9381,9277,9632,139,8328,9632,262437,4524,4097,2340,8473,9497,256,260,276,513]

theorem envBound26202 : H12AffineFastState.Bounded env26202 := by
  intro p hp
  have h : env26202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26201_26202 : H12AffineEnvironment.transform 14 8461 env26201 = env26202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env26201 == env26202) = true)

theorem identity26202 : scanCanonicalize (H12AffineFastState.compose env26202 (packedSelected [2,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 438) := by decide +kernel

theorem selectedBound26202 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env26203 : List Nat := [2,4,8,16,32,17,128,256,512,1024,438,4096,8192,185,8461,1183,4525,262144,1024,8461,9381,9277,9632,139,8328,9632,262437,4524,4097,146,8473,9497,256,260,276,513]

theorem envBound26203 : H12AffineFastState.Bounded env26203 := by
  intro p hp
  have h : env26203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26202_26203 : H12AffineEnvironment.transform 10 438 env26202 = env26203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 438 env26202 == env26203) = true)

theorem identity26203 : scanCanonicalize (H12AffineFastState.compose env26203 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound26203 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env26204 : List Nat := [2,4,8,16,32,17,128,256,512,1024,438,1297,8192,185,8461,1183,1212,262144,1024,8461,9381,9277,9632,139,8328,9632,262437,1213,1296,146,8473,9497,256,260,276,513]

theorem envBound26204 : H12AffineFastState.Bounded env26204 := by
  intro p hp
  have h : env26204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26203_26204 : H12AffineEnvironment.transform 11 1297 env26203 = env26204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env26203 == env26204) = true)

theorem identity26204 : scanCanonicalize (H12AffineFastState.compose env26204 (packedSelected [1,2,3,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound26204 : packedSelected [1,2,3,12,15] rootPS < 2^1333 := by decide +kernel

def env26205 : List Nat := [2,4,8,16,32,17,128,256,512,4,438,277,8192,185,8461,155,184,262144,4,8461,8353,8249,8612,139,8328,8612,262437,185,276,146,8473,8477,256,260,276,513]

theorem envBound26205 : H12AffineFastState.Bounded env26205 := by
  intro p hp
  have h : env26205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26204_26205 : H12AffineEnvironment.transform 9 4 env26204 = env26205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env26204 == env26205) = true)

theorem identity26205 : scanCanonicalize (H12AffineFastState.compose env26205 (packedSelected [13,17] rootPS)) = affineNative (2^(17+1) ^^^ 318) := by decide +kernel

theorem selectedBound26205 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env26206 : List Nat := [2,4,8,16,32,17,128,256,512,4,438,277,8192,185,8461,155,184,318,4,8461,8353,8249,8612,139,8328,8612,27,185,276,146,8473,8477,256,260,276,513]

theorem envBound26206 : H12AffineFastState.Bounded env26206 := by
  intro p hp
  have h : env26206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26205_26206 : H12AffineEnvironment.transform 17 318 env26205 = env26206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 318 env26205 == env26206) = true)

theorem identity26206 : scanCanonicalize (H12AffineFastState.compose env26206 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 138) := by decide +kernel

theorem selectedBound26206 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env26207 : List Nat := [2,4,8,16,32,17,128,256,512,4,438,277,138,185,391,155,184,318,4,391,43,179,302,139,2,302,27,185,276,146,403,407,256,260,276,513]

theorem envBound26207 : H12AffineFastState.Bounded env26207 := by
  intro p hp
  have h : env26207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26206_26207 : H12AffineEnvironment.transform 12 138 env26206 = env26207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 138 env26206 == env26207) = true)

theorem identity26207 : scanCanonicalize (H12AffineFastState.compose env26207 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(7+1) ^^^ 157) := by decide +kernel

theorem selectedBound26207 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env26208 : List Nat := [2,4,8,16,32,17,128,157,512,4,43,136,138,185,26,155,184,163,4,26,43,179,179,139,2,179,27,185,137,146,14,10,157,153,137,513]

theorem envBound26208 : H12AffineFastState.Bounded env26208 := by
  intro p hp
  have h : env26208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26207_26208 : H12AffineEnvironment.transform 7 157 env26207 = env26208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 157 env26207 == env26208) = true)

theorem identity26208 : scanCanonicalize (H12AffineFastState.compose env26208 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound26208 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env26209 : List Nat := [2,4,8,16,32,17,128,157,0,4,43,136,138,185,26,155,184,163,4,26,43,179,179,139,2,179,27,185,137,146,14,10,157,153,137,1]

theorem envBound26209 : H12AffineFastState.Bounded env26209 := by
  intro p hp
  have h : env26209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26208_26209 : H12AffineEnvironment.transform 8 0 env26208 = env26209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env26208 == env26209) = true)

theorem identity26209 : scanCanonicalize (H12AffineFastState.compose env26209 (packedSelected [0,3] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound26209 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env26210 : List Nat := [2,4,8,16,32,17,9,20,0,4,43,1,3,48,26,18,49,42,4,26,43,58,58,2,2,58,27,48,0,27,14,10,20,16,0,1]

theorem envBound26210 : H12AffineFastState.Bounded env26210 := by
  intro p hp
  have h : env26210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26209_26210 : H12AffineEnvironment.transform 6 9 env26209 = env26210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env26209 == env26210) = true)

theorem identity26210 : scanCanonicalize (H12AffineFastState.compose env26210 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound26210 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env26211 : List Nat := [2,4,8,10,32,11,9,14,0,4,43,1,3,42,0,8,43,42,4,0,43,32,32,2,2,32,1,42,0,1,14,10,14,10,0,1]

theorem envBound26211 : H12AffineFastState.Bounded env26211 := by
  intro p hp
  have h : env26211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26210_26211 : H12AffineEnvironment.transform 3 10 env26210 = env26211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env26210 == env26211) = true)

theorem identity26211 : scanCanonicalize (H12AffineFastState.compose env26211 (packedSelected [11] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound26211 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env26212 : List Nat := [2,4,8,10,11,11,9,14,0,4,0,1,3,1,0,8,0,1,4,0,0,11,11,2,2,11,1,1,0,1,14,10,14,10,0,1]

theorem envBound26212 : H12AffineFastState.Bounded env26212 := by
  intro p hp
  have h : env26212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26211_26212 : H12AffineEnvironment.transform 4 11 env26211 = env26212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env26211 == env26212) = true)

theorem identity26212 : scanCanonicalize (H12AffineFastState.compose env26212 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound26212 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env26213 : List Nat := [2,3,8,10,11,11,9,9,0,3,0,1,3,1,0,8,0,1,3,0,0,11,11,2,2,11,1,1,0,1,9,10,9,10,0,1]

theorem envBound26213 : H12AffineFastState.Bounded env26213 := by
  intro p hp
  have h : env26213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26212_26213 : H12AffineEnvironment.transform 1 3 env26212 = env26213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env26212 == env26213) = true)

def env26214 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,2248768,16777216,8328,2248720,134217728,151429283,151302307,4294795,16876545,151490696,257,138907683,155701329,513]

theorem envBound26214 : H12AffineFastState.Bounded env26214 := by
  intro p hp
  have h : env26214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26105_26214 : H12AffineEnvironment.transform 18 1025 env26105 = env26214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env26105 == env26214) = true)

def env26215 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,2248768,16777216,8328,2248720,21331968,4399267,4272291,4294795,16876545,4329608,257,16912419,151633,513]

theorem envBound26215 : H12AffineFastState.Bounded env26215 := by
  intro p hp
  have h : env26215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26214_26215 : H12AffineEnvironment.transform 26 21331968 env26214 = env26215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 21331968 env26214 == env26215) = true)

theorem identity26215 : scanCanonicalize (H12AffineFastState.compose env26215 (packedSelected [14] rootPS)) = affineNative (2^(20+1) ^^^ 230439) := by decide +kernel

theorem selectedBound26215 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env26216 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,230439,4194304,119911,16777216,8328,119863,21331968,4399267,4272291,4294795,16876545,4329608,257,16912419,151633,513]

theorem envBound26216 : H12AffineFastState.Bounded env26216 := by
  intro p hp
  have h : env26216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26215_26216 : H12AffineEnvironment.transform 20 230439 env26215 = env26216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 230439 env26215 == env26216) = true)

theorem identity26216 : scanCanonicalize (H12AffineFastState.compose env26216 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(23+1) ^^^ 4384162) := by decide +kernel

theorem selectedBound26216 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env26217 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,230439,4194304,119911,4384162,8328,119863,484770,4399267,4272291,4294795,4415907,4329608,257,4257153,151633,513]

theorem envBound26217 : H12AffineFastState.Bounded env26217 := by
  intro p hp
  have h : env26217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26216_26217 : H12AffineEnvironment.transform 23 4384162 env26216 = env26217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 4384162 env26216 == env26217) = true)

theorem identity26217 : scanCanonicalize (H12AffineFastState.compose env26217 (packedSelected [13,21] rootPS)) = affineNative (2^(16+1) ^^^ 45404) := by decide +kernel

theorem selectedBound26217 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env26218 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,45404,262144,1025,32768,79227,4194304,119911,4216062,8328,119863,382206,4297215,4272291,4294795,4313343,4235732,257,4257153,57613,513]

theorem envBound26218 : H12AffineFastState.Bounded env26218 := by
  intro p hp
  have h : env26218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26217_26218 : H12AffineEnvironment.transform 16 45404 env26217 = env26218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45404 env26217 == env26218) = true)

theorem identity26218 : scanCanonicalize (H12AffineFastState.compose env26218 (packedSelected [0,3,5,10,27] rootPS)) = affineNative (2^(21+1) ^^^ 41168) := by decide +kernel

theorem selectedBound26218 : packedSelected [0,3,5,10,27] rootPS < 2^1333 := by decide +kernel

def env26219 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,45404,262144,1025,32768,79227,41168,119911,62510,8328,119863,382206,78127,102515,75867,94255,260,257,21841,57613,513]

theorem envBound26219 : H12AffineFastState.Bounded env26219 := by
  intro p hp
  have h : env26219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26218_26219 : H12AffineEnvironment.transform 21 41168 env26218 = env26219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41168 env26218 == env26219) = true)

theorem identity26219 : scanCanonicalize (H12AffineFastState.compose env26219 (packedSelected [1,5,8,12,15,17,24] rootPS)) = affineNative (2^(15+1) ^^^ 32882) := by decide +kernel

theorem selectedBound26219 : packedSelected [1,5,8,12,15,17,24] rootPS < 2^1333 := by decide +kernel

def env26220 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,32882,45404,262144,1025,32768,46345,41168,21525,62510,8328,21573,283788,45405,4097,43049,61533,260,257,21841,57613,513]

theorem envBound26220 : H12AffineFastState.Bounded env26220 := by
  intro p hp
  have h : env26220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26219_26220 : H12AffineEnvironment.transform 15 32882 env26219 = env26220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32882 env26219 == env26220) = true)

theorem identity26220 : scanCanonicalize (H12AffineFastState.compose env26220 (packedSelected [2,3,6,8,10,11,13,17,18] rootPS)) = affineNative (2^(17+1) ^^^ 54127) := by decide +kernel

theorem selectedBound26220 : packedSelected [2,3,6,8,10,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env26221 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,32882,45404,54127,1025,32768,46345,41168,21525,62510,8328,21573,34787,45405,4097,43049,61533,260,257,21841,57613,513]

theorem envBound26221 : H12AffineFastState.Bounded env26221 := by
  intro p hp
  have h : env26221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26220_26221 : H12AffineEnvironment.transform 17 54127 env26220 = env26221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 54127 env26220 == env26221) = true)

def env26222 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,30040,29994,17412,9783,1025,30040,16465,21896,21525,374,8328,21573,29371,17413,4097,23921,1285,260,257,21841,5205,513]

theorem envBound26222 : H12AffineFastState.Bounded env26222 := by
  intro p hp
  have h : env26222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26221_26222 : H12AffineEnvironment.transform 14 30040 env26221 = env26222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 30040 env26221 == env26222) = true)

theorem identity26222 : scanCanonicalize (H12AffineFastState.compose env26222 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound26222 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env26223 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,8192,16384,25864,25978,17412,9783,1025,25864,16465,17880,17477,374,8328,17429,25323,17413,81,19745,1285,260,257,17665,1029,513]

theorem envBound26223 : H12AffineFastState.Bounded env26223 := by
  intro p hp
  have h : env26223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26222_26223 : H12AffineEnvironment.transform 11 80 env26222 = env26223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env26222 == env26223) = true)

theorem identity26223 : scanCanonicalize (H12AffineFastState.compose env26223 (packedSelected [3,8,10,13,17] rootPS)) = affineNative (2^(13+1) ^^^ 972) := by decide +kernel

theorem selectedBound26223 : packedSelected [3,8,10,13,17] rootPS < 2^1333 := by decide +kernel

def env26224 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,8192,972,9924,9910,1992,9783,1025,9924,925,1556,1929,374,8328,2009,8487,1993,81,3821,1285,260,257,1741,1029,513]

theorem envBound26224 : H12AffineFastState.Bounded env26224 := by
  intro p hp
  have h : env26224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26223_26224 : H12AffineEnvironment.transform 13 972 env26223 = env26224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 972 env26223 == env26224) = true)

def env26225 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,240,972,1588,1606,1992,1735,1025,1588,925,1556,1929,374,120,2009,471,1993,81,3821,1285,260,257,1741,1029,513]

theorem envBound26225 : H12AffineFastState.Bounded env26225 := by
  intro p hp
  have h : env26225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26224_26225 : H12AffineEnvironment.transform 12 240 env26224 = env26225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 240 env26224 == env26225) = true)

theorem identity26225 : scanCanonicalize (H12AffineFastState.compose env26225 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 653) := by decide +kernel

theorem selectedBound26225 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26226 : List Nat := [2,4,8,16,32,64,128,256,512,653,2048,80,240,972,185,203,325,74,652,185,925,153,260,374,120,340,471,324,81,2144,904,260,257,64,648,513]

theorem envBound26226 : H12AffineFastState.Bounded env26226 := by
  intro p hp
  have h : env26226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26225_26226 : H12AffineEnvironment.transform 9 653 env26225 = env26226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 653 env26225 == env26226) = true)

theorem identity26226 : scanCanonicalize (H12AffineFastState.compose env26226 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound26226 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env26227 : List Nat := [2,4,8,16,32,64,128,252,512,653,2048,80,240,560,185,203,185,74,652,185,609,153,248,138,120,168,43,184,81,2144,628,248,253,64,648,513]

theorem envBound26227 : H12AffineFastState.Bounded env26227 := by
  intro p hp
  have h : env26227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26226_26227 : H12AffineEnvironment.transform 7 252 env26226 = env26227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env26226 == env26227) = true)

theorem identity26227 : scanCanonicalize (H12AffineFastState.compose env26227 (packedSelected [0,4,5,7,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 147) := by decide +kernel

theorem selectedBound26227 : packedSelected [0,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env26228 : List Nat := [2,4,8,16,32,64,128,252,512,653,147,80,240,560,185,203,185,74,652,185,609,153,248,138,120,168,43,184,81,243,628,248,253,64,648,513]

theorem envBound26228 : H12AffineFastState.Bounded env26228 := by
  intro p hp
  have h : env26228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26227_26228 : H12AffineEnvironment.transform 10 147 env26227 = env26228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 147 env26227 == env26228) = true)

theorem identity26228 : scanCanonicalize (H12AffineFastState.compose env26228 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(8+1) ^^^ 185) := by decide +kernel

theorem selectedBound26228 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env26229 : List Nat := [2,4,8,16,32,64,128,252,185,52,147,80,240,137,185,203,185,74,53,185,216,153,248,138,120,168,43,184,81,243,205,248,253,64,49,184]

theorem envBound26229 : H12AffineFastState.Bounded env26229 := by
  intro p hp
  have h : env26229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26228_26229 : H12AffineEnvironment.transform 8 185 env26228 = env26229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 185 env26228 == env26229) = true)

theorem identity26229 : scanCanonicalize (H12AffineFastState.compose env26229 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 105) := by decide +kernel

theorem selectedBound26229 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env26230 : List Nat := [2,4,8,16,32,64,105,21,80,52,122,80,25,96,80,34,80,74,53,80,49,112,17,99,120,65,43,81,81,26,36,17,20,64,49,81]

theorem envBound26230 : H12AffineFastState.Bounded env26230 := by
  intro p hp
  have h : env26230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26229_26230 : H12AffineEnvironment.transform 6 105 env26229 = env26230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 105 env26229 == env26230) = true)

def env26231 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,241,972,1589,1607,1992,1734,1025,1589,925,1556,1929,374,121,2009,470,1993,81,3821,1285,260,257,1741,1029,513]

theorem envBound26231 : H12AffineFastState.Bounded env26231 := by
  intro p hp
  have h : env26231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26224_26231 : H12AffineEnvironment.transform 12 241 env26224 = env26231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 241 env26224 == env26231) = true)

theorem identity26231 : scanCanonicalize (H12AffineFastState.compose env26231 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 880) := by decide +kernel

theorem selectedBound26231 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26232 : List Nat := [2,4,8,16,32,64,128,256,512,880,2048,80,241,972,325,311,184,438,881,325,925,356,249,374,121,169,470,185,81,2461,629,260,257,445,885,513]

theorem envBound26232 : H12AffineFastState.Bounded env26232 := by
  intro p hp
  have h : env26232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26231_26232 : H12AffineEnvironment.transform 9 880 env26231 = env26232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 880 env26231 == env26232) = true)

theorem identity26232 : scanCanonicalize (H12AffineFastState.compose env26232 (packedSelected [4,5,8,9,11] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound26232 : packedSelected [4,5,8,9,11] rootPS < 2^1333 := by decide +kernel

def env26233 : List Nat := [2,4,8,16,32,64,128,252,512,652,2048,80,241,560,185,203,184,74,653,185,609,152,249,138,121,169,42,185,81,2145,629,248,253,65,649,513]

theorem envBound26233 : H12AffineFastState.Bounded env26233 := by
  intro p hp
  have h : env26233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26232_26233 : H12AffineEnvironment.transform 7 252 env26232 = env26233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env26232 == env26233) = true)

theorem identity26233 : scanCanonicalize (H12AffineFastState.compose env26233 (packedSelected [0,4,5,7,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 147) := by decide +kernel

theorem selectedBound26233 : packedSelected [0,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env26234 : List Nat := [2,4,8,16,32,64,128,252,512,652,147,80,241,560,185,203,184,74,653,185,609,152,249,138,121,169,42,185,81,242,629,248,253,65,649,513]

theorem envBound26234 : H12AffineFastState.Bounded env26234 := by
  intro p hp
  have h : env26234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26233_26234 : H12AffineEnvironment.transform 10 147 env26233 = env26234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 147 env26233 == env26234) = true)

theorem identity26234 : scanCanonicalize (H12AffineFastState.compose env26234 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(8+1) ^^^ 184) := by decide +kernel

theorem selectedBound26234 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env26235 : List Nat := [2,4,8,16,32,64,128,252,184,52,147,80,241,136,185,203,184,74,53,185,217,152,249,138,121,169,42,185,81,242,205,248,253,65,49,185]

theorem envBound26235 : H12AffineFastState.Bounded env26235 := by
  intro p hp
  have h : env26235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26234_26235 : H12AffineEnvironment.transform 8 184 env26234 = env26235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 184 env26234 == env26235) = true)

theorem identity26235 : scanCanonicalize (H12AffineFastState.compose env26235 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound26235 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env26236 : List Nat := [2,4,8,16,32,16,128,172,184,52,147,0,161,136,185,155,184,26,53,185,137,152,169,138,41,169,42,185,1,162,157,168,173,17,49,185]

theorem envBound26236 : H12AffineFastState.Bounded env26236 := by
  intro p hp
  have h : env26236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26235_26236 : H12AffineEnvironment.transform 5 16 env26235 = env26236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env26235 == env26236) = true)

theorem identity26236 : scanCanonicalize (H12AffineFastState.compose env26236 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound26236 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env26237 : List Nat := [2,4,8,16,32,16,56,20,0,52,43,0,25,48,1,35,0,26,53,1,49,32,17,50,41,17,42,1,1,26,37,16,21,17,49,1]

theorem envBound26237 : H12AffineFastState.Bounded env26237 := by
  intro p hp
  have h : env26237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26236_26237 : H12AffineEnvironment.transform 6 56 env26236 = env26237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env26236 == env26237) = true)

theorem identity26237 : scanCanonicalize (H12AffineFastState.compose env26237 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound26237 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26238 : List Nat := [2,4,8,13,32,13,37,9,0,41,43,0,4,45,1,35,0,7,40,1,44,32,12,47,41,12,42,1,1,7,37,13,8,12,44,1]

theorem envBound26238 : H12AffineFastState.Bounded env26238 := by
  intro p hp
  have h : env26238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26237_26238 : H12AffineEnvironment.transform 3 13 env26237 = env26238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env26237 == env26238) = true)

theorem identity26238 : scanCanonicalize (H12AffineFastState.compose env26238 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound26238 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env26239 : List Nat := [2,2,8,11,32,11,35,9,0,41,43,0,2,43,1,35,0,1,40,1,42,32,10,41,41,10,42,1,1,1,35,11,8,10,42,1]

theorem envBound26239 : H12AffineFastState.Bounded env26239 := by
  intro p hp
  have h : env26239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26238_26239 : H12AffineEnvironment.transform 1 2 env26238 = env26239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env26238 == env26239) = true)

def env26240 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,30041,29995,17413,9782,1025,30041,16464,21897,21525,375,8328,21573,29370,17412,4097,23920,1284,260,257,21841,5204,513]

theorem envBound26240 : H12AffineFastState.Bounded env26240 := by
  intro p hp
  have h : env26240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26221_26240 : H12AffineEnvironment.transform 14 30041 env26221 = env26240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 30041 env26221 == env26240) = true)

theorem identity26240 : scanCanonicalize (H12AffineFastState.compose env26240 (packedSelected [6] rootPS)) = affineNative (2^(13+1) ^^^ 1109) := by decide +kernel

theorem selectedBound26240 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env26241 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1109,12556,12670,80,9782,1025,12556,1029,4572,4160,375,8328,4112,14063,81,4097,6437,1284,260,257,4356,5204,513]

theorem envBound26241 : H12AffineFastState.Bounded env26241 := by
  intro p hp
  have h : env26241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26240_26241 : H12AffineEnvironment.transform 13 1109 env26240 = env26241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1109 env26240 == env26241) = true)

theorem identity26241 : scanCanonicalize (H12AffineFastState.compose env26241 (packedSelected [3,8,10,13,17] rootPS)) = affineNative (2^(11+1) ^^^ 1944) := by decide +kernel

theorem selectedBound26241 : packedSelected [3,8,10,13,17] rootPS < 2^1333 := by decide +kernel

def env26242 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1944,8192,1109,9876,9958,80,9782,1025,9876,1029,1604,2008,375,8328,1928,8567,81,1945,3773,1284,260,257,1692,972,513]

theorem envBound26242 : H12AffineFastState.Bounded env26242 := by
  intro p hp
  have h : env26242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26241_26242 : H12AffineEnvironment.transform 11 1944 env26241 = env26242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1944 env26241 == env26242) = true)

def env26243 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1944,240,1109,1636,1558,80,1734,1025,1636,1029,1604,2008,375,120,1928,391,81,1945,3773,1284,260,257,1692,972,513]

theorem envBound26243 : H12AffineFastState.Bounded env26243 := by
  intro p hp
  have h : env26243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26242_26243 : H12AffineEnvironment.transform 12 240 env26242 = env26243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 240 env26242 == env26243) = true)

theorem identity26243 : scanCanonicalize (H12AffineFastState.compose env26243 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound26243 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26244 : List Nat := [2,4,8,16,32,64,128,20,512,1024,2048,1676,240,1109,1636,1558,80,1734,1025,1636,1029,1604,1740,99,120,1692,147,81,1677,3773,1040,16,21,1692,728,513]

theorem envBound26244 : H12AffineFastState.Bounded env26244 := by
  intro p hp
  have h : env26244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26243_26244 : H12AffineEnvironment.transform 7 20 env26243 = env26244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env26243 == env26244) = true)

theorem identity26244 : scanCanonicalize (H12AffineFastState.compose env26244 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(6+1) ^^^ 105) := by decide +kernel

theorem selectedBound26244 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env26245 : List Nat := [2,4,8,16,32,64,105,20,512,1024,2048,1637,25,1109,1636,1558,80,1583,1025,1636,1029,1604,1573,99,120,1653,122,81,1636,3668,1040,16,21,1653,561,513]

theorem envBound26245 : H12AffineFastState.Bounded env26245 := by
  intro p hp
  have h : env26245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26244_26245 : H12AffineEnvironment.transform 6 105 env26244 = env26245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 105 env26244 == env26245) = true)

theorem identity26245 : scanCanonicalize (H12AffineFastState.compose env26245 (packedSelected [0,4,5,7,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 1566) := by decide +kernel

theorem selectedBound26245 : packedSelected [0,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env26246 : List Nat := [2,4,8,16,32,64,105,20,512,1024,1566,1637,25,1109,1636,1558,80,1583,1025,1636,1029,1604,1573,99,120,1653,122,81,1636,74,1040,16,21,1653,561,513]

theorem envBound26246 : H12AffineFastState.Bounded env26246 := by
  intro p hp
  have h : env26246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26245_26246 : H12AffineEnvironment.transform 10 1566 env26245 = env26246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1566 env26245 == env26246) = true)

theorem identity26246 : scanCanonicalize (H12AffineFastState.compose env26246 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound26246 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env26247 : List Nat := [2,4,8,16,32,64,105,20,512,101,635,512,25,48,513,627,80,586,100,513,96,545,576,99,120,528,122,81,513,74,117,16,21,528,561,513]

theorem envBound26247 : H12AffineFastState.Bounded env26247 := by
  intro p hp
  have h : env26247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26246_26247 : H12AffineEnvironment.transform 9 101 env26246 = env26247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env26246 == env26247) = true)

theorem identity26247 : scanCanonicalize (H12AffineFastState.compose env26247 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound26247 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env26248 : List Nat := [2,4,8,16,32,16,57,20,512,53,555,512,25,48,513,547,0,538,52,513,48,545,528,51,40,528,42,1,513,26,37,16,21,528,561,513]

theorem envBound26248 : H12AffineFastState.Bounded env26248 := by
  intro p hp
  have h : env26248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26247_26248 : H12AffineEnvironment.transform 5 16 env26247 = env26248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env26247 == env26248) = true)

def env26249 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1944,241,1109,1637,1559,80,1735,1025,1637,1029,1604,2008,375,121,1928,390,81,1945,3773,1284,260,257,1692,972,513]

theorem envBound26249 : H12AffineFastState.Bounded env26249 := by
  intro p hp
  have h : env26249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26242_26249 : H12AffineEnvironment.transform 12 241 env26242 = env26249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 241 env26242 == env26249) = true)

theorem identity26249 : scanCanonicalize (H12AffineFastState.compose env26249 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 104) := by decide +kernel

theorem selectedBound26249 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26250 : List Nat := [2,4,8,16,32,64,104,256,512,1024,2048,1904,25,1109,1637,1559,80,1583,1025,1637,1029,1604,1840,375,121,1888,366,81,1905,3669,1284,260,257,1652,804,513]

theorem envBound26250 : H12AffineFastState.Bounded env26250 := by
  intro p hp
  have h : env26250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26249_26250 : H12AffineEnvironment.transform 6 104 env26249 = env26250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 104 env26249 == env26250) = true)

theorem identity26250 : scanCanonicalize (H12AffineFastState.compose env26250 (packedSelected [4,5,8,9,11] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound26250 : packedSelected [4,5,8,9,11] rootPS < 2^1333 := by decide +kernel

def env26251 : List Nat := [2,4,8,16,32,64,104,21,512,1024,2048,1637,25,1109,1637,1559,80,1583,1025,1637,1029,1604,1573,98,121,1653,123,81,1636,3669,1041,17,20,1652,561,513]

theorem envBound26251 : H12AffineFastState.Bounded env26251 := by
  intro p hp
  have h : env26251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26250_26251 : H12AffineEnvironment.transform 7 21 env26250 = env26251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env26250 == env26251) = true)

theorem identity26251 : scanCanonicalize (H12AffineFastState.compose env26251 (packedSelected [0,4,5,7,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 1567) := by decide +kernel

theorem selectedBound26251 : packedSelected [0,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env26252 : List Nat := [2,4,8,16,32,64,104,21,512,1024,1567,1637,25,1109,1637,1559,80,1583,1025,1637,1029,1604,1573,98,121,1653,123,81,1636,74,1041,17,20,1652,561,513]

theorem envBound26252 : H12AffineFastState.Bounded env26252 := by
  intro p hp
  have h : env26252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26251_26252 : H12AffineEnvironment.transform 10 1567 env26251 = env26252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1567 env26251 == env26252) = true)

theorem identity26252 : scanCanonicalize (H12AffineFastState.compose env26252 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound26252 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env26253 : List Nat := [2,4,8,16,32,64,104,21,512,101,634,512,25,48,512,626,80,586,100,512,96,545,576,98,121,528,123,81,513,74,116,17,20,529,561,513]

theorem envBound26253 : H12AffineFastState.Bounded env26253 := by
  intro p hp
  have h : env26253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26252_26253 : H12AffineEnvironment.transform 9 101 env26252 = env26253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env26252 == env26253) = true)

theorem identity26253 : scanCanonicalize (H12AffineFastState.compose env26253 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 81) := by decide +kernel

theorem selectedBound26253 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env26254 : List Nat := [2,4,8,16,32,64,104,21,81,101,43,81,25,48,81,35,80,27,100,81,96,112,17,98,121,65,123,81,80,74,116,17,20,64,96,80]

theorem envBound26254 : H12AffineFastState.Bounded env26254 := by
  intro p hp
  have h : env26254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26253_26254 : H12AffineEnvironment.transform 8 81 env26253 = env26254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env26253 == env26254) = true)

theorem identity26254 : scanCanonicalize (H12AffineFastState.compose env26254 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound26254 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env26255 : List Nat := [2,4,8,16,32,17,57,21,0,52,43,0,25,48,0,35,1,27,53,0,49,33,17,51,40,16,42,0,1,27,37,17,20,17,49,1]

theorem envBound26255 : H12AffineFastState.Bounded env26255 := by
  intro p hp
  have h : env26255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26254_26255 : H12AffineEnvironment.transform 5 17 env26254 = env26255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env26254 == env26255) = true)

theorem identity26255 : scanCanonicalize (H12AffineFastState.compose env26255 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound26255 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26256 : List Nat := [2,4,8,16,12,17,21,21,0,24,7,0,25,28,0,15,1,27,25,0,29,13,17,31,4,16,6,0,1,27,9,17,20,17,29,1]

theorem envBound26256 : H12AffineFastState.Bounded env26256 := by
  intro p hp
  have h : env26256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26255_26256 : H12AffineEnvironment.transform 4 12 env26255 = env26256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env26255 == env26256) = true)

theorem identity26256 : scanCanonicalize (H12AffineFastState.compose env26256 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound26256 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env26257 : List Nat := [2,4,8,10,12,11,15,15,0,2,7,0,3,6,0,15,1,1,3,0,7,13,11,5,4,10,6,0,1,1,9,11,14,11,7,1]

theorem envBound26257 : H12AffineFastState.Bounded env26257 := by
  intro p hp
  have h : env26257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26256_26257 : H12AffineEnvironment.transform 3 10 env26256 = env26257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env26256 == env26257) = true)

def env26258 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,2248768,16777216,8328,2248720,21331969,4399266,4272290,4294795,16876545,4329609,257,16912418,151632,513]

theorem envBound26258 : H12AffineFastState.Bounded env26258 := by
  intro p hp
  have h : env26258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26214_26258 : H12AffineEnvironment.transform 26 21331969 env26214 = env26258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 21331969 env26214 == env26258) = true)

theorem identity26258 : scanCanonicalize (H12AffineFastState.compose env26258 (packedSelected [14] rootPS)) = affineNative (2^(16+1) ^^^ 103462) := by decide +kernel

theorem selectedBound26258 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env26259 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,103462,262144,1025,32768,2097152,4194304,2212966,16777216,8328,2212918,21331969,4240516,4272290,4294795,16876545,4293807,257,16876548,115830,513]

theorem envBound26259 : H12AffineFastState.Bounded env26259 := by
  intro p hp
  have h : env26259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26258_26259 : H12AffineEnvironment.transform 16 103462 env26258 = env26259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103462 env26258 == env26259) = true)

theorem identity26259 : scanCanonicalize (H12AffineFastState.compose env26259 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(20+1) ^^^ 17492) := by decide +kernel

theorem selectedBound26259 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env26260 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,103462,262144,1025,32768,17492,4194304,98354,16777216,8328,98402,21331969,4240516,4272290,4294795,16876545,4293807,257,16876548,115830,513]

theorem envBound26260 : H12AffineFastState.Bounded env26260 := by
  intro p hp
  have h : env26260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26259_26260 : H12AffineEnvironment.transform 20 17492 env26259 = env26260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17492 env26259 == env26260) = true)

theorem identity26260 : scanCanonicalize (H12AffineFastState.compose env26260 (packedSelected [13,21] rootPS)) = affineNative (2^(23+1) ^^^ 4195503) := by decide +kernel

end H12CloudChart2