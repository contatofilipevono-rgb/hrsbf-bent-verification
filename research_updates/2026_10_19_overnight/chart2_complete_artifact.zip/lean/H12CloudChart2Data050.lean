import H12CloudChart2Data049

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound12217 : H12AffineFastState.Bounded env12217 := by
  intro p hp
  have h : env12217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12216_12217 : H12AffineEnvironment.transform 18 306216 env12216 = env12217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 306216 env12216 == env12217) = true)

theorem identity12217 : scanCanonicalize (H12AffineFastState.compose env12217 (packedSelected [17,18,21,23] rootPS)) = affineNative (2^(15+1) ^^^ 33167) := by decide +kernel

theorem selectedBound12217 : packedSelected [17,18,21,23] rootPS < 2^1333 := by decide +kernel

def env12218 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,32768,33167,1344,262144,306216,32769,1344,41260,305256,305314,8328,16,2049,306536,306536,1073741824,1284,4294967296,305448,4295231780,1344,512]

theorem envBound12218 : H12AffineFastState.Bounded env12218 := by
  intro p hp
  have h : env12218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12217_12218 : H12AffineEnvironment.transform 15 33167 env12217 = env12218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33167 env12217 == env12218) = true)

def env12219 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,65536,1344,262144,524288,32769,4096,4194304,525377,623877,8328,17,4982021,524609,529409,1073741824,1284,4294967296,525568,4299785647,1344,512]

theorem envBound12219 : H12AffineFastState.Bounded env12219 := by
  intro p hp
  have h : env12219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12213_12219 : H12AffineEnvironment.transform 13 1345 env12213 = env12219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env12213 == env12219) = true)

theorem identity12219 : scanCanonicalize (H12AffineFastState.compose env12219 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound12219 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env12220 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,1296,32768,65536,1297,262144,524288,32769,4096,4194304,525328,623877,8328,17,4982021,524560,529409,1073741824,1284,4294967296,525568,4299785647,1297,512]

theorem envBound12220 : H12AffineFastState.Bounded env12220 := by
  intro p hp
  have h : env12220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12219_12220 : H12AffineEnvironment.transform 5 17 env12219 = env12220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env12219 == env12220) = true)

theorem identity12220 : scanCanonicalize (H12AffineFastState.compose env12220 (packedSelected [13,21] rootPS)) = affineNative (2^(31+1) ^^^ 4199833) := by decide +kernel

theorem selectedBound12220 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env12221 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,1296,32768,65536,1297,262144,524288,32769,4096,4194304,525328,623877,8328,17,4982021,524560,529409,1073741824,1284,4199833,525568,626742,1297,512]

theorem envBound12221 : H12AffineFastState.Bounded env12221 := by
  intro p hp
  have h : env12221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12220_12221 : H12AffineEnvironment.transform 31 4199833 env12220 = env12221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 4199833 env12220 == env12221) = true)

theorem identity12221 : scanCanonicalize (H12AffineFastState.compose env12221 (packedSelected [1,3,15,24,28,38] rootPS)) = affineNative (2^(29+1) ^^^ 43049) := by decide +kernel

theorem selectedBound12221 : packedSelected [1,3,15,24,28,38] rootPS < 2^1333 := by decide +kernel

def env12222 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,1296,32768,65536,1297,262144,524288,32769,4096,4194304,525328,623877,8328,17,4982021,524560,529409,43049,1284,4199833,525568,626742,1297,512]

theorem envBound12222 : H12AffineFastState.Bounded env12222 := by
  intro p hp
  have h : env12222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12221_12222 : H12AffineEnvironment.transform 29 43049 env12221 = env12222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 43049 env12221 == env12222) = true)

theorem identity12222 : scanCanonicalize (H12AffineFastState.compose env12222 (packedSelected [3,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound12222 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env12223 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1296,32768,65536,1297,262144,524288,32769,1297,4194304,525328,623877,8328,17,4982021,524560,524560,43049,1284,4194440,525568,623911,1297,512]

theorem envBound12223 : H12AffineFastState.Bounded env12223 := by
  intro p hp
  have h : env12223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12222_12223 : H12AffineEnvironment.transform 11 1297 env12222 = env12223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env12222 == env12223) = true)

def env12224 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32769,4096,4194304,8388608,8504324,8328,8914000,134217728,8389889,545089,1073741824,1284,4294967296,8406017,4307666094,139198533,512]

theorem envBound12224 : H12AffineFastState.Bounded env12224 := by
  intro p hp
  have h : env12224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12210_12224 : H12AffineEnvironment.transform 16 1345 env12210 = env12224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env12210 == env12224) = true)

theorem identity12224 : scanCanonicalize (H12AffineFastState.compose env12224 (packedSelected [7,20,27] rootPS)) = affineNative (2^(22+1) ^^^ 17665) := by decide +kernel

theorem selectedBound12224 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env12225 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32769,4096,4194304,17665,98565,8328,541009,134217728,16384,545089,1073741824,1284,4294967296,256,4299260335,139198533,512]

theorem envBound12225 : H12AffineFastState.Bounded env12225 := by
  intro p hp
  have h : env12225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12224_12225 : H12AffineEnvironment.transform 22 17665 env12224 = env12225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17665 env12224 == env12225) = true)

def env12226 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,16384,32768,65536,1345,262144,524288,32769,1344,4194304,17665,98565,8328,541009,134217728,16384,541697,1073741824,1284,4294967296,256,4299260335,139198533,512]

theorem envBound12226 : H12AffineFastState.Bounded env12226 := by
  intro p hp
  have h : env12226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12225_12226 : H12AffineEnvironment.transform 11 1344 env12225 = env12226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env12225 == env12226) = true)

def env12227 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,32768,65536,1345,262144,524288,32769,1344,4194304,65,98565,8328,525329,134217728,1344,524609,1073741824,1284,4294967296,256,4299260335,139198533,512]

theorem envBound12227 : H12AffineFastState.Bounded env12227 := by
  intro p hp
  have h : env12227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12226_12227 : H12AffineEnvironment.transform 13 1344 env12226 = env12227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env12226 == env12227) = true)

theorem identity12227 : scanCanonicalize (H12AffineFastState.compose env12227 (packedSelected [9,22] rootPS)) = affineNative (2^(26+1) ^^^ 4982100) := by decide +kernel

theorem selectedBound12227 : packedSelected [9,22] rootPS < 2^1333 := by decide +kernel

def env12228 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,32768,65536,1345,262144,524288,32769,1344,4194304,65,98565,8328,525329,4982100,1344,524609,1073741824,1284,4294967296,256,4299260335,1297,512]

theorem envBound12228 : H12AffineFastState.Bounded env12228 := by
  intro p hp
  have h : env12228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12227_12228 : H12AffineEnvironment.transform 26 4982100 env12227 = env12228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 4982100 env12227 == env12228) = true)

def env12229 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,32768,65536,1345,262144,524288,32769,1344,4194304,65,98565,8328,525329,4982100,1344,524609,5016608,1284,4294967296,256,4299260335,1297,512]

theorem envBound12229 : H12AffineFastState.Bounded env12229 := by
  intro p hp
  have h : env12229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12228_12229 : H12AffineEnvironment.transform 29 5016608 env12228 = env12229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 5016608 env12228 == env12229) = true)

theorem identity12229 : scanCanonicalize (H12AffineFastState.compose env12229 (packedSelected [1,3,5,8,12,13,15,17] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound12229 : packedSelected [1,3,5,8,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env12230 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1296,32768,65536,1297,262144,524288,32769,1296,4194304,17,98565,8328,525329,4982020,1296,524561,5016608,1284,4294967296,256,4299260335,1297,512]

theorem envBound12230 : H12AffineFastState.Bounded env12230 := by
  intro p hp
  have h : env12230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12229_12230 : H12AffineEnvironment.transform 5 16 env12229 = env12230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env12229 == env12230) = true)

theorem identity12230 : scanCanonicalize (H12AffineFastState.compose env12230 (packedSelected [5,8,13,15,19] rootPS)) = affineNative (2^(17+1) ^^^ 65706) := by decide +kernel

theorem selectedBound12230 : packedSelected [5,8,13,15,19] rootPS < 2^1333 := by decide +kernel

def env12231 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1296,32768,65536,1297,65706,524288,32769,1296,4194304,17,98565,8328,525329,4785582,1296,524561,4820106,1284,4294967296,256,4299260335,1297,512]

theorem envBound12231 : H12AffineFastState.Bounded env12231 := by
  intro p hp
  have h : env12231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12230_12231 : H12AffineEnvironment.transform 17 65706 env12230 = env12231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65706 env12230 == env12231) = true)

theorem identity12231 : scanCanonicalize (H12AffineFastState.compose env12231 (packedSelected [5,21] rootPS)) = affineNative (2^(21+1) ^^^ 909) := by decide +kernel

theorem selectedBound12231 : packedSelected [5,21] rootPS < 2^1333 := by decide +kernel

def env12232 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1296,32768,65536,1297,65706,524288,32769,1296,909,17,98565,8328,525329,591395,1296,524561,626439,1284,4294967296,256,4295066146,1297,512]

theorem envBound12232 : H12AffineFastState.Bounded env12232 := by
  intro p hp
  have h : env12232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12231_12232 : H12AffineEnvironment.transform 21 909 env12231 = env12232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 909 env12231 == env12232) = true)

def env12233 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1296,32768,65536,1297,65706,1536,32769,1296,909,17,98565,8328,529,65571,1296,1809,100615,1284,4294967296,256,4295066146,1297,512]

theorem envBound12233 : H12AffineFastState.Bounded env12233 := by
  intro p hp
  have h : env12233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12232_12233 : H12AffineEnvironment.transform 18 1536 env12232 = env12233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1536 env12232 == env12233) = true)

theorem identity12233 : scanCanonicalize (H12AffineFastState.compose env12233 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 74543) := by decide +kernel

theorem selectedBound12233 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env12234 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1296,32768,65536,1297,65706,1536,32769,1296,909,17,98565,8328,529,65571,1296,1809,100615,1284,74543,256,41229,1297,512]

theorem envBound12234 : H12AffineFastState.Bounded env12234 := by
  intro p hp
  have h : env12234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12233_12234 : H12AffineEnvironment.transform 31 74543 env12233 = env12234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 74543 env12233 == env12234) = true)

def env12235 : List Nat := [2,4,8,16,32,16,128,256,0,1024,2048,1296,8192,1296,32768,65536,1297,65706,1024,32769,1296,397,17,98565,8328,17,65571,1296,1297,100615,1284,74031,256,41229,1297,0]

theorem envBound12235 : H12AffineFastState.Bounded env12235 := by
  intro p hp
  have h : env12235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12234_12235 : H12AffineEnvironment.transform 8 0 env12234 = env12235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env12234 == env12235) = true)

theorem identity12235 : scanCanonicalize (H12AffineFastState.compose env12235 (packedSelected [1,3,5] rootPS)) = affineNative (2^(15+1) ^^^ 2446) := by decide +kernel

theorem selectedBound12235 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env12236 : List Nat := [2,4,8,16,32,16,128,256,0,1024,2048,1296,8192,1296,32768,2446,1297,2340,1024,32769,1296,397,17,34955,8328,17,2477,1296,1297,32905,1284,10401,256,41229,1297,0]

theorem envBound12236 : H12AffineFastState.Bounded env12236 := by
  intro p hp
  have h : env12236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12235_12236 : H12AffineEnvironment.transform 15 2446 env12235 = env12236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2446 env12235 == env12236) = true)

theorem identity12236 : scanCanonicalize (H12AffineFastState.compose env12236 (packedSelected [1,3,8] rootPS)) = affineNative (2^(14+1) ^^^ 2048) := by decide +kernel

theorem selectedBound12236 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env12237 : List Nat := [2,4,8,16,32,16,128,256,0,1024,2048,1296,8192,1296,2048,2446,1297,2340,1024,2049,1296,397,17,139,8328,17,2477,1296,1297,2185,1284,10401,256,10509,1297,0]

theorem envBound12237 : H12AffineFastState.Bounded env12237 := by
  intro p hp
  have h : env12237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12236_12237 : H12AffineEnvironment.transform 14 2048 env12236 = env12237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2048 env12236 == env12237) = true)

theorem identity12237 : scanCanonicalize (H12AffineFastState.compose env12237 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound12237 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env12238 : List Nat := [2,4,8,16,32,16,9,256,0,1024,2048,1296,8192,1296,2048,2311,1297,2340,1024,2049,1296,260,17,2,8193,17,2340,1296,1297,2048,1284,10280,256,10509,1297,0]

theorem envBound12238 : H12AffineFastState.Bounded env12238 := by
  intro p hp
  have h : env12238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12237_12238 : H12AffineEnvironment.transform 6 9 env12237 = env12238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env12237 == env12238) = true)

theorem identity12238 : scanCanonicalize (H12AffineFastState.compose env12238 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound12238 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12239 : List Nat := [2,4,8,16,32,16,9,37,0,1024,2048,1077,8192,1077,2048,2082,1076,2049,1024,2049,1077,33,17,2,8193,17,2049,1077,1076,2048,1057,10280,37,10280,1076,0]

theorem envBound12239 : H12AffineFastState.Bounded env12239 := by
  intro p hp
  have h : env12239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12238_12239 : H12AffineEnvironment.transform 7 37 env12238 = env12239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env12238 == env12239) = true)

theorem identity12239 : scanCanonicalize (H12AffineFastState.compose env12239 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 2088) := by decide +kernel

theorem selectedBound12239 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12240 : List Nat := [2,4,8,16,32,16,9,37,0,1024,2048,1077,2088,1077,2048,2082,1076,2049,1024,2049,1077,33,17,2,2089,17,2049,1077,1076,2048,1057,0,37,0,1076,0]

theorem envBound12240 : H12AffineFastState.Bounded env12240 := by
  intro p hp
  have h : env12240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12239_12240 : H12AffineEnvironment.transform 12 2088 env12239 = env12240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2088 env12239 == env12240) = true)

def env12241 : List Nat := [2,4,8,16,32,16,128,256,1,1024,2048,1296,8192,1296,32768,65536,1297,65706,1025,32769,1296,396,17,98565,8328,16,65571,1296,1296,100615,1284,74030,256,41229,1297,1]

theorem envBound12241 : H12AffineFastState.Bounded env12241 := by
  intro p hp
  have h : env12241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12234_12241 : H12AffineEnvironment.transform 8 1 env12234 = env12241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env12234 == env12241) = true)

theorem identity12241 : scanCanonicalize (H12AffineFastState.compose env12241 (packedSelected [1,3,5] rootPS)) = affineNative (2^(15+1) ^^^ 2176) := by decide +kernel

theorem selectedBound12241 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env12242 : List Nat := [2,4,8,16,32,16,128,256,1,1024,2048,1296,8192,1296,32768,2176,1297,2090,1025,32769,1296,396,17,35205,8328,16,2211,1296,1296,33159,1284,10670,256,41229,1297,1]

theorem envBound12242 : H12AffineFastState.Bounded env12242 := by
  intro p hp
  have h : env12242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12241_12242 : H12AffineEnvironment.transform 15 2176 env12241 = env12242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2176 env12241 == env12242) = true)

theorem identity12242 : scanCanonicalize (H12AffineFastState.compose env12242 (packedSelected [1,3,8] rootPS)) = affineNative (2^(7+1) ^^^ 135) := by decide +kernel

theorem selectedBound12242 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env12243 : List Nat := [2,4,8,16,32,16,128,135,1,1024,2048,1175,8192,1175,32768,2176,1174,2090,1025,32769,1175,11,17,34818,8328,16,2211,1175,1175,32768,1155,10281,135,41098,1174,1]

theorem envBound12243 : H12AffineFastState.Bounded env12243 := by
  intro p hp
  have h : env12243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12242_12243 : H12AffineEnvironment.transform 7 135 env12242 = env12243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 135 env12242 == env12243) = true)

theorem identity12243 : scanCanonicalize (H12AffineFastState.compose env12243 (packedSelected [1,10] rootPS)) = affineNative (2^(14+1) ^^^ 2090) := by decide +kernel

theorem selectedBound12243 : packedSelected [1,10] rootPS < 2^1333 := by decide +kernel

def env12244 : List Nat := [2,4,8,16,32,16,128,135,1,1024,2048,1175,8192,1175,2090,2176,1174,2090,1025,2091,1175,11,17,40,8328,16,2211,1175,1175,2090,1155,10281,135,10400,1174,1]

theorem envBound12244 : H12AffineFastState.Bounded env12244 := by
  intro p hp
  have h : env12244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12243_12244 : H12AffineEnvironment.transform 14 2090 env12243 = env12244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2090 env12243 == env12244) = true)

theorem identity12244 : scanCanonicalize (H12AffineFastState.compose env12244 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 2088) := by decide +kernel

theorem selectedBound12244 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env12245 : List Nat := [2,4,8,16,32,16,128,135,1,1024,2048,1175,2088,1175,2090,2176,1174,2090,1025,2091,1175,11,17,40,2208,16,2211,1175,1175,2090,1155,1,135,136,1174,1]

theorem envBound12245 : H12AffineFastState.Bounded env12245 := by
  intro p hp
  have h : env12245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12244_12245 : H12AffineEnvironment.transform 12 2088 env12244 = env12245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2088 env12244 == env12245) = true)

theorem identity12245 : scanCanonicalize (H12AffineFastState.compose env12245 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound12245 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12246 : List Nat := [2,4,8,16,32,16,35,36,1,1024,2048,1076,2088,1076,2090,2083,1077,2090,1025,2091,1076,11,17,40,2051,16,2048,1076,1076,2090,1056,1,36,43,1077,1]

theorem envBound12246 : H12AffineFastState.Bounded env12246 := by
  intro p hp
  have h : env12246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12245_12246 : H12AffineEnvironment.transform 6 35 env12245 = env12246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env12245 == env12246) = true)

theorem identity12246 : scanCanonicalize (H12AffineFastState.compose env12246 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound12246 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12247 : List Nat := [2,4,8,16,16,16,19,20,1,1024,2048,1028,2072,1028,2074,2067,1029,2074,1025,2075,1028,11,17,24,2051,16,2048,1028,1028,2074,1040,1,20,27,1029,1]

theorem envBound12247 : H12AffineFastState.Bounded env12247 := by
  intro p hp
  have h : env12247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12246_12247 : H12AffineEnvironment.transform 4 16 env12246 = env12247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env12246 == env12247) = true)

theorem identity12247 : scanCanonicalize (H12AffineFastState.compose env12247 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound12247 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env12248 : List Nat := [2,4,8,10,10,10,9,14,1,1024,2048,1028,2050,1028,2048,2057,1029,2048,1025,2049,1028,11,11,2,2051,10,2048,1028,1028,2048,1034,1,14,1,1029,1]

theorem envBound12248 : H12AffineFastState.Bounded env12248 := by
  intro p hp
  have h : env12248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12247_12248 : H12AffineEnvironment.transform 3 10 env12247 = env12248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env12247 == env12248) = true)

def env12249 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1296,32768,65536,1297,65706,1537,32769,1296,909,17,98565,8328,528,65570,1296,1808,100614,1284,4294967296,256,4295066146,1297,512]

theorem envBound12249 : H12AffineFastState.Bounded env12249 := by
  intro p hp
  have h : env12249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12232_12249 : H12AffineEnvironment.transform 18 1537 env12232 = env12249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1537 env12232 == env12249) = true)

theorem identity12249 : scanCanonicalize (H12AffineFastState.compose env12249 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 98851) := by decide +kernel

theorem selectedBound12249 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env12250 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1296,32768,65536,1297,65706,1537,32769,1296,909,17,98565,8328,528,65570,1296,1808,100614,1284,98851,256,1,1297,512]

theorem envBound12250 : H12AffineFastState.Bounded env12250 := by
  intro p hp
  have h : env12250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12249_12250 : H12AffineEnvironment.transform 31 98851 env12249 = env12250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 98851 env12249 == env12250) = true)

def env12251 : List Nat := [2,4,8,16,32,16,128,256,0,1024,2048,1296,8192,1296,32768,65536,1297,65706,1025,32769,1296,397,17,98565,8328,16,65570,1296,1296,100614,1284,98339,256,1,1297,0]

theorem envBound12251 : H12AffineFastState.Bounded env12251 := by
  intro p hp
  have h : env12251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12250_12251 : H12AffineEnvironment.transform 8 0 env12250 = env12251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env12250 == env12251) = true)

theorem identity12251 : scanCanonicalize (H12AffineFastState.compose env12251 (packedSelected [1,3,5] rootPS)) = affineNative (2^(15+1) ^^^ 2177) := by decide +kernel

theorem selectedBound12251 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env12252 : List Nat := [2,4,8,16,32,16,128,256,0,1024,2048,1296,8192,1296,32768,2177,1297,2091,1025,32769,1296,397,17,35204,8328,16,2211,1296,1296,33159,1284,34978,256,1,1297,0]

theorem envBound12252 : H12AffineFastState.Bounded env12252 := by
  intro p hp
  have h : env12252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12251_12252 : H12AffineEnvironment.transform 15 2177 env12251 = env12252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2177 env12251 == env12252) = true)

theorem identity12252 : scanCanonicalize (H12AffineFastState.compose env12252 (packedSelected [1,3,8] rootPS)) = affineNative (2^(7+1) ^^^ 135) := by decide +kernel

theorem selectedBound12252 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env12253 : List Nat := [2,4,8,16,32,16,128,135,0,1024,2048,1175,8192,1175,32768,2177,1174,2091,1025,32769,1175,10,17,34819,8328,16,2211,1175,1175,32768,1155,34978,135,1,1174,0]

theorem envBound12253 : H12AffineFastState.Bounded env12253 := by
  intro p hp
  have h : env12253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12252_12253 : H12AffineEnvironment.transform 7 135 env12252 = env12253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 135 env12252 == env12253) = true)

theorem identity12253 : scanCanonicalize (H12AffineFastState.compose env12253 (packedSelected [1,10] rootPS)) = affineNative (2^(14+1) ^^^ 2091) := by decide +kernel

theorem selectedBound12253 : packedSelected [1,10] rootPS < 2^1333 := by decide +kernel

def env12254 : List Nat := [2,4,8,16,32,16,128,135,0,1024,2048,1175,8192,1175,2091,2177,1174,2091,1025,2090,1175,10,17,40,8328,16,2211,1175,1175,2091,1155,137,135,1,1174,0]

theorem envBound12254 : H12AffineFastState.Bounded env12254 := by
  intro p hp
  have h : env12254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12253_12254 : H12AffineEnvironment.transform 14 2091 env12253 = env12254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2091 env12253 == env12254) = true)

theorem identity12254 : scanCanonicalize (H12AffineFastState.compose env12254 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 2088) := by decide +kernel

theorem selectedBound12254 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env12255 : List Nat := [2,4,8,16,32,16,128,135,0,1024,2048,1175,2088,1175,2091,2177,1174,2091,1025,2090,1175,10,17,40,2208,16,2211,1175,1175,2091,1155,137,135,1,1174,0]

theorem envBound12255 : H12AffineFastState.Bounded env12255 := by
  intro p hp
  have h : env12255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12254_12255 : H12AffineEnvironment.transform 12 2088 env12254 = env12255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2088 env12254 == env12255) = true)

theorem identity12255 : scanCanonicalize (H12AffineFastState.compose env12255 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound12255 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12256 : List Nat := [2,4,8,16,32,16,35,36,0,1024,2048,1076,2088,1076,2091,2082,1077,2091,1025,2090,1076,10,17,40,2051,16,2048,1076,1076,2091,1056,42,36,1,1077,0]

theorem envBound12256 : H12AffineFastState.Bounded env12256 := by
  intro p hp
  have h : env12256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12255_12256 : H12AffineEnvironment.transform 6 35 env12255 = env12256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env12255 == env12256) = true)

theorem identity12256 : scanCanonicalize (H12AffineFastState.compose env12256 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound12256 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12257 : List Nat := [2,4,8,10,32,10,35,36,0,1024,2048,1070,2088,1070,2091,2082,1071,2091,1025,2090,1070,10,11,40,2051,10,2048,1070,1070,2091,1056,42,36,1,1071,0]

theorem envBound12257 : H12AffineFastState.Bounded env12257 := by
  intro p hp
  have h : env12257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12256_12257 : H12AffineEnvironment.transform 3 10 env12256 = env12257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env12256 == env12257) = true)

theorem identity12257 : scanCanonicalize (H12AffineFastState.compose env12257 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound12257 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env12258 : List Nat := [2,4,8,10,11,10,8,15,0,1024,2048,1029,2051,1029,2048,2057,1028,2048,1025,2049,1029,10,11,3,2051,10,2048,1029,1029,2048,1035,1,15,1,1028,0]

theorem envBound12258 : H12AffineFastState.Bounded env12258 := by
  intro p hp
  have h : env12258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12257_12258 : H12AffineEnvironment.transform 4 11 env12257 = env12258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env12257 == env12258) = true)

def env12259 : List Nat := [2,4,8,16,32,16,128,256,1,1024,2048,1296,8192,1296,32768,65536,1297,65706,1024,32769,1296,396,17,98565,8328,17,65570,1296,1297,100614,1284,98338,256,1,1297,1]

theorem envBound12259 : H12AffineFastState.Bounded env12259 := by
  intro p hp
  have h : env12259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12250_12259 : H12AffineEnvironment.transform 8 1 env12250 = env12259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env12250 == env12259) = true)

theorem identity12259 : scanCanonicalize (H12AffineFastState.compose env12259 (packedSelected [1,3,5] rootPS)) = affineNative (2^(15+1) ^^^ 2447) := by decide +kernel

theorem selectedBound12259 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env12260 : List Nat := [2,4,8,16,32,16,128,256,1,1024,2048,1296,8192,1296,32768,2447,1297,2341,1024,32769,1296,396,17,34954,8328,17,2477,1296,1297,32905,1284,35245,256,1,1297,1]

theorem envBound12260 : H12AffineFastState.Bounded env12260 := by
  intro p hp
  have h : env12260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12259_12260 : H12AffineEnvironment.transform 15 2447 env12259 = env12260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2447 env12259 == env12260) = true)

theorem identity12260 : scanCanonicalize (H12AffineFastState.compose env12260 (packedSelected [1,3,8] rootPS)) = affineNative (2^(14+1) ^^^ 2049) := by decide +kernel

theorem selectedBound12260 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env12261 : List Nat := [2,4,8,16,32,16,128,256,1,1024,2048,1296,8192,1296,2049,2447,1297,2341,1024,2048,1296,396,17,139,8328,17,2477,1296,1297,2184,1284,428,256,1,1297,1]

theorem envBound12261 : H12AffineFastState.Bounded env12261 := by
  intro p hp
  have h : env12261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12260_12261 : H12AffineEnvironment.transform 14 2049 env12260 = env12261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2049 env12260 == env12261) = true)

theorem identity12261 : scanCanonicalize (H12AffineFastState.compose env12261 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound12261 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env12262 : List Nat := [2,4,8,16,32,16,8,256,1,1024,2048,1296,8192,1296,2049,2311,1297,2341,1024,2048,1296,260,17,3,8192,17,2341,1296,1297,2048,1284,292,256,1,1297,1]

theorem envBound12262 : H12AffineFastState.Bounded env12262 := by
  intro p hp
  have h : env12262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12261_12262 : H12AffineEnvironment.transform 6 8 env12261 = env12262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env12261 == env12262) = true)

theorem identity12262 : scanCanonicalize (H12AffineFastState.compose env12262 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound12262 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12263 : List Nat := [2,4,8,16,32,16,8,37,1,1024,2048,1077,8192,1077,2049,2082,1076,2048,1024,2048,1077,33,17,3,8192,17,2048,1077,1076,2048,1057,1,37,1,1076,1]

theorem envBound12263 : H12AffineFastState.Bounded env12263 := by
  intro p hp
  have h : env12263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12262_12263 : H12AffineEnvironment.transform 7 37 env12262 = env12263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env12262 == env12263) = true)

theorem identity12263 : scanCanonicalize (H12AffineFastState.compose env12263 (packedSelected [7] rootPS)) = affineNative (2^(12+1) ^^^ 2088) := by decide +kernel

theorem selectedBound12263 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env12264 : List Nat := [2,4,8,16,32,16,8,37,1,1024,2048,1077,2088,1077,2049,2082,1076,2048,1024,2048,1077,33,17,3,2088,17,2048,1077,1076,2048,1057,1,37,1,1076,1]

theorem envBound12264 : H12AffineFastState.Bounded env12264 := by
  intro p hp
  have h : env12264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12263_12264 : H12AffineEnvironment.transform 12 2088 env12263 = env12264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2088 env12263 == env12264) = true)

def leafEnv12264 : List Nat := [2,4,8,16,32,16,8,37,1,1024,2048,1077,2088,1077,2049,2082,1076,2048,1024,2048,1077,33,17,3,1057,2088,1,17,2048,1077,1076,2048,1057,1,37,1,4,2083,1076,1,0,1076,1]

def active12264 : List Nat := [0,1,2,3,4,9,10]

def tree12264 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood12264 : H12WitnessSearch.Good tree12264 := H12GlobalWitnessIndex.good

theorem leafIdentity12264 : H12AffineFastState.composeSystem env12264 rootObs = leafEnv12264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env12264 rootObs == leafEnv12264) = true)

theorem terminalChecked12264 : H12PackedTerminal.terminalCheckFast leafEnv12264 active12264 tree12264 = true := by decide +kernel

def env12265 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,32768,65536,1345,262144,524288,32769,1344,4194304,65,98565,8328,525329,4982100,1344,524609,5016609,1284,4294967296,256,4299260335,1297,512]

theorem envBound12265 : H12AffineFastState.Bounded env12265 := by
  intro p hp
  have h : env12265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12228_12265 : H12AffineEnvironment.transform 29 5016609 env12228 = env12265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 5016609 env12228 == env12265) = true)

def env12266 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1296,32768,65536,1297,262144,524288,32769,1296,4194304,17,98565,8328,525329,4982020,1296,524561,5016609,1284,4294967296,256,4299260335,1297,512]

theorem envBound12266 : H12AffineFastState.Bounded env12266 := by
  intro p hp
  have h : env12266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12265_12266 : H12AffineEnvironment.transform 5 16 env12265 = env12266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env12265 == env12266) = true)

theorem identity12266 : scanCanonicalize (H12AffineFastState.compose env12266 (packedSelected [5,8,13,15,19] rootPS)) = affineNative (2^(17+1) ^^^ 65707) := by decide +kernel

theorem selectedBound12266 : packedSelected [5,8,13,15,19] rootPS < 2^1333 := by decide +kernel

def env12267 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1296,32768,65536,1297,65707,524288,32769,1296,4194304,17,98565,8328,525329,4785583,1296,524561,4820106,1284,4294967296,256,4299260335,1297,512]

theorem envBound12267 : H12AffineFastState.Bounded env12267 := by
  intro p hp
  have h : env12267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12266_12267 : H12AffineEnvironment.transform 17 65707 env12266 = env12267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65707 env12266 == env12267) = true)

theorem identity12267 : scanCanonicalize (H12AffineFastState.compose env12267 (packedSelected [5,21] rootPS)) = affineNative (2^(21+1) ^^^ 526221) := by decide +kernel

theorem selectedBound12267 : packedSelected [5,21] rootPS < 2^1333 := by decide +kernel

def env12268 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1296,32768,65536,1297,65707,524288,32769,1296,526221,17,98565,8328,525329,66082,1296,524561,101127,1284,4294967296,256,4295591458,1297,512]

theorem envBound12268 : H12AffineFastState.Bounded env12268 := by
  intro p hp
  have h : env12268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12267_12268 : H12AffineEnvironment.transform 21 526221 env12267 = env12268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 526221 env12267 == env12268) = true)

def env12269 : List Nat := [2,4,8,16,32,16,128,256,0,1024,2048,1296,8192,1296,32768,65536,1297,65707,524288,32769,1296,525709,17,98565,8328,525329,65570,1296,524561,100615,1284,4294967296,256,4295590946,1297,0]

theorem envBound12269 : H12AffineFastState.Bounded env12269 := by
  intro p hp
  have h : env12269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12268_12269 : H12AffineEnvironment.transform 8 0 env12268 = env12269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env12268 == env12269) = true)

theorem identity12269 : scanCanonicalize (H12AffineFastState.compose env12269 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 599343) := by decide +kernel

theorem selectedBound12269 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env12270 : List Nat := [2,4,8,16,32,16,128,256,0,1024,2048,1296,8192,1296,32768,65536,1297,65707,524288,32769,1296,525709,17,98565,8328,525329,65570,1296,524561,100615,1284,599343,256,41229,1297,0]

theorem envBound12270 : H12AffineFastState.Bounded env12270 := by
  intro p hp
  have h : env12270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12269_12270 : H12AffineEnvironment.transform 31 599343 env12269 = env12270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 599343 env12269 == env12270) = true)

def env12271 : List Nat := [2,4,8,16,32,16,128,256,0,1024,2048,1296,8192,1296,32768,65536,1297,65707,1024,32769,1296,397,17,98565,8328,17,65570,1296,1297,100615,1284,74031,256,41229,1297,0]

theorem envBound12271 : H12AffineFastState.Bounded env12271 := by
  intro p hp
  have h : env12271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12270_12271 : H12AffineEnvironment.transform 18 1024 env12270 = env12271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env12270 == env12271) = true)

theorem identity12271 : scanCanonicalize (H12AffineFastState.compose env12271 (packedSelected [1,3,5] rootPS)) = affineNative (2^(15+1) ^^^ 2447) := by decide +kernel

theorem selectedBound12271 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env12272 : List Nat := [2,4,8,16,32,16,128,256,0,1024,2048,1296,8192,1296,32768,2447,1297,2340,1024,32769,1296,397,17,34954,8328,17,2477,1296,1297,32904,1284,10400,256,41229,1297,0]

theorem envBound12272 : H12AffineFastState.Bounded env12272 := by
  intro p hp
  have h : env12272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12271_12272 : H12AffineEnvironment.transform 15 2447 env12271 = env12272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2447 env12271 == env12272) = true)

theorem identity12272 : scanCanonicalize (H12AffineFastState.compose env12272 (packedSelected [1,3,8] rootPS)) = affineNative (2^(14+1) ^^^ 2049) := by decide +kernel

theorem selectedBound12272 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env12273 : List Nat := [2,4,8,16,32,16,128,256,0,1024,2048,1296,8192,1296,2049,2447,1297,2340,1024,2048,1296,397,17,139,8328,17,2477,1296,1297,2185,1284,10400,256,10508,1297,0]

theorem envBound12273 : H12AffineFastState.Bounded env12273 := by
  intro p hp
  have h : env12273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12272_12273 : H12AffineEnvironment.transform 14 2049 env12272 = env12273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2049 env12272 == env12273) = true)

theorem identity12273 : scanCanonicalize (H12AffineFastState.compose env12273 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound12273 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env12274 : List Nat := [2,4,8,16,32,16,9,256,0,1024,2048,1296,8192,1296,2049,2310,1297,2340,1024,2048,1296,260,17,2,8193,17,2340,1296,1297,2048,1284,10281,256,10508,1297,0]

theorem envBound12274 : H12AffineFastState.Bounded env12274 := by
  intro p hp
  have h : env12274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12273_12274 : H12AffineEnvironment.transform 6 9 env12273 = env12274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env12273 == env12274) = true)

theorem identity12274 : scanCanonicalize (H12AffineFastState.compose env12274 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound12274 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12275 : List Nat := [2,4,8,16,32,16,9,36,0,1024,2048,1076,8192,1076,2049,2082,1077,2048,1024,2048,1076,32,17,2,8193,17,2048,1076,1077,2048,1056,10281,36,10280,1077,0]

theorem envBound12275 : H12AffineFastState.Bounded env12275 := by
  intro p hp
  have h : env12275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12274_12275 : H12AffineEnvironment.transform 7 36 env12274 = env12275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env12274 == env12275) = true)

theorem identity12275 : scanCanonicalize (H12AffineFastState.compose env12275 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound12275 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12276 : List Nat := [2,4,8,16,0,16,9,4,0,1024,2048,1044,8192,1044,2049,2050,1045,2048,1024,2048,1044,0,17,2,8193,17,2048,1044,1045,2048,1024,10249,4,10248,1045,0]

theorem envBound12276 : H12AffineFastState.Bounded env12276 := by
  intro p hp
  have h : env12276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12275_12276 : H12AffineEnvironment.transform 4 0 env12275 = env12276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env12275 == env12276) = true)

theorem identity12276 : scanCanonicalize (H12AffineFastState.compose env12276 (packedSelected [7] rootPS)) = affineNative (2^(12+1) ^^^ 2056) := by decide +kernel

theorem selectedBound12276 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env12277 : List Nat := [2,4,8,16,0,16,9,4,0,1024,2048,1044,2056,1044,2049,2050,1045,2048,1024,2048,1044,0,17,2,2057,17,2048,1044,1045,2048,1024,1,4,0,1045,0]

theorem envBound12277 : H12AffineFastState.Bounded env12277 := by
  intro p hp
  have h : env12277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12276_12277 : H12AffineEnvironment.transform 12 2056 env12276 = env12277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2056 env12276 == env12277) = true)

def env12278 : List Nat := [2,4,8,16,32,16,128,256,0,1024,2048,1296,8192,1296,32768,65536,1297,65707,1025,32769,1296,396,17,98565,8328,16,65570,1296,1296,100615,1284,74030,256,41229,1297,0]

theorem envBound12278 : H12AffineFastState.Bounded env12278 := by
  intro p hp
  have h : env12278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12270_12278 : H12AffineEnvironment.transform 18 1025 env12270 = env12278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env12270 == env12278) = true)

theorem identity12278 : scanCanonicalize (H12AffineFastState.compose env12278 (packedSelected [1,3,5] rootPS)) = affineNative (2^(15+1) ^^^ 2177) := by decide +kernel

theorem selectedBound12278 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env12279 : List Nat := [2,4,8,16,32,16,128,256,0,1024,2048,1296,8192,1296,32768,2177,1297,2090,1025,32769,1296,396,17,35204,8328,16,2211,1296,1296,33158,1284,10671,256,41229,1297,0]

theorem envBound12279 : H12AffineFastState.Bounded env12279 := by
  intro p hp
  have h : env12279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12278_12279 : H12AffineEnvironment.transform 15 2177 env12278 = env12279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2177 env12278 == env12279) = true)

theorem identity12279 : scanCanonicalize (H12AffineFastState.compose env12279 (packedSelected [1,3,8] rootPS)) = affineNative (2^(7+1) ^^^ 134) := by decide +kernel

theorem selectedBound12279 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env12280 : List Nat := [2,4,8,16,32,16,128,134,0,1024,2048,1174,8192,1174,32768,2177,1175,2090,1025,32769,1174,10,17,34818,8328,16,2211,1174,1174,32768,1154,10281,134,41099,1175,0]

theorem envBound12280 : H12AffineFastState.Bounded env12280 := by
  intro p hp
  have h : env12280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12279_12280 : H12AffineEnvironment.transform 7 134 env12279 = env12280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 134 env12279 == env12280) = true)

theorem identity12280 : scanCanonicalize (H12AffineFastState.compose env12280 (packedSelected [1,10] rootPS)) = affineNative (2^(14+1) ^^^ 2090) := by decide +kernel

theorem selectedBound12280 : packedSelected [1,10] rootPS < 2^1333 := by decide +kernel

def env12281 : List Nat := [2,4,8,16,32,16,128,134,0,1024,2048,1174,8192,1174,2090,2177,1175,2090,1025,2091,1174,10,17,40,8328,16,2211,1174,1174,2090,1154,10281,134,10401,1175,0]

theorem envBound12281 : H12AffineFastState.Bounded env12281 := by
  intro p hp
  have h : env12281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12280_12281 : H12AffineEnvironment.transform 14 2090 env12280 = env12281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2090 env12280 == env12281) = true)

theorem identity12281 : scanCanonicalize (H12AffineFastState.compose env12281 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 2088) := by decide +kernel

theorem selectedBound12281 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env12282 : List Nat := [2,4,8,16,32,16,128,134,0,1024,2048,1174,2088,1174,2090,2177,1175,2090,1025,2091,1174,10,17,40,2208,16,2211,1174,1174,2090,1154,1,134,137,1175,0]

theorem envBound12282 : H12AffineFastState.Bounded env12282 := by
  intro p hp
  have h : env12282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12281_12282 : H12AffineEnvironment.transform 12 2088 env12281 = env12282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2088 env12281 == env12282) = true)

theorem identity12282 : scanCanonicalize (H12AffineFastState.compose env12282 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound12282 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12283 : List Nat := [2,4,8,16,32,16,34,36,0,1024,2048,1076,2088,1076,2090,2083,1077,2090,1025,2091,1076,10,17,40,2050,16,2049,1076,1076,2090,1056,1,36,43,1077,0]

theorem envBound12283 : H12AffineFastState.Bounded env12283 := by
  intro p hp
  have h : env12283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12282_12283 : H12AffineEnvironment.transform 6 34 env12282 = env12283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env12282 == env12283) = true)

theorem identity12283 : scanCanonicalize (H12AffineFastState.compose env12283 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound12283 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12284 : List Nat := [2,4,8,16,32,16,34,36,0,1024,49,1076,25,1076,27,18,1077,27,1025,26,1076,10,17,40,51,16,48,1076,1076,27,1056,1,36,43,1077,0]

theorem envBound12284 : H12AffineFastState.Bounded env12284 := by
  intro p hp
  have h : env12284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12283_12284 : H12AffineEnvironment.transform 10 49 env12283 = env12284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env12283 == env12284) = true)

theorem identity12284 : scanCanonicalize (H12AffineFastState.compose env12284 (packedSelected [3] rootPS)) = affineNative (2^(9+1) ^^^ 31) := by decide +kernel

theorem selectedBound12284 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env12285 : List Nat := [2,4,8,16,32,16,34,36,0,31,49,43,25,43,27,18,42,27,30,26,43,10,17,40,51,16,48,43,43,27,63,1,36,43,42,0]

theorem envBound12285 : H12AffineFastState.Bounded env12285 := by
  intro p hp
  have h : env12285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12284_12285 : H12AffineEnvironment.transform 9 31 env12284 = env12285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 31 env12284 == env12285) = true)

def env12286 : List Nat := [2,4,8,16,32,16,128,256,1,1024,2048,1296,8192,1296,32768,65536,1297,65707,524288,32769,1296,525708,17,98565,8328,525329,65571,1296,524561,100614,1284,4294967296,256,4295590947,1297,1]

theorem envBound12286 : H12AffineFastState.Bounded env12286 := by
  intro p hp
  have h : env12286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12268_12286 : H12AffineEnvironment.transform 8 1 env12268 = env12286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env12268 == env12286) = true)

theorem identity12286 : scanCanonicalize (H12AffineFastState.compose env12286 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 623650) := by decide +kernel

theorem selectedBound12286 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env12287 : List Nat := [2,4,8,16,32,16,128,256,1,1024,2048,1296,8192,1296,32768,65536,1297,65707,524288,32769,1296,525708,17,98565,8328,525329,65571,1296,524561,100614,1284,623650,256,1,1297,1]

theorem envBound12287 : H12AffineFastState.Bounded env12287 := by
  intro p hp
  have h : env12287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12286_12287 : H12AffineEnvironment.transform 31 623650 env12286 = env12287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 623650 env12286 == env12287) = true)

def env12288 : List Nat := [2,4,8,16,32,16,128,256,1,1024,2048,1296,8192,1296,32768,65536,1297,65707,1024,32769,1296,396,17,98565,8328,17,65571,1296,1297,100614,1284,98338,256,1,1297,1]

theorem envBound12288 : H12AffineFastState.Bounded env12288 := by
  intro p hp
  have h : env12288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12287_12288 : H12AffineEnvironment.transform 18 1024 env12287 = env12288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env12287 == env12288) = true)

theorem identity12288 : scanCanonicalize (H12AffineFastState.compose env12288 (packedSelected [1,3,5] rootPS)) = affineNative (2^(15+1) ^^^ 2446) := by decide +kernel

theorem selectedBound12288 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env12289 : List Nat := [2,4,8,16,32,16,128,256,1,1024,2048,1296,8192,1296,32768,2446,1297,2341,1024,32769,1296,396,17,34955,8328,17,2477,1296,1297,32904,1284,35244,256,1,1297,1]

theorem envBound12289 : H12AffineFastState.Bounded env12289 := by
  intro p hp
  have h : env12289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12288_12289 : H12AffineEnvironment.transform 15 2446 env12288 = env12289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2446 env12288 == env12289) = true)

theorem identity12289 : scanCanonicalize (H12AffineFastState.compose env12289 (packedSelected [1,3,8] rootPS)) = affineNative (2^(14+1) ^^^ 2048) := by decide +kernel

theorem selectedBound12289 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env12290 : List Nat := [2,4,8,16,32,16,128,256,1,1024,2048,1296,8192,1296,2048,2446,1297,2341,1024,2049,1296,396,17,139,8328,17,2477,1296,1297,2184,1284,428,256,1,1297,1]

theorem envBound12290 : H12AffineFastState.Bounded env12290 := by
  intro p hp
  have h : env12290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12289_12290 : H12AffineEnvironment.transform 14 2048 env12289 = env12290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2048 env12289 == env12290) = true)

theorem identity12290 : scanCanonicalize (H12AffineFastState.compose env12290 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound12290 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env12291 : List Nat := [2,4,8,16,32,16,8,256,1,1024,2048,1296,8192,1296,2048,2310,1297,2341,1024,2049,1296,260,17,3,8192,17,2341,1296,1297,2048,1284,292,256,1,1297,1]

theorem envBound12291 : H12AffineFastState.Bounded env12291 := by
  intro p hp
  have h : env12291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12290_12291 : H12AffineEnvironment.transform 6 8 env12290 = env12291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env12290 == env12291) = true)

theorem identity12291 : scanCanonicalize (H12AffineFastState.compose env12291 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound12291 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12292 : List Nat := [2,4,8,16,32,16,8,36,1,1024,2048,1076,8192,1076,2048,2082,1077,2049,1024,2049,1076,32,17,3,8192,17,2049,1076,1077,2048,1056,0,36,1,1077,1]

theorem envBound12292 : H12AffineFastState.Bounded env12292 := by
  intro p hp
  have h : env12292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12291_12292 : H12AffineEnvironment.transform 7 36 env12291 = env12292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env12291 == env12292) = true)

theorem identity12292 : scanCanonicalize (H12AffineFastState.compose env12292 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound12292 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12293 : List Nat := [2,4,8,16,1,16,8,5,1,1024,2048,1045,8192,1045,2048,2051,1044,2049,1024,2049,1045,1,17,3,8192,17,2049,1045,1044,2048,1025,0,5,1,1044,1]

theorem envBound12293 : H12AffineFastState.Bounded env12293 := by
  intro p hp
  have h : env12293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12292_12293 : H12AffineEnvironment.transform 4 1 env12292 = env12293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env12292 == env12293) = true)

theorem identity12293 : scanCanonicalize (H12AffineFastState.compose env12293 (packedSelected [7] rootPS)) = affineNative (2^(12+1) ^^^ 2057) := by decide +kernel

theorem selectedBound12293 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env12294 : List Nat := [2,4,8,16,1,16,8,5,1,1024,2048,1045,2057,1045,2048,2051,1044,2049,1024,2049,1045,1,17,3,2057,17,2049,1045,1044,2048,1025,0,5,1,1044,1]

theorem envBound12294 : H12AffineFastState.Bounded env12294 := by
  intro p hp
  have h : env12294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12293_12294 : H12AffineEnvironment.transform 12 2057 env12293 = env12294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2057 env12293 == env12294) = true)

def env12295 : List Nat := [2,4,8,16,32,16,128,256,1,1024,2048,1296,8192,1296,32768,65536,1297,65707,1025,32769,1296,397,17,98565,8328,16,65571,1296,1296,100614,1284,98339,256,1,1297,1]

theorem envBound12295 : H12AffineFastState.Bounded env12295 := by
  intro p hp
  have h : env12295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12287_12295 : H12AffineEnvironment.transform 18 1025 env12287 = env12295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env12287 == env12295) = true)

theorem identity12295 : scanCanonicalize (H12AffineFastState.compose env12295 (packedSelected [1,3,5] rootPS)) = affineNative (2^(15+1) ^^^ 2176) := by decide +kernel

theorem selectedBound12295 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env12296 : List Nat := [2,4,8,16,32,16,128,256,1,1024,2048,1296,8192,1296,32768,2176,1297,2091,1025,32769,1296,397,17,35205,8328,16,2211,1296,1296,33158,1284,34979,256,1,1297,1]

theorem envBound12296 : H12AffineFastState.Bounded env12296 := by
  intro p hp
  have h : env12296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12295_12296 : H12AffineEnvironment.transform 15 2176 env12295 = env12296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2176 env12295 == env12296) = true)

theorem identity12296 : scanCanonicalize (H12AffineFastState.compose env12296 (packedSelected [1,3,8] rootPS)) = affineNative (2^(7+1) ^^^ 134) := by decide +kernel

theorem selectedBound12296 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env12297 : List Nat := [2,4,8,16,32,16,128,134,1,1024,2048,1174,8192,1174,32768,2176,1175,2091,1025,32769,1174,11,17,34819,8328,16,2211,1174,1174,32768,1154,34979,134,1,1175,1]

theorem envBound12297 : H12AffineFastState.Bounded env12297 := by
  intro p hp
  have h : env12297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12296_12297 : H12AffineEnvironment.transform 7 134 env12296 = env12297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 134 env12296 == env12297) = true)

theorem identity12297 : scanCanonicalize (H12AffineFastState.compose env12297 (packedSelected [1,10] rootPS)) = affineNative (2^(14+1) ^^^ 2091) := by decide +kernel

theorem selectedBound12297 : packedSelected [1,10] rootPS < 2^1333 := by decide +kernel

def env12298 : List Nat := [2,4,8,16,32,16,128,134,1,1024,2048,1174,8192,1174,2091,2176,1175,2091,1025,2090,1174,11,17,40,8328,16,2211,1174,1174,2091,1154,136,134,1,1175,1]

theorem envBound12298 : H12AffineFastState.Bounded env12298 := by
  intro p hp
  have h : env12298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12297_12298 : H12AffineEnvironment.transform 14 2091 env12297 = env12298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2091 env12297 == env12298) = true)

theorem identity12298 : scanCanonicalize (H12AffineFastState.compose env12298 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 2088) := by decide +kernel

theorem selectedBound12298 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env12299 : List Nat := [2,4,8,16,32,16,128,134,1,1024,2048,1174,2088,1174,2091,2176,1175,2091,1025,2090,1174,11,17,40,2208,16,2211,1174,1174,2091,1154,136,134,1,1175,1]

theorem envBound12299 : H12AffineFastState.Bounded env12299 := by
  intro p hp
  have h : env12299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12298_12299 : H12AffineEnvironment.transform 12 2088 env12298 = env12299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2088 env12298 == env12299) = true)

theorem identity12299 : scanCanonicalize (H12AffineFastState.compose env12299 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound12299 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12300 : List Nat := [2,4,8,16,32,16,34,36,1,1024,2048,1076,2088,1076,2091,2082,1077,2091,1025,2090,1076,11,17,40,2050,16,2049,1076,1076,2091,1056,42,36,1,1077,1]

theorem envBound12300 : H12AffineFastState.Bounded env12300 := by
  intro p hp
  have h : env12300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12299_12300 : H12AffineEnvironment.transform 6 34 env12299 = env12300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env12299 == env12300) = true)

theorem identity12300 : scanCanonicalize (H12AffineFastState.compose env12300 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 27) := by decide +kernel

theorem selectedBound12300 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12301 : List Nat := [2,4,8,16,32,16,34,36,1,1024,27,1076,51,1076,48,57,1077,48,1025,49,1076,11,17,40,25,16,26,1076,1076,48,1056,42,36,1,1077,1]

theorem envBound12301 : H12AffineFastState.Bounded env12301 := by
  intro p hp
  have h : env12301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12300_12301 : H12AffineEnvironment.transform 10 27 env12300 = env12301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 27 env12300 == env12301) = true)

theorem identity12301 : scanCanonicalize (H12AffineFastState.compose env12301 (packedSelected [3] rootPS)) = affineNative (2^(9+1) ^^^ 30) := by decide +kernel

theorem selectedBound12301 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env12302 : List Nat := [2,4,8,16,32,16,34,36,1,30,27,42,51,42,48,57,43,48,31,49,42,11,17,40,25,16,26,42,42,48,62,42,36,1,43,1]

theorem envBound12302 : H12AffineFastState.Bounded env12302 := by
  intro p hp
  have h : env12302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12301_12302 : H12AffineEnvironment.transform 9 30 env12301 = env12302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 30 env12301 == env12302) = true)

def env12303 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1297,32768,65536,1296,262144,524288,32769,1297,4194304,16,98565,8328,525329,4982021,1297,524560,5016609,1284,4294967296,256,4299260335,1297,512]

theorem envBound12303 : H12AffineFastState.Bounded env12303 := by
  intro p hp
  have h : env12303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12265_12303 : H12AffineEnvironment.transform 5 17 env12265 = env12303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env12265 == env12303) = true)

theorem identity12303 : scanCanonicalize (H12AffineFastState.compose env12303 (packedSelected [5,8,13,15,19] rootPS)) = affineNative (2^(21+1) ^^^ 561037) := by decide +kernel

theorem selectedBound12303 : packedSelected [5,8,13,15,19] rootPS < 2^1333 := by decide +kernel

def env12304 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1297,32768,65536,1296,262144,524288,32769,1297,561037,16,98565,8328,525329,297608,1297,524560,263084,1284,4294967296,256,4295560738,1297,512]

theorem envBound12304 : H12AffineFastState.Bounded env12304 := by
  intro p hp
  have h : env12304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12303_12304 : H12AffineEnvironment.transform 21 561037 env12303 = env12304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 561037 env12303 == env12304) = true)

theorem identity12304 : scanCanonicalize (H12AffineFastState.compose env12304 (packedSelected [0,7,20] rootPS)) = affineNative (2^(18+1) ^^^ 1024) := by decide +kernel

theorem selectedBound12304 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env12305 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1297,32768,65536,1296,262144,1024,32769,1297,35725,16,98565,8328,17,297608,1297,1296,263084,1284,4294967296,256,4295035426,1297,512]

theorem envBound12305 : H12AffineFastState.Bounded env12305 := by
  intro p hp
  have h : env12305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12304_12305 : H12AffineEnvironment.transform 18 1024 env12304 = env12305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env12304 == env12305) = true)

theorem identity12305 : scanCanonicalize (H12AffineFastState.compose env12305 (packedSelected [1,3,5] rootPS)) = affineNative (2^(14+1) ^^^ 390) := by decide +kernel

theorem selectedBound12305 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env12306 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1297,390,65536,1296,262144,1024,391,1297,2571,16,65667,8328,17,264974,1297,1296,263084,1284,4294967296,256,4295035426,1297,512]

theorem envBound12306 : H12AffineFastState.Bounded env12306 := by
  intro p hp
  have h : env12306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12305_12306 : H12AffineEnvironment.transform 14 390 env12305 = env12306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 390 env12305 == env12306) = true)

theorem identity12306 : scanCanonicalize (H12AffineFastState.compose env12306 (packedSelected [1,3,8] rootPS)) = affineNative (2^(12+1) ^^^ 3) := by decide +kernel

theorem selectedBound12306 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env12307 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,3,1297,390,65536,1296,262144,1024,391,1297,2571,16,65667,139,17,264974,1297,1296,263084,1284,4294967296,256,4295035426,1297,512]

theorem envBound12307 : H12AffineFastState.Bounded env12307 := by
  intro p hp
  have h : env12307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12306_12307 : H12AffineEnvironment.transform 12 3 env12306 = env12307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3 env12306 == env12307) = true)

theorem identity12307 : scanCanonicalize (H12AffineFastState.compose env12307 (packedSelected [1,10] rootPS)) = affineNative (2^(17+1) ^^^ 2561) := by decide +kernel

theorem selectedBound12307 : packedSelected [1,10] rootPS < 2^1333 := by decide +kernel

def env12308 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,3,1297,390,65536,1296,2561,1024,391,1297,2571,16,65667,139,17,271,1297,1296,2477,1284,4294967296,256,4295035426,1297,512]

theorem envBound12308 : H12AffineFastState.Bounded env12308 := by
  intro p hp
  have h : env12308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12307_12308 : H12AffineEnvironment.transform 17 2561 env12307 = env12308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2561 env12307 == env12308) = true)

theorem identity12308 : scanCanonicalize (H12AffineFastState.compose env12308 (packedSelected [1,12,13] rootPS)) = affineNative (2^(31+1) ^^^ 2691) := by decide +kernel

theorem selectedBound12308 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env12309 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,3,1297,390,65536,1296,2561,1024,391,1297,2571,16,65667,139,17,271,1297,1296,2477,1284,2691,256,65697,1297,512]

theorem envBound12309 : H12AffineFastState.Bounded env12309 := by
  intro p hp
  have h : env12309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12308_12309 : H12AffineEnvironment.transform 31 2691 env12308 = env12309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 2691 env12308 == env12309) = true)

def env12310 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,32768,65536,1345,262144,524288,32769,1344,4194304,64,98565,8328,525328,134217728,1345,524608,1073741824,1284,4294967296,256,4299260335,139198533,512]

theorem envBound12310 : H12AffineFastState.Bounded env12310 := by
  intro p hp
  have h : env12310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12226_12310 : H12AffineEnvironment.transform 13 1345 env12226 = env12310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env12226 == env12310) = true)

theorem identity12310 : scanCanonicalize (H12AffineFastState.compose env12310 (packedSelected [9,22] rootPS)) = affineNative (2^(26+1) ^^^ 4456708) := by decide +kernel

theorem selectedBound12310 : packedSelected [9,22] rootPS < 2^1333 := by decide +kernel

def env12311 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,32768,65536,1345,262144,524288,32769,1344,4194304,64,98565,8328,525328,4456708,1345,524608,1073741824,1284,4294967296,256,4299260335,524609,512]

theorem envBound12311 : H12AffineFastState.Bounded env12311 := by
  intro p hp
  have h : env12311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12310_12311 : H12AffineEnvironment.transform 26 4456708 env12310 = env12311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 4456708 env12310 == env12311) = true)

theorem identity12311 : scanCanonicalize (H12AffineFastState.compose env12311 (packedSelected [0,7,20] rootPS)) = affineNative (2^(18+1) ^^^ 1024) := by decide +kernel

theorem selectedBound12311 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env12312 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,32768,65536,1345,262144,1024,32769,1344,4194304,64,98565,8328,16,4456708,1345,1344,1073741824,1284,4294967296,256,4299260335,1345,512]

theorem envBound12312 : H12AffineFastState.Bounded env12312 := by
  intro p hp
  have h : env12312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12311_12312 : H12AffineEnvironment.transform 18 1024 env12311 = env12312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env12311 == env12312) = true)

def env12313 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,0,8192,1,32768,65536,1,262144,320,32769,0,4194304,64,98565,8328,16,4456708,1,0,1073741824,68,4294967296,256,4299260335,1,512]

theorem envBound12313 : H12AffineFastState.Bounded env12313 := by
  intro p hp
  have h : env12313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12312_12313 : H12AffineEnvironment.transform 9 320 env12312 = env12313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env12312 == env12313) = true)

theorem identity12313 : scanCanonicalize (H12AffineFastState.compose env12313 (packedSelected [1,3,5,8,10] rootPS)) = affineNative (2^(21+1) ^^^ 98815) := by decide +kernel

theorem selectedBound12313 : packedSelected [1,3,5,8,10] rootPS < 2^1333 := by decide +kernel

def env12314 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,0,8192,1,32768,65536,1,262144,320,32769,0,98815,64,98565,8328,16,360699,1,0,1073741824,68,4294967296,256,4294967376,1,512]

theorem envBound12314 : H12AffineFastState.Bounded env12314 := by
  intro p hp
  have h : env12314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12313_12314 : H12AffineEnvironment.transform 21 98815 env12313 = env12314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 98815 env12313 == env12314) = true)

theorem identity12314 : scanCanonicalize (H12AffineFastState.compose env12314 (packedSelected [1,5] rootPS)) = affineNative (2^(29+1) ^^^ 2340) := by decide +kernel

theorem selectedBound12314 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env12315 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,0,8192,1,32768,65536,1,262144,320,32769,0,98815,64,98565,8328,16,360699,1,0,2340,68,4294967296,256,4294967376,1,512]

theorem envBound12315 : H12AffineFastState.Bounded env12315 := by
  intro p hp
  have h : env12315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12314_12315 : H12AffineEnvironment.transform 29 2340 env12314 = env12315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 2340 env12314 == env12315) = true)

theorem identity12315 : scanCanonicalize (H12AffineFastState.compose env12315 (packedSelected [15] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound12315 : packedSelected [15] rootPS < 2^1333 := by decide +kernel

def env12316 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,0,8192,1,8460,65536,1,262144,320,8461,0,73971,64,73737,8328,16,336375,1,0,2340,68,4294967296,256,4294967376,1,512]

theorem envBound12316 : H12AffineFastState.Bounded env12316 := by
  intro p hp
  have h : env12316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12315_12316 : H12AffineEnvironment.transform 14 8460 env12315 = env12316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env12315 == env12316) = true)

theorem identity12316 : scanCanonicalize (H12AffineFastState.compose env12316 (packedSelected [1,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound12316 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env12317 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,0,8192,1,8460,65536,1,262144,273,8461,0,73890,17,73737,8328,16,336294,1,0,2340,21,4294967296,256,4294967297,1,512]

theorem envBound12317 : H12AffineFastState.Bounded env12317 := by
  intro p hp
  have h : env12317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12316_12317 : H12AffineEnvironment.transform 5 17 env12316 = env12317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env12316 == env12317) = true)

theorem identity12317 : scanCanonicalize (H12AffineFastState.compose env12317 (packedSelected [1] rootPS)) = affineNative (2^(17+1) ^^^ 2852) := by decide +kernel

theorem selectedBound12317 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12318 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,0,8192,1,8460,65536,1,2852,273,8461,0,73890,17,73737,8328,16,76418,1,0,2340,21,4294967296,256,4294967297,1,512]

theorem envBound12318 : H12AffineFastState.Bounded env12318 := by
  intro p hp
  have h : env12318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12317_12318 : H12AffineEnvironment.transform 17 2852 env12317 = env12318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2852 env12317 == env12318) = true)

theorem identity12318 : scanCanonicalize (H12AffineFastState.compose env12318 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound12318 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env12319 : List Nat := [2,4,8,16,32,17,128,256,1,273,2048,0,8192,1,8460,65536,1,2341,273,8461,0,73890,17,73737,8328,16,75907,1,0,2340,21,4294967296,256,4294967297,1,1]

theorem envBound12319 : H12AffineFastState.Bounded env12319 := by
  intro p hp
  have h : env12319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12318_12319 : H12AffineEnvironment.transform 8 1 env12318 = env12319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env12318 == env12319) = true)

theorem identity12319 : scanCanonicalize (H12AffineFastState.compose env12319 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 0) := by decide +kernel

theorem selectedBound12319 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env12320 : List Nat := [2,4,8,16,32,17,128,256,1,273,2048,0,8192,1,8460,65536,1,2341,273,8461,0,73890,17,73737,8328,16,75907,1,0,2340,21,0,256,1,1,1]

theorem envBound12320 : H12AffineFastState.Bounded env12320 := by
  intro p hp
  have h : env12320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12319_12320 : H12AffineEnvironment.transform 31 0 env12319 = env12320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 0 env12319 == env12320) = true)

theorem identity12320 : scanCanonicalize (H12AffineFastState.compose env12320 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound12320 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env12321 : List Nat := [2,4,8,16,32,17,128,256,1,273,2048,0,8192,1,8460,8322,1,2341,273,8461,0,32,17,139,8328,16,2049,1,0,2340,21,0,256,1,1,1]

theorem envBound12321 : H12AffineFastState.Bounded env12321 := by
  intro p hp
  have h : env12321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12320_12321 : H12AffineEnvironment.transform 15 8322 env12320 = env12321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env12320 == env12321) = true)

theorem identity12321 : scanCanonicalize (H12AffineFastState.compose env12321 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound12321 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12322 : List Nat := [2,4,8,16,0,17,128,256,1,273,2048,0,8192,1,8460,8322,1,2309,273,8461,0,0,17,139,8328,16,2049,1,0,2308,21,0,256,1,1,1]

theorem envBound12322 : H12AffineFastState.Bounded env12322 := by
  intro p hp
  have h : env12322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12321_12322 : H12AffineEnvironment.transform 4 0 env12321 = env12322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env12321 == env12322) = true)

def env12323 : List Nat := [2,4,8,16,0,17,128,256,1,273,2048,0,2176,1,2444,2050,1,2309,273,2445,0,0,17,139,2056,16,2049,1,0,2308,21,0,256,1,1,1]

theorem envBound12323 : H12AffineFastState.Bounded env12323 := by
  intro p hp
  have h : env12323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12322_12323 : H12AffineEnvironment.transform 12 2176 env12322 = env12323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2176 env12322 == env12323) = true)

theorem identity12323 : scanCanonicalize (H12AffineFastState.compose env12323 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 141) := by decide +kernel

theorem selectedBound12323 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12324 : List Nat := [2,4,8,16,0,17,128,141,1,156,2048,0,2176,1,2049,2050,1,2184,156,2048,0,0,17,139,2056,16,2049,1,0,2185,21,0,141,1,1,1]

theorem envBound12324 : H12AffineFastState.Bounded env12324 := by
  intro p hp
  have h : env12324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12323_12324 : H12AffineEnvironment.transform 7 141 env12323 = env12324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 141 env12323 == env12324) = true)

def leafEnv12324 : List Nat := [2,4,8,16,0,17,128,141,1,156,2048,0,2176,1,2049,2050,1,2184,156,2048,0,0,17,139,21,2056,1,16,2049,1,0,2185,21,0,141,1,4,2187,1,1,0,0,1]

def active12324 : List Nat := [0,1,2,3,6,10]

def tree12324 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood12324 : H12WitnessSearch.Good tree12324 := H12GlobalWitnessIndex.good

theorem leafIdentity12324 : H12AffineFastState.composeSystem env12324 rootObs = leafEnv12324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env12324 rootObs == leafEnv12324) = true)

theorem terminalChecked12324 : H12PackedTerminal.terminalCheckFast leafEnv12324 active12324 tree12324 = true := by decide +kernel

def env12325 : List Nat := [2,4,8,16,0,17,128,256,1,273,2048,0,2177,1,2445,2051,1,2309,273,2444,0,0,17,139,2057,16,2049,1,0,2308,21,0,256,1,1,1]

theorem envBound12325 : H12AffineFastState.Bounded env12325 := by
  intro p hp
  have h : env12325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12322_12325 : H12AffineEnvironment.transform 12 2177 env12322 = env12325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2177 env12322 == env12325) = true)

theorem identity12325 : scanCanonicalize (H12AffineFastState.compose env12325 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound12325 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12326 : List Nat := [2,4,8,16,0,17,8,256,1,273,2048,0,2057,1,2309,2051,1,2309,273,2308,0,0,17,3,2057,16,2049,1,0,2308,21,0,256,1,1,1]

theorem envBound12326 : H12AffineFastState.Bounded env12326 := by
  intro p hp
  have h : env12326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12325_12326 : H12AffineEnvironment.transform 6 8 env12325 = env12326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env12325 == env12326) = true)

def leafEnv12326 : List Nat := [2,4,8,16,0,17,8,256,1,273,2048,0,2057,1,2309,2051,1,2309,273,2308,0,0,17,3,21,2057,1,16,2049,1,0,2308,21,0,256,1,4,2050,1,1,0,0,1]

def active12326 : List Nat := [0,1,2,3,7,10]

def tree12326 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood12326 : H12WitnessSearch.Good tree12326 := H12GlobalWitnessIndex.good

theorem leafIdentity12326 : H12AffineFastState.composeSystem env12326 rootObs = leafEnv12326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env12326 rootObs == leafEnv12326) = true)

theorem terminalChecked12326 : H12PackedTerminal.terminalCheckFast leafEnv12326 active12326 tree12326 = true := by decide +kernel

def env12327 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,1,8192,0,32768,65536,0,262144,321,32769,1,4194304,64,98565,8328,16,4456708,0,1,1073741824,69,4294967296,256,4299260335,0,512]

theorem envBound12327 : H12AffineFastState.Bounded env12327 := by
  intro p hp
  have h : env12327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12312_12327 : H12AffineEnvironment.transform 9 321 env12312 = env12327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env12312 == env12327) = true)

theorem identity12327 : scanCanonicalize (H12AffineFastState.compose env12327 (packedSelected [1,3,5,8,10] rootPS)) = affineNative (2^(21+1) ^^^ 305240) := by decide +kernel

theorem selectedBound12327 : packedSelected [1,3,5,8,10] rootPS < 2^1333 := by decide +kernel

def env12328 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,1,8192,0,32768,65536,0,262144,321,32769,1,305240,64,98565,8328,16,43356,0,1,1073741824,69,4294967296,256,4295305719,0,512]

theorem envBound12328 : H12AffineFastState.Bounded env12328 := by
  intro p hp
  have h : env12328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12327_12328 : H12AffineEnvironment.transform 21 305240 env12327 = env12328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 305240 env12327 == env12328) = true)

theorem identity12328 : scanCanonicalize (H12AffineFastState.compose env12328 (packedSelected [1,3,5,8,13] rootPS)) = affineNative (2^(15+1) ^^^ 8403) := by decide +kernel

theorem selectedBound12328 : packedSelected [1,3,5,8,13] rootPS < 2^1333 := by decide +kernel

def env12329 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,1,8192,0,32768,8403,0,262144,321,32769,1,305240,64,41430,8328,16,43356,0,1,1073741824,69,4294967296,256,4295231780,0,512]

theorem envBound12329 : H12AffineFastState.Bounded env12329 := by
  intro p hp
  have h : env12329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12328_12329 : H12AffineEnvironment.transform 15 8403 env12328 = env12329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8403 env12328 == env12329) = true)

theorem identity12329 : scanCanonicalize (H12AffineFastState.compose env12329 (packedSelected [3,8] rootPS)) = affineNative (2^(29+1) ^^^ 2421) := by decide +kernel

theorem selectedBound12329 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env12330 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,1,8192,0,32768,8403,0,262144,321,32769,1,305240,64,41430,8328,16,43356,0,1,2421,69,4294967296,256,4295231780,0,512]

theorem envBound12330 : H12AffineFastState.Bounded env12330 := by
  intro p hp
  have h : env12330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12329_12330 : H12AffineEnvironment.transform 29 2421 env12329 = env12330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 2421 env12329 == env12330) = true)

theorem identity12330 : scanCanonicalize (H12AffineFastState.compose env12330 (packedSelected [1,5,12] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound12330 : packedSelected [1,5,12] rootPS < 2^1333 := by decide +kernel

def env12331 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,1,8192,0,8541,8403,0,262144,321,8540,1,264453,64,139,8328,16,2049,0,1,2421,69,4294967296,256,4295231780,0,512]

theorem envBound12331 : H12AffineFastState.Bounded env12331 := by
  intro p hp
  have h : env12331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12330_12331 : H12AffineEnvironment.transform 14 8541 env12330 = env12331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env12330 == env12331) = true)

theorem identity12331 : scanCanonicalize (H12AffineFastState.compose env12331 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 2420) := by decide +kernel

theorem selectedBound12331 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env12332 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,1,8192,0,8541,8403,0,2420,321,8540,1,113,64,139,8328,16,2049,0,1,2421,69,4294967296,256,4294967376,0,512]

theorem envBound12332 : H12AffineFastState.Bounded env12332 := by
  intro p hp
  have h : env12332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12331_12332 : H12AffineEnvironment.transform 17 2420 env12331 = env12332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2420 env12331 == env12332) = true)

theorem identity12332 : scanCanonicalize (H12AffineFastState.compose env12332 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound12332 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env12333 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,1,8192,0,8460,8322,0,2341,272,8461,1,32,17,139,8328,16,2049,0,1,2340,20,4294967296,256,4294967297,0,512]

theorem envBound12333 : H12AffineFastState.Bounded env12333 := by
  intro p hp
  have h : env12333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12332_12333 : H12AffineEnvironment.transform 5 17 env12332 = env12333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env12332 == env12333) = true)

theorem identity12333 : scanCanonicalize (H12AffineFastState.compose env12333 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound12333 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12334 : List Nat := [2,4,8,16,32,17,128,256,1,272,2048,1,8192,0,8460,8322,0,2341,272,8461,1,32,17,139,8328,16,2049,0,1,2340,20,4294967296,256,4294967297,0,1]

theorem envBound12334 : H12AffineFastState.Bounded env12334 := by
  intro p hp
  have h : env12334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12333_12334 : H12AffineEnvironment.transform 8 1 env12333 = env12334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env12333 == env12334) = true)

theorem identity12334 : scanCanonicalize (H12AffineFastState.compose env12334 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound12334 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12335 : List Nat := [2,4,8,16,0,17,128,256,1,272,2048,1,8192,0,8460,8322,0,2309,272,8461,1,0,17,139,8328,16,2049,0,1,2308,20,4294967296,256,4294967297,0,1]

theorem envBound12335 : H12AffineFastState.Bounded env12335 := by
  intro p hp
  have h : env12335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12334_12335 : H12AffineEnvironment.transform 4 0 env12334 = env12335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env12334 == env12335) = true)

theorem identity12335 : scanCanonicalize (H12AffineFastState.compose env12335 (packedSelected [0,4] rootPS)) = affineNative (2^(31+1) ^^^ 0) := by decide +kernel

theorem selectedBound12335 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env12336 : List Nat := [2,4,8,16,0,17,128,256,1,272,2048,1,8192,0,8460,8322,0,2309,272,8461,1,0,17,139,8328,16,2049,0,1,2308,20,0,256,1,0,1]

theorem envBound12336 : H12AffineFastState.Bounded env12336 := by
  intro p hp
  have h : env12336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12335_12336 : H12AffineEnvironment.transform 31 0 env12335 = env12336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 0 env12335 == env12336) = true)

def env12337 : List Nat := [2,4,8,16,0,17,128,256,1,272,2048,1,2176,0,2444,2050,0,2309,272,2445,1,0,17,139,2056,16,2049,0,1,2308,20,0,256,1,0,1]

theorem envBound12337 : H12AffineFastState.Bounded env12337 := by
  intro p hp
  have h : env12337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12336_12337 : H12AffineEnvironment.transform 12 2176 env12336 = env12337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2176 env12336 == env12337) = true)

theorem identity12337 : scanCanonicalize (H12AffineFastState.compose env12337 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 141) := by decide +kernel

theorem selectedBound12337 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12338 : List Nat := [2,4,8,16,0,17,128,141,1,157,2048,1,2176,0,2049,2050,0,2184,157,2048,1,0,17,139,2056,16,2049,0,1,2185,20,0,141,1,0,1]

theorem envBound12338 : H12AffineFastState.Bounded env12338 := by
  intro p hp
  have h : env12338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12337_12338 : H12AffineEnvironment.transform 7 141 env12337 = env12338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 141 env12337 == env12338) = true)

def leafEnv12338 : List Nat := [2,4,8,16,0,17,128,141,1,157,2048,1,2176,0,2049,2050,0,2184,157,2048,1,0,17,139,20,2056,1,16,2049,0,1,2185,20,0,141,1,4,2187,0,1,0,1,1]

def active12338 : List Nat := [0,1,2,3,6,10]

def tree12338 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood12338 : H12WitnessSearch.Good tree12338 := H12GlobalWitnessIndex.good

theorem leafIdentity12338 : H12AffineFastState.composeSystem env12338 rootObs = leafEnv12338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env12338 rootObs == leafEnv12338) = true)

theorem terminalChecked12338 : H12PackedTerminal.terminalCheckFast leafEnv12338 active12338 tree12338 = true := by decide +kernel

def env12339 : List Nat := [2,4,8,16,0,17,128,256,1,272,2048,1,2177,0,2445,2051,0,2309,272,2444,1,0,17,139,2057,16,2049,0,1,2308,20,0,256,1,0,1]

theorem envBound12339 : H12AffineFastState.Bounded env12339 := by
  intro p hp
  have h : env12339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12336_12339 : H12AffineEnvironment.transform 12 2177 env12336 = env12339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2177 env12336 == env12339) = true)

theorem identity12339 : scanCanonicalize (H12AffineFastState.compose env12339 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound12339 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12340 : List Nat := [2,4,8,16,0,17,8,256,1,272,2048,1,2057,0,2309,2051,0,2309,272,2308,1,0,17,3,2057,16,2049,0,1,2308,20,0,256,1,0,1]

theorem envBound12340 : H12AffineFastState.Bounded env12340 := by
  intro p hp
  have h : env12340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12339_12340 : H12AffineEnvironment.transform 6 8 env12339 = env12340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env12339 == env12340) = true)

def leafEnv12340 : List Nat := [2,4,8,16,0,17,8,256,1,272,2048,1,2057,0,2309,2051,0,2309,272,2308,1,0,17,3,20,2057,1,16,2049,0,1,2308,20,0,256,1,4,2050,0,1,0,1,1]

def active12340 : List Nat := [0,1,2,3,7,10]

def tree12340 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood12340 : H12WitnessSearch.Good tree12340 := H12GlobalWitnessIndex.good

theorem leafIdentity12340 : H12AffineFastState.composeSystem env12340 rootObs = leafEnv12340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env12340 rootObs == leafEnv12340) = true)

theorem terminalChecked12340 : H12PackedTerminal.terminalCheckFast leafEnv12340 active12340 tree12340 = true := by decide +kernel

def env12341 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,16384,32768,65536,1345,262144,524288,32769,1345,4194304,17665,98565,8328,541009,134217728,16384,541696,1073741824,1284,4294967296,256,4299260335,139198533,512]

theorem envBound12341 : H12AffineFastState.Bounded env12341 := by
  intro p hp
  have h : env12341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12225_12341 : H12AffineEnvironment.transform 11 1345 env12225 = env12341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env12225 == env12341) = true)

def env12342 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,65536,1345,262144,524288,32769,1345,4194304,65,98565,8328,525329,134217728,1344,524608,1073741824,1284,4294967296,256,4299260335,139198533,512]

theorem envBound12342 : H12AffineFastState.Bounded env12342 := by
  intro p hp
  have h : env12342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12341_12342 : H12AffineEnvironment.transform 13 1344 env12341 = env12342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env12341 == env12342) = true)

theorem identity12342 : scanCanonicalize (H12AffineFastState.compose env12342 (packedSelected [9,22] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound12342 : packedSelected [9,22] rootPS < 2^1333 := by decide +kernel

def env12343 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1297,32768,65536,1296,262144,524288,32769,1296,4194304,16,98565,8328,525329,134217728,1297,524561,1073741824,1284,4294967296,256,4299260335,139198484,512]

theorem envBound12343 : H12AffineFastState.Bounded env12343 := by
  intro p hp
  have h : env12343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12342_12343 : H12AffineEnvironment.transform 5 17 env12342 = env12343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env12342 == env12343) = true)

def env12344 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1297,32768,65536,1296,262144,524288,32769,1296,4194304,16,98565,8328,525329,4982440,1297,524561,1073741824,1284,4294967296,256,4299260335,1724,512]

theorem envBound12344 : H12AffineFastState.Bounded env12344 := by
  intro p hp
  have h : env12344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12343_12344 : H12AffineEnvironment.transform 26 4982440 env12343 = env12344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 4982440 env12343 == env12344) = true)

theorem identity12344 : scanCanonicalize (H12AffineFastState.compose env12344 (packedSelected [5,8,12,13,17,19,21,38,41] rootPS)) = affineNative (2^(8+1) ^^^ 428) := by decide +kernel

theorem selectedBound12344 : packedSelected [5,8,12,13,17,19,21,38,41] rootPS < 2^1333 := by decide +kernel

def env12345 : List Nat := [2,4,8,16,32,17,128,256,428,1024,2048,1296,8192,1297,32768,65536,1296,262144,524288,32769,1296,4194304,16,98565,8328,525329,4982020,1297,524561,1073741824,1284,4294967296,256,4299260335,1296,428]

theorem envBound12345 : H12AffineFastState.Bounded env12345 := by
  intro p hp
  have h : env12345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12344_12345 : H12AffineEnvironment.transform 8 428 env12344 = env12345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 428 env12344 == env12345) = true)

theorem identity12345 : scanCanonicalize (H12AffineFastState.compose env12345 (packedSelected [5,8,13,15,19] rootPS)) = affineNative (2^(29+1) ^^^ 4820106) := by decide +kernel

theorem selectedBound12345 : packedSelected [5,8,13,15,19] rootPS < 2^1333 := by decide +kernel

def env12346 : List Nat := [2,4,8,16,32,17,128,256,428,1024,2048,1296,8192,1297,32768,65536,1296,262144,524288,32769,1296,4194304,16,98565,8328,525329,4982020,1297,524561,4820106,1284,4294967296,256,4299260335,1296,428]

theorem envBound12346 : H12AffineFastState.Bounded env12346 := by
  intro p hp
  have h : env12346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12345_12346 : H12AffineEnvironment.transform 29 4820106 env12345 = env12346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4820106 env12345 == env12346) = true)

def env12347 : List Nat := [2,4,8,16,32,17,128,256,428,1024,2048,1296,8192,1297,32768,65536,1296,262144,524288,32769,1296,566400,16,98565,8328,525329,303492,1297,524561,75786,1284,4294967296,256,4295566639,1296,428]

theorem envBound12347 : H12AffineFastState.Bounded env12347 := by
  intro p hp
  have h : env12347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12346_12347 : H12AffineEnvironment.transform 21 566400 env12346 = env12347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 566400 env12346 == env12347) = true)

theorem identity12347 : scanCanonicalize (H12AffineFastState.compose env12347 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 98339) := by decide +kernel

theorem selectedBound12347 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env12348 : List Nat := [2,4,8,16,32,17,128,256,428,1024,2048,1296,8192,1297,32768,65536,1296,262144,524288,32769,1296,566400,16,98565,8328,525329,303492,1297,524561,75786,1284,98339,256,566540,1296,428]

theorem envBound12348 : H12AffineFastState.Bounded env12348 := by
  intro p hp
  have h : env12348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12347_12348 : H12AffineEnvironment.transform 31 98339 env12347 = env12348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 98339 env12347 == env12348) = true)

def env12349 : List Nat := [2,4,8,16,32,17,128,256,428,1024,2048,1296,8192,1297,32768,65536,1296,262144,272,32769,1296,42384,16,98565,8328,1281,303492,1297,1,75786,1284,98339,256,42012,1296,428]

theorem envBound12349 : H12AffineFastState.Bounded env12349 := by
  intro p hp
  have h : env12349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12348_12349 : H12AffineEnvironment.transform 18 272 env12348 = env12349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 272 env12348 == env12349) = true)

theorem identity12349 : scanCanonicalize (H12AffineFastState.compose env12349 (packedSelected [12] rootPS)) = affineNative (2^(15+1) ^^^ 44435) := by decide +kernel

theorem selectedBound12349 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env12350 : List Nat := [2,4,8,16,32,17,128,256,428,1024,2048,1296,8192,1297,32768,44435,1296,262144,272,32769,1296,42384,16,11414,8328,1281,303492,1297,1,34201,1284,11696,256,42012,1296,428]

theorem envBound12350 : H12AffineFastState.Bounded env12350 := by
  intro p hp
  have h : env12350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12349_12350 : H12AffineEnvironment.transform 15 44435 env12349 = env12350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 44435 env12349 == env12350) = true)

theorem identity12350 : scanCanonicalize (H12AffineFastState.compose env12350 (packedSelected [1,5,8,10,13] rootPS)) = affineNative (2^(17+1) ^^^ 3125) := by decide +kernel

theorem selectedBound12350 : packedSelected [1,5,8,10,13] rootPS < 2^1333 := by decide +kernel

def env12351 : List Nat := [2,4,8,16,32,17,128,256,428,1024,2048,1296,8192,1297,32768,44435,1296,3125,272,32769,1296,42384,16,11414,8328,1281,44465,1297,1,34201,1284,11696,256,42012,1296,428]

theorem envBound12351 : H12AffineFastState.Bounded env12351 := by
  intro p hp
  have h : env12351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12350_12351 : H12AffineEnvironment.transform 17 3125 env12350 = env12351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3125 env12350 == env12351) = true)

theorem identity12351 : scanCanonicalize (H12AffineFastState.compose env12351 (packedSelected [1,8,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound12351 : packedSelected [1,8,10] rootPS < 2^1333 := by decide +kernel

def env12352 : List Nat := [2,4,8,16,32,17,8,256,292,1024,2048,1296,8192,1297,32768,44315,1296,3125,272,32769,1296,42264,16,11294,8192,1281,44345,1297,1,34065,1284,11576,256,42012,1296,292]

theorem envBound12352 : H12AffineFastState.Bounded env12352 := by
  intro p hp
  have h : env12352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12351_12352 : H12AffineEnvironment.transform 6 8 env12351 = env12352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env12351 == env12352) = true)

theorem identity12352 : scanCanonicalize (H12AffineFastState.compose env12352 (packedSelected [4,9,11,18] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound12352 : packedSelected [4,9,11,18] rootPS < 2^1333 := by decide +kernel

def env12353 : List Nat := [2,4,8,16,32,17,8,256,292,1024,2048,1296,8192,1297,8460,3095,1296,3125,272,8461,1296,1044,16,11294,8192,1281,3125,1297,1,9245,1284,11576,256,1296,1296,292]

theorem envBound12353 : H12AffineFastState.Bounded env12353 := by
  intro p hp
  have h : env12353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12352_12353 : H12AffineEnvironment.transform 14 8460 env12352 = env12353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env12352 == env12353) = true)

theorem identity12353 : scanCanonicalize (H12AffineFastState.compose env12353 (packedSelected [3,5,8] rootPS)) = affineNative (2^(12+1) ^^^ 3101) := by decide +kernel

theorem selectedBound12353 : packedSelected [3,5,8] rootPS < 2^1333 := by decide +kernel

def env12354 : List Nat := [2,4,8,16,32,17,8,256,292,1024,2048,1296,3101,1297,3345,3095,1296,3125,272,3344,1296,1044,16,3,3101,1281,3125,1297,1,2048,1284,293,256,1296,1296,292]

theorem envBound12354 : H12AffineFastState.Bounded env12354 := by
  intro p hp
  have h : env12354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12353_12354 : H12AffineEnvironment.transform 12 3101 env12353 = env12354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3101 env12353 == env12354) = true)

theorem identity12354 : scanCanonicalize (H12AffineFastState.compose env12354 (packedSelected [0,2,4] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound12354 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env12355 : List Nat := [2,4,8,16,32,17,8,256,292,53,2048,293,2088,292,2340,2082,293,2048,272,2341,293,33,16,3,2088,308,2048,292,1,2048,305,293,256,293,293,292]

theorem envBound12355 : H12AffineFastState.Bounded env12355 := by
  intro p hp
  have h : env12355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12354_12355 : H12AffineEnvironment.transform 9 53 env12354 = env12355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env12354 == env12355) = true)

theorem identity12355 : scanCanonicalize (H12AffineFastState.compose env12355 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound12355 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env12356 : List Nat := [2,4,8,16,32,17,8,37,1,53,2048,0,2088,1,2049,2082,0,2048,53,2048,0,33,16,3,2088,17,2048,1,1,2048,20,0,37,0,0,1]

theorem envBound12356 : H12AffineFastState.Bounded env12356 := by
  intro p hp
  have h : env12356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12355_12356 : H12AffineEnvironment.transform 7 37 env12355 = env12356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env12355 == env12356) = true)

def env12357 : List Nat := [2,4,8,16,32,17,128,256,428,1024,2048,1296,8192,1297,32768,65536,1296,262144,273,32769,1296,42385,16,98565,8328,1280,303492,1297,0,75786,1284,98339,256,42013,1296,428]

theorem envBound12357 : H12AffineFastState.Bounded env12357 := by
  intro p hp
  have h : env12357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12348_12357 : H12AffineEnvironment.transform 18 273 env12348 = env12357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 273 env12348 == env12357) = true)

theorem identity12357 : scanCanonicalize (H12AffineFastState.compose env12357 (packedSelected [12] rootPS)) = affineNative (2^(17+1) ^^^ 33060) := by decide +kernel

theorem selectedBound12357 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env12358 : List Nat := [2,4,8,16,32,17,128,256,428,1024,2048,1296,8192,1297,32768,65536,1296,33060,273,32769,1296,42385,16,98565,8328,1280,8352,1297,0,75786,1284,98339,256,42013,1296,428]

theorem envBound12358 : H12AffineFastState.Bounded env12358 := by
  intro p hp
  have h : env12358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12357_12358 : H12AffineEnvironment.transform 17 33060 env12357 = env12358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 33060 env12357 == env12358) = true)

theorem identity12358 : scanCanonicalize (H12AffineFastState.compose env12358 (packedSelected [1,5,8,10,13] rootPS)) = affineNative (2^(15+1) ^^^ 3230) := by decide +kernel

theorem selectedBound12358 : packedSelected [1,5,8,10,13] rootPS < 2^1333 := by decide +kernel

def env12359 : List Nat := [2,4,8,16,32,17,128,256,428,1024,2048,1296,8192,1297,32768,3230,1296,33060,273,32769,1296,42385,16,36251,8328,1280,8352,1297,0,9364,1284,36029,256,42013,1296,428]

theorem envBound12359 : H12AffineFastState.Bounded env12359 := by
  intro p hp
  have h : env12359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12358_12359 : H12AffineEnvironment.transform 15 3230 env12358 = env12359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3230 env12358 == env12359) = true)

theorem identity12359 : scanCanonicalize (H12AffineFastState.compose env12359 (packedSelected [1] rootPS)) = affineNative (2^(14+1) ^^^ 3344) := by decide +kernel

theorem selectedBound12359 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12360 : List Nat := [2,4,8,16,32,17,128,256,428,1024,2048,1296,8192,1297,3344,3230,1296,3124,273,3345,1296,10369,16,139,8328,1280,8352,1297,0,9364,1284,429,256,10509,1296,428]

theorem envBound12360 : H12AffineFastState.Bounded env12360 := by
  intro p hp
  have h : env12360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12359_12360 : H12AffineEnvironment.transform 14 3344 env12359 = env12360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 3344 env12359 == env12360) = true)

theorem identity12360 : scanCanonicalize (H12AffineFastState.compose env12360 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 3100) := by decide +kernel

theorem selectedBound12360 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env12361 : List Nat := [2,4,8,16,32,17,128,256,428,1024,2048,1296,3100,1297,3344,3230,1296,3124,273,3345,1296,1181,16,139,3220,1280,3260,1297,0,2184,1284,429,256,1297,1296,428]

theorem envBound12361 : H12AffineFastState.Bounded env12361 := by
  intro p hp
  have h : env12361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12360_12361 : H12AffineEnvironment.transform 12 3100 env12360 = env12361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3100 env12360 == env12361) = true)

theorem identity12361 : scanCanonicalize (H12AffineFastState.compose env12361 (packedSelected [2,4,7] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound12361 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env12362 : List Nat := [2,4,8,16,32,17,128,173,1,1024,2048,1213,3100,1212,3261,3230,1213,3124,188,3260,1213,1181,16,139,3220,1197,3260,1212,0,2184,1193,0,173,1212,1213,1]

theorem envBound12362 : H12AffineFastState.Bounded env12362 := by
  intro p hp
  have h : env12362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12361_12362 : H12AffineEnvironment.transform 7 173 env12361 = env12362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env12361 == env12362) = true)

theorem identity12362 : scanCanonicalize (H12AffineFastState.compose env12362 (packedSelected [3] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound12362 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env12363 : List Nat := [2,4,8,16,32,17,128,173,1,52,2048,137,2088,136,2185,2218,137,2048,188,2184,137,169,16,139,2208,153,2184,136,0,2184,157,0,173,136,137,1]

theorem envBound12363 : H12AffineFastState.Bounded env12363 := by
  intro p hp
  have h : env12363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12362_12363 : H12AffineEnvironment.transform 9 52 env12362 = env12363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env12362 == env12363) = true)

theorem identity12363 : scanCanonicalize (H12AffineFastState.compose env12363 (packedSelected [0,2,4] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound12363 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env12364 : List Nat := [2,4,8,16,32,17,8,37,1,52,2048,1,2088,0,2049,2082,1,2048,52,2048,1,33,16,3,2088,17,2048,0,0,2048,21,0,37,0,1,1]

theorem envBound12364 : H12AffineFastState.Bounded env12364 := by
  intro p hp
  have h : env12364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12363_12364 : H12AffineEnvironment.transform 6 8 env12363 = env12364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env12363 == env12364) = true)

def env12365 : List Nat := [2,4,8,16,32,17,128,256,428,1024,2048,1296,8192,1297,32768,65536,1296,262144,524288,32769,1296,566401,16,98565,8328,525329,303493,1297,524561,75787,1284,4294967296,256,4295566638,1296,428]

theorem envBound12365 : H12AffineFastState.Bounded env12365 := by
  intro p hp
  have h : env12365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12346_12365 : H12AffineEnvironment.transform 21 566401 env12346 = env12365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 566401 env12346 == env12365) = true)

theorem identity12365 : scanCanonicalize (H12AffineFastState.compose env12365 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 74030) := by decide +kernel

theorem selectedBound12365 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env12366 : List Nat := [2,4,8,16,32,17,128,256,428,1024,2048,1296,8192,1297,32768,65536,1296,262144,524288,32769,1296,566401,16,98565,8328,525329,303493,1297,524561,75787,1284,74030,256,525312,1296,428]

theorem envBound12366 : H12AffineFastState.Bounded env12366 := by
  intro p hp
  have h : env12366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12365_12366 : H12AffineEnvironment.transform 31 74030 env12365 = env12366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 74030 env12365 == env12366) = true)

def env12367 : List Nat := [2,4,8,16,32,17,128,256,428,1024,2048,1296,8192,1297,32768,65536,1296,262144,272,32769,1296,42385,16,98565,8328,1281,303493,1297,1,75787,1284,74030,256,1296,1296,428]

theorem envBound12367 : H12AffineFastState.Bounded env12367 := by
  intro p hp
  have h : env12367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12366_12367 : H12AffineEnvironment.transform 18 272 env12366 = env12367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 272 env12366 == env12367) = true)

theorem identity12367 : scanCanonicalize (H12AffineFastState.compose env12367 (packedSelected [12] rootPS)) = affineNative (2^(15+1) ^^^ 44435) := by decide +kernel

theorem selectedBound12367 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env12368 : List Nat := [2,4,8,16,32,17,128,256,428,1024,2048,1296,8192,1297,32768,44435,1296,262144,272,32769,1296,42385,16,11414,8328,1281,303493,1297,1,34200,1284,36029,256,1296,1296,428]

theorem envBound12368 : H12AffineFastState.Bounded env12368 := by
  intro p hp
  have h : env12368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12367_12368 : H12AffineEnvironment.transform 15 44435 env12367 = env12368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 44435 env12367 == env12368) = true)

theorem identity12368 : scanCanonicalize (H12AffineFastState.compose env12368 (packedSelected [1,5,8,10,13] rootPS)) = affineNative (2^(17+1) ^^^ 3125) := by decide +kernel

theorem selectedBound12368 : packedSelected [1,5,8,10,13] rootPS < 2^1333 := by decide +kernel

def env12369 : List Nat := [2,4,8,16,32,17,128,256,428,1024,2048,1296,8192,1297,32768,44435,1296,3125,272,32769,1296,42385,16,11414,8328,1281,44464,1297,1,34200,1284,36029,256,1296,1296,428]

theorem envBound12369 : H12AffineFastState.Bounded env12369 := by
  intro p hp
  have h : env12369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12368_12369 : H12AffineEnvironment.transform 17 3125 env12368 = env12369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3125 env12368 == env12369) = true)

theorem identity12369 : scanCanonicalize (H12AffineFastState.compose env12369 (packedSelected [1,8,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound12369 : packedSelected [1,8,10] rootPS < 2^1333 := by decide +kernel

def env12370 : List Nat := [2,4,8,16,32,17,9,256,293,1024,2048,1296,8192,1297,32768,44314,1296,3125,272,32769,1296,42264,16,11295,8193,1281,44345,1297,1,34065,1284,35892,256,1296,1296,293]

theorem envBound12370 : H12AffineFastState.Bounded env12370 := by
  intro p hp
  have h : env12370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12369_12370 : H12AffineEnvironment.transform 6 9 env12369 = env12370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env12369 == env12370) = true)

theorem identity12370 : scanCanonicalize (H12AffineFastState.compose env12370 (packedSelected [4,9,11,18] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound12370 : packedSelected [4,9,11,18] rootPS < 2^1333 := by decide +kernel

def env12371 : List Nat := [2,4,8,16,32,17,9,256,293,1024,2048,1296,8192,1297,8460,3094,1296,3125,272,8461,1296,1044,16,11295,8193,1281,3125,1297,1,9245,1284,11576,256,1296,1296,293]

theorem envBound12371 : H12AffineFastState.Bounded env12371 := by
  intro p hp
  have h : env12371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12370_12371 : H12AffineEnvironment.transform 14 8460 env12370 = env12371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env12370 == env12371) = true)

theorem identity12371 : scanCanonicalize (H12AffineFastState.compose env12371 (packedSelected [3,5,8] rootPS)) = affineNative (2^(12+1) ^^^ 3101) := by decide +kernel

theorem selectedBound12371 : packedSelected [3,5,8] rootPS < 2^1333 := by decide +kernel

def env12372 : List Nat := [2,4,8,16,32,17,9,256,293,1024,2048,1296,3101,1297,3345,3094,1296,3125,272,3344,1296,1044,16,2,3100,1281,3125,1297,1,2048,1284,293,256,1296,1296,293]

theorem envBound12372 : H12AffineFastState.Bounded env12372 := by
  intro p hp
  have h : env12372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12371_12372 : H12AffineEnvironment.transform 12 3101 env12371 = env12372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3101 env12371 == env12372) = true)

theorem identity12372 : scanCanonicalize (H12AffineFastState.compose env12372 (packedSelected [0,2,4] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound12372 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env12373 : List Nat := [2,4,8,16,32,17,9,256,293,53,2048,293,2088,292,2340,2083,293,2048,272,2341,293,33,16,2,2089,308,2048,292,1,2048,305,293,256,293,293,293]

theorem envBound12373 : H12AffineFastState.Bounded env12373 := by
  intro p hp
  have h : env12373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12372_12373 : H12AffineEnvironment.transform 9 53 env12372 = env12373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env12372 == env12373) = true)

theorem identity12373 : scanCanonicalize (H12AffineFastState.compose env12373 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound12373 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env12374 : List Nat := [2,4,8,16,32,17,9,37,0,53,2048,0,2088,1,2049,2083,0,2048,53,2048,0,33,16,2,2089,17,2048,1,1,2048,20,0,37,0,0,0]

theorem envBound12374 : H12AffineFastState.Bounded env12374 := by
  intro p hp
  have h : env12374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12373_12374 : H12AffineEnvironment.transform 7 37 env12373 = env12374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env12373 == env12374) = true)

def leafEnv12374 : List Nat := [2,4,8,16,32,17,9,37,0,53,2048,0,2088,1,2049,2083,0,2048,53,2048,0,33,16,2,20,2089,1,17,2048,1,1,2048,20,0,37,0,4,2083,0,0,0,1,1]

def active12374 : List Nat := [0,1,2,3,4,10]

def tree12374 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood12374 : H12WitnessSearch.Good tree12374 := H12GlobalWitnessIndex.good

theorem leafIdentity12374 : H12AffineFastState.composeSystem env12374 rootObs = leafEnv12374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env12374 rootObs == leafEnv12374) = true)

theorem terminalChecked12374 : H12PackedTerminal.terminalCheckFast leafEnv12374 active12374 tree12374 = true := by decide +kernel

def env12375 : List Nat := [2,4,8,16,32,17,128,256,428,1024,2048,1296,8192,1297,32768,65536,1296,262144,273,32769,1296,42384,16,98565,8328,1280,303493,1297,0,75787,1284,74030,256,1297,1296,428]

theorem envBound12375 : H12AffineFastState.Bounded env12375 := by
  intro p hp
  have h : env12375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12366_12375 : H12AffineEnvironment.transform 18 273 env12366 = env12375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 273 env12366 == env12375) = true)

theorem identity12375 : scanCanonicalize (H12AffineFastState.compose env12375 (packedSelected [12] rootPS)) = affineNative (2^(17+1) ^^^ 33060) := by decide +kernel

theorem selectedBound12375 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env12376 : List Nat := [2,4,8,16,32,17,128,256,428,1024,2048,1296,8192,1297,32768,65536,1296,33060,273,32769,1296,42384,16,98565,8328,1280,8353,1297,0,75787,1284,74030,256,1297,1296,428]

theorem envBound12376 : H12AffineFastState.Bounded env12376 := by
  intro p hp
  have h : env12376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12375_12376 : H12AffineEnvironment.transform 17 33060 env12375 = env12376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 33060 env12375 == env12376) = true)

theorem identity12376 : scanCanonicalize (H12AffineFastState.compose env12376 (packedSelected [1,5,8,10,13] rootPS)) = affineNative (2^(15+1) ^^^ 3230) := by decide +kernel

theorem selectedBound12376 : packedSelected [1,5,8,10,13] rootPS < 2^1333 := by decide +kernel

def env12377 : List Nat := [2,4,8,16,32,17,128,256,428,1024,2048,1296,8192,1297,32768,3230,1296,33060,273,32769,1296,42384,16,36251,8328,1280,8353,1297,0,9365,1284,11696,256,1297,1296,428]

theorem envBound12377 : H12AffineFastState.Bounded env12377 := by
  intro p hp
  have h : env12377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12376_12377 : H12AffineEnvironment.transform 15 3230 env12376 = env12377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3230 env12376 == env12377) = true)

theorem identity12377 : scanCanonicalize (H12AffineFastState.compose env12377 (packedSelected [1] rootPS)) = affineNative (2^(14+1) ^^^ 3344) := by decide +kernel

theorem selectedBound12377 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12378 : List Nat := [2,4,8,16,32,17,128,256,428,1024,2048,1296,8192,1297,3344,3230,1296,3124,273,3345,1296,10368,16,139,8328,1280,8353,1297,0,9365,1284,11696,256,1297,1296,428]

theorem envBound12378 : H12AffineFastState.Bounded env12378 := by
  intro p hp
  have h : env12378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12377_12378 : H12AffineEnvironment.transform 14 3344 env12377 = env12378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 3344 env12377 == env12378) = true)

theorem identity12378 : scanCanonicalize (H12AffineFastState.compose env12378 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 3100) := by decide +kernel

theorem selectedBound12378 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env12379 : List Nat := [2,4,8,16,32,17,128,256,428,1024,2048,1296,3100,1297,3344,3230,1296,3124,273,3345,1296,1180,16,139,3220,1280,3261,1297,0,2185,1284,428,256,1297,1296,428]

theorem envBound12379 : H12AffineFastState.Bounded env12379 := by
  intro p hp
  have h : env12379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12378_12379 : H12AffineEnvironment.transform 12 3100 env12378 = env12379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3100 env12378 == env12379) = true)

theorem identity12379 : scanCanonicalize (H12AffineFastState.compose env12379 (packedSelected [2,4,7] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound12379 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env12380 : List Nat := [2,4,8,16,32,17,128,172,0,1024,2048,1212,3100,1213,3260,3230,1212,3124,189,3261,1212,1180,16,139,3220,1196,3261,1213,0,2185,1192,0,172,1213,1212,0]

theorem envBound12380 : H12AffineFastState.Bounded env12380 := by
  intro p hp
  have h : env12380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12379_12380 : H12AffineEnvironment.transform 7 172 env12379 = env12380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env12379 == env12380) = true)

theorem identity12380 : scanCanonicalize (H12AffineFastState.compose env12380 (packedSelected [3] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound12380 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env12381 : List Nat := [2,4,8,16,32,17,128,172,0,52,2048,136,2088,137,2184,2218,136,2048,189,2185,136,168,16,139,2208,152,2185,137,0,2185,156,0,172,137,136,0]

theorem envBound12381 : H12AffineFastState.Bounded env12381 := by
  intro p hp
  have h : env12381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12380_12381 : H12AffineEnvironment.transform 9 52 env12380 = env12381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env12380 == env12381) = true)

theorem identity12381 : scanCanonicalize (H12AffineFastState.compose env12381 (packedSelected [0,2,4] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound12381 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env12382 : List Nat := [2,4,8,16,32,17,9,37,0,52,2048,1,2088,0,2049,2083,1,2048,52,2048,1,33,16,2,2089,17,2048,0,0,2048,21,0,37,0,1,0]

theorem envBound12382 : H12AffineFastState.Bounded env12382 := by
  intro p hp
  have h : env12382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12381_12382 : H12AffineEnvironment.transform 6 9 env12381 = env12382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env12381 == env12382) = true)

def leafEnv12382 : List Nat := [2,4,8,16,32,17,9,37,0,52,2048,1,2088,0,2049,2083,1,2048,52,2048,1,33,16,2,21,2089,1,17,2048,0,0,2048,21,0,37,0,4,2083,1,0,0,0,1]

def active12382 : List Nat := [0,1,2,3,4,10]

def tree12382 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood12382 : H12WitnessSearch.Good tree12382 := H12GlobalWitnessIndex.good

theorem leafIdentity12382 : H12AffineFastState.composeSystem env12382 rootObs = leafEnv12382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env12382 rootObs == leafEnv12382) = true)

theorem terminalChecked12382 : H12PackedTerminal.terminalCheckFast leafEnv12382 active12382 tree12382 = true := by decide +kernel

def env12383 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1297,32768,65536,1296,262144,524288,32769,1296,4194304,16,98565,8328,525329,4982441,1297,524561,1073741824,1284,4294967296,256,4299260335,1725,512]

theorem envBound12383 : H12AffineFastState.Bounded env12383 := by
  intro p hp
  have h : env12383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12343_12383 : H12AffineEnvironment.transform 26 4982441 env12343 = env12383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 4982441 env12343 == env12383) = true)

def env12384 : List Nat := [2,4,8,16,32,17,128,256,428,1024,2048,1296,8192,1297,32768,65536,1296,262144,524288,32769,1296,4194304,16,98565,8328,525329,4982021,1297,524561,1073741824,1284,4294967296,256,4299260335,1297,428]

theorem envBound12384 : H12AffineFastState.Bounded env12384 := by
  intro p hp
  have h : env12384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12383_12384 : H12AffineEnvironment.transform 8 428 env12383 = env12384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 428 env12383 == env12384) = true)

theorem identity12384 : scanCanonicalize (H12AffineFastState.compose env12384 (packedSelected [1,3,5,8,12,13,15,17] rootPS)) = affineNative (2^(29+1) ^^^ 4301191) := by decide +kernel

theorem selectedBound12384 : packedSelected [1,3,5,8,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env12385 : List Nat := [2,4,8,16,32,17,128,256,428,1024,2048,1296,8192,1297,32768,65536,1296,262144,524288,32769,1296,4194304,16,98565,8328,525329,4982021,1297,524561,4301191,1284,4294967296,256,4299260335,1297,428]

theorem envBound12385 : H12AffineFastState.Bounded env12385 := by
  intro p hp
  have h : env12385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12384_12385 : H12AffineEnvironment.transform 29 4301191 env12384 = env12385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4301191 env12384 == env12385) = true)

theorem identity12385 : scanCanonicalize (H12AffineFastState.compose env12385 (packedSelected [5,8,13,15,19] rootPS)) = affineNative (2^(21+1) ^^^ 593327) := by decide +kernel

theorem selectedBound12385 : packedSelected [5,8,13,15,19] rootPS < 2^1333 := by decide +kernel

def env12386 : List Nat := [2,4,8,16,32,17,128,256,428,1024,2048,1296,8192,1297,32768,65536,1296,262144,524288,32769,1296,593327,16,98565,8328,525329,329898,1297,524561,568360,1284,4294967296,256,4295527424,1297,428]

theorem envBound12386 : H12AffineFastState.Bounded env12386 := by
  intro p hp
  have h : env12386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12385_12386 : H12AffineEnvironment.transform 21 593327 env12385 = env12386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 593327 env12385 == env12386) = true)

theorem identity12386 : scanCanonicalize (H12AffineFastState.compose env12386 (packedSelected [0,7,20] rootPS)) = affineNative (2^(18+1) ^^^ 1024) := by decide +kernel

theorem selectedBound12386 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env12387 : List Nat := [2,4,8,16,32,17,128,256,428,1024,2048,1296,8192,1297,32768,65536,1296,262144,1024,32769,1296,68015,16,98565,8328,17,329898,1297,1297,43048,1284,4294967296,256,4295002112,1297,428]

theorem envBound12387 : H12AffineFastState.Bounded env12387 := by
  intro p hp
  have h : env12387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12386_12387 : H12AffineEnvironment.transform 18 1024 env12386 = env12387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env12386 == env12387) = true)

theorem identity12387 : scanCanonicalize (H12AffineFastState.compose env12387 (packedSelected [1,3,5] rootPS)) = affineNative (2^(17+1) ^^^ 41121) := by decide +kernel

theorem selectedBound12387 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env12388 : List Nat := [2,4,8,16,32,17,128,256,428,1024,2048,1296,8192,1297,32768,65536,1296,41121,1024,32769,1296,68015,16,98565,8328,17,108555,1297,1297,43048,1284,4294967296,256,4295002112,1297,428]

theorem envBound12388 : H12AffineFastState.Bounded env12388 := by
  intro p hp
  have h : env12388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12387_12388 : H12AffineEnvironment.transform 17 41121 env12387 = env12388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 41121 env12387 == env12388) = true)

theorem identity12388 : scanCanonicalize (H12AffineFastState.compose env12388 (packedSelected [1,3,8] rootPS)) = affineNative (2^(15+1) ^^^ 33030) := by decide +kernel

theorem selectedBound12388 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env12389 : List Nat := [2,4,8,16,32,17,128,256,428,1024,2048,1296,8192,1297,32768,33030,1296,41121,1024,32769,1296,34985,16,3,8328,17,10509,1297,1297,43048,1284,4294967296,256,4295002112,1297,428]

theorem envBound12389 : H12AffineFastState.Bounded env12389 := by
  intro p hp
  have h : env12389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12388_12389 : H12AffineEnvironment.transform 15 33030 env12388 = env12389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33030 env12388 == env12389) = true)

theorem identity12389 : scanCanonicalize (H12AffineFastState.compose env12389 (packedSelected [0,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound12389 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env12390 : List Nat := [2,4,8,16,32,17,128,256,428,1024,0,1296,8192,1297,32768,33030,1296,41121,1024,32769,1296,32937,16,3,8328,17,8461,1297,1297,41000,1284,4294967296,256,4295000064,1297,428]

theorem envBound12390 : H12AffineFastState.Bounded env12390 := by
  intro p hp
  have h : env12390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12389_12390 : H12AffineEnvironment.transform 10 0 env12389 = env12390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env12389 == env12390) = true)

theorem identity12390 : scanCanonicalize (H12AffineFastState.compose env12390 (packedSelected [3] rootPS)) = affineNative (2^(9+1) ^^^ 408) := by decide +kernel

theorem selectedBound12390 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env12391 : List Nat := [2,4,8,16,32,17,128,256,428,408,0,136,8192,137,32768,33030,136,41121,408,32769,136,32937,16,3,8328,17,8461,137,137,41000,156,4294967296,256,4295000064,137,428]

theorem envBound12391 : H12AffineFastState.Bounded env12391 := by
  intro p hp
  have h : env12391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12390_12391 : H12AffineEnvironment.transform 9 408 env12390 = env12391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 408 env12390 == env12391) = true)

theorem identity12391 : scanCanonicalize (H12AffineFastState.compose env12391 (packedSelected [0,1,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound12391 : packedSelected [0,1,4,7,9] rootPS < 2^1333 := by decide +kernel

def env12392 : List Nat := [2,4,8,16,32,17,128,256,428,408,0,136,269,137,32768,33030,136,33196,408,32769,136,32937,16,3,389,17,0,137,137,33061,156,4294967296,256,4295000064,137,428]

theorem envBound12392 : H12AffineFastState.Bounded env12392 := by
  intro p hp
  have h : env12392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12391_12392 : H12AffineEnvironment.transform 12 269 env12391 = env12392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env12391 == env12392) = true)

theorem identity12392 : scanCanonicalize (H12AffineFastState.compose env12392 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 33060) := by decide +kernel

theorem selectedBound12392 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12393 : List Nat := [2,4,8,16,32,17,128,256,428,408,0,136,269,137,32768,33030,136,33196,408,32769,136,32937,16,3,389,17,0,137,137,33061,156,33060,256,292,137,428]

theorem envBound12393 : H12AffineFastState.Bounded env12393 := by
  intro p hp
  have h : env12393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12392_12393 : H12AffineEnvironment.transform 31 33060 env12392 = env12393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 33060 env12392 == env12393) = true)

def env12394 : List Nat := [2,4,8,16,32,17,128,256,429,1024,2048,1296,8192,1297,32768,65536,1296,262144,524288,32769,1296,4194304,16,98565,8328,525329,4982020,1297,524561,1073741824,1284,4294967296,256,4299260335,1296,429]

theorem envBound12394 : H12AffineFastState.Bounded env12394 := by
  intro p hp
  have h : env12394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12383_12394 : H12AffineEnvironment.transform 8 429 env12383 = env12394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 429 env12383 == env12394) = true)

theorem identity12394 : scanCanonicalize (H12AffineFastState.compose env12394 (packedSelected [5,8,13,15,19] rootPS)) = affineNative (2^(29+1) ^^^ 4820106) := by decide +kernel

theorem selectedBound12394 : packedSelected [5,8,13,15,19] rootPS < 2^1333 := by decide +kernel

def env12395 : List Nat := [2,4,8,16,32,17,128,256,429,1024,2048,1296,8192,1297,32768,65536,1296,262144,524288,32769,1296,4194304,16,98565,8328,525329,4982020,1297,524561,4820106,1284,4294967296,256,4299260335,1296,429]

theorem envBound12395 : H12AffineFastState.Bounded env12395 := by
  intro p hp
  have h : env12395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12394_12395 : H12AffineEnvironment.transform 29 4820106 env12394 = env12395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4820106 env12394 == env12395) = true)

def env12396 : List Nat := [2,4,8,16,32,17,128,256,429,1024,2048,1296,8192,1297,32768,65536,1296,262144,524288,32769,1296,566400,16,98565,8328,525329,303492,1297,524561,75786,1284,4294967296,256,4295566639,1296,429]

theorem envBound12396 : H12AffineFastState.Bounded env12396 := by
  intro p hp
  have h : env12396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12395_12396 : H12AffineEnvironment.transform 21 566400 env12395 = env12396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 566400 env12395 == env12396) = true)

theorem identity12396 : scanCanonicalize (H12AffineFastState.compose env12396 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 98339) := by decide +kernel

theorem selectedBound12396 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env12397 : List Nat := [2,4,8,16,32,17,128,256,429,1024,2048,1296,8192,1297,32768,65536,1296,262144,524288,32769,1296,566400,16,98565,8328,525329,303492,1297,524561,75786,1284,98339,256,566540,1296,429]

theorem envBound12397 : H12AffineFastState.Bounded env12397 := by
  intro p hp
  have h : env12397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12396_12397 : H12AffineEnvironment.transform 31 98339 env12396 = env12397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 98339 env12396 == env12397) = true)

def env12398 : List Nat := [2,4,8,16,32,17,128,256,429,1024,2048,1296,8192,1297,32768,65536,1296,262144,272,32769,1296,42384,16,98565,8328,1281,303492,1297,1,75786,1284,98339,256,42012,1296,429]

theorem envBound12398 : H12AffineFastState.Bounded env12398 := by
  intro p hp
  have h : env12398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12397_12398 : H12AffineEnvironment.transform 18 272 env12397 = env12398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 272 env12397 == env12398) = true)

theorem identity12398 : scanCanonicalize (H12AffineFastState.compose env12398 (packedSelected [12] rootPS)) = affineNative (2^(15+1) ^^^ 43139) := by decide +kernel

theorem selectedBound12398 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env12399 : List Nat := [2,4,8,16,32,17,128,256,429,1024,2048,1296,8192,1297,32768,43139,1296,262144,272,32769,1296,42384,16,10630,8328,1281,303492,1297,1,32905,1284,10400,256,42012,1296,429]

theorem envBound12399 : H12AffineFastState.Bounded env12399 := by
  intro p hp
  have h : env12399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12398_12399 : H12AffineEnvironment.transform 15 43139 env12398 = env12399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 43139 env12398 == env12399) = true)

theorem identity12399 : scanCanonicalize (H12AffineFastState.compose env12399 (packedSelected [1,5,8,10,13] rootPS)) = affineNative (2^(17+1) ^^^ 2341) := by decide +kernel

theorem selectedBound12399 : packedSelected [1,5,8,10,13] rootPS < 2^1333 := by decide +kernel

def env12400 : List Nat := [2,4,8,16,32,17,128,256,429,1024,2048,1296,8192,1297,32768,43139,1296,2341,272,32769,1296,42384,16,10630,8328,1281,43169,1297,1,32905,1284,10400,256,42012,1296,429]

theorem envBound12400 : H12AffineFastState.Bounded env12400 := by
  intro p hp
  have h : env12400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12399_12400 : H12AffineEnvironment.transform 17 2341 env12399 = env12400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2341 env12399 == env12400) = true)

theorem identity12400 : scanCanonicalize (H12AffineFastState.compose env12400 (packedSelected [1,8,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound12400 : packedSelected [1,8,10] rootPS < 2^1333 := by decide +kernel

def env12401 : List Nat := [2,4,8,16,32,17,8,256,293,1024,2048,1296,8192,1297,32768,43019,1296,2341,272,32769,1296,42264,16,10510,8192,1281,43049,1297,1,32769,1284,10280,256,42012,1296,293]

theorem envBound12401 : H12AffineFastState.Bounded env12401 := by
  intro p hp
  have h : env12401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12400_12401 : H12AffineEnvironment.transform 6 8 env12400 = env12401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env12400 == env12401) = true)

theorem identity12401 : scanCanonicalize (H12AffineFastState.compose env12401 (packedSelected [3,4,5,8,9,11,18] rootPS)) = affineNative (2^(14+1) ^^^ 2049) := by decide +kernel

theorem selectedBound12401 : packedSelected [3,4,5,8,9,11,18] rootPS < 2^1333 := by decide +kernel

def env12402 : List Nat := [2,4,8,16,32,17,8,256,293,1024,2048,1296,8192,1297,2049,8202,1296,2341,272,2048,1296,11545,16,10510,8192,1281,8232,1297,1,2048,1284,10280,256,11293,1296,293]

theorem envBound12402 : H12AffineFastState.Bounded env12402 := by
  intro p hp
  have h : env12402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12401_12402 : H12AffineEnvironment.transform 14 2049 env12401 = env12402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2049 env12401 == env12402) = true)

theorem identity12402 : scanCanonicalize (H12AffineFastState.compose env12402 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound12402 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env12403 : List Nat := [2,4,8,16,32,17,8,256,293,272,2048,0,8192,1,2049,8202,0,2341,272,2048,0,10249,16,10510,8192,17,8232,1,1,2048,20,10280,256,10509,0,293]

theorem envBound12403 : H12AffineFastState.Bounded env12403 := by
  intro p hp
  have h : env12403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12402_12403 : H12AffineEnvironment.transform 9 272 env12402 = env12403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env12402 == env12403) = true)

theorem identity12403 : scanCanonicalize (H12AffineFastState.compose env12403 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 2317) := by decide +kernel

theorem selectedBound12403 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12404 : List Nat := [2,4,8,16,32,17,8,256,293,272,2048,0,2317,1,2049,2311,0,2341,272,2048,0,260,16,3,2317,17,2341,1,1,2048,20,293,256,0,0,293]

theorem envBound12404 : H12AffineFastState.Bounded env12404 := by
  intro p hp
  have h : env12404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12403_12404 : H12AffineEnvironment.transform 12 2317 env12403 = env12404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2317 env12403 == env12404) = true)

theorem identity12404 : scanCanonicalize (H12AffineFastState.compose env12404 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound12404 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12405 : List Nat := [2,4,8,16,32,17,8,36,1,52,2048,0,2089,1,2049,2083,0,2049,52,2048,0,32,16,3,2089,17,2049,1,1,2048,20,1,36,0,0,1]

theorem envBound12405 : H12AffineFastState.Bounded env12405 := by
  intro p hp
  have h : env12405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12404_12405 : H12AffineEnvironment.transform 7 36 env12404 = env12405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env12404 == env12405) = true)

theorem identity12405 : scanCanonicalize (H12AffineFastState.compose env12405 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound12405 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12406 : List Nat := [2,4,8,16,1,17,8,5,1,21,2048,0,2056,1,2049,2050,0,2049,21,2048,0,1,16,3,2056,17,2049,1,1,2048,20,1,5,0,0,1]

theorem envBound12406 : H12AffineFastState.Bounded env12406 := by
  intro p hp
  have h : env12406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12405_12406 : H12AffineEnvironment.transform 4 1 env12405 = env12406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env12405 == env12406) = true)

def env12407 : List Nat := [2,4,8,16,32,17,128,256,429,1024,2048,1296,8192,1297,32768,65536,1296,262144,273,32769,1296,42385,16,98565,8328,1280,303492,1297,0,75786,1284,98339,256,42013,1296,429]

theorem envBound12407 : H12AffineFastState.Bounded env12407 := by
  intro p hp
  have h : env12407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12397_12407 : H12AffineEnvironment.transform 18 273 env12397 = env12407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 273 env12397 == env12407) = true)

theorem identity12407 : scanCanonicalize (H12AffineFastState.compose env12407 (packedSelected [12] rootPS)) = affineNative (2^(17+1) ^^^ 33845) := by decide +kernel

theorem selectedBound12407 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env12408 : List Nat := [2,4,8,16,32,17,128,256,429,1024,2048,1296,8192,1297,32768,65536,1296,33845,273,32769,1296,42385,16,98565,8328,1280,9649,1297,0,75786,1284,98339,256,42013,1296,429]

theorem envBound12408 : H12AffineFastState.Bounded env12408 := by
  intro p hp
  have h : env12408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12407_12408 : H12AffineEnvironment.transform 17 33845 env12407 = env12408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 33845 env12407 == env12408) = true)

theorem identity12408 : scanCanonicalize (H12AffineFastState.compose env12408 (packedSelected [1,5,8,10,13] rootPS)) = affineNative (2^(15+1) ^^^ 3230) := by decide +kernel

theorem selectedBound12408 : packedSelected [1,5,8,10,13] rootPS < 2^1333 := by decide +kernel

def env12409 : List Nat := [2,4,8,16,32,17,128,256,429,1024,2048,1296,8192,1297,32768,3230,1296,33845,273,32769,1296,42385,16,36251,8328,1280,9649,1297,0,9364,1284,36029,256,42013,1296,429]

theorem envBound12409 : H12AffineFastState.Bounded env12409 := by
  intro p hp
  have h : env12409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12408_12409 : H12AffineEnvironment.transform 15 3230 env12408 = env12409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3230 env12408 == env12409) = true)

theorem identity12409 : scanCanonicalize (H12AffineFastState.compose env12409 (packedSelected [1] rootPS)) = affineNative (2^(14+1) ^^^ 2049) := by decide +kernel

theorem selectedBound12409 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12410 : List Nat := [2,4,8,16,32,17,128,256,429,1024,2048,1296,8192,1297,2049,3230,1296,3124,273,2048,1296,11664,16,1434,8328,1280,9649,1297,0,9364,1284,1212,256,11292,1296,429]

theorem envBound12410 : H12AffineFastState.Bounded env12410 := by
  intro p hp
  have h : env12410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12409_12410 : H12AffineEnvironment.transform 14 2049 env12409 = env12410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2049 env12409 == env12410) = true)

theorem identity12410 : scanCanonicalize (H12AffineFastState.compose env12410 (packedSelected [0,3,4,7,8,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 2317) := by decide +kernel

theorem selectedBound12410 : packedSelected [0,3,4,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env12411 : List Nat := [2,4,8,16,32,17,128,256,429,1024,2048,1296,2317,1297,2049,3230,1296,3124,273,2048,1296,1181,16,1434,2437,1280,3260,1297,0,3481,1284,1212,256,1297,1296,429]

theorem envBound12411 : H12AffineFastState.Bounded env12411 := by
  intro p hp
  have h : env12411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12410_12411 : H12AffineEnvironment.transform 12 2317 env12410 = env12411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2317 env12410 == env12411) = true)

theorem identity12411 : scanCanonicalize (H12AffineFastState.compose env12411 (packedSelected [0,3,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound12411 : packedSelected [0,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env12412 : List Nat := [2,4,8,16,32,17,8,256,293,1024,2048,1296,2317,1297,2049,3094,1296,3124,273,2048,1296,1045,16,1298,2317,1280,3124,1297,0,3345,1284,1076,256,1297,1296,293]

theorem envBound12412 : H12AffineFastState.Bounded env12412 := by
  intro p hp
  have h : env12412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12411_12412 : H12AffineEnvironment.transform 6 8 env12411 = env12412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env12411 == env12412) = true)

theorem identity12412 : scanCanonicalize (H12AffineFastState.compose env12412 (packedSelected [0,2,3,4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound12412 : packedSelected [0,2,3,4] rootPS < 2^1333 := by decide +kernel

def env12413 : List Nat := [2,4,8,16,32,17,8,37,0,1024,2048,1077,2088,1076,2049,3094,1077,3124,52,2048,1077,1045,16,1079,2088,1061,3124,1076,0,3124,1057,1076,37,1076,1077,0]

theorem envBound12413 : H12AffineFastState.Bounded env12413 := by
  intro p hp
  have h : env12413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12412_12413 : H12AffineEnvironment.transform 7 37 env12412 = env12413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env12412 == env12413) = true)

def env12414 : List Nat := [2,4,8,16,32,17,128,256,429,1024,2048,1296,8192,1297,32768,65536,1296,262144,524288,32769,1296,566401,16,98565,8328,525329,303493,1297,524561,75787,1284,4294967296,256,4295566638,1296,429]

theorem envBound12414 : H12AffineFastState.Bounded env12414 := by
  intro p hp
  have h : env12414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12395_12414 : H12AffineEnvironment.transform 21 566401 env12395 = env12414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 566401 env12395 == env12414) = true)

theorem identity12414 : scanCanonicalize (H12AffineFastState.compose env12414 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 74030) := by decide +kernel

theorem selectedBound12414 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env12415 : List Nat := [2,4,8,16,32,17,128,256,429,1024,2048,1296,8192,1297,32768,65536,1296,262144,524288,32769,1296,566401,16,98565,8328,525329,303493,1297,524561,75787,1284,74030,256,525312,1296,429]

theorem envBound12415 : H12AffineFastState.Bounded env12415 := by
  intro p hp
  have h : env12415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12414_12415 : H12AffineEnvironment.transform 31 74030 env12414 = env12415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 74030 env12414 == env12415) = true)

def env12416 : List Nat := [2,4,8,16,32,17,128,256,429,1024,2048,1296,8192,1297,32768,65536,1296,262144,272,32769,1296,42385,16,98565,8328,1281,303493,1297,1,75787,1284,74030,256,1296,1296,429]

theorem envBound12416 : H12AffineFastState.Bounded env12416 := by
  intro p hp
  have h : env12416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12415_12416 : H12AffineEnvironment.transform 18 272 env12415 = env12416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 272 env12415 == env12416) = true)

theorem identity12416 : scanCanonicalize (H12AffineFastState.compose env12416 (packedSelected [12] rootPS)) = affineNative (2^(15+1) ^^^ 43139) := by decide +kernel

theorem selectedBound12416 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env12417 : List Nat := [2,4,8,16,32,17,128,256,429,1024,2048,1296,8192,1297,32768,43139,1296,262144,272,32769,1296,42385,16,10630,8328,1281,303493,1297,1,32904,1284,35245,256,1296,1296,429]

theorem envBound12417 : H12AffineFastState.Bounded env12417 := by
  intro p hp
  have h : env12417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12416_12417 : H12AffineEnvironment.transform 15 43139 env12416 = env12417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 43139 env12416 == env12417) = true)

theorem identity12417 : scanCanonicalize (H12AffineFastState.compose env12417 (packedSelected [1,5,8,10,13] rootPS)) = affineNative (2^(17+1) ^^^ 2341) := by decide +kernel

theorem selectedBound12417 : packedSelected [1,5,8,10,13] rootPS < 2^1333 := by decide +kernel

def env12418 : List Nat := [2,4,8,16,32,17,128,256,429,1024,2048,1296,8192,1297,32768,43139,1296,2341,272,32769,1296,42385,16,10630,8328,1281,43168,1297,1,32904,1284,35245,256,1296,1296,429]

theorem envBound12418 : H12AffineFastState.Bounded env12418 := by
  intro p hp
  have h : env12418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12417_12418 : H12AffineEnvironment.transform 17 2341 env12417 = env12418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2341 env12417 == env12418) = true)

theorem identity12418 : scanCanonicalize (H12AffineFastState.compose env12418 (packedSelected [1,8,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound12418 : packedSelected [1,8,10] rootPS < 2^1333 := by decide +kernel

def env12419 : List Nat := [2,4,8,16,32,17,9,256,292,1024,2048,1296,8192,1297,32768,43018,1296,2341,272,32769,1296,42264,16,10511,8193,1281,43049,1297,1,32769,1284,35108,256,1296,1296,292]

theorem envBound12419 : H12AffineFastState.Bounded env12419 := by
  intro p hp
  have h : env12419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12418_12419 : H12AffineEnvironment.transform 6 9 env12418 = env12419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env12418 == env12419) = true)

theorem identity12419 : scanCanonicalize (H12AffineFastState.compose env12419 (packedSelected [3,4,5,8,9,11,18] rootPS)) = affineNative (2^(14+1) ^^^ 2049) := by decide +kernel

theorem selectedBound12419 : packedSelected [3,4,5,8,9,11,18] rootPS < 2^1333 := by decide +kernel

def env12420 : List Nat := [2,4,8,16,32,17,9,256,292,1024,2048,1296,8192,1297,2049,8203,1296,2341,272,2048,1296,11545,16,10511,8193,1281,8232,1297,1,2048,1284,293,256,1296,1296,292]

theorem envBound12420 : H12AffineFastState.Bounded env12420 := by
  intro p hp
  have h : env12420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12419_12420 : H12AffineEnvironment.transform 14 2049 env12419 = env12420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2049 env12419 == env12420) = true)

theorem identity12420 : scanCanonicalize (H12AffineFastState.compose env12420 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound12420 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env12421 : List Nat := [2,4,8,16,32,17,9,256,292,272,2048,0,8192,1,2049,8203,0,2341,272,2048,0,10249,16,10511,8193,17,8232,1,1,2048,20,293,256,0,0,292]

theorem envBound12421 : H12AffineFastState.Bounded env12421 := by
  intro p hp
  have h : env12421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12420_12421 : H12AffineEnvironment.transform 9 272 env12420 = env12421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env12420 == env12421) = true)

theorem identity12421 : scanCanonicalize (H12AffineFastState.compose env12421 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 2317) := by decide +kernel

theorem selectedBound12421 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12422 : List Nat := [2,4,8,16,32,17,9,256,292,272,2048,0,2317,1,2049,2310,0,2341,272,2048,0,260,16,2,2316,17,2341,1,1,2048,20,293,256,0,0,292]

theorem envBound12422 : H12AffineFastState.Bounded env12422 := by
  intro p hp
  have h : env12422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12421_12422 : H12AffineEnvironment.transform 12 2317 env12421 = env12422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2317 env12421 == env12422) = true)

def env12423 : List Nat := [2,4,8,16,32,17,128,256,429,1024,2048,1296,8192,1297,32768,65536,1296,262144,273,32769,1296,42384,16,98565,8328,1280,303493,1297,0,75787,1284,74030,256,1297,1296,429]

theorem envBound12423 : H12AffineFastState.Bounded env12423 := by
  intro p hp
  have h : env12423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12415_12423 : H12AffineEnvironment.transform 18 273 env12415 = env12423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 273 env12415 == env12423) = true)

theorem identity12423 : scanCanonicalize (H12AffineFastState.compose env12423 (packedSelected [12] rootPS)) = affineNative (2^(17+1) ^^^ 33845) := by decide +kernel

theorem selectedBound12423 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env12424 : List Nat := [2,4,8,16,32,17,128,256,429,1024,2048,1296,8192,1297,32768,65536,1296,33845,273,32769,1296,42384,16,98565,8328,1280,9648,1297,0,75787,1284,74030,256,1297,1296,429]

theorem envBound12424 : H12AffineFastState.Bounded env12424 := by
  intro p hp
  have h : env12424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12423_12424 : H12AffineEnvironment.transform 17 33845 env12423 = env12424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 33845 env12423 == env12424) = true)

theorem identity12424 : scanCanonicalize (H12AffineFastState.compose env12424 (packedSelected [1,5,8,10,13] rootPS)) = affineNative (2^(15+1) ^^^ 3230) := by decide +kernel

theorem selectedBound12424 : packedSelected [1,5,8,10,13] rootPS < 2^1333 := by decide +kernel

def env12425 : List Nat := [2,4,8,16,32,17,128,256,429,1024,2048,1296,8192,1297,32768,3230,1296,33845,273,32769,1296,42384,16,36251,8328,1280,9648,1297,0,9365,1284,11696,256,1297,1296,429]

theorem envBound12425 : H12AffineFastState.Bounded env12425 := by
  intro p hp
  have h : env12425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12424_12425 : H12AffineEnvironment.transform 15 3230 env12424 = env12425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3230 env12424 == env12425) = true)

theorem identity12425 : scanCanonicalize (H12AffineFastState.compose env12425 (packedSelected [1] rootPS)) = affineNative (2^(14+1) ^^^ 2049) := by decide +kernel

theorem selectedBound12425 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12426 : List Nat := [2,4,8,16,32,17,128,256,429,1024,2048,1296,8192,1297,2049,3230,1296,3124,273,2048,1296,11665,16,1434,8328,1280,9648,1297,0,9365,1284,11696,256,1297,1296,429]

theorem envBound12426 : H12AffineFastState.Bounded env12426 := by
  intro p hp
  have h : env12426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12425_12426 : H12AffineEnvironment.transform 14 2049 env12425 = env12426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2049 env12425 == env12426) = true)

theorem identity12426 : scanCanonicalize (H12AffineFastState.compose env12426 (packedSelected [0,3,4,7,8,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 2317) := by decide +kernel

theorem selectedBound12426 : packedSelected [0,3,4,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env12427 : List Nat := [2,4,8,16,32,17,128,256,429,1024,2048,1296,2317,1297,2049,3230,1296,3124,273,2048,1296,1180,16,1434,2437,1280,3261,1297,0,3480,1284,1213,256,1297,1296,429]

theorem envBound12427 : H12AffineFastState.Bounded env12427 := by
  intro p hp
  have h : env12427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12426_12427 : H12AffineEnvironment.transform 12 2317 env12426 = env12427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2317 env12426 == env12427) = true)

theorem identity12427 : scanCanonicalize (H12AffineFastState.compose env12427 (packedSelected [0,3,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound12427 : packedSelected [0,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env12428 : List Nat := [2,4,8,16,32,17,9,256,292,1024,2048,1296,2317,1297,2049,3095,1296,3124,273,2048,1296,1045,16,1299,2316,1280,3124,1297,0,3345,1284,1076,256,1297,1296,292]

theorem envBound12428 : H12AffineFastState.Bounded env12428 := by
  intro p hp
  have h : env12428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12427_12428 : H12AffineEnvironment.transform 6 9 env12427 = env12428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env12427 == env12428) = true)

theorem identity12428 : scanCanonicalize (H12AffineFastState.compose env12428 (packedSelected [0,2,3,4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound12428 : packedSelected [0,2,3,4] rootPS < 2^1333 := by decide +kernel

def env12429 : List Nat := [2,4,8,16,32,17,9,37,1,1024,2048,1077,2088,1076,2049,3095,1077,3124,52,2048,1077,1045,16,1078,2089,1061,3124,1076,0,3124,1057,1076,37,1076,1077,1]

theorem envBound12429 : H12AffineFastState.Bounded env12429 := by
  intro p hp
  have h : env12429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12428_12429 : H12AffineEnvironment.transform 7 37 env12428 = env12429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env12428 == env12429) = true)

theorem identity12429 : scanCanonicalize (H12AffineFastState.compose env12429 (packedSelected [0,2] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound12429 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env12430 : List Nat := [2,4,8,16,32,17,9,37,1,52,2048,1,2088,0,2049,2083,1,2048,52,2048,1,33,16,2,2089,17,2048,0,0,2048,21,0,37,0,1,1]

theorem envBound12430 : H12AffineFastState.Bounded env12430 := by
  intro p hp
  have h : env12430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12429_12430 : H12AffineEnvironment.transform 9 52 env12429 = env12430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env12429 == env12430) = true)

def env12431 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,32768,65536,1345,262144,524288,32769,1345,4194304,64,98565,8328,525328,134217728,1345,524609,1073741824,1284,4294967296,256,4299260335,139198533,512]

theorem envBound12431 : H12AffineFastState.Bounded env12431 := by
  intro p hp
  have h : env12431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12341_12431 : H12AffineEnvironment.transform 13 1345 env12341 = env12431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env12341 == env12431) = true)

theorem identity12431 : scanCanonicalize (H12AffineFastState.compose env12431 (packedSelected [9,22] rootPS)) = affineNative (2^(18+1) ^^^ 1024) := by decide +kernel

theorem selectedBound12431 : packedSelected [9,22] rootPS < 2^1333 := by decide +kernel

def env12432 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,32768,65536,1345,262144,1024,32769,1345,4194304,64,98565,8328,16,134217728,1345,1345,1073741824,1284,4294967296,256,4299260335,138675269,512]

theorem envBound12432 : H12AffineFastState.Bounded env12432 := by
  intro p hp
  have h : env12432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12431_12432 : H12AffineEnvironment.transform 18 1024 env12431 = env12432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env12431 == env12432) = true)

theorem identity12432 : scanCanonicalize (H12AffineFastState.compose env12432 (packedSelected [3,5,8,28] rootPS)) = affineNative (2^(26+1) ^^^ 4456708) := by decide +kernel

theorem selectedBound12432 : packedSelected [3,5,8,28] rootPS < 2^1333 := by decide +kernel

def env12433 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,32768,65536,1345,262144,1024,32769,1345,4194304,64,98565,8328,16,4456708,1345,1345,1073741824,1284,4294967296,256,4299260335,1345,512]

theorem envBound12433 : H12AffineFastState.Bounded env12433 := by
  intro p hp
  have h : env12433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12432_12433 : H12AffineEnvironment.transform 26 4456708 env12432 = env12433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 4456708 env12432 == env12433) = true)

def env12434 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,1,8192,1,32768,65536,1,262144,320,32769,1,4194304,64,98565,8328,16,4456708,1,1,1073741824,68,4294967296,256,4299260335,1,512]

theorem envBound12434 : H12AffineFastState.Bounded env12434 := by
  intro p hp
  have h : env12434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12433_12434 : H12AffineEnvironment.transform 9 320 env12433 = env12434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env12433 == env12434) = true)

theorem identity12434 : scanCanonicalize (H12AffineFastState.compose env12434 (packedSelected [1,3,5,8,10] rootPS)) = affineNative (2^(21+1) ^^^ 362714) := by decide +kernel

theorem selectedBound12434 : packedSelected [1,3,5,8,10] rootPS < 2^1333 := by decide +kernel

def env12435 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,1,8192,1,32768,65536,1,262144,320,32769,1,362714,64,98565,8328,16,100830,1,1,1073741824,68,4294967296,256,4295231861,1,512]

theorem envBound12435 : H12AffineFastState.Bounded env12435 := by
  intro p hp
  have h : env12435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12434_12435 : H12AffineEnvironment.transform 21 362714 env12434 = env12435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 362714 env12434 == env12435) = true)

theorem identity12435 : scanCanonicalize (H12AffineFastState.compose env12435 (packedSelected [1,5,13] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound12435 : packedSelected [1,5,13] rootPS < 2^1333 := by decide +kernel

def env12436 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,8192,1,32768,65536,1,262144,273,32769,1,362635,17,98565,8328,16,100751,1,1,1073741824,21,4294967296,256,4295231780,1,512]

theorem envBound12436 : H12AffineFastState.Bounded env12436 := by
  intro p hp
  have h : env12436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12435_12436 : H12AffineEnvironment.transform 5 17 env12435 = env12436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env12435 == env12436) = true)

theorem identity12436 : scanCanonicalize (H12AffineFastState.compose env12436 (packedSelected [1] rootPS)) = affineNative (2^(29+1) ^^^ 43146) := by decide +kernel

theorem selectedBound12436 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12437 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,8192,1,32768,65536,1,262144,273,32769,1,362635,17,98565,8328,16,100751,1,1,43146,21,4294967296,256,4295231780,1,512]

theorem envBound12437 : H12AffineFastState.Bounded env12437 := by
  intro p hp
  have h : env12437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12436_12437 : H12AffineEnvironment.transform 29 43146 env12436 = env12437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 43146 env12436 == env12437) = true)

theorem identity12437 : scanCanonicalize (H12AffineFastState.compose env12437 (packedSelected [3] rootPS)) = affineNative (2^(14+1) ^^^ 8622) := by decide +kernel

theorem selectedBound12437 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env12438 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,8192,1,8622,65536,1,262144,273,8623,1,338213,17,73899,8328,16,75809,1,1,2340,21,4294967296,256,4295231780,1,512]

theorem envBound12438 : H12AffineFastState.Bounded env12438 := by
  intro p hp
  have h : env12438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12437_12438 : H12AffineEnvironment.transform 14 8622 env12437 = env12438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8622 env12437 == env12438) = true)

theorem identity12438 : scanCanonicalize (H12AffineFastState.compose env12438 (packedSelected [5] rootPS)) = affineNative (2^(17+1) ^^^ 2341) := by decide +kernel

theorem selectedBound12438 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env12439 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,8192,1,8622,65536,1,2341,273,8623,1,73728,17,73899,8328,16,75809,1,1,2340,21,4294967296,256,4294967297,1,512]

theorem envBound12439 : H12AffineFastState.Bounded env12439 := by
  intro p hp
  have h : env12439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12438_12439 : H12AffineEnvironment.transform 17 2341 env12438 = env12439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2341 env12438 == env12439) = true)

theorem identity12439 : scanCanonicalize (H12AffineFastState.compose env12439 (packedSelected [8] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound12439 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env12440 : List Nat := [2,4,8,16,32,17,35,256,512,273,2048,1,8192,1,8461,65536,1,2341,273,8460,1,73728,17,73736,8235,16,75809,1,1,2340,21,4294967296,256,4294967297,1,512]

theorem envBound12440 : H12AffineFastState.Bounded env12440 := by
  intro p hp
  have h : env12440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12439_12440 : H12AffineEnvironment.transform 6 35 env12439 = env12440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env12439 == env12440) = true)

theorem identity12440 : scanCanonicalize (H12AffineFastState.compose env12440 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 74031) := by decide +kernel

theorem selectedBound12440 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env12441 : List Nat := [2,4,8,16,32,17,35,256,512,273,2048,1,8192,1,8461,65536,1,2341,273,8460,1,73728,17,73736,8235,16,75809,1,1,2340,21,74031,256,74030,1,512]

theorem envBound12441 : H12AffineFastState.Bounded env12441 := by
  intro p hp
  have h : env12441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12440_12441 : H12AffineEnvironment.transform 31 74031 env12440 = env12441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 74031 env12440 == env12441) = true)

theorem identity12441 : scanCanonicalize (H12AffineFastState.compose env12441 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 8225) := by decide +kernel

theorem selectedBound12441 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env12442 : List Nat := [2,4,8,16,32,17,35,256,512,273,2048,1,8192,1,8461,8225,1,2341,273,8460,1,33,17,41,8235,16,2048,1,1,2340,21,270,256,271,1,512]

theorem envBound12442 : H12AffineFastState.Bounded env12442 := by
  intro p hp
  have h : env12442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12441_12442 : H12AffineEnvironment.transform 15 8225 env12441 = env12442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8225 env12441 == env12442) = true)

theorem identity12442 : scanCanonicalize (H12AffineFastState.compose env12442 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 521) := by decide +kernel

theorem selectedBound12442 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12443 : List Nat := [2,4,8,16,32,17,35,256,512,273,2048,1,521,1,772,552,1,2341,273,773,1,33,17,41,546,16,2048,1,1,2340,21,270,256,271,1,512]

theorem envBound12443 : H12AffineFastState.Bounded env12443 := by
  intro p hp
  have h : env12443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12442_12443 : H12AffineEnvironment.transform 12 521 env12442 = env12443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 521 env12442 == env12443) = true)

theorem identity12443 : scanCanonicalize (H12AffineFastState.compose env12443 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound12443 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env12444 : List Nat := [2,4,8,16,32,17,35,256,261,273,2048,1,268,1,1,301,1,2341,273,0,1,33,17,41,295,16,2048,1,1,2340,21,270,256,271,1,261]

theorem envBound12444 : H12AffineFastState.Bounded env12444 := by
  intro p hp
  have h : env12444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12443_12444 : H12AffineEnvironment.transform 8 261 env12443 = env12444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env12443 == env12444) = true)

theorem identity12444 : scanCanonicalize (H12AffineFastState.compose env12444 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound12444 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env12445 : List Nat := [2,4,8,16,32,17,35,256,261,273,293,1,268,1,1,301,1,0,273,0,1,33,17,41,295,16,293,1,1,1,21,270,256,271,1,261]

theorem envBound12445 : H12AffineFastState.Bounded env12445 := by
  intro p hp
  have h : env12445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12444_12445 : H12AffineEnvironment.transform 10 293 env12444 = env12445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env12444 == env12445) = true)

theorem identity12445 : scanCanonicalize (H12AffineFastState.compose env12445 (packedSelected [11] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound12445 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env12446 : List Nat := [2,4,8,16,32,17,35,37,32,52,0,1,41,1,1,8,1,0,52,0,1,33,17,41,2,16,0,1,1,1,21,43,37,42,1,32]

theorem envBound12446 : H12AffineFastState.Bounded env12446 := by
  intro p hp
  have h : env12446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12445_12446 : H12AffineEnvironment.transform 7 37 env12445 = env12446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env12445 == env12446) = true)

def env12447 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,0,8192,0,32768,65536,0,262144,321,32769,0,4194304,64,98565,8328,16,4456708,0,0,1073741824,69,4294967296,256,4299260335,0,512]

theorem envBound12447 : H12AffineFastState.Bounded env12447 := by
  intro p hp
  have h : env12447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12433_12447 : H12AffineEnvironment.transform 9 321 env12433 = env12447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env12433 == env12447) = true)

theorem identity12447 : scanCanonicalize (H12AffineFastState.compose env12447 (packedSelected [1,3,5,8,10] rootPS)) = affineNative (2^(21+1) ^^^ 41341) := by decide +kernel

theorem selectedBound12447 : packedSelected [1,3,5,8,10] rootPS < 2^1333 := by decide +kernel

def env12448 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,0,8192,0,32768,65536,0,262144,321,32769,0,41341,64,98565,8328,16,303225,0,0,1073741824,69,4294967296,256,4295041234,0,512]

theorem envBound12448 : H12AffineFastState.Bounded env12448 := by
  intro p hp
  have h : env12448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12447_12448 : H12AffineEnvironment.transform 21 41341 env12447 = env12448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41341 env12447 == env12448) = true)

theorem identity12448 : scanCanonicalize (H12AffineFastState.compose env12448 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound12448 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env12449 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,0,8192,0,32768,65536,0,262144,273,32769,0,41261,16,98565,8328,16,303145,0,0,1073741824,21,4294967296,256,4295041154,0,512]

theorem envBound12449 : H12AffineFastState.Bounded env12449 := by
  intro p hp
  have h : env12449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12448_12449 : H12AffineEnvironment.transform 5 16 env12448 = env12449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env12448 == env12449) = true)

theorem identity12449 : scanCanonicalize (H12AffineFastState.compose env12449 (packedSelected [1] rootPS)) = affineNative (2^(14+1) ^^^ 8581) := by decide +kernel

theorem selectedBound12449 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12450 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,0,8192,0,8581,65536,0,262144,273,8580,0,168,16,73856,8328,16,262572,0,0,1073741824,21,4294967296,256,4295041154,0,512]

theorem envBound12450 : H12AffineFastState.Bounded env12450 := by
  intro p hp
  have h : env12450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12449_12450 : H12AffineEnvironment.transform 14 8581 env12449 = env12450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8581 env12449 == env12450) = true)

theorem identity12450 : scanCanonicalize (H12AffineFastState.compose env12450 (packedSelected [12] rootPS)) = affineNative (2^(29+1) ^^^ 262145) := by decide +kernel

theorem selectedBound12450 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env12451 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,0,8192,0,8581,65536,0,262144,273,8580,0,168,16,73856,8328,16,262572,0,0,262145,21,4294967296,256,4295041154,0,512]

theorem envBound12451 : H12AffineFastState.Bounded env12451 := by
  intro p hp
  have h : env12451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12450_12451 : H12AffineEnvironment.transform 29 262145 env12450 = env12451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 262145 env12450 == env12451) = true)

def env12452 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,4194304,8388608,16777216,8328,8914000,134217728,8519744,676865,1073741824,25412672,4294967296,8536385,4315938986,164610304,512]

theorem envBound12452 : H12AffineFastState.Bounded env12452 := by
  intro p hp
  have h : env12452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12208_12452 : H12AffineEnvironment.transform 20 4097 env12208 = env12452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env12208 == env12452) = true)

theorem identity12452 : scanCanonicalize (H12AffineFastState.compose env12452 (packedSelected [14] rootPS)) = affineNative (2^(26+1) ^^^ 13518149) := by decide +kernel

theorem selectedBound12452 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env12453 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,4194304,8388608,16777216,8328,8914000,13518149,8519744,676865,1073741824,25412672,4294967296,8536385,4315938986,16876613,512]

theorem envBound12453 : H12AffineFastState.Bounded env12453 := by
  intro p hp
  have h : env12453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12452_12453 : H12AffineEnvironment.transform 26 13518149 env12452 = env12453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 13518149 env12452 == env12453) = true)

def env12454 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,4194304,17664,16777216,8328,541008,5111877,148800,676865,1073741824,17006912,4294967296,132161,4315938986,16876613,512]

theorem envBound12454 : H12AffineFastState.Bounded env12454 := by
  intro p hp
  have h : env12454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12453_12454 : H12AffineEnvironment.transform 22 17664 env12453 = env12454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17664 env12453 == env12454) = true)

theorem identity12454 : scanCanonicalize (H12AffineFastState.compose env12454 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(23+1) ^^^ 230468) := by decide +kernel

theorem selectedBound12454 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env12455 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,4194304,17664,230468,8328,541008,5111877,148800,676865,1073741824,1284,4294967296,132161,4299392238,131073,512]

theorem envBound12455 : H12AffineFastState.Bounded env12455 := by
  intro p hp
  have h : env12455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12454_12455 : H12AffineEnvironment.transform 23 230468 env12454 = env12455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 230468 env12454 == env12455) = true)

def env12456 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,10248,17664,230468,8328,541008,927821,148800,676865,1073741824,1284,4294967296,132161,4295208166,131073,512]

theorem envBound12456 : H12AffineFastState.Bounded env12456 := by
  intro p hp
  have h : env12456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12455_12456 : H12AffineEnvironment.transform 21 10248 env12455 = env12456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10248 env12455 == env12456) = true)

def env12457 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,8200,17664,230468,8328,541008,925773,148800,676865,1073741824,1284,4294967296,132161,4295206118,131073,512]

theorem envBound12457 : H12AffineFastState.Bounded env12457 := by
  intro p hp
  have h : env12457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12456_12457 : H12AffineEnvironment.transform 10 0 env12456 = env12457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env12456 == env12457) = true)

def env12458 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1344,262144,524288,32769,4097,8200,17664,98564,8328,541008,795917,16384,545089,1073741824,1284,4294967296,257,4295074214,1345,512]

theorem envBound12458 : H12AffineFastState.Bounded env12458 := by
  intro p hp
  have h : env12458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12457_12458 : H12AffineEnvironment.transform 16 1344 env12457 = env12458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env12457 == env12458) = true)

theorem identity12458 : scanCanonicalize (H12AffineFastState.compose env12458 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 299381) := by decide +kernel

theorem selectedBound12458 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env12459 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1344,262144,524288,32769,4097,8200,17664,98564,8328,541008,795917,16384,545089,299381,1284,4294967296,257,4295074214,1345,512]

theorem envBound12459 : H12AffineFastState.Bounded env12459 := by
  intro p hp
  have h : env12459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12458_12459 : H12AffineEnvironment.transform 29 299381 env12458 = env12459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 299381 env12458 == env12459) = true)

theorem identity12459 : scanCanonicalize (H12AffineFastState.compose env12459 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(18+1) ^^^ 1025) := by decide +kernel

theorem selectedBound12459 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env12460 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1344,262144,1025,32769,4097,8200,17664,98564,8328,17745,270604,16384,21824,299381,1284,4294967296,257,4295074214,1345,512]

theorem envBound12460 : H12AffineFastState.Bounded env12460 := by
  intro p hp
  have h : env12460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12459_12460 : H12AffineEnvironment.transform 18 1025 env12459 = env12460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env12459 == env12460) = true)

theorem identity12460 : scanCanonicalize (H12AffineFastState.compose env12460 (packedSelected [1,5,8,15,17,21,24,38] rootPS)) = affineNative (2^(17+1) ^^^ 74151) := by decide +kernel

theorem selectedBound12460 : packedSelected [1,5,8,15,17,21,24,38] rootPS < 2^1333 := by decide +kernel

def env12461 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1344,74151,1025,32769,4097,8200,17664,98564,8328,17745,65707,16384,21824,110802,1284,4294967296,257,4295074214,1345,512]

theorem envBound12461 : H12AffineFastState.Bounded env12461 := by
  intro p hp
  have h : env12461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12460_12461 : H12AffineEnvironment.transform 17 74151 env12460 = env12461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 74151 env12460 == env12461) = true)

theorem identity12461 : scanCanonicalize (H12AffineFastState.compose env12461 (packedSelected [1,5,8,24] rootPS)) = affineNative (2^(15+1) ^^^ 37343) := by decide +kernel

theorem selectedBound12461 : packedSelected [1,5,8,24] rootPS < 2^1333 := by decide +kernel

def env12462 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,37343,1344,45176,1025,32769,4097,8200,17664,4315,8328,17745,37236,16384,21824,8461,1284,4294967296,257,4294979705,1345,512]

theorem envBound12462 : H12AffineFastState.Bounded env12462 := by
  intro p hp
  have h : env12462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12461_12462 : H12AffineEnvironment.transform 15 37343 env12461 = env12462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 37343 env12461 == env12462) = true)

theorem identity12462 : scanCanonicalize (H12AffineFastState.compose env12462 (packedSelected [1,3,5,8,12,13,15,17] rootPS)) = affineNative (2^(13+1) ^^^ 9292) := by decide +kernel

theorem selectedBound12462 : packedSelected [1,3,5,8,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env12463 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,9292,32768,37343,1344,45176,1025,32769,4097,8200,8524,4315,8328,8477,37236,9292,12556,8461,1284,4294967296,257,4294979705,1345,512]

theorem envBound12463 : H12AffineFastState.Bounded env12463 := by
  intro p hp
  have h : env12463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12462_12463 : H12AffineEnvironment.transform 13 9292 env12462 = env12463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 9292 env12462 == env12463) = true)

theorem identity12463 : scanCanonicalize (H12AffineFastState.compose env12463 (packedSelected [0,1,7,8,10,15] rootPS)) = affineNative (2^(12+1) ^^^ 5196) := by decide +kernel

theorem selectedBound12463 : packedSelected [0,1,7,8,10,15] rootPS < 2^1333 := by decide +kernel

def env12464 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,5196,4096,32768,37343,1344,33844,1025,32769,4097,5188,5376,4315,5316,5457,37236,4096,1344,5441,1284,4294967296,257,4294968373,1345,512]

theorem envBound12464 : H12AffineFastState.Bounded env12464 := by
  intro p hp
  have h : env12464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12463_12464 : H12AffineEnvironment.transform 12 5196 env12463 = env12464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5196 env12463 == env12464) = true)

theorem identity12464 : scanCanonicalize (H12AffineFastState.compose env12464 (packedSelected [0,1,3,7,10,13] rootPS)) = affineNative (2^(31+1) ^^^ 37636) := by decide +kernel

theorem selectedBound12464 : packedSelected [0,1,3,7,10,13] rootPS < 2^1333 := by decide +kernel

def env12465 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,5196,4096,32768,37343,1344,33844,1025,32769,4097,5188,5376,4315,5316,5457,37236,4096,1344,5441,1284,37636,257,38705,1345,512]

theorem envBound12465 : H12AffineFastState.Bounded env12465 := by
  intro p hp
  have h : env12465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12464_12465 : H12AffineEnvironment.transform 31 37636 env12464 = env12465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 37636 env12464 == env12465) = true)

theorem identity12465 : scanCanonicalize (H12AffineFastState.compose env12465 (packedSelected [0,1,3,4,5,7,8,9,12,18] rootPS)) = affineNative (2^(14+1) ^^^ 372) := by decide +kernel

theorem selectedBound12465 : packedSelected [0,1,3,4,5,7,8,9,12,18] rootPS < 2^1333 := by decide +kernel

def env12466 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,5196,4096,372,4267,1344,1344,1025,373,4097,5188,5376,4315,5316,5457,4096,4096,1344,5441,1284,4720,257,5701,1345,512]

theorem envBound12466 : H12AffineFastState.Bounded env12466 := by
  intro p hp
  have h : env12466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12465_12466 : H12AffineEnvironment.transform 14 372 env12465 = env12466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 372 env12465 == env12466) = true)

theorem identity12466 : scanCanonicalize (H12AffineFastState.compose env12466 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 1724) := by decide +kernel

theorem selectedBound12466 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env12467 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1724,752,1724,372,1559,1344,1344,1025,373,1725,760,956,1639,632,1005,1724,1724,1344,1021,1284,1228,257,249,1345,512]

theorem envBound12467 : H12AffineFastState.Bounded env12467 := by
  intro p hp
  have h : env12467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12466_12467 : H12AffineEnvironment.transform 11 1724 env12466 = env12467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1724 env12466 == env12467) = true)

theorem identity12467 : scanCanonicalize (H12AffineFastState.compose env12467 (packedSelected [0,4,7,9,12] rootPS)) = affineNative (2^(8+1) ^^^ 509) := by decide +kernel

theorem selectedBound12467 : packedSelected [0,4,7,9,12] rootPS < 2^1333 := by decide +kernel

def env12468 : List Nat := [2,4,8,16,32,64,128,256,509,1024,0,1345,269,1345,372,1514,1344,1344,1025,373,1344,261,65,1434,389,16,1345,1345,1344,0,1284,1228,257,249,1345,509]

theorem envBound12468 : H12AffineFastState.Bounded env12468 := by
  intro p hp
  have h : env12468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12467_12468 : H12AffineEnvironment.transform 8 509 env12467 = env12468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 509 env12467 == env12468) = true)

theorem identity12468 : scanCanonicalize (H12AffineFastState.compose env12468 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound12468 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env12469 : List Nat := [2,4,8,16,32,16,128,256,429,1024,0,1297,269,1297,292,1466,1296,1296,1025,293,1296,261,17,1434,389,16,1297,1297,1296,0,1284,1180,257,169,1297,429]

theorem envBound12469 : H12AffineFastState.Bounded env12469 := by
  intro p hp
  have h : env12469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12468_12469 : H12AffineEnvironment.transform 5 16 env12468 = env12469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env12468 == env12469) = true)

theorem identity12469 : scanCanonicalize (H12AffineFastState.compose env12469 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 434) := by decide +kernel

theorem selectedBound12469 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

end H12CloudChart2