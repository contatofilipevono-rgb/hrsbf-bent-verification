import H12CloudChart2Data121

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound30134 : packedSelected [0,4,11] rootPS < 2^1333 := by decide +kernel

def env30135 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,3212,553,3773,3773,2714,185,2185,2101,3772,3213,3620,3605,1726,3732,545,512,2744,2744,649,1689,1197,173,169,1212,3636]

theorem envBound30135 : H12AffineFastState.Bounded env30135 := by
  intro p hp
  have h : env30135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30134_30135 : H12AffineEnvironment.transform 11 3212 env30134 = env30135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3212 env30134 == env30135) = true)

theorem identity30135 : scanCanonicalize (H12AffineFastState.compose env30135 (packedSelected [2,3,7,8,9,10,12] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound30135 : packedSelected [2,3,7,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env30136 : List Nat := [2,4,8,16,32,17,128,173,43,1024,2048,3212,2,3222,3222,2225,185,2185,2101,3223,3213,3087,3134,1173,3263,10,43,2195,2195,162,1202,1197,173,169,1212,3103]

theorem envBound30136 : H12AffineFastState.Bounded env30136 := by
  intro p hp
  have h : env30136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30135_30136 : H12AffineEnvironment.transform 8 43 env30135 = env30136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env30135 == env30136) = true)

theorem identity30136 : scanCanonicalize (H12AffineFastState.compose env30136 (packedSelected [1,3,4,6,9] rootPS)) = affineNative (2^(10+1) ^^^ 1055) := by decide +kernel

theorem selectedBound30136 : packedSelected [1,3,4,6,9] rootPS < 2^1333 := by decide +kernel

def env30137 : List Nat := [2,4,8,16,32,17,128,173,43,1024,1055,147,2,137,137,1198,185,1174,1066,136,146,16,33,1173,160,10,43,1164,1164,162,1202,1197,173,169,1212,0]

theorem envBound30137 : H12AffineFastState.Bounded env30137 := by
  intro p hp
  have h : env30137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30136_30137 : H12AffineEnvironment.transform 10 1055 env30136 = env30137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1055 env30136 == env30137) = true)

theorem identity30137 : scanCanonicalize (H12AffineFastState.compose env30137 (packedSelected [1,2,3,4,5,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound30137 : packedSelected [1,2,3,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env30138 : List Nat := [2,4,8,16,32,17,35,14,43,1024,1055,48,2,42,42,1037,26,1077,1066,43,49,16,33,1078,3,10,43,1071,1071,1,1041,1038,14,10,1055,0]

theorem envBound30138 : H12AffineFastState.Bounded env30138 := by
  intro p hp
  have h : env30138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30137_30138 : H12AffineEnvironment.transform 6 35 env30137 = env30138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env30137 == env30138) = true)

theorem identity30138 : scanCanonicalize (H12AffineFastState.compose env30138 (packedSelected [3,5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound30138 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env30139 : List Nat := [2,4,8,11,32,10,35,14,43,1024,1028,43,2,42,42,1037,1,1070,1066,43,42,11,33,1069,3,10,43,1071,1071,1,1034,1038,14,10,1028,0]

theorem envBound30139 : H12AffineFastState.Bounded env30139 := by
  intro p hp
  have h : env30139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30138_30139 : H12AffineEnvironment.transform 3 11 env30138 = env30139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env30138 == env30139) = true)

theorem identity30139 : scanCanonicalize (H12AffineFastState.compose env30139 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 46) := by decide +kernel

theorem selectedBound30139 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env30140 : List Nat := [2,4,8,11,32,10,35,14,43,46,42,43,2,42,42,35,1,0,4,43,42,11,33,3,3,10,43,1,1,1,36,32,14,10,42,0]

theorem envBound30140 : H12AffineFastState.Bounded env30140 := by
  intro p hp
  have h : env30140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30139_30140 : H12AffineEnvironment.transform 9 46 env30139 = env30140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 46 env30139 == env30140) = true)

def env30141 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147520,58683,143497,20497,508154,148800,148801,96346,90427,1280,256,131137,1344,135680]

theorem envBound30141 : H12AffineFastState.Bounded env30141 := by
  intro p hp
  have h : env30141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30086_30141 : H12AffineEnvironment.transform 18 136193 env30086 = env30141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136193 env30086 == env30141) = true)

def env30142 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147520,58519,143497,20497,508154,148716,148717,96346,90263,1196,172,131137,1260,135680]

theorem envBound30142 : H12AffineFastState.Bounded env30142 := by
  intro p hp
  have h : env30142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30141_30142 : H12AffineEnvironment.transform 7 172 env30141 = env30142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env30141 == env30142) = true)

def env30143 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61568,147472,58519,143497,20497,508074,148668,148669,96266,90263,1196,172,131089,1212,135680]

theorem envBound30143 : H12AffineFastState.Bounded env30143 := by
  intro p hp
  have h : env30143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30142_30143 : H12AffineEnvironment.transform 5 16 env30142 = env30143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env30142 == env30143) = true)

theorem identity30143 : scanCanonicalize (H12AffineFastState.compose env30143 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 99487) := by decide +kernel

theorem selectedBound30143 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env30144 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,99487,262144,102558,32769,4097,61568,115855,58519,111638,20497,279605,114723,114722,96266,90263,1196,172,99470,1212,104095]

theorem envBound30144 : H12AffineFastState.Bounded env30144 := by
  intro p hp
  have h : env30144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30143_30144 : H12AffineEnvironment.transform 16 99487 env30143 = env30144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 99487 env30143 == env30144) = true)

theorem identity30144 : scanCanonicalize (H12AffineFastState.compose env30144 (packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 5124) := by decide +kernel

theorem selectedBound30144 : packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS < 2^1333 := by decide +kernel

def env30145 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,5124,32768,65536,99487,262144,102558,32769,4097,42116,102539,45203,111638,1045,266289,103463,103462,76814,78995,1196,172,99470,1212,104095]

theorem envBound30145 : H12AffineFastState.Bounded env30145 := by
  intro p hp
  have h : env30145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30144_30145 : H12AffineEnvironment.transform 13 5124 env30144 = env30145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5124 env30144 == env30145) = true)

theorem identity30145 : scanCanonicalize (H12AffineFastState.compose env30145 (packedSelected [3,7,10,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 38047) := by decide +kernel

theorem selectedBound30145 : packedSelected [3,7,10,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env30146 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,5124,32768,38047,4096,262144,1025,32769,4097,42116,1044,45203,8329,1045,266289,184,185,47249,40972,1196,172,4113,1212,512]

theorem envBound30146 : H12AffineFastState.Bounded env30146 := by
  intro p hp
  have h : env30146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30145_30146 : H12AffineEnvironment.transform 15 38047 env30145 = env30146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38047 env30145 == env30146) = true)

theorem identity30146 : scanCanonicalize (H12AffineFastState.compose env30146 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 185) := by decide +kernel

theorem selectedBound30146 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env30147 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,185,8192,1213,32768,33830,185,262144,1025,32769,184,42116,1044,41002,8329,1045,262280,184,185,43048,40972,1196,172,168,1212,512]

theorem envBound30147 : H12AffineFastState.Bounded env30147 := by
  intro p hp
  have h : env30147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30146_30147 : H12AffineEnvironment.transform 11 185 env30146 = env30147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 185 env30146 == env30147) = true)

theorem identity30147 : scanCanonicalize (H12AffineFastState.compose env30147 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 656) := by decide +kernel

theorem selectedBound30147 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env30148 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,185,656,1213,32768,33830,185,262144,1025,32769,184,34324,1044,33466,537,1045,262280,184,185,35512,33436,1196,172,168,1212,512]

theorem envBound30148 : H12AffineFastState.Bounded env30148 := by
  intro p hp
  have h : env30148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30147_30148 : H12AffineEnvironment.transform 12 656 env30147 = env30148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 656 env30147 == env30148) = true)

theorem identity30148 : scanCanonicalize (H12AffineFastState.compose env30148 (packedSelected [1,3,13] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound30148 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env30149 : List Nat := [2,4,8,16,32,16,128,172,512,5,2048,185,656,184,32768,32803,185,262144,4,32769,184,33297,17,33466,537,16,262280,184,185,35512,33436,169,172,168,185,512]

theorem envBound30149 : H12AffineFastState.Bounded env30149 := by
  intro p hp
  have h : env30149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30148_30149 : H12AffineEnvironment.transform 9 5 env30148 = env30149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env30148 == env30149) = true)

theorem identity30149 : scanCanonicalize (H12AffineFastState.compose env30149 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 554) := by decide +kernel

theorem selectedBound30149 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env30150 : List Nat := [2,4,8,16,32,16,128,172,512,5,2048,185,656,184,32768,32803,185,554,4,32769,184,33297,17,33466,537,16,674,184,185,35512,33436,169,172,168,185,512]

theorem envBound30150 : H12AffineFastState.Bounded env30150 := by
  intro p hp
  have h : env30150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30149_30150 : H12AffineEnvironment.transform 17 554 env30149 = env30150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 554 env30149 == env30150) = true)

theorem identity30150 : scanCanonicalize (H12AffineFastState.compose env30150 (packedSelected [0,1,3,4,7,9,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 560) := by decide +kernel

theorem selectedBound30150 : packedSelected [0,1,3,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env30151 : List Nat := [2,4,8,16,32,16,128,172,512,5,2048,185,656,184,560,531,185,554,4,561,184,33,17,138,537,16,674,184,185,2184,172,169,172,168,185,512]

theorem envBound30151 : H12AffineFastState.Bounded env30151 := by
  intro p hp
  have h : env30151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30150_30151 : H12AffineEnvironment.transform 14 560 env30150 = env30151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 560 env30150 == env30151) = true)

theorem identity30151 : scanCanonicalize (H12AffineFastState.compose env30151 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound30151 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30152 : List Nat := [2,4,8,16,32,16,128,172,512,5,512,185,656,184,560,531,185,554,4,561,184,33,17,138,537,16,674,184,185,648,172,169,172,168,185,512]

theorem envBound30152 : H12AffineFastState.Bounded env30152 := by
  intro p hp
  have h : env30152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30151_30152 : H12AffineEnvironment.transform 10 512 env30151 = env30152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env30151 == env30152) = true)

theorem identity30152 : scanCanonicalize (H12AffineFastState.compose env30152 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound30152 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env30153 : List Nat := [2,4,8,11,32,11,128,172,512,5,512,162,651,163,555,520,162,554,4,554,163,33,10,138,514,11,674,163,162,648,172,169,172,168,162,512]

theorem envBound30153 : H12AffineFastState.Bounded env30153 := by
  intro p hp
  have h : env30153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30152_30153 : H12AffineEnvironment.transform 3 11 env30152 = env30153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env30152 == env30153) = true)

theorem identity30153 : scanCanonicalize (H12AffineFastState.compose env30153 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound30153 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30154 : List Nat := [2,4,5,6,32,6,128,161,512,5,512,162,646,163,550,517,162,551,4,551,163,33,7,135,514,6,674,163,162,645,161,164,161,165,162,512]

theorem envBound30154 : H12AffineFastState.Bounded env30154 := by
  intro p hp
  have h : env30154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30153_30154 : H12AffineEnvironment.transform 2 5 env30153 = env30154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env30153 == env30154) = true)

theorem identity30154 : scanCanonicalize (H12AffineFastState.compose env30154 (packedSelected [5] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound30154 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env30155 : List Nat := [2,4,5,6,32,6,128,161,1,5,1,162,135,163,39,4,162,38,4,38,163,33,7,135,3,6,163,163,162,132,161,164,161,165,162,1]

theorem envBound30155 : H12AffineFastState.Bounded env30155 := by
  intro p hp
  have h : env30155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30154_30155 : H12AffineEnvironment.transform 8 1 env30154 = env30155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env30154 == env30155) = true)

theorem identity30155 : scanCanonicalize (H12AffineFastState.compose env30155 (packedSelected [7] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound30155 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env30156 : List Nat := [2,4,5,6,32,6,4,37,1,5,1,38,3,39,39,4,38,38,4,38,39,33,7,3,3,6,39,39,38,0,37,32,37,33,38,1]

theorem envBound30156 : H12AffineFastState.Bounded env30156 := by
  intro p hp
  have h : env30156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30155_30156 : H12AffineEnvironment.transform 6 4 env30155 = env30156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env30155 == env30156) = true)

theorem identity30156 : scanCanonicalize (H12AffineFastState.compose env30156 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound30156 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30157 : List Nat := [2,4,5,6,7,6,4,2,1,5,1,1,3,0,0,4,1,1,4,1,0,6,7,3,3,6,0,0,1,0,2,7,2,6,1,1]

theorem envBound30157 : H12AffineFastState.Bounded env30157 := by
  intro p hp
  have h : env30157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30156_30157 : H12AffineEnvironment.transform 4 7 env30156 = env30157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env30156 == env30157) = true)

def env30158 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61569,147473,58519,143497,20497,508075,148669,148668,96267,90263,1196,172,131088,1213,135680]

theorem envBound30158 : H12AffineFastState.Bounded env30158 := by
  intro p hp
  have h : env30158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30142_30158 : H12AffineEnvironment.transform 5 17 env30142 = env30158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env30142 == env30158) = true)

theorem identity30158 : scanCanonicalize (H12AffineFastState.compose env30158 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 208054) := by decide +kernel

theorem selectedBound30158 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env30159 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,208054,136193,32769,4097,61569,147473,58519,143497,20497,60445,148669,148668,96267,90263,1196,172,131088,1213,135680]

theorem envBound30159 : H12AffineFastState.Bounded env30159 := by
  intro p hp
  have h : env30159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30158_30159 : H12AffineEnvironment.transform 17 208054 env30158 = env30159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 208054 env30158 == env30159) = true)

theorem identity30159 : scanCanonicalize (H12AffineFastState.compose env30159 (packedSelected [1,3,5,7,8,10,20,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53283) := by decide +kernel

theorem selectedBound30159 : packedSelected [1,3,5,7,8,10,20,26,27] rootPS < 2^1333 := by decide +kernel

def env30160 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,53283,131072,195733,136193,32769,4097,61569,147473,58519,143497,20497,60445,148669,148668,43048,45236,1196,172,131088,1213,135680]

theorem envBound30160 : H12AffineFastState.Bounded env30160 := by
  intro p hp
  have h : env30160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30159_30160 : H12AffineEnvironment.transform 15 53283 env30159 = env30160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53283 env30159 == env30160) = true)

theorem identity30160 : scanCanonicalize (H12AffineFastState.compose env30160 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(16+1) ^^^ 21693) := by decide +kernel

theorem selectedBound30160 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env30161 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,53283,21693,43048,16572,32769,4097,61569,5292,58519,25652,20497,60445,4096,4097,43048,45236,1196,172,21677,1213,18109]

theorem envBound30161 : H12AffineFastState.Bounded env30161 := by
  intro p hp
  have h : env30161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30160_30161 : H12AffineEnvironment.transform 16 21693 env30160 = env30161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 21693 env30160 == env30161) = true)

theorem identity30161 : scanCanonicalize (H12AffineFastState.compose env30161 (packedSelected [4,9,20] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound30161 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env30162 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,184,8192,16384,32768,49307,17413,43048,16572,32769,185,57401,1044,58519,25652,16553,60445,184,185,43048,40972,1196,172,17429,1213,18109]

theorem envBound30162 : H12AffineFastState.Bounded env30162 := by
  intro p hp
  have h : env30162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30161_30162 : H12AffineEnvironment.transform 11 184 env30161 = env30162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env30161 == env30162) = true)

theorem identity30162 : scanCanonicalize (H12AffineFastState.compose env30162 (packedSelected [0,2,3,5,6,9,11] rootPS)) = affineNative (2^(14+1) ^^^ 17081) := by decide +kernel

theorem selectedBound30162 : packedSelected [0,2,3,5,6,9,11] rootPS < 2^1333 := by decide +kernel

def env30163 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,184,8192,16384,17081,546,17413,27281,16572,17080,185,8832,1044,9774,25652,16553,11940,184,185,27281,25269,1196,172,17429,1213,18109]

theorem envBound30163 : H12AffineFastState.Bounded env30163 := by
  intro p hp
  have h : env30163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30162_30163 : H12AffineEnvironment.transform 14 17081 env30162 = env30163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 17081 env30162 == env30163) = true)

theorem identity30163 : scanCanonicalize (H12AffineFastState.compose env30163 (packedSelected [0,1,2,4,5,7,9,15,16,17] rootPS)) = affineNative (2^(13+1) ^^^ 10890) := by decide +kernel

theorem selectedBound30163 : packedSelected [0,1,2,4,5,7,9,15,16,17] rootPS < 2^1333 := by decide +kernel

def env30164 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,184,8192,10890,10291,546,11919,27,10806,10290,185,8832,1044,9774,3774,10787,11940,184,185,27,2111,1196,172,11935,1213,11319]

theorem envBound30164 : H12AffineFastState.Bounded env30164 := by
  intro p hp
  have h : env30164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30163_30164 : H12AffineEnvironment.transform 13 10890 env30163 = env30164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 10890 env30163 == env30164) = true)

theorem identity30164 : scanCanonicalize (H12AffineFastState.compose env30164 (packedSelected [1,3,13] rootPS)) = affineNative (2^(12+1) ^^^ 3590) := by decide +kernel

theorem selectedBound30164 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env30165 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,184,3590,1164,1589,546,137,27,1072,1588,185,3206,1044,2088,3774,1061,162,184,185,27,2111,1196,172,153,1213,561]

theorem envBound30165 : H12AffineFastState.Bounded env30165 := by
  intro p hp
  have h : env30165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30164_30165 : H12AffineEnvironment.transform 12 3590 env30164 = env30165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3590 env30164 == env30165) = true)

theorem identity30165 : scanCanonicalize (H12AffineFastState.compose env30165 (packedSelected [0,3,5,6,9,15] rootPS)) = affineNative (2^(10+1) ^^^ 146) := by decide +kernel

theorem selectedBound30165 : packedSelected [0,3,5,6,9,15] rootPS < 2^1333 := by decide +kernel

def env30166 : List Nat := [2,4,8,16,32,17,128,172,512,1024,146,184,1684,1164,1589,546,137,27,1072,1588,185,1044,1044,186,1580,1061,162,184,185,27,173,1196,172,153,1213,561]

theorem envBound30166 : H12AffineFastState.Bounded env30166 := by
  intro p hp
  have h : env30166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30165_30166 : H12AffineEnvironment.transform 10 146 env30165 = env30166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 146 env30165 == env30166) = true)

theorem identity30166 : scanCanonicalize (H12AffineFastState.compose env30166 (packedSelected [2,3,5] rootPS)) = affineNative (2^(9+1) ^^^ 558) := by decide +kernel

theorem selectedBound30166 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env30167 : List Nat := [2,4,8,16,32,17,128,172,512,558,146,184,186,674,27,546,137,27,542,26,185,570,570,186,2,523,162,184,185,27,173,642,172,153,659,561]

theorem envBound30167 : H12AffineFastState.Bounded env30167 := by
  intro p hp
  have h : env30167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30166_30167 : H12AffineEnvironment.transform 9 558 env30166 = env30167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 558 env30166 == env30167) = true)

theorem identity30167 : scanCanonicalize (H12AffineFastState.compose env30167 (packedSelected [0,1,4,6] rootPS)) = affineNative (2^(8+1) ^^^ 149) := by decide +kernel

theorem selectedBound30167 : packedSelected [0,1,4,6] rootPS < 2^1333 := by decide +kernel

def env30168 : List Nat := [2,4,8,16,32,17,128,172,149,187,146,184,186,55,27,183,137,27,139,26,185,175,175,186,2,158,162,184,185,27,173,23,172,153,6,164]

theorem envBound30168 : H12AffineFastState.Bounded env30168 := by
  intro p hp
  have h : env30168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30167_30168 : H12AffineEnvironment.transform 8 149 env30167 = env30168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 149 env30167 == env30168) = true)

theorem identity30168 : scanCanonicalize (H12AffineFastState.compose env30168 (packedSelected [0,1,2,7] rootPS)) = affineNative (2^(4+1) ^^^ 22) := by decide +kernel

theorem selectedBound30168 : packedSelected [0,1,2,7] rootPS < 2^1333 := by decide +kernel

def env30169 : List Nat := [2,4,8,16,22,17,128,154,149,141,146,142,140,1,27,129,137,27,139,26,143,153,153,140,2,158,148,142,143,27,155,23,154,153,6,146]

theorem envBound30169 : H12AffineFastState.Bounded env30169 := by
  intro p hp
  have h : env30169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30168_30169 : H12AffineEnvironment.transform 4 22 env30168 = env30169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 22 env30168 == env30169) = true)

theorem identity30169 : scanCanonicalize (H12AffineFastState.compose env30169 (packedSelected [0,1,4] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound30169 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env30170 : List Nat := [2,4,8,16,22,17,19,9,6,30,1,29,31,1,27,18,26,27,24,26,28,10,10,31,2,13,7,29,28,27,8,23,9,10,6,1]

theorem envBound30170 : H12AffineFastState.Bounded env30170 := by
  intro p hp
  have h : env30170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30169_30170 : H12AffineEnvironment.transform 6 19 env30169 = env30170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env30169 == env30170) = true)

theorem identity30170 : scanCanonicalize (H12AffineFastState.compose env30170 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound30170 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env30171 : List Nat := [2,4,8,10,12,11,9,9,6,4,1,7,5,1,1,8,0,1,2,0,6,10,10,5,2,13,7,7,6,1,8,13,9,10,6,1]

theorem envBound30171 : H12AffineFastState.Bounded env30171 := by
  intro p hp
  have h : env30171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30170_30171 : H12AffineEnvironment.transform 3 10 env30170 = env30171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env30170 == env30171) = true)

theorem identity30171 : scanCanonicalize (H12AffineFastState.compose env30171 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound30171 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30172 : List Nat := [2,2,8,10,10,11,9,9,0,2,1,1,3,1,1,8,0,1,2,0,0,10,10,3,2,11,1,1,0,1,8,11,9,10,0,1]

theorem envBound30172 : H12AffineFastState.Bounded env30172 := by
  intro p hp
  have h : env30172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30171_30172 : H12AffineEnvironment.transform 1 2 env30171 = env30172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env30171 == env30172) = true)

theorem identity30172 : scanCanonicalize (H12AffineFastState.compose env30172 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound30172 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30173 : List Nat := [0,0,8,8,8,9,9,9,0,0,1,1,1,1,1,8,0,1,0,0,0,8,8,1,0,9,1,1,0,1,8,9,9,8,0,1]

theorem envBound30173 : H12AffineFastState.Bounded env30173 := by
  intro p hp
  have h : env30173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30172_30173 : H12AffineEnvironment.transform 0 0 env30172 = env30173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env30172 == env30173) = true)

theorem identity30173 : scanCanonicalize (H12AffineFastState.compose env30173 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound30173 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30174 : List Nat := [0,0,1,1,1,0,0,0,0,0,1,1,1,1,1,1,0,1,0,0,0,1,1,1,0,0,1,1,0,1,1,0,0,1,0,1]

theorem envBound30174 : H12AffineFastState.Bounded env30174 := by
  intro p hp
  have h : env30174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30173_30174 : H12AffineEnvironment.transform 2 1 env30173 = env30174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env30173 == env30174) = true)

def env30175 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147520,58518,143497,20497,508154,148717,148716,96346,90262,1197,173,131137,1261,135680]

theorem envBound30175 : H12AffineFastState.Bounded env30175 := by
  intro p hp
  have h : env30175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30141_30175 : H12AffineEnvironment.transform 7 173 env30141 = env30175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env30141 == env30175) = true)

def env30176 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61568,147472,58518,143497,20497,508074,148669,148668,96266,90262,1197,173,131089,1213,135680]

theorem envBound30176 : H12AffineFastState.Bounded env30176 := by
  intro p hp
  have h : env30176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30175_30176 : H12AffineEnvironment.transform 5 16 env30175 = env30176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env30175 == env30176) = true)

theorem identity30176 : scanCanonicalize (H12AffineFastState.compose env30176 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 45216) := by decide +kernel

theorem selectedBound30176 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env30177 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,45216,262144,42145,32769,4097,61568,61616,58518,32809,20497,356362,62493,62492,96266,90262,1197,173,45233,1213,41632]

theorem envBound30177 : H12AffineFastState.Bounded env30177 := by
  intro p hp
  have h : env30177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30176_30177 : H12AffineEnvironment.transform 16 45216 env30176 = env30177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45216 env30176 == env30177) = true)

theorem identity30177 : scanCanonicalize (H12AffineFastState.compose env30177 (packedSelected [16,20] rootPS)) = affineNative (2^(17+1) ^^^ 2185) := by decide +kernel

theorem selectedBound30177 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env30178 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,45216,2185,42145,32769,4097,61568,61616,58518,32809,20497,96387,62493,62492,96266,90262,1197,173,45233,1213,41632]

theorem envBound30178 : H12AffineFastState.Bounded env30178 := by
  intro p hp
  have h : env30178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30177_30178 : H12AffineEnvironment.transform 17 2185 env30177 = env30178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2185 env30177 == env30178) = true)

theorem identity30178 : scanCanonicalize (H12AffineFastState.compose env30178 (packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS)) = affineNative (2^(14+1) ^^^ 12313) := by decide +kernel

theorem selectedBound30178 : packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env30179 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,12313,65536,185,2185,5304,12312,4097,16537,16553,21647,12336,20497,96387,17412,17413,96266,90262,1197,173,168,1213,4793]

theorem envBound30179 : H12AffineFastState.Bounded env30179 := by
  intro p hp
  have h : env30179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30178_30179 : H12AffineEnvironment.transform 14 12313 env30178 = env30179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12313 env30178 == env30179) = true)

theorem identity30179 : scanCanonicalize (H12AffineFastState.compose env30179 (packedSelected [1,4,5,8,9,16,17,21,24] rootPS)) = affineNative (2^(15+1) ^^^ 13375) := by decide +kernel

theorem selectedBound30179 : packedSelected [1,4,5,8,9,16,17,21,24] rootPS < 2^1333 := by decide +kernel

def env30180 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,12313,13375,185,2185,5304,12312,4097,16537,16553,21647,12336,20497,19644,17412,17413,19509,21673,1197,173,168,1213,4793]

theorem envBound30180 : H12AffineFastState.Bounded env30180 := by
  intro p hp
  have h : env30180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30179_30180 : H12AffineEnvironment.transform 15 13375 env30179 = env30180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13375 env30179 == env30180) = true)

theorem identity30180 : scanCanonicalize (H12AffineFastState.compose env30180 (packedSelected [2,3,5,6,10,15,17] rootPS)) = affineNative (2^(13+1) ^^^ 10912) := by decide +kernel

theorem selectedBound30180 : packedSelected [2,3,5,6,10,15,17] rootPS < 2^1333 := by decide +kernel

def env30181 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,10912,12313,13375,185,2185,5304,12312,4097,10809,10761,15919,12336,15025,9756,11940,11941,9877,15881,1197,173,168,1213,4793]

theorem envBound30181 : H12AffineFastState.Bounded env30181 := by
  intro p hp
  have h : env30181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30180_30181 : H12AffineEnvironment.transform 13 10912 env30180 = env30181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 10912 env30180 == env30181) = true)

theorem identity30181 : scanCanonicalize (H12AffineFastState.compose env30181 (packedSelected [3,4,5,6,7,12,15,16] rootPS)) = affineNative (2^(11+1) ^^^ 2744) := by decide +kernel

theorem selectedBound30181 : packedSelected [3,4,5,6,7,12,15,16] rootPS < 2^1333 := by decide +kernel

def env30182 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,2744,8192,10912,10913,11911,185,2185,3584,10912,2745,10809,10761,9367,10888,8201,9756,11940,11941,9877,9393,1197,173,168,1213,2049]

theorem envBound30182 : H12AffineFastState.Bounded env30182 := by
  intro p hp
  have h : env30182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30181_30182 : H12AffineEnvironment.transform 11 2744 env30181 = env30182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2744 env30181 == env30182) = true)

theorem identity30182 : scanCanonicalize (H12AffineFastState.compose env30182 (packedSelected [0,2,3,4,7,8,9,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 1590) := by decide +kernel

theorem selectedBound30182 : packedSelected [0,2,3,4,7,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env30183 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,2744,1590,3222,3223,2225,185,2185,3584,3222,2745,3087,3135,673,3262,1599,42,2194,2195,163,647,1197,173,168,1213,2049]

theorem envBound30183 : H12AffineFastState.Bounded env30183 := by
  intro p hp
  have h : env30183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30182_30183 : H12AffineEnvironment.transform 12 1590 env30182 = env30183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1590 env30182 == env30183) = true)

theorem identity30183 : scanCanonicalize (H12AffineFastState.compose env30183 (packedSelected [0,4,7,9,10] rootPS)) = affineNative (2^(10+1) ^^^ 1676) := by decide +kernel

theorem selectedBound30183 : packedSelected [0,4,7,9,10] rootPS < 2^1333 := by decide +kernel

def env30184 : List Nat := [2,4,8,16,32,16,128,173,512,1024,1676,1076,1590,538,539,1597,185,1541,140,538,1077,643,691,673,562,1599,42,1566,1567,163,647,1197,173,168,1213,1677]

theorem envBound30184 : H12AffineFastState.Bounded env30184 := by
  intro p hp
  have h : env30184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30183_30184 : H12AffineEnvironment.transform 10 1676 env30183 = env30184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1676 env30183 == env30184) = true)

theorem identity30184 : scanCanonicalize (H12AffineFastState.compose env30184 (packedSelected [2,3,4,5,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 679) := by decide +kernel

theorem selectedBound30184 : packedSelected [2,3,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env30185 : List Nat := [2,4,8,16,32,16,128,173,512,679,43,659,145,538,539,154,185,162,140,538,658,643,691,673,562,152,42,185,184,163,647,522,173,168,538,42]

theorem envBound30185 : H12AffineFastState.Bounded env30185 := by
  intro p hp
  have h : env30185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30184_30185 : H12AffineEnvironment.transform 9 679 env30184 = env30185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 679 env30184 == env30185) = true)

theorem identity30185 : scanCanonicalize (H12AffineFastState.compose env30185 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 163) := by decide +kernel

theorem selectedBound30185 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env30186 : List Nat := [2,4,8,16,32,16,128,173,163,4,43,48,145,185,184,154,185,162,140,185,49,32,16,2,145,152,42,185,184,163,36,169,173,168,185,42]

theorem envBound30186 : H12AffineFastState.Bounded env30186 := by
  intro p hp
  have h : env30186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30185_30186 : H12AffineEnvironment.transform 8 163 env30185 = env30186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 163 env30185 == env30186) = true)

theorem identity30186 : scanCanonicalize (H12AffineFastState.compose env30186 (packedSelected [0,4,5] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound30186 : packedSelected [0,4,5] rootPS < 2^1333 := by decide +kernel

def env30187 : List Nat := [2,4,8,12,32,12,128,173,163,4,43,44,141,165,164,134,165,162,140,165,45,32,12,2,141,132,42,165,164,163,36,169,173,168,165,42]

theorem envBound30187 : H12AffineFastState.Bounded env30187 := by
  intro p hp
  have h : env30187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30186_30187 : H12AffineEnvironment.transform 3 12 env30186 = env30187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env30186 == env30187) = true)

theorem identity30187 : scanCanonicalize (H12AffineFastState.compose env30187 (packedSelected [0,1,4,6] rootPS)) = affineNative (2^(6+1) ^^^ 36) := by decide +kernel

theorem selectedBound30187 : packedSelected [0,1,4,6] rootPS < 2^1333 := by decide +kernel

def env30188 : List Nat := [2,4,8,12,32,12,36,9,7,4,43,44,41,1,0,34,1,6,40,1,45,32,12,2,41,32,42,1,0,7,36,13,9,12,1,42]

theorem envBound30188 : H12AffineFastState.Bounded env30188 := by
  intro p hp
  have h : env30188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30187_30188 : H12AffineEnvironment.transform 6 36 env30187 = env30188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 36 env30187 == env30188) = true)

def env30189 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61569,147473,58518,143497,20497,508075,148668,148669,96267,90262,1197,173,131088,1212,135680]

theorem envBound30189 : H12AffineFastState.Bounded env30189 := by
  intro p hp
  have h : env30189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30175_30189 : H12AffineEnvironment.transform 5 17 env30175 = env30189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env30175 == env30189) = true)

theorem identity30189 : scanCanonicalize (H12AffineFastState.compose env30189 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 137352) := by decide +kernel

theorem selectedBound30189 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env30190 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,137352,136193,32769,4097,61569,147473,58518,143497,20497,120867,148668,148669,96267,90262,1197,173,131088,1212,135680]

theorem envBound30190 : H12AffineFastState.Bounded env30190 := by
  intro p hp
  have h : env30190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30189_30190 : H12AffineEnvironment.transform 17 137352 env30189 = env30190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137352 env30189 == env30190) = true)

theorem identity30190 : scanCanonicalize (H12AffineFastState.compose env30190 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(16+1) ^^^ 62493) := by decide +kernel

theorem selectedBound30190 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env30191 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,62493,60565,57372,32769,4097,61569,46092,58518,50324,20497,120867,45217,45216,96267,90262,1197,173,62477,1212,58909]

theorem envBound30191 : H12AffineFastState.Bounded env30191 := by
  intro p hp
  have h : env30191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30190_30191 : H12AffineEnvironment.transform 16 62493 env30190 = env30191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 62493 env30190 == env30191) = true)

theorem identity30191 : scanCanonicalize (H12AffineFastState.compose env30191 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 24635) := by decide +kernel

theorem selectedBound30191 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env30192 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,24635,62493,60565,57372,32769,4097,61569,46092,58518,50324,20497,47128,45217,45216,6192,173,1197,173,62477,1212,58909]

theorem envBound30192 : H12AffineFastState.Bounded env30192 := by
  intro p hp
  have h : env30192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30191_30192 : H12AffineEnvironment.transform 15 24635 env30191 = env30192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 24635 env30191 == env30192) = true)

theorem identity30192 : scanCanonicalize (H12AffineFastState.compose env30192 (packedSelected [0,1,2,4,6,7,8,9,13,17,18,19,21,23] rootPS)) = affineNative (2^(12+1) ^^^ 7829) := by decide +kernel

theorem selectedBound30192 : packedSelected [0,1,2,4,6,7,8,9,13,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env30193 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,7829,16384,32768,24238,51848,53760,56969,32769,4097,52756,35481,55811,50324,20497,34445,36404,36405,6192,173,1197,173,51864,1212,55432]

theorem envBound30193 : H12AffineFastState.Bounded env30193 := by
  intro p hp
  have h : env30193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30192_30193 : H12AffineEnvironment.transform 12 7829 env30192 = env30193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7829 env30192 == env30193) = true)

theorem identity30193 : scanCanonicalize (H12AffineFastState.compose env30193 (packedSelected [0,1,2,4,6,7,8,9,13,26] rootPS)) = affineNative (2^(14+1) ^^^ 3724) := by decide +kernel

theorem selectedBound30193 : packedSelected [0,1,2,4,6,7,8,9,13,26] rootPS < 2^1333 := by decide +kernel

def env30194 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,7829,16384,3724,24238,17412,23692,20485,3725,4097,16536,1045,21647,18968,20497,2049,184,185,6192,173,1197,173,17428,1212,22020]

theorem envBound30194 : H12AffineFastState.Bounded env30194 := by
  intro p hp
  have h : env30194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30193_30194 : H12AffineEnvironment.transform 14 3724 env30193 = env30194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 3724 env30193 == env30194) = true)

theorem identity30194 : scanCanonicalize (H12AffineFastState.compose env30194 (packedSelected [0,2,3,4,5,6,7,9,10,13] rootPS)) = affineNative (2^(13+1) ^^^ 5124) := by decide +kernel

theorem selectedBound30194 : packedSelected [0,2,3,4,5,6,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env30195 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,7829,5124,3724,2730,4096,2184,1025,3725,4097,5276,1045,139,7708,1045,2049,184,185,6192,173,1197,173,4112,1212,512]

theorem envBound30195 : H12AffineFastState.Bounded env30195 := by
  intro p hp
  have h : env30195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30194_30195 : H12AffineEnvironment.transform 13 5124 env30194 = env30195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5124 env30194 == env30195) = true)

theorem identity30195 : scanCanonicalize (H12AffineFastState.compose env30195 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(11+1) ^^^ 1077) := by decide +kernel

theorem selectedBound30195 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env30196 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,1077,2720,49,3724,2730,1077,2184,1025,3725,1076,169,1045,139,2601,1045,2049,184,185,3077,173,1197,173,1061,1212,512]

theorem envBound30196 : H12AffineFastState.Bounded env30196 := by
  intro p hp
  have h : env30196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30195_30196 : H12AffineEnvironment.transform 11 1077 env30195 = env30196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1077 env30195 == env30196) = true)

theorem identity30196 : scanCanonicalize (H12AffineFastState.compose env30196 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound30196 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env30197 : List Nat := [2,4,8,16,32,17,128,173,26,1024,2048,1077,2234,49,3222,2224,1077,2184,1025,3223,1076,169,1045,139,2099,1045,2049,184,185,3077,173,1197,173,1061,1212,26]

theorem envBound30197 : H12AffineFastState.Bounded env30197 := by
  intro p hp
  have h : env30197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30196_30197 : H12AffineEnvironment.transform 8 26 env30196 = env30197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env30196 == env30197) = true)

theorem identity30197 : scanCanonicalize (H12AffineFastState.compose env30197 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 1071) := by decide +kernel

theorem selectedBound30197 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env30198 : List Nat := [2,4,8,16,32,17,128,173,26,1024,1071,1077,1173,49,185,1183,1077,1191,1025,184,1076,169,1045,139,1052,1045,1070,184,185,42,173,1197,173,1061,1212,26]

theorem envBound30198 : H12AffineFastState.Bounded env30198 := by
  intro p hp
  have h : env30198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30197_30198 : H12AffineEnvironment.transform 10 1071 env30197 = env30198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1071 env30197 == env30198) = true)

theorem identity30198 : scanCanonicalize (H12AffineFastState.compose env30198 (packedSelected [3,7] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound30198 : packedSelected [3,7] rootPS < 2^1333 := by decide +kernel

def env30199 : List Nat := [2,4,8,10,32,11,128,173,0,1024,1071,1071,1167,43,163,1157,1071,1191,1025,162,1070,169,1039,139,1030,1039,1070,162,163,42,173,1197,173,1061,1190,0]

theorem envBound30199 : H12AffineFastState.Bounded env30199 := by
  intro p hp
  have h : env30199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30198_30199 : H12AffineEnvironment.transform 3 10 env30198 = env30199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env30198 == env30199) = true)

theorem identity30199 : scanCanonicalize (H12AffineFastState.compose env30199 (packedSelected [2,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound30199 : packedSelected [2,3,4] rootPS < 2^1333 := by decide +kernel

def env30200 : List Nat := [2,4,8,10,32,11,128,173,0,5,42,42,138,43,163,128,42,162,4,162,43,169,10,139,3,10,43,162,163,42,173,168,173,32,163,0]

theorem envBound30200 : H12AffineFastState.Bounded env30200 := by
  intro p hp
  have h : env30200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30199_30200 : H12AffineEnvironment.transform 9 5 env30199 = env30200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env30199 == env30200) = true)

theorem identity30200 : scanCanonicalize (H12AffineFastState.compose env30200 (packedSelected [0,3] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound30200 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env30201 : List Nat := [2,4,8,10,32,11,9,36,0,5,42,42,3,43,42,9,42,43,4,43,43,32,10,2,3,10,43,43,42,42,36,33,36,32,42,0]

theorem envBound30201 : H12AffineFastState.Bounded env30201 := by
  intro p hp
  have h : env30201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30200_30201 : H12AffineEnvironment.transform 6 9 env30200 = env30201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env30200 == env30201) = true)

theorem identity30201 : scanCanonicalize (H12AffineFastState.compose env30201 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound30201 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30202 : List Nat := [2,4,8,10,6,11,9,2,0,5,12,12,3,13,12,9,12,13,4,13,13,6,10,2,3,10,13,13,12,12,2,7,2,6,12,0]

theorem envBound30202 : H12AffineFastState.Bounded env30202 := by
  intro p hp
  have h : env30202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30201_30202 : H12AffineEnvironment.transform 4 6 env30201 = env30202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env30201 == env30202) = true)

theorem identity30202 : scanCanonicalize (H12AffineFastState.compose env30202 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound30202 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30203 : List Nat := [2,4,4,6,6,7,5,2,0,5,0,0,3,1,0,5,0,1,4,1,1,6,6,2,3,6,1,1,0,0,2,7,2,6,0,0]

theorem envBound30203 : H12AffineFastState.Bounded env30203 := by
  intro p hp
  have h : env30203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30202_30203 : H12AffineEnvironment.transform 2 4 env30202 = env30203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env30202 == env30203) = true)

def env30204 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,16777216,533641,672784,134217728,148800,545089,96346,16876545,135123451,257,151332225,151462017,525824]

theorem envBound30204 : H12AffineFastState.Bounded env30204 := by
  intro p hp
  have h : env30204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29968_30204 : H12AffineEnvironment.transform 24 533641 env29968 = env30204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 533641 env29968 == env30204) = true)

def env30205 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,16777216,533641,672784,17245632,148800,545089,96346,16876545,17495099,257,131137,1345,525824]

theorem envBound30205 : H12AffineFastState.Bounded env30205 := by
  intro p hp
  have h : env30205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30204_30205 : H12AffineEnvironment.transform 26 17245632 env30204 = env30205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245632 env30204 == env30205) = true)

theorem identity30205 : scanCanonicalize (H12AffineFastState.compose env30205 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 74863) := by decide +kernel

theorem selectedBound30205 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env30206 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,524288,32769,4097,61648,91183,16777216,533641,614527,17039791,90415,545089,96346,16876545,17420372,257,74798,1345,525824]

theorem envBound30206 : H12AffineFastState.Bounded env30206 := by
  intro p hp
  have h : env30206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30205_30206 : H12AffineEnvironment.transform 16 74863 env30205 = env30206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 74863 env30205 == env30206) = true)

def env30207 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,524288,32769,4097,61648,91183,123164,533641,614527,385203,90415,545089,96346,25885,536904,257,74798,1345,525824]

theorem envBound30207 : H12AffineFastState.Bounded env30207 := by
  intro p hp
  have h : env30207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30206_30207 : H12AffineEnvironment.transform 23 123164 env30206 = env30207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 123164 env30206 == env30207) = true)

def env30208 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,21584,32769,4097,61648,91183,123164,28889,78895,385203,90415,1297,96346,25885,25880,257,74798,1345,21072]

theorem envBound30208 : H12AffineFastState.Bounded env30208 := by
  intro p hp
  have h : env30208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30207_30208 : H12AffineEnvironment.transform 18 21584 env30207 = env30208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21584 env30207 == env30208) = true)

theorem identity30208 : scanCanonicalize (H12AffineFastState.compose env30208 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound30208 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env30209 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,13341,65536,74863,262144,21584,13340,4097,17613,91183,87297,28889,78895,349358,90415,1297,96346,25885,25880,257,74798,1345,21072]

theorem envBound30209 : H12AffineFastState.Bounded env30209 := by
  intro p hp
  have h : env30209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30208_30209 : H12AffineEnvironment.transform 14 13341 env30208 = env30209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env30208 == env30209) = true)

def env30210 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74863,262144,4416,13340,4097,477,74047,69649,13769,78895,332222,74815,1297,81226,8205,8200,257,74798,1345,5952]

theorem envBound30210 : H12AffineFastState.Bounded env30210 := by
  intro p hp
  have h : env30210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30209_30210 : H12AffineEnvironment.transform 13 1296 env30209 = env30210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env30209 == env30210) = true)

def env30211 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74863,65664,4416,13340,4097,477,74047,69649,13769,78895,4414,74815,1297,81226,8205,8200,257,74798,1345,5952]

theorem envBound30211 : H12AffineFastState.Bounded env30211 := by
  intro p hp
  have h : env30211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30210_30211 : H12AffineEnvironment.transform 17 65664 env30210 = env30211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env30210 == env30211) = true)

theorem identity30211 : scanCanonicalize (H12AffineFastState.compose env30211 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5465) := by decide +kernel

theorem selectedBound30211 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env30212 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5465,1296,324,65536,69942,65664,4416,325,4097,477,70758,69649,144,65910,4414,69990,1297,67603,5460,5457,257,70007,1345,5952]

theorem envBound30212 : H12AffineFastState.Bounded env30212 := by
  intro p hp
  have h : env30212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30211_30212 : H12AffineEnvironment.transform 12 5465 env30211 = env30212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5465 env30211 == env30212) = true)

def env30213 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5465,1296,324,1052,5418,1180,4416,325,4097,477,4218,5133,144,1386,4414,5498,1297,3087,5460,5457,257,5483,1345,5952]

theorem envBound30213 : H12AffineFastState.Bounded env30213 := by
  intro p hp
  have h : env30213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30212_30213 : H12AffineEnvironment.transform 15 1052 env30212 = env30213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1052 env30212 == env30213) = true)

theorem identity30213 : scanCanonicalize (H12AffineFastState.compose env30213 (packedSelected [0,2,3,5,8,11,15,16,17,20,21,23,24,27,28] rootPS)) = affineNative (2^(11+1) ^^^ 631) := by decide +kernel

theorem selectedBound30213 : packedSelected [0,2,3,5,8,11,15,16,17,20,21,23,24,27,28] rootPS < 2^1333 := by decide +kernel

def env30214 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,631,1838,1296,324,1052,1885,1180,823,325,630,477,525,1658,144,1386,841,1805,1297,3087,1827,1830,257,1820,1345,1335]

theorem envBound30214 : H12AffineFastState.Bounded env30214 := by
  intro p hp
  have h : env30214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30213_30214 : H12AffineEnvironment.transform 11 631 env30213 = env30214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 631 env30213 == env30214) = true)

def env30215 : List Nat := [2,4,8,16,32,0,128,256,512,1024,2048,567,1838,1296,260,1052,1821,1180,823,261,566,413,525,1594,144,1322,777,1805,1297,3087,1827,1830,257,1820,1281,1335]

theorem envBound30215 : H12AffineFastState.Bounded env30215 := by
  intro p hp
  have h : env30215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30214_30215 : H12AffineEnvironment.transform 5 0 env30214 = env30215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env30214 == env30215) = true)

def env30216 : List Nat := [2,4,8,16,32,0,128,8,512,1024,2048,567,1574,1048,12,1052,1557,1180,575,13,566,149,525,1594,144,1058,513,1541,1049,3087,1579,1582,9,1556,1033,1087]

theorem envBound30216 : H12AffineFastState.Bounded env30216 := by
  intro p hp
  have h : env30216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30215_30216 : H12AffineEnvironment.transform 7 8 env30215 = env30216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 8 env30215 == env30216) = true)

theorem identity30216 : scanCanonicalize (H12AffineFastState.compose env30216 (packedSelected [0,1,2,3,5,11,15,16,17,20,21,23,24,27] rootPS)) = affineNative (2^(9+1) ^^^ 47) := by decide +kernel

theorem selectedBound30216 : packedSelected [0,1,2,3,5,11,15,16,17,20,21,23,24,27] rootPS < 2^1333 := by decide +kernel

def env30217 : List Nat := [2,4,8,16,32,0,128,8,512,47,2048,567,521,55,12,51,570,179,575,13,566,149,525,533,144,13,513,554,54,2080,516,513,9,571,38,16]

theorem envBound30217 : H12AffineFastState.Bounded env30217 := by
  intro p hp
  have h : env30217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30216_30217 : H12AffineEnvironment.transform 9 47 env30216 = env30217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 47 env30216 == env30217) = true)

theorem identity30217 : scanCanonicalize (H12AffineFastState.compose env30217 (packedSelected [0,1,7,8,13,19,20,21] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound30217 : packedSelected [0,1,7,8,13,19,20,21] rootPS < 2^1333 := by decide +kernel

def env30218 : List Nat := [2,4,8,16,26,0,128,8,512,21,2048,525,521,13,12,9,512,137,517,13,524,149,525,533,144,13,513,528,12,2074,516,513,9,513,28,16]

theorem envBound30218 : H12AffineFastState.Bounded env30218 := by
  intro p hp
  have h : env30218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30217_30218 : H12AffineEnvironment.transform 4 26 env30217 = env30218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env30217 == env30218) = true)

theorem identity30218 : scanCanonicalize (H12AffineFastState.compose env30218 (packedSelected [0,1,4,5,7,9,11,12,13,15,16] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound30218 : packedSelected [0,1,4,5,7,9,11,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env30219 : List Nat := [2,4,4,16,22,0,128,4,512,21,2048,513,517,1,0,5,512,133,517,1,512,149,513,533,144,1,513,528,0,2070,516,513,5,513,16,16]

theorem envBound30219 : H12AffineFastState.Bounded env30219 := by
  intro p hp
  have h : env30219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30218_30219 : H12AffineEnvironment.transform 2 4 env30218 = env30219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env30218 == env30219) = true)

theorem identity30219 : scanCanonicalize (H12AffineFastState.compose env30219 (packedSelected [0,3,5,7,10,11] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound30219 : packedSelected [0,3,5,7,10,11] rootPS < 2^1333 := by decide +kernel

def env30220 : List Nat := [2,4,4,16,22,0,128,4,17,21,2048,16,20,1,0,5,17,133,20,1,17,149,16,4,144,1,16,1,0,2070,21,16,5,16,16,16]

theorem envBound30220 : H12AffineFastState.Bounded env30220 := by
  intro p hp
  have h : env30220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30219_30220 : H12AffineEnvironment.transform 8 17 env30219 = env30220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env30219 == env30220) = true)

theorem identity30220 : scanCanonicalize (H12AffineFastState.compose env30220 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound30220 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env30221 : List Nat := [2,4,4,16,22,0,3,4,17,21,2048,16,20,1,0,5,17,6,20,1,17,22,16,4,19,1,16,1,0,2070,21,16,5,16,16,16]

theorem envBound30221 : H12AffineFastState.Bounded env30221 := by
  intro p hp
  have h : env30221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30220_30221 : H12AffineEnvironment.transform 6 3 env30220 = env30221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env30220 == env30221) = true)

theorem identity30221 : scanCanonicalize (H12AffineFastState.compose env30221 (packedSelected [2,5] rootPS)) = affineNative (2^(10+1) ^^^ 22) := by decide +kernel

theorem selectedBound30221 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env30222 : List Nat := [2,4,4,16,22,0,3,4,17,21,22,16,20,1,0,5,17,6,20,1,17,22,16,4,19,1,16,1,0,0,21,16,5,16,16,16]

theorem envBound30222 : H12AffineFastState.Bounded env30222 := by
  intro p hp
  have h : env30222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30221_30222 : H12AffineEnvironment.transform 10 22 env30221 = env30222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 22 env30221 == env30222) = true)

theorem identity30222 : scanCanonicalize (H12AffineFastState.compose env30222 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound30222 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30223 : List Nat := [0,4,4,16,20,0,1,4,17,21,20,16,20,1,0,5,17,4,20,1,17,20,16,4,17,1,16,1,0,0,21,16,5,16,16,16]

theorem envBound30223 : H12AffineFastState.Bounded env30223 := by
  intro p hp
  have h : env30223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30222_30223 : H12AffineEnvironment.transform 0 0 env30222 = env30223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env30222 == env30223) = true)

def env30224 : List Nat := [2,4,8,16,32,0,128,9,512,1024,2048,567,1575,1049,13,1052,1556,1180,574,12,566,148,525,1594,144,1059,512,1540,1048,3087,1578,1583,8,1557,1032,1086]

theorem envBound30224 : H12AffineFastState.Bounded env30224 := by
  intro p hp
  have h : env30224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30215_30224 : H12AffineEnvironment.transform 7 9 env30215 = env30224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 9 env30215 == env30224) = true)

theorem identity30224 : scanCanonicalize (H12AffineFastState.compose env30224 (packedSelected [0,1,2,3,5,11,15,16,17,20,21,23,24,27] rootPS)) = affineNative (2^(9+1) ^^^ 563) := by decide +kernel

theorem selectedBound30224 : packedSelected [0,1,2,3,5,11,15,16,17,20,21,23,24,27] rootPS < 2^1333 := by decide +kernel

def env30225 : List Nat := [2,4,8,16,32,0,128,9,512,563,2048,567,20,554,13,559,39,687,574,12,566,148,525,9,144,528,512,55,555,2620,25,28,8,38,571,525]

theorem envBound30225 : H12AffineFastState.Bounded env30225 := by
  intro p hp
  have h : env30225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30224_30225 : H12AffineEnvironment.transform 9 563 env30224 = env30225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 563 env30224 == env30225) = true)

theorem identity30225 : scanCanonicalize (H12AffineFastState.compose env30225 (packedSelected [0,1,2,3,4,5,7,9,11,13,15,17,23,24] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound30225 : packedSelected [0,1,2,3,4,5,7,9,11,13,15,17,23,24] rootPS < 2^1333 := by decide +kernel

def env30226 : List Nat := [2,4,8,16,6,0,128,9,512,533,2048,529,20,524,13,521,1,649,536,12,528,148,525,9,144,528,512,17,525,2586,25,28,8,0,541,525]

theorem envBound30226 : H12AffineFastState.Bounded env30226 := by
  intro p hp
  have h : env30226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30225_30226 : H12AffineEnvironment.transform 4 6 env30225 = env30226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env30225 == env30226) = true)

theorem identity30226 : scanCanonicalize (H12AffineFastState.compose env30226 (packedSelected [0,3,4,7,9,11,16] rootPS)) = affineNative (2^(10+1) ^^^ 130) := by decide +kernel

theorem selectedBound30226 : packedSelected [0,3,4,7,9,11,16] rootPS < 2^1333 := by decide +kernel

def env30227 : List Nat := [2,4,8,16,6,0,128,9,512,533,130,529,20,524,13,521,1,649,536,12,528,148,525,9,144,528,512,17,525,664,25,28,8,0,541,525]

theorem envBound30227 : H12AffineFastState.Bounded env30227 := by
  intro p hp
  have h : env30227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30226_30227 : H12AffineEnvironment.transform 10 130 env30226 = env30227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 130 env30226 == env30227) = true)

theorem identity30227 : scanCanonicalize (H12AffineFastState.compose env30227 (packedSelected [3,5] rootPS)) = affineNative (2^(8+1) ^^^ 146) := by decide +kernel

theorem selectedBound30227 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env30228 : List Nat := [2,4,8,16,6,0,128,9,146,135,130,131,20,158,13,155,1,27,138,12,130,148,159,9,144,130,146,17,159,10,25,28,8,0,143,159]

theorem envBound30228 : H12AffineFastState.Bounded env30228 := by
  intro p hp
  have h : env30228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30227_30228 : H12AffineEnvironment.transform 8 146 env30227 = env30228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 146 env30227 == env30228) = true)

theorem identity30228 : scanCanonicalize (H12AffineFastState.compose env30228 (packedSelected [2,8] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound30228 : packedSelected [2,8] rootPS < 2^1333 := by decide +kernel

def env30229 : List Nat := [2,4,8,10,6,0,128,9,136,135,130,131,14,132,13,129,1,1,138,12,130,142,133,9,138,130,136,11,133,10,3,6,8,0,143,133]

theorem envBound30229 : H12AffineFastState.Bounded env30229 := by
  intro p hp
  have h : env30229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30228_30229 : H12AffineEnvironment.transform 3 10 env30228 = env30229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env30228 == env30229) = true)

def env30230 : List Nat := [2,4,8,16,32,1,128,256,512,1024,2048,566,1838,1296,261,1052,1820,1180,823,260,567,412,525,1595,144,1323,776,1805,1297,3087,1827,1830,257,1820,1280,1335]

theorem envBound30230 : H12AffineFastState.Bounded env30230 := by
  intro p hp
  have h : env30230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30214_30230 : H12AffineEnvironment.transform 5 1 env30214 = env30230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env30214 == env30230) = true)

def env30231 : List Nat := [2,4,8,16,32,1,128,8,512,1024,2048,566,1574,1048,13,1052,1556,1180,575,12,567,148,525,1595,144,1059,512,1541,1049,3087,1579,1582,9,1556,1032,1087]

theorem envBound30231 : H12AffineFastState.Bounded env30231 := by
  intro p hp
  have h : env30231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30230_30231 : H12AffineEnvironment.transform 7 8 env30230 = env30231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 8 env30230 == env30231) = true)

theorem identity30231 : scanCanonicalize (H12AffineFastState.compose env30231 (packedSelected [0,1,2,3,5,11,15,16,17,20,21,23,24,27] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound30231 : packedSelected [0,1,2,3,5,11,15,16,17,20,21,23,24,27] rootPS < 2^1333 := by decide +kernel

def env30232 : List Nat := [2,4,8,16,32,1,128,8,512,21,2048,566,563,13,13,9,513,137,575,12,567,148,525,558,144,54,512,528,12,2074,574,571,9,513,29,42]

theorem envBound30232 : H12AffineFastState.Bounded env30232 := by
  intro p hp
  have h : env30232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30231_30232 : H12AffineEnvironment.transform 9 21 env30231 = env30232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env30231 == env30232) = true)

theorem identity30232 : scanCanonicalize (H12AffineFastState.compose env30232 (packedSelected [2,3,4,5,8,9,11,15,17,19,20,21,23,24] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound30232 : packedSelected [2,3,4,5,8,9,11,15,17,19,20,21,23,24] rootPS < 2^1333 := by decide +kernel

def env30233 : List Nat := [2,4,8,13,32,1,128,8,512,8,2048,555,558,13,13,9,513,137,546,12,554,137,525,558,141,43,512,525,12,2055,547,550,9,513,0,42]

theorem envBound30233 : H12AffineFastState.Bounded env30233 := by
  intro p hp
  have h : env30233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30232_30233 : H12AffineEnvironment.transform 3 13 env30232 = env30233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env30232 == env30233) = true)

theorem identity30233 : scanCanonicalize (H12AffineFastState.compose env30233 (packedSelected [2,5,10,13,15,17] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound30233 : packedSelected [2,5,10,13,15,17] rootPS < 2^1333 := by decide +kernel

def env30234 : List Nat := [2,4,5,0,32,1,128,5,512,5,2048,550,547,0,0,4,513,132,546,1,551,132,512,547,128,38,512,512,1,2055,547,550,4,513,0,39]

theorem envBound30234 : H12AffineFastState.Bounded env30234 := by
  intro p hp
  have h : env30234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30233_30234 : H12AffineEnvironment.transform 2 5 env30233 = env30234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env30233 == env30234) = true)

theorem identity30234 : scanCanonicalize (H12AffineFastState.compose env30234 (packedSelected [0,2,3,5,7,8,10,11,13] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound30234 : packedSelected [0,2,3,5,7,8,10,11,13] rootPS < 2^1333 := by decide +kernel

def env30235 : List Nat := [2,4,5,0,32,1,128,5,32,5,2048,6,3,0,0,4,33,132,2,1,7,132,32,3,128,38,32,32,1,2055,3,6,4,33,0,39]

theorem envBound30235 : H12AffineFastState.Bounded env30235 := by
  intro p hp
  have h : env30235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30234_30235 : H12AffineEnvironment.transform 8 32 env30234 = env30235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env30234 == env30235) = true)

theorem identity30235 : scanCanonicalize (H12AffineFastState.compose env30235 (packedSelected [0,2,7] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound30235 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env30236 : List Nat := [2,3,2,0,32,1,128,2,32,2,2048,1,3,0,0,3,33,131,2,1,0,131,32,3,128,33,32,32,1,2048,3,1,3,33,0,32]

theorem envBound30236 : H12AffineFastState.Bounded env30236 := by
  intro p hp
  have h : env30236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30235_30236 : H12AffineEnvironment.transform 1 3 env30235 = env30236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env30235 == env30236) = true)

theorem identity30236 : scanCanonicalize (H12AffineFastState.compose env30236 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 131) := by decide +kernel

theorem selectedBound30236 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30237 : List Nat := [2,3,2,0,32,1,128,2,32,2,131,1,3,0,0,3,33,131,2,1,0,131,32,3,128,33,32,32,1,131,3,1,3,33,0,32]

theorem envBound30237 : H12AffineFastState.Bounded env30237 := by
  intro p hp
  have h : env30237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30236_30237 : H12AffineEnvironment.transform 10 131 env30236 = env30237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 131 env30236 == env30237) = true)

theorem identity30237 : scanCanonicalize (H12AffineFastState.compose env30237 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound30237 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env30238 : List Nat := [2,3,2,0,1,1,128,2,1,2,131,1,3,0,0,3,0,131,2,1,0,131,1,3,128,0,1,1,1,131,3,1,3,0,0,1]

theorem envBound30238 : H12AffineFastState.Bounded env30238 := by
  intro p hp
  have h : env30238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30237_30238 : H12AffineEnvironment.transform 4 1 env30237 = env30238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env30237 == env30238) = true)

def env30239 : List Nat := [2,4,8,16,32,1,128,9,512,1024,2048,566,1575,1049,12,1052,1557,1180,574,13,567,149,525,1595,144,1058,513,1540,1048,3087,1578,1583,8,1557,1033,1086]

theorem envBound30239 : H12AffineFastState.Bounded env30239 := by
  intro p hp
  have h : env30239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30230_30239 : H12AffineEnvironment.transform 7 9 env30230 = env30239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 9 env30230 == env30239) = true)

theorem identity30239 : scanCanonicalize (H12AffineFastState.compose env30239 (packedSelected [0,1,2,3,5,11,15,16,17,20,21,23,24,27] rootPS)) = affineNative (2^(9+1) ^^^ 521) := by decide +kernel

theorem selectedBound30239 : packedSelected [0,1,2,3,5,11,15,16,17,20,21,23,24,27] rootPS < 2^1333 := by decide +kernel

def env30240 : List Nat := [2,4,8,16,32,1,128,9,512,521,2048,566,46,528,12,533,28,661,574,13,567,149,525,50,144,555,513,13,529,2566,35,38,8,28,512,567]

theorem envBound30240 : H12AffineFastState.Bounded env30240 := by
  intro p hp
  have h : env30240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30239_30240 : H12AffineEnvironment.transform 9 521 env30239 = env30240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 521 env30239 == env30240) = true)

theorem identity30240 : scanCanonicalize (H12AffineFastState.compose env30240 (packedSelected [0,1,7,8,13,19,20,21] rootPS)) = affineNative (2^(8+1) ^^^ 29) := by decide +kernel

theorem selectedBound30240 : packedSelected [0,1,7,8,13,19,20,21] rootPS < 2^1333 := by decide +kernel

def env30241 : List Nat := [2,4,8,16,32,1,128,9,29,20,2048,43,46,13,12,8,28,136,35,13,42,149,16,50,144,54,28,13,12,2075,35,38,8,28,29,42]

theorem envBound30241 : H12AffineFastState.Bounded env30241 := by
  intro p hp
  have h : env30241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30240_30241 : H12AffineEnvironment.transform 8 29 env30240 = env30241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 29 env30240 == env30241) = true)

theorem identity30241 : scanCanonicalize (H12AffineFastState.compose env30241 (packedSelected [3,4,9,10,16,17] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound30241 : packedSelected [3,4,9,10,16,17] rootPS < 2^1333 := by decide +kernel

def env30242 : List Nat := [2,4,5,16,32,1,128,4,16,20,2048,38,35,0,1,5,17,133,35,0,39,149,16,50,144,54,17,0,1,2070,35,38,5,17,16,39]

theorem envBound30242 : H12AffineFastState.Bounded env30242 := by
  intro p hp
  have h : env30242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30241_30242 : H12AffineEnvironment.transform 2 5 env30241 = env30242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env30241 == env30242) = true)

theorem identity30242 : scanCanonicalize (H12AffineFastState.compose env30242 (packedSelected [5,10] rootPS)) = affineNative (2^(10+1) ^^^ 130) := by decide +kernel

theorem selectedBound30242 : packedSelected [5,10] rootPS < 2^1333 := by decide +kernel

def env30243 : List Nat := [2,4,5,16,32,1,128,4,16,20,130,38,35,0,1,5,17,133,35,0,39,149,16,50,144,54,17,0,1,148,35,38,5,17,16,39]

theorem envBound30243 : H12AffineFastState.Bounded env30243 := by
  intro p hp
  have h : env30243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30242_30243 : H12AffineEnvironment.transform 10 130 env30242 = env30243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 130 env30242 == env30243) = true)

theorem identity30243 : scanCanonicalize (H12AffineFastState.compose env30243 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(4+1) ^^^ 23) := by decide +kernel

theorem selectedBound30243 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env30244 : List Nat := [2,4,5,16,23,1,128,4,16,20,130,17,20,0,1,5,17,133,20,0,16,149,16,5,144,1,17,0,1,148,20,17,5,17,16,16]

theorem envBound30244 : H12AffineFastState.Bounded env30244 := by
  intro p hp
  have h : env30244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30243_30244 : H12AffineEnvironment.transform 4 23 env30243 = env30244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 23 env30243 == env30244) = true)

theorem identity30244 : scanCanonicalize (H12AffineFastState.compose env30244 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound30244 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env30245 : List Nat := [2,4,5,16,23,1,5,4,16,20,7,17,20,0,1,5,17,0,20,0,16,16,16,5,21,1,17,0,1,17,20,17,5,17,16,16]

theorem envBound30245 : H12AffineFastState.Bounded env30245 := by
  intro p hp
  have h : env30245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30244_30245 : H12AffineEnvironment.transform 6 5 env30244 = env30245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env30244 == env30245) = true)

theorem identity30245 : scanCanonicalize (H12AffineFastState.compose env30245 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound30245 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30246 : List Nat := [2,3,2,16,16,1,2,3,16,19,0,17,19,0,1,2,17,0,19,0,16,16,16,2,18,1,17,0,1,17,19,17,2,17,16,16]

theorem envBound30246 : H12AffineFastState.Bounded env30246 := by
  intro p hp
  have h : env30246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30245_30246 : H12AffineEnvironment.transform 1 3 env30245 = env30246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env30245 == env30246) = true)

theorem identity30246 : scanCanonicalize (H12AffineFastState.compose env30246 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound30246 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30247 : List Nat := [2,3,2,0,0,1,2,3,0,3,0,1,3,0,1,2,1,0,3,0,0,0,0,2,2,1,1,0,1,1,3,1,2,1,0,0]

theorem envBound30247 : H12AffineFastState.Bounded env30247 := by
  intro p hp
  have h : env30247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30246_30247 : H12AffineEnvironment.transform 3 0 env30246 = env30247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env30246 == env30247) = true)

def env30248 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5465,1296,324,1053,5419,1181,4416,325,4097,477,4219,5132,144,1387,4414,5499,1297,3086,5460,5457,257,5482,1345,5952]

theorem envBound30248 : H12AffineFastState.Bounded env30248 := by
  intro p hp
  have h : env30248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30212_30248 : H12AffineEnvironment.transform 15 1053 env30212 = env30248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1053 env30212 == env30248) = true)

theorem identity30248 : scanCanonicalize (H12AffineFastState.compose env30248 (packedSelected [0,2,3,5,8,11,15,16,17,20,21,23,24,27,28] rootPS)) = affineNative (2^(11+1) ^^^ 589) := by decide +kernel

theorem selectedBound30248 : packedSelected [0,2,3,5,8,11,15,16,17,20,21,23,24,27,28] rootPS < 2^1333 := by decide +kernel

def env30249 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,589,1812,1296,324,1053,1894,1181,781,325,588,477,566,1601,144,1387,883,1846,1297,3086,1817,1820,257,1831,1345,1293]

theorem envBound30249 : H12AffineFastState.Bounded env30249 := by
  intro p hp
  have h : env30249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30248_30249 : H12AffineEnvironment.transform 11 589 env30248 = env30249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 589 env30248 == env30249) = true)

def env30250 : List Nat := [2,4,8,16,32,64,128,256,344,1024,2048,277,1100,1296,324,1053,1086,1181,85,325,276,477,366,1305,144,1387,43,1134,1297,3086,1089,1092,257,1151,1345,1293]

theorem envBound30250 : H12AffineFastState.Bounded env30250 := by
  intro p hp
  have h : env30250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30249_30250 : H12AffineEnvironment.transform 8 344 env30249 = env30250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 344 env30249 == env30250) = true)

theorem identity30250 : scanCanonicalize (H12AffineFastState.compose env30250 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 379) := by decide +kernel

theorem selectedBound30250 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env30251 : List Nat := [2,4,8,16,32,64,128,256,344,379,2048,277,311,107,324,358,325,486,85,325,276,477,366,98,144,16,43,277,106,2421,314,319,257,260,58,118]

theorem envBound30251 : H12AffineFastState.Bounded env30251 := by
  intro p hp
  have h : env30251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30250_30251 : H12AffineEnvironment.transform 9 379 env30250 = env30251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 379 env30250 == env30251) = true)

theorem identity30251 : scanCanonicalize (H12AffineFastState.compose env30251 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 46) := by decide +kernel

theorem selectedBound30251 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env30252 : List Nat := [2,4,8,16,32,64,128,46,118,85,2048,59,25,107,106,72,107,200,85,107,58,243,64,98,144,16,43,59,106,2139,20,17,47,42,58,118]

theorem envBound30252 : H12AffineFastState.Bounded env30252 := by
  intro p hp
  have h : env30252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30251_30252 : H12AffineEnvironment.transform 7 46 env30251 = env30252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 46 env30251 == env30252) = true)

theorem identity30252 : scanCanonicalize (H12AffineFastState.compose env30252 (packedSelected [0,5,7,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 95) := by decide +kernel

theorem selectedBound30252 : packedSelected [0,5,7,11,12] rootPS < 2^1333 := by decide +kernel

def env30253 : List Nat := [2,4,8,16,32,64,95,46,118,85,2048,59,25,107,106,72,107,23,85,107,58,44,64,98,79,16,43,59,106,2139,20,17,47,42,58,118]

theorem envBound30253 : H12AffineFastState.Bounded env30253 := by
  intro p hp
  have h : env30253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30252_30253 : H12AffineEnvironment.transform 6 95 env30252 = env30253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 95 env30252 == env30253) = true)

theorem identity30253 : scanCanonicalize (H12AffineFastState.compose env30253 (packedSelected [5,8,13] rootPS)) = affineNative (2^(4+1) ^^^ 23) := by decide +kernel

theorem selectedBound30253 : packedSelected [5,8,13] rootPS < 2^1333 := by decide +kernel

def env30254 : List Nat := [2,4,8,16,23,64,95,25,65,85,2048,12,25,92,93,72,92,23,85,92,13,27,64,85,79,16,28,12,93,2139,20,17,24,29,13,65]

theorem envBound30254 : H12AffineFastState.Bounded env30254 := by
  intro p hp
  have h : env30254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30253_30254 : H12AffineEnvironment.transform 4 23 env30253 = env30254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 23 env30253 == env30254) = true)

theorem identity30254 : scanCanonicalize (H12AffineFastState.compose env30254 (packedSelected [1,2,3,4,5,8,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 26) := by decide +kernel

theorem selectedBound30254 : packedSelected [1,2,3,4,5,8,9,11] rootPS < 2^1333 := by decide +kernel

def env30255 : List Nat := [2,4,8,16,23,26,5,25,27,15,2048,12,25,6,7,18,6,23,15,6,13,27,26,15,21,16,28,12,7,2049,20,17,24,29,13,27]

theorem envBound30255 : H12AffineFastState.Bounded env30255 := by
  intro p hp
  have h : env30255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30254_30255 : H12AffineEnvironment.transform 5 26 env30254 = env30255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 26 env30254 == env30255) = true)

theorem identity30255 : scanCanonicalize (H12AffineFastState.compose env30255 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound30255 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30256 : List Nat := [2,4,8,16,23,26,5,25,27,15,17,12,25,6,7,18,6,23,15,6,13,27,26,15,21,16,28,12,7,16,20,17,24,29,13,27]

theorem envBound30256 : H12AffineFastState.Bounded env30256 := by
  intro p hp
  have h : env30256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30255_30256 : H12AffineEnvironment.transform 10 17 env30255 = env30256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env30255 == env30256) = true)

theorem identity30256 : scanCanonicalize (H12AffineFastState.compose env30256 (packedSelected [0,1,3] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound30256 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env30257 : List Nat := [2,4,4,16,23,22,5,21,23,3,17,0,21,6,7,18,6,23,3,6,1,23,22,3,21,16,16,0,7,16,20,17,20,17,1,23]

theorem envBound30257 : H12AffineFastState.Bounded env30257 := by
  intro p hp
  have h : env30257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30256_30257 : H12AffineEnvironment.transform 2 4 env30256 = env30257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env30256 == env30257) = true)

theorem identity30257 : scanCanonicalize (H12AffineFastState.compose env30257 (packedSelected [0,1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound30257 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env30258 : List Nat := [2,2,2,16,17,16,3,19,17,3,17,0,19,0,1,18,0,17,3,0,1,17,16,3,19,16,16,0,1,16,18,17,18,17,1,17]

theorem envBound30258 : H12AffineFastState.Bounded env30258 := by
  intro p hp
  have h : env30258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30257_30258 : H12AffineEnvironment.transform 1 2 env30257 = env30258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env30257 == env30258) = true)

theorem identity30258 : scanCanonicalize (H12AffineFastState.compose env30258 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound30258 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30259 : List Nat := [2,2,2,0,1,0,3,3,1,3,1,0,3,0,1,2,0,1,3,0,1,1,0,3,3,0,0,0,1,0,2,1,2,1,1,1]

theorem envBound30259 : H12AffineFastState.Bounded env30259 := by
  intro p hp
  have h : env30259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30258_30259 : H12AffineEnvironment.transform 3 0 env30258 = env30259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env30258 == env30259) = true)

def env30260 : List Nat := [2,4,8,16,32,64,128,256,345,1024,2048,276,1101,1296,324,1053,1087,1181,84,325,277,477,367,1304,144,1387,42,1135,1297,3086,1088,1093,257,1150,1345,1293]

theorem envBound30260 : H12AffineFastState.Bounded env30260 := by
  intro p hp
  have h : env30260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30249_30260 : H12AffineEnvironment.transform 8 345 env30249 = env30260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 345 env30249 == env30260) = true)

theorem identity30260 : scanCanonicalize (H12AffineFastState.compose env30260 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound30260 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env30261 : List Nat := [2,4,8,16,32,64,128,256,345,320,2048,276,269,80,324,349,383,477,84,325,277,477,367,88,144,43,42,303,81,2382,256,261,257,318,1,77]

theorem envBound30261 : H12AffineFastState.Bounded env30261 := by
  intro p hp
  have h : env30261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30260_30261 : H12AffineEnvironment.transform 9 320 env30260 = env30261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env30260 == env30261) = true)

theorem identity30261 : scanCanonicalize (H12AffineFastState.compose env30261 (packedSelected [1,2,3,5,8,10,13,19,21,23,32] rootPS)) = affineNative (2^(7+1) ^^^ 186) := by decide +kernel

theorem selectedBound30261 : packedSelected [1,2,3,5,8,10,13,19,21,23,32] rootPS < 2^1333 := by decide +kernel

def env30262 : List Nat := [2,4,8,16,32,64,128,186,227,250,2048,174,183,80,254,231,197,103,84,255,175,103,213,88,144,43,42,149,81,2292,186,191,187,132,1,77]

theorem envBound30262 : H12AffineFastState.Bounded env30262 := by
  intro p hp
  have h : env30262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30261_30262 : H12AffineEnvironment.transform 7 186 env30261 = env30262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 186 env30261 == env30262) = true)

theorem identity30262 : scanCanonicalize (H12AffineFastState.compose env30262 (packedSelected [2,4,8,9,10,11,13,15,16,17,18,21] rootPS)) = affineNative (2^(6+1) ^^^ 20) := by decide +kernel

theorem selectedBound30262 : packedSelected [2,4,8,9,10,11,13,15,16,17,18,21] rootPS < 2^1333 := by decide +kernel

def env30263 : List Nat := [2,4,8,16,32,64,20,46,119,110,2048,58,35,80,106,115,81,103,84,107,59,103,65,88,4,43,42,1,81,2144,46,43,47,16,1,77]

theorem envBound30263 : H12AffineFastState.Bounded env30263 := by
  intro p hp
  have h : env30263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30262_30263 : H12AffineEnvironment.transform 6 20 env30262 = env30263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 20 env30262 == env30263) = true)

theorem identity30263 : scanCanonicalize (H12AffineFastState.compose env30263 (packedSelected [4,9,16] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound30263 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env30264 : List Nat := [2,4,8,16,27,64,20,21,76,85,2048,1,24,80,81,72,81,92,84,80,0,92,65,88,4,16,17,1,81,2139,21,16,20,16,1,77]

theorem envBound30264 : H12AffineFastState.Bounded env30264 := by
  intro p hp
  have h : env30264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30263_30264 : H12AffineEnvironment.transform 4 27 env30263 = env30264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env30263 == env30264) = true)

theorem identity30264 : scanCanonicalize (H12AffineFastState.compose env30264 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound30264 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env30265 : List Nat := [2,4,3,16,16,64,20,21,71,85,2048,1,19,80,81,67,81,87,84,80,0,87,65,83,4,16,17,1,81,2128,21,16,20,16,1,70]

theorem envBound30265 : H12AffineFastState.Bounded env30265 := by
  intro p hp
  have h : env30265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30264_30265 : H12AffineEnvironment.transform 2 3 env30264 = env30265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env30264 == env30265) = true)

theorem identity30265 : scanCanonicalize (H12AffineFastState.compose env30265 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound30265 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env30266 : List Nat := [2,4,3,16,16,1,20,21,6,20,2048,1,19,17,16,2,16,22,21,17,0,22,0,18,4,16,17,1,16,2065,21,16,20,16,1,7]

theorem envBound30266 : H12AffineFastState.Bounded env30266 := by
  intro p hp
  have h : env30266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30265_30266 : H12AffineEnvironment.transform 5 1 env30265 = env30266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env30265 == env30266) = true)

theorem identity30266 : scanCanonicalize (H12AffineFastState.compose env30266 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 5) := by decide +kernel

theorem selectedBound30266 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env30267 : List Nat := [2,4,3,16,16,1,20,21,6,20,5,1,19,17,16,2,16,22,21,17,0,22,0,18,4,16,17,1,16,20,21,16,20,16,1,7]

theorem envBound30267 : H12AffineFastState.Bounded env30267 := by
  intro p hp
  have h : env30267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30266_30267 : H12AffineEnvironment.transform 10 5 env30266 = env30267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 5 env30266 == env30267) = true)

theorem identity30267 : scanCanonicalize (H12AffineFastState.compose env30267 (packedSelected [2,7] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound30267 : packedSelected [2,7] rootPS < 2^1333 := by decide +kernel

def env30268 : List Nat := [2,0,3,16,16,1,16,17,2,16,1,1,19,17,16,2,16,18,17,17,0,18,0,18,0,16,17,1,16,16,17,16,16,16,1,3]

theorem envBound30268 : H12AffineFastState.Bounded env30268 := by
  intro p hp
  have h : env30268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30267_30268 : H12AffineEnvironment.transform 1 0 env30267 = env30268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env30267 == env30268) = true)

theorem identity30268 : scanCanonicalize (H12AffineFastState.compose env30268 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound30268 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30269 : List Nat := [2,0,3,3,3,1,3,2,2,3,1,1,0,2,3,2,3,1,2,2,0,1,0,1,0,3,2,1,3,3,2,3,3,3,1,3]

theorem envBound30269 : H12AffineFastState.Bounded env30269 := by
  intro p hp
  have h : env30269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30268_30269 : H12AffineEnvironment.transform 3 3 env30268 = env30269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env30268 == env30269) = true)

def env30270 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74863,65665,4416,13340,4097,477,74047,69649,13769,78895,4415,74815,1297,81226,8205,8200,257,74798,1345,5952]

theorem envBound30270 : H12AffineFastState.Bounded env30270 := by
  intro p hp
  have h : env30270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30210_30270 : H12AffineEnvironment.transform 17 65665 env30210 = env30270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env30210 == env30270) = true)

theorem identity30270 : scanCanonicalize (H12AffineFastState.compose env30270 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound30270 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env30271 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,24,1296,5125,65536,66679,65665,4416,5124,4097,477,65831,69649,5585,70711,4415,66599,1297,73042,21,16,257,66614,1345,5952]

theorem envBound30271 : H12AffineFastState.Bounded env30271 := by
  intro p hp
  have h : env30271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30270_30271 : H12AffineEnvironment.transform 12 24 env30270 = env30271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env30270 == env30271) = true)

def env30272 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,24,1296,5125,1052,107,1181,4416,5124,4097,477,1339,5133,5585,4139,4415,59,1297,6478,21,16,257,42,1345,5952]

theorem envBound30272 : H12AffineFastState.Bounded env30272 := by
  intro p hp
  have h : env30272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30271_30272 : H12AffineEnvironment.transform 15 1052 env30271 = env30272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1052 env30271 == env30272) = true)

theorem identity30272 : scanCanonicalize (H12AffineFastState.compose env30272 (packedSelected [0,1,2,4,7,9,10,11,15,17,19,21,23,24,28] rootPS)) = affineNative (2^(11+1) ^^^ 1570) := by decide +kernel

theorem selectedBound30272 : packedSelected [0,1,2,4,7,9,10,11,15,17,19,21,23,24,28] rootPS < 2^1333 := by decide +kernel

def env30273 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1570,24,1296,551,1052,107,1181,1890,550,1571,477,1339,559,1011,1545,1821,59,1297,3948,21,16,257,42,1345,354]

theorem envBound30273 : H12AffineFastState.Bounded env30273 := by
  intro p hp
  have h : env30273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30272_30273 : H12AffineEnvironment.transform 11 1570 env30272 = env30273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1570 env30272 == env30273) = true)

def env30274 : List Nat := [2,4,8,16,32,64,128,256,512,780,2048,302,24,540,551,784,107,913,110,550,303,477,567,559,1011,261,17,59,541,2144,21,16,257,42,589,354]

theorem envBound30274 : H12AffineFastState.Bounded env30274 := by
  intro p hp
  have h : env30274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30273_30274 : H12AffineEnvironment.transform 9 780 env30273 = env30274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 780 env30273 == env30274) = true)

theorem identity30274 : scanCanonicalize (H12AffineFastState.compose env30274 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound30274 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env30275 : List Nat := [2,4,8,16,32,64,128,21,512,537,2048,59,24,540,551,517,107,644,110,550,58,200,567,559,742,16,17,59,541,2144,21,16,20,42,589,119]

theorem envBound30275 : H12AffineFastState.Bounded env30275 := by
  intro p hp
  have h : env30275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30274_30275 : H12AffineEnvironment.transform 7 21 env30274 = env30275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env30274 == env30275) = true)

theorem identity30275 : scanCanonicalize (H12AffineFastState.compose env30275 (packedSelected [4,9,16] rootPS)) = affineNative (2^(8+1) ^^^ 76) := by decide +kernel

theorem selectedBound30275 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env30276 : List Nat := [2,4,8,16,32,64,128,21,76,85,2048,59,24,80,107,73,107,200,110,106,58,200,123,99,170,16,17,59,81,2144,21,16,20,42,1,119]

theorem envBound30276 : H12AffineFastState.Bounded env30276 := by
  intro p hp
  have h : env30276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30275_30276 : H12AffineEnvironment.transform 8 76 env30275 = env30276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 76 env30275 == env30276) = true)

theorem identity30276 : scanCanonicalize (H12AffineFastState.compose env30276 (packedSelected [0,2,5,7,10,11,15,17] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound30276 : packedSelected [0,2,5,7,10,11,15,17] rootPS < 2^1333 := by decide +kernel

def env30277 : List Nat := [2,4,3,16,32,64,128,21,71,85,2048,48,19,80,96,66,96,195,101,97,49,195,112,99,161,16,17,48,81,2144,21,16,20,33,1,119]

theorem envBound30277 : H12AffineFastState.Bounded env30277 := by
  intro p hp
  have h : env30277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30276_30277 : H12AffineEnvironment.transform 2 3 env30276 = env30277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env30276 == env30277) = true)

theorem identity30277 : scanCanonicalize (H12AffineFastState.compose env30277 (packedSelected [0,3,5,7,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound30277 : packedSelected [0,3,5,7,11,12] rootPS < 2^1333 := by decide +kernel

def env30278 : List Nat := [2,4,3,16,32,1,128,21,6,20,2048,48,19,17,33,3,33,130,36,32,49,130,49,34,161,16,17,48,16,2081,21,16,20,33,1,54]

theorem envBound30278 : H12AffineFastState.Bounded env30278 := by
  intro p hp
  have h : env30278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30277_30278 : H12AffineEnvironment.transform 5 1 env30277 = env30278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env30277 == env30278) = true)

theorem identity30278 : scanCanonicalize (H12AffineFastState.compose env30278 (packedSelected [0,1,2,9,10] rootPS)) = affineNative (2^(10+1) ^^^ 23) := by decide +kernel

theorem selectedBound30278 : packedSelected [0,1,2,9,10] rootPS < 2^1333 := by decide +kernel

def env30279 : List Nat := [2,4,3,16,32,1,128,21,6,20,23,48,19,17,33,3,33,130,36,32,49,130,49,34,161,16,17,48,16,54,21,16,20,33,1,54]

theorem envBound30279 : H12AffineFastState.Bounded env30279 := by
  intro p hp
  have h : env30279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30278_30279 : H12AffineEnvironment.transform 10 23 env30278 = env30279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 23 env30278 == env30279) = true)

theorem identity30279 : scanCanonicalize (H12AffineFastState.compose env30279 (packedSelected [0,1,3,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound30279 : packedSelected [0,1,3,5,7] rootPS < 2^1333 := by decide +kernel

def env30280 : List Nat := [2,4,3,16,16,1,128,21,6,20,23,0,19,17,17,3,17,130,20,16,1,130,1,18,145,16,17,0,16,6,21,16,20,17,1,6]

theorem envBound30280 : H12AffineFastState.Bounded env30280 := by
  intro p hp
  have h : env30280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30279_30280 : H12AffineEnvironment.transform 4 16 env30279 = env30280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env30279 == env30280) = true)

def env30281 : List Nat := [2,4,8,16,32,64,128,256,512,781,2048,303,24,541,551,785,107,912,111,550,302,477,566,559,1011,260,16,59,540,2145,21,16,257,42,588,354]

theorem envBound30281 : H12AffineFastState.Bounded env30281 := by
  intro p hp
  have h : env30281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30273_30281 : H12AffineEnvironment.transform 9 781 env30273 = env30281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 781 env30273 == env30281) = true)

theorem identity30281 : scanCanonicalize (H12AffineFastState.compose env30281 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 46) := by decide +kernel

theorem selectedBound30281 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env30282 : List Nat := [2,4,8,16,32,64,128,46,512,547,2048,1,24,541,551,575,107,702,111,550,0,243,566,559,733,42,16,59,540,2145,21,16,47,42,588,76]

theorem envBound30282 : H12AffineFastState.Bounded env30282 := by
  intro p hp
  have h : env30282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30281_30282 : H12AffineEnvironment.transform 7 46 env30281 = env30282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 46 env30281 == env30282) = true)

theorem identity30282 : scanCanonicalize (H12AffineFastState.compose env30282 (packedSelected [2,23,32] rootPS)) = affineNative (2^(8+1) ^^^ 178) := by decide +kernel

theorem selectedBound30282 : packedSelected [2,23,32] rootPS < 2^1333 := by decide +kernel

def env30283 : List Nat := [2,4,8,16,32,64,128,46,178,145,2048,1,24,175,149,141,107,12,111,148,0,243,132,157,111,42,16,59,174,2145,21,16,47,42,254,76]

theorem envBound30283 : H12AffineFastState.Bounded env30283 := by
  intro p hp
  have h : env30283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30282_30283 : H12AffineEnvironment.transform 8 178 env30282 = env30283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 178 env30282 == env30283) = true)

theorem identity30283 : scanCanonicalize (H12AffineFastState.compose env30283 (packedSelected [1,3,5,13,17,19,24] rootPS)) = affineNative (2^(5+1) ^^^ 26) := by decide +kernel

theorem selectedBound30283 : packedSelected [1,3,5,13,17,19,24] rootPS < 2^1333 := by decide +kernel

def env30284 : List Nat := [2,4,8,16,32,26,128,46,178,145,2048,1,24,175,149,141,49,12,53,148,0,169,132,157,53,42,16,59,174,2107,21,16,47,42,164,22]

theorem envBound30284 : H12AffineFastState.Bounded env30284 := by
  intro p hp
  have h : env30284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30283_30284 : H12AffineEnvironment.transform 5 26 env30283 = env30284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 26 env30283 == env30284) = true)

theorem identity30284 : scanCanonicalize (H12AffineFastState.compose env30284 (packedSelected [0,1,2,3,4,7,9,10,11,15,16,17] rootPS)) = affineNative (2^(10+1) ^^^ 39) := by decide +kernel

theorem selectedBound30284 : packedSelected [0,1,2,3,4,7,9,10,11,15,16,17] rootPS < 2^1333 := by decide +kernel

def env30285 : List Nat := [2,4,8,16,32,26,128,46,178,145,39,1,24,175,149,141,49,12,53,148,0,169,132,157,53,42,16,59,174,28,21,16,47,42,164,22]

theorem envBound30285 : H12AffineFastState.Bounded env30285 := by
  intro p hp
  have h : env30285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30284_30285 : H12AffineEnvironment.transform 10 39 env30284 = env30285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 39 env30284 == env30285) = true)

theorem identity30285 : scanCanonicalize (H12AffineFastState.compose env30285 (packedSelected [0,1,5,7,10,11,12] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound30285 : packedSelected [0,1,5,7,10,11,12] rootPS < 2^1333 := by decide +kernel

def env30286 : List Nat := [2,4,8,16,7,26,128,9,149,145,0,1,24,136,149,141,22,12,18,148,0,142,132,157,18,13,16,28,137,28,21,16,8,13,131,22]

theorem envBound30286 : H12AffineFastState.Bounded env30286 := by
  intro p hp
  have h : env30286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30285_30286 : H12AffineEnvironment.transform 4 7 env30285 = env30286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env30285 == env30286) = true)

theorem identity30286 : scanCanonicalize (H12AffineFastState.compose env30286 (packedSelected [0,1,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound30286 : packedSelected [0,1,7,8] rootPS < 2^1333 := by decide +kernel

def env30287 : List Nat := [2,4,8,16,7,26,4,9,17,21,0,1,24,12,17,9,22,12,18,16,0,10,0,25,18,13,16,28,13,28,21,16,8,13,7,22]

theorem envBound30287 : H12AffineFastState.Bounded env30287 := by
  intro p hp
  have h : env30287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30286_30287 : H12AffineEnvironment.transform 6 4 env30286 = env30287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env30286 == env30287) = true)

theorem identity30287 : scanCanonicalize (H12AffineFastState.compose env30287 (packedSelected [1,2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound30287 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env30288 : List Nat := [2,4,3,16,7,17,4,2,17,21,0,1,19,7,17,2,22,7,18,16,0,1,0,18,18,6,16,23,6,23,21,16,3,6,7,22]

theorem envBound30288 : H12AffineFastState.Bounded env30288 := by
  intro p hp
  have h : env30288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30287_30288 : H12AffineEnvironment.transform 2 3 env30287 = env30288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env30287 == env30288) = true)

theorem identity30288 : scanCanonicalize (H12AffineFastState.compose env30288 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound30288 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env30289 : List Nat := [2,4,3,0,7,1,4,2,1,5,0,1,3,7,1,2,6,7,2,0,0,1,0,2,2,6,0,7,6,7,5,0,3,6,7,6]

theorem envBound30289 : H12AffineFastState.Bounded env30289 := by
  intro p hp
  have h : env30289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30288_30289 : H12AffineEnvironment.transform 3 0 env30288 = env30289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env30288 == env30289) = true)

def env30290 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,24,1296,5125,1053,106,1180,4416,5124,4097,477,1338,5132,5585,4138,4415,58,1297,6479,21,16,257,43,1345,5952]

theorem envBound30290 : H12AffineFastState.Bounded env30290 := by
  intro p hp
  have h : env30290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30271_30290 : H12AffineEnvironment.transform 15 1053 env30271 = env30290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1053 env30271 == env30290) = true)

theorem identity30290 : scanCanonicalize (H12AffineFastState.compose env30290 (packedSelected [0,1,2,4,7,9,10,11,15,17,19,21,23,24,28] rootPS)) = affineNative (2^(11+1) ^^^ 1560) := by decide +kernel

theorem selectedBound30290 : packedSelected [0,1,2,4,7,9,10,11,15,17,19,21,23,24,28] rootPS < 2^1333 := by decide +kernel

def env30291 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1560,24,1296,541,1053,106,1180,1880,540,1561,477,1338,532,969,1586,1831,58,1297,3927,21,16,257,43,1345,344]

theorem envBound30291 : H12AffineFastState.Bounded env30291 := by
  intro p hp
  have h : env30291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30290_30291 : H12AffineEnvironment.transform 11 1560 env30290 = env30291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1560 env30290 == env30291) = true)

def env30292 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,1356,24,1296,329,1053,106,1180,1036,328,1357,477,1338,320,157,1382,1139,58,1297,3075,21,16,257,43,1345,344]

theorem envBound30292 : H12AffineFastState.Bounded env30292 := by
  intro p hp
  have h : env30292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30291_30292 : H12AffineEnvironment.transform 8 340 env30291 = env30292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env30291 == env30292) = true)

def env30293 : List Nat := [2,4,8,16,32,64,128,256,340,272,2048,92,24,0,329,269,106,396,284,328,93,477,42,320,157,118,355,58,1,2323,21,16,257,43,81,344]

theorem envBound30293 : H12AffineFastState.Bounded env30293 := by
  intro p hp
  have h : env30293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30292_30293 : H12AffineEnvironment.transform 9 272 env30292 = env30293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env30292 == env30293) = true)

theorem identity30293 : scanCanonicalize (H12AffineFastState.compose env30293 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound30293 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env30294 : List Nat := [2,4,8,16,32,64,128,69,17,85,2048,92,24,0,12,72,106,201,89,13,93,152,42,5,157,118,38,58,1,2134,21,16,68,43,81,29]

theorem envBound30294 : H12AffineFastState.Bounded env30294 := by
  intro p hp
  have h : env30294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30293_30294 : H12AffineEnvironment.transform 7 69 env30293 = env30294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env30293 == env30294) = true)

theorem identity30294 : scanCanonicalize (H12AffineFastState.compose env30294 (packedSelected [0,1,4,5,7,8,9,12,16,17,20] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound30294 : packedSelected [0,1,4,5,7,8,9,12,16,17,20] rootPS < 2^1333 := by decide +kernel

def env30295 : List Nat := [2,4,8,16,1,64,128,69,17,85,2048,92,24,0,12,72,75,201,89,13,93,152,11,5,157,87,7,27,1,2134,21,16,68,10,81,29]

theorem envBound30295 : H12AffineFastState.Bounded env30295 := by
  intro p hp
  have h : env30295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30294_30295 : H12AffineEnvironment.transform 4 1 env30294 = env30295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env30294 == env30295) = true)

theorem identity30295 : scanCanonicalize (H12AffineFastState.compose env30295 (packedSelected [0,1,2,4,5,7,9,10,12,13,15,16,18] rootPS)) = affineNative (2^(5+1) ^^^ 23) := by decide +kernel

theorem selectedBound30295 : packedSelected [0,1,2,4,5,7,9,10,12,13,15,16,18] rootPS < 2^1333 := by decide +kernel

def env30296 : List Nat := [2,4,8,16,1,23,128,18,17,2,2048,11,24,0,12,31,28,158,14,13,10,152,11,5,157,0,7,27,1,2049,21,16,19,10,6,29]

theorem envBound30296 : H12AffineFastState.Bounded env30296 := by
  intro p hp
  have h : env30296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30295_30296 : H12AffineEnvironment.transform 5 23 env30295 = env30296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 23 env30295 == env30296) = true)

theorem identity30296 : scanCanonicalize (H12AffineFastState.compose env30296 (packedSelected [0,2,3,5,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 158) := by decide +kernel

theorem selectedBound30296 : packedSelected [0,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env30297 : List Nat := [2,4,8,16,1,23,128,18,17,2,158,11,24,0,12,31,28,158,14,13,10,152,11,5,157,0,7,27,1,159,21,16,19,10,6,29]

theorem envBound30297 : H12AffineFastState.Bounded env30297 := by
  intro p hp
  have h : env30297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30296_30297 : H12AffineEnvironment.transform 10 158 env30296 = env30297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 158 env30296 == env30297) = true)

theorem identity30297 : scanCanonicalize (H12AffineFastState.compose env30297 (packedSelected [1,2,4,5,7] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound30297 : packedSelected [1,2,4,5,7] rootPS < 2^1333 := by decide +kernel

def env30298 : List Nat := [2,4,8,1,1,6,128,3,0,2,143,11,9,0,12,14,13,143,14,13,10,137,11,5,140,0,7,10,1,142,4,1,2,10,6,12]

theorem envBound30298 : H12AffineFastState.Bounded env30298 := by
  intro p hp
  have h : env30298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30297_30298 : H12AffineEnvironment.transform 3 1 env30297 = env30298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env30297 == env30298) = true)

theorem identity30298 : scanCanonicalize (H12AffineFastState.compose env30298 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound30298 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env30299 : List Nat := [2,4,4,1,1,6,128,3,0,2,131,7,5,0,0,2,1,131,2,1,6,133,7,5,128,0,7,6,1,130,4,1,2,6,6,0]

theorem envBound30299 : H12AffineFastState.Bounded env30299 := by
  intro p hp
  have h : env30299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30298_30299 : H12AffineEnvironment.transform 2 4 env30298 = env30299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env30298 == env30299) = true)

theorem identity30299 : scanCanonicalize (H12AffineFastState.compose env30299 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound30299 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30300 : List Nat := [2,4,4,1,1,6,2,3,0,2,1,7,5,0,0,2,1,1,2,1,6,7,7,5,2,0,7,6,1,0,4,1,2,6,6,0]

theorem envBound30300 : H12AffineFastState.Bounded env30300 := by
  intro p hp
  have h : env30300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30299_30300 : H12AffineEnvironment.transform 6 2 env30299 = env30300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env30299 == env30300) = true)

theorem identity30300 : scanCanonicalize (H12AffineFastState.compose env30300 (packedSelected [5] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound30300 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env30301 : List Nat := [2,2,2,1,1,0,2,3,0,2,1,1,3,0,0,2,1,1,2,1,0,1,1,3,2,0,1,0,1,0,2,1,2,0,0,0]

theorem envBound30301 : H12AffineFastState.Bounded env30301 := by
  intro p hp
  have h : env30301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30300_30301 : H12AffineEnvironment.transform 1 2 env30300 = env30301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env30300 == env30301) = true)

def env30302 : List Nat := [2,4,8,16,32,64,128,256,340,273,2048,93,24,1,329,268,106,397,285,328,92,477,43,320,157,119,354,58,0,2322,21,16,257,43,80,344]

theorem envBound30302 : H12AffineFastState.Bounded env30302 := by
  intro p hp
  have h : env30302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30292_30302 : H12AffineEnvironment.transform 9 273 env30292 = env30302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env30292 == env30302) = true)

theorem identity30302 : scanCanonicalize (H12AffineFastState.compose env30302 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 72) := by decide +kernel

theorem selectedBound30302 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env30303 : List Nat := [2,4,8,16,32,64,128,72,28,89,2048,93,24,1,1,68,106,197,85,0,92,149,43,8,157,119,42,58,0,2138,21,16,73,43,80,16]

theorem envBound30303 : H12AffineFastState.Bounded env30303 := by
  intro p hp
  have h : env30303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30302_30303 : H12AffineEnvironment.transform 7 72 env30302 = env30303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 72 env30302 == env30303) = true)

theorem identity30303 : scanCanonicalize (H12AffineFastState.compose env30303 (packedSelected [1,3,4,8,9,10,12,16,17] rootPS)) = affineNative (2^(10+1) ^^^ 91) := by decide +kernel

theorem selectedBound30303 : packedSelected [1,3,4,8,9,10,12,16,17] rootPS < 2^1333 := by decide +kernel

def env30304 : List Nat := [2,4,8,16,32,64,128,72,28,89,91,93,24,1,1,68,106,197,85,0,92,149,43,8,157,119,42,58,0,1,21,16,73,43,80,16]

theorem envBound30304 : H12AffineFastState.Bounded env30304 := by
  intro p hp
  have h : env30304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30303_30304 : H12AffineEnvironment.transform 10 91 env30303 = env30304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 91 env30303 == env30304) = true)

theorem identity30304 : scanCanonicalize (H12AffineFastState.compose env30304 (packedSelected [0,1,2,4,7,8,9,10,12,13,16,18] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound30304 : packedSelected [0,1,2,4,7,8,9,10,12,13,16,18] rootPS < 2^1333 := by decide +kernel

def env30305 : List Nat := [2,4,8,16,32,11,128,3,28,18,16,22,24,1,1,15,33,142,30,0,23,149,43,8,157,60,42,58,0,1,21,16,2,43,27,16]

theorem envBound30305 : H12AffineFastState.Bounded env30305 := by
  intro p hp
  have h : env30305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30304_30305 : H12AffineEnvironment.transform 5 11 env30304 = env30305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env30304 == env30305) = true)

theorem identity30305 : scanCanonicalize (H12AffineFastState.compose env30305 (packedSelected [1,2,3,4,5,9,10,11] rootPS)) = affineNative (2^(4+1) ^^^ 29) := by decide +kernel

theorem selectedBound30305 : packedSelected [1,2,3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env30306 : List Nat := [2,4,8,16,29,11,128,3,28,18,16,22,24,1,1,15,28,142,30,0,23,149,22,8,157,1,23,7,0,1,21,16,2,22,27,16]

theorem envBound30306 : H12AffineFastState.Bounded env30306 := by
  intro p hp
  have h : env30306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30305_30306 : H12AffineEnvironment.transform 4 29 env30305 = env30306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 29 env30305 == env30306) = true)

theorem identity30306 : scanCanonicalize (H12AffineFastState.compose env30306 (packedSelected [1,4,7] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound30306 : packedSelected [1,4,7] rootPS < 2^1333 := by decide +kernel

def env30307 : List Nat := [2,4,8,16,29,11,5,3,28,18,16,22,24,1,1,15,28,11,30,0,23,16,22,8,24,1,23,7,0,1,21,16,2,22,27,16]

theorem envBound30307 : H12AffineFastState.Bounded env30307 := by
  intro p hp
  have h : env30307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30306_30307 : H12AffineEnvironment.transform 6 5 env30306 = env30307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env30306 == env30307) = true)

theorem identity30307 : scanCanonicalize (H12AffineFastState.compose env30307 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound30307 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env30308 : List Nat := [2,4,8,7,10,11,5,3,11,5,7,1,15,1,1,15,11,11,9,0,0,7,1,8,15,1,0,7,0,1,2,7,2,1,12,7]

theorem envBound30308 : H12AffineFastState.Bounded env30308 := by
  intro p hp
  have h : env30308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30307_30308 : H12AffineEnvironment.transform 3 7 env30307 = env30308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env30307 == env30308) = true)

theorem identity30308 : scanCanonicalize (H12AffineFastState.compose env30308 (packedSelected [2,3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound30308 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env30309 : List Nat := [2,2,8,1,10,11,3,3,11,3,1,1,9,1,1,9,11,11,9,0,0,1,1,8,9,1,0,1,0,1,2,1,2,1,10,1]

theorem envBound30309 : H12AffineFastState.Bounded env30309 := by
  intro p hp
  have h : env30309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30308_30309 : H12AffineEnvironment.transform 1 2 env30308 = env30309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env30308 == env30309) = true)

theorem identity30309 : scanCanonicalize (H12AffineFastState.compose env30309 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound30309 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env30310 : List Nat := [2,2,3,1,1,0,3,3,0,3,1,1,2,1,1,2,0,0,2,0,0,1,1,3,2,1,0,1,0,1,2,1,2,1,1,1]

theorem envBound30310 : H12AffineFastState.Bounded env30310 := by
  intro p hp
  have h : env30310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30309_30310 : H12AffineEnvironment.transform 2 3 env30309 = env30310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env30309 == env30310) = true)

theorem identity30310 : scanCanonicalize (H12AffineFastState.compose env30310 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound30310 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30311 : List Nat := [0,0,1,1,1,0,1,1,0,1,1,1,0,1,1,0,0,0,0,0,0,1,1,1,0,1,0,1,0,1,0,1,0,1,1,1]

theorem envBound30311 : H12AffineFastState.Bounded env30311 := by
  intro p hp
  have h : env30311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30310_30311 : H12AffineEnvironment.transform 0 0 env30310 = env30311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env30310 == env30311) = true)

def env30312 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,1357,24,1296,328,1053,106,1180,1037,329,1356,477,1338,321,156,1383,1138,58,1297,3074,21,16,257,43,1345,344]

theorem envBound30312 : H12AffineFastState.Bounded env30312 := by
  intro p hp
  have h : env30312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30291_30312 : H12AffineEnvironment.transform 8 341 env30291 = env30312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env30291 == env30312) = true)

def env30313 : List Nat := [2,4,8,16,32,64,128,256,341,272,2048,93,24,0,328,269,106,396,285,329,92,477,42,321,156,119,354,58,1,2322,21,16,257,43,81,344]

theorem envBound30313 : H12AffineFastState.Bounded env30313 := by
  intro p hp
  have h : env30313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30312_30313 : H12AffineEnvironment.transform 9 272 env30312 = env30313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env30312 == env30313) = true)

theorem identity30313 : scanCanonicalize (H12AffineFastState.compose env30313 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound30313 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env30314 : List Nat := [2,4,8,16,32,64,128,69,16,85,2048,93,24,0,13,72,106,201,88,12,92,152,42,4,156,119,39,58,1,2135,21,16,68,43,81,29]

theorem envBound30314 : H12AffineFastState.Bounded env30314 := by
  intro p hp
  have h : env30314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30313_30314 : H12AffineEnvironment.transform 7 69 env30313 = env30314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env30313 == env30314) = true)

theorem identity30314 : scanCanonicalize (H12AffineFastState.compose env30314 (packedSelected [0,1,4,5,7,8,9,12,16,17,20] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound30314 : packedSelected [0,1,4,5,7,8,9,12,16,17,20] rootPS < 2^1333 := by decide +kernel

def env30315 : List Nat := [2,4,8,16,0,64,128,69,16,85,2048,93,24,0,13,72,74,201,88,12,92,152,10,4,156,87,7,26,1,2135,21,16,68,11,81,29]

theorem envBound30315 : H12AffineFastState.Bounded env30315 := by
  intro p hp
  have h : env30315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30314_30315 : H12AffineEnvironment.transform 4 0 env30314 = env30315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env30314 == env30315) = true)

theorem identity30315 : scanCanonicalize (H12AffineFastState.compose env30315 (packedSelected [0,1,2,4,5,7,9,10,12,13,15,16,18] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound30315 : packedSelected [0,1,2,4,5,7,9,10,12,13,15,16,18] rootPS < 2^1333 := by decide +kernel

def env30316 : List Nat := [2,2,8,16,0,64,128,67,16,83,2048,91,24,0,11,72,74,201,88,10,90,152,10,2,154,81,1,26,1,2129,19,16,66,11,81,27]

theorem envBound30316 : H12AffineFastState.Bounded env30316 := by
  intro p hp
  have h : env30316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30315_30316 : H12AffineEnvironment.transform 1 2 env30315 = env30316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env30315 == env30316) = true)

theorem identity30316 : scanCanonicalize (H12AffineFastState.compose env30316 (packedSelected [0,1,5,8,9,10] rootPS)) = affineNative (2^(10+1) ^^^ 64) := by decide +kernel

theorem selectedBound30316 : packedSelected [0,1,5,8,9,10] rootPS < 2^1333 := by decide +kernel

def env30317 : List Nat := [2,2,8,16,0,64,128,67,16,83,64,91,24,0,11,72,74,201,88,10,90,152,10,2,154,81,1,26,1,17,19,16,66,11,81,27]

theorem envBound30317 : H12AffineFastState.Bounded env30317 := by
  intro p hp
  have h : env30317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30316_30317 : H12AffineEnvironment.transform 10 64 env30316 = env30317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 64 env30316 == env30317) = true)

theorem identity30317 : scanCanonicalize (H12AffineFastState.compose env30317 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound30317 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30318 : List Nat := [2,2,8,16,0,64,89,67,16,83,64,91,24,0,11,72,74,16,88,10,90,65,10,2,67,81,1,26,1,17,19,16,66,11,81,27]

theorem envBound30318 : H12AffineFastState.Bounded env30318 := by
  intro p hp
  have h : env30318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30317_30318 : H12AffineEnvironment.transform 6 89 env30317 = env30318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env30317 == env30318) = true)

theorem identity30318 : scanCanonicalize (H12AffineFastState.compose env30318 (packedSelected [2,5] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound30318 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env30319 : List Nat := [2,2,8,16,0,1,24,2,16,18,1,26,24,0,11,9,11,16,25,10,27,0,10,2,2,16,1,26,1,17,19,16,3,11,16,27]

theorem envBound30319 : H12AffineFastState.Bounded env30319 := by
  intro p hp
  have h : env30319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30318_30319 : H12AffineEnvironment.transform 5 1 env30318 = env30319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env30318 == env30319) = true)

theorem identity30319 : scanCanonicalize (H12AffineFastState.compose env30319 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound30319 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30320 : List Nat := [2,2,3,16,0,1,19,2,16,18,1,17,19,0,0,2,0,16,18,1,16,0,1,2,2,16,1,17,1,17,19,16,3,0,16,16]

theorem envBound30320 : H12AffineFastState.Bounded env30320 := by
  intro p hp
  have h : env30320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30319_30320 : H12AffineEnvironment.transform 2 3 env30319 = env30320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env30319 == env30320) = true)

theorem identity30320 : scanCanonicalize (H12AffineFastState.compose env30320 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound30320 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30321 : List Nat := [2,2,3,0,0,1,3,2,0,2,1,1,3,0,0,2,0,0,2,1,0,0,1,2,2,0,1,1,1,1,3,0,3,0,0,0]

theorem envBound30321 : H12AffineFastState.Bounded env30321 := by
  intro p hp
  have h : env30321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30320_30321 : H12AffineEnvironment.transform 3 0 env30320 = env30321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env30320 == env30321) = true)

def env30322 : List Nat := [2,4,8,16,32,64,128,256,341,273,2048,92,24,1,328,268,106,397,284,329,93,477,43,321,156,118,355,58,0,2323,21,16,257,43,80,344]

theorem envBound30322 : H12AffineFastState.Bounded env30322 := by
  intro p hp
  have h : env30322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30312_30322 : H12AffineEnvironment.transform 9 273 env30312 = env30322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env30312 == env30322) = true)

theorem identity30322 : scanCanonicalize (H12AffineFastState.compose env30322 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 73) := by decide +kernel

theorem selectedBound30322 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env30323 : List Nat := [2,4,8,16,32,64,128,73,28,88,2048,92,24,1,1,69,106,196,85,0,93,148,43,8,156,118,42,58,0,2138,21,16,72,43,80,17]

theorem envBound30323 : H12AffineFastState.Bounded env30323 := by
  intro p hp
  have h : env30323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30322_30323 : H12AffineEnvironment.transform 7 73 env30322 = env30323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 73 env30322 == env30323) = true)

theorem identity30323 : scanCanonicalize (H12AffineFastState.compose env30323 (packedSelected [1,3,4,8,9,10,12,16,17] rootPS)) = affineNative (2^(10+1) ^^^ 90) := by decide +kernel

theorem selectedBound30323 : packedSelected [1,3,4,8,9,10,12,16,17] rootPS < 2^1333 := by decide +kernel

def env30324 : List Nat := [2,4,8,16,32,64,128,73,28,88,90,92,24,1,1,69,106,196,85,0,93,148,43,8,156,118,42,58,0,0,21,16,72,43,80,17]

theorem envBound30324 : H12AffineFastState.Bounded env30324 := by
  intro p hp
  have h : env30324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30323_30324 : H12AffineEnvironment.transform 10 90 env30323 = env30324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 90 env30323 == env30324) = true)

theorem identity30324 : scanCanonicalize (H12AffineFastState.compose env30324 (packedSelected [0,1,2,4,7,8,9,10,12,13,16,18] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound30324 : packedSelected [0,1,2,4,7,8,9,10,12,13,16,18] rootPS < 2^1333 := by decide +kernel

def env30325 : List Nat := [2,4,8,16,32,11,128,2,28,19,17,23,24,1,1,14,33,143,30,0,22,148,43,8,156,61,42,58,0,0,21,16,3,43,27,17]

theorem envBound30325 : H12AffineFastState.Bounded env30325 := by
  intro p hp
  have h : env30325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30324_30325 : H12AffineEnvironment.transform 5 11 env30324 = env30325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env30324 == env30325) = true)

theorem identity30325 : scanCanonicalize (H12AffineFastState.compose env30325 (packedSelected [1,2,3,4,5,9,10,11] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound30325 : packedSelected [1,2,3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env30326 : List Nat := [2,4,8,16,32,11,40,2,28,19,17,23,24,1,1,14,33,39,30,0,22,60,43,8,52,61,42,58,0,0,21,16,3,43,27,17]

theorem envBound30326 : H12AffineFastState.Bounded env30326 := by
  intro p hp
  have h : env30326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30325_30326 : H12AffineEnvironment.transform 6 40 env30325 = env30326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env30325 == env30326) = true)

theorem identity30326 : scanCanonicalize (H12AffineFastState.compose env30326 (packedSelected [0,1,3,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 22) := by decide +kernel

theorem selectedBound30326 : packedSelected [0,1,3,4,5] rootPS < 2^1333 := by decide +kernel

def env30327 : List Nat := [2,4,8,16,22,11,30,2,28,19,17,23,24,1,1,14,23,17,30,0,22,10,29,8,2,11,28,12,0,0,21,16,3,29,27,17]

theorem envBound30327 : H12AffineFastState.Bounded env30327 := by
  intro p hp
  have h : env30327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30326_30327 : H12AffineEnvironment.transform 4 22 env30326 = env30327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 22 env30326 == env30327) = true)

theorem identity30327 : scanCanonicalize (H12AffineFastState.compose env30327 (packedSelected [0,2,4] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound30327 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env30328 : List Nat := [2,4,8,7,1,11,9,2,11,4,6,0,15,1,1,14,0,6,9,0,1,10,10,8,2,11,11,12,0,0,2,7,3,10,12,6]

theorem envBound30328 : H12AffineFastState.Bounded env30328 := by
  intro p hp
  have h : env30328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30327_30328 : H12AffineEnvironment.transform 3 7 env30327 = env30328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env30327 == env30328) = true)

def env30329 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74863,262144,4417,13340,4097,476,74046,69648,13768,78895,332223,74814,1297,81227,8204,8201,257,74798,1345,5953]

theorem envBound30329 : H12AffineFastState.Bounded env30329 := by
  intro p hp
  have h : env30329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30209_30329 : H12AffineEnvironment.transform 13 1297 env30209 = env30329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env30209 == env30329) = true)

def env30330 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74863,65664,4417,13340,4097,476,74046,69648,13768,78895,4415,74814,1297,81227,8204,8201,257,74798,1345,5953]

theorem envBound30330 : H12AffineFastState.Bounded env30330 := by
  intro p hp
  have h : env30330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30329_30330 : H12AffineEnvironment.transform 17 65664 env30329 = env30330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env30329 == env30330) = true)

theorem identity30330 : scanCanonicalize (H12AffineFastState.compose env30330 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound30330 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env30331 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,8192,0,12556,65536,74110,65664,4417,12557,4097,476,74046,69648,12505,78142,4415,74031,0,79962,8204,8201,257,74047,80,4688]

theorem envBound30331 : H12AffineFastState.Bounded env30331 := by
  intro p hp
  have h : env30331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30330_30331 : H12AffineEnvironment.transform 9 273 env30330 = env30331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env30330 == env30331) = true)

def env30332 : List Nat := [2,4,8,16,32,64,128,256,340,273,2048,4096,8192,0,12556,65536,74110,65664,4417,12557,4097,476,74046,69648,12505,78142,4415,74031,0,79962,8204,8201,257,74047,80,4356]

theorem envBound30332 : H12AffineFastState.Bounded env30332 := by
  intro p hp
  have h : env30332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30331_30332 : H12AffineEnvironment.transform 8 340 env30331 = env30332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env30331 == env30332) = true)

def env30333 : List Nat := [2,4,8,16,32,64,128,256,340,273,2048,16,8192,0,8476,65536,74110,65664,337,8477,17,476,74046,65536,8393,74030,303,74031,0,75850,8204,8201,257,74047,80,276]

theorem envBound30333 : H12AffineFastState.Bounded env30333 := by
  intro p hp
  have h : env30333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30332_30333 : H12AffineEnvironment.transform 11 16 env30332 = env30333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env30332 == env30333) = true)

theorem identity30333 : scanCanonicalize (H12AffineFastState.compose env30333 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 435) := by decide +kernel

theorem selectedBound30333 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env30334 : List Nat := [2,4,8,16,32,64,128,256,340,273,2048,16,435,0,175,65536,65741,65664,337,174,17,476,65677,65536,378,65693,303,65692,0,68089,447,442,257,65676,80,276]

theorem envBound30334 : H12AffineFastState.Bounded env30334 := by
  intro p hp
  have h : env30334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30333_30334 : H12AffineEnvironment.transform 12 435 env30333 = env30334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 435 env30333 == env30334) = true)

def env30335 : List Nat := [2,4,8,16,32,64,128,160,244,177,2048,16,19,0,175,65536,65741,65664,241,174,17,124,65677,65536,218,65693,143,65692,0,67673,31,26,161,65676,80,180]

theorem envBound30335 : H12AffineFastState.Bounded env30335 := by
  intro p hp
  have h : env30335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30334_30335 : H12AffineEnvironment.transform 7 160 env30334 = env30335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 160 env30334 == env30335) = true)

theorem identity30335 : scanCanonicalize (H12AffineFastState.compose env30335 (packedSelected [0,8,13,15,24,27] rootPS)) = affineNative (2^(10+1) ^^^ 227) := by decide +kernel

theorem selectedBound30335 : packedSelected [0,8,13,15,24,27] rootPS < 2^1333 := by decide +kernel

def env30336 : List Nat := [2,4,8,16,32,64,128,160,244,177,227,16,19,0,175,65536,65741,65664,241,174,17,124,65677,65536,218,65693,143,65692,0,65722,31,26,161,65676,80,180]

theorem envBound30336 : H12AffineFastState.Bounded env30336 := by
  intro p hp
  have h : env30336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30335_30336 : H12AffineEnvironment.transform 10 227 env30335 = env30336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 227 env30335 == env30336) = true)

theorem identity30336 : scanCanonicalize (H12AffineFastState.compose env30336 (packedSelected [2,3,4,5,7,10,11,12,13,15,16,18,20,21,23] rootPS)) = affineNative (2^(6+1) ^^^ 62) := by decide +kernel

theorem selectedBound30336 : packedSelected [2,3,4,5,7,10,11,12,13,15,16,18,20,21,23] rootPS < 2^1333 := by decide +kernel

def env30337 : List Nat := [2,4,8,16,32,64,62,30,74,15,93,16,19,0,17,65536,65651,65598,79,16,17,124,65587,65536,100,65571,49,65570,0,65540,31,26,31,65586,80,10]

theorem envBound30337 : H12AffineFastState.Bounded env30337 := by
  intro p hp
  have h : env30337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30336_30337 : H12AffineEnvironment.transform 6 62 env30336 = env30337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 62 env30336 == env30337) = true)

theorem identity30337 : scanCanonicalize (H12AffineFastState.compose env30337 (packedSelected [2,5,12,13,17] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound30337 : packedSelected [2,5,12,13,17] rootPS < 2^1333 := by decide +kernel

def env30338 : List Nat := [2,4,5,16,32,64,51,19,71,2,80,16,19,0,17,65536,65651,65587,66,16,17,113,65587,65536,100,65571,49,65570,0,65540,18,23,18,65586,80,7]

theorem envBound30338 : H12AffineFastState.Bounded env30338 := by
  intro p hp
  have h : env30338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30337_30338 : H12AffineEnvironment.transform 2 5 env30337 = env30338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env30337 == env30338) = true)

theorem identity30338 : scanCanonicalize (H12AffineFastState.compose env30338 (packedSelected [1,4,9,10,12] rootPS)) = affineNative (2^(5+1) ^^^ 54) := by decide +kernel

theorem selectedBound30338 : packedSelected [1,4,9,10,12] rootPS < 2^1333 := by decide +kernel

def env30339 : List Nat := [2,4,5,16,32,54,51,19,49,2,38,16,19,0,17,65536,65541,65587,52,16,17,7,65587,65536,18,65571,49,65570,0,65540,18,23,18,65586,38,7]

theorem envBound30339 : H12AffineFastState.Bounded env30339 := by
  intro p hp
  have h : env30339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30338_30339 : H12AffineEnvironment.transform 5 54 env30338 = env30339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 54 env30338 == env30339) = true)

theorem identity30339 : scanCanonicalize (H12AffineFastState.compose env30339 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 19) := by decide +kernel

theorem selectedBound30339 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30340 : List Nat := [2,4,5,16,32,54,51,19,49,2,38,16,19,0,17,19,22,32,52,16,17,7,32,19,18,48,49,49,0,23,18,23,18,33,38,7]

theorem envBound30340 : H12AffineFastState.Bounded env30340 := by
  intro p hp
  have h : env30340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30339_30340 : H12AffineEnvironment.transform 15 19 env30339 = env30340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 19 env30339 == env30340) = true)

theorem identity30340 : scanCanonicalize (H12AffineFastState.compose env30340 (packedSelected [0,1,4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound30340 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env30341 : List Nat := [2,4,5,1,32,39,34,2,32,2,38,1,2,0,0,2,7,32,37,1,0,7,32,2,3,33,32,32,0,6,3,6,3,33,38,7]

theorem envBound30341 : H12AffineFastState.Bounded env30341 := by
  intro p hp
  have h : env30341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30340_30341 : H12AffineEnvironment.transform 3 1 env30340 = env30341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env30340 == env30341) = true)

theorem identity30341 : scanCanonicalize (H12AffineFastState.compose env30341 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound30341 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env30342 : List Nat := [2,4,5,1,0,7,2,2,0,2,6,1,2,0,0,2,7,0,5,1,0,7,0,2,3,1,0,0,0,6,3,6,3,1,6,7]

theorem envBound30342 : H12AffineFastState.Bounded env30342 := by
  intro p hp
  have h : env30342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30341_30342 : H12AffineEnvironment.transform 4 0 env30341 = env30342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env30341 == env30342) = true)

theorem identity30342 : scanCanonicalize (H12AffineFastState.compose env30342 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound30342 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30343 : List Nat := [2,2,3,1,0,1,2,2,0,2,0,1,2,0,0,2,1,0,3,1,0,1,0,2,3,1,0,0,0,0,3,0,3,1,0,1]

theorem envBound30343 : H12AffineFastState.Bounded env30343 := by
  intro p hp
  have h : env30343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30342_30343 : H12AffineEnvironment.transform 1 2 env30342 = env30343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env30342 == env30343) = true)

theorem identity30343 : scanCanonicalize (H12AffineFastState.compose env30343 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound30343 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30344 : List Nat := [1,1,0,1,0,1,1,1,0,1,0,1,1,0,0,1,1,0,0,1,0,1,0,1,0,1,0,0,0,0,0,0,0,1,0,1]

theorem envBound30344 : H12AffineFastState.Bounded env30344 := by
  intro p hp
  have h : env30344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30343_30344 : H12AffineEnvironment.transform 0 1 env30343 = env30344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env30343 == env30344) = true)

def env30345 : List Nat := [2,4,8,16,32,64,128,161,245,176,2048,16,18,0,175,65536,65741,65664,240,174,17,125,65677,65536,219,65693,142,65692,0,67672,30,27,160,65676,80,181]

theorem envBound30345 : H12AffineFastState.Bounded env30345 := by
  intro p hp
  have h : env30345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30334_30345 : H12AffineEnvironment.transform 7 161 env30334 = env30345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 161 env30334 == env30345) = true)

theorem identity30345 : scanCanonicalize (H12AffineFastState.compose env30345 (packedSelected [0,8,13,15,24,27] rootPS)) = affineNative (2^(10+1) ^^^ 232) := by decide +kernel

theorem selectedBound30345 : packedSelected [0,8,13,15,24,27] rootPS < 2^1333 := by decide +kernel

def env30346 : List Nat := [2,4,8,16,32,64,128,161,245,176,232,16,18,0,175,65536,65741,65664,240,174,17,125,65677,65536,219,65693,142,65692,0,65712,30,27,160,65676,80,181]

theorem envBound30346 : H12AffineFastState.Bounded env30346 := by
  intro p hp
  have h : env30346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30345_30346 : H12AffineEnvironment.transform 10 232 env30345 = env30346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 232 env30345 == env30346) = true)

theorem identity30346 : scanCanonicalize (H12AffineFastState.compose env30346 (packedSelected [0,2,4,11,16,18,19,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 98) := by decide +kernel

theorem selectedBound30346 : packedSelected [0,2,4,11,16,18,19,23,24] rootPS < 2^1333 := by decide +kernel

def env30347 : List Nat := [2,4,8,16,32,64,128,161,245,176,232,16,18,0,175,98,175,226,240,174,17,125,239,98,219,255,142,254,0,210,30,27,160,238,80,181]

theorem envBound30347 : H12AffineFastState.Bounded env30347 := by
  intro p hp
  have h : env30347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30346_30347 : H12AffineEnvironment.transform 15 98 env30346 = env30347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 98 env30346 == env30347) = true)

theorem identity30347 : scanCanonicalize (H12AffineFastState.compose env30347 (packedSelected [2,4,5,8,9,13,16] rootPS)) = affineNative (2^(6+1) ^^^ 110) := by decide +kernel

theorem selectedBound30347 : packedSelected [2,4,5,8,9,13,16] rootPS < 2^1333 := by decide +kernel

def env30348 : List Nat := [2,4,8,16,32,64,110,79,27,94,6,16,18,0,65,98,65,12,30,64,17,125,1,98,53,17,96,16,0,60,30,27,78,0,80,91]

theorem envBound30348 : H12AffineFastState.Bounded env30348 := by
  intro p hp
  have h : env30348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30347_30348 : H12AffineEnvironment.transform 6 110 env30347 = env30348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 110 env30347 == env30348) = true)

theorem identity30348 : scanCanonicalize (H12AffineFastState.compose env30348 (packedSelected [3,5,10,11] rootPS)) = affineNative (2^(4+1) ^^^ 23) := by decide +kernel

theorem selectedBound30348 : packedSelected [3,5,10,11] rootPS < 2^1333 := by decide +kernel

def env30349 : List Nat := [2,4,8,16,23,64,89,79,27,94,6,16,18,0,65,85,65,12,30,64,17,74,1,85,2,17,87,16,0,11,30,27,78,0,80,91]

theorem envBound30349 : H12AffineFastState.Bounded env30349 := by
  intro p hp
  have h : env30349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30348_30349 : H12AffineEnvironment.transform 4 23 env30348 = env30349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 23 env30348 == env30349) = true)

theorem identity30349 : scanCanonicalize (H12AffineFastState.compose env30349 (packedSelected [1,2,5] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound30349 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env30350 : List Nat := [2,4,8,16,23,1,24,14,27,31,6,16,18,0,0,20,0,12,30,1,17,11,1,20,2,17,22,16,0,11,30,27,15,0,17,26]

theorem envBound30350 : H12AffineFastState.Bounded env30350 := by
  intro p hp
  have h : env30350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30349_30350 : H12AffineEnvironment.transform 5 1 env30349 = env30350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env30349 == env30350) = true)

theorem identity30350 : scanCanonicalize (H12AffineFastState.compose env30350 (packedSelected [0,2] rootPS)) = affineNative (2^(3+1) ^^^ 15) := by decide +kernel

theorem selectedBound30350 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env30351 : List Nat := [2,4,8,15,8,1,7,14,4,0,6,15,13,0,0,11,0,12,1,1,14,11,1,11,2,14,9,15,0,11,1,4,15,0,14,5]

theorem envBound30351 : H12AffineFastState.Bounded env30351 := by
  intro p hp
  have h : env30351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30350_30351 : H12AffineEnvironment.transform 3 15 env30350 = env30351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 15 env30350 == env30351) = true)

theorem identity30351 : scanCanonicalize (H12AffineFastState.compose env30351 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound30351 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env30352 : List Nat := [2,4,3,4,3,1,7,5,4,0,6,4,6,0,0,0,0,7,1,1,5,0,1,0,2,5,2,4,0,0,1,4,4,0,5,5]

theorem envBound30352 : H12AffineFastState.Bounded env30352 := by
  intro p hp
  have h : env30352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30351_30352 : H12AffineEnvironment.transform 2 3 env30351 = env30352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env30351 == env30352) = true)

theorem identity30352 : scanCanonicalize (H12AffineFastState.compose env30352 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound30352 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30353 : List Nat := [0,4,1,4,1,1,5,5,4,0,4,4,4,0,0,0,0,5,1,1,5,0,1,0,0,5,0,4,0,0,1,4,4,0,5,5]

theorem envBound30353 : H12AffineFastState.Bounded env30353 := by
  intro p hp
  have h : env30353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30352_30353 : H12AffineEnvironment.transform 0 0 env30352 = env30353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env30352 == env30353) = true)

theorem identity30353 : scanCanonicalize (H12AffineFastState.compose env30353 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound30353 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env30354 : List Nat := [0,0,1,0,1,1,1,1,0,0,0,0,0,0,0,0,0,1,1,1,1,0,1,0,0,1,0,0,0,0,1,0,0,0,1,1]

theorem envBound30354 : H12AffineFastState.Bounded env30354 := by
  intro p hp
  have h : env30354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30353_30354 : H12AffineEnvironment.transform 1 0 env30353 = env30354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env30353 == env30354) = true)

def env30355 : List Nat := [2,4,8,16,32,64,128,256,340,273,2048,17,8192,0,8477,65536,74110,65664,336,8476,16,476,74046,65537,8392,74031,302,74031,0,75851,8204,8201,257,74047,80,277]

theorem envBound30355 : H12AffineFastState.Bounded env30355 := by
  intro p hp
  have h : env30355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30332_30355 : H12AffineEnvironment.transform 11 17 env30332 = env30355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env30332 == env30355) = true)

theorem identity30355 : scanCanonicalize (H12AffineFastState.compose env30355 (packedSelected [1,8,28] rootPS)) = affineNative (2^(7+1) ^^^ 171) := by decide +kernel

theorem selectedBound30355 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env30356 : List Nat := [2,4,8,16,32,64,128,171,255,186,2048,17,8192,0,8374,65536,73941,65664,251,8375,16,119,73877,65537,8392,73860,133,73860,0,75851,8204,8201,170,73876,80,190]

theorem envBound30356 : H12AffineFastState.Bounded env30356 := by
  intro p hp
  have h : env30356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30355_30356 : H12AffineEnvironment.transform 7 171 env30355 = env30356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 171 env30355 == env30356) = true)

def env30357 : List Nat := [2,4,8,16,32,64,128,171,255,186,2048,17,24,0,174,65536,65741,65664,251,175,16,119,65677,65537,208,65692,133,65692,0,67667,20,17,170,65676,80,190]

theorem envBound30357 : H12AffineFastState.Bounded env30357 := by
  intro p hp
  have h : env30357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30356_30357 : H12AffineEnvironment.transform 12 24 env30356 = env30357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env30356 == env30357) = true)

theorem identity30357 : scanCanonicalize (H12AffineFastState.compose env30357 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(6+1) ^^^ 111) := by decide +kernel

theorem selectedBound30357 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env30358 : List Nat := [2,4,8,16,32,64,111,68,16,85,2048,17,24,0,65,65536,65570,65647,20,64,16,119,65634,65537,63,65651,106,65651,0,67667,20,17,69,65635,80,81]

theorem envBound30358 : H12AffineFastState.Bounded env30358 := by
  intro p hp
  have h : env30358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30357_30358 : H12AffineEnvironment.transform 6 111 env30357 = env30358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 111 env30357 == env30358) = true)

theorem identity30358 : scanCanonicalize (H12AffineFastState.compose env30358 (packedSelected [0,2,3,4,7,9,11,12,23] rootPS)) = affineNative (2^(10+1) ^^^ 54) := by decide +kernel

theorem selectedBound30358 : packedSelected [0,2,3,4,7,9,11,12,23] rootPS < 2^1333 := by decide +kernel

def env30359 : List Nat := [2,4,8,16,32,64,111,68,16,85,54,17,24,0,65,65536,65570,65647,20,64,16,119,65634,65537,63,65651,106,65651,0,65637,20,17,69,65635,80,81]

theorem envBound30359 : H12AffineFastState.Bounded env30359 := by
  intro p hp
  have h : env30359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30358_30359 : H12AffineEnvironment.transform 10 54 env30358 = env30359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 54 env30358 == env30359) = true)

theorem identity30359 : scanCanonicalize (H12AffineFastState.compose env30359 (packedSelected [3,4,9,10,11,12,16,17,18] rootPS)) = affineNative (2^(15+1) ^^^ 20) := by decide +kernel

theorem selectedBound30359 : packedSelected [3,4,9,10,11,12,16,17,18] rootPS < 2^1333 := by decide +kernel

def env30360 : List Nat := [2,4,8,16,32,64,111,68,16,85,54,17,24,0,65,20,54,123,20,64,16,119,118,21,63,103,106,103,0,113,20,17,69,119,80,81]

theorem envBound30360 : H12AffineFastState.Bounded env30360 := by
  intro p hp
  have h : env30360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30359_30360 : H12AffineEnvironment.transform 15 20 env30359 = env30360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 20 env30359 == env30360) = true)

theorem identity30360 : scanCanonicalize (H12AffineFastState.compose env30360 (packedSelected [0,3,4,8] rootPS)) = affineNative (2^(5+1) ^^^ 29) := by decide +kernel

theorem selectedBound30360 : packedSelected [0,3,4,8] rootPS < 2^1333 := by decide +kernel

def env30361 : List Nat := [2,4,8,16,32,29,50,25,16,8,54,17,24,0,28,20,54,38,20,29,16,42,43,21,63,58,55,58,0,44,20,17,24,42,13,12]

theorem envBound30361 : H12AffineFastState.Bounded env30361 := by
  intro p hp
  have h : env30361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30360_30361 : H12AffineEnvironment.transform 5 29 env30360 = env30361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 29 env30360 == env30361) = true)

theorem identity30361 : scanCanonicalize (H12AffineFastState.compose env30361 (packedSelected [3,5] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound30361 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env30362 : List Nat := [2,4,8,16,6,29,20,25,16,8,16,17,24,0,28,20,16,0,20,29,16,12,13,21,25,28,17,28,0,10,20,17,24,12,13,12]

theorem envBound30362 : H12AffineFastState.Bounded env30362 := by
  intro p hp
  have h : env30362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30361_30362 : H12AffineEnvironment.transform 4 6 env30361 = env30362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env30361 == env30362) = true)

theorem identity30362 : scanCanonicalize (H12AffineFastState.compose env30362 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound30362 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env30363 : List Nat := [2,4,8,11,6,6,15,2,11,8,11,10,3,0,7,15,11,0,15,6,11,12,13,14,2,7,10,7,0,10,15,10,3,12,13,12]

theorem envBound30363 : H12AffineFastState.Bounded env30363 := by
  intro p hp
  have h : env30363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30362_30363 : H12AffineEnvironment.transform 3 11 env30362 = env30363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env30362 == env30363) = true)

theorem identity30363 : scanCanonicalize (H12AffineFastState.compose env30363 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound30363 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30364 : List Nat := [2,4,4,7,6,6,3,2,7,4,7,6,3,0,7,3,7,0,3,6,7,0,1,2,2,7,6,7,0,6,3,6,3,0,1,0]

theorem envBound30364 : H12AffineFastState.Bounded env30364 := by
  intro p hp
  have h : env30364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30363_30364 : H12AffineEnvironment.transform 2 4 env30363 = env30364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env30363 == env30364) = true)

def env30365 : List Nat := [2,4,8,16,32,64,128,171,255,186,2048,17,25,0,175,65536,65740,65664,251,174,16,119,65676,65537,209,65693,133,65693,0,67666,21,16,170,65677,80,190]

theorem envBound30365 : H12AffineFastState.Bounded env30365 := by
  intro p hp
  have h : env30365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30356_30365 : H12AffineEnvironment.transform 12 25 env30356 = env30365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env30356 == env30365) = true)

theorem identity30365 : scanCanonicalize (H12AffineFastState.compose env30365 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(6+1) ^^^ 46) := by decide +kernel

theorem selectedBound30365 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env30366 : List Nat := [2,4,8,16,32,64,46,5,81,20,2048,17,25,0,1,65536,65634,65582,85,0,16,119,65570,65537,127,65587,43,65587,0,67666,21,16,4,65571,80,16]

theorem envBound30366 : H12AffineFastState.Bounded env30366 := by
  intro p hp
  have h : env30366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30365_30366 : H12AffineEnvironment.transform 6 46 env30365 = env30366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 46 env30365 == env30366) = true)

theorem identity30366 : scanCanonicalize (H12AffineFastState.compose env30366 (packedSelected [0,1,2,4,7,8,9,10,12,13,16,18] rootPS)) = affineNative (2^(15+1) ^^^ 2100) := by decide +kernel

theorem selectedBound30366 : packedSelected [0,1,2,4,7,8,9,10,12,13,16,18] rootPS < 2^1333 := by decide +kernel

def env30367 : List Nat := [2,4,8,16,32,64,46,5,81,20,2048,17,25,0,1,2100,2134,2074,85,0,16,119,2070,2101,127,2055,43,2055,0,102,21,16,4,2071,80,16]

theorem envBound30367 : H12AffineFastState.Bounded env30367 := by
  intro p hp
  have h : env30367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30366_30367 : H12AffineEnvironment.transform 15 2100 env30366 = env30367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2100 env30366 == env30367) = true)

theorem identity30367 : scanCanonicalize (H12AffineFastState.compose env30367 (packedSelected [4,8,9,13,16] rootPS)) = affineNative (2^(5+1) ^^^ 7) := by decide +kernel

theorem selectedBound30367 : packedSelected [4,8,9,13,16] rootPS < 2^1333 := by decide +kernel

def env30368 : List Nat := [2,4,8,16,32,7,46,5,22,20,2048,17,25,0,1,2100,2065,2074,18,0,16,48,2070,2101,56,2055,43,2055,0,33,21,16,4,2071,23,16]

theorem envBound30368 : H12AffineFastState.Bounded env30368 := by
  intro p hp
  have h : env30368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30367_30368 : H12AffineEnvironment.transform 5 7 env30367 = env30368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 7 env30367 == env30368) = true)

theorem identity30368 : scanCanonicalize (H12AffineFastState.compose env30368 (packedSelected [0,4,5] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound30368 : packedSelected [0,4,5] rootPS < 2^1333 := by decide +kernel

def env30369 : List Nat := [2,4,8,7,32,7,46,5,1,3,2048,6,14,0,1,2083,2054,2061,5,0,7,39,2049,2082,47,2055,43,2055,0,33,2,7,4,2048,0,7]

theorem envBound30369 : H12AffineFastState.Bounded env30369 := by
  intro p hp
  have h : env30369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30368_30369 : H12AffineEnvironment.transform 3 7 env30368 = env30369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env30368 == env30369) = true)

theorem identity30369 : scanCanonicalize (H12AffineFastState.compose env30369 (packedSelected [0,1,2,3,4,8] rootPS)) = affineNative (2^(10+1) ^^^ 39) := by decide +kernel

theorem selectedBound30369 : packedSelected [0,1,2,3,4,8] rootPS < 2^1333 := by decide +kernel

def env30370 : List Nat := [2,4,8,7,32,7,46,5,1,3,39,6,14,0,1,4,33,42,5,0,7,39,38,5,47,32,43,32,0,33,2,7,4,39,0,7]

theorem envBound30370 : H12AffineFastState.Bounded env30370 := by
  intro p hp
  have h : env30370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30369_30370 : H12AffineEnvironment.transform 10 39 env30369 = env30370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 39 env30369 == env30370) = true)

theorem identity30370 : scanCanonicalize (H12AffineFastState.compose env30370 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound30370 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env30371 : List Nat := [2,4,8,7,12,7,2,5,1,3,11,6,14,0,1,4,13,6,5,0,7,11,10,5,3,12,7,12,0,13,2,7,4,11,0,7]

theorem envBound30371 : H12AffineFastState.Bounded env30371 := by
  intro p hp
  have h : env30371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30370_30371 : H12AffineEnvironment.transform 4 12 env30370 = env30371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env30370 == env30371) = true)

theorem identity30371 : scanCanonicalize (H12AffineFastState.compose env30371 (packedSelected [1,2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound30371 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env30372 : List Nat := [2,4,3,7,7,7,2,5,1,3,0,6,5,0,1,4,6,6,5,0,7,0,1,5,3,7,7,7,0,6,2,7,4,0,0,7]

theorem envBound30372 : H12AffineFastState.Bounded env30372 := by
  intro p hp
  have h : env30372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30371_30372 : H12AffineEnvironment.transform 2 3 env30371 = env30372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env30371 == env30372) = true)

def env30373 : List Nat := [2,4,8,16,32,64,128,256,341,273,2048,4096,8192,0,12556,65536,74110,65664,4417,12557,4097,476,74046,69648,12505,78142,4415,74031,0,79962,8204,8201,257,74047,80,4357]

theorem envBound30373 : H12AffineFastState.Bounded env30373 := by
  intro p hp
  have h : env30373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30331_30373 : H12AffineEnvironment.transform 8 341 env30331 = env30373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env30331 == env30373) = true)

def env30374 : List Nat := [2,4,8,16,32,64,128,256,341,273,2048,16,8192,0,8476,65536,74110,65664,337,8477,17,476,74046,65536,8393,74030,303,74031,0,75850,8204,8201,257,74047,80,277]

theorem envBound30374 : H12AffineFastState.Bounded env30374 := by
  intro p hp
  have h : env30374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30373_30374 : H12AffineEnvironment.transform 11 16 env30373 = env30374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env30373 == env30374) = true)

theorem identity30374 : scanCanonicalize (H12AffineFastState.compose env30374 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 157) := by decide +kernel

theorem selectedBound30374 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env30375 : List Nat := [2,4,8,16,32,64,128,256,341,273,2048,16,8192,0,8476,157,8675,29,337,8477,17,476,8611,157,8393,8627,303,8626,0,10455,8204,8201,257,8610,80,277]

theorem envBound30375 : H12AffineFastState.Bounded env30375 := by
  intro p hp
  have h : env30375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30374_30375 : H12AffineEnvironment.transform 15 157 env30374 = env30375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 157 env30374 == env30375) = true)

def env30376 : List Nat := [2,4,8,16,32,64,128,256,341,273,312,16,8192,0,8476,157,8675,29,337,8477,17,476,8611,157,8393,8627,303,8626,0,8687,8204,8201,257,8610,80,277]

theorem envBound30376 : H12AffineFastState.Bounded env30376 := by
  intro p hp
  have h : env30376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30375_30376 : H12AffineEnvironment.transform 10 312 env30375 = env30376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 312 env30375 == env30376) = true)

theorem identity30376 : scanCanonicalize (H12AffineFastState.compose env30376 (packedSelected [0,1,2,3,11,12,13,19,23,24,27,38] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound30376 : packedSelected [0,1,2,3,11,12,13,19,23,24,27,38] rootPS < 2^1333 := by decide +kernel

def env30377 : List Nat := [2,4,8,16,32,64,8,256,341,273,312,16,8192,0,8476,21,8555,29,337,8477,17,340,8491,21,8257,8507,303,8506,0,8551,8204,8201,257,8490,80,277]

theorem envBound30377 : H12AffineFastState.Bounded env30377 := by
  intro p hp
  have h : env30377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30376_30377 : H12AffineEnvironment.transform 6 8 env30376 = env30377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env30376 == env30377) = true)

theorem identity30377 : scanCanonicalize (H12AffineFastState.compose env30377 (packedSelected [0,1,4,8,10,11,12,15,16,17,24] rootPS)) = affineNative (2^(12+1) ^^^ 100) := by decide +kernel

theorem selectedBound30377 : packedSelected [0,1,4,8,10,11,12,15,16,17,24] rootPS < 2^1333 := by decide +kernel

def env30378 : List Nat := [2,4,8,16,32,64,8,256,341,273,312,16,100,0,376,21,271,29,337,377,17,340,335,21,37,351,303,350,0,259,104,109,257,334,80,277]

theorem envBound30378 : H12AffineFastState.Bounded env30378 := by
  intro p hp
  have h : env30378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30377_30378 : H12AffineEnvironment.transform 12 100 env30377 = env30378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 100 env30377 == env30378) = true)

theorem identity30378 : scanCanonicalize (H12AffineFastState.compose env30378 (packedSelected [0,1,2,3,7,10,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 67) := by decide +kernel

theorem selectedBound30378 : packedSelected [0,1,2,3,7,10,13,17] rootPS < 2^1333 := by decide +kernel

def env30379 : List Nat := [2,4,8,16,32,64,8,67,22,82,123,16,100,0,59,21,76,29,18,58,17,23,12,21,37,28,108,29,0,64,104,109,66,13,80,86]

theorem envBound30379 : H12AffineFastState.Bounded env30379 := by
  intro p hp
  have h : env30379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30378_30379 : H12AffineEnvironment.transform 7 67 env30378 = env30379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 67 env30378 == env30379) = true)

theorem identity30379 : scanCanonicalize (H12AffineFastState.compose env30379 (packedSelected [0,2,3,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound30379 : packedSelected [0,2,3,9,10] rootPS < 2^1333 := by decide +kernel

def env30380 : List Nat := [2,4,8,16,32,59,8,56,22,41,0,16,31,0,59,21,55,29,18,58,17,23,12,21,37,28,23,29,0,59,19,22,57,13,43,45]

theorem envBound30380 : H12AffineFastState.Bounded env30380 := by
  intro p hp
  have h : env30380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30379_30380 : H12AffineEnvironment.transform 5 59 env30379 = env30380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env30379 == env30380) = true)

theorem identity30380 : scanCanonicalize (H12AffineFastState.compose env30380 (packedSelected [2,3] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound30380 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env30381 : List Nat := [2,4,5,16,32,54,5,53,22,36,0,16,18,0,54,21,55,16,18,55,17,23,1,21,37,17,23,16,0,54,19,22,52,0,38,32]

theorem envBound30381 : H12AffineFastState.Bounded env30381 := by
  intro p hp
  have h : env30381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30380_30381 : H12AffineEnvironment.transform 2 5 env30380 = env30381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env30380 == env30381) = true)

theorem identity30381 : scanCanonicalize (H12AffineFastState.compose env30381 (packedSelected [4,7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound30381 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env30382 : List Nat := [2,4,5,16,0,22,5,21,22,4,0,16,18,0,22,21,23,16,18,23,17,23,1,21,5,17,23,16,0,22,19,22,20,0,6,0]

theorem envBound30382 : H12AffineFastState.Bounded env30382 := by
  intro p hp
  have h : env30382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30381_30382 : H12AffineEnvironment.transform 4 0 env30381 = env30382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env30381 == env30382) = true)

theorem identity30382 : scanCanonicalize (H12AffineFastState.compose env30382 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound30382 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30383 : List Nat := [2,3,2,16,0,17,2,18,17,3,0,16,18,0,17,18,16,16,18,16,17,16,1,18,2,17,16,16,0,17,19,17,19,0,1,0]

theorem envBound30383 : H12AffineFastState.Bounded env30383 := by
  intro p hp
  have h : env30383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30382_30383 : H12AffineEnvironment.transform 1 3 env30382 = env30383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env30382 == env30383) = true)

theorem identity30383 : scanCanonicalize (H12AffineFastState.compose env30383 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound30383 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30384 : List Nat := [2,3,2,0,0,1,2,2,1,3,0,0,2,0,1,2,0,0,2,0,1,0,1,2,2,1,0,0,0,1,3,1,3,0,1,0]

theorem envBound30384 : H12AffineFastState.Bounded env30384 := by
  intro p hp
  have h : env30384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30383_30384 : H12AffineEnvironment.transform 3 0 env30383 = env30384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env30383 == env30384) = true)

theorem identity30384 : scanCanonicalize (H12AffineFastState.compose env30384 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound30384 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30385 : List Nat := [1,0,1,0,0,1,1,1,1,0,0,0,1,0,1,1,0,0,1,0,1,0,1,1,1,1,0,0,0,1,0,1,0,0,1,0]

theorem envBound30385 : H12AffineFastState.Bounded env30385 := by
  intro p hp
  have h : env30385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30384_30385 : H12AffineEnvironment.transform 0 1 env30384 = env30385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env30384 == env30385) = true)

def env30386 : List Nat := [2,4,8,16,32,64,128,256,341,273,313,16,8192,0,8476,157,8675,29,337,8477,17,476,8611,157,8393,8627,303,8626,0,8686,8204,8201,257,8610,80,277]

theorem envBound30386 : H12AffineFastState.Bounded env30386 := by
  intro p hp
  have h : env30386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30375_30386 : H12AffineEnvironment.transform 10 313 env30375 = env30386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 313 env30375 == env30386) = true)

theorem identity30386 : scanCanonicalize (H12AffineFastState.compose env30386 (packedSelected [0,1,2,3,11,12,13,19,23,24,27,38] rootPS)) = affineNative (2^(6+1) ^^^ 15) := by decide +kernel

theorem selectedBound30386 : packedSelected [0,1,2,3,11,12,13,19,23,24,27,38] rootPS < 2^1333 := by decide +kernel

def env30387 : List Nat := [2,4,8,16,32,64,15,256,341,273,313,16,8192,0,8476,18,8556,29,337,8477,17,339,8492,18,8262,8508,303,8509,0,8545,8204,8201,257,8493,80,277]

theorem envBound30387 : H12AffineFastState.Bounded env30387 := by
  intro p hp
  have h : env30387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30386_30387 : H12AffineEnvironment.transform 6 15 env30386 = env30387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 15 env30386 == env30387) = true)

theorem identity30387 : scanCanonicalize (H12AffineFastState.compose env30387 (packedSelected [1,2,4,5,7,13,21,23] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound30387 : packedSelected [1,2,4,5,7,13,21,23] rootPS < 2^1333 := by decide +kernel

def env30388 : List Nat := [2,4,8,16,32,64,15,256,341,273,313,16,25,0,261,18,373,29,337,260,17,339,309,18,95,293,303,292,0,376,21,16,257,308,80,277]

theorem envBound30388 : H12AffineFastState.Bounded env30388 := by
  intro p hp
  have h : env30388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30387_30388 : H12AffineEnvironment.transform 12 25 env30387 = env30388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env30387 == env30388) = true)

theorem identity30388 : scanCanonicalize (H12AffineFastState.compose env30388 (packedSelected [1,3,4,9,16,17] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound30388 : packedSelected [1,3,4,9,16,17] rootPS < 2^1333 := by decide +kernel

def env30389 : List Nat := [2,4,8,16,6,64,15,256,341,273,287,16,25,0,261,18,339,29,337,260,17,339,275,18,95,259,265,258,0,350,21,16,257,274,80,277]

theorem envBound30389 : H12AffineFastState.Bounded env30389 := by
  intro p hp
  have h : env30389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30388_30389 : H12AffineEnvironment.transform 4 6 env30388 = env30389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env30388 == env30389) = true)

theorem identity30389 : scanCanonicalize (H12AffineFastState.compose env30389 (packedSelected [0,1,2,4,8,10] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound30389 : packedSelected [0,1,2,4,8,10] rootPS < 2^1333 := by decide +kernel

def env30390 : List Nat := [2,4,8,16,6,1,15,256,276,273,287,16,25,0,261,18,274,29,272,260,17,274,275,18,30,259,265,258,0,287,21,16,257,274,17,277]

theorem envBound30390 : H12AffineFastState.Bounded env30390 := by
  intro p hp
  have h : env30390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30389_30390 : H12AffineEnvironment.transform 5 1 env30389 = env30390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env30389 == env30390) = true)

theorem identity30390 : scanCanonicalize (H12AffineFastState.compose env30390 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 8) := by decide +kernel

theorem selectedBound30390 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30391 : List Nat := [2,4,8,8,6,1,15,256,268,265,263,8,1,0,261,10,266,5,264,260,9,266,267,10,6,259,265,258,0,263,13,8,257,266,9,269]

theorem envBound30391 : H12AffineFastState.Bounded env30391 := by
  intro p hp
  have h : env30391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30390_30391 : H12AffineEnvironment.transform 3 8 env30390 = env30391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 8 env30390 == env30391) = true)

theorem identity30391 : scanCanonicalize (H12AffineFastState.compose env30391 (packedSelected [4,5,8] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound30391 : packedSelected [4,5,8] rootPS < 2^1333 := by decide +kernel

def env30392 : List Nat := [2,4,2,2,6,1,5,256,262,259,263,2,1,0,261,0,256,5,258,260,3,256,257,0,6,259,259,258,0,263,7,2,257,256,3,263]

theorem envBound30392 : H12AffineFastState.Bounded env30392 := by
  intro p hp
  have h : env30392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30391_30392 : H12AffineEnvironment.transform 2 2 env30391 = env30392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env30391 == env30392) = true)

theorem identity30392 : scanCanonicalize (H12AffineFastState.compose env30392 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound30392 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30393 : List Nat := [2,1,2,2,3,1,0,256,259,259,258,2,1,0,256,0,256,0,258,257,3,256,257,0,3,259,259,258,0,258,2,2,257,256,3,258]

theorem envBound30393 : H12AffineFastState.Bounded env30393 := by
  intro p hp
  have h : env30393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30392_30393 : H12AffineEnvironment.transform 1 1 env30392 = env30393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env30392 == env30393) = true)

end H12CloudChart2