import H12CloudChart2Data133

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound33237 : H12AffineFastState.Bounded env33237 := by
  intro p hp
  have h : env33237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33236_33237 : H12AffineEnvironment.transform 6 72 env33236 = env33237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 72 env33236 == env33237) = true)

theorem identity33237 : scanCanonicalize (H12AffineFastState.compose env33237 (packedSelected [1,2,13] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound33237 : packedSelected [1,2,13] rootPS < 2^1333 := by decide +kernel

def env33238 : List Nat := [2,4,8,16,32,32,40,256,33,288,12,277,41,49,276,35,293,11,53,277,276,1,309,50,285,16,318,277,49,280,36,32,257,260,0,308]

theorem envBound33238 : H12AffineFastState.Bounded env33238 := by
  intro p hp
  have h : env33238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33237_33238 : H12AffineEnvironment.transform 5 32 env33237 = env33238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env33237 == env33238) = true)

theorem identity33238 : scanCanonicalize (H12AffineFastState.compose env33238 (packedSelected [2,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound33238 : packedSelected [2,5,10] rootPS < 2^1333 := by decide +kernel

def env33239 : List Nat := [2,4,8,1,32,32,40,256,33,288,12,260,41,32,261,35,293,11,36,260,261,1,292,35,268,1,303,260,32,265,36,32,257,260,0,293]

theorem envBound33239 : H12AffineFastState.Bounded env33239 := by
  intro p hp
  have h : env33239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33238_33239 : H12AffineEnvironment.transform 3 1 env33238 = env33239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env33238 == env33239) = true)

theorem identity33239 : scanCanonicalize (H12AffineFastState.compose env33239 (packedSelected [0,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound33239 : packedSelected [0,7,8] rootPS < 2^1333 := by decide +kernel

def env33240 : List Nat := [2,4,8,1,1,1,9,256,0,257,12,260,8,1,261,2,260,11,5,260,261,1,261,2,268,1,270,260,1,265,5,1,257,260,0,260]

theorem envBound33240 : H12AffineFastState.Bounded env33240 := by
  intro p hp
  have h : env33240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33239_33240 : H12AffineEnvironment.transform 4 1 env33239 = env33240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env33239 == env33240) = true)

theorem identity33240 : scanCanonicalize (H12AffineFastState.compose env33240 (packedSelected [2,3] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound33240 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env33241 : List Nat := [2,4,8,1,1,1,9,5,0,4,12,1,8,1,0,2,1,11,5,1,0,1,0,2,9,1,11,1,1,12,5,1,4,1,0,1]

theorem envBound33241 : H12AffineFastState.Bounded env33241 := by
  intro p hp
  have h : env33241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33240_33241 : H12AffineEnvironment.transform 7 5 env33240 = env33241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env33240 == env33241) = true)

theorem identity33241 : scanCanonicalize (H12AffineFastState.compose env33241 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound33241 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33242 : List Nat := [2,4,1,1,1,1,0,5,0,4,5,1,1,1,0,2,1,2,5,1,0,1,0,2,0,1,2,1,1,5,5,1,4,1,0,1]

theorem envBound33242 : H12AffineFastState.Bounded env33242 := by
  intro p hp
  have h : env33242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33241_33242 : H12AffineEnvironment.transform 2 1 env33241 = env33242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env33241 == env33242) = true)

theorem identity33242 : scanCanonicalize (H12AffineFastState.compose env33242 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound33242 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33243 : List Nat := [2,1,1,1,1,1,0,0,0,1,0,1,1,1,0,2,1,2,0,1,0,1,0,2,0,1,2,1,1,0,0,1,1,1,0,1]

theorem envBound33243 : H12AffineFastState.Bounded env33243 := by
  intro p hp
  have h : env33243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33242_33243 : H12AffineEnvironment.transform 1 1 env33242 = env33243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env33242 == env33243) = true)

def env33244 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,853,73,80,276,65536,65895,65664,533,277,852,648,65910,65552,916,66162,319,65847,80,68374,68,64,257,65830,1,340]

theorem envBound33244 : H12AffineFastState.Bounded env33244 := by
  intro p hp
  have h : env33244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33232_33244 : H12AffineEnvironment.transform 9 321 env33232 = env33244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env33232 == env33244) = true)

theorem identity33244 : scanCanonicalize (H12AffineFastState.compose env33244 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound33244 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env33245 : List Nat := [2,4,8,16,32,64,128,20,512,85,2048,577,73,80,0,65536,65651,65664,533,1,576,648,65634,65552,640,66162,43,65571,80,68098,68,64,21,65586,1,64]

theorem envBound33245 : H12AffineFastState.Bounded env33245 := by
  intro p hp
  have h : env33245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33244_33245 : H12AffineEnvironment.transform 7 20 env33244 = env33245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env33244 == env33245) = true)

theorem identity33245 : scanCanonicalize (H12AffineFastState.compose env33245 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 610) := by decide +kernel

theorem selectedBound33245 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env33246 : List Nat := [2,4,8,16,32,64,128,20,512,85,2048,577,73,80,0,610,529,738,533,1,576,648,512,626,640,16,43,577,80,2144,68,64,21,592,1,64]

theorem envBound33246 : H12AffineFastState.Bounded env33246 := by
  intro p hp
  have h : env33246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33245_33246 : H12AffineEnvironment.transform 15 610 env33245 = env33246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 610 env33245 == env33246) = true)

theorem identity33246 : scanCanonicalize (H12AffineFastState.compose env33246 (packedSelected [0,1,7,8,10,11,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound33246 : packedSelected [0,1,7,8,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env33247 : List Nat := [2,4,8,16,32,64,40,20,512,85,2048,577,73,80,0,610,529,586,533,1,576,544,512,626,552,16,43,577,80,2144,68,64,21,592,1,64]

theorem envBound33247 : H12AffineFastState.Bounded env33247 := by
  intro p hp
  have h : env33247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33246_33247 : H12AffineEnvironment.transform 6 40 env33246 = env33247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env33246 == env33247) = true)

theorem identity33247 : scanCanonicalize (H12AffineFastState.compose env33247 (packedSelected [1,2,3,5,10,13] rootPS)) = affineNative (2^(8+1) ^^^ 71) := by decide +kernel

theorem selectedBound33247 : packedSelected [1,2,3,5,10,13] rootPS < 2^1333 := by decide +kernel

def env33248 : List Nat := [2,4,8,16,32,64,40,20,71,85,2048,6,73,80,0,37,86,13,82,1,7,103,71,53,111,16,43,6,80,2144,68,64,21,23,1,64]

theorem envBound33248 : H12AffineFastState.Bounded env33248 := by
  intro p hp
  have h : env33248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33247_33248 : H12AffineEnvironment.transform 8 71 env33247 = env33248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 71 env33247 == env33248) = true)

theorem identity33248 : scanCanonicalize (H12AffineFastState.compose env33248 (packedSelected [4,9,16] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound33248 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env33249 : List Nat := [2,3,8,16,32,64,40,19,64,82,2048,1,73,80,0,34,81,10,82,1,0,96,64,50,104,16,43,1,80,2144,67,64,18,16,1,64]

theorem envBound33249 : H12AffineFastState.Bounded env33249 := by
  intro p hp
  have h : env33249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33248_33249 : H12AffineEnvironment.transform 1 3 env33248 = env33249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env33248 == env33249) = true)

def env33250 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1557,73,1297,276,65536,66598,65664,1877,277,1556,649,65910,66897,917,66163,1150,66678,1297,68375,68,64,257,66663,1344,341]

theorem envBound33250 : H12AffineFastState.Bounded env33250 := by
  intro p hp
  have h : env33250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33231_33250 : H12AffineEnvironment.transform 11 1557 env33231 = env33250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1557 env33231 == env33250) = true)

def env33251 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,853,73,81,276,65536,65894,65664,533,277,852,649,65910,65553,917,66163,318,65846,81,68375,68,64,257,65831,0,341]

theorem envBound33251 : H12AffineFastState.Bounded env33251 := by
  intro p hp
  have h : env33251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33250_33251 : H12AffineEnvironment.transform 9 320 env33250 = env33251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env33250 == env33251) = true)

theorem identity33251 : scanCanonicalize (H12AffineFastState.compose env33251 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 64) := by decide +kernel

theorem selectedBound33251 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env33252 : List Nat := [2,4,8,16,32,64,128,256,64,320,2048,277,73,81,276,65536,65894,65664,85,277,276,201,65910,65553,469,65587,318,65846,81,67927,68,64,257,65831,0,341]

theorem envBound33252 : H12AffineFastState.Bounded env33252 := by
  intro p hp
  have h : env33252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33251_33252 : H12AffineEnvironment.transform 8 64 env33251 = env33252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 64 env33251 == env33252) = true)

theorem identity33252 : scanCanonicalize (H12AffineFastState.compose env33252 (packedSelected [0,3,4,5,9,10,16,27] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound33252 : packedSelected [0,3,4,5,9,10,16,27] rootPS < 2^1333 := by decide +kernel

def env33253 : List Nat := [2,4,8,16,32,64,128,256,64,320,2048,277,73,81,276,35,325,163,85,277,276,201,341,50,469,16,318,277,81,2420,68,64,257,260,0,341]

theorem envBound33253 : H12AffineFastState.Bounded env33253 := by
  intro p hp
  have h : env33253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33252_33253 : H12AffineEnvironment.transform 15 35 env33252 = env33253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env33252 == env33253) = true)

theorem identity33253 : scanCanonicalize (H12AffineFastState.compose env33253 (packedSelected [0,2,3,5,7,8,10,13,18] rootPS)) = affineNative (2^(10+1) ^^^ 148) := by decide +kernel

theorem selectedBound33253 : packedSelected [0,2,3,5,7,8,10,13,18] rootPS < 2^1333 := by decide +kernel

def env33254 : List Nat := [2,4,8,16,32,64,128,256,64,320,148,277,73,81,276,35,325,163,85,277,276,201,341,50,469,16,318,277,81,480,68,64,257,260,0,341]

theorem envBound33254 : H12AffineFastState.Bounded env33254 := by
  intro p hp
  have h : env33254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33253_33254 : H12AffineEnvironment.transform 10 148 env33253 = env33254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 148 env33253 == env33254) = true)

theorem identity33254 : scanCanonicalize (H12AffineFastState.compose env33254 (packedSelected [8,11,12,15,20] rootPS)) = affineNative (2^(6+1) ^^^ 73) := by decide +kernel

theorem selectedBound33254 : packedSelected [8,11,12,15,20] rootPS < 2^1333 := by decide +kernel

def env33255 : List Nat := [2,4,8,16,32,64,73,256,64,320,93,277,73,81,276,35,325,106,85,277,276,0,341,50,284,16,318,277,81,297,68,64,257,260,0,341]

theorem envBound33255 : H12AffineFastState.Bounded env33255 := by
  intro p hp
  have h : env33255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33254_33255 : H12AffineEnvironment.transform 6 73 env33254 = env33255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 73 env33254 == env33255) = true)

theorem identity33255 : scanCanonicalize (H12AffineFastState.compose env33255 (packedSelected [1,2,13] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound33255 : packedSelected [1,2,13] rootPS < 2^1333 := by decide +kernel

def env33256 : List Nat := [2,4,8,16,32,64,73,117,64,53,93,96,73,81,97,35,48,106,85,96,97,0,32,50,105,16,75,96,81,92,68,64,116,113,0,32]

theorem envBound33256 : H12AffineFastState.Bounded env33256 := by
  intro p hp
  have h : env33256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33255_33256 : H12AffineEnvironment.transform 7 117 env33255 = env33256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env33255 == env33256) = true)

theorem identity33256 : scanCanonicalize (H12AffineFastState.compose env33256 (packedSelected [2,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound33256 : packedSelected [2,5,10] rootPS < 2^1333 := by decide +kernel

def env33257 : List Nat := [2,4,8,16,32,48,57,5,48,53,45,16,57,33,17,35,48,26,37,16,17,0,32,50,25,16,59,16,33,44,52,48,4,1,0,32]

theorem envBound33257 : H12AffineFastState.Bounded env33257 := by
  intro p hp
  have h : env33257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33256_33257 : H12AffineEnvironment.transform 5 48 env33256 = env33257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env33256 == env33257) = true)

theorem identity33257 : scanCanonicalize (H12AffineFastState.compose env33257 (packedSelected [0,1,2,5,7,8] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound33257 : packedSelected [0,1,2,5,7,8] rootPS < 2^1333 := by decide +kernel

def env33258 : List Nat := [2,4,8,7,32,39,46,5,39,34,45,7,46,33,6,35,39,13,37,7,6,0,32,37,14,7,44,7,33,44,35,39,4,1,0,32]

theorem envBound33258 : H12AffineFastState.Bounded env33258 := by
  intro p hp
  have h : env33258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33257_33258 : H12AffineEnvironment.transform 3 7 env33257 = env33258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env33257 == env33258) = true)

theorem identity33258 : scanCanonicalize (H12AffineFastState.compose env33258 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound33258 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33259 : List Nat := [2,4,8,7,11,12,5,5,12,9,6,7,5,10,6,8,12,13,14,7,6,0,11,14,14,7,7,7,10,7,8,12,4,1,0,11]

theorem envBound33259 : H12AffineFastState.Bounded env33259 := by
  intro p hp
  have h : env33259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33258_33259 : H12AffineEnvironment.transform 4 11 env33258 = env33259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env33258 == env33259) = true)

theorem identity33259 : scanCanonicalize (H12AffineFastState.compose env33259 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound33259 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33260 : List Nat := [2,4,5,7,6,1,5,5,1,4,6,7,5,7,6,5,1,0,3,7,6,0,6,3,3,7,7,7,7,7,5,1,4,1,0,6]

theorem envBound33260 : H12AffineFastState.Bounded env33260 := by
  intro p hp
  have h : env33260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33259_33260 : H12AffineEnvironment.transform 2 5 env33259 = env33260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env33259 == env33260) = true)

theorem identity33260 : scanCanonicalize (H12AffineFastState.compose env33260 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound33260 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env33261 : List Nat := [2,2,3,1,0,1,3,3,1,2,0,1,3,1,0,3,1,0,3,1,0,0,0,3,3,1,1,1,1,1,3,1,2,1,0,0]

theorem envBound33261 : H12AffineFastState.Bounded env33261 := by
  intro p hp
  have h : env33261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33260_33261 : H12AffineEnvironment.transform 1 2 env33260 = env33261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env33260 == env33261) = true)

theorem identity33261 : scanCanonicalize (H12AffineFastState.compose env33261 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound33261 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33262 : List Nat := [0,0,1,1,0,1,1,1,1,0,0,1,1,1,0,1,1,0,1,1,0,0,0,1,1,1,1,1,1,1,1,1,0,1,0,0]

theorem envBound33262 : H12AffineFastState.Bounded env33262 := by
  intro p hp
  have h : env33262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33261_33262 : H12AffineEnvironment.transform 0 0 env33261 = env33262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env33261 == env33262) = true)

def env33263 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,852,73,80,276,65536,65895,65664,532,277,853,649,65910,65552,917,66163,319,65847,80,68375,68,64,257,65830,1,341]

theorem envBound33263 : H12AffineFastState.Bounded env33263 := by
  intro p hp
  have h : env33263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33250_33263 : H12AffineEnvironment.transform 9 321 env33250 = env33263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env33250 == env33263) = true)

theorem identity33263 : scanCanonicalize (H12AffineFastState.compose env33263 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound33263 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env33264 : List Nat := [2,4,8,16,32,64,128,20,512,85,2048,576,73,80,0,65536,65651,65664,532,1,577,649,65634,65552,641,66163,43,65571,80,68099,68,64,21,65586,1,65]

theorem envBound33264 : H12AffineFastState.Bounded env33264 := by
  intro p hp
  have h : env33264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33263_33264 : H12AffineEnvironment.transform 7 20 env33263 = env33264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env33263 == env33264) = true)

theorem identity33264 : scanCanonicalize (H12AffineFastState.compose env33264 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 611) := by decide +kernel

theorem selectedBound33264 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env33265 : List Nat := [2,4,8,16,32,64,128,20,512,85,2048,576,73,80,0,611,528,739,532,1,577,649,513,627,641,16,43,576,80,2144,68,64,21,593,1,65]

theorem envBound33265 : H12AffineFastState.Bounded env33265 := by
  intro p hp
  have h : env33265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33264_33265 : H12AffineEnvironment.transform 15 611 env33264 = env33265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 611 env33264 == env33265) = true)

theorem identity33265 : scanCanonicalize (H12AffineFastState.compose env33265 (packedSelected [0,1,7,8,10,11,12,15] rootPS)) = affineNative (2^(8+1) ^^^ 232) := by decide +kernel

theorem selectedBound33265 : packedSelected [0,1,7,8,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env33266 : List Nat := [2,4,8,16,32,64,128,20,232,85,2048,168,73,80,0,139,248,11,252,1,169,97,233,155,105,16,43,168,80,2144,68,64,21,185,1,65]

theorem envBound33266 : H12AffineFastState.Bounded env33266 := by
  intro p hp
  have h : env33266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33265_33266 : H12AffineEnvironment.transform 8 232 env33265 = env33266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 232 env33265 == env33266) = true)

theorem identity33266 : scanCanonicalize (H12AffineFastState.compose env33266 (packedSelected [1,2,3,5,10,13] rootPS)) = affineNative (2^(5+1) ^^^ 22) := by decide +kernel

theorem selectedBound33266 : packedSelected [1,2,3,5,10,13] rootPS < 2^1333 := by decide +kernel

def env33267 : List Nat := [2,4,8,16,32,22,128,20,190,3,2048,168,31,6,0,139,174,11,170,1,169,55,191,155,63,16,43,168,6,2102,18,22,21,185,1,23]

theorem envBound33267 : H12AffineFastState.Bounded env33267 := by
  intro p hp
  have h : env33267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33266_33267 : H12AffineEnvironment.transform 5 22 env33266 = env33267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 22 env33266 == env33267) = true)

theorem identity33267 : scanCanonicalize (H12AffineFastState.compose env33267 (packedSelected [4,9,16] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound33267 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env33268 : List Nat := [2,4,8,16,32,22,41,20,23,3,2048,1,31,6,0,34,7,11,3,1,0,55,22,50,63,16,43,1,6,2102,18,22,21,16,1,23]

theorem envBound33268 : H12AffineFastState.Bounded env33268 := by
  intro p hp
  have h : env33268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33267_33268 : H12AffineEnvironment.transform 6 41 env33267 = env33268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env33267 == env33268) = true)

def env33269 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74863,65665,4416,8540,4097,5276,74047,66897,13769,78895,1151,74815,1297,81227,8205,8201,257,74798,1344,5952]

theorem envBound33269 : H12AffineFastState.Bounded env33269 := by
  intro p hp
  have h : env33269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33229_33269 : H12AffineEnvironment.transform 17 65665 env33229 = env33269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env33229 == env33269) = true)

theorem identity33269 : scanCanonicalize (H12AffineFastState.compose env33269 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5384) := by decide +kernel

theorem selectedBound33269 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env33270 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5384,1297,5205,65536,69991,65665,4416,5204,4097,5276,70711,66897,193,65831,1151,69943,1297,67651,5381,5377,257,69926,1344,5952]

theorem envBound33270 : H12AffineFastState.Bounded env33270 := by
  intro p hp
  have h : env33270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33269_33270 : H12AffineEnvironment.transform 12 5384 env33269 = env33270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5384 env33269 == env33270) = true)

def env33271 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1556,796,1297,577,65536,67443,65665,1876,576,1557,648,66083,66897,193,65831,1151,67363,1297,67651,785,789,257,67378,1344,340]

theorem envBound33271 : H12AffineFastState.Bounded env33271 := by
  intro p hp
  have h : env33271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33270_33271 : H12AffineEnvironment.transform 11 1556 env33270 = env33271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1556 env33270 == env33271) = true)

def env33272 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,836,796,65,577,65536,66083,65665,516,576,837,648,66083,65537,193,65831,303,66163,65,67651,785,789,257,66146,16,340]

theorem envBound33272 : H12AffineFastState.Bounded env33272 := by
  intro p hp
  have h : env33272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33271_33272 : H12AffineEnvironment.transform 9 336 env33271 = env33272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 336 env33271 == env33272) = true)

theorem identity33272 : scanCanonicalize (H12AffineFastState.compose env33272 (packedSelected [1,8,28] rootPS)) = affineNative (2^(7+1) ^^^ 234) := by decide +kernel

theorem selectedBound33272 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env33273 : List Nat := [2,4,8,16,32,64,128,234,512,186,2048,686,758,65,577,65536,66083,65665,516,576,687,648,66083,65537,193,65741,197,66163,65,67651,763,767,235,66146,16,190]

theorem envBound33273 : H12AffineFastState.Bounded env33273 := by
  intro p hp
  have h : env33273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33272_33273 : H12AffineEnvironment.transform 7 234 env33272 = env33273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 234 env33272 == env33273) = true)

def env33274 : List Nat := [2,4,8,16,32,64,128,234,164,186,2048,10,82,65,229,65536,65671,65665,160,228,11,44,65671,65537,193,65741,197,65751,65,67651,95,91,235,65734,16,190]

theorem envBound33274 : H12AffineFastState.Bounded env33274 := by
  intro p hp
  have h : env33274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33273_33274 : H12AffineEnvironment.transform 8 164 env33273 = env33274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 164 env33273 == env33274) = true)

theorem identity33274 : scanCanonicalize (H12AffineFastState.compose env33274 (packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS)) = affineNative (2^(10+1) ^^^ 242) := by decide +kernel

theorem selectedBound33274 : packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS < 2^1333 := by decide +kernel

def env33275 : List Nat := [2,4,8,16,32,64,128,234,164,186,242,10,82,65,229,65536,65671,65665,160,228,11,44,65671,65537,193,65741,197,65751,65,65713,95,91,235,65734,16,190]

theorem envBound33275 : H12AffineFastState.Bounded env33275 := by
  intro p hp
  have h : env33275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33274_33275 : H12AffineEnvironment.transform 10 242 env33274 = env33275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 242 env33274 == env33275) = true)

theorem identity33275 : scanCanonicalize (H12AffineFastState.compose env33275 (packedSelected [2,3,4,7,8,11,12,15,16,17,18,19,20,23] rootPS)) = affineNative (2^(6+1) ^^^ 100) := by decide +kernel

theorem selectedBound33275 : packedSelected [2,3,4,7,8,11,12,15,16,17,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env33276 : List Nat := [2,4,8,16,32,64,100,14,64,94,22,10,82,65,1,65536,65635,65637,68,0,11,44,65635,65537,37,65577,33,65587,65,65621,95,91,15,65570,16,90]

theorem envBound33276 : H12AffineFastState.Bounded env33276 := by
  intro p hp
  have h : env33276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33275_33276 : H12AffineEnvironment.transform 6 100 env33275 = env33276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 100 env33275 == env33276) = true)

theorem identity33276 : scanCanonicalize (H12AffineFastState.compose env33276 (packedSelected [1,2,4,5,8,9,10,16,18] rootPS)) = affineNative (2^(15+1) ^^^ 4) := by decide +kernel

theorem selectedBound33276 : packedSelected [1,2,4,5,8,9,10,16,18] rootPS < 2^1333 := by decide +kernel

def env33277 : List Nat := [2,4,8,16,32,64,100,14,64,94,22,10,82,65,1,4,103,97,68,0,11,44,103,5,37,45,33,55,65,81,95,91,15,38,16,90]

theorem envBound33277 : H12AffineFastState.Bounded env33277 := by
  intro p hp
  have h : env33277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33276_33277 : H12AffineEnvironment.transform 15 4 env33276 = env33277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4 env33276 == env33277) = true)

theorem identity33277 : scanCanonicalize (H12AffineFastState.compose env33277 (packedSelected [0,1,4,5,7,9,10,11] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound33277 : packedSelected [0,1,4,5,7,9,10,11] rootPS < 2^1333 := by decide +kernel

def env33278 : List Nat := [2,4,8,16,32,0,36,14,0,30,22,10,18,1,1,4,39,33,4,0,11,44,39,5,37,45,33,55,1,17,31,27,15,38,16,26]

theorem envBound33278 : H12AffineFastState.Bounded env33278 := by
  intro p hp
  have h : env33278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33277_33278 : H12AffineEnvironment.transform 5 0 env33277 = env33278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env33277 == env33278) = true)

theorem identity33278 : scanCanonicalize (H12AffineFastState.compose env33278 (packedSelected [0,1,3,4,5,8] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound33278 : packedSelected [0,1,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env33279 : List Nat := [2,2,8,16,32,0,34,8,0,24,16,10,18,1,1,2,33,33,2,0,11,42,33,3,35,43,33,49,1,17,25,27,9,32,16,26]

theorem envBound33279 : H12AffineFastState.Bounded env33279 := by
  intro p hp
  have h : env33279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33278_33279 : H12AffineEnvironment.transform 1 2 env33278 = env33279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env33278 == env33279) = true)

theorem identity33279 : scanCanonicalize (H12AffineFastState.compose env33279 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound33279 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env33280 : List Nat := [2,2,8,16,17,0,19,8,0,24,16,10,18,1,1,2,16,16,2,0,11,27,16,3,18,26,16,0,1,17,25,27,9,17,16,26]

theorem envBound33280 : H12AffineFastState.Bounded env33280 := by
  intro p hp
  have h : env33280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33279_33280 : H12AffineEnvironment.transform 4 17 env33279 = env33280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env33279 == env33280) = true)

theorem identity33280 : scanCanonicalize (H12AffineFastState.compose env33280 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound33280 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env33281 : List Nat := [2,2,8,0,1,0,3,8,0,8,0,10,2,1,1,2,0,0,2,0,11,11,0,3,2,10,0,0,1,1,9,11,9,1,0,10]

theorem envBound33281 : H12AffineFastState.Bounded env33281 := by
  intro p hp
  have h : env33281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33280_33281 : H12AffineEnvironment.transform 3 0 env33280 = env33281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env33280 == env33281) = true)

theorem identity33281 : scanCanonicalize (H12AffineFastState.compose env33281 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound33281 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33282 : List Nat := [2,2,3,0,1,0,3,3,0,3,0,1,2,1,1,2,0,0,2,0,0,0,0,3,2,1,0,0,1,1,2,0,2,1,0,1]

theorem envBound33282 : H12AffineFastState.Bounded env33282 := by
  intro p hp
  have h : env33282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33281_33282 : H12AffineEnvironment.transform 2 3 env33281 = env33282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env33281 == env33282) = true)

theorem identity33282 : scanCanonicalize (H12AffineFastState.compose env33282 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound33282 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33283 : List Nat := [1,1,0,0,1,0,0,0,0,0,0,1,1,1,1,1,0,0,1,0,0,0,0,0,1,1,0,0,1,1,1,0,1,1,0,1]

theorem envBound33283 : H12AffineFastState.Bounded env33283 := by
  intro p hp
  have h : env33283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33282_33283 : H12AffineEnvironment.transform 0 1 env33282 = env33283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env33282 == env33283) = true)

def env33284 : List Nat := [2,4,8,16,32,64,128,234,165,186,2048,11,83,65,228,65536,65670,65665,161,229,10,45,65670,65537,193,65741,197,65750,65,67651,94,90,235,65735,16,190]

theorem envBound33284 : H12AffineFastState.Bounded env33284 := by
  intro p hp
  have h : env33284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33273_33284 : H12AffineEnvironment.transform 8 165 env33273 = env33284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 165 env33273 == env33284) = true)

theorem identity33284 : scanCanonicalize (H12AffineFastState.compose env33284 (packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS)) = affineNative (2^(10+1) ^^^ 249) := by decide +kernel

theorem selectedBound33284 : packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS < 2^1333 := by decide +kernel

def env33285 : List Nat := [2,4,8,16,32,64,128,234,165,186,249,11,83,65,228,65536,65670,65665,161,229,10,45,65670,65537,193,65741,197,65750,65,65722,94,90,235,65735,16,190]

theorem envBound33285 : H12AffineFastState.Bounded env33285 := by
  intro p hp
  have h : env33285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33284_33285 : H12AffineEnvironment.transform 10 249 env33284 = env33285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 249 env33284 == env33285) = true)

theorem identity33285 : scanCanonicalize (H12AffineFastState.compose env33285 (packedSelected [1,8,10,11,15,19,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 140) := by decide +kernel

theorem selectedBound33285 : packedSelected [1,8,10,11,15,19,23,32] rootPS < 2^1333 := by decide +kernel

def env33286 : List Nat := [2,4,8,16,32,64,128,234,165,186,249,11,83,65,228,140,10,13,161,229,10,45,10,141,193,65,197,90,65,54,94,90,235,75,16,190]

theorem envBound33286 : H12AffineFastState.Bounded env33286 := by
  intro p hp
  have h : env33286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33285_33286 : H12AffineEnvironment.transform 15 140 env33285 = env33286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 140 env33285 == env33286) = true)

theorem identity33286 : scanCanonicalize (H12AffineFastState.compose env33286 (packedSelected [5,7,8,9,10,12,13,16,17] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound33286 : packedSelected [5,7,8,9,10,12,13,16,17] rootPS < 2^1333 := by decide +kernel

def env33287 : List Nat := [2,4,8,16,32,64,89,51,124,99,32,11,83,65,61,85,10,13,120,60,10,45,10,84,24,65,28,90,65,54,94,90,50,75,16,103]

theorem envBound33287 : H12AffineFastState.Bounded env33287 := by
  intro p hp
  have h : env33287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33286_33287 : H12AffineEnvironment.transform 6 89 env33286 = env33287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env33286 == env33287) = true)

theorem identity33287 : scanCanonicalize (H12AffineFastState.compose env33287 (packedSelected [2,3,5,8,10,11] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound33287 : packedSelected [2,3,5,8,10,11] rootPS < 2^1333 := by decide +kernel

def env33288 : List Nat := [2,4,8,16,32,10,19,51,54,41,32,11,25,11,61,31,10,13,50,60,10,45,10,30,24,11,28,16,11,54,20,16,50,1,16,45]

theorem envBound33288 : H12AffineFastState.Bounded env33288 := by
  intro p hp
  have h : env33288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33287_33288 : H12AffineEnvironment.transform 5 10 env33287 = env33288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env33287 == env33288) = true)

theorem identity33288 : scanCanonicalize (H12AffineFastState.compose env33288 (packedSelected [0,1,2,3,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound33288 : packedSelected [0,1,2,3,7,8] rootPS < 2^1333 := by decide +kernel

def env33289 : List Nat := [2,4,8,16,27,10,19,8,13,18,27,11,25,11,6,31,10,13,9,7,10,22,10,30,24,11,28,16,11,13,20,16,9,1,16,22]

theorem envBound33289 : H12AffineFastState.Bounded env33289 := by
  intro p hp
  have h : env33289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33288_33289 : H12AffineEnvironment.transform 4 27 env33288 = env33289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env33288 == env33289) = true)

def env33290 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,837,796,64,577,65536,66082,65665,517,576,836,648,66083,65536,193,65831,302,66162,64,67651,785,789,257,66147,17,340]

theorem envBound33290 : H12AffineFastState.Bounded env33290 := by
  intro p hp
  have h : env33290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33271_33290 : H12AffineEnvironment.transform 9 337 env33271 = env33290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 337 env33271 == env33290) = true)

theorem identity33290 : scanCanonicalize (H12AffineFastState.compose env33290 (packedSelected [1,8,28] rootPS)) = affineNative (2^(8+1) ^^^ 175) := by decide +kernel

theorem selectedBound33290 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env33291 : List Nat := [2,4,8,16,32,64,128,256,175,337,2048,490,435,64,238,65536,65677,65665,170,239,491,39,65676,65536,193,65831,302,65757,64,67651,446,442,257,65740,17,340]

theorem envBound33291 : H12AffineFastState.Bounded env33291 := by
  intro p hp
  have h : env33291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33290_33291 : H12AffineEnvironment.transform 8 175 env33290 = env33291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 175 env33290 == env33291) = true)

def env33292 : List Nat := [2,4,8,16,32,64,128,224,175,177,2048,10,83,64,238,65536,65677,65665,170,239,11,39,65676,65536,193,65735,206,65757,64,67651,94,90,225,65740,17,180]

theorem envBound33292 : H12AffineFastState.Bounded env33292 := by
  intro p hp
  have h : env33292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33291_33292 : H12AffineEnvironment.transform 7 224 env33291 = env33292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 224 env33291 == env33292) = true)

theorem identity33292 : scanCanonicalize (H12AffineFastState.compose env33292 (packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS)) = affineNative (2^(15+1) ^^^ 2149) := by decide +kernel

theorem selectedBound33292 : packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS < 2^1333 := by decide +kernel

def env33293 : List Nat := [2,4,8,16,32,64,128,224,175,177,2048,10,83,64,238,2149,2280,2276,170,239,11,39,2281,2149,193,2210,206,2232,64,38,94,90,225,2217,17,180]

theorem envBound33293 : H12AffineFastState.Bounded env33293 := by
  intro p hp
  have h : env33293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33292_33293 : H12AffineEnvironment.transform 15 2149 env33292 = env33293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2149 env33292 == env33293) = true)

theorem identity33293 : scanCanonicalize (H12AffineFastState.compose env33293 (packedSelected [0,1,2,3,4,10,11,13,15,16,17,18,19,23] rootPS)) = affineNative (2^(10+1) ^^^ 54) := by decide +kernel

theorem selectedBound33293 : packedSelected [0,1,2,3,4,10,11,13,15,16,17,18,19,23] rootPS < 2^1333 := by decide +kernel

def env33294 : List Nat := [2,4,8,16,32,64,128,224,175,177,54,10,83,64,238,83,222,210,170,239,11,39,223,83,193,148,206,142,64,38,94,90,225,159,17,180]

theorem envBound33294 : H12AffineFastState.Bounded env33294 := by
  intro p hp
  have h : env33294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33293_33294 : H12AffineEnvironment.transform 10 54 env33293 = env33294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 54 env33293 == env33294) = true)

theorem identity33294 : scanCanonicalize (H12AffineFastState.compose env33294 (packedSelected [0,4,8,10,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 84) := by decide +kernel

theorem selectedBound33294 : packedSelected [0,4,8,10,12,15] rootPS < 2^1333 := by decide +kernel

def env33295 : List Nat := [2,4,8,16,32,64,84,52,123,101,54,10,83,64,58,83,10,6,126,59,11,39,11,83,21,64,26,90,64,38,94,90,53,75,17,96]

theorem envBound33295 : H12AffineFastState.Bounded env33295 := by
  intro p hp
  have h : env33295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33294_33295 : H12AffineEnvironment.transform 6 84 env33294 = env33295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 84 env33294 == env33295) = true)

theorem identity33295 : scanCanonicalize (H12AffineFastState.compose env33295 (packedSelected [0,1,2,4,5,7,8,9,12] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound33295 : packedSelected [0,1,2,4,5,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env33296 : List Nat := [2,4,8,16,32,11,31,52,48,46,54,10,24,11,58,24,10,6,53,59,11,39,11,24,21,11,26,17,11,38,21,17,53,0,17,43]

theorem envBound33296 : H12AffineFastState.Bounded env33296 := by
  intro p hp
  have h : env33296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33295_33296 : H12AffineEnvironment.transform 5 11 env33295 = env33296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env33295 == env33296) = true)

def env33297 : List Nat := [2,4,8,16,32,64,128,225,175,176,2048,11,82,64,238,65536,65677,65665,170,239,10,39,65676,65536,193,65734,207,65757,64,67651,95,91,224,65740,17,181]

theorem envBound33297 : H12AffineFastState.Bounded env33297 := by
  intro p hp
  have h : env33297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33291_33297 : H12AffineEnvironment.transform 7 225 env33291 = env33297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 225 env33291 == env33297) = true)

theorem identity33297 : scanCanonicalize (H12AffineFastState.compose env33297 (packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS)) = affineNative (2^(15+1) ^^^ 2159) := by decide +kernel

theorem selectedBound33297 : packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS < 2^1333 := by decide +kernel

def env33298 : List Nat := [2,4,8,16,32,64,128,225,175,176,2048,11,82,64,238,2159,2274,2286,170,239,10,39,2275,2159,193,2217,207,2226,64,44,95,91,224,2211,17,181]

theorem envBound33298 : H12AffineFastState.Bounded env33298 := by
  intro p hp
  have h : env33298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33297_33298 : H12AffineEnvironment.transform 15 2159 env33297 = env33298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2159 env33297 == env33298) = true)

theorem identity33298 : scanCanonicalize (H12AffineFastState.compose env33298 (packedSelected [4,5,11,12,18,20,23,27,32] rootPS)) = affineNative (2^(10+1) ^^^ 201) := by decide +kernel

theorem selectedBound33298 : packedSelected [4,5,11,12,18,20,23,27,32] rootPS < 2^1333 := by decide +kernel

def env33299 : List Nat := [2,4,8,16,32,64,128,225,175,176,201,11,82,64,238,166,43,39,170,239,10,39,42,166,193,96,207,123,64,44,95,91,224,106,17,181]

theorem envBound33299 : H12AffineFastState.Bounded env33299 := by
  intro p hp
  have h : env33299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33298_33299 : H12AffineEnvironment.transform 10 201 env33298 = env33299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 201 env33298 == env33299) = true)

theorem identity33299 : scanCanonicalize (H12AffineFastState.compose env33299 (packedSelected [2,11,13,15,16] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound33299 : packedSelected [2,11,13,15,16] rootPS < 2^1333 := by decide +kernel

def env33300 : List Nat := [2,4,3,16,32,64,128,225,164,176,194,0,82,64,229,166,32,39,161,228,1,39,33,166,193,96,196,112,64,39,84,80,224,97,17,181]

theorem envBound33300 : H12AffineFastState.Bounded env33300 := by
  intro p hp
  have h : env33300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33299_33300 : H12AffineEnvironment.transform 2 3 env33299 = env33300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env33299 == env33300) = true)

theorem identity33300 : scanCanonicalize (H12AffineFastState.compose env33300 (packedSelected [3,4,5,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound33300 : packedSelected [3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env33301 : List Nat := [2,4,3,16,32,64,19,114,55,35,81,0,82,64,118,53,32,39,50,119,1,39,33,53,82,96,87,112,64,39,84,80,115,97,17,38]

theorem envBound33301 : H12AffineFastState.Bounded env33301 := by
  intro p hp
  have h : env33301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33300_33301 : H12AffineEnvironment.transform 6 19 env33300 = env33301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env33300 == env33301) = true)

theorem identity33301 : scanCanonicalize (H12AffineFastState.compose env33301 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound33301 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env33302 : List Nat := [2,4,3,16,7,64,19,85,16,4,81,0,82,64,81,18,7,0,21,80,1,0,6,18,82,71,87,87,64,0,84,80,84,70,17,1]

theorem envBound33302 : H12AffineFastState.Bounded env33302 := by
  intro p hp
  have h : env33302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33301_33302 : H12AffineEnvironment.transform 4 7 env33301 = env33302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env33301 == env33302) = true)

theorem identity33302 : scanCanonicalize (H12AffineFastState.compose env33302 (packedSelected [0,3,4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound33302 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env33303 : List Nat := [2,4,3,16,7,17,19,4,16,4,0,0,3,17,0,18,7,0,21,1,1,0,6,18,3,22,6,6,17,0,5,1,5,23,17,1]

theorem envBound33303 : H12AffineFastState.Bounded env33303 := by
  intro p hp
  have h : env33303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33302_33303 : H12AffineEnvironment.transform 5 17 env33302 = env33303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env33302 == env33303) = true)

def env33304 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1557,797,1297,576,65536,67442,65665,1877,577,1556,649,66082,66897,193,65831,1151,67362,1297,67651,784,788,257,67379,1344,341]

theorem envBound33304 : H12AffineFastState.Bounded env33304 := by
  intro p hp
  have h : env33304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33270_33304 : H12AffineEnvironment.transform 11 1557 env33270 = env33304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1557 env33270 == env33304) = true)

def env33305 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,837,797,65,576,65536,66082,65665,517,577,836,649,66082,65537,193,65831,303,66162,65,67651,784,788,257,66147,16,341]

theorem envBound33305 : H12AffineFastState.Bounded env33305 := by
  intro p hp
  have h : env33305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33304_33305 : H12AffineEnvironment.transform 9 336 env33304 = env33305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 336 env33304 == env33305) = true)

theorem identity33305 : scanCanonicalize (H12AffineFastState.compose env33305 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 984) := by decide +kernel

theorem selectedBound33305 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env33306 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,837,797,65,576,984,506,857,517,577,836,649,506,985,193,767,303,426,65,2971,784,788,257,443,16,341]

theorem envBound33306 : H12AffineFastState.Bounded env33306 := by
  intro p hp
  have h : env33306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33305_33306 : H12AffineEnvironment.transform 15 984 env33305 = env33306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 984 env33305 == env33306) = true)

def env33307 : List Nat := [2,4,8,0,32,64,128,256,512,320,2048,837,781,65,576,968,490,841,517,577,836,649,490,969,193,751,303,426,65,2955,768,772,257,427,0,325]

theorem envBound33307 : H12AffineFastState.Bounded env33307 := by
  intro p hp
  have h : env33307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33306_33307 : H12AffineEnvironment.transform 3 0 env33306 = env33307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env33306 == env33307) = true)

theorem identity33307 : scanCanonicalize (H12AffineFastState.compose env33307 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 64) := by decide +kernel

theorem selectedBound33307 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env33308 : List Nat := [2,4,8,0,32,64,128,256,64,320,2048,261,333,65,0,392,490,265,69,1,260,201,490,393,193,175,303,426,65,2507,320,324,257,427,0,325]

theorem envBound33308 : H12AffineFastState.Bounded env33308 := by
  intro p hp
  have h : env33308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33307_33308 : H12AffineEnvironment.transform 8 64 env33307 = env33308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 64 env33307 == env33308) = true)

theorem identity33308 : scanCanonicalize (H12AffineFastState.compose env33308 (packedSelected [0,2,3,4,5,7,9,10,11,13,16,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 13) := by decide +kernel

theorem selectedBound33308 : packedSelected [0,2,3,4,5,7,9,10,11,13,16,17,18,20] rootPS < 2^1333 := by decide +kernel

def env33309 : List Nat := [2,4,8,0,32,64,128,256,64,320,13,261,333,65,0,392,490,265,69,1,260,201,490,393,193,175,303,426,65,454,320,324,257,427,0,325]

theorem envBound33309 : H12AffineFastState.Bounded env33309 := by
  intro p hp
  have h : env33309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33308_33309 : H12AffineEnvironment.transform 10 13 env33308 = env33309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 13 env33308 == env33309) = true)

theorem identity33309 : scanCanonicalize (H12AffineFastState.compose env33309 (packedSelected [0,2,5,7,8,10,13,17,18] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound33309 : packedSelected [0,2,5,7,8,10,13,17,18] rootPS < 2^1333 := by decide +kernel

def env33310 : List Nat := [2,4,2,0,32,64,128,256,64,320,7,261,327,65,0,386,480,259,69,1,260,195,480,387,193,165,293,416,65,454,320,324,257,417,0,325]

theorem envBound33310 : H12AffineFastState.Bounded env33310 := by
  intro p hp
  have h : env33310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33309_33310 : H12AffineEnvironment.transform 2 2 env33309 = env33310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env33309 == env33310) = true)

theorem identity33310 : scanCanonicalize (H12AffineFastState.compose env33310 (packedSelected [2,4,5,7,10,12] rootPS)) = affineNative (2^(6+1) ^^^ 69) := by decide +kernel

theorem selectedBound33310 : packedSelected [2,4,5,7,10,12] rootPS < 2^1333 := by decide +kernel

def env33311 : List Nat := [2,4,2,0,32,64,69,256,64,320,7,261,327,65,0,327,293,259,69,1,260,6,293,326,4,96,293,357,65,259,320,324,257,356,0,325]

theorem envBound33311 : H12AffineFastState.Bounded env33311 := by
  intro p hp
  have h : env33311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33310_33311 : H12AffineEnvironment.transform 6 69 env33310 = env33311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 69 env33310 == env33311) = true)

theorem identity33311 : scanCanonicalize (H12AffineFastState.compose env33311 (packedSelected [0,4,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 39) := by decide +kernel

theorem selectedBound33311 : packedSelected [0,4,5,8] rootPS < 2^1333 := by decide +kernel

def env33312 : List Nat := [2,4,2,0,32,39,34,256,39,295,7,261,288,38,0,288,293,259,34,1,260,6,293,289,4,7,293,258,38,259,295,291,257,259,0,290]

theorem envBound33312 : H12AffineFastState.Bounded env33312 := by
  intro p hp
  have h : env33312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33311_33312 : H12AffineEnvironment.transform 5 39 env33311 = env33312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 39 env33311 == env33312) = true)

theorem identity33312 : scanCanonicalize (H12AffineFastState.compose env33312 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound33312 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env33313 : List Nat := [2,2,2,0,32,33,34,256,33,289,1,259,288,32,0,288,291,259,34,1,258,0,291,289,2,1,291,258,32,259,289,291,257,259,0,290]

theorem envBound33313 : H12AffineFastState.Bounded env33313 := by
  intro p hp
  have h : env33313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33312_33313 : H12AffineEnvironment.transform 1 2 env33312 = env33313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env33312 == env33313) = true)

theorem identity33313 : scanCanonicalize (H12AffineFastState.compose env33313 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 34) := by decide +kernel

theorem selectedBound33313 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33314 : List Nat := [2,2,2,0,32,33,34,34,33,3,1,33,2,32,0,2,1,33,34,1,32,0,1,3,2,1,1,32,32,33,3,1,35,33,0,0]

theorem envBound33314 : H12AffineFastState.Bounded env33314 := by
  intro p hp
  have h : env33314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33313_33314 : H12AffineEnvironment.transform 7 34 env33313 = env33314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 34 env33313 == env33314) = true)

theorem identity33314 : scanCanonicalize (H12AffineFastState.compose env33314 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound33314 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33315 : List Nat := [2,2,2,0,0,1,2,2,1,3,1,1,2,0,0,2,1,1,2,1,0,0,1,3,2,1,1,0,0,1,3,1,3,1,0,0]

theorem envBound33315 : H12AffineFastState.Bounded env33315 := by
  intro p hp
  have h : env33315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33314_33315 : H12AffineEnvironment.transform 4 0 env33314 = env33315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env33314 == env33315) = true)

theorem identity33315 : scanCanonicalize (H12AffineFastState.compose env33315 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound33315 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33316 : List Nat := [0,0,0,0,0,1,0,0,1,1,1,1,0,0,0,0,1,1,0,1,0,0,1,1,0,1,1,0,0,1,1,1,1,1,0,0]

theorem envBound33316 : H12AffineFastState.Bounded env33316 := by
  intro p hp
  have h : env33316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33315_33316 : H12AffineEnvironment.transform 0 0 env33315 = env33316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env33315 == env33316) = true)

def env33317 : List Nat := [2,4,8,1,32,64,128,256,512,321,2048,837,780,65,576,969,491,840,517,577,836,649,491,968,193,750,303,426,65,2954,769,773,257,426,1,324]

theorem envBound33317 : H12AffineFastState.Bounded env33317 := by
  intro p hp
  have h : env33317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33306_33317 : H12AffineEnvironment.transform 3 1 env33306 = env33317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env33306 == env33317) = true)

theorem identity33317 : scanCanonicalize (H12AffineFastState.compose env33317 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound33317 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env33318 : List Nat := [2,4,8,1,32,64,128,5,512,68,2048,576,521,65,576,716,238,589,517,577,577,649,238,717,193,750,42,175,65,2703,516,512,4,175,1,65]

theorem envBound33318 : H12AffineFastState.Bounded env33318 := by
  intro p hp
  have h : env33318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33317_33318 : H12AffineEnvironment.transform 7 5 env33317 = env33318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env33317 == env33318) = true)

theorem identity33318 : scanCanonicalize (H12AffineFastState.compose env33318 (packedSelected [2,4,9,11,13,16,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 229) := by decide +kernel

theorem selectedBound33318 : packedSelected [2,4,9,11,13,16,17,18] rootPS < 2^1333 := by decide +kernel

def env33319 : List Nat := [2,4,8,1,32,64,128,5,512,68,229,576,521,65,576,716,238,589,517,577,577,649,238,717,193,750,42,175,65,618,516,512,4,175,1,65]

theorem envBound33319 : H12AffineFastState.Bounded env33319 := by
  intro p hp
  have h : env33319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33318_33319 : H12AffineEnvironment.transform 10 229 env33318 = env33319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 229 env33318 == env33319) = true)

theorem identity33319 : scanCanonicalize (H12AffineFastState.compose env33319 (packedSelected [1,13,15] rootPS)) = affineNative (2^(8+1) ^^^ 162) := by decide +kernel

theorem selectedBound33319 : packedSelected [1,13,15] rootPS < 2^1333 := by decide +kernel

def env33320 : List Nat := [2,4,8,1,32,64,128,5,162,68,229,226,171,65,226,110,238,239,167,227,227,43,238,111,193,76,42,175,65,200,166,162,4,175,1,65]

theorem envBound33320 : H12AffineFastState.Bounded env33320 := by
  intro p hp
  have h : env33320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33319_33320 : H12AffineEnvironment.transform 8 162 env33319 = env33320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 162 env33319 == env33320) = true)

theorem identity33320 : scanCanonicalize (H12AffineFastState.compose env33320 (packedSelected [0,1,3,4,5,7,9,11] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound33320 : packedSelected [0,1,3,4,5,7,9,11] rootPS < 2^1333 := by decide +kernel

def env33321 : List Nat := [2,4,8,1,32,64,35,5,1,68,70,65,8,65,65,110,77,76,4,64,64,43,77,111,98,76,42,12,65,107,5,1,4,12,1,65]

theorem envBound33321 : H12AffineFastState.Bounded env33321 := by
  intro p hp
  have h : env33321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33320_33321 : H12AffineEnvironment.transform 6 35 env33320 = env33321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env33320 == env33321) = true)

def env33322 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,836,797,64,576,65536,66083,65665,516,577,837,649,66082,65536,193,65831,302,66163,64,67651,784,788,257,66146,17,341]

theorem envBound33322 : H12AffineFastState.Bounded env33322 := by
  intro p hp
  have h : env33322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33304_33322 : H12AffineEnvironment.transform 9 337 env33304 = env33322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 337 env33304 == env33322) = true)

theorem identity33322 : scanCanonicalize (H12AffineFastState.compose env33322 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 156) := by decide +kernel

theorem selectedBound33322 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env33323 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,836,797,64,576,156,703,29,516,577,837,649,702,156,193,443,302,751,64,2271,784,788,257,766,17,341]

theorem envBound33323 : H12AffineFastState.Bounded env33323 := by
  intro p hp
  have h : env33323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33322_33323 : H12AffineEnvironment.transform 15 156 env33322 = env33323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 156 env33322 == env33323) = true)

def env33324 : List Nat := [2,4,8,16,32,64,128,256,324,337,2048,0,89,64,260,156,507,29,320,261,1,461,506,156,193,443,302,427,64,2271,84,80,257,442,17,341]

theorem envBound33324 : H12AffineFastState.Bounded env33324 := by
  intro p hp
  have h : env33324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33323_33324 : H12AffineEnvironment.transform 8 324 env33323 = env33324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 324 env33323 == env33324) = true)

theorem identity33324 : scanCanonicalize (H12AffineFastState.compose env33324 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound33324 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env33325 : List Nat := [2,4,8,16,32,64,128,4,64,85,2048,0,89,64,0,156,255,29,68,1,1,201,254,156,193,191,42,175,64,2271,84,80,5,190,17,81]

theorem envBound33325 : H12AffineFastState.Bounded env33325 := by
  intro p hp
  have h : env33325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33324_33325 : H12AffineEnvironment.transform 7 4 env33324 = env33325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env33324 == env33325) = true)

theorem identity33325 : scanCanonicalize (H12AffineFastState.compose env33325 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(6+1) ^^^ 47) := by decide +kernel

theorem selectedBound33325 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env33326 : List Nat := [2,4,8,16,32,64,47,4,64,85,2048,0,89,64,0,51,80,29,68,1,1,102,81,51,110,16,42,0,64,2160,84,80,5,17,17,81]

theorem envBound33326 : H12AffineFastState.Bounded env33326 := by
  intro p hp
  have h : env33326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33325_33326 : H12AffineEnvironment.transform 6 47 env33325 = env33326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 47 env33325 == env33326) = true)

theorem identity33326 : scanCanonicalize (H12AffineFastState.compose env33326 (packedSelected [0,1,7,8,10,11,12,15] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound33326 : packedSelected [0,1,7,8,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env33327 : List Nat := [2,3,8,16,32,64,40,3,64,82,2048,0,89,64,0,51,80,26,67,1,1,97,81,51,105,16,42,0,64,2160,83,80,2,17,17,81]

theorem envBound33327 : H12AffineFastState.Bounded env33327 := by
  intro p hp
  have h : env33327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33326_33327 : H12AffineEnvironment.transform 1 3 env33326 = env33327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env33326 == env33327) = true)

theorem identity33327 : scanCanonicalize (H12AffineFastState.compose env33327 (packedSelected [0,4,7,9,10] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound33327 : packedSelected [0,4,7,9,10] rootPS < 2^1333 := by decide +kernel

def env33328 : List Nat := [2,3,8,16,32,64,40,3,64,82,17,0,89,64,0,51,80,26,67,1,1,97,81,51,105,16,42,0,64,97,83,80,2,17,17,81]

theorem envBound33328 : H12AffineFastState.Bounded env33328 := by
  intro p hp
  have h : env33328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33327_33328 : H12AffineEnvironment.transform 10 17 env33327 = env33328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env33327 == env33328) = true)

theorem identity33328 : scanCanonicalize (H12AffineFastState.compose env33328 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound33328 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env33329 : List Nat := [2,3,8,16,16,64,24,3,64,82,17,0,89,64,0,3,80,26,67,1,1,81,81,3,89,16,26,0,64,81,83,80,2,17,17,81]

theorem envBound33329 : H12AffineFastState.Bounded env33329 := by
  intro p hp
  have h : env33329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33328_33329 : H12AffineEnvironment.transform 4 16 env33328 = env33329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env33328 == env33329) = true)

theorem identity33329 : scanCanonicalize (H12AffineFastState.compose env33329 (packedSelected [0,2,3,4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound33329 : packedSelected [0,2,3,4] rootPS < 2^1333 := by decide +kernel

def env33330 : List Nat := [2,3,8,16,16,17,24,3,17,3,17,0,8,17,0,3,1,26,18,1,1,0,0,3,8,16,26,0,17,0,2,1,2,17,17,0]

theorem envBound33330 : H12AffineFastState.Bounded env33330 := by
  intro p hp
  have h : env33330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33329_33330 : H12AffineEnvironment.transform 5 17 env33329 = env33330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env33329 == env33330) = true)

theorem identity33330 : scanCanonicalize (H12AffineFastState.compose env33330 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound33330 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33331 : List Nat := [2,3,8,11,11,10,3,3,10,3,10,0,8,10,0,3,1,1,9,1,1,0,0,3,8,11,1,0,10,0,2,1,2,10,10,0]

theorem envBound33331 : H12AffineFastState.Bounded env33331 := by
  intro p hp
  have h : env33331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33330_33331 : H12AffineEnvironment.transform 3 11 env33330 = env33331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env33330 == env33331) = true)

theorem identity33331 : scanCanonicalize (H12AffineFastState.compose env33331 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound33331 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env33332 : List Nat := [2,3,3,0,0,1,3,3,1,3,1,0,3,1,0,3,1,1,2,1,1,0,0,3,3,0,1,0,1,0,2,1,2,1,1,0]

theorem envBound33332 : H12AffineFastState.Bounded env33332 := by
  intro p hp
  have h : env33332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33331_33332 : H12AffineEnvironment.transform 2 3 env33331 = env33332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env33331 == env33332) = true)

theorem identity33332 : scanCanonicalize (H12AffineFastState.compose env33332 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound33332 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33333 : List Nat := [1,0,0,0,0,1,0,0,1,0,1,0,0,1,0,0,1,1,1,1,1,0,0,0,0,0,1,0,1,0,1,1,1,1,1,0]

theorem envBound33333 : H12AffineFastState.Bounded env33333 := by
  intro p hp
  have h : env33333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33332_33333 : H12AffineEnvironment.transform 0 1 env33332 = env33333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env33332 == env33333) = true)

def env33334 : List Nat := [2,4,8,16,32,64,128,256,325,337,2048,1,88,64,261,156,506,29,321,260,0,460,507,156,193,443,302,426,64,2271,85,81,257,443,17,341]

theorem envBound33334 : H12AffineFastState.Bounded env33334 := by
  intro p hp
  have h : env33334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33323_33334 : H12AffineEnvironment.transform 8 325 env33323 = env33334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 325 env33323 == env33334) = true)

theorem identity33334 : scanCanonicalize (H12AffineFastState.compose env33334 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound33334 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env33335 : List Nat := [2,4,8,16,32,64,128,20,81,69,2048,1,88,64,17,156,238,29,85,16,0,216,239,156,193,175,58,190,64,2271,85,81,21,175,17,65]

theorem envBound33335 : H12AffineFastState.Bounded env33335 := by
  intro p hp
  have h : env33335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33334_33335 : H12AffineEnvironment.transform 7 20 env33334 = env33335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env33334 == env33335) = true)

theorem identity33335 : scanCanonicalize (H12AffineFastState.compose env33335 (packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS)) = affineNative (2^(10+1) ^^^ 248) := by decide +kernel

theorem selectedBound33335 : packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS < 2^1333 := by decide +kernel

def env33336 : List Nat := [2,4,8,16,32,64,128,20,81,69,248,1,88,64,17,156,238,29,85,16,0,216,239,156,193,175,58,190,64,39,85,81,21,175,17,65]

theorem envBound33336 : H12AffineFastState.Bounded env33336 := by
  intro p hp
  have h : env33336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33335_33336 : H12AffineEnvironment.transform 10 248 env33335 = env33336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 248 env33335 == env33336) = true)

theorem identity33336 : scanCanonicalize (H12AffineFastState.compose env33336 (packedSelected [8,13] rootPS)) = affineNative (2^(5+1) ^^^ 55) := by decide +kernel

theorem selectedBound33336 : packedSelected [8,13] rootPS < 2^1333 := by decide +kernel

def env33337 : List Nat := [2,4,8,16,32,55,128,20,38,50,143,1,47,55,17,156,153,29,34,16,0,175,152,156,182,175,58,190,55,39,34,38,21,175,17,54]

theorem envBound33337 : H12AffineFastState.Bounded env33337 := by
  intro p hp
  have h : env33337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33336_33337 : H12AffineEnvironment.transform 5 55 env33336 = env33337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 55 env33336 == env33337) = true)

theorem identity33337 : scanCanonicalize (H12AffineFastState.compose env33337 (packedSelected [0,7,10,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 47) := by decide +kernel

theorem selectedBound33337 : packedSelected [0,7,10,11,12] rootPS < 2^1333 := by decide +kernel

def env33338 : List Nat := [2,4,8,16,32,55,47,20,38,50,32,1,47,55,17,51,54,29,34,16,0,0,55,51,25,0,58,17,55,39,34,38,21,0,17,54]

theorem envBound33338 : H12AffineFastState.Bounded env33338 := by
  intro p hp
  have h : env33338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33337_33338 : H12AffineEnvironment.transform 6 47 env33337 = env33338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 47 env33337 == env33338) = true)

theorem identity33338 : scanCanonicalize (H12AffineFastState.compose env33338 (packedSelected [3,5,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound33338 : packedSelected [3,5,8] rootPS < 2^1333 := by decide +kernel

def env33339 : List Nat := [2,4,8,16,1,22,14,20,7,19,1,1,14,22,17,18,23,29,3,16,0,0,22,18,25,0,27,17,22,6,3,7,21,0,17,23]

theorem envBound33339 : H12AffineFastState.Bounded env33339 := by
  intro p hp
  have h : env33339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33338_33339 : H12AffineEnvironment.transform 4 1 env33338 = env33339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env33338 == env33339) = true)

theorem identity33339 : scanCanonicalize (H12AffineFastState.compose env33339 (packedSelected [0,2,4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound33339 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env33340 : List Nat := [2,4,8,0,1,6,14,4,7,3,1,1,14,6,1,2,7,13,3,0,0,0,6,2,9,0,11,1,6,6,3,7,5,0,1,7]

theorem envBound33340 : H12AffineFastState.Bounded env33340 := by
  intro p hp
  have h : env33340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33339_33340 : H12AffineEnvironment.transform 3 0 env33339 = env33340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env33339 == env33340) = true)

theorem identity33340 : scanCanonicalize (H12AffineFastState.compose env33340 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound33340 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33341 : List Nat := [2,4,5,0,1,6,3,4,7,3,1,1,3,6,1,2,7,0,3,0,0,0,6,2,4,0,6,1,6,6,3,7,5,0,1,7]

theorem envBound33341 : H12AffineFastState.Bounded env33341 := by
  intro p hp
  have h : env33341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33340_33341 : H12AffineEnvironment.transform 2 5 env33340 = env33341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env33340 == env33341) = true)

def env33342 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147521,16777216,533641,672785,17245633,148801,545088,96346,16876545,16949355,257,676881,1345,525824]

theorem envBound33342 : H12AffineFastState.Bounded env33342 := by
  intro p hp
  have h : env33342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32677_33342 : H12AffineEnvironment.transform 26 17245633 env32677 = env33342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245633 env32677 == env33342) = true)

theorem identity33342 : scanCanonicalize (H12AffineFastState.compose env33342 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(18+1) ^^^ 95614) := by decide +kernel

theorem selectedBound33342 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env33343 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95614,32769,4097,61648,147521,16777216,86519,209263,17245633,148801,74814,96346,16876545,16949355,257,205167,1345,95102]

theorem envBound33343 : H12AffineFastState.Bounded env33343 := by
  intro p hp
  have h : env33343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33342_33343 : H12AffineEnvironment.transform 18 95614 env33342 = env33343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 95614 env33342 == env33343) = true)

def env33344 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95614,32769,4097,61648,147521,284032,86519,209263,225345,148801,74814,96346,381313,456171,257,205167,1345,95102]

theorem envBound33344 : H12AffineFastState.Bounded env33344 := by
  intro p hp
  have h : env33344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33343_33344 : H12AffineEnvironment.transform 23 284032 env33343 = env33344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 284032 env33343 == env33344) = true)

def env33345 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16464,262144,95614,32769,4097,61648,17,284032,86519,94527,77841,1297,74814,96346,381313,308667,257,90431,1345,95102]

theorem envBound33345 : H12AffineFastState.Bounded env33345 := by
  intro p hp
  have h : env33345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33344_33345 : H12AffineEnvironment.transform 16 16464 env33344 = env33345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16464 env33344 == env33345) = true)

def env33346 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1344,262144,77934,32769,4097,46528,17,266384,70887,78895,77841,1297,74814,81226,365713,308667,257,74799,1345,79470]

theorem envBound33346 : H12AffineFastState.Bounded env33346 := by
  intro p hp
  have h : env33346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33345_33346 : H12AffineEnvironment.transform 13 1296 env33345 = env33346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env33345 == env33346) = true)

theorem identity33346 : scanCanonicalize (H12AffineFastState.compose env33346 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound33346 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env33347 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1344,262144,77934,13341,4097,476,17,266384,70887,78895,77841,1297,74814,81226,336013,262567,257,74799,1345,79470]

theorem envBound33347 : H12AffineFastState.Bounded env33347 := by
  intro p hp
  have h : env33347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33346_33347 : H12AffineEnvironment.transform 14 13340 env33346 = env33347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env33346 == env33347) = true)

def env33348 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1344,65664,77934,13341,4097,476,17,69648,70887,78895,77841,1297,74814,81226,8205,65831,257,74799,1345,79470]

theorem envBound33348 : H12AffineFastState.Bounded env33348 := by
  intro p hp
  have h : env33348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33347_33348 : H12AffineEnvironment.transform 17 65664 env33347 = env33348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env33347 == env33348) = true)

theorem identity33348 : scanCanonicalize (H12AffineFastState.compose env33348 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5159) := by decide +kernel

theorem selectedBound33348 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env33349 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,5159,1344,5287,9289,13341,4097,476,17,1079,192,8200,9270,1297,12313,10605,8205,5376,257,12296,1345,8777]

theorem envBound33349 : H12AffineFastState.Bounded env33349 := by
  intro p hp
  have h : env33349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33348_33349 : H12AffineEnvironment.transform 15 5159 env33348 = env33349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5159 env33348 == env33349) = true)

def env33350 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,1296,13340,5159,1296,5287,9241,13341,4097,396,17,1079,144,8200,9270,1297,12313,10557,8205,5376,257,12296,1297,8729]

theorem envBound33350 : H12AffineFastState.Bounded env33350 := by
  intro p hp
  have h : env33350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33349_33350 : H12AffineEnvironment.transform 5 16 env33349 = env33350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33349 == env33350) = true)

theorem identity33350 : scanCanonicalize (H12AffineFastState.compose env33350 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound33350 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env33351 : List Nat := [2,4,8,16,32,16,128,256,512,5,2048,4096,8192,277,12313,4130,277,4258,8220,12312,4097,396,17,50,144,8200,8243,276,12313,10557,8205,4357,257,12296,276,8729]

theorem envBound33351 : H12AffineFastState.Bounded env33351 := by
  intro p hp
  have h : env33351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33350_33351 : H12AffineEnvironment.transform 9 5 env33350 = env33351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env33350 == env33351) = true)

theorem identity33351 : scanCanonicalize (H12AffineFastState.compose env33351 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound33351 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env33352 : List Nat := [2,4,8,16,32,16,128,256,512,5,2048,4096,25,277,4096,4130,277,4258,5,4097,4097,396,17,50,144,17,42,276,4096,2340,20,4357,257,4113,276,512]

theorem envBound33352 : H12AffineFastState.Bounded env33352 := by
  intro p hp
  have h : env33352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33351_33352 : H12AffineEnvironment.transform 12 25 env33351 = env33352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env33351 == env33352) = true)

theorem identity33352 : scanCanonicalize (H12AffineFastState.compose env33352 (packedSelected [2,11,18] rootPS)) = affineNative (2^(10+1) ^^^ 782) := by decide +kernel

theorem selectedBound33352 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env33353 : List Nat := [2,4,8,16,32,16,128,256,512,5,782,4096,25,277,4096,4130,277,4258,5,4097,4097,396,17,50,144,17,42,276,4096,554,20,4357,257,4113,276,512]

theorem envBound33353 : H12AffineFastState.Bounded env33353 := by
  intro p hp
  have h : env33353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33352_33353 : H12AffineEnvironment.transform 10 782 env33352 = env33353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 782 env33352 == env33353) = true)

theorem identity33353 : scanCanonicalize (H12AffineFastState.compose env33353 (packedSelected [1,2,5,10,13] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound33353 : packedSelected [1,2,5,10,13] rootPS < 2^1333 := by decide +kernel

def env33354 : List Nat := [2,4,8,16,32,16,128,256,26,5,276,4096,25,277,4096,4130,277,4258,5,4097,4097,396,17,50,144,17,42,276,4096,48,20,4357,257,4113,276,26]

theorem envBound33354 : H12AffineFastState.Bounded env33354 := by
  intro p hp
  have h : env33354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33353_33354 : H12AffineEnvironment.transform 8 26 env33353 = env33354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env33353 == env33354) = true)

theorem identity33354 : scanCanonicalize (H12AffineFastState.compose env33354 (packedSelected [0,1,2,3,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 163) := by decide +kernel

theorem selectedBound33354 : packedSelected [0,1,2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env33355 : List Nat := [2,4,8,16,32,16,128,256,26,5,276,163,25,277,163,129,277,1,5,162,162,396,17,50,144,17,42,276,163,48,20,422,257,178,276,26]

theorem envBound33355 : H12AffineFastState.Bounded env33355 := by
  intro p hp
  have h : env33355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33354_33355 : H12AffineEnvironment.transform 11 163 env33354 = env33355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 163 env33354 == env33355) = true)

theorem identity33355 : scanCanonicalize (H12AffineFastState.compose env33355 (packedSelected [0,2,3,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound33355 : packedSelected [0,2,3,7,8] rootPS < 2^1333 := by decide +kernel

def env33356 : List Nat := [2,4,8,16,32,16,18,256,26,5,276,49,25,277,49,19,277,1,5,48,48,286,17,50,2,17,42,276,49,48,20,308,257,32,276,26]

theorem envBound33356 : H12AffineFastState.Bounded env33356 := by
  intro p hp
  have h : env33356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33355_33356 : H12AffineEnvironment.transform 6 18 env33355 = env33356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env33355 == env33356) = true)

theorem identity33356 : scanCanonicalize (H12AffineFastState.compose env33356 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound33356 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env33357 : List Nat := [2,4,8,16,32,16,18,37,26,5,49,49,25,48,49,19,48,1,5,48,48,59,17,50,2,17,42,49,49,48,20,17,36,32,49,26]

theorem envBound33357 : H12AffineFastState.Bounded env33357 := by
  intro p hp
  have h : env33357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33356_33357 : H12AffineEnvironment.transform 7 37 env33356 = env33357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env33356 == env33357) = true)

theorem identity33357 : scanCanonicalize (H12AffineFastState.compose env33357 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound33357 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env33358 : List Nat := [2,4,8,16,11,16,18,14,26,5,26,26,25,27,26,19,27,1,5,27,27,16,17,25,2,17,1,26,26,27,20,17,15,11,26,26]

theorem envBound33358 : H12AffineFastState.Bounded env33358 := by
  intro p hp
  have h : env33358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33357_33358 : H12AffineEnvironment.transform 4 11 env33357 = env33358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env33357 == env33358) = true)

theorem identity33358 : scanCanonicalize (H12AffineFastState.compose env33358 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound33358 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33359 : List Nat := [2,4,8,11,11,11,9,14,1,5,1,1,2,0,1,8,0,1,5,0,0,11,10,2,2,10,1,1,1,0,15,10,15,11,1,1]

theorem envBound33359 : H12AffineFastState.Bounded env33359 := by
  intro p hp
  have h : env33359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33358_33359 : H12AffineEnvironment.transform 3 11 env33358 = env33359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env33358 == env33359) = true)

theorem identity33359 : scanCanonicalize (H12AffineFastState.compose env33359 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound33359 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33360 : List Nat := [2,3,8,11,11,11,9,9,1,2,1,1,2,0,1,8,0,1,2,0,0,11,10,2,2,10,1,1,1,0,8,10,8,11,1,1]

theorem envBound33360 : H12AffineFastState.Bounded env33360 := by
  intro p hp
  have h : env33360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33359_33360 : H12AffineEnvironment.transform 1 3 env33359 = env33360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env33359 == env33360) = true)

def env33361 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,1296,13340,5159,1297,5287,9240,13341,4097,397,17,1079,145,8200,9270,1297,12313,10556,8205,5376,257,12296,1296,8728]

theorem envBound33361 : H12AffineFastState.Bounded env33361 := by
  intro p hp
  have h : env33361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33349_33361 : H12AffineEnvironment.transform 5 17 env33349 = env33361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env33349 == env33361) = true)

theorem identity33361 : scanCanonicalize (H12AffineFastState.compose env33361 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound33361 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env33362 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,1052,1296,4096,5159,1297,5287,4,4097,4097,397,17,1079,145,1044,42,1297,5125,3360,1041,5376,257,5140,1296,1540]

theorem envBound33362 : H12AffineFastState.Bounded env33362 := by
  intro p hp
  have h : env33362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33361_33362 : H12AffineEnvironment.transform 12 1052 env33361 = env33362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env33361 == env33362) = true)

theorem identity33362 : scanCanonicalize (H12AffineFastState.compose env33362 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound33362 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env33363 : List Nat := [2,4,8,16,32,17,128,256,512,5,2048,4096,25,277,4096,4130,276,4258,4,4097,4097,397,17,50,145,17,42,276,4096,2341,20,4357,257,4113,277,513]

theorem envBound33363 : H12AffineFastState.Bounded env33363 := by
  intro p hp
  have h : env33363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33362_33363 : H12AffineEnvironment.transform 9 5 env33362 = env33363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env33362 == env33363) = true)

theorem identity33363 : scanCanonicalize (H12AffineFastState.compose env33363 (packedSelected [2,11,18] rootPS)) = affineNative (2^(8+1) ^^^ 413) := by decide +kernel

theorem selectedBound33363 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env33364 : List Nat := [2,4,8,16,32,17,128,256,413,5,2048,4096,25,277,4096,4130,276,4258,4,4097,4097,397,17,50,145,17,42,276,4096,2341,20,4357,257,4113,277,412]

theorem envBound33364 : H12AffineFastState.Bounded env33364 := by
  intro p hp
  have h : env33364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33363_33364 : H12AffineEnvironment.transform 8 413 env33363 = env33364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 413 env33363 == env33364) = true)

theorem identity33364 : scanCanonicalize (H12AffineFastState.compose env33364 (packedSelected [0,1,3,7,11,13] rootPS)) = affineNative (2^(11+1) ^^^ 2194) := by decide +kernel

theorem selectedBound33364 : packedSelected [0,1,3,7,11,13] rootPS < 2^1333 := by decide +kernel

def env33365 : List Nat := [2,4,8,16,32,17,128,256,413,5,2048,2194,25,277,2194,2224,276,2096,4,2195,2195,397,17,50,145,17,42,276,2194,2341,20,2455,257,2179,277,412]

theorem envBound33365 : H12AffineFastState.Bounded env33365 := by
  intro p hp
  have h : env33365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33364_33365 : H12AffineEnvironment.transform 11 2194 env33364 = env33365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2194 env33364 == env33365) = true)

theorem identity33365 : scanCanonicalize (H12AffineFastState.compose env33365 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound33365 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env33366 : List Nat := [2,4,8,16,32,17,128,21,136,5,2048,2194,25,0,2194,2224,1,2096,4,2195,2195,152,17,50,145,17,42,1,2194,2096,20,2178,20,2179,0,137]

theorem envBound33366 : H12AffineFastState.Bounded env33366 := by
  intro p hp
  have h : env33366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33365_33366 : H12AffineEnvironment.transform 7 21 env33365 = env33366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env33365 == env33366) = true)

theorem identity33366 : scanCanonicalize (H12AffineFastState.compose env33366 (packedSelected [2,5] rootPS)) = affineNative (2^(6+1) ^^^ 20) := by decide +kernel

theorem selectedBound33366 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env33367 : List Nat := [2,4,8,16,32,17,20,21,28,5,2048,2054,25,0,2054,2084,1,2096,4,2055,2055,12,17,50,5,17,42,1,2054,2096,20,2070,20,2071,0,29]

theorem envBound33367 : H12AffineFastState.Bounded env33367 := by
  intro p hp
  have h : env33367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33366_33367 : H12AffineEnvironment.transform 6 20 env33366 = env33367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 20 env33366 == env33367) = true)

theorem identity33367 : scanCanonicalize (H12AffineFastState.compose env33367 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound33367 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env33368 : List Nat := [2,4,8,12,32,13,8,9,0,5,2048,2054,5,0,2054,2084,1,2092,4,2055,2055,12,13,46,5,13,42,1,2054,2092,8,2058,8,2059,0,1]

theorem envBound33368 : H12AffineFastState.Bounded env33368 := by
  intro p hp
  have h : env33368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33367_33368 : H12AffineEnvironment.transform 3 12 env33367 = env33368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env33367 == env33368) = true)

theorem identity33368 : scanCanonicalize (H12AffineFastState.compose env33368 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound33368 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env33369 : List Nat := [2,4,8,12,11,13,8,9,0,5,2048,2054,5,0,2054,2063,1,2055,4,2055,2055,12,13,5,5,13,1,1,2054,2055,8,2058,8,2059,0,1]

theorem envBound33369 : H12AffineFastState.Bounded env33369 := by
  intro p hp
  have h : env33369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33368_33369 : H12AffineEnvironment.transform 4 11 env33368 = env33369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env33368 == env33369) = true)

theorem identity33369 : scanCanonicalize (H12AffineFastState.compose env33369 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound33369 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33370 : List Nat := [2,4,8,12,11,13,8,9,0,5,1,7,5,0,7,14,1,6,4,6,6,12,13,5,5,13,1,1,7,6,8,11,8,10,0,1]

theorem envBound33370 : H12AffineFastState.Bounded env33370 := by
  intro p hp
  have h : env33370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33369_33370 : H12AffineEnvironment.transform 10 1 env33369 = env33370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env33369 == env33370) = true)

theorem identity33370 : scanCanonicalize (H12AffineFastState.compose env33370 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound33370 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33371 : List Nat := [2,4,6,2,5,3,6,7,0,5,1,7,5,0,7,0,1,6,4,6,6,2,3,5,5,3,1,1,7,6,6,5,6,4,0,1]

theorem envBound33371 : H12AffineFastState.Bounded env33371 := by
  intro p hp
  have h : env33371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33370_33371 : H12AffineEnvironment.transform 2 6 env33370 = env33371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env33370 == env33371) = true)

theorem identity33371 : scanCanonicalize (H12AffineFastState.compose env33371 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound33371 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env33372 : List Nat := [0,4,4,0,5,1,4,5,0,5,1,5,5,0,5,0,1,4,4,4,4,0,1,5,5,1,1,1,5,4,4,5,4,4,0,1]

theorem envBound33372 : H12AffineFastState.Bounded env33372 := by
  intro p hp
  have h : env33372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33371_33372 : H12AffineEnvironment.transform 0 0 env33371 = env33372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env33371 == env33372) = true)

theorem identity33372 : scanCanonicalize (H12AffineFastState.compose env33372 (packedSelected [10] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound33372 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env33373 : List Nat := [0,1,1,0,0,1,1,0,0,0,1,0,0,0,0,0,1,1,1,1,1,0,1,0,0,1,1,1,0,1,1,0,1,1,0,1]

theorem envBound33373 : H12AffineFastState.Bounded env33373 := by
  intro p hp
  have h : env33373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33372_33373 : H12AffineEnvironment.transform 1 1 env33372 = env33373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env33372 == env33373) = true)

def env33374 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1344,65665,77934,13341,4097,476,17,69649,70887,78895,77841,1297,74814,81226,8204,65830,257,74799,1345,79470]

theorem envBound33374 : H12AffineFastState.Bounded env33374 := by
  intro p hp
  have h : env33374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33347_33374 : H12AffineEnvironment.transform 17 65665 env33347 = env33374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env33347 == env33374) = true)

theorem identity33374 : scanCanonicalize (H12AffineFastState.compose env33374 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 358) := by decide +kernel

theorem selectedBound33374 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env33375 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,358,1344,487,12552,13341,4097,476,17,4471,5505,13641,12663,1297,9560,15404,8204,64,257,9545,1345,14088]

theorem envBound33375 : H12AffineFastState.Bounded env33375 := by
  intro p hp
  have h : env33375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33374_33375 : H12AffineEnvironment.transform 15 358 env33374 = env33375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 358 env33374 == env33375) = true)

def env33376 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,1296,13340,310,1296,439,12552,13341,4097,396,17,4391,5505,13593,12583,1297,9480,15404,8204,16,257,9497,1297,14088]

theorem envBound33376 : H12AffineFastState.Bounded env33376 := by
  intro p hp
  have h : env33376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33375_33376 : H12AffineEnvironment.transform 5 16 env33375 = env33376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33375 == env33376) = true)

theorem identity33376 : scanCanonicalize (H12AffineFastState.compose env33376 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound33376 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env33377 : List Nat := [2,4,8,16,32,16,128,256,512,5,2048,4096,8192,277,12313,310,277,439,12552,12312,4097,396,17,4391,4484,12572,12583,276,8461,14377,8204,16,257,8476,276,13069]

theorem envBound33377 : H12AffineFastState.Bounded env33377 := by
  intro p hp
  have h : env33377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33376_33377 : H12AffineEnvironment.transform 9 5 env33376 = env33377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env33376 == env33377) = true)

theorem identity33377 : scanCanonicalize (H12AffineFastState.compose env33377 (packedSelected [2,3,10,13,21,23,24,26,32] rootPS)) = affineNative (2^(12+1) ^^^ 4996) := by decide +kernel

theorem selectedBound33377 : packedSelected [2,3,10,13,21,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env33378 : List Nat := [2,4,8,16,32,16,128,256,512,5,2048,4096,4996,277,925,310,277,439,652,924,4097,396,17,4391,4484,664,675,276,4745,2989,5000,16,257,4760,276,137]

theorem envBound33378 : H12AffineFastState.Bounded env33378 := by
  intro p hp
  have h : env33378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33377_33378 : H12AffineEnvironment.transform 12 4996 env33377 = env33378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4996 env33377 == env33378) = true)

theorem identity33378 : scanCanonicalize (H12AffineFastState.compose env33378 (packedSelected [0,1,3,4,7,8,9,10,13,18,19,23,26,28] rootPS)) = affineNative (2^(11+1) ^^^ 2723) := by decide +kernel

theorem selectedBound33378 : packedSelected [0,1,3,4,7,8,9,10,13,18,19,23,26,28] rootPS < 2^1333 := by decide +kernel

def env33379 : List Nat := [2,4,8,16,32,16,128,256,512,5,2048,2723,2343,277,925,310,277,439,652,924,2722,396,17,2948,2855,664,675,276,2090,2989,2347,16,257,2107,276,137]

theorem envBound33379 : H12AffineFastState.Bounded env33379 := by
  intro p hp
  have h : env33379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33378_33379 : H12AffineEnvironment.transform 11 2723 env33378 = env33379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2723 env33378 == env33379) = true)

theorem identity33379 : scanCanonicalize (H12AffineFastState.compose env33379 (packedSelected [1,2,3,5,8,10,11,18,19] rootPS)) = affineNative (2^(10+1) ^^^ 782) := by decide +kernel

theorem selectedBound33379 : packedSelected [1,2,3,5,8,10,11,18,19] rootPS < 2^1333 := by decide +kernel

def env33380 : List Nat := [2,4,8,16,32,16,128,256,512,5,782,429,553,277,925,310,277,439,652,924,428,396,17,138,41,664,675,276,804,163,549,16,257,821,276,137]

theorem envBound33380 : H12AffineFastState.Bounded env33380 := by
  intro p hp
  have h : env33380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33379_33380 : H12AffineEnvironment.transform 10 782 env33379 = env33380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 782 env33379 == env33380) = true)

theorem identity33380 : scanCanonicalize (H12AffineFastState.compose env33380 (packedSelected [3,4,5,7,10,12] rootPS)) = affineNative (2^(8+1) ^^^ 413) := by decide +kernel

theorem selectedBound33380 : packedSelected [3,4,5,7,10,12] rootPS < 2^1333 := by decide +kernel

def env33381 : List Nat := [2,4,8,16,32,16,128,256,413,5,147,429,436,277,0,310,277,439,273,1,428,396,17,138,41,261,318,276,185,163,440,16,257,168,276,137]

theorem envBound33381 : H12AffineFastState.Bounded env33381 := by
  intro p hp
  have h : env33381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33380_33381 : H12AffineEnvironment.transform 8 413 env33380 = env33381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 413 env33380 == env33381) = true)

theorem identity33381 : scanCanonicalize (H12AffineFastState.compose env33381 (packedSelected [2,4,5,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound33381 : packedSelected [2,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env33382 : List Nat := [2,4,8,16,10,16,128,256,413,5,147,391,414,277,0,284,277,413,273,1,390,396,17,138,3,261,276,276,147,137,402,16,257,130,276,137]

theorem envBound33382 : H12AffineFastState.Bounded env33382 := by
  intro p hp
  have h : env33382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33381_33382 : H12AffineEnvironment.transform 4 10 env33381 = env33382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env33381 == env33382) = true)

theorem identity33382 : scanCanonicalize (H12AffineFastState.compose env33382 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound33382 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env33383 : List Nat := [2,4,8,16,10,16,128,20,137,5,147,147,138,1,0,8,1,137,5,1,146,152,17,138,3,17,0,0,147,137,134,16,21,130,0,137]

theorem envBound33383 : H12AffineFastState.Bounded env33383 := by
  intro p hp
  have h : env33383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33382_33383 : H12AffineEnvironment.transform 7 20 env33382 = env33383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env33382 == env33383) = true)

theorem identity33383 : scanCanonicalize (H12AffineFastState.compose env33383 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound33383 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env33384 : List Nat := [2,4,8,11,10,11,128,15,137,5,136,136,138,1,0,8,1,137,5,1,137,131,10,138,3,10,0,0,136,137,134,11,14,130,0,137]

theorem envBound33384 : H12AffineFastState.Bounded env33384 := by
  intro p hp
  have h : env33384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33383_33384 : H12AffineEnvironment.transform 3 11 env33383 = env33384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env33383 == env33384) = true)

def env33385 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,1296,13340,311,1297,438,12552,13341,4097,397,17,4390,5505,13592,12582,1297,9481,15404,8204,17,257,9496,1296,14088]

theorem envBound33385 : H12AffineFastState.Bounded env33385 := by
  intro p hp
  have h : env33385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33375_33385 : H12AffineEnvironment.transform 5 17 env33375 = env33385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env33375 == env33385) = true)

theorem identity33385 : scanCanonicalize (H12AffineFastState.compose env33385 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 4364) := by decide +kernel

theorem selectedBound33385 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env33386 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,4364,1296,1296,311,1297,438,4,1297,4097,397,17,4390,5505,1044,42,1297,5125,3360,4352,17,257,5140,1296,1540]

theorem envBound33386 : H12AffineFastState.Bounded env33386 := by
  intro p hp
  have h : env33386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33385_33386 : H12AffineEnvironment.transform 12 4364 env33385 = env33386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4364 env33385 == env33386) = true)

def env33387 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1345,262144,77935,32769,4097,46529,17,266385,70886,78894,77841,1297,74814,81227,365712,308667,257,74798,1345,79471]

theorem envBound33387 : H12AffineFastState.Bounded env33387 := by
  intro p hp
  have h : env33387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33345_33387 : H12AffineEnvironment.transform 13 1297 env33345 = env33387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env33345 == env33387) = true)

theorem identity33387 : scanCanonicalize (H12AffineFastState.compose env33387 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32882) := by decide +kernel

theorem selectedBound33387 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env33388 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,32882,1345,262144,45085,32769,4097,46529,17,266385,38036,46172,45155,1297,42060,48441,267490,308667,257,42076,1345,46621]

theorem envBound33388 : H12AffineFastState.Bounded env33388 := by
  intro p hp
  have h : env33388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33387_33388 : H12AffineEnvironment.transform 15 32882 env33387 = env33388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32882 env33387 == env33388) = true)

def env33389 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32882,1345,262144,42333,32769,1345,41089,17,263633,33236,41244,42275,1297,42060,43129,262562,303355,257,42076,1345,41821]

theorem envBound33389 : H12AffineFastState.Bounded env33389 := by
  intro p hp
  have h : env33389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33388_33389 : H12AffineEnvironment.transform 11 1344 env33388 = env33389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env33388 == env33389) = true)

theorem identity33389 : scanCanonicalize (H12AffineFastState.compose env33389 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 9244) := by decide +kernel

theorem selectedBound33389 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env33390 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,9244,9326,1345,262144,321,9245,1345,1181,17,263633,9672,1280,319,1297,80,3173,262562,263399,257,64,1345,1857]

theorem envBound33390 : H12AffineFastState.Bounded env33390 := by
  intro p hp
  have h : env33390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33389_33390 : H12AffineEnvironment.transform 14 9244 env33389 = env33390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9244 env33389 == env33390) = true)

theorem identity33390 : scanCanonicalize (H12AffineFastState.compose env33390 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound33390 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env33391 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,1,8192,80,8541,8495,0,262144,321,8540,0,476,17,262288,8329,65,319,80,80,2340,262562,262566,257,64,0,512]

theorem envBound33391 : H12AffineFastState.Bounded env33391 := by
  intro p hp
  have h : env33391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33390_33391 : H12AffineEnvironment.transform 9 321 env33390 = env33391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env33390 == env33391) = true)

theorem identity33391 : scanCanonicalize (H12AffineFastState.compose env33391 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound33391 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env33392 : List Nat := [2,4,8,16,32,64,128,20,512,85,2048,1,8192,80,8265,8251,0,262144,85,8264,0,200,17,262288,8329,65,43,80,80,2096,262326,262322,21,64,0,512]

theorem envBound33392 : H12AffineFastState.Bounded env33392 := by
  intro p hp
  have h : env33392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33391_33392 : H12AffineEnvironment.transform 7 20 env33391 = env33392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env33391 == env33392) = true)

theorem identity33392 : scanCanonicalize (H12AffineFastState.compose env33392 (packedSelected [3,5,10] rootPS)) = affineNative (2^(17+1) ^^^ 8755) := by decide +kernel

theorem selectedBound33392 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env33393 : List Nat := [2,4,8,16,32,64,128,20,512,85,2048,1,8192,80,8265,8251,0,8755,85,8264,0,200,17,8867,8329,65,43,80,80,2096,8837,8833,21,64,0,512]

theorem envBound33393 : H12AffineFastState.Bounded env33393 := by
  intro p hp
  have h : env33393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33392_33393 : H12AffineEnvironment.transform 17 8755 env33392 = env33393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8755 env33392 == env33393) = true)

theorem identity33393 : scanCanonicalize (H12AffineFastState.compose env33393 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound33393 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env33394 : List Nat := [2,4,8,16,32,16,128,20,512,5,2048,1,8192,0,8217,8251,0,8755,5,8216,0,152,17,8867,8329,17,43,0,0,2096,8837,8833,21,16,0,512]

theorem envBound33394 : H12AffineFastState.Bounded env33394 := by
  intro p hp
  have h : env33394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33393_33394 : H12AffineEnvironment.transform 5 16 env33393 = env33394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33393 == env33394) = true)

theorem identity33394 : scanCanonicalize (H12AffineFastState.compose env33394 (packedSelected [1,3,13] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound33394 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env33395 : List Nat := [2,4,8,16,32,16,128,20,512,5,43,1,8192,0,8217,8251,0,8755,5,8216,0,152,17,8867,8329,17,43,0,0,27,8837,8833,21,16,0,512]

theorem envBound33395 : H12AffineFastState.Bounded env33395 := by
  intro p hp
  have h : env33395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33394_33395 : H12AffineEnvironment.transform 10 43 env33394 = env33395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env33394 == env33395) = true)

theorem identity33395 : scanCanonicalize (H12AffineFastState.compose env33395 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound33395 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env33396 : List Nat := [2,4,8,16,32,16,56,20,512,5,43,1,8192,0,8217,8251,0,8755,5,8216,0,32,17,8731,8241,17,43,0,0,27,8765,8761,21,16,0,512]

theorem envBound33396 : H12AffineFastState.Bounded env33396 := by
  intro p hp
  have h : env33396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33395_33396 : H12AffineEnvironment.transform 6 56 env33395 = env33396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env33395 == env33396) = true)

theorem identity33396 : scanCanonicalize (H12AffineFastState.compose env33396 (packedSelected [1,2,5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound33396 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env33397 : List Nat := [2,4,8,11,32,11,35,15,512,5,43,1,8192,0,8194,8224,0,8744,5,8195,0,32,10,8704,8234,10,43,0,0,0,8742,8738,14,11,0,512]

theorem envBound33397 : H12AffineFastState.Bounded env33397 := by
  intro p hp
  have h : env33397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33396_33397 : H12AffineEnvironment.transform 3 11 env33396 = env33397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env33396 == env33397) = true)

theorem identity33397 : scanCanonicalize (H12AffineFastState.compose env33397 (packedSelected [0,2,4] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound33397 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env33398 : List Nat := [2,4,8,11,32,11,35,15,512,5,43,1,41,0,43,9,0,513,5,42,0,32,10,553,3,10,43,0,0,0,527,523,14,11,0,512]

theorem envBound33398 : H12AffineFastState.Bounded env33398 := by
  intro p hp
  have h : env33398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33397_33398 : H12AffineEnvironment.transform 12 41 env33397 = env33398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env33397 == env33398) = true)

theorem identity33398 : scanCanonicalize (H12AffineFastState.compose env33398 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound33398 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env33399 : List Nat := [2,4,8,11,32,11,35,15,1,5,43,1,41,0,43,9,0,0,5,42,0,32,10,40,3,10,43,0,0,0,14,10,14,11,0,1]

theorem envBound33399 : H12AffineFastState.Bounded env33399 := by
  intro p hp
  have h : env33399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33398_33399 : H12AffineEnvironment.transform 8 1 env33398 = env33399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env33398 == env33399) = true)

theorem identity33399 : scanCanonicalize (H12AffineFastState.compose env33399 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound33399 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33400 : List Nat := [2,4,8,11,7,11,4,15,1,5,12,1,14,0,12,9,0,0,5,13,0,7,10,15,3,10,12,0,0,0,14,10,14,11,0,1]

theorem envBound33400 : H12AffineFastState.Bounded env33400 := by
  intro p hp
  have h : env33400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33399_33400 : H12AffineEnvironment.transform 4 7 env33399 = env33400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env33399 == env33400) = true)

theorem identity33400 : scanCanonicalize (H12AffineFastState.compose env33400 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound33400 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33401 : List Nat := [2,4,5,6,7,6,4,2,1,5,1,1,3,0,1,4,0,0,5,0,0,7,7,2,3,7,1,0,0,0,3,7,3,6,0,1]

theorem envBound33401 : H12AffineFastState.Bounded env33401 := by
  intro p hp
  have h : env33401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33400_33401 : H12AffineEnvironment.transform 2 5 env33400 = env33401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env33400 == env33401) = true)

def env33402 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32882,1345,262144,42332,32769,1344,41088,17,263632,33237,41245,42274,1297,42060,43128,262563,303354,257,42076,1345,41820]

theorem envBound33402 : H12AffineFastState.Bounded env33402 := by
  intro p hp
  have h : env33402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33388_33402 : H12AffineEnvironment.transform 11 1345 env33388 = env33402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env33388 == env33402) = true)

theorem identity33402 : scanCanonicalize (H12AffineFastState.compose env33402 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 9454) := by decide +kernel

theorem selectedBound33402 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env33403 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32882,1345,9454,42332,32769,1344,41088,17,8510,33237,41245,42274,1297,42060,43128,9549,33812,257,42076,1345,41820]

theorem envBound33403 : H12AffineFastState.Bounded env33403 := by
  intro p hp
  have h : env33403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33402_33403 : H12AffineEnvironment.transform 17 9454 env33402 = env33403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 9454 env33402 == env33403) = true)

theorem identity33403 : scanCanonicalize (H12AffineFastState.compose env33403 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(12+1) ^^^ 3907) := by decide +kernel

theorem selectedBound33403 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env33404 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,3907,1297,32768,32882,1345,2989,35359,32769,1344,36803,17,3709,33237,36446,35425,1297,35599,34619,2574,33812,257,35615,1345,35871]

theorem envBound33404 : H12AffineFastState.Bounded env33404 := by
  intro p hp
  have h : env33404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33403_33404 : H12AffineEnvironment.transform 12 3907 env33403 = env33404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3907 env33403 == env33404) = true)

def env33405 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16465,262144,95614,32769,4097,61648,16,284032,86519,94526,77840,1296,74814,96346,381313,308666,257,90430,1345,95102]

theorem envBound33405 : H12AffineFastState.Bounded env33405 := by
  intro p hp
  have h : env33405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33344_33405 : H12AffineEnvironment.transform 16 16465 env33344 = env33405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16465 env33344 == env33405) = true)

def env33406 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1345,262144,77934,32769,4097,46528,16,266384,70887,78894,77840,1296,74814,81226,365713,308666,257,74798,1345,79470]

theorem envBound33406 : H12AffineFastState.Bounded env33406 := by
  intro p hp
  have h : env33406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33405_33406 : H12AffineEnvironment.transform 13 1296 env33405 = env33406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env33405 == env33406) = true)

theorem identity33406 : scanCanonicalize (H12AffineFastState.compose env33406 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32883) := by decide +kernel

theorem selectedBound33406 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env33407 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,32883,1345,262144,45085,32769,4097,46528,16,266384,38036,46173,45155,1296,42061,48441,267490,308666,257,42077,1345,46621]

theorem envBound33407 : H12AffineFastState.Bounded env33407 := by
  intro p hp
  have h : env33407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33406_33407 : H12AffineEnvironment.transform 15 32883 env33406 = env33407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32883 env33406 == env33407) = true)

def env33408 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32883,1345,262144,42333,32769,1345,41088,16,263632,33236,41245,42275,1296,42061,43129,262562,303354,257,42077,1345,41821]

theorem envBound33408 : H12AffineFastState.Bounded env33408 := by
  intro p hp
  have h : env33408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33407_33408 : H12AffineEnvironment.transform 11 1344 env33407 = env33408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env33407 == env33408) = true)

theorem identity33408 : scanCanonicalize (H12AffineFastState.compose env33408 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 73) := by decide +kernel

theorem selectedBound33408 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env33409 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,73,1296,32768,32883,1345,262144,34068,32769,1345,32969,16,263632,33236,33108,34154,1296,33796,34864,262562,295091,257,33812,1345,33556]

theorem envBound33409 : H12AffineFastState.Bounded env33409 := by
  intro p hp
  have h : env33409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33408_33409 : H12AffineEnvironment.transform 12 73 env33408 = env33409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env33408 == env33409) = true)

theorem identity33409 : scanCanonicalize (H12AffineFastState.compose env33409 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(17+1) ^^^ 2989) := by decide +kernel

theorem selectedBound33409 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env33410 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,73,1296,32768,32883,1345,2989,34068,32769,1345,32969,16,3709,33236,33108,34154,1296,33796,34864,2575,35614,257,33812,1345,33556]

theorem envBound33410 : H12AffineFastState.Bounded env33410 := by
  intro p hp
  have h : env33410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33409_33410 : H12AffineEnvironment.transform 17 2989 env33409 = env33410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2989 env33409 == env33410) = true)

def env33411 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32883,1345,262144,42332,32769,1344,41089,16,263633,33237,41244,42274,1296,42061,43128,262563,303355,257,42077,1345,41820]

theorem envBound33411 : H12AffineFastState.Bounded env33411 := by
  intro p hp
  have h : env33411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33407_33411 : H12AffineEnvironment.transform 11 1345 env33407 = env33411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env33407 == env33411) = true)

theorem identity33411 : scanCanonicalize (H12AffineFastState.compose env33411 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 41146) := by decide +kernel

theorem selectedBound33411 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env33412 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32883,1345,41146,42332,32769,1344,41089,16,42347,33237,41244,42274,1296,42061,43128,41241,65,257,42077,1345,41820]

theorem envBound33412 : H12AffineFastState.Bounded env33412 := by
  intro p hp
  have h : env33412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33411_33412 : H12AffineEnvironment.transform 17 41146 env33411 = env33412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 41146 env33411 == env33412) = true)

theorem identity33412 : scanCanonicalize (H12AffineFastState.compose env33412 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound33412 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env33413 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,8540,8495,1345,486,1024,8541,1344,477,16,1079,8329,64,1150,1296,1297,2340,69,65,257,1281,1345,512]

theorem envBound33413 : H12AffineFastState.Bounded env33413 := by
  intro p hp
  have h : env33413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33412_33413 : H12AffineEnvironment.transform 14 8540 env33412 = env33413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env33412 == env33413) = true)

theorem identity33413 : scanCanonicalize (H12AffineFastState.compose env33413 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 85) := by decide +kernel

theorem selectedBound33413 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env33414 : List Nat := [2,4,8,16,32,64,128,256,512,85,2048,276,8192,325,8540,8495,276,486,85,8541,277,477,16,98,8329,64,43,325,324,2340,69,65,257,340,276,512]

theorem envBound33414 : H12AffineFastState.Bounded env33414 := by
  intro p hp
  have h : env33414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33413_33414 : H12AffineEnvironment.transform 9 85 env33413 = env33414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env33413 == env33414) = true)

theorem identity33414 : scanCanonicalize (H12AffineFastState.compose env33414 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 704) := by decide +kernel

theorem selectedBound33414 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env33415 : List Nat := [2,4,8,16,32,64,128,256,512,85,2048,276,704,325,924,1007,276,486,85,925,277,477,16,98,585,64,43,325,324,2340,69,65,257,340,276,512]

theorem envBound33415 : H12AffineFastState.Bounded env33415 := by
  intro p hp
  have h : env33415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33414_33415 : H12AffineEnvironment.transform 12 704 env33414 = env33415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 704 env33414 == env33415) = true)

theorem identity33415 : scanCanonicalize (H12AffineFastState.compose env33415 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound33415 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env33416 : List Nat := [2,4,8,16,32,16,128,256,512,5,2048,276,656,277,924,959,276,438,5,925,277,397,16,50,537,16,43,277,276,2340,21,17,257,260,276,512]

theorem envBound33416 : H12AffineFastState.Bounded env33416 := by
  intro p hp
  have h : env33416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33415_33416 : H12AffineEnvironment.transform 5 16 env33415 = env33416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33415 == env33416) = true)

theorem identity33416 : scanCanonicalize (H12AffineFastState.compose env33416 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 438) := by decide +kernel

theorem selectedBound33416 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env33417 : List Nat := [2,4,8,16,32,16,128,256,512,5,438,276,656,277,924,959,276,438,5,925,277,397,16,50,537,16,43,277,276,146,21,17,257,260,276,512]

theorem envBound33417 : H12AffineFastState.Bounded env33417 := by
  intro p hp
  have h : env33417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33416_33417 : H12AffineEnvironment.transform 10 438 env33416 = env33417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 438 env33416 == env33417) = true)

def env33418 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1344,262144,77935,32769,4097,46529,16,266385,70886,78895,77840,1296,74814,81227,365712,308666,257,74799,1345,79471]

theorem envBound33418 : H12AffineFastState.Bounded env33418 := by
  intro p hp
  have h : env33418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33405_33418 : H12AffineEnvironment.transform 13 1297 env33405 = env33418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env33405 == env33418) = true)

theorem identity33418 : scanCanonicalize (H12AffineFastState.compose env33418 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound33418 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env33419 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1344,262144,77935,13341,4097,477,16,266385,70886,78895,77840,1296,74814,81227,336012,262566,257,74799,1345,79471]

theorem envBound33419 : H12AffineFastState.Bounded env33419 := by
  intro p hp
  have h : env33419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33418_33419 : H12AffineEnvironment.transform 14 13340 env33418 = env33419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env33418 == env33419) = true)

def env33420 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1344,65664,77935,13341,4097,477,16,69649,70886,78895,77840,1296,74814,81227,8204,65830,257,74799,1345,79471]

theorem envBound33420 : H12AffineFastState.Bounded env33420 := by
  intro p hp
  have h : env33420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33419_33420 : H12AffineEnvironment.transform 17 65664 env33419 = env33420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env33419 == env33420) = true)

theorem identity33420 : scanCanonicalize (H12AffineFastState.compose env33420 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9327) := by decide +kernel

theorem selectedBound33420 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env33421 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,9327,1344,9455,5120,13341,4097,477,16,13438,12425,4160,5247,1296,81,6436,8204,9545,257,64,1345,4608]

theorem envBound33421 : H12AffineFastState.Bounded env33421 := by
  intro p hp
  have h : env33421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33420_33421 : H12AffineEnvironment.transform 15 9327 env33420 = env33421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9327 env33420 == env33421) = true)

def env33422 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1297,9244,9327,1344,9455,1024,9245,1,477,16,9342,8329,64,1151,1296,81,2340,8204,9545,257,64,1345,512]

theorem envBound33422 : H12AffineFastState.Bounded env33422 := by
  intro p hp
  have h : env33422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33421_33422 : H12AffineEnvironment.transform 11 0 env33421 = env33422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env33421 == env33422) = true)

theorem identity33422 : scanCanonicalize (H12AffineFastState.compose env33422 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 85) := by decide +kernel

theorem selectedBound33422 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env33423 : List Nat := [2,4,8,16,32,64,128,256,512,85,2048,0,8192,324,8265,8250,277,8378,85,8264,1,477,16,8235,8329,64,42,325,81,2340,8204,8476,257,64,276,512]

theorem envBound33423 : H12AffineFastState.Bounded env33423 := by
  intro p hp
  have h : env33423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33422_33423 : H12AffineEnvironment.transform 9 85 env33422 = env33423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env33422 == env33423) = true)

theorem identity33423 : scanCanonicalize (H12AffineFastState.compose env33423 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound33423 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env33424 : List Nat := [2,4,8,16,32,16,128,256,512,5,2048,0,8192,276,8217,8250,277,8378,5,8216,1,397,16,8235,8329,16,42,277,1,2340,8204,8476,257,16,276,512]

theorem envBound33424 : H12AffineFastState.Bounded env33424 := by
  intro p hp
  have h : env33424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33423_33424 : H12AffineEnvironment.transform 5 16 env33423 = env33424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33423 == env33424) = true)

theorem identity33424 : scanCanonicalize (H12AffineFastState.compose env33424 (packedSelected [2,3,5,10,11,18] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound33424 : packedSelected [2,3,5,10,11,18] rootPS < 2^1333 := by decide +kernel

def env33425 : List Nat := [2,4,8,16,32,16,128,256,512,5,42,0,8192,276,8217,8250,277,8378,5,8216,1,397,16,8235,8329,16,42,277,1,270,8204,8476,257,16,276,512]

theorem envBound33425 : H12AffineFastState.Bounded env33425 := by
  intro p hp
  have h : env33425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33424_33425 : H12AffineEnvironment.transform 10 42 env33424 = env33425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env33424 == env33425) = true)

theorem identity33425 : scanCanonicalize (H12AffineFastState.compose env33425 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound33425 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env33426 : List Nat := [2,4,8,16,32,16,56,256,512,5,42,0,8192,276,8217,8250,277,8194,5,8216,1,309,16,8235,8241,16,42,277,1,270,8204,8476,257,16,276,512]

theorem envBound33426 : H12AffineFastState.Bounded env33426 := by
  intro p hp
  have h : env33426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33425_33426 : H12AffineEnvironment.transform 6 56 env33425 = env33426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env33425 == env33426) = true)

theorem identity33426 : scanCanonicalize (H12AffineFastState.compose env33426 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 563) := by decide +kernel

theorem selectedBound33426 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33427 : List Nat := [2,4,8,16,32,16,56,256,512,5,42,0,563,276,554,521,277,561,5,555,1,309,16,536,514,16,42,277,1,270,575,815,257,16,276,512]

theorem envBound33427 : H12AffineFastState.Bounded env33427 := by
  intro p hp
  have h : env33427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33426_33427 : H12AffineEnvironment.transform 12 563 env33426 = env33427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 563 env33426 == env33427) = true)

def env33428 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1297,9245,9327,1344,9455,1025,9244,0,477,16,9343,8328,65,1150,1296,81,2341,8204,9545,257,64,1345,513]

theorem envBound33428 : H12AffineFastState.Bounded env33428 := by
  intro p hp
  have h : env33428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33421_33428 : H12AffineEnvironment.transform 11 1 env33421 = env33428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env33421 == env33428) = true)

theorem identity33428 : scanCanonicalize (H12AffineFastState.compose env33428 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound33428 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env33429 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,1,8192,277,8217,8299,324,8427,5,8216,0,477,16,8315,8328,65,122,276,81,2341,8204,8525,257,64,325,513]

theorem envBound33429 : H12AffineFastState.Bounded env33429 := by
  intro p hp
  have h : env33429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33428_33429 : H12AffineEnvironment.transform 9 4 env33428 = env33429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env33428 == env33429) = true)

theorem identity33429 : scanCanonicalize (H12AffineFastState.compose env33429 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound33429 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env33430 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,1,349,277,324,310,324,438,5,325,0,477,16,294,469,65,122,276,81,2341,337,16,257,64,325,513]

theorem envBound33430 : H12AffineFastState.Bounded env33430 := by
  intro p hp
  have h : env33430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33429_33430 : H12AffineEnvironment.transform 12 349 env33429 = env33430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env33429 == env33430) = true)

theorem identity33430 : scanCanonicalize (H12AffineFastState.compose env33430 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound33430 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env33431 : List Nat := [2,4,8,16,32,64,128,4,512,4,2048,1,89,17,64,50,64,178,5,65,0,217,16,34,209,65,122,16,81,2081,85,16,5,64,65,513]

theorem envBound33431 : H12AffineFastState.Bounded env33431 := by
  intro p hp
  have h : env33431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33430_33431 : H12AffineEnvironment.transform 7 4 env33430 = env33431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env33430 == env33431) = true)

theorem identity33431 : scanCanonicalize (H12AffineFastState.compose env33431 (packedSelected [1,2,3,5,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 535) := by decide +kernel

theorem selectedBound33431 : packedSelected [1,2,3,5,15,17] rootPS < 2^1333 := by decide +kernel

def env33432 : List Nat := [2,4,8,16,32,64,128,4,512,4,535,1,89,17,64,50,64,178,5,65,0,217,16,34,209,65,122,16,81,566,85,16,5,64,65,513]

theorem envBound33432 : H12AffineFastState.Bounded env33432 := by
  intro p hp
  have h : env33432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33431_33432 : H12AffineEnvironment.transform 10 535 env33431 = env33432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 535 env33431 == env33432) = true)

theorem identity33432 : scanCanonicalize (H12AffineFastState.compose env33432 (packedSelected [2,11,12,13,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound33432 : packedSelected [2,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env33433 : List Nat := [2,4,8,16,32,64,128,4,137,4,158,1,89,17,64,50,64,178,5,65,0,217,16,34,209,65,122,16,81,191,85,16,5,64,65,136]

theorem envBound33433 : H12AffineFastState.Bounded env33433 := by
  intro p hp
  have h : env33433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33432_33433 : H12AffineEnvironment.transform 8 137 env33432 = env33433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env33432 == env33433) = true)

theorem identity33433 : scanCanonicalize (H12AffineFastState.compose env33433 (packedSelected [0,2,3,7,8,11,12,15] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound33433 : packedSelected [0,2,3,7,8,11,12,15] rootPS < 2^1333 := by decide +kernel

def env33434 : List Nat := [2,4,4,16,32,64,128,4,133,4,146,1,85,17,64,50,64,178,5,65,0,213,16,34,209,65,118,16,81,179,85,16,5,64,65,132]

theorem envBound33434 : H12AffineFastState.Bounded env33434 := by
  intro p hp
  have h : env33434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33433_33434 : H12AffineEnvironment.transform 2 4 env33433 = env33434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env33433 == env33434) = true)

theorem identity33434 : scanCanonicalize (H12AffineFastState.compose env33434 (packedSelected [3,4,8,9,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound33434 : packedSelected [3,4,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env33435 : List Nat := [2,4,4,16,32,16,128,4,133,4,146,1,5,17,16,50,16,178,5,17,0,133,16,34,129,17,38,16,1,179,5,16,5,16,17,132]

theorem envBound33435 : H12AffineFastState.Bounded env33435 := by
  intro p hp
  have h : env33435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33434_33435 : H12AffineEnvironment.transform 5 16 env33434 = env33435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33434 == env33435) = true)

theorem identity33435 : scanCanonicalize (H12AffineFastState.compose env33435 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound33435 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env33436 : List Nat := [2,4,4,0,32,0,128,4,133,4,130,1,5,1,0,34,0,162,5,1,0,133,0,34,129,1,38,0,1,163,5,0,5,0,1,132]

theorem envBound33436 : H12AffineFastState.Bounded env33436 := by
  intro p hp
  have h : env33436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33435_33436 : H12AffineEnvironment.transform 3 0 env33435 = env33436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env33435 == env33436) = true)

theorem identity33436 : scanCanonicalize (H12AffineFastState.compose env33436 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound33436 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33437 : List Nat := [2,4,4,0,32,0,2,4,7,4,0,1,5,1,0,34,0,32,5,1,0,7,0,34,3,1,38,0,1,33,5,0,5,0,1,6]

theorem envBound33437 : H12AffineFastState.Bounded env33437 := by
  intro p hp
  have h : env33437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33436_33437 : H12AffineEnvironment.transform 6 2 env33436 = env33437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env33436 == env33437) = true)

theorem identity33437 : scanCanonicalize (H12AffineFastState.compose env33437 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound33437 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33438 : List Nat := [2,0,0,0,32,0,2,0,3,0,0,1,1,1,0,34,0,32,1,1,0,3,0,34,3,1,34,0,1,33,1,0,1,0,1,2]

theorem envBound33438 : H12AffineFastState.Bounded env33438 := by
  intro p hp
  have h : env33438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33437_33438 : H12AffineEnvironment.transform 1 0 env33437 = env33438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env33437 == env33438) = true)

def env33439 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1344,65665,77935,13341,4097,477,16,69648,70886,78895,77840,1296,74814,81227,8205,65831,257,74799,1345,79471]

theorem envBound33439 : H12AffineFastState.Bounded env33439 := by
  intro p hp
  have h : env33439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33419_33439 : H12AffineEnvironment.transform 17 65665 env33419 = env33439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env33419 == env33439) = true)

theorem identity33439 : scanCanonicalize (H12AffineFastState.compose env33439 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12590) := by decide +kernel

theorem selectedBound33439 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env33440 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,12590,1344,12719,321,13341,4097,477,16,8510,9672,1281,318,1296,5392,3173,8205,12297,257,5377,1345,1857]

theorem envBound33440 : H12AffineFastState.Bounded env33440 := by
  intro p hp
  have h : env33440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33439_33440 : H12AffineEnvironment.transform 15 12590 env33439 = env33440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12590 env33439 == env33440) = true)

def env33441 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,81,12636,12590,0,12719,321,12637,4097,477,16,8510,8328,65,318,80,4176,2341,8205,12297,257,4161,1,513]

theorem envBound33441 : H12AffineFastState.Bounded env33441 := by
  intro p hp
  have h : env33441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33440_33441 : H12AffineEnvironment.transform 9 320 env33440 = env33441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env33440 == env33441) = true)

theorem identity33441 : scanCanonicalize (H12AffineFastState.compose env33441 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound33441 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env33442 : List Nat := [2,4,8,16,32,64,128,68,512,4,2048,4096,8192,81,12312,12394,0,12523,5,12313,4097,153,16,8314,8328,65,122,80,4176,2145,8205,12297,69,4161,1,513]

theorem envBound33442 : H12AffineFastState.Bounded env33442 := by
  intro p hp
  have h : env33442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33441_33442 : H12AffineEnvironment.transform 7 68 env33441 = env33442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env33441 == env33442) = true)

theorem identity33442 : scanCanonicalize (H12AffineFastState.compose env33442 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound33442 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env33443 : List Nat := [2,4,8,16,32,64,128,68,512,4,2048,4096,24,81,4096,4210,0,4339,5,4097,4097,153,16,98,144,65,122,80,4176,2145,21,4113,69,4161,1,513]

theorem envBound33443 : H12AffineFastState.Bounded env33443 := by
  intro p hp
  have h : env33443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33442_33443 : H12AffineEnvironment.transform 12 24 env33442 = env33443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env33442 == env33443) = true)

theorem identity33443 : scanCanonicalize (H12AffineFastState.compose env33443 (packedSelected [3,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound33443 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env33444 : List Nat := [2,4,8,16,32,64,128,68,512,4,2048,64,24,81,64,50,0,179,5,65,65,153,16,98,144,65,122,80,16,2145,21,81,69,1,1,513]

theorem envBound33444 : H12AffineFastState.Bounded env33444 := by
  intro p hp
  have h : env33444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33443_33444 : H12AffineEnvironment.transform 11 64 env33443 = env33444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env33443 == env33444) = true)

theorem identity33444 : scanCanonicalize (H12AffineFastState.compose env33444 (packedSelected [0,1,7,8,11,15] rootPS)) = affineNative (2^(10+1) ^^^ 123) := by decide +kernel

theorem selectedBound33444 : packedSelected [0,1,7,8,11,15] rootPS < 2^1333 := by decide +kernel

def env33445 : List Nat := [2,4,8,16,32,64,128,68,512,4,123,64,24,81,64,50,0,179,5,65,65,153,16,98,144,65,122,80,16,26,21,81,69,1,1,513]

theorem envBound33445 : H12AffineFastState.Bounded env33445 := by
  intro p hp
  have h : env33445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33444_33445 : H12AffineEnvironment.transform 10 123 env33444 = env33445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 123 env33444 == env33445) = true)

theorem identity33445 : scanCanonicalize (H12AffineFastState.compose env33445 (packedSelected [2,12,13] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound33445 : packedSelected [2,12,13] rootPS < 2^1333 := by decide +kernel

def env33446 : List Nat := [2,4,8,16,32,64,128,68,33,4,123,64,24,81,64,50,0,179,5,65,65,153,16,98,144,65,122,80,16,26,21,81,69,1,1,32]

theorem envBound33446 : H12AffineFastState.Bounded env33446 := by
  intro p hp
  have h : env33446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33445_33446 : H12AffineEnvironment.transform 8 33 env33445 = env33446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env33445 == env33446) = true)

theorem identity33446 : scanCanonicalize (H12AffineFastState.compose env33446 (packedSelected [0,1,2,5,7,8,11] rootPS)) = affineNative (2^(6+1) ^^^ 100) := by decide +kernel

theorem selectedBound33446 : packedSelected [0,1,2,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env33447 : List Nat := [2,4,8,16,32,64,100,68,33,4,123,64,24,81,64,50,0,87,5,65,65,125,16,98,116,65,122,80,16,26,21,81,69,1,1,32]

theorem envBound33447 : H12AffineFastState.Bounded env33447 := by
  intro p hp
  have h : env33447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33446_33447 : H12AffineEnvironment.transform 6 100 env33446 = env33447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 100 env33446 == env33447) = true)

theorem identity33447 : scanCanonicalize (H12AffineFastState.compose env33447 (packedSelected [1,3,17] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound33447 : packedSelected [1,3,17] rootPS < 2^1333 := by decide +kernel

def env33448 : List Nat := [2,4,8,1,32,64,100,68,33,4,106,64,9,64,64,35,0,70,5,65,65,108,1,98,101,65,107,65,1,11,4,64,69,1,1,32]

theorem envBound33448 : H12AffineFastState.Bounded env33448 := by
  intro p hp
  have h : env33448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33447_33448 : H12AffineEnvironment.transform 3 1 env33447 = env33448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env33447 == env33448) = true)

theorem identity33448 : scanCanonicalize (H12AffineFastState.compose env33448 (packedSelected [1,2] rootPS)) = affineNative (2^(5+1) ^^^ 39) := by decide +kernel

theorem selectedBound33448 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env33449 : List Nat := [2,4,8,1,32,39,3,35,33,4,13,39,9,39,39,35,0,33,5,38,38,11,1,5,2,38,12,38,1,11,4,39,34,1,1,32]

theorem envBound33449 : H12AffineFastState.Bounded env33449 := by
  intro p hp
  have h : env33449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33448_33449 : H12AffineEnvironment.transform 5 39 env33448 = env33449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 39 env33448 == env33449) = true)

theorem identity33449 : scanCanonicalize (H12AffineFastState.compose env33449 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound33449 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env33450 : List Nat := [2,4,8,1,1,6,3,2,0,4,13,6,9,6,6,2,0,0,5,7,7,11,1,5,2,7,12,7,1,11,4,6,3,1,1,1]

theorem envBound33450 : H12AffineFastState.Bounded env33450 := by
  intro p hp
  have h : env33450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33449_33450 : H12AffineEnvironment.transform 4 1 env33449 = env33450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env33449 == env33450) = true)

def env33451 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,80,12637,12590,1,12719,321,12636,4097,477,16,8510,8329,64,318,81,4177,2340,8205,12297,257,4160,0,512]

theorem envBound33451 : H12AffineFastState.Bounded env33451 := by
  intro p hp
  have h : env33451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33440_33451 : H12AffineEnvironment.transform 9 321 env33440 = env33451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env33440 == env33451) = true)

theorem identity33451 : scanCanonicalize (H12AffineFastState.compose env33451 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound33451 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env33452 : List Nat := [2,4,8,16,32,64,128,20,512,85,2048,4096,8192,80,12361,12346,1,12475,85,12360,4097,201,16,8234,8329,64,42,81,4177,2096,8205,12297,21,4160,0,512]

theorem envBound33452 : H12AffineFastState.Bounded env33452 := by
  intro p hp
  have h : env33452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33451_33452 : H12AffineEnvironment.transform 7 20 env33451 = env33452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env33451 == env33452) = true)

theorem identity33452 : scanCanonicalize (H12AffineFastState.compose env33452 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound33452 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env33453 : List Nat := [2,4,8,16,32,16,128,20,512,5,2048,4096,8192,0,12313,12346,1,12475,5,12312,4097,153,16,8234,8329,16,42,1,4097,2096,8205,12297,21,4112,0,512]

theorem envBound33453 : H12AffineFastState.Bounded env33453 := by
  intro p hp
  have h : env33453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33452_33453 : H12AffineEnvironment.transform 5 16 env33452 = env33453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33452 == env33453) = true)

theorem identity33453 : scanCanonicalize (H12AffineFastState.compose env33453 (packedSelected [2,3,5,10,11,18] rootPS)) = affineNative (2^(11+1) ^^^ 2091) := by decide +kernel

theorem selectedBound33453 : packedSelected [2,3,5,10,11,18] rootPS < 2^1333 := by decide +kernel

def env33454 : List Nat := [2,4,8,16,32,16,128,20,512,5,2048,2091,8192,0,10290,10257,1,10384,5,10291,2090,153,16,8234,8329,16,42,1,2090,2096,8205,10274,21,2107,0,512]

theorem envBound33454 : H12AffineFastState.Bounded env33454 := by
  intro p hp
  have h : env33454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33453_33454 : H12AffineEnvironment.transform 11 2091 env33453 = env33454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2091 env33453 == env33454) = true)

theorem identity33454 : scanCanonicalize (H12AffineFastState.compose env33454 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 2192) := by decide +kernel

theorem selectedBound33454 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env33455 : List Nat := [2,4,8,16,32,16,128,20,512,5,2048,2091,2192,0,162,129,1,0,5,163,2090,153,16,2234,2073,16,42,1,2090,2096,2205,178,21,2107,0,512]

theorem envBound33455 : H12AffineFastState.Bounded env33455 := by
  intro p hp
  have h : env33455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33454_33455 : H12AffineEnvironment.transform 12 2192 env33454 = env33455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2192 env33454 == env33455) = true)

theorem identity33455 : scanCanonicalize (H12AffineFastState.compose env33455 (packedSelected [0,4,5,8,10] rootPS)) = affineNative (2^(10+1) ^^^ 675) := by decide +kernel

theorem selectedBound33455 : packedSelected [0,4,5,8,10] rootPS < 2^1333 := by decide +kernel

def env33456 : List Nat := [2,4,8,16,32,16,128,20,512,5,675,648,563,0,162,129,1,0,5,163,649,153,16,537,698,16,42,1,649,659,574,178,21,664,0,512]

theorem envBound33456 : H12AffineFastState.Bounded env33456 := by
  intro p hp
  have h : env33456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33455_33456 : H12AffineEnvironment.transform 10 675 env33455 = env33456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 675 env33455 == env33456) = true)

theorem identity33456 : scanCanonicalize (H12AffineFastState.compose env33456 (packedSelected [0,2,4,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound33456 : packedSelected [0,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env33457 : List Nat := [2,4,8,16,17,16,128,20,512,5,658,648,514,0,147,129,1,0,5,146,649,153,16,537,651,16,27,1,649,659,527,131,21,664,0,512]

theorem envBound33457 : H12AffineFastState.Bounded env33457 := by
  intro p hp
  have h : env33457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33456_33457 : H12AffineEnvironment.transform 4 17 env33456 = env33457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env33456 == env33457) = true)

theorem identity33457 : scanCanonicalize (H12AffineFastState.compose env33457 (packedSelected [0,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound33457 : packedSelected [0,2,3] rootPS < 2^1333 := by decide +kernel

def env33458 : List Nat := [2,4,8,16,17,16,8,20,512,5,538,512,514,0,27,9,1,0,5,26,513,17,16,537,515,16,27,1,513,539,527,11,21,528,0,512]

theorem envBound33458 : H12AffineFastState.Bounded env33458 := by
  intro p hp
  have h : env33458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33457_33458 : H12AffineEnvironment.transform 6 8 env33457 = env33458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env33457 == env33458) = true)

theorem identity33458 : scanCanonicalize (H12AffineFastState.compose env33458 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound33458 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33459 : List Nat := [2,4,8,11,10,11,8,15,512,5,513,512,514,0,0,9,1,0,5,1,513,10,11,514,515,11,0,1,513,512,527,11,14,523,0,512]

theorem envBound33459 : H12AffineFastState.Bounded env33459 := by
  intro p hp
  have h : env33459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33458_33459 : H12AffineEnvironment.transform 3 11 env33458 = env33459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env33458 == env33459) = true)

def env33460 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95614,32769,4097,61648,147521,284033,86519,209263,225344,148801,74814,96346,381312,456170,257,205167,1345,95102]

theorem envBound33460 : H12AffineFastState.Bounded env33460 := by
  intro p hp
  have h : env33460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33343_33460 : H12AffineEnvironment.transform 23 284033 env33343 = env33460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 284033 env33343 == env33460) = true)

def env33461 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16464,262144,95614,32769,4097,61648,17,284033,86519,94527,77840,1297,74814,96346,381312,308666,257,90431,1345,95102]

theorem envBound33461 : H12AffineFastState.Bounded env33461 := by
  intro p hp
  have h : env33461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33460_33461 : H12AffineEnvironment.transform 16 16464 env33460 = env33461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16464 env33460 == env33461) = true)

def env33462 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1344,262144,77934,32769,4097,46528,17,266385,70887,78895,77840,1297,74814,81226,365712,308666,257,74799,1345,79470]

theorem envBound33462 : H12AffineFastState.Bounded env33462 := by
  intro p hp
  have h : env33462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33461_33462 : H12AffineEnvironment.transform 13 1296 env33461 = env33462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env33461 == env33462) = true)

theorem identity33462 : scanCanonicalize (H12AffineFastState.compose env33462 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound33462 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env33463 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1344,262144,77934,13341,4097,476,17,266385,70887,78895,77840,1297,74814,81226,336012,262566,257,74799,1345,79470]

theorem envBound33463 : H12AffineFastState.Bounded env33463 := by
  intro p hp
  have h : env33463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33462_33463 : H12AffineEnvironment.transform 14 13340 env33462 = env33463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env33462 == env33463) = true)

def env33464 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1344,65664,77934,13341,4097,476,17,69649,70887,78895,77840,1297,74814,81226,8204,65830,257,74799,1345,79470]

theorem envBound33464 : H12AffineFastState.Bounded env33464 := by
  intro p hp
  have h : env33464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33463_33464 : H12AffineEnvironment.transform 17 65664 env33463 = env33464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env33463 == env33464) = true)

theorem identity33464 : scanCanonicalize (H12AffineFastState.compose env33464 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5385) := by decide +kernel

theorem selectedBound33464 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env33465 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5385,1296,277,65536,1344,65664,66919,276,4097,476,17,69649,70887,65830,66841,1297,69943,67651,5381,65830,257,69926,1345,66407]

theorem envBound33465 : H12AffineFastState.Bounded env33465 := by
  intro p hp
  have h : env33465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33464_33465 : H12AffineEnvironment.transform 12 5385 env33464 = env33465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5385 env33464 == env33465) = true)

def env33466 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,5385,1296,277,65536,1296,65664,66871,276,4097,396,17,69649,70839,65830,66841,1297,69943,67603,5381,65830,257,69926,1297,66359]

theorem envBound33466 : H12AffineFastState.Bounded env33466 := by
  intro p hp
  have h : env33466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33465_33466 : H12AffineEnvironment.transform 5 16 env33465 = env33466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33465 == env33466) = true)

theorem identity33466 : scanCanonicalize (H12AffineFastState.compose env33466 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound33466 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env33467 : List Nat := [2,4,8,16,32,16,128,256,512,5,2048,4096,4364,277,277,65536,277,65664,65842,276,4097,396,17,69649,69810,65830,65820,276,69943,67603,4352,65830,257,69926,276,66359]

theorem envBound33467 : H12AffineFastState.Bounded env33467 := by
  intro p hp
  have h : env33467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33466_33467 : H12AffineEnvironment.transform 9 5 env33466 = env33467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env33466 == env33467) = true)

theorem identity33467 : scanCanonicalize (H12AffineFastState.compose env33467 (packedSelected [1,2,3,5,8,10,13,19,21,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 4778) := by decide +kernel

theorem selectedBound33467 : packedSelected [1,2,3,5,8,10,13,19,21,23,32] rootPS < 2^1333 := by decide +kernel

def env33468 : List Nat := [2,4,8,16,32,16,128,256,512,5,2048,4096,4364,277,277,4778,277,4650,5016,276,4097,396,17,699,536,5004,5046,276,925,6841,4352,5004,257,908,276,4509]

theorem envBound33468 : H12AffineFastState.Bounded env33468 := by
  intro p hp
  have h : env33468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33467_33468 : H12AffineEnvironment.transform 15 4778 env33467 = env33468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4778 env33467 == env33468) = true)

theorem identity33468 : scanCanonicalize (H12AffineFastState.compose env33468 (packedSelected [0,3,4,5,7,9,10,13,18,23,24,28] rootPS)) = affineNative (2^(10+1) ^^^ 319) := by decide +kernel

theorem selectedBound33468 : packedSelected [0,3,4,5,7,9,10,13,18,23,24,28] rootPS < 2^1333 := by decide +kernel

def env33469 : List Nat := [2,4,8,16,32,16,128,256,512,5,319,4096,4364,277,277,4778,277,4650,5016,276,4097,396,17,699,536,5004,5046,276,925,4998,4352,5004,257,908,276,4509]

theorem envBound33469 : H12AffineFastState.Bounded env33469 := by
  intro p hp
  have h : env33469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33468_33469 : H12AffineEnvironment.transform 10 319 env33468 = env33469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 319 env33468 == env33469) = true)

theorem identity33469 : scanCanonicalize (H12AffineFastState.compose env33469 (packedSelected [0,1,4,5,7,9,10,12,13,15,17] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound33469 : packedSelected [0,1,4,5,7,9,10,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env33470 : List Nat := [2,4,8,16,32,16,128,256,48,5,319,4096,4364,277,277,4250,277,4122,4520,276,4097,396,17,139,40,4540,4486,276,429,4534,4352,4540,257,444,276,4509]

theorem envBound33470 : H12AffineFastState.Bounded env33470 := by
  intro p hp
  have h : env33470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33469_33470 : H12AffineEnvironment.transform 8 48 env33469 = env33470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env33469 == env33470) = true)

theorem identity33470 : scanCanonicalize (H12AffineFastState.compose env33470 (packedSelected [1,4,7,8,11,12] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound33470 : packedSelected [1,4,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env33471 : List Nat := [2,4,8,16,16,16,128,256,0,5,271,4096,4364,277,277,4250,277,4122,4504,276,4097,396,17,139,24,4492,4486,276,413,4486,4352,4492,257,396,276,4509]

theorem envBound33471 : H12AffineFastState.Bounded env33471 := by
  intro p hp
  have h : env33471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33470_33471 : H12AffineEnvironment.transform 4 16 env33470 = env33471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env33470 == env33471) = true)

theorem identity33471 : scanCanonicalize (H12AffineFastState.compose env33471 (packedSelected [2,3,8] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound33471 : packedSelected [2,3,8] rootPS < 2^1333 := by decide +kernel

def env33472 : List Nat := [2,4,8,16,16,16,128,256,0,5,271,277,25,277,277,399,277,271,141,276,276,396,17,139,24,153,147,276,413,147,21,153,257,396,276,136]

theorem envBound33472 : H12AffineFastState.Bounded env33472 := by
  intro p hp
  have h : env33472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33471_33472 : H12AffineEnvironment.transform 11 277 env33471 = env33472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env33471 == env33472) = true)

theorem identity33472 : scanCanonicalize (H12AffineFastState.compose env33472 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound33472 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env33473 : List Nat := [2,4,8,16,16,16,19,256,0,5,271,277,25,277,277,284,277,271,30,276,276,287,17,24,24,10,0,276,270,0,21,10,257,287,276,27]

theorem envBound33473 : H12AffineFastState.Bounded env33473 := by
  intro p hp
  have h : env33473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33472_33473 : H12AffineEnvironment.transform 6 19 env33472 = env33473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env33472 == env33473) = true)

theorem identity33473 : scanCanonicalize (H12AffineFastState.compose env33473 (packedSelected [1,2,5] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound33473 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env33474 : List Nat := [2,4,8,16,16,16,19,14,0,5,1,27,25,27,27,18,27,1,30,26,26,17,17,24,24,10,0,26,0,0,21,10,15,17,26,27]

theorem envBound33474 : H12AffineFastState.Bounded env33474 := by
  intro p hp
  have h : env33474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33473_33474 : H12AffineEnvironment.transform 7 14 env33473 = env33474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env33473 == env33474) = true)

theorem identity33474 : scanCanonicalize (H12AffineFastState.compose env33474 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound33474 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33475 : List Nat := [2,4,8,10,10,10,9,14,0,5,1,1,3,1,1,8,1,1,4,0,0,11,11,2,2,10,0,0,0,0,15,10,15,11,0,1]

theorem envBound33475 : H12AffineFastState.Bounded env33475 := by
  intro p hp
  have h : env33475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33474_33475 : H12AffineEnvironment.transform 3 10 env33474 = env33475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env33474 == env33475) = true)

theorem identity33475 : scanCanonicalize (H12AffineFastState.compose env33475 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound33475 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33476 : List Nat := [2,4,7,5,5,5,6,1,0,5,1,1,3,1,1,7,1,1,4,0,0,4,4,2,2,5,0,0,0,0,0,5,0,4,0,1]

theorem envBound33476 : H12AffineFastState.Bounded env33476 := by
  intro p hp
  have h : env33476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33475_33476 : H12AffineEnvironment.transform 2 7 env33475 = env33476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env33475 == env33476) = true)

theorem identity33476 : scanCanonicalize (H12AffineFastState.compose env33476 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound33476 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33477 : List Nat := [2,2,1,3,3,3,0,1,0,3,1,1,3,1,1,1,1,1,2,0,0,2,2,2,2,3,0,0,0,0,0,3,0,2,0,1]

theorem envBound33477 : H12AffineFastState.Bounded env33477 := by
  intro p hp
  have h : env33477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33476_33477 : H12AffineEnvironment.transform 1 2 env33476 = env33477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env33476 == env33477) = true)

theorem identity33477 : scanCanonicalize (H12AffineFastState.compose env33477 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound33477 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env33478 : List Nat := [0,0,1,1,1,1,0,1,0,1,1,1,1,1,1,1,1,1,0,0,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,1]

theorem envBound33478 : H12AffineFastState.Bounded env33478 := by
  intro p hp
  have h : env33478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33477_33478 : H12AffineEnvironment.transform 0 0 env33477 = env33478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env33477 == env33478) = true)

def env33479 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,5385,1296,277,65536,1297,65664,66870,276,4097,397,17,69649,70838,65830,66841,1297,69943,67602,5381,65830,257,69926,1296,66358]

theorem envBound33479 : H12AffineFastState.Bounded env33479 := by
  intro p hp
  have h : env33479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33465_33479 : H12AffineEnvironment.transform 5 17 env33465 = env33479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env33465 == env33479) = true)

theorem identity33479 : scanCanonicalize (H12AffineFastState.compose env33479 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 1330) := by decide +kernel

theorem selectedBound33479 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env33480 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,5385,1296,277,1330,1297,1458,4,276,4097,397,17,5411,4484,1044,43,1297,5125,3360,5381,1044,257,5140,1296,1540]

theorem envBound33480 : H12AffineFastState.Bounded env33480 := by
  intro p hp
  have h : env33480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33479_33480 : H12AffineEnvironment.transform 15 1330 env33479 = env33480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1330 env33479 == env33480) = true)

def env33481 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1344,65665,77934,13341,4097,476,17,69648,70887,78895,77840,1297,74814,81226,8205,65831,257,74799,1345,79470]

theorem envBound33481 : H12AffineFastState.Bounded env33481 := by
  intro p hp
  have h : env33481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33463_33481 : H12AffineEnvironment.transform 17 65665 env33463 = env33481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env33463 == env33481) = true)

theorem identity33481 : scanCanonicalize (H12AffineFastState.compose env33481 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 72) := by decide +kernel

theorem selectedBound33481 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env33482 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,72,1296,5204,65536,1344,65665,69670,5205,4097,476,17,69648,70887,70759,69720,1297,66678,72962,69,65831,257,66663,1345,71206]

theorem envBound33482 : H12AffineFastState.Bounded env33482 := by
  intro p hp
  have h : env33482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33481_33482 : H12AffineEnvironment.transform 12 72 env33481 = env33482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env33481 == env33482) = true)

def env33483 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,24,1296,5124,65536,1296,65665,69670,5125,4097,396,17,69648,70839,70711,69640,1297,66598,72962,21,65831,257,66615,1297,71206]

theorem envBound33483 : H12AffineFastState.Bounded env33483 := by
  intro p hp
  have h : env33483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33482_33483 : H12AffineEnvironment.transform 5 16 env33482 = env33483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33482 == env33483) = true)

theorem identity33483 : scanCanonicalize (H12AffineFastState.compose env33483 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound33483 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env33484 : List Nat := [2,4,8,16,32,16,128,256,512,5,2048,4096,24,277,4097,65536,277,65665,69670,4096,4097,396,17,69648,69810,69682,69640,276,65571,71943,21,65831,257,65586,276,70179]

theorem envBound33484 : H12AffineFastState.Bounded env33484 := by
  intro p hp
  have h : env33484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33483_33484 : H12AffineEnvironment.transform 9 5 env33483 = env33484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env33483 == env33484) = true)

theorem identity33484 : scanCanonicalize (H12AffineFastState.compose env33484 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 4131) := by decide +kernel

theorem selectedBound33484 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env33485 : List Nat := [2,4,8,16,32,16,128,256,512,5,2048,4096,24,277,4097,4131,277,4258,5,4096,4097,396,17,51,145,17,43,276,4096,2340,21,4356,257,4113,276,512]

theorem envBound33485 : H12AffineFastState.Bounded env33485 := by
  intro p hp
  have h : env33485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33484_33485 : H12AffineEnvironment.transform 15 4131 env33484 = env33485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4131 env33484 == env33485) = true)

theorem identity33485 : scanCanonicalize (H12AffineFastState.compose env33485 (packedSelected [2,11,18] rootPS)) = affineNative (2^(11+1) ^^^ 2587) := by decide +kernel

theorem selectedBound33485 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env33486 : List Nat := [2,4,8,16,32,16,128,256,512,5,2048,2587,24,277,2586,2616,277,2745,5,2587,2586,396,17,51,145,17,43,276,2587,2340,21,2847,257,2570,276,512]

theorem envBound33486 : H12AffineFastState.Bounded env33486 := by
  intro p hp
  have h : env33486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33485_33486 : H12AffineEnvironment.transform 11 2587 env33485 = env33486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2587 env33485 == env33486) = true)

theorem identity33486 : scanCanonicalize (H12AffineFastState.compose env33486 (packedSelected [1,2,5,10,13] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound33486 : packedSelected [1,2,5,10,13] rootPS < 2^1333 := by decide +kernel

def env33487 : List Nat := [2,4,8,16,32,16,128,256,27,5,2048,2048,24,277,2049,2083,277,2210,5,2048,2049,396,17,51,145,17,43,276,2048,2340,21,2308,257,2065,276,27]

theorem envBound33487 : H12AffineFastState.Bounded env33487 := by
  intro p hp
  have h : env33487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33486_33487 : H12AffineEnvironment.transform 8 27 env33486 = env33487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env33486 == env33487) = true)

theorem identity33487 : scanCanonicalize (H12AffineFastState.compose env33487 (packedSelected [0,1,2,3,5,7,8,11] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound33487 : packedSelected [0,1,2,3,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env33488 : List Nat := [2,4,8,16,32,16,18,256,27,5,2048,2048,24,277,2049,2083,277,2096,5,2048,2049,286,17,51,3,17,43,276,2048,2340,21,2308,257,2065,276,27]

theorem envBound33488 : H12AffineFastState.Bounded env33488 := by
  intro p hp
  have h : env33488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33487_33488 : H12AffineEnvironment.transform 6 18 env33487 = env33488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env33487 == env33488) = true)

theorem identity33488 : scanCanonicalize (H12AffineFastState.compose env33488 (packedSelected [0,5] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound33488 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env33489 : List Nat := [2,4,8,10,32,10,8,256,1,5,2048,2048,2,271,2049,2083,271,2090,5,2048,2049,260,11,41,3,11,43,270,2048,2340,15,2308,257,2059,270,1]

theorem envBound33489 : H12AffineFastState.Bounded env33489 := by
  intro p hp
  have h : env33489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33488_33489 : H12AffineEnvironment.transform 3 10 env33488 = env33489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env33488 == env33489) = true)

theorem identity33489 : scanCanonicalize (H12AffineFastState.compose env33489 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound33489 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env33490 : List Nat := [2,4,8,10,10,10,8,256,1,5,2048,2048,2,271,2049,2057,271,2048,5,2048,2049,260,11,3,3,11,1,270,2048,2318,15,2308,257,2059,270,1]

theorem envBound33490 : H12AffineFastState.Bounded env33490 := by
  intro p hp
  have h : env33490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33489_33490 : H12AffineEnvironment.transform 4 10 env33489 = env33490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env33489 == env33490) = true)

theorem identity33490 : scanCanonicalize (H12AffineFastState.compose env33490 (packedSelected [0,3] rootPS)) = affineNative (2^(10+1) ^^^ 270) := by decide +kernel

theorem selectedBound33490 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env33491 : List Nat := [2,4,8,10,10,10,8,256,1,5,270,270,2,271,271,263,271,270,5,270,271,260,11,3,3,11,1,270,270,0,15,10,257,261,270,1]

theorem envBound33491 : H12AffineFastState.Bounded env33491 := by
  intro p hp
  have h : env33491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33490_33491 : H12AffineEnvironment.transform 10 270 env33490 = env33491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 270 env33490 == env33491) = true)

theorem identity33491 : scanCanonicalize (H12AffineFastState.compose env33491 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound33491 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33492 : List Nat := [2,4,8,10,10,10,8,15,1,5,1,1,2,0,0,8,0,1,5,1,0,11,11,3,3,11,1,1,1,0,15,10,14,10,1,1]

theorem envBound33492 : H12AffineFastState.Bounded env33492 := by
  intro p hp
  have h : env33492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33491_33492 : H12AffineEnvironment.transform 7 15 env33491 = env33492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env33491 == env33492) = true)

theorem identity33492 : scanCanonicalize (H12AffineFastState.compose env33492 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound33492 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33493 : List Nat := [2,4,5,7,7,7,5,2,1,5,1,1,2,0,0,5,0,1,5,1,0,6,6,3,3,6,1,1,1,0,2,7,3,7,1,1]

theorem envBound33493 : H12AffineFastState.Bounded env33493 := by
  intro p hp
  have h : env33493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33492_33493 : H12AffineEnvironment.transform 2 5 env33492 = env33493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env33492 == env33493) = true)

def env33494 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,25,1296,5125,65536,1297,65665,69670,5124,4097,397,17,69648,70838,70710,69641,1297,66599,72962,20,65831,257,66614,1296,71206]

theorem envBound33494 : H12AffineFastState.Bounded env33494 := by
  intro p hp
  have h : env33494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33482_33494 : H12AffineEnvironment.transform 5 17 env33482 = env33494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env33482 == env33494) = true)

theorem identity33494 : scanCanonicalize (H12AffineFastState.compose env33494 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 4130) := by decide +kernel

theorem selectedBound33494 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env33495 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,25,1296,5125,4130,1297,4259,4,5124,4097,397,17,50,1172,1044,43,1297,5125,3360,20,4357,257,5140,1296,1540]

theorem envBound33495 : H12AffineFastState.Bounded env33495 := by
  intro p hp
  have h : env33495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33494_33495 : H12AffineEnvironment.transform 15 4130 env33494 = env33495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4130 env33494 == env33495) = true)

theorem identity33495 : scanCanonicalize (H12AffineFastState.compose env33495 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound33495 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env33496 : List Nat := [2,4,8,16,32,17,128,256,512,5,2048,4096,25,277,4096,4130,276,4259,4,4097,4097,397,17,50,145,17,43,276,4096,2341,20,4357,257,4113,277,513]

theorem envBound33496 : H12AffineFastState.Bounded env33496 := by
  intro p hp
  have h : env33496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33495_33496 : H12AffineEnvironment.transform 9 5 env33495 = env33496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env33495 == env33496) = true)

theorem identity33496 : scanCanonicalize (H12AffineFastState.compose env33496 (packedSelected [2,11,18] rootPS)) = affineNative (2^(8+1) ^^^ 413) := by decide +kernel

theorem selectedBound33496 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env33497 : List Nat := [2,4,8,16,32,17,128,256,413,5,2048,4096,25,277,4096,4130,276,4259,4,4097,4097,397,17,50,145,17,43,276,4096,2341,20,4357,257,4113,277,412]

theorem envBound33497 : H12AffineFastState.Bounded env33497 := by
  intro p hp
  have h : env33497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33496_33497 : H12AffineEnvironment.transform 8 413 env33496 = env33497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 413 env33496 == env33497) = true)

theorem identity33497 : scanCanonicalize (H12AffineFastState.compose env33497 (packedSelected [0,1,3,7,11,13] rootPS)) = affineNative (2^(11+1) ^^^ 2194) := by decide +kernel

theorem selectedBound33497 : packedSelected [0,1,3,7,11,13] rootPS < 2^1333 := by decide +kernel

end H12CloudChart2