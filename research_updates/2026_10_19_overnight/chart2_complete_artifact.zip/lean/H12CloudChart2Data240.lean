import H12CloudChart2Data239

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env60638 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,656,1296,325,311,1344,262144,1673,324,1345,853,17,263632,145,713,1783,1296,1945,2989,262563,1929,256,262958,1344,136]

theorem envBound60638 : H12AffineFastState.Bounded env60638 := by
  intro p hp
  have h : env60638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60637_60638 : H12AffineEnvironment.transform 12 656 env60637 = env60638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 656 env60637 == env60638) = true)

def env60639 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32882,1344,262144,42333,32769,1344,41089,17,263633,33237,41245,42275,1296,42060,43129,262562,42076,256,303354,1344,41820]

theorem envBound60639 : H12AffineFastState.Bounded env60639 := by
  intro p hp
  have h : env60639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60635_60639 : H12AffineEnvironment.transform 11 1345 env60635 = env60639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env60635 == env60639) = true)

theorem identity60639 : scanCanonicalize (H12AffineFastState.compose env60639 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 438) := by decide +kernel

theorem selectedBound60639 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env60640 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32882,1344,438,42333,32769,1344,41089,17,1127,33237,41245,42275,1296,42060,43129,20,42076,256,41292,1344,41820]

theorem envBound60640 : H12AffineFastState.Bounded env60640 := by
  intro p hp
  have h : env60640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60639_60640 : H12AffineEnvironment.transform 17 438 env60639 = env60640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 438 env60639 == env60640) = true)

theorem identity60640 : scanCanonicalize (H12AffineFastState.compose env60640 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound60640 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env60641 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,8540,8494,1344,438,1025,8541,1344,477,17,1127,8329,65,1151,1296,1296,2341,20,1280,256,16,1344,512]

theorem envBound60641 : H12AffineFastState.Bounded env60641 := by
  intro p hp
  have h : env60641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60640_60641 : H12AffineEnvironment.transform 14 8540 env60640 = env60641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env60640 == env60641) = true)

theorem identity60641 : scanCanonicalize (H12AffineFastState.compose env60641 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound60641 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60642 : List Nat := [2,4,8,16,32,64,128,69,512,1024,2048,1028,8192,1109,8217,8299,1029,243,1025,8216,1029,152,17,1127,8329,65,1151,1109,1109,2144,20,1093,69,16,1029,512]

theorem envBound60642 : H12AffineFastState.Bounded env60642 := by
  intro p hp
  have h : env60642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60641_60642 : H12AffineEnvironment.transform 7 69 env60641 = env60642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env60641 == env60642) = true)

theorem identity60642 : scanCanonicalize (H12AffineFastState.compose env60642 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 656) := by decide +kernel

theorem selectedBound60642 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env60643 : List Nat := [2,4,8,16,32,64,128,69,512,1024,2048,1028,656,1109,649,763,1029,243,1025,648,1029,152,17,1127,537,65,1151,1109,1109,2144,20,1093,69,16,1029,512]

theorem envBound60643 : H12AffineFastState.Bounded env60643 := by
  intro p hp
  have h : env60643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60642_60643 : H12AffineEnvironment.transform 12 656 env60642 = env60643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 656 env60642 == env60643) = true)

theorem identity60643 : scanCanonicalize (H12AffineFastState.compose env60643 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound60643 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env60644 : List Nat := [2,4,8,16,32,16,128,21,512,1024,2048,1028,656,1029,649,683,1029,163,1025,648,1029,152,17,1079,537,17,1071,1029,1029,2096,20,1045,21,16,1029,512]

theorem envBound60644 : H12AffineFastState.Bounded env60644 := by
  intro p hp
  have h : env60644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60643_60644 : H12AffineEnvironment.transform 5 16 env60643 = env60644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env60643 == env60644) = true)

theorem identity60644 : scanCanonicalize (H12AffineFastState.compose env60644 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1174) := by decide +kernel

theorem selectedBound60644 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env60645 : List Nat := [2,4,8,16,32,16,128,21,512,1024,1174,1028,656,1029,649,683,1029,163,1025,648,1029,152,17,1079,537,17,1071,1029,1029,1190,20,1045,21,16,1029,512]

theorem envBound60645 : H12AffineFastState.Bounded env60645 := by
  intro p hp
  have h : env60645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60644_60645 : H12AffineEnvironment.transform 10 1174 env60644 = env60645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1174 env60644 == env60645) = true)

theorem identity60645 : scanCanonicalize (H12AffineFastState.compose env60645 (packedSelected [0,1,2,5,7,11] rootPS)) = affineNative (2^(8+1) ^^^ 163) := by decide +kernel

theorem selectedBound60645 : packedSelected [0,1,2,5,7,11] rootPS < 2^1333 := by decide +kernel

def env60646 : List Nat := [2,4,8,16,32,16,128,21,163,1024,1174,1028,51,1029,42,8,1029,163,1025,43,1029,152,17,1079,186,17,1071,1029,1029,1190,20,1045,21,16,1029,163]

theorem envBound60646 : H12AffineFastState.Bounded env60646 := by
  intro p hp
  have h : env60646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60645_60646 : H12AffineEnvironment.transform 8 163 env60645 = env60646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 163 env60645 == env60646) = true)

theorem identity60646 : scanCanonicalize (H12AffineFastState.compose env60646 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 141) := by decide +kernel

theorem selectedBound60646 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env60647 : List Nat := [2,4,8,16,32,16,128,21,163,141,27,137,51,136,42,8,136,163,140,43,136,152,17,186,186,17,162,136,136,43,20,152,21,16,136,163]

theorem envBound60647 : H12AffineFastState.Bounded env60647 := by
  intro p hp
  have h : env60647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60646_60647 : H12AffineEnvironment.transform 9 141 env60646 = env60647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 141 env60646 == env60647) = true)

theorem identity60647 : scanCanonicalize (H12AffineFastState.compose env60647 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound60647 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env60648 : List Nat := [2,4,8,16,32,16,56,21,27,53,27,49,51,48,42,8,48,27,52,43,48,32,17,2,2,17,26,48,48,43,20,32,21,16,48,27]

theorem envBound60648 : H12AffineFastState.Bounded env60648 := by
  intro p hp
  have h : env60648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60647_60648 : H12AffineEnvironment.transform 6 56 env60647 = env60648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env60647 == env60648) = true)

theorem identity60648 : scanCanonicalize (H12AffineFastState.compose env60648 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound60648 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env60649 : List Nat := [2,4,8,10,32,10,34,15,1,47,1,43,41,42,42,8,42,1,46,43,42,32,11,2,2,11,0,42,42,43,14,32,15,10,42,1]

theorem envBound60649 : H12AffineFastState.Bounded env60649 := by
  intro p hp
  have h : env60649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60648_60649 : H12AffineEnvironment.transform 3 10 env60648 = env60649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env60648 == env60649) = true)

theorem identity60649 : scanCanonicalize (H12AffineFastState.compose env60649 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound60649 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60650 : List Nat := [2,4,8,10,11,10,9,15,1,4,1,0,2,1,1,8,1,1,5,0,1,11,11,2,2,11,0,1,1,0,14,11,15,10,1,1]

theorem envBound60650 : H12AffineFastState.Bounded env60650 := by
  intro p hp
  have h : env60650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60649_60650 : H12AffineEnvironment.transform 4 11 env60649 = env60650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env60649 == env60650) = true)

theorem identity60650 : scanCanonicalize (H12AffineFastState.compose env60650 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound60650 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60651 : List Nat := [2,4,4,6,7,6,5,3,1,4,1,0,2,1,1,4,1,1,5,0,1,7,7,2,2,7,0,1,1,0,2,7,3,6,1,1]

theorem envBound60651 : H12AffineFastState.Bounded env60651 := by
  intro p hp
  have h : env60651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60650_60651 : H12AffineEnvironment.transform 2 4 env60650 = env60651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env60650 == env60651) = true)

def env60652 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1345,262144,77935,32769,4097,46529,17,266385,70887,78895,77840,1296,74814,81227,365712,74799,256,308667,1344,79470]

theorem envBound60652 : H12AffineFastState.Bounded env60652 := by
  intro p hp
  have h : env60652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60633_60652 : H12AffineEnvironment.transform 13 1297 env60633 = env60652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env60633 == env60652) = true)

theorem identity60652 : scanCanonicalize (H12AffineFastState.compose env60652 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound60652 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env60653 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1345,262144,77935,13341,4097,477,17,266385,70887,78895,77840,1296,74814,81227,336012,74799,256,262567,1344,79470]

theorem envBound60653 : H12AffineFastState.Bounded env60653 := by
  intro p hp
  have h : env60653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60652_60653 : H12AffineEnvironment.transform 14 13340 env60652 = env60653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env60652 == env60653) = true)

def env60654 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1345,65664,77935,13341,4097,477,17,69649,70887,78895,77840,1296,74814,81227,8204,74799,256,65831,1344,79470]

theorem envBound60654 : H12AffineFastState.Bounded env60654 := by
  intro p hp
  have h : env60654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60653_60654 : H12AffineEnvironment.transform 17 65664 env60653 = env60654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env60653 == env60654) = true)

theorem identity60654 : scanCanonicalize (H12AffineFastState.compose env60654 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound60654 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env60655 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,8192,1297,9292,65536,1345,65664,73791,9293,81,477,17,65601,66743,74879,73792,1296,74814,77083,8204,74799,256,65831,1344,75326]

theorem envBound60655 : H12AffineFastState.Bounded env60655 := by
  intro p hp
  have h : env60655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60654_60655 : H12AffineEnvironment.transform 11 80 env60654 = env60655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env60654 == env60655) = true)

def env60656 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,0,8192,1297,9244,65536,1297,65664,73791,9245,1,397,17,65553,66743,74799,73744,1296,74814,77083,8204,74799,256,65831,1296,75326]

theorem envBound60656 : H12AffineFastState.Bounded env60656 := by
  intro p hp
  have h : env60656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60655_60656 : H12AffineEnvironment.transform 5 16 env60655 = env60656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env60655 == env60656) = true)

theorem identity60656 : scanCanonicalize (H12AffineFastState.compose env60656 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound60656 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60657 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,0,269,1297,1297,65536,1297,65664,65842,1296,1,397,17,65553,66743,66850,65821,1296,66867,68630,257,66850,256,65831,1296,67379]

theorem envBound60657 : H12AffineFastState.Bounded env60657 := by
  intro p hp
  have h : env60657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60656_60657 : H12AffineEnvironment.transform 12 269 env60656 = env60657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env60656 == env60657) = true)

theorem identity60657 : scanCanonicalize (H12AffineFastState.compose env60657 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound60657 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env60658 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,0,269,0,0,65536,0,65664,65842,1,1,397,17,65553,65958,65587,65821,1,65570,67847,257,65587,256,65831,1,66082]

theorem envBound60658 : H12AffineFastState.Bounded env60658 := by
  intro p hp
  have h : env60658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60657_60658 : H12AffineEnvironment.transform 9 273 env60657 = env60658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env60657 == env60658) = true)

theorem identity60658 : scanCanonicalize (H12AffineFastState.compose env60658 (packedSelected [0,1,3,5,7,8,11,12,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound60658 : packedSelected [0,1,3,5,7,8,11,12,15,17] rootPS < 2^1333 := by decide +kernel

def env60659 : List Nat := [2,4,8,16,32,16,128,256,512,273,0,0,269,0,0,65536,0,65664,65842,1,1,397,17,65553,65958,65587,65821,1,65570,65799,257,65587,256,65831,1,66082]

theorem envBound60659 : H12AffineFastState.Bounded env60659 := by
  intro p hp
  have h : env60659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60658_60659 : H12AffineEnvironment.transform 10 0 env60658 = env60659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env60658 == env60659) = true)

theorem identity60659 : scanCanonicalize (H12AffineFastState.compose env60659 (packedSelected [1,2,8,10,12,13] rootPS)) = affineNative (2^(8+1) ^^^ 270) := by decide +kernel

theorem selectedBound60659 : packedSelected [1,2,8,10,12,13] rootPS < 2^1333 := by decide +kernel

def env60660 : List Nat := [2,4,8,16,32,16,128,256,270,273,0,0,269,0,0,65536,0,65664,65842,1,1,397,17,65553,65958,65587,65821,1,65570,65799,257,65587,256,65831,1,65836]

theorem envBound60660 : H12AffineFastState.Bounded env60660 := by
  intro p hp
  have h : env60660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60659_60660 : H12AffineEnvironment.transform 8 270 env60659 = env60660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 270 env60659 == env60660) = true)

theorem identity60660 : scanCanonicalize (H12AffineFastState.compose env60660 (packedSelected [1,3,5,8,11,18] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound60660 : packedSelected [1,3,5,8,11,18] rootPS < 2^1333 := by decide +kernel

def env60661 : List Nat := [2,4,8,16,32,16,128,14,0,31,0,0,3,0,0,65536,0,65664,65596,1,1,131,17,65553,65704,65587,65555,1,65570,65545,15,65587,14,65577,1,65570]

theorem envBound60661 : H12AffineFastState.Bounded env60661 := by
  intro p hp
  have h : env60661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60660_60661 : H12AffineEnvironment.transform 7 14 env60660 = env60661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env60660 == env60661) = true)

theorem identity60661 : scanCanonicalize (H12AffineFastState.compose env60661 (packedSelected [3,8] rootPS)) = affineNative (2^(15+1) ^^^ 155) := by decide +kernel

theorem selectedBound60661 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env60662 : List Nat := [2,4,8,16,32,16,128,14,0,31,0,0,3,0,0,155,0,27,167,1,1,131,17,138,51,168,136,1,185,146,15,168,14,178,1,185]

theorem envBound60662 : H12AffineFastState.Bounded env60662 := by
  intro p hp
  have h : env60662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60661_60662 : H12AffineEnvironment.transform 15 155 env60661 = env60662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 155 env60661 == env60662) = true)

theorem identity60662 : scanCanonicalize (H12AffineFastState.compose env60662 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound60662 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env60663 : List Nat := [2,4,8,16,32,16,18,14,0,31,0,0,3,0,0,9,0,27,53,1,1,17,17,24,51,58,26,1,43,0,15,58,14,32,1,43]

theorem envBound60663 : H12AffineFastState.Bounded env60663 := by
  intro p hp
  have h : env60663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60662_60663 : H12AffineEnvironment.transform 6 18 env60662 = env60663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env60662 == env60663) = true)

theorem identity60663 : scanCanonicalize (H12AffineFastState.compose env60663 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound60663 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60664 : List Nat := [2,4,8,10,32,10,8,14,0,5,0,0,3,0,0,9,0,1,47,1,1,11,11,2,41,32,0,1,43,0,15,32,14,32,1,43]

theorem envBound60664 : H12AffineFastState.Bounded env60664 := by
  intro p hp
  have h : env60664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60663_60664 : H12AffineEnvironment.transform 3 10 env60663 = env60664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env60663 == env60664) = true)

theorem identity60664 : scanCanonicalize (H12AffineFastState.compose env60664 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound60664 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env60665 : List Nat := [2,4,5,7,32,7,5,3,0,5,0,0,3,0,0,4,0,1,34,1,1,6,6,2,36,32,0,1,38,0,2,32,3,32,1,38]

theorem envBound60665 : H12AffineFastState.Bounded env60665 := by
  intro p hp
  have h : env60665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60664_60665 : H12AffineEnvironment.transform 2 5 env60664 = env60665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env60664 == env60665) = true)

def env60666 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1,8192,1297,9245,65536,1296,65664,73791,9244,0,396,17,65552,66743,74798,73745,1296,74814,77083,8204,74799,256,65831,1297,75326]

theorem envBound60666 : H12AffineFastState.Bounded env60666 := by
  intro p hp
  have h : env60666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60655_60666 : H12AffineEnvironment.transform 5 17 env60655 = env60666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env60655 == env60666) = true)

theorem identity60666 : scanCanonicalize (H12AffineFastState.compose env60666 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 1330) := by decide +kernel

theorem selectedBound60666 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60667 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1,8192,1297,9245,1330,1296,1458,9485,9244,0,396,17,1314,389,8476,9507,1296,8460,10281,8204,8477,256,1045,1297,8972]

theorem envBound60667 : H12AffineFastState.Bounded env60667 := by
  intro p hp
  have h : env60667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60666_60667 : H12AffineEnvironment.transform 15 1330 env60666 = env60667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1330 env60666 == env60667) = true)

theorem identity60667 : scanCanonicalize (H12AffineFastState.compose env60667 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound60667 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env60668 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,1,8192,1,8461,34,0,162,8221,8460,0,396,17,50,389,8476,8243,0,8460,10281,8204,8477,256,261,1,8972]

theorem envBound60668 : H12AffineFastState.Bounded env60668 := by
  intro p hp
  have h : env60668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60667_60668 : H12AffineEnvironment.transform 9 272 env60667 = env60668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env60667 == env60668) = true)

theorem identity60668 : scanCanonicalize (H12AffineFastState.compose env60668 (packedSelected [0,2,7,10,12,15,17,18,19] rootPS)) = affineNative (2^(10+1) ^^^ 940) := by decide +kernel

theorem selectedBound60668 : packedSelected [0,2,7,10,12,15,17,18,19] rootPS < 2^1333 := by decide +kernel

def env60669 : List Nat := [2,4,8,16,32,17,128,256,512,272,940,1,8192,1,8461,34,0,162,8221,8460,0,396,17,50,389,8476,8243,0,8460,9093,8204,8477,256,261,1,8972]

theorem envBound60669 : H12AffineFastState.Bounded env60669 := by
  intro p hp
  have h : env60669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60668_60669 : H12AffineEnvironment.transform 10 940 env60668 = env60669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 940 env60668 == env60669) = true)

theorem identity60669 : scanCanonicalize (H12AffineFastState.compose env60669 (packedSelected [1,8,13] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound60669 : packedSelected [1,8,13] rootPS < 2^1333 := by decide +kernel

def env60670 : List Nat := [2,4,8,16,32,17,18,256,512,272,830,1,8192,1,8461,34,0,48,8221,8460,0,286,17,50,279,8476,8243,0,8460,8983,8204,8477,256,261,1,8972]

theorem envBound60670 : H12AffineFastState.Bounded env60670 := by
  intro p hp
  have h : env60670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60669_60670 : H12AffineEnvironment.transform 6 18 env60669 = env60670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env60669 == env60670) = true)

theorem identity60670 : scanCanonicalize (H12AffineFastState.compose env60670 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(12+1) ^^^ 537) := by decide +kernel

theorem selectedBound60670 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env60671 : List Nat := [2,4,8,16,32,17,18,256,512,272,830,1,537,1,788,34,0,48,516,789,0,286,17,50,279,773,554,0,789,270,533,772,256,261,1,277]

theorem envBound60671 : H12AffineFastState.Bounded env60671 := by
  intro p hp
  have h : env60671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60670_60671 : H12AffineEnvironment.transform 12 537 env60670 = env60671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 537 env60670 == env60671) = true)

theorem identity60671 : scanCanonicalize (H12AffineFastState.compose env60671 (packedSelected [1,3,4,9,10,11] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound60671 : packedSelected [1,3,4,9,10,11] rootPS < 2^1333 := by decide +kernel

def env60672 : List Nat := [2,4,8,16,32,17,18,21,512,5,555,1,537,1,513,34,0,48,516,512,0,11,17,50,2,528,554,0,512,27,533,529,21,16,1,0]

theorem envBound60672 : H12AffineFastState.Bounded env60672 := by
  intro p hp
  have h : env60672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60671_60672 : H12AffineEnvironment.transform 7 21 env60671 = env60672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env60671 == env60672) = true)

theorem identity60672 : scanCanonicalize (H12AffineFastState.compose env60672 (packedSelected [3,5] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound60672 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env60673 : List Nat := [2,4,8,16,32,17,18,21,48,5,27,1,41,1,49,34,0,48,52,48,0,11,17,50,2,32,26,0,48,27,37,33,21,16,1,0]

theorem envBound60673 : H12AffineFastState.Bounded env60673 := by
  intro p hp
  have h : env60673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60672_60673 : H12AffineEnvironment.transform 8 48 env60672 = env60673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env60672 == env60673) = true)

theorem identity60673 : scanCanonicalize (H12AffineFastState.compose env60673 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound60673 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60674 : List Nat := [2,4,8,16,11,17,18,21,27,5,27,1,2,1,26,9,0,27,31,27,0,11,17,25,2,11,26,0,27,27,14,10,21,16,1,0]

theorem envBound60674 : H12AffineFastState.Bounded env60674 := by
  intro p hp
  have h : env60674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60673_60674 : H12AffineEnvironment.transform 4 11 env60673 = env60674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env60673 == env60674) = true)

theorem identity60674 : scanCanonicalize (H12AffineFastState.compose env60674 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound60674 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env60675 : List Nat := [2,4,8,10,11,11,8,15,1,5,1,1,2,1,0,9,0,1,5,1,0,11,11,3,2,11,0,0,1,1,14,10,15,10,1,0]

theorem envBound60675 : H12AffineFastState.Bounded env60675 := by
  intro p hp
  have h : env60675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60674_60675 : H12AffineEnvironment.transform 3 10 env60674 = env60675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env60674 == env60675) = true)

theorem identity60675 : scanCanonicalize (H12AffineFastState.compose env60675 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound60675 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60676 : List Nat := [2,1,8,10,11,11,8,10,1,0,1,1,2,1,0,9,0,1,0,1,0,11,11,3,2,11,0,0,1,1,11,10,10,10,1,0]

theorem envBound60676 : H12AffineFastState.Bounded env60676 := by
  intro p hp
  have h : env60676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60675_60676 : H12AffineEnvironment.transform 1 1 env60675 = env60676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env60675 == env60676) = true)

theorem identity60676 : scanCanonicalize (H12AffineFastState.compose env60676 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound60676 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env60677 : List Nat := [2,1,1,3,2,2,1,3,1,0,1,1,2,1,0,0,0,1,0,1,0,2,2,3,2,2,0,0,1,1,2,3,3,3,1,0]

theorem envBound60677 : H12AffineFastState.Bounded env60677 := by
  intro p hp
  have h : env60677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60676_60677 : H12AffineEnvironment.transform 2 1 env60676 = env60677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env60676 == env60677) = true)

theorem identity60677 : scanCanonicalize (H12AffineFastState.compose env60677 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound60677 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env60678 : List Nat := [1,1,1,0,1,1,1,0,1,0,1,1,1,1,0,0,0,1,0,1,0,1,1,0,1,1,0,0,1,1,1,0,0,0,1,0]

theorem envBound60678 : H12AffineFastState.Bounded env60678 := by
  intro p hp
  have h : env60678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60677_60678 : H12AffineEnvironment.transform 0 1 env60677 = env60678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env60677 == env60678) = true)

def env60679 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1345,65665,77935,13341,4097,477,17,69648,70887,78895,77840,1296,74814,81227,8205,74799,256,65830,1344,79470]

theorem envBound60679 : H12AffineFastState.Bounded env60679 := by
  intro p hp
  have h : env60679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60653_60679 : H12AffineEnvironment.transform 17 65665 env60653 = env60679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env60653 == env60679) = true)

theorem identity60679 : scanCanonicalize (H12AffineFastState.compose env60679 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound60679 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env60680 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,8192,0,12557,65536,80,65665,77935,12556,4097,477,17,69648,70134,78142,77840,1,74031,79962,8205,74046,256,65830,81,78719]

theorem envBound60680 : H12AffineFastState.Bounded env60680 := by
  intro p hp
  have h : env60680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60679_60680 : H12AffineEnvironment.transform 9 273 env60679 = env60680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env60679 == env60680) = true)

def env60681 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,4096,8192,0,12557,65536,0,65665,77887,12556,4097,397,17,69648,70054,78142,77840,1,74031,79882,8205,74046,256,65830,1,78639]

theorem envBound60681 : H12AffineFastState.Bounded env60681 := by
  intro p hp
  have h : env60681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60680_60681 : H12AffineEnvironment.transform 5 16 env60680 = env60681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env60680 == env60681) = true)

theorem identity60681 : scanCanonicalize (H12AffineFastState.compose env60681 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound60681 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60682 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,4096,268,0,4097,65536,0,65665,69939,4096,4097,397,17,69648,70054,69682,69916,1,65571,71942,257,65586,256,65830,1,70179]

theorem envBound60682 : H12AffineFastState.Bounded env60682 := by
  intro p hp
  have h : env60682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60681_60682 : H12AffineEnvironment.transform 12 268 env60681 = env60682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env60681 == env60682) = true)

theorem identity60682 : scanCanonicalize (H12AffineFastState.compose env60682 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound60682 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env60683 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,4096,268,0,4097,35,0,162,4368,4096,4097,397,17,4147,4485,4113,4415,1,0,6437,257,17,256,261,1,4608]

theorem envBound60683 : H12AffineFastState.Bounded env60683 := by
  intro p hp
  have h : env60683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60682_60683 : H12AffineEnvironment.transform 15 35 env60682 = env60683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env60682 == env60683) = true)

theorem identity60683 : scanCanonicalize (H12AffineFastState.compose env60683 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 2988) := by decide +kernel

theorem selectedBound60683 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env60684 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,2988,268,0,2989,35,0,162,2748,2988,2989,397,17,2975,2601,3005,2707,1,0,649,257,17,256,261,1,2476]

theorem envBound60684 : H12AffineFastState.Bounded env60684 := by
  intro p hp
  have h : env60684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60683_60684 : H12AffineEnvironment.transform 11 2988 env60683 = env60684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2988 env60683 == env60684) = true)

theorem identity60684 : scanCanonicalize (H12AffineFastState.compose env60684 (packedSelected [0,1,5,7,11,12,15,17] rootPS)) = affineNative (2^(7+1) ^^^ 63) := by decide +kernel

theorem selectedBound60684 : packedSelected [0,1,5,7,11,12,15,17] rootPS < 2^1333 := by decide +kernel

def env60685 : List Nat := [2,4,8,16,32,16,128,63,512,46,2048,2707,51,0,2706,35,0,162,2748,2707,2706,178,17,2720,2601,2690,2707,1,0,649,62,17,63,58,1,2195]

theorem envBound60685 : H12AffineFastState.Bounded env60685 := by
  intro p hp
  have h : env60685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60684_60685 : H12AffineEnvironment.transform 7 63 env60684 = env60685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 63 env60684 == env60685) = true)

theorem identity60685 : scanCanonicalize (H12AffineFastState.compose env60685 (packedSelected [1,5,11,18] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound60685 : packedSelected [1,5,11,18] rootPS < 2^1333 := by decide +kernel

def env60686 : List Nat := [2,4,8,16,32,16,9,63,512,46,2048,2586,51,0,2587,35,0,43,2613,2586,2587,59,17,2601,2601,2571,2586,1,0,512,62,17,63,58,1,2074]

theorem envBound60686 : H12AffineFastState.Bounded env60686 := by
  intro p hp
  have h : env60686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60685_60686 : H12AffineEnvironment.transform 6 9 env60685 = env60686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env60685 == env60686) = true)

theorem identity60686 : scanCanonicalize (H12AffineFastState.compose env60686 (packedSelected [0,1,2,3,4,7,9,11] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound60686 : packedSelected [0,1,2,3,4,7,9,11] rootPS < 2^1333 := by decide +kernel

def env60687 : List Nat := [2,4,8,16,32,16,9,63,0,46,2048,2074,51,0,2075,35,0,43,2101,2074,2075,59,17,2089,2089,2059,2074,1,0,0,62,17,63,58,1,2074]

theorem envBound60687 : H12AffineFastState.Bounded env60687 := by
  intro p hp
  have h : env60687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60686_60687 : H12AffineEnvironment.transform 8 0 env60686 = env60687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env60686 == env60687) = true)

theorem identity60687 : scanCanonicalize (H12AffineFastState.compose env60687 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound60687 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env60688 : List Nat := [2,4,8,16,32,16,9,63,0,46,0,26,51,0,27,35,0,43,53,26,27,59,17,41,41,11,26,1,0,0,62,17,63,58,1,26]

theorem envBound60688 : H12AffineFastState.Bounded env60688 := by
  intro p hp
  have h : env60688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60687_60688 : H12AffineEnvironment.transform 10 0 env60687 = env60688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env60687 == env60688) = true)

theorem identity60688 : scanCanonicalize (H12AffineFastState.compose env60688 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound60688 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env60689 : List Nat := [2,4,8,10,32,10,9,37,0,46,0,0,41,0,1,35,0,43,47,0,1,33,11,41,41,11,0,1,0,0,36,11,37,32,1,0]

theorem envBound60689 : H12AffineFastState.Bounded env60689 := by
  intro p hp
  have h : env60689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60688_60689 : H12AffineEnvironment.transform 3 10 env60688 = env60689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env60688 == env60689) = true)

def env60690 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,4096,8192,0,12557,65536,1,65665,77886,12556,4097,396,17,69648,70055,78142,77840,1,74031,79883,8205,74046,256,65830,0,78638]

theorem envBound60690 : H12AffineFastState.Bounded env60690 := by
  intro p hp
  have h : env60690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60680_60690 : H12AffineEnvironment.transform 5 17 env60680 = env60690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env60680 == env60690) = true)

theorem identity60690 : scanCanonicalize (H12AffineFastState.compose env60690 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 4131) := by decide +kernel

theorem selectedBound60690 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60691 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,4096,8192,0,12557,4131,1,4258,8221,12556,4097,396,17,51,388,8477,8243,1,12556,10280,8205,12573,256,4357,0,8973]

theorem envBound60691 : H12AffineFastState.Bounded env60691 := by
  intro p hp
  have h : env60691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60690_60691 : H12AffineEnvironment.transform 15 4131 env60690 = env60691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4131 env60690 == env60691) = true)

theorem identity60691 : scanCanonicalize (H12AffineFastState.compose env60691 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(12+1) ^^^ 4365) := by decide +kernel

theorem selectedBound60691 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env60692 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,4096,4365,0,0,4131,1,4258,4368,1,4097,396,17,51,388,4112,4414,1,1,6437,4352,16,256,4357,0,4608]

theorem envBound60692 : H12AffineFastState.Bounded env60692 := by
  intro p hp
  have h : env60692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60691_60692 : H12AffineEnvironment.transform 12 4365 env60691 = env60692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4365 env60691 == env60692) = true)

theorem identity60692 : scanCanonicalize (H12AffineFastState.compose env60692 (packedSelected [0,2,3,7,8,10,12,15,17,18,19] rootPS)) = affineNative (2^(10+1) ^^^ 925) := by decide +kernel

theorem selectedBound60692 : packedSelected [0,2,3,7,8,10,12,15,17,18,19] rootPS < 2^1333 := by decide +kernel

def env60693 : List Nat := [2,4,8,16,32,17,128,256,512,273,925,4096,4365,0,0,4131,1,4258,4368,1,4097,396,17,51,388,4112,4414,1,1,4792,4352,16,256,4357,0,4608]

theorem envBound60693 : H12AffineFastState.Bounded env60693 := by
  intro p hp
  have h : env60693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60692_60693 : H12AffineEnvironment.transform 10 925 env60692 = env60693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 925 env60692 == env60693) = true)

theorem identity60693 : scanCanonicalize (H12AffineFastState.compose env60693 (packedSelected [0,1,2,3,7,11,12,13,15,17] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound60693 : packedSelected [0,1,2,3,7,11,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env60694 : List Nat := [2,4,8,16,32,17,18,256,512,273,783,4096,4365,0,0,4131,1,4144,4368,1,4097,286,17,51,278,4112,4414,1,1,4650,4352,16,256,4357,0,4608]

theorem envBound60694 : H12AffineFastState.Bounded env60694 := by
  intro p hp
  have h : env60694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60693_60694 : H12AffineEnvironment.transform 6 18 env60693 = env60694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env60693 == env60694) = true)

theorem identity60694 : scanCanonicalize (H12AffineFastState.compose env60694 (packedSelected [0,1,2,3,5,7,8,10,11,12] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound60694 : packedSelected [0,1,2,3,5,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env60695 : List Nat := [2,4,8,16,32,17,18,256,42,273,293,4096,4365,0,0,4131,1,4144,4368,1,4097,286,17,51,278,4112,4414,1,1,4096,4352,16,256,4357,0,4138]

theorem envBound60695 : H12AffineFastState.Bounded env60695 := by
  intro p hp
  have h : env60695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60694_60695 : H12AffineEnvironment.transform 8 42 env60694 = env60695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env60694 == env60695) = true)

theorem identity60695 : scanCanonicalize (H12AffineFastState.compose env60695 (packedSelected [2,5,7,8,9] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound60695 : packedSelected [2,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env60696 : List Nat := [2,4,8,16,10,17,18,256,0,273,271,4096,4365,0,0,4105,1,4122,4368,1,4097,286,17,25,278,4112,4372,1,1,4096,4352,16,256,4357,0,4096]

theorem envBound60696 : H12AffineFastState.Bounded env60696 := by
  intro p hp
  have h : env60696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60695_60696 : H12AffineEnvironment.transform 4 10 env60695 = env60696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env60695 == env60696) = true)

theorem identity60696 : scanCanonicalize (H12AffineFastState.compose env60696 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound60696 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60697 : List Nat := [2,4,8,16,10,17,18,15,0,30,0,4096,4098,0,0,4105,1,4122,4127,1,4097,17,17,25,25,4112,4123,1,1,4096,4111,16,15,4106,0,4096]

theorem envBound60697 : H12AffineFastState.Bounded env60697 := by
  intro p hp
  have h : env60697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60696_60697 : H12AffineEnvironment.transform 7 15 env60696 = env60697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env60696 == env60697) = true)

theorem identity60697 : scanCanonicalize (H12AffineFastState.compose env60697 (packedSelected [3,5] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound60697 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env60698 : List Nat := [2,4,8,10,10,11,8,15,0,4,0,4096,4098,0,0,4105,1,4096,4101,1,4097,11,11,3,3,4106,4097,1,1,4096,4111,10,15,4106,0,4096]

theorem envBound60698 : H12AffineFastState.Bounded env60698 := by
  intro p hp
  have h : env60698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60697_60698 : H12AffineEnvironment.transform 3 10 env60697 = env60698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env60697 == env60698) = true)

def env60699 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16465,262144,95614,32769,4097,61648,16,284032,86518,94527,77841,1297,74814,96346,381313,90431,256,308666,1344,95103]

theorem envBound60699 : H12AffineFastState.Bounded env60699 := by
  intro p hp
  have h : env60699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60632_60699 : H12AffineEnvironment.transform 16 16465 env60632 = env60699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16465 env60632 == env60699) = true)

def env60700 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1345,262144,77934,32769,4097,46528,16,266384,70886,78895,77841,1297,74814,81226,365713,74799,256,308666,1344,79471]

theorem envBound60700 : H12AffineFastState.Bounded env60700 := by
  intro p hp
  have h : env60700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60699_60700 : H12AffineEnvironment.transform 13 1296 env60699 = env60700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env60699 == env60700) = true)

theorem identity60700 : scanCanonicalize (H12AffineFastState.compose env60700 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound60700 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env60701 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1345,262144,77934,13341,4097,476,16,266384,70886,78895,77841,1297,74814,81226,336013,74799,256,262566,1344,79471]

theorem envBound60701 : H12AffineFastState.Bounded env60701 := by
  intro p hp
  have h : env60701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60700_60701 : H12AffineEnvironment.transform 14 13340 env60700 = env60701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env60700 == env60701) = true)

def env60702 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1345,65664,77934,13341,4097,476,16,69648,70886,78895,77841,1297,74814,81226,8205,74799,256,65830,1344,79471]

theorem envBound60702 : H12AffineFastState.Bounded env60702 := by
  intro p hp
  have h : env60702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60701_60702 : H12AffineEnvironment.transform 17 65664 env60701 = env60702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env60701 == env60702) = true)

theorem identity60702 : scanCanonicalize (H12AffineFastState.compose env60702 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound60702 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env60703 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,25,1296,5125,65536,1345,65664,69751,5124,4097,476,16,69648,70886,70710,69640,1297,66599,73043,20,66614,256,65830,1344,71286]

theorem envBound60703 : H12AffineFastState.Bounded env60703 := by
  intro p hp
  have h : env60703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60702_60703 : H12AffineEnvironment.transform 12 25 env60702 = env60703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env60702 == env60703) = true)

def env60704 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,25,1296,5125,65536,1297,65664,69671,5124,4097,396,16,69648,70838,70710,69640,1297,66599,72963,20,66614,256,65830,1296,71206]

theorem envBound60704 : H12AffineFastState.Bounded env60704 := by
  intro p hp
  have h : env60704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60703_60704 : H12AffineEnvironment.transform 5 16 env60703 = env60704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env60703 == env60704) = true)

theorem identity60704 : scanCanonicalize (H12AffineFastState.compose env60704 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 5427) := by decide +kernel

theorem selectedBound60704 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60705 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,25,1296,5125,5427,1297,5555,1300,5124,4097,396,16,1315,389,261,1339,1297,4372,2096,20,4357,256,5141,1296,789]

theorem envBound60705 : H12AffineFastState.Bounded env60705 := by
  intro p hp
  have h : env60705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60704_60705 : H12AffineEnvironment.transform 15 5427 env60704 = env60705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5427 env60704 == env60705) = true)

theorem identity60705 : scanCanonicalize (H12AffineFastState.compose env60705 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound60705 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env60706 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1029,25,1296,0,310,1297,438,1300,1,1028,396,16,1315,389,261,1339,1297,1297,2096,20,1280,256,16,1296,789]

theorem envBound60706 : H12AffineFastState.Bounded env60706 := by
  intro p hp
  have h : env60706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60705_60706 : H12AffineEnvironment.transform 11 1029 env60705 = env60706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env60705 == env60706) = true)

theorem identity60706 : scanCanonicalize (H12AffineFastState.compose env60706 (packedSelected [0,1,2,5,7,10,11,19] rootPS)) = affineNative (2^(9+1) ^^^ 386) := by decide +kernel

theorem selectedBound60706 : packedSelected [0,1,2,5,7,10,11,19] rootPS < 2^1333 := by decide +kernel

def env60707 : List Nat := [2,4,8,16,32,16,128,256,512,386,2048,391,25,146,0,310,147,438,150,1,390,396,16,161,389,261,185,147,147,2096,20,130,256,16,146,789]

theorem envBound60707 : H12AffineFastState.Bounded env60707 := by
  intro p hp
  have h : env60707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60706_60707 : H12AffineEnvironment.transform 9 386 env60706 = env60707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 386 env60706 == env60707) = true)

theorem identity60707 : scanCanonicalize (H12AffineFastState.compose env60707 (packedSelected [3,5,10,12,13] rootPS)) = affineNative (2^(7+1) ^^^ 134) := by decide +kernel

theorem selectedBound60707 : packedSelected [3,5,10,12,13] rootPS < 2^1333 := by decide +kernel

def env60708 : List Nat := [2,4,8,16,32,16,128,134,512,4,2048,1,25,146,0,176,147,48,150,1,0,10,16,161,3,131,185,147,147,2096,20,130,134,16,146,659]

theorem envBound60708 : H12AffineFastState.Bounded env60708 := by
  intro p hp
  have h : env60708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60707_60708 : H12AffineEnvironment.transform 7 134 env60707 = env60708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 134 env60707 == env60708) = true)

theorem identity60708 : scanCanonicalize (H12AffineFastState.compose env60708 (packedSelected [1,2,5] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound60708 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env60709 : List Nat := [2,4,8,16,32,16,128,134,512,4,26,1,25,146,0,176,147,48,150,1,0,10,16,161,3,131,185,147,147,42,20,130,134,16,146,659]

theorem envBound60709 : H12AffineFastState.Bounded env60709 := by
  intro p hp
  have h : env60709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60708_60709 : H12AffineEnvironment.transform 10 26 env60708 = env60709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env60708 == env60709) = true)

theorem identity60709 : scanCanonicalize (H12AffineFastState.compose env60709 (packedSelected [0,1,7] rootPS)) = affineNative (2^(8+1) ^^^ 143) := by decide +kernel

theorem selectedBound60709 : packedSelected [0,1,7] rootPS < 2^1333 := by decide +kernel

def env60710 : List Nat := [2,4,8,16,32,16,128,134,143,4,26,1,25,146,0,176,147,48,150,1,0,10,16,161,3,131,185,147,147,42,20,130,134,16,146,28]

theorem envBound60710 : H12AffineFastState.Bounded env60710 := by
  intro p hp
  have h : env60710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60709_60710 : H12AffineEnvironment.transform 8 143 env60709 = env60710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 143 env60709 == env60710) = true)

theorem identity60710 : scanCanonicalize (H12AffineFastState.compose env60710 (packedSelected [3,8] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound60710 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env60711 : List Nat := [2,3,8,16,32,16,128,129,136,3,26,1,25,146,0,176,147,48,145,1,0,10,16,161,3,131,185,147,147,42,19,130,129,16,146,27]

theorem envBound60711 : H12AffineFastState.Bounded env60711 := by
  intro p hp
  have h : env60711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60710_60711 : H12AffineEnvironment.transform 1 3 env60710 = env60711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env60710 == env60711) = true)

theorem identity60711 : scanCanonicalize (H12AffineFastState.compose env60711 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound60711 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env60712 : List Nat := [2,3,8,16,32,16,18,19,26,3,26,1,25,0,0,34,1,48,3,1,0,10,16,51,3,17,43,1,1,42,19,16,19,16,0,27]

theorem envBound60712 : H12AffineFastState.Bounded env60712 := by
  intro p hp
  have h : env60712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60711_60712 : H12AffineEnvironment.transform 6 18 env60711 = env60712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env60711 == env60712) = true)

theorem identity60712 : scanCanonicalize (H12AffineFastState.compose env60712 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound60712 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env60713 : List Nat := [2,3,2,16,32,16,18,19,16,3,16,1,19,0,0,34,1,48,3,1,0,0,16,51,3,17,33,1,1,32,19,16,19,16,0,17]

theorem envBound60713 : H12AffineFastState.Bounded env60713 := by
  intro p hp
  have h : env60713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60712_60713 : H12AffineEnvironment.transform 2 2 env60712 = env60713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env60712 == env60713) = true)

theorem identity60713 : scanCanonicalize (H12AffineFastState.compose env60713 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound60713 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env60714 : List Nat := [1,0,1,16,32,16,17,16,16,0,16,1,16,0,0,33,1,48,0,1,0,0,16,48,0,17,33,1,1,32,16,16,16,16,0,17]

theorem envBound60714 : H12AffineFastState.Bounded env60714 := by
  intro p hp
  have h : env60714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60713_60714 : H12AffineEnvironment.transform 0 1 env60713 = env60714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env60713 == env60714) = true)

theorem identity60714 : scanCanonicalize (H12AffineFastState.compose env60714 (packedSelected [0,9] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound60714 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env60715 : List Nat := [1,0,1,16,17,16,17,16,16,0,16,1,16,0,0,16,1,1,0,1,0,0,16,1,0,17,16,1,1,17,16,16,16,16,0,17]

theorem envBound60715 : H12AffineFastState.Bounded env60715 := by
  intro p hp
  have h : env60715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60714_60715 : H12AffineEnvironment.transform 4 17 env60714 = env60715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env60714 == env60715) = true)

theorem identity60715 : scanCanonicalize (H12AffineFastState.compose env60715 (packedSelected [10] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound60715 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env60716 : List Nat := [1,0,1,0,1,0,1,0,0,0,0,1,0,0,0,0,1,1,0,1,0,0,0,1,0,1,0,1,1,1,0,0,0,0,0,1]

theorem envBound60716 : H12AffineFastState.Bounded env60716 := by
  intro p hp
  have h : env60716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60715_60716 : H12AffineEnvironment.transform 3 0 env60715 = env60716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env60715 == env60716) = true)

def env60717 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,25,1296,5125,65536,1296,65664,69670,5124,4097,397,16,69648,70839,70710,69640,1297,66599,72962,20,66614,256,65830,1297,71207]

theorem envBound60717 : H12AffineFastState.Bounded env60717 := by
  intro p hp
  have h : env60717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60703_60717 : H12AffineEnvironment.transform 5 17 env60703 = env60717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env60703 == env60717) = true)

theorem identity60717 : scanCanonicalize (H12AffineFastState.compose env60717 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound60717 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60718 : List Nat := [2,4,8,16,32,17,128,20,512,1024,2048,4096,25,1028,5125,65536,1028,65664,69670,5124,4097,153,16,69648,70839,70710,69640,1029,66599,72726,20,66614,20,65586,1029,71207]

theorem envBound60718 : H12AffineFastState.Bounded env60718 := by
  intro p hp
  have h : env60718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60717_60718 : H12AffineEnvironment.transform 7 20 env60717 = env60718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env60717 == env60718) = true)

theorem identity60718 : scanCanonicalize (H12AffineFastState.compose env60718 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound60718 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env60719 : List Nat := [2,4,8,16,32,17,128,20,512,1024,2048,4096,25,1028,5125,35,1028,163,4101,5124,4097,153,16,4147,5268,5141,4139,1029,1028,7221,20,1045,20,17,1029,5636]

theorem envBound60719 : H12AffineFastState.Bounded env60719 := by
  intro p hp
  have h : env60719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60718_60719 : H12AffineEnvironment.transform 15 35 env60718 = env60719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env60718 == env60719) = true)

theorem identity60719 : scanCanonicalize (H12AffineFastState.compose env60719 (packedSelected [10,11,13,17,18,19] rootPS)) = affineNative (2^(11+1) ^^^ 2075) := by decide +kernel

theorem selectedBound60719 : packedSelected [10,11,13,17,18,19] rootPS < 2^1333 := by decide +kernel

def env60720 : List Nat := [2,4,8,16,32,17,128,20,512,1024,2048,2075,25,1028,3102,35,1028,163,2078,3103,2074,153,16,2088,3215,3086,2096,1029,1028,1070,20,1045,20,17,1029,3615]

theorem envBound60720 : H12AffineFastState.Bounded env60720 := by
  intro p hp
  have h : env60720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60719_60720 : H12AffineEnvironment.transform 11 2075 env60719 = env60720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2075 env60719 == env60720) = true)

theorem identity60720 : scanCanonicalize (H12AffineFastState.compose env60720 (packedSelected [0,7,11,12,13,15] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound60720 : packedSelected [0,7,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env60721 : List Nat := [2,4,8,16,32,17,35,20,512,1024,2048,2075,25,1028,3102,35,1028,0,2078,3103,2074,58,16,2088,3116,3086,2096,1029,1028,1070,20,1045,20,17,1029,3615]

theorem envBound60721 : H12AffineFastState.Bounded env60721 := by
  intro p hp
  have h : env60721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60720_60721 : H12AffineEnvironment.transform 6 35 env60720 = env60721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env60720 == env60721) = true)

theorem identity60721 : scanCanonicalize (H12AffineFastState.compose env60721 (packedSelected [4,9] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound60721 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env60722 : List Nat := [2,4,8,16,32,17,35,20,512,1024,42,49,25,1028,1076,35,1028,0,52,1077,48,58,16,2,1030,1060,26,1029,1028,1070,20,1045,20,17,1029,1589]

theorem envBound60722 : H12AffineFastState.Bounded env60722 := by
  intro p hp
  have h : env60722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60721_60722 : H12AffineEnvironment.transform 10 42 env60721 = env60722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env60721 == env60722) = true)

theorem identity60722 : scanCanonicalize (H12AffineFastState.compose env60722 (packedSelected [2,3,8] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound60722 : packedSelected [2,3,8] rootPS < 2^1333 := by decide +kernel

def env60723 : List Nat := [2,4,8,16,32,17,35,20,43,1024,42,49,25,1028,1076,35,1028,0,52,1077,48,58,16,2,1030,1060,26,1029,1028,1070,20,1045,20,17,1029,1054]

theorem envBound60723 : H12AffineFastState.Bounded env60723 := by
  intro p hp
  have h : env60723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60722_60723 : H12AffineEnvironment.transform 8 43 env60722 = env60723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env60722 == env60723) = true)

theorem identity60723 : scanCanonicalize (H12AffineFastState.compose env60723 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound60723 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env60724 : List Nat := [2,4,8,16,11,17,8,20,0,1024,1,26,25,1028,1055,8,1028,0,31,1054,27,17,16,2,1030,1039,26,1029,1028,1029,20,1045,20,17,1029,1054]

theorem envBound60724 : H12AffineFastState.Bounded env60724 := by
  intro p hp
  have h : env60724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60723_60724 : H12AffineEnvironment.transform 4 11 env60723 = env60724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env60723 == env60724) = true)

theorem identity60724 : scanCanonicalize (H12AffineFastState.compose env60724 (packedSelected [1,2,5] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound60724 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env60725 : List Nat := [2,4,8,10,11,11,8,14,0,1024,1,0,3,1028,1029,8,1028,0,5,1028,1,11,10,2,1030,1039,0,1029,1028,1029,14,1039,14,11,1029,1028]

theorem envBound60725 : H12AffineFastState.Bounded env60725 := by
  intro p hp
  have h : env60725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60724_60725 : H12AffineEnvironment.transform 3 10 env60724 = env60725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env60724 == env60725) = true)

theorem identity60725 : scanCanonicalize (H12AffineFastState.compose env60725 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound60725 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60726 : List Nat := [2,4,8,10,11,11,8,14,0,5,1,0,3,1,0,8,1,0,5,1,1,11,10,2,3,10,0,0,1,0,14,10,14,11,0,1]

theorem envBound60726 : H12AffineFastState.Bounded env60726 := by
  intro p hp
  have h : env60726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60725_60726 : H12AffineEnvironment.transform 9 5 env60725 = env60726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env60725 == env60726) = true)

theorem identity60726 : scanCanonicalize (H12AffineFastState.compose env60726 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound60726 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60727 : List Nat := [2,4,6,4,5,5,6,0,0,5,1,0,3,1,0,6,1,0,5,1,1,5,4,2,3,4,0,0,1,0,0,4,0,5,0,1]

theorem envBound60727 : H12AffineFastState.Bounded env60727 := by
  intro p hp
  have h : env60727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60726_60727 : H12AffineEnvironment.transform 2 6 env60726 = env60727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env60726 == env60727) = true)

theorem identity60727 : scanCanonicalize (H12AffineFastState.compose env60727 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound60727 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env60728 : List Nat := [2,2,0,2,3,3,0,0,0,3,1,0,3,1,0,0,1,0,3,1,1,3,2,2,3,2,0,0,1,0,0,2,0,3,0,1]

theorem envBound60728 : H12AffineFastState.Bounded env60728 := by
  intro p hp
  have h : env60728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60727_60728 : H12AffineEnvironment.transform 1 2 env60727 = env60728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env60727 == env60728) = true)

theorem identity60728 : scanCanonicalize (H12AffineFastState.compose env60728 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound60728 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env60729 : List Nat := [1,1,0,1,0,0,0,0,0,0,1,0,0,1,0,0,1,0,0,1,1,0,1,1,0,1,0,0,1,0,0,1,0,0,0,1]

theorem envBound60729 : H12AffineFastState.Bounded env60729 := by
  intro p hp
  have h : env60729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60728_60729 : H12AffineEnvironment.transform 0 1 env60728 = env60729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env60728 == env60729) = true)

def env60730 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1345,65665,77934,13341,4097,476,16,69649,70886,78895,77841,1297,74814,81226,8204,74799,256,65831,1344,79471]

theorem envBound60730 : H12AffineFastState.Bounded env60730 := by
  intro p hp
  have h : env60730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60701_60730 : H12AffineEnvironment.transform 17 65665 env60701 = env60730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env60701 == env60730) = true)

theorem identity60730 : scanCanonicalize (H12AffineFastState.compose env60730 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5464) := by decide +kernel

theorem selectedBound60730 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env60731 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5464,1296,324,65536,1345,65665,66870,325,4097,476,16,69649,70886,65911,66889,1297,69990,67602,5460,70007,256,65831,1344,66359]

theorem envBound60731 : H12AffineFastState.Bounded env60731 := by
  intro p hp
  have h : env60731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60730_60731 : H12AffineEnvironment.transform 12 5464 env60730 = env60731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5464 env60730 == env60731) = true)

def env60732 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,5384,1296,276,65536,1297,65665,66870,277,4097,396,16,69649,70838,65831,66841,1297,69942,67602,5380,69927,256,65831,1296,66359]

theorem envBound60732 : H12AffineFastState.Bounded env60732 := by
  intro p hp
  have h : env60732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60731_60732 : H12AffineEnvironment.transform 5 16 env60731 = env60732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env60731 == env60732) = true)

theorem identity60732 : scanCanonicalize (H12AffineFastState.compose env60732 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 5426) := by decide +kernel

theorem selectedBound60732 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60733 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,5384,1296,276,5426,1297,5555,4100,277,4097,396,16,1315,388,5141,4139,1297,1028,7456,5380,1045,256,5141,1296,5637]

theorem envBound60733 : H12AffineFastState.Bounded env60733 := by
  intro p hp
  have h : env60733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60732_60733 : H12AffineEnvironment.transform 15 5426 env60732 = env60733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5426 env60732 == env60733) = true)

theorem identity60733 : scanCanonicalize (H12AffineFastState.compose env60733 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound60733 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env60734 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,24,1296,276,34,1297,163,1300,277,1297,396,16,1315,388,261,1339,1297,1028,2096,20,1045,256,261,1296,789]

theorem envBound60734 : H12AffineFastState.Bounded env60734 := by
  intro p hp
  have h : env60734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60733_60734 : H12AffineEnvironment.transform 11 1296 env60733 = env60734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env60733 == env60734) = true)

theorem identity60734 : scanCanonicalize (H12AffineFastState.compose env60734 (packedSelected [0,1,3,7,10,11,12,15,19] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound60734 : packedSelected [0,1,3,7,10,11,12,15,19] rootPS < 2^1333 := by decide +kernel

def env60735 : List Nat := [2,4,8,16,32,16,128,256,512,1024,26,1296,24,1296,276,34,1297,163,1300,277,1297,396,16,1315,388,261,1339,1297,1028,42,20,1045,256,261,1296,789]

theorem envBound60735 : H12AffineFastState.Bounded env60735 := by
  intro p hp
  have h : env60735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60734_60735 : H12AffineEnvironment.transform 10 26 env60734 = env60735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env60734 == env60735) = true)

theorem identity60735 : scanCanonicalize (H12AffineFastState.compose env60735 (packedSelected [5,8,13] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound60735 : packedSelected [5,8,13] rootPS < 2^1333 := by decide +kernel

def env60736 : List Nat := [2,4,8,16,32,16,128,256,512,272,26,0,24,0,276,34,1,163,4,277,1,396,16,51,388,261,43,1,276,42,20,261,256,261,0,789]

theorem envBound60736 : H12AffineFastState.Bounded env60736 := by
  intro p hp
  have h : env60736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60735_60736 : H12AffineEnvironment.transform 9 272 env60735 = env60736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env60735 == env60736) = true)

theorem identity60736 : scanCanonicalize (H12AffineFastState.compose env60736 (packedSelected [1,3,5] rootPS)) = affineNative (2^(8+1) ^^^ 61) := by decide +kernel

theorem selectedBound60736 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env60737 : List Nat := [2,4,8,16,32,16,128,256,61,272,26,0,24,0,276,34,1,163,4,277,1,396,16,51,388,261,43,1,276,42,20,261,256,261,0,296]

theorem envBound60737 : H12AffineFastState.Bounded env60737 := by
  intro p hp
  have h : env60737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60736_60737 : H12AffineEnvironment.transform 8 61 env60736 = env60737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 61 env60736 == env60737) = true)

theorem identity60737 : scanCanonicalize (H12AffineFastState.compose env60737 (packedSelected [2,3,8,10,12] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound60737 : packedSelected [2,3,8,10,12] rootPS < 2^1333 := by decide +kernel

def env60738 : List Nat := [2,4,5,16,32,16,128,256,48,272,23,0,21,0,276,34,1,163,4,277,1,385,16,51,388,261,38,1,276,39,20,261,256,261,0,293]

theorem envBound60738 : H12AffineFastState.Bounded env60738 := by
  intro p hp
  have h : env60738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60737_60738 : H12AffineEnvironment.transform 2 5 env60737 = env60738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env60737 == env60738) = true)

theorem identity60738 : scanCanonicalize (H12AffineFastState.compose env60738 (packedSelected [2,3,8] rootPS)) = affineNative (2^(7+1) ^^^ 183) := by decide +kernel

theorem selectedBound60738 : packedSelected [2,3,8] rootPS < 2^1333 := by decide +kernel

def env60739 : List Nat := [2,4,5,16,32,16,128,183,48,167,23,0,21,0,163,34,1,163,4,162,1,54,16,51,51,178,38,1,163,39,20,178,183,178,0,146]

theorem envBound60739 : H12AffineFastState.Bounded env60739 := by
  intro p hp
  have h : env60739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60738_60739 : H12AffineEnvironment.transform 7 183 env60738 = env60739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 183 env60738 == env60739) = true)

theorem identity60739 : scanCanonicalize (H12AffineFastState.compose env60739 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound60739 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env60740 : List Nat := [2,4,5,16,17,16,128,134,1,150,23,0,21,0,146,19,1,146,4,147,1,7,16,2,2,131,23,1,146,22,20,131,134,131,0,146]

theorem envBound60740 : H12AffineFastState.Bounded env60740 := by
  intro p hp
  have h : env60740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60739_60740 : H12AffineEnvironment.transform 4 17 env60739 = env60740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env60739 == env60740) = true)

theorem identity60740 : scanCanonicalize (H12AffineFastState.compose env60740 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound60740 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env60741 : List Nat := [2,4,5,16,17,16,5,3,1,19,23,0,21,0,23,19,1,23,4,22,1,7,16,2,2,6,23,1,23,22,20,6,3,6,0,23]

theorem envBound60741 : H12AffineFastState.Bounded env60741 := by
  intro p hp
  have h : env60741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60740_60741 : H12AffineEnvironment.transform 6 5 env60740 = env60741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env60740 == env60741) = true)

theorem identity60741 : scanCanonicalize (H12AffineFastState.compose env60741 (packedSelected [4,7] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound60741 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env60742 : List Nat := [2,4,5,6,7,6,5,3,1,5,1,0,3,0,1,5,1,1,4,0,1,7,6,2,2,6,1,1,1,0,2,6,3,6,0,1]

theorem envBound60742 : H12AffineFastState.Bounded env60742 := by
  intro p hp
  have h : env60742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60741_60742 : H12AffineEnvironment.transform 3 6 env60741 = env60742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env60741 == env60742) = true)

def env60743 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,5385,1296,277,65536,1296,65665,66870,276,4097,397,16,69649,70839,65830,66840,1297,69943,67602,5381,69926,256,65831,1297,66359]

theorem envBound60743 : H12AffineFastState.Bounded env60743 := by
  intro p hp
  have h : env60743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60731_60743 : H12AffineEnvironment.transform 5 17 env60731 = env60743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env60731 == env60743) = true)

theorem identity60743 : scanCanonicalize (H12AffineFastState.compose env60743 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound60743 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60744 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1029,268,1296,277,65536,1296,65665,66870,276,1028,397,16,66580,65714,65830,66840,1297,66866,67602,256,66851,256,65831,1297,66359]

theorem envBound60744 : H12AffineFastState.Bounded env60744 := by
  intro p hp
  have h : env60744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60743_60744 : H12AffineEnvironment.transform 11 1029 env60743 = env60744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env60743 == env60744) = true)

theorem identity60744 : scanCanonicalize (H12AffineFastState.compose env60744 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound60744 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env60745 : List Nat := [2,4,8,16,32,17,128,21,512,1024,2048,1029,25,1029,0,65536,1029,65665,66595,1,1028,152,16,66580,65714,65587,66573,1028,66599,67602,21,66614,21,65586,1028,66082]

theorem envBound60745 : H12AffineFastState.Bounded env60745 := by
  intro p hp
  have h : env60745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60744_60745 : H12AffineEnvironment.transform 7 21 env60744 = env60745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env60744 == env60745) = true)

theorem identity60745 : scanCanonicalize (H12AffineFastState.compose env60745 (packedSelected [0,1,2,3,7,10,12,15,18,19] rootPS)) = affineNative (2^(10+1) ^^^ 147) := by decide +kernel

theorem selectedBound60745 : packedSelected [0,1,2,3,7,10,12,15,18,19] rootPS < 2^1333 := by decide +kernel

def env60746 : List Nat := [2,4,8,16,32,17,128,21,512,1024,147,1029,25,1029,0,65536,1029,65665,66595,1,1028,152,16,66580,65714,65587,66573,1028,66599,65665,21,66614,21,65586,1028,66082]

theorem envBound60746 : H12AffineFastState.Bounded env60746 := by
  intro p hp
  have h : env60746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60745_60746 : H12AffineEnvironment.transform 10 147 env60745 = env60746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 147 env60745 == env60746) = true)

theorem identity60746 : scanCanonicalize (H12AffineFastState.compose env60746 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound60746 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env60747 : List Nat := [2,4,8,16,32,17,57,21,512,1024,42,1029,25,1029,0,65536,1029,65592,66595,1,1028,33,16,66580,65547,65587,66573,1028,66599,65592,21,66614,21,65586,1028,66082]

theorem envBound60747 : H12AffineFastState.Bounded env60747 := by
  intro p hp
  have h : env60747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60746_60747 : H12AffineEnvironment.transform 6 57 env60746 = env60747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env60746 == env60747) = true)

theorem identity60747 : scanCanonicalize (H12AffineFastState.compose env60747 (packedSelected [2,3,5,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 516) := by decide +kernel

theorem selectedBound60747 : packedSelected [2,3,5,7,9] rootPS < 2^1333 := by decide +kernel

def env60748 : List Nat := [2,4,8,16,32,17,57,21,512,516,42,513,25,513,0,65536,513,65592,66087,1,512,33,16,66064,65547,65587,66057,512,66083,65592,21,66098,21,65586,512,66082]

theorem envBound60748 : H12AffineFastState.Bounded env60748 := by
  intro p hp
  have h : env60748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60747_60748 : H12AffineEnvironment.transform 9 516 env60747 = env60748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 516 env60747 == env60748) = true)

theorem identity60748 : scanCanonicalize (H12AffineFastState.compose env60748 (packedSelected [0,2,3,7,8,11] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound60748 : packedSelected [0,2,3,7,8,11] rootPS < 2^1333 := by decide +kernel

def env60749 : List Nat := [2,4,8,16,10,17,19,21,512,516,0,513,25,513,0,65536,513,65554,66061,1,512,11,16,66064,65547,65561,66057,512,66057,65554,21,66072,21,65560,512,66056]

theorem envBound60749 : H12AffineFastState.Bounded env60749 := by
  intro p hp
  have h : env60749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60748_60749 : H12AffineEnvironment.transform 4 10 env60748 = env60749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env60748 == env60749) = true)

theorem identity60749 : scanCanonicalize (H12AffineFastState.compose env60749 (packedSelected [1,2,4,5,7] rootPS)) = affineNative (2^(15+1) ^^^ 9) := by decide +kernel

theorem selectedBound60749 : packedSelected [1,2,4,5,7] rootPS < 2^1333 := by decide +kernel

def env60750 : List Nat := [2,4,8,16,10,17,19,21,512,516,0,513,25,513,0,9,513,27,516,1,512,11,16,537,2,16,512,512,512,27,21,529,21,17,512,513]

theorem envBound60750 : H12AffineFastState.Bounded env60750 := by
  intro p hp
  have h : env60750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60749_60750 : H12AffineEnvironment.transform 15 9 env60749 = env60750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9 env60749 == env60750) = true)

theorem identity60750 : scanCanonicalize (H12AffineFastState.compose env60750 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound60750 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60751 : List Nat := [2,4,8,16,10,17,19,21,0,4,0,1,25,1,0,9,1,27,4,1,0,11,16,25,2,16,0,0,0,27,21,17,21,17,0,1]

theorem envBound60751 : H12AffineFastState.Bounded env60751 := by
  intro p hp
  have h : env60751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60750_60751 : H12AffineEnvironment.transform 8 0 env60750 = env60751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env60750 == env60751) = true)

theorem identity60751 : scanCanonicalize (H12AffineFastState.compose env60751 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 14) := by decide +kernel

theorem selectedBound60751 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60752 : List Nat := [2,4,8,14,10,15,13,11,0,4,0,1,7,1,0,9,1,5,4,1,0,11,14,7,2,14,0,0,0,5,11,15,11,15,0,1]

theorem envBound60752 : H12AffineFastState.Bounded env60752 := by
  intro p hp
  have h : env60752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60751_60752 : H12AffineEnvironment.transform 3 14 env60751 = env60752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 14 env60751 == env60752) = true)

theorem identity60752 : scanCanonicalize (H12AffineFastState.compose env60752 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound60752 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env60753 : List Nat := [2,4,4,2,6,3,1,7,0,4,0,1,7,1,0,5,1,5,4,1,0,7,2,7,2,2,0,0,0,5,7,3,7,3,0,1]

theorem envBound60753 : H12AffineFastState.Bounded env60753 := by
  intro p hp
  have h : env60753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60752_60753 : H12AffineEnvironment.transform 2 4 env60752 = env60753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env60752 == env60753) = true)

def env60754 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1344,262144,77935,32769,4097,46529,16,266385,70887,78894,77841,1297,74814,81227,365712,74798,256,308666,1344,79470]

theorem envBound60754 : H12AffineFastState.Bounded env60754 := by
  intro p hp
  have h : env60754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60699_60754 : H12AffineEnvironment.transform 13 1297 env60699 = env60754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env60699 == env60754) = true)

theorem identity60754 : scanCanonicalize (H12AffineFastState.compose env60754 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32883) := by decide +kernel

theorem selectedBound60754 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env60755 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,32883,1344,262144,45084,32769,4097,46529,16,266385,38036,46173,45154,1297,42061,48440,267491,42077,256,308666,1344,46621]

theorem envBound60755 : H12AffineFastState.Bounded env60755 := by
  intro p hp
  have h : env60755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60754_60755 : H12AffineEnvironment.transform 15 32883 env60754 = env60755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32883 env60754 == env60755) = true)

def env60756 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32883,1344,262144,42332,32769,1345,41089,16,263633,33236,41245,42274,1297,42061,43128,262563,42077,256,303354,1344,41821]

theorem envBound60756 : H12AffineFastState.Bounded env60756 := by
  intro p hp
  have h : env60756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60755_60756 : H12AffineEnvironment.transform 11 1344 env60755 = env60756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env60755 == env60756) = true)

theorem identity60756 : scanCanonicalize (H12AffineFastState.compose env60756 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound60756 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env60757 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,80,8192,1,32768,32883,80,262144,41036,32769,81,41089,16,262337,33236,41245,41010,1,41309,43128,262563,41293,256,303354,80,41821]

theorem envBound60757 : H12AffineFastState.Bounded env60757 := by
  intro p hp
  have h : env60757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60756_60757 : H12AffineEnvironment.transform 9 272 env60756 = env60757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env60756 == env60757) = true)

theorem identity60757 : scanCanonicalize (H12AffineFastState.compose env60757 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound60757 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env60758 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,80,8192,1,8541,8494,80,262144,273,8540,81,476,16,262337,8329,64,367,1,0,2341,262563,16,256,262567,80,512]

theorem envBound60758 : H12AffineFastState.Bounded env60758 := by
  intro p hp
  have h : env60758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60757_60758 : H12AffineEnvironment.transform 14 8541 env60757 = env60758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env60757 == env60758) = true)

theorem identity60758 : scanCanonicalize (H12AffineFastState.compose env60758 (packedSelected [4,9,16] rootPS)) = affineNative (2^(17+1) ^^^ 242) := by decide +kernel

theorem selectedBound60758 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60759 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,80,8192,1,8541,8494,80,242,273,8540,81,476,16,51,8329,64,367,1,0,2341,337,16,256,341,80,512]

theorem envBound60759 : H12AffineFastState.Bounded env60759 := by
  intro p hp
  have h : env60759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60758_60759 : H12AffineEnvironment.transform 17 242 env60758 = env60759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 242 env60758 == env60759) = true)

theorem identity60759 : scanCanonicalize (H12AffineFastState.compose env60759 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 981) := by decide +kernel

theorem selectedBound60759 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env60760 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,80,981,1,648,763,80,242,273,649,81,476,16,51,860,64,367,1,0,2341,337,16,256,341,80,512]

theorem envBound60760 : H12AffineFastState.Bounded env60760 := by
  intro p hp
  have h : env60760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60759_60760 : H12AffineEnvironment.transform 12 981 env60759 = env60760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 981 env60759 == env60760) = true)

theorem identity60760 : scanCanonicalize (H12AffineFastState.compose env60760 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound60760 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env60761 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,0,901,1,648,683,0,162,273,649,1,396,16,51,780,16,319,1,0,2341,257,16,256,261,0,512]

theorem envBound60761 : H12AffineFastState.Bounded env60761 := by
  intro p hp
  have h : env60761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60760_60761 : H12AffineEnvironment.transform 5 16 env60760 = env60761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env60760 == env60761) = true)

theorem identity60761 : scanCanonicalize (H12AffineFastState.compose env60761 (packedSelected [1,3,13] rootPS)) = affineNative (2^(10+1) ^^^ 390) := by decide +kernel

theorem selectedBound60761 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env60762 : List Nat := [2,4,8,16,32,16,128,256,512,272,390,0,901,1,648,683,0,162,273,649,1,396,16,51,780,16,319,1,0,163,257,16,256,261,0,512]

theorem envBound60762 : H12AffineFastState.Bounded env60762 := by
  intro p hp
  have h : env60762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60761_60762 : H12AffineEnvironment.transform 10 390 env60761 = env60762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 390 env60761 == env60762) = true)

theorem identity60762 : scanCanonicalize (H12AffineFastState.compose env60762 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound60762 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env60763 : List Nat := [2,4,8,16,32,16,128,21,512,5,147,0,656,1,648,683,0,162,4,649,1,153,16,51,537,16,42,1,0,163,20,16,21,16,0,512]

theorem envBound60763 : H12AffineFastState.Bounded env60763 := by
  intro p hp
  have h : env60763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60762_60763 : H12AffineEnvironment.transform 7 21 env60762 = env60763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env60762 == env60763) = true)

theorem identity60763 : scanCanonicalize (H12AffineFastState.compose env60763 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 15) := by decide +kernel

theorem selectedBound60763 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env60764 : List Nat := [2,4,8,16,32,16,15,21,512,5,28,0,543,1,519,548,0,45,4,518,1,22,16,51,537,16,42,1,0,44,20,16,21,16,0,512]

theorem envBound60764 : H12AffineFastState.Bounded env60764 := by
  intro p hp
  have h : env60764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60763_60764 : H12AffineEnvironment.transform 6 15 env60763 = env60764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 15 env60763 == env60764) = true)

theorem identity60764 : scanCanonicalize (H12AffineFastState.compose env60764 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound60764 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env60765 : List Nat := [2,4,8,16,16,16,15,21,512,5,28,0,543,1,519,532,0,29,4,518,1,22,16,3,537,16,26,1,0,28,20,16,21,16,0,512]

theorem envBound60765 : H12AffineFastState.Bounded env60765 := by
  intro p hp
  have h : env60765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60764_60765 : H12AffineEnvironment.transform 4 16 env60764 = env60765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env60764 == env60765) = true)

theorem identity60765 : scanCanonicalize (H12AffineFastState.compose env60765 (packedSelected [0,2] rootPS)) = affineNative (2^(8+1) ^^^ 28) := by decide +kernel

theorem selectedBound60765 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env60766 : List Nat := [2,4,8,16,16,16,15,21,28,5,28,0,3,1,27,8,0,29,4,26,1,22,16,3,5,16,26,1,0,28,20,16,21,16,0,28]

theorem envBound60766 : H12AffineFastState.Bounded env60766 := by
  intro p hp
  have h : env60766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60765_60766 : H12AffineEnvironment.transform 8 28 env60765 = env60766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 28 env60765 == env60766) = true)

theorem identity60766 : scanCanonicalize (H12AffineFastState.compose env60766 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound60766 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env60767 : List Nat := [2,4,8,13,13,13,15,8,1,5,1,0,3,1,6,8,0,0,4,7,1,11,13,3,5,13,7,1,0,1,9,13,8,13,0,1]

theorem envBound60767 : H12AffineFastState.Bounded env60767 := by
  intro p hp
  have h : env60767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60766_60767 : H12AffineEnvironment.transform 3 13 env60766 = env60767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env60766 == env60767) = true)

def env60768 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32883,1344,262144,42333,32769,1344,41088,16,263632,33237,41244,42275,1297,42061,43129,262562,42077,256,303355,1344,41820]

theorem envBound60768 : H12AffineFastState.Bounded env60768 := by
  intro p hp
  have h : env60768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60755_60768 : H12AffineEnvironment.transform 11 1345 env60755 = env60768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env60755 == env60768) = true)

theorem identity60768 : scanCanonicalize (H12AffineFastState.compose env60768 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 34274) := by decide +kernel

theorem selectedBound60768 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env60769 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32883,1344,34274,42333,32769,1344,41088,16,32818,33237,41244,42275,1297,42061,43129,33856,42077,256,9497,1344,41820]

theorem envBound60769 : H12AffineFastState.Bounded env60769 := by
  intro p hp
  have h : env60769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60768_60769 : H12AffineEnvironment.transform 17 34274 env60768 = env60769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 34274 env60768 == env60769) = true)

theorem identity60769 : scanCanonicalize (H12AffineFastState.compose env60769 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(14+1) ^^^ 9172) := by decide +kernel

theorem selectedBound60769 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env60770 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,9172,9127,1344,9782,1673,9173,1344,852,16,9190,8705,712,1783,1297,1945,2989,10132,1929,256,9497,1344,136]

theorem envBound60770 : H12AffineFastState.Bounded env60770 := by
  intro p hp
  have h : env60770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60769_60770 : H12AffineEnvironment.transform 14 9172 env60769 = env60770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9172 env60769 == env60770) = true)

def env60771 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95614,32769,4097,61648,147521,284033,86518,209262,225345,148800,74814,96346,381312,205166,256,456170,1344,95103]

theorem envBound60771 : H12AffineFastState.Bounded env60771 := by
  intro p hp
  have h : env60771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60631_60771 : H12AffineEnvironment.transform 23 284033 env60631 = env60771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 284033 env60631 == env60771) = true)

def env60772 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16464,262144,95614,32769,4097,61648,17,284033,86518,94526,77841,1296,74814,96346,381312,90430,256,308666,1344,95103]

theorem envBound60772 : H12AffineFastState.Bounded env60772 := by
  intro p hp
  have h : env60772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60771_60772 : H12AffineEnvironment.transform 16 16464 env60771 = env60772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16464 env60771 == env60772) = true)

def env60773 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1344,262144,77934,32769,4097,46528,17,266385,70886,78894,77841,1296,74814,81226,365712,74798,256,308666,1344,79471]

theorem envBound60773 : H12AffineFastState.Bounded env60773 := by
  intro p hp
  have h : env60773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60772_60773 : H12AffineEnvironment.transform 13 1296 env60772 = env60773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env60772 == env60773) = true)

theorem identity60773 : scanCanonicalize (H12AffineFastState.compose env60773 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32882) := by decide +kernel

theorem selectedBound60773 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env60774 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,32882,1344,262144,45084,32769,4097,46528,17,266385,38036,46172,45155,1296,42060,48440,267490,42076,256,308666,1344,46621]

theorem envBound60774 : H12AffineFastState.Bounded env60774 := by
  intro p hp
  have h : env60774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60773_60774 : H12AffineEnvironment.transform 15 32882 env60773 = env60774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32882 env60773 == env60774) = true)

def env60775 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32882,1344,262144,42332,32769,1345,41088,17,263633,33236,41244,42275,1296,42060,43128,262562,42076,256,303354,1344,41821]

theorem envBound60775 : H12AffineFastState.Bounded env60775 := by
  intro p hp
  have h : env60775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60774_60775 : H12AffineEnvironment.transform 11 1344 env60774 = env60775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env60774 == env60775) = true)

theorem identity60775 : scanCanonicalize (H12AffineFastState.compose env60775 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound60775 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env60776 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,25,1296,32768,32882,1344,262144,34117,32769,1345,32921,17,263633,33236,33029,34106,1296,33877,34913,262562,33861,256,295139,1344,33604]

theorem envBound60776 : H12AffineFastState.Bounded env60776 := by
  intro p hp
  have h : env60776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60775_60776 : H12AffineEnvironment.transform 12 25 env60775 = env60776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env60775 == env60776) = true)

theorem identity60776 : scanCanonicalize (H12AffineFastState.compose env60776 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(14+1) ^^^ 973) := by decide +kernel

theorem selectedBound60776 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env60777 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,25,1296,973,959,1344,262144,1672,972,1345,852,17,263633,537,712,1783,1296,1944,2988,262562,1928,256,262958,1344,137]

theorem envBound60777 : H12AffineFastState.Bounded env60777 := by
  intro p hp
  have h : env60777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60776_60777 : H12AffineEnvironment.transform 14 973 env60776 = env60777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 973 env60776 == env60777) = true)

def env60778 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32882,1344,262144,42333,32769,1344,41089,17,263632,33237,41245,42274,1296,42060,43129,262563,42076,256,303355,1344,41820]

theorem envBound60778 : H12AffineFastState.Bounded env60778 := by
  intro p hp
  have h : env60778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60774_60778 : H12AffineEnvironment.transform 11 1345 env60774 = env60778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env60774 == env60778) = true)

theorem identity60778 : scanCanonicalize (H12AffineFastState.compose env60778 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 41194) := by decide +kernel

theorem selectedBound60778 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env60779 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32882,1344,41194,42333,32769,1344,41089,17,42298,33237,41245,42274,1296,42060,43129,41289,42076,256,17,1344,41820]

theorem envBound60779 : H12AffineFastState.Bounded env60779 := by
  intro p hp
  have h : env60779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60778_60779 : H12AffineEnvironment.transform 17 41194 env60778 = env60779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 41194 env60778 == env60779) = true)

theorem identity60779 : scanCanonicalize (H12AffineFastState.compose env60779 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound60779 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env60780 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,8540,8494,1344,438,1025,8541,1344,477,17,1126,8329,65,1150,1296,1296,2341,21,1280,256,17,1344,512]

theorem envBound60780 : H12AffineFastState.Bounded env60780 := by
  intro p hp
  have h : env60780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60779_60780 : H12AffineEnvironment.transform 14 8540 env60779 = env60780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env60779 == env60780) = true)

theorem identity60780 : scanCanonicalize (H12AffineFastState.compose env60780 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound60780 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60781 : List Nat := [2,4,8,16,32,64,128,68,512,1024,2048,1029,8192,1108,8216,8298,1028,242,1025,8217,1028,153,17,1126,8329,65,1150,1108,1108,2145,21,1092,68,17,1028,512]

theorem envBound60781 : H12AffineFastState.Bounded env60781 := by
  intro p hp
  have h : env60781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60780_60781 : H12AffineEnvironment.transform 7 68 env60780 = env60781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env60780 == env60781) = true)

theorem identity60781 : scanCanonicalize (H12AffineFastState.compose env60781 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 656) := by decide +kernel

theorem selectedBound60781 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env60782 : List Nat := [2,4,8,16,32,64,128,68,512,1024,2048,1029,656,1108,648,762,1028,242,1025,649,1028,153,17,1126,537,65,1150,1108,1108,2145,21,1092,68,17,1028,512]

theorem envBound60782 : H12AffineFastState.Bounded env60782 := by
  intro p hp
  have h : env60782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60781_60782 : H12AffineEnvironment.transform 12 656 env60781 = env60782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 656 env60781 == env60782) = true)

theorem identity60782 : scanCanonicalize (H12AffineFastState.compose env60782 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound60782 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env60783 : List Nat := [2,4,8,16,32,16,128,20,512,1024,2048,1029,656,1028,648,682,1028,162,1025,649,1028,153,17,1078,537,17,1070,1028,1028,2097,21,1044,20,17,1028,512]

theorem envBound60783 : H12AffineFastState.Bounded env60783 := by
  intro p hp
  have h : env60783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60782_60783 : H12AffineEnvironment.transform 5 16 env60782 = env60783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env60782 == env60783) = true)

theorem identity60783 : scanCanonicalize (H12AffineFastState.compose env60783 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound60783 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env60784 : List Nat := [2,4,8,16,32,16,128,20,512,1024,42,1029,656,1028,648,682,1028,162,1025,649,1028,153,17,1078,537,17,1070,1028,1028,27,21,1044,20,17,1028,512]

theorem envBound60784 : H12AffineFastState.Bounded env60784 := by
  intro p hp
  have h : env60784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60783_60784 : H12AffineEnvironment.transform 10 42 env60783 = env60784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env60783 == env60784) = true)

theorem identity60784 : scanCanonicalize (H12AffineFastState.compose env60784 (packedSelected [1,4,5,9,11] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound60784 : packedSelected [1,4,5,9,11] rootPS < 2^1333 := by decide +kernel

def env60785 : List Nat := [2,4,8,16,32,16,128,20,512,517,42,512,656,513,648,682,513,162,516,649,513,153,17,563,537,17,555,513,513,27,21,529,20,17,513,512]

theorem envBound60785 : H12AffineFastState.Bounded env60785 := by
  intro p hp
  have h : env60785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60784_60785 : H12AffineEnvironment.transform 9 517 env60784 = env60785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env60784 == env60785) = true)

theorem identity60785 : scanCanonicalize (H12AffineFastState.compose env60785 (packedSelected [0,3,4,5,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 185) := by decide +kernel

theorem selectedBound60785 : packedSelected [0,3,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env60786 : List Nat := [2,4,8,16,32,16,128,20,185,188,42,185,41,184,49,19,184,162,189,48,184,153,17,138,160,17,146,184,184,27,21,168,20,17,184,185]

theorem envBound60786 : H12AffineFastState.Bounded env60786 := by
  intro p hp
  have h : env60786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60785_60786 : H12AffineEnvironment.transform 8 185 env60785 = env60786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 185 env60785 == env60786) = true)

theorem identity60786 : scanCanonicalize (H12AffineFastState.compose env60786 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound60786 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60787 : List Nat := [2,4,8,16,32,16,34,20,27,30,42,27,41,26,49,19,26,0,31,48,26,59,17,40,2,17,48,26,26,27,21,10,20,17,26,27]

theorem envBound60787 : H12AffineFastState.Bounded env60787 := by
  intro p hp
  have h : env60787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60786_60787 : H12AffineEnvironment.transform 6 34 env60786 = env60787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env60786 == env60787) = true)

theorem identity60787 : scanCanonicalize (H12AffineFastState.compose env60787 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound60787 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env60788 : List Nat := [2,4,8,16,11,16,9,20,27,30,1,27,2,26,26,19,26,0,31,27,26,16,17,3,2,17,27,26,26,27,21,10,20,17,26,27]

theorem envBound60788 : H12AffineFastState.Bounded env60788 := by
  intro p hp
  have h : env60788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60787_60788 : H12AffineEnvironment.transform 4 11 env60787 = env60788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env60787 == env60788) = true)

theorem identity60788 : scanCanonicalize (H12AffineFastState.compose env60788 (packedSelected [0,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound60788 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env60789 : List Nat := [2,4,8,10,11,10,9,14,1,4,1,1,2,0,0,9,0,0,5,1,0,10,11,3,2,11,1,0,0,1,15,10,14,11,0,1]

theorem envBound60789 : H12AffineFastState.Bounded env60789 := by
  intro p hp
  have h : env60789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60788_60789 : H12AffineEnvironment.transform 3 10 env60788 = env60789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env60788 == env60789) = true)

theorem identity60789 : scanCanonicalize (H12AffineFastState.compose env60789 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound60789 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60790 : List Nat := [2,4,5,7,6,7,4,3,1,4,1,1,2,0,0,4,0,0,5,1,0,7,6,3,2,6,1,0,0,1,2,7,3,6,0,1]

theorem envBound60790 : H12AffineFastState.Bounded env60790 := by
  intro p hp
  have h : env60790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60789_60790 : H12AffineEnvironment.transform 2 5 env60789 = env60790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env60789 == env60790) = true)

def env60791 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1345,262144,77935,32769,4097,46529,17,266384,70887,78895,77841,1296,74814,81227,365713,74799,256,308666,1344,79470]

theorem envBound60791 : H12AffineFastState.Bounded env60791 := by
  intro p hp
  have h : env60791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60772_60791 : H12AffineEnvironment.transform 13 1297 env60772 = env60791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env60772 == env60791) = true)

theorem identity60791 : scanCanonicalize (H12AffineFastState.compose env60791 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound60791 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env60792 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1345,262144,77935,13341,4097,477,17,266384,70887,78895,77841,1296,74814,81227,336013,74799,256,262566,1344,79470]

theorem envBound60792 : H12AffineFastState.Bounded env60792 := by
  intro p hp
  have h : env60792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60791_60792 : H12AffineEnvironment.transform 14 13340 env60791 = env60792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env60791 == env60792) = true)

def env60793 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1345,65664,77935,13341,4097,477,17,69648,70887,78895,77841,1296,74814,81227,8205,74799,256,65830,1344,79470]

theorem envBound60793 : H12AffineFastState.Bounded env60793 := by
  intro p hp
  have h : env60793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60792_60793 : H12AffineEnvironment.transform 17 65664 env60792 = env60793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env60792 == env60793) = true)

theorem identity60793 : scanCanonicalize (H12AffineFastState.compose env60793 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12670) := by decide +kernel

theorem selectedBound60793 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env60794 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,12670,1345,12798,273,13341,4097,477,17,8558,9625,1361,367,1296,5440,3125,8205,5457,256,12376,1344,1808]

theorem envBound60794 : H12AffineFastState.Bounded env60794 := by
  intro p hp
  have h : env60794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60793_60794 : H12AffineEnvironment.transform 15 12670 env60793 = env60794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12670 env60793 == env60794) = true)

def env60795 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,81,12636,12670,1,12798,273,12637,4097,477,17,8558,8409,17,367,80,4096,2421,8205,4113,256,12376,0,592]

theorem envBound60795 : H12AffineFastState.Bounded env60795 := by
  intro p hp
  have h : env60795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60794_60795 : H12AffineEnvironment.transform 9 320 env60794 = env60795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env60794 == env60795) = true)

theorem identity60795 : scanCanonicalize (H12AffineFastState.compose env60795 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound60795 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60796 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,268,81,4176,4210,1,4338,273,4177,4097,477,17,98,469,17,367,80,4096,2421,257,4113,256,4436,0,592]

theorem envBound60796 : H12AffineFastState.Bounded env60796 := by
  intro p hp
  have h : env60796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60795_60796 : H12AffineEnvironment.transform 12 268 env60795 = env60796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env60795 == env60796) = true)

theorem identity60796 : scanCanonicalize (H12AffineFastState.compose env60796 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound60796 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env60797 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,1,268,81,81,115,1,243,273,80,0,477,17,98,469,17,367,80,1,2421,257,16,256,341,0,592]

theorem envBound60797 : H12AffineFastState.Bounded env60797 := by
  intro p hp
  have h : env60797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60796_60797 : H12AffineEnvironment.transform 11 1 env60796 = env60797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env60796 == env60797) = true)

theorem identity60797 : scanCanonicalize (H12AffineFastState.compose env60797 (packedSelected [1,2,3,11,13,18] rootPS)) = affineNative (2^(8+1) ^^^ 412) := by decide +kernel

theorem selectedBound60797 : packedSelected [1,2,3,11,13,18] rootPS < 2^1333 := by decide +kernel

def env60798 : List Nat := [2,4,8,16,32,64,128,256,412,320,2048,1,268,81,81,115,1,243,273,80,0,477,17,98,469,17,367,80,1,2421,257,16,256,341,0,460]

theorem envBound60798 : H12AffineFastState.Bounded env60798 := by
  intro p hp
  have h : env60798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60797_60798 : H12AffineEnvironment.transform 8 412 env60797 = env60798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 412 env60797 == env60798) = true)

theorem identity60798 : scanCanonicalize (H12AffineFastState.compose env60798 (packedSelected [3,5,17] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound60798 : packedSelected [3,5,17] rootPS < 2^1333 := by decide +kernel

def env60799 : List Nat := [2,4,8,16,32,64,128,256,412,320,80,1,268,81,81,115,1,243,273,80,0,477,17,98,469,17,367,80,1,293,257,16,256,341,0,460]

theorem envBound60799 : H12AffineFastState.Bounded env60799 := by
  intro p hp
  have h : env60799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60798_60799 : H12AffineEnvironment.transform 10 80 env60798 = env60799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env60798 == env60799) = true)

theorem identity60799 : scanCanonicalize (H12AffineFastState.compose env60799 (packedSelected [0,2,7,10,11,13,15] rootPS)) = affineNative (2^(7+1) ^^^ 215) := by decide +kernel

theorem selectedBound60799 : packedSelected [0,2,7,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env60800 : List Nat := [2,4,8,16,32,64,128,215,75,151,80,1,219,81,81,115,1,243,198,80,0,10,17,98,2,17,184,80,1,242,214,16,215,130,0,27]

theorem envBound60800 : H12AffineFastState.Bounded env60800 := by
  intro p hp
  have h : env60800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60799_60800 : H12AffineEnvironment.transform 7 215 env60799 = env60800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 215 env60799 == env60800) = true)

theorem identity60800 : scanCanonicalize (H12AffineFastState.compose env60800 (packedSelected [0,4,5,7,8,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound60800 : packedSelected [0,4,5,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env60801 : List Nat := [2,4,8,16,32,64,35,116,75,52,80,1,120,81,81,115,1,80,101,80,0,10,17,98,2,17,27,80,1,81,117,16,116,33,0,27]

theorem envBound60801 : H12AffineFastState.Bounded env60801 := by
  intro p hp
  have h : env60801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60800_60801 : H12AffineEnvironment.transform 6 35 env60800 = env60801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env60800 == env60801) = true)

theorem identity60801 : scanCanonicalize (H12AffineFastState.compose env60801 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound60801 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env60802 : List Nat := [2,4,8,16,32,17,35,37,26,52,1,1,41,0,0,34,1,1,52,1,0,10,17,51,2,17,27,1,1,0,36,16,37,33,0,27]

theorem envBound60802 : H12AffineFastState.Bounded env60802 := by
  intro p hp
  have h : env60802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60801_60802 : H12AffineEnvironment.transform 5 17 env60801 = env60802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env60801 == env60802) = true)

theorem identity60802 : scanCanonicalize (H12AffineFastState.compose env60802 (packedSelected [0,1,2] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound60802 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env60803 : List Nat := [2,4,8,2,32,3,35,37,8,38,1,1,41,0,0,34,1,1,38,1,0,10,3,33,2,3,9,1,1,0,36,2,37,33,0,9]

theorem envBound60803 : H12AffineFastState.Bounded env60803 := by
  intro p hp
  have h : env60803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60802_60803 : H12AffineEnvironment.transform 3 2 env60802 = env60803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env60802 == env60803) = true)

theorem identity60803 : scanCanonicalize (H12AffineFastState.compose env60803 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound60803 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env60804 : List Nat := [2,4,8,2,2,3,1,7,8,4,1,1,11,0,0,0,1,1,4,1,0,10,3,3,2,3,9,1,1,0,6,2,7,3,0,9]

theorem envBound60804 : H12AffineFastState.Bounded env60804 := by
  intro p hp
  have h : env60804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60803_60804 : H12AffineEnvironment.transform 4 2 env60803 = env60804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env60803 == env60804) = true)

theorem identity60804 : scanCanonicalize (H12AffineFastState.compose env60804 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound60804 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60805 : List Nat := [2,4,7,2,2,3,1,7,7,4,1,1,4,0,0,0,1,1,4,1,0,5,3,3,2,3,6,1,1,0,6,2,7,3,0,6]

theorem envBound60805 : H12AffineFastState.Bounded env60805 := by
  intro p hp
  have h : env60805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60804_60805 : H12AffineEnvironment.transform 2 7 env60804 = env60805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env60804 == env60805) = true)

theorem identity60805 : scanCanonicalize (H12AffineFastState.compose env60805 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound60805 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env60806 : List Nat := [2,3,0,2,2,3,1,0,0,3,1,1,3,0,0,0,1,1,3,1,0,2,3,3,2,3,1,1,1,0,1,2,0,3,0,1]

theorem envBound60806 : H12AffineFastState.Bounded env60806 := by
  intro p hp
  have h : env60806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60805_60806 : H12AffineEnvironment.transform 1 3 env60805 = env60806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env60805 == env60806) = true)

theorem identity60806 : scanCanonicalize (H12AffineFastState.compose env60806 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound60806 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env60807 : List Nat := [0,1,0,0,0,1,1,0,0,1,1,1,1,0,0,0,1,1,1,1,0,0,1,1,0,1,1,1,1,0,1,0,0,1,0,1]

theorem envBound60807 : H12AffineFastState.Bounded env60807 := by
  intro p hp
  have h : env60807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60806_60807 : H12AffineEnvironment.transform 0 0 env60806 = env60807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env60806 == env60807) = true)

def env60808 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,80,12637,12670,0,12798,273,12636,4097,477,17,8558,8408,16,367,81,4097,2420,8205,4112,256,12376,1,593]

theorem envBound60808 : H12AffineFastState.Bounded env60808 := by
  intro p hp
  have h : env60808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60794_60808 : H12AffineEnvironment.transform 9 321 env60794 = env60808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env60794 == env60808) = true)

theorem identity60808 : scanCanonicalize (H12AffineFastState.compose env60808 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound60808 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60809 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,348,80,4097,4130,0,4258,273,4096,4097,477,17,50,388,16,367,81,4097,2420,337,4112,256,4356,1,593]

theorem envBound60809 : H12AffineFastState.Bounded env60809 := by
  intro p hp
  have h : env60809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60808_60809 : H12AffineEnvironment.transform 12 348 env60808 = env60809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env60808 == env60809) = true)

theorem identity60809 : scanCanonicalize (H12AffineFastState.compose env60809 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound60809 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env60810 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,1,348,80,0,35,0,163,273,1,0,477,17,50,388,16,367,81,0,2420,337,17,256,261,1,593]

theorem envBound60810 : H12AffineFastState.Bounded env60810 := by
  intro p hp
  have h : env60810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60809_60810 : H12AffineEnvironment.transform 11 1 env60809 = env60810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env60809 == env60810) = true)

theorem identity60810 : scanCanonicalize (H12AffineFastState.compose env60810 (packedSelected [1,2,3,5,8,11,13,17,18] rootPS)) = affineNative (2^(8+1) ^^^ 486) := by decide +kernel

theorem selectedBound60810 : packedSelected [1,2,3,5,8,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env60811 : List Nat := [2,4,8,16,32,64,128,256,486,321,2048,1,348,80,0,35,0,163,273,1,0,477,17,50,388,16,367,81,0,2420,337,17,256,261,1,439]

theorem envBound60811 : H12AffineFastState.Bounded env60811 := by
  intro p hp
  have h : env60811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60810_60811 : H12AffineEnvironment.transform 8 486 env60810 = env60811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 486 env60810 == env60811) = true)

theorem identity60811 : scanCanonicalize (H12AffineFastState.compose env60811 (packedSelected [1,3,10,17,19] rootPS)) = affineNative (2^(6+1) ^^^ 104) := by decide +kernel

theorem selectedBound60811 : packedSelected [1,3,10,17,19] rootPS < 2^1333 := by decide +kernel

def env60812 : List Nat := [2,4,8,16,32,64,104,256,270,321,2048,1,348,80,0,35,0,75,273,1,0,309,17,50,364,16,367,81,0,2420,337,17,256,261,1,351]

theorem envBound60812 : H12AffineFastState.Bounded env60812 := by
  intro p hp
  have h : env60812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60811_60812 : H12AffineEnvironment.transform 6 104 env60811 = env60812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 104 env60811 == env60812) = true)

theorem identity60812 : scanCanonicalize (H12AffineFastState.compose env60812 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 277) := by decide +kernel

theorem selectedBound60812 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env60813 : List Nat := [2,4,8,16,32,64,104,256,270,321,277,1,348,80,0,35,0,75,273,1,0,309,17,50,364,16,367,81,0,97,337,17,256,261,1,351]

theorem envBound60813 : H12AffineFastState.Bounded env60813 := by
  intro p hp
  have h : env60813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60812_60813 : H12AffineEnvironment.transform 10 277 env60812 = env60813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 277 env60812 == env60813) = true)

theorem identity60813 : scanCanonicalize (H12AffineFastState.compose env60813 (packedSelected [0,1,2,3,4,7,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 58) := by decide +kernel

theorem selectedBound60813 : packedSelected [0,1,2,3,4,7,9,10] rootPS < 2^1333 := by decide +kernel

def env60814 : List Nat := [2,4,8,16,32,58,18,256,270,315,277,1,294,42,0,35,0,49,273,1,0,309,17,50,278,16,277,43,0,27,299,17,256,261,1,293]

theorem envBound60814 : H12AffineFastState.Bounded env60814 := by
  intro p hp
  have h : env60814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60813_60814 : H12AffineEnvironment.transform 5 58 env60813 = env60814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 58 env60813 == env60814) = true)

theorem identity60814 : scanCanonicalize (H12AffineFastState.compose env60814 (packedSelected [1,2,5] rootPS)) = affineNative (2^(7+1) ^^^ 62) := by decide +kernel

theorem selectedBound60814 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env60815 : List Nat := [2,4,8,16,32,58,18,62,48,5,43,1,24,42,0,35,0,49,47,1,0,11,17,50,40,16,43,43,0,27,21,17,62,59,1,27]

theorem envBound60815 : H12AffineFastState.Bounded env60815 := by
  intro p hp
  have h : env60815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60814_60815 : H12AffineEnvironment.transform 7 62 env60814 = env60815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 62 env60814 == env60815) = true)

theorem identity60815 : scanCanonicalize (H12AffineFastState.compose env60815 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound60815 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60816 : List Nat := [2,4,8,10,32,32,8,36,42,5,43,1,2,42,0,35,0,43,47,1,0,11,11,40,40,10,43,43,0,1,15,11,36,33,1,1]

theorem envBound60816 : H12AffineFastState.Bounded env60816 := by
  intro p hp
  have h : env60816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60815_60816 : H12AffineEnvironment.transform 3 10 env60815 = env60816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env60815 == env60816) = true)

theorem identity60816 : scanCanonicalize (H12AffineFastState.compose env60816 (packedSelected [0,1,4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound60816 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env60817 : List Nat := [2,3,8,10,32,32,8,35,42,2,43,1,2,42,0,35,0,43,40,1,0,11,11,40,40,10,43,43,0,1,8,11,35,33,1,1]

theorem envBound60817 : H12AffineFastState.Bounded env60817 := by
  intro p hp
  have h : env60817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60816_60817 : H12AffineEnvironment.transform 1 3 env60816 = env60817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env60816 == env60817) = true)

theorem identity60817 : scanCanonicalize (H12AffineFastState.compose env60817 (packedSelected [0,1,7] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound60817 : packedSelected [0,1,7] rootPS < 2^1333 := by decide +kernel

def env60818 : List Nat := [2,3,8,10,10,10,8,9,0,2,1,1,2,0,0,9,0,1,2,1,0,11,11,2,2,10,1,1,0,1,8,11,9,11,1,1]

theorem envBound60818 : H12AffineFastState.Bounded env60818 := by
  intro p hp
  have h : env60818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60817_60818 : H12AffineEnvironment.transform 4 10 env60817 = env60818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env60817 == env60818) = true)

theorem identity60818 : scanCanonicalize (H12AffineFastState.compose env60818 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound60818 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60819 : List Nat := [0,1,8,8,8,8,8,9,0,0,1,1,0,0,0,9,0,1,0,1,0,9,9,0,0,8,1,1,0,1,8,9,9,9,1,1]

theorem envBound60819 : H12AffineFastState.Bounded env60819 := by
  intro p hp
  have h : env60819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60818_60819 : H12AffineEnvironment.transform 0 0 env60818 = env60819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env60818 == env60819) = true)

theorem identity60819 : scanCanonicalize (H12AffineFastState.compose env60819 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound60819 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env60820 : List Nat := [0,1,1,1,1,1,1,0,0,0,1,1,0,0,0,0,0,1,0,1,0,0,0,0,0,1,1,1,0,1,1,0,0,0,1,1]

theorem envBound60820 : H12AffineFastState.Bounded env60820 := by
  intro p hp
  have h : env60820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60819_60820 : H12AffineEnvironment.transform 2 1 env60819 = env60820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env60819 == env60820) = true)

def env60821 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1345,65665,77935,13341,4097,477,17,69649,70887,78895,77841,1296,74814,81227,8204,74799,256,65831,1344,79470]

theorem envBound60821 : H12AffineFastState.Bounded env60821 := by
  intro p hp
  have h : env60821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60792_60821 : H12AffineEnvironment.transform 17 65665 env60792 = env60821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env60792 == env60821) = true)

theorem identity60821 : scanCanonicalize (H12AffineFastState.compose env60821 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9279) := by decide +kernel

theorem selectedBound60821 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env60822 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,9279,1345,9406,5200,13341,4097,477,17,13358,12504,4112,5166,1296,1,6516,8204,16,256,9496,1344,4689]

theorem envBound60822 : H12AffineFastState.Bounded env60822 := by
  intro p hp
  have h : env60822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60821_60822 : H12AffineEnvironment.transform 15 9279 env60821 = env60822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9279 env60821 == env60822) = true)

def env60823 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1297,9244,9279,1345,9406,1104,9245,1,477,17,9262,8408,16,1070,1296,1,2420,8204,16,256,9496,1344,593]

theorem envBound60823 : H12AffineFastState.Bounded env60823 := by
  intro p hp
  have h : env60823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60822_60823 : H12AffineEnvironment.transform 11 0 env60822 = env60823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env60822 == env60823) = true)

theorem identity60823 : scanCanonicalize (H12AffineFastState.compose env60823 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound60823 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60824 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,349,1297,1345,1378,1345,1507,1104,1344,1,477,17,1395,389,16,1070,1296,1,2420,337,16,256,1093,1344,593]

theorem envBound60824 : H12AffineFastState.Bounded env60824 := by
  intro p hp
  have h : env60824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60823_60824 : H12AffineEnvironment.transform 12 349 env60823 = env60824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env60823 == env60824) = true)

theorem identity60824 : scanCanonicalize (H12AffineFastState.compose env60824 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound60824 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env60825 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,0,349,0,80,115,80,242,321,81,1,477,17,98,389,16,319,1,1,2420,337,16,256,340,81,593]

theorem envBound60825 : H12AffineFastState.Bounded env60825 := by
  intro p hp
  have h : env60825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60824_60825 : H12AffineEnvironment.transform 9 273 env60824 = env60825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env60824 == env60825) = true)

theorem identity60825 : scanCanonicalize (H12AffineFastState.compose env60825 (packedSelected [10,11,18,19] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound60825 : packedSelected [10,11,18,19] rootPS < 2^1333 := by decide +kernel

def env60826 : List Nat := [2,4,8,16,32,64,128,256,512,273,26,0,349,0,80,115,80,242,321,81,1,477,17,98,389,16,319,1,1,366,337,16,256,340,81,593]

theorem envBound60826 : H12AffineFastState.Bounded env60826 := by
  intro p hp
  have h : env60826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60825_60826 : H12AffineEnvironment.transform 10 26 env60825 = env60826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env60825 == env60826) = true)

theorem identity60826 : scanCanonicalize (H12AffineFastState.compose env60826 (packedSelected [2,12,13,15,17] rootPS)) = affineNative (2^(8+1) ^^^ 147) := by decide +kernel

theorem selectedBound60826 : packedSelected [2,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env60827 : List Nat := [2,4,8,16,32,64,128,256,147,273,26,0,349,0,80,115,80,242,321,81,1,477,17,98,389,16,319,1,1,366,337,16,256,340,81,194]

theorem envBound60827 : H12AffineFastState.Bounded env60827 := by
  intro p hp
  have h : env60827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60826_60827 : H12AffineEnvironment.transform 8 147 env60826 = env60827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 147 env60826 == env60827) = true)

theorem identity60827 : scanCanonicalize (H12AffineFastState.compose env60827 (packedSelected [0,1,7,8,11,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 62) := by decide +kernel

theorem selectedBound60827 : packedSelected [0,1,7,8,11,12,15] rootPS < 2^1333 := by decide +kernel

def env60828 : List Nat := [2,4,8,16,32,64,128,62,147,47,26,0,99,0,80,115,80,242,127,81,1,227,17,98,187,16,1,1,1,80,111,16,62,106,81,194]

theorem envBound60828 : H12AffineFastState.Bounded env60828 := by
  intro p hp
  have h : env60828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60827_60828 : H12AffineEnvironment.transform 7 62 env60827 = env60828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 62 env60827 == env60828) = true)

theorem identity60828 : scanCanonicalize (H12AffineFastState.compose env60828 (packedSelected [2,4,7] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound60828 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env60829 : List Nat := [2,4,8,16,32,64,34,62,49,47,26,0,99,0,80,115,80,80,127,81,1,65,17,98,25,16,1,1,1,80,111,16,62,106,81,96]

theorem envBound60829 : H12AffineFastState.Bounded env60829 := by
  intro p hp
  have h : env60829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60828_60829 : H12AffineEnvironment.transform 6 34 env60828 = env60829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env60828 == env60829) = true)

theorem identity60829 : scanCanonicalize (H12AffineFastState.compose env60829 (packedSelected [3,4,5,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound60829 : packedSelected [3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env60830 : List Nat := [2,4,8,16,32,17,34,62,49,47,26,0,50,0,1,34,1,1,46,0,1,16,17,51,25,16,1,1,1,1,62,16,62,59,0,49]

theorem envBound60830 : H12AffineFastState.Bounded env60830 := by
  intro p hp
  have h : env60830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60829_60830 : H12AffineEnvironment.transform 5 17 env60829 = env60830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env60829 == env60830) = true)

theorem identity60830 : scanCanonicalize (H12AffineFastState.compose env60830 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound60830 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env60831 : List Nat := [2,4,8,16,11,17,9,21,26,4,26,0,25,0,1,9,1,1,5,0,1,16,17,24,25,16,1,1,1,1,21,16,21,16,0,26]

theorem envBound60831 : H12AffineFastState.Bounded env60831 := by
  intro p hp
  have h : env60831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60830_60831 : H12AffineEnvironment.transform 4 11 env60830 = env60831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env60830 == env60831) = true)

theorem identity60831 : scanCanonicalize (H12AffineFastState.compose env60831 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound60831 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60832 : List Nat := [2,4,5,16,6,17,4,21,23,4,23,0,20,0,1,4,1,1,5,0,1,16,17,21,20,16,1,1,1,1,21,16,21,16,0,23]

theorem envBound60832 : H12AffineFastState.Bounded env60832 := by
  intro p hp
  have h : env60832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60831_60832 : H12AffineEnvironment.transform 2 5 env60831 = env60832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env60831 == env60832) = true)

theorem identity60832 : scanCanonicalize (H12AffineFastState.compose env60832 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound60832 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60833 : List Nat := [2,4,5,6,6,7,4,3,1,4,1,0,2,0,1,4,1,1,5,0,1,6,7,3,2,6,1,1,1,1,3,6,3,6,0,1]

theorem envBound60833 : H12AffineFastState.Bounded env60833 := by
  intro p hp
  have h : env60833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60832_60833 : H12AffineEnvironment.transform 3 6 env60832 = env60833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env60832 == env60833) = true)

def env60834 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1297,9245,9279,1345,9406,1105,9244,0,477,17,9263,8409,17,1071,1296,1,2421,8204,16,256,9496,1344,592]

theorem envBound60834 : H12AffineFastState.Bounded env60834 := by
  intro p hp
  have h : env60834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60822_60834 : H12AffineEnvironment.transform 11 1 env60822 = env60834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env60822 == env60834) = true)

theorem identity60834 : scanCanonicalize (H12AffineFastState.compose env60834 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound60834 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60835 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,269,1297,1296,1330,1345,1459,1105,1297,0,477,17,1314,468,17,1071,1296,1,2421,257,16,256,1045,1344,592]

theorem envBound60835 : H12AffineFastState.Bounded env60835 := by
  intro p hp
  have h : env60835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60834_60835 : H12AffineEnvironment.transform 12 269 env60834 = env60835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env60834 == env60835) = true)

theorem identity60835 : scanCanonicalize (H12AffineFastState.compose env60835 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound60835 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env60836 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,1,269,1,0,34,81,163,321,1,0,477,17,50,468,17,319,0,1,2421,257,16,256,261,80,592]

theorem envBound60836 : H12AffineFastState.Bounded env60836 := by
  intro p hp
  have h : env60836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60835_60836 : H12AffineEnvironment.transform 9 272 env60835 = env60836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env60835 == env60836) = true)

theorem identity60836 : scanCanonicalize (H12AffineFastState.compose env60836 (packedSelected [0,1,2,5,7,12,15,17,18] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound60836 : packedSelected [0,1,2,5,7,12,15,17,18] rootPS < 2^1333 := by decide +kernel

def env60837 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,1,269,1,0,34,81,42,321,1,0,340,17,50,349,17,319,0,1,2421,257,16,256,261,80,592]

theorem envBound60837 : H12AffineFastState.Bounded env60837 := by
  intro p hp
  have h : env60837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60836_60837 : H12AffineEnvironment.transform 6 9 env60836 = env60837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env60836 == env60837) = true)

theorem identity60837 : scanCanonicalize (H12AffineFastState.compose env60837 (packedSelected [2,13] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound60837 : packedSelected [2,13] rootPS < 2^1333 := by decide +kernel

def env60838 : List Nat := [2,4,8,16,32,64,9,256,42,272,2048,1,269,1,0,34,81,42,321,1,0,340,17,50,349,17,319,0,1,2421,257,16,256,261,80,122]

theorem envBound60838 : H12AffineFastState.Bounded env60838 := by
  intro p hp
  have h : env60838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60837_60838 : H12AffineEnvironment.transform 8 42 env60837 = env60838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env60837 == env60838) = true)

theorem identity60838 : scanCanonicalize (H12AffineFastState.compose env60838 (packedSelected [0,1,3,5,7,8,11,12,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound60838 : packedSelected [0,1,3,5,7,8,11,12,15,17] rootPS < 2^1333 := by decide +kernel

def env60839 : List Nat := [2,4,8,16,32,64,9,256,42,272,292,1,269,1,0,34,81,42,321,1,0,340,17,50,349,17,319,0,1,81,257,16,256,261,80,122]

theorem envBound60839 : H12AffineFastState.Bounded env60839 := by
  intro p hp
  have h : env60839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60838_60839 : H12AffineEnvironment.transform 10 292 env60838 = env60839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env60838 == env60839) = true)

theorem identity60839 : scanCanonicalize (H12AffineFastState.compose env60839 (packedSelected [5,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound60839 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env60840 : List Nat := [2,4,8,16,32,17,9,256,42,272,292,1,269,1,0,34,0,42,272,1,0,261,17,50,268,17,319,0,1,0,257,16,256,261,1,43]

theorem envBound60840 : H12AffineFastState.Bounded env60840 := by
  intro p hp
  have h : env60840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60839_60840 : H12AffineEnvironment.transform 5 17 env60839 = env60840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env60839 == env60840) = true)

theorem identity60840 : scanCanonicalize (H12AffineFastState.compose env60840 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound60840 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env60841 : List Nat := [2,4,8,16,32,17,9,36,42,52,0,1,41,1,0,34,0,42,52,1,0,33,17,50,40,17,27,0,1,0,37,16,36,33,1,43]

theorem envBound60841 : H12AffineFastState.Bounded env60841 := by
  intro p hp
  have h : env60841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60840_60841 : H12AffineEnvironment.transform 7 36 env60840 = env60841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env60840 == env60841) = true)

theorem identity60841 : scanCanonicalize (H12AffineFastState.compose env60841 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound60841 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60842 : List Nat := [2,4,8,16,10,17,9,14,0,30,0,1,3,1,0,8,0,0,30,1,0,11,17,24,2,17,27,0,1,0,15,16,14,11,1,1]

theorem envBound60842 : H12AffineFastState.Bounded env60842 := by
  intro p hp
  have h : env60842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60841_60842 : H12AffineEnvironment.transform 4 10 env60841 = env60842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env60841 == env60842) = true)

theorem identity60842 : scanCanonicalize (H12AffineFastState.compose env60842 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound60842 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env60843 : List Nat := [2,4,8,2,10,3,9,14,0,12,0,1,3,1,0,8,0,0,12,1,0,11,3,10,2,3,9,0,1,0,15,2,14,11,1,1]

theorem envBound60843 : H12AffineFastState.Bounded env60843 := by
  intro p hp
  have h : env60843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60842_60843 : H12AffineEnvironment.transform 3 2 env60842 = env60843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env60842 == env60843) = true)

theorem identity60843 : scanCanonicalize (H12AffineFastState.compose env60843 (packedSelected [0,4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound60843 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env60844 : List Nat := [0,4,8,0,8,1,9,12,0,12,0,1,1,1,0,8,0,0,12,1,0,9,1,8,0,1,9,0,1,0,13,0,12,9,1,1]

theorem envBound60844 : H12AffineFastState.Bounded env60844 := by
  intro p hp
  have h : env60844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60843_60844 : H12AffineEnvironment.transform 0 0 env60843 = env60844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env60843 == env60844) = true)

theorem identity60844 : scanCanonicalize (H12AffineFastState.compose env60844 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound60844 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60845 : List Nat := [0,0,8,0,8,1,9,8,0,8,0,1,1,1,0,8,0,0,8,1,0,9,1,8,0,1,9,0,1,0,9,0,8,9,1,1]

theorem envBound60845 : H12AffineFastState.Bounded env60845 := by
  intro p hp
  have h : env60845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60844_60845 : H12AffineEnvironment.transform 1 0 env60844 = env60845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env60844 == env60845) = true)

theorem identity60845 : scanCanonicalize (H12AffineFastState.compose env60845 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound60845 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env60846 : List Nat := [0,0,0,0,0,1,1,0,0,0,0,1,1,1,0,0,0,0,0,1,0,1,1,0,0,1,1,0,1,0,1,0,0,1,1,1]

theorem envBound60846 : H12AffineFastState.Bounded env60846 := by
  intro p hp
  have h : env60846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60845_60846 : H12AffineEnvironment.transform 2 0 env60845 = env60846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env60845 == env60846) = true)

def env60847 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16465,262144,95614,32769,4097,61648,16,284033,86518,94527,77840,1297,74814,96346,381312,90431,256,308667,1344,95103]

theorem envBound60847 : H12AffineFastState.Bounded env60847 := by
  intro p hp
  have h : env60847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60771_60847 : H12AffineEnvironment.transform 16 16465 env60771 = env60847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16465 env60771 == env60847) = true)

def env60848 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1345,262144,77934,32769,4097,46528,16,266385,70886,78895,77840,1297,74814,81226,365712,74799,256,308667,1344,79471]

theorem envBound60848 : H12AffineFastState.Bounded env60848 := by
  intro p hp
  have h : env60848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60847_60848 : H12AffineEnvironment.transform 13 1296 env60847 = env60848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env60847 == env60848) = true)

theorem identity60848 : scanCanonicalize (H12AffineFastState.compose env60848 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound60848 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env60849 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1345,262144,77934,13341,4097,476,16,266385,70886,78895,77840,1297,74814,81226,336012,74799,256,262567,1344,79471]

theorem envBound60849 : H12AffineFastState.Bounded env60849 := by
  intro p hp
  have h : env60849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60848_60849 : H12AffineEnvironment.transform 14 13340 env60848 = env60849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env60848 == env60849) = true)

def env60850 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1345,65664,77934,13341,4097,476,16,69649,70886,78895,77840,1297,74814,81226,8204,74799,256,65831,1344,79471]

theorem envBound60850 : H12AffineFastState.Bounded env60850 := by
  intro p hp
  have h : env60850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60849_60850 : H12AffineEnvironment.transform 17 65664 env60849 = env60850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env60849 == env60850) = true)

theorem identity60850 : scanCanonicalize (H12AffineFastState.compose env60850 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 310) := by decide +kernel

theorem selectedBound60850 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env60851 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,310,1345,438,12632,13341,4097,476,16,4391,5584,13593,12582,1297,9480,15484,8204,9497,256,17,1344,14169]

theorem envBound60851 : H12AffineFastState.Bounded env60851 := by
  intro p hp
  have h : env60851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60850_60851 : H12AffineEnvironment.transform 15 310 env60850 = env60851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 310 env60850 == env60851) = true)

def env60852 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,1296,13340,310,1297,438,12552,13341,4097,396,16,4391,5504,13593,12582,1297,9480,15404,8204,9497,256,17,1296,14089]

theorem envBound60852 : H12AffineFastState.Bounded env60852 := by
  intro p hp
  have h : env60852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60851_60852 : H12AffineEnvironment.transform 5 16 env60851 = env60852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env60851 == env60852) = true)

theorem identity60852 : scanCanonicalize (H12AffineFastState.compose env60852 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound60852 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60853 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1028,8192,1296,8216,310,1297,438,9484,8217,1029,396,16,1315,388,8477,9506,1297,9480,10280,8204,9497,256,17,1296,8973]

theorem envBound60853 : H12AffineFastState.Bounded env60853 := by
  intro p hp
  have h : env60853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60852_60853 : H12AffineEnvironment.transform 11 1028 env60852 = env60853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env60852 == env60853) = true)

theorem identity60853 : scanCanonicalize (H12AffineFastState.compose env60853 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound60853 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env60854 : List Nat := [2,4,8,16,32,16,128,20,512,1024,2048,1028,8192,1028,8216,34,1029,162,9240,8217,1029,152,16,1079,144,8201,9270,1029,9244,10280,8204,9229,20,17,1028,8729]

theorem envBound60854 : H12AffineFastState.Bounded env60854 := by
  intro p hp
  have h : env60854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60853_60854 : H12AffineEnvironment.transform 7 20 env60853 = env60854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env60853 == env60854) = true)

theorem identity60854 : scanCanonicalize (H12AffineFastState.compose env60854 (packedSelected [0,1,3,5,7,8,11,12,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 1055) := by decide +kernel

theorem selectedBound60854 : packedSelected [0,1,3,5,7,8,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env60855 : List Nat := [2,4,8,16,32,16,128,20,512,1024,1055,1028,8192,1028,8216,34,1029,162,9240,8217,1029,152,16,1079,144,8201,9270,1029,9244,9271,8204,9229,20,17,1028,8729]

theorem envBound60855 : H12AffineFastState.Bounded env60855 := by
  intro p hp
  have h : env60855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60854_60855 : H12AffineEnvironment.transform 10 1055 env60854 = env60855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1055 env60854 == env60855) = true)

theorem identity60855 : scanCanonicalize (H12AffineFastState.compose env60855 (packedSelected [0,5,7,8,18] rootPS)) = affineNative (2^(12+1) ^^^ 1167) := by decide +kernel

theorem selectedBound60855 : packedSelected [0,5,7,8,18] rootPS < 2^1333 := by decide +kernel

def env60856 : List Nat := [2,4,8,16,32,16,128,20,512,1024,1055,1028,1167,1028,1175,34,1029,162,151,1174,1029,152,16,1079,144,1158,185,1029,147,184,1155,130,20,17,1028,1686]

theorem envBound60856 : H12AffineFastState.Bounded env60856 := by
  intro p hp
  have h : env60856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60855_60856 : H12AffineEnvironment.transform 12 1167 env60855 = env60856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1167 env60855 == env60856) = true)

theorem identity60856 : scanCanonicalize (H12AffineFastState.compose env60856 (packedSelected [0,5,8,9,10] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound60856 : packedSelected [0,5,8,9,10] rootPS < 2^1333 := by decide +kernel

def env60857 : List Nat := [2,4,8,16,32,16,128,20,26,1024,1055,1028,1167,1028,1175,34,1029,162,151,1174,1029,152,16,1079,144,1158,185,1029,147,184,1155,130,20,17,1028,1164]

theorem envBound60857 : H12AffineFastState.Bounded env60857 := by
  intro p hp
  have h : env60857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60856_60857 : H12AffineEnvironment.transform 8 26 env60856 = env60857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env60856 == env60857) = true)

theorem identity60857 : scanCanonicalize (H12AffineFastState.compose env60857 (packedSelected [0,9,11] rootPS)) = affineNative (2^(9+1) ^^^ 189) := by decide +kernel

theorem selectedBound60857 : packedSelected [0,9,11] rootPS < 2^1333 := by decide +kernel

def env60858 : List Nat := [2,4,8,16,32,16,128,20,26,189,162,185,50,185,42,34,184,162,151,43,184,152,16,138,144,59,185,184,147,184,62,130,20,17,185,49]

theorem envBound60858 : H12AffineFastState.Bounded env60858 := by
  intro p hp
  have h : env60858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60857_60858 : H12AffineEnvironment.transform 9 189 env60857 = env60858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 189 env60857 == env60858) = true)

theorem identity60858 : scanCanonicalize (H12AffineFastState.compose env60858 (packedSelected [3,5] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound60858 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env60859 : List Nat := [2,4,8,16,32,16,8,20,26,53,42,49,50,49,42,34,48,42,31,43,48,16,16,2,24,59,49,48,27,48,62,10,20,17,49,49]

theorem envBound60859 : H12AffineFastState.Bounded env60859 := by
  intro p hp
  have h : env60859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60858_60859 : H12AffineEnvironment.transform 6 8 env60858 = env60859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env60858 == env60859) = true)

theorem identity60859 : scanCanonicalize (H12AffineFastState.compose env60859 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound60859 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env60860 : List Nat := [2,4,8,16,16,16,8,20,26,5,26,1,2,1,26,18,0,26,31,27,0,16,16,2,24,11,1,0,27,0,14,10,20,17,1,1]

theorem envBound60860 : H12AffineFastState.Bounded env60860 := by
  intro p hp
  have h : env60860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60859_60860 : H12AffineEnvironment.transform 4 16 env60859 = env60860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env60859 == env60860) = true)

def env60861 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,1296,13340,310,1296,438,12553,13341,4097,397,16,4391,5505,13593,12582,1297,9480,15405,8204,9497,256,17,1297,14088]

theorem envBound60861 : H12AffineFastState.Bounded env60861 := by
  intro p hp
  have h : env60861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60851_60861 : H12AffineEnvironment.transform 5 17 env60851 = env60861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env60851 == env60861) = true)

theorem identity60861 : scanCanonicalize (H12AffineFastState.compose env60861 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound60861 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60862 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,268,1296,5392,310,1296,438,4101,5393,4097,397,16,4391,5505,5141,4138,1297,1028,7457,256,1045,256,17,1297,5636]

theorem envBound60862 : H12AffineFastState.Bounded env60862 := by
  intro p hp
  have h : env60862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60861_60862 : H12AffineEnvironment.transform 12 268 env60861 = env60862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env60861 == env60862) = true)

theorem identity60862 : scanCanonicalize (H12AffineFastState.compose env60862 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound60862 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env60863 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,268,1296,0,310,1296,438,1301,1,1297,397,16,1079,145,261,1338,1297,1028,2097,256,1045,256,17,1297,788]

theorem envBound60863 : H12AffineFastState.Bounded env60863 := by
  intro p hp
  have h : env60863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60862_60863 : H12AffineEnvironment.transform 11 1296 env60862 = env60863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env60862 == env60863) = true)

theorem identity60863 : scanCanonicalize (H12AffineFastState.compose env60863 (packedSelected [0,1,2,3,5,7,8,12,13,15,18] rootPS)) = affineNative (2^(10+1) ^^^ 539) := by decide +kernel

theorem selectedBound60863 : packedSelected [0,1,2,3,5,7,8,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env60864 : List Nat := [2,4,8,16,32,17,128,256,512,1024,539,1296,268,1296,0,310,1296,438,1301,1,1297,397,16,1079,145,261,1338,1297,1028,554,256,1045,256,17,1297,788]

theorem envBound60864 : H12AffineFastState.Bounded env60864 := by
  intro p hp
  have h : env60864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60863_60864 : H12AffineEnvironment.transform 10 539 env60863 = env60864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 539 env60863 == env60864) = true)

theorem identity60864 : scanCanonicalize (H12AffineFastState.compose env60864 (packedSelected [1,2,8,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 564) := by decide +kernel

theorem selectedBound60864 : packedSelected [1,2,8,12,15] rootPS < 2^1333 := by decide +kernel

def env60865 : List Nat := [2,4,8,16,32,17,128,256,512,564,539,804,268,804,0,310,804,438,801,1,805,397,16,515,145,261,782,805,560,554,256,545,256,17,805,788]

theorem envBound60865 : H12AffineFastState.Bounded env60865 := by
  intro p hp
  have h : env60865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60864_60865 : H12AffineEnvironment.transform 9 564 env60864 = env60865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 564 env60864 == env60865) = true)

theorem identity60865 : scanCanonicalize (H12AffineFastState.compose env60865 (packedSelected [0,1,4,5,7,9,10,13] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound60865 : packedSelected [0,1,4,5,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env60866 : List Nat := [2,4,8,16,32,17,128,21,512,564,539,561,25,561,0,35,561,163,564,1,560,152,16,515,145,16,539,560,560,554,21,545,21,17,560,513]

theorem envBound60866 : H12AffineFastState.Bounded env60866 := by
  intro p hp
  have h : env60866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60865_60866 : H12AffineEnvironment.transform 7 21 env60865 = env60866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env60865 == env60866) = true)

theorem identity60866 : scanCanonicalize (H12AffineFastState.compose env60866 (packedSelected [1,2,5] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound60866 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env60867 : List Nat := [2,4,8,16,32,17,18,21,512,564,539,561,25,561,0,35,561,49,564,1,560,10,16,515,3,16,539,560,560,554,21,545,21,17,560,513]

theorem envBound60867 : H12AffineFastState.Bounded env60867 := by
  intro p hp
  have h : env60867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60866_60867 : H12AffineEnvironment.transform 6 18 env60866 = env60867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env60866 == env60867) = true)

theorem identity60867 : scanCanonicalize (H12AffineFastState.compose env60867 (packedSelected [1,4] rootPS)) = affineNative (2^(8+1) ^^^ 41) := by decide +kernel

theorem selectedBound60867 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env60868 : List Nat := [2,4,8,16,32,17,18,21,41,29,50,24,25,24,0,35,24,49,29,1,25,10,16,42,3,16,50,25,25,3,21,8,21,17,25,40]

theorem envBound60868 : H12AffineFastState.Bounded env60868 := by
  intro p hp
  have h : env60868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60867_60868 : H12AffineEnvironment.transform 8 41 env60867 = env60868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 41 env60867 == env60868) = true)

theorem identity60868 : scanCanonicalize (H12AffineFastState.compose env60868 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound60868 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env60869 : List Nat := [2,4,8,16,26,17,18,21,19,29,8,24,25,24,0,25,24,11,29,1,25,10,16,16,3,16,8,25,25,3,21,8,21,17,25,18]

theorem envBound60869 : H12AffineFastState.Bounded env60869 := by
  intro p hp
  have h : env60869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60868_60869 : H12AffineEnvironment.transform 4 26 env60868 = env60869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env60868 == env60869) = true)

theorem identity60869 : scanCanonicalize (H12AffineFastState.compose env60869 (packedSelected [2,3] rootPS)) = affineNative (2^(3+1) ^^^ 14) := by decide +kernel

theorem selectedBound60869 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env60870 : List Nat := [2,4,8,14,4,15,12,11,13,3,8,6,7,6,0,7,6,11,3,1,7,10,14,14,3,14,8,7,7,3,11,8,11,15,7,12]

theorem envBound60870 : H12AffineFastState.Bounded env60870 := by
  intro p hp
  have h : env60870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60869_60870 : H12AffineEnvironment.transform 3 14 env60869 = env60870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 14 env60869 == env60870) = true)

theorem identity60870 : scanCanonicalize (H12AffineFastState.compose env60870 (packedSelected [8] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound60870 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env60871 : List Nat := [2,2,8,8,2,9,10,11,11,3,8,0,1,0,0,1,0,11,3,1,1,10,8,8,3,8,8,1,1,3,11,8,11,9,1,10]

theorem envBound60871 : H12AffineFastState.Bounded env60871 := by
  intro p hp
  have h : env60871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60870_60871 : H12AffineEnvironment.transform 1 2 env60870 = env60871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env60870 == env60871) = true)

theorem identity60871 : scanCanonicalize (H12AffineFastState.compose env60871 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound60871 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env60872 : List Nat := [1,1,8,8,1,9,9,8,8,0,8,0,1,0,0,1,0,8,0,1,1,9,8,8,0,8,8,1,1,0,8,8,8,9,1,9]

theorem envBound60872 : H12AffineFastState.Bounded env60872 := by
  intro p hp
  have h : env60872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60871_60872 : H12AffineEnvironment.transform 0 1 env60871 = env60872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env60871 == env60872) = true)

def env60873 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1345,65665,77934,13341,4097,476,16,69648,70886,78895,77840,1297,74814,81226,8205,74799,256,65830,1344,79471]

theorem envBound60873 : H12AffineFastState.Bounded env60873 := by
  intro p hp
  have h : env60873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60849_60873 : H12AffineEnvironment.transform 17 65665 env60849 = env60873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env60849 == env60873) = true)

theorem identity60873 : scanCanonicalize (H12AffineFastState.compose env60873 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5239) := by decide +kernel

theorem selectedBound60873 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env60874 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,5239,1345,5366,9241,13341,4097,476,16,1127,145,8280,9319,1297,12361,10557,8205,12376,256,5457,1344,8728]

theorem envBound60874 : H12AffineFastState.Bounded env60874 := by
  intro p hp
  have h : env60874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60873_60874 : H12AffineEnvironment.transform 15 5239 env60873 = env60874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5239 env60873 == env60874) = true)

def env60875 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,1296,13340,5159,1297,5286,9241,13341,4097,396,16,1079,145,8200,9271,1297,12313,10557,8205,12296,256,5377,1296,8728]

theorem envBound60875 : H12AffineFastState.Bounded env60875 := by
  intro p hp
  have h : env60875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60874_60875 : H12AffineEnvironment.transform 5 16 env60874 = env60875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env60874 == env60875) = true)

theorem identity60875 : scanCanonicalize (H12AffineFastState.compose env60875 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound60875 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60876 : List Nat := [2,4,8,16,32,16,128,20,512,1024,2048,4096,8192,1028,13340,5159,1029,5286,9241,13341,4097,152,16,1079,145,8200,9271,1029,12313,10281,8205,12296,20,5141,1028,8728]

theorem envBound60876 : H12AffineFastState.Bounded env60876 := by
  intro p hp
  have h : env60876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60875_60876 : H12AffineEnvironment.transform 7 20 env60875 = env60876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env60875 == env60876) = true)

theorem identity60876 : scanCanonicalize (H12AffineFastState.compose env60876 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(12+1) ^^^ 5148) := by decide +kernel

theorem selectedBound60876 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env60877 : List Nat := [2,4,8,16,32,16,128,20,512,1024,2048,4096,5148,1028,0,5159,1029,5286,4101,1,4097,152,16,1079,145,5140,4139,1029,1029,7221,5137,1044,20,5141,1028,5636]

theorem envBound60877 : H12AffineFastState.Bounded env60877 := by
  intro p hp
  have h : env60877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60876_60877 : H12AffineEnvironment.transform 12 5148 env60876 = env60877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5148 env60876 == env60877) = true)

theorem identity60877 : scanCanonicalize (H12AffineFastState.compose env60877 (packedSelected [10,11,13,17,18,19] rootPS)) = affineNative (2^(11+1) ^^^ 1190) := by decide +kernel

theorem selectedBound60877 : packedSelected [10,11,13,17,18,19] rootPS < 2^1333 := by decide +kernel

def env60878 : List Nat := [2,4,8,16,32,16,128,20,512,1024,2048,1190,186,1028,0,129,1029,0,1187,1,1191,152,16,1079,145,178,1165,1029,1029,2195,183,1044,20,179,1028,674]

theorem envBound60878 : H12AffineFastState.Bounded env60878 := by
  intro p hp
  have h : env60878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60877_60878 : H12AffineEnvironment.transform 11 1190 env60877 = env60878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1190 env60877 == env60878) = true)

theorem identity60878 : scanCanonicalize (H12AffineFastState.compose env60878 (packedSelected [2,13,17] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound60878 : packedSelected [2,13,17] rootPS < 2^1333 := by decide +kernel

def env60879 : List Nat := [2,4,8,16,32,16,128,20,512,1024,512,1190,186,1028,0,129,1029,0,1187,1,1191,152,16,1079,145,178,1165,1029,1029,659,183,1044,20,179,1028,674]

theorem envBound60879 : H12AffineFastState.Bounded env60879 := by
  intro p hp
  have h : env60879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60878_60879 : H12AffineEnvironment.transform 10 512 env60878 = env60879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env60878 == env60879) = true)

theorem identity60879 : scanCanonicalize (H12AffineFastState.compose env60879 (packedSelected [0,2,3,5,7,11,13] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound60879 : packedSelected [0,2,3,5,7,11,13] rootPS < 2^1333 := by decide +kernel

def env60880 : List Nat := [2,4,8,16,32,16,128,20,27,1024,27,1190,186,1028,0,129,1029,0,1187,1,1191,152,16,1079,145,178,1165,1029,1029,136,183,1044,20,179,1028,185]

theorem envBound60880 : H12AffineFastState.Bounded env60880 := by
  intro p hp
  have h : env60880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60879_60880 : H12AffineEnvironment.transform 8 27 env60879 = env60880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env60879 == env60880) = true)

theorem identity60880 : scanCanonicalize (H12AffineFastState.compose env60880 (packedSelected [1,4,5,9] rootPS)) = affineNative (2^(9+1) ^^^ 47) := by decide +kernel

theorem selectedBound60880 : packedSelected [1,4,5,9] rootPS < 2^1333 := by decide +kernel

def env60881 : List Nat := [2,4,8,16,32,16,128,20,27,47,27,137,186,43,0,129,42,0,140,1,136,152,16,24,145,178,162,42,42,136,183,59,20,179,43,185]

theorem envBound60881 : H12AffineFastState.Bounded env60881 := by
  intro p hp
  have h : env60881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60880_60881 : H12AffineEnvironment.transform 9 47 env60880 = env60881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 47 env60880 == env60881) = true)

theorem identity60881 : scanCanonicalize (H12AffineFastState.compose env60881 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound60881 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env60882 : List Nat := [2,4,8,10,32,10,128,14,1,47,1,137,160,43,0,129,42,0,140,1,136,130,10,2,139,168,162,42,42,136,173,33,14,169,43,163]

theorem envBound60882 : H12AffineFastState.Bounded env60882 := by
  intro p hp
  have h : env60882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60881_60882 : H12AffineEnvironment.transform 3 10 env60881 = env60882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env60881 == env60882) = true)

theorem identity60882 : scanCanonicalize (H12AffineFastState.compose env60882 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound60882 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env60883 : List Nat := [2,4,8,10,32,10,35,14,1,47,1,42,3,43,0,34,42,0,47,1,43,33,10,2,40,11,1,42,42,43,14,33,14,10,43,0]

theorem envBound60883 : H12AffineFastState.Bounded env60883 := by
  intro p hp
  have h : env60883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60882_60883 : H12AffineEnvironment.transform 6 35 env60882 = env60883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env60882 == env60883) = true)

theorem identity60883 : scanCanonicalize (H12AffineFastState.compose env60883 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound60883 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env60884 : List Nat := [2,4,1,3,32,3,35,7,1,38,1,35,3,34,0,34,35,0,38,1,34,33,3,2,33,2,1,35,35,34,7,33,7,3,34,0]

theorem envBound60884 : H12AffineFastState.Bounded env60884 := by
  intro p hp
  have h : env60884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60883_60884 : H12AffineEnvironment.transform 2 1 env60883 = env60884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env60883 == env60884) = true)

theorem identity60884 : scanCanonicalize (H12AffineFastState.compose env60884 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound60884 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60885 : List Nat := [2,4,1,3,3,3,0,7,1,5,1,0,3,1,0,1,0,0,5,1,1,2,3,2,2,2,1,0,0,1,7,2,7,3,1,0]

theorem envBound60885 : H12AffineFastState.Bounded env60885 := by
  intro p hp
  have h : env60885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60884_60885 : H12AffineEnvironment.transform 4 3 env60884 = env60885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env60884 == env60885) = true)

theorem identity60885 : scanCanonicalize (H12AffineFastState.compose env60885 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound60885 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60886 : List Nat := [2,3,1,3,3,3,0,0,1,2,1,0,3,1,0,1,0,0,2,1,1,2,3,2,2,2,1,0,0,1,0,2,0,3,1,0]

theorem envBound60886 : H12AffineFastState.Bounded env60886 := by
  intro p hp
  have h : env60886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60885_60886 : H12AffineEnvironment.transform 1 3 env60885 = env60886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env60885 == env60886) = true)

theorem identity60886 : scanCanonicalize (H12AffineFastState.compose env60886 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound60886 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env60887 : List Nat := [1,0,1,0,0,0,0,0,1,1,1,0,0,1,0,1,0,0,1,1,1,1,0,1,1,1,1,0,0,1,0,1,0,0,1,0]

theorem envBound60887 : H12AffineFastState.Bounded env60887 := by
  intro p hp
  have h : env60887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60886_60887 : H12AffineEnvironment.transform 0 1 env60886 = env60887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env60886 == env60887) = true)

def env60888 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,1296,13340,5158,1296,5287,9241,13341,4097,397,16,1078,145,8201,9270,1297,12312,10557,8205,12297,256,5376,1297,8728]

theorem envBound60888 : H12AffineFastState.Bounded env60888 := by
  intro p hp
  have h : env60888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60874_60888 : H12AffineEnvironment.transform 5 17 env60874 = env60888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env60874 == env60888) = true)

theorem identity60888 : scanCanonicalize (H12AffineFastState.compose env60888 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound60888 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60889 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,269,1296,5393,5158,1296,5287,1300,5392,4097,397,16,1078,145,260,1339,1297,4373,2096,256,4356,256,5376,1297,789]

theorem envBound60889 : H12AffineFastState.Bounded env60889 := by
  intro p hp
  have h : env60889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60888_60889 : H12AffineEnvironment.transform 12 269 env60888 = env60889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env60888 == env60889) = true)

theorem identity60889 : scanCanonicalize (H12AffineFastState.compose env60889 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound60889 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env60890 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1029,269,1296,276,35,1296,162,1300,277,1028,397,16,1078,145,260,1339,1297,1296,2096,256,1281,256,261,1297,789]

theorem envBound60890 : H12AffineFastState.Bounded env60890 := by
  intro p hp
  have h : env60890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60889_60890 : H12AffineEnvironment.transform 11 1029 env60889 = env60890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env60889 == env60890) = true)

theorem identity60890 : scanCanonicalize (H12AffineFastState.compose env60890 (packedSelected [0,1,2,5,7,10,11,19] rootPS)) = affineNative (2^(8+1) ^^^ 391) := by decide +kernel

theorem selectedBound60890 : packedSelected [0,1,2,5,7,10,11,19] rootPS < 2^1333 := by decide +kernel

def env60891 : List Nat := [2,4,8,16,32,17,128,256,391,1024,2048,1029,269,1296,276,35,1296,162,1300,277,1028,397,16,1078,145,260,1339,1297,1296,2096,256,1281,256,261,1297,146]

theorem envBound60891 : H12AffineFastState.Bounded env60891 := by
  intro p hp
  have h : env60891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60890_60891 : H12AffineEnvironment.transform 8 391 env60890 = env60891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 391 env60890 == env60891) = true)

theorem identity60891 : scanCanonicalize (H12AffineFastState.compose env60891 (packedSelected [5,8,13] rootPS)) = affineNative (2^(10+1) ^^^ 146) := by decide +kernel

theorem selectedBound60891 : packedSelected [5,8,13] rootPS < 2^1333 := by decide +kernel

def env60892 : List Nat := [2,4,8,16,32,17,128,256,391,1024,146,1029,269,1296,276,35,1296,162,1300,277,1028,397,16,1078,145,260,1339,1297,1296,162,256,1281,256,261,1297,146]

theorem envBound60892 : H12AffineFastState.Bounded env60892 := by
  intro p hp
  have h : env60892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60891_60892 : H12AffineEnvironment.transform 10 146 env60891 = env60892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 146 env60891 == env60892) = true)

theorem identity60892 : scanCanonicalize (H12AffineFastState.compose env60892 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound60892 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env60893 : List Nat := [2,4,8,16,32,17,57,256,318,1024,43,1029,269,1296,276,35,1296,27,1300,277,1028,308,16,1078,40,260,1339,1297,1296,27,256,1281,256,261,1297,43]

theorem envBound60893 : H12AffineFastState.Bounded env60893 := by
  intro p hp
  have h : env60893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60892_60893 : H12AffineEnvironment.transform 6 57 env60892 = env60893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env60892 == env60893) = true)

end H12CloudChart2