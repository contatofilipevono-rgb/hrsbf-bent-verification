import H12CloudChart2Data216

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env54698 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,1213,1685,1212,560,531,1213,1583,1024,561,1212,1060,16,1166,1564,17,1702,1212,1213,3213,173,168,173,168,1213,512]

theorem envBound54698 : H12AffineFastState.Bounded env54698 := by
  intro p hp
  have h : env54698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54697_54698 : H12AffineEnvironment.transform 17 1583 env54697 = env54698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1583 env54697 == env54698) = true)

theorem identity54698 : scanCanonicalize (H12AffineFastState.compose env54698 (packedSelected [1,3,17] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound54698 : packedSelected [1,3,17] rootPS < 2^1333 := by decide +kernel

def env54699 : List Nat := [2,4,8,16,32,16,128,172,512,5,2048,184,656,185,560,531,184,554,5,561,185,33,16,139,537,17,675,185,184,2184,173,168,173,168,184,512]

theorem envBound54699 : H12AffineFastState.Bounded env54699 := by
  intro p hp
  have h : env54699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54698_54699 : H12AffineEnvironment.transform 9 5 env54698 = env54699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env54698 == env54699) = true)

theorem identity54699 : scanCanonicalize (H12AffineFastState.compose env54699 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound54699 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54700 : List Nat := [2,4,8,16,32,16,128,172,512,5,49,184,656,185,560,531,184,554,5,561,185,33,16,139,537,17,675,185,184,185,173,168,173,168,184,512]

theorem envBound54700 : H12AffineFastState.Bounded env54700 := by
  intro p hp
  have h : env54700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54699_54700 : H12AffineEnvironment.transform 10 49 env54699 = env54700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env54699 == env54700) = true)

theorem identity54700 : scanCanonicalize (H12AffineFastState.compose env54700 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound54700 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env54701 : List Nat := [2,4,8,16,32,16,128,172,27,5,49,184,139,185,43,8,184,49,5,42,185,33,16,139,2,17,184,185,184,185,173,168,173,168,184,27]

theorem envBound54701 : H12AffineFastState.Bounded env54701 := by
  intro p hp
  have h : env54701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54700_54701 : H12AffineEnvironment.transform 8 27 env54700 = env54701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env54700 == env54701) = true)

theorem identity54701 : scanCanonicalize (H12AffineFastState.compose env54701 (packedSelected [0,1,4] rootPS)) = affineNative (2^(6+1) ^^^ 21) := by decide +kernel

theorem selectedBound54701 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env54702 : List Nat := [2,4,8,16,32,16,21,57,27,5,49,45,30,44,43,8,45,49,5,42,44,33,16,30,2,17,45,44,45,44,56,61,56,61,45,27]

theorem envBound54702 : H12AffineFastState.Bounded env54702 := by
  intro p hp
  have h : env54702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54701_54702 : H12AffineEnvironment.transform 6 21 env54701 = env54702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 21 env54701 == env54702) = true)

theorem identity54702 : scanCanonicalize (H12AffineFastState.compose env54702 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound54702 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env54703 : List Nat := [2,4,8,13,32,13,8,36,6,5,44,45,3,44,43,8,45,44,5,42,44,33,13,3,2,12,45,44,45,44,37,32,37,32,45,6]

theorem envBound54703 : H12AffineFastState.Bounded env54703 := by
  intro p hp
  have h : env54703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54702_54703 : H12AffineEnvironment.transform 3 13 env54702 = env54703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env54702 == env54703) = true)

theorem identity54703 : scanCanonicalize (H12AffineFastState.compose env54703 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound54703 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54704 : List Nat := [2,3,8,10,32,10,8,35,1,2,43,42,3,43,43,8,42,43,2,42,43,33,10,3,2,11,42,43,42,43,34,32,34,32,42,1]

theorem envBound54704 : H12AffineFastState.Bounded env54704 := by
  intro p hp
  have h : env54704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54703_54704 : H12AffineEnvironment.transform 1 3 env54703 = env54704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env54703 == env54704) = true)

theorem identity54704 : scanCanonicalize (H12AffineFastState.compose env54704 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound54704 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54705 : List Nat := [2,3,8,10,10,10,8,9,1,2,1,0,3,1,1,8,0,1,2,0,1,11,10,3,2,11,0,1,0,1,8,10,8,10,0,1]

theorem envBound54705 : H12AffineFastState.Bounded env54705 := by
  intro p hp
  have h : env54705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54704_54705 : H12AffineEnvironment.transform 4 10 env54704 = env54705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env54704 == env54705) = true)

def env54706 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61569,147472,58519,143497,20496,508074,148668,148669,96267,90263,74798,173,204946,1212,135680]

theorem envBound54706 : H12AffineFastState.Bounded env54706 := by
  intro p hp
  have h : env54706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54690_54706 : H12AffineEnvironment.transform 5 17 env54690 = env54706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env54690 == env54706) = true)

theorem identity54706 : scanCanonicalize (H12AffineFastState.compose env54706 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 208055) := by decide +kernel

theorem selectedBound54706 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env54707 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,208055,136192,32769,4097,61569,147472,58519,143497,20496,60445,148668,148669,96267,90263,74798,173,204946,1212,135680]

theorem envBound54707 : H12AffineFastState.Bounded env54707 := by
  intro p hp
  have h : env54707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54706_54707 : H12AffineEnvironment.transform 17 208055 env54706 = env54707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 208055 env54706 == env54707) = true)

theorem identity54707 : scanCanonicalize (H12AffineFastState.compose env54707 (packedSelected [1,3,5,7,8,10,20,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53283) := by decide +kernel

theorem selectedBound54707 : packedSelected [1,3,5,7,8,10,20,26,27] rootPS < 2^1333 := by decide +kernel

def env54708 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,53283,131072,195732,136192,32769,4097,61569,147472,58519,143497,20496,60445,148668,148669,43048,45236,62477,173,192689,1212,135680]

theorem envBound54708 : H12AffineFastState.Bounded env54708 := by
  intro p hp
  have h : env54708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54707_54708 : H12AffineEnvironment.transform 15 53283 env54707 = env54708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53283 env54707 == env54708) = true)

theorem identity54708 : scanCanonicalize (H12AffineFastState.compose env54708 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(16+1) ^^^ 21692) := by decide +kernel

theorem selectedBound54708 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env54709 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,53283,21692,43048,16572,32769,4097,61569,5292,58519,25653,20496,60445,4096,4097,43048,45236,62477,173,41997,1212,18108]

theorem envBound54709 : H12AffineFastState.Bounded env54709 := by
  intro p hp
  have h : env54709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54708_54709 : H12AffineEnvironment.transform 16 21692 env54708 = env54709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 21692 env54708 == env54709) = true)

theorem identity54709 : scanCanonicalize (H12AffineFastState.compose env54709 (packedSelected [4,9,20] rootPS)) = affineNative (2^(14+1) ^^^ 9381) := by decide +kernel

theorem selectedBound54709 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env54710 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,9381,29830,21692,3213,16572,9380,4097,21540,5292,16434,25653,20496,18616,4096,4097,3213,5137,20648,173,168,1212,18108]

theorem envBound54710 : H12AffineFastState.Bounded env54710 := by
  intro p hp
  have h : env54710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54709_54710 : H12AffineEnvironment.transform 14 9381 env54709 = env54710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9381 env54709 == env54710) = true)

theorem identity54710 : scanCanonicalize (H12AffineFastState.compose env54710 (packedSelected [0,2,3,5,6,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 13988) := by decide +kernel

theorem selectedBound54710 : packedSelected [0,2,3,5,6,9,11] rootPS < 2^1333 := by decide +kernel

def env54711 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,13988,9381,546,8728,3213,13848,9380,4097,8832,5292,13974,4753,9908,15900,4096,4097,3213,5137,9740,173,168,1212,12312]

theorem envBound54711 : H12AffineFastState.Bounded env54711 := by
  intro p hp
  have h : env54711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54710_54711 : H12AffineEnvironment.transform 13 13988 env54710 = env54711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13988 env54710 == env54711) = true)

theorem identity54711 : scanCanonicalize (H12AffineFastState.compose env54711 (packedSelected [0,1,2,4,5,7,9,15,16,17] rootPS)) = affineNative (2^(10+1) ^^^ 1174) := by decide +kernel

theorem selectedBound54711 : packedSelected [0,1,2,4,5,7,9,15,16,17] rootPS < 2^1333 := by decide +kernel

def env54712 : List Nat := [2,4,8,16,32,17,128,172,512,1024,1174,4096,8192,13988,9381,546,8728,27,13848,9380,4097,8832,5292,13974,4753,9908,12938,4096,4097,27,5137,9740,173,168,1212,12312]

theorem envBound54712 : H12AffineFastState.Bounded env54712 := by
  intro p hp
  have h : env54712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54711_54712 : H12AffineEnvironment.transform 10 1174 env54711 = env54712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1174 env54711 == env54712) = true)

theorem identity54712 : scanCanonicalize (H12AffineFastState.compose env54712 (packedSelected [0,2,3,4,5,7,9,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 5677) := by decide +kernel

theorem selectedBound54712 : packedSelected [0,2,3,4,5,7,9,15,16] rootPS < 2^1333 := by decide +kernel

def env54713 : List Nat := [2,4,8,16,32,17,128,172,512,1024,1174,4096,5677,137,4744,546,5173,27,53,4745,4097,5293,5292,187,4753,4249,1191,4096,4097,27,5137,4129,173,168,1212,1589]

theorem envBound54713 : H12AffineFastState.Bounded env54713 := by
  intro p hp
  have h : env54713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54712_54713 : H12AffineEnvironment.transform 12 5677 env54712 = env54713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5677 env54712 == env54713) = true)

theorem identity54713 : scanCanonicalize (H12AffineFastState.compose env54713 (packedSelected [0,1,5,6,9,12] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound54713 : packedSelected [0,1,5,6,9,12] rootPS < 2^1333 := by decide +kernel

def env54714 : List Nat := [2,4,8,16,32,17,128,172,512,517,659,4096,4136,137,4744,546,4656,27,53,4745,4097,4776,4777,187,4753,4249,674,4096,4097,27,4628,4129,173,168,697,48]

theorem envBound54714 : H12AffineFastState.Bounded env54714 := by
  intro p hp
  have h : env54714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54713_54714 : H12AffineEnvironment.transform 9 517 env54713 = env54714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env54713 == env54714) = true)

theorem identity54714 : scanCanonicalize (H12AffineFastState.compose env54714 (packedSelected [1,2,8] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound54714 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env54715 : List Nat := [2,4,8,16,32,17,128,172,43,46,184,4096,4136,137,4259,9,4123,27,53,4258,4097,4227,4226,187,4282,4249,137,4096,4097,27,4159,4129,173,168,146,48]

theorem envBound54715 : H12AffineFastState.Bounded env54715 := by
  intro p hp
  have h : env54715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54714_54715 : H12AffineEnvironment.transform 8 43 env54714 = env54715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env54714 == env54715) = true)

theorem identity54715 : scanCanonicalize (H12AffineFastState.compose env54715 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound54715 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env54716 : List Nat := [2,4,8,16,32,17,57,21,43,46,1,4096,4136,48,4122,9,4123,27,53,4123,4097,4154,4155,2,4099,4128,48,4096,4097,27,4159,4129,20,17,43,48]

theorem envBound54716 : H12AffineFastState.Bounded env54716 := by
  intro p hp
  have h : env54716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54715_54716 : H12AffineEnvironment.transform 6 57 env54715 = env54716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env54715 == env54716) = true)

theorem identity54716 : scanCanonicalize (H12AffineFastState.compose env54716 (packedSelected [1,2,5,6] rootPS)) = affineNative (2^(11+1) ^^^ 42) := by decide +kernel

theorem selectedBound54716 : packedSelected [1,2,5,6] rootPS < 2^1333 := by decide +kernel

def env54717 : List Nat := [2,4,8,16,32,17,57,21,43,46,1,42,2,48,48,9,49,27,53,49,43,16,17,2,41,10,48,42,43,27,21,11,20,17,43,48]

theorem envBound54717 : H12AffineFastState.Bounded env54717 := by
  intro p hp
  have h : env54717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54716_54717 : H12AffineEnvironment.transform 11 42 env54716 = env54717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 42 env54716 == env54717) = true)

def env54718 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147521,58518,143497,20496,508155,148716,148717,96346,90262,74798,172,204994,1260,135680]

theorem envBound54718 : H12AffineFastState.Bounded env54718 := by
  intro p hp
  have h : env54718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54689_54718 : H12AffineEnvironment.transform 7 173 env54689 = env54718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env54689 == env54718) = true)

def env54719 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61568,147473,58518,143497,20496,508075,148668,148669,96266,90262,74798,172,204946,1212,135680]

theorem envBound54719 : H12AffineFastState.Bounded env54719 := by
  intro p hp
  have h : env54719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54718_54719 : H12AffineEnvironment.transform 5 16 env54718 = env54719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env54718 == env54719) = true)

theorem identity54719 : scanCanonicalize (H12AffineFastState.compose env54719 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 45217) := by decide +kernel

theorem selectedBound54719 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env54720 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,45217,262144,42145,32769,4097,61568,61616,58518,32808,20496,356362,62493,62492,96266,90262,74798,172,102451,1212,41633]

theorem envBound54720 : H12AffineFastState.Bounded env54720 := by
  intro p hp
  have h : env54720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54719_54720 : H12AffineEnvironment.transform 16 45217 env54719 = env54720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45217 env54719 == env54720) = true)

theorem identity54720 : scanCanonicalize (H12AffineFastState.compose env54720 (packedSelected [16,20] rootPS)) = affineNative (2^(17+1) ^^^ 2184) := by decide +kernel

theorem selectedBound54720 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env54721 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,45217,2184,42145,32769,4097,61568,61616,58518,32808,20496,96386,62493,62492,96266,90262,74798,172,102451,1212,41633]

theorem envBound54721 : H12AffineFastState.Bounded env54721 := by
  intro p hp
  have h : env54721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54720_54721 : H12AffineEnvironment.transform 17 2184 env54720 = env54721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2184 env54720 == env54721) = true)

theorem identity54721 : scanCanonicalize (H12AffineFastState.compose env54721 (packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS)) = affineNative (2^(15+1) ^^^ 12346) := by decide +kernel

theorem selectedBound54721 : packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env54722 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,12346,45217,2184,42145,32769,4097,61568,61616,58518,32808,20496,18616,62493,62492,18480,20652,5140,172,40969,1212,41633]

theorem envBound54722 : H12AffineFastState.Bounded env54722 := by
  intro p hp
  have h : env54722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54721_54722 : H12AffineEnvironment.transform 15 12346 env54721 = env54722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12346 env54721 == env54722) = true)

theorem identity54722 : scanCanonicalize (H12AffineFastState.compose env54722 (packedSelected [1,4,5,8,9,16,17,21,24] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound54722 : packedSelected [1,4,5,8,9,16,17,21,24] rootPS < 2^1333 := by decide +kernel

def env54723 : List Nat := [2,4,8,16,32,16,128,173,512,5,2048,4096,8192,16384,32768,12346,45217,2184,41124,32769,4097,61568,61616,57491,32808,20496,18616,61464,61465,18480,20652,4113,172,40969,185,41633]

theorem envBound54723 : H12AffineFastState.Bounded env54723 := by
  intro p hp
  have h : env54723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54722_54723 : H12AffineEnvironment.transform 9 5 env54722 = env54723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env54722 == env54723) = true)

theorem identity54723 : scanCanonicalize (H12AffineFastState.compose env54723 (packedSelected [2,3,5,6,10,15,17] rootPS)) = affineNative (2^(13+1) ^^^ 10912) := by decide +kernel

theorem selectedBound54723 : packedSelected [2,3,5,6,10,15,17] rootPS < 2^1333 := by decide +kernel

def env54724 : List Nat := [2,4,8,16,32,16,128,173,512,5,2048,4096,8192,10912,32768,12346,45217,2184,41124,32769,4097,39456,39440,35379,32808,15024,8728,39608,39609,8848,14860,4113,172,40969,185,41633]

theorem envBound54724 : H12AffineFastState.Bounded env54724 := by
  intro p hp
  have h : env54724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54723_54724 : H12AffineEnvironment.transform 13 10912 env54723 = env54724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 10912 env54723 == env54724) = true)

theorem identity54724 : scanCanonicalize (H12AffineFastState.compose env54724 (packedSelected [2,4,7,10,12,13,16] rootPS)) = affineNative (2^(12+1) ^^^ 4257) := by decide +kernel

theorem selectedBound54724 : packedSelected [2,4,7,10,12,13,16] rootPS < 2^1333 := by decide +kernel

def env54725 : List Nat := [2,4,8,16,32,16,128,173,512,5,2048,4096,4257,6657,32768,155,32768,2184,36869,32769,4097,39456,39440,35379,32808,2577,4793,39608,39609,4657,2733,4113,172,37032,185,37376]

theorem envBound54725 : H12AffineFastState.Bounded env54725 := by
  intro p hp
  have h : env54725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54724_54725 : H12AffineEnvironment.transform 12 4257 env54724 = env54725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4257 env54724 == env54725) = true)

theorem identity54725 : scanCanonicalize (H12AffineFastState.compose env54725 (packedSelected [0,3,4,6,7,8,9,11] rootPS)) = affineNative (2^(14+1) ^^^ 4771) := by decide +kernel

theorem selectedBound54725 : packedSelected [0,3,4,6,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env54726 : List Nat := [2,4,8,16,32,16,128,173,512,5,2048,4096,4257,6657,4771,155,4771,2184,678,4770,4097,2179,2227,6288,4747,2577,4793,2075,2074,4657,2733,4113,172,523,185,163]

theorem envBound54726 : H12AffineFastState.Bounded env54726 := by
  intro p hp
  have h : env54726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54725_54726 : H12AffineEnvironment.transform 14 4771 env54725 = env54726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 4771 env54725 == env54726) = true)

theorem identity54726 : scanCanonicalize (H12AffineFastState.compose env54726 (packedSelected [2,6,10,12] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound54726 : packedSelected [2,6,10,12] rootPS < 2^1333 := by decide +kernel

def env54727 : List Nat := [2,4,8,16,32,16,128,173,42,5,2048,4096,4257,6187,4233,155,4233,2184,140,4232,4097,2179,2227,6288,4257,2107,4243,2075,2074,4123,2183,4113,172,33,185,163]

theorem envBound54727 : H12AffineFastState.Bounded env54727 := by
  intro p hp
  have h : env54727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54726_54727 : H12AffineEnvironment.transform 8 42 env54726 = env54727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env54726 == env54727) = true)

theorem identity54727 : scanCanonicalize (H12AffineFastState.compose env54727 (packedSelected [4,6,9] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound54727 : packedSelected [4,6,9] rootPS < 2^1333 := by decide +kernel

def env54728 : List Nat := [2,4,8,16,32,16,57,20,42,5,2048,4096,4120,6187,4144,34,4144,2097,53,4145,4097,2106,2058,6185,4120,2107,4138,2075,2074,4123,2110,4113,21,33,0,26]

theorem envBound54728 : H12AffineFastState.Bounded env54728 := by
  intro p hp
  have h : env54728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54727_54728 : H12AffineEnvironment.transform 6 57 env54727 = env54728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env54727 == env54728) = true)

theorem identity54728 : scanCanonicalize (H12AffineFastState.compose env54728 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 27) := by decide +kernel

theorem selectedBound54728 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env54729 : List Nat := [2,4,8,16,32,16,57,20,42,5,27,4096,4120,4144,4144,34,4144,42,53,4145,4097,33,17,4146,4120,32,4138,0,1,4123,37,4113,21,33,0,26]

theorem envBound54729 : H12AffineFastState.Bounded env54729 := by
  intro p hp
  have h : env54729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54728_54729 : H12AffineEnvironment.transform 10 27 env54728 = env54729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 27 env54728 == env54729) = true)

theorem identity54729 : scanCanonicalize (H12AffineFastState.compose env54729 (packedSelected [3,5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound54729 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env54730 : List Nat := [2,4,8,16,17,16,8,20,27,5,27,4096,4120,4097,4097,19,4097,27,4,4096,4097,16,17,4099,4120,17,4123,0,1,4123,20,4113,21,16,0,26]

theorem envBound54730 : H12AffineFastState.Bounded env54730 := by
  intro p hp
  have h : env54730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54729_54730 : H12AffineEnvironment.transform 4 17 env54729 = env54730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env54729 == env54730) = true)

theorem identity54730 : scanCanonicalize (H12AffineFastState.compose env54730 (packedSelected [0,1] rootPS)) = affineNative (2^(11+1) ^^^ 19) := by decide +kernel

theorem selectedBound54730 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env54731 : List Nat := [2,4,8,16,17,16,8,20,27,5,27,19,11,18,18,19,18,27,4,19,18,16,17,16,11,17,8,0,1,8,20,2,21,16,0,26]

theorem envBound54731 : H12AffineFastState.Bounded env54731 := by
  intro p hp
  have h : env54731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54730_54731 : H12AffineEnvironment.transform 11 19 env54730 = env54731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 19 env54730 == env54731) = true)

theorem identity54731 : scanCanonicalize (H12AffineFastState.compose env54731 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound54731 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54732 : List Nat := [2,4,0,16,17,16,0,20,19,5,19,19,3,18,18,19,18,19,4,19,18,16,17,16,3,17,0,0,1,0,20,2,21,16,0,18]

theorem envBound54732 : H12AffineFastState.Bounded env54732 := by
  intro p hp
  have h : env54732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54731_54732 : H12AffineEnvironment.transform 2 0 env54731 = env54732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env54731 == env54732) = true)

theorem identity54732 : scanCanonicalize (H12AffineFastState.compose env54732 (packedSelected [0,3] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound54732 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env54733 : List Nat := [2,4,0,3,2,3,0,7,0,5,0,0,3,1,1,0,1,0,4,0,1,3,2,3,3,2,0,0,1,0,7,2,6,3,0,1]

theorem envBound54733 : H12AffineFastState.Bounded env54733 := by
  intro p hp
  have h : env54733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54732_54733 : H12AffineEnvironment.transform 3 3 env54732 = env54733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env54732 == env54733) = true)

theorem identity54733 : scanCanonicalize (H12AffineFastState.compose env54733 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound54733 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54734 : List Nat := [2,3,0,3,2,3,0,0,0,2,0,0,3,1,1,0,1,0,3,0,1,3,2,3,3,2,0,0,1,0,0,2,1,3,0,1]

theorem envBound54734 : H12AffineFastState.Bounded env54734 := by
  intro p hp
  have h : env54734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54733_54734 : H12AffineEnvironment.transform 1 3 env54733 = env54734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env54733 == env54734) = true)

theorem identity54734 : scanCanonicalize (H12AffineFastState.compose env54734 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound54734 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env54735 : List Nat := [1,0,0,0,1,0,0,0,0,1,0,0,0,1,1,0,1,0,0,0,1,0,1,0,0,1,0,0,1,0,0,1,1,0,0,1]

theorem envBound54735 : H12AffineFastState.Bounded env54735 := by
  intro p hp
  have h : env54735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54734_54735 : H12AffineEnvironment.transform 0 1 env54734 = env54735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env54734 == env54735) = true)

def env54736 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61569,147472,58518,143497,20496,508074,148669,148668,96267,90262,74798,172,204947,1213,135680]

theorem envBound54736 : H12AffineFastState.Bounded env54736 := by
  intro p hp
  have h : env54736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54718_54736 : H12AffineEnvironment.transform 5 17 env54718 = env54736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env54718 == env54736) = true)

theorem identity54736 : scanCanonicalize (H12AffineFastState.compose env54736 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 137353) := by decide +kernel

theorem selectedBound54736 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env54737 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,137353,136192,32769,4097,61569,147472,58518,143497,20496,120867,148669,148668,96267,90262,74798,172,204947,1213,135680]

theorem envBound54737 : H12AffineFastState.Bounded env54737 := by
  intro p hp
  have h : env54737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54736_54737 : H12AffineEnvironment.transform 17 137353 env54736 = env54737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137353 env54736 == env54737) = true)

theorem identity54737 : scanCanonicalize (H12AffineFastState.compose env54737 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(16+1) ^^^ 62493) := by decide +kernel

theorem selectedBound54737 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env54738 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,62493,60564,57373,32769,4097,61569,46093,58518,50324,20496,120867,45216,45217,96267,90262,74798,172,119950,1213,58909]

theorem envBound54738 : H12AffineFastState.Bounded env54738 := by
  intro p hp
  have h : env54738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54737_54738 : H12AffineEnvironment.transform 16 62493 env54737 = env54738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 62493 env54737 == env54738) = true)

theorem identity54738 : scanCanonicalize (H12AffineFastState.compose env54738 (packedSelected [4,9,16] rootPS)) = affineNative (2^(14+1) ^^^ 9380) := by decide +kernel

theorem selectedBound54738 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env54739 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,9380,65536,20665,18480,17593,9381,4097,21541,4265,16434,24624,20496,97415,5124,5125,96267,90262,74798,172,94250,1213,17081]

theorem envBound54739 : H12AffineFastState.Bounded env54739 := by
  intro p hp
  have h : env54739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54738_54739 : H12AffineEnvironment.transform 14 9380 env54738 = env54739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9380 env54738 == env54739) = true)

theorem identity54739 : scanCanonicalize (H12AffineFastState.compose env54739 (packedSelected [0,1,2,6,7,8,13,17,19,20,21] rootPS)) = affineNative (2^(12+1) ^^^ 7829) := by decide +kernel

theorem selectedBound54739 : packedSelected [0,1,2,6,7,8,13,17,19,20,21] rootPS < 2^1333 := by decide +kernel

def env54740 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,7829,16384,6705,65536,20665,18480,17593,6704,4097,21541,4265,16434,24229,20496,82450,5124,5125,83614,89603,72379,172,85695,1213,17081]

theorem envBound54740 : H12AffineFastState.Bounded env54740 := by
  intro p hp
  have h : env54740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54739_54740 : H12AffineEnvironment.transform 12 7829 env54739 = env54740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7829 env54739 == env54740) = true)

theorem identity54740 : scanCanonicalize (H12AffineFastState.compose env54740 (packedSelected [0,1,2,6,7,8,13,18,20,23,26] rootPS)) = affineNative (2^(15+1) ^^^ 18963) := by decide +kernel

theorem selectedBound54740 : packedSelected [0,1,2,6,7,8,13,18,20,23,26] rootPS < 2^1333 := by decide +kernel

def env54741 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,7829,16384,6705,18963,20665,18480,17593,6704,4097,21541,4265,16434,24229,20496,2049,5124,5125,3213,5136,20648,172,1196,1213,17081]

theorem envBound54741 : H12AffineFastState.Bounded env54741 := by
  intro p hp
  have h : env54741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54740_54741 : H12AffineEnvironment.transform 15 18963 env54740 = env54741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 18963 env54740 == env54741) = true)

theorem identity54741 : scanCanonicalize (H12AffineFastState.compose env54741 (packedSelected [0,1,6,8,9,10,12,13,15] rootPS)) = affineNative (2^(13+1) ^^^ 5636) := by decide +kernel

theorem selectedBound54741 : packedSelected [0,1,6,8,9,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env54742 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,7829,5636,6705,7191,1725,7732,4797,6704,4097,545,4265,5686,2209,1556,2049,5124,5125,3213,5136,1708,172,1196,1213,5309]

theorem envBound54742 : H12AffineFastState.Bounded env54742 := by
  intro p hp
  have h : env54742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54741_54742 : H12AffineEnvironment.transform 13 5636 env54741 = env54742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5636 env54741 == env54742) = true)

theorem identity54742 : scanCanonicalize (H12AffineFastState.compose env54742 (packedSelected [5,8,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 3734) := by decide +kernel

theorem selectedBound54742 : packedSelected [5,8,11,12] rootPS < 2^1333 := by decide +kernel

def env54743 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,3734,3,2194,1191,641,1725,162,3115,1190,3735,545,3647,2208,2209,1556,2049,2706,2707,3213,2694,1708,172,1196,1213,2603]

theorem envBound54743 : H12AffineFastState.Bounded env54743 := by
  intro p hp
  have h : env54743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54742_54743 : H12AffineEnvironment.transform 11 3734 env54742 = env54743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3734 env54742 == env54743) = true)

theorem identity54743 : scanCanonicalize (H12AffineFastState.compose env54743 (packedSelected [2,4,7,10,11,13] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound54743 : packedSelected [2,4,7,10,11,13] rootPS < 2^1333 := by decide +kernel

def env54744 : List Nat := [2,4,8,16,32,17,128,173,26,1024,2048,3212,3,2194,1191,155,1191,162,3115,1190,3213,59,3109,2208,2209,1038,2049,2184,2185,3213,2204,1206,172,1196,1213,2097]

theorem envBound54744 : H12AffineFastState.Bounded env54744 := by
  intro p hp
  have h : env54744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54743_54744 : H12AffineEnvironment.transform 8 26 env54743 = env54744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env54743 == env54744) = true)

theorem identity54744 : scanCanonicalize (H12AffineFastState.compose env54744 (packedSelected [2,4,5,6,8,9] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound54744 : packedSelected [2,4,5,6,8,9] rootPS < 2^1333 := by decide +kernel

def env54745 : List Nat := [2,4,8,10,32,11,128,173,0,1024,2048,3212,3,2184,1191,129,1191,162,3115,1190,3213,33,3109,2208,2209,1038,2049,2184,2185,3213,2182,1196,172,1196,1191,2091]

theorem envBound54745 : H12AffineFastState.Bounded env54745 := by
  intro p hp
  have h : env54745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54744_54745 : H12AffineEnvironment.transform 3 10 env54744 = env54745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env54744 == env54745) = true)

def env54746 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147521,58682,143496,20497,508154,148801,148801,96346,90426,74798,257,205167,1345,135681]

theorem envBound54746 : H12AffineFastState.Bounded env54746 := by
  intro p hp
  have h : env54746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54688_54746 : H12AffineEnvironment.transform 18 136193 env54688 = env54746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136193 env54688 == env54746) = true)

def env54747 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147521,58518,143496,20497,508154,148717,148717,96346,90262,74798,173,204995,1261,135681]

theorem envBound54747 : H12AffineFastState.Bounded env54747 := by
  intro p hp
  have h : env54747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54746_54747 : H12AffineEnvironment.transform 7 172 env54746 = env54747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env54746 == env54747) = true)

def env54748 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61568,147473,58518,143496,20497,508074,148669,148669,96266,90262,74798,173,204947,1213,135681]

theorem envBound54748 : H12AffineFastState.Bounded env54748 := by
  intro p hp
  have h : env54748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54747_54748 : H12AffineEnvironment.transform 5 16 env54747 = env54748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env54747 == env54748) = true)

theorem identity54748 : scanCanonicalize (H12AffineFastState.compose env54748 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 208054) := by decide +kernel

theorem selectedBound54748 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env54749 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,208054,136193,32769,4097,61568,147473,58518,143496,20497,60444,148669,148669,96266,90262,74798,173,204947,1213,135681]

theorem envBound54749 : H12AffineFastState.Bounded env54749 := by
  intro p hp
  have h : env54749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54748_54749 : H12AffineEnvironment.transform 17 208054 env54748 = env54749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 208054 env54748 == env54749) = true)

theorem identity54749 : scanCanonicalize (H12AffineFastState.compose env54749 (packedSelected [1,3,5,7,8,10,20,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53282) := by decide +kernel

theorem selectedBound54749 : packedSelected [1,3,5,7,8,10,20,26,27] rootPS < 2^1333 := by decide +kernel

def env54750 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,53282,131072,195732,136193,32769,4097,61568,147473,58518,143496,20497,60444,148669,148669,43048,45236,62476,173,192689,1213,135681]

theorem envBound54750 : H12AffineFastState.Bounded env54750 := by
  intro p hp
  have h : env54750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54749_54750 : H12AffineEnvironment.transform 15 53282 env54749 = env54750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53282 env54749 == env54750) = true)

theorem identity54750 : scanCanonicalize (H12AffineFastState.compose env54750 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(16+1) ^^^ 21692) := by decide +kernel

theorem selectedBound54750 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env54751 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,53282,21692,43048,16573,32769,4097,61568,5293,58518,25652,20497,60444,4097,4097,43048,45236,62476,173,41997,1213,18109]

theorem envBound54751 : H12AffineFastState.Bounded env54751 := by
  intro p hp
  have h : env54751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54750_54751 : H12AffineEnvironment.transform 16 21692 env54750 = env54751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 21692 env54750 == env54751) = true)

theorem identity54751 : scanCanonicalize (H12AffineFastState.compose env54751 (packedSelected [4,9,20] rootPS)) = affineNative (2^(14+1) ^^^ 9380) := by decide +kernel

theorem selectedBound54751 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env54752 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,9380,29830,21692,3212,16573,9381,4097,21540,5293,16434,25652,20497,18616,4097,4097,3212,5136,20648,173,169,1213,18109]

theorem envBound54752 : H12AffineFastState.Bounded env54752 := by
  intro p hp
  have h : env54752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54751_54752 : H12AffineEnvironment.transform 14 9380 env54751 = env54752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9380 env54751 == env54752) = true)

theorem identity54752 : scanCanonicalize (H12AffineFastState.compose env54752 (packedSelected [0,2,3,5,6,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 5661) := by decide +kernel

theorem selectedBound54752 : packedSelected [0,2,3,5,6,9,11] rootPS < 2^1333 := by decide +kernel

def env54753 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,5661,16384,4793,17051,21692,3212,16573,4792,4097,21540,5293,16434,21033,20497,18616,4097,4097,3212,5136,20648,173,169,1213,18109]

theorem envBound54753 : H12AffineFastState.Bounded env54753 := by
  intro p hp
  have h : env54753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54752_54753 : H12AffineEnvironment.transform 12 5661 env54752 = env54753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5661 env54752 == env54753) = true)

theorem identity54753 : scanCanonicalize (H12AffineFastState.compose env54753 (packedSelected [0,1,2,5,7,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 147) := by decide +kernel

theorem selectedBound54753 : packedSelected [0,1,2,5,7,15,17] rootPS < 2^1333 := by decide +kernel

def env54754 : List Nat := [2,4,8,16,32,16,128,172,512,1024,147,4096,5661,16384,4793,17051,21692,1055,16573,4792,4097,21540,5293,16434,21033,20497,16427,4097,4097,1055,5136,20648,173,169,1213,18109]

theorem envBound54754 : H12AffineFastState.Bounded env54754 := by
  intro p hp
  have h : env54754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54753_54754 : H12AffineEnvironment.transform 10 147 env54753 = env54754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 147 env54753 == env54754) = true)

theorem identity54754 : scanCanonicalize (H12AffineFastState.compose env54754 (packedSelected [0,2,3,4,5,7,9,15,16] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound54754 : packedSelected [0,2,3,4,5,7,9,15,16] rootPS < 2^1333 := by decide +kernel

def env54755 : List Nat := [2,4,8,16,17,16,128,157,512,1024,147,4096,5661,16384,4744,17051,21645,1055,16524,4745,4097,21525,5276,16387,21016,20497,16410,4097,4097,1055,5136,20633,156,152,1164,18060]

theorem envBound54755 : H12AffineFastState.Bounded env54755 := by
  intro p hp
  have h : env54755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54754_54755 : H12AffineEnvironment.transform 4 17 env54754 = env54755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env54754 == env54755) = true)

theorem identity54755 : scanCanonicalize (H12AffineFastState.compose env54755 (packedSelected [2,3,4,6,7,8,10,12] rootPS)) = affineNative (2^(13+1) ^^^ 1174) := by decide +kernel

theorem selectedBound54755 : packedSelected [2,3,4,6,7,8,10,12] rootPS < 2^1333 := by decide +kernel

def env54756 : List Nat := [2,4,8,16,17,16,128,157,512,1024,147,4096,5661,1174,4744,1549,4123,1055,1050,4745,4097,4227,5276,1173,5774,5255,1164,4097,4097,1055,5136,5135,156,152,1164,538]

theorem envBound54756 : H12AffineFastState.Bounded env54756 := by
  intro p hp
  have h : env54756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54755_54756 : H12AffineEnvironment.transform 13 1174 env54755 = env54756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1174 env54755 == env54756) = true)

theorem identity54756 : scanCanonicalize (H12AffineFastState.compose env54756 (packedSelected [0,1,2,5,9,10] rootPS)) = affineNative (2^(8+1) ^^^ 146) := by decide +kernel

theorem selectedBound54756 : packedSelected [0,1,2,5,9,10] rootPS < 2^1333 := by decide +kernel

def env54757 : List Nat := [2,4,8,16,17,16,128,157,146,1024,147,4096,5263,1174,4122,1183,4123,1055,1050,4123,4097,4227,5276,1173,5148,5255,1164,4097,4097,1055,5136,5135,156,152,1164,136]

theorem envBound54757 : H12AffineFastState.Bounded env54757 := by
  intro p hp
  have h : env54757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54756_54757 : H12AffineEnvironment.transform 8 146 env54756 = env54757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 146 env54756 == env54757) = true)

theorem identity54757 : scanCanonicalize (H12AffineFastState.compose env54757 (packedSelected [2,3,4,5,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 146) := by decide +kernel

theorem selectedBound54757 : packedSelected [2,3,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env54758 : List Nat := [2,4,8,16,17,16,128,157,146,1024,147,146,1053,1174,136,1183,137,1055,1050,137,147,17,1038,1173,1166,1045,1164,147,147,1055,1154,1181,156,152,1164,136]

theorem envBound54758 : H12AffineFastState.Bounded env54758 := by
  intro p hp
  have h : env54758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54757_54758 : H12AffineEnvironment.transform 11 146 env54757 = env54758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 146 env54757 == env54758) = true)

theorem identity54758 : scanCanonicalize (H12AffineFastState.compose env54758 (packedSelected [3,5,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound54758 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env54759 : List Nat := [2,4,8,16,17,16,8,21,26,1024,27,26,1053,1054,0,1047,1,1055,1050,1,27,17,1038,1053,1030,1045,1028,27,27,1055,1034,1045,20,16,1028,0]

theorem envBound54759 : H12AffineFastState.Bounded env54759 := by
  intro p hp
  have h : env54759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54758_54759 : H12AffineEnvironment.transform 6 8 env54758 = env54759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env54758 == env54759) = true)

theorem identity54759 : scanCanonicalize (H12AffineFastState.compose env54759 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound54759 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env54760 : List Nat := [2,4,8,10,11,10,8,15,0,1024,1,0,1031,1028,0,1037,1,1029,1024,1,1,11,1038,1031,1030,1039,1028,1,1,1029,1034,1039,14,10,1028,0]

theorem envBound54760 : H12AffineFastState.Bounded env54760 := by
  intro p hp
  have h : env54760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54759_54760 : H12AffineEnvironment.transform 3 10 env54759 = env54760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env54759 == env54760) = true)

def env54761 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61569,147472,58518,143496,20497,508075,148668,148668,96267,90262,74798,173,204946,1212,135681]

theorem envBound54761 : H12AffineFastState.Bounded env54761 := by
  intro p hp
  have h : env54761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54747_54761 : H12AffineEnvironment.transform 5 17 env54747 = env54761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env54747 == env54761) = true)

theorem identity54761 : scanCanonicalize (H12AffineFastState.compose env54761 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 99487) := by decide +kernel

theorem selectedBound54761 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env54762 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,99487,262144,102558,32769,4097,61569,115855,58518,111639,20497,279604,114723,114723,96267,90262,74798,173,41997,1212,104094]

theorem envBound54762 : H12AffineFastState.Bounded env54762 := by
  intro p hp
  have h : env54762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54761_54762 : H12AffineEnvironment.transform 16 99487 env54761 = env54762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 99487 env54761 == env54762) = true)

theorem identity54762 : scanCanonicalize (H12AffineFastState.compose env54762 (packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS)) = affineNative (2^(14+1) ^^^ 24601) := by decide +kernel

theorem selectedBound54762 : packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS < 2^1333 := by decide +kernel

def env54763 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,24601,65536,91270,262144,94343,24600,4097,4248,74902,1167,87054,20497,279604,73786,73786,96267,90262,74798,173,17428,1212,95879]

theorem envBound54763 : H12AffineFastState.Bounded env54763 := by
  intro p hp
  have h : env54763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54762_54763 : H12AffineEnvironment.transform 14 24601 env54762 = env54763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 24601 env54762 == env54763) = true)

theorem identity54763 : scanCanonicalize (H12AffineFastState.compose env54763 (packedSelected [3,7,10,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 29831) := by decide +kernel

theorem selectedBound54763 : packedSelected [3,7,10,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env54764 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,24601,29831,4097,262144,1024,24600,4097,4248,20497,1167,8329,20497,279604,21693,21693,3212,5137,20649,173,17428,1212,512]

theorem envBound54764 : H12AffineFastState.Bounded env54764 := by
  intro p hp
  have h : env54764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54763_54764 : H12AffineEnvironment.transform 15 29831 env54763 = env54764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29831 env54763 == env54764) = true)

theorem identity54764 : scanCanonicalize (H12AffineFastState.compose env54764 (packedSelected [4,9,16] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound54764 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env54765 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1213,9380,12346,4097,262144,1024,9381,4097,4248,5292,1167,8329,5292,262281,4096,4096,3212,5137,5140,173,169,1212,512]

theorem envBound54765 : H12AffineFastState.Bounded env54765 := by
  intro p hp
  have h : env54765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54764_54765 : H12AffineEnvironment.transform 13 1213 env54764 = env54765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env54764 == env54765) = true)

theorem identity54765 : scanCanonicalize (H12AffineFastState.compose env54765 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 5676) := by decide +kernel

theorem selectedBound54765 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env54766 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,5676,1213,4744,1558,4097,262144,1024,4745,4097,4248,5292,1167,5797,5292,262281,4096,4096,3212,5137,5140,173,169,1212,512]

theorem envBound54766 : H12AffineFastState.Bounded env54766 := by
  intro p hp
  have h : env54766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54765_54766 : H12AffineEnvironment.transform 12 5676 env54765 = env54766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5676 env54765 == env54766) = true)

theorem identity54766 : scanCanonicalize (H12AffineFastState.compose env54766 (packedSelected [1,3,13] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound54766 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env54767 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,184,1684,1213,560,1558,185,262144,1024,561,185,32,1044,1167,1565,1044,262281,184,184,3212,1193,1196,173,169,1212,512]

theorem envBound54767 : H12AffineFastState.Bounded env54767 := by
  intro p hp
  have h : env54767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54766_54767 : H12AffineEnvironment.transform 11 184 env54766 = env54767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env54766 == env54767) = true)

theorem identity54767 : scanCanonicalize (H12AffineFastState.compose env54767 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 554) := by decide +kernel

theorem selectedBound54767 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env54768 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,184,1684,1213,560,1558,185,554,1024,561,185,32,1044,1167,1565,1044,675,184,184,3212,1193,1196,173,169,1212,512]

theorem envBound54768 : H12AffineFastState.Bounded env54768 := by
  intro p hp
  have h : env54768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54767_54768 : H12AffineEnvironment.transform 17 554 env54767 = env54768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 554 env54767 == env54768) = true)

theorem identity54768 : scanCanonicalize (H12AffineFastState.compose env54768 (packedSelected [0,1,3,4,7,9,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound54768 : packedSelected [0,1,3,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env54769 : List Nat := [2,4,8,16,32,17,128,172,512,4,2048,184,656,185,560,530,185,554,4,561,185,32,16,139,537,16,675,184,184,2184,173,168,173,169,184,512]

theorem envBound54769 : H12AffineFastState.Bounded env54769 := by
  intro p hp
  have h : env54769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54768_54769 : H12AffineEnvironment.transform 9 4 env54768 = env54769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env54768 == env54769) = true)

theorem identity54769 : scanCanonicalize (H12AffineFastState.compose env54769 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound54769 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54770 : List Nat := [2,4,8,16,32,17,128,172,512,4,49,184,656,185,560,530,185,554,4,561,185,32,16,139,537,16,675,184,184,185,173,168,173,169,184,512]

theorem envBound54770 : H12AffineFastState.Bounded env54770 := by
  intro p hp
  have h : env54770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54769_54770 : H12AffineEnvironment.transform 10 49 env54769 = env54770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env54769 == env54770) = true)

theorem identity54770 : scanCanonicalize (H12AffineFastState.compose env54770 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound54770 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env54771 : List Nat := [2,4,8,16,32,17,128,172,27,4,49,184,139,185,43,9,185,49,4,42,185,32,16,139,2,16,184,184,184,185,173,168,173,169,184,27]

theorem envBound54771 : H12AffineFastState.Bounded env54771 := by
  intro p hp
  have h : env54771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54770_54771 : H12AffineEnvironment.transform 8 27 env54770 = env54771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env54770 == env54771) = true)

theorem identity54771 : scanCanonicalize (H12AffineFastState.compose env54771 (packedSelected [0,1,4] rootPS)) = affineNative (2^(6+1) ^^^ 36) := by decide +kernel

theorem selectedBound54771 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env54772 : List Nat := [2,4,8,16,32,17,36,8,27,4,49,28,47,29,43,9,29,49,4,42,29,32,16,47,2,16,28,28,28,29,9,12,9,13,28,27]

theorem envBound54772 : H12AffineFastState.Bounded env54772 := by
  intro p hp
  have h : env54772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54771_54772 : H12AffineEnvironment.transform 6 36 env54771 = env54772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 36 env54771 == env54772) = true)

def env54773 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147521,58519,143496,20497,508154,148716,148716,96346,90263,74798,172,204994,1260,135681]

theorem envBound54773 : H12AffineFastState.Bounded env54773 := by
  intro p hp
  have h : env54773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54746_54773 : H12AffineEnvironment.transform 7 173 env54746 = env54773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env54746 == env54773) = true)

def env54774 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61568,147473,58519,143496,20497,508074,148668,148668,96266,90263,74798,172,204946,1212,135681]

theorem envBound54774 : H12AffineFastState.Bounded env54774 := by
  intro p hp
  have h : env54774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54773_54774 : H12AffineEnvironment.transform 5 16 env54773 = env54774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env54773 == env54774) = true)

theorem identity54774 : scanCanonicalize (H12AffineFastState.compose env54774 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 137352) := by decide +kernel

theorem selectedBound54774 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env54775 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,137352,136193,32769,4097,61568,147473,58519,143496,20497,120866,148668,148668,96266,90263,74798,172,204946,1212,135681]

theorem envBound54775 : H12AffineFastState.Bounded env54775 := by
  intro p hp
  have h : env54775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54774_54775 : H12AffineEnvironment.transform 17 137352 env54774 = env54775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137352 env54774 == env54775) = true)

theorem identity54775 : scanCanonicalize (H12AffineFastState.compose env54775 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(16+1) ^^^ 62493) := by decide +kernel

theorem selectedBound54775 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env54776 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,62493,60565,57372,32769,4097,61568,46092,58519,50325,20497,120866,45217,45217,96266,90263,74798,172,119951,1212,58908]

theorem envBound54776 : H12AffineFastState.Bounded env54776 := by
  intro p hp
  have h : env54776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54775_54776 : H12AffineEnvironment.transform 16 62493 env54775 = env54776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 62493 env54775 == env54776) = true)

theorem identity54776 : scanCanonicalize (H12AffineFastState.compose env54776 (packedSelected [4,9,16] rootPS)) = affineNative (2^(14+1) ^^^ 9381) := by decide +kernel

theorem selectedBound54776 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env54777 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,9381,65536,20664,18480,17593,9380,4097,21541,4265,16434,24624,20497,97415,5124,5124,96266,90263,74798,172,94250,1212,17081]

theorem envBound54777 : H12AffineFastState.Bounded env54777 := by
  intro p hp
  have h : env54777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54776_54777 : H12AffineEnvironment.transform 14 9381 env54776 = env54777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9381 env54776 == env54777) = true)

theorem identity54777 : scanCanonicalize (H12AffineFastState.compose env54777 (packedSelected [0,1,2,6,7,8,13,17,19,20,21] rootPS)) = affineNative (2^(15+1) ^^^ 19991) := by decide +kernel

theorem selectedBound54777 : packedSelected [0,1,2,6,7,8,13,17,19,20,21] rootPS < 2^1333 := by decide +kernel

def env54778 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,9381,19991,20664,18480,17593,9380,4097,21541,4265,16434,24624,20497,12944,5124,5124,13853,11904,27193,172,15933,1212,17081]

theorem envBound54778 : H12AffineFastState.Bounded env54778 := by
  intro p hp
  have h : env54778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54777_54778 : H12AffineEnvironment.transform 15 19991 env54777 = env54778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 19991 env54777 == env54778) = true)

theorem identity54778 : scanCanonicalize (H12AffineFastState.compose env54778 (packedSelected [0,1,2,6,7,8,13,18,20,23,26] rootPS)) = affineNative (2^(12+1) ^^^ 6801) := by decide +kernel

theorem selectedBound54778 : packedSelected [0,1,2,6,7,8,13,18,20,23,26] rootPS < 2^1333 := by decide +kernel

def env54779 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,6801,16384,7732,19991,20664,18480,17593,7733,4097,21541,4265,16434,23201,20497,2049,5124,5124,3212,5137,20648,172,1196,1212,17081]

theorem envBound54779 : H12AffineFastState.Bounded env54779 := by
  intro p hp
  have h : env54779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54778_54779 : H12AffineEnvironment.transform 12 6801 env54778 = env54779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6801 env54778 == env54779) = true)

theorem identity54779 : scanCanonicalize (H12AffineFastState.compose env54779 (packedSelected [3,5,6,10,11,12,15,17] rootPS)) = affineNative (2^(11+1) ^^^ 1077) := by decide +kernel

theorem selectedBound54779 : packedSelected [3,5,6,10,11,12,15,17] rootPS < 2^1333 := by decide +kernel

def env54780 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,1077,3748,16384,2561,19991,17549,18480,17593,2560,1076,16400,1180,16434,20116,17444,2049,49,49,3212,36,17565,172,1196,1212,17081]

theorem envBound54780 : H12AffineFastState.Bounded env54780 := by
  intro p hp
  have h : env54780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54779_54780 : H12AffineEnvironment.transform 11 1077 env54779 = env54780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1077 env54779 == env54780) = true)

theorem identity54780 : scanCanonicalize (H12AffineFastState.compose env54780 (packedSelected [0,1,3,9,10,13] rootPS)) = affineNative (2^(13+1) ^^^ 1190) := by decide +kernel

theorem selectedBound54780 : packedSelected [0,1,3,9,10,13] rootPS < 2^1333 := by decide +kernel

def env54781 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,1077,3748,1190,2561,2737,43,3222,31,2560,1076,1206,1180,1172,2610,130,2049,49,49,3212,36,59,172,1196,1212,1567]

theorem envBound54781 : H12AffineFastState.Bounded env54781 := by
  intro p hp
  have h : env54781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54780_54781 : H12AffineEnvironment.transform 13 1190 env54780 = env54781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1190 env54780 == env54781) = true)

theorem identity54781 : scanCanonicalize (H12AffineFastState.compose env54781 (packedSelected [1,2,4,6,7,8,10,11] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound54781 : packedSelected [1,2,4,6,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env54782 : List Nat := [2,4,8,16,32,16,18,63,512,1024,2048,1077,3638,1076,2561,2595,43,3076,31,2560,1076,1060,1038,1030,2610,16,2049,49,49,3102,36,59,62,1086,1070,1567]

theorem envBound54782 : H12AffineFastState.Bounded env54782 := by
  intro p hp
  have h : env54782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54781_54782 : H12AffineEnvironment.transform 6 18 env54781 = env54782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env54781 == env54782) = true)

theorem identity54782 : scanCanonicalize (H12AffineFastState.compose env54782 (packedSelected [1,2,4,5,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 31) := by decide +kernel

theorem selectedBound54782 : packedSelected [1,2,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env54783 : List Nat := [2,4,8,16,32,16,18,63,512,31,2048,42,2601,43,2561,2595,43,2075,31,2560,43,59,17,25,2610,16,2049,49,49,2049,36,59,62,33,49,512]

theorem envBound54783 : H12AffineFastState.Bounded env54783 := by
  intro p hp
  have h : env54783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54782_54783 : H12AffineEnvironment.transform 9 31 env54782 = env54783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 31 env54782 == env54783) = true)

theorem identity54783 : scanCanonicalize (H12AffineFastState.compose env54783 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound54783 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env54784 : List Nat := [2,4,8,16,32,16,18,63,512,31,49,42,536,43,560,530,43,42,31,561,43,59,17,25,515,16,48,49,49,48,36,59,62,33,49,512]

theorem envBound54784 : H12AffineFastState.Bounded env54784 := by
  intro p hp
  have h : env54784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54783_54784 : H12AffineEnvironment.transform 10 49 env54783 = env54784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env54783 == env54784) = true)

theorem identity54784 : scanCanonicalize (H12AffineFastState.compose env54784 (packedSelected [0,3] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound54784 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env54785 : List Nat := [2,4,8,16,32,16,18,63,26,31,49,42,2,43,42,8,43,42,31,43,43,59,17,25,25,16,48,49,49,48,36,59,62,33,49,26]

theorem envBound54785 : H12AffineFastState.Bounded env54785 := by
  intro p hp
  have h : env54785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54784_54785 : H12AffineEnvironment.transform 8 26 env54784 = env54785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env54784 == env54785) = true)

theorem identity54785 : scanCanonicalize (H12AffineFastState.compose env54785 (packedSelected [0,2,4] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound54785 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env54786 : List Nat := [2,4,8,11,32,11,9,36,1,4,42,42,2,43,42,8,43,42,4,43,43,32,10,2,2,11,43,42,42,43,36,32,37,33,42,1]

theorem envBound54786 : H12AffineFastState.Bounded env54786 := by
  intro p hp
  have h : env54786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54785_54786 : H12AffineEnvironment.transform 3 11 env54785 = env54786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env54785 == env54786) = true)

theorem identity54786 : scanCanonicalize (H12AffineFastState.compose env54786 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound54786 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54787 : List Nat := [2,4,5,6,32,6,4,36,1,4,39,39,2,38,39,5,38,39,4,38,38,32,7,2,2,6,38,39,39,38,36,32,37,33,39,1]

theorem envBound54787 : H12AffineFastState.Bounded env54787 := by
  intro p hp
  have h : env54787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54786_54787 : H12AffineEnvironment.transform 2 5 env54786 = env54787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env54786 == env54787) = true)

theorem identity54787 : scanCanonicalize (H12AffineFastState.compose env54787 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound54787 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54788 : List Nat := [2,4,5,6,6,6,4,2,1,4,1,1,2,0,1,5,0,1,4,0,0,6,7,2,2,6,0,1,1,0,2,6,3,7,1,1]

theorem envBound54788 : H12AffineFastState.Bounded env54788 := by
  intro p hp
  have h : env54788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54787_54788 : H12AffineEnvironment.transform 4 6 env54787 = env54788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env54787 == env54788) = true)

def env54789 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61569,147472,58519,143496,20497,508075,148669,148669,96267,90263,74798,172,204947,1213,135681]

theorem envBound54789 : H12AffineFastState.Bounded env54789 := by
  intro p hp
  have h : env54789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54773_54789 : H12AffineEnvironment.transform 5 17 env54773 = env54789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env54773 == env54789) = true)

theorem identity54789 : scanCanonicalize (H12AffineFastState.compose env54789 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 45216) := by decide +kernel

theorem selectedBound54789 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env54790 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,45216,262144,42145,32769,4097,61569,61616,58519,32808,20497,356363,62493,62493,96267,90263,74798,172,102451,1213,41633]

theorem envBound54790 : H12AffineFastState.Bounded env54790 := by
  intro p hp
  have h : env54790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54789_54790 : H12AffineEnvironment.transform 16 45216 env54789 = env54790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45216 env54789 == env54790) = true)

theorem identity54790 : scanCanonicalize (H12AffineFastState.compose env54790 (packedSelected [16,20] rootPS)) = affineNative (2^(17+1) ^^^ 2184) := by decide +kernel

theorem selectedBound54790 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env54791 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,45216,2184,42145,32769,4097,61569,61616,58519,32808,20497,96387,62493,62493,96267,90263,74798,172,102451,1213,41633]

theorem envBound54791 : H12AffineFastState.Bounded env54791 := by
  intro p hp
  have h : env54791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54790_54791 : H12AffineEnvironment.transform 17 2184 env54790 = env54791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2184 env54790 == env54791) = true)

theorem identity54791 : scanCanonicalize (H12AffineFastState.compose env54791 (packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS)) = affineNative (2^(15+1) ^^^ 12347) := by decide +kernel

theorem selectedBound54791 : packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env54792 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,12347,45216,2184,42145,32769,4097,61569,61616,58519,32808,20497,18616,62493,62493,18480,20652,5141,172,40968,1213,41633]

theorem envBound54792 : H12AffineFastState.Bounded env54792 := by
  intro p hp
  have h : env54792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54791_54792 : H12AffineEnvironment.transform 15 12347 env54791 = env54792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12347 env54791 == env54792) = true)

theorem identity54792 : scanCanonicalize (H12AffineFastState.compose env54792 (packedSelected [1,4,5,8,9,16,17,21,24] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound54792 : packedSelected [1,4,5,8,9,16,17,21,24] rootPS < 2^1333 := by decide +kernel

def env54793 : List Nat := [2,4,8,16,32,17,128,173,512,4,2048,4096,8192,16384,32768,12347,45216,2184,41125,32769,4097,61569,61616,57491,32808,20497,18616,61465,61465,18480,20652,4113,172,40968,185,41633]

theorem envBound54793 : H12AffineFastState.Bounded env54793 := by
  intro p hp
  have h : env54793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54792_54793 : H12AffineEnvironment.transform 9 4 env54792 = env54793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env54792 == env54793) = true)

theorem identity54793 : scanCanonicalize (H12AffineFastState.compose env54793 (packedSelected [2,3,5,6,10,15,17] rootPS)) = affineNative (2^(14+1) ^^^ 2745) := by decide +kernel

theorem selectedBound54793 : packedSelected [2,3,5,6,10,15,17] rootPS < 2^1333 := by decide +kernel

def env54794 : List Nat := [2,4,8,16,32,17,128,173,512,4,2048,4096,8192,16384,2745,12347,14873,2184,10780,2744,4097,31288,31241,27178,2705,20497,18616,31392,31392,18480,20652,4113,172,10929,185,10264]

theorem envBound54794 : H12AffineFastState.Bounded env54794 := by
  intro p hp
  have h : env54794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54793_54794 : H12AffineEnvironment.transform 14 2745 env54793 = env54794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2745 env54793 == env54794) = true)

theorem identity54794 : scanCanonicalize (H12AffineFastState.compose env54794 (packedSelected [2,4,7,10,12,13,16] rootPS)) = affineNative (2^(11+1) ^^^ 2744) := by decide +kernel

theorem selectedBound54794 : packedSelected [2,4,7,10,12,13,16] rootPS < 2^1333 := by decide +kernel

def env54795 : List Nat := [2,4,8,16,32,17,128,173,512,4,2048,2744,8192,16384,2745,10883,8353,2184,10780,2744,2745,24704,24753,27178,2705,19113,18616,24600,24600,18480,18964,2729,172,10929,185,10264]

theorem envBound54795 : H12AffineFastState.Bounded env54795 := by
  intro p hp
  have h : env54795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54794_54795 : H12AffineEnvironment.transform 11 2744 env54794 = env54795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2744 env54794 == env54795) = true)

theorem identity54795 : scanCanonicalize (H12AffineFastState.compose env54795 (packedSelected [2,6,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 2705) := by decide +kernel

theorem selectedBound54795 : packedSelected [2,6,10,12] rootPS < 2^1333 := by decide +kernel

def env54796 : List Nat := [2,4,8,16,32,17,128,173,512,4,2048,2744,2705,16384,2745,18,2608,2184,141,2744,2745,18961,18976,16571,2705,19113,18616,19081,19081,18480,18964,2729,172,32,185,649]

theorem envBound54796 : H12AffineFastState.Bounded env54796 := by
  intro p hp
  have h : env54796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54795_54796 : H12AffineEnvironment.transform 12 2705 env54795 = env54796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2705 env54795 == env54796) = true)

theorem identity54796 : scanCanonicalize (H12AffineFastState.compose env54796 (packedSelected [0,2,3,5,6,7,11] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound54796 : packedSelected [0,2,3,5,6,7,11] rootPS < 2^1333 := by decide +kernel

def env54797 : List Nat := [2,4,8,16,32,17,128,173,48,4,2048,2184,2209,16384,2185,18,2048,2184,141,2184,2185,18465,18448,16571,2209,18585,18616,18617,18617,18480,18468,2201,172,32,185,185]

theorem envBound54797 : H12AffineFastState.Bounded env54797 := by
  intro p hp
  have h : env54797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54796_54797 : H12AffineEnvironment.transform 8 48 env54796 = env54797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env54796 == env54797) = true)

theorem identity54797 : scanCanonicalize (H12AffineFastState.compose env54797 (packedSelected [1,2,4,5,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 163) := by decide +kernel

theorem selectedBound54797 : packedSelected [1,2,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env54798 : List Nat := [2,4,8,16,32,17,128,173,48,4,163,43,2,16384,42,18,163,43,141,43,42,16514,16563,16571,2,16442,16411,16410,16410,16531,16519,58,172,32,185,185]

theorem envBound54798 : H12AffineFastState.Bounded env54798 := by
  intro p hp
  have h : env54798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54797_54798 : H12AffineEnvironment.transform 10 163 env54797 = env54798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 163 env54797 == env54798) = true)

theorem identity54798 : scanCanonicalize (H12AffineFastState.compose env54798 (packedSelected [4,5,8,9] rootPS)) = affineNative (2^(13+1) ^^^ 163) := by decide +kernel

theorem selectedBound54798 : packedSelected [4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env54799 : List Nat := [2,4,8,16,32,17,128,173,48,4,163,43,2,163,42,18,163,43,141,43,42,33,16,24,2,153,184,185,185,48,36,58,172,32,185,185]

theorem envBound54799 : H12AffineFastState.Bounded env54799 := by
  intro p hp
  have h : env54799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54798_54799 : H12AffineEnvironment.transform 13 163 env54798 = env54799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 163 env54798 == env54799) = true)

theorem identity54799 : scanCanonicalize (H12AffineFastState.compose env54799 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound54799 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env54800 : List Nat := [2,4,8,16,32,17,9,36,48,4,42,43,2,42,42,18,42,43,4,43,42,33,16,24,2,16,49,48,48,48,36,58,37,32,48,48]

theorem envBound54800 : H12AffineFastState.Bounded env54800 := by
  intro p hp
  have h : env54800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54799_54800 : H12AffineEnvironment.transform 6 9 env54799 = env54800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env54799 == env54800) = true)

theorem identity54800 : scanCanonicalize (H12AffineFastState.compose env54800 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound54800 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54801 : List Nat := [2,4,8,11,32,10,9,36,43,4,42,43,2,42,42,9,42,43,4,43,42,33,11,3,2,11,42,43,43,43,36,33,37,32,43,43]

theorem envBound54801 : H12AffineFastState.Bounded env54801 := by
  intro p hp
  have h : env54801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54800_54801 : H12AffineEnvironment.transform 3 11 env54800 = env54801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env54800 == env54801) = true)

theorem identity54801 : scanCanonicalize (H12AffineFastState.compose env54801 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound54801 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54802 : List Nat := [2,4,4,7,32,6,5,36,39,4,38,39,2,38,38,5,38,39,4,39,38,33,7,3,2,7,38,39,39,39,36,33,37,32,39,39]

theorem envBound54802 : H12AffineFastState.Bounded env54802 := by
  intro p hp
  have h : env54802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54801_54802 : H12AffineEnvironment.transform 2 4 env54801 = env54802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env54801 == env54802) = true)

theorem identity54802 : scanCanonicalize (H12AffineFastState.compose env54802 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound54802 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54803 : List Nat := [2,4,4,7,7,6,5,3,0,4,1,0,2,1,1,5,1,0,4,0,1,6,7,3,2,7,1,0,0,0,3,6,2,7,0,0]

theorem envBound54803 : H12AffineFastState.Bounded env54803 := by
  intro p hp
  have h : env54803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54802_54803 : H12AffineEnvironment.transform 4 7 env54802 = env54803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env54802 == env54803) = true)

def env54804 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147521,16777216,533641,672784,17245633,148801,545088,96346,16876544,74799,257,17420373,1344,525824]

theorem envBound54804 : H12AffineFastState.Bounded env54804 := by
  intro p hp
  have h : env54804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54686_54804 : H12AffineEnvironment.transform 26 17245633 env54686 = env54804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245633 env54686 == env54804) = true)

theorem identity54804 : scanCanonicalize (H12AffineFastState.compose env54804 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 41002) := by decide +kernel

theorem selectedBound54804 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env54805 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147521,41002,533641,672784,493035,148801,545088,96346,74794,74799,257,618623,1344,525824]

theorem envBound54805 : H12AffineFastState.Bounded env54805 := by
  intro p hp
  have h : env54805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54804_54805 : H12AffineEnvironment.transform 23 41002 env54804 = env54805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41002 env54804 == env54805) = true)

def env54806 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147521,41002,143497,20496,493035,148801,148800,96346,74794,74799,257,222335,1344,135680]

theorem envBound54806 : H12AffineFastState.Bounded env54806 := by
  intro p hp
  have h : env54806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54805_54806 : H12AffineEnvironment.transform 18 136192 env54805 = env54806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136192 env54805 == env54806) = true)

def env54807 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147521,41002,143497,20496,492615,148717,148716,96346,74794,74799,173,222335,1260,135680]

theorem envBound54807 : H12AffineFastState.Bounded env54807 := by
  intro p hp
  have h : env54807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54806_54807 : H12AffineEnvironment.transform 7 172 env54806 = env54807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env54806 == env54807) = true)

def env54808 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61568,147473,41002,143497,20496,492567,148669,148668,96266,74794,74799,173,222255,1212,135680]

theorem envBound54808 : H12AffineFastState.Bounded env54808 := by
  intro p hp
  have h : env54808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54807_54808 : H12AffineEnvironment.transform 5 16 env54807 = env54808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env54807 == env54808) = true)

theorem identity54808 : scanCanonicalize (H12AffineFastState.compose env54808 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 114723) := by decide +kernel

theorem selectedBound54808 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env54809 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,114723,262144,119843,32769,4097,61568,98354,41002,127146,20496,279604,99486,99487,96266,74794,74799,173,41996,1212,119331]

theorem envBound54809 : H12AffineFastState.Bounded env54809 := by
  intro p hp
  have h : env54809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54808_54809 : H12AffineEnvironment.transform 16 114723 env54808 = env54809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114723 env54808 == env54809) = true)

theorem identity54809 : scanCanonicalize (H12AffineFastState.compose env54809 (packedSelected [3,10,16,18,19,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 3212) := by decide +kernel

theorem selectedBound54809 : packedSelected [3,10,16,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env54810 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,114723,3212,119843,32769,4097,61568,98354,41002,127146,20496,18616,99486,99487,96266,74794,74799,173,41996,1212,119331]

theorem envBound54810 : H12AffineFastState.Bounded env54810 := by
  intro p hp
  have h : env54810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54809_54810 : H12AffineEnvironment.transform 17 3212 env54809 = env54810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3212 env54809 == env54810) = true)

theorem identity54810 : scanCanonicalize (H12AffineFastState.compose env54810 (packedSelected [7,16,18,19,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53283) := by decide +kernel

theorem selectedBound54810 : packedSelected [7,16,18,19,23,26,27] rootPS < 2^1333 := by decide +kernel

def env54811 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,53283,4096,3212,1024,32769,4097,61568,20497,41002,8329,20496,18616,21693,21692,43049,62473,62476,173,41996,1212,512]

theorem envBound54811 : H12AffineFastState.Bounded env54811 := by
  intro p hp
  have h : env54811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54810_54811 : H12AffineEnvironment.transform 15 53283 env54810 = env54811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53283 env54810 == env54811) = true)

theorem identity54811 : scanCanonicalize (H12AffineFastState.compose env54811 (packedSelected [4,9,16] rootPS)) = affineNative (2^(14+1) ^^^ 24601) := by decide +kernel

theorem selectedBound54811 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env54812 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,24601,12346,4096,3212,1024,24600,4097,4249,20497,16435,8329,20496,18616,21693,21692,18480,5136,5141,173,17429,1212,512]

theorem envBound54812 : H12AffineFastState.Bounded env54812 := by
  intro p hp
  have h : env54812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54811_54812 : H12AffineEnvironment.transform 14 24601 env54811 = env54812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 24601 env54811 == env54812) = true)

theorem identity54812 : scanCanonicalize (H12AffineFastState.compose env54812 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 8745) := by decide +kernel

theorem selectedBound54812 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env54813 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,8745,560,12346,4096,3212,1024,561,4097,4249,12856,8730,8329,12857,10897,13972,13973,10777,5136,5141,173,9788,1212,512]

theorem envBound54813 : H12AffineFastState.Bounded env54813 := by
  intro p hp
  have h : env54813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54812_54813 : H12AffineEnvironment.transform 13 8745 env54812 = env54813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8745 env54812 == env54813) = true)

theorem identity54813 : scanCanonicalize (H12AffineFastState.compose env54813 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound54813 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env54814 : List Nat := [2,4,8,16,32,16,128,172,26,1024,2048,4096,8192,8243,42,12346,4096,3212,1024,43,4097,4249,12322,8192,8329,12323,10379,13454,13455,10243,5136,5141,173,9254,1212,26]

theorem envBound54814 : H12AffineFastState.Bounded env54814 := by
  intro p hp
  have h : env54814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54813_54814 : H12AffineEnvironment.transform 8 26 env54813 = env54814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env54813 == env54814) = true)

def env54815 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61569,147472,41002,143497,20496,492566,148668,148669,96267,74794,74799,173,222254,1213,135680]

theorem envBound54815 : H12AffineFastState.Bounded env54815 := by
  intro p hp
  have h : env54815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54807_54815 : H12AffineEnvironment.transform 5 17 env54807 = env54815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env54807 == env54815) = true)

theorem identity54815 : scanCanonicalize (H12AffineFastState.compose env54815 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 223242) := by decide +kernel

theorem selectedBound54815 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env54816 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,223242,136192,32769,4097,61569,147472,41002,143497,20496,60444,148668,148669,96267,74794,74799,173,222254,1213,135680]

theorem envBound54816 : H12AffineFastState.Bounded env54816 := by
  intro p hp
  have h : env54816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54815_54816 : H12AffineEnvironment.transform 17 223242 env54815 = env54816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223242 env54815 == env54816) = true)

theorem identity54816 : scanCanonicalize (H12AffineFastState.compose env54816 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 28802) := by decide +kernel

theorem selectedBound54816 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env54817 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,28802,131072,137352,136192,32769,4097,61569,147472,41002,143497,20496,60444,148668,148669,2185,21672,21677,173,136364,1213,135680]

theorem envBound54817 : H12AffineFastState.Bounded env54817 := by
  intro p hp
  have h : env54817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54816_54817 : H12AffineEnvironment.transform 15 28802 env54816 = env54817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28802 env54816 == env54817) = true)

theorem identity54817 : scanCanonicalize (H12AffineFastState.compose env54817 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(14+1) ^^^ 9380) := by decide +kernel

theorem selectedBound54817 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env54818 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,9380,28802,131072,137352,136192,9381,4097,21541,147472,1166,143497,20496,18616,148668,148669,2185,21672,21677,173,136364,1213,135680]

theorem envBound54818 : H12AffineFastState.Bounded env54818 := by
  intro p hp
  have h : env54818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54817_54818 : H12AffineEnvironment.transform 14 9380 env54817 = env54818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9380 env54817 == env54818) = true)

theorem identity54818 : scanCanonicalize (H12AffineFastState.compose env54818 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound54818 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env54819 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1213,9380,13375,131072,137352,136192,9381,4097,4248,132269,1166,143497,5293,3077,131073,131072,2185,4117,4112,173,136364,1213,135680]

theorem envBound54819 : H12AffineFastState.Bounded env54819 := by
  intro p hp
  have h : env54819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54818_54819 : H12AffineEnvironment.transform 13 1213 env54818 = env54819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env54818 == env54819) = true)

theorem identity54819 : scanCanonicalize (H12AffineFastState.compose env54819 (packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS)) = affineNative (2^(16+1) ^^^ 10379) := by decide +kernel

theorem selectedBound54819 : packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env54820 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1213,9380,13375,10379,12291,15499,9381,4097,4248,11302,1166,6146,5293,3077,10378,10379,2185,4117,4112,173,15399,1213,14987]

theorem envBound54820 : H12AffineFastState.Bounded env54820 := by
  intro p hp
  have h : env54820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54819_54820 : H12AffineEnvironment.transform 16 10379 env54819 = env54820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 10379 env54819 == env54820) = true)

theorem identity54820 : scanCanonicalize (H12AffineFastState.compose env54820 (packedSelected [13,17] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound54820 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env54821 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,184,8192,1213,9380,9351,10379,8379,11315,9381,185,32,11302,1166,2234,1045,3077,10378,10379,2185,173,168,173,11423,1213,10803]

theorem envBound54821 : H12AffineFastState.Bounded env54821 := by
  intro p hp
  have h : env54821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54820_54821 : H12AffineEnvironment.transform 11 184 env54820 = env54821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env54820 == env54821) = true)

theorem identity54821 : scanCanonicalize (H12AffineFastState.compose env54821 (packedSelected [0,1,2,3,4,5,6,7,8,9,11,13] rootPS)) = affineNative (2^(12+1) ^^^ 3638) := by decide +kernel

theorem selectedBound54821 : packedSelected [0,1,2,3,4,5,6,7,8,9,11,13] rootPS < 2^1333 := by decide +kernel

def env54822 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,184,3638,1213,2706,2737,1725,3725,517,2707,185,32,528,1166,2234,1045,3077,1724,1725,2185,173,168,173,681,1213,1029]

theorem envBound54822 : H12AffineFastState.Bounded env54822 := by
  intro p hp
  have h : env54822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54821_54822 : H12AffineEnvironment.transform 12 3638 env54821 = env54822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3638 env54821 == env54822) = true)

theorem identity54822 : scanCanonicalize (H12AffineFastState.compose env54822 (packedSelected [1,2,3,5,6,8,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 674) := by decide +kernel

theorem selectedBound54822 : packedSelected [1,2,3,5,6,8,10,11] rootPS < 2^1333 := by decide +kernel

def env54823 : List Nat := [2,4,8,16,32,17,128,172,512,1024,674,184,1172,1213,48,19,1725,1071,517,49,185,32,528,1166,536,1045,1703,1724,1725,555,173,168,173,681,1213,1029]

theorem envBound54823 : H12AffineFastState.Bounded env54823 := by
  intro p hp
  have h : env54823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54822_54823 : H12AffineEnvironment.transform 10 674 env54822 = env54823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 674 env54822 == env54823) = true)

def env54824 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147521,41002,143497,20496,492614,148716,148717,96346,74794,74799,172,222335,1261,135680]

theorem envBound54824 : H12AffineFastState.Bounded env54824 := by
  intro p hp
  have h : env54824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54806_54824 : H12AffineEnvironment.transform 7 173 env54806 = env54824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env54806 == env54824) = true)

def env54825 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61568,147473,41002,143497,20496,492566,148668,148669,96266,74794,74799,172,222255,1213,135680]

theorem envBound54825 : H12AffineFastState.Bounded env54825 := by
  intro p hp
  have h : env54825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54824_54825 : H12AffineEnvironment.transform 5 16 env54824 = env54825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env54824 == env54825) = true)

theorem identity54825 : scanCanonicalize (H12AffineFastState.compose env54825 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 45217) := by decide +kernel

theorem selectedBound54825 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env54826 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,45217,262144,42145,32769,4097,61568,61616,41002,32808,20496,341175,62493,62492,96266,74794,74799,172,119950,1213,41633]

theorem envBound54826 : H12AffineFastState.Bounded env54826 := by
  intro p hp
  have h : env54826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54825_54826 : H12AffineEnvironment.transform 16 45217 env54825 = env54826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45217 env54825 == env54826) = true)

theorem identity54826 : scanCanonicalize (H12AffineFastState.compose env54826 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound54826 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env54827 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1212,32768,65536,45217,262144,42145,32769,4097,46140,46092,41002,32808,5292,341175,45217,45216,81078,74794,74799,172,102450,1213,41633]

theorem envBound54827 : H12AffineFastState.Bounded env54827 := by
  intro p hp
  have h : env54827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54826_54827 : H12AffineEnvironment.transform 13 1212 env54826 = env54827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env54826 == env54827) = true)

theorem identity54827 : scanCanonicalize (H12AffineFastState.compose env54827 (packedSelected [4,9,16] rootPS)) = affineNative (2^(14+1) ^^^ 9381) := by decide +kernel

theorem selectedBound54827 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env54828 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1212,9381,65536,5124,262144,4,9380,4097,4249,4265,1167,9357,5292,341175,5124,5125,81078,74794,74799,172,78999,1213,1540]

theorem envBound54828 : H12AffineFastState.Bounded env54828 := by
  intro p hp
  have h : env54828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54827_54828 : H12AffineEnvironment.transform 14 9381 env54827 = env54828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9381 env54827 == env54828) = true)

theorem identity54828 : scanCanonicalize (H12AffineFastState.compose env54828 (packedSelected [4,9,20] rootPS)) = affineNative (2^(15+1) ^^^ 12346) := by decide +kernel

theorem selectedBound54828 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env54829 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1212,9381,12346,5124,262144,4,9380,4097,4249,4265,1167,9357,5292,263309,5124,5125,3212,5136,5141,172,1197,1213,1540]

theorem envBound54829 : H12AffineFastState.Bounded env54829 := by
  intro p hp
  have h : env54829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54828_54829 : H12AffineEnvironment.transform 15 12346 env54828 = env54829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12346 env54828 == env54829) = true)

theorem identity54829 : scanCanonicalize (H12AffineFastState.compose env54829 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound54829 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env54830 : List Nat := [2,4,8,16,32,16,128,173,512,4,2048,4096,8192,184,8353,12346,4096,262144,4,8352,4097,4249,4265,139,8329,4264,262281,4096,4097,2184,4116,4113,172,169,185,512]

theorem envBound54830 : H12AffineFastState.Bounded env54830 := by
  intro p hp
  have h : env54830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54829_54830 : H12AffineEnvironment.transform 9 4 env54829 = env54830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env54829 == env54830) = true)

theorem identity54830 : scanCanonicalize (H12AffineFastState.compose env54830 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 2600) := by decide +kernel

theorem selectedBound54830 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54831 : List Nat := [2,4,8,16,32,16,128,173,512,4,2048,4096,2600,184,2697,6674,4096,262144,4,2696,4097,4249,4265,139,2721,4264,262281,4096,4097,2184,4116,4113,172,169,185,512]

theorem envBound54831 : H12AffineFastState.Bounded env54831 := by
  intro p hp
  have h : env54831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54830_54831 : H12AffineEnvironment.transform 12 2600 env54830 = env54831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2600 env54830 == env54831) = true)

theorem identity54831 : scanCanonicalize (H12AffineFastState.compose env54831 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 2707) := by decide +kernel

theorem selectedBound54831 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env54832 : List Nat := [2,4,8,16,32,16,128,173,512,4,2048,4096,2600,184,2697,6674,4096,2707,4,2696,4097,4249,4265,139,2721,4264,2586,4096,4097,2184,4116,4113,172,169,185,512]

theorem envBound54832 : H12AffineFastState.Bounded env54832 := by
  intro p hp
  have h : env54832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54831_54832 : H12AffineEnvironment.transform 17 2707 env54831 = env54832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2707 env54831 == env54832) = true)

theorem identity54832 : scanCanonicalize (H12AffineFastState.compose env54832 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 184) := by decide +kernel

theorem selectedBound54832 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env54833 : List Nat := [2,4,8,16,32,16,128,173,512,4,184,4096,656,184,561,4778,4096,555,4,560,4097,4249,4265,139,537,4264,674,4096,4097,48,4116,4113,172,169,185,512]

theorem envBound54833 : H12AffineFastState.Bounded env54833 := by
  intro p hp
  have h : env54833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54832_54833 : H12AffineEnvironment.transform 10 184 env54832 = env54833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 184 env54832 == env54833) = true)

theorem identity54833 : scanCanonicalize (H12AffineFastState.compose env54833 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound54833 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env54834 : List Nat := [2,4,8,11,32,11,128,173,512,4,163,4096,651,163,554,4778,4096,555,4,555,4097,4226,4265,139,514,4264,674,4096,4097,43,4111,4106,172,169,162,512]

theorem envBound54834 : H12AffineFastState.Bounded env54834 := by
  intro p hp
  have h : env54834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54833_54834 : H12AffineEnvironment.transform 3 11 env54833 = env54834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env54833 == env54834) = true)

theorem identity54834 : scanCanonicalize (H12AffineFastState.compose env54834 (packedSelected [0,1,4,7] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound54834 : packedSelected [0,1,4,7] rootPS < 2^1333 := by decide +kernel

def env54835 : List Nat := [2,4,8,11,32,11,128,173,0,4,163,4096,139,163,42,4266,4096,43,4,43,4097,4226,4265,139,2,4264,162,4096,4097,43,4111,4106,172,169,162,0]

theorem envBound54835 : H12AffineFastState.Bounded env54835 := by
  intro p hp
  have h : env54835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54834_54835 : H12AffineEnvironment.transform 8 0 env54834 = env54835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env54834 == env54835) = true)

theorem identity54835 : scanCanonicalize (H12AffineFastState.compose env54835 (packedSelected [0,1] rootPS)) = affineNative (2^(11+1) ^^^ 162) := by decide +kernel

theorem selectedBound54835 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env54836 : List Nat := [2,4,8,11,32,11,128,173,0,4,163,162,139,163,42,8,162,43,4,43,163,32,11,139,2,10,162,162,163,43,173,168,172,169,162,0]

theorem envBound54836 : H12AffineFastState.Bounded env54836 := by
  intro p hp
  have h : env54836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54835_54836 : H12AffineEnvironment.transform 11 162 env54835 = env54836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 162 env54835 == env54836) = true)

theorem identity54836 : scanCanonicalize (H12AffineFastState.compose env54836 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound54836 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54837 : List Nat := [2,4,4,7,32,7,128,161,0,4,163,162,135,163,38,4,162,39,4,39,163,32,7,135,2,6,162,162,163,39,161,164,160,165,162,0]

theorem envBound54837 : H12AffineFastState.Bounded env54837 := by
  intro p hp
  have h : env54837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54836_54837 : H12AffineEnvironment.transform 2 4 env54836 = env54837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env54836 == env54837) = true)

theorem identity54837 : scanCanonicalize (H12AffineFastState.compose env54837 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound54837 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env54838 : List Nat := [2,4,4,7,32,7,5,36,0,4,38,39,2,38,38,4,39,39,4,39,38,32,7,2,2,6,39,39,38,39,36,33,37,32,39,0]

theorem envBound54838 : H12AffineFastState.Bounded env54838 := by
  intro p hp
  have h : env54838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54837_54838 : H12AffineEnvironment.transform 6 5 env54837 = env54838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env54837 == env54838) = true)

def env54839 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61569,147472,41002,143497,20496,492567,148669,148668,96267,74794,74799,172,222254,1212,135680]

theorem envBound54839 : H12AffineFastState.Bounded env54839 := by
  intro p hp
  have h : env54839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54824_54839 : H12AffineEnvironment.transform 5 17 env54824 = env54839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env54824 == env54839) = true)

theorem identity54839 : scanCanonicalize (H12AffineFastState.compose env54839 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 137353) := by decide +kernel

theorem selectedBound54839 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env54840 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,137353,136192,32769,4097,61569,147472,41002,143497,20496,105630,148669,148668,96267,74794,74799,172,222254,1212,135680]

theorem envBound54840 : H12AffineFastState.Bounded env54840 := by
  intro p hp
  have h : env54840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54839_54840 : H12AffineEnvironment.transform 17 137353 env54839 = env54840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137353 env54839 == env54840) = true)

theorem identity54840 : scanCanonicalize (H12AffineFastState.compose env54840 (packedSelected [1,5,8,18,19,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 13374) := by decide +kernel

theorem selectedBound54840 : packedSelected [1,5,8,18,19,23,24,26] rootPS < 2^1333 := by decide +kernel

def env54841 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,13374,131072,137353,136192,32769,4097,61569,147472,41002,143497,20496,43168,148669,148668,19509,4116,4113,172,151568,1212,135680]

theorem envBound54841 : H12AffineFastState.Bounded env54841 := by
  intro p hp
  have h : env54841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54840_54841 : H12AffineEnvironment.transform 15 13374 env54840 = env54841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13374 env54840 == env54841) = true)

theorem identity54841 : scanCanonicalize (H12AffineFastState.compose env54841 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound54841 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env54842 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1212,32768,13374,131072,137353,136192,32769,4097,46141,132268,41002,143497,5292,43168,131073,131072,2185,4116,4113,172,136364,1212,135680]

theorem envBound54842 : H12AffineFastState.Bounded env54842 := by
  intro p hp
  have h : env54842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54841_54842 : H12AffineEnvironment.transform 13 1212 env54841 = env54842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env54841 == env54842) = true)

theorem identity54842 : scanCanonicalize (H12AffineFastState.compose env54842 (packedSelected [13,17] rootPS)) = affineNative (2^(16+1) ^^^ 40985) := by decide +kernel

theorem selectedBound54842 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env54843 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1212,32768,13374,40985,47248,46105,32769,4097,46141,42165,41002,37008,5292,43168,40984,40985,2185,4116,4113,172,46261,1212,45593]

theorem envBound54843 : H12AffineFastState.Bounded env54843 := by
  intro p hp
  have h : env54843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54842_54843 : H12AffineEnvironment.transform 16 40985 env54842 = env54843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 40985 env54842 == env54843) = true)

theorem identity54843 : scanCanonicalize (H12AffineFastState.compose env54843 (packedSelected [0,4,5,7,8,9,10,13] rootPS)) = affineNative (2^(10+1) ^^^ 1191) := by decide +kernel

theorem selectedBound54843 : packedSelected [0,4,5,7,8,9,10,13] rootPS < 2^1333 := by decide +kernel

def env54844 : List Nat := [2,4,8,16,32,17,128,173,512,1024,1191,4096,8192,1212,32768,13374,40985,46135,46105,32769,4097,46141,42165,41002,37008,5292,41991,40984,40985,1070,4116,4113,172,46261,1212,45593]

theorem envBound54844 : H12AffineFastState.Bounded env54844 := by
  intro p hp
  have h : env54844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54843_54844 : H12AffineEnvironment.transform 10 1191 env54843 = env54844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1191 env54843 == env54844) = true)

theorem identity54844 : scanCanonicalize (H12AffineFastState.compose env54844 (packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 185) := by decide +kernel

theorem selectedBound54844 : packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env54845 : List Nat := [2,4,8,16,32,17,128,173,512,1024,1191,185,8192,1212,32768,9351,40985,42126,42144,32769,184,42116,42165,41002,32809,1045,41991,40984,40985,1070,173,168,172,41996,1212,41632]

theorem envBound54845 : H12AffineFastState.Bounded env54845 := by
  intro p hp
  have h : env54845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54844_54845 : H12AffineEnvironment.transform 11 185 env54844 = env54845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 185 env54844 == env54845) = true)

theorem identity54845 : scanCanonicalize (H12AffineFastState.compose env54845 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(14+1) ^^^ 675) := by decide +kernel

theorem selectedBound54845 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env54846 : List Nat := [2,4,8,16,32,17,128,173,512,1024,1191,185,8192,1212,675,9351,8890,9773,9731,674,184,9767,9750,8841,650,1045,9892,8891,8890,1070,173,168,172,9903,1212,8195]

theorem envBound54846 : H12AffineFastState.Bounded env54846 := by
  intro p hp
  have h : env54846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54845_54846 : H12AffineEnvironment.transform 14 675 env54845 = env54846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 675 env54845 == env54846) = true)

theorem identity54846 : scanCanonicalize (H12AffineFastState.compose env54846 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 1679) := by decide +kernel

theorem selectedBound54846 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env54847 : List Nat := [2,4,8,16,32,17,128,173,512,1024,1191,185,1679,1212,675,520,1077,162,140,674,184,168,153,1030,650,1045,43,1076,1077,1070,173,168,172,32,1212,1676]

theorem envBound54847 : H12AffineFastState.Bounded env54847 := by
  intro p hp
  have h : env54847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54846_54847 : H12AffineEnvironment.transform 12 1679 env54846 = env54847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1679 env54846 == env54847) = true)

theorem identity54847 : scanCanonicalize (H12AffineFastState.compose env54847 (packedSelected [4,6,7] rootPS)) = affineNative (2^(8+1) ^^^ 163) := by decide +kernel

theorem selectedBound54847 : packedSelected [4,6,7] rootPS < 2^1333 := by decide +kernel

def env54848 : List Nat := [2,4,8,16,32,17,128,173,163,1024,1191,185,1068,1212,0,171,1077,162,140,1,184,168,153,1030,41,1045,43,1076,1077,1070,173,168,172,32,1212,1071]

theorem envBound54848 : H12AffineFastState.Bounded env54848 := by
  intro p hp
  have h : env54848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54847_54848 : H12AffineEnvironment.transform 8 163 env54847 = env54848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 163 env54847 == env54848) = true)

theorem identity54848 : scanCanonicalize (H12AffineFastState.compose env54848 (packedSelected [0,3,4,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound54848 : packedSelected [0,3,4,5,10] rootPS < 2^1333 := by decide +kernel

def env54849 : List Nat := [2,4,8,16,32,17,56,21,27,1024,1055,1,1068,1028,0,19,1077,26,52,1,0,16,33,1030,41,1045,43,1076,1077,1070,21,16,20,32,1028,1071]

theorem envBound54849 : H12AffineFastState.Bounded env54849 := by
  intro p hp
  have h : env54849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54848_54849 : H12AffineEnvironment.transform 6 56 env54848 = env54849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env54848 == env54849) = true)

theorem identity54849 : scanCanonicalize (H12AffineFastState.compose env54849 (packedSelected [3,5] rootPS)) = affineNative (2^(9+1) ^^^ 47) := by decide +kernel

theorem selectedBound54849 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env54850 : List Nat := [2,4,8,16,32,17,56,21,27,47,48,1,3,43,0,19,26,26,52,1,0,16,33,41,41,58,43,27,26,1,21,16,20,32,43,0]

theorem envBound54850 : H12AffineFastState.Bounded env54850 := by
  intro p hp
  have h : env54850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54849_54850 : H12AffineEnvironment.transform 9 47 env54849 = env54850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 47 env54849 == env54850) = true)

def env54851 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147521,41002,143496,20497,493035,148801,148801,96346,74794,74799,257,222334,1344,135681]

theorem envBound54851 : H12AffineFastState.Bounded env54851 := by
  intro p hp
  have h : env54851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54805_54851 : H12AffineEnvironment.transform 18 136193 env54805 = env54851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136193 env54805 == env54851) = true)

def env54852 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147521,41002,143496,20497,492615,148717,148717,96346,74794,74799,173,222334,1260,135681]

theorem envBound54852 : H12AffineFastState.Bounded env54852 := by
  intro p hp
  have h : env54852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54851_54852 : H12AffineEnvironment.transform 7 172 env54851 = env54852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env54851 == env54852) = true)

def env54853 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61568,147473,41002,143496,20497,492567,148669,148669,96266,74794,74799,173,222254,1212,135681]

theorem envBound54853 : H12AffineFastState.Bounded env54853 := by
  intro p hp
  have h : env54853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54852_54853 : H12AffineEnvironment.transform 5 16 env54852 = env54853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env54852 == env54853) = true)

theorem identity54853 : scanCanonicalize (H12AffineFastState.compose env54853 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 223242) := by decide +kernel

theorem selectedBound54853 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env54854 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,223242,136193,32769,4097,61568,147473,41002,143496,20497,60445,148669,148669,96266,74794,74799,173,222254,1212,135681]

theorem envBound54854 : H12AffineFastState.Bounded env54854 := by
  intro p hp
  have h : env54854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54853_54854 : H12AffineEnvironment.transform 17 223242 env54853 = env54854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223242 env54853 == env54854) = true)

theorem identity54854 : scanCanonicalize (H12AffineFastState.compose env54854 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 28803) := by decide +kernel

theorem selectedBound54854 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env54855 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,28803,131072,137353,136193,32769,4097,61568,147473,41002,143496,20497,60445,148669,148669,2185,21673,21676,173,136365,1212,135681]

theorem envBound54855 : H12AffineFastState.Bounded env54855 := by
  intro p hp
  have h : env54855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54854_54855 : H12AffineEnvironment.transform 15 28803 env54854 = env54855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28803 env54854 == env54855) = true)

theorem identity54855 : scanCanonicalize (H12AffineFastState.compose env54855 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(14+1) ^^^ 9381) := by decide +kernel

theorem selectedBound54855 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env54856 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,9381,28803,131072,137353,136193,9380,4097,21541,147473,1167,143496,20497,18616,148669,148669,2185,21673,21676,173,136365,1212,135681]

theorem envBound54856 : H12AffineFastState.Bounded env54856 := by
  intro p hp
  have h : env54856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54855_54856 : H12AffineEnvironment.transform 14 9381 env54855 = env54856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9381 env54855 == env54856) = true)

theorem identity54856 : scanCanonicalize (H12AffineFastState.compose env54856 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound54856 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env54857 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1212,9381,13375,131072,137353,136193,9380,4097,4249,132269,1167,143496,5293,3076,131073,131073,2185,4117,4112,173,136365,1212,135681]

theorem envBound54857 : H12AffineFastState.Bounded env54857 := by
  intro p hp
  have h : env54857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54856_54857 : H12AffineEnvironment.transform 13 1212 env54856 = env54857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env54856 == env54857) = true)

theorem identity54857 : scanCanonicalize (H12AffineFastState.compose env54857 (packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 6282) := by decide +kernel

theorem selectedBound54857 : packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env54858 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,6282,1212,7215,3253,131072,137353,136193,7214,4097,4249,132269,1167,133122,5293,3076,131073,131073,2185,4117,4112,173,136365,1212,135681]

theorem envBound54858 : H12AffineFastState.Bounded env54858 := by
  intro p hp
  have h : env54858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54857_54858 : H12AffineEnvironment.transform 12 6282 env54857 = env54858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6282 env54857 == env54858) = true)

theorem identity54858 : scanCanonicalize (H12AffineFastState.compose env54858 (packedSelected [13,17] rootPS)) = affineNative (2^(16+1) ^^^ 185) := by decide +kernel

theorem selectedBound54858 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env54859 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,6282,1212,7215,3253,185,6192,5304,7214,4097,4249,1044,1167,2235,5293,3076,184,184,2185,4117,4112,173,5140,1212,4792]

theorem envBound54859 : H12AffineFastState.Bounded env54859 := by
  intro p hp
  have h : env54859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54858_54859 : H12AffineEnvironment.transform 16 185 env54858 = env54859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 185 env54858 == env54859) = true)

theorem identity54859 : scanCanonicalize (H12AffineFastState.compose env54859 (packedSelected [1,2,3,6,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 697) := by decide +kernel

theorem selectedBound54859 : packedSelected [1,2,3,6,10,11] rootPS < 2^1333 := by decide +kernel

def env54860 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,697,2611,1212,3734,3253,185,2697,1537,3735,696,544,1044,1167,2235,1556,3076,184,184,2185,684,681,173,1709,1212,1]

theorem envBound54860 : H12AffineFastState.Bounded env54860 := by
  intro p hp
  have h : env54860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54859_54860 : H12AffineEnvironment.transform 11 697 env54859 = env54860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 697 env54859 == env54860) = true)

theorem identity54860 : scanCanonicalize (H12AffineFastState.compose env54860 (packedSelected [0,1,3,4,6,8,10,12] rootPS)) = affineNative (2^(10+1) ^^^ 12) := by decide +kernel

theorem selectedBound54860 : packedSelected [0,1,3,4,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env54861 : List Nat := [2,4,8,16,32,16,128,172,512,1024,12,697,575,1212,1690,1209,185,645,1537,1691,696,544,1044,1167,183,1556,1032,184,184,133,684,681,173,1709,1212,1]

theorem envBound54861 : H12AffineFastState.Bounded env54861 := by
  intro p hp
  have h : env54861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54860_54861 : H12AffineEnvironment.transform 10 12 env54860 = env54861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 12 env54860 == env54861) = true)

theorem identity54861 : scanCanonicalize (H12AffineFastState.compose env54861 (packedSelected [0,4,7,9,10,13] rootPS)) = affineNative (2^(8+1) ^^^ 174) := by decide +kernel

theorem selectedBound54861 : packedSelected [0,4,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env54862 : List Nat := [2,4,8,16,32,16,128,172,174,1024,12,23,145,1212,1076,1209,185,43,1199,1077,22,142,1044,1167,183,1210,1032,184,184,133,2,7,173,1027,1212,1]

theorem envBound54862 : H12AffineFastState.Bounded env54862 := by
  intro p hp
  have h : env54862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54861_54862 : H12AffineEnvironment.transform 8 174 env54861 = env54862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 174 env54861 == env54862) = true)

theorem identity54862 : scanCanonicalize (H12AffineFastState.compose env54862 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(9+1) ^^^ 151) := by decide +kernel

theorem selectedBound54862 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env54863 : List Nat := [2,4,8,16,32,16,128,172,174,151,12,23,145,43,163,46,185,43,56,162,22,142,131,24,183,45,159,184,184,133,2,7,173,148,43,1]

theorem envBound54863 : H12AffineFastState.Bounded env54863 := by
  intro p hp
  have h : env54863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54862_54863 : H12AffineEnvironment.transform 9 151 env54862 = env54863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 151 env54862 == env54863) = true)

theorem identity54863 : scanCanonicalize (H12AffineFastState.compose env54863 (packedSelected [1,8] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound54863 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env54864 : List Nat := [2,4,8,16,32,16,19,63,61,4,12,23,2,43,48,46,42,43,56,49,22,29,16,24,36,45,12,43,43,22,2,7,62,7,43,1]

theorem envBound54864 : H12AffineFastState.Bounded env54864 := by
  intro p hp
  have h : env54864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54863_54864 : H12AffineEnvironment.transform 6 19 env54863 = env54864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env54863 == env54864) = true)

theorem identity54864 : scanCanonicalize (H12AffineFastState.compose env54864 (packedSelected [0,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 28) := by decide +kernel

theorem selectedBound54864 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env54865 : List Nat := [2,4,8,16,28,16,19,3,1,4,12,23,2,23,12,18,22,23,4,13,22,29,16,24,24,17,12,23,23,22,2,7,2,7,23,1]

theorem envBound54865 : H12AffineFastState.Bounded env54865 := by
  intro p hp
  have h : env54865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54864_54865 : H12AffineEnvironment.transform 4 28 env54864 = env54865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 28 env54864 == env54865) = true)

theorem identity54865 : scanCanonicalize (H12AffineFastState.compose env54865 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound54865 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54866 : List Nat := [2,4,8,10,6,10,9,3,1,4,12,13,2,13,12,8,12,13,4,13,12,7,10,2,2,11,12,13,13,12,2,7,2,7,13,1]

theorem envBound54866 : H12AffineFastState.Bounded env54866 := by
  intro p hp
  have h : env54866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54865_54866 : H12AffineEnvironment.transform 3 10 env54865 = env54866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env54865 == env54866) = true)

def env54867 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61569,147472,41002,143496,20497,492566,148668,148668,96267,74794,74799,173,222255,1213,135681]

theorem envBound54867 : H12AffineFastState.Bounded env54867 := by
  intro p hp
  have h : env54867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54852_54867 : H12AffineEnvironment.transform 5 17 env54852 = env54867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env54852 == env54867) = true)

theorem identity54867 : scanCanonicalize (H12AffineFastState.compose env54867 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 114723) := by decide +kernel

theorem selectedBound54867 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env54868 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,114723,262144,119842,32769,4097,61569,98355,41002,127147,20497,279605,99487,99487,96267,74794,74799,173,41996,1213,119330]

theorem envBound54868 : H12AffineFastState.Bounded env54868 := by
  intro p hp
  have h : env54868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54867_54868 : H12AffineEnvironment.transform 16 114723 env54867 = env54868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114723 env54867 == env54868) = true)

theorem identity54868 : scanCanonicalize (H12AffineFastState.compose env54868 (packedSelected [3,10,16,18,19,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 3213) := by decide +kernel

theorem selectedBound54868 : packedSelected [3,10,16,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env54869 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,114723,3213,119842,32769,4097,61569,98355,41002,127147,20497,18616,99487,99487,96267,74794,74799,173,41996,1213,119330]

theorem envBound54869 : H12AffineFastState.Bounded env54869 := by
  intro p hp
  have h : env54869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54868_54869 : H12AffineEnvironment.transform 17 3213 env54868 = env54869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3213 env54868 == env54869) = true)

theorem identity54869 : scanCanonicalize (H12AffineFastState.compose env54869 (packedSelected [7,16,18,19,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53282) := by decide +kernel

theorem selectedBound54869 : packedSelected [7,16,18,19,23,26,27] rootPS < 2^1333 := by decide +kernel

def env54870 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,53282,4097,3213,1024,32769,4097,61569,20497,41002,8329,20497,18616,21693,21693,43049,62472,62477,173,41996,1213,512]

theorem envBound54870 : H12AffineFastState.Bounded env54870 := by
  intro p hp
  have h : env54870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54869_54870 : H12AffineEnvironment.transform 15 53282 env54869 = env54870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53282 env54869 == env54870) = true)

theorem identity54870 : scanCanonicalize (H12AffineFastState.compose env54870 (packedSelected [4,9,16] rootPS)) = affineNative (2^(14+1) ^^^ 24601) := by decide +kernel

theorem selectedBound54870 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env54871 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,24601,12347,4097,3213,1024,24600,4097,4248,20497,16435,8329,20497,18616,21693,21693,18480,5137,5140,173,17429,1213,512]

theorem envBound54871 : H12AffineFastState.Bounded env54871 := by
  intro p hp
  have h : env54871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54870_54871 : H12AffineEnvironment.transform 14 24601 env54870 = env54871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 24601 env54870 == env54871) = true)

theorem identity54871 : scanCanonicalize (H12AffineFastState.compose env54871 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 656) := by decide +kernel

theorem selectedBound54871 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env54872 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,656,16384,17033,4779,4097,3213,1024,17032,4097,4248,20497,16435,537,20497,18616,21693,21693,18480,5137,5140,173,17429,1213,512]

theorem envBound54872 : H12AffineFastState.Bounded env54872 := by
  intro p hp
  have h : env54872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54871_54872 : H12AffineEnvironment.transform 12 656 env54871 = env54872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 656 env54871 == env54872) = true)

theorem identity54872 : scanCanonicalize (H12AffineFastState.compose env54872 (packedSelected [0,3,4,8,13] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound54872 : packedSelected [0,3,4,8,13] rootPS < 2^1333 := by decide +kernel

def env54873 : List Nat := [2,4,8,16,32,17,128,172,27,1024,2048,4096,139,16384,16530,4272,4097,3213,1024,16531,4097,4248,20497,16435,2,20497,18616,21693,21693,18480,5137,5140,173,17429,1213,27]

theorem envBound54873 : H12AffineFastState.Bounded env54873 := by
  intro p hp
  have h : env54873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54872_54873 : H12AffineEnvironment.transform 8 27 env54872 = env54873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env54872 == env54873) = true)

theorem identity54873 : scanCanonicalize (H12AffineFastState.compose env54873 (packedSelected [0,2,5,7,8,11,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 6328) := by decide +kernel

theorem selectedBound54873 : packedSelected [0,2,5,7,8,11,12,15] rootPS < 2^1333 := by decide +kernel

def env54874 : List Nat := [2,4,8,16,32,17,128,172,27,1024,2048,4096,139,6328,6186,4272,4097,3213,1024,6187,4097,4248,2217,6283,2,2217,4096,3077,3077,4232,5137,5140,173,7341,1213,27]

theorem envBound54874 : H12AffineFastState.Bounded env54874 := by
  intro p hp
  have h : env54874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54873_54874 : H12AffineEnvironment.transform 13 6328 env54873 = env54874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6328 env54873 == env54874) = true)

theorem identity54874 : scanCanonicalize (H12AffineFastState.compose env54874 (packedSelected [1,2,4,5,6,9,12] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound54874 : packedSelected [1,2,4,5,6,9,12] rootPS < 2^1333 := by decide +kernel

def env54875 : List Nat := [2,4,8,16,32,17,128,172,27,1024,2048,184,139,2048,2194,8,185,3213,1024,2195,185,32,2217,2099,2,2217,184,3077,3077,48,1193,1196,173,3093,1213,27]

theorem envBound54875 : H12AffineFastState.Bounded env54875 := by
  intro p hp
  have h : env54875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54874_54875 : H12AffineEnvironment.transform 11 184 env54874 = env54875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env54874 == env54875) = true)

theorem identity54875 : scanCanonicalize (H12AffineFastState.compose env54875 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 185) := by decide +kernel

theorem selectedBound54875 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env54876 : List Nat := [2,4,8,16,32,17,128,172,27,1024,185,184,139,185,43,8,185,1076,1024,42,185,32,16,138,2,16,184,1212,1212,48,1193,1196,173,1196,1213,27]

theorem envBound54876 : H12AffineFastState.Bounded env54876 := by
  intro p hp
  have h : env54876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54875_54876 : H12AffineEnvironment.transform 10 185 env54875 = env54876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 185 env54875 == env54876) = true)

theorem identity54876 : scanCanonicalize (H12AffineFastState.compose env54876 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound54876 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env54877 : List Nat := [2,4,8,16,32,17,128,172,27,4,185,184,139,185,43,8,185,48,4,42,185,32,16,138,2,16,184,184,184,48,173,168,173,168,185,27]

theorem envBound54877 : H12AffineFastState.Bounded env54877 := by
  intro p hp
  have h : env54877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54876_54877 : H12AffineEnvironment.transform 9 4 env54876 = env54877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env54876 == env54877) = true)

theorem identity54877 : scanCanonicalize (H12AffineFastState.compose env54877 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 21) := by decide +kernel

theorem selectedBound54877 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54878 : List Nat := [2,4,8,16,32,17,21,57,27,4,44,45,30,44,43,8,44,48,4,42,44,32,16,31,2,16,45,45,45,48,56,61,56,61,44,27]

theorem envBound54878 : H12AffineFastState.Bounded env54878 := by
  intro p hp
  have h : env54878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54877_54878 : H12AffineEnvironment.transform 6 21 env54877 = env54878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 21 env54877 == env54878) = true)

theorem identity54878 : scanCanonicalize (H12AffineFastState.compose env54878 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound54878 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54879 : List Nat := [2,4,8,12,32,13,9,37,7,4,44,45,2,44,43,8,44,44,4,42,44,32,12,3,2,12,45,45,45,44,36,33,36,33,44,7]

theorem envBound54879 : H12AffineFastState.Bounded env54879 := by
  intro p hp
  have h : env54879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54878_54879 : H12AffineEnvironment.transform 3 12 env54878 = env54879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env54878 == env54879) = true)

theorem identity54879 : scanCanonicalize (H12AffineFastState.compose env54879 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound54879 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54880 : List Nat := [2,3,8,11,32,10,9,34,0,3,43,42,2,43,43,8,43,43,3,42,43,32,11,3,2,11,42,42,42,43,35,33,35,33,43,0]

theorem envBound54880 : H12AffineFastState.Bounded env54880 := by
  intro p hp
  have h : env54880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54879_54880 : H12AffineEnvironment.transform 1 3 env54879 = env54880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env54879 == env54880) = true)

theorem identity54880 : scanCanonicalize (H12AffineFastState.compose env54880 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound54880 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env54881 : List Nat := [2,3,8,11,10,10,9,8,0,3,1,0,2,1,1,8,1,1,3,0,1,10,11,3,2,11,0,0,0,1,9,11,9,11,1,0]

theorem envBound54881 : H12AffineFastState.Bounded env54881 := by
  intro p hp
  have h : env54881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54880_54881 : H12AffineEnvironment.transform 4 10 env54880 = env54881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env54880 == env54881) = true)

def env54882 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147521,41002,143496,20497,492614,148716,148716,96346,74794,74799,172,222334,1261,135681]

theorem envBound54882 : H12AffineFastState.Bounded env54882 := by
  intro p hp
  have h : env54882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54851_54882 : H12AffineEnvironment.transform 7 173 env54851 = env54882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env54851 == env54882) = true)

def env54883 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61568,147473,41002,143496,20497,492566,148668,148668,96266,74794,74799,172,222254,1213,135681]

theorem envBound54883 : H12AffineFastState.Bounded env54883 := by
  intro p hp
  have h : env54883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54882_54883 : H12AffineEnvironment.transform 5 16 env54882 = env54883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env54882 == env54883) = true)

theorem identity54883 : scanCanonicalize (H12AffineFastState.compose env54883 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 137352) := by decide +kernel

theorem selectedBound54883 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env54884 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,137352,136193,32769,4097,61568,147473,41002,143496,20497,105630,148668,148668,96266,74794,74799,172,222254,1213,135681]

theorem envBound54884 : H12AffineFastState.Bounded env54884 := by
  intro p hp
  have h : env54884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54883_54884 : H12AffineEnvironment.transform 17 137352 env54883 = env54884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137352 env54883 == env54884) = true)

theorem identity54884 : scanCanonicalize (H12AffineFastState.compose env54884 (packedSelected [1,5,8,18,19,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 13374) := by decide +kernel

theorem selectedBound54884 : packedSelected [1,5,8,18,19,23,24,26] rootPS < 2^1333 := by decide +kernel

def env54885 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,13374,131072,137352,136193,32769,4097,61568,147473,41002,143496,20497,43168,148668,148668,19508,4116,4113,172,151568,1213,135681]

theorem envBound54885 : H12AffineFastState.Bounded env54885 := by
  intro p hp
  have h : env54885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54884_54885 : H12AffineEnvironment.transform 15 13374 env54884 = env54885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13374 env54884 == env54885) = true)

theorem identity54885 : scanCanonicalize (H12AffineFastState.compose env54885 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound54885 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env54886 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1213,32768,13374,131072,137352,136193,32769,4097,46141,132268,41002,143496,5292,43168,131073,131073,2185,4116,4113,172,136365,1213,135681]

theorem envBound54886 : H12AffineFastState.Bounded env54886 := by
  intro p hp
  have h : env54886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54885_54886 : H12AffineEnvironment.transform 13 1213 env54885 = env54886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env54885 == env54886) = true)

theorem identity54886 : scanCanonicalize (H12AffineFastState.compose env54886 (packedSelected [13,17] rootPS)) = affineNative (2^(14+1) ^^^ 12313) := by decide +kernel

theorem selectedBound54886 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env54887 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1213,12313,13374,131072,137352,136193,12312,4097,1060,132268,4147,143496,5292,6329,131073,131073,2185,4116,4113,172,136365,1213,135681]

theorem envBound54887 : H12AffineFastState.Bounded env54887 := by
  intro p hp
  have h : env54887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54886_54887 : H12AffineEnvironment.transform 14 12313 env54886 = env54887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12313 env54886 == env54887) = true)

theorem identity54887 : scanCanonicalize (H12AffineFastState.compose env54887 (packedSelected [0,4,5,7,8,9,10,13] rootPS)) = affineNative (2^(11+1) ^^^ 3103) := by decide +kernel

theorem selectedBound54887 : packedSelected [0,4,5,7,8,9,10,13] rootPS < 2^1333 := by decide +kernel

def env54888 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,3103,8192,1213,11270,10273,131072,132247,133150,11271,3102,1060,132268,3116,142487,2227,1190,131073,131073,2185,3083,3086,172,133298,1213,134686]

theorem envBound54888 : H12AffineFastState.Bounded env54888 := by
  intro p hp
  have h : env54888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54887_54888 : H12AffineEnvironment.transform 11 3103 env54887 = env54888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3103 env54887 == env54888) = true)

theorem identity54888 : scanCanonicalize (H12AffineFastState.compose env54888 (packedSelected [1,4,5,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound54888 : packedSelected [1,4,5,9,16] rootPS < 2^1333 := by decide +kernel

def env54889 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,3103,1052,1213,2074,3133,131072,132247,133150,2075,3102,1060,132268,3116,133259,2227,1190,131073,131073,2185,3083,3086,172,133298,1213,134686]

theorem envBound54889 : H12AffineFastState.Bounded env54889 := by
  intro p hp
  have h : env54889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54888_54889 : H12AffineEnvironment.transform 12 1052 env54888 = env54889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env54888 == env54889) = true)

theorem identity54889 : scanCanonicalize (H12AffineFastState.compose env54889 (packedSelected [0,2,3,4,5,10,12,15] rootPS)) = affineNative (2^(16+1) ^^^ 2194) := by decide +kernel

theorem selectedBound54889 : packedSelected [0,2,3,4,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env54890 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,3103,1052,1213,2074,3133,2194,3077,140,2075,3102,1060,3134,3116,25,2227,1190,2195,2195,2185,3083,3086,172,32,1213,1676]

theorem envBound54890 : H12AffineFastState.Bounded env54890 := by
  intro p hp
  have h : env54890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54889_54890 : H12AffineEnvironment.transform 16 2194 env54889 = env54890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 2194 env54889 == env54890) = true)

theorem identity54890 : scanCanonicalize (H12AffineFastState.compose env54890 (packedSelected [0,3,4,5,6,7,9,10] rootPS)) = affineNative (2^(10+1) ^^^ 162) := by decide +kernel

theorem selectedBound54890 : packedSelected [0,3,4,5,6,7,9,10] rootPS < 2^1333 := by decide +kernel

def env54891 : List Nat := [2,4,8,16,32,16,128,173,512,1024,162,1213,1052,1213,184,1183,48,1191,140,185,1212,1060,1180,1166,25,17,1190,49,49,43,1193,1196,172,32,1213,1676]

theorem envBound54891 : H12AffineFastState.Bounded env54891 := by
  intro p hp
  have h : env54891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54890_54891 : H12AffineEnvironment.transform 10 162 env54890 = env54891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 162 env54890 == env54891) = true)

theorem identity54891 : scanCanonicalize (H12AffineFastState.compose env54891 (packedSelected [0,1,3,4,5,6] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound54891 : packedSelected [0,1,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env54892 : List Nat := [2,4,8,16,12,16,128,129,512,1024,142,1169,1052,1169,148,1183,28,1163,140,149,1168,1032,1180,1166,25,17,1162,29,29,7,1157,1152,128,12,1169,1676]

theorem envBound54892 : H12AffineFastState.Bounded env54892 := by
  intro p hp
  have h : env54892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54891_54892 : H12AffineEnvironment.transform 4 12 env54891 = env54892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env54891 == env54892) = true)

theorem identity54892 : scanCanonicalize (H12AffineFastState.compose env54892 (packedSelected [0,2,4,8] rootPS)) = affineNative (2^(8+1) ^^^ 146) := by decide +kernel

theorem selectedBound54892 : packedSelected [0,2,4,8] rootPS < 2^1333 := by decide +kernel

def env54893 : List Nat := [2,4,8,16,12,16,128,129,146,1024,142,1169,1052,1169,148,1183,28,1163,140,149,1168,1032,1180,1166,25,17,1162,29,29,7,1157,1152,128,12,1169,1054]

theorem envBound54893 : H12AffineFastState.Bounded env54893 := by
  intro p hp
  have h : env54893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54892_54893 : H12AffineEnvironment.transform 8 146 env54892 = env54893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 146 env54892 == env54893) = true)

theorem identity54893 : scanCanonicalize (H12AffineFastState.compose env54893 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 140) := by decide +kernel

theorem selectedBound54893 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env54894 : List Nat := [2,4,8,16,12,16,128,129,146,140,142,29,144,29,148,19,28,7,140,149,28,132,16,2,25,17,6,29,29,7,9,12,128,12,29,146]

theorem envBound54894 : H12AffineFastState.Bounded env54894 := by
  intro p hp
  have h : env54894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54893_54894 : H12AffineEnvironment.transform 9 140 env54893 = env54894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 140 env54893 == env54894) = true)

theorem identity54894 : scanCanonicalize (H12AffineFastState.compose env54894 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound54894 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env54895 : List Nat := [2,4,8,16,12,16,18,19,0,30,28,29,2,29,6,19,28,7,30,7,28,22,16,2,25,17,6,29,29,7,9,12,18,12,29,0]

theorem envBound54895 : H12AffineFastState.Bounded env54895 := by
  intro p hp
  have h : env54895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54894_54895 : H12AffineEnvironment.transform 6 18 env54894 = env54895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env54894 == env54895) = true)

def env54896 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61569,147472,41002,143496,20497,492567,148669,148669,96267,74794,74799,172,222255,1212,135681]

theorem envBound54896 : H12AffineFastState.Bounded env54896 := by
  intro p hp
  have h : env54896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54882_54896 : H12AffineEnvironment.transform 5 17 env54882 = env54896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env54882 == env54896) = true)

theorem identity54896 : scanCanonicalize (H12AffineFastState.compose env54896 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 45216) := by decide +kernel

theorem selectedBound54896 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env54897 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,45216,262144,42145,32769,4097,61569,61616,41002,32808,20497,341175,62493,62493,96267,74794,74799,172,119951,1212,41633]

theorem envBound54897 : H12AffineFastState.Bounded env54897 := by
  intro p hp
  have h : env54897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54896_54897 : H12AffineEnvironment.transform 16 45216 env54896 = env54897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45216 env54896 == env54897) = true)

theorem identity54897 : scanCanonicalize (H12AffineFastState.compose env54897 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound54897 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env54898 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1213,32768,65536,45216,262144,42145,32769,4097,46140,46093,41002,32808,5292,341175,45216,45216,81078,74794,74799,172,102450,1212,41633]

theorem envBound54898 : H12AffineFastState.Bounded env54898 := by
  intro p hp
  have h : env54898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54897_54898 : H12AffineEnvironment.transform 13 1213 env54897 = env54898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env54897 == env54898) = true)

theorem identity54898 : scanCanonicalize (H12AffineFastState.compose env54898 (packedSelected [4,9,16] rootPS)) = affineNative (2^(14+1) ^^^ 9380) := by decide +kernel

theorem selectedBound54898 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env54899 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1213,9380,65536,5124,262144,5,9381,4097,4248,4265,1166,9356,5292,341175,5124,5124,81078,74794,74799,172,78998,1212,1541]

theorem envBound54899 : H12AffineFastState.Bounded env54899 := by
  intro p hp
  have h : env54899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54898_54899 : H12AffineEnvironment.transform 14 9380 env54898 = env54899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9380 env54898 == env54899) = true)

theorem identity54899 : scanCanonicalize (H12AffineFastState.compose env54899 (packedSelected [4,9,20] rootPS)) = affineNative (2^(15+1) ^^^ 12347) := by decide +kernel

theorem selectedBound54899 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env54900 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1213,9380,12347,5124,262144,5,9381,4097,4248,4265,1166,9356,5292,263308,5124,5124,3213,5137,5140,172,1197,1212,1541]

theorem envBound54900 : H12AffineFastState.Bounded env54900 := by
  intro p hp
  have h : env54900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54899_54900 : H12AffineEnvironment.transform 15 12347 env54899 = env54900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12347 env54899 == env54900) = true)

theorem identity54900 : scanCanonicalize (H12AffineFastState.compose env54900 (packedSelected [1,3,6,10,12,13,17] rootPS)) = affineNative (2^(12+1) ^^^ 7311) := by decide +kernel

theorem selectedBound54900 : packedSelected [1,3,6,10,12,13,17] rootPS < 2^1333 := by decide +kernel

def env54901 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,7311,1213,6187,3252,5124,262144,5,6186,4097,4248,4265,1166,6147,5292,263308,5124,5124,3213,5137,5140,172,1197,1212,1541]

theorem envBound54901 : H12AffineFastState.Bounded env54901 := by
  intro p hp
  have h : env54901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54900_54901 : H12AffineEnvironment.transform 12 7311 env54900 = env54901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7311 env54900 == env54901) = true)

theorem identity54901 : scanCanonicalize (H12AffineFastState.compose env54901 (packedSelected [1,2,3,5,8,11,13,18] rootPS)) = affineNative (2^(9+1) ^^^ 653) := by decide +kernel

theorem selectedBound54901 : packedSelected [1,2,3,5,8,11,13,18] rootPS < 2^1333 := by decide +kernel

def env54902 : List Nat := [2,4,8,16,32,17,128,173,512,653,2048,4096,6658,560,6187,2617,4745,262144,5,6186,4097,4248,4265,515,6147,4641,262657,4745,4745,2560,4764,4761,172,544,561,136]

theorem envBound54902 : H12AffineFastState.Bounded env54902 := by
  intro p hp
  have h : env54902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54901_54902 : H12AffineEnvironment.transform 9 653 env54901 = env54902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 653 env54901 == env54902) = true)

theorem identity54902 : scanCanonicalize (H12AffineFastState.compose env54902 (packedSelected [10,12,13] rootPS)) = affineNative (2^(17+1) ^^^ 4754) := by decide +kernel

theorem selectedBound54902 : packedSelected [10,12,13] rootPS < 2^1333 := by decide +kernel

def env54903 : List Nat := [2,4,8,16,32,17,128,173,512,653,2048,4096,6658,560,6187,2617,4745,4754,5,6186,4097,4248,4265,515,6147,4641,4243,4745,4745,2560,4764,4761,172,544,561,136]

theorem envBound54903 : H12AffineFastState.Bounded env54903 := by
  intro p hp
  have h : env54903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54902_54903 : H12AffineEnvironment.transform 17 4754 env54902 = env54903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 4754 env54902 == env54903) = true)

theorem identity54903 : scanCanonicalize (H12AffineFastState.compose env54903 (packedSelected [0,3,4,5,6,7,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 2587) := by decide +kernel

theorem selectedBound54903 : packedSelected [0,3,4,5,6,7,9,10] rootPS < 2^1333 := by decide +kernel

def env54904 : List Nat := [2,4,8,16,32,17,128,173,512,653,2048,2587,25,560,560,2617,2194,2185,5,561,2586,2691,2738,515,536,2106,2696,2194,2194,2560,2183,2178,172,544,561,136]

theorem envBound54904 : H12AffineFastState.Bounded env54904 := by
  intro p hp
  have h : env54904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54903_54904 : H12AffineEnvironment.transform 11 2587 env54903 = env54904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2587 env54903 == env54904) = true)

theorem identity54904 : scanCanonicalize (H12AffineFastState.compose env54904 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound54904 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env54905 : List Nat := [2,4,8,11,32,10,128,173,512,653,2048,2560,2,555,555,2594,2185,2185,5,554,2561,2691,2729,515,515,2081,2696,2185,2185,2560,2183,2178,172,544,554,136]

theorem envBound54905 : H12AffineFastState.Bounded env54905 := by
  intro p hp
  have h : env54905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54904_54905 : H12AffineEnvironment.transform 3 11 env54904 = env54905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env54904 == env54905) = true)

theorem identity54905 : scanCanonicalize (H12AffineFastState.compose env54905 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 555) := by decide +kernel

theorem selectedBound54905 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54906 : List Nat := [2,4,8,11,32,10,128,173,512,653,555,43,2,555,555,9,674,674,5,554,42,168,130,515,515,522,163,674,674,43,684,681,172,544,554,136]

theorem envBound54906 : H12AffineFastState.Bounded env54906 := by
  intro p hp
  have h : env54906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54905_54906 : H12AffineEnvironment.transform 10 555 env54905 = env54906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 555 env54905 == env54906) = true)

theorem identity54906 : scanCanonicalize (H12AffineFastState.compose env54906 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound54906 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env54907 : List Nat := [2,4,8,11,32,10,128,173,42,167,1,43,2,1,1,9,136,136,5,0,42,168,130,41,41,32,163,136,136,43,134,131,172,10,0,136]

theorem envBound54907 : H12AffineFastState.Bounded env54907 := by
  intro p hp
  have h : env54907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54906_54907 : H12AffineEnvironment.transform 8 42 env54906 = env54907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env54906 == env54907) = true)

theorem identity54907 : scanCanonicalize (H12AffineFastState.compose env54907 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound54907 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env54908 : List Nat := [2,4,8,11,32,10,9,36,42,46,1,43,2,1,1,9,1,1,5,0,42,33,11,41,41,32,42,1,1,43,15,10,37,10,0,1]

theorem envBound54908 : H12AffineFastState.Bounded env54908 := by
  intro p hp
  have h : env54908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54907_54908 : H12AffineEnvironment.transform 6 9 env54907 = env54908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env54907 == env54908) = true)

theorem identity54908 : scanCanonicalize (H12AffineFastState.compose env54908 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound54908 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54909 : List Nat := [2,4,5,6,32,7,4,36,39,35,1,38,2,1,1,4,1,1,5,0,39,33,6,36,36,32,39,1,1,38,2,7,37,7,0,1]

theorem envBound54909 : H12AffineFastState.Bounded env54909 := by
  intro p hp
  have h : env54909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54908_54909 : H12AffineEnvironment.transform 2 5 env54908 = env54909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env54908 == env54909) = true)

def env54910 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,2154705,8388608,16777216,33554432,8914001,134217728,8389889,42087817,2189403,50962569,4294967296,34088328,4347445490,34359738368,33563273]

theorem envBound54910 : H12AffineFastState.Bounded env54910 := by
  intro p hp
  have h : env54910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45450_54910 : H12AffineEnvironment.transform 27 8389889 env45450 = env54910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 8389889 env45450 == env54910) = true)

def env54911 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,2154705,147520,16777216,33554432,672785,134217728,148801,33584585,2189403,50962569,4294967296,34088328,4347445490,34359738368,33563273]

theorem envBound54911 : H12AffineFastState.Bounded env54911 := by
  intro p hp
  have h : env54911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54910_54911 : H12AffineEnvironment.transform 22 147520 env54910 = env54911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147520 env54910 == env54911) = true)

def env54912 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,2154705,147520,16777216,33554432,672785,134217728,148801,33584585,2189403,50962569,4294967296,34088328,4347445490,151462016,33563273]

theorem envBound54912 : H12AffineFastState.Bounded env54912 := by
  intro p hp
  have h : env54912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54911_54912 : H12AffineEnvironment.transform 34 151462016 env54911 = env54912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 151462016 env54911 == env54912) = true)

def env54913 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,16777216,33554432,672785,134217728,148801,33584585,96347,50962569,4294967296,34088328,4345352434,151462016,33563273]

theorem envBound54913 : H12AffineFastState.Bounded env54913 := by
  intro p hp
  have h : env54913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54912_54913 : H12AffineEnvironment.transform 20 4096 env54912 = env54913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env54912 == env54913) = true)

theorem identity54913 : scanCanonicalize (H12AffineFastState.compose env54913 (packedSelected [14] rootPS)) = affineNative (2^(31+1) ^^^ 750911) := by decide +kernel

theorem selectedBound54913 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env54914 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,16777216,33554432,672785,134217728,148801,33584585,96347,50962569,750911,34088328,51094989,151462016,33563273]

theorem envBound54914 : H12AffineFastState.Bounded env54914 := by
  intro p hp
  have h : env54914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54913_54914 : H12AffineEnvironment.transform 31 750911 env54913 = env54914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 750911 env54913 == env54914) = true)

def env54915 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,16777216,533640,672785,134217728,148801,545089,96347,16876545,750911,256,17006917,151462016,525825]

theorem envBound54915 : H12AffineFastState.Bounded env54915 := by
  intro p hp
  have h : env54915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54914_54915 : H12AffineEnvironment.transform 24 533640 env54914 = env54915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 533640 env54914 == env54915) = true)

def env54916 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,16777216,533640,672785,17245632,148801,545089,96347,16876545,750911,256,17006917,1344,525825]

theorem envBound54916 : H12AffineFastState.Bounded env54916 := by
  intro p hp
  have h : env54916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54915_54916 : H12AffineEnvironment.transform 26 17245632 env54915 = env54916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245632 env54915 == env54916) = true)

theorem identity54916 : scanCanonicalize (H12AffineFastState.compose env54916 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 74862) := by decide +kernel

theorem selectedBound54916 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env54917 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,524288,32769,4096,61649,91182,16777216,533640,614527,17039790,90415,545089,96347,16876545,545105,256,16819499,1344,525825]

theorem envBound54917 : H12AffineFastState.Bounded env54917 := by
  intro p hp
  have h : env54917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54916_54917 : H12AffineEnvironment.transform 16 74862 env54916 = env54917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 74862 env54916 == env54917) = true)

def env54918 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,524288,32769,4096,61649,91182,123164,533640,614527,385202,90415,545089,96347,25885,545105,256,82999,1344,525825]

theorem envBound54918 : H12AffineFastState.Bounded env54918 := by
  intro p hp
  have h : env54918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54917_54918 : H12AffineEnvironment.transform 23 123164 env54917 = env54918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 123164 env54917 == env54918) = true)

def env54919 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,21584,32769,4096,61649,91182,123164,28888,78895,385202,90415,1297,96347,25885,1281,256,82999,1344,21073]

theorem envBound54919 : H12AffineFastState.Bounded env54919 := by
  intro p hp
  have h : env54919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54918_54919 : H12AffineEnvironment.transform 18 21584 env54918 = env54919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21584 env54918 == env54919) = true)

theorem identity54919 : scanCanonicalize (H12AffineFastState.compose env54919 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 25677) := by decide +kernel

theorem selectedBound54919 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env54920 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,25677,65536,74862,262144,21584,25676,4096,5276,91182,66897,28888,78895,328959,90415,1297,96347,25885,1281,256,82999,1344,21073]

theorem envBound54920 : H12AffineFastState.Bounded env54920 := by
  intro p hp
  have h : env54920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54919_54920 : H12AffineEnvironment.transform 14 25677 env54919 = env54920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25677 env54919 == env54920) = true)

def env54921 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74862,262144,4416,8540,4096,5276,74046,66897,13768,78895,328959,74815,1297,81227,8205,1281,256,65831,1344,5953]

theorem envBound54921 : H12AffineFastState.Bounded env54921 := by
  intro p hp
  have h : env54921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54920_54921 : H12AffineEnvironment.transform 13 1296 env54920 = env54921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env54920 == env54921) = true)

def env54922 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74862,65664,4416,8540,4096,5276,74046,66897,13768,78895,1151,74815,1297,81227,8205,1281,256,65831,1344,5953]

theorem envBound54922 : H12AffineFastState.Bounded env54922 := by
  intro p hp
  have h : env54922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54921_54922 : H12AffineEnvironment.transform 17 65664 env54921 = env54922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env54921 == env54922) = true)

theorem identity54922 : scanCanonicalize (H12AffineFastState.compose env54922 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5238) := by decide +kernel

theorem selectedBound54922 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env54923 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,5238,12312,5366,4416,8540,4096,5276,13640,4391,13768,8281,1151,12361,1297,10557,8205,1281,256,5457,1344,5953]

theorem envBound54923 : H12AffineFastState.Bounded env54923 := by
  intro p hp
  have h : env54923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54922_54923 : H12AffineEnvironment.transform 15 5238 env54922 = env54923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5238 env54922 == env54923) = true)

def env54924 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5464,1296,5125,5238,1344,5366,4416,5124,4096,5276,16,4391,144,5377,1151,1297,1297,7269,5461,1281,256,5457,1344,5953]

theorem envBound54924 : H12AffineFastState.Bounded env54924 := by
  intro p hp
  have h : env54924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54923_54924 : H12AffineEnvironment.transform 12 5464 env54923 = env54924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5464 env54923 == env54924) = true)

theorem identity54924 : scanCanonicalize (H12AffineFastState.compose env54924 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound54924 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env54925 : List Nat := [2,4,8,16,32,64,128,20,512,1024,2048,4096,5196,1028,5125,5238,1108,5366,4180,5124,4096,5276,16,4147,144,5141,1151,1029,1029,7269,5185,1045,20,5189,1108,5717]

theorem envBound54925 : H12AffineFastState.Bounded env54925 := by
  intro p hp
  have h : env54925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54924_54925 : H12AffineEnvironment.transform 7 20 env54924 = env54925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env54924 == env54925) = true)

theorem identity54925 : scanCanonicalize (H12AffineFastState.compose env54925 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 1109) := by decide +kernel

theorem selectedBound54925 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env54926 : List Nat := [2,4,8,16,32,64,128,20,512,1024,2048,1109,25,1028,80,35,1108,163,1025,81,1109,201,16,1126,144,64,1151,1029,1029,2096,20,1045,20,16,1108,512]

theorem envBound54926 : H12AffineFastState.Bounded env54926 := by
  intro p hp
  have h : env54926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54925_54926 : H12AffineEnvironment.transform 11 1109 env54925 = env54926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1109 env54925 == env54926) = true)

theorem identity54926 : scanCanonicalize (H12AffineFastState.compose env54926 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound54926 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env54927 : List Nat := [2,4,8,16,32,16,128,20,512,1024,2048,1029,25,1028,0,35,1028,163,1025,1,1029,153,16,1078,144,16,1071,1029,1029,2096,20,1045,20,16,1028,512]

theorem envBound54927 : H12AffineFastState.Bounded env54927 := by
  intro p hp
  have h : env54927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54926_54927 : H12AffineEnvironment.transform 5 16 env54926 = env54927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env54926 == env54927) = true)

theorem identity54927 : scanCanonicalize (H12AffineFastState.compose env54927 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1212) := by decide +kernel

theorem selectedBound54927 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env54928 : List Nat := [2,4,8,16,32,16,128,20,512,1024,1212,1029,25,1028,0,35,1028,163,1025,1,1029,153,16,1078,144,16,1071,1029,1029,1164,20,1045,20,16,1028,512]

theorem envBound54928 : H12AffineFastState.Bounded env54928 := by
  intro p hp
  have h : env54928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54927_54928 : H12AffineEnvironment.transform 10 1212 env54927 = env54928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1212 env54927 == env54928) = true)

theorem identity54928 : scanCanonicalize (H12AffineFastState.compose env54928 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound54928 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env54929 : List Nat := [2,4,8,16,32,16,128,20,136,1024,1212,1029,25,1028,0,35,1028,163,1025,1,1029,153,16,1078,144,16,1071,1029,1029,1164,20,1045,20,16,1028,136]

theorem envBound54929 : H12AffineFastState.Bounded env54929 := by
  intro p hp
  have h : env54929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54928_54929 : H12AffineEnvironment.transform 8 136 env54928 = env54929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env54928 == env54929) = true)

theorem identity54929 : scanCanonicalize (H12AffineFastState.compose env54929 (packedSelected [0,5,7,9] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound54929 : packedSelected [0,5,7,9] rootPS < 2^1333 := by decide +kernel

def env54930 : List Nat := [2,4,8,10,32,10,128,14,136,1024,1190,1029,3,1028,0,35,1028,163,1025,1,1029,131,10,1068,138,10,1071,1029,1029,1164,14,1039,14,10,1028,136]

theorem envBound54930 : H12AffineFastState.Bounded env54930 := by
  intro p hp
  have h : env54930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54929_54930 : H12AffineEnvironment.transform 3 10 env54929 = env54930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env54929 == env54930) = true)

theorem identity54930 : scanCanonicalize (H12AffineFastState.compose env54930 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound54930 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env54931 : List Nat := [2,4,8,10,11,10,128,14,136,1024,1165,1029,3,1028,0,8,1028,136,1025,1,1029,131,10,1031,138,10,1028,1029,1029,1164,14,1039,14,10,1028,136]

theorem envBound54931 : H12AffineFastState.Bounded env54931 := by
  intro p hp
  have h : env54931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54930_54931 : H12AffineEnvironment.transform 4 11 env54930 = env54931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env54930 == env54931) = true)

theorem identity54931 : scanCanonicalize (H12AffineFastState.compose env54931 (packedSelected [0,1,2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound54931 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env54932 : List Nat := [2,4,8,10,11,10,9,14,1,1024,1028,1029,3,1028,0,8,1028,1,1025,1,1029,10,10,1031,3,10,1028,1029,1029,1029,14,1039,14,10,1028,1]

theorem envBound54932 : H12AffineFastState.Bounded env54932 := by
  intro p hp
  have h : env54932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54931_54932 : H12AffineEnvironment.transform 6 9 env54931 = env54932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env54931 == env54932) = true)

theorem identity54932 : scanCanonicalize (H12AffineFastState.compose env54932 (packedSelected [0,1] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound54932 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env54933 : List Nat := [2,4,8,10,11,10,9,14,1,4,0,1,3,0,0,8,0,1,5,1,1,10,10,3,3,10,0,1,1,1,14,11,14,10,0,1]

theorem envBound54933 : H12AffineFastState.Bounded env54933 := by
  intro p hp
  have h : env54933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54932_54933 : H12AffineEnvironment.transform 9 4 env54932 = env54933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env54932 == env54933) = true)

theorem identity54933 : scanCanonicalize (H12AffineFastState.compose env54933 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound54933 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54934 : List Nat := [2,3,8,10,11,10,9,9,1,3,0,1,3,0,0,8,0,1,2,1,1,10,10,3,3,10,0,1,1,1,9,11,9,10,0,1]

theorem envBound54934 : H12AffineFastState.Bounded env54934 := by
  intro p hp
  have h : env54934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54933_54934 : H12AffineEnvironment.transform 1 3 env54933 = env54934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env54933 == env54934) = true)

def env54935 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5465,1296,5124,5238,1345,5366,4416,5125,4096,5276,17,4391,145,5376,1151,1296,1297,7268,5460,1281,256,5457,1344,5953]

theorem envBound54935 : H12AffineFastState.Bounded env54935 := by
  intro p hp
  have h : env54935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54923_54935 : H12AffineEnvironment.transform 12 5465 env54923 = env54935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5465 env54923 == env54935) = true)

theorem identity54935 : scanCanonicalize (H12AffineFastState.compose env54935 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound54935 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env54936 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,4120,81,4421,4407,0,4535,4416,4420,4096,4573,17,4391,145,4161,318,81,80,6437,4117,64,256,4112,1,4608]

theorem envBound54936 : H12AffineFastState.Bounded env54936 := by
  intro p hp
  have h : env54936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54935_54936 : H12AffineEnvironment.transform 9 321 env54935 = env54936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env54935 == env54936) = true)

theorem identity54936 : scanCanonicalize (H12AffineFastState.compose env54936 (packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,16,18,20] rootPS)) = affineNative (2^(11+1) ^^^ 649) := by decide +kernel

theorem selectedBound54936 : packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,16,18,20] rootPS < 2^1333 := by decide +kernel

def env54937 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,649,657,81,972,958,0,830,969,973,649,852,17,942,145,712,318,81,80,2988,668,64,256,665,1,137]

theorem envBound54937 : H12AffineFastState.Bounded env54937 := by
  intro p hp
  have h : env54937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54936_54937 : H12AffineEnvironment.transform 11 649 env54936 = env54937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 649 env54936 == env54937) = true)

theorem identity54937 : scanCanonicalize (H12AffineFastState.compose env54937 (packedSelected [0,1,2,3,7,8,10,11,12,13,15,16,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound54937 : packedSelected [0,1,2,3,7,8,10,11,12,13,15,16,23,24] rootPS < 2^1333 := by decide +kernel

def env54938 : List Nat := [2,4,8,16,32,64,128,69,512,4,2048,649,657,81,649,763,0,635,652,648,649,529,17,747,145,712,123,81,80,2793,668,64,69,665,1,137]

theorem envBound54938 : H12AffineFastState.Bounded env54938 := by
  intro p hp
  have h : env54938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54937_54938 : H12AffineEnvironment.transform 7 69 env54937 = env54938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env54937 == env54938) = true)

theorem identity54938 : scanCanonicalize (H12AffineFastState.compose env54938 (packedSelected [0,1,2,3,7,10,11,12,13] rootPS)) = affineNative (2^(10+1) ^^^ 659) := by decide +kernel

theorem selectedBound54938 : packedSelected [0,1,2,3,7,10,11,12,13] rootPS < 2^1333 := by decide +kernel

def env54939 : List Nat := [2,4,8,16,32,64,128,69,512,4,659,649,657,81,649,763,0,635,652,648,649,529,17,747,145,712,123,81,80,122,668,64,69,665,1,137]

theorem envBound54939 : H12AffineFastState.Bounded env54939 := by
  intro p hp
  have h : env54939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54938_54939 : H12AffineEnvironment.transform 10 659 env54938 = env54939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 659 env54938 == env54939) = true)

theorem identity54939 : scanCanonicalize (H12AffineFastState.compose env54939 (packedSelected [3,4,5,9,10,15,16] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound54939 : packedSelected [3,4,5,9,10,15,16] rootPS < 2^1333 := by decide +kernel

def env54940 : List Nat := [2,4,8,16,32,64,128,69,136,4,27,1,25,81,1,115,0,243,4,0,1,153,17,99,145,64,123,81,80,122,20,64,69,17,1,137]

theorem envBound54940 : H12AffineFastState.Bounded env54940 := by
  intro p hp
  have h : env54940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54939_54940 : H12AffineEnvironment.transform 8 136 env54939 = env54940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env54939 == env54940) = true)

theorem identity54940 : scanCanonicalize (H12AffineFastState.compose env54940 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound54940 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env54941 : List Nat := [2,4,8,16,11,64,128,69,136,4,27,1,25,81,1,88,0,216,4,0,1,153,17,72,145,64,80,81,80,81,20,64,69,17,1,137]

theorem envBound54941 : H12AffineFastState.Bounded env54941 := by
  intro p hp
  have h : env54941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54940_54941 : H12AffineEnvironment.transform 4 11 env54940 = env54941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env54940 == env54941) = true)

theorem identity54941 : scanCanonicalize (H12AffineFastState.compose env54941 (packedSelected [0,1,2] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound54941 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env54942 : List Nat := [2,4,8,2,11,64,128,69,136,4,9,1,11,67,1,74,0,202,4,0,1,139,3,72,131,64,66,67,66,67,6,64,69,3,1,137]

theorem envBound54942 : H12AffineFastState.Bounded env54942 := by
  intro p hp
  have h : env54942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54941_54942 : H12AffineEnvironment.transform 3 2 env54941 = env54942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env54941 == env54942) = true)

theorem identity54942 : scanCanonicalize (H12AffineFastState.compose env54942 (packedSelected [1,4] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound54942 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env54943 : List Nat := [2,4,8,2,11,0,128,5,136,4,9,1,11,3,1,10,0,138,4,0,1,139,3,8,131,0,2,3,2,3,6,0,5,3,1,137]

theorem envBound54943 : H12AffineFastState.Bounded env54943 := by
  intro p hp
  have h : env54943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54942_54943 : H12AffineEnvironment.transform 5 0 env54942 = env54943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env54942 == env54943) = true)

theorem identity54943 : scanCanonicalize (H12AffineFastState.compose env54943 (packedSelected [0,1,7] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound54943 : packedSelected [0,1,7] rootPS < 2^1333 := by decide +kernel

def env54944 : List Nat := [2,2,8,2,11,0,128,3,136,2,9,1,11,3,1,10,0,138,2,0,1,139,3,8,131,0,2,3,2,3,0,0,3,3,1,137]

theorem envBound54944 : H12AffineFastState.Bounded env54944 := by
  intro p hp
  have h : env54944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54943_54944 : H12AffineEnvironment.transform 1 2 env54943 = env54944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env54943 == env54944) = true)

theorem identity54944 : scanCanonicalize (H12AffineFastState.compose env54944 (packedSelected [0,1,8] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound54944 : packedSelected [0,1,8] rootPS < 2^1333 := by decide +kernel

def env54945 : List Nat := [2,2,2,2,1,0,128,3,130,2,3,1,1,3,1,0,0,128,2,0,1,129,3,2,131,0,2,3,2,3,0,0,3,3,1,131]

theorem envBound54945 : H12AffineFastState.Bounded env54945 := by
  intro p hp
  have h : env54945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54944_54945 : H12AffineEnvironment.transform 2 2 env54944 = env54945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env54944 == env54945) = true)

def env54946 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74862,65665,4416,8540,4096,5276,74046,66897,13768,78895,1150,74815,1297,81227,8205,1281,256,65831,1344,5953]

theorem envBound54946 : H12AffineFastState.Bounded env54946 := by
  intro p hp
  have h : env54946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54921_54946 : H12AffineEnvironment.transform 17 65665 env54921 = env54946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env54921 == env54946) = true)

theorem identity54946 : scanCanonicalize (H12AffineFastState.compose env54946 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 310) := by decide +kernel

theorem selectedBound54946 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env54947 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,310,9560,439,4416,8540,4096,5276,8200,1127,13768,13593,1150,9481,1297,15485,8205,1281,256,17,1344,5953]

theorem envBound54947 : H12AffineFastState.Bounded env54947 := by
  intro p hp
  have h : env54947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54946_54947 : H12AffineEnvironment.transform 15 310 env54946 = env54947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 310 env54946 == env54947) = true)

def env54948 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,24,1296,325,310,1344,439,4416,324,4096,5276,16,1127,5584,5377,1150,1297,1297,7269,21,1281,256,17,1344,5953]

theorem envBound54948 : H12AffineFastState.Bounded env54948 := by
  intro p hp
  have h : env54948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54947_54948 : H12AffineEnvironment.transform 12 24 env54947 = env54948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env54947 == env54948) = true)

theorem identity54948 : scanCanonicalize (H12AffineFastState.compose env54948 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 1108) := by decide +kernel

theorem selectedBound54948 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env54949 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1108,24,1296,325,310,1344,439,1300,324,1108,200,16,1127,388,341,1150,1297,1297,2097,21,1281,256,17,1344,789]

theorem envBound54949 : H12AffineFastState.Bounded env54949 := by
  intro p hp
  have h : env54949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54948_54949 : H12AffineEnvironment.transform 11 1108 env54948 = env54949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1108 env54948 == env54949) = true)

theorem identity54949 : scanCanonicalize (H12AffineFastState.compose env54949 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound54949 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env54950 : List Nat := [2,4,8,16,32,64,128,21,512,1024,2048,1108,24,1029,80,35,1109,162,1025,81,1108,200,16,1127,145,64,1150,1028,1028,2097,21,1044,21,17,1109,512]

theorem envBound54950 : H12AffineFastState.Bounded env54950 := by
  intro p hp
  have h : env54950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54949_54950 : H12AffineEnvironment.transform 7 21 env54949 = env54950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env54949 == env54950) = true)

theorem identity54950 : scanCanonicalize (H12AffineFastState.compose env54950 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound54950 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env54951 : List Nat := [2,4,8,16,32,16,128,21,512,1024,2048,1028,24,1029,0,35,1029,162,1025,1,1028,152,16,1079,145,16,1070,1028,1028,2097,21,1044,21,17,1029,512]

theorem envBound54951 : H12AffineFastState.Bounded env54951 := by
  intro p hp
  have h : env54951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54950_54951 : H12AffineEnvironment.transform 5 16 env54950 = env54951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env54950 == env54951) = true)

theorem identity54951 : scanCanonicalize (H12AffineFastState.compose env54951 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound54951 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env54952 : List Nat := [2,4,8,16,32,16,128,21,512,1024,1,1028,24,1029,0,35,1029,162,1025,1,1028,152,16,1079,145,16,1070,1028,1028,48,21,1044,21,17,1029,512]

theorem envBound54952 : H12AffineFastState.Bounded env54952 := by
  intro p hp
  have h : env54952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54951_54952 : H12AffineEnvironment.transform 10 1 env54951 = env54952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env54951 == env54952) = true)

theorem identity54952 : scanCanonicalize (H12AffineFastState.compose env54952 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound54952 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env54953 : List Nat := [2,4,8,16,32,16,128,21,137,1024,1,1028,24,1029,0,35,1029,162,1025,1,1028,152,16,1079,145,16,1070,1028,1028,48,21,1044,21,17,1029,137]

theorem envBound54953 : H12AffineFastState.Bounded env54953 := by
  intro p hp
  have h : env54953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54952_54953 : H12AffineEnvironment.transform 8 137 env54952 = env54953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env54952 == env54953) = true)

theorem identity54953 : scanCanonicalize (H12AffineFastState.compose env54953 (packedSelected [0,2,5] rootPS)) = affineNative (2^(9+1) ^^^ 47) := by decide +kernel

theorem selectedBound54953 : packedSelected [0,2,5] rootPS < 2^1333 := by decide +kernel

end H12CloudChart2