import H12CloudChart2Data150

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound37631 : H12AffineFastState.Bounded env37631 := by
  intro p hp
  have h : env37631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37630_37631 : H12AffineEnvironment.transform 7 34 env37630 = env37631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 34 env37630 == env37631) = true)

theorem identity37631 : scanCanonicalize (H12AffineFastState.compose env37631 (packedSelected [1,2,5] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound37631 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env37632 : List Nat := [2,4,8,16,13,1,4,15,1,31,27,10,24,1,11,31,27,26,5,10,11,13,27,30,15,16,13,10,0,12,20,26,14,16,17,27]

theorem envBound37632 : H12AffineFastState.Bounded env37632 := by
  intro p hp
  have h : env37632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37631_37632 : H12AffineEnvironment.transform 4 13 env37631 = env37632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env37631 == env37632) = true)

theorem identity37632 : scanCanonicalize (H12AffineFastState.compose env37632 (packedSelected [0,3,4] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound37632 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env37633 : List Nat := [2,4,8,12,13,1,4,15,1,3,7,10,4,1,11,3,7,6,5,10,11,13,7,2,15,12,13,10,0,12,8,6,14,12,13,7]

theorem envBound37633 : H12AffineFastState.Bounded env37633 := by
  intro p hp
  have h : env37633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37632_37633 : H12AffineEnvironment.transform 3 12 env37632 = env37633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env37632 == env37633) = true)

theorem identity37633 : scanCanonicalize (H12AffineFastState.compose env37633 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound37633 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37634 : List Nat := [2,4,3,7,6,1,4,4,1,3,7,1,4,1,0,3,7,6,5,1,0,6,7,2,4,7,6,1,0,7,3,6,5,7,6,7]

theorem envBound37634 : H12AffineFastState.Bounded env37634 := by
  intro p hp
  have h : env37634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37633_37634 : H12AffineEnvironment.transform 2 3 env37633 = env37634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env37633 == env37634) = true)

theorem identity37634 : scanCanonicalize (H12AffineFastState.compose env37634 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound37634 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37635 : List Nat := [2,3,3,0,1,1,3,3,1,3,0,1,3,1,0,3,0,1,2,1,0,1,0,2,3,0,1,1,0,0,3,1,2,0,1,0]

theorem envBound37635 : H12AffineFastState.Bounded env37635 := by
  intro p hp
  have h : env37635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37634_37635 : H12AffineEnvironment.transform 1 3 env37634 = env37635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env37634 == env37635) = true)

theorem identity37635 : scanCanonicalize (H12AffineFastState.compose env37635 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound37635 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37636 : List Nat := [0,1,1,0,1,1,1,1,1,1,0,1,1,1,0,1,0,1,0,1,0,1,0,0,1,0,1,1,0,0,1,1,0,0,1,0]

theorem envBound37636 : H12AffineFastState.Bounded env37636 := by
  intro p hp
  have h : env37636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37635_37636 : H12AffineEnvironment.transform 0 0 env37635 = env37636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env37635 == env37636) = true)

def env37637 : List Nat := [2,4,8,16,32,1,128,256,512,273,2048,773,24,0,260,694,913,567,517,261,772,648,912,694,901,149,302,896,1,2480,20,913,257,17,16,276]

theorem envBound37637 : H12AffineFastState.Bounded env37637 := by
  intro p hp
  have h : env37637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37626_37637 : H12AffineEnvironment.transform 9 273 env37626 = env37637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env37626 == env37637) = true)

theorem identity37637 : scanCanonicalize (H12AffineFastState.compose env37637 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 145) := by decide +kernel

theorem selectedBound37637 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env37638 : List Nat := [2,4,8,16,32,1,128,145,512,128,2048,660,24,0,149,694,512,567,517,148,661,648,513,694,532,149,191,529,1,2081,20,512,144,17,16,133]

theorem envBound37638 : H12AffineFastState.Bounded env37638 := by
  intro p hp
  have h : env37638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37637_37638 : H12AffineEnvironment.transform 7 145 env37637 = env37638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 145 env37637 == env37638) = true)

theorem identity37638 : scanCanonicalize (H12AffineFastState.compose env37638 (packedSelected [0,1,2,3,7,10,12,17,20] rootPS)) = affineNative (2^(10+1) ^^^ 525) := by decide +kernel

theorem selectedBound37638 : packedSelected [0,1,2,3,7,10,12,17,20] rootPS < 2^1333 := by decide +kernel

def env37639 : List Nat := [2,4,8,16,32,1,128,145,512,128,525,660,24,0,149,694,512,567,517,148,661,648,513,694,532,149,191,529,1,556,20,512,144,17,16,133]

theorem envBound37639 : H12AffineFastState.Bounded env37639 := by
  intro p hp
  have h : env37639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37638_37639 : H12AffineEnvironment.transform 10 525 env37638 = env37639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 525 env37638 == env37639) = true)

theorem identity37639 : scanCanonicalize (H12AffineFastState.compose env37639 (packedSelected [0,1,4,7,9,11,12,13,15,16,17] rootPS)) = affineNative (2^(8+1) ^^^ 29) := by decide +kernel

theorem selectedBound37639 : packedSelected [0,1,4,7,9,11,12,13,15,16,17] rootPS < 2^1333 := by decide +kernel

def env37640 : List Nat := [2,4,8,16,32,1,128,145,29,128,16,137,24,0,149,171,29,42,24,148,136,149,28,171,9,149,191,12,1,49,20,29,144,17,16,133]

theorem envBound37640 : H12AffineFastState.Bounded env37640 := by
  intro p hp
  have h : env37640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37639_37640 : H12AffineEnvironment.transform 8 29 env37639 = env37640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 29 env37639 == env37640) = true)

theorem identity37640 : scanCanonicalize (H12AffineFastState.compose env37640 (packedSelected [0,2,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 21) := by decide +kernel

theorem selectedBound37640 : packedSelected [0,2,5,7] rootPS < 2^1333 := by decide +kernel

def env37641 : List Nat := [2,4,8,16,32,1,21,4,29,21,16,28,24,0,0,62,29,42,24,1,29,0,28,62,9,0,42,12,1,49,20,29,5,17,16,16]

theorem envBound37641 : H12AffineFastState.Bounded env37641 := by
  intro p hp
  have h : env37641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37640_37641 : H12AffineEnvironment.transform 6 21 env37640 = env37641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 21 env37640 == env37641) = true)

theorem identity37641 : scanCanonicalize (H12AffineFastState.compose env37641 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound37641 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env37642 : List Nat := [2,4,8,16,27,1,21,4,29,21,16,28,24,0,0,5,29,17,24,1,29,0,28,5,9,0,17,12,1,10,20,29,5,17,16,16]

theorem envBound37642 : H12AffineFastState.Bounded env37642 := by
  intro p hp
  have h : env37642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37641_37642 : H12AffineEnvironment.transform 4 27 env37641 = env37642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env37641 == env37642) = true)

theorem identity37642 : scanCanonicalize (H12AffineFastState.compose env37642 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound37642 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env37643 : List Nat := [2,4,8,12,7,1,9,4,1,9,12,0,4,0,0,5,1,13,4,1,1,0,0,5,9,0,13,12,1,10,8,1,5,13,12,12]

theorem envBound37643 : H12AffineFastState.Bounded env37643 := by
  intro p hp
  have h : env37643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37642_37643 : H12AffineEnvironment.transform 3 12 env37642 = env37643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env37642 == env37643) = true)

def env37644 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1557,24,1297,325,65536,66679,65665,1876,324,1556,649,65830,66896,965,66082,1150,66599,1296,68422,20,65831,257,1280,1344,340]

theorem envBound37644 : H12AffineFastState.Bounded env37644 := by
  intro p hp
  have h : env37644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37603_37644 : H12AffineEnvironment.transform 11 1557 env37603 = env37644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1557 env37603 == env37644) = true)

def env37645 : List Nat := [2,4,8,16,32,0,128,256,512,1024,2048,1557,24,1297,261,65536,66615,65665,1812,260,1556,649,65830,66832,901,66082,1086,66599,1296,68358,20,65831,257,1280,1280,276]

theorem envBound37645 : H12AffineFastState.Bounded env37645 := by
  intro p hp
  have h : env37645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37644_37645 : H12AffineEnvironment.transform 5 0 env37644 = env37645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env37644 == env37645) = true)

theorem identity37645 : scanCanonicalize (H12AffineFastState.compose env37645 (packedSelected [1,8,28] rootPS)) = affineNative (2^(8+1) ^^^ 385) := by decide +kernel

theorem selectedBound37645 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env37646 : List Nat := [2,4,8,16,32,0,128,256,385,1024,2048,1428,24,1297,261,65536,66615,65665,1173,260,1429,264,65830,66832,4,65955,1086,66599,1296,67719,20,65831,257,1280,1280,276]

theorem envBound37646 : H12AffineFastState.Bounded env37646 := by
  intro p hp
  have h : env37646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37645_37646 : H12AffineEnvironment.transform 8 385 env37645 = env37646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 385 env37645 == env37646) = true)

def env37647 : List Nat := [2,4,8,16,32,0,128,256,385,272,2048,132,24,1,261,65536,65831,65665,389,260,133,264,65830,65536,4,65955,302,65847,0,67719,20,65831,257,16,16,276]

theorem envBound37647 : H12AffineFastState.Bounded env37647 := by
  intro p hp
  have h : env37647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37646_37647 : H12AffineEnvironment.transform 9 272 env37646 = env37647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env37646 == env37647) = true)

theorem identity37647 : scanCanonicalize (H12AffineFastState.compose env37647 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 51) := by decide +kernel

theorem selectedBound37647 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env37648 : List Nat := [2,4,8,16,32,0,128,256,385,272,2048,132,24,1,261,51,276,178,389,260,133,264,277,51,4,400,302,260,0,2228,20,276,257,16,16,276]

theorem envBound37648 : H12AffineFastState.Bounded env37648 := by
  intro p hp
  have h : env37648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37647_37648 : H12AffineEnvironment.transform 15 51 env37647 = env37648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 51 env37647 == env37648) = true)

theorem identity37648 : scanCanonicalize (H12AffineFastState.compose env37648 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 128) := by decide +kernel

theorem selectedBound37648 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env37649 : List Nat := [2,4,8,16,32,0,128,128,1,144,2048,132,24,1,133,51,148,178,5,132,133,136,149,51,4,16,174,132,0,2228,20,148,129,16,16,148]

theorem envBound37649 : H12AffineFastState.Bounded env37649 := by
  intro p hp
  have h : env37649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37648_37649 : H12AffineEnvironment.transform 7 128 env37648 = env37649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 128 env37648 == env37649) = true)

theorem identity37649 : scanCanonicalize (H12AffineFastState.compose env37649 (packedSelected [1,2,3,15] rootPS)) = affineNative (2^(10+1) ^^^ 169) := by decide +kernel

theorem selectedBound37649 : packedSelected [1,2,3,15] rootPS < 2^1333 := by decide +kernel

def env37650 : List Nat := [2,4,8,16,32,0,128,128,1,144,169,132,24,1,133,51,148,178,5,132,133,136,149,51,4,16,174,132,0,29,20,148,129,16,16,148]

theorem envBound37650 : H12AffineFastState.Bounded env37650 := by
  intro p hp
  have h : env37650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37649_37650 : H12AffineEnvironment.transform 10 169 env37649 = env37650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 169 env37649 == env37650) = true)

theorem identity37650 : scanCanonicalize (H12AffineFastState.compose env37650 (packedSelected [1,12] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound37650 : packedSelected [1,12] rootPS < 2^1333 := by decide +kernel

def env37651 : List Nat := [2,4,8,16,7,0,128,128,1,144,142,132,24,1,133,20,148,149,5,132,133,136,149,20,4,16,137,132,0,29,20,148,129,16,16,148]

theorem envBound37651 : H12AffineFastState.Bounded env37651 := by
  intro p hp
  have h : env37651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37650_37651 : H12AffineEnvironment.transform 4 7 env37650 = env37651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env37650 == env37651) = true)

theorem identity37651 : scanCanonicalize (H12AffineFastState.compose env37651 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound37651 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env37652 : List Nat := [2,4,8,0,7,0,128,128,1,128,142,132,8,1,133,4,132,133,5,132,133,136,133,4,4,0,137,132,0,13,4,132,129,0,0,132]

theorem envBound37652 : H12AffineFastState.Bounded env37652 := by
  intro p hp
  have h : env37652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37651_37652 : H12AffineEnvironment.transform 3 0 env37651 = env37652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env37651 == env37652) = true)

def env37653 : List Nat := [2,4,8,16,32,0,128,256,385,273,2048,133,24,0,261,65536,65830,65665,388,260,132,264,65830,65537,4,65955,303,65846,1,67719,20,65831,257,17,17,276]

theorem envBound37653 : H12AffineFastState.Bounded env37653 := by
  intro p hp
  have h : env37653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37646_37653 : H12AffineEnvironment.transform 9 273 env37646 = env37653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env37646 == env37653) = true)

theorem identity37653 : scanCanonicalize (H12AffineFastState.compose env37653 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 167) := by decide +kernel

theorem selectedBound37653 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env37654 : List Nat := [2,4,8,16,32,0,128,256,385,273,2048,133,24,0,261,167,385,38,388,260,132,264,385,166,4,260,303,401,1,2080,20,384,257,17,17,276]

theorem envBound37654 : H12AffineFastState.Bounded env37654 := by
  intro p hp
  have h : env37654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37653_37654 : H12AffineEnvironment.transform 15 167 env37653 = env37654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 167 env37653 == env37654) = true)

theorem identity37654 : scanCanonicalize (H12AffineFastState.compose env37654 (packedSelected [0,1,2,3,7,10,12,17,20] rootPS)) = affineNative (2^(10+1) ^^^ 136) := by decide +kernel

theorem selectedBound37654 : packedSelected [0,1,2,3,7,10,12,17,20] rootPS < 2^1333 := by decide +kernel

def env37655 : List Nat := [2,4,8,16,32,0,128,256,385,273,136,133,24,0,261,167,385,38,388,260,132,264,385,166,4,260,303,401,1,168,20,384,257,17,17,276]

theorem envBound37655 : H12AffineFastState.Bounded env37655 := by
  intro p hp
  have h : env37655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37654_37655 : H12AffineEnvironment.transform 10 136 env37654 = env37655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 136 env37654 == env37655) = true)

theorem identity37655 : scanCanonicalize (H12AffineFastState.compose env37655 (packedSelected [0,2,4,5,7,9,11,13,15,16] rootPS)) = affineNative (2^(7+1) ^^^ 141) := by decide +kernel

theorem selectedBound37655 : packedSelected [0,2,4,5,7,9,11,13,15,16] rootPS < 2^1333 := by decide +kernel

def env37656 : List Nat := [2,4,8,16,32,0,128,141,12,156,136,133,24,0,136,167,12,38,9,137,132,133,12,166,4,137,162,28,1,168,20,13,140,17,17,153]

theorem envBound37656 : H12AffineFastState.Bounded env37656 := by
  intro p hp
  have h : env37656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37655_37656 : H12AffineEnvironment.transform 7 141 env37655 = env37656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 141 env37655 == env37656) = true)

def env37657 : List Nat := [2,4,8,16,32,1,128,256,512,1024,2048,1557,24,1297,260,65536,66614,65665,1813,261,1556,649,65830,66833,900,66082,1087,66599,1296,68359,20,65831,257,1280,1281,277]

theorem envBound37657 : H12AffineFastState.Bounded env37657 := by
  intro p hp
  have h : env37657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37644_37657 : H12AffineEnvironment.transform 5 1 env37644 = env37657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env37644 == env37657) = true)

theorem identity37657 : scanCanonicalize (H12AffineFastState.compose env37657 (packedSelected [1,8,28] rootPS)) = affineNative (2^(9+1) ^^^ 657) := by decide +kernel

theorem selectedBound37657 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env37658 : List Nat := [2,4,8,16,32,1,128,256,512,657,2048,132,24,896,260,65536,66215,65665,388,261,133,649,65830,66432,900,66082,686,66230,897,68359,20,65831,257,913,912,277]

theorem envBound37658 : H12AffineFastState.Bounded env37658 := by
  intro p hp
  have h : env37658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37657_37658 : H12AffineEnvironment.transform 9 657 env37657 = env37658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 657 env37657 == env37658) = true)

def env37659 : List Nat := [2,4,8,16,32,1,128,256,512,657,2048,132,24,896,260,688,23,561,388,261,133,649,918,304,900,146,686,6,897,2487,20,919,257,913,912,277]

theorem envBound37659 : H12AffineFastState.Bounded env37659 := by
  intro p hp
  have h : env37659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37658_37659 : H12AffineEnvironment.transform 15 688 env37658 = env37659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 688 env37658 == env37659) = true)

def env37660 : List Nat := [2,4,8,16,32,1,128,256,512,657,416,132,24,896,260,688,23,561,388,261,133,649,918,304,900,146,686,6,897,23,20,919,257,913,912,277]

theorem envBound37660 : H12AffineFastState.Bounded env37660 := by
  intro p hp
  have h : env37660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37659_37660 : H12AffineEnvironment.transform 10 416 env37659 = env37660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 416 env37659 == env37660) = true)

theorem identity37660 : scanCanonicalize (H12AffineFastState.compose env37660 (packedSelected [1,4,9,12,13,16] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound37660 : packedSelected [1,4,9,12,13,16] rootPS < 2^1333 := by decide +kernel

def env37661 : List Nat := [2,4,8,16,26,1,128,256,512,657,410,132,24,896,260,650,23,523,388,261,133,649,918,266,900,146,660,6,897,23,20,919,257,913,912,277]

theorem envBound37661 : H12AffineFastState.Bounded env37661 := by
  intro p hp
  have h : env37661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37660_37661 : H12AffineEnvironment.transform 4 26 env37660 = env37661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env37660 == env37661) = true)

theorem identity37661 : scanCanonicalize (H12AffineFastState.compose env37661 (packedSelected [1,2,8] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound37661 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env37662 : List Nat := [2,4,8,16,26,1,128,14,512,657,148,132,24,654,10,650,23,523,138,11,133,649,664,4,650,146,660,6,655,23,20,665,15,671,670,27]

theorem envBound37662 : H12AffineFastState.Bounded env37662 := by
  intro p hp
  have h : env37662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37661_37662 : H12AffineEnvironment.transform 7 14 env37661 = env37662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env37661 == env37662) = true)

theorem identity37662 : scanCanonicalize (H12AffineFastState.compose env37662 (packedSelected [0,2,3,4,5,10,12] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound37662 : packedSelected [0,2,3,4,5,10,12] rootPS < 2^1333 := by decide +kernel

def env37663 : List Nat := [2,4,8,1,11,1,128,14,512,640,133,132,9,654,10,650,6,523,138,11,133,649,649,4,650,131,645,6,655,6,5,648,15,654,655,10]

theorem envBound37663 : H12AffineFastState.Bounded env37663 := by
  intro p hp
  have h : env37663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37662_37663 : H12AffineEnvironment.transform 3 1 env37662 = env37663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env37662 == env37663) = true)

theorem identity37663 : scanCanonicalize (H12AffineFastState.compose env37663 (packedSelected [1,2,3,7,9] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound37663 : packedSelected [1,2,3,7,9] rootPS < 2^1333 := by decide +kernel

def env37664 : List Nat := [2,3,8,1,11,1,128,9,512,640,130,131,9,649,10,650,1,523,138,11,130,649,649,3,650,131,642,1,648,1,2,648,8,649,648,10]

theorem envBound37664 : H12AffineFastState.Bounded env37664 := by
  intro p hp
  have h : env37664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37663_37664 : H12AffineEnvironment.transform 1 3 env37663 = env37664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env37663 == env37664) = true)

theorem identity37664 : scanCanonicalize (H12AffineFastState.compose env37664 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound37664 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env37665 : List Nat := [2,3,8,1,11,1,3,9,512,515,1,0,9,522,10,521,1,523,9,11,1,522,522,3,521,0,513,1,523,1,2,523,8,522,523,10]

theorem envBound37665 : H12AffineFastState.Bounded env37665 := by
  intro p hp
  have h : env37665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37664_37665 : H12AffineEnvironment.transform 6 3 env37664 = env37665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env37664 == env37665) = true)

theorem identity37665 : scanCanonicalize (H12AffineFastState.compose env37665 (packedSelected [1,2] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound37665 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env37666 : List Nat := [2,3,8,1,11,1,3,9,11,8,1,0,9,1,10,2,1,0,9,11,1,1,1,3,2,0,10,1,0,1,2,0,8,1,0,10]

theorem envBound37666 : H12AffineFastState.Bounded env37666 := by
  intro p hp
  have h : env37666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37665_37666 : H12AffineEnvironment.transform 8 11 env37665 = env37666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env37665 == env37666) = true)

theorem identity37666 : scanCanonicalize (H12AffineFastState.compose env37666 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound37666 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37667 : List Nat := [1,0,8,1,8,1,0,9,8,8,1,0,9,1,9,1,1,0,9,8,1,1,1,0,1,0,9,1,0,1,1,0,8,1,0,9]

theorem envBound37667 : H12AffineFastState.Bounded env37667 := by
  intro p hp
  have h : env37667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37666_37667 : H12AffineEnvironment.transform 0 1 env37666 = env37667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env37666 == env37667) = true)

theorem identity37667 : scanCanonicalize (H12AffineFastState.compose env37667 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound37667 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37668 : List Nat := [1,0,1,1,1,1,0,0,1,1,1,0,0,1,0,1,1,0,0,1,1,1,1,0,1,0,0,1,0,1,1,0,1,1,0,0]

theorem envBound37668 : H12AffineFastState.Bounded env37668 := by
  intro p hp
  have h : env37668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37667_37668 : H12AffineEnvironment.transform 2 1 env37667 = env37668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env37667 == env37668) = true)

def env37669 : List Nat := [2,4,8,16,32,1,128,256,512,657,417,132,24,896,260,688,23,561,388,261,133,649,918,304,900,146,686,6,897,22,20,919,257,913,912,277]

theorem envBound37669 : H12AffineFastState.Bounded env37669 := by
  intro p hp
  have h : env37669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37659_37669 : H12AffineEnvironment.transform 10 417 env37659 = env37669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 417 env37659 == env37669) = true)

theorem identity37669 : scanCanonicalize (H12AffineFastState.compose env37669 (packedSelected [1,4,9,12,13,16] rootPS)) = affineNative (2^(4+1) ^^^ 28) := by decide +kernel

theorem selectedBound37669 : packedSelected [1,4,9,12,13,16] rootPS < 2^1333 := by decide +kernel

def env37670 : List Nat := [2,4,8,16,28,1,128,256,512,657,413,132,24,896,260,652,23,525,388,261,133,649,918,268,900,146,658,6,897,22,20,919,257,913,912,277]

theorem envBound37670 : H12AffineFastState.Bounded env37670 := by
  intro p hp
  have h : env37670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37669_37670 : H12AffineEnvironment.transform 4 28 env37669 = env37670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 28 env37669 == env37670) = true)

theorem identity37670 : scanCanonicalize (H12AffineFastState.compose env37670 (packedSelected [2,8,12,13,15,17] rootPS)) = affineNative (2^(8+1) ^^^ 277) := by decide +kernel

theorem selectedBound37670 : packedSelected [2,8,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env37671 : List Nat := [2,4,8,16,28,1,128,256,277,388,413,132,24,149,260,409,23,280,388,261,133,412,131,268,145,146,391,6,148,22,20,130,257,132,133,277]

theorem envBound37671 : H12AffineFastState.Bounded env37671 := by
  intro p hp
  have h : env37671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37670_37671 : H12AffineEnvironment.transform 8 277 env37670 = env37671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env37670 == env37671) = true)

theorem identity37671 : scanCanonicalize (H12AffineFastState.compose env37671 (packedSelected [3,5,7,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound37671 : packedSelected [3,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env37672 : List Nat := [2,4,8,16,28,1,8,256,277,268,277,12,24,29,260,273,23,280,268,261,13,276,11,268,25,26,271,6,28,22,20,10,257,12,13,277]

theorem envBound37672 : H12AffineFastState.Bounded env37672 := by
  intro p hp
  have h : env37672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37671_37672 : H12AffineEnvironment.transform 6 8 env37671 = env37672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env37671 == env37672) = true)

theorem identity37672 : scanCanonicalize (H12AffineFastState.compose env37672 (packedSelected [1,2,3,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 18) := by decide +kernel

theorem selectedBound37672 : packedSelected [1,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env37673 : List Nat := [2,4,8,16,28,1,8,18,7,30,7,12,24,29,22,3,23,10,30,23,13,6,11,30,25,26,29,6,28,22,20,10,19,12,13,7]

theorem envBound37673 : H12AffineFastState.Bounded env37673 := by
  intro p hp
  have h : env37673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37672_37673 : H12AffineEnvironment.transform 7 18 env37672 = env37673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 18 env37672 == env37673) = true)

theorem identity37673 : scanCanonicalize (H12AffineFastState.compose env37673 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound37673 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env37674 : List Nat := [2,4,3,16,23,1,3,18,7,21,7,7,19,22,22,3,23,1,21,23,6,6,0,21,18,17,22,6,23,22,20,1,19,7,6,7]

theorem envBound37674 : H12AffineFastState.Bounded env37674 := by
  intro p hp
  have h : env37674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37673_37674 : H12AffineEnvironment.transform 2 3 env37673 = env37674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env37673 == env37674) = true)

def env37675 : List Nat := [2,4,8,16,32,1,128,256,512,657,2048,132,24,896,260,689,22,560,388,261,133,649,919,305,900,147,686,7,897,2486,20,918,257,913,912,277]

theorem envBound37675 : H12AffineFastState.Bounded env37675 := by
  intro p hp
  have h : env37675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37658_37675 : H12AffineEnvironment.transform 15 689 env37658 = env37675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 689 env37658 == env37675) = true)

def env37676 : List Nat := [2,4,8,16,32,1,128,256,512,657,416,132,24,896,260,689,22,560,388,261,133,649,919,305,900,147,686,7,897,22,20,918,257,913,912,277]

theorem envBound37676 : H12AffineFastState.Bounded env37676 := by
  intro p hp
  have h : env37676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37675_37676 : H12AffineEnvironment.transform 10 416 env37675 = env37676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 416 env37675 == env37676) = true)

theorem identity37676 : scanCanonicalize (H12AffineFastState.compose env37676 (packedSelected [1,4,9,12,13,16] rootPS)) = affineNative (2^(8+1) ^^^ 444) := by decide +kernel

theorem selectedBound37676 : packedSelected [1,4,9,12,13,16] rootPS < 2^1333 := by decide +kernel

def env37677 : List Nat := [2,4,8,16,32,1,128,256,444,301,416,132,24,60,260,269,22,396,388,261,133,309,43,305,56,147,274,7,61,22,20,42,257,45,44,277]

theorem envBound37677 : H12AffineFastState.Bounded env37677 := by
  intro p hp
  have h : env37677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37676_37677 : H12AffineEnvironment.transform 8 444 env37676 = env37677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 444 env37676 == env37677) = true)

theorem identity37677 : scanCanonicalize (H12AffineFastState.compose env37677 (packedSelected [1,5,8,10,12,15,18] rootPS)) = affineNative (2^(7+1) ^^^ 35) := by decide +kernel

theorem selectedBound37677 : packedSelected [1,5,8,10,12,15,18] rootPS < 2^1333 := by decide +kernel

def env37678 : List Nat := [2,4,8,16,32,1,128,35,159,14,131,132,24,60,39,46,22,175,167,38,133,22,43,18,56,147,49,7,61,22,20,42,34,45,44,54]

theorem envBound37678 : H12AffineFastState.Bounded env37678 := by
  intro p hp
  have h : env37678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37677_37678 : H12AffineEnvironment.transform 7 35 env37677 = env37678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 35 env37677 == env37678) = true)

theorem identity37678 : scanCanonicalize (H12AffineFastState.compose env37678 (packedSelected [2,3,5,8,13] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound37678 : packedSelected [2,3,5,8,13] rootPS < 2^1333 := by decide +kernel

def env37679 : List Nat := [2,4,8,16,11,1,128,8,159,14,131,132,24,23,12,5,22,132,140,13,133,22,0,18,19,147,26,7,22,22,20,1,9,6,7,29]

theorem envBound37679 : H12AffineFastState.Bounded env37679 := by
  intro p hp
  have h : env37679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37678_37679 : H12AffineEnvironment.transform 4 11 env37678 = env37679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env37678 == env37679) = true)

theorem identity37679 : scanCanonicalize (H12AffineFastState.compose env37679 (packedSelected [0,2,3,5,7,8] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound37679 : packedSelected [0,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env37680 : List Nat := [2,4,2,16,1,1,128,2,149,4,131,132,18,23,6,5,22,132,134,7,133,22,0,18,19,147,16,7,22,22,20,1,3,6,7,23]

theorem envBound37680 : H12AffineFastState.Bounded env37680 := by
  intro p hp
  have h : env37680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37679_37680 : H12AffineEnvironment.transform 2 2 env37679 = env37680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env37679 == env37680) = true)

theorem identity37680 : scanCanonicalize (H12AffineFastState.compose env37680 (packedSelected [1,2] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound37680 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env37681 : List Nat := [2,4,2,16,1,1,19,2,6,4,16,23,18,23,6,5,22,23,21,7,22,22,0,18,19,0,16,7,22,22,20,1,3,6,7,23]

theorem envBound37681 : H12AffineFastState.Bounded env37681 := by
  intro p hp
  have h : env37681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37680_37681 : H12AffineEnvironment.transform 6 19 env37680 = env37681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env37680 == env37681) = true)

theorem identity37681 : scanCanonicalize (H12AffineFastState.compose env37681 (packedSelected [1,3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound37681 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env37682 : List Nat := [2,2,2,16,1,1,19,2,0,2,16,17,18,17,0,3,16,17,19,1,16,16,0,18,19,0,16,1,16,16,18,1,3,0,1,17]

theorem envBound37682 : H12AffineFastState.Bounded env37682 := by
  intro p hp
  have h : env37682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37681_37682 : H12AffineEnvironment.transform 1 2 env37681 = env37682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env37681 == env37682) = true)

def env37683 : List Nat := [2,4,8,16,32,1,128,256,512,657,417,132,24,896,260,689,22,560,388,261,133,649,919,305,900,147,686,7,897,23,20,918,257,913,912,277]

theorem envBound37683 : H12AffineFastState.Bounded env37683 := by
  intro p hp
  have h : env37683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37675_37683 : H12AffineEnvironment.transform 10 417 env37675 = env37683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 417 env37675 == env37683) = true)

theorem identity37683 : scanCanonicalize (H12AffineFastState.compose env37683 (packedSelected [1,4,9,12,13,16] rootPS)) = affineNative (2^(8+1) ^^^ 443) := by decide +kernel

theorem selectedBound37683 : packedSelected [1,4,9,12,13,16] rootPS < 2^1333 := by decide +kernel

def env37684 : List Nat := [2,4,8,16,32,1,128,256,443,298,417,132,24,59,260,266,22,395,388,261,133,306,44,305,63,147,277,7,58,23,20,45,257,42,43,277]

theorem envBound37684 : H12AffineFastState.Bounded env37684 := by
  intro p hp
  have h : env37684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37683_37684 : H12AffineEnvironment.transform 8 443 env37683 = env37684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 443 env37683 == env37684) = true)

theorem identity37684 : scanCanonicalize (H12AffineFastState.compose env37684 (packedSelected [1,4,5,7,11,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 53) := by decide +kernel

theorem selectedBound37684 : packedSelected [1,4,5,7,11,12,15] rootPS < 2^1333 := by decide +kernel

def env37685 : List Nat := [2,4,8,16,32,1,53,256,270,298,276,49,24,59,260,266,22,318,305,261,48,306,44,305,63,38,277,7,58,23,20,45,257,42,43,277]

theorem envBound37685 : H12AffineFastState.Bounded env37685 := by
  intro p hp
  have h : env37685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37684_37685 : H12AffineEnvironment.transform 6 53 env37684 = env37685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 53 env37684 == env37685) = true)

theorem identity37685 : scanCanonicalize (H12AffineFastState.compose env37685 (packedSelected [3,10,12] rootPS)) = affineNative (2^(7+1) ^^^ 19) := by decide +kernel

theorem selectedBound37685 : packedSelected [3,10,12] rootPS < 2^1333 := by decide +kernel

def env37686 : List Nat := [2,4,8,16,32,1,53,19,29,57,7,49,24,59,23,25,22,45,34,22,48,33,44,34,63,38,6,7,58,23,20,45,18,42,43,6]

theorem envBound37686 : H12AffineFastState.Bounded env37686 := by
  intro p hp
  have h : env37686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37685_37686 : H12AffineEnvironment.transform 7 19 env37685 = env37686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 19 env37685 == env37686) = true)

theorem identity37686 : scanCanonicalize (H12AffineFastState.compose env37686 (packedSelected [2,4,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound37686 : packedSelected [2,4,5,7] rootPS < 2^1333 := by decide +kernel

def env37687 : List Nat := [2,4,8,16,12,1,25,19,29,21,7,29,24,23,23,25,22,1,14,22,28,13,0,14,19,10,6,7,22,23,20,1,18,6,7,6]

theorem envBound37687 : H12AffineFastState.Bounded env37687 := by
  intro p hp
  have h : env37687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37686_37687 : H12AffineEnvironment.transform 4 12 env37686 = env37687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env37686 == env37687) = true)

theorem identity37687 : scanCanonicalize (H12AffineFastState.compose env37687 (packedSelected [0,2,3,4] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound37687 : packedSelected [0,2,3,4] rootPS < 2^1333 := by decide +kernel

def env37688 : List Nat := [2,4,8,10,12,1,3,9,7,15,7,7,2,13,13,3,12,1,14,12,6,13,0,14,9,10,6,7,12,13,14,1,8,6,7,6]

theorem envBound37688 : H12AffineFastState.Bounded env37688 := by
  intro p hp
  have h : env37688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37687_37688 : H12AffineEnvironment.transform 3 10 env37687 = env37688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env37687 == env37688) = true)

theorem identity37688 : scanCanonicalize (H12AffineFastState.compose env37688 (packedSelected [0,1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound37688 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env37689 : List Nat := [2,0,8,10,8,1,3,9,3,11,3,3,2,9,9,3,8,1,10,8,2,9,0,10,9,10,2,3,8,9,10,1,8,2,3,2]

theorem envBound37689 : H12AffineFastState.Bounded env37689 := by
  intro p hp
  have h : env37689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37688_37689 : H12AffineEnvironment.transform 1 0 env37688 = env37689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env37688 == env37689) = true)

theorem identity37689 : scanCanonicalize (H12AffineFastState.compose env37689 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound37689 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37690 : List Nat := [2,0,0,2,0,1,3,1,3,3,3,3,2,1,1,3,0,1,2,0,2,1,0,2,1,2,2,3,0,1,2,1,0,2,3,2]

theorem envBound37690 : H12AffineFastState.Bounded env37690 := by
  intro p hp
  have h : env37690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37689_37690 : H12AffineEnvironment.transform 2 0 env37689 = env37690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env37689 == env37690) = true)

theorem identity37690 : scanCanonicalize (H12AffineFastState.compose env37690 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound37690 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37691 : List Nat := [1,0,0,1,0,1,0,1,0,0,0,0,1,1,1,0,0,1,1,0,1,1,0,1,1,1,1,0,0,1,1,1,0,1,0,1]

theorem envBound37691 : H12AffineFastState.Bounded env37691 := by
  intro p hp
  have h : env37691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37690_37691 : H12AffineEnvironment.transform 0 1 env37690 = env37691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env37690 == env37691) = true)

def env37692 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,21585,32769,4097,61648,91183,123164,28888,78894,385203,90414,1297,96346,25885,82999,257,1280,1344,21073]

theorem envBound37692 : H12AffineFastState.Bounded env37692 := by
  intro p hp
  have h : env37692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37387_37692 : H12AffineEnvironment.transform 18 21585 env37387 = env37692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21585 env37387 == env37692) = true)

theorem identity37692 : scanCanonicalize (H12AffineFastState.compose env37692 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound37692 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env37693 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,13341,65536,74863,262144,21585,13340,4097,17613,91183,87297,28888,78894,349358,90414,1297,96346,25885,82999,257,1280,1344,21073]

theorem envBound37693 : H12AffineFastState.Bounded env37693 := by
  intro p hp
  have h : env37693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37692_37693 : H12AffineEnvironment.transform 14 13341 env37692 = env37693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env37692 == env37693) = true)

def env37694 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74863,262144,4417,13340,4097,477,74047,69649,13768,78894,332222,74814,1297,81226,8205,65831,257,1280,1344,5953]

theorem envBound37694 : H12AffineFastState.Bounded env37694 := by
  intro p hp
  have h : env37694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37693_37694 : H12AffineEnvironment.transform 13 1296 env37693 = env37694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env37693 == env37694) = true)

def env37695 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74863,65664,4417,13340,4097,477,74047,69649,13768,78894,4414,74814,1297,81226,8205,65831,257,1280,1344,5953]

theorem envBound37695 : H12AffineFastState.Bounded env37695 := by
  intro p hp
  have h : env37695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37694_37695 : H12AffineEnvironment.transform 17 65664 env37694 = env37695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env37694 == env37695) = true)

theorem identity37695 : scanCanonicalize (H12AffineFastState.compose env37695 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound37695 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env37696 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,8192,1,12556,65536,74110,65664,4417,12557,4097,477,74047,69649,12505,78143,4414,74031,0,79963,8205,65831,257,17,81,4688]

theorem envBound37696 : H12AffineFastState.Bounded env37696 := by
  intro p hp
  have h : env37696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37695_37696 : H12AffineEnvironment.transform 9 273 env37695 = env37696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env37695 == env37696) = true)

def env37697 : List Nat := [2,4,8,16,32,64,128,256,340,273,2048,4096,8192,1,12556,65536,74110,65664,4417,12557,4097,477,74047,69649,12505,78143,4414,74031,0,79963,8205,65831,257,17,81,4356]

theorem envBound37697 : H12AffineFastState.Bounded env37697 := by
  intro p hp
  have h : env37697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37696_37697 : H12AffineEnvironment.transform 8 340 env37696 = env37697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env37696 == env37697) = true)

def env37698 : List Nat := [2,4,8,16,32,64,128,256,340,273,2048,16,8192,1,8476,65536,74110,65664,337,8477,17,477,74047,65537,8393,74031,302,74031,0,75851,8205,65831,257,17,81,276]

theorem envBound37698 : H12AffineFastState.Bounded env37698 := by
  intro p hp
  have h : env37698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37697_37698 : H12AffineEnvironment.transform 11 16 env37697 = env37698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env37697 == env37698) = true)

theorem identity37698 : scanCanonicalize (H12AffineFastState.compose env37698 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 8618) := by decide +kernel

theorem selectedBound37698 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env37699 : List Nat := [2,4,8,16,32,64,128,256,340,273,2048,16,8192,1,8476,8618,212,8490,337,8477,17,477,149,8619,8393,133,302,133,0,2529,8205,8333,257,17,81,276]

theorem envBound37699 : H12AffineFastState.Bounded env37699 := by
  intro p hp
  have h : env37699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37698_37699 : H12AffineEnvironment.transform 15 8618 env37698 = env37699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8618 env37698 == env37699) = true)

def env37700 : List Nat := [2,4,8,16,32,64,128,256,340,273,2048,16,156,1,384,310,212,438,337,385,17,477,149,311,85,133,302,133,0,2529,145,17,257,17,81,276]

theorem envBound37700 : H12AffineFastState.Bounded env37700 := by
  intro p hp
  have h : env37700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37699_37700 : H12AffineEnvironment.transform 12 156 env37699 = env37700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 156 env37699 == env37700) = true)

theorem identity37700 : scanCanonicalize (H12AffineFastState.compose env37700 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound37700 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env37701 : List Nat := [2,4,8,0,32,64,128,256,324,257,2048,0,140,1,384,294,196,422,321,385,1,461,133,295,69,133,302,133,0,2529,129,1,257,1,65,260]

theorem envBound37701 : H12AffineFastState.Bounded env37701 := by
  intro p hp
  have h : env37701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37700_37701 : H12AffineEnvironment.transform 3 0 env37700 = env37701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env37700 == env37701) = true)

theorem identity37701 : scanCanonicalize (H12AffineFastState.compose env37701 (packedSelected [1,2,3,4,8,9,10,11,12,15,16,18,21] rootPS)) = affineNative (2^(10+1) ^^^ 270) := by decide +kernel

theorem selectedBound37701 : packedSelected [1,2,3,4,8,9,10,11,12,15,16,18,21] rootPS < 2^1333 := by decide +kernel

def env37702 : List Nat := [2,4,8,0,32,64,128,256,324,257,270,0,140,1,384,294,196,422,321,385,1,461,133,295,69,133,302,133,0,239,129,1,257,1,65,260]

theorem envBound37702 : H12AffineFastState.Bounded env37702 := by
  intro p hp
  have h : env37702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37701_37702 : H12AffineEnvironment.transform 10 270 env37701 = env37702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 270 env37701 == env37702) = true)

theorem identity37702 : scanCanonicalize (H12AffineFastState.compose env37702 (packedSelected [4,5,9,13,15,16] rootPS)) = affineNative (2^(6+1) ^^^ 79) := by decide +kernel

theorem selectedBound37702 : packedSelected [4,5,9,13,15,16] rootPS < 2^1333 := by decide +kernel

def env37703 : List Nat := [2,4,8,0,32,64,79,256,324,257,270,0,67,1,335,294,11,361,321,334,1,258,74,295,69,74,302,74,0,32,78,1,257,1,65,260]

theorem envBound37703 : H12AffineFastState.Bounded env37703 := by
  intro p hp
  have h : env37703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37702_37703 : H12AffineEnvironment.transform 6 79 env37702 = env37703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 79 env37702 == env37703) = true)

theorem identity37703 : scanCanonicalize (H12AffineFastState.compose env37703 (packedSelected [0,2,4,5,7,8,9,11] rootPS)) = affineNative (2^(7+1) ^^^ 111) := by decide +kernel

theorem selectedBound37703 : packedSelected [0,2,4,5,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env37704 : List Nat := [2,4,8,0,32,64,79,111,43,110,97,0,67,1,32,73,11,6,46,33,1,109,74,72,69,74,65,74,0,32,78,1,110,1,65,107]

theorem envBound37704 : H12AffineFastState.Bounded env37704 := by
  intro p hp
  have h : env37704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37703_37704 : H12AffineEnvironment.transform 7 111 env37703 = env37704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 111 env37703 == env37704) = true)

theorem identity37704 : scanCanonicalize (H12AffineFastState.compose env37704 (packedSelected [3,8] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound37704 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env37705 : List Nat := [2,4,8,0,32,33,46,14,43,15,0,0,34,1,32,40,11,6,46,33,1,12,43,41,36,43,32,43,0,32,47,1,15,1,32,10]

theorem envBound37705 : H12AffineFastState.Bounded env37705 := by
  intro p hp
  have h : env37705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37704_37705 : H12AffineEnvironment.transform 5 33 env37704 = env37705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env37704 == env37705) = true)

theorem identity37705 : scanCanonicalize (H12AffineFastState.compose env37705 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound37705 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37706 : List Nat := [2,4,8,0,10,11,4,14,1,15,0,0,8,1,10,2,11,6,4,11,1,12,1,3,14,1,10,1,0,10,5,1,15,1,10,10]

theorem envBound37706 : H12AffineFastState.Bounded env37706 := by
  intro p hp
  have h : env37706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37705_37706 : H12AffineEnvironment.transform 4 10 env37705 = env37706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env37705 == env37706) = true)

theorem identity37706 : scanCanonicalize (H12AffineFastState.compose env37706 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound37706 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37707 : List Nat := [2,3,8,0,10,11,3,9,1,8,0,0,8,1,10,2,11,1,3,11,1,11,1,3,9,1,10,1,0,10,2,1,8,1,10,10]

theorem envBound37707 : H12AffineFastState.Bounded env37707 := by
  intro p hp
  have h : env37707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37706_37707 : H12AffineEnvironment.transform 1 3 env37706 = env37707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env37706 == env37707) = true)

theorem identity37707 : scanCanonicalize (H12AffineFastState.compose env37707 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound37707 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env37708 : List Nat := [2,3,2,0,0,1,3,3,1,2,0,0,2,1,0,2,1,1,3,1,1,1,1,3,3,1,0,1,0,0,2,1,2,1,0,0]

theorem envBound37708 : H12AffineFastState.Bounded env37708 := by
  intro p hp
  have h : env37708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37707_37708 : H12AffineEnvironment.transform 2 2 env37707 = env37708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env37707 == env37708) = true)

theorem identity37708 : scanCanonicalize (H12AffineFastState.compose env37708 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound37708 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37709 : List Nat := [0,1,0,0,0,1,1,1,1,0,0,0,0,1,0,0,1,1,1,1,1,1,1,1,1,1,0,1,0,0,0,1,0,1,0,0]

theorem envBound37709 : H12AffineFastState.Bounded env37709 := by
  intro p hp
  have h : env37709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37708_37709 : H12AffineEnvironment.transform 0 0 env37708 = env37709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env37708 == env37709) = true)

def env37710 : List Nat := [2,4,8,16,32,64,128,256,340,273,2048,16,157,1,385,311,212,439,337,384,17,477,149,310,84,133,302,133,0,2529,144,16,257,17,81,276]

theorem envBound37710 : H12AffineFastState.Bounded env37710 := by
  intro p hp
  have h : env37710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37699_37710 : H12AffineEnvironment.transform 12 157 env37699 = env37710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 157 env37699 == env37710) = true)

theorem identity37710 : scanCanonicalize (H12AffineFastState.compose env37710 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 145) := by decide +kernel

theorem selectedBound37710 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env37711 : List Nat := [2,4,8,16,32,64,128,145,197,128,2048,16,157,1,16,166,212,38,192,17,17,76,149,167,84,133,191,133,0,2160,144,16,144,17,81,133]

theorem envBound37711 : H12AffineFastState.Bounded env37711 := by
  intro p hp
  have h : env37711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37710_37711 : H12AffineEnvironment.transform 7 145 env37710 = env37711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 145 env37710 == env37711) = true)

theorem identity37711 : scanCanonicalize (H12AffineFastState.compose env37711 (packedSelected [1,3,13,15,17,19] rootPS)) = affineNative (2^(6+1) ^^^ 117) := by decide +kernel

theorem selectedBound37711 : packedSelected [1,3,13,15,17,19] rootPS < 2^1333 := by decide +kernel

def env37712 : List Nat := [2,4,8,16,32,64,117,100,48,117,2048,16,104,1,16,83,33,38,53,17,17,76,96,82,84,112,74,112,0,2160,101,16,101,17,81,112]

theorem envBound37712 : H12AffineFastState.Bounded env37712 := by
  intro p hp
  have h : env37712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37711_37712 : H12AffineEnvironment.transform 6 117 env37711 = env37712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 117 env37711 == env37712) = true)

theorem identity37712 : scanCanonicalize (H12AffineFastState.compose env37712 (packedSelected [0,4,5,7,8,9,10,11,12,13,15,16,17] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound37712 : packedSelected [0,4,5,7,8,9,10,11,12,13,15,16,17] rootPS < 2^1333 := by decide +kernel

def env37713 : List Nat := [2,4,8,7,32,64,98,100,39,98,2048,7,104,1,7,68,33,38,34,6,6,76,96,69,67,103,74,103,0,2151,101,7,101,6,70,103]

theorem envBound37713 : H12AffineFastState.Bounded env37713 := by
  intro p hp
  have h : env37713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37712_37713 : H12AffineEnvironment.transform 3 7 env37712 = env37713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env37712 == env37713) = true)

theorem identity37713 : scanCanonicalize (H12AffineFastState.compose env37713 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 43) := by decide +kernel

theorem selectedBound37713 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env37714 : List Nat := [2,4,8,7,32,43,9,15,39,9,2048,7,3,1,7,47,33,38,34,6,6,39,11,46,40,12,33,12,0,2060,14,7,14,6,45,12]

theorem envBound37714 : H12AffineFastState.Bounded env37714 := by
  intro p hp
  have h : env37714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37713_37714 : H12AffineEnvironment.transform 5 43 env37713 = env37714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 43 env37713 == env37714) = true)

theorem identity37714 : scanCanonicalize (H12AffineFastState.compose env37714 (packedSelected [0,2,3,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 12) := by decide +kernel

theorem selectedBound37714 : packedSelected [0,2,3,7,8] rootPS < 2^1333 := by decide +kernel

def env37715 : List Nat := [2,4,8,7,32,43,9,15,39,9,12,7,3,1,7,47,33,38,34,6,6,39,11,46,40,12,33,12,0,0,14,7,14,6,45,12]

theorem envBound37715 : H12AffineFastState.Bounded env37715 := by
  intro p hp
  have h : env37715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37714_37715 : H12AffineEnvironment.transform 10 12 env37714 = env37715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 12 env37714 == env37715) = true)

theorem identity37715 : scanCanonicalize (H12AffineFastState.compose env37715 (packedSelected [1,3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound37715 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env37716 : List Nat := [2,3,8,0,32,43,9,8,32,9,11,0,3,1,0,40,33,33,34,1,1,32,11,41,40,11,33,11,0,0,9,0,9,1,42,11]

theorem envBound37716 : H12AffineFastState.Bounded env37716 := by
  intro p hp
  have h : env37716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37715_37716 : H12AffineEnvironment.transform 1 3 env37715 = env37716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env37715 == env37716) = true)

theorem identity37716 : scanCanonicalize (H12AffineFastState.compose env37716 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound37716 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env37717 : List Nat := [2,3,8,0,11,0,9,8,11,9,11,0,3,1,0,3,10,10,9,1,1,11,11,2,3,11,10,11,0,0,9,0,9,1,1,11]

theorem envBound37717 : H12AffineFastState.Bounded env37717 := by
  intro p hp
  have h : env37717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37716_37717 : H12AffineEnvironment.transform 4 11 env37716 = env37717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env37716 == env37717) = true)

def env37718 : List Nat := [2,4,8,16,32,64,128,256,340,273,2048,17,8192,1,8477,65536,74110,65664,336,8476,16,477,74047,65536,8392,74030,303,74031,0,75850,8205,65831,257,17,81,277]

theorem envBound37718 : H12AffineFastState.Bounded env37718 := by
  intro p hp
  have h : env37718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37697_37718 : H12AffineEnvironment.transform 11 17 env37697 = env37718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env37697 == env37718) = true)

theorem identity37718 : scanCanonicalize (H12AffineFastState.compose env37718 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 435) := by decide +kernel

theorem selectedBound37718 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env37719 : List Nat := [2,4,8,16,32,64,128,256,340,273,2048,17,8192,1,8477,435,8397,307,336,8476,16,477,8332,435,8392,8349,303,8348,0,10745,8205,148,257,17,81,277]

theorem envBound37719 : H12AffineFastState.Bounded env37719 := by
  intro p hp
  have h : env37719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37718_37719 : H12AffineEnvironment.transform 15 435 env37718 = env37719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 435 env37718 == env37719) = true)

def env37720 : List Nat := [2,4,8,16,32,0,128,256,276,273,2048,17,8192,1,8477,435,8333,307,272,8476,16,413,8332,435,8328,8349,303,8348,0,10681,8205,148,257,17,17,277]

theorem envBound37720 : H12AffineFastState.Bounded env37720 := by
  intro p hp
  have h : env37720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37719_37720 : H12AffineEnvironment.transform 5 0 env37719 = env37720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env37719 == env37720) = true)

theorem identity37720 : scanCanonicalize (H12AffineFastState.compose env37720 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound37720 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env37721 : List Nat := [2,4,8,16,32,0,128,20,0,5,2048,17,8192,1,8201,167,8333,39,4,8200,16,137,8332,167,8328,8349,59,8348,0,10413,8205,148,21,17,17,1]

theorem envBound37721 : H12AffineFastState.Bounded env37721 := by
  intro p hp
  have h : env37721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37720_37721 : H12AffineEnvironment.transform 7 20 env37720 = env37721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env37720 == env37721) = true)

theorem identity37721 : scanCanonicalize (H12AffineFastState.compose env37721 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(6+1) ^^^ 20) := by decide +kernel

theorem selectedBound37721 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env37722 : List Nat := [2,4,8,16,32,0,20,20,0,5,2048,17,8192,1,8201,51,8217,39,4,8200,16,29,8216,51,8220,8201,59,8200,0,10297,8205,0,21,17,17,1]

theorem envBound37722 : H12AffineFastState.Bounded env37722 := by
  intro p hp
  have h : env37722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37721_37722 : H12AffineEnvironment.transform 6 20 env37721 = env37722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 20 env37721 == env37722) = true)

theorem identity37722 : scanCanonicalize (H12AffineFastState.compose env37722 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound37722 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env37723 : List Nat := [2,4,8,16,32,0,20,20,0,5,2048,17,24,1,17,51,1,39,4,16,16,29,0,51,4,17,59,16,0,2081,21,0,21,17,17,1]

theorem envBound37723 : H12AffineFastState.Bounded env37723 := by
  intro p hp
  have h : env37723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37722_37723 : H12AffineEnvironment.transform 12 24 env37722 = env37723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env37722 == env37723) = true)

theorem identity37723 : scanCanonicalize (H12AffineFastState.compose env37723 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound37723 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37724 : List Nat := [2,4,8,16,27,0,20,20,0,5,2048,17,24,1,17,8,1,28,4,16,16,29,0,8,4,17,0,16,0,2074,21,0,21,17,17,1]

theorem envBound37724 : H12AffineFastState.Bounded env37724 := by
  intro p hp
  have h : env37724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37723_37724 : H12AffineEnvironment.transform 4 27 env37723 = env37724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env37723 == env37724) = true)

theorem identity37724 : scanCanonicalize (H12AffineFastState.compose env37724 (packedSelected [3,5] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound37724 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env37725 : List Nat := [2,4,8,16,27,0,20,20,0,5,17,17,24,1,17,8,1,28,4,16,16,29,0,8,4,17,0,16,0,11,21,0,21,17,17,1]

theorem envBound37725 : H12AffineFastState.Bounded env37725 := by
  intro p hp
  have h : env37725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37724_37725 : H12AffineEnvironment.transform 10 17 env37724 = env37725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env37724 == env37725) = true)

theorem identity37725 : scanCanonicalize (H12AffineFastState.compose env37725 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound37725 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env37726 : List Nat := [2,4,8,1,10,0,5,5,0,5,0,0,9,1,0,8,1,13,4,1,1,12,0,8,4,0,0,1,0,11,4,0,4,0,0,1]

theorem envBound37726 : H12AffineFastState.Bounded env37726 := by
  intro p hp
  have h : env37726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37725_37726 : H12AffineEnvironment.transform 3 1 env37725 = env37726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env37725 == env37726) = true)

theorem identity37726 : scanCanonicalize (H12AffineFastState.compose env37726 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound37726 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37727 : List Nat := [2,0,8,1,10,0,1,1,0,1,0,0,9,1,0,8,1,9,0,1,1,8,0,8,0,0,0,1,0,11,0,0,0,0,0,1]

theorem envBound37727 : H12AffineFastState.Bounded env37727 := by
  intro p hp
  have h : env37727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37726_37727 : H12AffineEnvironment.transform 1 0 env37726 = env37727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env37726 == env37727) = true)

theorem identity37727 : scanCanonicalize (H12AffineFastState.compose env37727 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound37727 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37728 : List Nat := [2,0,1,1,3,0,1,1,0,1,0,0,0,1,0,1,1,0,0,1,1,1,0,1,0,0,0,1,0,2,0,0,0,0,0,1]

theorem envBound37728 : H12AffineFastState.Bounded env37728 := by
  intro p hp
  have h : env37728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37727_37728 : H12AffineEnvironment.transform 2 1 env37727 = env37728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env37727 == env37728) = true)

def env37729 : List Nat := [2,4,8,16,32,1,128,256,277,273,2048,17,8192,1,8477,435,8332,307,273,8476,16,412,8332,435,8329,8349,303,8348,0,10680,8205,148,257,17,16,277]

theorem envBound37729 : H12AffineFastState.Bounded env37729 := by
  intro p hp
  have h : env37729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37719_37729 : H12AffineEnvironment.transform 5 1 env37719 = env37729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env37719 == env37729) = true)

theorem identity37729 : scanCanonicalize (H12AffineFastState.compose env37729 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 409) := by decide +kernel

theorem selectedBound37729 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env37730 : List Nat := [2,4,8,16,32,1,128,256,277,273,2048,17,409,1,132,435,277,307,273,133,16,412,277,435,272,260,303,261,0,2081,404,148,257,17,16,277]

theorem envBound37730 : H12AffineFastState.Bounded env37730 := by
  intro p hp
  have h : env37730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37729_37730 : H12AffineEnvironment.transform 12 409 env37729 = env37730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 409 env37729 == env37730) = true)

theorem identity37730 : scanCanonicalize (H12AffineFastState.compose env37730 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound37730 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env37731 : List Nat := [2,4,8,1,32,1,128,256,260,256,2048,0,392,1,132,418,260,290,256,133,1,397,260,418,257,260,303,261,0,2081,389,133,257,0,1,260]

theorem envBound37731 : H12AffineFastState.Bounded env37731 := by
  intro p hp
  have h : env37731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37730_37731 : H12AffineEnvironment.transform 3 1 env37730 = env37731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env37730 == env37731) = true)

theorem identity37731 : scanCanonicalize (H12AffineFastState.compose env37731 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 132) := by decide +kernel

theorem selectedBound37731 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env37732 : List Nat := [2,4,8,1,32,1,128,256,260,256,132,0,392,1,132,418,260,290,256,133,1,397,260,418,257,260,303,261,0,165,389,133,257,0,1,260]

theorem envBound37732 : H12AffineFastState.Bounded env37732 := by
  intro p hp
  have h : env37732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37731_37732 : H12AffineEnvironment.transform 10 132 env37731 = env37732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 132 env37731 == env37732) = true)

theorem identity37732 : scanCanonicalize (H12AffineFastState.compose env37732 (packedSelected [3] rootPS)) = affineNative (2^(7+1) ^^^ 34) := by decide +kernel

theorem selectedBound37732 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env37733 : List Nat := [2,4,8,1,32,1,128,34,38,34,132,0,170,1,132,128,38,0,34,133,1,175,38,128,35,38,13,39,0,165,167,133,35,0,1,38]

theorem envBound37733 : H12AffineFastState.Bounded env37733 := by
  intro p hp
  have h : env37733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37732_37733 : H12AffineEnvironment.transform 7 34 env37732 = env37733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 34 env37732 == env37733) = true)

theorem identity37733 : scanCanonicalize (H12AffineFastState.compose env37733 (packedSelected [0,1,7] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound37733 : packedSelected [0,1,7] rootPS < 2^1333 := by decide +kernel

def env37734 : List Nat := [2,3,8,1,32,1,128,34,33,34,131,0,170,1,131,128,33,0,34,130,1,168,33,128,35,33,10,32,0,162,160,130,35,0,1,33]

theorem envBound37734 : H12AffineFastState.Bounded env37734 := by
  intro p hp
  have h : env37734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37733_37734 : H12AffineEnvironment.transform 1 3 env37733 = env37734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env37733 == env37734) = true)

theorem identity37734 : scanCanonicalize (H12AffineFastState.compose env37734 (packedSelected [1,2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound37734 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env37735 : List Nat := [2,3,8,1,32,1,8,34,33,34,11,0,34,1,11,8,33,0,34,10,1,32,33,8,35,33,10,32,0,42,40,10,35,0,1,33]

theorem envBound37735 : H12AffineFastState.Bounded env37735 := by
  intro p hp
  have h : env37735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37734_37735 : H12AffineEnvironment.transform 6 8 env37734 = env37735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env37734 == env37735) = true)

def env37736 : List Nat := [2,4,8,16,32,64,128,256,341,273,2048,4096,8192,1,12556,65536,74110,65664,4417,12557,4097,477,74047,69649,12505,78143,4414,74031,0,79963,8205,65831,257,17,81,4357]

theorem envBound37736 : H12AffineFastState.Bounded env37736 := by
  intro p hp
  have h : env37736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37696_37736 : H12AffineEnvironment.transform 8 341 env37696 = env37736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env37696 == env37736) = true)

def env37737 : List Nat := [2,4,8,16,32,64,128,256,341,273,2048,16,8192,1,8476,65536,74110,65664,337,8477,17,477,74047,65537,8393,74031,302,74031,0,75851,8205,65831,257,17,81,277]

theorem envBound37737 : H12AffineFastState.Bounded env37737 := by
  intro p hp
  have h : env37737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37736_37737 : H12AffineEnvironment.transform 11 16 env37736 = env37737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env37736 == env37737) = true)

theorem identity37737 : scanCanonicalize (H12AffineFastState.compose env37737 (packedSelected [1,8,28] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound37737 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env37738 : List Nat := [2,4,8,16,32,64,4,256,341,273,2048,16,8192,1,8476,65536,74110,65540,337,8477,17,345,74047,65537,8269,74031,302,74031,0,75851,8205,65831,257,17,81,277]

theorem envBound37738 : H12AffineFastState.Bounded env37738 := by
  intro p hp
  have h : env37738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37737_37738 : H12AffineEnvironment.transform 6 4 env37737 = env37738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env37737 == env37738) = true)

def env37739 : List Nat := [2,4,8,16,32,64,4,256,341,273,2048,16,8192,1,8476,304,8270,308,337,8477,17,345,8207,305,8269,8223,302,8223,0,10619,8205,23,257,17,81,277]

theorem envBound37739 : H12AffineFastState.Bounded env37739 := by
  intro p hp
  have h : env37739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37738_37739 : H12AffineEnvironment.transform 15 304 env37738 = env37739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 304 env37738 == env37739) = true)

theorem identity37739 : scanCanonicalize (H12AffineFastState.compose env37739 (packedSelected [1,2,3,12,19,23,32,38,41] rootPS)) = affineNative (2^(12+1) ^^^ 310) := by decide +kernel

theorem selectedBound37739 : packedSelected [1,2,3,12,19,23,32,38,41] rootPS < 2^1333 := by decide +kernel

def env37740 : List Nat := [2,4,8,16,32,64,4,256,341,273,2048,16,310,1,42,304,376,308,337,43,17,345,313,305,379,297,302,297,0,2125,315,23,257,17,81,277]

theorem envBound37740 : H12AffineFastState.Bounded env37740 := by
  intro p hp
  have h : env37740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37739_37740 : H12AffineEnvironment.transform 12 310 env37739 = env37740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 310 env37739 == env37740) = true)

theorem identity37740 : scanCanonicalize (H12AffineFastState.compose env37740 (packedSelected [1,7,9,10,11,12,18] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound37740 : packedSelected [1,7,9,10,11,12,18] rootPS < 2^1333 := by decide +kernel

def env37741 : List Nat := [2,4,8,16,32,1,4,256,276,273,2048,16,310,1,42,304,313,308,272,43,17,280,313,305,314,297,302,297,0,2060,315,23,257,17,16,277]

theorem envBound37741 : H12AffineFastState.Bounded env37741 := by
  intro p hp
  have h : env37741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37740_37741 : H12AffineEnvironment.transform 5 1 env37740 = env37741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env37740 == env37741) = true)

theorem identity37741 : scanCanonicalize (H12AffineFastState.compose env37741 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound37741 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env37742 : List Nat := [2,4,8,16,32,1,4,20,0,5,2048,16,34,1,42,36,45,32,4,43,17,12,45,37,46,61,58,61,0,2060,47,23,21,17,16,1]

theorem envBound37742 : H12AffineFastState.Bounded env37742 := by
  intro p hp
  have h : env37742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37741_37742 : H12AffineEnvironment.transform 7 20 env37741 = env37742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env37741 == env37742) = true)

theorem identity37742 : scanCanonicalize (H12AffineFastState.compose env37742 (packedSelected [7,8] rootPS)) = affineNative (2^(10+1) ^^^ 63) := by decide +kernel

theorem selectedBound37742 : packedSelected [7,8] rootPS < 2^1333 := by decide +kernel

def env37743 : List Nat := [2,4,8,16,32,1,4,20,0,5,63,16,34,1,42,36,45,32,4,43,17,12,45,37,46,61,58,61,0,51,47,23,21,17,16,1]

theorem envBound37743 : H12AffineFastState.Bounded env37743 := by
  intro p hp
  have h : env37743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37742_37743 : H12AffineEnvironment.transform 10 63 env37742 = env37743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 63 env37742 == env37743) = true)

theorem identity37743 : scanCanonicalize (H12AffineFastState.compose env37743 (packedSelected [2,3,5,7,10] rootPS)) = affineNative (2^(4+1) ^^^ 4) := by decide +kernel

theorem selectedBound37743 : packedSelected [2,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env37744 : List Nat := [2,4,8,16,4,1,4,20,0,5,27,16,6,1,14,0,9,4,4,15,17,12,9,1,10,25,30,25,0,23,11,23,21,17,16,1]

theorem envBound37744 : H12AffineFastState.Bounded env37744 := by
  intro p hp
  have h : env37744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37743_37744 : H12AffineEnvironment.transform 4 4 env37743 = env37744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 4 env37743 == env37744) = true)

theorem identity37744 : scanCanonicalize (H12AffineFastState.compose env37744 (packedSelected [0,3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound37744 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env37745 : List Nat := [2,4,8,0,4,1,4,4,0,5,11,0,6,1,14,0,9,4,4,15,1,12,9,1,10,9,14,9,0,7,11,7,5,1,0,1]

theorem envBound37745 : H12AffineFastState.Bounded env37745 := by
  intro p hp
  have h : env37745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37744_37745 : H12AffineEnvironment.transform 3 0 env37744 = env37745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env37744 == env37745) = true)

theorem identity37745 : scanCanonicalize (H12AffineFastState.compose env37745 (packedSelected [1,2,4] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound37745 : packedSelected [1,2,4] rootPS < 2^1333 := by decide +kernel

def env37746 : List Nat := [2,4,7,0,4,1,4,4,0,5,4,0,6,1,1,0,6,4,4,0,1,3,6,1,5,6,1,6,0,7,4,7,5,1,0,1]

theorem envBound37746 : H12AffineFastState.Bounded env37746 := by
  intro p hp
  have h : env37746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37745_37746 : H12AffineEnvironment.transform 2 7 env37745 = env37746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env37745 == env37746) = true)

theorem identity37746 : scanCanonicalize (H12AffineFastState.compose env37746 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound37746 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37747 : List Nat := [1,4,4,0,4,1,4,4,0,5,4,0,5,1,1,0,5,4,4,0,1,0,5,1,5,5,1,5,0,4,4,4,5,1,0,1]

theorem envBound37747 : H12AffineFastState.Bounded env37747 := by
  intro p hp
  have h : env37747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37746_37747 : H12AffineEnvironment.transform 0 1 env37746 = env37747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env37746 == env37747) = true)

theorem identity37747 : scanCanonicalize (H12AffineFastState.compose env37747 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound37747 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37748 : List Nat := [1,0,0,0,0,1,0,0,0,1,0,0,1,1,1,0,1,0,0,0,1,0,1,1,1,1,1,1,0,0,0,0,1,1,0,1]

theorem envBound37748 : H12AffineFastState.Bounded env37748 := by
  intro p hp
  have h : env37748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37747_37748 : H12AffineEnvironment.transform 1 0 env37747 = env37748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env37747 == env37748) = true)

def env37749 : List Nat := [2,4,8,16,32,64,4,256,341,273,2048,16,8192,1,8476,305,8271,309,337,8477,17,345,8206,304,8269,8222,302,8222,0,10618,8205,22,257,17,81,277]

theorem envBound37749 : H12AffineFastState.Bounded env37749 := by
  intro p hp
  have h : env37749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37738_37749 : H12AffineEnvironment.transform 15 305 env37738 = env37749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 305 env37738 == env37749) = true)

theorem identity37749 : scanCanonicalize (H12AffineFastState.compose env37749 (packedSelected [1,2,3,12,19,23,32,38,41] rootPS)) = affineNative (2^(12+1) ^^^ 305) := by decide +kernel

theorem selectedBound37749 : packedSelected [1,2,3,12,19,23,32,38,41] rootPS < 2^1333 := by decide +kernel

def env37750 : List Nat := [2,4,8,16,32,64,4,256,341,273,2048,16,305,1,45,305,382,309,337,44,17,345,319,304,380,303,302,303,0,2123,316,22,257,17,81,277]

theorem envBound37750 : H12AffineFastState.Bounded env37750 := by
  intro p hp
  have h : env37750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37749_37750 : H12AffineEnvironment.transform 12 305 env37749 = env37750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 305 env37749 == env37750) = true)

theorem identity37750 : scanCanonicalize (H12AffineFastState.compose env37750 (packedSelected [2,4,5,9,18,19,20,23] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound37750 : packedSelected [2,4,5,9,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env37751 : List Nat := [2,4,8,11,32,64,4,256,334,266,2048,11,298,1,45,298,357,302,330,44,10,322,292,299,359,303,302,303,0,2123,295,13,257,10,74,270]

theorem envBound37751 : H12AffineFastState.Bounded env37751 := by
  intro p hp
  have h : env37751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37750_37751 : H12AffineEnvironment.transform 3 11 env37750 = env37751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env37750 == env37751) = true)

theorem identity37751 : scanCanonicalize (H12AffineFastState.compose env37751 (packedSelected [2,3,4,7,16] rootPS)) = affineNative (2^(10+1) ^^^ 324) := by decide +kernel

theorem selectedBound37751 : packedSelected [2,3,4,7,16] rootPS < 2^1333 := by decide +kernel

def env37752 : List Nat := [2,4,8,11,32,64,4,256,334,266,324,11,298,1,45,298,357,302,330,44,10,322,292,299,359,303,302,303,0,271,295,13,257,10,74,270]

theorem envBound37752 : H12AffineFastState.Bounded env37752 := by
  intro p hp
  have h : env37752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37751_37752 : H12AffineEnvironment.transform 10 324 env37751 = env37752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 324 env37751 == env37752) = true)

theorem identity37752 : scanCanonicalize (H12AffineFastState.compose env37752 (packedSelected [3,4,5,7,8,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound37752 : packedSelected [3,4,5,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env37753 : List Nat := [2,4,8,11,32,64,4,15,65,5,75,11,37,1,45,37,106,33,69,44,10,77,43,36,104,32,33,32,0,0,40,13,14,10,74,1]

theorem envBound37753 : H12AffineFastState.Bounded env37753 := by
  intro p hp
  have h : env37753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37752_37753 : H12AffineEnvironment.transform 7 15 env37752 = env37753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env37752 == env37753) = true)

theorem identity37753 : scanCanonicalize (H12AffineFastState.compose env37753 (packedSelected [0,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound37753 : packedSelected [0,4,5] rootPS < 2^1333 := by decide +kernel

def env37754 : List Nat := [2,4,8,11,32,11,4,15,10,5,0,11,37,1,45,37,33,33,14,44,10,6,43,36,35,32,33,32,0,0,40,13,14,10,1,1]

theorem envBound37754 : H12AffineFastState.Bounded env37754 := by
  intro p hp
  have h : env37754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37753_37754 : H12AffineEnvironment.transform 5 11 env37753 = env37754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env37753 == env37754) = true)

theorem identity37754 : scanCanonicalize (H12AffineFastState.compose env37754 (packedSelected [0,2,4] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound37754 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env37755 : List Nat := [2,2,8,11,32,11,2,9,10,3,0,11,35,1,43,35,33,33,8,42,10,0,43,34,35,32,33,32,0,0,40,11,8,10,1,1]

theorem envBound37755 : H12AffineFastState.Bounded env37755 := by
  intro p hp
  have h : env37755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37754_37755 : H12AffineEnvironment.transform 1 2 env37754 = env37755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env37754 == env37755) = true)

theorem identity37755 : scanCanonicalize (H12AffineFastState.compose env37755 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound37755 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37756 : List Nat := [2,2,8,11,10,11,2,9,10,3,0,11,9,1,1,9,11,11,8,0,10,0,1,8,9,10,11,10,0,0,2,11,8,10,1,1]

theorem envBound37756 : H12AffineFastState.Bounded env37756 := by
  intro p hp
  have h : env37756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37755_37756 : H12AffineEnvironment.transform 4 10 env37755 = env37756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env37755 == env37756) = true)

def env37757 : List Nat := [2,4,8,16,32,64,128,256,341,273,2048,17,8192,1,8477,65536,74110,65664,336,8476,16,477,74047,65536,8392,74030,303,74031,0,75850,8205,65831,257,17,81,276]

theorem envBound37757 : H12AffineFastState.Bounded env37757 := by
  intro p hp
  have h : env37757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37736_37757 : H12AffineEnvironment.transform 11 17 env37736 = env37757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env37736 == env37757) = true)

theorem identity37757 : scanCanonicalize (H12AffineFastState.compose env37757 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 157) := by decide +kernel

theorem selectedBound37757 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env37758 : List Nat := [2,4,8,16,32,64,128,256,341,273,2048,17,157,1,384,65536,66019,65664,336,385,16,477,65954,65536,85,65971,303,65970,0,67799,144,65831,257,17,81,276]

theorem envBound37758 : H12AffineFastState.Bounded env37758 := by
  intro p hp
  have h : env37758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37757_37758 : H12AffineEnvironment.transform 12 157 env37757 = env37758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 157 env37757 == env37758) = true)

def env37759 : List Nat := [2,4,8,16,32,64,128,256,341,273,2048,17,157,1,384,304,211,432,336,385,16,477,146,304,85,131,303,130,0,2535,144,23,257,17,81,276]

theorem envBound37759 : H12AffineFastState.Bounded env37759 := by
  intro p hp
  have h : env37759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37758_37759 : H12AffineEnvironment.transform 15 304 env37758 = env37759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 304 env37758 == env37759) = true)

theorem identity37759 : scanCanonicalize (H12AffineFastState.compose env37759 (packedSelected [1,2,3,7,15,17,19,20,21,23,27,32] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound37759 : packedSelected [1,2,3,7,15,17,19,20,21,23,27,32] rootPS < 2^1333 := by decide +kernel

def env37760 : List Nat := [2,4,8,16,32,64,40,256,341,273,2048,17,53,1,296,304,123,280,336,297,16,373,58,304,85,43,303,42,0,2383,56,23,257,17,81,276]

theorem envBound37760 : H12AffineFastState.Bounded env37760 := by
  intro p hp
  have h : env37760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37759_37760 : H12AffineEnvironment.transform 6 40 env37759 = env37760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env37759 == env37760) = true)

theorem identity37760 : scanCanonicalize (H12AffineFastState.compose env37760 (packedSelected [2,3,5,7,8,10,12,13,15,16,18,20,24,27] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound37760 : packedSelected [2,3,5,7,8,10,12,13,15,16,18,20,24,27] rootPS < 2^1333 := by decide +kernel

def env37761 : List Nat := [2,4,8,16,32,64,40,256,341,273,33,17,53,1,296,304,123,280,336,297,16,373,58,304,85,43,303,42,0,366,56,23,257,17,81,276]

theorem envBound37761 : H12AffineFastState.Bounded env37761 := by
  intro p hp
  have h : env37761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37760_37761 : H12AffineEnvironment.transform 10 33 env37760 = env37761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env37760 == env37761) = true)

theorem identity37761 : scanCanonicalize (H12AffineFastState.compose env37761 (packedSelected [1,3,8,10,12,15] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound37761 : packedSelected [1,3,8,10,12,15] rootPS < 2^1333 := by decide +kernel

def env37762 : List Nat := [2,4,8,16,27,64,19,256,341,273,26,17,14,1,275,267,64,280,336,274,16,334,1,267,85,16,276,17,0,341,3,23,257,17,81,276]

theorem envBound37762 : H12AffineFastState.Bounded env37762 := by
  intro p hp
  have h : env37762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37761_37762 : H12AffineEnvironment.transform 4 27 env37761 = env37762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env37761 == env37762) = true)

theorem identity37762 : scanCanonicalize (H12AffineFastState.compose env37762 (packedSelected [2,7,9,10,12] rootPS)) = affineNative (2^(7+1) ^^^ 72) := by decide +kernel

theorem selectedBound37762 : packedSelected [2,7,9,10,12] rootPS < 2^1333 := by decide +kernel

def env37763 : List Nat := [2,4,8,16,27,64,19,72,29,89,26,17,14,1,91,67,64,80,24,90,16,6,1,67,85,16,92,17,0,29,3,23,73,17,81,92]

theorem envBound37763 : H12AffineFastState.Bounded env37763 := by
  intro p hp
  have h : env37763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37762_37763 : H12AffineEnvironment.transform 7 72 env37762 = env37763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 72 env37762 == env37763) = true)

theorem identity37763 : scanCanonicalize (H12AffineFastState.compose env37763 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 29) := by decide +kernel

theorem selectedBound37763 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env37764 : List Nat := [2,4,8,16,27,29,19,21,29,4,26,17,14,1,6,30,29,13,24,7,16,6,1,30,8,16,1,17,0,29,3,23,20,17,12,1]

theorem envBound37764 : H12AffineFastState.Bounded env37764 := by
  intro p hp
  have h : env37764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37763_37764 : H12AffineEnvironment.transform 5 29 env37763 = env37764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 29 env37763 == env37764) = true)

theorem identity37764 : scanCanonicalize (H12AffineFastState.compose env37764 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound37764 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env37765 : List Nat := [2,4,5,16,22,16,19,21,16,4,23,17,3,1,6,19,16,0,21,7,16,6,1,19,5,16,1,17,0,16,3,23,20,17,1,1]

theorem envBound37765 : H12AffineFastState.Bounded env37765 := by
  intro p hp
  have h : env37765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37764_37765 : H12AffineEnvironment.transform 2 5 env37764 = env37765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env37764 == env37765) = true)

theorem identity37765 : scanCanonicalize (H12AffineFastState.compose env37765 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound37765 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37766 : List Nat := [2,3,2,16,17,16,19,18,16,3,16,17,3,1,1,19,16,0,18,0,16,1,1,19,2,16,1,17,0,16,3,16,19,17,1,1]

theorem envBound37766 : H12AffineFastState.Bounded env37766 := by
  intro p hp
  have h : env37766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37765_37766 : H12AffineEnvironment.transform 1 3 env37765 = env37766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env37765 == env37766) = true)

theorem identity37766 : scanCanonicalize (H12AffineFastState.compose env37766 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound37766 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37767 : List Nat := [2,3,2,0,1,0,3,2,0,3,0,1,3,1,1,3,0,0,2,0,0,1,1,3,2,0,1,1,0,0,3,0,3,1,1,1]

theorem envBound37767 : H12AffineFastState.Bounded env37767 := by
  intro p hp
  have h : env37767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37766_37767 : H12AffineEnvironment.transform 3 0 env37766 = env37767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env37766 == env37767) = true)

theorem identity37767 : scanCanonicalize (H12AffineFastState.compose env37767 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound37767 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37768 : List Nat := [0,1,0,0,1,0,1,0,0,1,0,1,1,1,1,1,0,0,0,0,0,1,1,1,0,0,1,1,0,0,1,0,1,1,1,1]

theorem envBound37768 : H12AffineFastState.Bounded env37768 := by
  intro p hp
  have h : env37768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37767_37768 : H12AffineEnvironment.transform 0 0 env37767 = env37768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env37767 == env37768) = true)

def env37769 : List Nat := [2,4,8,16,32,64,128,256,341,273,2048,17,157,1,384,305,210,433,336,385,16,477,147,305,85,130,303,131,0,2534,144,22,257,17,81,276]

theorem envBound37769 : H12AffineFastState.Bounded env37769 := by
  intro p hp
  have h : env37769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37758_37769 : H12AffineEnvironment.transform 15 305 env37758 = env37769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 305 env37758 == env37769) = true)

theorem identity37769 : scanCanonicalize (H12AffineFastState.compose env37769 (packedSelected [1,2,3,7,15,17,19,20,21,23,27,32] rootPS)) = affineNative (2^(6+1) ^^^ 46) := by decide +kernel

theorem selectedBound37769 : packedSelected [1,2,3,7,15,17,19,20,21,23,27,32] rootPS < 2^1333 := by decide +kernel

def env37770 : List Nat := [2,4,8,16,32,64,46,256,341,273,2048,17,51,1,302,305,124,287,336,303,16,371,61,305,85,44,303,45,0,2376,62,22,257,17,81,276]

theorem envBound37770 : H12AffineFastState.Bounded env37770 := by
  intro p hp
  have h : env37770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37769_37770 : H12AffineEnvironment.transform 6 46 env37769 = env37770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 46 env37769 == env37770) = true)

theorem identity37770 : scanCanonicalize (H12AffineFastState.compose env37770 (packedSelected [1,3,5,8,10,11,18,19,20,23] rootPS)) = affineNative (2^(10+1) ^^^ 366) := by decide +kernel

theorem selectedBound37770 : packedSelected [1,3,5,8,10,11,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env37771 : List Nat := [2,4,8,16,32,64,46,256,341,273,366,17,51,1,302,305,124,287,336,303,16,371,61,305,85,44,303,45,0,38,62,22,257,17,81,276]

theorem envBound37771 : H12AffineFastState.Bounded env37771 := by
  intro p hp
  have h : env37771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37770_37771 : H12AffineEnvironment.transform 10 366 env37770 = env37771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 366 env37770 == env37771) = true)

theorem identity37771 : scanCanonicalize (H12AffineFastState.compose env37771 (packedSelected [1,3,8,10,11,15] rootPS)) = affineNative (2^(7+1) ^^^ 19) := by decide +kernel

theorem selectedBound37771 : packedSelected [1,3,8,10,11,15] rootPS < 2^1333 := by decide +kernel

def env37772 : List Nat := [2,4,8,16,32,64,46,19,70,2,125,17,51,1,61,34,124,12,67,60,16,96,61,34,85,44,60,45,0,38,62,22,18,17,81,7]

theorem envBound37772 : H12AffineFastState.Bounded env37772 := by
  intro p hp
  have h : env37772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37771_37772 : H12AffineEnvironment.transform 7 19 env37771 = env37772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 19 env37771 == env37772) = true)

theorem identity37772 : scanCanonicalize (H12AffineFastState.compose env37772 (packedSelected [0,3,8,9,10,11] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound37772 : packedSelected [0,3,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env37773 : List Nat := [2,4,8,16,32,33,46,19,39,2,28,17,51,1,61,34,29,12,34,60,16,1,61,34,52,44,60,45,0,38,62,22,18,17,48,7]

theorem envBound37773 : H12AffineFastState.Bounded env37773 := by
  intro p hp
  have h : env37773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37772_37773 : H12AffineEnvironment.transform 5 33 env37772 = env37773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env37772 == env37773) = true)

theorem identity37773 : scanCanonicalize (H12AffineFastState.compose env37773 (packedSelected [0,2,3,5,7,8] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound37773 : packedSelected [0,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env37774 : List Nat := [2,3,8,16,32,33,41,19,32,2,27,17,51,1,58,34,26,11,34,59,16,1,58,34,51,43,59,42,0,33,57,17,18,17,48,0]

theorem envBound37774 : H12AffineFastState.Bounded env37774 := by
  intro p hp
  have h : env37774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37773_37774 : H12AffineEnvironment.transform 1 3 env37773 = env37774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env37773 == env37774) = true)

theorem identity37774 : scanCanonicalize (H12AffineFastState.compose env37774 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound37774 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env37775 : List Nat := [2,3,8,16,16,17,25,19,16,2,27,17,3,1,10,18,26,11,18,11,16,1,10,18,3,27,11,26,0,17,9,17,18,17,0,0]

theorem envBound37775 : H12AffineFastState.Bounded env37775 := by
  intro p hp
  have h : env37775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37774_37775 : H12AffineEnvironment.transform 4 16 env37774 = env37775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env37774 == env37775) = true)

def env37776 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74863,65665,4417,13340,4097,477,74047,69649,13768,78894,4415,74814,1297,81226,8205,65831,257,1280,1344,5953]

theorem envBound37776 : H12AffineFastState.Bounded env37776 := by
  intro p hp
  have h : env37776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37694_37776 : H12AffineEnvironment.transform 17 65665 env37694 = env37776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env37694 == env37776) = true)

theorem identity37776 : scanCanonicalize (H12AffineFastState.compose env37776 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound37776 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env37777 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,8192,1296,9292,65536,74863,65665,272,9293,80,477,74047,65600,9625,74879,366,74814,1297,77083,8205,65831,257,1280,1344,1808]

theorem envBound37777 : H12AffineFastState.Bounded env37777 := by
  intro p hp
  have h : env37777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37776_37777 : H12AffineEnvironment.transform 11 81 env37776 = env37777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env37776 == env37777) = true)

def env37778 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,81,8192,80,8460,65536,74031,65665,272,8461,80,477,74047,65600,8409,74047,366,74110,81,75867,8205,65831,257,64,0,592]

theorem envBound37778 : H12AffineFastState.Bounded env37778 := by
  intro p hp
  have h : env37778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37777_37778 : H12AffineEnvironment.transform 9 320 env37777 = env37778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env37777 == env37778) = true)

theorem identity37778 : scanCanonicalize (H12AffineFastState.compose env37778 (packedSelected [7,20,27] rootPS)) = affineNative (2^(15+1) ^^^ 8298) := by decide +kernel

theorem selectedBound37778 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env37779 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,81,8192,80,8460,8298,325,8427,272,8461,80,477,341,8234,8409,341,366,276,81,2097,8205,8525,257,64,0,592]

theorem envBound37779 : H12AffineFastState.Bounded env37779 := by
  intro p hp
  have h : env37779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37778_37779 : H12AffineEnvironment.transform 15 8298 env37778 = env37779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8298 env37778 == env37779) = true)

theorem identity37779 : scanCanonicalize (H12AffineFastState.compose env37779 (packedSelected [2,4,9,13,16,21,23,32] rootPS)) = affineNative (2^(8+1) ^^^ 413) := by decide +kernel

theorem selectedBound37779 : packedSelected [2,4,9,13,16,21,23,32] rootPS < 2^1333 := by decide +kernel

def env37780 : List Nat := [2,4,8,16,32,64,128,256,413,320,2048,81,8192,80,8460,8298,325,8427,272,8461,80,477,341,8234,8409,341,366,276,81,2097,8205,8525,257,64,0,461]

theorem envBound37780 : H12AffineFastState.Bounded env37780 := by
  intro p hp
  have h : env37780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37779_37780 : H12AffineEnvironment.transform 8 413 env37779 = env37780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 413 env37779 == env37780) = true)

theorem identity37780 : scanCanonicalize (H12AffineFastState.compose env37780 (packedSelected [0,1,7,8,13,16,18,19,23,24,28] rootPS)) = affineNative (2^(12+1) ^^^ 2267) := by decide +kernel

theorem selectedBound37780 : packedSelected [0,1,7,8,13,16,18,19,23,24,28] rootPS < 2^1333 := by decide +kernel

def env37781 : List Nat := [2,4,8,16,32,64,128,256,413,320,2048,81,2267,80,2519,2225,325,2096,272,2518,80,477,341,2289,2050,341,366,276,81,2097,2262,2454,257,64,0,461]

theorem envBound37781 : H12AffineFastState.Bounded env37781 := by
  intro p hp
  have h : env37781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37780_37781 : H12AffineEnvironment.transform 12 2267 env37780 = env37781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2267 env37780 == env37781) = true)

theorem identity37781 : scanCanonicalize (H12AffineFastState.compose env37781 (packedSelected [0,1,5,7,10,12,13,15,16,17] rootPS)) = affineNative (2^(10+1) ^^^ 122) := by decide +kernel

theorem selectedBound37781 : packedSelected [0,1,5,7,10,12,13,15,16,17] rootPS < 2^1333 := by decide +kernel

def env37782 : List Nat := [2,4,8,16,32,64,128,256,413,320,122,81,161,80,429,203,325,74,272,428,80,477,341,139,120,341,366,276,81,75,172,492,257,64,0,461]

theorem envBound37782 : H12AffineFastState.Bounded env37782 := by
  intro p hp
  have h : env37782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37781_37782 : H12AffineEnvironment.transform 10 122 env37781 = env37782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 122 env37781 == env37782) = true)

theorem identity37782 : scanCanonicalize (H12AffineFastState.compose env37782 (packedSelected [0,2,4,5,8,10] rootPS)) = affineNative (2^(7+1) ^^^ 63) := by decide +kernel

theorem selectedBound37782 : packedSelected [0,2,4,5,8,10] rootPS < 2^1333 := by decide +kernel

def env37783 : List Nat := [2,4,8,16,32,64,128,63,162,127,122,81,161,80,146,203,122,74,47,147,80,226,106,139,120,106,81,43,81,75,172,211,62,64,0,242]

theorem envBound37783 : H12AffineFastState.Bounded env37783 := by
  intro p hp
  have h : env37783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37782_37783 : H12AffineEnvironment.transform 7 63 env37782 = env37783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 63 env37782 == env37783) = true)

theorem identity37783 : scanCanonicalize (H12AffineFastState.compose env37783 (packedSelected [0,4,11] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound37783 : packedSelected [0,4,11] rootPS < 2^1333 := by decide +kernel

def env37784 : List Nat := [2,4,8,16,32,64,89,63,123,127,122,81,120,80,75,18,122,74,47,74,80,59,106,82,120,106,81,43,81,75,117,10,62,64,0,43]

theorem envBound37784 : H12AffineFastState.Bounded env37784 := by
  intro p hp
  have h : env37784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37783_37784 : H12AffineEnvironment.transform 6 89 env37783 = env37784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env37783 == env37784) = true)

theorem identity37784 : scanCanonicalize (H12AffineFastState.compose env37784 (packedSelected [4,7] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound37784 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env37785 : List Nat := [2,4,8,16,32,59,34,63,0,4,1,42,3,43,48,18,1,49,47,49,43,59,17,41,3,17,42,43,42,48,14,10,62,59,0,43]

theorem envBound37785 : H12AffineFastState.Bounded env37785 := by
  intro p hp
  have h : env37785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37784_37785 : H12AffineEnvironment.transform 5 59 env37784 = env37785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env37784 == env37785) = true)

theorem identity37785 : scanCanonicalize (H12AffineFastState.compose env37785 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound37785 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env37786 : List Nat := [2,4,8,16,10,17,8,21,0,4,1,0,3,1,26,18,1,27,5,27,1,17,17,3,3,17,0,1,0,26,14,10,20,17,0,1]

theorem envBound37786 : H12AffineFastState.Bounded env37786 := by
  intro p hp
  have h : env37786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37785_37786 : H12AffineEnvironment.transform 4 10 env37785 = env37786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env37785 == env37786) = true)

theorem identity37786 : scanCanonicalize (H12AffineFastState.compose env37786 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound37786 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env37787 : List Nat := [2,4,8,2,10,3,8,7,0,4,1,0,3,1,8,0,1,9,5,9,1,3,3,3,3,3,0,1,0,8,14,10,6,3,0,1]

theorem envBound37787 : H12AffineFastState.Bounded env37787 := by
  intro p hp
  have h : env37787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37786_37787 : H12AffineEnvironment.transform 3 2 env37786 = env37787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env37786 == env37787) = true)

theorem identity37787 : scanCanonicalize (H12AffineFastState.compose env37787 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound37787 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37788 : List Nat := [2,4,0,2,2,3,0,7,0,4,1,0,3,1,0,0,1,1,5,1,1,3,3,3,3,3,0,1,0,0,6,2,6,3,0,1]

theorem envBound37788 : H12AffineFastState.Bounded env37788 := by
  intro p hp
  have h : env37788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37787_37788 : H12AffineEnvironment.transform 2 0 env37787 = env37788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env37787 == env37788) = true)

theorem identity37788 : scanCanonicalize (H12AffineFastState.compose env37788 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound37788 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37789 : List Nat := [2,0,0,2,2,3,0,3,0,0,1,0,3,1,0,0,1,1,1,1,1,3,3,3,3,3,0,1,0,0,2,2,2,3,0,1]

theorem envBound37789 : H12AffineFastState.Bounded env37789 := by
  intro p hp
  have h : env37789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37788_37789 : H12AffineEnvironment.transform 1 0 env37788 = env37789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env37788 == env37789) = true)

theorem identity37789 : scanCanonicalize (H12AffineFastState.compose env37789 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound37789 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env37790 : List Nat := [1,0,0,1,1,0,0,0,0,0,1,0,0,1,0,0,1,1,1,1,1,0,0,0,0,0,0,1,0,0,1,1,1,0,0,1]

theorem envBound37790 : H12AffineFastState.Bounded env37790 := by
  intro p hp
  have h : env37790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37789_37790 : H12AffineEnvironment.transform 0 1 env37789 = env37790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env37789 == env37790) = true)

def env37791 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,81,8192,81,8461,65536,74030,65665,272,8460,80,477,74047,65600,8408,74046,366,74111,80,75866,8205,65831,257,65,1,593]

theorem envBound37791 : H12AffineFastState.Bounded env37791 := by
  intro p hp
  have h : env37791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37777_37791 : H12AffineEnvironment.transform 9 321 env37777 = env37791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env37777 == env37791) = true)

theorem identity37791 : scanCanonicalize (H12AffineFastState.compose env37791 (packedSelected [7,20,27] rootPS)) = affineNative (2^(15+1) ^^^ 8251) := by decide +kernel

theorem selectedBound37791 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env37792 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,81,8192,81,8461,8251,277,8378,272,8460,80,477,260,8315,8408,261,366,324,80,2145,8205,8476,257,65,1,593]

theorem envBound37792 : H12AffineFastState.Bounded env37792 := by
  intro p hp
  have h : env37792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37791_37792 : H12AffineEnvironment.transform 15 8251 env37791 = env37792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8251 env37791 == env37792) = true)

theorem identity37792 : scanCanonicalize (H12AffineFastState.compose env37792 (packedSelected [0,1,4,7,8,9,16,19,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound37792 : packedSelected [0,1,4,7,8,9,16,19,20] rootPS < 2^1333 := by decide +kernel

def env37793 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,8192,1,8461,8251,277,8378,272,8460,0,397,260,8235,8328,261,318,276,0,2097,8205,8476,257,17,1,513]

theorem envBound37793 : H12AffineFastState.Bounded env37793 := by
  intro p hp
  have h : env37793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37792_37793 : H12AffineEnvironment.transform 5 16 env37792 = env37793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env37792 == env37793) = true)

theorem identity37793 : scanCanonicalize (H12AffineFastState.compose env37793 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 933) := by decide +kernel

theorem selectedBound37793 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env37794 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,933,1,680,926,277,799,272,681,0,397,260,910,813,261,318,276,0,2097,936,697,257,17,1,513]

theorem envBound37794 : H12AffineFastState.Bounded env37794 := by
  intro p hp
  have h : env37794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37793_37794 : H12AffineEnvironment.transform 12 933 env37793 = env37794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 933 env37793 == env37794) = true)

theorem identity37794 : scanCanonicalize (H12AffineFastState.compose env37794 (packedSelected [0,7,11] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound37794 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env37795 : List Nat := [2,4,8,16,11,16,128,256,512,273,2048,1,910,1,643,926,277,799,272,642,0,397,260,910,774,261,277,276,0,2074,899,658,257,17,1,513]

theorem envBound37795 : H12AffineFastState.Bounded env37795 := by
  intro p hp
  have h : env37795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37794_37795 : H12AffineEnvironment.transform 4 11 env37794 = env37795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env37794 == env37795) = true)

theorem identity37795 : scanCanonicalize (H12AffineFastState.compose env37795 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound37795 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env37796 : List Nat := [2,4,8,16,11,16,128,20,512,5,2048,1,666,1,643,650,1,523,4,642,0,153,16,666,530,17,1,0,0,2074,663,658,21,17,1,513]

theorem envBound37796 : H12AffineFastState.Bounded env37796 := by
  intro p hp
  have h : env37796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37795_37796 : H12AffineEnvironment.transform 7 20 env37795 = env37796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env37795 == env37796) = true)

theorem identity37796 : scanCanonicalize (H12AffineFastState.compose env37796 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 146) := by decide +kernel

theorem selectedBound37796 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37797 : List Nat := [2,4,8,16,11,16,128,20,146,5,2048,1,8,1,17,24,1,153,4,16,0,153,16,8,128,17,1,0,0,2074,5,0,21,17,1,147]

theorem envBound37797 : H12AffineFastState.Bounded env37797 := by
  intro p hp
  have h : env37797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37796_37797 : H12AffineEnvironment.transform 8 146 env37796 = env37797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 146 env37796 == env37797) = true)

theorem identity37797 : scanCanonicalize (H12AffineFastState.compose env37797 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 148) := by decide +kernel

theorem selectedBound37797 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env37798 : List Nat := [2,4,8,16,11,16,128,20,146,5,148,1,8,1,17,24,1,153,4,16,0,153,16,8,128,17,1,0,0,142,5,0,21,17,1,147]

theorem envBound37798 : H12AffineFastState.Bounded env37798 := by
  intro p hp
  have h : env37798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37797_37798 : H12AffineEnvironment.transform 10 148 env37797 = env37798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 148 env37797 == env37798) = true)

theorem identity37798 : scanCanonicalize (H12AffineFastState.compose env37798 (packedSelected [1,7] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound37798 : packedSelected [1,7] rootPS < 2^1333 := by decide +kernel

def env37799 : List Nat := [2,4,8,2,11,2,128,6,128,5,134,1,8,1,3,10,1,139,4,2,0,139,2,8,128,3,1,0,0,142,5,0,7,3,1,129]

theorem envBound37799 : H12AffineFastState.Bounded env37799 := by
  intro p hp
  have h : env37799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37798_37799 : H12AffineEnvironment.transform 3 2 env37798 = env37799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env37798 == env37799) = true)

theorem identity37799 : scanCanonicalize (H12AffineFastState.compose env37799 (packedSelected [8] rootPS)) = affineNative (2^(6+1) ^^^ 10) := by decide +kernel

theorem selectedBound37799 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env37800 : List Nat := [2,4,8,2,11,2,10,6,10,5,12,1,8,1,3,10,1,1,4,2,0,1,2,8,10,3,1,0,0,4,5,0,7,3,1,11]

theorem envBound37800 : H12AffineFastState.Bounded env37800 := by
  intro p hp
  have h : env37800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37799_37800 : H12AffineEnvironment.transform 6 10 env37799 = env37800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 10 env37799 == env37800) = true)

theorem identity37800 : scanCanonicalize (H12AffineFastState.compose env37800 (packedSelected [1,4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound37800 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env37801 : List Nat := [2,4,3,2,0,2,1,6,1,5,7,1,3,1,3,1,1,1,4,2,0,1,2,3,1,3,1,0,0,4,5,0,7,3,1,0]

theorem envBound37801 : H12AffineFastState.Bounded env37801 := by
  intro p hp
  have h : env37801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37800_37801 : H12AffineEnvironment.transform 2 3 env37800 = env37801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env37800 == env37801) = true)

theorem identity37801 : scanCanonicalize (H12AffineFastState.compose env37801 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound37801 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37802 : List Nat := [2,3,3,2,0,2,1,1,1,2,0,1,3,1,3,1,1,1,3,2,0,1,2,3,1,3,1,0,0,3,2,0,0,3,1,0]

theorem envBound37802 : H12AffineFastState.Bounded env37802 := by
  intro p hp
  have h : env37802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37801_37802 : H12AffineEnvironment.transform 1 3 env37801 = env37802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env37801 == env37802) = true)

theorem identity37802 : scanCanonicalize (H12AffineFastState.compose env37802 (packedSelected [5] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound37802 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env37803 : List Nat := [1,0,0,1,0,1,1,1,1,1,0,1,0,1,0,1,1,1,0,1,0,1,1,0,1,0,1,0,0,0,1,0,0,0,1,0]

theorem envBound37803 : H12AffineFastState.Bounded env37803 := by
  intro p hp
  have h : env37803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37802_37803 : H12AffineEnvironment.transform 0 1 env37802 = env37803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env37802 == env37803) = true)

def env37804 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74863,262144,4416,13340,4097,476,74046,69648,13769,78894,332223,74815,1297,81227,8204,65830,257,1280,1344,5952]

theorem envBound37804 : H12AffineFastState.Bounded env37804 := by
  intro p hp
  have h : env37804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37693_37804 : H12AffineEnvironment.transform 13 1297 env37693 = env37804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env37693 == env37804) = true)

def env37805 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74863,65664,4416,13340,4097,476,74046,69648,13769,78894,4415,74815,1297,81227,8204,65830,257,1280,1344,5952]

theorem envBound37805 : H12AffineFastState.Bounded env37805 := by
  intro p hp
  have h : env37805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37804_37805 : H12AffineEnvironment.transform 17 65664 env37804 = env37805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env37804 == env37805) = true)

theorem identity37805 : scanCanonicalize (H12AffineFastState.compose env37805 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5464) := by decide +kernel

theorem selectedBound37805 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env37806 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5464,1297,325,65536,69943,65664,4416,324,4097,476,70758,69648,145,65910,4415,69991,1297,67603,5460,65830,257,1280,1344,5952]

theorem envBound37806 : H12AffineFastState.Bounded env37806 := by
  intro p hp
  have h : env37806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37805_37806 : H12AffineEnvironment.transform 12 5464 env37805 = env37806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5464 env37805 == env37806) = true)

def env37807 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5464,1297,325,1052,5419,1180,4416,324,4097,476,4218,5132,145,1386,4415,5499,1297,3087,5460,1338,257,1280,1344,5952]

theorem envBound37807 : H12AffineFastState.Bounded env37807 := by
  intro p hp
  have h : env37807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37806_37807 : H12AffineEnvironment.transform 15 1052 env37806 = env37807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1052 env37806 == env37807) = true)

theorem identity37807 : scanCanonicalize (H12AffineFastState.compose env37807 (packedSelected [0,2,3,5,8,11,15,16,17,20,21,23,24,27,28] rootPS)) = affineNative (2^(10+1) ^^^ 354) := by decide +kernel

theorem selectedBound37807 : packedSelected [0,2,3,5,8,11,15,16,17,20,21,23,24,27,28] rootPS < 2^1333 := by decide +kernel

def env37808 : List Nat := [2,4,8,16,32,64,128,256,512,1024,354,4096,5464,1297,325,1052,5419,1180,4416,324,4097,476,4218,5132,145,1386,4415,5499,1297,1389,5460,1338,257,1280,1344,5952]

theorem envBound37808 : H12AffineFastState.Bounded env37808 := by
  intro p hp
  have h : env37808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37807_37808 : H12AffineEnvironment.transform 10 354 env37807 = env37808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 354 env37807 == env37808) = true)

def env37809 : List Nat := [2,4,4,16,32,64,128,256,512,1024,354,4096,5460,1297,325,1040,5415,1168,4416,324,4097,464,4214,5120,145,1382,4403,5495,1297,1377,5460,1334,257,1280,1344,5952]

theorem envBound37809 : H12AffineFastState.Bounded env37809 := by
  intro p hp
  have h : env37809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37808_37809 : H12AffineEnvironment.transform 2 4 env37808 = env37809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env37808 == env37809) = true)

theorem identity37809 : scanCanonicalize (H12AffineFastState.compose env37809 (packedSelected [1,3,7,8,10,12,13,17,20,21,27] rootPS)) = affineNative (2^(11+1) ^^^ 1863) := by decide +kernel

theorem selectedBound37809 : packedSelected [1,3,7,8,10,12,13,17,20,21,27] rootPS < 2^1333 := by decide +kernel

def env37810 : List Nat := [2,4,4,16,32,64,128,256,512,1024,354,1863,531,1297,325,1040,608,1168,1543,324,1862,464,1841,839,145,1382,1652,560,1297,1377,531,1334,257,1280,1344,7]

theorem envBound37810 : H12AffineFastState.Bounded env37810 := by
  intro p hp
  have h : env37810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37809_37810 : H12AffineEnvironment.transform 11 1863 env37809 = env37810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1863 env37809 == env37810) = true)

theorem identity37810 : scanCanonicalize (H12AffineFastState.compose env37810 (packedSelected [0,2,4,7,8,9,10,11,13,17,18,24,38,41] rootPS)) = affineNative (2^(9+1) ^^^ 420) := by decide +kernel

theorem selectedBound37810 : packedSelected [0,2,4,7,8,9,10,11,13,17,18,24,38,41] rootPS < 2^1333 := by decide +kernel

def env37811 : List Nat := [2,4,4,16,32,64,128,256,512,420,354,739,531,181,325,436,608,308,931,324,738,464,661,839,145,194,976,560,181,197,531,146,257,164,228,7]

theorem envBound37811 : H12AffineFastState.Bounded env37811 := by
  intro p hp
  have h : env37811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37810_37811 : H12AffineEnvironment.transform 9 420 env37810 = env37811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 420 env37810 == env37811) = true)

theorem identity37811 : scanCanonicalize (H12AffineFastState.compose env37811 (packedSelected [0,1,2,3,5,7,8,10,11,13,15,16,17,18,19,24] rootPS)) = affineNative (2^(8+1) ^^^ 423) := by decide +kernel

theorem selectedBound37811 : packedSelected [0,1,2,3,5,7,8,10,11,13,15,16,17,18,19,24] rootPS < 2^1333 := by decide +kernel

def env37812 : List Nat := [2,4,4,16,32,64,128,256,423,420,354,324,436,181,325,436,455,308,4,324,325,464,306,224,145,194,119,407,181,197,436,146,257,164,228,7]

theorem envBound37812 : H12AffineFastState.Bounded env37812 := by
  intro p hp
  have h : env37812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37811_37812 : H12AffineEnvironment.transform 8 423 env37811 = env37812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 423 env37811 == env37812) = true)

theorem identity37812 : scanCanonicalize (H12AffineFastState.compose env37812 (packedSelected [13,17] rootPS)) = affineNative (2^(7+1) ^^^ 198) := by decide +kernel

theorem selectedBound37812 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env37813 : List Nat := [2,4,4,16,32,64,128,198,97,98,164,130,114,181,131,114,1,242,4,130,131,22,244,224,145,194,119,81,181,197,114,146,199,164,228,7]

theorem envBound37813 : H12AffineFastState.Bounded env37813 := by
  intro p hp
  have h : env37813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37812_37813 : H12AffineEnvironment.transform 7 198 env37812 = env37813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 198 env37812 == env37813) = true)

theorem identity37813 : scanCanonicalize (H12AffineFastState.compose env37813 (packedSelected [1,2,4,8,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 22) := by decide +kernel

theorem selectedBound37813 : packedSelected [1,2,4,8,9,11] rootPS < 2^1333 := by decide +kernel

def env37814 : List Nat := [2,4,4,16,32,22,128,144,55,52,164,130,36,181,131,36,1,164,4,130,131,22,162,182,145,148,33,7,181,147,36,146,145,164,178,7]

theorem envBound37814 : H12AffineFastState.Bounded env37814 := by
  intro p hp
  have h : env37814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37813_37814 : H12AffineEnvironment.transform 5 22 env37813 = env37814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 22 env37813 == env37814) = true)

theorem identity37814 : scanCanonicalize (H12AffineFastState.compose env37814 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 50) := by decide +kernel

theorem selectedBound37814 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env37815 : List Nat := [2,4,4,16,32,22,50,34,55,52,22,48,36,7,49,36,1,22,4,48,49,22,16,4,35,38,33,7,7,33,36,32,35,22,0,7]

theorem envBound37815 : H12AffineFastState.Bounded env37815 := by
  intro p hp
  have h : env37815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37814_37815 : H12AffineEnvironment.transform 6 50 env37814 = env37815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 50 env37814 == env37815) = true)

theorem identity37815 : scanCanonicalize (H12AffineFastState.compose env37815 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound37815 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37816 : List Nat := [2,4,4,16,6,22,20,4,17,18,22,22,2,7,23,2,1,22,4,22,23,22,16,4,5,0,7,7,7,7,2,6,5,22,0,7]

theorem envBound37816 : H12AffineFastState.Bounded env37816 := by
  intro p hp
  have h : env37816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37815_37816 : H12AffineEnvironment.transform 4 6 env37815 = env37816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env37815 == env37816) = true)

theorem identity37816 : scanCanonicalize (H12AffineFastState.compose env37816 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound37816 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env37817 : List Nat := [2,2,2,16,0,16,18,2,17,18,16,16,2,1,17,2,1,16,2,16,17,16,16,2,3,0,1,1,1,1,2,0,3,16,0,1]

theorem envBound37817 : H12AffineFastState.Bounded env37817 := by
  intro p hp
  have h : env37817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37816_37817 : H12AffineEnvironment.transform 1 2 env37816 = env37817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env37816 == env37817) = true)

theorem identity37817 : scanCanonicalize (H12AffineFastState.compose env37817 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound37817 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env37818 : List Nat := [2,2,2,1,0,1,3,2,0,3,1,1,2,1,0,2,1,1,2,1,0,1,1,2,3,0,1,1,1,1,2,0,3,1,0,1]

theorem envBound37818 : H12AffineFastState.Bounded env37818 := by
  intro p hp
  have h : env37818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37817_37818 : H12AffineEnvironment.transform 3 1 env37817 = env37818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env37817 == env37818) = true)

theorem identity37818 : scanCanonicalize (H12AffineFastState.compose env37818 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound37818 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37819 : List Nat := [1,1,1,1,0,1,0,1,0,0,1,1,1,1,0,1,1,1,1,1,0,1,1,1,0,0,1,1,1,1,1,0,0,1,0,1]

theorem envBound37819 : H12AffineFastState.Bounded env37819 := by
  intro p hp
  have h : env37819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37818_37819 : H12AffineEnvironment.transform 0 1 env37818 = env37819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env37818 == env37819) = true)

def env37820 : List Nat := [2,4,5,16,32,64,128,256,512,1024,354,4096,5461,1297,325,1041,5414,1169,4416,324,4097,465,4215,5121,145,1383,4402,5494,1297,1376,5460,1335,257,1280,1344,5952]

theorem envBound37820 : H12AffineFastState.Bounded env37820 := by
  intro p hp
  have h : env37820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37808_37820 : H12AffineEnvironment.transform 2 5 env37808 = env37820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env37808 == env37820) = true)

theorem identity37820 : scanCanonicalize (H12AffineFastState.compose env37820 (packedSelected [0,1,2,4,5,7,8,9,11,15,16,20,23] rootPS)) = affineNative (2^(7+1) ^^^ 198) := by decide +kernel

theorem selectedBound37820 : packedSelected [0,1,2,4,5,7,8,9,11,15,16,20,23] rootPS < 2^1333 := by decide +kernel

def env37821 : List Nat := [2,4,5,16,32,64,128,198,512,1024,164,4096,5267,1239,131,1041,5344,1169,4230,130,4097,23,4215,5121,145,1185,4340,5296,1239,1190,5266,1265,199,1222,1158,5766]

theorem envBound37821 : H12AffineFastState.Bounded env37821 := by
  intro p hp
  have h : env37821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37820_37821 : H12AffineEnvironment.transform 7 198 env37820 = env37821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 198 env37820 == env37821) = true)

theorem identity37821 : scanCanonicalize (H12AffineFastState.compose env37821 (packedSelected [5,12,13,19] rootPS)) = affineNative (2^(11+1) ^^^ 599) := by decide +kernel

theorem selectedBound37821 : packedSelected [5,12,13,19] rootPS < 2^1333 := by decide +kernel

def env37822 : List Nat := [2,4,5,16,32,64,128,198,512,1024,164,599,1732,1239,131,1041,1719,1169,721,130,598,23,544,1622,145,1185,675,1767,1239,1190,1733,1265,199,1222,1158,1233]

theorem envBound37822 : H12AffineFastState.Bounded env37822 := by
  intro p hp
  have h : env37822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37821_37822 : H12AffineEnvironment.transform 11 599 env37821 = env37822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 599 env37821 == env37822) = true)

theorem identity37822 : scanCanonicalize (H12AffineFastState.compose env37822 (packedSelected [1,3,4,9,16,21] rootPS)) = affineNative (2^(8+1) ^^^ 213) := by decide +kernel

theorem selectedBound37822 : packedSelected [1,3,4,9,16,21] rootPS < 2^1333 := by decide +kernel

def env37823 : List Nat := [2,4,5,16,32,64,128,198,213,1024,164,130,1041,1239,131,1041,1122,1169,4,130,131,23,245,1155,145,1185,118,1074,1239,1190,1040,1265,199,1222,1158,1233]

theorem envBound37823 : H12AffineFastState.Bounded env37823 := by
  intro p hp
  have h : env37823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37822_37823 : H12AffineEnvironment.transform 8 213 env37822 = env37823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 213 env37822 == env37823) = true)

theorem identity37823 : scanCanonicalize (H12AffineFastState.compose env37823 (packedSelected [0,1,4,5,7,9,10,12,15] rootPS)) = affineNative (2^(4+1) ^^^ 23) := by decide +kernel

theorem selectedBound37823 : packedSelected [0,1,4,5,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env37824 : List Nat := [2,4,5,16,23,64,128,198,213,1024,147,130,1041,1239,131,1041,1109,1169,4,130,131,23,194,1155,145,1174,65,1029,1239,1169,1040,1222,199,1222,1158,1233]

theorem envBound37824 : H12AffineFastState.Bounded env37824 := by
  intro p hp
  have h : env37824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37823_37824 : H12AffineEnvironment.transform 4 23 env37823 = env37824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 23 env37823 == env37824) = true)

theorem identity37824 : scanCanonicalize (H12AffineFastState.compose env37824 (packedSelected [0,1,7,8,11] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound37824 : packedSelected [0,1,7,8,11] rootPS < 2^1333 := by decide +kernel

def env37825 : List Nat := [2,4,5,16,23,1,128,135,148,1024,147,130,1041,1174,131,1041,1044,1169,4,130,131,23,131,1155,145,1174,0,1029,1174,1169,1040,1159,134,1159,1158,1168]

theorem envBound37825 : H12AffineFastState.Bounded env37825 := by
  intro p hp
  have h : env37825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37824_37825 : H12AffineEnvironment.transform 5 1 env37824 = env37825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env37824 == env37825) = true)

theorem identity37825 : scanCanonicalize (H12AffineFastState.compose env37825 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound37825 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env37826 : List Nat := [2,4,5,16,23,1,128,135,148,20,147,130,5,130,131,5,0,133,4,130,131,23,131,151,145,130,0,17,130,133,4,147,134,147,146,132]

theorem envBound37826 : H12AffineFastState.Bounded env37826 := by
  intro p hp
  have h : env37826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37825_37826 : H12AffineEnvironment.transform 9 20 env37825 = env37826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env37825 == env37826) = true)

theorem identity37826 : scanCanonicalize (H12AffineFastState.compose env37826 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound37826 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env37827 : List Nat := [2,4,5,0,7,1,128,135,132,4,131,130,5,130,131,5,0,133,4,130,131,7,131,135,129,130,0,1,130,133,4,131,134,131,130,132]

theorem envBound37827 : H12AffineFastState.Bounded env37827 := by
  intro p hp
  have h : env37827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37826_37827 : H12AffineEnvironment.transform 3 0 env37826 = env37827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env37826 == env37827) = true)

def env37828 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5464,1297,325,1053,5418,1181,4416,324,4097,476,4219,5133,145,1387,4415,5498,1297,3086,5460,1339,257,1280,1344,5952]

theorem envBound37828 : H12AffineFastState.Bounded env37828 := by
  intro p hp
  have h : env37828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37806_37828 : H12AffineEnvironment.transform 15 1053 env37806 = env37828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1053 env37806 == env37828) = true)

theorem identity37828 : scanCanonicalize (H12AffineFastState.compose env37828 (packedSelected [0,2,3,5,8,11,15,16,17,20,21,23,24,27,28] rootPS)) = affineNative (2^(10+1) ^^^ 344) := by decide +kernel

theorem selectedBound37828 : packedSelected [0,2,3,5,8,11,15,16,17,20,21,23,24,27,28] rootPS < 2^1333 := by decide +kernel

def env37829 : List Nat := [2,4,8,16,32,64,128,256,512,1024,344,4096,5464,1297,325,1053,5418,1181,4416,324,4097,476,4219,5133,145,1387,4415,5498,1297,1366,5460,1339,257,1280,1344,5952]

theorem envBound37829 : H12AffineFastState.Bounded env37829 := by
  intro p hp
  have h : env37829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37828_37829 : H12AffineEnvironment.transform 10 344 env37828 = env37829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 344 env37828 == env37829) = true)

def env37830 : List Nat := [2,4,4,16,32,64,128,256,512,1024,340,4096,5460,1297,325,1041,5414,1169,4416,324,4097,464,4215,5121,145,1383,4403,5494,1297,1366,5460,1335,257,1280,1344,5952]

theorem envBound37830 : H12AffineFastState.Bounded env37830 := by
  intro p hp
  have h : env37830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37829_37830 : H12AffineEnvironment.transform 2 4 env37829 = env37830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env37829 == env37830) = true)

theorem identity37830 : scanCanonicalize (H12AffineFastState.compose env37830 (packedSelected [0,1,2,3,4,8,9,10,12,13,15,17,20,21,23,24,27,32] rootPS)) = affineNative (2^(9+1) ^^^ 694) := by decide +kernel

theorem selectedBound37830 : packedSelected [0,1,2,3,4,8,9,10,12,13,15,17,20,21,23,24,27,32] rootPS < 2^1333 := by decide +kernel

def env37831 : List Nat := [2,4,4,16,32,64,128,256,512,694,340,4096,5090,935,325,679,5008,551,4416,324,4097,464,4215,4791,145,977,4403,5056,935,992,5090,897,257,950,1014,4598]

theorem envBound37831 : H12AffineFastState.Bounded env37831 := by
  intro p hp
  have h : env37831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37830_37831 : H12AffineEnvironment.transform 9 694 env37830 = env37831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 694 env37830 == env37831) = true)

theorem identity37831 : scanCanonicalize (H12AffineFastState.compose env37831 (packedSelected [0,1,2,5,7,10,11,12,13,15,18,20,21] rootPS)) = affineNative (2^(11+1) ^^^ 935) := by decide +kernel

theorem selectedBound37831 : packedSelected [0,1,2,5,7,10,11,12,13,15,18,20,21] rootPS < 2^1333 := by decide +kernel

def env37832 : List Nat := [2,4,4,16,32,64,128,256,512,694,340,935,69,935,325,679,55,551,743,324,934,464,976,272,145,977,660,103,935,992,69,897,257,950,1014,593]

theorem envBound37832 : H12AffineFastState.Bounded env37832 := by
  intro p hp
  have h : env37832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37831_37832 : H12AffineEnvironment.transform 11 935 env37831 = env37832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 935 env37831 == env37832) = true)

theorem identity37832 : scanCanonicalize (H12AffineFastState.compose env37832 (packedSelected [0,2,3,4,5,7,8,9,11,15,17,23] rootPS)) = affineNative (2^(7+1) ^^^ 241) := by decide +kernel

theorem selectedBound37832 : packedSelected [0,2,3,4,5,7,8,9,11,15,17,23] rootPS < 2^1333 := by decide +kernel

def env37833 : List Nat := [2,4,4,16,32,64,128,241,512,694,165,598,69,598,180,679,55,551,743,181,599,33,545,225,145,544,660,103,598,529,69,624,240,583,519,593]

theorem envBound37833 : H12AffineFastState.Bounded env37833 := by
  intro p hp
  have h : env37833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37832_37833 : H12AffineEnvironment.transform 7 241 env37832 = env37833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 241 env37832 == env37833) = true)

theorem identity37833 : scanCanonicalize (H12AffineFastState.compose env37833 (packedSelected [0,1,3,8,9,10,11,13] rootPS)) = affineNative (2^(6+1) ^^^ 52) := by decide +kernel

theorem selectedBound37833 : packedSelected [0,1,3,8,9,10,11,13] rootPS < 2^1333 := by decide +kernel

def env37834 : List Nat := [2,4,4,16,32,64,52,69,512,514,17,598,69,598,0,531,55,551,595,1,599,33,545,85,37,544,544,103,598,529,69,624,68,583,519,593]

theorem envBound37834 : H12AffineFastState.Bounded env37834 := by
  intro p hp
  have h : env37834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37833_37834 : H12AffineEnvironment.transform 6 52 env37833 = env37834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 52 env37833 == env37834) = true)

theorem identity37834 : scanCanonicalize (H12AffineFastState.compose env37834 (packedSelected [0,2,9,10] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound37834 : packedSelected [0,2,9,10] rootPS < 2^1333 := by decide +kernel

def env37835 : List Nat := [2,4,4,6,32,64,34,69,512,514,7,576,69,576,0,517,33,551,581,1,577,33,545,67,37,544,544,103,576,519,69,614,68,583,519,583]

theorem envBound37835 : H12AffineFastState.Bounded env37835 := by
  intro p hp
  have h : env37835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37834_37835 : H12AffineEnvironment.transform 3 6 env37834 = env37835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env37834 == env37835) = true)

theorem identity37835 : scanCanonicalize (H12AffineFastState.compose env37835 (packedSelected [1,3,4,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound37835 : packedSelected [1,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env37836 : List Nat := [2,4,4,6,7,64,5,69,512,514,7,576,69,576,0,517,6,512,581,1,577,6,518,67,2,519,519,64,576,519,69,577,68,583,519,583]

theorem envBound37836 : H12AffineFastState.Bounded env37836 := by
  intro p hp
  have h : env37836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37835_37836 : H12AffineEnvironment.transform 4 7 env37835 = env37836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env37835 == env37836) = true)

theorem identity37836 : scanCanonicalize (H12AffineFastState.compose env37836 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound37836 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37837 : List Nat := [2,4,4,6,7,64,5,69,1,3,7,65,69,65,0,4,6,1,68,1,64,6,7,67,2,6,6,64,65,6,69,64,68,70,6,70]

theorem envBound37837 : H12AffineFastState.Bounded env37837 := by
  intro p hp
  have h : env37837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37836_37837 : H12AffineEnvironment.transform 8 1 env37836 = env37837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env37836 == env37837) = true)

theorem identity37837 : scanCanonicalize (H12AffineFastState.compose env37837 (packedSelected [2,5] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound37837 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env37838 : List Nat := [2,3,3,1,0,64,2,66,1,3,0,65,66,65,0,3,1,1,67,1,64,1,0,67,2,1,1,64,65,1,66,64,67,65,1,65]

theorem envBound37838 : H12AffineFastState.Bounded env37838 := by
  intro p hp
  have h : env37838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37837_37838 : H12AffineEnvironment.transform 1 3 env37837 = env37838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env37837 == env37838) = true)

def env37839 : List Nat := [2,4,5,16,32,64,128,256,512,1024,341,4096,5461,1297,325,1040,5415,1168,4416,324,4097,465,4214,5120,145,1382,4402,5495,1297,1366,5460,1334,257,1280,1344,5952]

theorem envBound37839 : H12AffineFastState.Bounded env37839 := by
  intro p hp
  have h : env37839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37829_37839 : H12AffineEnvironment.transform 2 5 env37829 = env37839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env37829 == env37839) = true)

theorem identity37839 : scanCanonicalize (H12AffineFastState.compose env37839 (packedSelected [0,1,2,3,4,8,9,10,12,13,15,17,20,21,23,24,27,32] rootPS)) = affineNative (2^(11+1) ^^^ 1825) := by decide +kernel

theorem selectedBound37839 : packedSelected [0,1,2,3,4,8,9,10,12,13,15,17,20,21,23,24,27,32] rootPS < 2^1333 := by decide +kernel

def env37840 : List Nat := [2,4,5,16,32,64,128,256,512,1024,341,1825,628,1297,325,1040,518,1168,1633,324,1824,465,1879,801,145,1382,1555,598,1297,1366,629,1334,257,1280,1344,97]

theorem envBound37840 : H12AffineFastState.Bounded env37840 := by
  intro p hp
  have h : env37840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37839_37840 : H12AffineEnvironment.transform 11 1825 env37839 = env37840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1825 env37839 == env37840) = true)

theorem identity37840 : scanCanonicalize (H12AffineFastState.compose env37840 (packedSelected [7,8,10,12,13,15,17,18,20,23,27,38] rootPS)) = affineNative (2^(8+1) ^^^ 87) := by decide +kernel

theorem selectedBound37840 : packedSelected [7,8,10,12,13,15,17,18,20,23,27,38] rootPS < 2^1333 := by decide +kernel

def env37841 : List Nat := [2,4,5,16,32,64,128,256,87,1024,341,1398,35,1297,325,1040,81,1168,1078,324,1399,465,1280,374,145,1382,1092,1,1297,1366,34,1334,257,1280,1344,97]

theorem envBound37841 : H12AffineFastState.Bounded env37841 := by
  intro p hp
  have h : env37841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37840_37841 : H12AffineEnvironment.transform 8 87 env37840 = env37841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 87 env37840 == env37841) = true)

theorem identity37841 : scanCanonicalize (H12AffineFastState.compose env37841 (packedSelected [0,3,5,7,10,12,15,16,17] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound37841 : packedSelected [0,3,5,7,10,12,15,16,17] rootPS < 2^1333 := by decide +kernel

def env37842 : List Nat := [2,4,5,16,32,64,128,256,87,320,341,54,35,81,325,336,81,464,374,324,55,465,64,374,145,38,260,1,81,22,34,118,257,64,0,97]

theorem envBound37842 : H12AffineFastState.Bounded env37842 := by
  intro p hp
  have h : env37842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37841_37842 : H12AffineEnvironment.transform 9 320 env37841 = env37842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env37841 == env37842) = true)

theorem identity37842 : scanCanonicalize (H12AffineFastState.compose env37842 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 18) := by decide +kernel

theorem selectedBound37842 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env37843 : List Nat := [2,4,5,16,32,64,128,18,87,82,71,54,35,81,87,66,81,194,100,86,55,195,64,100,145,38,22,1,81,22,34,118,19,64,0,97]

theorem envBound37843 : H12AffineFastState.Bounded env37843 := by
  intro p hp
  have h : env37843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37842_37843 : H12AffineEnvironment.transform 7 18 env37842 = env37843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 18 env37842 == env37843) = true)

theorem identity37843 : scanCanonicalize (H12AffineFastState.compose env37843 (packedSelected [1,2,4,7,8,10] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound37843 : packedSelected [1,2,4,7,8,10] rootPS < 2^1333 := by decide +kernel

def env37844 : List Nat := [2,4,5,16,16,64,128,18,87,82,71,6,19,81,87,66,81,194,84,86,7,195,64,84,145,22,22,1,81,22,18,70,19,64,0,81]

theorem envBound37844 : H12AffineFastState.Bounded env37844 := by
  intro p hp
  have h : env37844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37843_37844 : H12AffineEnvironment.transform 4 16 env37843 = env37844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env37843 == env37844) = true)

theorem identity37844 : scanCanonicalize (H12AffineFastState.compose env37844 (packedSelected [1,2,4,5,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound37844 : packedSelected [1,2,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env37845 : List Nat := [2,4,5,16,16,64,18,18,87,82,71,6,19,81,87,66,81,80,84,86,7,81,64,84,3,22,22,1,81,22,18,70,19,64,0,81]

theorem envBound37845 : H12AffineFastState.Bounded env37845 := by
  intro p hp
  have h : env37845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37844_37845 : H12AffineEnvironment.transform 6 18 env37844 = env37845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env37844 == env37845) = true)

theorem identity37845 : scanCanonicalize (H12AffineFastState.compose env37845 (packedSelected [1,2] rootPS)) = affineNative (2^(5+1) ^^^ 22) := by decide +kernel

theorem selectedBound37845 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env37846 : List Nat := [2,4,5,16,16,22,18,18,1,4,17,6,19,7,1,20,7,6,2,0,7,7,22,2,3,22,22,1,7,22,18,16,19,22,0,7]

theorem envBound37846 : H12AffineFastState.Bounded env37846 := by
  intro p hp
  have h : env37846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37845_37846 : H12AffineEnvironment.transform 5 22 env37845 = env37846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 22 env37845 == env37846) = true)

theorem identity37846 : scanCanonicalize (H12AffineFastState.compose env37846 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound37846 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env37847 : List Nat := [2,4,5,7,7,1,5,5,1,4,6,6,4,7,1,3,7,6,2,0,7,7,1,2,3,1,1,1,7,1,5,7,4,1,0,7]

theorem envBound37847 : H12AffineFastState.Bounded env37847 := by
  intro p hp
  have h : env37847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37846_37847 : H12AffineEnvironment.transform 3 7 env37846 = env37847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env37846 == env37847) = true)

theorem identity37847 : scanCanonicalize (H12AffineFastState.compose env37847 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound37847 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37848 : List Nat := [2,2,3,1,1,1,3,3,1,2,0,0,2,1,1,3,1,0,2,0,1,1,1,2,3,1,1,1,1,1,3,1,2,1,0,1]

theorem envBound37848 : H12AffineFastState.Bounded env37848 := by
  intro p hp
  have h : env37848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37847_37848 : H12AffineEnvironment.transform 1 2 env37847 = env37848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env37847 == env37848) = true)

def env37849 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74863,65665,4416,13340,4097,476,74046,69648,13769,78894,4414,74815,1297,81227,8204,65830,257,1280,1344,5952]

theorem envBound37849 : H12AffineFastState.Bounded env37849 := by
  intro p hp
  have h : env37849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37804_37849 : H12AffineEnvironment.transform 17 65665 env37804 = env37849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env37804 == env37849) = true)

theorem identity37849 : scanCanonicalize (H12AffineFastState.compose env37849 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound37849 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env37850 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,25,1297,5124,65536,66678,65665,4416,5125,4097,476,65831,69648,5584,70711,4414,66598,1297,73042,21,65830,257,1280,1344,5952]

theorem envBound37850 : H12AffineFastState.Bounded env37850 := by
  intro p hp
  have h : env37850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37849_37850 : H12AffineEnvironment.transform 12 25 env37849 = env37850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env37849 == env37850) = true)

def env37851 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,25,1297,5124,1052,106,1181,4416,5125,4097,476,1339,5132,5584,4139,4414,58,1297,6478,21,1338,257,1280,1344,5952]

theorem envBound37851 : H12AffineFastState.Bounded env37851 := by
  intro p hp
  have h : env37851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37850_37851 : H12AffineEnvironment.transform 15 1052 env37850 = env37851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1052 env37850 == env37851) = true)

theorem identity37851 : scanCanonicalize (H12AffineFastState.compose env37851 (packedSelected [0,1,2,4,7,9,10,11,15,17,19,21,23,24,28] rootPS)) = affineNative (2^(11+1) ^^^ 3420) := by decide +kernel

theorem selectedBound37851 : packedSelected [0,1,2,4,7,9,10,11,15,17,19,21,23,24,28] rootPS < 2^1333 := by decide +kernel

def env37852 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3420,25,1297,2392,1052,106,1181,3100,2393,3421,476,1339,2384,2188,3447,3170,58,1297,1042,21,1338,257,1280,1344,2588]

theorem envBound37852 : H12AffineFastState.Bounded env37852 := by
  intro p hp
  have h : env37852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37851_37852 : H12AffineEnvironment.transform 11 3420 env37851 = env37852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3420 env37851 == env37852) = true)

def env37853 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,2124,25,1,2392,268,106,397,2316,2393,2125,476,43,2384,2188,2151,2418,58,1,258,21,42,257,16,80,2588]

theorem envBound37853 : H12AffineFastState.Bounded env37853 := by
  intro p hp
  have h : env37853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37852_37853 : H12AffineEnvironment.transform 9 272 env37852 = env37853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env37852 == env37853) = true)

theorem identity37853 : scanCanonicalize (H12AffineFastState.compose env37853 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 355) := by decide +kernel

theorem selectedBound37853 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env37854 : List Nat := [2,4,8,16,32,64,128,256,512,272,355,303,25,1,59,268,106,397,111,58,302,476,43,51,495,260,17,58,1,258,21,42,257,16,80,895]

theorem envBound37854 : H12AffineFastState.Bounded env37854 := by
  intro p hp
  have h : env37854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37853_37854 : H12AffineEnvironment.transform 10 355 env37853 = env37854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 355 env37853 == env37854) = true)

theorem identity37854 : scanCanonicalize (H12AffineFastState.compose env37854 (packedSelected [1,3,4,8,9,10,12,16,17] rootPS)) = affineNative (2^(8+1) ^^^ 90) := by decide +kernel

theorem selectedBound37854 : packedSelected [1,3,4,8,9,10,12,16,17] rootPS < 2^1333 := by decide +kernel

def env37855 : List Nat := [2,4,8,16,32,64,128,256,90,272,355,303,25,1,59,268,106,397,111,58,302,476,43,51,495,260,17,58,1,258,21,42,257,16,80,293]

theorem envBound37855 : H12AffineFastState.Bounded env37855 := by
  intro p hp
  have h : env37855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37854_37855 : H12AffineEnvironment.transform 8 90 env37854 = env37855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 90 env37854 == env37855) = true)

theorem identity37855 : scanCanonicalize (H12AffineFastState.compose env37855 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound37855 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env37856 : List Nat := [2,4,8,16,32,16,128,256,10,272,307,303,25,1,59,268,58,397,63,58,302,396,43,51,447,260,17,58,1,258,21,42,257,16,0,293]

theorem envBound37856 : H12AffineFastState.Bounded env37856 := by
  intro p hp
  have h : env37856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37855_37856 : H12AffineEnvironment.transform 5 16 env37855 = env37856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env37855 == env37856) = true)

theorem identity37856 : scanCanonicalize (H12AffineFastState.compose env37856 (packedSelected [1,2,3,5,8,15] rootPS)) = affineNative (2^(6+1) ^^^ 21) := by decide +kernel

theorem selectedBound37856 : packedSelected [1,2,3,5,8,15] rootPS < 2^1333 := by decide +kernel

def env37857 : List Nat := [2,4,8,16,32,16,21,256,10,272,307,303,25,1,59,268,58,280,63,58,302,281,43,51,298,260,17,58,1,258,21,42,257,16,0,293]

theorem envBound37857 : H12AffineFastState.Bounded env37857 := by
  intro p hp
  have h : env37857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37856_37857 : H12AffineEnvironment.transform 6 21 env37856 = env37857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 21 env37856 == env37857) = true)

theorem identity37857 : scanCanonicalize (H12AffineFastState.compose env37857 (packedSelected [0,3,7,10,11] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound37857 : packedSelected [0,3,7,10,11] rootPS < 2^1333 := by decide +kernel

def env37858 : List Nat := [2,4,8,16,12,16,21,256,10,272,287,259,25,1,23,268,22,280,19,22,258,281,7,31,262,260,17,22,1,258,21,6,257,16,0,265]

theorem envBound37858 : H12AffineFastState.Bounded env37858 := by
  intro p hp
  have h : env37858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37857_37858 : H12AffineEnvironment.transform 4 12 env37857 = env37858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env37857 == env37858) = true)

theorem identity37858 : scanCanonicalize (H12AffineFastState.compose env37858 (packedSelected [1,3,5] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound37858 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env37859 : List Nat := [2,4,8,12,12,12,9,256,10,268,259,259,5,1,11,268,10,260,15,10,258,261,7,3,262,260,13,10,1,258,9,6,257,12,0,265]

theorem envBound37859 : H12AffineFastState.Bounded env37859 := by
  intro p hp
  have h : env37859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37858_37859 : H12AffineEnvironment.transform 3 12 env37858 = env37859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env37858 == env37859) = true)

theorem identity37859 : scanCanonicalize (H12AffineFastState.compose env37859 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound37859 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env37860 : List Nat := [2,4,8,12,12,12,9,5,10,9,6,6,5,1,11,9,10,1,15,10,7,0,7,3,3,1,13,10,1,7,9,6,4,12,0,12]

theorem envBound37860 : H12AffineFastState.Bounded env37860 := by
  intro p hp
  have h : env37860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37859_37860 : H12AffineEnvironment.transform 7 5 env37859 = env37860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env37859 == env37860) = true)

theorem identity37860 : scanCanonicalize (H12AffineFastState.compose env37860 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound37860 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37861 : List Nat := [2,4,2,6,6,6,3,5,0,3,6,6,5,1,1,3,0,1,5,0,7,0,7,3,3,1,7,0,1,7,3,6,4,6,0,6]

theorem envBound37861 : H12AffineFastState.Bounded env37861 := by
  intro p hp
  have h : env37861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37860_37861 : H12AffineEnvironment.transform 2 2 env37860 = env37861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env37860 == env37861) = true)

theorem identity37861 : scanCanonicalize (H12AffineFastState.compose env37861 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound37861 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37862 : List Nat := [2,2,2,0,0,0,3,3,0,3,0,0,3,1,1,3,0,1,3,0,1,0,1,3,3,1,1,0,1,1,3,0,2,0,0,0]

theorem envBound37862 : H12AffineFastState.Bounded env37862 := by
  intro p hp
  have h : env37862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37861_37862 : H12AffineEnvironment.transform 1 2 env37861 = env37862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env37861 == env37862) = true)

def env37863 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,2125,25,0,2392,269,106,396,2317,2393,2124,476,42,2384,2188,2150,2419,58,0,259,21,43,257,17,81,2588]

theorem envBound37863 : H12AffineFastState.Bounded env37863 := by
  intro p hp
  have h : env37863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37852_37863 : H12AffineEnvironment.transform 9 273 env37852 = env37863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env37852 == env37863) = true)

theorem identity37863 : scanCanonicalize (H12AffineFastState.compose env37863 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 127) := by decide +kernel

theorem selectedBound37863 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env37864 : List Nat := [2,4,8,16,32,64,128,127,512,110,2048,2125,25,0,2087,114,106,243,2162,2086,2124,163,42,2095,2188,2150,2060,58,0,124,21,43,126,17,81,2588]

theorem envBound37864 : H12AffineFastState.Bounded env37864 := by
  intro p hp
  have h : env37864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37863_37864 : H12AffineEnvironment.transform 7 127 env37863 = env37864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 127 env37863 == env37864) = true)

theorem identity37864 : scanCanonicalize (H12AffineFastState.compose env37864 (packedSelected [0,1,4,5,7,8,9,12,16,17,20] rootPS)) = affineNative (2^(10+1) ^^^ 545) := by decide +kernel

theorem selectedBound37864 : packedSelected [0,1,4,5,7,8,9,12,16,17,20] rootPS < 2^1333 := by decide +kernel

def env37865 : List Nat := [2,4,8,16,32,64,128,127,512,110,545,620,25,0,518,114,106,243,595,519,621,163,42,526,685,583,557,58,0,124,21,43,126,17,81,61]

theorem envBound37865 : H12AffineFastState.Bounded env37865 := by
  intro p hp
  have h : env37865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37864_37865 : H12AffineEnvironment.transform 10 545 env37864 = env37865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 545 env37864 == env37865) = true)

theorem identity37865 : scanCanonicalize (H12AffineFastState.compose env37865 (packedSelected [1,3,4,8,9,10,12,13,16,17,21] rootPS)) = affineNative (2^(8+1) ^^^ 7) := by decide +kernel

theorem selectedBound37865 : packedSelected [1,3,4,8,9,10,12,13,16,17,21] rootPS < 2^1333 := by decide +kernel

def env37866 : List Nat := [2,4,8,16,32,64,128,127,7,110,38,107,25,0,1,114,106,243,84,0,106,163,42,9,170,64,42,58,0,124,21,43,126,17,81,61]

theorem envBound37866 : H12AffineFastState.Bounded env37866 := by
  intro p hp
  have h : env37866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37865_37866 : H12AffineEnvironment.transform 8 7 env37865 = env37866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 7 env37865 == env37866) = true)

theorem identity37866 : scanCanonicalize (H12AffineFastState.compose env37866 (packedSelected [0,3,7,11] rootPS)) = affineNative (2^(6+1) ^^^ 127) := by decide +kernel

theorem selectedBound37866 : packedSelected [0,3,7,11] rootPS < 2^1333 := by decide +kernel

def env37867 : List Nat := [2,4,8,16,32,64,127,127,7,110,38,107,25,0,1,114,106,12,84,0,106,92,42,9,85,64,42,58,0,124,21,43,126,17,81,61]

theorem envBound37867 : H12AffineFastState.Bounded env37867 := by
  intro p hp
  have h : env37867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37866_37867 : H12AffineEnvironment.transform 6 127 env37866 = env37867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 127 env37866 == env37867) = true)

def env37868 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,25,1297,5124,1053,107,1180,4416,5125,4097,476,1338,5133,5584,4138,4414,59,1297,6479,21,1339,257,1280,1344,5952]

theorem envBound37868 : H12AffineFastState.Bounded env37868 := by
  intro p hp
  have h : env37868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37850_37868 : H12AffineEnvironment.transform 15 1053 env37850 = env37868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1053 env37850 == env37868) = true)

theorem identity37868 : scanCanonicalize (H12AffineFastState.compose env37868 (packedSelected [0,1,2,4,7,9,10,11,15,17,19,21,23,24,28] rootPS)) = affineNative (2^(11+1) ^^^ 3431) := by decide +kernel

theorem selectedBound37868 : packedSelected [0,1,2,4,7,9,10,11,15,17,19,21,23,24,28] rootPS < 2^1333 := by decide +kernel

def env37869 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3431,25,1297,2403,1053,107,1180,3111,2402,3430,476,1338,2410,2231,3405,3161,59,1297,1064,21,1339,257,1280,1344,2599]

theorem envBound37869 : H12AffineFastState.Bounded env37869 := by
  intro p hp
  have h : env37869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37868_37869 : H12AffineEnvironment.transform 11 3431 env37868 = env37869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3431 env37868 == env37869) = true)

def env37870 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,2167,25,1,2403,269,107,396,2359,2402,2166,476,42,2410,2231,2141,2377,59,1,312,21,43,257,16,80,2599]

theorem envBound37870 : H12AffineFastState.Bounded env37870 := by
  intro p hp
  have h : env37870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37869_37870 : H12AffineEnvironment.transform 9 272 env37869 = env37870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env37869 == env37870) = true)

theorem identity37870 : scanCanonicalize (H12AffineFastState.compose env37870 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 345) := by decide +kernel

theorem selectedBound37870 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env37871 : List Nat := [2,4,8,16,32,64,128,256,512,272,345,302,25,1,58,269,107,396,110,59,303,476,42,51,494,260,16,59,1,312,21,43,257,16,80,894]

theorem envBound37871 : H12AffineFastState.Bounded env37871 := by
  intro p hp
  have h : env37871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37870_37871 : H12AffineEnvironment.transform 10 345 env37870 = env37871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 345 env37870 == env37871) = true)

theorem identity37871 : scanCanonicalize (H12AffineFastState.compose env37871 (packedSelected [1,3,4,8,9,10,12,16,17] rootPS)) = affineNative (2^(8+1) ^^^ 91) := by decide +kernel

theorem selectedBound37871 : packedSelected [1,3,4,8,9,10,12,16,17] rootPS < 2^1333 := by decide +kernel

def env37872 : List Nat := [2,4,8,16,32,64,128,256,91,272,345,302,25,1,58,269,107,396,110,59,303,476,42,51,494,260,16,59,1,312,21,43,257,16,80,293]

theorem envBound37872 : H12AffineFastState.Bounded env37872 := by
  intro p hp
  have h : env37872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37871_37872 : H12AffineEnvironment.transform 8 91 env37871 = env37872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 91 env37871 == env37872) = true)

theorem identity37872 : scanCanonicalize (H12AffineFastState.compose env37872 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound37872 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env37873 : List Nat := [2,4,8,16,32,16,128,256,11,272,265,302,25,1,58,269,59,396,62,59,303,396,42,51,446,260,16,59,1,312,21,43,257,16,0,293]

theorem envBound37873 : H12AffineFastState.Bounded env37873 := by
  intro p hp
  have h : env37873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37872_37873 : H12AffineEnvironment.transform 5 16 env37872 = env37873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env37872 == env37873) = true)

theorem identity37873 : scanCanonicalize (H12AffineFastState.compose env37873 (packedSelected [1,2,3,5,8,15] rootPS)) = affineNative (2^(7+1) ^^^ 128) := by decide +kernel

theorem selectedBound37873 : packedSelected [1,2,3,5,8,15] rootPS < 2^1333 := by decide +kernel

def env37874 : List Nat := [2,4,8,16,32,16,128,128,11,144,137,174,25,1,58,141,59,12,62,59,175,12,42,51,62,132,16,59,1,184,21,43,129,16,0,165]

theorem envBound37874 : H12AffineFastState.Bounded env37874 := by
  intro p hp
  have h : env37874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37873_37874 : H12AffineEnvironment.transform 7 128 env37873 = env37874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 128 env37873 == env37874) = true)

theorem identity37874 : scanCanonicalize (H12AffineFastState.compose env37874 (packedSelected [0,2,3,7,10,11] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound37874 : packedSelected [0,2,3,7,10,11] rootPS < 2^1333 := by decide +kernel

def env37875 : List Nat := [2,4,8,7,32,7,128,128,11,135,137,174,14,1,45,141,44,12,41,44,175,12,42,36,41,132,7,44,1,175,2,43,129,7,0,165]

theorem envBound37875 : H12AffineFastState.Bounded env37875 := by
  intro p hp
  have h : env37875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37874_37875 : H12AffineEnvironment.transform 3 7 env37874 = env37875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env37874 == env37875) = true)

theorem identity37875 : scanCanonicalize (H12AffineFastState.compose env37875 (packedSelected [1,2,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound37875 : packedSelected [1,2,3,5] rootPS < 2^1333 := by decide +kernel

def env37876 : List Nat := [2,4,8,7,32,7,9,9,11,14,0,39,14,1,45,4,44,12,41,44,38,12,42,36,41,13,7,44,1,38,2,43,8,7,0,44]

theorem envBound37876 : H12AffineFastState.Bounded env37876 := by
  intro p hp
  have h : env37876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37875_37876 : H12AffineEnvironment.transform 6 9 env37875 = env37876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env37875 == env37876) = true)

theorem identity37876 : scanCanonicalize (H12AffineFastState.compose env37876 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound37876 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env37877 : List Nat := [2,4,8,7,7,7,9,9,11,14,0,0,14,1,10,4,11,12,14,11,1,12,13,3,14,13,7,11,1,1,2,12,8,7,0,11]

theorem envBound37877 : H12AffineFastState.Bounded env37877 := by
  intro p hp
  have h : env37877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37876_37877 : H12AffineEnvironment.transform 4 7 env37876 = env37877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env37876 == env37877) = true)

theorem identity37877 : scanCanonicalize (H12AffineFastState.compose env37877 (packedSelected [0,3] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound37877 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env37878 : List Nat := [2,4,5,7,7,7,4,4,6,3,0,0,3,1,7,4,6,1,3,6,1,1,0,3,3,0,7,6,1,1,2,1,5,7,0,6]

theorem envBound37878 : H12AffineFastState.Bounded env37878 := by
  intro p hp
  have h : env37878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37877_37878 : H12AffineEnvironment.transform 2 5 env37877 = env37878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env37877 == env37878) = true)

theorem identity37878 : scanCanonicalize (H12AffineFastState.compose env37878 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound37878 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37879 : List Nat := [2,2,3,1,1,1,2,2,0,3,0,0,3,1,1,2,0,1,3,0,1,1,0,3,3,0,1,0,1,1,2,1,3,1,0,0]

theorem envBound37879 : H12AffineFastState.Bounded env37879 := by
  intro p hp
  have h : env37879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37878_37879 : H12AffineEnvironment.transform 1 2 env37878 = env37879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env37878 == env37879) = true)

def env37880 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,2166,25,0,2403,268,107,397,2358,2402,2167,476,43,2410,2231,2140,2376,59,0,313,21,42,257,17,81,2599]

theorem envBound37880 : H12AffineFastState.Bounded env37880 := by
  intro p hp
  have h : env37880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37869_37880 : H12AffineEnvironment.transform 9 273 env37869 = env37880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env37869 == env37880) = true)

theorem identity37880 : scanCanonicalize (H12AffineFastState.compose env37880 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 126) := by decide +kernel

theorem selectedBound37880 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env37881 : List Nat := [2,4,8,16,32,64,128,126,512,111,2048,2166,25,0,2077,114,107,243,2120,2076,2167,162,43,2068,2231,2140,2102,59,0,71,21,42,127,17,81,2599]

theorem envBound37881 : H12AffineFastState.Bounded env37881 := by
  intro p hp
  have h : env37881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37880_37881 : H12AffineEnvironment.transform 7 126 env37880 = env37881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 126 env37880 == env37881) = true)

theorem identity37881 : scanCanonicalize (H12AffineFastState.compose env37881 (packedSelected [0,1,4,5,7,8,9,12,16,17,20] rootPS)) = affineNative (2^(10+1) ^^^ 544) := by decide +kernel

theorem selectedBound37881 : packedSelected [0,1,4,5,7,8,9,12,16,17,20] rootPS < 2^1333 := by decide +kernel

def env37882 : List Nat := [2,4,8,16,32,64,128,126,512,111,544,598,25,0,573,114,107,243,616,572,599,162,43,564,663,636,534,59,0,71,21,42,127,17,81,7]

theorem envBound37882 : H12AffineFastState.Bounded env37882 := by
  intro p hp
  have h : env37882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37881_37882 : H12AffineEnvironment.transform 10 544 env37881 = env37882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 544 env37881 == env37882) = true)

theorem identity37882 : scanCanonicalize (H12AffineFastState.compose env37882 (packedSelected [1,3,4,8,9,10,12,13,16,17,21] rootPS)) = affineNative (2^(8+1) ^^^ 60) := by decide +kernel

theorem selectedBound37882 : packedSelected [1,3,4,8,9,10,12,13,16,17,21] rootPS < 2^1333 := by decide +kernel

def env37883 : List Nat := [2,4,8,16,32,64,128,126,60,111,28,106,25,0,1,114,107,243,84,0,107,162,43,8,171,64,42,59,0,71,21,42,127,17,81,7]

theorem envBound37883 : H12AffineFastState.Bounded env37883 := by
  intro p hp
  have h : env37883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37882_37883 : H12AffineEnvironment.transform 8 60 env37882 = env37883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 60 env37882 == env37883) = true)

theorem identity37883 : scanCanonicalize (H12AffineFastState.compose env37883 (packedSelected [0,3,7,11] rootPS)) = affineNative (2^(6+1) ^^^ 69) := by decide +kernel

theorem selectedBound37883 : packedSelected [0,3,7,11] rootPS < 2^1333 := by decide +kernel

def env37884 : List Nat := [2,4,8,16,32,64,69,126,60,111,28,106,25,0,1,114,107,54,84,0,107,103,43,8,110,64,42,59,0,71,21,42,127,17,81,7]

theorem envBound37884 : H12AffineFastState.Bounded env37884 := by
  intro p hp
  have h : env37884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37883_37884 : H12AffineEnvironment.transform 6 69 env37883 = env37884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 69 env37883 == env37884) = true)

def env37885 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,524288,32769,4097,61648,91183,123165,533641,614527,385202,90414,545088,96346,25884,594023,257,1280,1344,525824]

theorem envBound37885 : H12AffineFastState.Bounded env37885 := by
  intro p hp
  have h : env37885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37386_37885 : H12AffineEnvironment.transform 23 123165 env37386 = env37885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 123165 env37386 == env37885) = true)

def env37886 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,21584,32769,4097,61648,91183,123165,28889,78895,385202,90414,1296,96346,25884,82999,257,1280,1344,21072]

theorem envBound37886 : H12AffineFastState.Bounded env37886 := by
  intro p hp
  have h : env37886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37885_37886 : H12AffineEnvironment.transform 18 21584 env37885 = env37886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21584 env37885 == env37886) = true)

theorem identity37886 : scanCanonicalize (H12AffineFastState.compose env37886 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 25676) := by decide +kernel

theorem selectedBound37886 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env37887 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,25676,65536,74863,262144,21584,25677,4097,5276,91183,66897,28889,78895,328958,90414,1296,96346,25884,82999,257,1280,1344,21072]

theorem envBound37887 : H12AffineFastState.Bounded env37887 := by
  intro p hp
  have h : env37887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37886_37887 : H12AffineEnvironment.transform 14 25676 env37886 = env37887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25676 env37886 == env37887) = true)

def env37888 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74863,262144,4416,8541,4097,5276,74047,66897,13769,78895,328958,74814,1296,81226,8204,65831,257,1280,1344,5952]

theorem envBound37888 : H12AffineFastState.Bounded env37888 := by
  intro p hp
  have h : env37888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37887_37888 : H12AffineEnvironment.transform 13 1296 env37887 = env37888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env37887 == env37888) = true)

def env37889 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74863,65664,4416,8541,4097,5276,74047,66897,13769,78895,1150,74814,1296,81226,8204,65831,257,1280,1344,5952]

theorem envBound37889 : H12AffineFastState.Bounded env37889 := by
  intro p hp
  have h : env37889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37888_37889 : H12AffineEnvironment.transform 17 65664 env37888 = env37889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env37888 == env37889) = true)

theorem identity37889 : scanCanonicalize (H12AffineFastState.compose env37889 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9278) := by decide +kernel

theorem selectedBound37889 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env37890 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,9278,81,9406,4416,8541,4097,5276,1281,8559,13769,4113,1150,0,1296,6516,8204,9497,257,1280,1344,5952]

theorem envBound37890 : H12AffineFastState.Bounded env37890 := by
  intro p hp
  have h : env37890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37889_37890 : H12AffineEnvironment.transform 15 9278 env37889 = env37890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9278 env37889 == env37890) = true)

def env37891 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,8192,0,8540,8494,81,8622,4416,8541,4097,4492,17,8559,12505,4113,366,0,0,6516,8204,8201,257,16,80,4688]

theorem envBound37891 : H12AffineFastState.Bounded env37891 := by
  intro p hp
  have h : env37891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37890_37891 : H12AffineEnvironment.transform 9 272 env37890 = env37891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env37890 == env37891) = true)

theorem identity37891 : scanCanonicalize (H12AffineFastState.compose env37891 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 72) := by decide +kernel

theorem selectedBound37891 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

end H12CloudChart2