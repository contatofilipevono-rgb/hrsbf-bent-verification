import H12CloudChart2Data055

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity13689 : scanCanonicalize (H12AffineFastState.compose env13689 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound13689 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13690 : List Nat := [2,4,8,16,32,17,128,37,136,53,2048,0,8192,1,8232,8323,1,2049,53,8233,0,10249,17,139,8328,16,8233,1,0,8232,20,137,37,10401,1,136]

theorem envBound13690 : H12AffineFastState.Bounded env13690 := by
  intro p hp
  have h : env13690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13689_13690 : H12AffineEnvironment.transform 7 37 env13689 = env13690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env13689 == env13690) = true)

theorem identity13690 : scanCanonicalize (H12AffineFastState.compose env13690 (packedSelected [2,4] rootPS)) = affineNative (2^(12+1) ^^^ 2088) := by decide +kernel

theorem selectedBound13690 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env13691 : List Nat := [2,4,8,16,32,17,128,37,136,53,2048,0,2088,1,2048,2219,1,2049,53,2049,0,33,17,139,2208,16,2049,1,0,2048,20,137,37,137,1,136]

theorem envBound13691 : H12AffineFastState.Bounded env13691 := by
  intro p hp
  have h : env13691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13690_13691 : H12AffineEnvironment.transform 12 2088 env13690 = env13691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2088 env13690 == env13691) = true)

def leafEnv13691 : List Nat := [2,4,8,16,32,17,128,37,136,53,2048,0,2088,1,2048,2219,1,2049,53,2049,0,33,17,139,20,2208,1,16,2049,1,0,2048,20,137,37,137,4,2082,1,136,0,0,1]

def active13691 : List Nat := [0,1,2,3,4,6,10]

def tree13691 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13691 : H12WitnessSearch.Good tree13691 := H12GlobalWitnessIndex.good

theorem leafIdentity13691 : H12AffineFastState.composeSystem env13691 rootObs = leafEnv13691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13691 rootObs == leafEnv13691) = true)

theorem terminalChecked13691 : H12PackedTerminal.terminalCheckFast leafEnv13691 active13691 tree13691 = true := by decide +kernel

def env13692 : List Nat := [2,4,8,16,32,17,128,256,136,273,2048,1,8192,0,8461,65536,0,262144,273,8460,1,4194304,17,73736,8328,16,4456708,0,1,4270471,21,74031,256,4194701,0,136]

theorem envBound13692 : H12AffineFastState.Bounded env13692 := by
  intro p hp
  have h : env13692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13681_13692 : H12AffineEnvironment.transform 9 273 env13681 = env13692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env13681 == env13692) = true)

theorem identity13692 : scanCanonicalize (H12AffineFastState.compose env13692 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound13692 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13693 : List Nat := [2,4,8,16,32,17,128,256,136,273,2048,1,8192,0,8461,8323,0,262144,273,8460,1,4194304,17,139,8328,16,4456708,0,1,4196612,21,428,256,4194701,0,136]

theorem envBound13693 : H12AffineFastState.Bounded env13693 := by
  intro p hp
  have h : env13693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13692_13693 : H12AffineEnvironment.transform 15 8323 env13692 = env13693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env13692 == env13693) = true)

theorem identity13693 : scanCanonicalize (H12AffineFastState.compose env13693 (packedSelected [3] rootPS)) = affineNative (2^(17+1) ^^^ 2340) := by decide +kernel

theorem selectedBound13693 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env13694 : List Nat := [2,4,8,16,32,17,128,256,136,273,2048,1,8192,0,8461,8323,0,2340,273,8460,1,4194304,17,139,8328,16,4196384,0,1,4196612,21,428,256,4194701,0,136]

theorem envBound13694 : H12AffineFastState.Bounded env13694 := by
  intro p hp
  have h : env13694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13693_13694 : H12AffineEnvironment.transform 17 2340 env13693 = env13694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2340 env13693 == env13694) = true)

def env13695 : List Nat := [2,4,8,16,32,17,128,256,136,273,2048,1,8192,0,8461,8323,0,2340,273,8460,1,10248,17,139,8328,16,8232,0,1,8460,21,428,256,10629,0,136]

theorem envBound13695 : H12AffineFastState.Bounded env13695 := by
  intro p hp
  have h : env13695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13694_13695 : H12AffineEnvironment.transform 21 10248 env13694 = env13695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10248 env13694 == env13695) = true)

theorem identity13695 : scanCanonicalize (H12AffineFastState.compose env13695 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 2088) := by decide +kernel

theorem selectedBound13695 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13696 : List Nat := [2,4,8,16,32,17,128,256,136,273,2048,1,2088,0,2341,2219,0,2340,273,2340,1,32,17,139,2208,16,2048,0,1,2340,21,428,256,429,0,136]

theorem envBound13696 : H12AffineFastState.Bounded env13696 := by
  intro p hp
  have h : env13696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13695_13696 : H12AffineEnvironment.transform 12 2088 env13695 = env13696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2088 env13695 == env13696) = true)

theorem identity13696 : scanCanonicalize (H12AffineFastState.compose env13696 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 141) := by decide +kernel

theorem selectedBound13696 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13697 : List Nat := [2,4,8,16,32,17,128,141,136,156,2048,1,2088,0,2216,2219,0,2217,156,2217,1,32,17,139,2208,16,2048,0,1,2217,21,33,141,32,0,136]

theorem envBound13697 : H12AffineFastState.Bounded env13697 := by
  intro p hp
  have h : env13697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13696_13697 : H12AffineEnvironment.transform 7 141 env13696 = env13697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 141 env13696 == env13697) = true)

theorem identity13697 : scanCanonicalize (H12AffineFastState.compose env13697 (packedSelected [7] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound13697 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env13698 : List Nat := [2,4,8,16,32,17,41,36,33,53,2048,1,2088,0,2049,2050,0,2048,53,2048,1,32,17,34,2057,16,2048,0,1,2048,21,33,36,32,0,33]

theorem envBound13698 : H12AffineFastState.Bounded env13698 := by
  intro p hp
  have h : env13698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13697_13698 : H12AffineEnvironment.transform 6 41 env13697 = env13698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env13697 == env13698) = true)

def leafEnv13698 : List Nat := [2,4,8,16,32,17,41,36,33,53,2048,1,2088,0,2049,2050,0,2048,53,2048,1,32,17,34,21,2057,1,16,2048,0,1,2048,21,33,36,32,4,2082,0,33,0,1,1]

def active13698 : List Nat := [0,1,2,3,4,10]

def tree13698 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13698 : H12WitnessSearch.Good tree13698 := H12GlobalWitnessIndex.good

theorem leafIdentity13698 : H12AffineFastState.composeSystem env13698 rootObs = leafEnv13698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13698 rootObs == leafEnv13698) = true)

theorem terminalChecked13698 : H12PackedTerminal.terminalCheckFast leafEnv13698 active13698 tree13698 = true := by decide +kernel

def env13699 : List Nat := [2,4,8,16,32,17,128,256,136,273,2048,1,8192,0,8461,8323,0,2340,273,8460,1,10249,17,139,8328,16,8233,0,1,8461,21,428,256,10628,0,136]

theorem envBound13699 : H12AffineFastState.Bounded env13699 := by
  intro p hp
  have h : env13699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13694_13699 : H12AffineEnvironment.transform 21 10249 env13694 = env13699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10249 env13694 == env13699) = true)

theorem identity13699 : scanCanonicalize (H12AffineFastState.compose env13699 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound13699 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13700 : List Nat := [2,4,8,16,32,17,128,37,136,52,2048,1,8192,0,8232,8323,0,2049,52,8233,1,10249,17,139,8328,16,8233,0,1,8232,21,137,37,10401,0,136]

theorem envBound13700 : H12AffineFastState.Bounded env13700 := by
  intro p hp
  have h : env13700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13699_13700 : H12AffineEnvironment.transform 7 37 env13699 = env13700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env13699 == env13700) = true)

theorem identity13700 : scanCanonicalize (H12AffineFastState.compose env13700 (packedSelected [2,4] rootPS)) = affineNative (2^(12+1) ^^^ 2088) := by decide +kernel

theorem selectedBound13700 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env13701 : List Nat := [2,4,8,16,32,17,128,37,136,52,2048,1,2088,0,2048,2219,0,2049,52,2049,1,33,17,139,2208,16,2049,0,1,2048,21,137,37,137,0,136]

theorem envBound13701 : H12AffineFastState.Bounded env13701 := by
  intro p hp
  have h : env13701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13700_13701 : H12AffineEnvironment.transform 12 2088 env13700 = env13701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2088 env13700 == env13701) = true)

def leafEnv13701 : List Nat := [2,4,8,16,32,17,128,37,136,52,2048,1,2088,0,2048,2219,0,2049,52,2049,1,33,17,139,21,2208,1,16,2049,0,1,2048,21,137,37,137,4,2082,0,136,0,1,1]

def active13701 : List Nat := [0,1,2,3,4,6,10]

def tree13701 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13701 : H12WitnessSearch.Good tree13701 := H12GlobalWitnessIndex.good

theorem leafIdentity13701 : H12AffineFastState.composeSystem env13701 rootObs = leafEnv13701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13701 rootObs == leafEnv13701) = true)

theorem terminalChecked13701 : H12PackedTerminal.terminalCheckFast leafEnv13701 active13701 tree13701 = true := by decide +kernel

def env13702 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,32768,65536,1344,262144,524288,32769,1345,4194304,65,98565,8328,525329,134217728,1345,524608,1073741824,1284,4294967296,256,4299260335,139198532,512]

theorem envBound13702 : H12AffineFastState.Bounded env13702 := by
  intro p hp
  have h : env13702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13650_13702 : H12AffineEnvironment.transform 13 1345 env13650 = env13702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env13650 == env13702) = true)

theorem identity13702 : scanCanonicalize (H12AffineFastState.compose env13702 (packedSelected [9,22] rootPS)) = affineNative (2^(26+1) ^^^ 4456788) := by decide +kernel

theorem selectedBound13702 : packedSelected [9,22] rootPS < 2^1333 := by decide +kernel

def env13703 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,32768,65536,1344,262144,524288,32769,1345,4194304,65,98565,8328,525329,4456788,1345,524608,1073741824,1284,4294967296,256,4299260335,524560,512]

theorem envBound13703 : H12AffineFastState.Bounded env13703 := by
  intro p hp
  have h : env13703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13702_13703 : H12AffineEnvironment.transform 26 4456788 env13702 = env13703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 4456788 env13702 == env13703) = true)

def env13704 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,32768,65536,1344,262144,1104,32769,1345,4194304,65,98565,8328,65,4456788,1345,1296,1073741824,1284,4294967296,256,4299260335,1344,512]

theorem envBound13704 : H12AffineFastState.Bounded env13704 := by
  intro p hp
  have h : env13704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13703_13704 : H12AffineEnvironment.transform 18 1104 env13703 = env13704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1104 env13703 == env13704) = true)

theorem identity13704 : scanCanonicalize (H12AffineFastState.compose env13704 (packedSelected [8,10,13,15] rootPS)) = affineNative (2^(29+1) ^^^ 4295170) := by decide +kernel

theorem selectedBound13704 : packedSelected [8,10,13,15] rootPS < 2^1333 := by decide +kernel

def env13705 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,32768,65536,1344,262144,1104,32769,1345,4194304,65,98565,8328,65,4456788,1345,1296,4295170,1284,4294967296,256,4299260335,1344,512]

theorem envBound13705 : H12AffineFastState.Bounded env13705 := by
  intro p hp
  have h : env13705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13704_13705 : H12AffineEnvironment.transform 29 4295170 env13704 = env13705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4295170 env13704 == env13705) = true)

theorem identity13705 : scanCanonicalize (H12AffineFastState.compose env13705 (packedSelected [3,8,10,13,17] rootPS)) = affineNative (2^(8+1) ^^^ 216) := by decide +kernel

theorem selectedBound13705 : packedSelected [3,8,10,13,17] rootPS < 2^1333 := by decide +kernel

def env13706 : List Nat := [2,4,8,16,32,64,128,256,216,1024,2048,1345,8192,1345,32768,65536,1344,262144,1104,32769,1345,4194304,65,98565,8328,65,4456788,1345,1296,4294874,1284,4294967296,256,4299260335,1344,216]

theorem envBound13706 : H12AffineFastState.Bounded env13706 := by
  intro p hp
  have h : env13706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13705_13706 : H12AffineEnvironment.transform 8 216 env13705 = env13706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env13705 == env13706) = true)

def env13707 : List Nat := [2,4,8,16,32,64,128,256,216,1024,2048,1345,8192,1345,32768,65536,1344,262144,1104,32769,1345,41168,65,98565,8328,65,303492,1345,1296,75786,1284,4294967296,256,4295041407,1344,216]

theorem envBound13707 : H12AffineFastState.Bounded env13707 := by
  intro p hp
  have h : env13707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13706_13707 : H12AffineEnvironment.transform 21 41168 env13706 = env13707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41168 env13706 == env13707) = true)

theorem identity13707 : scanCanonicalize (H12AffineFastState.compose env13707 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 98418) := by decide +kernel

theorem selectedBound13707 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env13708 : List Nat := [2,4,8,16,32,64,128,256,216,1024,2048,1345,8192,1345,32768,65536,1344,262144,1104,32769,1345,41168,65,98565,8328,65,303492,1345,1296,75786,1284,98418,256,41229,1344,216]

theorem envBound13708 : H12AffineFastState.Bounded env13708 := by
  intro p hp
  have h : env13708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13707_13708 : H12AffineEnvironment.transform 31 98418 env13707 = env13708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 98418 env13707 == env13708) = true)

def env13709 : List Nat := [2,4,8,16,32,64,128,256,216,1024,2048,1345,8192,1345,32768,65536,1344,32984,1104,32769,1345,41168,65,98565,8328,65,8540,1345,1296,75786,1284,98418,256,41229,1344,216]

theorem envBound13709 : H12AffineFastState.Bounded env13709 := by
  intro p hp
  have h : env13709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13708_13709 : H12AffineEnvironment.transform 17 32984 env13708 = env13709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32984 env13708 == env13709) = true)

theorem identity13709 : scanCanonicalize (H12AffineFastState.compose env13709 (packedSelected [7] rootPS)) = affineNative (2^(14+1) ^^^ 8580) := by decide +kernel

theorem selectedBound13709 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env13710 : List Nat := [2,4,8,16,32,64,128,256,216,1024,2048,1345,8192,1345,8580,65536,1344,8540,1104,8581,1345,340,65,73857,8328,65,8540,1345,1296,75786,1284,74230,256,137,1344,216]

theorem envBound13710 : H12AffineFastState.Bounded env13710 := by
  intro p hp
  have h : env13710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13709_13710 : H12AffineEnvironment.transform 14 8580 env13709 = env13710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8580 env13709 == env13710) = true)

def env13711 : List Nat := [2,4,8,16,32,64,128,256,216,1024,0,1345,8192,1345,8580,65536,1344,8540,1104,8581,1345,340,65,73857,8328,65,8540,1345,1296,73738,1284,74230,256,137,1344,216]

theorem envBound13711 : H12AffineFastState.Bounded env13711 := by
  intro p hp
  have h : env13711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13710_13711 : H12AffineEnvironment.transform 10 0 env13710 = env13711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env13710 == env13711) = true)

theorem identity13711 : scanCanonicalize (H12AffineFastState.compose env13711 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 171) := by decide +kernel

theorem selectedBound13711 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13712 : List Nat := [2,4,8,16,32,64,128,256,216,1024,0,1345,8192,1345,8580,171,1344,8540,1104,8581,1345,340,65,8234,8328,65,8540,1345,1296,8353,1284,8541,256,137,1344,216]

theorem envBound13712 : H12AffineFastState.Bounded env13712 := by
  intro p hp
  have h : env13712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13711_13712 : H12AffineEnvironment.transform 15 171 env13711 = env13712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 171 env13711 == env13712) = true)

theorem identity13712 : scanCanonicalize (H12AffineFastState.compose env13712 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 161) := by decide +kernel

theorem selectedBound13712 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env13713 : List Nat := [2,4,8,16,32,64,128,256,216,1024,0,1345,161,1345,293,171,1344,509,1104,292,1345,340,65,139,41,65,509,1345,1296,0,1284,508,256,137,1344,216]

theorem envBound13713 : H12AffineFastState.Bounded env13713 := by
  intro p hp
  have h : env13713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13712_13713 : H12AffineEnvironment.transform 12 161 env13712 = env13713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env13712 == env13713) = true)

def env13714 : List Nat := [2,4,8,16,32,16,128,256,136,1024,0,1297,161,1297,293,171,1296,429,1024,292,1297,260,17,139,41,17,429,1297,1296,0,1284,428,256,137,1296,136]

theorem envBound13714 : H12AffineFastState.Bounded env13714 := by
  intro p hp
  have h : env13714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13713_13714 : H12AffineEnvironment.transform 5 16 env13713 = env13714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13713 == env13714) = true)

def env13715 : List Nat := [2,4,8,16,32,17,128,256,137,1024,0,1296,161,1296,293,171,1297,428,1025,292,1296,261,16,139,41,16,428,1296,1296,0,1284,429,256,137,1297,137]

theorem envBound13715 : H12AffineFastState.Bounded env13715 := by
  intro p hp
  have h : env13715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13713_13715 : H12AffineEnvironment.transform 5 17 env13713 = env13715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env13713 == env13715) = true)

theorem identity13715 : scanCanonicalize (H12AffineFastState.compose env13715 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 134) := by decide +kernel

theorem selectedBound13715 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13716 : List Nat := [2,4,8,16,32,17,128,134,137,1024,0,1174,161,1174,163,171,1175,42,1025,162,1174,131,16,139,41,16,42,1174,1174,0,1154,43,134,137,1175,137]

theorem envBound13716 : H12AffineFastState.Bounded env13716 := by
  intro p hp
  have h : env13716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13715_13716 : H12AffineEnvironment.transform 7 134 env13715 = env13716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 134 env13715 == env13716) = true)

theorem identity13716 : scanCanonicalize (H12AffineFastState.compose env13716 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound13716 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env13717 : List Nat := [2,4,8,16,32,17,9,15,0,1024,0,1055,40,1055,42,34,1054,42,1025,43,1055,10,16,2,41,16,42,1055,1055,0,1035,43,15,0,1054,0]

theorem envBound13717 : H12AffineFastState.Bounded env13717 := by
  intro p hp
  have h : env13717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13716_13717 : H12AffineEnvironment.transform 6 9 env13716 = env13717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env13716 == env13717) = true)

def env13718 : List Nat := [2,4,8,16,0,17,9,15,0,1024,0,1055,8,1055,10,2,1054,10,1025,11,1055,10,16,2,9,16,10,1055,1055,0,1035,11,15,0,1054,0]

theorem envBound13718 : H12AffineFastState.Bounded env13718 := by
  intro p hp
  have h : env13718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13717_13718 : H12AffineEnvironment.transform 4 0 env13717 = env13718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13717 == env13718) = true)

theorem identity13718 : scanCanonicalize (H12AffineFastState.compose env13718 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound13718 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13719 : List Nat := [2,4,8,10,0,11,9,15,0,1024,0,1029,8,1029,10,2,1028,10,1025,11,1029,10,10,2,9,10,10,1029,1029,0,1035,11,15,0,1028,0]

theorem envBound13719 : H12AffineFastState.Bounded env13719 := by
  intro p hp
  have h : env13719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13718_13719 : H12AffineEnvironment.transform 3 10 env13718 = env13719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env13718 == env13719) = true)

def leafEnv13719 : List Nat := [2,4,8,10,0,11,9,15,0,1024,0,1029,8,1029,10,2,1028,10,1025,11,1029,10,10,2,1034,9,1,10,10,1029,1029,0,1035,11,15,0,4,2,1028,0,0,1029,1]

def active13719 : List Nat := [0,1,2,9]

def tree13719 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13719 : H12WitnessSearch.Good tree13719 := H12GlobalWitnessIndex.good

theorem leafIdentity13719 : H12AffineFastState.composeSystem env13719 rootObs = leafEnv13719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13719 rootObs == leafEnv13719) = true)

theorem terminalChecked13719 : H12PackedTerminal.terminalCheckFast leafEnv13719 active13719 tree13719 = true := by decide +kernel

def env13720 : List Nat := [2,4,8,16,1,17,9,15,0,1024,0,1055,9,1055,11,3,1054,11,1025,10,1055,10,16,2,8,16,11,1055,1055,0,1035,10,15,0,1054,0]

theorem envBound13720 : H12AffineFastState.Bounded env13720 := by
  intro p hp
  have h : env13720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13717_13720 : H12AffineEnvironment.transform 4 1 env13717 = env13720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13717 == env13720) = true)

theorem identity13720 : scanCanonicalize (H12AffineFastState.compose env13720 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound13720 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13721 : List Nat := [2,4,8,0,1,1,9,15,0,1024,0,1039,9,1039,11,3,1038,11,1025,10,1039,10,0,2,8,0,11,1039,1039,0,1035,10,15,0,1038,0]

theorem envBound13721 : H12AffineFastState.Bounded env13721 := by
  intro p hp
  have h : env13721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13720_13721 : H12AffineEnvironment.transform 3 0 env13720 = env13721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env13720 == env13721) = true)

def leafEnv13721 : List Nat := [2,4,8,0,1,1,9,15,0,1024,0,1039,9,1039,11,3,1038,11,1025,10,1039,10,0,2,1034,8,1,0,11,1039,1039,0,1035,10,15,0,4,3,1038,0,0,1039,1]

def active13721 : List Nat := [0,1,2,9]

def tree13721 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13721 : H12WitnessSearch.Good tree13721 := H12GlobalWitnessIndex.good

theorem leafIdentity13721 : H12AffineFastState.composeSystem env13721 rootObs = leafEnv13721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13721 rootObs == leafEnv13721) = true)

theorem terminalChecked13721 : H12PackedTerminal.terminalCheckFast leafEnv13721 active13721 tree13721 = true := by decide +kernel

def env13722 : List Nat := [2,4,8,16,32,64,128,256,216,1024,1,1345,8192,1345,8580,65536,1344,8540,1104,8581,1345,340,65,73857,8328,65,8540,1345,1296,73739,1284,74230,256,137,1344,216]

theorem envBound13722 : H12AffineFastState.Bounded env13722 := by
  intro p hp
  have h : env13722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13710_13722 : H12AffineEnvironment.transform 10 1 env13710 = env13722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env13710 == env13722) = true)

theorem identity13722 : scanCanonicalize (H12AffineFastState.compose env13722 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 160) := by decide +kernel

theorem selectedBound13722 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13723 : List Nat := [2,4,8,16,32,64,128,256,216,1024,1,1345,160,1345,292,65536,1344,508,1104,293,1345,340,65,65569,40,65,508,1345,1296,65707,1284,65878,256,137,1344,216]

theorem envBound13723 : H12AffineFastState.Bounded env13723 := by
  intro p hp
  have h : env13723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13722_13723 : H12AffineEnvironment.transform 12 160 env13722 = env13723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env13722 == env13723) = true)

theorem identity13723 : scanCanonicalize (H12AffineFastState.compose env13723 (packedSelected [1,3,8] rootPS)) = affineNative (2^(15+1) ^^^ 170) := by decide +kernel

theorem selectedBound13723 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env13724 : List Nat := [2,4,8,16,32,64,128,256,216,1024,1,1345,160,1345,292,170,1344,508,1104,293,1345,340,65,139,40,65,508,1345,1296,1,1284,508,256,137,1344,216]

theorem envBound13724 : H12AffineFastState.Bounded env13724 := by
  intro p hp
  have h : env13724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13723_13724 : H12AffineEnvironment.transform 15 170 env13723 = env13724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 170 env13723 == env13724) = true)

def env13725 : List Nat := [2,4,8,16,32,16,128,256,136,1024,1,1297,160,1297,292,170,1296,428,1024,293,1297,260,17,139,40,17,428,1297,1296,1,1284,428,256,137,1296,136]

theorem envBound13725 : H12AffineFastState.Bounded env13725 := by
  intro p hp
  have h : env13725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13724_13725 : H12AffineEnvironment.transform 5 16 env13724 = env13725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13724 == env13725) = true)

def env13726 : List Nat := [2,4,8,16,32,17,128,256,137,1024,1,1296,160,1296,292,170,1297,429,1025,293,1296,261,16,139,40,16,429,1296,1296,1,1284,429,256,137,1297,137]

theorem envBound13726 : H12AffineFastState.Bounded env13726 := by
  intro p hp
  have h : env13726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13724_13726 : H12AffineEnvironment.transform 5 17 env13724 = env13726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env13724 == env13726) = true)

theorem identity13726 : scanCanonicalize (H12AffineFastState.compose env13726 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 134) := by decide +kernel

theorem selectedBound13726 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13727 : List Nat := [2,4,8,16,32,17,128,134,137,1024,1,1174,160,1174,162,170,1175,43,1025,163,1174,131,16,139,40,16,43,1174,1174,1,1154,43,134,137,1175,137]

theorem envBound13727 : H12AffineFastState.Bounded env13727 := by
  intro p hp
  have h : env13727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13726_13727 : H12AffineEnvironment.transform 7 134 env13726 = env13727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 134 env13726 == env13727) = true)

theorem identity13727 : scanCanonicalize (H12AffineFastState.compose env13727 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound13727 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env13728 : List Nat := [2,4,8,16,32,17,9,15,0,1024,1,1055,41,1055,43,35,1054,43,1025,42,1055,10,16,2,40,16,43,1055,1055,1,1035,43,15,0,1054,0]

theorem envBound13728 : H12AffineFastState.Bounded env13728 := by
  intro p hp
  have h : env13728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13727_13728 : H12AffineEnvironment.transform 6 9 env13727 = env13728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env13727 == env13728) = true)

def env13729 : List Nat := [2,4,8,16,0,17,9,15,0,1024,1,1055,9,1055,11,3,1054,11,1025,10,1055,10,16,2,8,16,11,1055,1055,1,1035,11,15,0,1054,0]

theorem envBound13729 : H12AffineFastState.Bounded env13729 := by
  intro p hp
  have h : env13729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13728_13729 : H12AffineEnvironment.transform 4 0 env13728 = env13729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13728 == env13729) = true)

theorem identity13729 : scanCanonicalize (H12AffineFastState.compose env13729 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound13729 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13730 : List Nat := [2,4,8,10,0,11,9,15,0,1024,1,1029,9,1029,11,3,1028,11,1025,10,1029,10,10,2,8,10,11,1029,1029,1,1035,11,15,0,1028,0]

theorem envBound13730 : H12AffineFastState.Bounded env13730 := by
  intro p hp
  have h : env13730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13729_13730 : H12AffineEnvironment.transform 3 10 env13729 = env13730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env13729 == env13730) = true)

def leafEnv13730 : List Nat := [2,4,8,10,0,11,9,15,0,1024,1,1029,9,1029,11,3,1028,11,1025,10,1029,10,10,2,1034,8,1,10,11,1029,1029,1,1035,11,15,0,4,3,1028,0,0,1029,1]

def active13730 : List Nat := [0,1,2,9]

def tree13730 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13730 : H12WitnessSearch.Good tree13730 := H12GlobalWitnessIndex.good

theorem leafIdentity13730 : H12AffineFastState.composeSystem env13730 rootObs = leafEnv13730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13730 rootObs == leafEnv13730) = true)

theorem terminalChecked13730 : H12PackedTerminal.terminalCheckFast leafEnv13730 active13730 tree13730 = true := by decide +kernel

def env13731 : List Nat := [2,4,8,16,1,17,9,15,0,1024,1,1055,8,1055,10,2,1054,10,1025,11,1055,10,16,2,9,16,10,1055,1055,1,1035,10,15,0,1054,0]

theorem envBound13731 : H12AffineFastState.Bounded env13731 := by
  intro p hp
  have h : env13731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13728_13731 : H12AffineEnvironment.transform 4 1 env13728 = env13731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13728 == env13731) = true)

theorem identity13731 : scanCanonicalize (H12AffineFastState.compose env13731 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound13731 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13732 : List Nat := [2,4,8,0,1,1,9,15,0,1024,1,1039,8,1039,10,2,1038,10,1025,11,1039,10,0,2,9,0,10,1039,1039,1,1035,10,15,0,1038,0]

theorem envBound13732 : H12AffineFastState.Bounded env13732 := by
  intro p hp
  have h : env13732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13731_13732 : H12AffineEnvironment.transform 3 0 env13731 = env13732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env13731 == env13732) = true)

def leafEnv13732 : List Nat := [2,4,8,0,1,1,9,15,0,1024,1,1039,8,1039,10,2,1038,10,1025,11,1039,10,0,2,1034,9,1,0,10,1039,1039,1,1035,10,15,0,4,2,1038,0,0,1039,1]

def active13732 : List Nat := [0,1,2,9]

def tree13732 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13732 : H12WitnessSearch.Good tree13732 := H12GlobalWitnessIndex.good

theorem leafIdentity13732 : H12AffineFastState.composeSystem env13732 rootObs = leafEnv13732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13732 rootObs == leafEnv13732) = true)

theorem terminalChecked13732 : H12PackedTerminal.terminalCheckFast leafEnv13732 active13732 tree13732 = true := by decide +kernel

def env13733 : List Nat := [2,4,8,16,32,64,128,256,216,1024,2048,1345,8192,1345,32768,65536,1344,32985,1104,32769,1345,41168,65,98565,8328,65,8541,1345,1296,75786,1284,98418,256,41229,1344,216]

theorem envBound13733 : H12AffineFastState.Bounded env13733 := by
  intro p hp
  have h : env13733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13708_13733 : H12AffineEnvironment.transform 17 32985 env13708 = env13733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32985 env13708 == env13733) = true)

def env13734 : List Nat := [2,4,8,16,32,64,128,256,216,1024,2048,1345,8192,1345,32768,65536,1344,262144,1104,32769,1345,41169,65,98565,8328,65,303493,1345,1296,75787,1284,4294967296,256,4295041406,1344,216]

theorem envBound13734 : H12AffineFastState.Bounded env13734 := by
  intro p hp
  have h : env13734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13706_13734 : H12AffineEnvironment.transform 21 41169 env13706 = env13734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41169 env13706 == env13734) = true)

theorem identity13734 : scanCanonicalize (H12AffineFastState.compose env13734 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 74111) := by decide +kernel

theorem selectedBound13734 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env13735 : List Nat := [2,4,8,16,32,64,128,256,216,1024,2048,1345,8192,1345,32768,65536,1344,262144,1104,32769,1345,41169,65,98565,8328,65,303493,1345,1296,75787,1284,74111,256,1,1344,216]

theorem envBound13735 : H12AffineFastState.Bounded env13735 := by
  intro p hp
  have h : env13735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13734_13735 : H12AffineEnvironment.transform 31 74111 env13734 = env13735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 74111 env13734 == env13735) = true)

def env13736 : List Nat := [2,4,8,16,32,64,128,256,216,1024,2048,1345,8192,1345,32768,65536,1344,32984,1104,32769,1345,41169,65,98565,8328,65,8541,1345,1296,75787,1284,74111,256,1,1344,216]

theorem envBound13736 : H12AffineFastState.Bounded env13736 := by
  intro p hp
  have h : env13736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13735_13736 : H12AffineEnvironment.transform 17 32984 env13735 = env13736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32984 env13735 == env13736) = true)

def env13737 : List Nat := [2,4,8,16,32,64,128,256,216,1024,2048,1345,8192,1345,32768,65536,1344,32985,1104,32769,1345,41169,65,98565,8328,65,8540,1345,1296,75787,1284,74111,256,1,1344,216]

theorem envBound13737 : H12AffineFastState.Bounded env13737 := by
  intro p hp
  have h : env13737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13735_13737 : H12AffineEnvironment.transform 17 32985 env13735 = env13737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32985 env13735 == env13737) = true)

theorem identity13737 : scanCanonicalize (H12AffineFastState.compose env13737 (packedSelected [7] rootPS)) = affineNative (2^(14+1) ^^^ 8581) := by decide +kernel

theorem selectedBound13737 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env13738 : List Nat := [2,4,8,16,32,64,128,256,216,1024,2048,1345,8192,1345,8581,65536,1344,8540,1104,8580,1345,340,65,73856,8328,65,8540,1345,1296,75787,1284,74111,256,1,1344,216]

theorem envBound13738 : H12AffineFastState.Bounded env13738 := by
  intro p hp
  have h : env13738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13737_13738 : H12AffineEnvironment.transform 14 8581 env13737 = env13738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8581 env13737 == env13738) = true)

def env13739 : List Nat := [2,4,8,16,32,64,128,256,216,1024,0,1345,8192,1345,8581,65536,1344,8540,1104,8580,1345,340,65,73856,8328,65,8540,1345,1296,73739,1284,74111,256,1,1344,216]

theorem envBound13739 : H12AffineFastState.Bounded env13739 := by
  intro p hp
  have h : env13739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13738_13739 : H12AffineEnvironment.transform 10 0 env13738 = env13739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env13738 == env13739) = true)

theorem identity13739 : scanCanonicalize (H12AffineFastState.compose env13739 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 171) := by decide +kernel

theorem selectedBound13739 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13740 : List Nat := [2,4,8,16,32,64,128,256,216,1024,0,1345,8192,1345,8581,171,1344,8540,1104,8580,1345,340,65,8235,8328,65,8540,1345,1296,8352,1284,8660,256,1,1344,216]

theorem envBound13740 : H12AffineFastState.Bounded env13740 := by
  intro p hp
  have h : env13740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13739_13740 : H12AffineEnvironment.transform 15 171 env13739 = env13740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 171 env13739 == env13740) = true)

theorem identity13740 : scanCanonicalize (H12AffineFastState.compose env13740 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 160) := by decide +kernel

theorem selectedBound13740 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env13741 : List Nat := [2,4,8,16,32,64,128,256,216,1024,0,1345,160,1345,293,171,1344,508,1104,292,1345,340,65,139,40,65,508,1345,1296,0,1284,372,256,1,1344,216]

theorem envBound13741 : H12AffineFastState.Bounded env13741 := by
  intro p hp
  have h : env13741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13740_13741 : H12AffineEnvironment.transform 12 160 env13740 = env13741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env13740 == env13741) = true)

def env13742 : List Nat := [2,4,8,16,32,16,128,256,136,1024,0,1297,160,1297,293,171,1296,428,1024,292,1297,260,17,139,40,17,428,1297,1296,0,1284,292,256,1,1296,136]

theorem envBound13742 : H12AffineFastState.Bounded env13742 := by
  intro p hp
  have h : env13742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13741_13742 : H12AffineEnvironment.transform 5 16 env13741 = env13742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13741 == env13742) = true)

def env13743 : List Nat := [2,4,8,16,0,16,128,256,136,1024,0,1297,128,1297,261,139,1296,396,1024,260,1297,260,17,139,8,17,396,1297,1296,0,1284,260,256,1,1296,136]

theorem envBound13743 : H12AffineFastState.Bounded env13743 := by
  intro p hp
  have h : env13743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13742_13743 : H12AffineEnvironment.transform 4 0 env13742 = env13743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13742 == env13743) = true)

theorem identity13743 : scanCanonicalize (H12AffineFastState.compose env13743 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 140) := by decide +kernel

theorem selectedBound13743 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13744 : List Nat := [2,4,8,16,0,16,128,140,136,1024,0,1181,128,1181,137,139,1180,0,1024,136,1181,136,17,139,8,17,0,1181,1180,0,1160,136,140,1,1180,136]

theorem envBound13744 : H12AffineFastState.Bounded env13744 := by
  intro p hp
  have h : env13744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13743_13744 : H12AffineEnvironment.transform 7 140 env13743 = env13744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 140 env13743 == env13744) = true)

def leafEnv13744 : List Nat := [2,4,8,16,0,16,128,140,136,1024,0,1181,128,1181,137,139,1180,0,1024,136,1181,136,17,139,1160,8,1,17,0,1181,1180,0,1160,136,140,1,4,2,1180,136,0,1180,1]

def active13744 : List Nat := [0,1,2,3,6,9]

def tree13744 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13744 : H12WitnessSearch.Good tree13744 := H12GlobalWitnessIndex.good

theorem leafIdentity13744 : H12AffineFastState.composeSystem env13744 rootObs = leafEnv13744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13744 rootObs == leafEnv13744) = true)

theorem terminalChecked13744 : H12PackedTerminal.terminalCheckFast leafEnv13744 active13744 tree13744 = true := by decide +kernel

def env13745 : List Nat := [2,4,8,16,1,16,128,256,136,1024,0,1297,129,1297,260,138,1296,397,1024,261,1297,260,17,139,9,17,397,1297,1296,0,1284,261,256,1,1296,136]

theorem envBound13745 : H12AffineFastState.Bounded env13745 := by
  intro p hp
  have h : env13745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13742_13745 : H12AffineEnvironment.transform 4 1 env13742 = env13745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13742 == env13745) = true)

theorem identity13745 : scanCanonicalize (H12AffineFastState.compose env13745 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound13745 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13746 : List Nat := [2,4,8,16,1,16,9,256,1,1024,0,1297,8,1297,260,3,1296,260,1024,261,1297,260,17,2,9,17,260,1297,1296,0,1284,261,256,1,1296,1]

theorem envBound13746 : H12AffineFastState.Bounded env13746 := by
  intro p hp
  have h : env13746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13745_13746 : H12AffineEnvironment.transform 6 9 env13745 = env13746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env13745 == env13746) = true)

def leafEnv13746 : List Nat := [2,4,8,16,1,16,9,256,1,1024,0,1297,8,1297,260,3,1296,260,1024,261,1297,260,17,2,1284,9,1,17,260,1297,1296,0,1284,261,256,1,4,3,1296,1,0,1296,1]

def active13746 : List Nat := [0,1,2,3,7,9]

def tree13746 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13746 : H12WitnessSearch.Good tree13746 := H12GlobalWitnessIndex.good

theorem leafIdentity13746 : H12AffineFastState.composeSystem env13746 rootObs = leafEnv13746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13746 rootObs == leafEnv13746) = true)

theorem terminalChecked13746 : H12PackedTerminal.terminalCheckFast leafEnv13746 active13746 tree13746 = true := by decide +kernel

def env13747 : List Nat := [2,4,8,16,32,17,128,256,137,1024,0,1296,160,1296,293,171,1297,429,1025,292,1296,261,16,139,40,16,429,1296,1296,0,1284,293,256,1,1297,137]

theorem envBound13747 : H12AffineFastState.Bounded env13747 := by
  intro p hp
  have h : env13747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13741_13747 : H12AffineEnvironment.transform 5 17 env13741 = env13747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env13741 == env13747) = true)

theorem identity13747 : scanCanonicalize (H12AffineFastState.compose env13747 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 134) := by decide +kernel

theorem selectedBound13747 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13748 : List Nat := [2,4,8,16,32,17,128,134,137,1024,0,1174,160,1174,163,171,1175,43,1025,162,1174,131,16,139,40,16,43,1174,1174,0,1154,163,134,1,1175,137]

theorem envBound13748 : H12AffineFastState.Bounded env13748 := by
  intro p hp
  have h : env13748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13747_13748 : H12AffineEnvironment.transform 7 134 env13747 = env13748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 134 env13747 == env13748) = true)

theorem identity13748 : scanCanonicalize (H12AffineFastState.compose env13748 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound13748 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env13749 : List Nat := [2,4,8,16,32,17,8,14,1,1024,0,1054,40,1054,43,35,1055,43,1025,42,1054,11,16,3,40,16,43,1054,1054,0,1034,43,14,1,1055,1]

theorem envBound13749 : H12AffineFastState.Bounded env13749 := by
  intro p hp
  have h : env13749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13748_13749 : H12AffineEnvironment.transform 6 8 env13748 = env13749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13748 == env13749) = true)

def env13750 : List Nat := [2,4,8,16,0,17,8,14,1,1024,0,1054,8,1054,11,3,1055,11,1025,10,1054,11,16,3,8,16,11,1054,1054,0,1034,11,14,1,1055,1]

theorem envBound13750 : H12AffineFastState.Bounded env13750 := by
  intro p hp
  have h : env13750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13749_13750 : H12AffineEnvironment.transform 4 0 env13749 = env13750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13749 == env13750) = true)

theorem identity13750 : scanCanonicalize (H12AffineFastState.compose env13750 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound13750 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13751 : List Nat := [2,4,8,1,0,0,8,14,1,1024,0,1039,8,1039,11,3,1038,11,1025,10,1039,11,1,3,8,1,11,1039,1039,0,1034,11,14,1,1038,1]

theorem envBound13751 : H12AffineFastState.Bounded env13751 := by
  intro p hp
  have h : env13751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13750_13751 : H12AffineEnvironment.transform 3 1 env13750 = env13751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env13750 == env13751) = true)

def leafEnv13751 : List Nat := [2,4,8,1,0,0,8,14,1,1024,0,1039,8,1039,11,3,1038,11,1025,10,1039,11,1,3,1035,8,1,1,11,1039,1039,0,1034,11,14,1,4,2,1038,1,0,1039,1]

def active13751 : List Nat := [0,1,2,9]

def tree13751 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13751 : H12WitnessSearch.Good tree13751 := H12GlobalWitnessIndex.good

theorem leafIdentity13751 : H12AffineFastState.composeSystem env13751 rootObs = leafEnv13751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13751 rootObs == leafEnv13751) = true)

theorem terminalChecked13751 : H12PackedTerminal.terminalCheckFast leafEnv13751 active13751 tree13751 = true := by decide +kernel

def env13752 : List Nat := [2,4,8,16,1,17,8,14,1,1024,0,1054,9,1054,10,2,1055,10,1025,11,1054,11,16,3,9,16,10,1054,1054,0,1034,10,14,1,1055,1]

theorem envBound13752 : H12AffineFastState.Bounded env13752 := by
  intro p hp
  have h : env13752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13749_13752 : H12AffineEnvironment.transform 4 1 env13749 = env13752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13749 == env13752) = true)

theorem identity13752 : scanCanonicalize (H12AffineFastState.compose env13752 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound13752 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13753 : List Nat := [2,4,8,11,1,10,8,14,1,1024,0,1029,9,1029,10,2,1028,10,1025,11,1029,11,11,3,9,11,10,1029,1029,0,1034,10,14,1,1028,1]

theorem envBound13753 : H12AffineFastState.Bounded env13753 := by
  intro p hp
  have h : env13753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13752_13753 : H12AffineEnvironment.transform 3 11 env13752 = env13753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env13752 == env13753) = true)

def leafEnv13753 : List Nat := [2,4,8,11,1,10,8,14,1,1024,0,1029,9,1029,10,2,1028,10,1025,11,1029,11,11,3,1035,9,1,11,10,1029,1029,0,1034,10,14,1,4,3,1028,1,0,1029,1]

def active13753 : List Nat := [0,1,2,9]

def tree13753 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13753 : H12WitnessSearch.Good tree13753 := H12GlobalWitnessIndex.good

theorem leafIdentity13753 : H12AffineFastState.composeSystem env13753 rootObs = leafEnv13753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13753 rootObs == leafEnv13753) = true)

theorem terminalChecked13753 : H12PackedTerminal.terminalCheckFast leafEnv13753 active13753 tree13753 = true := by decide +kernel

def env13754 : List Nat := [2,4,8,16,32,64,128,256,216,1024,1,1345,8192,1345,8581,65536,1344,8540,1104,8580,1345,340,65,73856,8328,65,8540,1345,1296,73738,1284,74111,256,1,1344,216]

theorem envBound13754 : H12AffineFastState.Bounded env13754 := by
  intro p hp
  have h : env13754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13738_13754 : H12AffineEnvironment.transform 10 1 env13738 = env13754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env13738 == env13754) = true)

theorem identity13754 : scanCanonicalize (H12AffineFastState.compose env13754 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 161) := by decide +kernel

theorem selectedBound13754 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13755 : List Nat := [2,4,8,16,32,64,128,256,216,1024,1,1345,161,1345,292,65536,1344,509,1104,293,1345,340,65,65569,41,65,509,1345,1296,65707,1284,66014,256,1,1344,216]

theorem envBound13755 : H12AffineFastState.Bounded env13755 := by
  intro p hp
  have h : env13755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13754_13755 : H12AffineEnvironment.transform 12 161 env13754 = env13755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env13754 == env13755) = true)

theorem identity13755 : scanCanonicalize (H12AffineFastState.compose env13755 (packedSelected [1,3,8] rootPS)) = affineNative (2^(15+1) ^^^ 170) := by decide +kernel

theorem selectedBound13755 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env13756 : List Nat := [2,4,8,16,32,64,128,256,216,1024,1,1345,161,1345,292,170,1344,509,1104,293,1345,340,65,139,41,65,509,1345,1296,1,1284,372,256,1,1344,216]

theorem envBound13756 : H12AffineFastState.Bounded env13756 := by
  intro p hp
  have h : env13756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13755_13756 : H12AffineEnvironment.transform 15 170 env13755 = env13756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 170 env13755 == env13756) = true)

def env13757 : List Nat := [2,4,8,16,32,16,128,256,136,1024,1,1297,161,1297,292,170,1296,429,1024,293,1297,260,17,139,41,17,429,1297,1296,1,1284,292,256,1,1296,136]

theorem envBound13757 : H12AffineFastState.Bounded env13757 := by
  intro p hp
  have h : env13757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13756_13757 : H12AffineEnvironment.transform 5 16 env13756 = env13757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13756 == env13757) = true)

def env13758 : List Nat := [2,4,8,16,0,16,128,256,136,1024,1,1297,129,1297,260,138,1296,397,1024,261,1297,260,17,139,9,17,397,1297,1296,1,1284,260,256,1,1296,136]

theorem envBound13758 : H12AffineFastState.Bounded env13758 := by
  intro p hp
  have h : env13758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13757_13758 : H12AffineEnvironment.transform 4 0 env13757 = env13758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13757 == env13758) = true)

theorem identity13758 : scanCanonicalize (H12AffineFastState.compose env13758 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 140) := by decide +kernel

theorem selectedBound13758 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13759 : List Nat := [2,4,8,16,0,16,128,140,136,1024,1,1181,129,1181,136,138,1180,1,1024,137,1181,136,17,139,9,17,1,1181,1180,1,1160,136,140,1,1180,136]

theorem envBound13759 : H12AffineFastState.Bounded env13759 := by
  intro p hp
  have h : env13759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13758_13759 : H12AffineEnvironment.transform 7 140 env13758 = env13759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 140 env13758 == env13759) = true)

def leafEnv13759 : List Nat := [2,4,8,16,0,16,128,140,136,1024,1,1181,129,1181,136,138,1180,1,1024,137,1181,136,17,139,1160,9,1,17,1,1181,1180,1,1160,136,140,1,4,3,1180,136,0,1180,1]

def active13759 : List Nat := [0,1,2,3,6,9]

def tree13759 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13759 : H12WitnessSearch.Good tree13759 := H12GlobalWitnessIndex.good

theorem leafIdentity13759 : H12AffineFastState.composeSystem env13759 rootObs = leafEnv13759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13759 rootObs == leafEnv13759) = true)

theorem terminalChecked13759 : H12PackedTerminal.terminalCheckFast leafEnv13759 active13759 tree13759 = true := by decide +kernel

def env13760 : List Nat := [2,4,8,16,1,16,128,256,136,1024,1,1297,128,1297,261,139,1296,396,1024,260,1297,260,17,139,8,17,396,1297,1296,1,1284,261,256,1,1296,136]

theorem envBound13760 : H12AffineFastState.Bounded env13760 := by
  intro p hp
  have h : env13760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13757_13760 : H12AffineEnvironment.transform 4 1 env13757 = env13760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13757 == env13760) = true)

theorem identity13760 : scanCanonicalize (H12AffineFastState.compose env13760 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound13760 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13761 : List Nat := [2,4,8,16,1,16,9,256,1,1024,1,1297,9,1297,261,2,1296,261,1024,260,1297,260,17,2,8,17,261,1297,1296,1,1284,261,256,1,1296,1]

theorem envBound13761 : H12AffineFastState.Bounded env13761 := by
  intro p hp
  have h : env13761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13760_13761 : H12AffineEnvironment.transform 6 9 env13760 = env13761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env13760 == env13761) = true)

def leafEnv13761 : List Nat := [2,4,8,16,1,16,9,256,1,1024,1,1297,9,1297,261,2,1296,261,1024,260,1297,260,17,2,1284,8,1,17,261,1297,1296,1,1284,261,256,1,4,2,1296,1,0,1296,1]

def active13761 : List Nat := [0,1,2,3,7,9]

def tree13761 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13761 : H12WitnessSearch.Good tree13761 := H12GlobalWitnessIndex.good

theorem leafIdentity13761 : H12AffineFastState.composeSystem env13761 rootObs = leafEnv13761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13761 rootObs == leafEnv13761) = true)

theorem terminalChecked13761 : H12PackedTerminal.terminalCheckFast leafEnv13761 active13761 tree13761 = true := by decide +kernel

def env13762 : List Nat := [2,4,8,16,32,17,128,256,137,1024,1,1296,161,1296,292,170,1297,428,1025,293,1296,261,16,139,41,16,428,1296,1296,1,1284,293,256,1,1297,137]

theorem envBound13762 : H12AffineFastState.Bounded env13762 := by
  intro p hp
  have h : env13762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13756_13762 : H12AffineEnvironment.transform 5 17 env13756 = env13762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env13756 == env13762) = true)

theorem identity13762 : scanCanonicalize (H12AffineFastState.compose env13762 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 134) := by decide +kernel

theorem selectedBound13762 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13763 : List Nat := [2,4,8,16,32,17,128,134,137,1024,1,1174,161,1174,162,170,1175,42,1025,163,1174,131,16,139,41,16,42,1174,1174,1,1154,163,134,1,1175,137]

theorem envBound13763 : H12AffineFastState.Bounded env13763 := by
  intro p hp
  have h : env13763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13762_13763 : H12AffineEnvironment.transform 7 134 env13762 = env13763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 134 env13762 == env13763) = true)

theorem identity13763 : scanCanonicalize (H12AffineFastState.compose env13763 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound13763 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env13764 : List Nat := [2,4,8,16,32,17,8,14,1,1024,1,1054,41,1054,42,34,1055,42,1025,43,1054,11,16,3,41,16,42,1054,1054,1,1034,43,14,1,1055,1]

theorem envBound13764 : H12AffineFastState.Bounded env13764 := by
  intro p hp
  have h : env13764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13763_13764 : H12AffineEnvironment.transform 6 8 env13763 = env13764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13763 == env13764) = true)

def env13765 : List Nat := [2,4,8,16,0,17,8,14,1,1024,1,1054,9,1054,10,2,1055,10,1025,11,1054,11,16,3,9,16,10,1054,1054,1,1034,11,14,1,1055,1]

theorem envBound13765 : H12AffineFastState.Bounded env13765 := by
  intro p hp
  have h : env13765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13764_13765 : H12AffineEnvironment.transform 4 0 env13764 = env13765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13764 == env13765) = true)

theorem identity13765 : scanCanonicalize (H12AffineFastState.compose env13765 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound13765 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13766 : List Nat := [2,4,8,1,0,0,8,14,1,1024,1,1039,9,1039,10,2,1038,10,1025,11,1039,11,1,3,9,1,10,1039,1039,1,1034,11,14,1,1038,1]

theorem envBound13766 : H12AffineFastState.Bounded env13766 := by
  intro p hp
  have h : env13766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13765_13766 : H12AffineEnvironment.transform 3 1 env13765 = env13766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env13765 == env13766) = true)

def leafEnv13766 : List Nat := [2,4,8,1,0,0,8,14,1,1024,1,1039,9,1039,10,2,1038,10,1025,11,1039,11,1,3,1035,9,1,1,10,1039,1039,1,1034,11,14,1,4,3,1038,1,0,1039,1]

def active13766 : List Nat := [0,1,2,9]

def tree13766 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13766 : H12WitnessSearch.Good tree13766 := H12GlobalWitnessIndex.good

theorem leafIdentity13766 : H12AffineFastState.composeSystem env13766 rootObs = leafEnv13766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13766 rootObs == leafEnv13766) = true)

theorem terminalChecked13766 : H12PackedTerminal.terminalCheckFast leafEnv13766 active13766 tree13766 = true := by decide +kernel

def env13767 : List Nat := [2,4,8,16,1,17,8,14,1,1024,1,1054,8,1054,11,3,1055,11,1025,10,1054,11,16,3,8,16,11,1054,1054,1,1034,10,14,1,1055,1]

theorem envBound13767 : H12AffineFastState.Bounded env13767 := by
  intro p hp
  have h : env13767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13764_13767 : H12AffineEnvironment.transform 4 1 env13764 = env13767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13764 == env13767) = true)

theorem identity13767 : scanCanonicalize (H12AffineFastState.compose env13767 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound13767 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13768 : List Nat := [2,4,8,11,1,10,8,14,1,1024,1,1029,8,1029,11,3,1028,11,1025,10,1029,11,11,3,8,11,11,1029,1029,1,1034,10,14,1,1028,1]

theorem envBound13768 : H12AffineFastState.Bounded env13768 := by
  intro p hp
  have h : env13768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13767_13768 : H12AffineEnvironment.transform 3 11 env13767 = env13768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env13767 == env13768) = true)

def leafEnv13768 : List Nat := [2,4,8,11,1,10,8,14,1,1024,1,1029,8,1029,11,3,1028,11,1025,10,1029,11,11,3,1035,8,1,11,11,1029,1029,1,1034,10,14,1,4,2,1028,1,0,1029,1]

def active13768 : List Nat := [0,1,2,9]

def tree13768 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13768 : H12WitnessSearch.Good tree13768 := H12GlobalWitnessIndex.good

theorem leafIdentity13768 : H12AffineFastState.composeSystem env13768 rootObs = leafEnv13768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13768 rootObs == leafEnv13768) = true)

theorem terminalChecked13768 : H12PackedTerminal.terminalCheckFast leafEnv13768 active13768 tree13768 = true := by decide +kernel

def env13769 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,32768,65536,1344,262144,1105,32769,1345,4194304,65,98565,8328,64,4456788,1345,1297,1073741824,1284,4294967296,256,4299260335,1345,512]

theorem envBound13769 : H12AffineFastState.Bounded env13769 := by
  intro p hp
  have h : env13769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13703_13769 : H12AffineEnvironment.transform 18 1105 env13703 = env13769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1105 env13703 == env13769) = true)

theorem identity13769 : scanCanonicalize (H12AffineFastState.compose env13769 (packedSelected [8,10,13,15] rootPS)) = affineNative (2^(21+1) ^^^ 336892) := by decide +kernel

theorem selectedBound13769 : packedSelected [8,10,13,15] rootPS < 2^1333 := by decide +kernel

def env13770 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,32768,65536,1344,262144,1105,32769,1345,336892,65,98565,8328,64,74408,1345,1297,1073741824,1284,4294967296,256,4295270995,1345,512]

theorem envBound13770 : H12AffineFastState.Bounded env13770 := by
  intro p hp
  have h : env13770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13769_13770 : H12AffineEnvironment.transform 21 336892 env13769 = env13770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 336892 env13769 == env13770) = true)

theorem identity13770 : scanCanonicalize (H12AffineFastState.compose env13770 (packedSelected [3,8,10,13,17] rootPS)) = affineNative (2^(31+1) ^^^ 1073775272) := by decide +kernel

theorem selectedBound13770 : packedSelected [3,8,10,13,17] rootPS < 2^1333 := by decide +kernel

def env13771 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,32768,65536,1344,262144,1105,32769,1345,336892,65,98565,8328,64,74408,1345,1297,1073741824,1284,1073775272,256,1074012411,1345,512]

theorem envBound13771 : H12AffineFastState.Bounded env13771 := by
  intro p hp
  have h : env13771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13770_13771 : H12AffineEnvironment.transform 31 1073775272 env13770 = env13771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1073775272 env13770 == env13771) = true)

theorem identity13771 : scanCanonicalize (H12AffineFastState.compose env13771 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound13771 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env13772 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1296,32768,65536,1297,262144,1024,32769,1296,336813,16,98565,8328,17,74408,1296,1297,1073741824,1284,1073775272,256,1074012330,1296,512]

theorem envBound13772 : H12AffineFastState.Bounded env13772 := by
  intro p hp
  have h : env13772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13771_13772 : H12AffineEnvironment.transform 5 17 env13771 = env13772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env13771 == env13772) = true)

theorem identity13772 : scanCanonicalize (H12AffineFastState.compose env13772 (packedSelected [1,3,5] rootPS)) = affineNative (2^(29+1) ^^^ 271279) := by decide +kernel

theorem selectedBound13772 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env13773 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1296,32768,65536,1297,262144,1024,32769,1296,336813,16,98565,8328,17,74408,1296,1297,271279,1284,303367,256,773,1296,512]

theorem envBound13773 : H12AffineFastState.Bounded env13773 := by
  intro p hp
  have h : env13773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13772_13773 : H12AffineEnvironment.transform 29 271279 env13772 = env13773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 271279 env13772 == env13773) = true)

theorem identity13773 : scanCanonicalize (H12AffineFastState.compose env13773 (packedSelected [1,3,8] rootPS)) = affineNative (2^(17+1) ^^^ 68005) := by decide +kernel

theorem selectedBound13773 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env13774 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1296,32768,65536,1297,68005,1024,32769,1296,10760,16,98565,8328,17,74408,1296,1297,76298,1284,108706,256,773,1296,512]

theorem envBound13774 : H12AffineFastState.Bounded env13774 := by
  intro p hp
  have h : env13774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13773_13774 : H12AffineEnvironment.transform 17 68005 env13773 = env13774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 68005 env13773 == env13774) = true)

theorem identity13774 : scanCanonicalize (H12AffineFastState.compose env13774 (packedSelected [1,10] rootPS)) = affineNative (2^(15+1) ^^^ 33314) := by decide +kernel

theorem selectedBound13774 : packedSelected [1,10] rootPS < 2^1333 := by decide +kernel

def env13775 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1296,32768,33314,1297,35719,1024,32769,1296,10760,16,807,8328,17,41098,1296,1297,43048,1284,10880,256,773,1296,512]

theorem envBound13775 : H12AffineFastState.Bounded env13775 := by
  intro p hp
  have h : env13775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13774_13775 : H12AffineEnvironment.transform 15 33314 env13774 = env13775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33314 env13774 == env13775) = true)

theorem identity13775 : scanCanonicalize (H12AffineFastState.compose env13775 (packedSelected [1,12,13] rootPS)) = affineNative (2^(10+1) ^^^ 675) := by decide +kernel

theorem selectedBound13775 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env13776 : List Nat := [2,4,8,16,32,17,128,256,512,1024,675,1296,8192,1296,32768,33314,1297,33060,1024,32769,1296,8363,16,807,8328,17,41098,1296,1297,41611,1284,8227,256,773,1296,512]

theorem envBound13776 : H12AffineFastState.Bounded env13776 := by
  intro p hp
  have h : env13776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13775_13776 : H12AffineEnvironment.transform 10 675 env13775 = env13776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 675 env13775 == env13776) = true)

def env13777 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32769,4096,4194304,8388608,98565,8328,8914000,134217728,8389889,545089,1073741824,8404997,4294967296,8406017,4299260335,147604805,512]

theorem envBound13777 : H12AffineFastState.Bounded env13777 := by
  intro p hp
  have h : env13777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13109_13777 : H12AffineEnvironment.transform 16 1345 env13109 = env13777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env13109 == env13777) = true)

theorem identity13777 : scanCanonicalize (H12AffineFastState.compose env13777 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(26+1) ^^^ 13385732) := by decide +kernel

theorem selectedBound13777 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env13778 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32769,4096,4194304,8388608,98565,8328,8914000,13385732,8389889,545089,1073741824,8404997,4294967296,8406017,4299260335,1345,512]

theorem envBound13778 : H12AffineFastState.Bounded env13778 := by
  intro p hp
  have h : env13778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13777_13778 : H12AffineEnvironment.transform 26 13385732 env13777 = env13778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 13385732 env13777 == env13778) = true)

theorem identity13778 : scanCanonicalize (H12AffineFastState.compose env13778 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(22+1) ^^^ 540929) := by decide +kernel

theorem selectedBound13778 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env13779 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32769,4096,4194304,540929,98565,8328,17745,4456709,541696,545089,1073741824,524548,4294967296,525568,4299260335,1345,512]

theorem envBound13779 : H12AffineFastState.Bounded env13779 := by
  intro p hp
  have h : env13779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13778_13779 : H12AffineEnvironment.transform 22 540929 env13778 = env13779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 540929 env13778 == env13779) = true)

def env13780 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,65536,1345,262144,524288,32769,4096,4194304,525377,98565,8328,17,4456709,524608,529409,1073741824,524548,4294967296,525568,4299260335,1345,512]

theorem envBound13780 : H12AffineFastState.Bounded env13780 := by
  intro p hp
  have h : env13780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13779_13780 : H12AffineEnvironment.transform 13 1344 env13779 = env13780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env13779 == env13780) = true)

theorem identity13780 : scanCanonicalize (H12AffineFastState.compose env13780 (packedSelected [15,38] rootPS)) = affineNative (2^(17+1) ^^^ 43048) := by decide +kernel

theorem selectedBound13780 : packedSelected [15,38] rootPS < 2^1333 := by decide +kernel

def env13781 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,65536,1345,43048,524288,32769,4096,4194304,525377,98565,8328,17,4237613,524608,529409,1073741824,524548,4294967296,525568,4299260335,1345,512]

theorem envBound13781 : H12AffineFastState.Bounded env13781 := by
  intro p hp
  have h : env13781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13780_13781 : H12AffineEnvironment.transform 17 43048 env13780 = env13781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43048 env13780 == env13781) = true)

theorem identity13781 : scanCanonicalize (H12AffineFastState.compose env13781 (packedSelected [11,32] rootPS)) = affineNative (2^(29+1) ^^^ 4721924) := by decide +kernel

theorem selectedBound13781 : packedSelected [11,32] rootPS < 2^1333 := by decide +kernel

def env13782 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,65536,1345,43048,524288,32769,4096,4194304,525377,98565,8328,17,4237613,524608,529409,4721924,524548,4294967296,525568,4299260335,1345,512]

theorem envBound13782 : H12AffineFastState.Bounded env13782 := by
  intro p hp
  have h : env13782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13781_13782 : H12AffineEnvironment.transform 29 4721924 env13781 = env13782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4721924 env13781 == env13782) = true)

theorem identity13782 : scanCanonicalize (H12AffineFastState.compose env13782 (packedSelected [1,4,5,8,9,20,24] rootPS)) = affineNative (2^(21+1) ^^^ 73890) := by decide +kernel

theorem selectedBound13782 : packedSelected [1,4,5,8,9,20,24] rootPS < 2^1333 := by decide +kernel

def env13783 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,65536,1345,43048,524288,32769,4096,73890,525377,98565,8328,17,100751,524608,529409,601510,524548,4294967296,525568,4295008525,1345,512]

theorem envBound13783 : H12AffineFastState.Bounded env13783 := by
  intro p hp
  have h : env13783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13782_13783 : H12AffineEnvironment.transform 21 73890 env13782 = env13783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73890 env13782 == env13783) = true)

theorem identity13783 : scanCanonicalize (H12AffineFastState.compose env13783 (packedSelected [0,3,4,5,7,9,10,15] rootPS)) = affineNative (2^(18+1) ^^^ 38964) := by decide +kernel

theorem selectedBound13783 : packedSelected [0,3,4,5,7,9,10,15] rootPS < 2^1333 := by decide +kernel

def env13784 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,65536,1345,43048,38964,32769,4096,73890,40053,98565,8328,17,100751,39284,35893,112018,39216,4294967296,40244,4295008525,1345,512]

theorem envBound13784 : H12AffineFastState.Bounded env13784 := by
  intro p hp
  have h : env13784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13783_13784 : H12AffineEnvironment.transform 18 38964 env13783 = env13784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 38964 env13783 == env13784) = true)

theorem identity13784 : scanCanonicalize (H12AffineFastState.compose env13784 (packedSelected [0,1,7,8,10,12,13,17,18] rootPS)) = affineNative (2^(14+1) ^^^ 7221) := by decide +kernel

theorem selectedBound13784 : packedSelected [0,1,7,8,10,12,13,17,18] rootPS < 2^1333 := by decide +kernel

def env13785 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,7221,65536,1345,13341,1025,7220,4096,73890,64,73008,8328,17,71098,1345,4096,76199,1285,4294967296,257,4294982968,1345,512]

theorem envBound13785 : H12AffineFastState.Bounded env13785 := by
  intro p hp
  have h : env13785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13784_13785 : H12AffineEnvironment.transform 14 7221 env13784 = env13785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 7221 env13784 == env13785) = true)

theorem identity13785 : scanCanonicalize (H12AffineFastState.compose env13785 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound13785 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env13786 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1296,8192,1344,2341,65536,1345,8461,1025,2340,1296,73890,64,67616,8328,17,65706,1345,1296,76199,1285,4294967296,257,4294977576,1345,512]

theorem envBound13786 : H12AffineFastState.Bounded env13786 := by
  intro p hp
  have h : env13786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13785_13786 : H12AffineEnvironment.transform 11 1296 env13785 = env13786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env13785 == env13786) = true)

theorem identity13786 : scanCanonicalize (H12AffineFastState.compose env13786 (packedSelected [5,8] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound13786 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env13787 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1296,8192,1344,2341,65536,1345,8461,1025,2340,1296,73890,64,67616,8328,17,65706,1345,1296,76199,1285,4294967296,257,4294977576,1345,137]

theorem envBound13787 : H12AffineFastState.Bounded env13787 := by
  intro p hp
  have h : env13787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13786_13787 : H12AffineEnvironment.transform 8 137 env13786 = env13787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env13786 == env13787) = true)

theorem identity13787 : scanCanonicalize (H12AffineFastState.compose env13787 (packedSelected [1,3,5] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound13787 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env13788 : List Nat := [2,4,8,16,32,64,128,4,137,1024,2048,1044,8192,1092,2081,65536,1093,8201,1025,2080,1044,73890,64,67616,8328,17,65706,1093,1044,75939,1025,4294967296,5,4294977576,1093,137]

theorem envBound13788 : H12AffineFastState.Bounded env13788 := by
  intro p hp
  have h : env13788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13787_13788 : H12AffineEnvironment.transform 7 4 env13787 = env13788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env13787 == env13788) = true)

theorem identity13788 : scanCanonicalize (H12AffineFastState.compose env13788 (packedSelected [0,2,4,7] rootPS)) = affineNative (2^(15+1) ^^^ 8355) := by decide +kernel

theorem selectedBound13788 : packedSelected [0,2,4,7] rootPS < 2^1333 := by decide +kernel

def env13789 : List Nat := [2,4,8,16,32,64,128,4,137,1024,2048,1044,8192,1092,2081,8355,1093,8201,1025,2080,1044,1,64,10371,8328,17,8201,1093,1044,2048,1025,4294967296,5,4294977576,1093,137]

theorem envBound13789 : H12AffineFastState.Bounded env13789 := by
  intro p hp
  have h : env13789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13788_13789 : H12AffineEnvironment.transform 15 8355 env13788 = env13789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8355 env13788 == env13789) = true)

def env13790 : List Nat := [2,4,8,16,32,16,128,4,137,1024,2048,1044,8192,1044,2081,8355,1045,8201,1025,2080,1044,1,16,10371,8328,17,8201,1045,1044,2048,1025,4294967296,5,4294977576,1045,137]

theorem envBound13790 : H12AffineFastState.Bounded env13790 := by
  intro p hp
  have h : env13790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13789_13790 : H12AffineEnvironment.transform 5 16 env13789 = env13790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13789 == env13790) = true)

theorem identity13790 : scanCanonicalize (H12AffineFastState.compose env13790 (packedSelected [1,3] rootPS)) = affineNative (2^(31+1) ^^^ 10369) := by decide +kernel

theorem selectedBound13790 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env13791 : List Nat := [2,4,8,16,32,16,128,4,137,1024,2048,1044,8192,1044,2081,8355,1045,8201,1025,2080,1044,1,16,10371,8328,17,8201,1045,1044,2048,1025,10369,5,169,1045,137]

theorem envBound13791 : H12AffineFastState.Bounded env13791 := by
  intro p hp
  have h : env13791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13790_13791 : H12AffineEnvironment.transform 31 10369 env13790 = env13791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 10369 env13790 == env13791) = true)

def env13792 : List Nat := [2,4,8,16,32,16,128,4,137,1024,2048,1044,2056,1044,2081,2219,1045,2049,1025,2080,1044,1,16,139,2176,17,2049,1045,1044,2048,1025,137,5,169,1045,137]

theorem envBound13792 : H12AffineFastState.Bounded env13792 := by
  intro p hp
  have h : env13792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13791_13792 : H12AffineEnvironment.transform 12 2056 env13791 = env13792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2056 env13791 == env13792) = true)

theorem identity13792 : scanCanonicalize (H12AffineFastState.compose env13792 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 169) := by decide +kernel

theorem selectedBound13792 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13793 : List Nat := [2,4,8,16,32,16,128,4,137,1024,169,1044,161,1044,136,2,1045,168,1025,137,1044,1,16,139,41,17,168,1045,1044,169,1025,137,5,169,1045,137]

theorem envBound13793 : H12AffineFastState.Bounded env13793 := by
  intro p hp
  have h : env13793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13792_13793 : H12AffineEnvironment.transform 10 169 env13792 = env13793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 169 env13792 == env13793) = true)

theorem identity13793 : scanCanonicalize (H12AffineFastState.compose env13793 (packedSelected [0,2] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound13793 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env13794 : List Nat := [2,4,8,16,32,16,128,4,137,52,169,32,161,32,136,2,33,168,53,137,32,1,16,139,41,17,168,33,32,169,53,137,5,169,33,137]

theorem envBound13794 : H12AffineFastState.Bounded env13794 := by
  intro p hp
  have h : env13794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13793_13794 : H12AffineEnvironment.transform 9 52 env13793 = env13794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env13793 == env13794) = true)

def env13795 : List Nat := [2,4,8,16,0,16,128,4,137,20,137,0,129,0,136,2,1,136,21,137,0,1,16,139,9,17,136,1,0,137,21,137,5,137,1,137]

theorem envBound13795 : H12AffineFastState.Bounded env13795 := by
  intro p hp
  have h : env13795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13794_13795 : H12AffineEnvironment.transform 4 0 env13794 = env13795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13794 == env13795) = true)

theorem identity13795 : scanCanonicalize (H12AffineFastState.compose env13795 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound13795 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13796 : List Nat := [2,4,8,1,0,1,128,4,137,5,137,0,129,0,136,2,1,136,4,137,0,1,1,139,9,0,136,1,0,137,4,137,5,137,1,137]

theorem envBound13796 : H12AffineFastState.Bounded env13796 := by
  intro p hp
  have h : env13796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13795_13796 : H12AffineEnvironment.transform 3 1 env13795 = env13796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env13795 == env13796) = true)

def leafEnv13796 : List Nat := [2,4,8,1,0,1,128,4,137,5,137,0,129,0,136,2,1,136,4,137,0,1,1,139,4,9,1,0,136,1,0,137,4,137,5,137,4,139,1,137,0,1,1]

def active13796 : List Nat := [0,1,2,6]

def tree13796 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13796 : H12WitnessSearch.Good tree13796 := H12GlobalWitnessIndex.good

theorem leafIdentity13796 : H12AffineFastState.composeSystem env13796 rootObs = leafEnv13796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13796 rootObs == leafEnv13796) = true)

theorem terminalChecked13796 : H12PackedTerminal.terminalCheckFast leafEnv13796 active13796 tree13796 = true := by decide +kernel

def env13797 : List Nat := [2,4,8,16,1,16,128,4,137,21,136,1,128,1,136,2,0,137,20,137,1,1,16,139,8,17,137,0,1,136,20,137,5,136,0,137]

theorem envBound13797 : H12AffineFastState.Bounded env13797 := by
  intro p hp
  have h : env13797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13794_13797 : H12AffineEnvironment.transform 4 1 env13794 = env13797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13794 == env13797) = true)

theorem identity13797 : scanCanonicalize (H12AffineFastState.compose env13797 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound13797 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13798 : List Nat := [2,4,8,16,1,16,25,4,16,21,17,1,25,1,17,2,0,16,20,16,1,1,16,18,8,17,16,0,1,17,20,16,5,17,0,16]

theorem envBound13798 : H12AffineFastState.Bounded env13798 := by
  intro p hp
  have h : env13798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13797_13798 : H12AffineEnvironment.transform 6 25 env13797 = env13798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env13797 == env13798) = true)

def leafEnv13798 : List Nat := [2,4,8,16,1,16,25,4,16,21,17,1,25,1,17,2,0,16,20,16,1,1,16,18,20,8,1,17,16,0,1,17,20,16,5,17,4,18,0,16,0,0,1]

def active13798 : List Nat := [0,1,2,3]

def tree13798 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13798 : H12WitnessSearch.Good tree13798 := H12GlobalWitnessIndex.good

theorem leafIdentity13798 : H12AffineFastState.composeSystem env13798 rootObs = leafEnv13798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13798 rootObs == leafEnv13798) = true)

theorem terminalChecked13798 : H12PackedTerminal.terminalCheckFast leafEnv13798 active13798 tree13798 = true := by decide +kernel

def env13799 : List Nat := [2,4,8,16,32,16,128,4,137,1024,2048,1044,2057,1044,2081,2218,1045,2048,1025,2080,1044,1,16,138,2177,17,2048,1045,1044,2048,1025,136,5,169,1045,137]

theorem envBound13799 : H12AffineFastState.Bounded env13799 := by
  intro p hp
  have h : env13799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13791_13799 : H12AffineEnvironment.transform 12 2057 env13791 = env13799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2057 env13791 == env13799) = true)

theorem identity13799 : scanCanonicalize (H12AffineFastState.compose env13799 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1212) := by decide +kernel

theorem selectedBound13799 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13800 : List Nat := [2,4,8,16,32,16,128,4,137,1024,1212,1044,1205,1044,1181,1046,1045,1212,1025,1180,1044,1,16,138,1085,17,1212,1045,1044,1212,1025,136,5,169,1045,137]

theorem envBound13800 : H12AffineFastState.Bounded env13800 := by
  intro p hp
  have h : env13800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13799_13800 : H12AffineEnvironment.transform 10 1212 env13799 = env13800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1212 env13799 == env13800) = true)

def env13801 : List Nat := [2,4,8,16,32,17,128,4,137,1024,2048,1044,8192,1045,2081,8355,1044,8201,1025,2080,1044,1,17,10371,8328,17,8201,1044,1044,2048,1025,4294967296,5,4294977576,1044,137]

theorem envBound13801 : H12AffineFastState.Bounded env13801 := by
  intro p hp
  have h : env13801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13789_13801 : H12AffineEnvironment.transform 5 17 env13789 = env13801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env13789 == env13801) = true)

theorem identity13801 : scanCanonicalize (H12AffineFastState.compose env13801 (packedSelected [1,3] rootPS)) = affineNative (2^(31+1) ^^^ 137) := by decide +kernel

theorem selectedBound13801 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env13802 : List Nat := [2,4,8,16,32,17,128,4,137,1024,2048,1044,8192,1045,2081,8355,1044,8201,1025,2080,1044,1,17,10371,8328,17,8201,1044,1044,2048,1025,137,5,10401,1044,137]

theorem envBound13802 : H12AffineFastState.Bounded env13802 := by
  intro p hp
  have h : env13802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13801_13802 : H12AffineEnvironment.transform 31 137 env13801 = env13802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 137 env13801 == env13802) = true)

def env13803 : List Nat := [2,4,8,16,32,17,128,4,137,1024,2048,1044,2056,1045,2081,2219,1044,2049,1025,2080,1044,1,17,139,2176,17,2049,1044,1044,2048,1025,137,5,169,1044,137]

theorem envBound13803 : H12AffineFastState.Bounded env13803 := by
  intro p hp
  have h : env13803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13802_13803 : H12AffineEnvironment.transform 12 2056 env13802 = env13803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2056 env13802 == env13803) = true)

theorem identity13803 : scanCanonicalize (H12AffineFastState.compose env13803 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 137) := by decide +kernel

theorem selectedBound13803 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13804 : List Nat := [2,4,8,16,32,17,128,4,137,1024,137,1044,129,1045,168,34,1044,136,1025,169,1044,1,17,139,9,17,136,1044,1044,137,1025,137,5,169,1044,137]

theorem envBound13804 : H12AffineFastState.Bounded env13804 := by
  intro p hp
  have h : env13804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13803_13804 : H12AffineEnvironment.transform 10 137 env13803 = env13804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 137 env13803 == env13804) = true)

theorem identity13804 : scanCanonicalize (H12AffineFastState.compose env13804 (packedSelected [0,2] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound13804 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env13805 : List Nat := [2,4,8,16,32,17,128,4,137,53,137,33,129,32,168,34,33,136,52,169,33,1,17,139,9,17,136,33,33,137,52,137,5,169,33,137]

theorem envBound13805 : H12AffineFastState.Bounded env13805 := by
  intro p hp
  have h : env13805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13804_13805 : H12AffineEnvironment.transform 9 53 env13804 = env13805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env13804 == env13805) = true)

def env13806 : List Nat := [2,4,8,16,0,17,128,4,137,21,137,1,129,0,136,2,1,136,20,137,1,1,17,139,9,17,136,1,1,137,20,137,5,137,1,137]

theorem envBound13806 : H12AffineFastState.Bounded env13806 := by
  intro p hp
  have h : env13806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13805_13806 : H12AffineEnvironment.transform 4 0 env13805 = env13806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13805 == env13806) = true)

theorem identity13806 : scanCanonicalize (H12AffineFastState.compose env13806 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound13806 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13807 : List Nat := [2,4,8,0,0,1,128,4,137,5,137,1,129,0,136,2,1,136,4,137,1,1,1,139,9,1,136,1,1,137,4,137,5,137,1,137]

theorem envBound13807 : H12AffineFastState.Bounded env13807 := by
  intro p hp
  have h : env13807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13806_13807 : H12AffineEnvironment.transform 3 0 env13806 = env13807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env13806 == env13807) = true)

def leafEnv13807 : List Nat := [2,4,8,0,0,1,128,4,137,5,137,1,129,0,136,2,1,136,4,137,1,1,1,139,4,9,1,1,136,1,1,137,4,137,5,137,4,139,1,137,0,0,1]

def active13807 : List Nat := [0,1,2,6]

def tree13807 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13807 : H12WitnessSearch.Good tree13807 := H12GlobalWitnessIndex.good

theorem leafIdentity13807 : H12AffineFastState.composeSystem env13807 rootObs = leafEnv13807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13807 rootObs == leafEnv13807) = true)

theorem terminalChecked13807 : H12PackedTerminal.terminalCheckFast leafEnv13807 active13807 tree13807 = true := by decide +kernel

def env13808 : List Nat := [2,4,8,16,1,17,128,4,137,20,137,0,129,1,137,3,0,136,21,136,0,1,17,139,9,17,136,0,0,137,21,137,5,136,0,137]

theorem envBound13808 : H12AffineFastState.Bounded env13808 := by
  intro p hp
  have h : env13808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13805_13808 : H12AffineEnvironment.transform 4 1 env13805 = env13808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13805 == env13808) = true)

theorem identity13808 : scanCanonicalize (H12AffineFastState.compose env13808 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound13808 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13809 : List Nat := [2,4,8,16,1,17,24,4,17,20,17,0,25,1,17,3,0,16,21,16,0,1,17,19,9,17,16,0,0,17,21,17,5,16,0,17]

theorem envBound13809 : H12AffineFastState.Bounded env13809 := by
  intro p hp
  have h : env13809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13808_13809 : H12AffineEnvironment.transform 6 24 env13808 = env13809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env13808 == env13809) = true)

def leafEnv13809 : List Nat := [2,4,8,16,1,17,24,4,17,20,17,0,25,1,17,3,0,16,21,16,0,1,17,19,21,9,1,17,16,0,0,17,21,17,5,16,4,18,0,17,0,1,1]

def active13809 : List Nat := [0,1,2,3]

def tree13809 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13809 : H12WitnessSearch.Good tree13809 := H12GlobalWitnessIndex.good

theorem leafIdentity13809 : H12AffineFastState.composeSystem env13809 rootObs = leafEnv13809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13809 rootObs == leafEnv13809) = true)

theorem terminalChecked13809 : H12PackedTerminal.terminalCheckFast leafEnv13809 active13809 tree13809 = true := by decide +kernel

def env13810 : List Nat := [2,4,8,16,32,17,128,4,137,1024,2048,1044,2057,1045,2081,2218,1044,2048,1025,2080,1044,1,17,138,2177,17,2048,1044,1044,2048,1025,137,5,168,1044,137]

theorem envBound13810 : H12AffineFastState.Bounded env13810 := by
  intro p hp
  have h : env13810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13802_13810 : H12AffineEnvironment.transform 12 2057 env13802 = env13810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2057 env13802 == env13810) = true)

theorem identity13810 : scanCanonicalize (H12AffineFastState.compose env13810 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1180) := by decide +kernel

theorem selectedBound13810 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13811 : List Nat := [2,4,8,16,32,17,128,4,137,1024,1180,1044,1173,1045,1213,1078,1044,1180,1025,1212,1044,1,17,138,1053,17,1180,1044,1044,1180,1025,137,5,168,1044,137]

theorem envBound13811 : H12AffineFastState.Bounded env13811 := by
  intro p hp
  have h : env13811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13810_13811 : H12AffineEnvironment.transform 10 1180 env13810 = env13811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1180 env13810 == env13811) = true)

def env13812 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,65536,1345,262144,524288,32769,4096,4194304,525376,98565,8328,16,4456709,524609,529408,1073741824,524548,4294967296,525568,4299260335,1345,512]

theorem envBound13812 : H12AffineFastState.Bounded env13812 := by
  intro p hp
  have h : env13812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13779_13812 : H12AffineEnvironment.transform 13 1345 env13779 = env13812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env13779 == env13812) = true)

def env13813 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,65536,1345,262144,1024,32769,4096,4194304,64,98565,8328,16,4456709,1345,4096,1073741824,1284,4294967296,256,4299260335,1345,512]

theorem envBound13813 : H12AffineFastState.Bounded env13813 := by
  intro p hp
  have h : env13813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13812_13813 : H12AffineEnvironment.transform 18 1024 env13812 = env13813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env13812 == env13813) = true)

theorem identity13813 : scanCanonicalize (H12AffineFastState.compose env13813 (packedSelected [0,7,20] rootPS)) = affineNative (2^(11+1) ^^^ 1345) := by decide +kernel

theorem selectedBound13813 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env13814 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,32768,65536,1345,262144,1024,32769,1345,4194304,64,98565,8328,16,4456709,1345,1345,1073741824,1284,4294967296,256,4299260335,1345,512]

theorem envBound13814 : H12AffineFastState.Bounded env13814 := by
  intro p hp
  have h : env13814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13813_13814 : H12AffineEnvironment.transform 11 1345 env13813 = env13814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env13813 == env13814) = true)

theorem identity13814 : scanCanonicalize (H12AffineFastState.compose env13814 (packedSelected [17,21] rootPS)) = affineNative (2^(15+1) ^^^ 33167) := by decide +kernel

theorem selectedBound13814 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env13815 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,32768,33167,1345,262144,1024,32769,1345,4194304,64,138,8328,16,4456709,1345,1345,1073741824,1284,4294967296,256,4299161632,1345,512]

theorem envBound13815 : H12AffineFastState.Bounded env13815 := by
  intro p hp
  have h : env13815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13814_13815 : H12AffineEnvironment.transform 15 33167 env13814 = env13815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33167 env13814 == env13815) = true)

theorem identity13815 : scanCanonicalize (H12AffineFastState.compose env13815 (packedSelected [1,3,5,8,10,15] rootPS)) = affineNative (2^(17+1) ^^^ 44392) := by decide +kernel

theorem selectedBound13815 : packedSelected [1,3,5,8,10,15] rootPS < 2^1333 := by decide +kernel

def env13816 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,32768,33167,1345,44392,1024,32769,1345,4194304,64,138,8328,16,4238445,1345,1345,1073741824,1284,4294967296,256,4299161632,1345,512]

theorem envBound13816 : H12AffineFastState.Bounded env13816 := by
  intro p hp
  have h : env13816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13815_13816 : H12AffineEnvironment.transform 17 44392 env13815 = env13816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 44392 env13815 == env13816) = true)

theorem identity13816 : scanCanonicalize (H12AffineFastState.compose env13816 (packedSelected [1,3,5,8,10] rootPS)) = affineNative (2^(21+1) ^^^ 42044) := by decide +kernel

theorem selectedBound13816 : packedSelected [1,3,5,8,10] rootPS < 2^1333 := by decide +kernel

def env13817 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,32768,33167,1345,44392,1024,32769,1345,42044,64,138,8328,16,2129,1345,1345,1073741824,1284,4294967296,256,4295009308,1345,512]

theorem envBound13817 : H12AffineFastState.Bounded env13817 := by
  intro p hp
  have h : env13817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13816_13817 : H12AffineEnvironment.transform 21 42044 env13816 = env13817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 42044 env13816 == env13817) = true)

theorem identity13817 : scanCanonicalize (H12AffineFastState.compose env13817 (packedSelected [0,3,4,5,7,9,12] rootPS)) = affineNative (2^(31+1) ^^^ 1073774841) := by decide +kernel

theorem selectedBound13817 : packedSelected [0,3,4,5,7,9,12] rootPS < 2^1333 := by decide +kernel

def env13818 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,32768,33167,1345,44392,1024,32769,1345,42044,64,138,8328,16,2129,1345,1345,1073741824,1284,1073774841,256,1073751269,1345,512]

theorem envBound13818 : H12AffineFastState.Bounded env13818 := by
  intro p hp
  have h : env13818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13817_13818 : H12AffineEnvironment.transform 31 1073774841 env13817 = env13818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1073774841 env13817 == env13818) = true)

theorem identity13818 : scanCanonicalize (H12AffineFastState.compose env13818 (packedSelected [1,5,13] rootPS)) = affineNative (2^(14+1) ^^^ 3993) := by decide +kernel

theorem selectedBound13818 : packedSelected [1,5,13] rootPS < 2^1333 := by decide +kernel

def env13819 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,3993,3606,1345,8945,1024,3992,1345,11173,64,138,8328,16,2129,1345,1345,1073741824,1284,1073745760,256,1073751269,1345,512]

theorem envBound13819 : H12AffineFastState.Bounded env13819 := by
  intro p hp
  have h : env13819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13818_13819 : H12AffineEnvironment.transform 14 3993 env13818 = env13819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 3993 env13818 == env13819) = true)

theorem identity13819 : scanCanonicalize (H12AffineFastState.compose env13819 (packedSelected [0,1,4,5,7,9,17] rootPS)) = affineNative (2^(29+1) ^^^ 8461) := by decide +kernel

theorem selectedBound13819 : packedSelected [0,1,4,5,7,9,17] rootPS < 2^1333 := by decide +kernel

def env13820 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,3993,3606,1345,8945,1024,3992,1345,11173,64,138,8328,16,2129,1345,1345,8461,1284,11885,256,1512,1345,512]

theorem envBound13820 : H12AffineFastState.Bounded env13820 := by
  intro p hp
  have h : env13820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13819_13820 : H12AffineEnvironment.transform 29 8461 env13819 = env13820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 8461 env13819 == env13820) = true)

theorem identity13820 : scanCanonicalize (H12AffineFastState.compose env13820 (packedSelected [0,1,3,4,5,7,8,9,18,23] rootPS)) = affineNative (2^(10+1) ^^^ 1773) := by decide +kernel

theorem selectedBound13820 : packedSelected [0,1,3,4,5,7,8,9,18,23] rootPS < 2^1333 := by decide +kernel

def env13821 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1773,1345,8192,1345,372,251,1345,8945,1024,373,1345,9544,64,138,8328,16,1724,1345,1345,8461,1284,8320,256,1512,1345,512]

theorem envBound13821 : H12AffineFastState.Bounded env13821 := by
  intro p hp
  have h : env13821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13820_13821 : H12AffineEnvironment.transform 10 1773 env13820 = env13821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1773 env13820 == env13821) = true)

theorem identity13821 : scanCanonicalize (H12AffineFastState.compose env13821 (packedSelected [0,3,4,5,7,9,11] rootPS)) = affineNative (2^(8+1) ^^^ 509) := by decide +kernel

theorem selectedBound13821 : packedSelected [0,3,4,5,7,9,11] rootPS < 2^1333 := by decide +kernel

def env13822 : List Nat := [2,4,8,16,32,64,128,256,509,1024,1296,1345,8192,1345,372,251,1345,8460,1024,373,1345,9544,64,138,8328,16,1345,1345,1345,8461,1284,8320,256,1512,1345,509]

theorem envBound13822 : H12AffineFastState.Bounded env13822 := by
  intro p hp
  have h : env13822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13821_13822 : H12AffineEnvironment.transform 8 509 env13821 = env13822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 509 env13821 == env13822) = true)

theorem identity13822 : scanCanonicalize (H12AffineFastState.compose env13822 (packedSelected [0,1,2,4,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 237) := by decide +kernel

theorem selectedBound13822 : packedSelected [0,1,2,4,5,6] rootPS < 2^1333 := by decide +kernel

def env13823 : List Nat := [2,4,8,16,32,64,128,256,509,237,509,428,8192,428,372,251,428,8460,237,373,428,8613,64,138,8328,16,428,428,428,8461,489,8320,256,261,428,509]

theorem envBound13823 : H12AffineFastState.Bounded env13823 := by
  intro p hp
  have h : env13823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13822_13823 : H12AffineEnvironment.transform 9 237 env13822 = env13823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 237 env13822 == env13823) = true)

theorem identity13823 : scanCanonicalize (H12AffineFastState.compose env13823 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound13823 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env13824 : List Nat := [2,4,8,16,32,64,128,173,80,237,80,1,8192,1,217,251,1,8353,237,216,1,8200,64,138,8328,16,1,1,1,8352,68,8320,173,168,1,80]

theorem envBound13824 : H12AffineFastState.Bounded env13824 := by
  intro p hp
  have h : env13824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13823_13824 : H12AffineEnvironment.transform 7 173 env13823 = env13824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env13823 == env13824) = true)

theorem identity13824 : scanCanonicalize (H12AffineFastState.compose env13824 (packedSelected [0,4] rootPS)) = affineNative (2^(12+1) ^^^ 161) := by decide +kernel

theorem selectedBound13824 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env13825 : List Nat := [2,4,8,16,32,64,128,173,80,237,80,1,161,1,217,251,1,0,237,216,1,169,64,138,41,16,1,1,1,1,68,33,173,168,1,80]

theorem envBound13825 : H12AffineFastState.Bounded env13825 := by
  intro p hp
  have h : env13825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13824_13825 : H12AffineEnvironment.transform 12 161 env13824 = env13825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env13824 == env13825) = true)

theorem identity13825 : scanCanonicalize (H12AffineFastState.compose env13825 (packedSelected [3,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound13825 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env13826 : List Nat := [2,4,8,16,32,16,128,173,0,189,0,1,161,1,137,171,1,0,189,136,1,169,16,138,41,16,1,1,1,1,20,33,173,168,1,0]

theorem envBound13826 : H12AffineFastState.Bounded env13826 := by
  intro p hp
  have h : env13826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13825_13826 : H12AffineEnvironment.transform 5 16 env13825 = env13826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13825 == env13826) = true)

theorem identity13826 : scanCanonicalize (H12AffineFastState.compose env13826 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound13826 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13827 : List Nat := [2,4,8,16,1,16,128,140,0,156,0,1,128,1,137,138,1,0,156,136,1,136,16,138,8,16,1,1,1,1,20,0,140,137,1,0]

theorem envBound13827 : H12AffineFastState.Bounded env13827 := by
  intro p hp
  have h : env13827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13826_13827 : H12AffineEnvironment.transform 4 1 env13826 = env13827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13826 == env13827) = true)

theorem identity13827 : scanCanonicalize (H12AffineFastState.compose env13827 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound13827 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13828 : List Nat := [2,4,8,16,1,16,24,20,0,4,0,1,24,1,17,18,1,0,4,16,1,16,16,18,8,16,1,1,1,1,20,0,20,17,1,0]

theorem envBound13828 : H12AffineFastState.Bounded env13828 := by
  intro p hp
  have h : env13828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13827_13828 : H12AffineEnvironment.transform 6 24 env13827 = env13828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env13827 == env13828) = true)

theorem identity13828 : scanCanonicalize (H12AffineFastState.compose env13828 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound13828 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env13829 : List Nat := [2,4,8,1,1,1,9,5,0,4,0,1,9,1,0,3,1,0,4,1,1,1,1,3,8,1,1,1,1,1,5,0,5,0,1,0]

theorem envBound13829 : H12AffineFastState.Bounded env13829 := by
  intro p hp
  have h : env13829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13828_13829 : H12AffineEnvironment.transform 3 1 env13828 = env13829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env13828 == env13829) = true)

def env13830 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,65536,1345,262144,1025,32769,4096,4194304,65,98565,8328,16,4456709,1344,4097,1073741824,1285,4294967296,257,4299260335,1345,512]

theorem envBound13830 : H12AffineFastState.Bounded env13830 := by
  intro p hp
  have h : env13830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13812_13830 : H12AffineEnvironment.transform 18 1025 env13812 = env13830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env13812 == env13830) = true)

theorem identity13830 : scanCanonicalize (H12AffineFastState.compose env13830 (packedSelected [17,21] rootPS)) = affineNative (2^(29+1) ^^^ 43049) := by decide +kernel

theorem selectedBound13830 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env13831 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,65536,1345,262144,1025,32769,4096,4194304,65,98565,8328,16,4456709,1344,4097,43049,1285,4294967296,257,4299260335,1345,512]

theorem envBound13831 : H12AffineFastState.Bounded env13831 := by
  intro p hp
  have h : env13831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13830_13831 : H12AffineEnvironment.transform 29 43049 env13830 = env13831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 43049 env13830 == env13831) = true)

def env13832 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1296,8192,1345,32768,65536,1345,262144,1025,32769,1296,4194304,65,98565,8328,16,4456709,1344,1297,43049,1285,4294967296,257,4299260335,1345,512]

theorem envBound13832 : H12AffineFastState.Bounded env13832 := by
  intro p hp
  have h : env13832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13831_13832 : H12AffineEnvironment.transform 11 1296 env13831 = env13832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env13831 == env13832) = true)

theorem identity13832 : scanCanonicalize (H12AffineFastState.compose env13832 (packedSelected [5,8] rootPS)) = affineNative (2^(14+1) ^^^ 9092) := by decide +kernel

theorem selectedBound13832 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env13833 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1296,8192,1345,9092,65536,1345,262144,1025,9093,1296,4194304,65,74369,8328,16,4456709,1344,1297,2989,1285,4294967296,257,4299235883,1345,512]

theorem envBound13833 : H12AffineFastState.Bounded env13833 := by
  intro p hp
  have h : env13833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13832_13833 : H12AffineEnvironment.transform 14 9092 env13832 = env13833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9092 env13832 == env13833) = true)

theorem identity13833 : scanCanonicalize (H12AffineFastState.compose env13833 (packedSelected [3,5,12,13] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound13833 : packedSelected [3,5,12,13] rootPS < 2^1333 := by decide +kernel

def env13834 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1296,8192,1345,9092,8323,1345,262144,1025,9093,1296,4194304,65,514,8328,16,4456709,1344,1297,2989,1285,4294967296,257,4299162280,1345,512]

theorem envBound13834 : H12AffineFastState.Bounded env13834 := by
  intro p hp
  have h : env13834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13833_13834 : H12AffineEnvironment.transform 15 8323 env13833 = env13834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env13833 == env13834) = true)

theorem identity13834 : scanCanonicalize (H12AffineFastState.compose env13834 (packedSelected [1,5,10,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 2341) := by decide +kernel

theorem selectedBound13834 : packedSelected [1,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env13835 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1296,8192,1345,9092,8323,1345,2341,1025,9093,1296,4194304,65,514,8328,16,4196384,1344,1297,2989,1285,4294967296,257,4299162280,1345,512]

theorem envBound13835 : H12AffineFastState.Bounded env13835 := by
  intro p hp
  have h : env13835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13834_13835 : H12AffineEnvironment.transform 17 2341 env13834 = env13835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2341 env13834 == env13835) = true)

theorem identity13835 : scanCanonicalize (H12AffineFastState.compose env13835 (packedSelected [1,3,10] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound13835 : packedSelected [1,3,10] rootPS < 2^1333 := by decide +kernel

def env13836 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1296,268,1345,648,399,1345,2341,1025,649,1296,4194304,65,514,388,16,4196384,1344,1297,2989,1285,4294967296,257,4299162280,1345,512]

theorem envBound13836 : H12AffineFastState.Bounded env13836 := by
  intro p hp
  have h : env13836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13835_13836 : H12AffineEnvironment.transform 12 268 env13835 = env13836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env13835 == env13836) = true)

theorem identity13836 : scanCanonicalize (H12AffineFastState.compose env13836 (packedSelected [0,7,11] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound13836 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env13837 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1296,268,1345,648,399,1345,2341,1025,649,1296,33,65,514,388,16,2049,1344,1297,2989,1285,4294967296,257,4294967945,1345,512]

theorem envBound13837 : H12AffineFastState.Bounded env13837 := by
  intro p hp
  have h : env13837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13836_13837 : H12AffineEnvironment.transform 21 33 env13836 = env13837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env13836 == env13837) = true)

theorem identity13837 : scanCanonicalize (H12AffineFastState.compose env13837 (packedSelected [1,5] rootPS)) = affineNative (2^(31+1) ^^^ 168) := by decide +kernel

theorem selectedBound13837 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env13838 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1296,268,1345,648,399,1345,2341,1025,649,1296,33,65,514,388,16,2049,1344,1297,2989,1285,168,257,545,1345,512]

theorem envBound13838 : H12AffineFastState.Bounded env13838 := by
  intro p hp
  have h : env13838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13837_13838 : H12AffineEnvironment.transform 31 168 env13837 = env13838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 168 env13837 == env13838) = true)

theorem identity13838 : scanCanonicalize (H12AffineFastState.compose env13838 (packedSelected [2,6] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound13838 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env13839 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,0,268,81,648,399,81,2341,273,649,0,33,65,514,388,16,2049,80,1,2989,21,168,257,545,81,512]

theorem envBound13839 : H12AffineFastState.Bounded env13839 := by
  intro p hp
  have h : env13839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13838_13839 : H12AffineEnvironment.transform 9 272 env13838 = env13839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env13838 == env13839) = true)

theorem identity13839 : scanCanonicalize (H12AffineFastState.compose env13839 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 423) := by decide +kernel

theorem selectedBound13839 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13840 : List Nat := [2,4,8,16,32,64,128,256,423,272,2048,0,268,81,303,399,81,2341,273,302,0,33,65,421,388,16,2049,80,1,2058,21,168,257,390,81,423]

theorem envBound13840 : H12AffineFastState.Bounded env13840 := by
  intro p hp
  have h : env13840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13839_13840 : H12AffineEnvironment.transform 8 423 env13839 = env13840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 423 env13839 == env13840) = true)

theorem identity13840 : scanCanonicalize (H12AffineFastState.compose env13840 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 46) := by decide +kernel

theorem selectedBound13840 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env13841 : List Nat := [2,4,8,16,32,64,128,46,137,62,2048,0,34,81,1,161,81,2059,63,0,0,33,65,139,170,16,2049,80,1,2058,21,168,47,168,81,137]

theorem envBound13841 : H12AffineFastState.Bounded env13841 := by
  intro p hp
  have h : env13841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13840_13841 : H12AffineEnvironment.transform 7 46 env13840 = env13841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 46 env13840 == env13841) = true)

theorem identity13841 : scanCanonicalize (H12AffineFastState.compose env13841 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound13841 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13842 : List Nat := [2,4,8,16,27,64,128,21,137,5,2048,0,25,81,1,154,81,2059,4,0,0,26,65,139,145,16,2049,80,1,2058,21,147,20,147,81,137]

theorem envBound13842 : H12AffineFastState.Bounded env13842 := by
  intro p hp
  have h : env13842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13841_13842 : H12AffineEnvironment.transform 4 27 env13841 = env13842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env13841 == env13842) = true)

def env13843 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1297,8192,1345,32768,65536,1345,262144,1025,32769,1297,4194304,65,98565,8328,16,4456709,1344,1296,43049,1285,4294967296,257,4299260335,1345,512]

theorem envBound13843 : H12AffineFastState.Bounded env13843 := by
  intro p hp
  have h : env13843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13831_13843 : H12AffineEnvironment.transform 11 1297 env13831 = env13843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env13831 == env13843) = true)

theorem identity13843 : scanCanonicalize (H12AffineFastState.compose env13843 (packedSelected [5,8] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound13843 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env13844 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1297,8192,1345,32768,65536,1345,262144,1025,32769,1297,4194304,65,98565,8328,16,4456709,1344,1296,43049,1285,4294967296,257,4299260335,1345,137]

theorem envBound13844 : H12AffineFastState.Bounded env13844 := by
  intro p hp
  have h : env13844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13843_13844 : H12AffineEnvironment.transform 8 137 env13843 = env13844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env13843 == env13844) = true)

theorem identity13844 : scanCanonicalize (H12AffineFastState.compose env13844 (packedSelected [1,3,5] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound13844 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env13845 : List Nat := [2,4,8,16,32,64,128,4,137,1024,2048,1045,8192,1093,32768,65536,1093,262144,1025,32769,1045,4194304,65,98305,8328,16,4456449,1092,1044,43049,1025,4294967296,5,4299260075,1093,137]

theorem envBound13845 : H12AffineFastState.Bounded env13845 := by
  intro p hp
  have h : env13845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13844_13845 : H12AffineEnvironment.transform 7 4 env13844 = env13845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env13844 == env13845) = true)

def env13846 : List Nat := [2,4,8,16,32,16,128,4,137,1024,2048,1045,8192,1045,32768,65536,1045,262144,1025,32769,1045,4194304,17,98305,8328,16,4456449,1044,1044,43049,1025,4294967296,5,4299260075,1045,137]

theorem envBound13846 : H12AffineFastState.Bounded env13846 := by
  intro p hp
  have h : env13846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13845_13846 : H12AffineEnvironment.transform 5 16 env13845 = env13846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13845 == env13846) = true)

theorem identity13846 : scanCanonicalize (H12AffineFastState.compose env13846 (packedSelected [1,10] rootPS)) = affineNative (2^(31+1) ^^^ 4194440) := by decide +kernel

theorem selectedBound13846 : packedSelected [1,10] rootPS < 2^1333 := by decide +kernel

def env13847 : List Nat := [2,4,8,16,32,16,128,4,137,1024,2048,1045,8192,1045,32768,65536,1045,262144,1025,32769,1045,4194304,17,98305,8328,16,4456449,1044,1044,43049,1025,4194440,5,98339,1045,137]

theorem envBound13847 : H12AffineFastState.Bounded env13847 := by
  intro p hp
  have h : env13847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13846_13847 : H12AffineEnvironment.transform 31 4194440 env13846 = env13847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 4194440 env13846 == env13847) = true)

def env13848 : List Nat := [2,4,8,16,32,16,128,4,137,20,2048,1,8192,1,32768,65536,1,262144,21,32769,1,4194304,17,98305,8328,16,4456449,0,0,43049,21,4194440,5,98339,1,137]

theorem envBound13848 : H12AffineFastState.Bounded env13848 := by
  intro p hp
  have h : env13848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13847_13848 : H12AffineEnvironment.transform 9 20 env13847 = env13848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env13847 == env13848) = true)

theorem identity13848 : scanCanonicalize (H12AffineFastState.compose env13848 (packedSelected [1] rootPS)) = affineNative (2^(21+1) ^^^ 370819) := by decide +kernel

theorem selectedBound13848 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13849 : List Nat := [2,4,8,16,32,16,128,4,137,20,2048,1,8192,1,32768,65536,1,262144,21,32769,1,370819,17,98305,8328,16,108674,0,0,43049,21,370699,5,98339,1,137]

theorem envBound13849 : H12AffineFastState.Bounded env13849 := by
  intro p hp
  have h : env13849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13848_13849 : H12AffineEnvironment.transform 21 370819 env13848 = env13849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 370819 env13848 == env13849) = true)

theorem identity13849 : scanCanonicalize (H12AffineFastState.compose env13849 (packedSelected [3] rootPS)) = affineNative (2^(17+1) ^^^ 67755) := by decide +kernel

theorem selectedBound13849 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env13850 : List Nat := [2,4,8,16,32,16,128,4,137,20,2048,1,8192,1,32768,65536,1,67755,21,32769,1,41000,17,98305,8328,16,108674,0,0,43049,21,41120,5,98339,1,137]

theorem envBound13850 : H12AffineFastState.Bounded env13850 := by
  intro p hp
  have h : env13850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13849_13850 : H12AffineEnvironment.transform 17 67755 env13849 = env13850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67755 env13849 == env13850) = true)

theorem identity13850 : scanCanonicalize (H12AffineFastState.compose env13850 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 41091) := by decide +kernel

theorem selectedBound13850 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env13851 : List Nat := [2,4,8,16,32,16,128,4,137,20,2048,1,8192,1,32768,41091,1,43048,21,32769,1,41000,17,8322,8328,16,2049,0,0,43049,21,41120,5,8352,1,137]

theorem envBound13851 : H12AffineFastState.Bounded env13851 := by
  intro p hp
  have h : env13851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13850_13851 : H12AffineEnvironment.transform 15 41091 env13850 = env13851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41091 env13850 == env13851) = true)

def env13852 : List Nat := [2,4,8,16,32,16,128,4,137,20,2048,1,8192,1,8352,35,1,2184,21,8353,1,136,17,8322,8328,16,2049,0,0,2185,21,0,5,8352,1,137]

theorem envBound13852 : H12AffineFastState.Bounded env13852 := by
  intro p hp
  have h : env13852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13851_13852 : H12AffineEnvironment.transform 14 8352 env13851 = env13852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8352 env13851 == env13852) = true)

theorem identity13852 : scanCanonicalize (H12AffineFastState.compose env13852 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 176) := by decide +kernel

theorem selectedBound13852 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13853 : List Nat := [2,4,8,16,32,16,128,4,137,20,2048,1,176,1,16,35,1,2184,21,17,1,136,17,50,56,16,2049,0,0,2185,21,0,5,16,1,137]

theorem envBound13853 : H12AffineFastState.Bounded env13853 := by
  intro p hp
  have h : env13853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13852_13853 : H12AffineEnvironment.transform 12 176 env13852 = env13853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 176 env13852 == env13853) = true)

def env13854 : List Nat := [2,4,8,16,32,16,128,4,137,20,48,1,176,1,16,35,1,184,21,17,1,136,17,50,56,16,49,0,0,185,21,0,5,16,1,137]

theorem envBound13854 : H12AffineFastState.Bounded env13854 := by
  intro p hp
  have h : env13854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13853_13854 : H12AffineEnvironment.transform 10 48 env13853 = env13854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env13853 == env13854) = true)

def env13855 : List Nat := [2,4,8,16,32,16,128,4,137,20,49,1,176,1,16,35,1,185,21,17,1,136,17,50,56,16,48,0,0,184,21,0,5,16,1,137]

theorem envBound13855 : H12AffineFastState.Bounded env13855 := by
  intro p hp
  have h : env13855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13853_13855 : H12AffineEnvironment.transform 10 49 env13853 = env13855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env13853 == env13855) = true)

theorem identity13855 : scanCanonicalize (H12AffineFastState.compose env13855 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound13855 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env13856 : List Nat := [2,4,8,16,32,16,9,4,0,20,49,1,57,1,16,35,1,48,21,17,1,1,17,50,56,16,48,0,0,49,21,0,5,16,1,0]

theorem envBound13856 : H12AffineFastState.Bounded env13856 := by
  intro p hp
  have h : env13856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13855_13856 : H12AffineEnvironment.transform 6 9 env13855 = env13856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env13855 == env13856) = true)

def env13857 : List Nat := [2,4,8,16,0,16,9,4,0,20,17,1,25,1,16,3,1,16,21,17,1,1,17,18,24,16,16,0,0,17,21,0,5,16,1,0]

theorem envBound13857 : H12AffineFastState.Bounded env13857 := by
  intro p hp
  have h : env13857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13856_13857 : H12AffineEnvironment.transform 4 0 env13856 = env13857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13856 == env13857) = true)

def env13858 : List Nat := [2,4,8,16,1,16,9,4,0,20,16,1,24,1,16,2,1,17,21,17,1,1,17,19,25,16,17,0,0,16,21,0,5,16,1,0]

theorem envBound13858 : H12AffineFastState.Bounded env13858 := by
  intro p hp
  have h : env13858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13856_13858 : H12AffineEnvironment.transform 4 1 env13856 = env13858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13856 == env13858) = true)

theorem identity13858 : scanCanonicalize (H12AffineFastState.compose env13858 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound13858 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13859 : List Nat := [2,4,8,1,1,1,9,4,0,5,1,1,9,1,1,2,1,0,4,0,1,1,0,2,8,1,0,0,0,1,4,0,5,1,1,0]

theorem envBound13859 : H12AffineFastState.Bounded env13859 := by
  intro p hp
  have h : env13859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13858_13859 : H12AffineEnvironment.transform 3 1 env13858 = env13859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env13858 == env13859) = true)

def leafEnv13859 : List Nat := [2,4,8,1,1,1,9,4,0,5,1,1,9,1,1,2,1,0,4,0,1,1,0,2,4,8,1,1,0,0,0,1,4,0,5,1,4,2,1,0,0,1,1]

def active13859 : List Nat := [0,1,2]

def tree13859 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13859 : H12WitnessSearch.Good tree13859 := H12GlobalWitnessIndex.good

theorem leafIdentity13859 : H12AffineFastState.composeSystem env13859 rootObs = leafEnv13859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13859 rootObs == leafEnv13859) = true)

theorem terminalChecked13859 : H12PackedTerminal.terminalCheckFast leafEnv13859 active13859 tree13859 = true := by decide +kernel

def env13860 : List Nat := [2,4,8,16,32,16,128,4,137,20,2048,1,8192,1,8353,34,1,2185,21,8352,1,137,17,8322,8328,16,2049,0,0,2184,21,1,5,8352,1,137]

theorem envBound13860 : H12AffineFastState.Bounded env13860 := by
  intro p hp
  have h : env13860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13851_13860 : H12AffineEnvironment.transform 14 8353 env13851 = env13860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8353 env13851 == env13860) = true)

theorem identity13860 : scanCanonicalize (H12AffineFastState.compose env13860 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound13860 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13861 : List Nat := [2,4,8,16,32,16,128,4,137,20,2048,1,25,1,184,34,1,2185,21,185,1,137,17,155,145,16,2049,0,0,2184,21,1,5,185,1,137]

theorem envBound13861 : H12AffineFastState.Bounded env13861 := by
  intro p hp
  have h : env13861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13860_13861 : H12AffineEnvironment.transform 12 25 env13860 = env13861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env13860 == env13861) = true)

def env13862 : List Nat := [2,4,8,16,32,16,128,4,137,20,16,1,25,1,184,34,1,153,21,185,1,137,17,155,145,16,17,0,0,152,21,1,5,185,1,137]

theorem envBound13862 : H12AffineFastState.Bounded env13862 := by
  intro p hp
  have h : env13862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13861_13862 : H12AffineEnvironment.transform 10 16 env13861 = env13862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env13861 == env13862) = true)

def env13863 : List Nat := [2,4,8,16,32,16,128,4,137,20,17,1,25,1,184,34,1,152,21,185,1,137,17,155,145,16,16,0,0,153,21,1,5,185,1,137]

theorem envBound13863 : H12AffineFastState.Bounded env13863 := by
  intro p hp
  have h : env13863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13861_13863 : H12AffineEnvironment.transform 10 17 env13861 = env13863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env13861 == env13863) = true)

theorem identity13863 : scanCanonicalize (H12AffineFastState.compose env13863 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound13863 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env13864 : List Nat := [2,4,8,16,32,16,8,4,1,20,17,1,25,1,48,34,1,16,21,49,1,1,17,19,25,16,16,0,0,17,21,1,5,49,1,1]

theorem envBound13864 : H12AffineFastState.Bounded env13864 := by
  intro p hp
  have h : env13864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13863_13864 : H12AffineEnvironment.transform 6 8 env13863 = env13864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13863 == env13864) = true)

def env13865 : List Nat := [2,4,8,16,0,16,8,4,1,20,17,1,25,1,16,2,1,16,21,17,1,1,17,19,25,16,16,0,0,17,21,1,5,17,1,1]

theorem envBound13865 : H12AffineFastState.Bounded env13865 := by
  intro p hp
  have h : env13865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13864_13865 : H12AffineEnvironment.transform 4 0 env13864 = env13865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13864 == env13865) = true)

def env13866 : List Nat := [2,4,8,16,1,16,8,4,1,20,17,1,25,1,17,3,1,16,21,16,1,1,17,19,25,16,16,0,0,17,21,1,5,16,1,1]

theorem envBound13866 : H12AffineFastState.Bounded env13866 := by
  intro p hp
  have h : env13866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13864_13866 : H12AffineEnvironment.transform 4 1 env13864 = env13866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13864 == env13866) = true)

theorem identity13866 : scanCanonicalize (H12AffineFastState.compose env13866 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound13866 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13867 : List Nat := [2,4,8,0,1,0,8,4,1,4,1,1,9,1,1,3,1,0,5,0,1,1,1,3,9,0,0,0,0,1,5,1,5,0,1,1]

theorem envBound13867 : H12AffineFastState.Bounded env13867 := by
  intro p hp
  have h : env13867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13866_13867 : H12AffineEnvironment.transform 3 0 env13866 = env13867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env13866 == env13867) = true)

def leafEnv13867 : List Nat := [2,4,8,0,1,0,8,4,1,4,1,1,9,1,1,3,1,0,5,0,1,1,1,3,5,9,1,0,0,0,0,1,5,1,5,0,4,2,1,1,0,1,1]

def active13867 : List Nat := [0,1,2]

def tree13867 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13867 : H12WitnessSearch.Good tree13867 := H12GlobalWitnessIndex.good

theorem leafIdentity13867 : H12AffineFastState.composeSystem env13867 rootObs = leafEnv13867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13867 rootObs == leafEnv13867) = true)

theorem terminalChecked13867 : H12PackedTerminal.terminalCheckFast leafEnv13867 active13867 tree13867 = true := by decide +kernel

def env13868 : List Nat := [2,4,8,16,32,16,128,4,137,21,2048,0,8192,0,32768,65536,0,262144,20,32769,0,4194304,17,98305,8328,16,4456449,1,1,43049,20,4194440,5,98339,0,137]

theorem envBound13868 : H12AffineFastState.Bounded env13868 := by
  intro p hp
  have h : env13868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13847_13868 : H12AffineEnvironment.transform 9 21 env13847 = env13868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env13847 == env13868) = true)

theorem identity13868 : scanCanonicalize (H12AffineFastState.compose env13868 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound13868 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13869 : List Nat := [2,4,8,16,32,16,128,4,137,21,2048,0,9,0,32768,65536,0,262144,20,32769,0,4194304,17,98305,129,16,4456449,1,1,34848,20,4194440,5,98339,0,137]

theorem envBound13869 : H12AffineFastState.Bounded env13869 := by
  intro p hp
  have h : env13869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13868_13869 : H12AffineEnvironment.transform 12 9 env13868 = env13869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env13868 == env13869) = true)

def env13870 : List Nat := [2,4,8,16,32,16,128,4,137,21,2048,0,9,0,0,65536,0,262144,20,1,0,4194304,17,65537,129,16,4456449,1,1,2080,20,4194440,5,65571,0,137]

theorem envBound13870 : H12AffineFastState.Bounded env13870 := by
  intro p hp
  have h : env13870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13869_13870 : H12AffineEnvironment.transform 14 0 env13869 = env13870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env13869 == env13870) = true)

theorem identity13870 : scanCanonicalize (H12AffineFastState.compose env13870 (packedSelected [2] rootPS)) = affineNative (2^(21+1) ^^^ 65723) := by decide +kernel

theorem selectedBound13870 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13871 : List Nat := [2,4,8,16,32,16,128,4,137,21,2048,0,9,0,0,65536,0,262144,20,1,0,65723,17,65537,129,16,327866,1,1,2080,20,65587,5,65571,0,137]

theorem envBound13871 : H12AffineFastState.Bounded env13871 := by
  intro p hp
  have h : env13871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13870_13871 : H12AffineEnvironment.transform 21 65723 env13870 = env13871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 65723 env13870 == env13871) = true)

theorem identity13871 : scanCanonicalize (H12AffineFastState.compose env13871 (packedSelected [6] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound13871 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env13872 : List Nat := [2,4,8,0,32,0,128,4,137,5,2048,0,9,0,0,65536,0,262144,4,1,0,65707,1,65537,129,0,327850,1,1,2080,4,65571,5,65571,0,137]

theorem envBound13872 : H12AffineFastState.Bounded env13872 := by
  intro p hp
  have h : env13872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13871_13872 : H12AffineEnvironment.transform 3 0 env13871 = env13872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env13871 == env13872) = true)

def env13873 : List Nat := [2,4,8,0,32,0,128,4,137,5,0,0,9,0,0,65536,0,262144,4,1,0,65707,1,65537,129,0,327850,1,1,32,4,65571,5,65571,0,137]

theorem envBound13873 : H12AffineFastState.Bounded env13873 := by
  intro p hp
  have h : env13873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13872_13873 : H12AffineEnvironment.transform 10 0 env13872 = env13873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env13872 == env13873) = true)

def env13874 : List Nat := [2,4,8,0,32,0,128,4,137,5,1,0,9,0,0,65536,0,262144,4,1,0,65707,1,65537,129,0,327850,1,1,33,4,65571,5,65571,0,137]

theorem envBound13874 : H12AffineFastState.Bounded env13874 := by
  intro p hp
  have h : env13874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13872_13874 : H12AffineEnvironment.transform 10 1 env13872 = env13874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env13872 == env13874) = true)

theorem identity13874 : scanCanonicalize (H12AffineFastState.compose env13874 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound13874 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13875 : List Nat := [2,4,8,0,0,0,128,4,137,5,1,0,9,0,0,65536,0,262144,4,1,0,65675,1,65537,129,0,327818,1,1,1,4,65539,5,65539,0,137]

theorem envBound13875 : H12AffineFastState.Bounded env13875 := by
  intro p hp
  have h : env13875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13874_13875 : H12AffineEnvironment.transform 4 0 env13874 = env13875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13874 == env13875) = true)

def env13876 : List Nat := [2,4,8,0,0,0,128,4,137,5,1,0,9,0,0,65536,0,0,4,1,0,65675,1,65537,129,0,65674,1,1,1,4,65539,5,65539,0,137]

theorem envBound13876 : H12AffineFastState.Bounded env13876 := by
  intro p hp
  have h : env13876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13875_13876 : H12AffineEnvironment.transform 17 0 env13875 = env13876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 0 env13875 == env13876) = true)

theorem identity13876 : scanCanonicalize (H12AffineFastState.compose env13876 (packedSelected [7] rootPS)) = affineNative (2^(15+1) ^^^ 138) := by decide +kernel

theorem selectedBound13876 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env13877 : List Nat := [2,4,8,0,0,0,128,4,137,5,1,0,9,0,0,138,0,0,4,1,0,1,1,139,129,0,0,1,1,1,4,137,5,137,0,137]

theorem envBound13877 : H12AffineFastState.Bounded env13877 := by
  intro p hp
  have h : env13877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13876_13877 : H12AffineEnvironment.transform 15 138 env13876 = env13877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 138 env13876 == env13877) = true)

def leafEnv13877 : List Nat := [2,4,8,0,0,0,128,4,137,5,1,0,9,0,0,138,0,0,4,1,0,1,1,139,4,129,1,0,0,1,1,1,4,137,5,137,4,3,0,137,0,0,1]

def active13877 : List Nat := [0,1,2,6]

def tree13877 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13877 : H12WitnessSearch.Good tree13877 := H12GlobalWitnessIndex.good

theorem leafIdentity13877 : H12AffineFastState.composeSystem env13877 rootObs = leafEnv13877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13877 rootObs == leafEnv13877) = true)

theorem terminalChecked13877 : H12PackedTerminal.terminalCheckFast leafEnv13877 active13877 tree13877 = true := by decide +kernel

def env13878 : List Nat := [2,4,8,0,0,0,128,4,137,5,1,0,9,0,0,65536,0,1,4,1,0,65675,1,65537,129,0,65675,1,1,1,4,65539,5,65539,0,137]

theorem envBound13878 : H12AffineFastState.Bounded env13878 := by
  intro p hp
  have h : env13878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13875_13878 : H12AffineEnvironment.transform 17 1 env13875 = env13878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1 env13875 == env13878) = true)

def env13879 : List Nat := [2,4,8,16,32,16,128,4,137,21,2048,0,9,0,1,65536,0,262144,20,0,0,4194304,17,65536,129,16,4456449,1,1,2081,20,4194440,5,65570,0,137]

theorem envBound13879 : H12AffineFastState.Bounded env13879 := by
  intro p hp
  have h : env13879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13869_13879 : H12AffineEnvironment.transform 14 1 env13869 = env13879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env13869 == env13879) = true)

theorem identity13879 : scanCanonicalize (H12AffineFastState.compose env13879 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 50) := by decide +kernel

theorem selectedBound13879 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13880 : List Nat := [2,4,8,16,32,16,128,4,137,21,2048,0,9,0,1,50,0,262144,20,0,0,4194304,17,50,129,16,4456449,1,1,2081,20,4194440,5,16,0,137]

theorem envBound13880 : H12AffineFastState.Bounded env13880 := by
  intro p hp
  have h : env13880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13879_13880 : H12AffineEnvironment.transform 15 50 env13879 = env13880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 50 env13879 == env13880) = true)

def env13881 : List Nat := [2,4,8,16,32,17,128,4,137,1024,2048,1045,8192,1044,32768,65536,1044,262144,1025,32769,1045,4194304,16,98305,8328,16,4456449,1045,1044,43049,1025,4294967296,5,4299260075,1044,137]

theorem envBound13881 : H12AffineFastState.Bounded env13881 := by
  intro p hp
  have h : env13881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13845_13881 : H12AffineEnvironment.transform 5 17 env13845 = env13881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env13845 == env13881) = true)

theorem identity13881 : scanCanonicalize (H12AffineFastState.compose env13881 (packedSelected [1,10] rootPS)) = affineNative (2^(31+1) ^^^ 73770) := by decide +kernel

theorem selectedBound13881 : packedSelected [1,10] rootPS < 2^1333 := by decide +kernel

def env13882 : List Nat := [2,4,8,16,32,17,128,4,137,1024,2048,1045,8192,1044,32768,65536,1044,262144,1025,32769,1045,4194304,16,98305,8328,16,4456449,1045,1044,43049,1025,73770,5,4235393,1044,137]

theorem envBound13882 : H12AffineFastState.Bounded env13882 := by
  intro p hp
  have h : env13882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13881_13882 : H12AffineEnvironment.transform 31 73770 env13881 = env13882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 73770 env13881 == env13882) = true)

def env13883 : List Nat := [2,4,8,16,32,17,128,4,137,20,2048,1,8192,0,32768,65536,0,262144,21,32769,1,4194304,16,98305,8328,16,4456449,1,0,43049,21,73770,5,4235393,0,137]

theorem envBound13883 : H12AffineFastState.Bounded env13883 := by
  intro p hp
  have h : env13883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13882_13883 : H12AffineEnvironment.transform 9 20 env13882 = env13883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env13882 == env13883) = true)

theorem identity13883 : scanCanonicalize (H12AffineFastState.compose env13883 (packedSelected [1] rootPS)) = affineNative (2^(21+1) ^^^ 8232) := by decide +kernel

theorem selectedBound13883 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13884 : List Nat := [2,4,8,16,32,17,128,4,137,20,2048,1,8192,0,32768,65536,0,262144,21,32769,1,8232,16,98305,8328,16,270377,1,0,43049,21,73770,5,32937,0,137]

theorem envBound13884 : H12AffineFastState.Bounded env13884 := by
  intro p hp
  have h : env13884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13883_13884 : H12AffineEnvironment.transform 21 8232 env13883 = env13884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8232 env13883 == env13884) = true)

theorem identity13884 : scanCanonicalize (H12AffineFastState.compose env13884 (packedSelected [3] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound13884 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env13885 : List Nat := [2,4,8,16,32,17,128,4,137,20,2048,1,8192,0,32768,65536,0,10280,21,32769,1,8232,16,98305,8328,16,2049,1,0,43049,21,73770,5,32937,0,137]

theorem envBound13885 : H12AffineFastState.Bounded env13885 := by
  intro p hp
  have h : env13885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13884_13885 : H12AffineEnvironment.transform 17 10280 env13884 = env13885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env13884 == env13885) = true)

theorem identity13885 : scanCanonicalize (H12AffineFastState.compose env13885 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound13885 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env13886 : List Nat := [2,4,8,16,32,17,128,4,137,20,2048,1,8192,0,0,65536,0,10280,21,1,1,8232,16,65537,8328,16,2049,1,0,10281,21,73770,5,169,0,137]

theorem envBound13886 : H12AffineFastState.Bounded env13886 := by
  intro p hp
  have h : env13886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13885_13886 : H12AffineEnvironment.transform 14 0 env13885 = env13886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env13885 == env13886) = true)

def env13887 : List Nat := [2,4,8,16,32,17,128,4,137,20,2048,1,8,0,0,65536,0,2080,21,1,1,32,16,65537,128,16,2049,1,0,2081,21,65570,5,169,0,137]

theorem envBound13887 : H12AffineFastState.Bounded env13887 := by
  intro p hp
  have h : env13887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13886_13887 : H12AffineEnvironment.transform 12 8 env13886 = env13887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env13886 == env13887) = true)

theorem identity13887 : scanCanonicalize (H12AffineFastState.compose env13887 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound13887 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13888 : List Nat := [2,4,8,16,32,17,57,4,48,20,2048,1,8,0,0,65536,0,2080,21,1,1,32,16,65537,57,16,2049,1,0,2081,21,65570,5,16,0,48]

theorem envBound13888 : H12AffineFastState.Bounded env13888 := by
  intro p hp
  have h : env13888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13887_13888 : H12AffineEnvironment.transform 6 57 env13887 = env13888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env13887 == env13888) = true)

theorem identity13888 : scanCanonicalize (H12AffineFastState.compose env13888 (packedSelected [0,4] rootPS)) = affineNative (2^(15+1) ^^^ 51) := by decide +kernel

theorem selectedBound13888 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env13889 : List Nat := [2,4,8,16,32,17,57,4,48,20,2048,1,8,0,0,51,0,2080,21,1,1,32,16,50,57,16,2049,1,0,2081,21,17,5,16,0,48]

theorem envBound13889 : H12AffineFastState.Bounded env13889 := by
  intro p hp
  have h : env13889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13888_13889 : H12AffineEnvironment.transform 15 51 env13888 = env13889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 51 env13888 == env13889) = true)

def env13890 : List Nat := [2,4,8,16,32,17,57,4,48,20,0,1,8,0,0,51,0,32,21,1,1,32,16,50,57,16,1,1,0,33,21,17,5,16,0,48]

theorem envBound13890 : H12AffineFastState.Bounded env13890 := by
  intro p hp
  have h : env13890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13889_13890 : H12AffineEnvironment.transform 10 0 env13889 = env13890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env13889 == env13890) = true)

theorem identity13890 : scanCanonicalize (H12AffineFastState.compose env13890 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound13890 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13891 : List Nat := [2,4,8,16,1,17,24,4,17,20,0,1,8,0,0,18,0,1,21,1,1,1,16,19,24,16,1,1,0,0,21,17,5,16,0,17]

theorem envBound13891 : H12AffineFastState.Bounded env13891 := by
  intro p hp
  have h : env13891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13890_13891 : H12AffineEnvironment.transform 4 1 env13890 = env13891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13890 == env13891) = true)

def leafEnv13891 : List Nat := [2,4,8,16,1,17,24,4,17,20,0,1,8,0,0,18,0,1,21,1,1,1,16,19,21,24,1,16,1,1,0,0,21,17,5,16,4,3,0,17,0,1,1]

def active13891 : List Nat := [0,1,2,3]

def tree13891 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13891 : H12WitnessSearch.Good tree13891 := H12GlobalWitnessIndex.good

theorem leafIdentity13891 : H12AffineFastState.composeSystem env13891 rootObs = leafEnv13891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13891 rootObs == leafEnv13891) = true)

theorem terminalChecked13891 : H12PackedTerminal.terminalCheckFast leafEnv13891 active13891 tree13891 = true := by decide +kernel

def env13892 : List Nat := [2,4,8,16,32,17,57,4,48,20,1,1,8,0,0,51,0,33,21,1,1,32,16,50,57,16,0,1,0,32,21,17,5,16,0,48]

theorem envBound13892 : H12AffineFastState.Bounded env13892 := by
  intro p hp
  have h : env13892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13889_13892 : H12AffineEnvironment.transform 10 1 env13889 = env13892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env13889 == env13892) = true)

def env13893 : List Nat := [2,4,8,16,32,17,128,4,137,20,2048,1,9,0,0,65536,0,2081,21,1,1,33,16,65537,129,16,2049,1,0,2080,21,65571,5,169,0,137]

theorem envBound13893 : H12AffineFastState.Bounded env13893 := by
  intro p hp
  have h : env13893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13886_13893 : H12AffineEnvironment.transform 12 9 env13886 = env13893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env13886 == env13893) = true)

theorem identity13893 : scanCanonicalize (H12AffineFastState.compose env13893 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 154) := by decide +kernel

theorem selectedBound13893 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13894 : List Nat := [2,4,8,16,32,17,128,4,137,20,2048,1,9,0,0,154,0,2081,21,1,1,33,16,155,129,16,2049,1,0,2080,21,185,5,169,0,137]

theorem envBound13894 : H12AffineFastState.Bounded env13894 := by
  intro p hp
  have h : env13894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13893_13894 : H12AffineEnvironment.transform 15 154 env13893 = env13894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 154 env13893 == env13894) = true)

def env13895 : List Nat := [2,4,8,16,32,17,128,4,137,21,2048,0,8192,1,32768,65536,1,262144,20,32769,0,4194304,16,98305,8328,16,4456449,0,1,43049,20,73770,5,4235393,1,137]

theorem envBound13895 : H12AffineFastState.Bounded env13895 := by
  intro p hp
  have h : env13895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13882_13895 : H12AffineEnvironment.transform 9 21 env13882 = env13895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env13882 == env13895) = true)

theorem identity13895 : scanCanonicalize (H12AffineFastState.compose env13895 (packedSelected [1] rootPS)) = affineNative (2^(17+1) ^^^ 108706) := by decide +kernel

theorem selectedBound13895 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13896 : List Nat := [2,4,8,16,32,17,128,4,137,21,2048,0,8192,1,32768,65536,1,108706,20,32769,0,4194304,16,98305,8328,16,4303011,0,1,43049,20,73770,5,4235393,1,137]

theorem envBound13896 : H12AffineFastState.Bounded env13896 := by
  intro p hp
  have h : env13896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13895_13896 : H12AffineEnvironment.transform 17 108706 env13895 = env13896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 108706 env13895 == env13896) = true)

theorem identity13896 : scanCanonicalize (H12AffineFastState.compose env13896 (packedSelected [3] rootPS)) = affineNative (2^(15+1) ^^^ 138) := by decide +kernel

theorem selectedBound13896 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env13897 : List Nat := [2,4,8,16,32,17,128,4,137,21,2048,0,8192,1,32768,138,1,43048,20,32769,0,4194304,16,32907,8328,16,4237353,0,1,43049,20,8352,5,4235393,1,137]

theorem envBound13897 : H12AffineFastState.Bounded env13897 := by
  intro p hp
  have h : env13897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13896_13897 : H12AffineEnvironment.transform 15 138 env13896 = env13897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 138 env13896 == env13897) = true)

theorem identity13897 : scanCanonicalize (H12AffineFastState.compose env13897 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(21+1) ^^^ 41000) := by decide +kernel

theorem selectedBound13897 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env13898 : List Nat := [2,4,8,16,32,17,128,4,137,21,2048,0,8192,1,32768,138,1,43048,20,32769,0,41000,16,32907,8328,16,2049,0,1,43049,20,8352,5,169,1,137]

theorem envBound13898 : H12AffineFastState.Bounded env13898 := by
  intro p hp
  have h : env13898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13897_13898 : H12AffineEnvironment.transform 21 41000 env13897 = env13898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41000 env13897 == env13898) = true)

def env13899 : List Nat := [2,4,8,16,32,17,128,4,137,21,2048,0,160,1,32768,138,1,34952,20,32769,0,32904,16,32907,40,16,2049,0,1,34953,20,0,5,169,1,137]

theorem envBound13899 : H12AffineFastState.Bounded env13899 := by
  intro p hp
  have h : env13899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13898_13899 : H12AffineEnvironment.transform 12 160 env13898 = env13899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env13898 == env13899) = true)

theorem identity13899 : scanCanonicalize (H12AffineFastState.compose env13899 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound13899 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13900 : List Nat := [2,4,8,16,32,17,57,4,48,21,2048,0,25,1,32768,51,1,34865,20,32769,0,32817,16,32818,40,16,2049,0,1,34864,20,0,5,16,1,48]

theorem envBound13900 : H12AffineFastState.Bounded env13900 := by
  intro p hp
  have h : env13900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13899_13900 : H12AffineEnvironment.transform 6 57 env13899 = env13900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env13899 == env13900) = true)

def env13901 : List Nat := [2,4,8,16,32,17,57,4,48,21,2048,0,25,1,2080,51,1,17,20,2081,0,2065,16,2066,40,16,2049,0,1,16,20,0,5,16,1,48]

theorem envBound13901 : H12AffineFastState.Bounded env13901 := by
  intro p hp
  have h : env13901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13900_13901 : H12AffineEnvironment.transform 14 2080 env13900 = env13901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2080 env13900 == env13901) = true)

def env13902 : List Nat := [2,4,8,16,32,17,57,4,48,21,2048,0,25,1,2081,51,1,16,20,2080,0,2064,16,2067,40,16,2049,0,1,17,20,0,5,16,1,48]

theorem envBound13902 : H12AffineFastState.Bounded env13902 := by
  intro p hp
  have h : env13902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13900_13902 : H12AffineEnvironment.transform 14 2081 env13900 = env13902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2081 env13900 == env13902) = true)

theorem identity13902 : scanCanonicalize (H12AffineFastState.compose env13902 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound13902 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env13903 : List Nat := [2,4,8,16,32,17,57,4,48,21,17,0,25,1,48,51,1,16,20,49,0,1,16,2,40,16,16,0,1,17,20,0,5,16,1,48]

theorem envBound13903 : H12AffineFastState.Bounded env13903 := by
  intro p hp
  have h : env13903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13902_13903 : H12AffineEnvironment.transform 10 17 env13902 = env13903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env13902 == env13903) = true)

def env13904 : List Nat := [2,4,8,16,0,17,25,4,16,21,17,0,25,1,16,19,1,16,20,17,0,1,16,2,8,16,16,0,1,17,20,0,5,16,1,16]

theorem envBound13904 : H12AffineFastState.Bounded env13904 := by
  intro p hp
  have h : env13904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13903_13904 : H12AffineEnvironment.transform 4 0 env13903 = env13904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13903 == env13904) = true)

theorem identity13904 : scanCanonicalize (H12AffineFastState.compose env13904 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound13904 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13905 : List Nat := [2,4,8,0,0,1,9,4,0,5,1,0,9,1,0,3,1,0,4,1,0,1,0,2,8,0,0,0,1,1,4,0,5,0,1,0]

theorem envBound13905 : H12AffineFastState.Bounded env13905 := by
  intro p hp
  have h : env13905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13904_13905 : H12AffineEnvironment.transform 3 0 env13904 = env13905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env13904 == env13905) = true)

def leafEnv13905 : List Nat := [2,4,8,0,0,1,9,4,0,5,1,0,9,1,0,3,1,0,4,1,0,1,0,2,4,8,1,0,0,0,1,1,4,0,5,0,4,3,1,0,0,0,1]

def active13905 : List Nat := [0,1,2]

def tree13905 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13905 : H12WitnessSearch.Good tree13905 := H12GlobalWitnessIndex.good

theorem leafIdentity13905 : H12AffineFastState.composeSystem env13905 rootObs = leafEnv13905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13905 rootObs == leafEnv13905) = true)

theorem terminalChecked13905 : H12PackedTerminal.terminalCheckFast leafEnv13905 active13905 tree13905 = true := by decide +kernel

def env13906 : List Nat := [2,4,8,16,1,17,24,4,17,21,17,0,25,1,17,18,1,16,20,16,0,1,16,2,9,16,16,0,1,17,20,0,5,16,1,17]

theorem envBound13906 : H12AffineFastState.Bounded env13906 := by
  intro p hp
  have h : env13906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13903_13906 : H12AffineEnvironment.transform 4 1 env13903 = env13906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13903 == env13906) = true)

def env13907 : List Nat := [2,4,8,16,32,17,128,4,137,21,2048,0,161,1,32768,138,1,34953,20,32769,0,32905,16,32907,41,16,2049,0,1,34952,20,1,5,169,1,137]

theorem envBound13907 : H12AffineFastState.Bounded env13907 := by
  intro p hp
  have h : env13907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13898_13907 : H12AffineEnvironment.transform 12 161 env13898 = env13907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env13898 == env13907) = true)

theorem identity13907 : scanCanonicalize (H12AffineFastState.compose env13907 (packedSelected [2] rootPS)) = affineNative (2^(14+1) ^^^ 16) := by decide +kernel

theorem selectedBound13907 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13908 : List Nat := [2,4,8,16,32,17,128,4,137,21,2048,0,161,1,16,138,1,2201,20,17,0,153,16,155,41,16,2049,0,1,2200,20,1,5,169,1,137]

theorem envBound13908 : H12AffineFastState.Bounded env13908 := by
  intro p hp
  have h : env13908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13907_13908 : H12AffineEnvironment.transform 14 16 env13907 = env13908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 16 env13907 == env13908) = true)

def env13909 : List Nat := [2,4,8,16,32,17,128,4,137,21,48,0,161,1,16,138,1,169,20,17,0,153,16,155,41,16,49,0,1,168,20,1,5,169,1,137]

theorem envBound13909 : H12AffineFastState.Bounded env13909 := by
  intro p hp
  have h : env13909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13908_13909 : H12AffineEnvironment.transform 10 48 env13908 = env13909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env13908 == env13909) = true)

def env13910 : List Nat := [2,4,8,16,32,17,128,4,137,21,49,0,161,1,16,138,1,168,20,17,0,153,16,155,41,16,48,0,1,169,20,1,5,169,1,137]

theorem envBound13910 : H12AffineFastState.Bounded env13910 := by
  intro p hp
  have h : env13910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13908_13910 : H12AffineEnvironment.transform 10 49 env13908 = env13910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env13908 == env13910) = true)

theorem identity13910 : scanCanonicalize (H12AffineFastState.compose env13910 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound13910 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env13911 : List Nat := [2,4,8,16,32,17,24,4,17,21,49,0,57,1,16,18,1,48,20,17,0,1,16,3,41,16,48,0,1,49,20,1,5,49,1,17]

theorem envBound13911 : H12AffineFastState.Bounded env13911 := by
  intro p hp
  have h : env13911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13910_13911 : H12AffineEnvironment.transform 6 24 env13910 = env13911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env13910 == env13911) = true)

def env13912 : List Nat := [2,4,8,16,0,17,24,4,17,21,17,0,25,1,16,18,1,16,20,17,0,1,16,3,9,16,16,0,1,17,20,1,5,17,1,17]

theorem envBound13912 : H12AffineFastState.Bounded env13912 := by
  intro p hp
  have h : env13912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13911_13912 : H12AffineEnvironment.transform 4 0 env13911 = env13912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13911 == env13912) = true)

theorem identity13912 : scanCanonicalize (H12AffineFastState.compose env13912 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound13912 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13913 : List Nat := [2,4,8,0,0,1,8,4,1,5,1,0,9,1,0,2,1,0,4,1,0,1,0,3,9,0,0,0,1,1,4,1,5,1,1,1]

theorem envBound13913 : H12AffineFastState.Bounded env13913 := by
  intro p hp
  have h : env13913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13912_13913 : H12AffineEnvironment.transform 3 0 env13912 = env13913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env13912 == env13913) = true)

def leafEnv13913 : List Nat := [2,4,8,0,0,1,8,4,1,5,1,0,9,1,0,2,1,0,4,1,0,1,0,3,4,9,1,0,0,0,1,1,4,1,5,1,4,3,1,1,0,0,1]

def active13913 : List Nat := [0,1,2]

def tree13913 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13913 : H12WitnessSearch.Good tree13913 := H12GlobalWitnessIndex.good

theorem leafIdentity13913 : H12AffineFastState.composeSystem env13913 rootObs = leafEnv13913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13913 rootObs == leafEnv13913) = true)

theorem terminalChecked13913 : H12PackedTerminal.terminalCheckFast leafEnv13913 active13913 tree13913 = true := by decide +kernel

def env13914 : List Nat := [2,4,8,16,1,17,24,4,17,21,16,0,24,1,16,18,1,17,20,17,0,1,16,3,8,16,17,0,1,16,20,1,5,16,1,17]

theorem envBound13914 : H12AffineFastState.Bounded env13914 := by
  intro p hp
  have h : env13914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13911_13914 : H12AffineEnvironment.transform 4 1 env13911 = env13914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13911 == env13914) = true)

def env13915 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,4194304,8388608,16777216,8328,8914000,134217728,8519744,676865,1073741824,25412672,4294967296,8536385,4315938986,164610305,512]

theorem envBound13915 : H12AffineFastState.Bounded env13915 := by
  intro p hp
  have h : env13915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13107_13915 : H12AffineEnvironment.transform 20 4097 env13107 = env13915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env13107 == env13915) = true)

theorem identity13915 : scanCanonicalize (H12AffineFastState.compose env13915 (packedSelected [14] rootPS)) = affineNative (2^(26+1) ^^^ 4982020) := by decide +kernel

theorem selectedBound13915 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env13916 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,4194304,8388608,16777216,8328,8914000,4982020,8519744,676865,1073741824,25412672,4294967296,8536385,4315938986,25412613,512]

theorem envBound13916 : H12AffineFastState.Bounded env13916 := by
  intro p hp
  have h : env13916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13915_13916 : H12AffineEnvironment.transform 26 4982020 env13915 = env13916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 4982020 env13915 == env13916) = true)

def env13917 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,4194304,17664,16777216,8328,541008,4982020,148800,676865,1073741824,17006912,4294967296,132161,4315938986,17006853,512]

theorem envBound13917 : H12AffineFastState.Bounded env13917 := by
  intro p hp
  have h : env13917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13916_13917 : H12AffineEnvironment.transform 22 17664 env13916 = env13917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17664 env13916 == env13917) = true)

def env13918 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,4194304,17665,16777216,8328,541009,4982020,148801,676865,1073741824,17006913,4294967296,132160,4315938986,17006852,512]

theorem envBound13918 : H12AffineFastState.Bounded env13918 := by
  intro p hp
  have h : env13918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13916_13918 : H12AffineEnvironment.transform 22 17665 env13916 = env13918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17665 env13916 == env13918) = true)

theorem identity13918 : scanCanonicalize (H12AffineFastState.compose env13918 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(23+1) ^^^ 98565) := by decide +kernel

theorem selectedBound13918 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env13919 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,4194304,17665,98565,8328,541009,4982020,148801,676865,1073741824,131140,4294967296,132160,4299260335,131073,512]

theorem envBound13919 : H12AffineFastState.Bounded env13919 := by
  intro p hp
  have h : env13919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13918_13919 : H12AffineEnvironment.transform 23 98565 env13918 = env13919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98565 env13918 == env13919) = true)

def env13920 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16384,262144,524288,32769,4097,4194304,17665,98565,8328,541009,4982020,1345,529409,1073741824,16452,4294967296,17472,4299260335,16385,512]

theorem envBound13920 : H12AffineFastState.Bounded env13920 := by
  intro p hp
  have h : env13920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13919_13920 : H12AffineEnvironment.transform 16 16384 env13919 = env13920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16384 env13919 == env13920) = true)

theorem identity13920 : scanCanonicalize (H12AffineFastState.compose env13920 (packedSelected [0,4,7,9,16,20] rootPS)) = affineNative (2^(18+1) ^^^ 4369) := by decide +kernel

theorem selectedBound13920 : packedSelected [0,4,7,9,16,20] rootPS < 2^1333 := by decide +kernel

def env13921 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16384,262144,4369,32769,4097,4194304,17665,98565,8328,20544,4461589,1345,1296,1073741824,16452,4294967296,17472,4299260335,16385,512]

theorem envBound13921 : H12AffineFastState.Bounded env13921 := by
  intro p hp
  have h : env13921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13920_13921 : H12AffineEnvironment.transform 18 4369 env13920 = env13921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4369 env13920 == env13921) = true)

theorem identity13921 : scanCanonicalize (H12AffineFastState.compose env13921 (packedSelected [5,15,17,24] rootPS)) = affineNative (2^(29+1) ^^^ 4497709) := by decide +kernel

theorem selectedBound13921 : packedSelected [5,15,17,24] rootPS < 2^1333 := by decide +kernel

def env13922 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16384,262144,4369,32769,4097,4194304,17665,98565,8328,20544,4461589,1345,1296,4497709,16452,4294967296,17472,4299260335,16385,512]

theorem envBound13922 : H12AffineFastState.Bounded env13922 := by
  intro p hp
  have h : env13922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13921_13922 : H12AffineEnvironment.transform 29 4497709 env13921 = env13922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4497709 env13921 == env13922) = true)

theorem identity13922 : scanCanonicalize (H12AffineFastState.compose env13922 (packedSelected [4,9,16,18,23] rootPS)) = affineNative (2^(17+1) ^^^ 48440) := by decide +kernel

theorem selectedBound13922 : packedSelected [4,9,16,18,23] rootPS < 2^1333 := by decide +kernel

def env13923 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16384,48440,4369,32769,4097,4194304,17665,98565,8328,20544,4237613,1345,1296,4201493,16452,4294967296,17472,4299260335,16385,512]

theorem envBound13923 : H12AffineFastState.Bounded env13923 := by
  intro p hp
  have h : env13923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13922_13923 : H12AffineEnvironment.transform 17 48440 env13922 = env13923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 48440 env13922 == env13923) = true)

def env13924 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16384,48440,4369,32769,4097,10248,17665,98565,8328,20544,33061,1345,1296,13341,16452,4294967296,17472,4295076263,16385,512]

theorem envBound13924 : H12AffineFastState.Bounded env13924 := by
  intro p hp
  have h : env13924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13923_13924 : H12AffineEnvironment.transform 21 10248 env13923 = env13924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10248 env13923 == env13924) = true)

theorem identity13924 : scanCanonicalize (H12AffineFastState.compose env13924 (packedSelected [11] rootPS)) = affineNative (2^(13+1) ^^^ 4176) := by decide +kernel

theorem selectedBound13924 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env13925 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,4176,48440,4369,32769,4097,10248,5457,98565,8328,16,33061,1345,1296,13341,4116,4294967296,5136,4295076263,4177,512]

theorem envBound13925 : H12AffineFastState.Bounded env13925 := by
  intro p hp
  have h : env13925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13924_13925 : H12AffineEnvironment.transform 13 4176 env13924 = env13925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env13924 == env13925) = true)

theorem identity13925 : scanCanonicalize (H12AffineFastState.compose env13925 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound13925 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env13926 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1296,8192,1344,32768,65536,1344,43048,1025,32769,1297,10248,65,98565,8328,16,33061,1345,1296,8461,1284,4294967296,256,4295076263,1345,512]

theorem envBound13926 : H12AffineFastState.Bounded env13926 := by
  intro p hp
  have h : env13926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13925_13926 : H12AffineEnvironment.transform 11 1296 env13925 = env13926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env13925 == env13926) = true)

theorem identity13926 : scanCanonicalize (H12AffineFastState.compose env13926 (packedSelected [5,8] rootPS)) = affineNative (2^(15+1) ^^^ 33543) := by decide +kernel

theorem selectedBound13926 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env13927 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1296,8192,1344,32768,33543,1344,43048,1025,32769,1297,10248,65,514,8328,16,33061,1345,1296,8461,1284,4294967296,256,4294978208,1345,512]

theorem envBound13927 : H12AffineFastState.Bounded env13927 := by
  intro p hp
  have h : env13927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13926_13927 : H12AffineEnvironment.transform 15 33543 env13926 = env13927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33543 env13926 == env13927) = true)

theorem identity13927 : scanCanonicalize (H12AffineFastState.compose env13927 (packedSelected [5] rootPS)) = affineNative (2^(12+1) ^^^ 2721) := by decide +kernel

theorem selectedBound13927 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env13928 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1296,2721,1344,32768,33543,1344,33417,1025,32769,1297,681,65,514,2601,16,33061,1345,1296,2988,1284,4294967296,256,4294967297,1345,512]

theorem envBound13928 : H12AffineFastState.Bounded env13928 := by
  intro p hp
  have h : env13928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13927_13928 : H12AffineEnvironment.transform 12 2721 env13927 = env13928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2721 env13927 == env13928) = true)

theorem identity13928 : scanCanonicalize (H12AffineFastState.compose env13928 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound13928 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env13929 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1296,2088,1344,32768,33166,1344,32768,1025,32769,1297,32,65,139,2208,16,33061,1345,1296,2341,1284,4294967296,256,4294967297,1345,137]

theorem envBound13929 : H12AffineFastState.Bounded env13929 := by
  intro p hp
  have h : env13929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13928_13929 : H12AffineEnvironment.transform 8 137 env13928 = env13929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env13928 == env13929) = true)

theorem identity13929 : scanCanonicalize (H12AffineFastState.compose env13929 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound13929 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env13930 : List Nat := [2,4,8,16,32,64,128,37,137,1024,2048,1077,2088,1125,32768,32939,1125,32768,1025,32769,1076,32,65,139,2208,16,32768,1124,1077,2048,1057,4294967296,37,4294967297,1124,137]

theorem envBound13930 : H12AffineFastState.Bounded env13930 := by
  intro p hp
  have h : env13930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13929_13930 : H12AffineEnvironment.transform 7 37 env13929 = env13930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env13929 == env13930) = true)

theorem identity13930 : scanCanonicalize (H12AffineFastState.compose env13930 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound13930 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13931 : List Nat := [2,4,8,16,32,64,25,37,16,1024,2048,1077,2088,1125,32768,32818,1125,32768,1025,32769,1076,32,65,18,2105,16,32768,1124,1077,2048,1057,4294967296,37,4294967297,1124,16]

theorem envBound13931 : H12AffineFastState.Bounded env13931 := by
  intro p hp
  have h : env13931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13930_13931 : H12AffineEnvironment.transform 6 25 env13930 = env13931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env13930 == env13931) = true)

theorem identity13931 : scanCanonicalize (H12AffineFastState.compose env13931 (packedSelected [4] rootPS)) = affineNative (2^(14+1) ^^^ 2048) := by decide +kernel

theorem selectedBound13931 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env13932 : List Nat := [2,4,8,16,32,64,25,37,16,1024,2048,1077,2088,1125,2048,2098,1125,2048,1025,2049,1076,32,65,18,2105,16,2048,1124,1077,2048,1057,4294967296,37,4294967297,1124,16]

theorem envBound13932 : H12AffineFastState.Bounded env13932 := by
  intro p hp
  have h : env13932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13931_13932 : H12AffineEnvironment.transform 14 2048 env13931 = env13932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2048 env13931 == env13932) = true)

theorem identity13932 : scanCanonicalize (H12AffineFastState.compose env13932 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 17) := by decide +kernel

theorem selectedBound13932 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13933 : List Nat := [2,4,8,16,32,64,25,37,16,1024,2048,1077,2088,1125,2048,2098,1125,2048,1025,2049,1076,32,65,18,2105,16,2048,1124,1077,2048,1057,17,37,16,1124,16]

theorem envBound13933 : H12AffineFastState.Bounded env13933 := by
  intro p hp
  have h : env13933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13932_13933 : H12AffineEnvironment.transform 31 17 env13932 = env13933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 17 env13932 == env13933) = true)

theorem identity13933 : scanCanonicalize (H12AffineFastState.compose env13933 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound13933 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13934 : List Nat := [2,4,8,16,27,64,25,30,16,1024,2048,1038,2067,1118,2048,2057,1118,2048,1025,2049,1039,27,65,18,2050,16,2048,1119,1038,2048,1050,17,30,16,1119,16]

theorem envBound13934 : H12AffineFastState.Bounded env13934 := by
  intro p hp
  have h : env13934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13933_13934 : H12AffineEnvironment.transform 4 27 env13933 = env13934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env13933 == env13934) = true)

def env13935 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16384,48440,4369,32769,4097,10249,17665,98565,8328,20544,33060,1345,1296,13340,16452,4294967296,17472,4295076262,16385,512]

theorem envBound13935 : H12AffineFastState.Bounded env13935 := by
  intro p hp
  have h : env13935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13923_13935 : H12AffineEnvironment.transform 21 10249 env13923 = env13935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10249 env13923 == env13935) = true)

theorem identity13935 : scanCanonicalize (H12AffineFastState.compose env13935 (packedSelected [11] rootPS)) = affineNative (2^(14+1) ^^^ 22901) := by decide +kernel

theorem selectedBound13935 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env13936 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,22901,65536,16384,25677,4369,22900,4097,10249,17665,88176,8328,20544,22609,1345,1296,13340,16452,4294967296,17472,4295061715,16385,512]

theorem envBound13936 : H12AffineFastState.Bounded env13936 := by
  intro p hp
  have h : env13936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13935_13936 : H12AffineEnvironment.transform 14 22901 env13935 = env13936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 22901 env13935 == env13936) = true)

theorem identity13936 : scanCanonicalize (H12AffineFastState.compose env13936 (packedSelected [0,3,4,5,7,9,12,13] rootPS)) = affineNative (2^(15+1) ^^^ 7611) := by decide +kernel

theorem selectedBound13936 : packedSelected [0,3,4,5,7,9,12,13] rootPS < 2^1333 := by decide +kernel

def env13937 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,22901,7611,16384,25677,4369,22900,4097,10249,17665,17867,8328,20544,22609,1345,1296,13340,16452,4294967296,17472,4294995304,16385,512]

theorem envBound13937 : H12AffineFastState.Bounded env13937 := by
  intro p hp
  have h : env13937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13936_13937 : H12AffineEnvironment.transform 15 7611 env13936 = env13937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 7611 env13936 == env13937) = true)

end H12CloudChart2