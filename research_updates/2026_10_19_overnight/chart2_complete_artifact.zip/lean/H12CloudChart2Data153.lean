import H12CloudChart2Data152

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity38149 : scanCanonicalize (H12AffineFastState.compose env38149 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 430) := by decide +kernel

theorem selectedBound38149 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env38150 : List Nat := [2,4,8,1,32,1,128,256,512,521,2048,1,652,777,136,430,777,303,781,137,0,396,1,430,769,261,803,777,260,2080,640,644,257,776,777,772]

theorem envBound38150 : H12AffineFastState.Bounded env38150 := by
  intro p hp
  have h : env38150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38149_38150 : H12AffineEnvironment.transform 15 430 env38149 = env38150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 430 env38149 == env38150) = true)

theorem identity38150 : scanCanonicalize (H12AffineFastState.compose env38150 (packedSelected [3,4,5,9,10,11,17,18,19,21,23] rootPS)) = affineNative (2^(10+1) ^^^ 390) := by decide +kernel

theorem selectedBound38150 : packedSelected [3,4,5,9,10,11,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env38151 : List Nat := [2,4,8,1,32,1,128,256,512,521,390,1,652,777,136,430,777,303,781,137,0,396,1,430,769,261,803,777,260,422,640,644,257,776,777,772]

theorem envBound38151 : H12AffineFastState.Bounded env38151 := by
  intro p hp
  have h : env38151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38150_38151 : H12AffineEnvironment.transform 10 390 env38150 = env38151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 390 env38150 == env38151) = true)

theorem identity38151 : scanCanonicalize (H12AffineFastState.compose env38151 (packedSelected [3,4,7,10,11,12,13] rootPS)) = affineNative (2^(8+1) ^^^ 130) := by decide +kernel

theorem selectedBound38151 : packedSelected [3,4,7,10,11,12,13] rootPS < 2^1333 := by decide +kernel

def env38152 : List Nat := [2,4,8,1,32,1,128,256,130,139,390,1,14,395,136,430,395,303,399,137,0,396,1,430,387,261,417,395,260,422,2,6,257,394,395,390]

theorem envBound38152 : H12AffineFastState.Bounded env38152 := by
  intro p hp
  have h : env38152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38151_38152 : H12AffineEnvironment.transform 8 130 env38151 = env38152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 130 env38151 == env38152) = true)

theorem identity38152 : scanCanonicalize (H12AffineFastState.compose env38152 (packedSelected [0,3,7,8,10,11] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound38152 : packedSelected [0,3,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env38153 : List Nat := [2,4,8,1,12,1,128,256,130,139,390,1,14,395,136,386,395,259,399,137,0,396,1,386,387,261,397,395,260,394,2,6,257,394,395,390]

theorem envBound38153 : H12AffineFastState.Bounded env38153 := by
  intro p hp
  have h : env38153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38152_38153 : H12AffineEnvironment.transform 4 12 env38152 = env38153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env38152 == env38153) = true)

theorem identity38153 : scanCanonicalize (H12AffineFastState.compose env38153 (packedSelected [1,4,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 128) := by decide +kernel

theorem selectedBound38153 : packedSelected [1,4,7,8] rootPS < 2^1333 := by decide +kernel

def env38154 : List Nat := [2,4,8,1,12,1,128,128,130,139,6,1,14,11,136,2,11,131,15,137,0,12,1,2,3,133,13,11,132,10,2,6,129,10,11,6]

theorem envBound38154 : H12AffineFastState.Bounded env38154 := by
  intro p hp
  have h : env38154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38153_38154 : H12AffineEnvironment.transform 7 128 env38153 = env38154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 128 env38153 == env38154) = true)

theorem identity38154 : scanCanonicalize (H12AffineFastState.compose env38154 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound38154 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env38155 : List Nat := [2,4,8,1,12,1,2,2,0,9,6,1,14,11,10,2,11,1,15,11,0,12,1,2,3,7,13,11,6,10,2,6,3,10,11,6]

theorem envBound38155 : H12AffineFastState.Bounded env38155 := by
  intro p hp
  have h : env38155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38154_38155 : H12AffineEnvironment.transform 6 2 env38154 = env38155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env38154 == env38155) = true)

theorem identity38155 : scanCanonicalize (H12AffineFastState.compose env38155 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound38155 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env38156 : List Nat := [2,4,3,1,7,1,2,2,0,2,6,1,5,0,1,2,0,1,4,0,0,7,1,2,3,7,6,0,6,1,2,6,3,1,0,6]

theorem envBound38156 : H12AffineFastState.Bounded env38156 := by
  intro p hp
  have h : env38156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38155_38156 : H12AffineEnvironment.transform 2 3 env38155 = env38156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env38155 == env38156) = true)

def env38157 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,1221,1297,137,65536,1345,65665,66811,136,80,476,16,65601,66743,65723,66693,1297,65787,68063,1225,1229,257,1281,1345,66299]

theorem envBound38157 : H12AffineFastState.Bounded env38157 := by
  intro p hp
  have h : env38157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38113_38157 : H12AffineEnvironment.transform 12 1221 env38113 = env38157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1221 env38113 == env38157) = true)

def env38158 : List Nat := [2,4,8,16,32,0,128,256,512,1024,2048,17,1157,1297,137,65536,1281,65665,66747,136,16,412,16,65537,66743,65723,66693,1297,65723,67999,1161,1165,257,1281,1281,66235]

theorem envBound38158 : H12AffineFastState.Bounded env38158 := by
  intro p hp
  have h : env38158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38157_38158 : H12AffineEnvironment.transform 5 0 env38157 = env38158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env38157 == env38158) = true)

theorem identity38158 : scanCanonicalize (H12AffineFastState.compose env38158 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 575) := by decide +kernel

theorem selectedBound38158 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env38159 : List Nat := [2,4,8,16,32,0,128,256,512,1024,2048,17,1157,1297,137,575,1281,702,1668,136,16,412,16,574,1672,644,1722,1297,644,2976,1161,1165,257,1281,1281,132]

theorem envBound38159 : H12AffineFastState.Bounded env38159 := by
  intro p hp
  have h : env38159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38158_38159 : H12AffineEnvironment.transform 15 575 env38158 = env38159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 575 env38158 == env38159) = true)

def env38160 : List Nat := [2,4,8,0,32,0,128,256,512,1024,2048,1,1157,1281,137,559,1281,686,1668,136,0,396,0,558,1672,644,1706,1281,644,2976,1161,1165,257,1281,1281,132]

theorem envBound38160 : H12AffineFastState.Bounded env38160 := by
  intro p hp
  have h : env38160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38159_38160 : H12AffineEnvironment.transform 3 0 env38159 = env38160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env38159 == env38160) = true)

theorem identity38160 : scanCanonicalize (H12AffineFastState.compose env38160 (packedSelected [4,9,16] rootPS)) = affineNative (2^(8+1) ^^^ 385) := by decide +kernel

theorem selectedBound38160 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env38161 : List Nat := [2,4,8,0,32,0,128,256,385,1024,2048,1,1157,1281,137,430,1281,303,1285,136,0,396,0,431,1289,261,1323,1281,261,2081,1161,1165,257,1281,1281,132]

theorem envBound38161 : H12AffineFastState.Bounded env38161 := by
  intro p hp
  have h : env38161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38160_38161 : H12AffineEnvironment.transform 8 385 env38160 = env38161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 385 env38160 == env38161) = true)

theorem identity38161 : scanCanonicalize (H12AffineFastState.compose env38161 (packedSelected [3,4,5,9,10,11,17,18,19,21,23] rootPS)) = affineNative (2^(10+1) ^^^ 271) := by decide +kernel

theorem selectedBound38161 : packedSelected [3,4,5,9,10,11,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env38162 : List Nat := [2,4,8,0,32,0,128,256,385,1024,271,1,1157,1281,137,430,1281,303,1285,136,0,396,0,431,1289,261,1323,1281,261,302,1161,1165,257,1281,1281,132]

theorem envBound38162 : H12AffineFastState.Bounded env38162 := by
  intro p hp
  have h : env38162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38161_38162 : H12AffineEnvironment.transform 10 271 env38161 = env38162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 271 env38161 == env38162) = true)

theorem identity38162 : scanCanonicalize (H12AffineFastState.compose env38162 (packedSelected [1,3,4,7,11,12,13,15] rootPS)) = affineNative (2^(9+1) ^^^ 389) := by decide +kernel

theorem selectedBound38162 : packedSelected [1,3,4,7,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env38163 : List Nat := [2,4,8,0,32,0,128,256,385,389,271,1,256,132,137,430,132,303,128,136,0,396,0,431,140,261,174,132,261,302,268,264,257,132,132,132]

theorem envBound38163 : H12AffineFastState.Bounded env38163 := by
  intro p hp
  have h : env38163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38162_38163 : H12AffineEnvironment.transform 9 389 env38162 = env38163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 389 env38162 == env38163) = true)

theorem identity38163 : scanCanonicalize (H12AffineFastState.compose env38163 (packedSelected [0,2,5,7,8,10,11] rootPS)) = affineNative (2^(7+1) ^^^ 35) := by decide +kernel

theorem selectedBound38163 : packedSelected [0,2,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env38164 : List Nat := [2,4,8,0,32,0,128,35,162,166,44,1,35,132,137,141,132,12,128,136,0,175,0,140,140,38,174,132,38,13,47,43,34,132,132,132]

theorem envBound38164 : H12AffineFastState.Bounded env38164 := by
  intro p hp
  have h : env38164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38163_38164 : H12AffineEnvironment.transform 7 35 env38163 = env38164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 35 env38163 == env38164) = true)

theorem identity38164 : scanCanonicalize (H12AffineFastState.compose env38164 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(6+1) ^^^ 46) := by decide +kernel

theorem selectedBound38164 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env38165 : List Nat := [2,4,8,0,32,0,46,35,12,8,44,1,35,42,39,35,42,12,46,38,0,1,0,34,34,38,0,42,38,13,47,43,34,42,42,42]

theorem envBound38165 : H12AffineFastState.Bounded env38165 := by
  intro p hp
  have h : env38165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38164_38165 : H12AffineEnvironment.transform 6 46 env38164 = env38165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 46 env38164 == env38165) = true)

theorem identity38165 : scanCanonicalize (H12AffineFastState.compose env38165 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound38165 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env38166 : List Nat := [2,4,8,0,13,0,3,14,12,8,1,1,14,7,10,14,7,12,3,11,0,1,0,15,15,11,0,7,11,13,2,6,15,7,7,7]

theorem envBound38166 : H12AffineFastState.Bounded env38166 := by
  intro p hp
  have h : env38166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38165_38166 : H12AffineEnvironment.transform 4 13 env38165 = env38166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env38165 == env38166) = true)

theorem identity38166 : scanCanonicalize (H12AffineFastState.compose env38166 (packedSelected [1,2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound38166 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env38167 : List Nat := [2,3,8,0,10,0,3,9,11,8,1,1,9,0,10,9,0,11,3,11,0,1,0,8,8,11,0,0,11,10,2,1,8,0,0,0]

theorem envBound38167 : H12AffineFastState.Bounded env38167 := by
  intro p hp
  have h : env38167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38166_38167 : H12AffineEnvironment.transform 1 3 env38166 = env38167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env38166 == env38167) = true)

theorem identity38167 : scanCanonicalize (H12AffineFastState.compose env38167 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound38167 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38168 : List Nat := [2,3,2,0,0,0,3,3,1,2,1,1,3,0,0,3,0,1,3,1,0,1,0,2,2,1,0,0,1,0,2,1,2,0,0,0]

theorem envBound38168 : H12AffineFastState.Bounded env38168 := by
  intro p hp
  have h : env38168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38167_38168 : H12AffineEnvironment.transform 2 2 env38167 = env38168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env38167 == env38168) = true)

theorem identity38168 : scanCanonicalize (H12AffineFastState.compose env38168 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound38168 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38169 : List Nat := [1,0,1,0,0,0,0,0,1,1,1,1,0,0,0,0,0,1,0,1,0,1,0,1,1,1,0,0,1,0,1,1,1,0,0,0]

theorem envBound38169 : H12AffineFastState.Bounded env38169 := by
  intro p hp
  have h : env38169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38168_38169 : H12AffineEnvironment.transform 0 1 env38168 = env38169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env38168 == env38169) = true)

def env38170 : List Nat := [2,4,8,1,32,0,128,256,512,1024,2048,0,1157,1280,137,558,1281,687,1668,136,1,397,1,559,1672,644,1707,1280,644,2976,1161,1165,257,1281,1281,132]

theorem envBound38170 : H12AffineFastState.Bounded env38170 := by
  intro p hp
  have h : env38170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38159_38170 : H12AffineEnvironment.transform 3 1 env38159 = env38170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env38159 == env38170) = true)

theorem identity38170 : scanCanonicalize (H12AffineFastState.compose env38170 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound38170 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env38171 : List Nat := [2,4,8,1,32,0,128,5,512,1024,2048,0,1157,1029,137,558,1028,687,1668,136,1,136,1,559,1672,644,1707,1029,644,2725,1161,1165,4,1028,1028,132]

theorem envBound38171 : H12AffineFastState.Bounded env38171 := by
  intro p hp
  have h : env38171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38170_38171 : H12AffineEnvironment.transform 7 5 env38170 = env38171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env38170 == env38171) = true)

theorem identity38171 : scanCanonicalize (H12AffineFastState.compose env38171 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(8+1) ^^^ 133) := by decide +kernel

theorem selectedBound38171 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env38172 : List Nat := [2,4,8,1,32,0,128,5,133,1024,2048,0,1157,1029,137,171,1028,42,1025,136,1,136,1,170,1037,1,1070,1029,1,2080,1161,1165,4,1028,1028,132]

theorem envBound38172 : H12AffineFastState.Bounded env38172 := by
  intro p hp
  have h : env38172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38171_38172 : H12AffineEnvironment.transform 8 133 env38171 = env38172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 133 env38171 == env38172) = true)

theorem identity38172 : scanCanonicalize (H12AffineFastState.compose env38172 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound38172 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env38173 : List Nat := [2,4,8,1,12,0,128,5,133,1024,2048,0,1157,1029,137,135,1028,6,1025,136,1,136,1,134,1037,1,1026,1029,1,2060,1161,1165,4,1028,1028,132]

theorem envBound38173 : H12AffineFastState.Bounded env38173 := by
  intro p hp
  have h : env38173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38172_38173 : H12AffineEnvironment.transform 4 12 env38172 = env38173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env38172 == env38173) = true)

theorem identity38173 : scanCanonicalize (H12AffineFastState.compose env38173 (packedSelected [1,2,3,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 1025) := by decide +kernel

theorem selectedBound38173 : packedSelected [1,2,3,7,8] rootPS < 2^1333 := by decide +kernel

def env38174 : List Nat := [2,4,8,1,12,0,128,5,133,1024,1025,0,1157,1029,137,135,1028,6,1025,136,1,136,1,134,1037,1,1026,1029,1,1037,1161,1165,4,1028,1028,132]

theorem envBound38174 : H12AffineFastState.Bounded env38174 := by
  intro p hp
  have h : env38174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38173_38174 : H12AffineEnvironment.transform 10 1025 env38173 = env38174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1025 env38173 == env38174) = true)

theorem identity38174 : scanCanonicalize (H12AffineFastState.compose env38174 (packedSelected [0,7,11] rootPS)) = affineNative (2^(9+1) ^^^ 3) := by decide +kernel

theorem selectedBound38174 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env38175 : List Nat := [2,4,8,1,12,0,128,5,133,3,2,0,134,6,137,135,7,6,2,136,1,136,1,134,14,1,1,6,1,14,138,142,4,7,7,132]

theorem envBound38175 : H12AffineFastState.Bounded env38175 := by
  intro p hp
  have h : env38175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38174_38175 : H12AffineEnvironment.transform 9 3 env38174 = env38175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 3 env38174 == env38175) = true)

theorem identity38175 : scanCanonicalize (H12AffineFastState.compose env38175 (packedSelected [2,3] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound38175 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env38176 : List Nat := [1,4,8,1,12,0,128,5,133,0,1,0,133,5,137,132,4,5,1,136,1,136,1,133,13,1,1,5,1,13,137,141,4,4,4,132]

theorem envBound38176 : H12AffineFastState.Bounded env38176 := by
  intro p hp
  have h : env38176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38175_38176 : H12AffineEnvironment.transform 0 1 env38175 = env38176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env38175 == env38176) = true)

theorem identity38176 : scanCanonicalize (H12AffineFastState.compose env38176 (packedSelected [0,1,2] rootPS)) = affineNative (2^(6+1) ^^^ 0) := by decide +kernel

theorem selectedBound38176 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env38177 : List Nat := [1,4,8,1,12,0,0,5,5,0,1,0,5,5,9,4,4,5,1,8,1,8,1,5,13,1,1,5,1,13,9,13,4,4,4,4]

theorem envBound38177 : H12AffineFastState.Bounded env38177 := by
  intro p hp
  have h : env38177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38176_38177 : H12AffineEnvironment.transform 6 0 env38176 = env38177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 0 env38176 == env38177) = true)

theorem identity38177 : scanCanonicalize (H12AffineFastState.compose env38177 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound38177 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38178 : List Nat := [1,0,8,1,8,0,0,1,1,0,1,0,1,1,9,0,0,1,1,8,1,8,1,1,9,1,1,1,1,9,9,9,0,0,0,0]

theorem envBound38178 : H12AffineFastState.Bounded env38178 := by
  intro p hp
  have h : env38178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38177_38178 : H12AffineEnvironment.transform 1 0 env38177 = env38178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env38177 == env38178) = true)

def env38179 : List Nat := [2,4,8,16,32,1,128,256,512,1024,2048,16,1156,1297,137,65536,1280,65665,66746,136,17,413,16,65536,66743,65723,66693,1297,65722,67998,1160,1164,257,1281,1280,66234]

theorem envBound38179 : H12AffineFastState.Bounded env38179 := by
  intro p hp
  have h : env38179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38157_38179 : H12AffineEnvironment.transform 5 1 env38157 = env38179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env38157 == env38179) = true)

theorem identity38179 : scanCanonicalize (H12AffineFastState.compose env38179 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 947) := by decide +kernel

theorem selectedBound38179 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env38180 : List Nat := [2,4,8,16,32,1,128,256,512,1024,2048,16,1156,1297,137,947,1280,818,1801,136,17,413,16,947,1796,776,1846,1297,777,2605,1160,1164,257,1281,1280,265]

theorem envBound38180 : H12AffineFastState.Bounded env38180 := by
  intro p hp
  have h : env38180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38179_38180 : H12AffineEnvironment.transform 15 947 env38179 = env38180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 947 env38179 == env38180) = true)

def env38181 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,0,1156,1281,137,931,1280,802,1801,136,1,397,0,931,1796,776,1830,1281,777,2605,1160,1164,257,1281,1280,265]

theorem envBound38181 : H12AffineFastState.Bounded env38181 := by
  intro p hp
  have h : env38181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38180_38181 : H12AffineEnvironment.transform 3 0 env38180 = env38181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env38180 == env38181) = true)

theorem identity38181 : scanCanonicalize (H12AffineFastState.compose env38181 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound38181 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env38182 : List Nat := [2,4,8,0,32,1,128,4,512,1024,2048,0,1156,1029,137,679,1028,550,1549,136,1,137,0,679,1536,524,1570,1029,525,2605,1160,1164,5,1029,1028,13]

theorem envBound38182 : H12AffineFastState.Bounded env38182 := by
  intro p hp
  have h : env38182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38181_38182 : H12AffineEnvironment.transform 7 4 env38181 = env38182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env38181 == env38182) = true)

theorem identity38182 : scanCanonicalize (H12AffineFastState.compose env38182 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(8+1) ^^^ 12) := by decide +kernel

theorem selectedBound38182 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env38183 : List Nat := [2,4,8,0,32,1,128,4,12,1024,2048,0,1156,1029,137,171,1028,42,1025,136,1,137,0,171,1036,0,1070,1029,1,2081,1160,1164,5,1029,1028,13]

theorem envBound38183 : H12AffineFastState.Bounded env38183 := by
  intro p hp
  have h : env38183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38182_38183 : H12AffineEnvironment.transform 8 12 env38182 = env38183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 12 env38182 == env38183) = true)

theorem identity38183 : scanCanonicalize (H12AffineFastState.compose env38183 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 37) := by decide +kernel

theorem selectedBound38183 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env38184 : List Nat := [2,4,8,0,32,1,37,4,12,1024,2048,0,1057,1029,44,14,1028,42,1025,45,1,44,0,14,1036,0,1070,1029,1,2081,1069,1065,5,1029,1028,13]

theorem envBound38184 : H12AffineFastState.Bounded env38184 := by
  intro p hp
  have h : env38184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38183_38184 : H12AffineEnvironment.transform 6 37 env38183 = env38184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 37 env38183 == env38184) = true)

theorem identity38184 : scanCanonicalize (H12AffineFastState.compose env38184 (packedSelected [1,2,3,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 1025) := by decide +kernel

theorem selectedBound38184 : packedSelected [1,2,3,7,8] rootPS < 2^1333 := by decide +kernel

def env38185 : List Nat := [2,4,8,0,32,1,37,4,12,1024,1025,0,1057,1029,44,14,1028,42,1025,45,1,44,0,14,1036,0,1070,1029,1,1056,1069,1065,5,1029,1028,13]

theorem envBound38185 : H12AffineFastState.Bounded env38185 := by
  intro p hp
  have h : env38185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38184_38185 : H12AffineEnvironment.transform 10 1025 env38184 = env38185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1025 env38184 == env38185) = true)

theorem identity38185 : scanCanonicalize (H12AffineFastState.compose env38185 (packedSelected [0,7,11] rootPS)) = affineNative (2^(9+1) ^^^ 47) := by decide +kernel

theorem selectedBound38185 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env38186 : List Nat := [2,4,8,0,32,1,37,4,12,47,46,0,14,42,44,14,43,42,46,45,1,44,0,14,35,0,1,42,1,15,2,6,5,42,43,13]

theorem envBound38186 : H12AffineFastState.Bounded env38186 := by
  intro p hp
  have h : env38186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38185_38186 : H12AffineEnvironment.transform 9 47 env38185 = env38186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 47 env38185 == env38186) = true)

theorem identity38186 : scanCanonicalize (H12AffineFastState.compose env38186 (packedSelected [2,3] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound38186 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env38187 : List Nat := [2,0,8,0,32,1,33,0,8,43,42,0,10,42,40,10,43,42,42,41,1,40,0,10,35,0,1,42,1,11,2,2,1,42,43,9]

theorem envBound38187 : H12AffineFastState.Bounded env38187 := by
  intro p hp
  have h : env38187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38186_38187 : H12AffineEnvironment.transform 1 0 env38186 = env38187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env38186 == env38187) = true)

theorem identity38187 : scanCanonicalize (H12AffineFastState.compose env38187 (packedSelected [1,2,4] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound38187 : packedSelected [1,2,4] rootPS < 2^1333 := by decide +kernel

def env38188 : List Nat := [2,0,8,0,3,1,2,0,8,8,9,0,10,9,11,10,8,9,9,10,1,11,0,10,0,0,1,9,1,11,2,2,1,9,8,9]

theorem envBound38188 : H12AffineFastState.Bounded env38188 := by
  intro p hp
  have h : env38188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38187_38188 : H12AffineEnvironment.transform 4 3 env38187 = env38188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env38187 == env38188) = true)

theorem identity38188 : scanCanonicalize (H12AffineFastState.compose env38188 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound38188 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38189 : List Nat := [2,0,1,0,3,1,2,0,1,1,0,0,3,0,2,3,1,0,0,3,1,2,0,3,0,0,1,0,1,2,2,2,1,0,1,0]

theorem envBound38189 : H12AffineFastState.Bounded env38189 := by
  intro p hp
  have h : env38189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38188_38189 : H12AffineEnvironment.transform 2 1 env38188 = env38189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env38188 == env38189) = true)

def env38190 : List Nat := [2,4,8,1,32,1,128,256,512,1024,2048,1,1156,1280,137,930,1280,803,1801,136,0,396,1,930,1796,776,1831,1280,777,2605,1160,1164,257,1281,1280,265]

theorem envBound38190 : H12AffineFastState.Bounded env38190 := by
  intro p hp
  have h : env38190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38180_38190 : H12AffineEnvironment.transform 3 1 env38180 = env38190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env38180 == env38190) = true)

theorem identity38190 : scanCanonicalize (H12AffineFastState.compose env38190 (packedSelected [4,9,16] rootPS)) = affineNative (2^(8+1) ^^^ 13) := by decide +kernel

theorem selectedBound38190 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env38191 : List Nat := [2,4,8,1,32,1,128,256,13,1024,2048,1,1156,1280,137,431,1280,302,1284,136,0,396,1,431,1289,261,1322,1280,260,2080,1160,1164,257,1281,1280,265]

theorem envBound38191 : H12AffineFastState.Bounded env38191 := by
  intro p hp
  have h : env38191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38190_38191 : H12AffineEnvironment.transform 8 13 env38190 = env38191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 13 env38190 == env38191) = true)

theorem identity38191 : scanCanonicalize (H12AffineFastState.compose env38191 (packedSelected [3,4,5,9,10,11,17,18,19,21,23] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound38191 : packedSelected [3,4,5,9,10,11,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env38192 : List Nat := [2,4,8,1,32,1,128,256,13,1024,11,1,1156,1280,137,431,1280,302,1284,136,0,396,1,431,1289,261,1322,1280,260,43,1160,1164,257,1281,1280,265]

theorem envBound38192 : H12AffineFastState.Bounded env38192 := by
  intro p hp
  have h : env38192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38191_38192 : H12AffineEnvironment.transform 10 11 env38191 = env38192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env38191 == env38192) = true)

theorem identity38192 : scanCanonicalize (H12AffineFastState.compose env38192 (packedSelected [1,5,7,9,10,13] rootPS)) = affineNative (2^(9+1) ^^^ 388) := by decide +kernel

theorem selectedBound38192 : packedSelected [1,5,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env38193 : List Nat := [2,4,8,1,32,1,128,256,13,388,11,1,256,132,137,431,132,302,128,136,0,396,1,431,141,261,174,132,260,43,268,264,257,133,132,265]

theorem envBound38193 : H12AffineFastState.Bounded env38193 := by
  intro p hp
  have h : env38193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38192_38193 : H12AffineEnvironment.transform 9 388 env38192 = env38193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 388 env38192 == env38193) = true)

theorem identity38193 : scanCanonicalize (H12AffineFastState.compose env38193 (packedSelected [0,2,4,5,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound38193 : packedSelected [0,2,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env38194 : List Nat := [2,4,8,1,6,1,128,256,13,388,11,1,256,132,137,393,132,264,128,136,0,396,1,393,141,261,136,132,260,13,268,264,257,133,132,265]

theorem envBound38194 : H12AffineFastState.Bounded env38194 := by
  intro p hp
  have h : env38194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38193_38194 : H12AffineEnvironment.transform 4 6 env38193 = env38194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env38193 == env38194) = true)

theorem identity38194 : scanCanonicalize (H12AffineFastState.compose env38194 (packedSelected [2,3,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 15) := by decide +kernel

theorem selectedBound38194 : packedSelected [2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env38195 : List Nat := [2,4,8,1,6,1,15,256,13,267,11,1,256,11,6,262,11,264,15,7,0,259,1,262,2,261,7,11,260,13,268,264,257,10,11,265]

theorem envBound38195 : H12AffineFastState.Bounded env38195 := by
  intro p hp
  have h : env38195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38194_38195 : H12AffineEnvironment.transform 6 15 env38194 = env38195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 15 env38194 == env38195) = true)

theorem identity38195 : scanCanonicalize (H12AffineFastState.compose env38195 (packedSelected [0,1,4] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound38195 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env38196 : List Nat := [2,4,4,1,6,1,3,256,1,263,7,1,256,7,6,262,7,260,3,7,0,259,1,262,2,261,7,7,260,1,256,260,257,6,7,261]

theorem envBound38196 : H12AffineFastState.Bounded env38196 := by
  intro p hp
  have h : env38196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38195_38196 : H12AffineEnvironment.transform 2 4 env38195 = env38196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env38195 == env38196) = true)

theorem identity38196 : scanCanonicalize (H12AffineFastState.compose env38196 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound38196 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38197 : List Nat := [2,3,3,1,1,1,3,256,1,256,0,1,256,0,1,257,0,259,3,0,0,259,1,257,2,258,0,0,259,1,256,259,257,1,0,258]

theorem envBound38197 : H12AffineFastState.Bounded env38197 := by
  intro p hp
  have h : env38197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38196_38197 : H12AffineEnvironment.transform 1 3 env38196 = env38197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env38196 == env38197) = true)

theorem identity38197 : scanCanonicalize (H12AffineFastState.compose env38197 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 2) := by decide +kernel

theorem selectedBound38197 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38198 : List Nat := [2,3,3,1,1,1,3,2,1,2,0,1,2,0,1,3,0,1,3,0,0,1,1,3,2,0,0,0,1,1,2,1,3,1,0,0]

theorem envBound38198 : H12AffineFastState.Bounded env38198 := by
  intro p hp
  have h : env38198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38197_38198 : H12AffineEnvironment.transform 7 2 env38197 = env38198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 2 env38197 == env38198) = true)

theorem identity38198 : scanCanonicalize (H12AffineFastState.compose env38198 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound38198 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38199 : List Nat := [1,0,0,1,1,1,0,1,1,1,0,1,1,0,1,0,0,1,0,0,0,1,1,0,1,0,0,0,1,1,1,1,0,1,0,0]

theorem envBound38199 : H12AffineFastState.Bounded env38199 := by
  intro p hp
  have h : env38199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38198_38199 : H12AffineEnvironment.transform 0 1 env38198 = env38199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env38198 == env38199) = true)

def env38200 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16465,262144,95614,32769,4097,61648,17,284032,86519,94527,77840,1296,74814,96346,381313,381317,257,1281,1345,95102]

theorem envBound38200 : H12AffineFastState.Bounded env38200 := by
  intro p hp
  have h : env38200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38078_38200 : H12AffineEnvironment.transform 16 16465 env38078 = env38200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16465 env38078 == env38200) = true)

def env38201 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1345,262144,77934,32769,4097,46528,17,266384,70887,78895,77840,1296,74814,81226,365713,365717,257,1281,1345,79470]

theorem envBound38201 : H12AffineFastState.Bounded env38201 := by
  intro p hp
  have h : env38201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38200_38201 : H12AffineEnvironment.transform 13 1296 env38200 = env38201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env38200 == env38201) = true)

theorem identity38201 : scanCanonicalize (H12AffineFastState.compose env38201 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound38201 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env38202 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1345,262144,77934,13340,4097,477,17,266384,70887,78895,77840,1296,74814,81226,336012,336008,257,1281,1345,79470]

theorem envBound38202 : H12AffineFastState.Bounded env38202 := by
  intro p hp
  have h : env38202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38201_38202 : H12AffineEnvironment.transform 14 13341 env38201 = env38202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env38201 == env38202) = true)

def env38203 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1345,65664,77934,13340,4097,477,17,69648,70887,78895,77840,1296,74814,81226,8204,8200,257,1281,1345,79470]

theorem envBound38203 : H12AffineFastState.Bounded env38203 := by
  intro p hp
  have h : env38203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38202_38203 : H12AffineEnvironment.transform 17 65664 env38202 = env38203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env38202 == env38203) = true)

theorem identity38203 : scanCanonicalize (H12AffineFastState.compose env38203 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5464) := by decide +kernel

theorem selectedBound38203 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env38204 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5464,1296,325,65536,1345,65664,66870,324,4097,477,17,69648,70887,65911,66888,1296,69990,67602,5460,5456,257,1281,1345,66358]

theorem envBound38204 : H12AffineFastState.Bounded env38204 := by
  intro p hp
  have h : env38204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38203_38204 : H12AffineEnvironment.transform 12 5464 env38203 = env38204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5464 env38203 == env38204) = true)

def env38205 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,5384,1296,277,65536,1297,65664,66870,276,4097,397,17,69648,70839,65831,66840,1296,69942,67602,5380,5376,257,1281,1297,66358]

theorem envBound38205 : H12AffineFastState.Bounded env38205 := by
  intro p hp
  have h : env38205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38204_38205 : H12AffineEnvironment.transform 5 16 env38204 = env38205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38204 == env38205) = true)

theorem identity38205 : scanCanonicalize (H12AffineFastState.compose env38205 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound38205 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env38206 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,277,1053,1296,277,65536,1297,65664,66870,276,276,397,17,65797,66978,65831,66840,1296,65571,67602,1041,1045,257,1281,1297,66358]

theorem envBound38206 : H12AffineFastState.Bounded env38206 := by
  intro p hp
  have h : env38206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38205_38206 : H12AffineEnvironment.transform 11 277 env38205 = env38206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env38205 == env38206) = true)

theorem identity38206 : scanCanonicalize (H12AffineFastState.compose env38206 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 310) := by decide +kernel

theorem selectedBound38206 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env38207 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,277,1053,1296,277,310,1297,438,1024,276,276,397,17,51,1172,17,1070,1296,277,2340,1041,1045,257,1281,1297,512]

theorem envBound38207 : H12AffineFastState.Bounded env38207 := by
  intro p hp
  have h : env38207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38206_38207 : H12AffineEnvironment.transform 15 310 env38206 = env38207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 310 env38206 == env38207) = true)

theorem identity38207 : scanCanonicalize (H12AffineFastState.compose env38207 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 276) := by decide +kernel

theorem selectedBound38207 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env38208 : List Nat := [2,4,8,16,32,16,128,256,512,1024,276,277,1053,1296,277,310,1297,438,1024,276,276,397,17,51,1172,17,1070,1296,277,48,1041,1045,257,1281,1297,512]

theorem envBound38208 : H12AffineFastState.Bounded env38208 := by
  intro p hp
  have h : env38208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38207_38208 : H12AffineEnvironment.transform 10 276 env38207 = env38208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 276 env38207 == env38208) = true)

theorem identity38208 : scanCanonicalize (H12AffineFastState.compose env38208 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(9+1) ^^^ 784) := by decide +kernel

theorem selectedBound38208 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env38209 : List Nat := [2,4,8,16,32,16,128,256,512,784,276,277,781,512,277,310,513,438,784,276,276,397,17,51,900,17,830,512,277,48,769,773,257,529,513,512]

theorem envBound38209 : H12AffineFastState.Bounded env38209 := by
  intro p hp
  have h : env38209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38208_38209 : H12AffineEnvironment.transform 9 784 env38208 = env38209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 784 env38208 == env38209) = true)

theorem identity38209 : scanCanonicalize (H12AffineFastState.compose env38209 (packedSelected [0,2,8] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound38209 : packedSelected [0,2,8] rootPS < 2^1333 := by decide +kernel

def env38210 : List Nat := [2,4,8,16,32,16,18,256,512,784,276,277,781,512,277,310,513,292,784,276,276,287,17,51,790,17,830,512,277,48,769,773,257,529,513,512]

theorem envBound38210 : H12AffineFastState.Bounded env38210 := by
  intro p hp
  have h : env38210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38209_38210 : H12AffineEnvironment.transform 6 18 env38209 = env38210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env38209 == env38210) = true)

theorem identity38210 : scanCanonicalize (H12AffineFastState.compose env38210 (packedSelected [0,3] rootPS)) = affineNative (2^(8+1) ^^^ 270) := by decide +kernel

theorem selectedBound38210 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env38211 : List Nat := [2,4,8,16,32,16,18,256,270,30,276,277,3,270,277,310,271,292,30,276,276,287,17,51,24,17,48,270,277,48,15,11,257,287,271,270]

theorem envBound38211 : H12AffineFastState.Bounded env38211 := by
  intro p hp
  have h : env38211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38210_38211 : H12AffineEnvironment.transform 8 270 env38210 = env38211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 270 env38210 == env38211) = true)

theorem identity38211 : scanCanonicalize (H12AffineFastState.compose env38211 (packedSelected [0,2,5] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound38211 : packedSelected [0,2,5] rootPS < 2^1333 := by decide +kernel

def env38212 : List Nat := [2,4,8,16,32,16,18,15,1,30,27,26,3,1,26,57,0,43,30,27,27,16,17,51,24,17,48,1,26,48,15,11,14,16,0,1]

theorem envBound38212 : H12AffineFastState.Bounded env38212 := by
  intro p hp
  have h : env38212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38211_38212 : H12AffineEnvironment.transform 7 15 env38211 = env38212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env38211 == env38212) = true)

def env38213 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,5385,1296,276,65536,1296,65664,66870,277,4097,396,17,69648,70838,65830,66841,1296,69943,67602,5381,5377,257,1281,1296,66358]

theorem envBound38213 : H12AffineFastState.Bounded env38213 := by
  intro p hp
  have h : env38213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38204_38213 : H12AffineEnvironment.transform 5 17 env38204 = env38213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env38204 == env38213) = true)

theorem identity38213 : scanCanonicalize (H12AffineFastState.compose env38213 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 4131) := by decide +kernel

theorem selectedBound38213 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env38214 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,5385,1296,276,4131,1296,4259,5397,277,4097,396,17,51,1173,4357,5434,1296,276,6193,5381,5377,257,1281,1296,4885]

theorem envBound38214 : H12AffineFastState.Bounded env38214 := by
  intro p hp
  have h : env38214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38213_38214 : H12AffineEnvironment.transform 15 4131 env38213 = env38214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4131 env38213 == env38214) = true)

def env38215 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1345,65665,77934,13340,4097,477,17,69649,70887,78895,77840,1296,74814,81226,8205,8201,257,1281,1345,79470]

theorem envBound38215 : H12AffineFastState.Bounded env38215 := by
  intro p hp
  have h : env38215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38202_38215 : H12AffineEnvironment.transform 17 65665 env38202 = env38215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env38202 == env38215) = true)

theorem identity38215 : scanCanonicalize (H12AffineFastState.compose env38215 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound38215 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env38216 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,24,1296,5125,65536,1345,65665,69750,5124,4097,477,17,69649,70887,70711,69640,1296,66598,73042,21,17,257,1281,1345,71286]

theorem envBound38216 : H12AffineFastState.Bounded env38216 := by
  intro p hp
  have h : env38216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38215_38216 : H12AffineEnvironment.transform 12 24 env38215 = env38216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env38215 == env38216) = true)

def env38217 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,24,1296,5125,65536,1297,65665,69670,5124,4097,397,17,69649,70839,70711,69640,1296,66598,72962,21,17,257,1281,1297,71206]

theorem envBound38217 : H12AffineFastState.Bounded env38217 := by
  intro p hp
  have h : env38217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38216_38217 : H12AffineEnvironment.transform 5 16 env38216 = env38217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38216 == env38217) = true)

theorem identity38217 : scanCanonicalize (H12AffineFastState.compose env38217 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound38217 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env38218 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,277,24,1296,1296,65536,1297,65665,65843,1297,276,397,17,65796,66978,66850,65821,1296,66598,68631,21,17,257,1281,1297,67379]

theorem envBound38218 : H12AffineFastState.Bounded env38218 := by
  intro p hp
  have h : env38218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38217_38218 : H12AffineEnvironment.transform 11 277 env38217 = env38218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env38217 == env38218) = true)

theorem identity38218 : scanCanonicalize (H12AffineFastState.compose env38218 (packedSelected [1,2,5,8,13,19,21,23,24,26,32] rootPS)) = affineNative (2^(15+1) ^^^ 682) := by decide +kernel

theorem selectedBound38218 : packedSelected [1,2,5,8,13,19,21,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env38219 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,277,24,1296,1296,682,1297,555,921,1297,276,397,17,942,1800,1928,951,1296,1676,3773,21,17,257,1281,1297,1433]

theorem envBound38219 : H12AffineFastState.Bounded env38219 := by
  intro p hp
  have h : env38219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38218_38219 : H12AffineEnvironment.transform 15 682 env38218 = env38219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 682 env38218 == env38219) = true)

theorem identity38219 : scanCanonicalize (H12AffineFastState.compose env38219 (packedSelected [0,3,4,5,7,9,10,18,21,23,24,28] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound38219 : packedSelected [0,3,4,5,7,9,10,18,21,23,24,28] rootPS < 2^1333 := by decide +kernel

def env38220 : List Nat := [2,4,8,16,32,16,57,256,512,1024,2048,277,24,1296,1296,531,1297,555,800,1297,276,308,17,791,1800,1841,782,1296,1589,3588,21,17,257,1281,1297,1312]

theorem envBound38220 : H12AffineFastState.Bounded env38220 := by
  intro p hp
  have h : env38220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38219_38220 : H12AffineEnvironment.transform 6 57 env38219 = env38220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env38219 == env38220) = true)

theorem identity38220 : scanCanonicalize (H12AffineFastState.compose env38220 (packedSelected [0,2,3,4,5,7,9,10,11,18] rootPS)) = affineNative (2^(10+1) ^^^ 1070) := by decide +kernel

theorem selectedBound38220 : packedSelected [0,2,3,4,5,7,9,10,11,18] rootPS < 2^1333 := by decide +kernel

def env38221 : List Nat := [2,4,8,16,32,16,57,256,512,1024,1070,277,24,1296,1296,531,1297,555,800,1297,276,308,17,791,1800,1841,782,1296,1589,554,21,17,257,1281,1297,1312]

theorem envBound38221 : H12AffineFastState.Bounded env38221 := by
  intro p hp
  have h : env38221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38220_38221 : H12AffineEnvironment.transform 10 1070 env38220 = env38221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1070 env38220 == env38221) = true)

theorem identity38221 : scanCanonicalize (H12AffineFastState.compose env38221 (packedSelected [0,4,11] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound38221 : packedSelected [0,4,11] rootPS < 2^1333 := by decide +kernel

def env38222 : List Nat := [2,4,8,16,32,16,57,256,512,517,555,277,24,789,789,531,788,555,800,788,276,308,17,791,269,308,782,789,48,554,21,17,257,772,788,805]

theorem envBound38222 : H12AffineFastState.Bounded env38222 := by
  intro p hp
  have h : env38222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38221_38222 : H12AffineEnvironment.transform 9 517 env38221 = env38222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env38221 == env38222) = true)

theorem identity38222 : scanCanonicalize (H12AffineFastState.compose env38222 (packedSelected [2,3,8] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound38222 : packedSelected [2,3,8] rootPS < 2^1333 := by decide +kernel

def env38223 : List Nat := [2,4,8,16,16,16,9,256,512,517,539,277,24,789,789,531,788,539,784,788,276,260,17,791,269,260,782,789,0,538,21,17,257,772,788,789]

theorem envBound38223 : H12AffineFastState.Bounded env38223 := by
  intro p hp
  have h : env38223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38222_38223 : H12AffineEnvironment.transform 4 16 env38222 = env38223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env38222 == env38223) = true)

def env38224 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,24,1296,5125,65536,1296,65665,69671,5124,4097,396,17,69649,70838,70711,69640,1296,66598,72963,21,17,257,1281,1296,71207]

theorem envBound38224 : H12AffineFastState.Bounded env38224 := by
  intro p hp
  have h : env38224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38216_38224 : H12AffineEnvironment.transform 5 17 env38216 = env38224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env38216 == env38224) = true)

theorem identity38224 : scanCanonicalize (H12AffineFastState.compose env38224 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 1330) := by decide +kernel

theorem selectedBound38224 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env38225 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,24,1296,5125,1330,1296,1459,5397,5124,4097,396,17,5411,4484,4357,5434,1296,276,6193,21,17,257,1281,1296,4885]

theorem envBound38225 : H12AffineFastState.Bounded env38225 := by
  intro p hp
  have h : env38225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38224_38225 : H12AffineEnvironment.transform 15 1330 env38224 = env38225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1330 env38224 == env38225) = true)

theorem identity38225 : scanCanonicalize (H12AffineFastState.compose env38225 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound38225 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env38226 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,276,24,1296,1297,1330,1296,1459,1025,1296,277,396,17,1079,144,17,1070,1296,276,2341,21,17,257,1281,1296,513]

theorem envBound38226 : H12AffineFastState.Bounded env38226 := by
  intro p hp
  have h : env38226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38225_38226 : H12AffineEnvironment.transform 11 276 env38225 = env38226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env38225 == env38226) = true)

theorem identity38226 : scanCanonicalize (H12AffineFastState.compose env38226 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 549) := by decide +kernel

theorem selectedBound38226 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env38227 : List Nat := [2,4,8,16,32,17,128,256,512,549,2048,276,24,821,820,791,821,918,548,821,277,396,17,530,144,17,523,821,276,2341,21,17,257,804,821,513]

theorem envBound38227 : H12AffineFastState.Bounded env38227 := by
  intro p hp
  have h : env38227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38226_38227 : H12AffineEnvironment.transform 9 549 env38226 = env38227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 549 env38226 == env38227) = true)

theorem identity38227 : scanCanonicalize (H12AffineFastState.compose env38227 (packedSelected [0,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 799) := by decide +kernel

theorem selectedBound38227 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env38228 : List Nat := [2,4,8,16,32,17,128,256,512,549,799,276,24,821,820,791,821,918,548,821,277,396,17,530,144,17,523,821,276,570,21,17,257,804,821,513]

theorem envBound38228 : H12AffineFastState.Bounded env38228 := by
  intro p hp
  have h : env38228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38227_38228 : H12AffineEnvironment.transform 10 799 env38227 = env38228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 799 env38227 == env38228) = true)

theorem identity38228 : scanCanonicalize (H12AffineFastState.compose env38228 (packedSelected [12,13,15] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound38228 : packedSelected [12,13,15] rootPS < 2^1333 := by decide +kernel

def env38229 : List Nat := [2,4,8,16,32,17,128,21,512,549,522,1,24,544,545,514,544,643,548,544,0,153,17,530,144,17,523,544,1,570,21,17,20,561,544,513]

theorem envBound38229 : H12AffineFastState.Bounded env38229 := by
  intro p hp
  have h : env38229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38228_38229 : H12AffineEnvironment.transform 7 21 env38228 = env38229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env38228 == env38229) = true)

theorem identity38229 : scanCanonicalize (H12AffineFastState.compose env38229 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound38229 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38230 : List Nat := [2,4,8,1,32,0,128,4,512,549,522,1,9,544,545,514,544,643,548,544,0,136,0,515,129,0,523,544,1,555,4,0,5,544,544,513]

theorem envBound38230 : H12AffineFastState.Bounded env38230 := by
  intro p hp
  have h : env38230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38229_38230 : H12AffineEnvironment.transform 3 1 env38229 = env38230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env38229 == env38230) = true)

theorem identity38230 : scanCanonicalize (H12AffineFastState.compose env38230 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 162) := by decide +kernel

theorem selectedBound38230 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env38231 : List Nat := [2,4,8,1,32,0,128,4,162,135,168,1,9,130,131,160,130,33,134,130,0,136,0,161,129,0,169,130,1,137,4,0,5,130,130,163]

theorem envBound38231 : H12AffineFastState.Bounded env38231 := by
  intro p hp
  have h : env38231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38230_38231 : H12AffineEnvironment.transform 8 162 env38230 = env38231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 162 env38230 == env38231) = true)

theorem identity38231 : scanCanonicalize (H12AffineFastState.compose env38231 (packedSelected [1,4] rootPS)) = affineNative (2^(6+1) ^^^ 10) := by decide +kernel

theorem selectedBound38231 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env38232 : List Nat := [2,4,8,1,32,0,10,4,40,13,34,1,9,8,9,42,8,33,12,8,0,2,0,43,11,0,35,8,1,3,4,0,5,8,8,41]

theorem envBound38232 : H12AffineFastState.Bounded env38232 := by
  intro p hp
  have h : env38232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38231_38232 : H12AffineEnvironment.transform 6 10 env38231 = env38232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 10 env38231 == env38232) = true)

theorem identity38232 : scanCanonicalize (H12AffineFastState.compose env38232 (packedSelected [0,7] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound38232 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env38233 : List Nat := [2,4,3,1,32,0,1,4,35,6,34,1,2,3,2,33,3,33,7,3,0,2,0,32,0,0,35,3,1,3,4,0,5,3,3,34]

theorem envBound38233 : H12AffineFastState.Bounded env38233 := by
  intro p hp
  have h : env38233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38232_38233 : H12AffineEnvironment.transform 2 3 env38232 = env38233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env38232 == env38233) = true)

theorem identity38233 : scanCanonicalize (H12AffineFastState.compose env38233 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound38233 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env38234 : List Nat := [2,4,3,1,2,0,1,4,1,6,0,1,2,3,2,3,3,3,7,3,0,2,0,2,0,0,1,3,1,3,4,0,5,3,3,0]

theorem envBound38234 : H12AffineFastState.Bounded env38234 := by
  intro p hp
  have h : env38234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38233_38234 : H12AffineEnvironment.transform 4 2 env38233 = env38234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env38233 == env38234) = true)

theorem identity38234 : scanCanonicalize (H12AffineFastState.compose env38234 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound38234 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38235 : List Nat := [2,3,3,1,2,0,1,3,1,1,0,1,2,3,2,3,3,3,0,3,0,2,0,2,0,0,1,3,1,3,3,0,2,3,3,0]

theorem envBound38235 : H12AffineFastState.Bounded env38235 := by
  intro p hp
  have h : env38235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38234_38235 : H12AffineEnvironment.transform 1 3 env38234 = env38235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env38234 == env38235) = true)

theorem identity38235 : scanCanonicalize (H12AffineFastState.compose env38235 (packedSelected [5] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound38235 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env38236 : List Nat := [1,0,0,1,1,0,1,0,1,1,0,1,1,0,1,0,0,0,0,0,0,1,0,1,0,0,1,0,1,0,0,0,1,0,0,0]

theorem envBound38236 : H12AffineFastState.Bounded env38236 := by
  intro p hp
  have h : env38236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38235_38236 : H12AffineEnvironment.transform 0 1 env38235 = env38236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env38235 == env38236) = true)

def env38237 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1344,262144,77935,32769,4097,46529,17,266385,70886,78894,77840,1296,74814,81227,365712,365716,257,1281,1345,79471]

theorem envBound38237 : H12AffineFastState.Bounded env38237 := by
  intro p hp
  have h : env38237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38200_38237 : H12AffineEnvironment.transform 13 1297 env38200 = env38237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env38200 == env38237) = true)

theorem identity38237 : scanCanonicalize (H12AffineFastState.compose env38237 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32883) := by decide +kernel

theorem selectedBound38237 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env38238 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,32883,1344,262144,45084,32769,4097,46529,17,266385,38037,46173,45155,1296,42061,48440,267491,267495,257,1281,1345,46620]

theorem envBound38238 : H12AffineFastState.Bounded env38238 := by
  intro p hp
  have h : env38238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38237_38238 : H12AffineEnvironment.transform 15 32883 env38237 = env38238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32883 env38237 == env38238) = true)

def env38239 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32883,1344,262144,42332,32769,1345,41089,17,263633,33237,41245,42275,1296,42061,43128,262563,262567,257,1281,1345,41820]

theorem envBound38239 : H12AffineFastState.Bounded env38239 := by
  intro p hp
  have h : env38239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38238_38239 : H12AffineEnvironment.transform 11 1344 env38238 = env38239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env38238 == env38239) = true)

theorem identity38239 : scanCanonicalize (H12AffineFastState.compose env38239 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 9406) := by decide +kernel

theorem selectedBound38239 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env38240 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32883,1344,9406,42332,32769,1345,41089,17,8559,33237,41245,42275,1296,42061,43128,9501,9497,257,1281,1345,41820]

theorem envBound38240 : H12AffineFastState.Bounded env38240 := by
  intro p hp
  have h : env38240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38239_38240 : H12AffineEnvironment.transform 17 9406 env38239 = env38240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 9406 env38239 == env38240) = true)

theorem identity38240 : scanCanonicalize (H12AffineFastState.compose env38240 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(12+1) ^^^ 705) := by decide +kernel

theorem selectedBound38240 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env38241 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,705,1297,32768,32883,1344,1663,34717,32769,1345,33344,17,942,33237,33756,34786,1296,34444,35513,2012,2008,257,1281,1345,33181]

theorem envBound38241 : H12AffineFastState.Bounded env38241 := by
  intro p hp
  have h : env38241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38240_38241 : H12AffineEnvironment.transform 12 705 env38240 = env38241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 705 env38240 == env38241) = true)

def env38242 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32883,1344,262144,42333,32769,1344,41088,17,263632,33236,41244,42274,1296,42061,43129,262562,262566,257,1281,1345,41821]

theorem envBound38242 : H12AffineFastState.Bounded env38242 := by
  intro p hp
  have h : env38242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38238_38242 : H12AffineEnvironment.transform 11 1345 env38238 = env38242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env38238 == env38242) = true)

theorem identity38242 : scanCanonicalize (H12AffineFastState.compose env38242 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 9292) := by decide +kernel

theorem selectedBound38242 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env38243 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,9292,9279,1344,262144,273,9293,1344,1228,17,263632,9624,1360,366,1296,1,3125,262562,262566,257,1281,1345,1809]

theorem envBound38243 : H12AffineFastState.Bounded env38243 := by
  intro p hp
  have h : env38243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38242_38243 : H12AffineEnvironment.transform 14 9292 env38242 = env38243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9292 env38242 == env38243) = true)

theorem identity38243 : scanCanonicalize (H12AffineFastState.compose env38243 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound38243 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env38244 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,80,8192,0,8541,8494,81,262144,273,8540,81,477,17,262337,8329,65,366,1,1,2340,262562,262566,257,16,80,512]

theorem envBound38244 : H12AffineFastState.Bounded env38244 := by
  intro p hp
  have h : env38244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38243_38244 : H12AffineEnvironment.transform 9 273 env38243 = env38244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env38243 == env38244) = true)

theorem identity38244 : scanCanonicalize (H12AffineFastState.compose env38244 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound38244 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env38245 : List Nat := [2,4,8,16,32,64,128,69,512,84,2048,80,8192,0,8216,8299,81,262144,84,8217,81,152,17,262337,8329,65,43,1,1,2145,262375,262371,68,16,80,512]

theorem envBound38245 : H12AffineFastState.Bounded env38245 := by
  intro p hp
  have h : env38245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38244_38245 : H12AffineEnvironment.transform 7 69 env38244 = env38245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env38244 == env38245) = true)

theorem identity38245 : scanCanonicalize (H12AffineFastState.compose env38245 (packedSelected [3,5,10] rootPS)) = affineNative (2^(17+1) ^^^ 8754) := by decide +kernel

theorem selectedBound38245 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env38246 : List Nat := [2,4,8,16,32,64,128,69,512,84,2048,80,8192,0,8216,8299,81,8754,84,8217,81,152,17,8947,8329,65,43,1,1,2145,8917,8913,68,16,80,512]

theorem envBound38246 : H12AffineFastState.Bounded env38246 := by
  intro p hp
  have h : env38246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38245_38246 : H12AffineEnvironment.transform 17 8754 env38245 = env38246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8754 env38245 == env38246) = true)

theorem identity38246 : scanCanonicalize (H12AffineFastState.compose env38246 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound38246 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env38247 : List Nat := [2,4,8,16,32,16,128,21,512,4,2048,0,8192,0,8216,8251,1,8754,4,8217,1,152,17,8867,8329,17,43,1,1,2097,8837,8833,20,16,0,512]

theorem envBound38247 : H12AffineFastState.Bounded env38247 := by
  intro p hp
  have h : env38247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38246_38247 : H12AffineEnvironment.transform 5 16 env38246 = env38247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38246 == env38247) = true)

theorem identity38247 : scanCanonicalize (H12AffineFastState.compose env38247 (packedSelected [1,3,13] rootPS)) = affineNative (2^(12+1) ^^^ 553) := by decide +kernel

theorem selectedBound38247 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env38248 : List Nat := [2,4,8,16,32,16,128,21,512,4,2048,0,553,0,561,530,1,27,4,560,1,152,17,138,672,17,43,1,1,2097,172,168,20,16,0,512]

theorem envBound38248 : H12AffineFastState.Bounded env38248 := by
  intro p hp
  have h : env38248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38247_38248 : H12AffineEnvironment.transform 12 553 env38247 = env38248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 553 env38247 == env38248) = true)

theorem identity38248 : scanCanonicalize (H12AffineFastState.compose env38248 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound38248 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38249 : List Nat := [2,4,8,16,32,16,128,21,512,4,49,0,553,0,561,530,1,27,4,560,1,152,17,138,672,17,43,1,1,0,172,168,20,16,0,512]

theorem envBound38249 : H12AffineFastState.Bounded env38249 := by
  intro p hp
  have h : env38249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38248_38249 : H12AffineEnvironment.transform 10 49 env38248 = env38249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env38248 == env38249) = true)

theorem identity38249 : scanCanonicalize (H12AffineFastState.compose env38249 (packedSelected [4,7] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound38249 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env38250 : List Nat := [2,4,8,16,32,16,19,21,512,4,49,0,553,0,561,530,1,27,4,560,1,11,17,25,563,17,43,1,1,0,63,59,20,16,0,512]

theorem envBound38250 : H12AffineFastState.Bounded env38250 := by
  intro p hp
  have h : env38250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38249_38250 : H12AffineEnvironment.transform 6 19 env38249 = env38250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env38249 == env38250) = true)

theorem identity38250 : scanCanonicalize (H12AffineFastState.compose env38250 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound38250 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env38251 : List Nat := [2,4,8,16,32,16,19,21,1,4,49,0,40,0,48,19,1,27,4,49,1,11,17,25,50,17,43,1,1,0,63,59,20,16,0,1]

theorem envBound38251 : H12AffineFastState.Bounded env38251 := by
  intro p hp
  have h : env38251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38250_38251 : H12AffineEnvironment.transform 8 1 env38250 = env38251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env38250 == env38251) = true)

theorem identity38251 : scanCanonicalize (H12AffineFastState.compose env38251 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound38251 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env38252 : List Nat := [2,4,8,16,11,16,19,21,1,4,26,0,3,0,27,19,1,27,4,26,1,11,17,25,25,17,0,1,1,0,20,16,20,16,0,1]

theorem envBound38252 : H12AffineFastState.Bounded env38252 := by
  intro p hp
  have h : env38252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38251_38252 : H12AffineEnvironment.transform 4 11 env38251 = env38252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env38251 == env38252) = true)

theorem identity38252 : scanCanonicalize (H12AffineFastState.compose env38252 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound38252 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38253 : List Nat := [2,4,8,12,11,12,15,9,1,4,6,0,3,0,7,15,1,7,4,6,1,11,13,5,5,13,0,1,1,0,8,12,8,12,0,1]

theorem envBound38253 : H12AffineFastState.Bounded env38253 := by
  intro p hp
  have h : env38253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38252_38253 : H12AffineEnvironment.transform 3 12 env38252 = env38253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env38252 == env38253) = true)

theorem identity38253 : scanCanonicalize (H12AffineFastState.compose env38253 (packedSelected [5] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound38253 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env38254 : List Nat := [2,3,8,11,11,11,8,9,1,3,1,0,3,0,0,8,1,0,3,1,1,11,10,2,2,10,0,1,1,0,8,11,8,11,0,1]

theorem envBound38254 : H12AffineFastState.Bounded env38254 := by
  intro p hp
  have h : env38254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38253_38254 : H12AffineEnvironment.transform 1 3 env38253 = env38254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env38253 == env38254) = true)

def env38255 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95614,32769,4097,61648,147520,284033,86519,209262,225344,148801,74814,96346,381312,381316,257,1281,1345,95102]

theorem envBound38255 : H12AffineFastState.Bounded env38255 := by
  intro p hp
  have h : env38255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38077_38255 : H12AffineEnvironment.transform 23 284033 env38077 = env38255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 284033 env38077 == env38255) = true)

def env38256 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16464,262144,95614,32769,4097,61648,16,284033,86519,94526,77840,1297,74814,96346,381312,381316,257,1281,1345,95102]

theorem envBound38256 : H12AffineFastState.Bounded env38256 := by
  intro p hp
  have h : env38256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38255_38256 : H12AffineEnvironment.transform 16 16464 env38255 = env38256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16464 env38255 == env38256) = true)

def env38257 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1344,262144,77934,32769,4097,46528,16,266385,70887,78894,77840,1297,74814,81226,365712,365716,257,1281,1345,79470]

theorem envBound38257 : H12AffineFastState.Bounded env38257 := by
  intro p hp
  have h : env38257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38256_38257 : H12AffineEnvironment.transform 13 1296 env38256 = env38257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env38256 == env38257) = true)

theorem identity38257 : scanCanonicalize (H12AffineFastState.compose env38257 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32882) := by decide +kernel

theorem selectedBound38257 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env38258 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,32882,1344,262144,45084,32769,4097,46528,16,266385,38037,46172,45154,1297,42060,48440,267490,267494,257,1281,1345,46620]

theorem envBound38258 : H12AffineFastState.Bounded env38258 := by
  intro p hp
  have h : env38258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38257_38258 : H12AffineEnvironment.transform 15 32882 env38257 = env38258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32882 env38257 == env38258) = true)

def env38259 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32882,1344,262144,42332,32769,1345,41088,16,263633,33237,41244,42274,1297,42060,43128,262562,262566,257,1281,1345,41820]

theorem envBound38259 : H12AffineFastState.Bounded env38259 := by
  intro p hp
  have h : env38259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38258_38259 : H12AffineEnvironment.transform 11 1344 env38258 = env38259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env38258 == env38259) = true)

theorem identity38259 : scanCanonicalize (H12AffineFastState.compose env38259 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 439) := by decide +kernel

theorem selectedBound38259 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env38260 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32882,1344,439,42332,32769,1345,41088,16,1126,33237,41244,42274,1297,42060,43128,21,17,257,1281,1345,41820]

theorem envBound38260 : H12AffineFastState.Bounded env38260 := by
  intro p hp
  have h : env38260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38259_38260 : H12AffineEnvironment.transform 17 439 env38259 = env38260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 439 env38259 == env38260) = true)

theorem identity38260 : scanCanonicalize (H12AffineFastState.compose env38260 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound38260 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env38261 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,8540,8494,1344,439,1024,8541,1345,476,16,1126,8329,64,1150,1297,1296,2340,21,17,257,1281,1345,512]

theorem envBound38261 : H12AffineFastState.Bounded env38261 := by
  intro p hp
  have h : env38261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38260_38261 : H12AffineEnvironment.transform 14 8540 env38260 = env38261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env38260 == env38261) = true)

theorem identity38261 : scanCanonicalize (H12AffineFastState.compose env38261 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 84) := by decide +kernel

theorem selectedBound38261 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env38262 : List Nat := [2,4,8,16,32,64,128,256,512,84,2048,276,8192,324,8540,8494,276,439,84,8541,277,476,16,50,8329,64,42,325,324,2340,21,17,257,341,277,512]

theorem envBound38262 : H12AffineFastState.Bounded env38262 := by
  intro p hp
  have h : env38262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38261_38262 : H12AffineEnvironment.transform 9 84 env38261 = env38262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env38261 == env38262) = true)

theorem identity38262 : scanCanonicalize (H12AffineFastState.compose env38262 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 704) := by decide +kernel

theorem selectedBound38262 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env38263 : List Nat := [2,4,8,16,32,64,128,256,512,84,2048,276,704,324,924,1006,276,439,84,925,277,476,16,50,585,64,42,325,324,2340,21,17,257,341,277,512]

theorem envBound38263 : H12AffineFastState.Bounded env38263 := by
  intro p hp
  have h : env38263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38262_38263 : H12AffineEnvironment.transform 12 704 env38262 = env38263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 704 env38262 == env38263) = true)

theorem identity38263 : scanCanonicalize (H12AffineFastState.compose env38263 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound38263 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env38264 : List Nat := [2,4,8,16,32,16,128,256,512,4,2048,276,656,276,924,958,276,439,4,925,277,396,16,50,537,16,42,277,276,2340,21,17,257,261,277,512]

theorem envBound38264 : H12AffineFastState.Bounded env38264 := by
  intro p hp
  have h : env38264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38263_38264 : H12AffineEnvironment.transform 5 16 env38263 = env38264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38263 == env38264) = true)

theorem identity38264 : scanCanonicalize (H12AffineFastState.compose env38264 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 156) := by decide +kernel

theorem selectedBound38264 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env38265 : List Nat := [2,4,8,16,32,16,128,156,512,4,2048,136,656,136,512,546,136,43,4,513,137,16,16,50,537,16,42,137,136,2232,21,17,157,153,137,512]

theorem envBound38265 : H12AffineFastState.Bounded env38265 := by
  intro p hp
  have h : env38265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38264_38265 : H12AffineEnvironment.transform 7 156 env38264 = env38265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 156 env38264 == env38265) = true)

theorem identity38265 : scanCanonicalize (H12AffineFastState.compose env38265 (packedSelected [13] rootPS)) = affineNative (2^(10+1) ^^^ 146) := by decide +kernel

theorem selectedBound38265 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env38266 : List Nat := [2,4,8,16,32,16,128,156,512,4,146,136,656,136,512,546,136,43,4,513,137,16,16,50,537,16,42,137,136,42,21,17,157,153,137,512]

theorem envBound38266 : H12AffineFastState.Bounded env38266 := by
  intro p hp
  have h : env38266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38265_38266 : H12AffineEnvironment.transform 10 146 env38265 = env38266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 146 env38265 == env38266) = true)

theorem identity38266 : scanCanonicalize (H12AffineFastState.compose env38266 (packedSelected [0,2,4] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound38266 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env38267 : List Nat := [2,4,8,16,32,16,18,14,512,4,0,26,514,26,512,546,26,43,4,513,27,16,16,50,537,16,42,27,26,42,21,17,15,11,27,512]

theorem envBound38267 : H12AffineFastState.Bounded env38267 := by
  intro p hp
  have h : env38267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38266_38267 : H12AffineEnvironment.transform 6 18 env38266 = env38267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env38266 == env38267) = true)

theorem identity38267 : scanCanonicalize (H12AffineFastState.compose env38267 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound38267 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env38268 : List Nat := [2,4,8,16,32,16,18,14,0,4,0,26,2,26,0,34,26,43,4,1,27,16,16,50,25,16,42,27,26,42,21,17,15,11,27,0]

theorem envBound38268 : H12AffineFastState.Bounded env38268 := by
  intro p hp
  have h : env38268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38267_38268 : H12AffineEnvironment.transform 8 0 env38267 = env38268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env38267 == env38268) = true)

theorem identity38268 : scanCanonicalize (H12AffineFastState.compose env38268 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound38268 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env38269 : List Nat := [2,4,8,16,16,16,18,14,0,4,0,26,2,26,0,18,26,27,4,1,27,16,16,2,25,16,26,27,26,26,21,17,15,11,27,0]

theorem envBound38269 : H12AffineFastState.Bounded env38269 := by
  intro p hp
  have h : env38269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38268_38269 : H12AffineEnvironment.transform 4 16 env38268 = env38269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env38268 == env38269) = true)

theorem identity38269 : scanCanonicalize (H12AffineFastState.compose env38269 (packedSelected [0,9] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound38269 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env38270 : List Nat := [2,4,8,10,10,10,8,14,0,4,0,0,2,0,0,8,0,1,4,1,1,10,10,2,3,10,0,1,0,0,15,11,15,11,1,0]

theorem envBound38270 : H12AffineFastState.Bounded env38270 := by
  intro p hp
  have h : env38270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38269_38270 : H12AffineEnvironment.transform 3 10 env38269 = env38270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env38269 == env38270) = true)

theorem identity38270 : scanCanonicalize (H12AffineFastState.compose env38270 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound38270 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38271 : List Nat := [2,2,8,10,10,10,8,8,0,2,0,0,2,0,0,8,0,1,2,1,1,10,10,2,3,10,0,1,0,0,9,11,9,11,1,0]

theorem envBound38271 : H12AffineFastState.Bounded env38271 := by
  intro p hp
  have h : env38271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38270_38271 : H12AffineEnvironment.transform 1 2 env38270 = env38271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env38270 == env38271) = true)

def env38272 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32882,1344,262144,42333,32769,1344,41089,16,263632,33236,41245,42275,1297,42060,43129,262563,262567,257,1281,1345,41821]

theorem envBound38272 : H12AffineFastState.Bounded env38272 := by
  intro p hp
  have h : env38272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38258_38272 : H12AffineEnvironment.transform 11 1345 env38258 = env38272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env38258 == env38272) = true)

theorem identity38272 : scanCanonicalize (H12AffineFastState.compose env38272 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 324) := by decide +kernel

theorem selectedBound38272 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env38273 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,324,310,1344,262144,9241,325,1344,8645,16,263632,144,8281,9319,1297,9480,10557,262563,262567,257,1281,1345,8729]

theorem envBound38273 : H12AffineFastState.Bounded env38273 := by
  intro p hp
  have h : env38273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38272_38273 : H12AffineEnvironment.transform 14 324 env38272 = env38273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 324 env38272 == env38273) = true)

theorem identity38273 : scanCanonicalize (H12AffineFastState.compose env38273 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(17+1) ^^^ 1663) := by decide +kernel

theorem selectedBound38273 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env38274 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,324,310,1344,1663,9241,325,1344,8645,16,943,144,8281,9319,1297,9480,10557,2012,2008,257,1281,1345,8729]

theorem envBound38274 : H12AffineFastState.Bounded env38274 := by
  intro p hp
  have h : env38274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38273_38274 : H12AffineEnvironment.transform 17 1663 env38273 = env38274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1663 env38273 == env38274) = true)

def env38275 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1345,262144,77935,32769,4097,46529,16,266384,70886,78895,77840,1297,74814,81227,365713,365717,257,1281,1345,79471]

theorem envBound38275 : H12AffineFastState.Bounded env38275 := by
  intro p hp
  have h : env38275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38256_38275 : H12AffineEnvironment.transform 13 1297 env38256 = env38275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env38256 == env38275) = true)

theorem identity38275 : scanCanonicalize (H12AffineFastState.compose env38275 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound38275 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env38276 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1345,262144,77935,13340,4097,476,16,266384,70886,78895,77840,1297,74814,81227,336012,336008,257,1281,1345,79471]

theorem envBound38276 : H12AffineFastState.Bounded env38276 := by
  intro p hp
  have h : env38276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38275_38276 : H12AffineEnvironment.transform 14 13341 env38275 = env38276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env38275 == env38276) = true)

def env38277 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1345,65664,77935,13340,4097,476,16,69648,70886,78895,77840,1297,74814,81227,8204,8200,257,1281,1345,79471]

theorem envBound38277 : H12AffineFastState.Bounded env38277 := by
  intro p hp
  have h : env38277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38276_38277 : H12AffineEnvironment.transform 17 65664 env38276 = env38277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env38276 == env38277) = true)

theorem identity38277 : scanCanonicalize (H12AffineFastState.compose env38277 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9279) := by decide +kernel

theorem selectedBound38277 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env38278 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,9279,1345,9407,5200,13340,4097,476,16,13359,12505,4112,5167,1297,1,6516,8204,8200,257,1281,1345,4688]

theorem envBound38278 : H12AffineFastState.Bounded env38278 := by
  intro p hp
  have h : env38278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38277_38278 : H12AffineEnvironment.transform 15 9279 env38277 = env38278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9279 env38277 == env38278) = true)

def env38279 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1297,9245,9279,1345,9407,1104,9244,1,476,16,9263,8409,16,1071,1297,1,2420,8204,8200,257,1281,1345,592]

theorem envBound38279 : H12AffineFastState.Bounded env38279 := by
  intro p hp
  have h : env38279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38278_38279 : H12AffineEnvironment.transform 11 0 env38278 = env38279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env38278 == env38279) = true)

theorem identity38279 : scanCanonicalize (H12AffineFastState.compose env38279 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound38279 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env38280 : List Nat := [2,4,8,16,32,64,128,20,512,1024,2048,0,8192,1029,9245,9279,1109,9407,1104,9244,1,200,16,9263,8409,16,1071,1029,1,2144,8204,8200,21,1045,1109,592]

theorem envBound38280 : H12AffineFastState.Bounded env38280 := by
  intro p hp
  have h : env38280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38279_38280 : H12AffineEnvironment.transform 7 20 env38279 = env38280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env38279 == env38280) = true)

theorem identity38280 : scanCanonicalize (H12AffineFastState.compose env38280 (packedSelected [1,2,5,8,19,23,24,26,32] rootPS)) = affineNative (2^(12+1) ^^^ 1732) := by decide +kernel

theorem selectedBound38280 : packedSelected [1,2,5,8,19,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env38281 : List Nat := [2,4,8,16,32,64,128,20,512,1024,2048,0,1732,1029,729,763,1109,635,1104,728,1,200,16,747,1565,16,1071,1029,1,2144,1736,1740,21,1045,1109,592]

theorem envBound38281 : H12AffineFastState.Bounded env38281 := by
  intro p hp
  have h : env38281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38280_38281 : H12AffineEnvironment.transform 12 1732 env38280 = env38281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1732 env38280 == env38281) = true)

theorem identity38281 : scanCanonicalize (H12AffineFastState.compose env38281 (packedSelected [0,1,3,4,7,8,9,10,13,18,19,23,26,28] rootPS)) = affineNative (2^(8+1) ^^^ 97) := by decide +kernel

theorem selectedBound38281 : packedSelected [0,1,3,4,7,8,9,10,13,18,19,23,26,28] rootPS < 2^1333 := by decide +kernel

def env38282 : List Nat := [2,4,8,16,32,64,128,20,97,1024,2048,0,1189,1029,184,154,1109,26,1104,185,1,200,16,138,1148,16,1071,1029,1,2144,1193,1197,21,1045,1109,49]

theorem envBound38282 : H12AffineFastState.Bounded env38282 := by
  intro p hp
  have h : env38282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38281_38282 : H12AffineEnvironment.transform 8 97 env38281 = env38282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 97 env38281 == env38282) = true)

theorem identity38282 : scanCanonicalize (H12AffineFastState.compose env38282 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 195) := by decide +kernel

theorem selectedBound38282 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env38283 : List Nat := [2,4,8,16,32,64,128,20,97,1024,195,0,1189,1029,184,154,1109,26,1104,185,1,200,16,138,1148,16,1071,1029,1,163,1193,1197,21,1045,1109,49]

theorem envBound38283 : H12AffineFastState.Bounded env38283 := by
  intro p hp
  have h : env38283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38282_38283 : H12AffineEnvironment.transform 10 195 env38282 = env38283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 195 env38282 == env38283) = true)

theorem identity38283 : scanCanonicalize (H12AffineFastState.compose env38283 (packedSelected [0,5,8,9,10,11,12,13] rootPS)) = affineNative (2^(9+1) ^^^ 46) := by decide +kernel

theorem selectedBound38283 : packedSelected [0,5,8,9,10,11,12,13] rootPS < 2^1333 := by decide +kernel

def env38284 : List Nat := [2,4,8,16,32,64,128,20,97,46,195,0,139,43,184,154,123,26,126,185,1,200,16,138,82,16,1,43,1,163,135,131,21,59,123,49]

theorem envBound38284 : H12AffineFastState.Bounded env38284 := by
  intro p hp
  have h : env38284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38283_38284 : H12AffineEnvironment.transform 9 46 env38283 = env38284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 46 env38283 == env38284) = true)

theorem identity38284 : scanCanonicalize (H12AffineFastState.compose env38284 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound38284 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env38285 : List Nat := [2,4,8,16,32,64,88,20,97,46,27,0,83,43,96,66,123,26,126,97,1,16,16,82,82,16,1,43,1,123,95,91,21,59,123,49]

theorem envBound38285 : H12AffineFastState.Bounded env38285 := by
  intro p hp
  have h : env38285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38284_38285 : H12AffineEnvironment.transform 6 88 env38284 = env38285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env38284 == env38285) = true)

theorem identity38285 : scanCanonicalize (H12AffineFastState.compose env38285 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound38285 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env38286 : List Nat := [2,4,8,16,32,16,8,20,49,46,27,0,3,43,48,18,43,26,46,49,1,16,16,2,2,16,1,43,1,43,15,11,21,59,43,49]

theorem envBound38286 : H12AffineFastState.Bounded env38286 := by
  intro p hp
  have h : env38286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38285_38286 : H12AffineEnvironment.transform 5 16 env38285 = env38286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38285 == env38286) = true)

theorem identity38286 : scanCanonicalize (H12AffineFastState.compose env38286 (packedSelected [0,1,2] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound38286 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env38287 : List Nat := [2,4,8,16,11,16,8,20,26,5,27,0,3,0,27,18,0,26,5,26,1,16,16,2,2,16,1,0,1,0,15,11,21,16,0,26]

theorem envBound38287 : H12AffineFastState.Bounded env38287 := by
  intro p hp
  have h : env38287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38286_38287 : H12AffineEnvironment.transform 4 11 env38286 = env38287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env38286 == env38287) = true)

theorem identity38287 : scanCanonicalize (H12AffineFastState.compose env38287 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound38287 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env38288 : List Nat := [2,4,8,11,11,11,8,15,1,5,0,0,3,0,0,9,0,1,5,1,1,11,11,2,2,11,1,0,1,0,15,11,14,11,0,1]

theorem envBound38288 : H12AffineFastState.Bounded env38288 := by
  intro p hp
  have h : env38288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38287_38288 : H12AffineEnvironment.transform 3 11 env38287 = env38288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env38287 == env38288) = true)

theorem identity38288 : scanCanonicalize (H12AffineFastState.compose env38288 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound38288 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38289 : List Nat := [2,4,4,7,7,7,4,3,1,5,0,0,3,0,0,5,0,1,5,1,1,7,7,2,2,7,1,0,1,0,3,7,2,7,0,1]

theorem envBound38289 : H12AffineFastState.Bounded env38289 := by
  intro p hp
  have h : env38289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38288_38289 : H12AffineEnvironment.transform 2 4 env38288 = env38289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env38288 == env38289) = true)

def env38290 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1297,9244,9279,1345,9407,1105,9245,0,476,16,9262,8408,17,1070,1297,1,2421,8204,8200,257,1281,1345,593]

theorem envBound38290 : H12AffineFastState.Bounded env38290 := by
  intro p hp
  have h : env38290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38278_38290 : H12AffineEnvironment.transform 11 1 env38278 = env38290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env38278 == env38290) = true)

theorem identity38290 : scanCanonicalize (H12AffineFastState.compose env38290 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound38290 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env38291 : List Nat := [2,4,8,16,32,64,128,68,512,1024,2048,1,8192,1109,9244,9279,1029,9407,1105,9245,0,152,16,9262,8408,17,1070,1109,1,2097,8204,8200,69,1093,1029,593]

theorem envBound38291 : H12AffineFastState.Bounded env38291 := by
  intro p hp
  have h : env38291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38290_38291 : H12AffineEnvironment.transform 7 68 env38290 = env38291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env38290 == env38291) = true)

theorem identity38291 : scanCanonicalize (H12AffineFastState.compose env38291 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound38291 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env38292 : List Nat := [2,4,8,16,32,16,128,20,512,1024,2048,1,8192,1029,9244,9279,1029,9407,1025,9245,0,152,16,9262,8328,17,1070,1029,1,2097,8204,8200,21,1045,1029,513]

theorem envBound38292 : H12AffineFastState.Bounded env38292 := by
  intro p hp
  have h : env38292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38291_38292 : H12AffineEnvironment.transform 5 16 env38291 = env38292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38291 == env38292) = true)

theorem identity38292 : scanCanonicalize (H12AffineFastState.compose env38292 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound38292 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env38293 : List Nat := [2,4,8,16,32,16,128,20,32,1024,2048,1,8192,1029,9244,9279,1029,9407,1025,9245,0,152,16,9262,8328,17,1070,1029,1,2097,8204,8200,21,1045,1029,33]

theorem envBound38293 : H12AffineFastState.Bounded env38293 := by
  intro p hp
  have h : env38293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38292_38293 : H12AffineEnvironment.transform 8 32 env38292 = env38293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env38292 == env38293) = true)

theorem identity38293 : scanCanonicalize (H12AffineFastState.compose env38293 (packedSelected [0,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound38293 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env38294 : List Nat := [2,4,8,16,32,16,128,20,32,1024,42,1,8192,1029,9244,9279,1029,9407,1025,9245,0,152,16,9262,8328,17,1070,1029,1,27,8204,8200,21,1045,1029,33]

theorem envBound38294 : H12AffineFastState.Bounded env38294 := by
  intro p hp
  have h : env38294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38293_38294 : H12AffineEnvironment.transform 10 42 env38293 = env38294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env38293 == env38294) = true)

theorem identity38294 : scanCanonicalize (H12AffineFastState.compose env38294 (packedSelected [2,12,13,15] rootPS)) = affineNative (2^(12+1) ^^^ 1037) := by decide +kernel

theorem selectedBound38294 : packedSelected [2,12,13,15] rootPS < 2^1333 := by decide +kernel

def env38295 : List Nat := [2,4,8,16,32,16,128,20,32,1024,42,1,1037,1029,17,50,1029,178,1025,16,0,152,16,35,1157,17,1070,1029,1,27,1025,1029,21,1045,1029,33]

theorem envBound38295 : H12AffineFastState.Bounded env38295 := by
  intro p hp
  have h : env38295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38294_38295 : H12AffineEnvironment.transform 12 1037 env38294 = env38295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1037 env38294 == env38295) = true)

theorem identity38295 : scanCanonicalize (H12AffineFastState.compose env38295 (packedSelected [0,1,2,3,4,7,9,13] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound38295 : packedSelected [0,1,2,3,4,7,9,13] rootPS < 2^1333 := by decide +kernel

def env38296 : List Nat := [2,4,8,16,32,16,128,20,32,5,42,1,8,0,17,50,0,178,4,16,0,152,16,35,128,17,43,0,1,27,4,0,21,16,0,33]

theorem envBound38296 : H12AffineFastState.Bounded env38296 := by
  intro p hp
  have h : env38296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38295_38296 : H12AffineEnvironment.transform 9 5 env38295 = env38296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env38295 == env38296) = true)

theorem identity38296 : scanCanonicalize (H12AffineFastState.compose env38296 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound38296 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38297 : List Nat := [2,4,8,1,32,1,128,5,32,5,42,1,8,0,0,35,0,163,4,1,0,137,1,35,128,0,43,0,1,10,4,0,4,1,0,33]

theorem envBound38297 : H12AffineFastState.Bounded env38297 := by
  intro p hp
  have h : env38297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38296_38297 : H12AffineEnvironment.transform 3 1 env38296 = env38297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env38296 == env38297) = true)

theorem identity38297 : scanCanonicalize (H12AffineFastState.compose env38297 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 37) := by decide +kernel

theorem selectedBound38297 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38298 : List Nat := [2,4,8,1,32,1,37,5,32,5,42,1,8,0,0,35,0,6,4,1,0,44,1,35,37,0,43,0,1,10,4,0,4,1,0,33]

theorem envBound38298 : H12AffineFastState.Bounded env38298 := by
  intro p hp
  have h : env38298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38297_38298 : H12AffineEnvironment.transform 6 37 env38297 = env38298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 37 env38297 == env38298) = true)

theorem identity38298 : scanCanonicalize (H12AffineFastState.compose env38298 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound38298 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env38299 : List Nat := [2,4,8,1,10,1,15,5,10,5,0,1,8,0,0,9,0,6,4,1,0,6,1,9,15,0,1,0,1,10,4,0,4,1,0,11]

theorem envBound38299 : H12AffineFastState.Bounded env38299 := by
  intro p hp
  have h : env38299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38298_38299 : H12AffineEnvironment.transform 4 10 env38298 = env38299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env38298 == env38299) = true)

theorem identity38299 : scanCanonicalize (H12AffineFastState.compose env38299 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound38299 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38300 : List Nat := [1,4,8,1,9,1,12,5,9,5,0,1,8,0,0,9,0,5,4,1,0,5,1,9,12,0,1,0,1,9,4,0,4,1,0,8]

theorem envBound38300 : H12AffineFastState.Bounded env38300 := by
  intro p hp
  have h : env38300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38299_38300 : H12AffineEnvironment.transform 0 1 env38299 = env38300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env38299 == env38300) = true)

theorem identity38300 : scanCanonicalize (H12AffineFastState.compose env38300 (packedSelected [7] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound38300 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env38301 : List Nat := [1,0,8,1,9,1,8,1,9,1,0,1,8,0,0,9,0,1,0,1,0,1,1,9,8,0,1,0,1,9,0,0,0,1,0,8]

theorem envBound38301 : H12AffineFastState.Bounded env38301 := by
  intro p hp
  have h : env38301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38300_38301 : H12AffineEnvironment.transform 1 0 env38300 = env38301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env38300 == env38301) = true)

theorem identity38301 : scanCanonicalize (H12AffineFastState.compose env38301 (packedSelected [8] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound38301 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env38302 : List Nat := [1,0,1,1,0,1,1,1,0,1,0,1,1,0,0,0,0,1,0,1,0,1,1,0,1,0,1,0,1,0,0,0,0,1,0,1]

theorem envBound38302 : H12AffineFastState.Bounded env38302 := by
  intro p hp
  have h : env38302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38301_38302 : H12AffineEnvironment.transform 2 1 env38301 = env38302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env38301 == env38302) = true)

def env38303 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1345,65665,77935,13340,4097,476,16,69649,70886,78895,77840,1297,74814,81227,8205,8201,257,1281,1345,79471]

theorem envBound38303 : H12AffineFastState.Bounded env38303 := by
  intro p hp
  have h : env38303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38276_38303 : H12AffineEnvironment.transform 17 65665 env38276 = env38303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env38276 == env38303) = true)

theorem identity38303 : scanCanonicalize (H12AffineFastState.compose env38303 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12671) := by decide +kernel

theorem selectedBound38303 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env38304 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,12671,1345,12798,272,13340,4097,476,16,8558,9625,1360,367,1297,5441,3124,8205,8201,257,1281,1345,1808]

theorem envBound38304 : H12AffineFastState.Bounded env38304 := by
  intro p hp
  have h : env38304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38303_38304 : H12AffineEnvironment.transform 15 12671 env38303 = env38304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12671 env38303 == env38304) = true)

def env38305 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,81,12637,12671,1,12798,272,12636,4097,476,16,8558,8409,16,367,81,4097,2420,8205,8201,257,65,1,592]

theorem envBound38305 : H12AffineFastState.Bounded env38305 := by
  intro p hp
  have h : env38305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38304_38305 : H12AffineEnvironment.transform 9 320 env38304 = env38305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env38304 == env38305) = true)

theorem identity38305 : scanCanonicalize (H12AffineFastState.compose env38305 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound38305 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env38306 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,276,8192,81,8265,8299,1,8426,272,8264,277,476,16,8558,8409,16,367,81,277,2420,8205,8201,257,65,1,592]

theorem envBound38306 : H12AffineFastState.Bounded env38306 := by
  intro p hp
  have h : env38306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38305_38306 : H12AffineEnvironment.transform 11 276 env38305 = env38306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env38305 == env38306) = true)

theorem identity38306 : scanCanonicalize (H12AffineFastState.compose env38306 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound38306 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env38307 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,276,8192,1,8217,8251,1,8378,272,8216,277,396,16,8510,8329,16,319,1,277,2340,8205,8201,257,17,1,512]

theorem envBound38307 : H12AffineFastState.Bounded env38307 := by
  intro p hp
  have h : env38307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38306_38307 : H12AffineEnvironment.transform 5 16 env38306 = env38307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38306 == env38307) = true)

theorem identity38307 : scanCanonicalize (H12AffineFastState.compose env38307 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 2364) := by decide +kernel

theorem selectedBound38307 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env38308 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,276,2364,1,2341,2311,1,2438,272,2340,277,396,16,2050,2485,16,319,1,277,2340,2353,2357,257,17,1,512]

theorem envBound38308 : H12AffineFastState.Bounded env38308 := by
  intro p hp
  have h : env38308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38307_38308 : H12AffineEnvironment.transform 12 2364 env38307 = env38308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2364 env38307 == env38308) = true)

theorem identity38308 : scanCanonicalize (H12AffineFastState.compose env38308 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(8+1) ^^^ 270) := by decide +kernel

theorem selectedBound38308 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env38309 : List Nat := [2,4,8,16,32,16,128,256,270,272,2048,276,2364,1,2341,2311,1,2438,272,2340,277,396,16,2050,2485,16,319,1,277,2340,2353,2357,257,17,1,270]

theorem envBound38309 : H12AffineFastState.Bounded env38309 := by
  intro p hp
  have h : env38309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38308_38309 : H12AffineEnvironment.transform 8 270 env38308 = env38309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 270 env38308 == env38309) = true)

theorem identity38309 : scanCanonicalize (H12AffineFastState.compose env38309 (packedSelected [1,2,3,12,13] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound38309 : packedSelected [1,2,3,12,13] rootPS < 2^1333 := by decide +kernel

def env38310 : List Nat := [2,4,8,16,32,16,128,172,162,188,2048,184,2192,1,2185,2219,1,2090,188,2184,185,32,16,2050,2073,16,147,1,185,2184,2205,2201,173,17,1,162]

theorem envBound38310 : H12AffineFastState.Bounded env38310 := by
  intro p hp
  have h : env38310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38309_38310 : H12AffineEnvironment.transform 7 172 env38309 = env38310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env38309 == env38310) = true)

theorem identity38310 : scanCanonicalize (H12AffineFastState.compose env38310 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(10+1) ^^^ 27) := by decide +kernel

theorem selectedBound38310 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env38311 : List Nat := [2,4,8,16,32,16,128,172,162,188,27,184,139,1,146,176,1,49,188,147,185,32,16,25,2,16,147,1,185,147,134,130,173,17,1,162]

theorem envBound38311 : H12AffineFastState.Bounded env38311 := by
  intro p hp
  have h : env38311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38310_38311 : H12AffineEnvironment.transform 10 27 env38310 = env38311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 27 env38310 == env38311) = true)

theorem identity38311 : scanCanonicalize (H12AffineFastState.compose env38311 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound38311 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env38312 : List Nat := [2,4,8,16,32,16,35,15,1,31,27,27,40,1,49,19,1,49,31,48,26,32,16,25,2,16,48,1,26,48,37,33,14,17,1,1]

theorem envBound38312 : H12AffineFastState.Bounded env38312 := by
  intro p hp
  have h : env38312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38311_38312 : H12AffineEnvironment.transform 6 35 env38311 = env38312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env38311 == env38312) = true)

theorem identity38312 : scanCanonicalize (H12AffineFastState.compose env38312 (packedSelected [0,1,2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound38312 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env38313 : List Nat := [2,4,8,11,32,11,35,15,1,4,0,0,40,1,42,8,1,42,4,43,1,32,11,2,2,11,43,1,1,43,37,33,14,10,1,1]

theorem envBound38313 : H12AffineFastState.Bounded env38313 := by
  intro p hp
  have h : env38313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38312_38313 : H12AffineEnvironment.transform 3 11 env38312 = env38313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env38312 == env38313) = true)

theorem identity38313 : scanCanonicalize (H12AffineFastState.compose env38313 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound38313 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env38314 : List Nat := [2,4,8,11,10,11,9,15,1,4,0,0,2,1,0,8,1,0,4,1,1,10,11,2,2,11,1,1,1,1,15,11,14,10,1,1]

theorem envBound38314 : H12AffineFastState.Bounded env38314 := by
  intro p hp
  have h : env38314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38313_38314 : H12AffineEnvironment.transform 4 10 env38313 = env38314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env38313 == env38314) = true)

theorem identity38314 : scanCanonicalize (H12AffineFastState.compose env38314 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound38314 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38315 : List Nat := [2,2,8,11,10,11,9,9,1,2,0,0,2,1,0,8,1,0,2,1,1,10,11,2,2,11,1,1,1,1,9,11,8,10,1,1]

theorem envBound38315 : H12AffineFastState.Bounded env38315 := by
  intro p hp
  have h : env38315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38314_38315 : H12AffineEnvironment.transform 1 2 env38314 = env38315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env38314 == env38315) = true)

def env38316 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,80,12636,12671,0,12798,272,12637,4097,476,16,8558,8408,17,367,80,4096,2421,8205,8201,257,64,0,593]

theorem envBound38316 : H12AffineFastState.Bounded env38316 := by
  intro p hp
  have h : env38316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38304_38316 : H12AffineEnvironment.transform 9 321 env38304 = env38316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env38304 == env38316) = true)

theorem identity38316 : scanCanonicalize (H12AffineFastState.compose env38316 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 325) := by decide +kernel

theorem selectedBound38316 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env38317 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,325,8192,80,8217,8250,0,8379,272,8216,324,476,16,8558,8408,17,367,80,325,2421,8205,8201,257,64,0,593]

theorem envBound38317 : H12AffineFastState.Bounded env38317 := by
  intro p hp
  have h : env38317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38316_38317 : H12AffineEnvironment.transform 11 325 env38316 = env38317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 325 env38316 == env38317) = true)

def env38318 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16465,262144,95614,32769,4097,61648,17,284033,86519,94527,77841,1296,74814,96346,381312,381316,257,1281,1345,95102]

theorem envBound38318 : H12AffineFastState.Bounded env38318 := by
  intro p hp
  have h : env38318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38255_38318 : H12AffineEnvironment.transform 16 16465 env38255 = env38318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16465 env38255 == env38318) = true)

def env38319 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1345,262144,77934,32769,4097,46528,17,266385,70887,78895,77841,1296,74814,81226,365712,365716,257,1281,1345,79470]

theorem envBound38319 : H12AffineFastState.Bounded env38319 := by
  intro p hp
  have h : env38319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38318_38319 : H12AffineEnvironment.transform 13 1296 env38318 = env38319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env38318 == env38319) = true)

theorem identity38319 : scanCanonicalize (H12AffineFastState.compose env38319 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound38319 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env38320 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1345,262144,77934,13340,4097,477,17,266385,70887,78895,77841,1296,74814,81226,336013,336009,257,1281,1345,79470]

theorem envBound38320 : H12AffineFastState.Bounded env38320 := by
  intro p hp
  have h : env38320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38319_38320 : H12AffineEnvironment.transform 14 13341 env38319 = env38320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env38319 == env38320) = true)

def env38321 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1345,65664,77934,13340,4097,477,17,69649,70887,78895,77841,1296,74814,81226,8205,8201,257,1281,1345,79470]

theorem envBound38321 : H12AffineFastState.Bounded env38321 := by
  intro p hp
  have h : env38321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38320_38321 : H12AffineEnvironment.transform 17 65664 env38320 = env38321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env38320 == env38321) = true)

theorem identity38321 : scanCanonicalize (H12AffineFastState.compose env38321 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5239) := by decide +kernel

theorem selectedBound38321 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env38322 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,5239,1345,5367,9241,13340,4097,477,17,1126,144,8280,9318,1296,12361,10557,8205,8201,257,1281,1345,8729]

theorem envBound38322 : H12AffineFastState.Bounded env38322 := by
  intro p hp
  have h : env38322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38321_38322 : H12AffineEnvironment.transform 15 5239 env38321 = env38322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5239 env38321 == env38322) = true)

def env38323 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,1296,13341,5159,1297,5287,9241,13340,4097,397,17,1078,144,8200,9270,1296,12313,10557,8205,8201,257,1281,1297,8729]

theorem envBound38323 : H12AffineFastState.Bounded env38323 := by
  intro p hp
  have h : env38323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38322_38323 : H12AffineEnvironment.transform 5 16 env38322 = env38323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38322 == env38323) = true)

theorem identity38323 : scanCanonicalize (H12AffineFastState.compose env38323 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound38323 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env38324 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,277,8192,1296,9480,1330,1297,1458,9241,9481,276,397,17,1078,144,8200,9270,1296,8460,10557,8205,8201,257,1281,1297,8729]

theorem envBound38324 : H12AffineFastState.Bounded env38324 := by
  intro p hp
  have h : env38324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38323_38324 : H12AffineEnvironment.transform 11 277 env38323 = env38324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env38323 == env38324) = true)

theorem identity38324 : scanCanonicalize (H12AffineFastState.compose env38324 (packedSelected [2,13,21,23,32] rootPS)) = affineNative (2^(8+1) ^^^ 413) := by decide +kernel

theorem selectedBound38324 : packedSelected [2,13,21,23,32] rootPS < 2^1333 := by decide +kernel

def env38325 : List Nat := [2,4,8,16,32,16,128,256,413,1024,2048,277,8192,1296,9480,1330,1297,1458,9241,9481,276,397,17,1078,144,8200,9270,1296,8460,10557,8205,8201,257,1281,1297,8580]

theorem envBound38325 : H12AffineFastState.Bounded env38325 := by
  intro p hp
  have h : env38325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38324_38325 : H12AffineEnvironment.transform 8 413 env38324 = env38325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 413 env38324 == env38325) = true)

theorem identity38325 : scanCanonicalize (H12AffineFastState.compose env38325 (packedSelected [0,1,3,4,7,8,9,10,18,19,21,23,26,28] rootPS)) = affineNative (2^(12+1) ^^^ 1189) := by decide +kernel

theorem selectedBound38325 : packedSelected [0,1,3,4,7,8,9,10,18,19,21,23,26,28] rootPS < 2^1333 := by decide +kernel

def env38326 : List Nat := [2,4,8,16,32,16,128,256,413,1024,2048,277,1189,1296,429,1330,1297,1458,188,428,276,397,17,1078,144,1197,147,1296,1449,3480,1192,1196,257,1281,1297,1313]

theorem envBound38326 : H12AffineFastState.Bounded env38326 := by
  intro p hp
  have h : env38326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38325_38326 : H12AffineEnvironment.transform 12 1189 env38325 = env38326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1189 env38325 == env38326) = true)

theorem identity38326 : scanCanonicalize (H12AffineFastState.compose env38326 (packedSelected [0,1,2,4,5,7,9,10,11,13,18] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound38326 : packedSelected [0,1,2,4,5,7,9,10,11,13,18] rootPS < 2^1333 := by decide +kernel

def env38327 : List Nat := [2,4,8,16,32,16,128,256,413,4,2048,277,161,276,429,310,277,438,188,428,276,397,17,50,144,169,147,276,429,2460,172,168,257,261,277,293]

theorem envBound38327 : H12AffineFastState.Bounded env38327 := by
  intro p hp
  have h : env38327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38326_38327 : H12AffineEnvironment.transform 9 4 env38326 = env38327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env38326 == env38327) = true)

theorem identity38327 : scanCanonicalize (H12AffineFastState.compose env38327 (packedSelected [1,4,8,9,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 429) := by decide +kernel

theorem selectedBound38327 : packedSelected [1,4,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env38328 : List Nat := [2,4,8,16,32,16,128,256,413,4,429,277,161,276,429,310,277,438,188,428,276,397,17,50,144,169,147,276,429,49,172,168,257,261,277,293]

theorem envBound38328 : H12AffineFastState.Bounded env38328 := by
  intro p hp
  have h : env38328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38327_38328 : H12AffineEnvironment.transform 10 429 env38327 = env38328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 429 env38327 == env38328) = true)

theorem identity38328 : scanCanonicalize (H12AffineFastState.compose env38328 (packedSelected [0,1,2,4,7,8,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound38328 : packedSelected [0,1,2,4,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env38329 : List Nat := [2,4,8,16,32,16,34,256,319,4,271,277,3,276,271,310,277,276,30,270,276,303,17,50,50,11,49,276,271,49,14,10,257,261,277,293]

theorem envBound38329 : H12AffineFastState.Bounded env38329 := by
  intro p hp
  have h : env38329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38328_38329 : H12AffineEnvironment.transform 6 34 env38328 = env38329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env38328 == env38329) = true)

theorem identity38329 : scanCanonicalize (H12AffineFastState.compose env38329 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound38329 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env38330 : List Nat := [2,4,8,16,32,16,34,36,27,4,43,49,3,48,43,18,49,48,30,42,48,11,17,50,50,11,49,48,43,49,14,10,37,33,49,1]

theorem envBound38330 : H12AffineFastState.Bounded env38330 := by
  intro p hp
  have h : env38330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38329_38330 : H12AffineEnvironment.transform 7 36 env38329 = env38330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env38329 == env38330) = true)

theorem identity38330 : scanCanonicalize (H12AffineFastState.compose env38330 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound38330 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env38331 : List Nat := [2,4,8,10,32,10,34,36,1,4,43,43,3,42,43,8,43,42,4,42,42,11,11,40,40,11,43,42,43,43,14,10,37,33,43,1]

theorem envBound38331 : H12AffineFastState.Bounded env38331 := by
  intro p hp
  have h : env38331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38330_38331 : H12AffineEnvironment.transform 3 10 env38330 = env38331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env38330 == env38331) = true)

theorem identity38331 : scanCanonicalize (H12AffineFastState.compose env38331 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound38331 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env38332 : List Nat := [2,4,8,10,10,10,8,14,1,4,1,1,3,0,1,8,1,0,4,0,0,11,11,2,2,11,1,0,1,1,14,10,15,11,1,1]

theorem envBound38332 : H12AffineFastState.Bounded env38332 := by
  intro p hp
  have h : env38332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38331_38332 : H12AffineEnvironment.transform 4 10 env38331 = env38332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env38331 == env38332) = true)

theorem identity38332 : scanCanonicalize (H12AffineFastState.compose env38332 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound38332 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38333 : List Nat := [2,3,8,10,10,10,8,9,1,3,1,1,3,0,1,8,1,0,3,0,0,11,11,2,2,11,1,0,1,1,9,10,8,11,1,1]

theorem envBound38333 : H12AffineFastState.Bounded env38333 := by
  intro p hp
  have h : env38333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38332_38333 : H12AffineEnvironment.transform 1 3 env38332 = env38333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env38332 == env38333) = true)

def env38334 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,1296,13341,5158,1296,5286,9241,13340,4097,396,17,1079,144,8201,9271,1296,12312,10557,8205,8201,257,1281,1296,8729]

theorem envBound38334 : H12AffineFastState.Bounded env38334 := by
  intro p hp
  have h : env38334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38322_38334 : H12AffineEnvironment.transform 5 17 env38322 = env38334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env38322 == env38334) = true)

theorem identity38334 : scanCanonicalize (H12AffineFastState.compose env38334 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 4364) := by decide +kernel

theorem selectedBound38334 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env38335 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,4364,1296,1297,5158,1296,5286,5397,1296,4097,396,17,1079,144,4357,5435,1296,276,6193,4353,4357,257,1281,1296,4885]

theorem envBound38335 : H12AffineFastState.Bounded env38335 := by
  intro p hp
  have h : env38335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38334_38335 : H12AffineEnvironment.transform 12 4364 env38334 = env38335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4364 env38334 == env38335) = true)

theorem identity38335 : scanCanonicalize (H12AffineFastState.compose env38335 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound38335 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env38336 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,276,24,1296,1297,1330,1296,1458,1025,1296,277,396,17,1079,144,17,1071,1296,276,2341,21,17,257,1281,1296,513]

theorem envBound38336 : H12AffineFastState.Bounded env38336 := by
  intro p hp
  have h : env38336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38335_38336 : H12AffineEnvironment.transform 11 276 env38335 = env38336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env38335 == env38336) = true)

theorem identity38336 : scanCanonicalize (H12AffineFastState.compose env38336 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 549) := by decide +kernel

theorem selectedBound38336 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env38337 : List Nat := [2,4,8,16,32,17,128,256,512,549,2048,276,24,821,820,791,821,919,548,821,277,396,17,530,144,17,522,821,276,2341,21,17,257,804,821,513]

theorem envBound38337 : H12AffineFastState.Bounded env38337 := by
  intro p hp
  have h : env38337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38336_38337 : H12AffineEnvironment.transform 9 549 env38336 = env38337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 549 env38336 == env38337) = true)

theorem identity38337 : scanCanonicalize (H12AffineFastState.compose env38337 (packedSelected [0,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 798) := by decide +kernel

theorem selectedBound38337 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env38338 : List Nat := [2,4,8,16,32,17,128,256,512,549,798,276,24,821,820,791,821,919,548,821,277,396,17,530,144,17,522,821,276,571,21,17,257,804,821,513]

theorem envBound38338 : H12AffineFastState.Bounded env38338 := by
  intro p hp
  have h : env38338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38337_38338 : H12AffineEnvironment.transform 10 798 env38337 = env38338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 798 env38337 == env38338) = true)

theorem identity38338 : scanCanonicalize (H12AffineFastState.compose env38338 (packedSelected [12,13,15] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound38338 : packedSelected [12,13,15] rootPS < 2^1333 := by decide +kernel

def env38339 : List Nat := [2,4,8,16,32,17,128,21,512,549,523,1,24,544,545,514,544,642,548,544,0,153,17,530,144,17,522,544,1,571,21,17,20,561,544,513]

theorem envBound38339 : H12AffineFastState.Bounded env38339 := by
  intro p hp
  have h : env38339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38338_38339 : H12AffineEnvironment.transform 7 21 env38338 = env38339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env38338 == env38339) = true)

theorem identity38339 : scanCanonicalize (H12AffineFastState.compose env38339 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound38339 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38340 : List Nat := [2,4,8,1,32,0,128,4,512,549,523,1,9,544,545,514,544,642,548,544,0,136,0,515,129,0,522,544,1,554,4,0,5,544,544,513]

theorem envBound38340 : H12AffineFastState.Bounded env38340 := by
  intro p hp
  have h : env38340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38339_38340 : H12AffineEnvironment.transform 3 1 env38339 = env38340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env38339 == env38340) = true)

theorem identity38340 : scanCanonicalize (H12AffineFastState.compose env38340 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 162) := by decide +kernel

theorem selectedBound38340 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env38341 : List Nat := [2,4,8,1,32,0,128,4,162,135,169,1,9,130,131,160,130,32,134,130,0,136,0,161,129,0,168,130,1,136,4,0,5,130,130,163]

theorem envBound38341 : H12AffineFastState.Bounded env38341 := by
  intro p hp
  have h : env38341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38340_38341 : H12AffineEnvironment.transform 8 162 env38340 = env38341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 162 env38340 == env38341) = true)

theorem identity38341 : scanCanonicalize (H12AffineFastState.compose env38341 (packedSelected [1,4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound38341 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env38342 : List Nat := [1,4,8,1,32,0,128,4,161,132,169,1,9,129,128,160,129,32,133,129,0,136,0,161,129,0,168,129,1,136,4,0,5,129,129,160]

theorem envBound38342 : H12AffineFastState.Bounded env38342 := by
  intro p hp
  have h : env38342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38341_38342 : H12AffineEnvironment.transform 0 1 env38341 = env38342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env38341 == env38342) = true)

theorem identity38342 : scanCanonicalize (H12AffineFastState.compose env38342 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 33) := by decide +kernel

theorem selectedBound38342 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env38343 : List Nat := [1,4,8,1,32,0,33,4,0,37,8,1,9,32,33,1,32,32,36,32,0,41,0,0,32,0,9,32,1,41,4,0,5,32,32,1]

theorem envBound38343 : H12AffineFastState.Bounded env38343 := by
  intro p hp
  have h : env38343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38342_38343 : H12AffineEnvironment.transform 6 33 env38342 = env38343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 33 env38342 == env38343) = true)

theorem identity38343 : scanCanonicalize (H12AffineFastState.compose env38343 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound38343 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env38344 : List Nat := [1,4,0,1,32,0,33,4,0,37,0,1,1,32,33,1,32,32,36,32,0,33,0,0,32,0,1,32,1,33,4,0,5,32,32,1]

theorem envBound38344 : H12AffineFastState.Bounded env38344 := by
  intro p hp
  have h : env38344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38343_38344 : H12AffineEnvironment.transform 2 0 env38343 = env38344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env38343 == env38344) = true)

theorem identity38344 : scanCanonicalize (H12AffineFastState.compose env38344 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 4) := by decide +kernel

theorem selectedBound38344 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38345 : List Nat := [1,4,0,1,4,0,5,4,0,1,0,1,1,4,5,1,4,4,0,4,0,5,0,0,4,0,1,4,1,5,4,0,5,4,4,1]

theorem envBound38345 : H12AffineFastState.Bounded env38345 := by
  intro p hp
  have h : env38345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38344_38345 : H12AffineEnvironment.transform 4 4 env38344 = env38345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 4 env38344 == env38345) = true)

def env38346 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1345,65665,77934,13340,4097,477,17,69648,70887,78895,77841,1296,74814,81226,8204,8200,257,1281,1345,79470]

theorem envBound38346 : H12AffineFastState.Bounded env38346 := by
  intro p hp
  have h : env38346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38320_38346 : H12AffineEnvironment.transform 17 65665 env38320 = env38346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env38320 == env38346) = true)

theorem identity38346 : scanCanonicalize (H12AffineFastState.compose env38346 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 311) := by decide +kernel

theorem selectedBound38346 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env38347 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,311,1345,438,12633,13340,4097,477,17,4391,5584,13592,12582,1296,9481,15485,8204,8200,257,1281,1345,14169]

theorem envBound38347 : H12AffineFastState.Bounded env38347 := by
  intro p hp
  have h : env38347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38346_38347 : H12AffineEnvironment.transform 15 311 env38346 = env38347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 311 env38346 == env38347) = true)

def env38348 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,24,1296,5125,311,1345,438,4417,5124,4097,477,17,4391,5584,5376,4414,1296,1297,7269,20,16,257,1281,1345,5953]

theorem envBound38348 : H12AffineFastState.Bounded env38348 := by
  intro p hp
  have h : env38348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38347_38348 : H12AffineEnvironment.transform 12 24 env38347 = env38348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env38347 == env38348) = true)

theorem identity38348 : scanCanonicalize (H12AffineFastState.compose env38348 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound38348 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env38349 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,24,1296,1029,311,1345,438,321,1028,1,477,17,295,1488,1280,318,1296,1297,3173,20,16,257,1281,1345,1857]

theorem envBound38349 : H12AffineFastState.Bounded env38349 := by
  intro p hp
  have h : env38349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38348_38349 : H12AffineEnvironment.transform 11 0 env38348 = env38349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env38348 == env38349) = true)

theorem identity38349 : scanCanonicalize (H12AffineFastState.compose env38349 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(10+1) ^^^ 318) := by decide +kernel

theorem selectedBound38349 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env38350 : List Nat := [2,4,8,16,32,64,128,256,512,1024,318,0,24,1296,1029,311,1345,438,321,1028,1,477,17,295,1488,1280,318,1296,1297,1371,20,16,257,1281,1345,1857]

theorem envBound38350 : H12AffineFastState.Bounded env38350 := by
  intro p hp
  have h : env38350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38349_38350 : H12AffineEnvironment.transform 10 318 env38349 = env38350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 318 env38349 == env38350) = true)

theorem identity38350 : scanCanonicalize (H12AffineFastState.compose env38350 (packedSelected [1,3,10,11,16] rootPS)) = affineNative (2^(8+1) ^^^ 81) := by decide +kernel

theorem selectedBound38350 : packedSelected [1,3,10,11,16] rootPS < 2^1333 := by decide +kernel

def env38351 : List Nat := [2,4,8,16,32,64,128,256,81,1024,318,0,24,1296,1029,311,1345,438,321,1028,1,477,17,295,1488,1280,318,1296,1297,1371,20,16,257,1281,1345,1296]

theorem envBound38351 : H12AffineFastState.Bounded env38351 := by
  intro p hp
  have h : env38351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38350_38351 : H12AffineEnvironment.transform 8 81 env38350 = env38351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env38350 == env38351) = true)

theorem identity38351 : scanCanonicalize (H12AffineFastState.compose env38351 (packedSelected [3,8,10,13,15,17] rootPS)) = affineNative (2^(9+1) ^^^ 505) := by decide +kernel

theorem selectedBound38351 : packedSelected [3,8,10,13,15,17] rootPS < 2^1333 := by decide +kernel

def env38352 : List Nat := [2,4,8,16,32,64,128,256,81,505,318,0,24,233,508,311,184,438,321,509,1,477,17,295,41,249,318,233,232,162,20,16,257,248,184,233]

theorem envBound38352 : H12AffineFastState.Bounded env38352 := by
  intro p hp
  have h : env38352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38351_38352 : H12AffineEnvironment.transform 9 505 env38351 = env38352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 505 env38351 == env38352) = true)

theorem identity38352 : scanCanonicalize (H12AffineFastState.compose env38352 (packedSelected [2,4,5,8,9,10,11] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound38352 : packedSelected [2,4,5,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env38353 : List Nat := [2,4,8,16,32,59,128,256,42,386,318,0,24,146,391,311,184,438,314,390,1,422,17,295,41,130,318,146,147,162,20,16,257,131,184,146]

theorem envBound38353 : H12AffineFastState.Bounded env38353 := by
  intro p hp
  have h : env38353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38352_38353 : H12AffineEnvironment.transform 5 59 env38352 = env38353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env38352 == env38353) = true)

theorem identity38353 : scanCanonicalize (H12AffineFastState.compose env38353 (packedSelected [2,4,5,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound38353 : packedSelected [2,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env38354 : List Nat := [2,4,8,16,32,59,128,36,42,166,26,0,24,146,163,19,184,146,30,162,1,130,17,3,41,130,26,146,147,162,20,16,37,131,184,146]

theorem envBound38354 : H12AffineFastState.Bounded env38354 := by
  intro p hp
  have h : env38354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38353_38354 : H12AffineEnvironment.transform 7 36 env38353 = env38354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env38353 == env38354) = true)

theorem identity38354 : scanCanonicalize (H12AffineFastState.compose env38354 (packedSelected [2,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound38354 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env38355 : List Nat := [2,4,8,16,11,16,128,15,1,141,26,0,24,146,136,19,147,146,30,137,1,130,17,3,2,130,26,146,147,137,20,16,14,131,147,146]

theorem envBound38355 : H12AffineFastState.Bounded env38355 := by
  intro p hp
  have h : env38355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38354_38355 : H12AffineEnvironment.transform 4 11 env38354 = env38355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env38354 == env38355) = true)

theorem identity38355 : scanCanonicalize (H12AffineFastState.compose env38355 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound38355 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38356 : List Nat := [2,4,8,16,11,16,8,15,1,5,26,0,24,26,0,19,27,26,30,1,1,10,17,3,2,10,26,26,27,1,20,16,14,11,27,26]

theorem envBound38356 : H12AffineFastState.Bounded env38356 := by
  intro p hp
  have h : env38356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38355_38356 : H12AffineEnvironment.transform 6 8 env38355 = env38356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env38355 == env38356) = true)

theorem identity38356 : scanCanonicalize (H12AffineFastState.compose env38356 (packedSelected [0,1,4] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound38356 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env38357 : List Nat := [2,4,5,16,6,16,5,2,1,5,23,0,21,23,0,19,22,23,19,1,1,7,17,3,2,7,23,23,22,1,20,16,3,6,22,23]

theorem envBound38357 : H12AffineFastState.Bounded env38357 := by
  intro p hp
  have h : env38357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38356_38357 : H12AffineEnvironment.transform 2 5 env38356 = env38357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env38356 == env38357) = true)

def env38358 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,25,1296,5124,311,1345,438,4416,5125,4097,477,17,4391,5584,5377,4415,1296,1296,7268,21,17,257,1281,1345,5952]

theorem envBound38358 : H12AffineFastState.Bounded env38358 := by
  intro p hp
  have h : env38358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38347_38358 : H12AffineEnvironment.transform 12 25 env38347 = env38358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env38347 == env38358) = true)

theorem identity38358 : scanCanonicalize (H12AffineFastState.compose env38358 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 325) := by decide +kernel

theorem selectedBound38358 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env38359 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,325,25,1296,1345,311,1345,438,5,1344,324,477,17,98,1173,1092,122,1296,1296,3361,21,17,257,1281,1345,1541]

theorem envBound38359 : H12AffineFastState.Bounded env38359 := by
  intro p hp
  have h : env38359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38358_38359 : H12AffineEnvironment.transform 11 325 env38358 = env38359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 325 env38358 == env38359) = true)

theorem identity38359 : scanCanonicalize (H12AffineFastState.compose env38359 (packedSelected [3,4,9,10,13,17,18,19,20,23,24] rootPS)) = affineNative (2^(10+1) ^^^ 470) := by decide +kernel

theorem selectedBound38359 : packedSelected [3,4,9,10,13,17,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env38360 : List Nat := [2,4,8,16,32,64,128,256,512,1024,470,325,25,1296,1345,311,1345,438,5,1344,324,477,17,98,1173,1092,122,1296,1296,1271,21,17,257,1281,1345,1541]

theorem envBound38360 : H12AffineFastState.Bounded env38360 := by
  intro p hp
  have h : env38360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38359_38360 : H12AffineEnvironment.transform 10 470 env38359 = env38360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 470 env38359 == env38360) = true)

theorem identity38360 : scanCanonicalize (H12AffineFastState.compose env38360 (packedSelected [5,8,10,12,13,15,16,18] rootPS)) = affineNative (2^(7+1) ^^^ 182) := by decide +kernel

theorem selectedBound38360 : packedSelected [5,8,10,12,13,15,16,18] rootPS < 2^1333 := by decide +kernel

def env38361 : List Nat := [2,4,8,16,32,64,128,182,512,1024,96,243,25,1190,1271,129,1271,0,5,1270,242,107,17,98,1173,1092,122,1190,1190,1271,21,17,183,1207,1271,1541]

theorem envBound38361 : H12AffineFastState.Bounded env38361 := by
  intro p hp
  have h : env38361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38360_38361 : H12AffineEnvironment.transform 7 182 env38360 = env38361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 182 env38360 == env38361) = true)

theorem identity38361 : scanCanonicalize (H12AffineFastState.compose env38361 (packedSelected [1,8,10,11,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 66) := by decide +kernel

theorem selectedBound38361 : packedSelected [1,8,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env38362 : List Nat := [2,4,8,16,32,64,66,116,512,1024,96,49,25,1124,1077,67,1077,0,5,1076,48,107,17,98,1111,1092,122,1124,1124,1077,21,17,117,1141,1077,1541]

theorem envBound38362 : H12AffineFastState.Bounded env38362 := by
  intro p hp
  have h : env38362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38361_38362 : H12AffineEnvironment.transform 6 66 env38361 = env38362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 66 env38361 == env38362) = true)

theorem identity38362 : scanCanonicalize (H12AffineFastState.compose env38362 (packedSelected [0,1,2,3,7,10] rootPS)) = affineNative (2^(9+1) ^^^ 564) := by decide +kernel

theorem selectedBound38362 : packedSelected [0,1,2,3,7,10] rootPS < 2^1333 := by decide +kernel

def env38363 : List Nat := [2,4,8,16,32,64,66,116,512,564,96,49,25,592,513,67,513,0,5,512,48,107,17,98,611,624,122,592,592,513,21,17,117,577,513,49]

theorem envBound38363 : H12AffineFastState.Bounded env38363 := by
  intro p hp
  have h : env38363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38362_38363 : H12AffineEnvironment.transform 9 564 env38362 = env38363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 564 env38362 == env38363) = true)

theorem identity38363 : scanCanonicalize (H12AffineFastState.compose env38363 (packedSelected [1,2,3,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 123) := by decide +kernel

theorem selectedBound38363 : packedSelected [1,2,3,7,9] rootPS < 2^1333 := by decide +kernel

def env38364 : List Nat := [2,4,8,16,32,64,66,116,123,79,96,49,25,43,122,67,122,0,5,123,48,107,17,98,24,11,122,43,43,122,21,17,117,58,122,49]

theorem envBound38364 : H12AffineFastState.Bounded env38364 := by
  intro p hp
  have h : env38364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38363_38364 : H12AffineEnvironment.transform 8 123 env38363 = env38364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 123 env38363 == env38364) = true)

theorem identity38364 : scanCanonicalize (H12AffineFastState.compose env38364 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound38364 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env38365 : List Nat := [2,4,8,16,32,33,35,21,26,46,1,49,25,43,27,34,27,0,5,26,48,10,17,3,24,11,27,43,43,27,21,17,20,58,27,49]

theorem envBound38365 : H12AffineFastState.Bounded env38365 := by
  intro p hp
  have h : env38365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38364_38365 : H12AffineEnvironment.transform 5 33 env38364 = env38365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env38364 == env38365) = true)

theorem identity38365 : scanCanonicalize (H12AffineFastState.compose env38365 (packedSelected [0,1,4] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound38365 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env38366 : List Nat := [2,4,4,16,32,33,35,21,22,34,1,49,21,39,23,34,23,0,5,22,48,6,17,3,20,7,23,39,39,23,21,17,20,54,23,49]

theorem envBound38366 : H12AffineFastState.Bounded env38366 := by
  intro p hp
  have h : env38366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38365_38366 : H12AffineEnvironment.transform 2 4 env38365 = env38366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env38365 == env38366) = true)

theorem identity38366 : scanCanonicalize (H12AffineFastState.compose env38366 (packedSelected [1,2,5] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound38366 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env38367 : List Nat := [2,4,4,16,7,6,4,21,22,5,1,22,21,0,23,5,23,0,5,22,23,6,17,3,20,7,23,0,0,23,21,17,20,17,23,22]

theorem envBound38367 : H12AffineFastState.Bounded env38367 := by
  intro p hp
  have h : env38367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38366_38367 : H12AffineEnvironment.transform 4 7 env38366 = env38367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env38366 == env38367) = true)

theorem identity38367 : scanCanonicalize (H12AffineFastState.compose env38367 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound38367 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38368 : List Nat := [2,4,4,6,7,6,4,3,0,5,1,0,3,0,1,5,1,0,5,0,1,6,7,3,2,7,1,0,0,1,3,7,2,7,1,0]

theorem envBound38368 : H12AffineFastState.Bounded env38368 := by
  intro p hp
  have h : env38368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38367_38368 : H12AffineEnvironment.transform 3 6 env38367 = env38368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env38367 == env38368) = true)

def env38369 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1344,262144,77935,32769,4097,46529,17,266384,70886,78894,77841,1296,74814,81227,365713,365717,257,1281,1345,79471]

theorem envBound38369 : H12AffineFastState.Bounded env38369 := by
  intro p hp
  have h : env38369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38318_38369 : H12AffineEnvironment.transform 13 1297 env38318 = env38369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env38318 == env38369) = true)

theorem identity38369 : scanCanonicalize (H12AffineFastState.compose env38369 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32883) := by decide +kernel

theorem selectedBound38369 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env38370 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,32883,1344,262144,45084,32769,4097,46529,17,266384,38037,46173,45154,1296,42061,48440,267490,267494,257,1281,1345,46620]

theorem envBound38370 : H12AffineFastState.Bounded env38370 := by
  intro p hp
  have h : env38370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38369_38370 : H12AffineEnvironment.transform 15 32883 env38369 = env38370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32883 env38369 == env38370) = true)

def env38371 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32883,1344,262144,42332,32769,1345,41089,17,263632,33237,41245,42274,1296,42061,43128,262562,262566,257,1281,1345,41820]

theorem envBound38371 : H12AffineFastState.Bounded env38371 := by
  intro p hp
  have h : env38371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38370_38371 : H12AffineEnvironment.transform 11 1344 env38370 = env38371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env38370 == env38371) = true)

theorem identity38371 : scanCanonicalize (H12AffineFastState.compose env38371 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 34274) := by decide +kernel

theorem selectedBound38371 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env38372 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32883,1344,34274,42332,32769,1345,41089,17,32818,33237,41245,42274,1296,42061,43128,33856,33860,257,1281,1345,41820]

theorem envBound38372 : H12AffineFastState.Bounded env38372 := by
  intro p hp
  have h : env38372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38371_38372 : H12AffineEnvironment.transform 17 34274 env38371 = env38372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 34274 env38371 == env38372) = true)

theorem identity38372 : scanCanonicalize (H12AffineFastState.compose env38372 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(14+1) ^^^ 925) := by decide +kernel

theorem selectedBound38372 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env38373 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,925,1006,1344,1663,9921,924,1345,8988,17,943,584,8832,9919,1296,10192,11237,2013,2009,257,1281,1345,8385]

theorem envBound38373 : H12AffineFastState.Bounded env38373 := by
  intro p hp
  have h : env38373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38372_38373 : H12AffineEnvironment.transform 14 925 env38372 = env38373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 925 env38372 == env38373) = true)

def env38374 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32883,1344,262144,42333,32769,1344,41088,17,263633,33236,41244,42275,1296,42061,43129,262563,262567,257,1281,1345,41821]

theorem envBound38374 : H12AffineFastState.Bounded env38374 := by
  intro p hp
  have h : env38374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38370_38374 : H12AffineEnvironment.transform 11 1345 env38370 = env38374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env38370 == env38374) = true)

theorem identity38374 : scanCanonicalize (H12AffineFastState.compose env38374 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound38374 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env38375 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,81,8192,1,32768,32883,80,262144,41037,32769,80,41088,17,262337,33236,41244,41011,0,41309,43129,262563,262567,257,17,81,41821]

theorem envBound38375 : H12AffineFastState.Bounded env38375 := by
  intro p hp
  have h : env38375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38374_38375 : H12AffineEnvironment.transform 9 272 env38374 = env38375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env38374 == env38375) = true)

theorem identity38375 : scanCanonicalize (H12AffineFastState.compose env38375 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound38375 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env38376 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,81,8192,1,8541,8494,80,262144,272,8540,80,477,17,262337,8329,65,366,0,0,2340,262563,262567,257,17,81,512]

theorem envBound38376 : H12AffineFastState.Bounded env38376 := by
  intro p hp
  have h : env38376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38375_38376 : H12AffineEnvironment.transform 14 8541 env38375 = env38376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env38375 == env38376) = true)

theorem identity38376 : scanCanonicalize (H12AffineFastState.compose env38376 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound38376 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env38377 : List Nat := [2,4,8,16,32,64,128,68,512,84,2048,81,8192,1,8217,8298,80,262144,84,8216,80,153,17,262337,8329,65,42,0,0,2144,262375,262371,69,17,81,512]

theorem envBound38377 : H12AffineFastState.Bounded env38377 := by
  intro p hp
  have h : env38377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38376_38377 : H12AffineEnvironment.transform 7 68 env38376 = env38377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env38376 == env38377) = true)

theorem identity38377 : scanCanonicalize (H12AffineFastState.compose env38377 (packedSelected [3,5,10] rootPS)) = affineNative (2^(17+1) ^^^ 8755) := by decide +kernel

theorem selectedBound38377 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env38378 : List Nat := [2,4,8,16,32,64,128,68,512,84,2048,81,8192,1,8217,8298,80,8755,84,8216,80,153,17,8946,8329,65,42,0,0,2144,8916,8912,69,17,81,512]

theorem envBound38378 : H12AffineFastState.Bounded env38378 := by
  intro p hp
  have h : env38378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38377_38378 : H12AffineEnvironment.transform 17 8755 env38377 = env38378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8755 env38377 == env38378) = true)

theorem identity38378 : scanCanonicalize (H12AffineFastState.compose env38378 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound38378 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env38379 : List Nat := [2,4,8,16,32,16,128,20,512,4,2048,1,8192,1,8217,8250,0,8755,4,8216,0,153,17,8866,8329,17,42,0,0,2096,8836,8832,21,17,1,512]

theorem envBound38379 : H12AffineFastState.Bounded env38379 := by
  intro p hp
  have h : env38379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38378_38379 : H12AffineEnvironment.transform 5 16 env38378 = env38379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38378 == env38379) = true)

theorem identity38379 : scanCanonicalize (H12AffineFastState.compose env38379 (packedSelected [1,3,13] rootPS)) = affineNative (2^(12+1) ^^^ 552) := by decide +kernel

theorem selectedBound38379 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env38380 : List Nat := [2,4,8,16,32,16,128,20,512,4,2048,1,552,1,561,530,0,27,4,560,0,153,17,138,673,17,42,0,0,2096,172,168,21,17,1,512]

theorem envBound38380 : H12AffineFastState.Bounded env38380 := by
  intro p hp
  have h : env38380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38379_38380 : H12AffineEnvironment.transform 12 552 env38379 = env38380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 552 env38379 == env38380) = true)

theorem identity38380 : scanCanonicalize (H12AffineFastState.compose env38380 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound38380 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38381 : List Nat := [2,4,8,16,32,16,128,20,512,4,48,1,552,1,561,530,0,27,4,560,0,153,17,138,673,17,42,0,0,0,172,168,21,17,1,512]

theorem envBound38381 : H12AffineFastState.Bounded env38381 := by
  intro p hp
  have h : env38381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38380_38381 : H12AffineEnvironment.transform 10 48 env38380 = env38381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env38380 == env38381) = true)

theorem identity38381 : scanCanonicalize (H12AffineFastState.compose env38381 (packedSelected [4,7] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound38381 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env38382 : List Nat := [2,4,8,16,11,16,128,20,512,4,27,1,515,1,538,530,0,27,4,539,0,153,17,138,650,17,1,0,0,0,135,131,21,17,1,512]

theorem envBound38382 : H12AffineFastState.Bounded env38382 := by
  intro p hp
  have h : env38382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38381_38382 : H12AffineEnvironment.transform 4 11 env38381 = env38382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env38381 == env38382) = true)

theorem identity38382 : scanCanonicalize (H12AffineFastState.compose env38382 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound38382 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env38383 : List Nat := [2,4,8,16,11,16,128,20,137,4,27,1,138,1,147,155,0,27,4,146,0,153,17,138,3,17,1,0,0,0,135,131,21,17,1,137]

theorem envBound38383 : H12AffineFastState.Bounded env38383 := by
  intro p hp
  have h : env38383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38382_38383 : H12AffineEnvironment.transform 8 137 env38382 = env38383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env38382 == env38383) = true)

theorem identity38383 : scanCanonicalize (H12AffineFastState.compose env38383 (packedSelected [1,5] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound38383 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env38384 : List Nat := [2,4,8,16,11,16,19,20,26,4,27,1,25,1,0,8,0,27,4,1,0,10,17,25,3,17,1,0,0,0,20,16,21,17,1,26]

theorem envBound38384 : H12AffineFastState.Bounded env38384 := by
  intro p hp
  have h : env38384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38383_38384 : H12AffineEnvironment.transform 6 19 env38383 = env38384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env38383 == env38384) = true)

theorem identity38384 : scanCanonicalize (H12AffineFastState.compose env38384 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound38384 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38385 : List Nat := [2,4,5,16,6,16,19,20,23,4,22,1,20,1,0,5,0,22,4,1,0,7,17,20,3,17,1,0,0,0,20,16,21,17,1,23]

theorem envBound38385 : H12AffineFastState.Bounded env38385 := by
  intro p hp
  have h : env38385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38384_38385 : H12AffineEnvironment.transform 2 5 env38384 = env38385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env38384 == env38385) = true)

theorem identity38385 : scanCanonicalize (H12AffineFastState.compose env38385 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound38385 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38386 : List Nat := [2,4,5,6,6,6,5,2,1,4,0,1,2,1,0,5,0,0,4,1,0,7,7,2,3,7,1,0,0,0,2,6,3,7,1,1]

theorem envBound38386 : H12AffineFastState.Bounded env38386 := by
  intro p hp
  have h : env38386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38385_38386 : H12AffineEnvironment.transform 3 6 env38385 = env38386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env38385 == env38386) = true)

def env38387 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,2154705,147520,16777216,33554432,672784,134217728,148801,33584585,2189403,50962568,4294967296,34088328,4347445490,151462017,33563273]

theorem envBound38387 : H12AffineFastState.Bounded env38387 := by
  intro p hp
  have h : env38387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35962_38387 : H12AffineEnvironment.transform 34 151462017 env35962 = env38387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 151462017 env35962 == env38387) = true)

def env38388 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,16777216,33554432,672784,134217728,148801,33584585,96347,50962568,4294967296,34088328,4345352434,151462017,33563273]

theorem envBound38388 : H12AffineFastState.Bounded env38388 := by
  intro p hp
  have h : env38388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38387_38388 : H12AffineEnvironment.transform 20 4096 env38387 = env38388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env38387 == env38388) = true)

theorem identity38388 : scanCanonicalize (H12AffineFastState.compose env38388 (packedSelected [14] rootPS)) = affineNative (2^(31+1) ^^^ 50386419) := by decide +kernel

theorem selectedBound38388 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env38389 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,16777216,33554432,672784,134217728,148801,33584585,96347,50962568,50386419,34088328,1281,151462017,33563273]

theorem envBound38389 : H12AffineFastState.Bounded env38389 := by
  intro p hp
  have h : env38389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38388_38389 : H12AffineEnvironment.transform 31 50386419 env38388 = env38389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 50386419 env38388 == env38389) = true)

def env38390 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,16777216,533640,672784,134217728,148801,545089,96347,16876544,17363323,256,1281,151462017,525825]

theorem envBound38390 : H12AffineFastState.Bounded env38390 := by
  intro p hp
  have h : env38390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38389_38390 : H12AffineEnvironment.transform 24 533640 env38389 = env38390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 533640 env38389 == env38390) = true)

def env38391 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,16777216,533640,672784,17245632,148801,545089,96347,16876544,17363323,256,1281,1345,525825]

theorem envBound38391 : H12AffineFastState.Bounded env38391 := by
  intro p hp
  have h : env38391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38390_38391 : H12AffineEnvironment.transform 26 17245632 env38390 = env38391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245632 env38390 == env38391) = true)

theorem identity38391 : scanCanonicalize (H12AffineFastState.compose env38391 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 717114) := by decide +kernel

theorem selectedBound38391 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env38392 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,717114,533640,672784,906490,148801,545089,96347,750906,131137,256,1281,1345,525825]

theorem envBound38392 : H12AffineFastState.Bounded env38392 := by
  intro p hp
  have h : env38392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38391_38392 : H12AffineEnvironment.transform 23 717114 env38391 = env38392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 717114 env38391 == env38392) = true)

def env38393 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147520,58682,143496,20496,508154,148801,148801,96347,90426,131137,256,1281,1345,135681]

theorem envBound38393 : H12AffineFastState.Bounded env38393 := by
  intro p hp
  have h : env38393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38392_38393 : H12AffineEnvironment.transform 18 136192 env38392 = env38393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136192 env38392 == env38393) = true)

def env38394 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147520,58518,143496,20496,508154,148717,148717,96347,90262,131137,172,1197,1261,135681]

theorem envBound38394 : H12AffineFastState.Bounded env38394 := by
  intro p hp
  have h : env38394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38393_38394 : H12AffineEnvironment.transform 7 172 env38393 = env38394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env38393 == env38394) = true)

def env38395 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61569,147472,58518,143496,20496,508074,148669,148669,96267,90262,131089,172,1197,1213,135681]

theorem envBound38395 : H12AffineFastState.Bounded env38395 := by
  intro p hp
  have h : env38395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38394_38395 : H12AffineEnvironment.transform 5 16 env38394 = env38395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38394 == env38395) = true)

theorem identity38395 : scanCanonicalize (H12AffineFastState.compose env38395 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 99486) := by decide +kernel

theorem selectedBound38395 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env38396 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,99486,262144,102558,32769,4096,61569,115854,58518,111638,20496,279604,114723,114723,96267,90262,99471,172,1197,1213,104095]

theorem envBound38396 : H12AffineFastState.Bounded env38396 := by
  intro p hp
  have h : env38396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38395_38396 : H12AffineEnvironment.transform 16 99486 env38395 = env38396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 99486 env38395 == env38396) = true)

theorem identity38396 : scanCanonicalize (H12AffineFastState.compose env38396 (packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS)) = affineNative (2^(15+1) ^^^ 54311) := by decide +kernel

theorem selectedBound38396 : packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS < 2^1333 := by decide +kernel

def env38397 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,54311,20665,262144,17593,32769,4096,61569,4265,58518,24625,20496,279604,5124,5124,44076,46257,20648,172,1197,1213,17080]

theorem envBound38397 : H12AffineFastState.Bounded env38397 := by
  intro p hp
  have h : env38397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38396_38397 : H12AffineEnvironment.transform 15 54311 env38396 = env38397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54311 env38396 == env38397) = true)

theorem identity38397 : scanCanonicalize (H12AffineFastState.compose env38397 (packedSelected [3,7,10,20,24,26,27] rootPS)) = affineNative (2^(13+1) ^^^ 184) := by decide +kernel

theorem selectedBound38397 : packedSelected [3,7,10,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env38398 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,184,32768,38047,4097,262144,1025,32769,4096,45113,4265,42030,8329,4264,263308,5124,5124,44076,46257,4112,172,1197,1213,512]

theorem envBound38398 : H12AffineFastState.Bounded env38398 := by
  intro p hp
  have h : env38398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38397_38398 : H12AffineEnvironment.transform 13 184 env38397 = env38398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 184 env38397 == env38398) = true)

theorem identity38398 : scanCanonicalize (H12AffineFastState.compose env38398 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound38398 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env38399 : List Nat := [2,4,8,16,32,16,128,172,512,4,2048,4096,8192,184,32768,37019,4097,262144,5,32769,4096,45113,4265,41002,8329,4264,262280,4096,4096,43048,45237,4112,172,169,185,512]

theorem envBound38399 : H12AffineFastState.Bounded env38399 := by
  intro p hp
  have h : env38399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38398_38399 : H12AffineEnvironment.transform 9 4 env38398 = env38399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env38398 == env38399) = true)

theorem identity38399 : scanCanonicalize (H12AffineFastState.compose env38399 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 4745) := by decide +kernel

theorem selectedBound38399 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env38400 : List Nat := [2,4,8,16,32,16,128,172,512,4,2048,4096,8192,184,4745,530,4097,262144,5,4744,4096,8880,4265,12963,8329,4264,262280,4096,4096,15009,8764,4112,172,169,185,512]

theorem envBound38400 : H12AffineFastState.Bounded env38400 := by
  intro p hp
  have h : env38400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38399_38400 : H12AffineEnvironment.transform 14 4745 env38399 = env38400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 4745 env38399 == env38400) = true)

theorem identity38400 : scanCanonicalize (H12AffineFastState.compose env38400 (packedSelected [1,3,13] rootPS)) = affineNative (2^(12+1) ^^^ 656) := by decide +kernel

theorem selectedBound38400 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env38401 : List Nat := [2,4,8,16,32,16,128,172,512,4,2048,4096,656,184,4745,530,4097,262144,5,4744,4096,32,4265,4147,537,4264,262280,4096,4096,6193,172,4112,172,169,185,512]

theorem envBound38401 : H12AffineFastState.Bounded env38401 := by
  intro p hp
  have h : env38401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38400_38401 : H12AffineEnvironment.transform 12 656 env38400 = env38401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 656 env38400 == env38401) = true)

theorem identity38401 : scanCanonicalize (H12AffineFastState.compose env38401 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 4754) := by decide +kernel

theorem selectedBound38401 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env38402 : List Nat := [2,4,8,16,32,16,128,172,512,4,2048,4096,656,184,4745,530,4097,4754,5,4744,4096,32,4265,4147,537,4264,4634,4096,4096,6193,172,4112,172,169,185,512]

theorem envBound38402 : H12AffineFastState.Bounded env38402 := by
  intro p hp
  have h : env38402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38401_38402 : H12AffineEnvironment.transform 17 4754 env38401 = env38402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 4754 env38401 == env38402) = true)

theorem identity38402 : scanCanonicalize (H12AffineFastState.compose env38402 (packedSelected [0,1,3,4,7,9,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 185) := by decide +kernel

theorem selectedBound38402 : packedSelected [0,1,3,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env38403 : List Nat := [2,4,8,16,32,16,128,172,512,4,2048,185,656,184,560,530,184,555,5,561,185,32,16,138,537,17,675,185,185,2184,172,169,172,169,185,512]

theorem envBound38403 : H12AffineFastState.Bounded env38403 := by
  intro p hp
  have h : env38403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38402_38403 : H12AffineEnvironment.transform 11 185 env38402 = env38403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 185 env38402 == env38403) = true)

theorem identity38403 : scanCanonicalize (H12AffineFastState.compose env38403 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound38403 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38404 : List Nat := [2,4,8,16,32,16,128,172,512,4,512,185,656,184,560,530,184,555,5,561,185,32,16,138,537,17,675,185,185,648,172,169,172,169,185,512]

theorem envBound38404 : H12AffineFastState.Bounded env38404 := by
  intro p hp
  have h : env38404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38403_38404 : H12AffineEnvironment.transform 10 512 env38403 = env38404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env38403 == env38404) = true)

theorem identity38404 : scanCanonicalize (H12AffineFastState.compose env38404 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound38404 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env38405 : List Nat := [2,4,8,16,32,16,56,20,512,4,512,1,552,0,560,530,0,555,5,561,1,32,16,50,537,17,539,1,1,560,20,17,20,17,1,512]

theorem envBound38405 : H12AffineFastState.Bounded env38405 := by
  intro p hp
  have h : env38405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38404_38405 : H12AffineEnvironment.transform 6 56 env38404 = env38405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env38404 == env38405) = true)

theorem identity38405 : scanCanonicalize (H12AffineFastState.compose env38405 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 28) := by decide +kernel

theorem selectedBound38405 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38406 : List Nat := [2,4,8,16,28,16,4,20,512,4,512,1,532,0,524,530,0,535,5,525,1,28,16,14,537,17,539,1,1,524,20,17,20,17,1,512]

theorem envBound38406 : H12AffineFastState.Bounded env38406 := by
  intro p hp
  have h : env38406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38405_38406 : H12AffineEnvironment.transform 4 28 env38405 = env38406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 28 env38405 == env38406) = true)

theorem identity38406 : scanCanonicalize (H12AffineFastState.compose env38406 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound38406 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38407 : List Nat := [2,4,8,16,28,16,4,20,0,4,0,1,20,0,12,18,0,23,5,13,1,28,16,14,25,17,27,1,1,12,20,17,20,17,1,0]

theorem envBound38407 : H12AffineFastState.Bounded env38407 := by
  intro p hp
  have h : env38407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38406_38407 : H12AffineEnvironment.transform 8 0 env38406 = env38407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env38406 == env38407) = true)

theorem identity38407 : scanCanonicalize (H12AffineFastState.compose env38407 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound38407 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env38408 : List Nat := [2,4,8,11,7,11,4,15,0,4,0,1,15,0,12,9,0,12,5,13,1,7,11,14,2,10,0,1,1,12,15,10,15,10,1,0]

theorem envBound38408 : H12AffineFastState.Bounded env38408 := by
  intro p hp
  have h : env38408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38407_38408 : H12AffineEnvironment.transform 3 11 env38407 = env38408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env38407 == env38408) = true)

def env38409 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61568,147473,58518,143496,20496,508075,148668,148668,96266,90262,131088,172,1197,1212,135681]

end H12CloudChart2