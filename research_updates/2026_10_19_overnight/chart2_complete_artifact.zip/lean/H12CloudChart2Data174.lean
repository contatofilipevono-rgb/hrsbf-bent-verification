import H12CloudChart2Data173

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound43578 : packedSelected [1,4,11] rootPS < 2^1333 := by decide +kernel

def env43579 : List Nat := [2,4,8,9,2,9,7,12,5,4,7,1,8,0,9,9,1,15,5,8,1,6,9,1,7,8,8,0,0,12,4,0,13,9,0,4]

theorem envBound43579 : H12AffineFastState.Bounded env43579 := by
  intro p hp
  have h : env43579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43578_43579 : H12AffineEnvironment.transform 4 2 env43578 = env43579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env43578 == env43579) = true)

theorem identity43579 : scanCanonicalize (H12AffineFastState.compose env43579 (packedSelected [0,4,5] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound43579 : packedSelected [0,4,5] rootPS < 2^1333 := by decide +kernel

def env43580 : List Nat := [2,4,4,5,2,5,7,0,5,4,7,1,4,0,5,5,1,3,5,4,1,6,5,1,7,4,4,0,0,0,4,0,1,5,0,4]

theorem envBound43580 : H12AffineFastState.Bounded env43580 := by
  intro p hp
  have h : env43580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43579_43580 : H12AffineEnvironment.transform 2 4 env43579 = env43580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env43579 == env43580) = true)

theorem identity43580 : scanCanonicalize (H12AffineFastState.compose env43580 (packedSelected [0,1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound43580 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env43581 : List Nat := [2,1,1,0,2,0,2,0,0,1,2,1,1,0,0,0,1,3,0,1,1,3,0,1,2,1,1,0,0,0,1,0,1,0,0,1]

theorem envBound43581 : H12AffineFastState.Bounded env43581 := by
  intro p hp
  have h : env43581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43580_43581 : H12AffineEnvironment.transform 1 1 env43580 = env43581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env43580 == env43581) = true)

def env43582 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,21585,32769,4096,61649,91182,123164,28888,78895,385203,90415,1296,96347,25885,25881,257,74799,1345,21073]

theorem envBound43582 : H12AffineFastState.Bounded env43582 := by
  intro p hp
  have h : env43582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43386_43582 : H12AffineEnvironment.transform 18 21585 env43386 = env43582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21585 env43386 == env43582) = true)

theorem identity43582 : scanCanonicalize (H12AffineFastState.compose env43582 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 25677) := by decide +kernel

theorem selectedBound43582 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env43583 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,25677,65536,74863,262144,21585,25676,4096,5276,91182,66897,28888,78895,328958,90415,1296,96347,25885,25881,257,74799,1345,21073]

theorem envBound43583 : H12AffineFastState.Bounded env43583 := by
  intro p hp
  have h : env43583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43582_43583 : H12AffineEnvironment.transform 14 25677 env43582 = env43583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25677 env43582 == env43583) = true)

def env43584 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74863,262144,4417,8540,4096,5276,74046,66897,13768,78895,328958,74815,1296,81227,8205,8201,257,74799,1345,5953]

theorem envBound43584 : H12AffineFastState.Bounded env43584 := by
  intro p hp
  have h : env43584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43583_43584 : H12AffineEnvironment.transform 13 1296 env43583 = env43584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env43583 == env43584) = true)

def env43585 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74863,65664,4417,8540,4096,5276,74046,66897,13768,78895,1150,74815,1296,81227,8205,8201,257,74799,1345,5953]

theorem envBound43585 : H12AffineFastState.Bounded env43585 := by
  intro p hp
  have h : env43585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43584_43585 : H12AffineEnvironment.transform 17 65664 env43584 = env43585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env43584 == env43585) = true)

theorem identity43585 : scanCanonicalize (H12AffineFastState.compose env43585 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5465) := by decide +kernel

theorem selectedBound43585 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env43586 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5465,1296,5124,65536,69942,65664,4417,5125,4096,5276,70759,66897,145,65910,1150,69990,1296,67602,5460,5456,257,70006,1345,5953]

theorem envBound43586 : H12AffineFastState.Bounded env43586 := by
  intro p hp
  have h : env43586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43585_43586 : H12AffineEnvironment.transform 12 5465 env43585 = env43586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5465 env43585 == env43586) = true)

def env43587 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1556,845,1296,528,65536,67362,65664,1877,529,1556,648,66163,66897,145,65910,1150,67442,1296,67602,832,836,257,67426,1345,341]

theorem envBound43587 : H12AffineFastState.Bounded env43587 := by
  intro p hp
  have h : env43587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43586_43587 : H12AffineEnvironment.transform 11 1556 env43586 = env43587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1556 env43586 == env43587) = true)

def env43588 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,836,845,64,528,65536,66162,65664,517,529,836,648,66163,65537,145,65910,302,66082,64,67602,832,836,257,66098,17,341]

theorem envBound43588 : H12AffineFastState.Bounded env43588 := by
  intro p hp
  have h : env43588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43587_43588 : H12AffineEnvironment.transform 9 336 env43587 = env43588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 336 env43587 == env43588) = true)

theorem identity43588 : scanCanonicalize (H12AffineFastState.compose env43588 (packedSelected [1,8,28] rootPS)) = affineNative (2^(5+1) ^^^ 12) := by decide +kernel

theorem selectedBound43588 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env43589 : List Nat := [2,4,8,16,32,12,128,256,512,284,2048,776,769,12,528,65536,66110,65664,517,529,776,648,66111,65537,145,65850,302,66082,12,67602,780,776,257,66098,17,281]

theorem envBound43589 : H12AffineFastState.Bounded env43589 := by
  intro p hp
  have h : env43589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43588_43589 : H12AffineEnvironment.transform 5 12 env43588 = env43589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 12 env43588 == env43589) = true)

def env43590 : List Nat := [2,4,8,16,32,12,128,256,280,284,2048,16,25,12,264,65536,65830,65664,285,265,16,400,65831,65537,145,65850,302,65850,12,67602,20,16,257,65834,17,281]

theorem envBound43590 : H12AffineFastState.Bounded env43590 := by
  intro p hp
  have h : env43590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43589_43590 : H12AffineEnvironment.transform 8 280 env43589 = env43590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 280 env43589 == env43590) = true)

theorem identity43590 : scanCanonicalize (H12AffineFastState.compose env43590 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 46) := by decide +kernel

theorem selectedBound43590 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env43591 : List Nat := [2,4,8,16,32,12,128,256,280,284,2048,16,25,12,264,46,264,174,285,265,16,400,265,47,145,276,302,276,12,2108,20,16,257,260,17,281]

theorem envBound43591 : H12AffineFastState.Bounded env43591 := by
  intro p hp
  have h : env43591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43590_43591 : H12AffineEnvironment.transform 15 46 env43590 = env43591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 46 env43590 == env43591) = true)

theorem identity43591 : scanCanonicalize (H12AffineFastState.compose env43591 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 8) := by decide +kernel

theorem selectedBound43591 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env43592 : List Nat := [2,4,8,16,32,12,128,8,16,20,2048,16,25,12,0,46,0,174,21,1,16,152,1,47,145,28,38,28,12,2108,20,16,9,12,17,17]

theorem envBound43592 : H12AffineFastState.Bounded env43592 := by
  intro p hp
  have h : env43592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43591_43592 : H12AffineEnvironment.transform 7 8 env43591 = env43592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 8 env43591 == env43592) = true)

theorem identity43592 : scanCanonicalize (H12AffineFastState.compose env43592 (packedSelected [3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound43592 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env43593 : List Nat := [2,4,8,0,32,12,128,8,0,4,2048,0,9,12,0,46,0,174,5,1,0,136,1,47,129,12,38,12,12,2092,4,0,9,12,1,1]

theorem envBound43593 : H12AffineFastState.Bounded env43593 := by
  intro p hp
  have h : env43593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43592_43593 : H12AffineEnvironment.transform 3 0 env43592 = env43593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env43592 == env43593) = true)

theorem identity43593 : scanCanonicalize (H12AffineFastState.compose env43593 (packedSelected [2,8] rootPS)) = affineNative (2^(10+1) ^^^ 131) := by decide +kernel

theorem selectedBound43593 : packedSelected [2,8] rootPS < 2^1333 := by decide +kernel

def env43594 : List Nat := [2,4,8,0,32,12,128,8,0,4,131,0,9,12,0,46,0,174,5,1,0,136,1,47,129,12,38,12,12,175,4,0,9,12,1,1]

theorem envBound43594 : H12AffineFastState.Bounded env43594 := by
  intro p hp
  have h : env43594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43593_43594 : H12AffineEnvironment.transform 10 131 env43593 = env43594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 131 env43593 == env43594) = true)

theorem identity43594 : scanCanonicalize (H12AffineFastState.compose env43594 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound43594 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env43595 : List Nat := [2,4,2,0,32,6,128,2,0,4,131,0,3,6,0,36,0,164,5,1,0,130,1,37,129,6,38,6,6,165,4,0,3,6,1,1]

theorem envBound43595 : H12AffineFastState.Bounded env43595 := by
  intro p hp
  have h : env43595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43594_43595 : H12AffineEnvironment.transform 2 2 env43594 = env43595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env43594 == env43595) = true)

theorem identity43595 : scanCanonicalize (H12AffineFastState.compose env43595 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 38) := by decide +kernel

theorem selectedBound43595 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env43596 : List Nat := [2,4,2,0,32,6,38,2,0,4,37,0,3,6,0,36,0,2,5,1,0,36,1,37,39,6,38,6,6,3,4,0,3,6,1,1]

theorem envBound43596 : H12AffineFastState.Bounded env43596 := by
  intro p hp
  have h : env43596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43595_43596 : H12AffineEnvironment.transform 6 38 env43595 = env43596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 38 env43595 == env43596) = true)

theorem identity43596 : scanCanonicalize (H12AffineFastState.compose env43596 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 4) := by decide +kernel

theorem selectedBound43596 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env43597 : List Nat := [2,4,2,0,4,6,2,2,0,4,1,0,3,6,0,0,0,2,5,1,0,0,1,1,3,6,2,6,6,3,4,0,3,6,1,1]

theorem envBound43597 : H12AffineFastState.Bounded env43597 := by
  intro p hp
  have h : env43597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43596_43597 : H12AffineEnvironment.transform 4 4 env43596 = env43597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 4 env43596 == env43597) = true)

theorem identity43597 : scanCanonicalize (H12AffineFastState.compose env43597 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound43597 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43598 : List Nat := [2,3,2,0,3,1,2,2,0,3,1,0,3,1,0,0,0,2,2,1,0,0,1,1,3,1,2,1,1,3,3,0,3,1,1,1]

theorem envBound43598 : H12AffineFastState.Bounded env43598 := by
  intro p hp
  have h : env43598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43597_43598 : H12AffineEnvironment.transform 1 3 env43597 = env43598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env43597 == env43598) = true)

theorem identity43598 : scanCanonicalize (H12AffineFastState.compose env43598 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound43598 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43599 : List Nat := [1,0,1,0,0,1,1,1,0,0,1,0,0,1,0,0,0,1,1,1,0,0,1,1,0,1,1,1,1,0,0,0,0,1,1,1]

theorem envBound43599 : H12AffineFastState.Bounded env43599 := by
  intro p hp
  have h : env43599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43598_43599 : H12AffineEnvironment.transform 0 1 env43598 = env43599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env43598 == env43599) = true)

def env43600 : List Nat := [2,4,8,16,32,12,128,256,281,284,2048,17,24,12,265,65536,65831,65664,284,264,17,401,65830,65537,145,65850,302,65851,12,67602,21,17,257,65835,17,281]

theorem envBound43600 : H12AffineFastState.Bounded env43600 := by
  intro p hp
  have h : env43600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43589_43600 : H12AffineEnvironment.transform 8 281 env43589 = env43600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 281 env43589 == env43600) = true)

theorem identity43600 : scanCanonicalize (H12AffineFastState.compose env43600 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound43600 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env43601 : List Nat := [2,4,8,16,32,12,128,4,29,24,2048,17,24,12,13,65536,65571,65664,24,12,17,149,65570,65537,145,65598,42,65599,12,67602,21,17,5,65583,17,29]

theorem envBound43601 : H12AffineFastState.Bounded env43601 := by
  intro p hp
  have h : env43601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43600_43601 : H12AffineEnvironment.transform 7 4 env43600 = env43601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env43600 == env43601) = true)

theorem identity43601 : scanCanonicalize (H12AffineFastState.compose env43601 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 46) := by decide +kernel

theorem selectedBound43601 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env43602 : List Nat := [2,4,8,16,32,12,128,4,29,24,2048,17,24,12,13,46,13,174,24,12,17,149,12,47,145,16,42,17,12,2108,21,17,5,1,17,29]

theorem envBound43602 : H12AffineFastState.Bounded env43602 := by
  intro p hp
  have h : env43602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43601_43602 : H12AffineEnvironment.transform 15 46 env43601 = env43602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 46 env43601 == env43602) = true)

theorem identity43602 : scanCanonicalize (H12AffineFastState.compose env43602 (packedSelected [1,2,3,13] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound43602 : packedSelected [1,2,3,13] rootPS < 2^1333 := by decide +kernel

def env43603 : List Nat := [2,4,8,16,27,12,128,4,29,24,2048,17,24,12,13,21,13,149,24,12,17,149,12,20,145,16,17,17,12,2055,21,17,5,1,17,29]

theorem envBound43603 : H12AffineFastState.Bounded env43603 := by
  intro p hp
  have h : env43603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43602_43603 : H12AffineEnvironment.transform 4 27 env43602 = env43603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env43602 == env43603) = true)

theorem identity43603 : scanCanonicalize (H12AffineFastState.compose env43603 (packedSelected [2,3,5,7,10] rootPS)) = affineNative (2^(10+1) ^^^ 146) := by decide +kernel

theorem selectedBound43603 : packedSelected [2,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env43604 : List Nat := [2,4,8,16,27,12,128,4,29,24,146,17,24,12,13,21,13,149,24,12,17,149,12,20,145,16,17,17,12,149,21,17,5,1,17,29]

theorem envBound43604 : H12AffineFastState.Bounded env43604 := by
  intro p hp
  have h : env43604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43603_43604 : H12AffineEnvironment.transform 10 146 env43603 = env43604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 146 env43603 == env43604) = true)

theorem identity43604 : scanCanonicalize (H12AffineFastState.compose env43604 (packedSelected [2,3,4,7] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound43604 : packedSelected [2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env43605 : List Nat := [2,4,5,16,22,1,128,4,16,21,146,17,21,1,0,21,0,149,21,1,17,149,1,20,145,16,17,17,1,149,21,17,5,1,17,16]

theorem envBound43605 : H12AffineFastState.Bounded env43605 := by
  intro p hp
  have h : env43605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43604_43605 : H12AffineEnvironment.transform 2 5 env43604 = env43605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env43604 == env43605) = true)

theorem identity43605 : scanCanonicalize (H12AffineFastState.compose env43605 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound43605 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43606 : List Nat := [2,2,3,16,16,1,128,2,16,19,146,17,19,1,0,19,0,147,19,1,17,147,1,18,145,16,17,17,1,147,19,17,3,1,17,16]

theorem envBound43606 : H12AffineFastState.Bounded env43606 := by
  intro p hp
  have h : env43606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43605_43606 : H12AffineEnvironment.transform 1 2 env43605 = env43606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env43605 == env43606) = true)

theorem identity43606 : scanCanonicalize (H12AffineFastState.compose env43606 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound43606 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43607 : List Nat := [2,2,3,16,16,1,19,2,16,19,1,17,19,1,0,19,0,0,19,1,17,0,1,18,2,16,17,17,1,0,19,17,3,1,17,16]

theorem envBound43607 : H12AffineFastState.Bounded env43607 := by
  intro p hp
  have h : env43607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43606_43607 : H12AffineEnvironment.transform 6 19 env43606 = env43607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env43606 == env43607) = true)

theorem identity43607 : scanCanonicalize (H12AffineFastState.compose env43607 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound43607 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43608 : List Nat := [2,2,3,0,0,1,3,2,0,3,1,1,3,1,0,3,0,0,3,1,1,0,1,2,2,0,1,1,1,0,3,1,3,1,1,0]

theorem envBound43608 : H12AffineFastState.Bounded env43608 := by
  intro p hp
  have h : env43608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43607_43608 : H12AffineEnvironment.transform 3 0 env43607 = env43608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env43607 == env43608) = true)

def env43609 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,837,845,65,528,65536,66163,65664,516,529,837,648,66163,65536,145,65910,303,66083,65,67602,832,836,257,66099,16,341]

theorem envBound43609 : H12AffineFastState.Bounded env43609 := by
  intro p hp
  have h : env43609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43587_43609 : H12AffineEnvironment.transform 9 337 env43587 = env43609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 337 env43587 == env43609) = true)

theorem identity43609 : scanCanonicalize (H12AffineFastState.compose env43609 (packedSelected [1,8,28] rootPS)) = affineNative (2^(8+1) ^^^ 344) := by decide +kernel

theorem selectedBound43609 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env43610 : List Nat := [2,4,8,16,32,64,128,256,344,337,2048,29,21,65,328,65536,65835,65664,348,329,29,464,65835,65536,145,65910,303,65915,65,67602,24,28,257,65899,16,341]

theorem envBound43610 : H12AffineFastState.Bounded env43610 := by
  intro p hp
  have h : env43610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43609_43610 : H12AffineEnvironment.transform 8 344 env43609 = env43610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 344 env43609 == env43610) = true)

def env43611 : List Nat := [2,4,4,16,32,64,128,256,340,337,2048,17,21,65,324,65536,65831,65664,336,325,17,464,65831,65536,145,65910,291,65911,65,67602,20,16,257,65895,16,341]

theorem envBound43611 : H12AffineFastState.Bounded env43611 := by
  intro p hp
  have h : env43611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43610_43611 : H12AffineEnvironment.transform 2 4 env43610 = env43611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env43610 == env43611) = true)

theorem identity43611 : scanCanonicalize (H12AffineFastState.compose env43611 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 99) := by decide +kernel

theorem selectedBound43611 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env43612 : List Nat := [2,4,4,16,32,64,128,256,340,337,2048,17,21,65,324,99,324,227,336,325,17,464,324,99,145,277,291,276,65,2161,20,16,257,260,16,341]

theorem envBound43612 : H12AffineFastState.Bounded env43612 := by
  intro p hp
  have h : env43612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43611_43612 : H12AffineEnvironment.transform 15 99 env43611 = env43612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 99 env43611 == env43612) = true)

theorem identity43612 : scanCanonicalize (H12AffineFastState.compose env43612 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound43612 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env43613 : List Nat := [2,4,4,16,32,64,128,68,16,21,2048,17,21,65,0,99,0,227,20,1,17,148,0,99,145,81,103,80,65,2161,20,16,69,64,16,17]

theorem envBound43613 : H12AffineFastState.Bounded env43613 := by
  intro p hp
  have h : env43613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43612_43613 : H12AffineEnvironment.transform 7 68 env43612 = env43613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env43612 == env43613) = true)

theorem identity43613 : scanCanonicalize (H12AffineFastState.compose env43613 (packedSelected [3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound43613 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env43614 : List Nat := [2,4,4,0,32,64,128,68,0,5,2048,1,5,65,0,99,0,227,4,1,1,132,0,99,129,65,103,64,65,2145,4,0,69,64,0,1]

theorem envBound43614 : H12AffineFastState.Bounded env43614 := by
  intro p hp
  have h : env43614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43613_43614 : H12AffineEnvironment.transform 3 0 env43613 = env43614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env43613 == env43614) = true)

theorem identity43614 : scanCanonicalize (H12AffineFastState.compose env43614 (packedSelected [2,8] rootPS)) = affineNative (2^(10+1) ^^^ 65) := by decide +kernel

theorem selectedBound43614 : packedSelected [2,8] rootPS < 2^1333 := by decide +kernel

def env43615 : List Nat := [2,4,4,0,32,64,128,68,0,5,65,1,5,65,0,99,0,227,4,1,1,132,0,99,129,65,103,64,65,32,4,0,69,64,0,1]

theorem envBound43615 : H12AffineFastState.Bounded env43615 := by
  intro p hp
  have h : env43615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43614_43615 : H12AffineEnvironment.transform 10 65 env43614 = env43615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 65 env43614 == env43615) = true)

theorem identity43615 : scanCanonicalize (H12AffineFastState.compose env43615 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 67) := by decide +kernel

theorem selectedBound43615 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env43616 : List Nat := [2,4,4,0,32,64,67,68,0,5,65,1,5,65,0,99,0,32,4,1,1,71,0,99,66,65,103,64,65,32,4,0,69,64,0,1]

theorem envBound43616 : H12AffineFastState.Bounded env43616 := by
  intro p hp
  have h : env43616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43615_43616 : H12AffineEnvironment.transform 6 67 env43615 = env43616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 67 env43615 == env43616) = true)

theorem identity43616 : scanCanonicalize (H12AffineFastState.compose env43616 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound43616 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43617 : List Nat := [2,4,4,0,0,64,67,68,0,5,65,1,5,65,0,67,0,0,4,1,1,71,0,67,66,65,71,64,65,0,4,0,69,64,0,1]

theorem envBound43617 : H12AffineFastState.Bounded env43617 := by
  intro p hp
  have h : env43617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43616_43617 : H12AffineEnvironment.transform 4 0 env43616 = env43617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env43616 == env43617) = true)

theorem identity43617 : scanCanonicalize (H12AffineFastState.compose env43617 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 2) := by decide +kernel

theorem selectedBound43617 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43618 : List Nat := [2,4,4,0,0,2,1,6,0,5,3,1,5,3,0,1,0,0,4,1,1,5,0,1,0,3,5,2,3,0,4,0,7,2,0,1]

theorem envBound43618 : H12AffineFastState.Bounded env43618 := by
  intro p hp
  have h : env43618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43617_43618 : H12AffineEnvironment.transform 5 2 env43617 = env43618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 2 env43617 == env43618) = true)

theorem identity43618 : scanCanonicalize (H12AffineFastState.compose env43618 (packedSelected [2,4] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound43618 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env43619 : List Nat := [2,0,0,0,0,2,1,2,0,1,3,1,1,3,0,1,0,0,0,1,1,1,0,1,0,3,1,2,3,0,0,0,3,2,0,1]

theorem envBound43619 : H12AffineFastState.Bounded env43619 := by
  intro p hp
  have h : env43619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43618_43619 : H12AffineEnvironment.transform 1 0 env43618 = env43619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env43618 == env43619) = true)

theorem identity43619 : scanCanonicalize (H12AffineFastState.compose env43619 (packedSelected [2] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound43619 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43620 : List Nat := [1,0,0,0,0,1,1,1,0,1,0,1,1,0,0,1,0,0,0,1,1,1,0,1,0,0,1,1,0,0,0,0,0,1,0,1]

theorem envBound43620 : H12AffineFastState.Bounded env43620 := by
  intro p hp
  have h : env43620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43619_43620 : H12AffineEnvironment.transform 0 1 env43619 = env43620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env43619 == env43620) = true)

def env43621 : List Nat := [2,4,5,16,32,64,128,256,341,337,2048,16,21,65,325,65536,65830,65664,337,324,16,464,65830,65536,145,65910,290,65910,65,67602,21,17,257,65894,16,341]

theorem envBound43621 : H12AffineFastState.Bounded env43621 := by
  intro p hp
  have h : env43621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43610_43621 : H12AffineEnvironment.transform 2 5 env43610 = env43621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env43610 == env43621) = true)

theorem identity43621 : scanCanonicalize (H12AffineFastState.compose env43621 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound43621 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env43622 : List Nat := [2,4,5,16,32,64,128,5,80,84,2048,16,21,65,64,65536,65571,65664,84,65,16,213,65571,65536,145,65651,39,65651,65,67602,21,17,4,65635,16,80]

theorem envBound43622 : H12AffineFastState.Bounded env43622 := by
  intro p hp
  have h : env43622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43621_43622 : H12AffineEnvironment.transform 7 5 env43621 = env43622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env43621 == env43622) = true)

theorem identity43622 : scanCanonicalize (H12AffineFastState.compose env43622 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 99) := by decide +kernel

theorem selectedBound43622 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env43623 : List Nat := [2,4,5,16,32,64,128,5,80,84,2048,16,21,65,64,99,64,227,84,65,16,213,64,99,145,16,39,16,65,2161,21,17,4,0,16,80]

theorem envBound43623 : H12AffineFastState.Bounded env43623 := by
  intro p hp
  have h : env43623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43622_43623 : H12AffineEnvironment.transform 15 99 env43622 = env43623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 99 env43622 == env43623) = true)

theorem identity43623 : scanCanonicalize (H12AffineFastState.compose env43623 (packedSelected [1,2,3,13] rootPS)) = affineNative (2^(5+1) ^^^ 38) := by decide +kernel

theorem selectedBound43623 : packedSelected [1,2,3,13] rootPS < 2^1333 := by decide +kernel

def env43624 : List Nat := [2,4,5,16,32,38,128,5,54,50,2048,16,21,39,38,5,38,133,50,39,16,179,38,5,145,16,39,16,39,2071,21,17,4,0,16,54]

theorem envBound43624 : H12AffineFastState.Bounded env43624 := by
  intro p hp
  have h : env43624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43623_43624 : H12AffineEnvironment.transform 5 38 env43623 = env43624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 38 env43623 == env43624) = true)

theorem identity43624 : scanCanonicalize (H12AffineFastState.compose env43624 (packedSelected [3,5,7,10] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound43624 : packedSelected [3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env43625 : List Nat := [2,4,5,16,32,38,4,5,54,50,2048,16,21,39,38,5,38,1,50,39,16,55,38,5,21,16,39,16,39,2071,21,17,4,0,16,54]

theorem envBound43625 : H12AffineFastState.Bounded env43625 := by
  intro p hp
  have h : env43625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43624_43625 : H12AffineEnvironment.transform 6 4 env43624 = env43625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env43624 == env43625) = true)

theorem identity43625 : scanCanonicalize (H12AffineFastState.compose env43625 (packedSelected [1,2,3,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound43625 : packedSelected [1,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env43626 : List Nat := [2,4,5,16,16,22,4,5,6,2,2048,16,21,23,22,5,22,1,2,23,16,7,22,5,21,16,23,16,23,2071,21,17,4,0,16,6]

theorem envBound43626 : H12AffineFastState.Bounded env43626 := by
  intro p hp
  have h : env43626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43625_43626 : H12AffineEnvironment.transform 4 16 env43625 = env43626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env43625 == env43626) = true)

theorem identity43626 : scanCanonicalize (H12AffineFastState.compose env43626 (packedSelected [0,1,2] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound43626 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env43627 : List Nat := [2,4,5,16,16,22,4,5,6,2,1,16,21,23,22,5,22,1,2,23,16,7,22,5,21,16,23,16,23,22,21,17,4,0,16,6]

theorem envBound43627 : H12AffineFastState.Bounded env43627 := by
  intro p hp
  have h : env43627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43626_43627 : H12AffineEnvironment.transform 10 1 env43626 = env43627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env43626 == env43627) = true)

theorem identity43627 : scanCanonicalize (H12AffineFastState.compose env43627 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound43627 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env43628 : List Nat := [2,4,5,7,7,1,4,5,6,2,1,7,2,0,1,5,1,1,2,0,7,7,1,5,2,7,0,7,0,1,2,6,4,0,7,6]

theorem envBound43628 : H12AffineFastState.Bounded env43628 := by
  intro p hp
  have h : env43628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43627_43628 : H12AffineEnvironment.transform 3 7 env43627 = env43628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env43627 == env43628) = true)

def env43629 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1557,844,1296,529,65536,67363,65664,1876,528,1557,649,66162,66897,145,65910,1150,67443,1296,67602,833,837,257,67427,1345,340]

theorem envBound43629 : H12AffineFastState.Bounded env43629 := by
  intro p hp
  have h : env43629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43586_43629 : H12AffineEnvironment.transform 11 1557 env43586 = env43629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1557 env43586 == env43629) = true)

def env43630 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,837,844,64,529,65536,66163,65664,516,528,837,649,66162,65537,145,65910,302,66083,64,67602,833,837,257,66099,17,340]

theorem envBound43630 : H12AffineFastState.Bounded env43630 := by
  intro p hp
  have h : env43630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43629_43630 : H12AffineEnvironment.transform 9 336 env43629 = env43630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 336 env43629 == env43630) = true)

theorem identity43630 : scanCanonicalize (H12AffineFastState.compose env43630 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 559) := by decide +kernel

theorem selectedBound43630 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env43631 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,837,844,64,529,559,92,687,516,528,837,649,93,558,145,857,302,12,64,2621,833,837,257,28,17,340]

theorem envBound43631 : H12AffineFastState.Bounded env43631 := by
  intro p hp
  have h : env43631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43630_43631 : H12AffineEnvironment.transform 15 559 env43630 = env43631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 559 env43630 == env43631) = true)

def env43632 : List Nat := [2,4,8,16,32,64,128,256,328,336,2048,13,4,64,345,359,92,487,332,344,13,449,93,358,145,17,302,12,64,2421,9,13,257,28,17,340]

theorem envBound43632 : H12AffineFastState.Bounded env43632 := by
  intro p hp
  have h : env43632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43631_43632 : H12AffineEnvironment.transform 8 328 env43631 = env43632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 328 env43631 == env43632) = true)

theorem identity43632 : scanCanonicalize (H12AffineFastState.compose env43632 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 24) := by decide +kernel

theorem selectedBound43632 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env43633 : List Nat := [2,4,8,16,32,64,128,24,80,72,2048,13,4,64,65,127,92,255,84,64,13,217,93,126,145,17,54,12,64,2157,9,13,25,28,17,76]

theorem envBound43633 : H12AffineFastState.Bounded env43633 := by
  intro p hp
  have h : env43633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43632_43633 : H12AffineEnvironment.transform 7 24 env43632 = env43633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 24 env43632 == env43633) = true)

theorem identity43633 : scanCanonicalize (H12AffineFastState.compose env43633 (packedSelected [0,1,2,3,5,7,8,10,12,15,17,18,21] rootPS)) = affineNative (2^(4+1) ^^^ 22) := by decide +kernel

theorem selectedBound43633 : packedSelected [0,1,2,3,5,7,8,10,12,15,17,18,21] rootPS < 2^1333 := by decide +kernel

def env43634 : List Nat := [2,4,8,16,22,64,128,24,80,72,2048,13,4,64,65,73,92,201,84,64,13,217,93,72,145,17,0,12,64,2139,9,13,25,28,17,76]

theorem envBound43634 : H12AffineFastState.Bounded env43634 := by
  intro p hp
  have h : env43634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43633_43634 : H12AffineEnvironment.transform 4 22 env43633 = env43634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 22 env43633 == env43634) = true)

theorem identity43634 : scanCanonicalize (H12AffineFastState.compose env43634 (packedSelected [1,2,8,10,11,13,15,18,19] rootPS)) = affineNative (2^(10+1) ^^^ 71) := by decide +kernel

theorem selectedBound43634 : packedSelected [1,2,8,10,11,13,15,18,19] rootPS < 2^1333 := by decide +kernel

def env43635 : List Nat := [2,4,8,16,22,64,128,24,80,72,71,13,4,64,65,73,92,201,84,64,13,217,93,72,145,17,0,12,64,28,9,13,25,28,17,76]

theorem envBound43635 : H12AffineFastState.Bounded env43635 := by
  intro p hp
  have h : env43635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43634_43635 : H12AffineEnvironment.transform 10 71 env43634 = env43635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 71 env43634 == env43635) = true)

theorem identity43635 : scanCanonicalize (H12AffineFastState.compose env43635 (packedSelected [1,2,3,4,5,7,8,11] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound43635 : packedSelected [1,2,3,4,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env43636 : List Nat := [2,4,8,6,0,64,128,14,70,72,71,13,4,64,65,73,74,201,66,64,13,207,75,72,135,7,0,12,64,10,9,13,15,10,7,76]

theorem envBound43636 : H12AffineFastState.Bounded env43636 := by
  intro p hp
  have h : env43636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43635_43636 : H12AffineEnvironment.transform 3 6 env43635 = env43636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env43635 == env43636) = true)

def env43637 : List Nat := [2,4,8,16,32,64,128,256,329,336,2048,12,5,64,344,358,92,486,333,345,12,448,93,359,145,16,302,12,64,2420,8,12,257,28,17,340]

theorem envBound43637 : H12AffineFastState.Bounded env43637 := by
  intro p hp
  have h : env43637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43631_43637 : H12AffineEnvironment.transform 8 329 env43631 = env43637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 329 env43631 == env43637) = true)

theorem identity43637 : scanCanonicalize (H12AffineFastState.compose env43637 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound43637 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env43638 : List Nat := [2,4,8,16,32,64,128,4,77,84,2048,12,5,64,92,98,92,226,73,93,12,196,93,99,145,16,42,12,64,2160,8,12,5,28,17,80]

theorem envBound43638 : H12AffineFastState.Bounded env43638 := by
  intro p hp
  have h : env43638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43637_43638 : H12AffineEnvironment.transform 7 4 env43637 = env43638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env43637 == env43638) = true)

theorem identity43638 : scanCanonicalize (H12AffineFastState.compose env43638 (packedSelected [3,4,5,8,9,10,13,17,23] rootPS)) = affineNative (2^(10+1) ^^^ 132) := by decide +kernel

theorem selectedBound43638 : packedSelected [3,4,5,8,9,10,13,17,23] rootPS < 2^1333 := by decide +kernel

def env43639 : List Nat := [2,4,8,16,32,64,128,4,77,84,132,12,5,64,92,98,92,226,73,93,12,196,93,99,145,16,42,12,64,244,8,12,5,28,17,80]

theorem envBound43639 : H12AffineFastState.Bounded env43639 := by
  intro p hp
  have h : env43639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43638_43639 : H12AffineEnvironment.transform 10 132 env43638 = env43639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 132 env43638 == env43639) = true)

theorem identity43639 : scanCanonicalize (H12AffineFastState.compose env43639 (packedSelected [3,10,12,13,17,19] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound43639 : packedSelected [3,10,12,13,17,19] rootPS < 2^1333 := by decide +kernel

def env43640 : List Nat := [2,4,8,16,17,64,128,4,77,84,132,12,5,64,92,83,92,211,73,93,12,196,93,82,145,16,27,12,64,197,8,12,5,28,17,80]

theorem envBound43640 : H12AffineFastState.Bounded env43640 := by
  intro p hp
  have h : env43640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43639_43640 : H12AffineEnvironment.transform 4 17 env43639 = env43640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env43639 == env43640) = true)

theorem identity43640 : scanCanonicalize (H12AffineFastState.compose env43640 (packedSelected [2,4,5,7,10,12] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound43640 : packedSelected [2,4,5,7,10,12] rootPS < 2^1333 := by decide +kernel

def env43641 : List Nat := [2,4,8,7,6,64,128,4,77,67,132,12,5,64,75,68,75,196,73,74,12,196,74,69,134,7,12,12,64,197,8,12,5,11,6,71]

theorem envBound43641 : H12AffineFastState.Bounded env43641 := by
  intro p hp
  have h : env43641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43640_43641 : H12AffineEnvironment.transform 3 7 env43640 = env43641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env43640 == env43641) = true)

theorem identity43641 : scanCanonicalize (H12AffineFastState.compose env43641 (packedSelected [1,3,4,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 12) := by decide +kernel

theorem selectedBound43641 : packedSelected [1,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env43642 : List Nat := [2,4,8,7,6,12,128,4,1,15,132,12,5,12,7,8,7,136,5,6,12,136,6,9,134,7,12,12,12,137,8,12,5,11,6,11]

theorem envBound43642 : H12AffineFastState.Bounded env43642 := by
  intro p hp
  have h : env43642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43641_43642 : H12AffineEnvironment.transform 5 12 env43641 = env43642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 12 env43641 == env43642) = true)

theorem identity43642 : scanCanonicalize (H12AffineFastState.compose env43642 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound43642 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env43643 : List Nat := [2,3,8,0,1,11,128,3,1,8,131,11,2,11,0,8,0,136,2,1,11,136,1,9,129,0,11,11,11,137,8,11,2,11,1,11]

theorem envBound43643 : H12AffineFastState.Bounded env43643 := by
  intro p hp
  have h : env43643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43642_43643 : H12AffineEnvironment.transform 1 3 env43642 = env43643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env43642 == env43643) = true)

theorem identity43643 : scanCanonicalize (H12AffineFastState.compose env43643 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound43643 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43644 : List Nat := [2,3,8,0,1,11,8,3,1,8,11,11,2,11,0,8,0,0,2,1,11,0,1,9,9,0,11,11,11,1,8,11,2,11,1,11]

theorem envBound43644 : H12AffineFastState.Bounded env43644 := by
  intro p hp
  have h : env43644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43643_43644 : H12AffineEnvironment.transform 6 8 env43643 = env43644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env43643 == env43644) = true)

def env43645 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,836,844,65,529,65536,66162,65664,517,528,836,649,66162,65536,145,65910,303,66082,65,67602,833,837,257,66098,16,340]

theorem envBound43645 : H12AffineFastState.Bounded env43645 := by
  intro p hp
  have h : env43645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43629_43645 : H12AffineEnvironment.transform 9 337 env43629 = env43645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 337 env43629 == env43645) = true)

theorem identity43645 : scanCanonicalize (H12AffineFastState.compose env43645 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 314) := by decide +kernel

theorem selectedBound43645 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env43646 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,836,844,65,529,314,840,442,517,528,836,649,840,314,145,76,303,792,65,2344,833,837,257,776,16,340]

theorem envBound43646 : H12AffineFastState.Bounded env43646 := by
  intro p hp
  have h : env43646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43645_43646 : H12AffineEnvironment.transform 15 314 env43645 = env43646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 314 env43645 == env43646) = true)

def env43647 : List Nat := [2,4,8,16,32,64,128,256,276,337,2048,80,88,65,261,314,92,442,273,260,80,413,92,314,145,76,303,12,65,2344,85,81,257,28,16,340]

theorem envBound43647 : H12AffineFastState.Bounded env43647 := by
  intro p hp
  have h : env43647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43646_43647 : H12AffineEnvironment.transform 8 276 env43646 = env43647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env43646 == env43647) = true)

theorem identity43647 : scanCanonicalize (H12AffineFastState.compose env43647 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound43647 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env43648 : List Nat := [2,4,8,16,32,64,128,5,17,84,2048,80,88,65,0,63,92,191,20,1,80,152,92,63,145,76,42,12,65,2093,85,81,4,28,16,81]

theorem envBound43648 : H12AffineFastState.Bounded env43648 := by
  intro p hp
  have h : env43648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43647_43648 : H12AffineEnvironment.transform 7 5 env43647 = env43648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env43647 == env43648) = true)

theorem identity43648 : scanCanonicalize (H12AffineFastState.compose env43648 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 28) := by decide +kernel

theorem selectedBound43648 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env43649 : List Nat := [2,4,8,16,32,28,128,5,17,8,2048,12,4,29,0,63,0,191,20,1,12,152,0,63,145,16,42,12,29,2093,9,13,4,28,16,13]

theorem envBound43649 : H12AffineFastState.Bounded env43649 := by
  intro p hp
  have h : env43649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43648_43649 : H12AffineEnvironment.transform 5 28 env43648 = env43649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 28 env43648 == env43649) = true)

theorem identity43649 : scanCanonicalize (H12AffineFastState.compose env43649 (packedSelected [1,2,3,12,13] rootPS)) = affineNative (2^(10+1) ^^^ 181) := by decide +kernel

theorem selectedBound43649 : packedSelected [1,2,3,12,13] rootPS < 2^1333 := by decide +kernel

def env43650 : List Nat := [2,4,8,16,32,28,128,5,17,8,181,12,4,29,0,63,0,191,20,1,12,152,0,63,145,16,42,12,29,152,9,13,4,28,16,13]

theorem envBound43650 : H12AffineFastState.Bounded env43650 := by
  intro p hp
  have h : env43650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43649_43650 : H12AffineEnvironment.transform 10 181 env43649 = env43650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 181 env43649 == env43650) = true)

theorem identity43650 : scanCanonicalize (H12AffineFastState.compose env43650 (packedSelected [1,2,3,8] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound43650 : packedSelected [1,2,3,8] rootPS < 2^1333 := by decide +kernel

def env43651 : List Nat := [2,4,8,16,13,28,128,5,17,8,152,12,4,29,0,18,0,146,20,1,12,152,0,18,145,16,7,12,29,152,9,13,4,28,16,13]

theorem envBound43651 : H12AffineFastState.Bounded env43651 := by
  intro p hp
  have h : env43651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43650_43651 : H12AffineEnvironment.transform 4 13 env43650 = env43651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env43650 == env43651) = true)

def env43652 : List Nat := [2,4,8,16,32,64,128,256,277,337,2048,81,89,65,260,314,93,442,272,261,81,412,93,314,145,76,303,13,65,2344,84,80,257,29,16,340]

theorem envBound43652 : H12AffineFastState.Bounded env43652 := by
  intro p hp
  have h : env43652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43646_43652 : H12AffineEnvironment.transform 8 277 env43646 = env43652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env43646 == env43652) = true)

theorem identity43652 : scanCanonicalize (H12AffineFastState.compose env43652 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound43652 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env43653 : List Nat := [2,4,8,16,32,64,128,68,81,21,2048,81,89,65,64,126,93,254,84,65,81,216,93,126,145,76,107,13,65,2156,84,80,69,29,16,16]

theorem envBound43653 : H12AffineFastState.Bounded env43653 := by
  intro p hp
  have h : env43653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43652_43653 : H12AffineEnvironment.transform 7 68 env43652 = env43653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env43652 == env43653) = true)

theorem identity43653 : scanCanonicalize (H12AffineFastState.compose env43653 (packedSelected [0,5,7,10,11,15,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 185) := by decide +kernel

theorem selectedBound43653 : packedSelected [0,5,7,10,11,15,18,20] rootPS < 2^1333 := by decide +kernel

def env43654 : List Nat := [2,4,8,16,32,64,128,68,81,21,185,81,89,65,64,126,93,254,84,65,81,216,93,126,145,76,107,13,65,213,84,80,69,29,16,16]

theorem envBound43654 : H12AffineFastState.Bounded env43654 := by
  intro p hp
  have h : env43654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43653_43654 : H12AffineEnvironment.transform 10 185 env43653 = env43654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 185 env43653 == env43654) = true)

theorem identity43654 : scanCanonicalize (H12AffineFastState.compose env43654 (packedSelected [0,4,5,7,9,10,12,13,16,18] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound43654 : packedSelected [0,4,5,7,9,10,12,13,16,18] rootPS < 2^1333 := by decide +kernel

def env43655 : List Nat := [2,4,8,16,32,64,2,68,81,21,59,81,89,65,64,126,93,124,84,65,81,90,93,126,19,76,107,13,65,87,84,80,69,29,16,16]

theorem envBound43655 : H12AffineFastState.Bounded env43655 := by
  intro p hp
  have h : env43655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43654_43655 : H12AffineEnvironment.transform 6 2 env43654 = env43655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env43654 == env43655) = true)

theorem identity43655 : scanCanonicalize (H12AffineFastState.compose env43655 (packedSelected [0,3,5,7,8,10,12] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound43655 : packedSelected [0,3,5,7,8,10,12] rootPS < 2^1333 := by decide +kernel

def env43656 : List Nat := [2,4,8,16,32,49,2,53,32,21,59,32,40,48,49,15,44,13,37,48,32,43,44,15,19,61,26,13,48,38,37,33,52,29,16,16]

theorem envBound43656 : H12AffineFastState.Bounded env43656 := by
  intro p hp
  have h : env43656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43655_43656 : H12AffineEnvironment.transform 5 49 env43655 = env43656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env43655 == env43656) = true)

theorem identity43656 : scanCanonicalize (H12AffineFastState.compose env43656 (packedSelected [0,3,9] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound43656 : packedSelected [0,3,9] rootPS < 2^1333 := by decide +kernel

def env43657 : List Nat := [2,4,8,10,32,43,2,47,32,15,33,32,40,42,43,15,44,13,37,42,32,43,44,15,9,39,0,13,42,38,37,33,46,7,10,10]

theorem envBound43657 : H12AffineFastState.Bounded env43657 := by
  intro p hp
  have h : env43657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43656_43657 : H12AffineEnvironment.transform 3 10 env43656 = env43657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env43656 == env43657) = true)

def env43658 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74863,65665,4417,8540,4096,5276,74046,66897,13768,78895,1151,74815,1296,81227,8205,8201,257,74799,1345,5953]

theorem envBound43658 : H12AffineFastState.Bounded env43658 := by
  intro p hp
  have h : env43658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43584_43658 : H12AffineEnvironment.transform 17 65665 env43584 = env43658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env43584 == env43658) = true)

theorem identity43658 : scanCanonicalize (H12AffineFastState.compose env43658 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound43658 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env43659 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,25,1296,324,65536,66678,65665,4417,325,4096,5276,65831,66897,5585,70710,1151,66598,1296,73042,20,16,257,66614,1345,5953]

theorem envBound43659 : H12AffineFastState.Bounded env43659 := by
  intro p hp
  have h : env43659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43658_43659 : H12AffineEnvironment.transform 12 25 env43658 = env43659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env43658 == env43659) = true)

def env43660 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1556,25,1296,324,65536,66678,65665,1877,325,1556,648,65831,66897,965,66082,1151,66598,1296,68422,20,16,257,66614,1345,341]

theorem envBound43660 : H12AffineFastState.Bounded env43660 := by
  intro p hp
  have h : env43660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43659_43660 : H12AffineEnvironment.transform 11 1556 env43659 = env43660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1556 env43659 == env43660) = true)

def env43661 : List Nat := [2,4,8,16,32,0,128,256,512,1024,2048,1556,25,1296,260,65536,66614,65665,1813,261,1556,648,65831,66833,901,66082,1087,66598,1296,68358,20,16,257,66614,1281,277]

theorem envBound43661 : H12AffineFastState.Bounded env43661 := by
  intro p hp
  have h : env43661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43660_43661 : H12AffineEnvironment.transform 5 0 env43660 = env43661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env43660 == env43661) = true)

theorem identity43661 : scanCanonicalize (H12AffineFastState.compose env43661 (packedSelected [1,8,28] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound43661 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env43662 : List Nat := [2,4,5,16,32,0,128,256,512,1024,2048,1556,20,1296,260,65536,66614,65665,1813,261,1556,645,65831,66833,901,66082,1074,66598,1296,68358,20,16,257,66614,1281,277]

theorem envBound43662 : H12AffineFastState.Bounded env43662 := by
  intro p hp
  have h : env43662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43661_43662 : H12AffineEnvironment.transform 2 5 env43661 = env43662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env43661 == env43662) = true)

def env43663 : List Nat := [2,4,5,0,32,0,128,256,512,1024,2048,1540,4,1280,260,65536,66598,65665,1797,261,1540,645,65831,66817,901,66082,1058,66598,1280,68358,4,0,257,66598,1281,261]

theorem envBound43663 : H12AffineFastState.Bounded env43663 := by
  intro p hp
  have h : env43663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43662_43663 : H12AffineEnvironment.transform 3 0 env43662 = env43663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env43662 == env43663) = true)

theorem identity43663 : scanCanonicalize (H12AffineFastState.compose env43663 (packedSelected [7,20,27] rootPS)) = affineNative (2^(9+1) ^^^ 769) := by decide +kernel

theorem selectedBound43663 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env43664 : List Nat := [2,4,5,0,32,0,128,256,512,769,2048,261,4,513,260,65536,66343,65665,4,261,261,645,65831,66048,901,66082,803,66343,513,68358,4,0,257,66343,512,261]

theorem envBound43664 : H12AffineFastState.Bounded env43664 := by
  intro p hp
  have h : env43664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43663_43664 : H12AffineEnvironment.transform 9 769 env43663 = env43664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 769 env43663 == env43664) = true)

theorem identity43664 : scanCanonicalize (H12AffineFastState.compose env43664 (packedSelected [0,1,4,7,8,9,16,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 295) := by decide +kernel

theorem selectedBound43664 : packedSelected [0,1,4,7,8,9,16,19,20] rootPS < 2^1333 := by decide +kernel

def env43665 : List Nat := [2,4,5,0,32,0,128,256,512,769,2048,261,4,513,260,295,512,422,4,261,261,645,0,807,901,773,803,512,513,2593,4,0,257,512,512,261]

theorem envBound43665 : H12AffineFastState.Bounded env43665 := by
  intro p hp
  have h : env43665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43664_43665 : H12AffineEnvironment.transform 15 295 env43664 = env43665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 295 env43664 == env43665) = true)

theorem identity43665 : scanCanonicalize (H12AffineFastState.compose env43665 (packedSelected [1,2,5,8,12,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 130) := by decide +kernel

theorem selectedBound43665 : packedSelected [1,2,5,8,12,13,15] rootPS < 2^1333 := by decide +kernel

def env43666 : List Nat := [2,4,5,0,32,0,128,256,512,769,130,261,4,513,260,295,512,422,4,261,261,645,0,807,901,773,803,512,513,675,4,0,257,512,512,261]

theorem envBound43666 : H12AffineFastState.Bounded env43666 := by
  intro p hp
  have h : env43666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43665_43666 : H12AffineEnvironment.transform 10 130 env43665 = env43666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 130 env43665 == env43666) = true)

theorem identity43666 : scanCanonicalize (H12AffineFastState.compose env43666 (packedSelected [0,1,2,3,4,5,7,8,9] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound43666 : packedSelected [0,1,2,3,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env43667 : List Nat := [2,4,5,0,6,0,128,256,512,769,130,261,4,513,260,257,512,384,4,261,261,645,0,769,901,773,773,512,513,645,4,0,257,512,512,261]

theorem envBound43667 : H12AffineFastState.Bounded env43667 := by
  intro p hp
  have h : env43667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43666_43667 : H12AffineEnvironment.transform 4 6 env43666 = env43667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env43666 == env43667) = true)

theorem identity43667 : scanCanonicalize (H12AffineFastState.compose env43667 (packedSelected [4,7] rootPS)) = affineNative (2^(8+1) ^^^ 258) := by decide +kernel

theorem selectedBound43667 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env43668 : List Nat := [2,4,5,0,6,0,128,256,258,3,130,261,4,259,260,257,258,384,4,261,261,391,0,3,135,7,7,258,259,391,4,0,257,258,258,261]

theorem envBound43668 : H12AffineFastState.Bounded env43668 := by
  intro p hp
  have h : env43668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43667_43668 : H12AffineEnvironment.transform 8 258 env43667 = env43668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 258 env43667 == env43668) = true)

theorem identity43668 : scanCanonicalize (H12AffineFastState.compose env43668 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 2) := by decide +kernel

theorem selectedBound43668 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43669 : List Nat := [2,4,5,0,6,0,128,2,0,3,130,7,4,1,6,3,0,130,4,7,7,133,0,3,135,7,7,0,1,133,4,0,3,0,0,7]

theorem envBound43669 : H12AffineFastState.Bounded env43669 := by
  intro p hp
  have h : env43669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43668_43669 : H12AffineEnvironment.transform 7 2 env43668 = env43669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 2 env43668 == env43669) = true)

theorem identity43669 : scanCanonicalize (H12AffineFastState.compose env43669 (packedSelected [2,3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound43669 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env43670 : List Nat := [2,2,3,0,0,0,128,2,0,3,130,1,2,1,0,3,0,130,2,1,1,131,0,3,129,1,1,0,1,131,2,0,3,0,0,1]

theorem envBound43670 : H12AffineFastState.Bounded env43670 := by
  intro p hp
  have h : env43670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43669_43670 : H12AffineEnvironment.transform 1 2 env43669 = env43670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env43669 == env43670) = true)

theorem identity43670 : scanCanonicalize (H12AffineFastState.compose env43670 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 0) := by decide +kernel

theorem selectedBound43670 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43671 : List Nat := [2,2,3,0,0,0,0,2,0,3,2,1,2,1,0,3,0,2,2,1,1,3,0,3,1,1,1,0,1,3,2,0,3,0,0,1]

theorem envBound43671 : H12AffineFastState.Bounded env43671 := by
  intro p hp
  have h : env43671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43670_43671 : H12AffineEnvironment.transform 6 0 env43670 = env43671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 0 env43670 == env43671) = true)

theorem identity43671 : scanCanonicalize (H12AffineFastState.compose env43671 (packedSelected [2] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound43671 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43672 : List Nat := [1,1,0,0,0,0,0,1,0,0,1,1,1,1,0,0,0,1,1,1,1,0,0,0,1,1,1,0,1,0,1,0,0,0,0,1]

theorem envBound43672 : H12AffineFastState.Bounded env43672 := by
  intro p hp
  have h : env43672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43671_43672 : H12AffineEnvironment.transform 0 1 env43671 = env43672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env43671 == env43672) = true)

def env43673 : List Nat := [2,4,5,1,32,0,128,256,512,1024,2048,1541,5,1281,260,65536,66599,65665,1796,261,1541,645,65831,66816,901,66082,1059,66598,1281,68358,5,1,257,66599,1281,260]

theorem envBound43673 : H12AffineFastState.Bounded env43673 := by
  intro p hp
  have h : env43673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43662_43673 : H12AffineEnvironment.transform 3 1 env43662 = env43673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env43662 == env43673) = true)

theorem identity43673 : scanCanonicalize (H12AffineFastState.compose env43673 (packedSelected [7,20,27] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound43673 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env43674 : List Nat := [2,4,5,1,32,0,128,256,512,5,2048,512,5,260,260,65536,65570,65665,769,261,512,645,65831,65797,901,66082,38,65571,260,68358,5,1,257,65570,260,260]

theorem envBound43674 : H12AffineFastState.Bounded env43674 := by
  intro p hp
  have h : env43674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43673_43674 : H12AffineEnvironment.transform 9 5 env43673 = env43674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env43673 == env43674) = true)

theorem identity43674 : scanCanonicalize (H12AffineFastState.compose env43674 (packedSelected [0,2,3,4,5,7,8,9,11,13,16,17,19] rootPS)) = affineNative (2^(15+1) ^^^ 2177) := by decide +kernel

theorem selectedBound43674 : packedSelected [0,2,3,4,5,7,8,9,11,13,16,17,19] rootPS < 2^1333 := by decide +kernel

def env43675 : List Nat := [2,4,5,1,32,0,128,256,512,5,2048,512,5,260,260,2177,2211,2048,769,261,512,645,2470,2436,901,2723,38,2210,260,903,5,1,257,2211,260,260]

theorem envBound43675 : H12AffineFastState.Bounded env43675 := by
  intro p hp
  have h : env43675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43674_43675 : H12AffineEnvironment.transform 15 2177 env43674 = env43675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2177 env43674 == env43675) = true)

theorem identity43675 : scanCanonicalize (H12AffineFastState.compose env43675 (packedSelected [1,2,4,5,9,10,11,13,16,18] rootPS)) = affineNative (2^(10+1) ^^^ 39) := by decide +kernel

theorem selectedBound43675 : packedSelected [1,2,4,5,9,10,11,13,16,18] rootPS < 2^1333 := by decide +kernel

def env43676 : List Nat := [2,4,5,1,32,0,128,256,512,5,39,512,5,260,260,166,132,39,769,261,512,645,385,419,901,644,38,133,260,903,5,1,257,132,260,260]

theorem envBound43676 : H12AffineFastState.Bounded env43676 := by
  intro p hp
  have h : env43676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43675_43676 : H12AffineEnvironment.transform 10 39 env43675 = env43676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 39 env43675 == env43676) = true)

theorem identity43676 : scanCanonicalize (H12AffineFastState.compose env43676 (packedSelected [1,4,5,7,8] rootPS)) = affineNative (2^(8+1) ^^^ 416) := by decide +kernel

theorem selectedBound43676 : packedSelected [1,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env43677 : List Nat := [2,4,5,1,32,0,128,256,416,5,39,416,5,260,260,166,132,39,161,261,416,293,385,419,37,292,38,133,260,39,5,1,257,132,260,260]

theorem envBound43677 : H12AffineFastState.Bounded env43677 := by
  intro p hp
  have h : env43677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43676_43677 : H12AffineEnvironment.transform 8 416 env43676 = env43677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 416 env43676 == env43677) = true)

theorem identity43677 : scanCanonicalize (H12AffineFastState.compose env43677 (packedSelected [0,2,4] rootPS)) = affineNative (2^(7+1) ^^^ 128) := by decide +kernel

theorem selectedBound43677 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env43678 : List Nat := [2,4,5,1,32,0,128,128,32,5,39,32,5,132,132,166,132,39,161,133,32,165,1,35,37,164,38,133,132,39,5,1,129,132,132,132]

theorem envBound43678 : H12AffineFastState.Bounded env43678 := by
  intro p hp
  have h : env43678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43677_43678 : H12AffineEnvironment.transform 7 128 env43677 = env43678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 128 env43677 == env43678) = true)

theorem identity43678 : scanCanonicalize (H12AffineFastState.compose env43678 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 37) := by decide +kernel

theorem selectedBound43678 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env43679 : List Nat := [2,4,5,1,32,0,37,37,32,5,39,32,5,33,33,3,33,39,4,32,32,0,1,35,37,1,38,32,33,39,5,1,36,33,33,33]

theorem envBound43679 : H12AffineFastState.Bounded env43679 := by
  intro p hp
  have h : env43679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43678_43679 : H12AffineEnvironment.transform 6 37 env43678 = env43679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 37 env43678 == env43679) = true)

theorem identity43679 : scanCanonicalize (H12AffineFastState.compose env43679 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound43679 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43680 : List Nat := [1,4,5,1,32,0,37,37,32,5,36,32,5,33,33,0,33,36,4,32,32,0,1,32,37,1,37,32,33,36,5,1,36,33,33,33]

theorem envBound43680 : H12AffineFastState.Bounded env43680 := by
  intro p hp
  have h : env43680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43679_43680 : H12AffineEnvironment.transform 0 1 env43679 = env43680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env43679 == env43680) = true)

theorem identity43680 : scanCanonicalize (H12AffineFastState.compose env43680 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound43680 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43681 : List Nat := [1,1,0,1,32,0,32,32,32,0,33,32,0,33,33,0,33,33,1,32,32,0,1,32,32,1,32,32,33,33,0,1,33,33,33,33]

theorem envBound43681 : H12AffineFastState.Bounded env43681 := by
  intro p hp
  have h : env43681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43680_43681 : H12AffineEnvironment.transform 1 1 env43680 = env43681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env43680 == env43681) = true)

theorem identity43681 : scanCanonicalize (H12AffineFastState.compose env43681 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound43681 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43682 : List Nat := [1,1,0,1,0,0,0,0,0,0,1,0,0,1,1,0,1,1,1,0,0,0,1,0,0,1,0,0,1,1,0,1,1,1,1,1]

theorem envBound43682 : H12AffineFastState.Bounded env43682 := by
  intro p hp
  have h : env43682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43681_43682 : H12AffineEnvironment.transform 4 0 env43681 = env43682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env43681 == env43682) = true)

def env43683 : List Nat := [2,4,8,16,32,1,128,256,512,1024,2048,1556,25,1296,261,65536,66615,65665,1812,260,1556,648,65831,66832,900,66082,1086,66598,1296,68359,20,16,257,66614,1280,276]

theorem envBound43683 : H12AffineFastState.Bounded env43683 := by
  intro p hp
  have h : env43683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43660_43683 : H12AffineEnvironment.transform 5 1 env43660 = env43683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env43660 == env43683) = true)

theorem identity43683 : scanCanonicalize (H12AffineFastState.compose env43683 (packedSelected [1,8,28] rootPS)) = affineNative (2^(9+1) ^^^ 285) := by decide +kernel

theorem selectedBound43683 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env43684 : List Nat := [2,4,8,16,32,1,128,256,512,285,2048,777,25,13,261,65536,65834,65665,521,260,777,648,65831,65549,900,66082,291,65851,13,68359,20,16,257,65835,29,276]

theorem envBound43684 : H12AffineFastState.Bounded env43684 := by
  intro p hp
  have h : env43684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43683_43684 : H12AffineEnvironment.transform 9 285 env43683 = env43684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 285 env43683 == env43684) = true)

def env43685 : List Nat := [2,4,8,16,32,1,128,256,280,285,2048,17,25,13,261,65536,65834,65665,273,260,17,400,65831,65549,156,65850,291,65851,13,67615,20,16,257,65835,29,276]

theorem envBound43685 : H12AffineFastState.Bounded env43685 := by
  intro p hp
  have h : env43685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43684_43685 : H12AffineEnvironment.transform 8 280 env43684 = env43685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 280 env43684 == env43685) = true)

theorem identity43685 : scanCanonicalize (H12AffineFastState.compose env43685 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 8) := by decide +kernel

theorem selectedBound43685 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env43686 : List Nat := [2,4,8,16,32,1,128,8,16,21,2048,17,25,13,13,65536,65570,65665,25,12,17,152,65583,65549,156,65586,43,65587,13,67615,20,16,9,65571,29,28]

theorem envBound43686 : H12AffineFastState.Bounded env43686 := by
  intro p hp
  have h : env43686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43685_43686 : H12AffineEnvironment.transform 7 8 env43685 = env43686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 8 env43685 == env43686) = true)

theorem identity43686 : scanCanonicalize (H12AffineFastState.compose env43686 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound43686 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env43687 : List Nat := [2,4,8,16,32,1,128,8,16,21,2048,17,25,13,13,34,0,163,25,12,17,152,13,47,156,16,43,17,13,2109,20,16,9,1,29,28]

theorem envBound43687 : H12AffineFastState.Bounded env43687 := by
  intro p hp
  have h : env43687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43686_43687 : H12AffineEnvironment.transform 15 34 env43686 = env43687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env43686 == env43687) = true)

theorem identity43687 : scanCanonicalize (H12AffineFastState.compose env43687 (packedSelected [1,3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 62) := by decide +kernel

theorem selectedBound43687 : packedSelected [1,3,5,10] rootPS < 2^1333 := by decide +kernel

def env43688 : List Nat := [2,4,8,16,32,1,62,8,16,21,2048,17,25,13,13,34,0,29,25,12,17,38,13,47,34,16,43,17,13,2109,20,16,9,1,29,28]

theorem envBound43688 : H12AffineFastState.Bounded env43688 := by
  intro p hp
  have h : env43688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43687_43688 : H12AffineEnvironment.transform 6 62 env43687 = env43688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 62 env43687 == env43688) = true)

theorem identity43688 : scanCanonicalize (H12AffineFastState.compose env43688 (packedSelected [0,1,2,3,7,11] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound43688 : packedSelected [0,1,2,3,7,11] rootPS < 2^1333 := by decide +kernel

def env43689 : List Nat := [2,4,8,16,10,1,20,8,16,21,2048,17,25,13,13,8,0,29,25,12,17,12,13,5,8,16,1,17,13,2071,20,16,9,1,29,28]

theorem envBound43689 : H12AffineFastState.Bounded env43689 := by
  intro p hp
  have h : env43689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43688_43689 : H12AffineEnvironment.transform 4 10 env43688 = env43689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env43688 == env43689) = true)

theorem identity43689 : scanCanonicalize (H12AffineFastState.compose env43689 (packedSelected [2,3,4,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound43689 : packedSelected [2,3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env43690 : List Nat := [2,4,8,16,10,1,20,8,16,21,10,17,25,13,13,8,0,29,25,12,17,12,13,5,8,16,1,17,13,29,20,16,9,1,29,28]

theorem envBound43690 : H12AffineFastState.Bounded env43690 := by
  intro p hp
  have h : env43690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43689_43690 : H12AffineEnvironment.transform 10 10 env43689 = env43690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env43689 == env43690) = true)

theorem identity43690 : scanCanonicalize (H12AffineFastState.compose env43690 (packedSelected [0,3,4] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound43690 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env43691 : List Nat := [2,2,8,16,10,1,18,8,16,19,10,17,25,11,11,8,0,27,25,10,17,10,11,3,8,16,1,17,11,27,18,16,9,1,27,26]

theorem envBound43691 : H12AffineFastState.Bounded env43691 := by
  intro p hp
  have h : env43691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43690_43691 : H12AffineEnvironment.transform 1 2 env43690 = env43691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env43690 == env43691) = true)

theorem identity43691 : scanCanonicalize (H12AffineFastState.compose env43691 (packedSelected [1,2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound43691 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env43692 : List Nat := [2,2,8,1,10,1,3,8,1,2,10,0,8,11,11,8,0,10,8,10,0,10,11,3,8,1,1,0,11,10,3,1,9,1,10,11]

theorem envBound43692 : H12AffineFastState.Bounded env43692 := by
  intro p hp
  have h : env43692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43691_43692 : H12AffineEnvironment.transform 3 1 env43691 = env43692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env43691 == env43692) = true)

theorem identity43692 : scanCanonicalize (H12AffineFastState.compose env43692 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound43692 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43693 : List Nat := [2,2,2,1,0,1,3,2,1,2,0,0,2,1,1,2,0,0,2,0,0,0,1,3,2,1,1,0,1,0,3,1,3,1,0,1]

theorem envBound43693 : H12AffineFastState.Bounded env43693 := by
  intro p hp
  have h : env43693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43692_43693 : H12AffineEnvironment.transform 2 2 env43692 = env43693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env43692 == env43693) = true)

def env43694 : List Nat := [2,4,8,16,32,1,128,256,281,285,2048,16,25,13,261,65536,65834,65665,272,260,16,401,65831,65549,157,65851,291,65851,13,67614,20,16,257,65835,29,276]

theorem envBound43694 : H12AffineFastState.Bounded env43694 := by
  intro p hp
  have h : env43694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43684_43694 : H12AffineEnvironment.transform 8 281 env43684 = env43694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 281 env43684 == env43694) = true)

theorem identity43694 : scanCanonicalize (H12AffineFastState.compose env43694 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound43694 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env43695 : List Nat := [2,4,8,16,32,1,128,5,28,24,2048,16,25,13,0,65536,65583,65665,21,1,16,148,65570,65549,157,65598,38,65598,13,67614,20,16,4,65582,29,17]

theorem envBound43695 : H12AffineFastState.Bounded env43695 := by
  intro p hp
  have h : env43695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43694_43695 : H12AffineEnvironment.transform 7 5 env43694 = env43695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env43694 == env43695) = true)

theorem identity43695 : scanCanonicalize (H12AffineFastState.compose env43695 (packedSelected [13,21] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound43695 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env43696 : List Nat := [2,4,8,16,32,1,128,5,28,24,2048,16,25,13,0,35,12,162,21,1,16,148,1,46,157,29,38,29,13,2109,20,16,4,13,29,17]

theorem envBound43696 : H12AffineFastState.Bounded env43696 := by
  intro p hp
  have h : env43696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43695_43696 : H12AffineEnvironment.transform 15 35 env43695 = env43696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env43695 == env43696) = true)

theorem identity43696 : scanCanonicalize (H12AffineFastState.compose env43696 (packedSelected [0,1,2,5,7,8,11,13,15] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound43696 : packedSelected [0,1,2,5,7,8,11,13,15] rootPS < 2^1333 := by decide +kernel

def env43697 : List Nat := [2,4,8,16,32,1,9,5,28,24,2048,16,25,13,0,35,12,43,21,1,16,29,1,46,20,29,38,29,13,2109,20,16,4,13,29,17]

theorem envBound43697 : H12AffineFastState.Bounded env43697 := by
  intro p hp
  have h : env43697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43696_43697 : H12AffineEnvironment.transform 6 9 env43696 = env43697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env43696 == env43697) = true)

theorem identity43697 : scanCanonicalize (H12AffineFastState.compose env43697 (packedSelected [1,10] rootPS)) = affineNative (2^(4+1) ^^^ 28) := by decide +kernel

theorem selectedBound43697 : packedSelected [1,10] rootPS < 2^1333 := by decide +kernel

def env43698 : List Nat := [2,4,8,16,28,1,9,5,28,24,2048,16,25,13,0,31,12,23,21,1,16,29,1,18,20,29,26,29,13,2049,20,16,4,13,29,17]

theorem envBound43698 : H12AffineFastState.Bounded env43698 := by
  intro p hp
  have h : env43698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43697_43698 : H12AffineEnvironment.transform 4 28 env43697 = env43698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 28 env43697 == env43698) = true)

theorem identity43698 : scanCanonicalize (H12AffineFastState.compose env43698 (packedSelected [1,2] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound43698 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env43699 : List Nat := [2,4,4,16,16,1,5,5,16,20,2048,16,21,1,0,19,0,23,21,1,16,17,1,18,20,17,22,17,1,2049,20,16,4,1,17,17]

theorem envBound43699 : H12AffineFastState.Bounded env43699 := by
  intro p hp
  have h : env43699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43698_43699 : H12AffineEnvironment.transform 2 4 env43698 = env43699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env43698 == env43699) = true)

theorem identity43699 : scanCanonicalize (H12AffineFastState.compose env43699 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound43699 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43700 : List Nat := [2,4,4,5,5,1,5,5,5,1,2048,5,0,1,0,6,0,2,0,1,5,4,1,7,1,4,3,4,1,2049,1,5,4,1,4,4]

theorem envBound43700 : H12AffineFastState.Bounded env43700 := by
  intro p hp
  have h : env43700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43699_43700 : H12AffineEnvironment.transform 3 5 env43699 = env43700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env43699 == env43700) = true)

theorem identity43700 : scanCanonicalize (H12AffineFastState.compose env43700 (packedSelected [3,5] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound43700 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env43701 : List Nat := [2,1,1,0,0,1,0,0,0,1,2048,0,0,1,0,3,0,2,0,1,0,1,1,2,1,1,3,1,1,2049,1,0,1,1,1,1]

theorem envBound43701 : H12AffineFastState.Bounded env43701 := by
  intro p hp
  have h : env43701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43700_43701 : H12AffineEnvironment.transform 1 1 env43700 = env43701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env43700 == env43701) = true)

theorem identity43701 : scanCanonicalize (H12AffineFastState.compose env43701 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound43701 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env43702 : List Nat := [2,1,1,0,0,1,0,0,0,1,1,0,0,1,0,3,0,2,0,1,0,1,1,2,1,1,3,1,1,0,1,0,1,1,1,1]

theorem envBound43702 : H12AffineFastState.Bounded env43702 := by
  intro p hp
  have h : env43702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43701_43702 : H12AffineEnvironment.transform 10 1 env43701 = env43702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env43701 == env43702) = true)

def env43703 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1557,25,1296,324,65536,66678,65665,1876,325,1557,649,65831,66897,964,66083,1151,66598,1296,68423,20,16,257,66614,1345,340]

theorem envBound43703 : H12AffineFastState.Bounded env43703 := by
  intro p hp
  have h : env43703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43659_43703 : H12AffineEnvironment.transform 11 1557 env43659 = env43703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1557 env43659 == env43703) = true)

def env43704 : List Nat := [2,4,8,16,32,0,128,256,512,1024,2048,1557,25,1296,260,65536,66614,65665,1812,261,1557,649,65831,66833,900,66083,1087,66598,1296,68359,20,16,257,66614,1281,276]

theorem envBound43704 : H12AffineFastState.Bounded env43704 := by
  intro p hp
  have h : env43704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43703_43704 : H12AffineEnvironment.transform 5 0 env43703 = env43704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env43703 == env43704) = true)

theorem identity43704 : scanCanonicalize (H12AffineFastState.compose env43704 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 315) := by decide +kernel

theorem selectedBound43704 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env43705 : List Nat := [2,4,8,16,32,0,128,256,512,1024,2048,1557,25,1296,260,315,1293,442,1812,261,1557,649,28,1066,900,792,1087,1309,1296,2620,20,16,257,1293,1281,276]

theorem envBound43705 : H12AffineFastState.Bounded env43705 := by
  intro p hp
  have h : env43705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43704_43705 : H12AffineEnvironment.transform 15 315 env43704 = env43705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 315 env43704 == env43705) = true)

def env43706 : List Nat := [2,4,8,16,32,0,128,256,264,1024,2048,1309,25,1296,260,315,1293,442,1052,261,1309,385,28,1066,140,16,1087,1309,1296,2356,20,16,257,1293,1281,276]

theorem envBound43706 : H12AffineFastState.Bounded env43706 := by
  intro p hp
  have h : env43706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43705_43706 : H12AffineEnvironment.transform 8 264 env43705 = env43706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 264 env43705 == env43706) = true)

theorem identity43706 : scanCanonicalize (H12AffineFastState.compose env43706 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound43706 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env43707 : List Nat := [2,4,8,16,32,0,128,256,264,20,2048,265,25,260,260,315,281,442,8,261,265,385,28,62,140,16,43,265,260,2356,20,16,257,281,277,276]

theorem envBound43707 : H12AffineFastState.Bounded env43707 := by
  intro p hp
  have h : env43707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43706_43707 : H12AffineEnvironment.transform 9 20 env43706 = env43707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env43706 == env43707) = true)

theorem identity43707 : scanCanonicalize (H12AffineFastState.compose env43707 (packedSelected [1,3,4,8,9,10,11,12,15,18,19,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 51) := by decide +kernel

theorem selectedBound43707 : packedSelected [1,3,4,8,9,10,11,12,15,18,19,23,24] rootPS < 2^1333 := by decide +kernel

def env43708 : List Nat := [2,4,8,16,32,0,128,51,59,20,2048,58,25,55,55,8,42,137,8,54,58,178,28,62,140,16,43,58,55,2055,20,16,50,42,38,39]

theorem envBound43708 : H12AffineFastState.Bounded env43708 := by
  intro p hp
  have h : env43708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43707_43708 : H12AffineEnvironment.transform 7 51 env43707 = env43708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 51 env43707 == env43708) = true)

theorem identity43708 : scanCanonicalize (H12AffineFastState.compose env43708 (packedSelected [5,11,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 178) := by decide +kernel

theorem selectedBound43708 : packedSelected [5,11,17,18] rootPS < 2^1333 := by decide +kernel

def env43709 : List Nat := [2,4,8,16,32,0,128,51,59,20,178,58,25,55,55,8,42,137,8,54,58,178,28,62,140,16,43,58,55,181,20,16,50,42,38,39]

theorem envBound43709 : H12AffineFastState.Bounded env43709 := by
  intro p hp
  have h : env43709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43708_43709 : H12AffineEnvironment.transform 10 178 env43708 = env43709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 178 env43708 == env43709) = true)

theorem identity43709 : scanCanonicalize (H12AffineFastState.compose env43709 (packedSelected [0,5,8,9,12] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound43709 : packedSelected [0,5,8,9,12] rootPS < 2^1333 := by decide +kernel

def env43710 : List Nat := [2,4,8,11,32,0,128,40,32,15,169,33,2,44,44,8,42,137,8,45,33,169,7,37,140,11,43,33,44,174,15,11,41,42,38,39]

theorem envBound43710 : H12AffineFastState.Bounded env43710 := by
  intro p hp
  have h : env43710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43709_43710 : H12AffineEnvironment.transform 3 11 env43709 = env43710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env43709 == env43710) = true)

theorem identity43710 : scanCanonicalize (H12AffineFastState.compose env43710 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound43710 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env43711 : List Nat := [2,4,8,11,10,0,128,2,10,15,131,11,2,6,6,8,0,137,8,7,11,131,7,15,140,11,1,11,6,132,15,11,3,0,12,13]

theorem envBound43711 : H12AffineFastState.Bounded env43711 := by
  intro p hp
  have h : env43711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43710_43711 : H12AffineEnvironment.transform 4 10 env43710 = env43711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env43710 == env43711) = true)

theorem identity43711 : scanCanonicalize (H12AffineFastState.compose env43711 (packedSelected [0,1,4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound43711 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env43712 : List Nat := [2,3,8,11,10,0,128,2,10,8,131,11,2,1,1,8,0,137,8,0,11,131,0,8,139,11,1,11,1,131,8,11,3,0,11,10]

theorem envBound43712 : H12AffineFastState.Bounded env43712 := by
  intro p hp
  have h : env43712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43711_43712 : H12AffineEnvironment.transform 1 3 env43711 = env43712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env43711 == env43712) = true)

theorem identity43712 : scanCanonicalize (H12AffineFastState.compose env43712 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound43712 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43713 : List Nat := [2,3,8,11,10,0,3,2,10,8,0,11,2,1,1,8,0,10,8,0,11,0,0,8,8,11,1,11,1,0,8,11,3,0,11,10]

theorem envBound43713 : H12AffineFastState.Bounded env43713 := by
  intro p hp
  have h : env43713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43712_43713 : H12AffineEnvironment.transform 6 3 env43712 = env43713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env43712 == env43713) = true)

theorem identity43713 : scanCanonicalize (H12AffineFastState.compose env43713 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound43713 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43714 : List Nat := [2,3,2,1,0,0,3,2,0,2,0,1,2,1,1,2,0,0,2,0,1,0,0,2,2,1,1,1,1,0,2,1,3,0,1,0]

theorem envBound43714 : H12AffineFastState.Bounded env43714 := by
  intro p hp
  have h : env43714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43713_43714 : H12AffineEnvironment.transform 2 2 env43713 = env43714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env43713 == env43714) = true)

def env43715 : List Nat := [2,4,8,16,32,0,128,256,265,1024,2048,1308,25,1296,260,315,1293,442,1053,261,1308,384,28,1066,141,17,1087,1309,1296,2357,20,16,257,1293,1281,276]

theorem envBound43715 : H12AffineFastState.Bounded env43715 := by
  intro p hp
  have h : env43715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43705_43715 : H12AffineEnvironment.transform 8 265 env43705 = env43715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 265 env43705 == env43715) = true)

theorem identity43715 : scanCanonicalize (H12AffineFastState.compose env43715 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 9) := by decide +kernel

theorem selectedBound43715 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env43716 : List Nat := [2,4,8,16,32,0,128,256,265,9,2048,277,25,281,260,315,260,442,20,261,277,384,28,35,141,17,54,276,281,2357,20,16,257,260,264,276]

theorem envBound43716 : H12AffineFastState.Bounded env43716 := by
  intro p hp
  have h : env43716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43715_43716 : H12AffineEnvironment.transform 9 9 env43715 = env43716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 9 env43715 == env43716) = true)

theorem identity43716 : scanCanonicalize (H12AffineFastState.compose env43716 (packedSelected [0,1,3,5,7,11,12,15,19] rootPS)) = affineNative (2^(10+1) ^^^ 137) := by decide +kernel

theorem selectedBound43716 : packedSelected [0,1,3,5,7,11,12,15,19] rootPS < 2^1333 := by decide +kernel

def env43717 : List Nat := [2,4,8,16,32,0,128,256,265,9,137,277,25,281,260,315,260,442,20,261,277,384,28,35,141,17,54,276,281,444,20,16,257,260,264,276]

theorem envBound43717 : H12AffineFastState.Bounded env43717 := by
  intro p hp
  have h : env43717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43716_43717 : H12AffineEnvironment.transform 10 137 env43716 = env43717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 137 env43716 == env43717) = true)

theorem identity43717 : scanCanonicalize (H12AffineFastState.compose env43717 (packedSelected [0,1,2,5,7,8,11,12,13,15] rootPS)) = affineNative (2^(4+1) ^^^ 28) := by decide +kernel

theorem selectedBound43717 : packedSelected [0,1,2,5,7,8,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env43718 : List Nat := [2,4,8,16,28,0,128,256,265,9,137,277,25,281,260,263,260,390,20,261,277,384,28,31,141,17,10,276,281,384,20,16,257,260,264,276]

theorem envBound43718 : H12AffineFastState.Bounded env43718 := by
  intro p hp
  have h : env43718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43717_43718 : H12AffineEnvironment.transform 4 28 env43717 = env43718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 28 env43717 == env43718) = true)

theorem identity43718 : scanCanonicalize (H12AffineFastState.compose env43718 (packedSelected [1,4,7] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound43718 : packedSelected [1,4,7] rootPS < 2^1333 := by decide +kernel

def env43719 : List Nat := [2,4,8,16,28,0,128,15,6,9,137,26,25,22,11,8,11,137,20,10,26,143,28,31,141,17,10,27,22,143,20,16,14,11,7,27]

theorem envBound43719 : H12AffineFastState.Bounded env43719 := by
  intro p hp
  have h : env43719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43718_43719 : H12AffineEnvironment.transform 7 15 env43718 = env43719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env43718 == env43719) = true)

theorem identity43719 : scanCanonicalize (H12AffineFastState.compose env43719 (packedSelected [2,4,5,8,9] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound43719 : packedSelected [2,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env43720 : List Nat := [2,4,8,13,1,0,128,15,6,9,137,7,4,11,11,8,11,137,9,10,7,143,1,2,141,12,10,6,11,143,9,13,14,11,7,6]

theorem envBound43720 : H12AffineFastState.Bounded env43720 := by
  intro p hp
  have h : env43720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43719_43720 : H12AffineEnvironment.transform 3 13 env43719 = env43720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env43719 == env43720) = true)

theorem identity43720 : scanCanonicalize (H12AffineFastState.compose env43720 (packedSelected [0,2] rootPS)) = affineNative (2^(6+1) ^^^ 14) := by decide +kernel

theorem selectedBound43720 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env43721 : List Nat := [2,4,8,13,1,0,14,15,6,9,7,7,4,11,11,8,11,7,9,10,7,1,1,2,3,12,10,6,11,1,9,13,14,11,7,6]

theorem envBound43721 : H12AffineFastState.Bounded env43721 := by
  intro p hp
  have h : env43721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43720_43721 : H12AffineEnvironment.transform 6 14 env43720 = env43721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 14 env43720 == env43721) = true)

theorem identity43721 : scanCanonicalize (H12AffineFastState.compose env43721 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound43721 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43722 : List Nat := [2,4,5,0,1,0,3,2,6,4,7,7,4,6,6,5,6,7,4,7,7,1,1,2,3,1,7,6,6,1,4,0,3,6,7,6]

theorem envBound43722 : H12AffineFastState.Bounded env43722 := by
  intro p hp
  have h : env43722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43721_43722 : H12AffineEnvironment.transform 2 5 env43721 = env43722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env43721 == env43722) = true)

theorem identity43722 : scanCanonicalize (H12AffineFastState.compose env43722 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound43722 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env43723 : List Nat := [2,3,2,0,1,0,3,2,1,3,0,0,3,1,1,2,1,0,3,0,0,1,1,2,3,1,0,1,1,1,3,0,3,1,0,1]

theorem envBound43723 : H12AffineFastState.Bounded env43723 := by
  intro p hp
  have h : env43723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43722_43723 : H12AffineEnvironment.transform 1 3 env43722 = env43723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env43722 == env43723) = true)

def env43724 : List Nat := [2,4,8,16,32,1,128,256,512,1024,2048,1557,25,1296,261,65536,66615,65665,1813,260,1557,649,65831,66832,901,66083,1086,66598,1296,68358,20,16,257,66614,1280,277]

theorem envBound43724 : H12AffineFastState.Bounded env43724 := by
  intro p hp
  have h : env43724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43703_43724 : H12AffineEnvironment.transform 5 1 env43703 = env43724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env43703 == env43724) = true)

theorem identity43724 : scanCanonicalize (H12AffineFastState.compose env43724 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 1067) := by decide +kernel

theorem selectedBound43724 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env43725 : List Nat := [2,4,8,16,32,1,128,256,512,1024,2048,1557,25,1296,261,1067,28,1194,1813,260,1557,649,1292,315,901,1544,1086,13,1296,3885,20,16,257,29,1280,277]

theorem envBound43725 : H12AffineFastState.Bounded env43725 := by
  intro p hp
  have h : env43725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43724_43725 : H12AffineEnvironment.transform 15 1067 env43724 = env43725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1067 env43724 == env43725) = true)

def env43726 : List Nat := [2,4,8,16,32,1,128,256,264,1024,2048,1309,25,1296,261,1067,28,1194,1053,260,1309,385,1292,315,141,1280,1086,13,1296,3109,20,16,257,29,1280,277]

theorem envBound43726 : H12AffineFastState.Bounded env43726 := by
  intro p hp
  have h : env43726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43725_43726 : H12AffineEnvironment.transform 8 264 env43725 = env43726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 264 env43725 == env43726) = true)

theorem identity43726 : scanCanonicalize (H12AffineFastState.compose env43726 (packedSelected [1,5,7,8,16,18,23,24,27] rootPS)) = affineNative (2^(9+1) ^^^ 8) := by decide +kernel

theorem selectedBound43726 : packedSelected [1,5,7,8,16,18,23,24,27] rootPS < 2^1333 := by decide +kernel

def env43727 : List Nat := [2,4,8,16,32,1,128,256,264,8,2048,277,25,280,261,35,28,162,21,260,277,385,260,315,141,264,54,13,280,2093,20,16,257,29,264,277]

theorem envBound43727 : H12AffineFastState.Bounded env43727 := by
  intro p hp
  have h : env43727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43726_43727 : H12AffineEnvironment.transform 9 8 env43726 = env43727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 8 env43726 == env43727) = true)

theorem identity43727 : scanCanonicalize (H12AffineFastState.compose env43727 (packedSelected [0,2,3,4,5,7,9,10,11,12,15,16,18,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 156) := by decide +kernel

theorem selectedBound43727 : packedSelected [0,2,3,4,5,7,9,10,11,12,15,16,18,20,21] rootPS < 2^1333 := by decide +kernel

def env43728 : List Nat := [2,4,8,16,32,1,128,156,148,8,2048,137,25,132,153,35,28,162,21,152,137,29,152,167,141,148,54,13,132,2093,20,16,157,29,148,137]

theorem envBound43728 : H12AffineFastState.Bounded env43728 := by
  intro p hp
  have h : env43728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43727_43728 : H12AffineEnvironment.transform 7 156 env43727 = env43728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 156 env43727 == env43728) = true)

theorem identity43728 : scanCanonicalize (H12AffineFastState.compose env43728 (packedSelected [0,1,3,4,7,8,9,10,11,13,16,17] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound43728 : packedSelected [0,1,3,4,7,8,9,10,11,13,16,17] rootPS < 2^1333 := by decide +kernel

def env43729 : List Nat := [2,4,8,7,32,1,128,139,131,8,2048,137,14,132,142,35,11,162,2,143,137,10,143,167,141,131,33,13,132,2093,3,7,138,10,131,137]

theorem envBound43729 : H12AffineFastState.Bounded env43729 := by
  intro p hp
  have h : env43729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43728_43729 : H12AffineEnvironment.transform 3 7 env43728 = env43729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env43728 == env43729) = true)

theorem identity43729 : scanCanonicalize (H12AffineFastState.compose env43729 (packedSelected [1,4,5,9] rootPS)) = affineNative (2^(6+1) ^^^ 15) := by decide +kernel

theorem selectedBound43729 : packedSelected [1,4,5,9] rootPS < 2^1333 := by decide +kernel

def env43730 : List Nat := [2,4,8,7,32,1,15,4,12,8,2048,6,14,11,1,35,11,45,2,0,6,10,0,40,2,12,33,13,11,2093,3,7,5,10,12,6]

theorem envBound43730 : H12AffineFastState.Bounded env43730 := by
  intro p hp
  have h : env43730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43729_43730 : H12AffineEnvironment.transform 6 15 env43729 = env43730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 15 env43729 == env43730) = true)

theorem identity43730 : scanCanonicalize (H12AffineFastState.compose env43730 (packedSelected [1,8] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound43730 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env43731 : List Nat := [2,4,8,7,32,1,15,4,12,8,0,6,14,11,1,35,11,45,2,0,6,10,0,40,2,12,33,13,11,45,3,7,5,10,12,6]

theorem envBound43731 : H12AffineFastState.Bounded env43731 := by
  intro p hp
  have h : env43731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43730_43731 : H12AffineEnvironment.transform 10 0 env43730 = env43731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env43730 == env43731) = true)

theorem identity43731 : scanCanonicalize (H12AffineFastState.compose env43731 (packedSelected [0,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound43731 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env43732 : List Nat := [2,4,8,7,7,1,15,4,12,8,0,6,14,11,1,4,11,10,2,0,6,10,0,15,2,12,6,13,11,10,3,7,5,10,12,6]

theorem envBound43732 : H12AffineFastState.Bounded env43732 := by
  intro p hp
  have h : env43732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43731_43732 : H12AffineEnvironment.transform 4 7 env43731 = env43732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env43731 == env43732) = true)

theorem identity43732 : scanCanonicalize (H12AffineFastState.compose env43732 (packedSelected [2,3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound43732 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env43733 : List Nat := [2,4,2,7,7,1,5,4,6,2,0,6,4,1,1,4,1,0,2,0,6,0,0,5,2,6,6,7,1,0,3,7,5,0,6,6]

theorem envBound43733 : H12AffineFastState.Bounded env43733 := by
  intro p hp
  have h : env43733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43732_43733 : H12AffineEnvironment.transform 2 2 env43732 = env43733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env43732 == env43733) = true)

theorem identity43733 : scanCanonicalize (H12AffineFastState.compose env43733 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound43733 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43734 : List Nat := [2,3,2,0,0,1,2,3,1,2,0,1,3,1,1,3,1,0,2,0,1,0,0,2,2,1,1,0,1,0,3,0,2,0,1,1]

theorem envBound43734 : H12AffineFastState.Bounded env43734 := by
  intro p hp
  have h : env43734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43733_43734 : H12AffineEnvironment.transform 1 3 env43733 = env43734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env43733 == env43734) = true)

def env43735 : List Nat := [2,4,8,16,32,1,128,256,265,1024,2048,1308,25,1296,261,1067,28,1194,1052,260,1308,384,1292,315,140,1281,1086,13,1296,3108,20,16,257,29,1280,277]

theorem envBound43735 : H12AffineFastState.Bounded env43735 := by
  intro p hp
  have h : env43735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43725_43735 : H12AffineEnvironment.transform 8 265 env43725 = env43735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 265 env43725 == env43735) = true)

theorem identity43735 : scanCanonicalize (H12AffineFastState.compose env43735 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound43735 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env43736 : List Nat := [2,4,8,12,32,1,128,256,265,1024,2048,1280,5,1292,261,1067,0,1194,1024,260,1280,384,1292,295,140,1281,1058,13,1292,3108,8,12,257,1,1280,265]

theorem envBound43736 : H12AffineFastState.Bounded env43736 := by
  intro p hp
  have h : env43736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43735_43736 : H12AffineEnvironment.transform 3 12 env43735 = env43736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env43735 == env43736) = true)

theorem identity43736 : scanCanonicalize (H12AffineFastState.compose env43736 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 9) := by decide +kernel

theorem selectedBound43736 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env43737 : List Nat := [2,4,8,12,32,1,128,256,265,9,2048,265,5,261,261,34,0,163,9,260,265,384,261,295,140,264,43,13,261,2093,8,12,257,1,265,265]

theorem envBound43737 : H12AffineFastState.Bounded env43737 := by
  intro p hp
  have h : env43737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43736_43737 : H12AffineEnvironment.transform 9 9 env43736 = env43737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 9 env43736 == env43737) = true)

theorem identity43737 : scanCanonicalize (H12AffineFastState.compose env43737 (packedSelected [1,2,5,10,12,13] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound43737 : packedSelected [1,2,5,10,12,13] rootPS < 2^1333 := by decide +kernel

def env43738 : List Nat := [2,4,5,1,32,1,128,256,260,4,2048,260,5,261,261,34,0,163,4,260,260,384,261,295,129,261,38,0,261,2080,5,1,257,1,260,260]

theorem envBound43738 : H12AffineFastState.Bounded env43738 := by
  intro p hp
  have h : env43738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43737_43738 : H12AffineEnvironment.transform 2 5 env43737 = env43738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env43737 == env43738) = true)

theorem identity43738 : scanCanonicalize (H12AffineFastState.compose env43738 (packedSelected [1,2,3] rootPS)) = affineNative (2^(10+1) ^^^ 384) := by decide +kernel

theorem selectedBound43738 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env43739 : List Nat := [2,4,5,1,32,1,128,256,260,4,384,260,5,261,261,34,0,163,4,260,260,384,261,295,129,261,38,0,261,416,5,1,257,1,260,260]

theorem envBound43739 : H12AffineFastState.Bounded env43739 := by
  intro p hp
  have h : env43739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43738_43739 : H12AffineEnvironment.transform 10 384 env43738 = env43739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 384 env43738 == env43739) = true)

theorem identity43739 : scanCanonicalize (H12AffineFastState.compose env43739 (packedSelected [0,1,2,4,7] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound43739 : packedSelected [0,1,2,4,7] rootPS < 2^1333 := by decide +kernel

def env43740 : List Nat := [2,4,5,1,32,1,128,37,33,4,165,33,5,32,32,34,0,163,4,33,33,165,32,2,129,32,38,0,32,133,5,1,36,1,33,33]

theorem envBound43740 : H12AffineFastState.Bounded env43740 := by
  intro p hp
  have h : env43740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43739_43740 : H12AffineEnvironment.transform 7 37 env43739 = env43740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env43739 == env43740) = true)

def env43741 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74863,262144,4416,8541,4096,5276,74047,66897,13769,78895,328958,74814,1296,81226,8204,8200,257,74799,1345,5952]

theorem envBound43741 : H12AffineFastState.Bounded env43741 := by
  intro p hp
  have h : env43741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43583_43741 : H12AffineEnvironment.transform 13 1297 env43583 = env43741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env43583 == env43741) = true)

def env43742 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74863,65664,4416,8541,4096,5276,74047,66897,13769,78895,1150,74814,1296,81226,8204,8200,257,74799,1345,5952]

theorem envBound43742 : H12AffineFastState.Bounded env43742 := by
  intro p hp
  have h : env43742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43741_43742 : H12AffineEnvironment.transform 17 65664 env43741 = env43742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env43741 == env43742) = true)

theorem identity43742 : scanCanonicalize (H12AffineFastState.compose env43742 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound43742 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env43743 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,8192,0,8540,65536,74110,65664,4416,8541,4096,4493,74047,65600,12504,78142,367,74031,1,79963,8204,8200,257,74046,80,4689]

theorem envBound43743 : H12AffineFastState.Bounded env43743 := by
  intro p hp
  have h : env43743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43742_43743 : H12AffineEnvironment.transform 9 273 env43742 = env43743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env43742 == env43743) = true)

def env43744 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,772,8192,0,8540,65536,74110,65664,580,8541,772,649,74047,65600,9180,74298,367,74031,1,76639,8204,8200,257,74046,80,341]

theorem envBound43744 : H12AffineFastState.Bounded env43744 := by
  intro p hp
  have h : env43744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43743_43744 : H12AffineEnvironment.transform 11 772 env43743 = env43744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 772 env43743 == env43744) = true)

def env43745 : List Nat := [2,4,8,16,32,0,128,256,512,273,2048,772,8192,0,8476,65536,74046,65664,516,8477,772,649,74047,65536,9116,74298,303,74031,1,76575,8204,8200,257,74046,16,277]

theorem envBound43745 : H12AffineFastState.Bounded env43745 := by
  intro p hp
  have h : env43745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43744_43745 : H12AffineEnvironment.transform 5 0 env43744 = env43745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env43744 == env43745) = true)

theorem identity43745 : scanCanonicalize (H12AffineFastState.compose env43745 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 668) := by decide +kernel

theorem selectedBound43745 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env43746 : List Nat := [2,4,8,16,32,0,128,256,512,273,2048,772,668,0,896,65536,66466,65664,516,897,772,649,66467,65536,256,65702,303,66483,1,67971,656,660,257,66466,16,277]

theorem envBound43746 : H12AffineFastState.Bounded env43746 := by
  intro p hp
  have h : env43746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43745_43746 : H12AffineEnvironment.transform 12 668 env43745 = env43746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 668 env43745 == env43746) = true)

def env43747 : List Nat := [2,4,8,16,32,0,128,256,132,273,2048,384,24,0,260,65536,65830,65664,128,261,384,13,65831,65536,256,65702,303,65847,1,67971,20,16,257,65830,16,277]

theorem envBound43747 : H12AffineFastState.Bounded env43747 := by
  intro p hp
  have h : env43747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43746_43747 : H12AffineEnvironment.transform 8 132 env43746 = env43747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 132 env43746 == env43747) = true)

theorem identity43747 : scanCanonicalize (H12AffineFastState.compose env43747 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(6+1) ^^^ 20) := by decide +kernel

theorem selectedBound43747 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env43748 : List Nat := [2,4,8,16,32,0,20,256,16,273,2048,276,24,0,260,65536,65830,65556,20,261,276,13,65831,65536,256,65586,303,65847,1,67863,20,16,257,65830,16,277]

theorem envBound43748 : H12AffineFastState.Bounded env43748 := by
  intro p hp
  have h : env43748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43747_43748 : H12AffineEnvironment.transform 6 20 env43747 = env43748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 20 env43747 == env43748) = true)

theorem identity43748 : scanCanonicalize (H12AffineFastState.compose env43748 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(15+1) ^^^ 50) := by decide +kernel

theorem selectedBound43748 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env43749 : List Nat := [2,4,8,16,32,0,20,256,16,273,2048,276,24,0,260,50,276,38,20,261,276,13,277,50,256,0,303,261,1,2341,20,16,257,276,16,277]

theorem envBound43749 : H12AffineFastState.Bounded env43749 := by
  intro p hp
  have h : env43749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43748_43749 : H12AffineEnvironment.transform 15 50 env43748 = env43749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 50 env43748 == env43749) = true)

theorem identity43749 : scanCanonicalize (H12AffineFastState.compose env43749 (packedSelected [1,2,12] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound43749 : packedSelected [1,2,12] rootPS < 2^1333 := by decide +kernel

def env43750 : List Nat := [2,4,8,16,26,0,20,256,16,273,2048,276,24,0,260,8,276,28,20,261,276,13,277,8,256,0,277,261,1,2335,20,16,257,276,16,277]

theorem envBound43750 : H12AffineFastState.Bounded env43750 := by
  intro p hp
  have h : env43750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43749_43750 : H12AffineEnvironment.transform 4 26 env43749 = env43750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env43749 == env43750) = true)

theorem identity43750 : scanCanonicalize (H12AffineFastState.compose env43750 (packedSelected [2,3,13] rootPS)) = affineNative (2^(10+1) ^^^ 261) := by decide +kernel

theorem selectedBound43750 : packedSelected [2,3,13] rootPS < 2^1333 := by decide +kernel

def env43751 : List Nat := [2,4,8,16,26,0,20,256,16,273,261,276,24,0,260,8,276,28,20,261,276,13,277,8,256,0,277,261,1,26,20,16,257,276,16,277]

theorem envBound43751 : H12AffineFastState.Bounded env43751 := by
  intro p hp
  have h : env43751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43750_43751 : H12AffineEnvironment.transform 10 261 env43750 = env43751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 261 env43750 == env43751) = true)

theorem identity43751 : scanCanonicalize (H12AffineFastState.compose env43751 (packedSelected [0,1,2,3,5,7] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound43751 : packedSelected [0,1,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env43752 : List Nat := [2,4,3,16,17,0,20,256,16,273,261,276,19,0,260,3,276,23,20,261,276,6,277,3,256,0,277,261,1,17,20,16,257,276,16,277]

theorem envBound43752 : H12AffineFastState.Bounded env43752 := by
  intro p hp
  have h : env43752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43751_43752 : H12AffineEnvironment.transform 2 3 env43751 = env43752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env43751 == env43752) = true)

theorem identity43752 : scanCanonicalize (H12AffineFastState.compose env43752 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound43752 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43753 : List Nat := [2,4,3,16,17,0,20,5,16,20,0,17,19,0,1,3,17,23,20,0,17,6,16,3,5,0,16,0,1,17,20,16,4,17,16,16]

theorem envBound43753 : H12AffineFastState.Bounded env43753 := by
  intro p hp
  have h : env43753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43752_43753 : H12AffineEnvironment.transform 7 5 env43752 = env43753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env43752 == env43753) = true)

theorem identity43753 : scanCanonicalize (H12AffineFastState.compose env43753 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound43753 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43754 : List Nat := [2,2,3,16,17,0,18,3,16,18,0,17,19,0,1,3,17,17,18,0,17,0,16,3,3,0,16,0,1,17,18,16,2,17,16,16]

theorem envBound43754 : H12AffineFastState.Bounded env43754 := by
  intro p hp
  have h : env43754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43753_43754 : H12AffineEnvironment.transform 1 2 env43753 = env43754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env43753 == env43754) = true)

theorem identity43754 : scanCanonicalize (H12AffineFastState.compose env43754 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound43754 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env43755 : List Nat := [2,2,3,1,0,0,3,3,1,3,0,0,2,0,1,3,0,0,3,0,0,0,1,3,3,0,1,0,1,0,3,1,2,0,1,1]

theorem envBound43755 : H12AffineFastState.Bounded env43755 := by
  intro p hp
  have h : env43755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43754_43755 : H12AffineEnvironment.transform 3 1 env43754 = env43755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env43754 == env43755) = true)

def env43756 : List Nat := [2,4,8,16,32,0,128,256,133,273,2048,385,25,0,261,65536,65831,65664,129,260,385,12,65830,65536,256,65702,303,65846,1,67971,21,17,257,65831,16,277]

theorem envBound43756 : H12AffineFastState.Bounded env43756 := by
  intro p hp
  have h : env43756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43746_43756 : H12AffineEnvironment.transform 8 133 env43746 = env43756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 133 env43746 == env43756) = true)

theorem identity43756 : scanCanonicalize (H12AffineFastState.compose env43756 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound43756 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env43757 : List Nat := [2,4,8,16,32,0,128,5,133,20,2048,132,25,0,0,65536,65570,65664,129,1,132,12,65571,65536,5,65702,42,65587,1,67718,21,17,4,65570,16,16]

theorem envBound43757 : H12AffineFastState.Bounded env43757 := by
  intro p hp
  have h : env43757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43756_43757 : H12AffineEnvironment.transform 7 5 env43756 = env43757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env43756 == env43757) = true)

theorem identity43757 : scanCanonicalize (H12AffineFastState.compose env43757 (packedSelected [3,11,15,18] rootPS)) = affineNative (2^(15+1) ^^^ 154) := by decide +kernel

theorem selectedBound43757 : packedSelected [3,11,15,18] rootPS < 2^1333 := by decide +kernel

def env43758 : List Nat := [2,4,8,16,32,0,128,5,133,20,2048,132,25,0,0,154,184,26,129,1,132,12,185,154,5,60,42,169,1,2076,21,17,4,184,16,16]

theorem envBound43758 : H12AffineFastState.Bounded env43758 := by
  intro p hp
  have h : env43758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43757_43758 : H12AffineEnvironment.transform 15 154 env43757 = env43758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 154 env43757 == env43758) = true)

theorem identity43758 : scanCanonicalize (H12AffineFastState.compose env43758 (packedSelected [1,3,4,5,9,12,13,15,16] rootPS)) = affineNative (2^(10+1) ^^^ 191) := by decide +kernel

theorem selectedBound43758 : packedSelected [1,3,4,5,9,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env43759 : List Nat := [2,4,8,16,32,0,128,5,133,20,191,132,25,0,0,154,184,26,129,1,132,12,185,154,5,60,42,169,1,163,21,17,4,184,16,16]

theorem envBound43759 : H12AffineFastState.Bounded env43759 := by
  intro p hp
  have h : env43759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43758_43759 : H12AffineEnvironment.transform 10 191 env43758 = env43759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 191 env43758 == env43759) = true)

theorem identity43759 : scanCanonicalize (H12AffineFastState.compose env43759 (packedSelected [1,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound43759 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env43760 : List Nat := [2,4,8,16,12,0,128,5,133,20,147,132,25,0,0,154,148,26,129,1,132,12,149,154,5,16,6,133,1,143,21,17,4,148,16,16]

theorem envBound43760 : H12AffineFastState.Bounded env43760 := by
  intro p hp
  have h : env43760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43759_43760 : H12AffineEnvironment.transform 4 12 env43759 = env43760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env43759 == env43760) = true)

theorem identity43760 : scanCanonicalize (H12AffineFastState.compose env43760 (packedSelected [2,3,4,7] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound43760 : packedSelected [2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env43761 : List Nat := [2,4,8,7,12,0,128,5,133,3,132,132,14,0,0,141,131,13,129,1,132,12,130,141,5,7,6,133,1,143,2,6,4,131,7,7]

theorem envBound43761 : H12AffineFastState.Bounded env43761 := by
  intro p hp
  have h : env43761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43760_43761 : H12AffineEnvironment.transform 3 7 env43760 = env43761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env43760 == env43761) = true)

theorem identity43761 : scanCanonicalize (H12AffineFastState.compose env43761 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound43761 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env43762 : List Nat := [2,4,8,7,12,0,5,5,0,3,1,1,14,0,0,8,6,13,4,1,1,12,7,8,5,7,6,0,1,10,2,6,4,6,7,7]

theorem envBound43762 : H12AffineFastState.Bounded env43762 := by
  intro p hp
  have h : env43762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43761_43762 : H12AffineEnvironment.transform 6 5 env43761 = env43762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env43761 == env43762) = true)

theorem identity43762 : scanCanonicalize (H12AffineFastState.compose env43762 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound43762 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43763 : List Nat := [2,4,5,7,1,0,5,5,0,3,1,1,3,0,0,5,6,0,4,1,1,1,7,5,5,7,6,0,1,7,2,6,4,6,7,7]

theorem envBound43763 : H12AffineFastState.Bounded env43763 := by
  intro p hp
  have h : env43763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43762_43763 : H12AffineEnvironment.transform 2 5 env43762 = env43763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env43762 == env43763) = true)

def env43764 : List Nat := [2,4,8,16,32,1,128,256,512,273,2048,772,8192,0,8477,65536,74047,65664,517,8476,772,649,74047,65537,9117,74298,302,74031,1,76574,8204,8200,257,74046,17,276]

theorem envBound43764 : H12AffineFastState.Bounded env43764 := by
  intro p hp
  have h : env43764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43744_43764 : H12AffineEnvironment.transform 5 1 env43744 = env43764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env43744 == env43764) = true)

theorem identity43764 : scanCanonicalize (H12AffineFastState.compose env43764 (packedSelected [1,8,28] rootPS)) = affineNative (2^(8+1) ^^^ 133) := by decide +kernel

theorem selectedBound43764 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env43765 : List Nat := [2,4,8,16,32,1,128,256,133,273,2048,385,8192,0,8477,65536,74047,65664,128,8476,385,12,74047,65537,8472,73919,302,74031,1,76187,8204,8200,257,74046,17,276]

theorem envBound43765 : H12AffineFastState.Bounded env43765 := by
  intro p hp
  have h : env43765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43764_43765 : H12AffineEnvironment.transform 8 133 env43764 = env43765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 133 env43764 == env43765) = true)

def env43766 : List Nat := [2,4,8,16,32,1,128,256,133,273,2048,385,24,0,261,65536,65831,65664,128,260,385,12,65831,65537,256,65703,302,65847,1,67971,20,16,257,65830,17,276]

theorem envBound43766 : H12AffineFastState.Bounded env43766 := by
  intro p hp
  have h : env43766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43765_43766 : H12AffineEnvironment.transform 12 24 env43765 = env43766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env43765 == env43766) = true)

theorem identity43766 : scanCanonicalize (H12AffineFastState.compose env43766 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(6+1) ^^^ 21) := by decide +kernel

theorem selectedBound43766 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env43767 : List Nat := [2,4,8,16,32,1,21,256,16,273,2048,276,24,0,261,65536,65831,65557,21,260,276,12,65831,65537,256,65586,302,65847,1,67862,20,16,257,65830,17,276]

theorem envBound43767 : H12AffineFastState.Bounded env43767 := by
  intro p hp
  have h : env43767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43766_43767 : H12AffineEnvironment.transform 6 21 env43766 = env43767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 21 env43766 == env43767) = true)

theorem identity43767 : scanCanonicalize (H12AffineFastState.compose env43767 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(15+1) ^^^ 51) := by decide +kernel

theorem selectedBound43767 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env43768 : List Nat := [2,4,8,16,32,1,21,256,16,273,2048,276,24,0,261,51,276,38,21,260,276,12,276,50,256,1,302,260,1,2341,20,16,257,277,17,276]

theorem envBound43768 : H12AffineFastState.Bounded env43768 := by
  intro p hp
  have h : env43768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43767_43768 : H12AffineEnvironment.transform 15 51 env43767 = env43768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 51 env43767 == env43768) = true)

theorem identity43768 : scanCanonicalize (H12AffineFastState.compose env43768 (packedSelected [1,2,12] rootPS)) = affineNative (2^(7+1) ^^^ 62) := by decide +kernel

theorem selectedBound43768 : packedSelected [1,2,12] rootPS < 2^1333 := by decide +kernel

def env43769 : List Nat := [2,4,8,16,32,1,21,62,16,47,2048,42,24,0,59,51,42,38,21,58,42,12,42,50,62,1,16,58,1,2075,20,16,63,43,17,42]

theorem envBound43769 : H12AffineFastState.Bounded env43769 := by
  intro p hp
  have h : env43769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43768_43769 : H12AffineEnvironment.transform 7 62 env43768 = env43769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 62 env43768 == env43769) = true)

theorem identity43769 : scanCanonicalize (H12AffineFastState.compose env43769 (packedSelected [0,3,5,7,10,11] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound43769 : packedSelected [0,3,5,7,10,11] rootPS < 2^1333 := by decide +kernel

def env43770 : List Nat := [2,4,8,16,26,1,21,4,16,21,2048,16,24,0,1,9,16,28,21,0,16,12,16,8,4,1,16,0,1,2075,20,16,5,17,17,16]

theorem envBound43770 : H12AffineFastState.Bounded env43770 := by
  intro p hp
  have h : env43770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43769_43770 : H12AffineEnvironment.transform 4 26 env43769 = env43770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env43769 == env43770) = true)

theorem identity43770 : scanCanonicalize (H12AffineFastState.compose env43770 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 12) := by decide +kernel

theorem selectedBound43770 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env43771 : List Nat := [2,4,8,16,26,1,21,4,16,21,12,16,24,0,1,9,16,28,21,0,16,12,16,8,4,1,16,0,1,23,20,16,5,17,17,16]

theorem envBound43771 : H12AffineFastState.Bounded env43771 := by
  intro p hp
  have h : env43771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43770_43771 : H12AffineEnvironment.transform 10 12 env43770 = env43771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 12 env43770 == env43771) = true)

theorem identity43771 : scanCanonicalize (H12AffineFastState.compose env43771 (packedSelected [0,2,4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound43771 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env43772 : List Nat := [2,4,8,0,10,1,5,4,0,5,12,0,8,0,1,9,0,12,5,0,0,12,0,8,4,1,0,0,1,7,4,0,5,1,1,0]

theorem envBound43772 : H12AffineFastState.Bounded env43772 := by
  intro p hp
  have h : env43772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43771_43772 : H12AffineEnvironment.transform 3 0 env43771 = env43772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env43771 == env43772) = true)

theorem identity43772 : scanCanonicalize (H12AffineFastState.compose env43772 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound43772 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43773 : List Nat := [2,4,2,0,0,1,5,4,0,5,6,0,2,0,1,3,0,6,5,0,0,6,0,2,4,1,0,0,1,7,4,0,5,1,1,0]

theorem envBound43773 : H12AffineFastState.Bounded env43773 := by
  intro p hp
  have h : env43773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43772_43773 : H12AffineEnvironment.transform 2 2 env43772 = env43773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env43772 == env43773) = true)

theorem identity43773 : scanCanonicalize (H12AffineFastState.compose env43773 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound43773 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43774 : List Nat := [2,3,2,0,0,1,2,3,0,2,1,0,2,0,1,3,0,1,2,0,0,1,0,2,3,1,0,0,1,0,3,0,2,1,1,0]

theorem envBound43774 : H12AffineFastState.Bounded env43774 := by
  intro p hp
  have h : env43774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43773_43774 : H12AffineEnvironment.transform 1 3 env43773 = env43774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env43773 == env43774) = true)

def env43775 : List Nat := [2,4,8,16,32,1,128,256,133,273,2048,385,25,0,260,65536,65830,65664,128,261,385,12,65830,65537,257,65702,302,65846,1,67970,21,17,257,65831,17,276]

theorem envBound43775 : H12AffineFastState.Bounded env43775 := by
  intro p hp
  have h : env43775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43765_43775 : H12AffineEnvironment.transform 12 25 env43765 = env43775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env43765 == env43775) = true)

theorem identity43775 : scanCanonicalize (H12AffineFastState.compose env43775 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound43775 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env43776 : List Nat := [2,4,8,16,32,1,128,4,133,21,2048,133,25,0,0,65536,65570,65664,128,1,133,12,65570,65537,5,65702,42,65586,1,67718,21,17,5,65571,17,16]

theorem envBound43776 : H12AffineFastState.Bounded env43776 := by
  intro p hp
  have h : env43776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43775_43776 : H12AffineEnvironment.transform 7 4 env43775 = env43776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env43775 == env43776) = true)

theorem identity43776 : scanCanonicalize (H12AffineFastState.compose env43776 (packedSelected [3,11,15,18] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound43776 : packedSelected [3,11,15,18] rootPS < 2^1333 := by decide +kernel

def env43777 : List Nat := [2,4,8,16,32,1,41,4,44,21,2048,44,25,0,0,65536,65570,65577,41,1,44,12,65570,65537,5,65551,42,65586,1,67631,21,17,5,65571,17,16]

theorem envBound43777 : H12AffineFastState.Bounded env43777 := by
  intro p hp
  have h : env43777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43776_43777 : H12AffineEnvironment.transform 6 41 env43776 = env43777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env43776 == env43777) = true)

theorem identity43777 : scanCanonicalize (H12AffineFastState.compose env43777 (packedSelected [0,3,4,7,9,12] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound43777 : packedSelected [0,3,4,7,9,12] rootPS < 2^1333 := by decide +kernel

def env43778 : List Nat := [2,4,8,6,32,1,41,4,44,3,2048,44,15,0,0,65536,65570,65577,41,1,44,12,65570,65537,5,65551,42,65572,1,67631,3,7,5,65571,7,6]

theorem envBound43778 : H12AffineFastState.Bounded env43778 := by
  intro p hp
  have h : env43778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43777_43778 : H12AffineEnvironment.transform 3 6 env43777 = env43778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env43777 == env43778) = true)

theorem identity43778 : scanCanonicalize (H12AffineFastState.compose env43778 (packedSelected [0,2,3,5,9,11,13] rootPS)) = affineNative (2^(15+1) ^^^ 2057) := by decide +kernel

theorem selectedBound43778 : packedSelected [0,2,3,5,9,11,13] rootPS < 2^1333 := by decide +kernel

def env43779 : List Nat := [2,4,8,6,32,1,41,4,44,3,2048,44,15,0,0,2057,2091,2080,41,1,44,12,2091,2056,5,2054,42,2093,1,38,3,7,5,2090,7,6]

theorem envBound43779 : H12AffineFastState.Bounded env43779 := by
  intro p hp
  have h : env43779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43778_43779 : H12AffineEnvironment.transform 15 2057 env43778 = env43779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2057 env43778 == env43779) = true)

theorem identity43779 : scanCanonicalize (H12AffineFastState.compose env43779 (packedSelected [2,3,8] rootPS)) = affineNative (2^(10+1) ^^^ 6) := by decide +kernel

theorem selectedBound43779 : packedSelected [2,3,8] rootPS < 2^1333 := by decide +kernel

def env43780 : List Nat := [2,4,8,6,32,1,41,4,44,3,6,44,15,0,0,15,45,38,41,1,44,12,45,14,5,0,42,43,1,38,3,7,5,44,7,6]

theorem envBound43780 : H12AffineFastState.Bounded env43780 := by
  intro p hp
  have h : env43780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43779_43780 : H12AffineEnvironment.transform 10 6 env43779 = env43780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 6 env43779 == env43780) = true)

theorem identity43780 : scanCanonicalize (H12AffineFastState.compose env43780 (packedSelected [1,2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound43780 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env43781 : List Nat := [2,4,3,6,32,1,34,4,39,3,6,39,4,0,0,4,38,38,34,1,39,7,38,5,5,0,33,32,1,38,3,7,5,39,7,6]

theorem envBound43781 : H12AffineFastState.Bounded env43781 := by
  intro p hp
  have h : env43781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43780_43781 : H12AffineEnvironment.transform 2 3 env43780 = env43781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env43780 == env43781) = true)

theorem identity43781 : scanCanonicalize (H12AffineFastState.compose env43781 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound43781 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43782 : List Nat := [2,4,3,6,7,1,5,4,0,3,6,0,4,0,0,4,1,1,5,1,0,7,1,5,5,0,6,7,1,1,3,7,5,0,7,6]

theorem envBound43782 : H12AffineFastState.Bounded env43782 := by
  intro p hp
  have h : env43782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43781_43782 : H12AffineEnvironment.transform 4 7 env43781 = env43782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env43781 == env43782) = true)

def env43783 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,773,8192,0,8540,65536,74110,65664,581,8541,773,648,74047,65600,9181,74299,367,74031,1,76638,8204,8200,257,74046,80,340]

theorem envBound43783 : H12AffineFastState.Bounded env43783 := by
  intro p hp
  have h : env43783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43743_43783 : H12AffineEnvironment.transform 11 773 env43743 = env43783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 773 env43743 == env43783) = true)

def env43784 : List Nat := [2,4,8,16,32,0,128,256,512,273,2048,773,8192,0,8476,65536,74046,65664,517,8477,773,648,74047,65536,9117,74299,303,74031,1,76574,8204,8200,257,74046,16,276]

theorem envBound43784 : H12AffineFastState.Bounded env43784 := by
  intro p hp
  have h : env43784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43783_43784 : H12AffineEnvironment.transform 5 0 env43783 = env43784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env43783 == env43784) = true)

theorem identity43784 : scanCanonicalize (H12AffineFastState.compose env43784 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 947) := by decide +kernel

theorem selectedBound43784 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env43785 : List Nat := [2,4,8,16,32,0,128,256,512,273,2048,773,8192,0,8476,947,8845,819,517,8477,773,648,8844,947,9117,8584,303,8860,1,10413,8204,8200,257,8845,16,276]

theorem envBound43785 : H12AffineFastState.Bounded env43785 := by
  intro p hp
  have h : env43785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43784_43785 : H12AffineEnvironment.transform 15 947 env43784 = env43785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 947 env43784 == env43785) = true)

def env43786 : List Nat := [2,4,8,16,32,0,128,256,512,273,2048,773,2316,0,2064,947,2945,819,517,2065,773,648,2944,947,2705,2180,303,2960,1,417,2304,2308,257,2945,16,276]

theorem envBound43786 : H12AffineFastState.Bounded env43786 := by
  intro p hp
  have h : env43786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43785_43786 : H12AffineEnvironment.transform 12 2316 env43785 = env43786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2316 env43785 == env43786) = true)

def env43787 : List Nat := [2,4,8,16,16,0,128,256,512,273,2048,773,2316,0,2064,899,2945,771,517,2065,773,648,2944,899,2705,2180,287,2960,1,401,2304,2308,257,2945,16,276]

theorem envBound43787 : H12AffineFastState.Bounded env43787 := by
  intro p hp
  have h : env43787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43786_43787 : H12AffineEnvironment.transform 4 16 env43786 = env43787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env43786 == env43787) = true)

theorem identity43787 : scanCanonicalize (H12AffineFastState.compose env43787 (packedSelected [2,4,7,10,11,15,16,17,18,19,20] rootPS)) = affineNative (2^(8+1) ^^^ 400) := by decide +kernel

theorem selectedBound43787 : packedSelected [2,4,7,10,11,15,16,17,18,19,20] rootPS < 2^1333 := by decide +kernel

def env43788 : List Nat := [2,4,8,16,16,0,128,256,400,273,2048,149,2316,0,2064,19,2065,147,405,2065,149,280,2064,19,2305,2180,287,2048,1,401,2304,2308,257,2065,16,276]

theorem envBound43788 : H12AffineFastState.Bounded env43788 := by
  intro p hp
  have h : env43788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43787_43788 : H12AffineEnvironment.transform 8 400 env43787 = env43788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 400 env43787 == env43788) = true)

theorem identity43788 : scanCanonicalize (H12AffineFastState.compose env43788 (packedSelected [0,1,2,5,8,9,13,16] rootPS)) = affineNative (2^(10+1) ^^^ 385) := by decide +kernel

theorem selectedBound43788 : packedSelected [0,1,2,5,8,9,13,16] rootPS < 2^1333 := by decide +kernel

def env43789 : List Nat := [2,4,8,16,16,0,128,256,400,273,385,149,141,0,401,19,400,147,405,400,149,280,401,19,128,261,287,385,1,401,129,133,257,400,16,276]

theorem envBound43789 : H12AffineFastState.Bounded env43789 := by
  intro p hp
  have h : env43789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43788_43789 : H12AffineEnvironment.transform 10 385 env43788 = env43789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 385 env43788 == env43789) = true)

theorem identity43789 : scanCanonicalize (H12AffineFastState.compose env43789 (packedSelected [0,1,3,5,9] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound43789 : packedSelected [0,1,3,5,9] rootPS < 2^1333 := by decide +kernel

def env43790 : List Nat := [2,3,8,16,16,0,128,256,400,273,385,146,138,0,401,19,400,147,402,400,146,280,401,19,128,258,280,385,1,401,129,130,257,400,16,275]

theorem envBound43790 : H12AffineFastState.Bounded env43790 := by
  intro p hp
  have h : env43790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43789_43790 : H12AffineEnvironment.transform 1 3 env43789 = env43790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env43789 == env43790) = true)

theorem identity43790 : scanCanonicalize (H12AffineFastState.compose env43790 (packedSelected [0,4,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound43790 : packedSelected [0,4,5,8] rootPS < 2^1333 := by decide +kernel

def env43791 : List Nat := [2,3,8,16,16,0,3,256,275,273,258,17,9,0,274,19,275,16,273,275,17,280,274,19,3,258,280,258,1,274,2,1,257,275,16,275]

theorem envBound43791 : H12AffineFastState.Bounded env43791 := by
  intro p hp
  have h : env43791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43790_43791 : H12AffineEnvironment.transform 6 3 env43790 = env43791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env43790 == env43791) = true)

theorem identity43791 : scanCanonicalize (H12AffineFastState.compose env43791 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound43791 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43792 : List Nat := [2,3,8,1,1,0,3,256,258,256,258,0,9,0,259,2,258,1,256,258,0,265,259,2,3,258,265,258,1,259,2,1,257,258,1,258]

theorem envBound43792 : H12AffineFastState.Bounded env43792 := by
  intro p hp
  have h : env43792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43791_43792 : H12AffineEnvironment.transform 3 1 env43791 = env43792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env43791 == env43792) = true)

def env43793 : List Nat := [2,4,8,16,17,0,128,256,512,273,2048,773,2316,0,2064,898,2945,770,517,2065,773,648,2944,898,2705,2180,286,2960,1,400,2304,2308,257,2945,16,276]

theorem envBound43793 : H12AffineFastState.Bounded env43793 := by
  intro p hp
  have h : env43793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43786_43793 : H12AffineEnvironment.transform 4 17 env43786 = env43793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env43786 == env43793) = true)

theorem identity43793 : scanCanonicalize (H12AffineFastState.compose env43793 (packedSelected [2,4,7,10,11,15,16,17,18,19,20] rootPS)) = affineNative (2^(8+1) ^^^ 406) := by decide +kernel

theorem selectedBound43793 : packedSelected [2,4,7,10,11,15,16,17,18,19,20] rootPS < 2^1333 := by decide +kernel

def env43794 : List Nat := [2,4,8,16,17,0,128,256,406,273,2048,147,2316,0,2064,20,2071,148,403,2065,147,286,2070,20,2311,2180,286,2054,1,400,2304,2308,257,2071,16,276]

theorem envBound43794 : H12AffineFastState.Bounded env43794 := by
  intro p hp
  have h : env43794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43793_43794 : H12AffineEnvironment.transform 8 406 env43793 = env43794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 406 env43793 == env43794) = true)

theorem identity43794 : scanCanonicalize (H12AffineFastState.compose env43794 (packedSelected [0,2,3,4,10,12,16,17,18] rootPS)) = affineNative (2^(7+1) ^^^ 19) := by decide +kernel

theorem selectedBound43794 : packedSelected [0,2,3,4,10,12,16,17,18] rootPS < 2^1333 := by decide +kernel

def env43795 : List Nat := [2,4,8,16,17,0,128,19,133,2,2048,147,2079,0,2064,20,2071,148,128,2065,147,13,2070,20,2068,2180,13,2054,1,131,2067,2071,18,2071,16,7]

theorem envBound43795 : H12AffineFastState.Bounded env43795 := by
  intro p hp
  have h : env43795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43794_43795 : H12AffineEnvironment.transform 7 19 env43794 = env43795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 19 env43794 == env43795) = true)

theorem identity43795 : scanCanonicalize (H12AffineFastState.compose env43795 (packedSelected [4,8,9,10] rootPS)) = affineNative (2^(10+1) ^^^ 131) := by decide +kernel

theorem selectedBound43795 : packedSelected [4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env43796 : List Nat := [2,4,8,16,17,0,128,19,133,2,131,147,156,0,147,20,148,148,128,146,147,13,149,20,151,7,13,133,1,131,144,148,18,148,16,7]

theorem envBound43796 : H12AffineFastState.Bounded env43796 := by
  intro p hp
  have h : env43796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43795_43796 : H12AffineEnvironment.transform 10 131 env43795 = env43796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 131 env43795 == env43796) = true)

theorem identity43796 : scanCanonicalize (H12AffineFastState.compose env43796 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound43796 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env43797 : List Nat := [2,4,8,16,17,0,2,19,7,2,1,17,30,0,17,20,22,22,2,16,17,13,23,20,21,7,13,7,1,1,18,22,18,22,16,7]

theorem envBound43797 : H12AffineFastState.Bounded env43797 := by
  intro p hp
  have h : env43797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43796_43797 : H12AffineEnvironment.transform 6 2 env43796 = env43797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env43796 == env43797) = true)

theorem identity43797 : scanCanonicalize (H12AffineFastState.compose env43797 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound43797 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43798 : List Nat := [2,4,8,1,0,0,2,2,7,2,1,0,15,0,0,5,7,7,2,1,0,13,6,5,4,7,13,7,1,1,3,7,3,7,1,7]

theorem envBound43798 : H12AffineFastState.Bounded env43798 := by
  intro p hp
  have h : env43798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43797_43798 : H12AffineEnvironment.transform 3 1 env43797 = env43798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env43797 == env43798) = true)

theorem identity43798 : scanCanonicalize (H12AffineFastState.compose env43798 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound43798 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43799 : List Nat := [2,2,8,1,0,0,2,2,1,2,1,0,9,0,0,3,1,1,2,1,0,11,0,3,2,1,11,1,1,1,3,1,3,1,1,1]

theorem envBound43799 : H12AffineFastState.Bounded env43799 := by
  intro p hp
  have h : env43799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43798_43799 : H12AffineEnvironment.transform 1 2 env43798 = env43799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env43798 == env43799) = true)

def env43800 : List Nat := [2,4,8,16,32,0,128,256,512,273,2048,773,2317,0,2065,947,2944,819,517,2064,773,648,2945,947,2704,2181,303,2961,1,416,2305,2309,257,2944,16,276]

theorem envBound43800 : H12AffineFastState.Bounded env43800 := by
  intro p hp
  have h : env43800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43785_43800 : H12AffineEnvironment.transform 12 2317 env43785 = env43800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2317 env43785 == env43800) = true)

def env43801 : List Nat := [2,4,8,16,16,0,128,256,512,273,2048,773,2317,0,2065,899,2944,771,517,2064,773,648,2945,899,2704,2181,287,2961,1,400,2305,2309,257,2944,16,276]

theorem envBound43801 : H12AffineFastState.Bounded env43801 := by
  intro p hp
  have h : env43801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43800_43801 : H12AffineEnvironment.transform 4 16 env43800 = env43801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env43800 == env43801) = true)

theorem identity43801 : scanCanonicalize (H12AffineFastState.compose env43801 (packedSelected [2,4,7,10,11,15,16,17,18,19,20] rootPS)) = affineNative (2^(8+1) ^^^ 395) := by decide +kernel

theorem selectedBound43801 : packedSelected [2,4,7,10,11,15,16,17,18,19,20] rootPS < 2^1333 := by decide +kernel

def env43802 : List Nat := [2,4,8,16,16,0,128,256,395,273,2048,142,2317,0,2065,8,2059,136,398,2064,142,259,2058,8,2331,2181,287,2074,1,400,2305,2309,257,2059,16,276]

theorem envBound43802 : H12AffineFastState.Bounded env43802 := by
  intro p hp
  have h : env43802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43801_43802 : H12AffineEnvironment.transform 8 395 env43801 = env43802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 395 env43801 == env43802) = true)

theorem identity43802 : scanCanonicalize (H12AffineFastState.compose env43802 (packedSelected [0,2,3,4,5,7,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 152) := by decide +kernel

theorem selectedBound43802 : packedSelected [0,2,3,4,5,7,9,11] rootPS < 2^1333 := by decide +kernel

def env43803 : List Nat := [2,4,8,16,16,0,128,256,395,273,152,142,405,0,137,8,147,136,398,136,142,259,146,8,387,29,287,130,1,400,409,413,257,147,16,276]

theorem envBound43803 : H12AffineFastState.Bounded env43803 := by
  intro p hp
  have h : env43803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43802_43803 : H12AffineEnvironment.transform 10 152 env43802 = env43803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 152 env43802 == env43803) = true)

theorem identity43803 : scanCanonicalize (H12AffineFastState.compose env43803 (packedSelected [2,3,7,8,9,10,13] rootPS)) = affineNative (2^(7+1) ^^^ 129) := by decide +kernel

theorem selectedBound43803 : packedSelected [2,3,7,8,9,10,13] rootPS < 2^1333 := by decide +kernel

def env43804 : List Nat := [2,4,8,16,16,0,128,129,10,144,152,142,20,0,137,8,147,136,15,136,142,130,146,8,2,29,158,130,1,17,24,28,128,147,16,149]

theorem envBound43804 : H12AffineFastState.Bounded env43804 := by
  intro p hp
  have h : env43804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43803_43804 : H12AffineEnvironment.transform 7 129 env43803 = env43804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 129 env43803 == env43804) = true)

theorem identity43804 : scanCanonicalize (H12AffineFastState.compose env43804 (packedSelected [1,2,5] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound43804 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env43805 : List Nat := [2,4,8,16,16,0,25,24,10,9,1,23,20,0,16,8,10,17,15,17,23,27,11,8,2,29,7,27,1,17,24,28,25,10,16,12]

theorem envBound43805 : H12AffineFastState.Bounded env43805 := by
  intro p hp
  have h : env43805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43804_43805 : H12AffineEnvironment.transform 6 25 env43804 = env43805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env43804 == env43805) = true)

theorem identity43805 : scanCanonicalize (H12AffineFastState.compose env43805 (packedSelected [1,2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound43805 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env43806 : List Nat := [2,4,8,1,1,0,8,9,10,9,1,6,5,0,1,8,10,0,15,0,6,10,11,8,2,12,7,10,1,0,9,13,8,10,1,12]

theorem envBound43806 : H12AffineFastState.Bounded env43806 := by
  intro p hp
  have h : env43806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43805_43806 : H12AffineEnvironment.transform 3 1 env43805 = env43806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env43805 == env43806) = true)

theorem identity43806 : scanCanonicalize (H12AffineFastState.compose env43806 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound43806 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env43807 : List Nat := [2,4,3,1,1,0,3,2,1,2,1,6,5,0,1,3,1,0,4,0,6,1,0,3,2,7,7,1,1,0,2,6,3,1,1,7]

theorem envBound43807 : H12AffineFastState.Bounded env43807 := by
  intro p hp
  have h : env43807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43806_43807 : H12AffineEnvironment.transform 2 3 env43806 = env43807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env43806 == env43807) = true)

theorem identity43807 : scanCanonicalize (H12AffineFastState.compose env43807 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound43807 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43808 : List Nat := [2,2,3,1,1,0,3,2,1,2,1,0,3,0,1,3,1,0,2,0,0,1,0,3,2,1,1,1,1,0,2,0,3,1,1,1]

theorem envBound43808 : H12AffineFastState.Bounded env43808 := by
  intro p hp
  have h : env43808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43807_43808 : H12AffineEnvironment.transform 1 2 env43807 = env43808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env43807 == env43808) = true)

def env43809 : List Nat := [2,4,8,16,17,0,128,256,512,273,2048,773,2317,0,2065,898,2944,770,517,2064,773,648,2945,898,2704,2181,286,2961,1,401,2305,2309,257,2944,16,276]

theorem envBound43809 : H12AffineFastState.Bounded env43809 := by
  intro p hp
  have h : env43809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43800_43809 : H12AffineEnvironment.transform 4 17 env43800 = env43809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env43800 == env43809) = true)

theorem identity43809 : scanCanonicalize (H12AffineFastState.compose env43809 (packedSelected [2,4,7,10,11,15,16,17,18,19,20] rootPS)) = affineNative (2^(8+1) ^^^ 397) := by decide +kernel

theorem selectedBound43809 : packedSelected [2,4,7,10,11,15,16,17,18,19,20] rootPS < 2^1333 := by decide +kernel

def env43810 : List Nat := [2,4,8,16,17,0,128,256,397,273,2048,136,2317,0,2065,15,2061,143,392,2064,136,261,2060,15,2333,2181,286,2076,1,401,2305,2309,257,2061,16,276]

theorem envBound43810 : H12AffineFastState.Bounded env43810 := by
  intro p hp
  have h : env43810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43809_43810 : H12AffineEnvironment.transform 8 397 env43809 = env43810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 397 env43809 == env43810) = true)

theorem identity43810 : scanCanonicalize (H12AffineFastState.compose env43810 (packedSelected [2,7,9,11,12,18] rootPS)) = affineNative (2^(10+1) ^^^ 260) := by decide +kernel

theorem selectedBound43810 : packedSelected [2,7,9,11,12,18] rootPS < 2^1333 := by decide +kernel

def env43811 : List Nat := [2,4,8,16,17,0,128,256,397,273,260,136,9,0,277,15,265,143,392,276,136,261,264,15,25,385,286,280,1,401,5,1,257,265,16,276]

theorem envBound43811 : H12AffineFastState.Bounded env43811 := by
  intro p hp
  have h : env43811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43810_43811 : H12AffineEnvironment.transform 10 260 env43810 = env43811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env43810 == env43811) = true)

theorem identity43811 : scanCanonicalize (H12AffineFastState.compose env43811 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 31) := by decide +kernel

theorem selectedBound43811 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env43812 : List Nat := [2,4,8,16,17,0,128,31,146,14,27,136,9,0,10,15,22,143,151,11,136,26,23,15,25,158,1,7,1,142,5,1,30,22,16,11]

theorem envBound43812 : H12AffineFastState.Bounded env43812 := by
  intro p hp
  have h : env43812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43811_43812 : H12AffineEnvironment.transform 7 31 env43811 = env43812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 31 env43811 == env43812) = true)

theorem identity43812 : scanCanonicalize (H12AffineFastState.compose env43812 (packedSelected [0,2,4] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound43812 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env43813 : List Nat := [2,4,8,16,17,0,8,31,26,14,27,0,9,0,10,15,22,7,31,11,0,26,23,15,25,22,1,7,1,6,5,1,30,22,16,11]

theorem envBound43813 : H12AffineFastState.Bounded env43813 := by
  intro p hp
  have h : env43813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43812_43813 : H12AffineEnvironment.transform 6 8 env43812 = env43813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env43812 == env43813) = true)

def env43814 : List Nat := [2,4,8,16,32,1,128,256,512,273,2048,773,8192,0,8477,65536,74047,65664,516,8476,773,648,74047,65537,9116,74299,302,74031,1,76575,8204,8200,257,74046,17,277]

theorem envBound43814 : H12AffineFastState.Bounded env43814 := by
  intro p hp
  have h : env43814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43783_43814 : H12AffineEnvironment.transform 5 1 env43783 = env43814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env43783 == env43814) = true)

theorem identity43814 : scanCanonicalize (H12AffineFastState.compose env43814 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 9130) := by decide +kernel

theorem selectedBound43814 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env43815 : List Nat := [2,4,8,16,32,1,128,256,512,273,2048,773,8192,0,8477,9130,661,9002,516,8476,773,648,661,9131,9116,401,302,645,1,2229,8204,8200,257,660,17,277]

theorem envBound43815 : H12AffineFastState.Bounded env43815 := by
  intro p hp
  have h : env43815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43814_43815 : H12AffineEnvironment.transform 15 9130 env43814 = env43815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9130 env43814 == env43815) = true)

def env43816 : List Nat := [2,4,8,16,32,1,128,256,512,273,2048,773,24,0,261,946,661,818,516,260,773,648,661,947,900,401,302,645,1,2229,20,16,257,660,17,277]

theorem envBound43816 : H12AffineFastState.Bounded env43816 := by
  intro p hp
  have h : env43816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43815_43816 : H12AffineEnvironment.transform 12 24 env43815 = env43816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env43815 == env43816) = true)

theorem identity43816 : scanCanonicalize (H12AffineFastState.compose env43816 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound43816 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env43817 : List Nat := [2,4,8,16,32,1,128,256,17,273,2048,276,24,0,261,419,132,291,21,260,276,153,132,418,405,401,302,148,1,2229,20,16,257,133,17,277]

theorem envBound43817 : H12AffineFastState.Bounded env43817 := by
  intro p hp
  have h : env43817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43816_43817 : H12AffineEnvironment.transform 8 17 env43816 = env43817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env43816 == env43817) = true)

theorem identity43817 : scanCanonicalize (H12AffineFastState.compose env43817 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 144) := by decide +kernel

theorem selectedBound43817 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env43818 : List Nat := [2,4,8,16,32,1,128,144,17,129,2048,132,24,0,149,51,132,179,21,148,132,153,132,50,5,1,190,148,1,2229,20,16,145,133,17,133]

theorem envBound43818 : H12AffineFastState.Bounded env43818 := by
  intro p hp
  have h : env43818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43817_43818 : H12AffineEnvironment.transform 7 144 env43817 = env43818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 144 env43817 == env43818) = true)

theorem identity43818 : scanCanonicalize (H12AffineFastState.compose env43818 (packedSelected [1,2,12] rootPS)) = affineNative (2^(6+1) ^^^ 47) := by decide +kernel

theorem selectedBound43818 : packedSelected [1,2,12] rootPS < 2^1333 := by decide +kernel

def env43819 : List Nat := [2,4,8,16,32,1,47,63,17,46,2048,43,24,0,58,51,43,28,21,59,43,54,43,50,5,1,17,59,1,2074,20,16,62,42,17,42]

theorem envBound43819 : H12AffineFastState.Bounded env43819 := by
  intro p hp
  have h : env43819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43818_43819 : H12AffineEnvironment.transform 6 47 env43818 = env43819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 47 env43818 == env43819) = true)

theorem identity43819 : scanCanonicalize (H12AffineFastState.compose env43819 (packedSelected [0,3,5,7,10,11] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound43819 : packedSelected [0,3,5,7,10,11] rootPS < 2^1333 := by decide +kernel

def env43820 : List Nat := [2,4,8,16,10,1,5,21,17,4,2048,1,24,0,16,25,1,28,21,17,1,28,1,24,5,1,17,17,1,2074,20,16,20,0,17,0]

theorem envBound43820 : H12AffineFastState.Bounded env43820 := by
  intro p hp
  have h : env43820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43819_43820 : H12AffineEnvironment.transform 4 10 env43819 = env43820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env43819 == env43820) = true)

theorem identity43820 : scanCanonicalize (H12AffineFastState.compose env43820 (packedSelected [2,3] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound43820 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env43821 : List Nat := [2,4,8,6,10,1,5,3,7,4,2048,1,14,0,6,15,1,10,3,7,1,10,1,14,5,1,7,7,1,2060,2,6,2,0,7,0]

theorem envBound43821 : H12AffineFastState.Bounded env43821 := by
  intro p hp
  have h : env43821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43820_43821 : H12AffineEnvironment.transform 3 6 env43820 = env43821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env43820 == env43821) = true)

theorem identity43821 : scanCanonicalize (H12AffineFastState.compose env43821 (packedSelected [0,4] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound43821 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env43822 : List Nat := [2,4,4,6,6,1,5,3,7,4,2048,1,2,0,6,3,1,6,3,7,1,6,1,2,5,1,7,7,1,2048,2,6,2,0,7,0]

theorem envBound43822 : H12AffineFastState.Bounded env43822 := by
  intro p hp
  have h : env43822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43821_43822 : H12AffineEnvironment.transform 2 4 env43821 = env43822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env43821 == env43822) = true)

theorem identity43822 : scanCanonicalize (H12AffineFastState.compose env43822 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound43822 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43823 : List Nat := [2,4,4,6,6,1,5,3,7,4,0,1,2,0,6,3,1,6,3,7,1,6,1,2,5,1,7,7,1,0,2,6,2,0,7,0]

theorem envBound43823 : H12AffineFastState.Bounded env43823 := by
  intro p hp
  have h : env43823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43822_43823 : H12AffineEnvironment.transform 10 0 env43822 = env43823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env43822 == env43823) = true)

theorem identity43823 : scanCanonicalize (H12AffineFastState.compose env43823 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound43823 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43824 : List Nat := [2,2,2,0,0,1,3,3,1,2,0,1,2,0,0,3,1,0,3,1,1,0,1,2,3,1,1,1,1,0,2,0,2,0,1,0]

theorem envBound43824 : H12AffineFastState.Bounded env43824 := by
  intro p hp
  have h : env43824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43823_43824 : H12AffineEnvironment.transform 1 2 env43823 = env43824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env43823 == env43824) = true)

theorem identity43824 : scanCanonicalize (H12AffineFastState.compose env43824 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound43824 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43825 : List Nat := [1,1,1,0,0,1,0,0,1,1,0,1,1,0,0,0,1,0,0,1,1,0,1,1,0,1,1,1,1,0,1,0,1,0,1,0]

theorem envBound43825 : H12AffineFastState.Bounded env43825 := by
  intro p hp
  have h : env43825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43824_43825 : H12AffineEnvironment.transform 0 1 env43824 = env43825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env43824 == env43825) = true)

def env43826 : List Nat := [2,4,8,16,32,1,128,256,512,273,2048,773,25,0,260,947,661,819,516,261,773,648,661,946,901,401,302,645,1,2229,21,17,257,660,17,277]

theorem envBound43826 : H12AffineFastState.Bounded env43826 := by
  intro p hp
  have h : env43826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43815_43826 : H12AffineEnvironment.transform 12 25 env43815 = env43826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env43815 == env43826) = true)

theorem identity43826 : scanCanonicalize (H12AffineFastState.compose env43826 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound43826 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env43827 : List Nat := [2,4,8,16,32,1,128,4,512,21,2048,513,25,0,0,695,661,567,516,1,513,648,661,694,641,149,42,645,1,2229,21,17,5,660,17,17]

theorem envBound43827 : H12AffineFastState.Bounded env43827 := by
  intro p hp
  have h : env43827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43826_43827 : H12AffineEnvironment.transform 7 4 env43826 = env43827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env43826 == env43827) = true)

theorem identity43827 : scanCanonicalize (H12AffineFastState.compose env43827 (packedSelected [3,11,15,18] rootPS)) = affineNative (2^(4+1) ^^^ 28) := by decide +kernel

theorem selectedBound43827 : packedSelected [3,11,15,18] rootPS < 2^1333 := by decide +kernel

def env43828 : List Nat := [2,4,8,16,28,1,128,4,512,21,2048,513,25,0,0,651,661,523,516,1,513,648,661,650,641,149,22,645,1,2185,21,17,5,660,17,17]

theorem envBound43828 : H12AffineFastState.Bounded env43828 := by
  intro p hp
  have h : env43828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43827_43828 : H12AffineEnvironment.transform 4 28 env43827 = env43828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 28 env43827 == env43828) = true)

theorem identity43828 : scanCanonicalize (H12AffineFastState.compose env43828 (packedSelected [0,2,5,7,10,12,16,17] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound43828 : packedSelected [0,2,5,7,10,12,16,17] rootPS < 2^1333 := by decide +kernel

def env43829 : List Nat := [2,4,8,16,28,1,128,4,512,21,11,513,25,0,0,651,661,523,516,1,513,648,661,650,641,149,22,645,1,130,21,17,5,660,17,17]

theorem envBound43829 : H12AffineFastState.Bounded env43829 := by
  intro p hp
  have h : env43829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43828_43829 : H12AffineEnvironment.transform 10 11 env43828 = env43829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env43828 == env43829) = true)

theorem identity43829 : scanCanonicalize (H12AffineFastState.compose env43829 (packedSelected [0,2,7,10] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound43829 : packedSelected [0,2,7,10] rootPS < 2^1333 := by decide +kernel

def env43830 : List Nat := [2,4,8,12,0,1,128,4,512,9,11,513,5,0,0,651,649,523,516,1,513,648,649,650,641,137,10,645,1,130,9,13,5,648,13,13]

theorem envBound43830 : H12AffineFastState.Bounded env43830 := by
  intro p hp
  have h : env43830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43829_43830 : H12AffineEnvironment.transform 3 12 env43829 = env43830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env43829 == env43830) = true)

theorem identity43830 : scanCanonicalize (H12AffineFastState.compose env43830 (packedSelected [1,3,5] rootPS)) = affineNative (2^(8+1) ^^^ 13) := by decide +kernel

theorem selectedBound43830 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env43831 : List Nat := [2,4,8,12,0,1,128,4,13,9,11,12,5,0,0,134,132,6,9,1,12,133,132,135,140,137,10,136,1,130,9,13,5,133,13,13]

theorem envBound43831 : H12AffineFastState.Bounded env43831 := by
  intro p hp
  have h : env43831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43830_43831 : H12AffineEnvironment.transform 8 13 env43830 = env43831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 13 env43830 == env43831) = true)

theorem identity43831 : scanCanonicalize (H12AffineFastState.compose env43831 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound43831 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43832 : List Nat := [2,2,8,10,0,1,128,2,11,9,11,10,3,0,0,128,130,0,9,1,10,131,130,129,138,137,10,136,1,130,9,11,3,131,11,11]

theorem envBound43832 : H12AffineFastState.Bounded env43832 := by
  intro p hp
  have h : env43832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43831_43832 : H12AffineEnvironment.transform 1 2 env43831 = env43832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env43831 == env43832) = true)

def env43833 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74863,65665,4416,8541,4096,5276,74047,66897,13769,78895,1151,74814,1296,81226,8204,8200,257,74799,1345,5952]

theorem envBound43833 : H12AffineFastState.Bounded env43833 := by
  intro p hp
  have h : env43833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43741_43833 : H12AffineEnvironment.transform 17 65665 env43741 = env43833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env43741 == env43833) = true)

theorem identity43833 : scanCanonicalize (H12AffineFastState.compose env43833 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound43833 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env43834 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,8192,1297,8540,65536,74863,65665,272,8541,80,1228,74047,66897,9625,74879,1151,74814,1296,77082,8204,8200,257,74799,1345,1808]

theorem envBound43834 : H12AffineFastState.Bounded env43834 := by
  intro p hp
  have h : env43834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43833_43834 : H12AffineEnvironment.transform 11 80 env43833 = env43834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env43833 == env43834) = true)

def env43835 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,80,8192,81,8540,65536,74031,65665,272,8541,80,396,74047,65553,8409,74047,319,74110,80,75866,8204,8200,257,74095,1,592]

theorem envBound43835 : H12AffineFastState.Bounded env43835 := by
  intro p hp
  have h : env43835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43834_43835 : H12AffineEnvironment.transform 9 320 env43834 = env43835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env43834 == env43835) = true)

theorem identity43835 : scanCanonicalize (H12AffineFastState.compose env43835 (packedSelected [7,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound43835 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env43836 : List Nat := [2,4,8,16,32,64,128,68,512,4,2048,80,8192,81,8216,65536,73835,65665,84,8217,80,200,73851,65553,8409,73851,123,73786,80,75866,8204,8200,69,73771,1,592]

theorem envBound43836 : H12AffineFastState.Bounded env43836 := by
  intro p hp
  have h : env43836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43835_43836 : H12AffineEnvironment.transform 7 68 env43835 = env43836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env43835 == env43836) = true)

theorem identity43836 : scanCanonicalize (H12AffineFastState.compose env43836 (packedSelected [0,1,4,7,8,9,16,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 8298) := by decide +kernel

theorem selectedBound43836 : packedSelected [0,1,4,7,8,9,16,19,20] rootPS < 2^1333 := by decide +kernel

def env43837 : List Nat := [2,4,8,16,32,64,128,68,512,4,2048,80,8192,81,8216,8298,1,8427,84,8217,80,200,17,8315,8409,17,123,80,80,2096,8204,8200,69,65,1,592]

theorem envBound43837 : H12AffineFastState.Bounded env43837 := by
  intro p hp
  have h : env43837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43836_43837 : H12AffineEnvironment.transform 15 8298 env43836 = env43837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8298 env43836 == env43837) = true)

theorem identity43837 : scanCanonicalize (H12AffineFastState.compose env43837 (packedSelected [0,1,3,5,7,8,13,17,18] rootPS)) = affineNative (2^(12+1) ^^^ 2050) := by decide +kernel

theorem selectedBound43837 : packedSelected [0,1,3,5,7,8,13,17,18] rootPS < 2^1333 := by decide +kernel

def env43838 : List Nat := [2,4,8,16,32,64,128,68,512,4,2048,80,2050,81,2074,2152,1,2281,84,2075,80,200,17,2169,2267,17,123,80,80,2096,2062,2058,69,65,1,592]

theorem envBound43838 : H12AffineFastState.Bounded env43838 := by
  intro p hp
  have h : env43838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43837_43838 : H12AffineEnvironment.transform 12 2050 env43837 = env43838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2050 env43837 == env43838) = true)

theorem identity43838 : scanCanonicalize (H12AffineFastState.compose env43838 (packedSelected [1,5,12,13,15,17] rootPS)) = affineNative (2^(8+1) ^^^ 232) := by decide +kernel

theorem selectedBound43838 : packedSelected [1,5,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env43839 : List Nat := [2,4,8,16,32,64,128,68,232,4,2048,80,2050,81,2074,2152,1,2281,84,2075,80,200,17,2169,2267,17,123,80,80,2096,2062,2058,69,65,1,184]

theorem envBound43839 : H12AffineFastState.Bounded env43839 := by
  intro p hp
  have h : env43839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43838_43839 : H12AffineEnvironment.transform 8 232 env43838 = env43839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 232 env43838 == env43839) = true)

theorem identity43839 : scanCanonicalize (H12AffineFastState.compose env43839 (packedSelected [1,2,8,12,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 136) := by decide +kernel

theorem selectedBound43839 : packedSelected [1,2,8,12,13,15] rootPS < 2^1333 := by decide +kernel

def env43840 : List Nat := [2,4,8,16,32,64,128,68,232,4,136,80,138,81,146,224,1,97,84,147,80,200,17,241,83,17,123,80,80,184,134,130,69,65,1,184]

theorem envBound43840 : H12AffineFastState.Bounded env43840 := by
  intro p hp
  have h : env43840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart2