import H12CloudChart2Data147

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans36855_36856 : H12AffineEnvironment.transform 7 66 env36855 = env36856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 66 env36855 == env36856) = true)

theorem identity36856 : scanCanonicalize (H12AffineFastState.compose env36856 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 65) := by decide +kernel

theorem selectedBound36856 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36857 : List Nat := [2,4,2,0,7,64,2,66,65,3,65,71,67,64,70,3,1,0,69,71,71,65,1,3,4,7,65,65,64,71,68,64,67,65,1,7]

theorem envBound36857 : H12AffineFastState.Bounded env36857 := by
  intro p hp
  have h : env36857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36856_36857 : H12AffineEnvironment.transform 10 65 env36856 = env36857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 65 env36856 == env36857) = true)

theorem identity36857 : scanCanonicalize (H12AffineFastState.compose env36857 (packedSelected [2,3] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound36857 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env36858 : List Nat := [2,4,2,0,7,1,2,3,0,3,0,6,2,1,7,3,1,0,4,6,6,0,1,3,4,7,0,0,1,6,5,1,2,0,1,7]

theorem envBound36858 : H12AffineFastState.Bounded env36858 := by
  intro p hp
  have h : env36858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36857_36858 : H12AffineEnvironment.transform 5 1 env36857 = env36858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env36857 == env36858) = true)

theorem identity36858 : scanCanonicalize (H12AffineFastState.compose env36858 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound36858 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36859 : List Nat := [2,2,2,0,1,1,2,3,0,3,0,0,2,1,1,3,1,0,2,0,0,0,1,3,2,1,0,0,1,0,3,1,2,0,1,1]

theorem envBound36859 : H12AffineFastState.Bounded env36859 := by
  intro p hp
  have h : env36859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36858_36859 : H12AffineEnvironment.transform 1 2 env36858 = env36859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env36858 == env36859) = true)

theorem identity36859 : scanCanonicalize (H12AffineFastState.compose env36859 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound36859 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36860 : List Nat := [1,1,1,0,1,1,1,0,0,0,0,0,1,1,1,0,1,0,1,0,0,0,1,0,1,1,0,0,1,0,0,1,1,0,1,1]

theorem envBound36860 : H12AffineFastState.Bounded env36860 := by
  intro p hp
  have h : env36860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36859_36860 : H12AffineEnvironment.transform 0 1 env36859 = env36860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env36859 == env36860) = true)

def env36861 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,16777216,533641,672784,17245633,148801,545088,96347,16876545,17495099,257,131136,1345,525824]

theorem envBound36861 : H12AffineFastState.Bounded env36861 := by
  intro p hp
  have h : env36861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36212_36861 : H12AffineEnvironment.transform 26 17245633 env36212 = env36861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245633 env36212 == env36861) = true)

theorem identity36861 : scanCanonicalize (H12AffineFastState.compose env36861 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(18+1) ^^^ 95615) := by decide +kernel

theorem selectedBound36861 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env36862 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95615,32769,4096,61649,147520,16777216,86518,209263,17245633,148801,74815,96347,16876545,17006916,257,131136,1345,95103]

theorem envBound36862 : H12AffineFastState.Bounded env36862 := by
  intro p hp
  have h : env36862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36861_36862 : H12AffineEnvironment.transform 18 95615 env36861 = env36862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 95615 env36861 == env36862) = true)

def env36863 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95615,32769,4096,61649,147520,284032,86518,209263,225345,148801,74815,96347,381313,513220,257,131136,1345,95103]

theorem envBound36863 : H12AffineFastState.Bounded env36863 := by
  intro p hp
  have h : env36863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36862_36863 : H12AffineEnvironment.transform 23 284032 env36862 = env36863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 284032 env36862 == env36863) = true)

def env36864 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16464,262144,95615,32769,4096,61649,16,284032,86518,94527,77841,1297,74815,96347,381313,365716,257,16400,1345,95103]

theorem envBound36864 : H12AffineFastState.Bounded env36864 := by
  intro p hp
  have h : env36864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36863_36864 : H12AffineEnvironment.transform 16 16464 env36863 = env36864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16464 env36863 == env36864) = true)

def env36865 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1344,262144,77935,32769,4096,46529,16,266384,70886,78895,77841,1297,74815,81227,365713,365716,257,1280,1345,79471]

theorem envBound36865 : H12AffineFastState.Bounded env36865 := by
  intro p hp
  have h : env36865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36864_36865 : H12AffineEnvironment.transform 13 1296 env36864 = env36865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env36864 == env36865) = true)

theorem identity36865 : scanCanonicalize (H12AffineFastState.compose env36865 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32882) := by decide +kernel

theorem selectedBound36865 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env36866 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,32882,1344,262144,45085,32769,4096,46529,16,266384,38036,46173,45155,1297,42061,48441,267491,267494,257,1280,1345,46621]

theorem envBound36866 : H12AffineFastState.Bounded env36866 := by
  intro p hp
  have h : env36866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36865_36866 : H12AffineEnvironment.transform 15 32882 env36865 = env36866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32882 env36865 == env36866) = true)

def env36867 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32882,1344,262144,42333,32769,1344,41089,16,263632,33236,41245,42275,1297,42061,43129,262563,262566,257,1280,1345,41821]

theorem envBound36867 : H12AffineFastState.Bounded env36867 := by
  intro p hp
  have h : env36867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36866_36867 : H12AffineEnvironment.transform 11 1344 env36866 = env36867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env36866 == env36867) = true)

theorem identity36867 : scanCanonicalize (H12AffineFastState.compose env36867 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 276) := by decide +kernel

theorem selectedBound36867 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env36868 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,276,358,1344,262144,9289,277,1344,8597,16,263632,192,8201,9271,1297,9561,10605,262563,262566,257,1280,1345,8777]

theorem envBound36868 : H12AffineFastState.Bounded env36868 := by
  intro p hp
  have h : env36868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36867_36868 : H12AffineEnvironment.transform 14 276 env36867 = env36868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 276 env36867 == env36868) = true)

theorem identity36868 : scanCanonicalize (H12AffineFastState.compose env36868 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(17+1) ^^^ 2003) := by decide +kernel

theorem selectedBound36868 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env36869 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,276,358,1344,2003,9289,277,1344,8597,16,515,192,8201,9271,1297,9561,10605,1648,1653,257,1280,1345,8777]

theorem envBound36869 : H12AffineFastState.Bounded env36869 := by
  intro p hp
  have h : env36869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36868_36869 : H12AffineEnvironment.transform 17 2003 env36868 = env36869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2003 env36868 == env36869) = true)

def env36870 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32882,1344,262144,42332,32769,1345,41088,16,263633,33237,41244,42274,1297,42061,43128,262562,262567,257,1280,1345,41820]

theorem envBound36870 : H12AffineFastState.Bounded env36870 := by
  intro p hp
  have h : env36870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36866_36870 : H12AffineEnvironment.transform 11 1345 env36866 = env36870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env36866 == env36870) = true)

theorem identity36870 : scanCanonicalize (H12AffineFastState.compose env36870 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 487) := by decide +kernel

theorem selectedBound36870 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env36871 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32882,1344,487,42332,32769,1345,41088,16,1078,33237,41244,42274,1297,42061,43128,69,64,257,1280,1345,41820]

theorem envBound36871 : H12AffineFastState.Bounded env36871 := by
  intro p hp
  have h : env36871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36870_36871 : H12AffineEnvironment.transform 17 487 env36870 = env36871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 487 env36870 == env36871) = true)

theorem identity36871 : scanCanonicalize (H12AffineFastState.compose env36871 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound36871 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env36872 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,8540,8494,1344,487,1024,8541,1345,476,16,1078,8329,64,1150,1297,1297,2340,69,64,257,1280,1345,512]

theorem envBound36872 : H12AffineFastState.Bounded env36872 := by
  intro p hp
  have h : env36872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36871_36872 : H12AffineEnvironment.transform 14 8540 env36871 = env36872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env36871 == env36872) = true)

theorem identity36872 : scanCanonicalize (H12AffineFastState.compose env36872 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 84) := by decide +kernel

theorem selectedBound36872 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env36873 : List Nat := [2,4,8,16,32,64,128,256,512,84,2048,277,8192,324,8540,8494,276,487,84,8541,277,476,16,98,8329,64,42,325,325,2340,69,64,257,340,277,512]

theorem envBound36873 : H12AffineFastState.Bounded env36873 := by
  intro p hp
  have h : env36873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36872_36873 : H12AffineEnvironment.transform 9 84 env36872 = env36873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env36872 == env36873) = true)

theorem identity36873 : scanCanonicalize (H12AffineFastState.compose env36873 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 900) := by decide +kernel

theorem selectedBound36873 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env36874 : List Nat := [2,4,8,16,32,64,128,256,512,84,2048,277,900,324,728,682,276,487,84,729,277,476,16,98,781,64,42,325,325,2340,69,64,257,340,277,512]

theorem envBound36874 : H12AffineFastState.Bounded env36874 := by
  intro p hp
  have h : env36874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36873_36874 : H12AffineEnvironment.transform 12 900 env36873 = env36874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 900 env36873 == env36874) = true)

theorem identity36874 : scanCanonicalize (H12AffineFastState.compose env36874 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound36874 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env36875 : List Nat := [2,4,8,16,32,17,128,256,512,5,2048,277,900,277,649,682,276,438,5,648,277,397,16,51,781,17,42,276,276,2340,20,17,257,261,277,512]

theorem envBound36875 : H12AffineFastState.Bounded env36875 := by
  intro p hp
  have h : env36875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36874_36875 : H12AffineEnvironment.transform 5 17 env36874 = env36875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env36874 == env36875) = true)

theorem identity36875 : scanCanonicalize (H12AffineFastState.compose env36875 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 318) := by decide +kernel

theorem selectedBound36875 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env36876 : List Nat := [2,4,8,16,32,17,128,256,512,5,318,277,900,277,649,682,276,438,5,648,277,397,16,51,781,17,42,276,276,26,20,17,257,261,277,512]

theorem envBound36876 : H12AffineFastState.Bounded env36876 := by
  intro p hp
  have h : env36876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36875_36876 : H12AffineEnvironment.transform 10 318 env36875 = env36876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 318 env36875 == env36876) = true)

theorem identity36876 : scanCanonicalize (H12AffineFastState.compose env36876 (packedSelected [1,4,5,9,11] rootPS)) = affineNative (2^(7+1) ^^^ 157) := by decide +kernel

theorem selectedBound36876 : packedSelected [1,4,5,9,11] rootPS < 2^1333 := by decide +kernel

def env36877 : List Nat := [2,4,8,16,32,17,128,157,512,5,163,136,537,136,649,682,137,43,5,648,136,16,16,51,656,17,42,137,137,26,20,17,156,152,136,512]

theorem envBound36877 : H12AffineFastState.Bounded env36877 := by
  intro p hp
  have h : env36877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36876_36877 : H12AffineEnvironment.transform 7 157 env36876 = env36877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 157 env36876 == env36877) = true)

theorem identity36877 : scanCanonicalize (H12AffineFastState.compose env36877 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound36877 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env36878 : List Nat := [2,4,8,16,16,17,128,157,512,5,147,136,537,136,649,666,137,27,5,648,136,16,16,3,656,17,26,137,137,26,20,17,156,152,136,512]

theorem envBound36878 : H12AffineFastState.Bounded env36878 := by
  intro p hp
  have h : env36878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36877_36878 : H12AffineEnvironment.transform 4 16 env36877 = env36878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env36877 == env36878) = true)

theorem identity36878 : scanCanonicalize (H12AffineFastState.compose env36878 (packedSelected [0,2,4] rootPS)) = affineNative (2^(8+1) ^^^ 146) := by decide +kernel

theorem selectedBound36878 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env36879 : List Nat := [2,4,8,16,16,17,128,157,146,5,147,136,139,136,27,8,137,27,5,26,136,16,16,3,2,17,26,137,137,26,20,17,156,152,136,146]

theorem envBound36879 : H12AffineFastState.Bounded env36879 := by
  intro p hp
  have h : env36879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36878_36879 : H12AffineEnvironment.transform 8 146 env36878 = env36879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 146 env36878 == env36879) = true)

theorem identity36879 : scanCanonicalize (H12AffineFastState.compose env36879 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound36879 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env36880 : List Nat := [2,4,8,16,16,17,19,14,1,5,0,27,24,27,27,8,26,27,5,26,27,16,16,3,2,17,26,26,26,26,20,17,15,11,27,1]

theorem envBound36880 : H12AffineFastState.Bounded env36880 := by
  intro p hp
  have h : env36880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36879_36880 : H12AffineEnvironment.transform 6 19 env36879 = env36880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env36879 == env36880) = true)

def env36881 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1345,262144,77934,32769,4096,46528,16,266385,70887,78894,77841,1297,74815,81226,365712,365716,257,1281,1345,79470]

theorem envBound36881 : H12AffineFastState.Bounded env36881 := by
  intro p hp
  have h : env36881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36864_36881 : H12AffineEnvironment.transform 13 1297 env36864 = env36881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env36864 == env36881) = true)

theorem identity36881 : scanCanonicalize (H12AffineFastState.compose env36881 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound36881 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env36882 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1345,262144,77934,13341,4096,476,16,266385,70887,78894,77841,1297,74815,81226,336012,336008,257,1281,1345,79470]

theorem envBound36882 : H12AffineFastState.Bounded env36882 := by
  intro p hp
  have h : env36882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36881_36882 : H12AffineEnvironment.transform 14 13340 env36881 = env36882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env36881 == env36882) = true)

def env36883 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1345,65664,77934,13341,4096,476,16,69649,70887,78894,77841,1297,74815,81226,8204,8200,257,1281,1345,79470]

theorem envBound36883 : H12AffineFastState.Bounded env36883 := by
  intro p hp
  have h : env36883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36882_36883 : H12AffineEnvironment.transform 17 65664 env36882 = env36883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env36882 == env36883) = true)

theorem identity36883 : scanCanonicalize (H12AffineFastState.compose env36883 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9327) := by decide +kernel

theorem selectedBound36883 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env36884 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,9327,1345,9455,5121,13341,4096,476,16,13438,12424,4161,5246,1297,80,6437,8204,8200,257,1281,1345,4609]

theorem envBound36884 : H12AffineFastState.Bounded env36884 := by
  intro p hp
  have h : env36884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36883_36884 : H12AffineEnvironment.transform 15 9327 env36883 = env36884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9327 env36883 == env36884) = true)

def env36885 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1297,9244,9327,1345,9455,1025,9245,0,476,16,9342,8328,65,1150,1297,80,2341,8204,8200,257,1281,1345,513]

theorem envBound36885 : H12AffineFastState.Bounded env36885 := by
  intro p hp
  have h : env36885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36884_36885 : H12AffineEnvironment.transform 11 0 env36884 = env36885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env36884 == env36885) = true)

theorem identity36885 : scanCanonicalize (H12AffineFastState.compose env36885 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound36885 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env36886 : List Nat := [2,4,8,16,32,64,128,69,512,1024,2048,0,8192,1108,9244,9327,1028,9455,1025,9245,0,153,16,9342,8328,65,1150,1108,80,2144,8204,8200,68,1092,1028,513]

theorem envBound36886 : H12AffineFastState.Bounded env36886 := by
  intro p hp
  have h : env36886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36885_36886 : H12AffineEnvironment.transform 7 69 env36885 = env36886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env36885 == env36886) = true)

theorem identity36886 : scanCanonicalize (H12AffineFastState.compose env36886 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound36886 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env36887 : List Nat := [2,4,8,16,32,64,128,69,512,1024,2048,0,1052,1108,0,115,1028,243,1025,1,0,153,16,98,1172,65,1150,1108,80,2144,1040,1044,68,1092,1028,513]

theorem envBound36887 : H12AffineFastState.Bounded env36887 := by
  intro p hp
  have h : env36887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36886_36887 : H12AffineEnvironment.transform 12 1052 env36886 = env36887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env36886 == env36887) = true)

theorem identity36887 : scanCanonicalize (H12AffineFastState.compose env36887 (packedSelected [3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound36887 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env36888 : List Nat := [2,4,8,1,32,64,128,69,512,1024,2048,0,1037,1093,0,98,1028,226,1025,1,0,136,1,98,1157,65,1135,1093,65,2144,1025,1029,68,1092,1028,513]

theorem envBound36888 : H12AffineFastState.Bounded env36888 := by
  intro p hp
  have h : env36888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36887_36888 : H12AffineEnvironment.transform 3 1 env36887 = env36888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env36887 == env36888) = true)

theorem identity36888 : scanCanonicalize (H12AffineFastState.compose env36888 (packedSelected [1,2,3,5,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 1097) := by decide +kernel

theorem selectedBound36888 : packedSelected [1,2,3,5,13,15] rootPS < 2^1333 := by decide +kernel

def env36889 : List Nat := [2,4,8,1,32,64,128,69,512,1024,1097,0,1037,1093,0,98,1028,226,1025,1,0,136,1,98,1157,65,1135,1093,65,1065,1025,1029,68,1092,1028,513]

theorem envBound36889 : H12AffineFastState.Bounded env36889 := by
  intro p hp
  have h : env36889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36888_36889 : H12AffineEnvironment.transform 10 1097 env36888 = env36889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1097 env36888 == env36889) = true)

theorem identity36889 : scanCanonicalize (H12AffineFastState.compose env36889 (packedSelected [1,3,5,11,12,18] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound36889 : packedSelected [1,3,5,11,12,18] rootPS < 2^1333 := by decide +kernel

def env36890 : List Nat := [2,4,8,1,32,64,128,69,136,1024,1097,0,1037,1093,0,98,1028,226,1025,1,0,136,1,98,1157,65,1135,1093,65,1065,1025,1029,68,1092,1028,137]

theorem envBound36890 : H12AffineFastState.Bounded env36890 := by
  intro p hp
  have h : env36890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36889_36890 : H12AffineEnvironment.transform 8 136 env36889 = env36890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env36889 == env36890) = true)

theorem identity36890 : scanCanonicalize (H12AffineFastState.compose env36890 (packedSelected [1,2,3,12] rootPS)) = affineNative (2^(6+1) ^^^ 78) := by decide +kernel

theorem selectedBound36890 : packedSelected [1,2,3,12] rootPS < 2^1333 := by decide +kernel

def env36891 : List Nat := [2,4,8,1,32,64,78,69,70,1024,1097,0,1037,1093,0,98,1028,44,1025,1,0,70,1,98,1099,65,1135,1093,65,1065,1025,1029,68,1092,1028,71]

theorem envBound36891 : H12AffineFastState.Bounded env36891 := by
  intro p hp
  have h : env36891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36890_36891 : H12AffineEnvironment.transform 6 78 env36890 = env36891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 78 env36890 == env36891) = true)

theorem identity36891 : scanCanonicalize (H12AffineFastState.compose env36891 (packedSelected [1,2,4,8,9,11] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound36891 : packedSelected [1,2,4,8,9,11] rootPS < 2^1333 := by decide +kernel

def env36892 : List Nat := [2,4,8,1,6,64,78,69,70,1024,1097,0,1037,1093,0,68,1028,10,1025,1,0,70,1,68,1099,65,1097,1093,65,1039,1025,1029,68,1092,1028,71]

theorem envBound36892 : H12AffineFastState.Bounded env36892 := by
  intro p hp
  have h : env36892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36891_36892 : H12AffineEnvironment.transform 4 6 env36891 = env36892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env36891 == env36892) = true)

theorem identity36892 : scanCanonicalize (H12AffineFastState.compose env36892 (packedSelected [1,3,4,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 9) := by decide +kernel

theorem selectedBound36892 : packedSelected [1,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env36893 : List Nat := [2,4,8,1,6,64,78,69,70,9,64,0,4,76,0,68,13,10,8,1,0,70,1,68,66,65,64,76,65,6,8,12,68,77,13,71]

theorem envBound36893 : H12AffineFastState.Bounded env36893 := by
  intro p hp
  have h : env36893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36892_36893 : H12AffineEnvironment.transform 9 9 env36892 = env36893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 9 env36892 == env36893) = true)

theorem identity36893 : scanCanonicalize (H12AffineFastState.compose env36893 (packedSelected [0,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 4) := by decide +kernel

theorem selectedBound36893 : packedSelected [0,2,3] rootPS < 2^1333 := by decide +kernel

def env36894 : List Nat := [2,4,8,1,6,4,10,1,2,9,4,0,4,8,0,0,13,10,8,1,0,2,1,0,6,5,4,8,5,6,8,12,0,9,13,3]

theorem envBound36894 : H12AffineFastState.Bounded env36894 := by
  intro p hp
  have h : env36894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36893_36894 : H12AffineEnvironment.transform 5 4 env36893 = env36894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 4 env36893 == env36894) = true)

theorem identity36894 : scanCanonicalize (H12AffineFastState.compose env36894 (packedSelected [0,1,4] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound36894 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env36895 : List Nat := [2,2,8,1,0,2,10,1,2,9,2,0,2,8,0,0,11,10,8,1,0,2,1,0,0,3,2,8,3,0,8,10,0,9,11,3]

theorem envBound36895 : H12AffineFastState.Bounded env36895 := by
  intro p hp
  have h : env36895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36894_36895 : H12AffineEnvironment.transform 1 2 env36894 = env36895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env36894 == env36895) = true)

theorem identity36895 : scanCanonicalize (H12AffineFastState.compose env36895 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound36895 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36896 : List Nat := [1,1,8,1,0,1,9,1,1,9,1,0,1,8,0,0,8,9,8,1,0,1,1,0,0,0,1,8,0,0,8,9,0,9,8,0]

theorem envBound36896 : H12AffineFastState.Bounded env36896 := by
  intro p hp
  have h : env36896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36895_36896 : H12AffineEnvironment.transform 0 1 env36895 = env36896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env36895 == env36896) = true)

theorem identity36896 : scanCanonicalize (H12AffineFastState.compose env36896 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound36896 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36897 : List Nat := [1,1,0,1,0,1,1,1,1,1,1,0,1,0,0,0,0,1,0,1,0,1,1,0,0,0,1,0,0,0,0,1,0,1,0,0]

theorem envBound36897 : H12AffineFastState.Bounded env36897 := by
  intro p hp
  have h : env36897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36896_36897 : H12AffineEnvironment.transform 2 0 env36896 = env36897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env36896 == env36897) = true)

def env36898 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1297,9245,9327,1345,9455,1024,9244,1,476,16,9343,8329,64,1151,1297,80,2340,8204,8200,257,1281,1345,512]

theorem envBound36898 : H12AffineFastState.Bounded env36898 := by
  intro p hp
  have h : env36898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36884_36898 : H12AffineEnvironment.transform 11 1 env36884 = env36898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env36884 == env36898) = true)

theorem identity36898 : scanCanonicalize (H12AffineFastState.compose env36898 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound36898 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env36899 : List Nat := [2,4,8,16,32,64,128,21,512,1024,2048,1,8192,1028,9245,9327,1108,9455,1024,9244,1,201,16,9343,8329,64,1151,1028,80,2097,8204,8200,20,1044,1108,512]

theorem envBound36899 : H12AffineFastState.Bounded env36899 := by
  intro p hp
  have h : env36899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36898_36899 : H12AffineEnvironment.transform 7 21 env36898 = env36899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env36898 == env36899) = true)

theorem identity36899 : scanCanonicalize (H12AffineFastState.compose env36899 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound36899 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env36900 : List Nat := [2,4,8,16,32,64,128,21,512,4,2048,1,8192,0,8217,8299,80,8427,4,8216,1,201,16,8315,8329,64,123,0,80,2097,8204,8200,20,16,80,512]

theorem envBound36900 : H12AffineFastState.Bounded env36900 := by
  intro p hp
  have h : env36900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36899_36900 : H12AffineEnvironment.transform 9 4 env36899 = env36900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env36899 == env36900) = true)

theorem identity36900 : scanCanonicalize (H12AffineFastState.compose env36900 (packedSelected [0,1,2,3,5,7,8,10,13,18] rootPS)) = affineNative (2^(12+1) ^^^ 552) := by decide +kernel

theorem selectedBound36900 : packedSelected [0,1,2,3,5,7,8,10,13,18] rootPS < 2^1333 := by decide +kernel

def env36901 : List Nat := [2,4,8,16,32,64,128,21,512,4,2048,1,552,0,561,579,80,707,4,560,1,201,16,595,673,64,123,0,80,2097,548,544,20,16,80,512]

theorem envBound36901 : H12AffineFastState.Bounded env36901 := by
  intro p hp
  have h : env36901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36900_36901 : H12AffineEnvironment.transform 12 552 env36900 = env36901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 552 env36900 == env36901) = true)

theorem identity36901 : scanCanonicalize (H12AffineFastState.compose env36901 (packedSelected [0,3,7,8,11] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound36901 : packedSelected [0,3,7,8,11] rootPS < 2^1333 := by decide +kernel

def env36902 : List Nat := [2,4,8,16,32,64,128,21,137,4,2048,1,161,0,184,202,80,74,4,185,1,201,16,218,40,64,123,0,80,2097,173,169,20,16,80,137]

theorem envBound36902 : H12AffineFastState.Bounded env36902 := by
  intro p hp
  have h : env36902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36901_36902 : H12AffineEnvironment.transform 8 137 env36901 = env36902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env36901 == env36902) = true)

theorem identity36902 : scanCanonicalize (H12AffineFastState.compose env36902 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(10+1) ^^^ 194) := by decide +kernel

theorem selectedBound36902 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env36903 : List Nat := [2,4,8,16,32,64,128,21,137,4,194,1,161,0,184,202,80,74,4,185,1,201,16,218,40,64,123,0,80,243,173,169,20,16,80,137]

theorem envBound36903 : H12AffineFastState.Bounded env36903 := by
  intro p hp
  have h : env36903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36902_36903 : H12AffineEnvironment.transform 10 194 env36902 = env36903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 194 env36902 == env36903) = true)

theorem identity36903 : scanCanonicalize (H12AffineFastState.compose env36903 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound36903 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env36904 : List Nat := [2,4,8,16,32,32,128,21,137,4,162,1,161,0,184,170,48,42,4,185,1,169,16,186,40,32,27,0,48,147,173,169,20,16,48,137]

theorem envBound36904 : H12AffineFastState.Bounded env36904 := by
  intro p hp
  have h : env36904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36903_36904 : H12AffineEnvironment.transform 5 32 env36903 = env36904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env36903 == env36904) = true)

theorem identity36904 : scanCanonicalize (H12AffineFastState.compose env36904 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound36904 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36905 : List Nat := [2,4,8,10,32,32,128,15,137,4,162,1,161,0,162,170,42,42,4,163,1,169,10,160,40,32,1,0,42,137,173,169,14,10,42,137]

theorem envBound36905 : H12AffineFastState.Bounded env36905 := by
  intro p hp
  have h : env36905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36904_36905 : H12AffineEnvironment.transform 3 10 env36904 = env36905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env36904 == env36905) = true)

theorem identity36905 : scanCanonicalize (H12AffineFastState.compose env36905 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound36905 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env36906 : List Nat := [2,4,8,10,11,11,128,15,137,4,137,1,138,0,137,129,1,1,4,136,1,130,10,139,3,11,1,0,1,137,134,130,14,10,1,137]

theorem envBound36906 : H12AffineFastState.Bounded env36906 := by
  intro p hp
  have h : env36906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36905_36906 : H12AffineEnvironment.transform 4 11 env36905 = env36906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env36905 == env36906) = true)

theorem identity36906 : scanCanonicalize (H12AffineFastState.compose env36906 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound36906 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env36907 : List Nat := [2,4,8,10,11,11,9,15,0,4,0,1,3,0,0,8,1,1,4,1,1,11,10,2,3,11,1,0,1,0,15,11,14,10,1,0]

theorem envBound36907 : H12AffineFastState.Bounded env36907 := by
  intro p hp
  have h : env36907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36906_36907 : H12AffineEnvironment.transform 6 9 env36906 = env36907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env36906 == env36907) = true)

theorem identity36907 : scanCanonicalize (H12AffineFastState.compose env36907 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound36907 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36908 : List Nat := [2,2,8,10,11,11,9,9,0,2,0,1,3,0,0,8,1,1,2,1,1,11,10,2,3,11,1,0,1,0,9,11,8,10,1,0]

theorem envBound36908 : H12AffineFastState.Bounded env36908 := by
  intro p hp
  have h : env36908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36907_36908 : H12AffineEnvironment.transform 1 2 env36907 = env36908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env36907 == env36908) = true)

def env36909 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1345,65665,77934,13341,4096,476,16,69648,70887,78894,77841,1297,74815,81226,8205,8201,257,1281,1345,79470]

theorem envBound36909 : H12AffineFastState.Bounded env36909 := by
  intro p hp
  have h : env36909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36882_36909 : H12AffineEnvironment.transform 17 65665 env36882 = env36909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env36882 == env36909) = true)

theorem identity36909 : scanCanonicalize (H12AffineFastState.compose env36909 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12590) := by decide +kernel

theorem selectedBound36909 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env36910 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,12590,1345,12719,320,13341,4096,476,16,8510,9673,1280,319,1297,5393,3172,8205,8201,257,1281,1345,1856]

theorem envBound36910 : H12AffineFastState.Bounded env36910 := by
  intro p hp
  have h : env36910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36909_36910 : H12AffineEnvironment.transform 15 12590 env36909 = env36910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12590 env36909 == env36910) = true)

def env36911 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,81,12636,12590,1,12719,320,12637,4096,476,16,8510,8329,64,319,81,4177,2340,8205,8201,257,65,1,512]

theorem envBound36911 : H12AffineFastState.Bounded env36911 := by
  intro p hp
  have h : env36911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36910_36911 : H12AffineEnvironment.transform 9 320 env36910 = env36911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env36910 == env36911) = true)

theorem identity36911 : scanCanonicalize (H12AffineFastState.compose env36911 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound36911 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env36912 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,276,8192,81,8264,8250,1,8379,320,8265,276,476,16,8510,8329,64,319,81,325,2340,8205,8201,257,65,1,512]

theorem envBound36912 : H12AffineFastState.Bounded env36912 := by
  intro p hp
  have h : env36912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36911_36912 : H12AffineEnvironment.transform 11 276 env36911 = env36912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env36911 == env36912) = true)

theorem identity36912 : scanCanonicalize (H12AffineFastState.compose env36912 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound36912 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env36913 : List Nat := [2,4,8,16,32,64,128,68,512,4,2048,80,8192,81,8264,8250,1,8379,4,8265,80,152,16,8314,8329,64,123,81,1,2144,8205,8201,69,65,1,512]

theorem envBound36913 : H12AffineFastState.Bounded env36913 := by
  intro p hp
  have h : env36913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36912_36913 : H12AffineEnvironment.transform 7 68 env36912 = env36913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env36912 == env36913) = true)

theorem identity36913 : scanCanonicalize (H12AffineFastState.compose env36913 (packedSelected [10,11,17,18] rootPS)) = affineNative (2^(12+1) ^^^ 72) := by decide +kernel

theorem selectedBound36913 : packedSelected [10,11,17,18] rootPS < 2^1333 := by decide +kernel

def env36914 : List Nat := [2,4,8,16,32,64,128,68,512,4,2048,80,72,81,0,114,1,243,4,1,80,152,16,50,193,64,123,81,1,2144,69,65,69,65,1,512]

theorem envBound36914 : H12AffineFastState.Bounded env36914 := by
  intro p hp
  have h : env36914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36913_36914 : H12AffineEnvironment.transform 12 72 env36913 = env36914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env36913 == env36914) = true)

theorem identity36914 : scanCanonicalize (H12AffineFastState.compose env36914 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 181) := by decide +kernel

theorem selectedBound36914 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36915 : List Nat := [2,4,8,16,32,64,128,68,512,4,181,80,72,81,0,114,1,243,4,1,80,152,16,50,193,64,123,81,1,213,69,65,69,65,1,512]

theorem envBound36915 : H12AffineFastState.Bounded env36915 := by
  intro p hp
  have h : env36915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36914_36915 : H12AffineEnvironment.transform 10 181 env36914 = env36915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 181 env36914 == env36915) = true)

theorem identity36915 : scanCanonicalize (H12AffineFastState.compose env36915 (packedSelected [2,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound36915 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env36916 : List Nat := [2,4,8,16,32,64,56,68,512,4,13,80,72,81,0,114,1,75,4,1,80,32,16,50,121,64,123,81,1,109,69,65,69,65,1,512]

theorem envBound36916 : H12AffineFastState.Bounded env36916 := by
  intro p hp
  have h : env36916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36915_36916 : H12AffineEnvironment.transform 6 56 env36915 = env36916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env36915 == env36916) = true)

theorem identity36916 : scanCanonicalize (H12AffineFastState.compose env36916 (packedSelected [2,10] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound36916 : packedSelected [2,10] rootPS < 2^1333 := by decide +kernel

def env36917 : List Nat := [2,4,8,16,32,64,56,68,49,4,13,80,72,81,0,114,1,75,4,1,80,32,16,50,121,64,123,81,1,109,69,65,69,65,1,49]

theorem envBound36917 : H12AffineFastState.Bounded env36917 := by
  intro p hp
  have h : env36917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36916_36917 : H12AffineEnvironment.transform 8 49 env36916 = env36917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env36916 == env36917) = true)

theorem identity36917 : scanCanonicalize (H12AffineFastState.compose env36917 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound36917 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env36918 : List Nat := [2,4,8,16,32,17,56,21,49,4,13,1,25,0,0,35,1,26,4,1,1,32,16,50,40,17,42,0,1,60,20,16,20,16,1,49]

theorem envBound36918 : H12AffineFastState.Bounded env36918 := by
  intro p hp
  have h : env36918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36917_36918 : H12AffineEnvironment.transform 5 17 env36917 = env36918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env36917 == env36918) = true)

theorem identity36918 : scanCanonicalize (H12AffineFastState.compose env36918 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound36918 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36919 : List Nat := [2,4,5,16,32,17,53,21,49,4,0,1,20,0,0,35,1,23,4,1,1,32,16,50,37,17,39,0,1,49,20,16,20,16,1,49]

theorem envBound36919 : H12AffineFastState.Bounded env36919 := by
  intro p hp
  have h : env36919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36918_36919 : H12AffineEnvironment.transform 2 5 env36918 = env36919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env36918 == env36919) = true)

def env36920 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,80,12637,12590,0,12719,320,12636,4096,476,16,8510,8328,65,319,80,4176,2341,8205,8201,257,64,0,513]

theorem envBound36920 : H12AffineFastState.Bounded env36920 := by
  intro p hp
  have h : env36920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36910_36920 : H12AffineEnvironment.transform 9 321 env36910 = env36920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env36910 == env36920) = true)

theorem identity36920 : scanCanonicalize (H12AffineFastState.compose env36920 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 325) := by decide +kernel

theorem selectedBound36920 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env36921 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,325,8192,80,8216,8299,0,8426,320,8217,325,476,16,8510,8328,65,319,80,277,2341,8205,8201,257,64,0,513]

theorem envBound36921 : H12AffineFastState.Bounded env36921 := by
  intro p hp
  have h : env36921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36920_36921 : H12AffineEnvironment.transform 11 325 env36920 = env36921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 325 env36920 == env36921) = true)

theorem identity36921 : scanCanonicalize (H12AffineFastState.compose env36921 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound36921 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env36922 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,325,25,80,1,114,0,243,320,0,325,476,16,295,145,65,319,80,277,2341,20,16,257,64,0,513]

theorem envBound36922 : H12AffineFastState.Bounded env36922 := by
  intro p hp
  have h : env36922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36921_36922 : H12AffineEnvironment.transform 12 25 env36921 = env36922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env36921 == env36922) = true)

theorem identity36922 : scanCanonicalize (H12AffineFastState.compose env36922 (packedSelected [3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound36922 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env36923 : List Nat := [2,4,8,0,32,64,128,256,512,321,2048,325,9,64,1,98,0,227,320,0,325,460,0,295,129,65,303,64,261,2341,4,0,257,64,0,513]

theorem envBound36923 : H12AffineFastState.Bounded env36923 := by
  intro p hp
  have h : env36923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36922_36923 : H12AffineEnvironment.transform 3 0 env36922 = env36923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env36922 == env36923) = true)

theorem identity36923 : scanCanonicalize (H12AffineFastState.compose env36923 (packedSelected [2,11,12,13,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 461) := by decide +kernel

theorem selectedBound36923 : packedSelected [2,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env36924 : List Nat := [2,4,8,0,32,64,128,256,461,321,2048,325,9,64,1,98,0,227,320,0,325,460,0,295,129,65,303,64,261,2341,4,0,257,64,0,460]

theorem envBound36924 : H12AffineFastState.Bounded env36924 := by
  intro p hp
  have h : env36924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36923_36924 : H12AffineEnvironment.transform 8 461 env36923 = env36924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 461 env36923 == env36924) = true)

theorem identity36924 : scanCanonicalize (H12AffineFastState.compose env36924 (packedSelected [0,2,3,7,8,11,12,13,15,17] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound36924 : packedSelected [0,2,3,7,8,11,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env36925 : List Nat := [2,4,8,0,32,64,128,69,136,4,2048,0,9,64,1,98,0,227,5,0,0,137,0,98,129,65,106,64,64,2144,4,0,68,64,0,137]

theorem envBound36925 : H12AffineFastState.Bounded env36925 := by
  intro p hp
  have h : env36925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36924_36925 : H12AffineEnvironment.transform 7 69 env36924 = env36925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env36924 == env36925) = true)

theorem identity36925 : scanCanonicalize (H12AffineFastState.compose env36925 (packedSelected [2,8] rootPS)) = affineNative (2^(6+1) ^^^ 101) := by decide +kernel

theorem selectedBound36925 : packedSelected [2,8] rootPS < 2^1333 := by decide +kernel

def env36926 : List Nat := [2,4,8,0,32,64,101,69,109,4,2048,0,9,64,1,98,0,6,5,0,0,108,0,98,100,65,106,64,64,2144,4,0,68,64,0,108]

theorem envBound36926 : H12AffineFastState.Bounded env36926 := by
  intro p hp
  have h : env36926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36925_36926 : H12AffineEnvironment.transform 6 101 env36925 = env36926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 101 env36925 == env36926) = true)

theorem identity36926 : scanCanonicalize (H12AffineFastState.compose env36926 (packedSelected [0,3,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 45) := by decide +kernel

theorem selectedBound36926 : packedSelected [0,3,7,11] rootPS < 2^1333 := by decide +kernel

def env36927 : List Nat := [2,4,8,0,32,64,101,69,109,4,45,0,9,64,1,98,0,6,5,0,0,108,0,98,100,65,106,64,64,77,4,0,68,64,0,108]

theorem envBound36927 : H12AffineFastState.Bounded env36927 := by
  intro p hp
  have h : env36927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36926_36927 : H12AffineEnvironment.transform 10 45 env36926 = env36927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 45 env36926 == env36927) = true)

theorem identity36927 : scanCanonicalize (H12AffineFastState.compose env36927 (packedSelected [2,3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound36927 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env36928 : List Nat := [2,4,3,0,32,64,101,69,102,4,38,0,2,64,1,98,0,6,5,0,0,103,0,98,100,65,97,64,64,70,4,0,68,64,0,103]

theorem envBound36928 : H12AffineFastState.Bounded env36928 := by
  intro p hp
  have h : env36928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36927_36928 : H12AffineEnvironment.transform 2 3 env36927 = env36928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env36927 == env36928) = true)

theorem identity36928 : scanCanonicalize (H12AffineFastState.compose env36928 (packedSelected [1,2] rootPS)) = affineNative (2^(5+1) ^^^ 7) := by decide +kernel

theorem selectedBound36928 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env36929 : List Nat := [2,4,3,0,32,7,34,2,33,4,38,0,2,7,1,37,0,6,5,0,0,32,0,37,35,6,38,7,7,1,4,0,3,7,0,32]

theorem envBound36929 : H12AffineFastState.Bounded env36929 := by
  intro p hp
  have h : env36929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36928_36929 : H12AffineEnvironment.transform 5 7 env36928 = env36929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 7 env36928 == env36929) = true)

theorem identity36929 : scanCanonicalize (H12AffineFastState.compose env36929 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound36929 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36930 : List Nat := [2,1,3,0,32,2,34,2,33,1,35,0,2,2,1,32,0,3,0,0,0,32,0,32,35,3,35,2,2,1,1,0,3,2,0,32]

theorem envBound36930 : H12AffineFastState.Bounded env36930 := by
  intro p hp
  have h : env36930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36929_36930 : H12AffineEnvironment.transform 1 1 env36929 = env36930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env36929 == env36930) = true)

theorem identity36930 : scanCanonicalize (H12AffineFastState.compose env36930 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound36930 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env36931 : List Nat := [0,1,1,0,32,0,32,0,33,1,33,0,0,0,1,32,0,1,0,0,0,32,0,32,33,1,33,0,0,1,1,0,1,0,0,32]

theorem envBound36931 : H12AffineFastState.Bounded env36931 := by
  intro p hp
  have h : env36931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36930_36931 : H12AffineEnvironment.transform 0 0 env36930 = env36931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env36930 == env36931) = true)

theorem identity36931 : scanCanonicalize (H12AffineFastState.compose env36931 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound36931 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env36932 : List Nat := [0,1,1,0,0,0,0,0,1,1,1,0,0,0,1,0,0,1,0,0,0,0,0,0,1,1,1,0,0,1,1,0,1,0,0,0]

theorem envBound36932 : H12AffineFastState.Bounded env36932 := by
  intro p hp
  have h : env36932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36931_36932 : H12AffineEnvironment.transform 4 0 env36931 = env36932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env36931 == env36932) = true)

def env36933 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16465,262144,95615,32769,4096,61649,17,284032,86518,94526,77840,1296,74815,96347,381313,365717,257,16401,1345,95103]

theorem envBound36933 : H12AffineFastState.Bounded env36933 := by
  intro p hp
  have h : env36933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36863_36933 : H12AffineEnvironment.transform 16 16465 env36863 = env36933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16465 env36863 == env36933) = true)

def env36934 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1345,262144,77935,32769,4096,46529,17,266384,70886,78894,77840,1296,74815,81227,365713,365717,257,1281,1345,79471]

theorem envBound36934 : H12AffineFastState.Bounded env36934 := by
  intro p hp
  have h : env36934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36933_36934 : H12AffineEnvironment.transform 13 1296 env36933 = env36934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env36933 == env36934) = true)

theorem identity36934 : scanCanonicalize (H12AffineFastState.compose env36934 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound36934 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env36935 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1345,262144,77935,13341,4096,477,17,266384,70886,78894,77840,1296,74815,81227,336013,336009,257,1281,1345,79471]

theorem envBound36935 : H12AffineFastState.Bounded env36935 := by
  intro p hp
  have h : env36935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36934_36935 : H12AffineEnvironment.transform 14 13340 env36934 = env36935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env36934 == env36935) = true)

def env36936 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1345,65664,77935,13341,4096,477,17,69648,70886,78894,77840,1296,74815,81227,8205,8201,257,1281,1345,79471]

theorem envBound36936 : H12AffineFastState.Bounded env36936 := by
  intro p hp
  have h : env36936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36935_36936 : H12AffineEnvironment.transform 17 65664 env36935 = env36936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env36935 == env36936) = true)

theorem identity36936 : scanCanonicalize (H12AffineFastState.compose env36936 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5159) := by decide +kernel

theorem selectedBound36936 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env36937 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,5159,1345,5287,9288,13341,4096,477,17,1079,193,8201,9271,1296,12312,10604,8205,8201,257,1281,1345,8776]

theorem envBound36937 : H12AffineFastState.Bounded env36937 := by
  intro p hp
  have h : env36937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36936_36937 : H12AffineEnvironment.transform 15 5159 env36936 = env36937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5159 env36936 == env36937) = true)

def env36938 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,1296,13340,5159,1297,5287,9240,13341,4096,397,17,1079,145,8201,9271,1296,12312,10556,8205,8201,257,1281,1297,8728]

theorem envBound36938 : H12AffineFastState.Bounded env36938 := by
  intro p hp
  have h : env36938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36937_36938 : H12AffineEnvironment.transform 5 16 env36937 = env36938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env36937 == env36938) = true)

theorem identity36938 : scanCanonicalize (H12AffineFastState.compose env36938 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound36938 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env36939 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,277,8192,1296,9481,1330,1297,1458,9240,9480,277,397,17,1079,145,8201,9271,1296,8461,10556,8205,8201,257,1281,1297,8728]

theorem envBound36939 : H12AffineFastState.Bounded env36939 := by
  intro p hp
  have h : env36939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36938_36939 : H12AffineEnvironment.transform 11 277 env36938 = env36939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env36938 == env36939) = true)

theorem identity36939 : scanCanonicalize (H12AffineFastState.compose env36939 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound36939 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env36940 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,277,1052,1296,277,1330,1297,1458,4,276,277,397,17,1079,145,1045,43,1296,1297,3360,1041,1045,257,1281,1297,1540]

theorem envBound36940 : H12AffineFastState.Bounded env36940 := by
  intro p hp
  have h : env36940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36939_36940 : H12AffineEnvironment.transform 12 1052 env36939 = env36940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env36939 == env36940) = true)

theorem identity36940 : scanCanonicalize (H12AffineFastState.compose env36940 (packedSelected [0,2,3,7,8,11,12,15,17] rootPS)) = affineNative (2^(8+1) ^^^ 147) := by decide +kernel

theorem selectedBound36940 : packedSelected [0,2,3,7,8,11,12,15,17] rootPS < 2^1333 := by decide +kernel

def env36941 : List Nat := [2,4,8,16,32,16,128,256,147,1024,2048,277,1052,1296,277,1330,1297,1458,4,276,277,397,17,1079,145,1045,43,1296,1297,3360,1041,1045,257,1281,1297,1175]

theorem envBound36941 : H12AffineFastState.Bounded env36941 := by
  intro p hp
  have h : env36941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36940_36941 : H12AffineEnvironment.transform 8 147 env36940 = env36941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 147 env36940 == env36941) = true)

theorem identity36941 : scanCanonicalize (H12AffineFastState.compose env36941 (packedSelected [5,8,13] rootPS)) = affineNative (2^(10+1) ^^^ 1411) := by decide +kernel

theorem selectedBound36941 : packedSelected [5,8,13] rootPS < 2^1333 := by decide +kernel

def env36942 : List Nat := [2,4,8,16,32,16,128,256,147,1024,1411,277,1052,1296,277,1330,1297,1458,4,276,277,397,17,1079,145,1045,43,1296,1297,163,1041,1045,257,1281,1297,1175]

theorem envBound36942 : H12AffineFastState.Bounded env36942 := by
  intro p hp
  have h : env36942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36941_36942 : H12AffineEnvironment.transform 10 1411 env36941 = env36942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1411 env36941 == env36942) = true)

theorem identity36942 : scanCanonicalize (H12AffineFastState.compose env36942 (packedSelected [0,1,5,7,11] rootPS)) = affineNative (2^(9+1) ^^^ 46) := by decide +kernel

theorem selectedBound36942 : packedSelected [0,1,5,7,11] rootPS < 2^1333 := by decide +kernel

def env36943 : List Nat := [2,4,8,16,32,16,128,256,147,46,429,277,50,318,277,284,319,412,4,276,277,397,17,25,145,59,43,318,319,163,63,59,257,303,319,185]

theorem envBound36943 : H12AffineFastState.Bounded env36943 := by
  intro p hp
  have h : env36943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36942_36943 : H12AffineEnvironment.transform 9 46 env36942 = env36943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 46 env36942 == env36943) = true)

theorem identity36943 : scanCanonicalize (H12AffineFastState.compose env36943 (packedSelected [1,4,7,8] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound36943 : packedSelected [1,4,7,8] rootPS < 2^1333 := by decide +kernel

def env36944 : List Nat := [2,4,8,10,32,10,128,256,137,46,429,271,40,292,271,262,293,390,4,270,271,397,11,3,139,33,43,292,293,163,37,33,257,303,293,163]

theorem envBound36944 : H12AffineFastState.Bounded env36944 := by
  intro p hp
  have h : env36944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36943_36944 : H12AffineEnvironment.transform 3 10 env36943 = env36944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env36943 == env36944) = true)

theorem identity36944 : scanCanonicalize (H12AffineFastState.compose env36944 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound36944 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env36945 : List Nat := [2,4,8,10,10,10,128,256,137,4,391,271,2,270,271,262,271,390,4,270,271,397,11,3,139,11,1,270,271,137,15,11,257,261,271,137]

theorem envBound36945 : H12AffineFastState.Bounded env36945 := by
  intro p hp
  have h : env36945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36944_36945 : H12AffineEnvironment.transform 4 10 env36944 = env36945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env36944 == env36945) = true)

theorem identity36945 : scanCanonicalize (H12AffineFastState.compose env36945 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound36945 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36946 : List Nat := [2,4,8,10,10,10,9,256,0,4,270,271,2,270,271,262,271,271,4,270,271,260,11,3,2,11,1,270,271,0,15,11,257,261,271,0]

theorem envBound36946 : H12AffineFastState.Bounded env36946 := by
  intro p hp
  have h : env36946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36945_36946 : H12AffineEnvironment.transform 6 9 env36945 = env36946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env36945 == env36946) = true)

def env36947 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,1296,13340,5159,1296,5287,9241,13341,4096,396,17,1079,144,8201,9271,1296,12312,10557,8205,8201,257,1281,1296,8729]

theorem envBound36947 : H12AffineFastState.Bounded env36947 := by
  intro p hp
  have h : env36947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36937_36947 : H12AffineEnvironment.transform 5 17 env36937 = env36947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env36937 == env36947) = true)

theorem identity36947 : scanCanonicalize (H12AffineFastState.compose env36947 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 4364) := by decide +kernel

theorem selectedBound36947 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env36948 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,4364,1296,1296,5159,1296,5287,5397,1297,4096,396,17,1079,144,4357,5435,1296,276,6193,4353,4357,257,1281,1296,4885]

theorem envBound36948 : H12AffineFastState.Bounded env36948 := by
  intro p hp
  have h : env36948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36947_36948 : H12AffineEnvironment.transform 12 4364 env36947 = env36948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4364 env36947 == env36948) = true)

theorem identity36948 : scanCanonicalize (H12AffineFastState.compose env36948 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound36948 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env36949 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,1053,1296,1296,310,1296,438,4,1297,1297,396,17,1079,144,1044,42,1296,276,3360,1040,1044,257,1281,1296,1540]

theorem envBound36949 : H12AffineFastState.Bounded env36949 := by
  intro p hp
  have h : env36949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36948_36949 : H12AffineEnvironment.transform 11 1297 env36948 = env36949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env36948 == env36949) = true)

theorem identity36949 : scanCanonicalize (H12AffineFastState.compose env36949 (packedSelected [0,1,3,7,10,11,13,19] rootPS)) = affineNative (2^(10+1) ^^^ 439) := by decide +kernel

theorem selectedBound36949 : packedSelected [0,1,3,7,10,11,13,19] rootPS < 2^1333 := by decide +kernel

def env36950 : List Nat := [2,4,8,16,32,17,128,256,512,1024,439,1297,1053,1296,1296,310,1296,438,4,1297,1297,396,17,1079,144,1044,42,1296,276,1175,1040,1044,257,1281,1296,1540]

theorem envBound36950 : H12AffineFastState.Bounded env36950 := by
  intro p hp
  have h : env36950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36949_36950 : H12AffineEnvironment.transform 10 439 env36949 = env36950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 439 env36949 == env36950) = true)

theorem identity36950 : scanCanonicalize (H12AffineFastState.compose env36950 (packedSelected [5,8,13] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound36950 : packedSelected [5,8,13] rootPS < 2^1333 := by decide +kernel

def env36951 : List Nat := [2,4,8,16,32,17,128,20,512,1024,163,1029,1053,1028,1028,34,1028,162,4,1029,1029,152,17,1079,144,1044,42,1028,0,1175,1040,1044,21,1045,1028,1540]

theorem envBound36951 : H12AffineFastState.Bounded env36951 := by
  intro p hp
  have h : env36951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36950_36951 : H12AffineEnvironment.transform 7 20 env36950 = env36951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env36950 == env36951) = true)

theorem identity36951 : scanCanonicalize (H12AffineFastState.compose env36951 (packedSelected [8] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound36951 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env36952 : List Nat := [2,4,8,16,13,17,128,20,512,1024,142,1029,1053,1028,1028,15,1028,143,4,1029,1029,152,17,1050,144,1044,7,1028,0,1175,1040,1044,21,1045,1028,1540]

theorem envBound36952 : H12AffineFastState.Bounded env36952 := by
  intro p hp
  have h : env36952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36951_36952 : H12AffineEnvironment.transform 4 13 env36951 = env36952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env36951 == env36952) = true)

theorem identity36952 : scanCanonicalize (H12AffineFastState.compose env36952 (packedSelected [0,7,11] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound36952 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env36953 : List Nat := [2,4,8,16,13,17,128,20,512,4,142,1,25,0,0,15,0,143,4,1,1,152,17,30,144,16,7,0,0,147,20,16,21,17,0,512]

theorem envBound36953 : H12AffineFastState.Bounded env36953 := by
  intro p hp
  have h : env36953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36952_36953 : H12AffineEnvironment.transform 9 4 env36952 = env36953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env36952 == env36953) = true)

theorem identity36953 : scanCanonicalize (H12AffineFastState.compose env36953 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 149) := by decide +kernel

theorem selectedBound36953 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36954 : List Nat := [2,4,8,16,13,17,128,20,149,4,142,1,25,0,0,15,0,143,4,1,1,152,17,30,144,16,7,0,0,147,20,16,21,17,0,149]

theorem envBound36954 : H12AffineFastState.Bounded env36954 := by
  intro p hp
  have h : env36954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36953_36954 : H12AffineEnvironment.transform 8 149 env36953 = env36954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 149 env36953 == env36954) = true)

theorem identity36954 : scanCanonicalize (H12AffineFastState.compose env36954 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 15) := by decide +kernel

theorem selectedBound36954 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36955 : List Nat := [2,4,8,16,13,17,15,20,26,4,1,1,25,0,0,15,0,0,4,1,1,23,17,30,31,16,7,0,0,28,20,16,21,17,0,26]

theorem envBound36955 : H12AffineFastState.Bounded env36955 := by
  intro p hp
  have h : env36955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36954_36955 : H12AffineEnvironment.transform 6 15 env36954 = env36955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 15 env36954 == env36955) = true)

theorem identity36955 : scanCanonicalize (H12AffineFastState.compose env36955 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound36955 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env36956 : List Nat := [2,4,8,11,13,10,15,15,1,4,1,1,2,0,0,15,0,0,4,1,1,12,10,5,4,11,7,0,0,7,15,11,14,10,0,1]

theorem envBound36956 : H12AffineFastState.Bounded env36956 := by
  intro p hp
  have h : env36956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36955_36956 : H12AffineEnvironment.transform 3 11 env36955 = env36956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env36955 == env36956) = true)

def env36957 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1345,65665,77935,13341,4096,477,17,69649,70886,78894,77840,1296,74815,81227,8204,8200,257,1281,1345,79471]

theorem envBound36957 : H12AffineFastState.Bounded env36957 := by
  intro p hp
  have h : env36957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36935_36957 : H12AffineEnvironment.transform 17 65665 env36935 = env36957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env36935 == env36957) = true)

theorem identity36957 : scanCanonicalize (H12AffineFastState.compose env36957 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 358) := by decide +kernel

theorem selectedBound36957 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env36958 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,358,1345,487,12553,13341,4096,477,17,4471,5504,13640,12662,1296,9561,15405,8204,8200,257,1281,1345,14089]

theorem envBound36958 : H12AffineFastState.Bounded env36958 := by
  intro p hp
  have h : env36958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36957_36958 : H12AffineEnvironment.transform 15 358 env36957 = env36958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 358 env36957 == env36958) = true)

def env36959 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,7632,1296,2508,358,1345,487,3289,2509,4096,477,17,4471,5504,2200,3238,1296,6281,509,7644,7640,257,1281,1345,2777]

theorem envBound36959 : H12AffineFastState.Bounded env36959 := by
  intro p hp
  have h : env36959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36958_36959 : H12AffineEnvironment.transform 12 7632 env36958 = env36959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7632 env36958 == env36959) = true)

def env36960 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1344,4096,4240,1296,1164,358,1345,487,409,1165,4096,477,17,4471,5504,1496,486,1296,5577,509,4252,4248,257,1281,1345,1945]

theorem envBound36960 : H12AffineFastState.Bounded env36960 := by
  intro p hp
  have h : env36960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36959_36960 : H12AffineEnvironment.transform 10 1344 env36959 = env36960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1344 env36959 == env36960) = true)

theorem identity36960 : scanCanonicalize (H12AffineFastState.compose env36960 (packedSelected [13] rootPS)) = affineNative (2^(11+1) ^^^ 49) := by decide +kernel

theorem selectedBound36960 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env36961 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1344,49,161,1296,1164,358,1345,487,409,1165,49,477,17,326,1457,1496,486,1296,1528,509,173,169,257,1281,1345,1945]

theorem envBound36961 : H12AffineFastState.Bounded env36961 := by
  intro p hp
  have h : env36961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36960_36961 : H12AffineEnvironment.transform 11 49 env36960 = env36961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env36960 == env36961) = true)

theorem identity36961 : scanCanonicalize (H12AffineFastState.compose env36961 (packedSelected [0,1,2,4,7,8,9,10,11,15] rootPS)) = affineNative (2^(9+1) ^^^ 678) := by decide +kernel

theorem selectedBound36961 : packedSelected [0,1,2,4,7,8,9,10,11,15] rootPS < 2^1333 := by decide +kernel

def env36962 : List Nat := [2,4,8,16,32,64,128,256,512,678,998,49,161,950,554,358,999,487,409,555,49,477,17,326,791,894,486,950,862,509,173,169,257,935,999,319]

theorem envBound36962 : H12AffineFastState.Bounded env36962 := by
  intro p hp
  have h : env36962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36961_36962 : H12AffineEnvironment.transform 9 678 env36961 = env36962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 678 env36961 == env36962) = true)

theorem identity36962 : scanCanonicalize (H12AffineFastState.compose env36962 (packedSelected [0,1,2,3,7,11,16,17,20] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound36962 : packedSelected [0,1,2,3,7,11,16,17,20] rootPS < 2^1333 := by decide +kernel

def env36963 : List Nat := [2,4,8,16,32,64,35,256,512,517,837,49,2,789,554,358,836,324,314,555,49,382,17,326,791,894,325,789,862,350,14,10,257,772,836,319]

theorem envBound36963 : H12AffineFastState.Bounded env36963 := by
  intro p hp
  have h : env36963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36962_36963 : H12AffineEnvironment.transform 6 35 env36962 = env36963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env36962 == env36963) = true)

theorem identity36963 : scanCanonicalize (H12AffineFastState.compose env36963 (packedSelected [0,2,4,7,9,10] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound36963 : packedSelected [0,2,4,7,9,10] rootPS < 2^1333 := by decide +kernel

def env36964 : List Nat := [2,4,8,16,11,64,8,256,512,517,837,26,2,789,513,333,836,324,273,512,26,341,17,326,791,853,325,789,862,350,14,10,257,772,836,276]

theorem envBound36964 : H12AffineFastState.Bounded env36964 := by
  intro p hp
  have h : env36964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36963_36964 : H12AffineEnvironment.transform 4 11 env36963 = env36964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env36963 == env36964) = true)

theorem identity36964 : scanCanonicalize (H12AffineFastState.compose env36964 (packedSelected [3,5,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound36964 : packedSelected [3,5,7,9] rootPS < 2^1333 := by decide +kernel

def env36965 : List Nat := [2,4,8,16,11,64,8,14,512,517,587,26,2,539,513,67,586,74,31,512,26,91,17,72,537,603,75,539,592,80,14,10,15,522,586,26]

theorem envBound36965 : H12AffineFastState.Bounded env36965 := by
  intro p hp
  have h : env36965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36964_36965 : H12AffineEnvironment.transform 7 14 env36964 = env36965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env36964 == env36965) = true)

theorem identity36965 : scanCanonicalize (H12AffineFastState.compose env36965 (packedSelected [2,4,7] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound36965 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env36966 : List Nat := [2,4,8,16,11,11,8,14,512,517,512,26,2,539,513,8,513,1,31,512,26,16,17,3,537,528,0,539,539,27,14,10,15,522,513,26]

theorem envBound36966 : H12AffineFastState.Bounded env36966 := by
  intro p hp
  have h : env36966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36965_36966 : H12AffineEnvironment.transform 5 11 env36965 = env36966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env36965 == env36966) = true)

theorem identity36966 : scanCanonicalize (H12AffineFastState.compose env36966 (packedSelected [1,8] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound36966 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env36967 : List Nat := [2,4,8,16,11,11,8,14,1,4,1,26,2,26,0,8,0,1,31,1,26,16,17,3,24,17,0,26,26,27,14,10,15,11,0,26]

theorem envBound36967 : H12AffineFastState.Bounded env36967 := by
  intro p hp
  have h : env36967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36966_36967 : H12AffineEnvironment.transform 8 1 env36966 = env36967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env36966 == env36967) = true)

theorem identity36967 : scanCanonicalize (H12AffineFastState.compose env36967 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound36967 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36968 : List Nat := [2,3,8,16,11,11,8,9,1,3,1,26,2,26,0,8,0,1,24,1,26,16,17,3,24,17,0,26,26,27,9,10,8,11,0,26]

theorem envBound36968 : H12AffineFastState.Bounded env36968 := by
  intro p hp
  have h : env36968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36967_36968 : H12AffineEnvironment.transform 1 3 env36967 = env36968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env36967 == env36968) = true)

theorem identity36968 : scanCanonicalize (H12AffineFastState.compose env36968 (packedSelected [0,4,12] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound36968 : packedSelected [0,4,12] rootPS < 2^1333 := by decide +kernel

def env36969 : List Nat := [2,3,8,10,11,11,8,9,1,3,1,0,2,0,0,8,0,1,2,1,0,10,11,3,2,11,0,0,0,1,9,10,8,11,0,0]

theorem envBound36969 : H12AffineFastState.Bounded env36969 := by
  intro p hp
  have h : env36969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36968_36969 : H12AffineEnvironment.transform 3 10 env36968 = env36969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env36968 == env36969) = true)

theorem identity36969 : scanCanonicalize (H12AffineFastState.compose env36969 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound36969 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36970 : List Nat := [2,3,1,3,2,2,1,0,1,3,1,0,2,0,0,1,0,1,2,1,0,3,2,3,2,2,0,0,0,1,0,3,1,2,0,0]

theorem envBound36970 : H12AffineFastState.Bounded env36970 := by
  intro p hp
  have h : env36970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36969_36970 : H12AffineEnvironment.transform 2 1 env36969 = env36970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env36969 == env36970) = true)

theorem identity36970 : scanCanonicalize (H12AffineFastState.compose env36970 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound36970 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env36971 : List Nat := [0,1,1,1,0,0,1,0,1,1,1,0,0,0,0,1,0,1,0,1,0,1,0,1,0,0,0,0,0,1,0,1,1,0,0,0]

theorem envBound36971 : H12AffineFastState.Bounded env36971 := by
  intro p hp
  have h : env36971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36970_36971 : H12AffineEnvironment.transform 0 0 env36970 = env36971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env36970 == env36971) = true)

def env36972 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1345,4096,4241,1296,1165,358,1345,487,408,1164,4096,477,17,4471,5504,1497,487,1296,5576,509,4253,4249,257,1281,1345,1944]

theorem envBound36972 : H12AffineFastState.Bounded env36972 := by
  intro p hp
  have h : env36972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36959_36972 : H12AffineEnvironment.transform 10 1345 env36959 = env36972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1345 env36959 == env36972) = true)

theorem identity36972 : scanCanonicalize (H12AffineFastState.compose env36972 (packedSelected [13] rootPS)) = affineNative (2^(11+1) ^^^ 1312) := by decide +kernel

theorem selectedBound36972 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env36973 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1345,1312,1457,1296,1165,358,1345,487,408,1164,1312,477,17,1111,160,1497,487,1296,232,509,1469,1465,257,1281,1345,1944]

theorem envBound36973 : H12AffineFastState.Bounded env36973 := by
  intro p hp
  have h : env36973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36972_36973 : H12AffineEnvironment.transform 11 1312 env36972 = env36973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1312 env36972 == env36973) = true)

theorem identity36973 : scanCanonicalize (H12AffineFastState.compose env36973 (packedSelected [1,3,4,5,8,9,10,12,16,17,19,23] rootPS)) = affineNative (2^(7+1) ^^^ 204) := by decide +kernel

theorem selectedBound36973 : packedSelected [1,3,4,5,8,9,10,12,16,17,19,23] rootPS < 2^1333 := by decide +kernel

def env36974 : List Nat := [2,4,8,16,32,64,128,204,512,1024,1165,1260,1149,1244,1165,170,1165,43,84,1164,1260,17,17,1111,160,1045,43,1244,232,49,1137,1141,205,1229,1165,1620]

theorem envBound36974 : H12AffineFastState.Bounded env36974 := by
  intro p hp
  have h : env36974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36973_36974 : H12AffineEnvironment.transform 7 204 env36973 = env36974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 204 env36973 == env36974) = true)

theorem identity36974 : scanCanonicalize (H12AffineFastState.compose env36974 (packedSelected [0,1,2,5,9,11,16] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound36974 : packedSelected [0,1,2,5,9,11,16] rootPS < 2^1333 := by decide +kernel

def env36975 : List Nat := [2,4,8,16,32,64,57,117,512,1024,1076,1109,1149,1125,1076,19,1076,43,84,1077,1109,17,17,1111,25,1045,43,1125,81,49,1137,1141,116,1140,1076,1620]

theorem envBound36975 : H12AffineFastState.Bounded env36975 := by
  intro p hp
  have h : env36975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36974_36975 : H12AffineEnvironment.transform 6 57 env36974 = env36975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env36974 == env36975) = true)

theorem identity36975 : scanCanonicalize (H12AffineFastState.compose env36975 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 597) := by decide +kernel

theorem selectedBound36975 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36976 : List Nat := [2,4,8,16,32,64,57,117,512,597,609,512,552,560,609,19,609,43,84,608,512,17,17,514,25,576,43,560,81,49,548,544,116,545,609,1]

theorem envBound36976 : H12AffineFastState.Bounded env36976 := by
  intro p hp
  have h : env36976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36975_36976 : H12AffineEnvironment.transform 9 597 env36975 = env36976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 597 env36975 == env36976) = true)

theorem identity36976 : scanCanonicalize (H12AffineFastState.compose env36976 (packedSelected [0,4,5,8,10] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound36976 : packedSelected [0,4,5,8,10] rootPS < 2^1333 := by decide +kernel

def env36977 : List Nat := [2,4,8,16,32,64,57,117,0,85,97,0,40,48,97,19,97,43,84,96,0,17,17,2,25,64,43,48,81,49,36,32,116,33,97,1]

theorem envBound36977 : H12AffineFastState.Bounded env36977 := by
  intro p hp
  have h : env36977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36976_36977 : H12AffineEnvironment.transform 8 0 env36976 = env36977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env36976 == env36977) = true)

theorem identity36977 : scanCanonicalize (H12AffineFastState.compose env36977 (packedSelected [0,3,4] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound36977 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env36978 : List Nat := [2,4,8,6,32,64,47,99,0,67,97,0,40,38,97,5,97,43,66,96,0,7,7,2,15,64,43,38,71,39,36,32,98,33,97,1]

theorem envBound36978 : H12AffineFastState.Bounded env36978 := by
  intro p hp
  have h : env36978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36977_36978 : H12AffineEnvironment.transform 3 6 env36977 = env36978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env36977 == env36978) = true)

theorem identity36978 : scanCanonicalize (H12AffineFastState.compose env36978 (packedSelected [5] rootPS)) = affineNative (2^(5+1) ^^^ 42) := by decide +kernel

theorem selectedBound36978 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env36979 : List Nat := [2,4,8,6,32,42,47,9,0,41,11,0,40,38,11,5,11,43,40,10,0,7,7,2,15,42,43,38,45,39,36,32,8,33,11,1]

theorem envBound36979 : H12AffineFastState.Bounded env36979 := by
  intro p hp
  have h : env36979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36978_36979 : H12AffineEnvironment.transform 5 42 env36978 = env36979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 42 env36978 == env36979) = true)

theorem identity36979 : scanCanonicalize (H12AffineFastState.compose env36979 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 15) := by decide +kernel

theorem selectedBound36979 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env36980 : List Nat := [2,4,8,6,15,5,0,9,0,6,11,0,7,9,11,5,11,4,7,10,0,7,7,2,15,5,4,9,2,8,11,15,8,14,11,1]

theorem envBound36980 : H12AffineFastState.Bounded env36980 := by
  intro p hp
  have h : env36980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36979_36980 : H12AffineEnvironment.transform 4 15 env36979 = env36980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 15 env36979 == env36980) = true)

theorem identity36980 : scanCanonicalize (H12AffineFastState.compose env36980 (packedSelected [0,8] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound36980 : packedSelected [0,8] rootPS < 2^1333 := by decide +kernel

def env36981 : List Nat := [2,1,8,3,10,0,0,9,0,3,11,0,2,9,11,0,11,1,2,10,0,2,2,2,10,0,1,9,2,8,11,10,8,11,11,1]

theorem envBound36981 : H12AffineFastState.Bounded env36981 := by
  intro p hp
  have h : env36981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36980_36981 : H12AffineEnvironment.transform 1 1 env36980 = env36981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env36980 == env36981) = true)

theorem identity36981 : scanCanonicalize (H12AffineFastState.compose env36981 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound36981 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36982 : List Nat := [1,1,8,0,9,0,0,9,0,0,8,0,1,9,8,0,8,1,1,9,0,1,1,1,9,0,1,9,1,8,8,9,8,8,8,1]

theorem envBound36982 : H12AffineFastState.Bounded env36982 := by
  intro p hp
  have h : env36982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36981_36982 : H12AffineEnvironment.transform 0 1 env36981 = env36982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env36981 == env36982) = true)

theorem identity36982 : scanCanonicalize (H12AffineFastState.compose env36982 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound36982 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env36983 : List Nat := [1,1,1,0,0,0,0,0,0,0,1,0,1,0,1,0,1,1,1,0,0,1,1,1,0,0,1,0,1,1,1,0,1,1,1,1]

theorem envBound36983 : H12AffineFastState.Bounded env36983 := by
  intro p hp
  have h : env36983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36982_36983 : H12AffineEnvironment.transform 2 1 env36982 = env36983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env36982 == env36983) = true)

def env36984 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,7633,1296,2509,358,1345,487,3288,2508,4096,477,17,4471,5504,2201,3239,1296,6280,508,7645,7641,257,1281,1345,2776]

theorem envBound36984 : H12AffineFastState.Bounded env36984 := by
  intro p hp
  have h : env36984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36958_36984 : H12AffineEnvironment.transform 12 7633 env36958 = env36984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7633 env36958 == env36984) = true)

def env36985 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1344,4096,4241,1296,1165,358,1345,487,408,1164,4096,477,17,4471,5504,1497,487,1296,5576,508,4253,4249,257,1281,1345,1944]

theorem envBound36985 : H12AffineFastState.Bounded env36985 := by
  intro p hp
  have h : env36985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36984_36985 : H12AffineEnvironment.transform 10 1344 env36984 = env36985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1344 env36984 == env36985) = true)

theorem identity36985 : scanCanonicalize (H12AffineFastState.compose env36985 (packedSelected [13] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound36985 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env36986 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1344,184,41,1296,1165,358,1345,487,408,1164,184,477,17,463,1336,1497,487,1296,1392,508,37,33,257,1281,1345,1944]

theorem envBound36986 : H12AffineFastState.Bounded env36986 := by
  intro p hp
  have h : env36986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36985_36986 : H12AffineEnvironment.transform 11 184 env36985 = env36986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env36985 == env36986) = true)

theorem identity36986 : scanCanonicalize (H12AffineFastState.compose env36986 (packedSelected [1,3,4,5,8,9,10,11,16,17,18,19,21] rootPS)) = affineNative (2^(9+1) ^^^ 347) := by decide +kernel

theorem selectedBound36986 : packedSelected [1,3,4,5,8,9,10,11,16,17,18,19,21] rootPS < 2^1333 := by decide +kernel

def env36987 : List Nat := [2,4,8,16,32,64,128,256,512,347,27,184,41,75,470,358,26,487,408,471,184,477,17,463,99,130,487,75,43,508,37,33,257,90,26,707]

theorem envBound36987 : H12AffineFastState.Bounded env36987 := by
  intro p hp
  have h : env36987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36986_36987 : H12AffineEnvironment.transform 9 347 env36986 = env36987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 347 env36986 == env36987) = true)

theorem identity36987 : scanCanonicalize (H12AffineFastState.compose env36987 (packedSelected [1,2,3,4,5,8,9,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 162) := by decide +kernel

theorem selectedBound36987 : packedSelected [1,2,3,4,5,8,9,10,19] rootPS < 2^1333 := by decide +kernel

def env36988 : List Nat := [2,4,8,16,32,64,128,256,162,347,27,184,41,75,470,358,26,487,408,471,184,477,17,463,99,130,487,75,43,508,37,33,257,90,26,97]

theorem envBound36988 : H12AffineFastState.Bounded env36988 := by
  intro p hp
  have h : env36988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36987_36988 : H12AffineEnvironment.transform 8 162 env36987 = env36988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 162 env36987 == env36988) = true)

theorem identity36988 : scanCanonicalize (H12AffineFastState.compose env36988 (packedSelected [0,1,2,4,5,10,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 67) := by decide +kernel

theorem selectedBound36988 : packedSelected [0,1,2,4,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env36989 : List Nat := [2,4,8,16,32,64,67,256,97,347,27,123,41,75,277,358,26,292,347,276,123,286,17,268,99,65,292,75,43,319,37,33,257,90,26,97]

theorem envBound36989 : H12AffineFastState.Bounded env36989 := by
  intro p hp
  have h : env36989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36988_36989 : H12AffineEnvironment.transform 6 67 env36988 = env36989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 67 env36988 == env36989) = true)

theorem identity36989 : scanCanonicalize (H12AffineFastState.compose env36989 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound36989 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env36990 : List Nat := [2,4,8,16,32,64,67,20,97,79,27,123,41,75,1,114,26,48,79,0,123,10,17,24,99,65,48,75,43,43,37,33,21,90,26,97]

theorem envBound36990 : H12AffineFastState.Bounded env36990 := by
  intro p hp
  have h : env36990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36989_36990 : H12AffineEnvironment.transform 7 20 env36989 = env36990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env36989 == env36990) = true)

theorem identity36990 : scanCanonicalize (H12AffineFastState.compose env36990 (packedSelected [0,1,2,3,5] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound36990 : packedSelected [0,1,2,3,5] rootPS < 2^1333 := by decide +kernel

def env36991 : List Nat := [2,4,8,16,32,59,56,20,26,52,27,0,41,48,1,9,26,48,52,0,0,10,17,24,24,58,48,48,43,43,37,33,21,33,26,26]

theorem envBound36991 : H12AffineFastState.Bounded env36991 := by
  intro p hp
  have h : env36991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36990_36991 : H12AffineEnvironment.transform 5 59 env36990 = env36991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env36990 == env36991) = true)

theorem identity36991 : scanCanonicalize (H12AffineFastState.compose env36991 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound36991 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36992 : List Nat := [2,4,8,7,32,44,47,3,13,35,12,0,41,39,1,9,13,39,35,0,0,10,6,15,15,45,39,39,43,43,37,33,2,33,13,13]

theorem envBound36992 : H12AffineFastState.Bounded env36992 := by
  intro p hp
  have h : env36992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36991_36992 : H12AffineEnvironment.transform 3 7 env36991 = env36992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env36991 == env36992) = true)

def env36993 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1345,4096,4240,1296,1164,358,1345,487,409,1165,4096,477,17,4471,5504,1496,486,1296,5577,508,4252,4248,257,1281,1345,1945]

theorem envBound36993 : H12AffineFastState.Bounded env36993 := by
  intro p hp
  have h : env36993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36984_36993 : H12AffineEnvironment.transform 10 1345 env36984 = env36993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1345 env36984 == env36993) = true)

theorem identity36993 : scanCanonicalize (H12AffineFastState.compose env36993 (packedSelected [13] rootPS)) = affineNative (2^(11+1) ^^^ 1448) := by decide +kernel

theorem selectedBound36993 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env36994 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1345,1448,1336,1296,1164,358,1345,487,409,1165,1448,477,17,1247,40,1496,486,1296,97,508,1332,1328,257,1281,1345,1945]

theorem envBound36994 : H12AffineFastState.Bounded env36994 := by
  intro p hp
  have h : env36994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36993_36994 : H12AffineEnvironment.transform 11 1448 env36993 = env36994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1448 env36993 == env36994) = true)

theorem identity36994 : scanCanonicalize (H12AffineFastState.compose env36994 (packedSelected [3,5,7,8,9,10,15,16,20,24] rootPS)) = affineNative (2^(8+1) ^^^ 185) := by decide +kernel

theorem selectedBound36994 : packedSelected [3,5,7,8,9,10,15,16,20,24] rootPS < 2^1333 := by decide +kernel

def env36995 : List Nat := [2,4,8,16,32,64,128,256,185,1024,1345,1448,1336,1296,1164,358,1345,487,409,1165,1448,477,17,1247,40,1496,486,1296,97,508,1332,1328,257,1281,1345,1312]

theorem envBound36995 : H12AffineFastState.Bounded env36995 := by
  intro p hp
  have h : env36995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36994_36995 : H12AffineEnvironment.transform 8 185 env36994 = env36995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 185 env36994 == env36995) = true)

theorem identity36995 : scanCanonicalize (H12AffineFastState.compose env36995 (packedSelected [0,1,3,4,7,9,12,18,19,21] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound36995 : packedSelected [0,1,3,4,7,9,12,18,19,21] rootPS < 2^1333 := by decide +kernel

def env36996 : List Nat := [2,4,8,16,32,64,88,256,97,1024,1345,1392,1336,1296,1108,358,1345,319,321,1109,1392,261,17,1031,40,1280,318,1296,97,292,1332,1328,257,1281,1345,1312]

theorem envBound36996 : H12AffineFastState.Bounded env36996 := by
  intro p hp
  have h : env36996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36995_36996 : H12AffineEnvironment.transform 6 88 env36995 = env36996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env36995 == env36996) = true)

theorem identity36996 : scanCanonicalize (H12AffineFastState.compose env36996 (packedSelected [0,1,2,3,7,10,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound36996 : packedSelected [0,1,2,3,7,10,12,15] rootPS < 2^1333 := by decide +kernel

def env36997 : List Nat := [2,4,8,16,32,64,88,256,97,272,81,96,40,0,324,358,81,319,321,325,96,261,17,279,40,16,318,0,97,292,36,32,257,17,81,48]

theorem envBound36997 : H12AffineFastState.Bounded env36997 := by
  intro p hp
  have h : env36997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36996_36997 : H12AffineEnvironment.transform 9 272 env36996 = env36997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env36996 == env36997) = true)

theorem identity36997 : scanCanonicalize (H12AffineFastState.compose env36997 (packedSelected [2,3,5] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound36997 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env36998 : List Nat := [2,4,8,16,32,10,18,256,43,272,27,42,40,0,270,300,27,319,267,271,42,261,17,279,40,16,318,0,43,292,36,32,257,17,27,48]

theorem envBound36998 : H12AffineFastState.Bounded env36998 := by
  intro p hp
  have h : env36998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36997_36998 : H12AffineEnvironment.transform 5 10 env36997 = env36998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env36997 == env36998) = true)

theorem identity36998 : scanCanonicalize (H12AffineFastState.compose env36998 (packedSelected [2,4,7] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound36998 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env36999 : List Nat := [2,4,8,16,32,10,18,37,43,53,27,42,40,0,43,9,27,26,46,42,42,32,17,50,40,16,27,0,43,1,36,32,36,17,27,48]

theorem envBound36999 : H12AffineFastState.Bounded env36999 := by
  intro p hp
  have h : env36999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36998_36999 : H12AffineEnvironment.transform 7 37 env36998 = env36999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env36998 == env36999) = true)

def env37000 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1344,262144,77934,32769,4096,46528,17,266385,70887,78895,77840,1296,74815,81226,365712,365717,257,1280,1345,79470]

theorem envBound37000 : H12AffineFastState.Bounded env37000 := by
  intro p hp
  have h : env37000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36933_37000 : H12AffineEnvironment.transform 13 1297 env36933 = env37000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env36933 == env37000) = true)

theorem identity37000 : scanCanonicalize (H12AffineFastState.compose env37000 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32883) := by decide +kernel

theorem selectedBound37000 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env37001 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,32883,1344,262144,45085,32769,4096,46528,17,266385,38036,46172,45155,1296,42060,48441,267491,267494,257,1280,1345,46621]

theorem envBound37001 : H12AffineFastState.Bounded env37001 := by
  intro p hp
  have h : env37001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37000_37001 : H12AffineEnvironment.transform 15 32883 env37000 = env37001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32883 env37000 == env37001) = true)

def env37002 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32883,1344,262144,42333,32769,1344,41088,17,263633,33236,41244,42275,1296,42060,43129,262563,262566,257,1280,1345,41821]

theorem envBound37002 : H12AffineFastState.Bounded env37002 := by
  intro p hp
  have h : env37002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37001_37002 : H12AffineEnvironment.transform 11 1344 env37001 = env37002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env37001 == env37002) = true)

theorem identity37002 : scanCanonicalize (H12AffineFastState.compose env37002 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound37002 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env37003 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,1,8192,80,32768,32883,1,262144,40988,32769,1,41088,17,262288,33236,41244,41058,81,41229,43129,262563,262566,257,65,0,41821]

theorem envBound37003 : H12AffineFastState.Bounded env37003 := by
  intro p hp
  have h : env37003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37002_37003 : H12AffineEnvironment.transform 9 321 env37002 = env37003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env37002 == env37003) = true)

theorem identity37003 : scanCanonicalize (H12AffineFastState.compose env37003 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound37003 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env37004 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,1,8192,80,8541,8494,1,262144,321,8540,1,477,17,262288,8329,65,319,81,80,2340,262563,262566,257,65,0,512]

theorem envBound37004 : H12AffineFastState.Bounded env37004 := by
  intro p hp
  have h : env37004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37003_37004 : H12AffineEnvironment.transform 14 8541 env37003 = env37004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env37003 == env37004) = true)

theorem identity37004 : scanCanonicalize (H12AffineFastState.compose env37004 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound37004 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env37005 : List Nat := [2,4,8,16,32,64,128,21,512,84,2048,1,8192,80,8264,8251,1,262144,84,8265,1,200,17,262288,8329,65,42,81,80,2097,262326,262323,20,65,0,512]

theorem envBound37005 : H12AffineFastState.Bounded env37005 := by
  intro p hp
  have h : env37005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37004_37005 : H12AffineEnvironment.transform 7 21 env37004 = env37005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env37004 == env37005) = true)

theorem identity37005 : scanCanonicalize (H12AffineFastState.compose env37005 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 656) := by decide +kernel

theorem selectedBound37005 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env37006 : List Nat := [2,4,8,16,32,64,128,21,512,84,2048,1,656,80,728,683,1,262144,84,729,1,200,17,262288,537,65,42,81,80,2097,262326,262323,20,65,0,512]

theorem envBound37006 : H12AffineFastState.Bounded env37006 := by
  intro p hp
  have h : env37006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37005_37006 : H12AffineEnvironment.transform 12 656 env37005 = env37006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 656 env37005 == env37006) = true)

theorem identity37006 : scanCanonicalize (H12AffineFastState.compose env37006 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound37006 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env37007 : List Nat := [2,4,8,16,32,17,128,21,512,5,2048,1,656,1,649,683,1,262144,5,648,1,153,17,262288,537,16,42,0,1,2097,262326,262323,20,16,0,512]

theorem envBound37007 : H12AffineFastState.Bounded env37007 := by
  intro p hp
  have h : env37007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37006_37007 : H12AffineEnvironment.transform 5 17 env37006 = env37007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env37006 == env37007) = true)

theorem identity37007 : scanCanonicalize (H12AffineFastState.compose env37007 (packedSelected [1,3,13] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound37007 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env37008 : List Nat := [2,4,8,16,32,17,128,21,512,5,42,1,656,1,649,683,1,262144,5,648,1,153,17,262288,537,16,42,0,1,27,262326,262323,20,16,0,512]

theorem envBound37008 : H12AffineFastState.Bounded env37008 := by
  intro p hp
  have h : env37008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37007_37008 : H12AffineEnvironment.transform 10 42 env37007 = env37008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env37007 == env37008) = true)

theorem identity37008 : scanCanonicalize (H12AffineFastState.compose env37008 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound37008 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env37009 : List Nat := [2,4,8,16,32,17,57,21,512,5,42,1,553,1,560,530,1,262144,5,561,1,32,17,262185,537,16,42,0,1,27,262159,262154,20,16,0,512]

theorem envBound37009 : H12AffineFastState.Bounded env37009 := by
  intro p hp
  have h : env37009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37008_37009 : H12AffineEnvironment.transform 6 57 env37008 = env37009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env37008 == env37009) = true)

theorem identity37009 : scanCanonicalize (H12AffineFastState.compose env37009 (packedSelected [1,2,5] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound37009 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env37010 : List Nat := [2,4,8,16,32,17,57,21,49,5,42,1,24,1,1,35,1,262144,5,0,1,32,17,262185,40,16,42,0,1,27,262159,262154,20,16,0,49]

theorem envBound37010 : H12AffineFastState.Bounded env37010 := by
  intro p hp
  have h : env37010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37009_37010 : H12AffineEnvironment.transform 8 49 env37009 = env37010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env37009 == env37010) = true)

theorem identity37010 : scanCanonicalize (H12AffineFastState.compose env37010 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound37010 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37011 : List Nat := [2,4,8,16,10,17,19,21,27,5,0,1,24,1,1,9,1,262144,5,0,1,10,17,262147,2,16,0,0,1,27,262159,262154,20,16,0,27]

theorem envBound37011 : H12AffineFastState.Bounded env37011 := by
  intro p hp
  have h : env37011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37010_37011 : H12AffineEnvironment.transform 4 10 env37010 = env37011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env37010 == env37011) = true)

theorem identity37011 : scanCanonicalize (H12AffineFastState.compose env37011 (packedSelected [0,1] rootPS)) = affineNative (2^(17+1) ^^^ 26) := by decide +kernel

theorem selectedBound37011 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env37012 : List Nat := [2,4,8,16,10,17,19,21,27,5,0,1,24,1,1,9,1,26,5,0,1,10,17,25,2,16,0,0,1,27,21,16,20,16,0,27]

theorem envBound37012 : H12AffineFastState.Bounded env37012 := by
  intro p hp
  have h : env37012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37011_37012 : H12AffineEnvironment.transform 17 26 env37011 = env37012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 26 env37011 == env37012) = true)

theorem identity37012 : scanCanonicalize (H12AffineFastState.compose env37012 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound37012 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37013 : List Nat := [2,3,8,16,10,17,19,18,27,2,0,1,24,1,1,9,1,26,2,0,1,10,17,25,2,16,0,0,1,27,18,16,19,16,0,27]

theorem envBound37013 : H12AffineFastState.Bounded env37013 := by
  intro p hp
  have h : env37013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37012_37013 : H12AffineEnvironment.transform 1 3 env37012 = env37013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env37012 == env37013) = true)

theorem identity37013 : scanCanonicalize (H12AffineFastState.compose env37013 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound37013 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env37014 : List Nat := [2,3,8,10,10,11,9,8,1,2,0,1,2,1,1,9,1,0,2,0,1,10,11,3,2,10,0,0,1,1,8,10,9,10,0,1]

theorem envBound37014 : H12AffineFastState.Bounded env37014 := by
  intro p hp
  have h : env37014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37013_37014 : H12AffineEnvironment.transform 3 10 env37013 = env37014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env37013 == env37014) = true)

def env37015 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32883,1344,262144,42332,32769,1345,41089,17,263632,33237,41245,42274,1296,42060,43128,262562,262567,257,1280,1345,41820]

theorem envBound37015 : H12AffineFastState.Bounded env37015 := by
  intro p hp
  have h : env37015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37001_37015 : H12AffineEnvironment.transform 11 1345 env37001 = env37015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env37001 == env37015) = true)

theorem identity37015 : scanCanonicalize (H12AffineFastState.compose env37015 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 34227) := by decide +kernel

theorem selectedBound37015 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env37016 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32883,1344,34227,42332,32769,1345,41089,17,32867,33237,41245,42274,1296,42060,43128,33809,33812,257,1280,1345,41820]

theorem envBound37016 : H12AffineFastState.Bounded env37016 := by
  intro p hp
  have h : env37016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37015_37016 : H12AffineEnvironment.transform 17 34227 env37015 = env37016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 34227 env37015 == env37016) = true)

theorem identity37016 : scanCanonicalize (H12AffineFastState.compose env37016 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(14+1) ^^^ 608) := by decide +kernel

theorem selectedBound37016 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env37017 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,608,531,1344,2003,10044,609,1345,8929,17,515,949,9085,10050,1296,9772,10776,1649,1652,257,1280,1345,8508]

theorem envBound37017 : H12AffineFastState.Bounded env37017 := by
  intro p hp
  have h : env37017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37016_37017 : H12AffineEnvironment.transform 14 608 env37016 = env37017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 608 env37016 == env37017) = true)

def env37018 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95615,32769,4096,61649,147520,284033,86518,209263,225344,148801,74815,96347,381312,513221,257,131136,1345,95103]

theorem envBound37018 : H12AffineFastState.Bounded env37018 := by
  intro p hp
  have h : env37018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36862_37018 : H12AffineEnvironment.transform 23 284033 env36862 = env37018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 284033 env36862 == env37018) = true)

def env37019 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16464,262144,95615,32769,4096,61649,16,284033,86518,94527,77840,1297,74815,96347,381312,365717,257,16400,1345,95103]

theorem envBound37019 : H12AffineFastState.Bounded env37019 := by
  intro p hp
  have h : env37019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37018_37019 : H12AffineEnvironment.transform 16 16464 env37018 = env37019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16464 env37018 == env37019) = true)

def env37020 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1344,262144,77935,32769,4096,46529,16,266385,70886,78895,77840,1297,74815,81227,365712,365717,257,1280,1345,79471]

theorem envBound37020 : H12AffineFastState.Bounded env37020 := by
  intro p hp
  have h : env37020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37019_37020 : H12AffineEnvironment.transform 13 1296 env37019 = env37020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env37019 == env37020) = true)

theorem identity37020 : scanCanonicalize (H12AffineFastState.compose env37020 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32882) := by decide +kernel

theorem selectedBound37020 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env37021 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,32882,1344,262144,45085,32769,4096,46529,16,266385,38036,46173,45154,1297,42061,48441,267490,267495,257,1280,1345,46621]

theorem envBound37021 : H12AffineFastState.Bounded env37021 := by
  intro p hp
  have h : env37021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37020_37021 : H12AffineEnvironment.transform 15 32882 env37020 = env37021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32882 env37020 == env37021) = true)

def env37022 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32882,1344,262144,42333,32769,1344,41089,16,263633,33236,41245,42274,1297,42061,43129,262562,262567,257,1280,1345,41821]

theorem envBound37022 : H12AffineFastState.Bounded env37022 := by
  intro p hp
  have h : env37022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37021_37022 : H12AffineEnvironment.transform 11 1344 env37021 = env37022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env37021 == env37022) = true)

theorem identity37022 : scanCanonicalize (H12AffineFastState.compose env37022 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 72) := by decide +kernel

theorem selectedBound37022 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env37023 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,72,1296,32768,32882,1344,262144,34069,32769,1344,32969,16,263633,33236,33109,34154,1297,33797,34865,262562,262567,257,1280,1345,33557]

theorem envBound37023 : H12AffineFastState.Bounded env37023 := by
  intro p hp
  have h : env37023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37022_37023 : H12AffineEnvironment.transform 12 72 env37022 = env37023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env37022 == env37023) = true)

theorem identity37023 : scanCanonicalize (H12AffineFastState.compose env37023 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(17+1) ^^^ 2003) := by decide +kernel

theorem selectedBound37023 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env37024 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,72,1296,32768,32882,1344,2003,34069,32769,1344,32969,16,514,33236,33109,34154,1297,33797,34865,1649,1652,257,1280,1345,33557]

theorem envBound37024 : H12AffineFastState.Bounded env37024 := by
  intro p hp
  have h : env37024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37023_37024 : H12AffineEnvironment.transform 17 2003 env37023 = env37024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2003 env37023 == env37024) = true)

def env37025 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32882,1344,262144,42332,32769,1345,41088,16,263632,33237,41244,42275,1297,42061,43128,262563,262566,257,1280,1345,41820]

theorem envBound37025 : H12AffineFastState.Bounded env37025 := by
  intro p hp
  have h : env37025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37021_37025 : H12AffineEnvironment.transform 11 1345 env37021 = env37025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env37021 == env37025) = true)

theorem identity37025 : scanCanonicalize (H12AffineFastState.compose env37025 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 41147) := by decide +kernel

theorem selectedBound37025 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env37026 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32882,1344,41147,42332,32769,1345,41088,16,42347,33237,41244,42275,1297,42061,43128,41240,41245,257,1280,1345,41820]

theorem envBound37026 : H12AffineFastState.Bounded env37026 := by
  intro p hp
  have h : env37026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37025_37026 : H12AffineEnvironment.transform 17 41147 env37025 = env37026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 41147 env37025 == env37026) = true)

theorem identity37026 : scanCanonicalize (H12AffineFastState.compose env37026 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound37026 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env37027 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,8540,8494,1344,487,1024,8541,1345,476,16,1079,8329,64,1151,1297,1297,2340,68,65,257,1280,1345,512]

theorem envBound37027 : H12AffineFastState.Bounded env37027 := by
  intro p hp
  have h : env37027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37026_37027 : H12AffineEnvironment.transform 14 8540 env37026 = env37027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env37026 == env37027) = true)

theorem identity37027 : scanCanonicalize (H12AffineFastState.compose env37027 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 84) := by decide +kernel

theorem selectedBound37027 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env37028 : List Nat := [2,4,8,16,32,64,128,256,512,84,2048,277,8192,324,8540,8494,276,487,84,8541,277,476,16,99,8329,64,43,325,325,2340,68,65,257,340,277,512]

theorem envBound37028 : H12AffineFastState.Bounded env37028 := by
  intro p hp
  have h : env37028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37027_37028 : H12AffineEnvironment.transform 9 84 env37027 = env37028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env37027 == env37028) = true)

theorem identity37028 : scanCanonicalize (H12AffineFastState.compose env37028 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 901) := by decide +kernel

theorem selectedBound37028 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env37029 : List Nat := [2,4,8,16,32,64,128,256,512,84,2048,277,901,324,729,683,276,487,84,728,277,476,16,99,780,64,43,325,325,2340,68,65,257,340,277,512]

theorem envBound37029 : H12AffineFastState.Bounded env37029 := by
  intro p hp
  have h : env37029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37028_37029 : H12AffineEnvironment.transform 12 901 env37028 = env37029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 901 env37028 == env37029) = true)

theorem identity37029 : scanCanonicalize (H12AffineFastState.compose env37029 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound37029 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env37030 : List Nat := [2,4,8,16,32,17,128,256,512,5,2048,277,901,277,648,683,276,438,5,649,277,397,16,50,780,17,43,276,276,2340,21,16,257,261,277,512]

theorem envBound37030 : H12AffineFastState.Bounded env37030 := by
  intro p hp
  have h : env37030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37029_37030 : H12AffineEnvironment.transform 5 17 env37029 = env37030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env37029 == env37030) = true)

theorem identity37030 : scanCanonicalize (H12AffineFastState.compose env37030 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 390) := by decide +kernel

theorem selectedBound37030 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env37031 : List Nat := [2,4,8,16,32,17,128,256,512,5,390,277,901,277,648,683,276,438,5,649,277,397,16,50,780,17,43,276,276,162,21,16,257,261,277,512]

theorem envBound37031 : H12AffineFastState.Bounded env37031 := by
  intro p hp
  have h : env37031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37030_37031 : H12AffineEnvironment.transform 10 390 env37030 = env37031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 390 env37030 == env37031) = true)

theorem identity37031 : scanCanonicalize (H12AffineFastState.compose env37031 (packedSelected [0,1,2,5,7,11] rootPS)) = affineNative (2^(7+1) ^^^ 135) := by decide +kernel

theorem selectedBound37031 : packedSelected [0,1,2,5,7,11] rootPS < 2^1333 := by decide +kernel

def env37032 : List Nat := [2,4,8,16,32,17,128,135,512,5,1,146,514,146,648,683,147,49,5,649,146,10,16,50,651,17,43,147,147,162,21,16,134,130,146,512]

theorem envBound37032 : H12AffineFastState.Bounded env37032 := by
  intro p hp
  have h : env37032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37031_37032 : H12AffineEnvironment.transform 7 135 env37031 = env37032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 135 env37031 == env37032) = true)

theorem identity37032 : scanCanonicalize (H12AffineFastState.compose env37032 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound37032 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env37033 : List Nat := [2,4,8,16,32,17,9,14,512,5,1,27,514,27,513,546,26,49,5,512,27,10,16,50,514,17,43,26,26,43,21,16,15,11,27,512]

theorem envBound37033 : H12AffineFastState.Bounded env37033 := by
  intro p hp
  have h : env37033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37032_37033 : H12AffineEnvironment.transform 6 9 env37032 = env37033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env37032 == env37033) = true)

theorem identity37033 : scanCanonicalize (H12AffineFastState.compose env37033 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound37033 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env37034 : List Nat := [2,4,8,16,16,17,9,14,512,5,1,27,514,27,513,530,26,1,5,512,27,10,16,2,514,17,27,26,26,27,21,16,15,11,27,512]

theorem envBound37034 : H12AffineFastState.Bounded env37034 := by
  intro p hp
  have h : env37034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37033_37034 : H12AffineEnvironment.transform 4 16 env37033 = env37034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env37033 == env37034) = true)

theorem identity37034 : scanCanonicalize (H12AffineFastState.compose env37034 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound37034 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env37035 : List Nat := [2,4,8,11,11,10,9,14,512,5,1,0,514,0,513,521,1,1,5,512,0,10,11,2,514,10,0,1,1,0,14,11,15,11,0,512]

theorem envBound37035 : H12AffineFastState.Bounded env37035 := by
  intro p hp
  have h : env37035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37034_37035 : H12AffineEnvironment.transform 3 11 env37034 = env37035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env37034 == env37035) = true)

theorem identity37035 : scanCanonicalize (H12AffineFastState.compose env37035 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 7) := by decide +kernel

theorem selectedBound37035 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37036 : List Nat := [2,4,8,11,11,10,9,14,7,5,1,0,5,0,6,14,1,1,5,7,0,10,11,2,5,10,0,1,1,0,14,11,15,11,0,7]

theorem envBound37036 : H12AffineFastState.Bounded env37036 := by
  intro p hp
  have h : env37036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37035_37036 : H12AffineEnvironment.transform 8 7 env37035 = env37036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 7 env37035 == env37036) = true)

theorem identity37036 : scanCanonicalize (H12AffineFastState.compose env37036 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound37036 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37037 : List Nat := [2,2,8,11,11,10,9,8,1,3,1,0,3,0,0,8,1,1,3,1,0,10,11,2,3,10,0,1,1,0,8,11,9,11,0,1]

theorem envBound37037 : H12AffineFastState.Bounded env37037 := by
  intro p hp
  have h : env37037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37036_37037 : H12AffineEnvironment.transform 1 2 env37036 = env37037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env37036 == env37037) = true)

def env37038 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1345,262144,77934,32769,4096,46528,16,266384,70887,78894,77840,1297,74815,81226,365713,365717,257,1281,1345,79470]

theorem envBound37038 : H12AffineFastState.Bounded env37038 := by
  intro p hp
  have h : env37038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37019_37038 : H12AffineEnvironment.transform 13 1297 env37019 = env37038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env37019 == env37038) = true)

theorem identity37038 : scanCanonicalize (H12AffineFastState.compose env37038 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound37038 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env37039 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1345,262144,77934,13341,4096,476,16,266384,70887,78894,77840,1297,74815,81226,336013,336009,257,1281,1345,79470]

theorem envBound37039 : H12AffineFastState.Bounded env37039 := by
  intro p hp
  have h : env37039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37038_37039 : H12AffineEnvironment.transform 14 13340 env37038 = env37039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env37038 == env37039) = true)

def env37040 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1345,65664,77934,13341,4096,476,16,69648,70887,78894,77840,1297,74815,81226,8205,8201,257,1281,1345,79470]

theorem envBound37040 : H12AffineFastState.Bounded env37040 := by
  intro p hp
  have h : env37040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37039_37040 : H12AffineEnvironment.transform 17 65664 env37039 = env37040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env37039 == env37040) = true)

theorem identity37040 : scanCanonicalize (H12AffineFastState.compose env37040 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound37040 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env37041 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,80,12637,65536,0,65664,77934,12636,4096,476,16,69648,70054,78191,77840,80,74110,79883,8205,8201,257,64,0,78639]

theorem envBound37041 : H12AffineFastState.Bounded env37041 := by
  intro p hp
  have h : env37041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37040_37041 : H12AffineEnvironment.transform 9 321 env37040 = env37041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env37040 == env37041) = true)

def env37042 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,4096,8192,0,12557,65536,0,65664,77886,12556,4096,396,16,69648,70054,78143,77840,0,74030,79883,8205,8201,257,16,0,78639]

theorem envBound37042 : H12AffineFastState.Bounded env37042 := by
  intro p hp
  have h : env37042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37041_37042 : H12AffineEnvironment.transform 5 16 env37041 = env37042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env37041 == env37042) = true)

theorem identity37042 : scanCanonicalize (H12AffineFastState.compose env37042 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 8251) := by decide +kernel

theorem selectedBound37042 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env37043 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,4096,8192,0,12557,8251,0,8379,4101,12556,4096,396,16,12331,12701,4356,4139,0,277,6192,8205,8201,257,16,0,4884]

theorem envBound37043 : H12AffineFastState.Bounded env37043 := by
  intro p hp
  have h : env37043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37042_37043 : H12AffineEnvironment.transform 15 8251 env37042 = env37043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8251 env37042 == env37043) = true)

theorem identity37043 : scanCanonicalize (H12AffineFastState.compose env37043 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound37043 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env37044 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,8192,0,8460,8251,0,8379,4,8461,1,396,16,8234,8604,261,42,0,277,2097,8205,8201,257,16,0,789]

theorem envBound37044 : H12AffineFastState.Bounded env37044 := by
  intro p hp
  have h : env37044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37043_37044 : H12AffineEnvironment.transform 11 1 env37043 = env37044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env37043 == env37044) = true)

theorem identity37044 : scanCanonicalize (H12AffineFastState.compose env37044 (packedSelected [0,1,2,3,7,10,17,18,19] rootPS)) = affineNative (2^(12+1) ^^^ 2089) := by decide +kernel

theorem selectedBound37044 : packedSelected [0,1,2,3,7,10,17,18,19] rootPS < 2^1333 := by decide +kernel

def env37045 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,2089,0,2341,2066,0,2194,4,2340,1,396,16,2051,2485,261,42,0,277,2097,2084,2080,257,16,0,789]

theorem envBound37045 : H12AffineFastState.Bounded env37045 := by
  intro p hp
  have h : env37045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37044_37045 : H12AffineEnvironment.transform 12 2089 env37044 = env37045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2089 env37044 == env37045) = true)

theorem identity37045 : scanCanonicalize (H12AffineFastState.compose env37045 (packedSelected [0,1,7,8,10,11,12,13,17] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound37045 : packedSelected [0,1,7,8,10,11,12,13,17] rootPS < 2^1333 := by decide +kernel

def env37046 : List Nat := [2,4,8,16,10,16,128,256,512,273,2048,1,2051,0,2319,2066,0,2194,4,2318,1,396,16,2051,2463,261,0,0,277,2075,2062,2058,257,16,0,789]

theorem envBound37046 : H12AffineFastState.Bounded env37046 := by
  intro p hp
  have h : env37046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37045_37046 : H12AffineEnvironment.transform 4 10 env37045 = env37046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env37045 == env37046) = true)

theorem identity37046 : scanCanonicalize (H12AffineFastState.compose env37046 (packedSelected [1,5,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 538) := by decide +kernel

theorem selectedBound37046 : packedSelected [1,5,10,11] rootPS < 2^1333 := by decide +kernel

def env37047 : List Nat := [2,4,8,16,10,16,128,256,512,273,538,1,537,0,789,520,0,648,4,788,1,396,16,537,901,261,0,0,277,513,532,528,257,16,0,789]

theorem envBound37047 : H12AffineFastState.Bounded env37047 := by
  intro p hp
  have h : env37047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37046_37047 : H12AffineEnvironment.transform 10 538 env37046 = env37047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 538 env37046 == env37047) = true)

theorem identity37047 : scanCanonicalize (H12AffineFastState.compose env37047 (packedSelected [4,5,7,8] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound37047 : packedSelected [4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env37048 : List Nat := [2,4,8,16,10,16,128,256,0,273,26,1,25,0,277,8,0,136,4,276,1,396,16,25,389,261,0,0,277,1,20,16,257,16,0,277]

theorem envBound37048 : H12AffineFastState.Bounded env37048 := by
  intro p hp
  have h : env37048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37047_37048 : H12AffineEnvironment.transform 8 0 env37047 = env37048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env37047 == env37048) = true)

theorem identity37048 : scanCanonicalize (H12AffineFastState.compose env37048 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound37048 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37049 : List Nat := [2,4,8,11,10,11,128,256,0,266,1,1,2,0,270,8,0,136,4,271,1,396,11,2,389,261,0,0,270,1,15,11,257,11,0,270]

theorem envBound37049 : H12AffineFastState.Bounded env37049 := by
  intro p hp
  have h : env37049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37048_37049 : H12AffineEnvironment.transform 3 11 env37048 = env37049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env37048 == env37049) = true)

theorem identity37049 : scanCanonicalize (H12AffineFastState.compose env37049 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound37049 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env37050 : List Nat := [2,4,8,11,10,11,128,14,0,4,1,1,2,0,0,8,0,136,4,1,1,130,11,2,139,11,0,0,0,1,15,11,15,11,0,0]

theorem envBound37050 : H12AffineFastState.Bounded env37050 := by
  intro p hp
  have h : env37050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37049_37050 : H12AffineEnvironment.transform 7 14 env37049 = env37050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env37049 == env37050) = true)

theorem identity37050 : scanCanonicalize (H12AffineFastState.compose env37050 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound37050 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37051 : List Nat := [2,4,8,11,10,11,4,14,0,4,1,1,2,0,0,8,0,12,4,1,1,6,11,2,15,11,0,0,0,1,15,11,15,11,0,0]

theorem envBound37051 : H12AffineFastState.Bounded env37051 := by
  intro p hp
  have h : env37051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37050_37051 : H12AffineEnvironment.transform 6 4 env37050 = env37051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env37050 == env37051) = true)

theorem identity37051 : scanCanonicalize (H12AffineFastState.compose env37051 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound37051 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37052 : List Nat := [2,4,4,7,6,7,4,2,0,4,1,1,2,0,0,4,0,0,4,1,1,6,7,2,3,7,0,0,0,1,3,7,3,7,0,0]

theorem envBound37052 : H12AffineFastState.Bounded env37052 := by
  intro p hp
  have h : env37052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37051_37052 : H12AffineEnvironment.transform 2 4 env37051 = env37052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env37051 == env37052) = true)

def env37053 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,4096,8192,1,12556,65536,0,65664,77887,12557,4096,397,16,69648,70054,78142,77840,1,74031,79883,8205,8201,257,17,0,78639]

theorem envBound37053 : H12AffineFastState.Bounded env37053 := by
  intro p hp
  have h : env37053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37041_37053 : H12AffineEnvironment.transform 5 17 env37041 = env37053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env37041 == env37053) = true)

theorem identity37053 : scanCanonicalize (H12AffineFastState.compose env37053 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound37053 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env37054 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,276,8192,1,8216,65536,0,65664,74027,8217,276,397,16,65796,65714,73770,73988,1,74031,76063,8205,8201,257,17,0,74299]

theorem envBound37054 : H12AffineFastState.Bounded env37054 := by
  intro p hp
  have h : env37054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37053_37054 : H12AffineEnvironment.transform 11 276 env37053 = env37054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env37053 == env37054) = true)

theorem identity37054 : scanCanonicalize (H12AffineFastState.compose env37054 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 8495) := by decide +kernel

theorem selectedBound37054 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env37055 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,276,8192,1,8216,8495,0,8623,4,8217,276,397,16,8235,8605,261,43,1,0,2096,8205,8201,257,17,0,788]

theorem envBound37055 : H12AffineFastState.Bounded env37055 := by
  intro p hp
  have h : env37055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37054_37055 : H12AffineEnvironment.transform 15 8495 env37054 = env37055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8495 env37054 == env37055) = true)

theorem identity37055 : scanCanonicalize (H12AffineFastState.compose env37055 (packedSelected [0,2,3,7,8,11] rootPS)) = affineNative (2^(12+1) ^^^ 2073) := by decide +kernel

theorem selectedBound37055 : packedSelected [0,2,3,7,8,11] rootPS < 2^1333 := by decide +kernel

def env37056 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,276,2073,1,2049,2358,0,2486,4,2048,276,397,16,2098,2436,261,43,1,0,2096,2068,2064,257,17,0,788]

theorem envBound37056 : H12AffineFastState.Bounded env37056 := by
  intro p hp
  have h : env37056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37055_37056 : H12AffineEnvironment.transform 12 2073 env37055 = env37056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2073 env37055 == env37056) = true)

theorem identity37056 : scanCanonicalize (H12AffineFastState.compose env37056 (packedSelected [1,2,3,10,12,17] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound37056 : packedSelected [1,2,3,10,12,17] rootPS < 2^1333 := by decide +kernel

def env37057 : List Nat := [2,4,8,16,17,17,128,256,512,272,2048,276,2073,1,2049,2311,0,2439,4,2048,276,397,16,2051,2436,261,26,1,0,2049,2068,2064,257,17,0,788]

theorem envBound37057 : H12AffineFastState.Bounded env37057 := by
  intro p hp
  have h : env37057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37056_37057 : H12AffineEnvironment.transform 4 17 env37056 = env37057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env37056 == env37057) = true)

theorem identity37057 : scanCanonicalize (H12AffineFastState.compose env37057 (packedSelected [1,2,3,4,5,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 783) := by decide +kernel

theorem selectedBound37057 : packedSelected [1,2,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env37058 : List Nat := [2,4,8,16,17,17,128,256,512,272,783,276,790,1,782,520,0,648,4,783,276,397,16,780,651,261,26,1,0,782,795,799,257,17,0,788]

theorem envBound37058 : H12AffineFastState.Bounded env37058 := by
  intro p hp
  have h : env37058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37057_37058 : H12AffineEnvironment.transform 10 783 env37057 = env37058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 783 env37057 == env37058) = true)

theorem identity37058 : scanCanonicalize (H12AffineFastState.compose env37058 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound37058 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env37059 : List Nat := [2,4,8,16,17,17,128,14,512,30,513,26,536,1,512,520,0,648,4,513,26,131,16,514,651,11,26,1,0,512,533,529,15,17,0,538]

theorem envBound37059 : H12AffineFastState.Bounded env37059 := by
  intro p hp
  have h : env37059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37058_37059 : H12AffineEnvironment.transform 7 14 env37058 = env37059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env37058 == env37059) = true)

theorem identity37059 : scanCanonicalize (H12AffineFastState.compose env37059 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound37059 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env37060 : List Nat := [2,4,8,16,17,17,128,14,137,30,136,26,145,1,137,129,0,1,4,136,26,131,16,139,2,11,26,1,0,137,156,152,15,17,0,147]

theorem envBound37060 : H12AffineFastState.Bounded env37060 := by
  intro p hp
  have h : env37060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37059_37060 : H12AffineEnvironment.transform 8 137 env37059 = env37060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env37059 == env37060) = true)

theorem identity37060 : scanCanonicalize (H12AffineFastState.compose env37060 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound37060 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env37061 : List Nat := [2,4,8,11,10,10,128,14,137,5,136,1,138,1,137,129,0,1,4,136,1,131,11,139,2,11,1,1,0,137,135,131,15,10,0,136]

theorem envBound37061 : H12AffineFastState.Bounded env37061 := by
  intro p hp
  have h : env37061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37060_37061 : H12AffineEnvironment.transform 3 11 env37060 = env37061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env37060 == env37061) = true)

theorem identity37061 : scanCanonicalize (H12AffineFastState.compose env37061 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 1) := by decide +kernel

theorem selectedBound37061 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env37062 : List Nat := [2,4,8,11,10,10,1,14,8,5,9,1,11,1,8,0,0,1,4,9,1,2,11,10,2,11,1,1,0,8,6,2,15,10,0,9]

theorem envBound37062 : H12AffineFastState.Bounded env37062 := by
  intro p hp
  have h : env37062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37061_37062 : H12AffineEnvironment.transform 6 1 env37061 = env37062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 1 env37061 == env37062) = true)

theorem identity37062 : scanCanonicalize (H12AffineFastState.compose env37062 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound37062 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37063 : List Nat := [2,4,0,3,2,2,1,6,0,5,1,1,3,1,0,0,0,1,4,1,1,2,3,2,2,3,1,1,0,0,6,2,7,2,0,1]

theorem envBound37063 : H12AffineFastState.Bounded env37063 := by
  intro p hp
  have h : env37063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37062_37063 : H12AffineEnvironment.transform 2 0 env37062 = env37063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env37062 == env37063) = true)

theorem identity37063 : scanCanonicalize (H12AffineFastState.compose env37063 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound37063 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37064 : List Nat := [2,0,0,3,2,2,1,2,0,1,1,1,3,1,0,0,0,1,0,1,1,2,3,2,2,3,1,1,0,0,2,2,3,2,0,1]

theorem envBound37064 : H12AffineFastState.Bounded env37064 := by
  intro p hp
  have h : env37064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37063_37064 : H12AffineEnvironment.transform 1 0 env37063 = env37064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env37063 == env37064) = true)

theorem identity37064 : scanCanonicalize (H12AffineFastState.compose env37064 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound37064 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env37065 : List Nat := [1,0,0,0,1,1,1,1,0,1,1,1,0,1,0,0,0,1,0,1,1,1,0,1,1,0,1,1,0,0,1,1,0,1,0,1]

theorem envBound37065 : H12AffineFastState.Bounded env37065 := by
  intro p hp
  have h : env37065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37064_37065 : H12AffineEnvironment.transform 0 1 env37064 = env37065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env37064 == env37065) = true)

def env37066 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1345,65665,77934,13341,4096,476,16,69649,70887,78894,77840,1297,74815,81226,8204,8200,257,1281,1345,79470]

theorem envBound37066 : H12AffineFastState.Bounded env37066 := by
  intro p hp
  have h : env37066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37039_37066 : H12AffineEnvironment.transform 17 65665 env37039 = env37066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env37039 == env37066) = true)

theorem identity37066 : scanCanonicalize (H12AffineFastState.compose env37066 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound37066 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env37067 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1297,9244,65536,1345,65665,73838,9245,0,476,16,65553,66791,74798,73744,1297,74815,77130,8204,8200,257,1281,1345,75374]

theorem envBound37067 : H12AffineFastState.Bounded env37067 := by
  intro p hp
  have h : env37067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37066_37067 : H12AffineEnvironment.transform 11 0 env37066 = env37067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env37066 == env37067) = true)

def env37068 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,0,8192,1297,9244,65536,1297,65665,73790,9245,0,396,16,65553,66743,74798,73744,1297,74815,77082,8204,8200,257,1281,1297,75326]

theorem envBound37068 : H12AffineFastState.Bounded env37068 := by
  intro p hp
  have h : env37068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37067_37068 : H12AffineEnvironment.transform 5 16 env37067 = env37068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env37067 == env37068) = true)

theorem identity37068 : scanCanonicalize (H12AffineFastState.compose env37068 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 9514) := by decide +kernel

theorem selectedBound37068 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env37069 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,0,8192,1297,9244,9514,1297,9643,1300,9245,0,396,16,9531,8605,260,1338,1297,277,2096,8204,8200,257,1281,1297,788]

theorem envBound37069 : H12AffineFastState.Bounded env37069 := by
  intro p hp
  have h : env37069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37068_37069 : H12AffineEnvironment.transform 15 9514 env37068 = env37069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9514 env37068 == env37069) = true)

theorem identity37069 : scanCanonicalize (H12AffineFastState.compose env37069 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound37069 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env37070 : List Nat := [2,4,8,16,32,16,128,256,512,4,2048,0,8192,277,8216,8494,277,8623,272,8217,0,396,16,8511,8605,260,318,277,277,2096,8204,8200,257,261,277,788]

theorem envBound37070 : H12AffineFastState.Bounded env37070 := by
  intro p hp
  have h : env37070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37069_37070 : H12AffineEnvironment.transform 9 4 env37069 = env37070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env37069 == env37070) = true)

theorem identity37070 : scanCanonicalize (H12AffineFastState.compose env37070 (packedSelected [0,2,3,7,8,11] rootPS)) = affineNative (2^(8+1) ^^^ 391) := by decide +kernel

theorem selectedBound37070 : packedSelected [0,2,3,7,8,11] rootPS < 2^1333 := by decide +kernel

def env37071 : List Nat := [2,4,8,16,32,16,128,256,391,4,2048,0,8192,277,8216,8494,277,8623,272,8217,0,396,16,8511,8605,260,318,277,277,2096,8204,8200,257,261,277,147]

theorem envBound37071 : H12AffineFastState.Bounded env37071 := by
  intro p hp
  have h : env37071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37070_37071 : H12AffineEnvironment.transform 8 391 env37070 = env37071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 391 env37070 == env37071) = true)

theorem identity37071 : scanCanonicalize (H12AffineFastState.compose env37071 (packedSelected [0,1,7,8,10,17,18,19] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound37071 : packedSelected [0,1,7,8,10,17,18,19] rootPS < 2^1333 := by decide +kernel

def env37072 : List Nat := [2,4,8,16,32,16,128,256,391,4,1,0,8192,277,8216,8494,277,8623,272,8217,0,396,16,8511,8605,260,318,277,277,49,8204,8200,257,261,277,147]

theorem envBound37072 : H12AffineFastState.Bounded env37072 := by
  intro p hp
  have h : env37072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37071_37072 : H12AffineEnvironment.transform 10 1 env37071 = env37072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env37071 == env37072) = true)

theorem identity37072 : scanCanonicalize (H12AffineFastState.compose env37072 (packedSelected [3,5,10,12,13] rootPS)) = affineNative (2^(12+1) ^^^ 295) := by decide +kernel

theorem selectedBound37072 : packedSelected [3,5,10,12,13] rootPS < 2^1333 := by decide +kernel

def env37073 : List Nat := [2,4,8,16,32,16,128,256,391,4,1,0,295,277,319,9,277,136,272,318,0,396,16,24,186,260,318,277,277,49,299,303,257,261,277,147]

theorem envBound37073 : H12AffineFastState.Bounded env37073 := by
  intro p hp
  have h : env37073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37072_37073 : H12AffineEnvironment.transform 12 295 env37072 = env37073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 295 env37072 == env37073) = true)

theorem identity37073 : scanCanonicalize (H12AffineFastState.compose env37073 (packedSelected [1,3,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 183) := by decide +kernel

theorem selectedBound37073 : packedSelected [1,3,4,9] rootPS < 2^1333 := by decide +kernel

def env37074 : List Nat := [2,4,8,16,32,16,128,183,48,4,1,0,144,162,136,9,162,136,167,137,0,59,16,24,186,179,137,162,162,49,156,152,182,178,162,147]

theorem envBound37074 : H12AffineFastState.Bounded env37074 := by
  intro p hp
  have h : env37074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37073_37074 : H12AffineEnvironment.transform 7 183 env37073 = env37074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 183 env37073 == env37074) = true)

theorem identity37074 : scanCanonicalize (H12AffineFastState.compose env37074 (packedSelected [2,4,7] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound37074 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env37075 : List Nat := [2,4,8,11,32,11,128,172,43,4,1,0,139,162,136,9,162,136,167,137,0,32,11,3,161,168,137,162,162,42,135,131,173,169,162,136]

theorem envBound37075 : H12AffineFastState.Bounded env37075 := by
  intro p hp
  have h : env37075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37074_37075 : H12AffineEnvironment.transform 3 11 env37074 = env37075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env37074 == env37075) = true)

theorem identity37075 : scanCanonicalize (H12AffineFastState.compose env37075 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound37075 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37076 : List Nat := [2,4,8,11,32,11,35,15,43,4,1,0,40,1,43,9,1,43,4,42,0,32,11,3,2,11,42,1,1,42,36,32,14,10,1,43]

theorem envBound37076 : H12AffineFastState.Bounded env37076 := by
  intro p hp
  have h : env37076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37075_37076 : H12AffineEnvironment.transform 6 35 env37075 = env37076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env37075 == env37076) = true)

theorem identity37076 : scanCanonicalize (H12AffineFastState.compose env37076 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound37076 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env37077 : List Nat := [2,4,8,11,10,11,9,15,1,4,1,0,2,1,1,9,1,1,4,0,0,10,11,3,2,11,0,1,1,0,14,10,14,10,1,1]

theorem envBound37077 : H12AffineFastState.Bounded env37077 := by
  intro p hp
  have h : env37077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37076_37077 : H12AffineEnvironment.transform 4 10 env37076 = env37077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env37076 == env37077) = true)

theorem identity37077 : scanCanonicalize (H12AffineFastState.compose env37077 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound37077 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37078 : List Nat := [2,4,5,6,7,6,4,2,1,4,1,0,2,1,1,4,1,1,4,0,0,7,6,3,2,6,0,1,1,0,3,7,3,7,1,1]

theorem envBound37078 : H12AffineFastState.Bounded env37078 := by
  intro p hp
  have h : env37078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37077_37078 : H12AffineEnvironment.transform 2 5 env37077 = env37078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env37077 == env37078) = true)

def env37079 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,0,8192,1297,9244,65536,1296,65665,73791,9245,0,397,16,65553,66742,74798,73744,1297,74815,77083,8204,8200,257,1281,1296,75327]

theorem envBound37079 : H12AffineFastState.Bounded env37079 := by
  intro p hp
  have h : env37079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37067_37079 : H12AffineEnvironment.transform 5 17 env37067 = env37079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env37067 == env37079) = true)

theorem identity37079 : scanCanonicalize (H12AffineFastState.compose env37079 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound37079 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env37080 : List Nat := [2,4,8,16,32,17,128,20,512,1024,2048,0,8192,1029,9244,65536,1028,65665,73791,9245,0,153,16,65553,66742,74798,73744,1029,74815,76815,8204,8200,21,1045,1028,75327]

theorem envBound37080 : H12AffineFastState.Bounded env37080 := by
  intro p hp
  have h : env37080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37079_37080 : H12AffineEnvironment.transform 7 20 env37079 = env37080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env37079 == env37080) = true)

theorem identity37080 : scanCanonicalize (H12AffineFastState.compose env37080 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound37080 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env37081 : List Nat := [2,4,8,16,32,17,128,20,512,4,2048,0,8192,1,8216,65536,0,65665,73791,8217,0,153,16,65553,65714,73770,73744,1,73787,75787,8204,8200,21,17,0,74299]

theorem envBound37081 : H12AffineFastState.Bounded env37081 := by
  intro p hp
  have h : env37081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37080_37081 : H12AffineEnvironment.transform 9 4 env37080 = env37081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env37080 == env37081) = true)

theorem identity37081 : scanCanonicalize (H12AffineFastState.compose env37081 (packedSelected [0,1,3,7,10,11,17,19] rootPS)) = affineNative (2^(12+1) ^^^ 139) := by decide +kernel

theorem selectedBound37081 : packedSelected [0,1,3,7,10,11,17,19] rootPS < 2^1333 := by decide +kernel

def env37082 : List Nat := [2,4,8,16,32,17,128,20,512,4,2048,0,139,1,147,65536,0,65665,65716,146,0,153,16,65553,65714,65697,65691,1,65712,67712,135,131,21,17,0,66224]

theorem envBound37082 : H12AffineFastState.Bounded env37082 := by
  intro p hp
  have h : env37082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37081_37082 : H12AffineEnvironment.transform 12 139 env37081 = env37082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 139 env37081 == env37082) = true)

theorem identity37082 : scanCanonicalize (H12AffineFastState.compose env37082 (packedSelected [2,3,8,10,13,15] rootPS)) = affineNative (2^(15+1) ^^^ 641) := by decide +kernel

theorem selectedBound37082 : packedSelected [2,3,8,10,13,15] rootPS < 2^1333 := by decide +kernel

def env37083 : List Nat := [2,4,8,16,32,17,128,20,512,4,2048,0,139,1,147,641,0,512,565,146,0,153,16,656,563,544,538,1,561,2561,135,131,21,17,0,49]

theorem envBound37083 : H12AffineFastState.Bounded env37083 := by
  intro p hp
  have h : env37083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37082_37083 : H12AffineEnvironment.transform 15 641 env37082 = env37083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 641 env37082 == env37083) = true)

theorem identity37083 : scanCanonicalize (H12AffineFastState.compose env37083 (packedSelected [1,2,8,13] rootPS)) = affineNative (2^(8+1) ^^^ 147) := by decide +kernel

theorem selectedBound37083 : packedSelected [1,2,8,13] rootPS < 2^1333 := by decide +kernel

def env37084 : List Nat := [2,4,8,16,32,17,128,20,147,4,2048,0,139,1,147,18,0,147,166,146,0,153,16,3,160,179,137,1,162,2194,135,131,21,17,0,49]

theorem envBound37084 : H12AffineFastState.Bounded env37084 := by
  intro p hp
  have h : env37084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37083_37084 : H12AffineEnvironment.transform 8 147 env37083 = env37084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 147 env37083 == env37084) = true)

theorem identity37084 : scanCanonicalize (H12AffineFastState.compose env37084 (packedSelected [0,2,3,4,8,10] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound37084 : packedSelected [0,2,3,4,8,10] rootPS < 2^1333 := by decide +kernel

def env37085 : List Nat := [2,4,8,16,32,17,128,20,147,4,0,0,139,1,147,18,0,147,166,146,0,153,16,3,160,179,137,1,162,146,135,131,21,17,0,49]

theorem envBound37085 : H12AffineFastState.Bounded env37085 := by
  intro p hp
  have h : env37085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37084_37085 : H12AffineEnvironment.transform 10 0 env37084 = env37085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env37084 == env37085) = true)

def env37086 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16465,262144,95615,32769,4096,61649,17,284033,86518,94526,77841,1296,74815,96347,381312,365716,257,16401,1345,95103]

theorem envBound37086 : H12AffineFastState.Bounded env37086 := by
  intro p hp
  have h : env37086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37018_37086 : H12AffineEnvironment.transform 16 16465 env37018 = env37086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16465 env37018 == env37086) = true)

def env37087 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1345,262144,77935,32769,4096,46529,17,266385,70886,78894,77841,1296,74815,81227,365712,365716,257,1281,1345,79471]

theorem envBound37087 : H12AffineFastState.Bounded env37087 := by
  intro p hp
  have h : env37087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37086_37087 : H12AffineEnvironment.transform 13 1296 env37086 = env37087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env37086 == env37087) = true)

theorem identity37087 : scanCanonicalize (H12AffineFastState.compose env37087 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound37087 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env37088 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1345,262144,77935,13341,4096,477,17,266385,70886,78894,77841,1296,74815,81227,336012,336008,257,1281,1345,79471]

theorem envBound37088 : H12AffineFastState.Bounded env37088 := by
  intro p hp
  have h : env37088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37087_37088 : H12AffineEnvironment.transform 14 13340 env37087 = env37088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env37087 == env37088) = true)

def env37089 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1345,65664,77935,13341,4096,477,17,69649,70886,78894,77841,1296,74815,81227,8204,8200,257,1281,1345,79471]

theorem envBound37089 : H12AffineFastState.Bounded env37089 := by
  intro p hp
  have h : env37089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37088_37089 : H12AffineEnvironment.transform 17 65664 env37088 = env37089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env37088 == env37089) = true)

theorem identity37089 : scanCanonicalize (H12AffineFastState.compose env37089 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5384) := by decide +kernel

theorem selectedBound37089 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env37090 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5384,1296,276,65536,1345,65664,66919,277,4096,477,17,69649,70886,65830,66841,1296,69943,67651,5380,5376,257,1281,1345,66407]

theorem envBound37090 : H12AffineFastState.Bounded env37090 := by
  intro p hp
  have h : env37090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37089_37090 : H12AffineEnvironment.transform 12 5384 env37089 = env37090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5384 env37089 == env37090) = true)

def env37091 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,5384,1296,276,65536,1297,65664,66871,277,4096,397,17,69649,70838,65830,66841,1296,69943,67603,5380,5376,257,1281,1297,66359]

theorem envBound37091 : H12AffineFastState.Bounded env37091 := by
  intro p hp
  have h : env37091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37090_37091 : H12AffineEnvironment.transform 5 16 env37090 = env37091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env37090 == env37091) = true)

theorem identity37091 : scanCanonicalize (H12AffineFastState.compose env37091 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound37091 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env37092 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,277,1053,1296,276,65536,1297,65664,66871,277,277,397,17,65796,66979,65830,66841,1296,65570,67603,1041,1045,257,1281,1297,66359]

theorem envBound37092 : H12AffineFastState.Bounded env37092 := by
  intro p hp
  have h : env37092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37091_37092 : H12AffineEnvironment.transform 11 277 env37091 = env37092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env37091 == env37092) = true)

theorem identity37092 : scanCanonicalize (H12AffineFastState.compose env37092 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound37092 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env37093 : List Nat := [2,4,8,16,32,16,128,256,512,4,2048,277,25,276,276,65536,277,65664,65843,277,277,397,17,65796,65959,65830,65821,276,65570,67603,21,17,257,261,277,66359]

theorem envBound37093 : H12AffineFastState.Bounded env37093 := by
  intro p hp
  have h : env37093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37092_37093 : H12AffineEnvironment.transform 9 4 env37092 = env37093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env37092 == env37093) = true)

theorem identity37093 : scanCanonicalize (H12AffineFastState.compose env37093 (packedSelected [0,2,7,10,18,19] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound37093 : packedSelected [0,2,7,10,18,19] rootPS < 2^1333 := by decide +kernel

def env37094 : List Nat := [2,4,8,16,32,16,128,256,293,4,2048,277,25,276,276,65536,277,65664,65843,277,277,397,17,65796,65959,65830,65821,276,65570,67603,21,17,257,261,277,65554]

theorem envBound37094 : H12AffineFastState.Bounded env37094 := by
  intro p hp
  have h : env37094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37093_37094 : H12AffineEnvironment.transform 8 293 env37093 = env37094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env37093 == env37094) = true)

theorem identity37094 : scanCanonicalize (H12AffineFastState.compose env37094 (packedSelected [0,2,3,5,7,11,12,13,15,17] rootPS)) = affineNative (2^(15+1) ^^^ 311) := by decide +kernel

theorem selectedBound37094 : packedSelected [0,2,3,5,7,11,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env37095 : List Nat := [2,4,8,16,32,16,128,256,293,4,2048,277,25,276,276,311,277,439,4,277,277,397,17,51,144,17,42,276,277,2340,21,17,257,261,277,293]

theorem envBound37095 : H12AffineFastState.Bounded env37095 := by
  intro p hp
  have h : env37095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37094_37095 : H12AffineEnvironment.transform 15 311 env37094 = env37095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 311 env37094 == env37095) = true)

theorem identity37095 : scanCanonicalize (H12AffineFastState.compose env37095 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound37095 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37096 : List Nat := [2,4,8,16,32,16,128,256,293,4,1,277,25,276,276,311,277,439,4,277,277,397,17,51,144,17,42,276,277,293,21,17,257,261,277,293]

theorem envBound37096 : H12AffineFastState.Bounded env37096 := by
  intro p hp
  have h : env37096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37095_37096 : H12AffineEnvironment.transform 10 1 env37095 = env37096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env37095 == env37096) = true)

theorem identity37096 : scanCanonicalize (H12AffineFastState.compose env37096 (packedSelected [0,1,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound37096 : packedSelected [0,1,3,5] rootPS < 2^1333 := by decide +kernel

def env37097 : List Nat := [2,4,8,16,32,16,18,256,293,4,1,277,25,276,276,311,277,293,4,277,277,287,17,51,2,17,42,276,277,293,21,17,257,261,277,293]

theorem envBound37097 : H12AffineFastState.Bounded env37097 := by
  intro p hp
  have h : env37097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37096_37097 : H12AffineEnvironment.transform 6 18 env37096 = env37097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env37096 == env37097) = true)

theorem identity37097 : scanCanonicalize (H12AffineFastState.compose env37097 (packedSelected [0,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound37097 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env37098 : List Nat := [2,4,8,16,32,16,18,37,0,4,1,48,25,49,49,18,48,0,4,48,48,58,17,51,2,17,42,49,48,0,21,17,36,32,48,0]

theorem envBound37098 : H12AffineFastState.Bounded env37098 := by
  intro p hp
  have h : env37098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37097_37098 : H12AffineEnvironment.transform 7 37 env37097 = env37098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env37097 == env37098) = true)

def env37099 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,5384,1296,276,65536,1296,65664,66870,277,4096,396,17,69649,70839,65830,66841,1296,69943,67602,5380,5376,257,1281,1296,66358]

theorem envBound37099 : H12AffineFastState.Bounded env37099 := by
  intro p hp
  have h : env37099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37090_37099 : H12AffineEnvironment.transform 5 17 env37090 = env37099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env37090 == env37099) = true)

theorem identity37099 : scanCanonicalize (H12AffineFastState.compose env37099 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 4131) := by decide +kernel

theorem selectedBound37099 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env37100 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,5384,1296,276,4131,1296,4259,5397,277,4096,396,17,50,1172,4357,5434,1296,276,6193,5380,5376,257,1281,1296,4885]

theorem envBound37100 : H12AffineFastState.Bounded env37100 := by
  intro p hp
  have h : env37100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37099_37100 : H12AffineEnvironment.transform 15 4131 env37099 = env37100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4131 env37099 == env37100) = true)

theorem identity37100 : scanCanonicalize (H12AffineFastState.compose env37100 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound37100 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env37101 : List Nat := [2,4,8,16,32,17,128,256,512,4,2048,4096,4364,276,276,4131,276,4259,4369,277,4096,396,17,50,144,4357,4414,276,276,6193,4352,4356,257,261,276,4885]

theorem envBound37101 : H12AffineFastState.Bounded env37101 := by
  intro p hp
  have h : env37101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37100_37101 : H12AffineEnvironment.transform 9 4 env37100 = env37101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env37100 == env37101) = true)

theorem identity37101 : scanCanonicalize (H12AffineFastState.compose env37101 (packedSelected [0,2,3,7,8,10,12,15,17,18,19] rootPS)) = affineNative (2^(11+1) ^^^ 136) := by decide +kernel

theorem selectedBound37101 : packedSelected [0,2,3,7,8,10,12,15,17,18,19] rootPS < 2^1333 := by decide +kernel

def env37102 : List Nat := [2,4,8,16,32,17,128,256,512,4,2048,136,388,276,276,171,276,43,409,277,136,396,17,50,144,397,438,276,276,2233,392,396,257,261,276,925]

theorem envBound37102 : H12AffineFastState.Bounded env37102 := by
  intro p hp
  have h : env37102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37101_37102 : H12AffineEnvironment.transform 11 136 env37101 = env37102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 136 env37101 == env37102) = true)

theorem identity37102 : scanCanonicalize (H12AffineFastState.compose env37102 (packedSelected [2,13] rootPS)) = affineNative (2^(10+1) ^^^ 788) := by decide +kernel

theorem selectedBound37102 : packedSelected [2,13] rootPS < 2^1333 := by decide +kernel

def env37103 : List Nat := [2,4,8,16,32,17,128,256,512,4,788,136,388,276,276,171,276,43,409,277,136,396,17,50,144,397,438,276,276,941,392,396,257,261,276,925]

theorem envBound37103 : H12AffineFastState.Bounded env37103 := by
  intro p hp
  have h : env37103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37102_37103 : H12AffineEnvironment.transform 10 788 env37102 = env37103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 788 env37102 == env37103) = true)

theorem identity37103 : scanCanonicalize (H12AffineFastState.compose env37103 (packedSelected [0,1,3,7,11] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound37103 : packedSelected [0,1,3,7,11] rootPS < 2^1333 := by decide +kernel

def env37104 : List Nat := [2,4,8,16,32,17,128,21,512,4,513,136,145,1,1,171,1,43,140,0,136,153,17,50,144,152,163,1,1,696,157,153,20,16,1,648]

theorem envBound37104 : H12AffineFastState.Bounded env37104 := by
  intro p hp
  have h : env37104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37103_37104 : H12AffineEnvironment.transform 7 21 env37103 = env37104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env37103 == env37104) = true)

theorem identity37104 : scanCanonicalize (H12AffineFastState.compose env37104 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound37104 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env37105 : List Nat := [2,4,8,16,32,17,128,21,0,4,1,136,145,1,1,171,1,43,140,0,136,153,17,50,144,152,163,1,1,184,157,153,20,16,1,136]

theorem envBound37105 : H12AffineFastState.Bounded env37105 := by
  intro p hp
  have h : env37105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37104_37105 : H12AffineEnvironment.transform 8 0 env37104 = env37105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env37104 == env37105) = true)

theorem identity37105 : scanCanonicalize (H12AffineFastState.compose env37105 (packedSelected [0,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 63) := by decide +kernel

theorem selectedBound37105 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env37106 : List Nat := [2,4,8,16,32,17,63,21,0,4,1,55,46,1,1,20,1,43,51,0,55,38,17,50,47,39,28,1,1,7,34,38,20,16,1,55]

theorem envBound37106 : H12AffineFastState.Bounded env37106 := by
  intro p hp
  have h : env37106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37105_37106 : H12AffineEnvironment.transform 6 63 env37105 = env37106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 63 env37105 == env37106) = true)

theorem identity37106 : scanCanonicalize (H12AffineFastState.compose env37106 (packedSelected [0,1,7] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound37106 : packedSelected [0,1,7] rootPS < 2^1333 := by decide +kernel

def env37107 : List Nat := [2,4,8,16,10,17,21,21,0,4,1,29,4,1,1,20,1,1,25,0,29,12,17,24,5,13,28,1,1,7,8,12,20,16,1,29]

theorem envBound37107 : H12AffineFastState.Bounded env37107 := by
  intro p hp
  have h : env37107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37106_37107 : H12AffineEnvironment.transform 4 10 env37106 = env37107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env37106 == env37107) = true)

def env37108 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1345,65665,77935,13341,4096,477,17,69648,70886,78894,77841,1296,74815,81227,8205,8201,257,1281,1345,79471]

theorem envBound37108 : H12AffineFastState.Bounded env37108 := by
  intro p hp
  have h : env37108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37088_37108 : H12AffineEnvironment.transform 17 65665 env37088 = env37108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env37088 == env37108) = true)

theorem identity37108 : scanCanonicalize (H12AffineFastState.compose env37108 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 73) := by decide +kernel

theorem selectedBound37108 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env37109 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,73,1296,5205,65536,1345,65665,69670,5204,4096,477,17,69648,70886,70759,69720,1296,66678,72962,68,64,257,1281,1345,71206]

theorem envBound37109 : H12AffineFastState.Bounded env37109 := by
  intro p hp
  have h : env37109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37108_37109 : H12AffineEnvironment.transform 12 73 env37108 = env37109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env37108 == env37109) = true)

def env37110 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,25,1296,5125,65536,1297,65665,69670,5124,4096,397,17,69648,70838,70711,69640,1296,66598,72962,20,16,257,1281,1297,71206]

theorem envBound37110 : H12AffineFastState.Bounded env37110 := by
  intro p hp
  have h : env37110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37109_37110 : H12AffineEnvironment.transform 5 16 env37109 = env37110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env37109 == env37110) = true)

theorem identity37110 : scanCanonicalize (H12AffineFastState.compose env37110 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound37110 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env37111 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,277,25,1296,1296,65536,1297,65665,65843,1297,277,397,17,65797,66979,66850,65821,1296,66598,68631,20,16,257,1281,1297,67379]

theorem envBound37111 : H12AffineFastState.Bounded env37111 := by
  intro p hp
  have h : env37111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37110_37111 : H12AffineEnvironment.transform 11 277 env37110 = env37111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env37110 == env37111) = true)

theorem identity37111 : scanCanonicalize (H12AffineFastState.compose env37111 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 311) := by decide +kernel

theorem selectedBound37111 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env37112 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,277,25,1296,1296,311,1297,438,4,1297,277,397,17,50,1172,1045,42,1296,1297,3360,20,16,257,1281,1297,1540]

theorem envBound37112 : H12AffineFastState.Bounded env37112 := by
  intro p hp
  have h : env37112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37111_37112 : H12AffineEnvironment.transform 15 311 env37111 = env37112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 311 env37111 == env37112) = true)

theorem identity37112 : scanCanonicalize (H12AffineFastState.compose env37112 (packedSelected [0,2,3,7,8,10,12,15,17,18,19] rootPS)) = affineNative (2^(8+1) ^^^ 163) := by decide +kernel

theorem selectedBound37112 : packedSelected [0,2,3,7,8,10,12,15,17,18,19] rootPS < 2^1333 := by decide +kernel

def env37113 : List Nat := [2,4,8,16,32,16,128,256,163,1024,2048,277,25,1296,1296,311,1297,438,4,1297,277,397,17,50,1172,1045,42,1296,1297,3360,20,16,257,1281,1297,1191]

theorem envBound37113 : H12AffineFastState.Bounded env37113 := by
  intro p hp
  have h : env37113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37112_37113 : H12AffineEnvironment.transform 8 163 env37112 = env37113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 163 env37112 == env37113) = true)

theorem identity37113 : scanCanonicalize (H12AffineFastState.compose env37113 (packedSelected [1,2,8,11,12,13,15,17,18] rootPS)) = affineNative (2^(9+1) ^^^ 386) := by decide +kernel

theorem selectedBound37113 : packedSelected [1,2,8,11,12,13,15,17,18] rootPS < 2^1333 := by decide +kernel

def env37114 : List Nat := [2,4,8,16,32,16,128,256,163,386,2048,277,25,146,146,311,147,438,4,147,277,397,17,50,278,407,42,146,147,2210,20,16,257,131,147,293]

theorem envBound37114 : H12AffineFastState.Bounded env37114 := by
  intro p hp
  have h : env37114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37113_37114 : H12AffineEnvironment.transform 9 386 env37113 = env37114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 386 env37113 == env37114) = true)

theorem identity37114 : scanCanonicalize (H12AffineFastState.compose env37114 (packedSelected [3,5,10,12,13] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound37114 : packedSelected [3,5,10,12,13] rootPS < 2^1333 := by decide +kernel

def env37115 : List Nat := [2,4,8,16,32,16,128,256,163,386,293,277,25,146,146,311,147,438,4,147,277,397,17,50,278,407,42,146,147,391,20,16,257,131,147,293]

end H12CloudChart2