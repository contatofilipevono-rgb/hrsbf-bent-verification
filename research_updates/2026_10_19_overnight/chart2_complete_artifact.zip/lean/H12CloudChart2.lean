import H12CloudChart2Proof107

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem rejected (f : Nat → Bool) (hm : packedModels f rootPS) : ¬H12CertificateBridge.Target (packedObservation f rootObs) :=
  H12AffineFastState.reject_identity H12CertificateBridge.Target rootPS rootObs ref0 f hm

#print axioms rejected

theorem rootPS_identity : rootPS = H12PackedRoots.rootPS 2 := by
  exact beq_iff_eq.mp (by decide +kernel : (rootPS == H12PackedRoots.rootPS 2) = true)

theorem rootObs_identity : rootObs = H12PackedRoots.rootEnv 2 := by
  exact beq_iff_eq.mp (by decide +kernel : (rootObs == H12PackedRoots.rootEnv 2) = true)

theorem refutation : H12AffineFastState.Refutes H12CertificateBridge.Target (H12PackedRoots.rootPS 2) (H12PackedRoots.rootEnv 2) H12AffineFastState.identityEnv := by
  have h := ref0
  rw [rootPS_identity, rootObs_identity] at h
  exact h

#print axioms refutation

end H12CloudChart2