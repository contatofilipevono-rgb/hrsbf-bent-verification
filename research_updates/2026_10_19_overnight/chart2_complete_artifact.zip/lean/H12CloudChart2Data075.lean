import H12CloudChart2Data074

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem leafIdentity18385 : H12AffineFastState.composeSystem env18385 rootObs = leafEnv18385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18385 rootObs == leafEnv18385) = true)

theorem terminalChecked18385 : H12PackedTerminal.terminalCheckFast leafEnv18385 active18385 tree18385 = true := by decide +kernel

def env18386 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,32768,65536,1345,262144,1024,32769,1345,4194304,64,16777216,8328,17,21331968,1345,1345,1073741824,16876544,4294967296,256,4315938986,1344,512]

theorem envBound18386 : H12AffineFastState.Bounded env18386 := by
  intro p hp
  have h : env18386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18250_18386 : H12AffineEnvironment.transform 13 1345 env18250 = env18386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env18250 == env18386) = true)

theorem identity18386 : scanCanonicalize (H12AffineFastState.compose env18386 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound18386 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env18387 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1297,32768,65536,1297,262144,1024,32769,1297,4194304,16,16777216,8328,17,21331968,1297,1297,1073741824,16876544,4294967296,256,4315938986,1296,512]

theorem envBound18387 : H12AffineFastState.Bounded env18387 := by
  intro p hp
  have h : env18387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18386_18387 : H12AffineEnvironment.transform 5 16 env18386 = env18387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env18386 == env18387) = true)

theorem identity18387 : scanCanonicalize (H12AffineFastState.compose env18387 (packedSelected [13,21] rootPS)) = affineNative (2^(31+1) ^^^ 4194440) := by decide +kernel

theorem selectedBound18387 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env18388 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1297,32768,65536,1297,262144,1024,32769,1297,4194304,16,16777216,8328,17,21331968,1297,1297,1073741824,16876544,4194440,256,16777250,1296,512]

theorem envBound18388 : H12AffineFastState.Bounded env18388 := by
  intro p hp
  have h : env18388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18387_18388 : H12AffineEnvironment.transform 31 4194440 env18387 = env18388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 4194440 env18387 == env18388) = true)

theorem identity18388 : scanCanonicalize (H12AffineFastState.compose env18388 (packedSelected [1,3,24,28] rootPS)) = affineNative (2^(29+1) ^^^ 21071872) := by decide +kernel

theorem selectedBound18388 : packedSelected [1,3,24,28] rootPS < 2^1333 := by decide +kernel

def env18389 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1297,32768,65536,1297,262144,1024,32769,1297,4194304,16,16777216,8328,17,21331968,1297,1297,21071872,16876544,4194440,256,16777250,1296,512]

theorem envBound18389 : H12AffineFastState.Bounded env18389 := by
  intro p hp
  have h : env18389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18388_18389 : H12AffineEnvironment.transform 29 21071872 env18388 = env18389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 21071872 env18388 == env18389) = true)

theorem identity18389 : scanCanonicalize (H12AffineFastState.compose env18389 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(23+1) ^^^ 338220) := by decide +kernel

theorem selectedBound18389 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env18390 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1297,32768,65536,1297,262144,1024,32769,1297,4194304,16,338220,8328,17,4237612,1297,1297,4497708,306476,4194440,256,338190,1296,512]

theorem envBound18390 : H12AffineFastState.Bounded env18390 := by
  intro p hp
  have h : env18390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18389_18390 : H12AffineEnvironment.transform 23 338220 env18389 = env18390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 338220 env18389 == env18390) = true)

theorem identity18390 : scanCanonicalize (H12AffineFastState.compose env18390 (packedSelected [0,1,3,5,7,8,11,12,15,18] rootPS)) = affineNative (2^(21+1) ^^^ 362634) := by decide +kernel

theorem selectedBound18390 : packedSelected [0,1,3,5,7,8,11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env18391 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1297,32768,65536,1297,262144,1024,32769,1297,362634,16,338220,8328,17,336294,1297,1297,76198,306476,362498,256,338190,1296,512]

theorem envBound18391 : H12AffineFastState.Bounded env18391 := by
  intro p hp
  have h : env18391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18390_18391 : H12AffineEnvironment.transform 21 362634 env18390 = env18391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 362634 env18390 == env18391) = true)

theorem identity18391 : scanCanonicalize (H12AffineFastState.compose env18391 (packedSelected [1,3,5,8,13,17] rootPS)) = affineNative (2^(17+1) ^^^ 2049) := by decide +kernel

theorem selectedBound18391 : packedSelected [1,3,5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env18392 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1297,32768,65536,1297,2049,1024,32769,1297,98443,16,74029,8328,17,76199,1297,1297,76198,42285,98307,256,73999,1296,512]

theorem envBound18392 : H12AffineFastState.Bounded env18392 := by
  intro p hp
  have h : env18392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18391_18392 : H12AffineEnvironment.transform 17 2049 env18391 = env18392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2049 env18391 == env18392) = true)

theorem identity18392 : scanCanonicalize (H12AffineFastState.compose env18392 (packedSelected [0,7] rootPS)) = affineNative (2^(15+1) ^^^ 33166) := by decide +kernel

theorem selectedBound18392 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env18393 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1297,32768,33166,1297,2049,1024,32769,1297,261,16,41123,8328,17,43049,1297,1297,43048,42285,397,256,41089,1296,512]

theorem envBound18393 : H12AffineFastState.Bounded env18393 := by
  intro p hp
  have h : env18393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18392_18393 : H12AffineEnvironment.transform 15 33166 env18392 = env18393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33166 env18392 == env18393) = true)

theorem identity18393 : scanCanonicalize (H12AffineFastState.compose env18393 (packedSelected [1,2,3,6,11,13] rootPS)) = affineNative (2^(14+1) ^^^ 2340) := by decide +kernel

theorem selectedBound18393 : packedSelected [1,2,3,6,11,13] rootPS < 2^1333 := by decide +kernel

def env18394 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1297,2340,2218,1297,2049,1024,2341,1297,261,16,10631,8328,17,8461,1297,1297,8460,11273,397,256,10661,1296,512]

theorem envBound18394 : H12AffineFastState.Bounded env18394 := by
  intro p hp
  have h : env18394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18393_18394 : H12AffineEnvironment.transform 14 2340 env18393 = env18394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2340 env18393 == env18394) = true)

theorem identity18394 : scanCanonicalize (H12AffineFastState.compose env18394 (packedSelected [11,12] rootPS)) = affineNative (2^(12+1) ^^^ 2317) := by decide +kernel

theorem selectedBound18394 : packedSelected [11,12] rootPS < 2^1333 := by decide +kernel

def env18395 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,2317,1297,2340,2218,1297,2049,1024,2341,1297,261,16,138,2437,17,2048,1297,1297,2049,1284,397,256,168,1296,512]

theorem envBound18395 : H12AffineFastState.Bounded env18395 := by
  intro p hp
  have h : env18395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18394_18395 : H12AffineEnvironment.transform 12 2317 env18394 = env18395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2317 env18394 == env18395) = true)

theorem identity18395 : scanCanonicalize (H12AffineFastState.compose env18395 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1556) := by decide +kernel

theorem selectedBound18395 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18396 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1556,1297,1817,1297,1840,1726,1297,1557,1024,1841,1297,261,16,138,1937,17,1556,1297,1297,1557,1284,397,256,168,1296,512]

theorem envBound18396 : H12AffineFastState.Bounded env18396 := by
  intro p hp
  have h : env18396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18395_18396 : H12AffineEnvironment.transform 10 1556 env18395 = env18396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1556 env18395 == env18396) = true)

theorem identity18396 : scanCanonicalize (H12AffineFastState.compose env18396 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound18396 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env18397 : List Nat := [2,4,8,16,32,16,128,256,137,1024,1181,1297,1424,1297,1465,1079,1297,1180,1024,1464,1297,261,16,138,1304,17,1181,1297,1297,1180,1284,397,256,168,1296,137]

theorem envBound18397 : H12AffineFastState.Bounded env18397 := by
  intro p hp
  have h : env18397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18396_18397 : H12AffineEnvironment.transform 8 137 env18396 = env18397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env18396 == env18397) = true)

def env18398 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,4194304,8388608,16777216,8328,8914001,134217728,8519744,676865,1073741824,25412673,4294967296,8536385,4315938986,164610304,512]

theorem envBound18398 : H12AffineFastState.Bounded env18398 := by
  intro p hp
  have h : env18398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17943_18398 : H12AffineEnvironment.transform 20 4097 env17943 = env18398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env17943 == env18398) = true)

theorem identity18398 : scanCanonicalize (H12AffineFastState.compose env18398 (packedSelected [14] rootPS)) = affineNative (2^(26+1) ^^^ 30261504) := by decide +kernel

theorem selectedBound18398 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env18399 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,4194304,8388608,16777216,8328,8914001,30261504,8519744,676865,1073741824,25412673,4294967296,8536385,4315938986,131072,512]

theorem envBound18399 : H12AffineFastState.Bounded env18399 := by
  intro p hp
  have h : env18399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18398_18399 : H12AffineEnvironment.transform 26 30261504 env18398 = env18399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30261504 env18398 == env18399) = true)

def env18400 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,4194304,147520,16777216,8328,672785,21987648,16384,676865,1073741824,16876545,4294967296,257,4315938986,131072,512]

theorem envBound18400 : H12AffineFastState.Bounded env18400 := by
  intro p hp
  have h : env18400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18399_18400 : H12AffineEnvironment.transform 22 147520 env18399 = env18400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147520 env18399 == env18400) = true)

theorem identity18400 : scanCanonicalize (H12AffineFastState.compose env18400 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(23+1) ^^^ 98564) := by decide +kernel

theorem selectedBound18400 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env18401 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,4194304,147520,98564,8328,672785,5111876,16384,676865,1073741824,1285,4294967296,257,4299260334,131072,512]

theorem envBound18401 : H12AffineFastState.Bounded env18401 := by
  intro p hp
  have h : env18401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18400_18401 : H12AffineEnvironment.transform 23 98564 env18400 = env18401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98564 env18400 == env18401) = true)

def env18402 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16384,262144,524288,32769,4097,4194304,64,98564,8328,525329,4997188,16384,529409,1073741824,1285,4294967296,257,4299260334,16384,512]

theorem envBound18402 : H12AffineFastState.Bounded env18402 := by
  intro p hp
  have h : env18402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18401_18402 : H12AffineEnvironment.transform 16 16384 env18401 = env18402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16384 env18401 == env18402) = true)

def env18403 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4096,32768,65536,4096,262144,524288,32769,4097,4194304,64,98564,8328,525329,4984900,4096,529409,1073741824,1285,4294967296,257,4299260334,4096,512]

theorem envBound18403 : H12AffineFastState.Bounded env18403 := by
  intro p hp
  have h : env18403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18402_18403 : H12AffineEnvironment.transform 13 4096 env18402 = env18403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4096 env18402 == env18403) = true)

def env18404 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4096,32768,65536,4096,262144,524288,32769,4097,10248,64,98564,8328,525329,800844,4096,529409,1073741824,1285,4294967296,257,4295076262,4096,512]

theorem envBound18404 : H12AffineFastState.Bounded env18404 := by
  intro p hp
  have h : env18404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18403_18404 : H12AffineEnvironment.transform 21 10248 env18403 = env18404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10248 env18403 == env18404) = true)

def env18405 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,4096,32768,65536,4096,262144,524288,32769,4097,8200,64,98564,8328,525329,798796,4096,529409,1073741824,1285,4294967296,257,4295074214,4096,512]

theorem envBound18405 : H12AffineFastState.Bounded env18405 := by
  intro p hp
  have h : env18405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18404_18405 : H12AffineEnvironment.transform 10 0 env18404 = env18405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env18404 == env18405) = true)

theorem identity18405 : scanCanonicalize (H12AffineFastState.compose env18405 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 820517) := by decide +kernel

theorem selectedBound18405 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env18406 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,4096,32768,65536,4096,262144,524288,32769,4097,8200,64,98564,8328,525329,798796,4096,529409,820517,1285,4294967296,257,4295074214,4096,512]

theorem envBound18406 : H12AffineFastState.Bounded env18406 := by
  intro p hp
  have h : env18406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18405_18406 : H12AffineEnvironment.transform 29 820517 env18405 = env18406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 820517 env18405 == env18406) = true)

theorem identity18406 : scanCanonicalize (H12AffineFastState.compose env18406 (packedSelected [0,3,4,7,9,10,18,19,23,24,32] rootPS)) = affineNative (2^(17+1) ^^^ 46441) := by decide +kernel

theorem selectedBound18406 : packedSelected [0,3,4,7,9,10,18,19,23,24,32] rootPS < 2^1333 := by decide +kernel

def env18407 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,4096,32768,65536,4096,46441,524288,32769,4097,8200,64,98564,8328,525329,558373,4096,529409,536652,1285,4294967296,257,4295074214,4096,512]

theorem envBound18407 : H12AffineFastState.Bounded env18407 := by
  intro p hp
  have h : env18407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18406_18407 : H12AffineEnvironment.transform 17 46441 env18406 = env18407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 46441 env18406 == env18407) = true)

theorem identity18407 : scanCanonicalize (H12AffineFastState.compose env18407 (packedSelected [4,9,20] rootPS)) = affineNative (2^(18+1) ^^^ 1025) := by decide +kernel

theorem selectedBound18407 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env18408 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,4096,32768,65536,4096,46441,1025,32769,4097,8200,64,98564,8328,16,33060,4096,4096,13389,1285,4294967296,257,4295074214,4096,512]

theorem envBound18408 : H12AffineFastState.Bounded env18408 := by
  intro p hp
  have h : env18408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18407_18408 : H12AffineEnvironment.transform 18 1025 env18407 = env18408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env18407 == env18408) = true)

theorem identity18408 : scanCanonicalize (H12AffineFastState.compose env18408 (packedSelected [0,7,18] rootPS)) = affineNative (2^(11+1) ^^^ 1344) := by decide +kernel

theorem selectedBound18408 : packedSelected [0,7,18] rootPS < 2^1333 := by decide +kernel

def env18409 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1344,8192,1344,32768,65536,1344,41001,1025,32769,1345,8200,64,98564,8328,16,33060,1344,1344,8461,1285,4294967296,257,4295074214,1344,512]

theorem envBound18409 : H12AffineFastState.Bounded env18409 := by
  intro p hp
  have h : env18409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18408_18409 : H12AffineEnvironment.transform 11 1344 env18408 = env18409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env18408 == env18409) = true)

theorem identity18409 : scanCanonicalize (H12AffineFastState.compose env18409 (packedSelected [1,3,10,13] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound18409 : packedSelected [1,3,10,13] rootPS < 2^1333 := by decide +kernel

def env18410 : List Nat := [2,4,8,16,32,17,128,256,512,1024,0,1297,8192,1297,32768,65536,1297,41001,1025,32769,1296,8200,17,98564,8328,16,33060,1297,1297,8461,1285,4294967296,257,4295074214,1297,512]

theorem envBound18410 : H12AffineFastState.Bounded env18410 := by
  intro p hp
  have h : env18410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18409_18410 : H12AffineEnvironment.transform 5 17 env18409 = env18410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env18409 == env18410) = true)

theorem identity18410 : scanCanonicalize (H12AffineFastState.compose env18410 (packedSelected [1,3] rootPS)) = affineNative (2^(14+1) ^^^ 293) := by decide +kernel

theorem selectedBound18410 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env18411 : List Nat := [2,4,8,16,32,17,128,256,512,1024,0,1297,8192,1297,293,65536,1297,8460,1025,292,1296,8200,17,65569,8328,16,1,1297,1297,8461,1285,4294967296,257,4295041155,1297,512]

theorem envBound18411 : H12AffineFastState.Bounded env18411 := by
  intro p hp
  have h : env18411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18410_18411 : H12AffineEnvironment.transform 14 293 env18410 = env18411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 293 env18410 == env18411) = true)

def env18412 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,4096,32768,65536,4096,262144,524288,32769,4097,8201,64,98564,8328,525329,798797,4096,529409,1073741824,1285,4294967296,257,4295074215,4096,512]

theorem envBound18412 : H12AffineFastState.Bounded env18412 := by
  intro p hp
  have h : env18412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18404_18412 : H12AffineEnvironment.transform 10 1 env18404 = env18412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env18404 == env18412) = true)

theorem identity18412 : scanCanonicalize (H12AffineFastState.compose env18412 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 13389) := by decide +kernel

theorem selectedBound18412 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env18413 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,4096,32768,65536,4096,262144,524288,32769,4097,8201,64,98564,8328,525329,798797,4096,529409,13389,1285,4294967296,257,4295074215,4096,512]

theorem envBound18413 : H12AffineFastState.Bounded env18413 := by
  intro p hp
  have h : env18413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18412_18413 : H12AffineEnvironment.transform 29 13389 env18412 = env18413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 13389 env18412 == env18413) = true)

theorem identity18413 : scanCanonicalize (H12AffineFastState.compose env18413 (packedSelected [0,3,4,7,9,10,18,19,23,24,32] rootPS)) = affineNative (2^(17+1) ^^^ 46440) := by decide +kernel

theorem selectedBound18413 : packedSelected [0,3,4,7,9,10,18,19,23,24,32] rootPS < 2^1333 := by decide +kernel

def env18414 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,4096,32768,65536,4096,46440,524288,32769,4097,8201,64,98564,8328,525329,558373,4096,529409,13389,1285,4294967296,257,4295074215,4096,512]

theorem envBound18414 : H12AffineFastState.Bounded env18414 := by
  intro p hp
  have h : env18414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18413_18414 : H12AffineEnvironment.transform 17 46440 env18413 = env18414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 46440 env18413 == env18414) = true)

theorem identity18414 : scanCanonicalize (H12AffineFastState.compose env18414 (packedSelected [0,7,18,20,23] rootPS)) = affineNative (2^(18+1) ^^^ 1025) := by decide +kernel

theorem selectedBound18414 : packedSelected [0,7,18,20,23] rootPS < 2^1333 := by decide +kernel

def env18415 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,4096,32768,65536,4096,46440,1025,32769,4097,8201,64,98564,8328,16,33060,4096,4096,13389,1285,4294967296,257,4295074215,4096,512]

theorem envBound18415 : H12AffineFastState.Bounded env18415 := by
  intro p hp
  have h : env18415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18414_18415 : H12AffineEnvironment.transform 18 1025 env18414 = env18415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env18414 == env18415) = true)

theorem identity18415 : scanCanonicalize (H12AffineFastState.compose env18415 (packedSelected [0,7,18] rootPS)) = affineNative (2^(11+1) ^^^ 1344) := by decide +kernel

theorem selectedBound18415 : packedSelected [0,7,18] rootPS < 2^1333 := by decide +kernel

def env18416 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1344,8192,1344,32768,65536,1344,41000,1025,32769,1345,8201,64,98564,8328,16,33060,1344,1344,8461,1285,4294967296,257,4295074215,1344,512]

theorem envBound18416 : H12AffineFastState.Bounded env18416 := by
  intro p hp
  have h : env18416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18415_18416 : H12AffineEnvironment.transform 11 1344 env18415 = env18416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env18415 == env18416) = true)

theorem identity18416 : scanCanonicalize (H12AffineFastState.compose env18416 (packedSelected [1,3,10,13] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound18416 : packedSelected [1,3,10,13] rootPS < 2^1333 := by decide +kernel

def env18417 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1,1297,8192,1297,32768,65536,1297,41000,1025,32769,1296,8201,17,98564,8328,16,33060,1297,1297,8461,1285,4294967296,257,4295074215,1297,512]

theorem envBound18417 : H12AffineFastState.Bounded env18417 := by
  intro p hp
  have h : env18417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18416_18417 : H12AffineEnvironment.transform 5 17 env18416 = env18417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env18416 == env18417) = true)

theorem identity18417 : scanCanonicalize (H12AffineFastState.compose env18417 (packedSelected [1,3] rootPS)) = affineNative (2^(14+1) ^^^ 292) := by decide +kernel

theorem selectedBound18417 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env18418 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1,1297,8192,1297,292,65536,1297,8460,1025,293,1296,8201,17,65568,8328,16,0,1297,1297,8461,1285,4294967296,257,4295041155,1297,512]

theorem envBound18418 : H12AffineFastState.Bounded env18418 := by
  intro p hp
  have h : env18418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18417_18418 : H12AffineEnvironment.transform 14 292 env18417 = env18418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 292 env18417 == env18418) = true)

def env18419 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4096,32768,65536,4096,262144,524288,32769,4097,10249,64,98564,8328,525329,800845,4096,529409,1073741824,1285,4294967296,257,4295076263,4096,512]

theorem envBound18419 : H12AffineFastState.Bounded env18419 := by
  intro p hp
  have h : env18419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18403_18419 : H12AffineEnvironment.transform 21 10249 env18403 = env18419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10249 env18403 == env18419) = true)

def env18420 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,4096,32768,65536,4096,262144,524288,32769,4097,8201,64,98564,8328,525329,798797,4096,529409,1073741824,1285,4294967296,257,4295074215,4096,512]

theorem envBound18420 : H12AffineFastState.Bounded env18420 := by
  intro p hp
  have h : env18420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18419_18420 : H12AffineEnvironment.transform 10 0 env18419 = env18420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env18419 == env18420) = true)

theorem identity18420 : scanCanonicalize (H12AffineFastState.compose env18420 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 46440) := by decide +kernel

theorem selectedBound18420 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env18421 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,4096,32768,65536,4096,262144,524288,32769,4097,8201,64,98564,8328,525329,798797,4096,529409,46440,1285,4294967296,257,4295074215,4096,512]

theorem envBound18421 : H12AffineFastState.Bounded env18421 := by
  intro p hp
  have h : env18421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18420_18421 : H12AffineEnvironment.transform 29 46440 env18420 = env18421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 46440 env18420 == env18421) = true)

theorem identity18421 : scanCanonicalize (H12AffineFastState.compose env18421 (packedSelected [0,3,4,7,9,10,18,19,23,24] rootPS)) = affineNative (2^(11+1) ^^^ 1344) := by decide +kernel

theorem selectedBound18421 : packedSelected [0,3,4,7,9,10,18,19,23,24] rootPS < 2^1333 := by decide +kernel

def env18422 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1344,8192,1344,32768,65536,1344,262144,524288,32769,1345,8201,64,98564,8328,525329,795917,1344,524609,41000,1285,4294967296,257,4295074215,1344,512]

theorem envBound18422 : H12AffineFastState.Bounded env18422 := by
  intro p hp
  have h : env18422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18421_18422 : H12AffineEnvironment.transform 11 1344 env18421 = env18422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env18421 == env18422) = true)

def env18423 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1344,8192,1344,32768,65536,1344,262144,304168,32769,1345,8201,64,98564,8328,303161,33061,1344,304489,41000,1285,4294967296,257,4295074215,1344,512]

theorem envBound18423 : H12AffineFastState.Bounded env18423 := by
  intro p hp
  have h : env18423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18422_18423 : H12AffineEnvironment.transform 18 304168 env18422 = env18423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 304168 env18422 == env18423) = true)

theorem identity18423 : scanCanonicalize (H12AffineFastState.compose env18423 (packedSelected [4,9,18] rootPS)) = affineNative (2^(17+1) ^^^ 8461) := by decide +kernel

theorem selectedBound18423 : packedSelected [4,9,18] rootPS < 2^1333 := by decide +kernel

def env18424 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1344,8192,1344,32768,65536,1344,8461,34085,32769,1345,8201,64,98564,8328,33076,33061,1344,33892,41000,1285,4294967296,257,4295074215,1344,512]

theorem envBound18424 : H12AffineFastState.Bounded env18424 := by
  intro p hp
  have h : env18424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18423_18424 : H12AffineEnvironment.transform 17 8461 env18423 = env18424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8461 env18423 == env18424) = true)

theorem identity18424 : scanCanonicalize (H12AffineFastState.compose env18424 (packedSelected [0,3,7,8,12,15,17] rootPS)) = affineNative (2^(14+1) ^^^ 292) := by decide +kernel

theorem selectedBound18424 : packedSelected [0,3,7,8,12,15,17] rootPS < 2^1333 := by decide +kernel

def env18425 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1344,8192,1344,292,65536,1344,8461,1025,293,1345,8201,64,65568,8328,16,1,1344,1344,8460,1285,4294967296,257,4295041155,1344,512]

theorem envBound18425 : H12AffineFastState.Bounded env18425 := by
  intro p hp
  have h : env18425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18424_18425 : H12AffineEnvironment.transform 14 292 env18424 = env18425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 292 env18424 == env18425) = true)

theorem identity18425 : scanCanonicalize (H12AffineFastState.compose env18425 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound18425 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env18426 : List Nat := [2,4,8,16,32,17,128,256,512,1024,0,1297,8192,1297,292,65536,1297,8461,1025,293,1296,8201,17,65568,8328,16,1,1297,1297,8460,1285,4294967296,257,4295041155,1297,512]

theorem envBound18426 : H12AffineFastState.Bounded env18426 := by
  intro p hp
  have h : env18426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18425_18426 : H12AffineEnvironment.transform 5 17 env18425 = env18426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env18425 == env18426) = true)

def env18427 : List Nat := [2,4,8,16,32,17,128,256,512,272,0,1,8192,1,292,65536,1,8461,273,293,0,8201,17,65568,8328,16,1,1,1,8460,21,4294967296,257,4295041155,1,512]

theorem envBound18427 : H12AffineFastState.Bounded env18427 := by
  intro p hp
  have h : env18427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18426_18427 : H12AffineEnvironment.transform 9 272 env18426 = env18427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env18426 == env18427) = true)

def env18428 : List Nat := [2,4,8,16,32,17,128,36,512,52,0,1,8192,1,0,65536,1,8233,53,1,0,8201,17,65568,8328,16,1,1,1,8232,21,4294967296,37,4295041155,1,512]

theorem envBound18428 : H12AffineFastState.Bounded env18428 := by
  intro p hp
  have h : env18428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18427_18428 : H12AffineEnvironment.transform 7 36 env18427 = env18428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env18427 == env18428) = true)

def env18429 : List Nat := [2,4,8,16,32,17,128,36,0,52,0,1,8192,1,0,65536,1,8233,53,1,0,8201,17,65568,8328,16,1,1,1,8232,21,4294967296,37,4295041155,1,0]

theorem envBound18429 : H12AffineFastState.Bounded env18429 := by
  intro p hp
  have h : env18429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18428_18429 : H12AffineEnvironment.transform 8 0 env18428 = env18429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env18428 == env18429) = true)

theorem identity18429 : scanCanonicalize (H12AffineFastState.compose env18429 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 1) := by decide +kernel

theorem selectedBound18429 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18430 : List Nat := [2,4,8,16,32,17,128,36,0,52,0,1,8192,1,0,65536,1,8233,53,1,0,8201,17,65568,8328,16,1,1,1,8232,21,1,37,73858,1,0]

theorem envBound18430 : H12AffineFastState.Bounded env18430 := by
  intro p hp
  have h : env18430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18429_18430 : H12AffineEnvironment.transform 31 1 env18429 = env18430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1 env18429 == env18430) = true)

def env18431 : List Nat := [2,4,8,16,32,17,128,36,0,52,0,1,160,1,0,65536,1,137,53,1,0,169,17,65568,40,16,1,1,1,136,21,1,37,65570,1,0]

theorem envBound18431 : H12AffineFastState.Bounded env18431 := by
  intro p hp
  have h : env18431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18430_18431 : H12AffineEnvironment.transform 12 160 env18430 = env18431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env18430 == env18431) = true)

def env18432 : List Nat := [2,4,8,16,0,17,128,4,0,20,0,1,128,1,0,65536,1,137,21,1,0,137,17,65536,8,16,1,1,1,136,21,1,5,65538,1,0]

theorem envBound18432 : H12AffineFastState.Bounded env18432 := by
  intro p hp
  have h : env18432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18431_18432 : H12AffineEnvironment.transform 4 0 env18431 = env18432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env18431 == env18432) = true)

theorem identity18432 : scanCanonicalize (H12AffineFastState.compose env18432 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 2) := by decide +kernel

theorem selectedBound18432 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18433 : List Nat := [2,4,8,16,0,17,128,4,0,20,0,1,128,1,0,2,1,137,21,1,0,137,17,2,8,16,1,1,1,136,21,1,5,0,1,0]

theorem envBound18433 : H12AffineFastState.Bounded env18433 := by
  intro p hp
  have h : env18433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18432_18433 : H12AffineEnvironment.transform 15 2 env18432 = env18433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2 env18432 == env18433) = true)

def leafEnv18433 : List Nat := [2,4,8,16,0,17,128,4,0,20,0,1,128,1,0,2,1,137,21,1,0,137,17,2,20,8,1,16,1,1,1,136,21,1,5,0,5,2,1,0,0,0,1]

def active18433 : List Nat := [0,1,2,3,6]

def tree18433 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18433 : H12WitnessSearch.Good tree18433 := H12GlobalWitnessIndex.good

theorem leafIdentity18433 : H12AffineFastState.composeSystem env18433 rootObs = leafEnv18433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18433 rootObs == leafEnv18433) = true)

theorem terminalChecked18433 : H12PackedTerminal.terminalCheckFast leafEnv18433 active18433 tree18433 = true := by decide +kernel

def env18434 : List Nat := [2,4,8,16,1,17,128,5,0,21,0,1,129,1,0,65536,1,137,20,1,0,136,17,65537,9,16,1,1,1,136,21,1,4,65539,1,0]

theorem envBound18434 : H12AffineFastState.Bounded env18434 := by
  intro p hp
  have h : env18434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18431_18434 : H12AffineEnvironment.transform 4 1 env18431 = env18434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env18431 == env18434) = true)

theorem identity18434 : scanCanonicalize (H12AffineFastState.compose env18434 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 139) := by decide +kernel

theorem selectedBound18434 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18435 : List Nat := [2,4,8,16,1,17,128,5,0,21,0,1,129,1,0,139,1,137,20,1,0,136,17,138,9,16,1,1,1,136,21,1,4,136,1,0]

theorem envBound18435 : H12AffineFastState.Bounded env18435 := by
  intro p hp
  have h : env18435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18434_18435 : H12AffineEnvironment.transform 15 139 env18434 = env18435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 139 env18434 == env18435) = true)

def env18436 : List Nat := [2,4,8,16,32,17,128,36,0,52,0,1,161,1,0,65536,1,136,53,1,0,168,17,65568,41,16,1,1,1,137,21,1,37,65571,1,0]

theorem envBound18436 : H12AffineFastState.Bounded env18436 := by
  intro p hp
  have h : env18436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18430_18436 : H12AffineEnvironment.transform 12 161 env18430 = env18436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env18430 == env18436) = true)

def env18437 : List Nat := [2,4,8,16,0,17,128,4,0,20,0,1,129,1,0,65536,1,136,21,1,0,136,17,65536,9,16,1,1,1,137,21,1,5,65539,1,0]

theorem envBound18437 : H12AffineFastState.Bounded env18437 := by
  intro p hp
  have h : env18437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18436_18437 : H12AffineEnvironment.transform 4 0 env18436 = env18437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env18436 == env18437) = true)

theorem identity18437 : scanCanonicalize (H12AffineFastState.compose env18437 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound18437 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18438 : List Nat := [2,4,8,16,0,17,8,4,0,20,0,1,9,1,0,65536,1,0,21,1,0,0,17,65536,9,16,1,1,1,1,21,1,5,65539,1,0]

theorem envBound18438 : H12AffineFastState.Bounded env18438 := by
  intro p hp
  have h : env18438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18437_18438 : H12AffineEnvironment.transform 6 8 env18437 = env18438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18437 == env18438) = true)

theorem identity18438 : scanCanonicalize (H12AffineFastState.compose env18438 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 3) := by decide +kernel

theorem selectedBound18438 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env18439 : List Nat := [2,4,8,16,0,17,8,4,0,20,0,1,9,1,0,3,1,0,21,1,0,0,17,3,9,16,1,1,1,1,21,1,5,0,1,0]

theorem envBound18439 : H12AffineFastState.Bounded env18439 := by
  intro p hp
  have h : env18439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18438_18439 : H12AffineEnvironment.transform 15 3 env18438 = env18439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3 env18438 == env18439) = true)

def leafEnv18439 : List Nat := [2,4,8,16,0,17,8,4,0,20,0,1,9,1,0,3,1,0,21,1,0,0,17,3,20,9,1,16,1,1,1,1,21,1,5,0,5,2,1,0,0,0,1]

def active18439 : List Nat := [0,1,2,3]

def tree18439 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18439 : H12WitnessSearch.Good tree18439 := H12GlobalWitnessIndex.good

theorem leafIdentity18439 : H12AffineFastState.composeSystem env18439 rootObs = leafEnv18439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18439 rootObs == leafEnv18439) = true)

theorem terminalChecked18439 : H12PackedTerminal.terminalCheckFast leafEnv18439 active18439 tree18439 = true := by decide +kernel

def env18440 : List Nat := [2,4,8,16,1,17,128,5,0,21,0,1,128,1,0,65536,1,136,20,1,0,137,17,65537,8,16,1,1,1,137,21,1,4,65538,1,0]

theorem envBound18440 : H12AffineFastState.Bounded env18440 := by
  intro p hp
  have h : env18440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18436_18440 : H12AffineEnvironment.transform 4 1 env18436 = env18440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env18436 == env18440) = true)

def env18441 : List Nat := [2,4,8,16,32,17,128,36,1,52,0,1,8192,1,0,65536,1,8233,53,1,0,8201,17,65568,8328,16,1,1,1,8232,21,4294967296,37,4295041155,1,1]

theorem envBound18441 : H12AffineFastState.Bounded env18441 := by
  intro p hp
  have h : env18441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18428_18441 : H12AffineEnvironment.transform 8 1 env18428 = env18441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env18428 == env18441) = true)

theorem identity18441 : scanCanonicalize (H12AffineFastState.compose env18441 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 8353) := by decide +kernel

theorem selectedBound18441 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18442 : List Nat := [2,4,8,16,32,17,128,36,1,52,0,1,8192,1,0,65536,1,8233,53,1,0,8201,17,65568,8328,16,1,1,1,8232,21,8353,37,65570,1,1]

theorem envBound18442 : H12AffineFastState.Bounded env18442 := by
  intro p hp
  have h : env18442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18441_18442 : H12AffineEnvironment.transform 31 8353 env18441 = env18442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 8353 env18441 == env18442) = true)

def env18443 : List Nat := [2,4,8,16,32,17,128,36,1,52,0,1,128,1,0,65536,1,169,53,1,0,137,17,65568,8,16,1,1,1,168,21,33,37,65570,1,1]

theorem envBound18443 : H12AffineFastState.Bounded env18443 := by
  intro p hp
  have h : env18443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18442_18443 : H12AffineEnvironment.transform 12 128 env18442 = env18443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 128 env18442 == env18443) = true)

theorem identity18443 : scanCanonicalize (H12AffineFastState.compose env18443 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound18443 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18444 : List Nat := [2,4,8,16,32,17,128,36,1,52,0,1,128,1,0,35,1,169,53,1,0,137,17,3,8,16,1,1,1,168,21,33,37,1,1,1]

theorem envBound18444 : H12AffineFastState.Bounded env18444 := by
  intro p hp
  have h : env18444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18443_18444 : H12AffineEnvironment.transform 15 35 env18443 = env18444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env18443 == env18444) = true)

def env18445 : List Nat := [2,4,8,16,32,17,128,36,1,52,0,1,129,1,0,65536,1,168,53,1,0,136,17,65568,9,16,1,1,1,169,21,32,37,65570,1,1]

theorem envBound18445 : H12AffineFastState.Bounded env18445 := by
  intro p hp
  have h : env18445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18442_18445 : H12AffineEnvironment.transform 12 129 env18442 = env18445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 129 env18442 == env18445) = true)

theorem identity18445 : scanCanonicalize (H12AffineFastState.compose env18445 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 138) := by decide +kernel

theorem selectedBound18445 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18446 : List Nat := [2,4,8,16,32,17,128,36,1,52,0,1,129,1,0,138,1,168,53,1,0,136,17,170,9,16,1,1,1,169,21,32,37,168,1,1]

theorem envBound18446 : H12AffineFastState.Bounded env18446 := by
  intro p hp
  have h : env18446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18445_18446 : H12AffineEnvironment.transform 15 138 env18445 = env18446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 138 env18445 == env18446) = true)

theorem identity18446 : scanCanonicalize (H12AffineFastState.compose env18446 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound18446 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env18447 : List Nat := [2,4,8,16,32,17,9,36,1,52,0,1,8,1,0,3,1,33,53,1,0,1,17,35,9,16,1,1,1,32,21,32,37,33,1,1]

theorem envBound18447 : H12AffineFastState.Bounded env18447 := by
  intro p hp
  have h : env18447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18446_18447 : H12AffineEnvironment.transform 6 9 env18446 = env18447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18446 == env18447) = true)

def leafEnv18447 : List Nat := [2,4,8,16,32,17,9,36,1,52,0,1,8,1,0,3,1,33,53,1,0,1,17,35,20,9,1,16,1,1,1,32,21,32,37,33,5,34,1,1,0,0,1]

def active18447 : List Nat := [0,1,2,3,4]

def tree18447 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18447 : H12WitnessSearch.Good tree18447 := H12GlobalWitnessIndex.good

theorem leafIdentity18447 : H12AffineFastState.composeSystem env18447 rootObs = leafEnv18447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18447 rootObs == leafEnv18447) = true)

theorem terminalChecked18447 : H12PackedTerminal.terminalCheckFast leafEnv18447 active18447 tree18447 = true := by decide +kernel

def env18448 : List Nat := [2,4,8,16,32,17,128,37,512,53,0,1,8192,1,1,65536,1,8232,52,0,0,8201,17,65568,8328,16,1,1,1,8233,21,4294967296,36,4295041155,1,512]

theorem envBound18448 : H12AffineFastState.Bounded env18448 := by
  intro p hp
  have h : env18448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18427_18448 : H12AffineEnvironment.transform 7 37 env18427 = env18448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env18427 == env18448) = true)

def env18449 : List Nat := [2,4,8,16,32,17,128,37,0,53,0,1,8192,1,1,65536,1,8232,52,0,0,8201,17,65568,8328,16,1,1,1,8233,21,4294967296,36,4295041155,1,0]

theorem envBound18449 : H12AffineFastState.Bounded env18449 := by
  intro p hp
  have h : env18449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18448_18449 : H12AffineEnvironment.transform 8 0 env18448 = env18449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env18448 == env18449) = true)

theorem identity18449 : scanCanonicalize (H12AffineFastState.compose env18449 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 73738) := by decide +kernel

theorem selectedBound18449 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18450 : List Nat := [2,4,8,16,32,17,128,37,0,53,0,1,8192,1,1,65536,1,8232,52,0,0,8201,17,65568,8328,16,1,1,1,8233,21,73738,36,137,1,0]

theorem envBound18450 : H12AffineFastState.Bounded env18450 := by
  intro p hp
  have h : env18450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18449_18450 : H12AffineEnvironment.transform 31 73738 env18449 = env18450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 73738 env18449 == env18450) = true)

def env18451 : List Nat := [2,4,8,16,32,17,128,37,0,53,0,1,40,1,1,65536,1,0,52,0,0,33,17,65568,160,16,1,1,1,1,21,65570,36,137,1,0]

theorem envBound18451 : H12AffineFastState.Bounded env18451 := by
  intro p hp
  have h : env18451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18450_18451 : H12AffineEnvironment.transform 12 40 env18450 = env18451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env18450 == env18451) = true)

theorem identity18451 : scanCanonicalize (H12AffineFastState.compose env18451 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound18451 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18452 : List Nat := [2,4,8,16,32,17,8,37,0,53,0,1,40,1,1,65536,1,0,52,0,0,33,17,65568,40,16,1,1,1,1,21,65570,36,1,1,0]

theorem envBound18452 : H12AffineFastState.Bounded env18452 := by
  intro p hp
  have h : env18452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18451_18452 : H12AffineEnvironment.transform 6 8 env18451 = env18452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18451 == env18452) = true)

def env18453 : List Nat := [2,4,8,16,0,17,8,5,0,21,0,1,8,1,1,65536,1,0,20,0,0,1,17,65536,8,16,1,1,1,1,21,65538,4,1,1,0]

theorem envBound18453 : H12AffineFastState.Bounded env18453 := by
  intro p hp
  have h : env18453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18452_18453 : H12AffineEnvironment.transform 4 0 env18452 = env18453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env18452 == env18453) = true)

def leafEnv18453 : List Nat := [2,4,8,16,0,17,8,5,0,21,0,1,8,1,1,65536,1,0,20,0,0,1,17,65536,20,8,1,16,1,1,1,1,21,65538,4,1,5,2,1,0,0,0,1]

def active18453 : List Nat := [0,1,2,3,15]

def tree18453 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18453 : H12WitnessSearch.Good tree18453 := H12GlobalWitnessIndex.good

theorem leafIdentity18453 : H12AffineFastState.composeSystem env18453 rootObs = leafEnv18453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18453 rootObs == leafEnv18453) = true)

theorem terminalChecked18453 : H12PackedTerminal.terminalCheckFast leafEnv18453 active18453 tree18453 = true := by decide +kernel

def env18454 : List Nat := [2,4,8,16,1,17,8,4,0,20,0,1,9,1,1,65536,1,0,21,0,0,0,17,65537,9,16,1,1,1,1,21,65539,5,1,1,0]

theorem envBound18454 : H12AffineFastState.Bounded env18454 := by
  intro p hp
  have h : env18454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18452_18454 : H12AffineEnvironment.transform 4 1 env18452 = env18454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env18452 == env18454) = true)

theorem identity18454 : scanCanonicalize (H12AffineFastState.compose env18454 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 2) := by decide +kernel

theorem selectedBound18454 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env18455 : List Nat := [2,4,8,16,1,17,8,4,0,20,0,1,9,1,1,2,1,0,21,0,0,0,17,3,9,16,1,1,1,1,21,1,5,1,1,0]

theorem envBound18455 : H12AffineFastState.Bounded env18455 := by
  intro p hp
  have h : env18455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18454_18455 : H12AffineEnvironment.transform 15 2 env18454 = env18455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2 env18454 == env18455) = true)

def leafEnv18455 : List Nat := [2,4,8,16,1,17,8,4,0,20,0,1,9,1,1,2,1,0,21,0,0,0,17,3,20,9,1,16,1,1,1,1,21,1,5,1,5,3,1,0,0,0,1]

def active18455 : List Nat := [0,1,2,3]

def tree18455 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18455 : H12WitnessSearch.Good tree18455 := H12GlobalWitnessIndex.good

theorem leafIdentity18455 : H12AffineFastState.composeSystem env18455 rootObs = leafEnv18455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18455 rootObs == leafEnv18455) = true)

theorem terminalChecked18455 : H12PackedTerminal.terminalCheckFast leafEnv18455 active18455 tree18455 = true := by decide +kernel

def env18456 : List Nat := [2,4,8,16,32,17,128,37,0,53,0,1,41,1,1,65536,1,1,52,0,0,32,17,65568,161,16,1,1,1,0,21,65571,36,137,1,0]

theorem envBound18456 : H12AffineFastState.Bounded env18456 := by
  intro p hp
  have h : env18456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18450_18456 : H12AffineEnvironment.transform 12 41 env18450 = env18456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env18450 == env18456) = true)

theorem identity18456 : scanCanonicalize (H12AffineFastState.compose env18456 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 139) := by decide +kernel

theorem selectedBound18456 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18457 : List Nat := [2,4,8,16,32,17,128,37,0,53,0,1,41,1,1,139,1,1,52,0,0,32,17,171,161,16,1,1,1,0,21,168,36,137,1,0]

theorem envBound18457 : H12AffineFastState.Bounded env18457 := by
  intro p hp
  have h : env18457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18456_18457 : H12AffineEnvironment.transform 15 139 env18456 = env18457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 139 env18456 == env18457) = true)

theorem identity18457 : scanCanonicalize (H12AffineFastState.compose env18457 (packedSelected [6] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound18457 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env18458 : List Nat := [2,4,8,16,32,17,41,37,0,53,0,1,41,1,1,34,1,1,52,0,0,32,17,2,8,16,1,1,1,0,21,1,36,32,1,0]

theorem envBound18458 : H12AffineFastState.Bounded env18458 := by
  intro p hp
  have h : env18458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18457_18458 : H12AffineEnvironment.transform 6 41 env18457 = env18458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env18457 == env18458) = true)

def leafEnv18458 : List Nat := [2,4,8,16,32,17,41,37,0,53,0,1,41,1,1,34,1,1,52,0,0,32,17,2,20,8,1,16,1,1,1,0,21,1,36,32,5,34,1,0,0,0,1]

def active18458 : List Nat := [0,1,2,3,4]

def tree18458 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18458 : H12WitnessSearch.Good tree18458 := H12GlobalWitnessIndex.good

theorem leafIdentity18458 : H12AffineFastState.composeSystem env18458 rootObs = leafEnv18458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18458 rootObs == leafEnv18458) = true)

theorem terminalChecked18458 : H12PackedTerminal.terminalCheckFast leafEnv18458 active18458 tree18458 = true := by decide +kernel

def env18459 : List Nat := [2,4,8,16,32,17,128,37,1,53,0,1,8192,1,1,65536,1,8232,52,0,0,8201,17,65568,8328,16,1,1,1,8233,21,4294967296,36,4295041155,1,1]

theorem envBound18459 : H12AffineFastState.Bounded env18459 := by
  intro p hp
  have h : env18459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18448_18459 : H12AffineEnvironment.transform 8 1 env18448 = env18459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env18448 == env18459) = true)

theorem identity18459 : scanCanonicalize (H12AffineFastState.compose env18459 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 65707) := by decide +kernel

theorem selectedBound18459 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18460 : List Nat := [2,4,8,16,32,17,128,37,1,53,0,1,8192,1,1,65536,1,8232,52,0,0,8201,17,65568,8328,16,1,1,1,8233,21,65707,36,8232,1,1]

theorem envBound18460 : H12AffineFastState.Bounded env18460 := by
  intro p hp
  have h : env18460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18459_18460 : H12AffineEnvironment.transform 31 65707 env18459 = env18460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 65707 env18459 == env18460) = true)

def env18461 : List Nat := [2,4,8,16,0,17,128,5,1,21,0,1,8192,1,1,65536,1,8200,20,0,0,8201,17,65536,8328,16,1,1,1,8201,21,65675,4,8200,1,1]

theorem envBound18461 : H12AffineFastState.Bounded env18461 := by
  intro p hp
  have h : env18461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18460_18461 : H12AffineEnvironment.transform 4 0 env18460 = env18461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env18460 == env18461) = true)

theorem identity18461 : scanCanonicalize (H12AffineFastState.compose env18461 (packedSelected [4,6] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound18461 : packedSelected [4,6] rootPS < 2^1333 := by decide +kernel

def env18462 : List Nat := [2,4,8,16,0,17,128,5,1,21,0,1,8,1,1,65536,1,0,20,0,0,1,17,65536,128,16,1,1,1,1,21,65675,4,0,1,1]

theorem envBound18462 : H12AffineFastState.Bounded env18462 := by
  intro p hp
  have h : env18462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18461_18462 : H12AffineEnvironment.transform 12 8 env18461 = env18462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env18461 == env18462) = true)

theorem identity18462 : scanCanonicalize (H12AffineFastState.compose env18462 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound18462 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env18463 : List Nat := [2,4,8,16,0,17,9,5,1,21,0,1,8,1,1,65536,1,0,20,0,0,1,17,65536,9,16,1,1,1,1,21,65538,4,0,1,1]

theorem envBound18463 : H12AffineFastState.Bounded env18463 := by
  intro p hp
  have h : env18463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18462_18463 : H12AffineEnvironment.transform 6 9 env18462 = env18463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18462 == env18463) = true)

def leafEnv18463 : List Nat := [2,4,8,16,0,17,9,5,1,21,0,1,8,1,1,65536,1,0,20,0,0,1,17,65536,20,9,1,16,1,1,1,1,21,65538,4,0,5,2,1,1,0,0,1]

def active18463 : List Nat := [0,1,2,3,15]

def tree18463 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18463 : H12WitnessSearch.Good tree18463 := H12GlobalWitnessIndex.good

theorem leafIdentity18463 : H12AffineFastState.composeSystem env18463 rootObs = leafEnv18463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18463 rootObs == leafEnv18463) = true)

theorem terminalChecked18463 : H12PackedTerminal.terminalCheckFast leafEnv18463 active18463 tree18463 = true := by decide +kernel

def env18464 : List Nat := [2,4,8,16,1,17,128,4,1,20,0,1,8192,1,1,65536,1,8201,21,0,0,8201,17,65537,8328,16,1,1,1,8200,21,65674,5,8201,1,1]

theorem envBound18464 : H12AffineFastState.Bounded env18464 := by
  intro p hp
  have h : env18464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18460_18464 : H12AffineEnvironment.transform 4 1 env18460 = env18464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env18460 == env18464) = true)

def env18465 : List Nat := [2,4,8,16,1,17,8,4,1,20,0,1,8192,1,1,65536,1,8201,21,0,0,8201,17,65537,8192,16,1,1,1,8200,21,65538,5,8201,1,1]

theorem envBound18465 : H12AffineFastState.Bounded env18465 := by
  intro p hp
  have h : env18465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18464_18465 : H12AffineEnvironment.transform 6 8 env18464 = env18465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18464 == env18465) = true)

theorem identity18465 : scanCanonicalize (H12AffineFastState.compose env18465 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 2) := by decide +kernel

theorem selectedBound18465 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18466 : List Nat := [2,4,8,16,1,17,8,4,1,20,0,1,8192,1,1,2,1,8201,21,0,0,8201,17,3,8192,16,1,1,1,8200,21,0,5,8201,1,1]

theorem envBound18466 : H12AffineFastState.Bounded env18466 := by
  intro p hp
  have h : env18466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18465_18466 : H12AffineEnvironment.transform 15 2 env18465 = env18466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2 env18465 == env18466) = true)

def env18467 : List Nat := [2,4,8,16,1,17,9,4,1,20,0,1,8192,1,1,65536,1,8201,21,0,0,8201,17,65537,8193,16,1,1,1,8200,21,65539,5,8201,1,1]

theorem envBound18467 : H12AffineFastState.Bounded env18467 := by
  intro p hp
  have h : env18467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18464_18467 : H12AffineEnvironment.transform 6 9 env18464 = env18467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18464 == env18467) = true)

theorem identity18467 : scanCanonicalize (H12AffineFastState.compose env18467 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound18467 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env18468 : List Nat := [2,4,8,16,1,17,9,4,1,20,0,1,8192,1,1,8202,1,8201,21,0,0,8201,17,8203,8193,16,1,1,1,8200,21,8201,5,8201,1,1]

theorem envBound18468 : H12AffineFastState.Bounded env18468 := by
  intro p hp
  have h : env18468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18467_18468 : H12AffineEnvironment.transform 15 8202 env18467 = env18468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env18467 == env18468) = true)

def leafEnv18468 : List Nat := [2,4,8,16,1,17,9,4,1,20,0,1,8192,1,1,8202,1,8201,21,0,0,8201,17,8203,20,8193,1,16,1,1,1,8200,21,8201,5,8201,5,3,1,1,0,0,1]

def active18468 : List Nat := [0,1,2,3,12]

def tree18468 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18468 : H12WitnessSearch.Good tree18468 := H12GlobalWitnessIndex.good

theorem leafIdentity18468 : H12AffineFastState.composeSystem env18468 rootObs = leafEnv18468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18468 rootObs == leafEnv18468) = true)

theorem terminalChecked18468 : H12PackedTerminal.terminalCheckFast leafEnv18468 active18468 tree18468 = true := by decide +kernel

def env18469 : List Nat := [2,4,8,16,32,17,128,256,512,273,0,0,8192,0,292,65536,0,8461,272,293,1,8201,17,65568,8328,16,1,0,0,8460,20,4294967296,257,4295041155,0,512]

theorem envBound18469 : H12AffineFastState.Bounded env18469 := by
  intro p hp
  have h : env18469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18426_18469 : H12AffineEnvironment.transform 9 273 env18426 = env18469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env18426 == env18469) = true)

theorem identity18469 : scanCanonicalize (H12AffineFastState.compose env18469 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 171) := by decide +kernel

theorem selectedBound18469 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18470 : List Nat := [2,4,8,16,32,17,128,256,512,273,0,0,8192,0,292,171,0,8461,272,293,1,8201,17,139,8328,16,1,0,0,8460,20,4294967296,257,4294975528,0,512]

theorem envBound18470 : H12AffineFastState.Bounded env18470 := by
  intro p hp
  have h : env18470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18469_18470 : H12AffineEnvironment.transform 15 171 env18469 = env18470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 171 env18469 == env18470) = true)

def env18471 : List Nat := [2,4,8,16,32,17,128,256,512,273,0,0,672,0,292,171,0,941,272,293,1,681,17,139,552,16,1,0,0,940,20,4294967296,257,4294967944,0,512]

theorem envBound18471 : H12AffineFastState.Bounded env18471 := by
  intro p hp
  have h : env18471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18470_18471 : H12AffineEnvironment.transform 12 672 env18470 = env18471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 672 env18470 == env18471) = true)

theorem identity18471 : scanCanonicalize (H12AffineFastState.compose env18471 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 513) := by decide +kernel

theorem selectedBound18471 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18472 : List Nat := [2,4,8,16,32,17,128,256,512,273,0,0,672,0,292,171,0,941,272,293,1,681,17,139,552,16,1,0,0,940,20,513,257,137,0,512]

theorem envBound18472 : H12AffineFastState.Bounded env18472 := by
  intro p hp
  have h : env18472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18471_18472 : H12AffineEnvironment.transform 31 513 env18471 = env18472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 513 env18471 == env18472) = true)

def env18473 : List Nat := [2,4,8,16,32,17,128,256,136,273,0,0,40,0,292,171,0,293,272,293,1,33,17,139,160,16,1,0,0,292,20,137,257,137,0,136]

theorem envBound18473 : H12AffineFastState.Bounded env18473 := by
  intro p hp
  have h : env18473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18472_18473 : H12AffineEnvironment.transform 8 136 env18472 = env18473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env18472 == env18473) = true)

theorem identity18473 : scanCanonicalize (H12AffineFastState.compose env18473 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound18473 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18474 : List Nat := [2,4,8,16,32,17,128,37,136,52,0,0,40,0,1,171,0,0,53,0,1,33,17,139,160,16,1,0,0,1,20,137,36,137,0,136]

theorem envBound18474 : H12AffineFastState.Bounded env18474 := by
  intro p hp
  have h : env18474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18473_18474 : H12AffineEnvironment.transform 7 37 env18473 = env18474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env18473 == env18474) = true)

def leafEnv18474 : List Nat := [2,4,8,16,32,17,128,37,136,52,0,0,40,0,1,171,0,0,53,0,1,33,17,139,21,160,1,16,1,0,0,1,20,137,36,137,5,34,0,136,0,1,1]

def active18474 : List Nat := [0,1,2,3,4,6]

def tree18474 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18474 : H12WitnessSearch.Good tree18474 := H12GlobalWitnessIndex.good

theorem leafIdentity18474 : H12AffineFastState.composeSystem env18474 rootObs = leafEnv18474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18474 rootObs == leafEnv18474) = true)

theorem terminalChecked18474 : H12PackedTerminal.terminalCheckFast leafEnv18474 active18474 tree18474 = true := by decide +kernel

def env18475 : List Nat := [2,4,8,16,32,17,128,256,137,273,0,0,41,0,292,171,0,292,272,293,1,32,17,139,161,16,1,0,0,293,20,136,257,137,0,137]

theorem envBound18475 : H12AffineFastState.Bounded env18475 := by
  intro p hp
  have h : env18475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18472_18475 : H12AffineEnvironment.transform 8 137 env18472 = env18475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env18472 == env18475) = true)

theorem identity18475 : scanCanonicalize (H12AffineFastState.compose env18475 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound18475 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18476 : List Nat := [2,4,8,16,32,17,41,256,32,273,0,0,41,0,292,2,0,292,272,293,1,32,17,34,8,16,1,0,0,293,20,33,257,32,0,32]

theorem envBound18476 : H12AffineFastState.Bounded env18476 := by
  intro p hp
  have h : env18476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18475_18476 : H12AffineEnvironment.transform 6 41 env18475 = env18476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env18475 == env18476) = true)

theorem identity18476 : scanCanonicalize (H12AffineFastState.compose env18476 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound18476 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env18477 : List Nat := [2,4,8,16,0,17,9,256,0,273,0,0,9,0,260,2,0,260,272,261,1,0,17,2,8,16,1,0,0,261,20,1,257,0,0,0]

theorem envBound18477 : H12AffineFastState.Bounded env18477 := by
  intro p hp
  have h : env18477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18476_18477 : H12AffineEnvironment.transform 4 0 env18476 = env18477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env18476 == env18477) = true)

def leafEnv18477 : List Nat := [2,4,8,16,0,17,9,256,0,273,0,0,9,0,260,2,0,260,272,261,1,0,17,2,21,8,1,16,1,0,0,261,20,1,257,0,5,2,0,0,0,1,1]

def active18477 : List Nat := [0,1,2,3,7]

def tree18477 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18477 : H12WitnessSearch.Good tree18477 := H12GlobalWitnessIndex.good

theorem leafIdentity18477 : H12AffineFastState.composeSystem env18477 rootObs = leafEnv18477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18477 rootObs == leafEnv18477) = true)

theorem terminalChecked18477 : H12PackedTerminal.terminalCheckFast leafEnv18477 active18477 tree18477 = true := by decide +kernel

def env18478 : List Nat := [2,4,8,16,32,17,128,256,512,273,0,0,673,0,292,171,0,940,272,293,1,680,17,139,553,16,1,0,0,941,20,4294967296,257,4294967945,0,512]

theorem envBound18478 : H12AffineFastState.Bounded env18478 := by
  intro p hp
  have h : env18478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18470_18478 : H12AffineEnvironment.transform 12 673 env18470 = env18478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 673 env18470 == env18478) = true)

theorem identity18478 : scanCanonicalize (H12AffineFastState.compose env18478 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 293) := by decide +kernel

theorem selectedBound18478 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18479 : List Nat := [2,4,8,16,32,17,128,256,512,273,0,0,673,0,292,171,0,940,272,293,1,680,17,139,553,16,1,0,0,941,20,293,257,940,0,512]

theorem envBound18479 : H12AffineFastState.Bounded env18479 := by
  intro p hp
  have h : env18479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18478_18479 : H12AffineEnvironment.transform 31 293 env18478 = env18479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 293 env18478 == env18479) = true)

def env18480 : List Nat := [2,4,8,16,0,17,128,256,512,273,0,0,641,0,260,139,0,908,272,261,1,648,17,139,521,16,1,0,0,909,20,261,257,908,0,512]

theorem envBound18480 : H12AffineFastState.Bounded env18480 := by
  intro p hp
  have h : env18480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18479_18480 : H12AffineEnvironment.transform 4 0 env18479 = env18480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env18479 == env18480) = true)

theorem identity18480 : scanCanonicalize (H12AffineFastState.compose env18480 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound18480 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18481 : List Nat := [2,4,8,16,0,17,8,256,512,273,0,0,521,0,260,3,0,772,272,261,1,512,17,3,521,16,1,0,0,773,20,261,257,772,0,512]

theorem envBound18481 : H12AffineFastState.Bounded env18481 := by
  intro p hp
  have h : env18481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18480_18481 : H12AffineEnvironment.transform 6 8 env18480 = env18481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18480 == env18481) = true)

def env18482 : List Nat := [2,4,8,16,0,17,8,256,0,273,0,0,9,0,260,3,0,260,272,261,1,0,17,3,9,16,1,0,0,261,20,261,257,260,0,0]

theorem envBound18482 : H12AffineFastState.Bounded env18482 := by
  intro p hp
  have h : env18482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18481_18482 : H12AffineEnvironment.transform 8 0 env18481 = env18482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env18481 == env18482) = true)

theorem identity18482 : scanCanonicalize (H12AffineFastState.compose env18482 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound18482 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env18483 : List Nat := [2,4,8,16,0,17,8,4,0,21,0,0,9,0,0,3,0,0,20,1,1,0,17,3,9,16,1,0,0,1,20,1,5,0,0,0]

theorem envBound18483 : H12AffineFastState.Bounded env18483 := by
  intro p hp
  have h : env18483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18482_18483 : H12AffineEnvironment.transform 7 4 env18482 = env18483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env18482 == env18483) = true)

def leafEnv18483 : List Nat := [2,4,8,16,0,17,8,4,0,21,0,0,9,0,0,3,0,0,20,1,1,0,17,3,21,9,1,16,1,0,0,1,20,1,5,0,5,2,0,0,0,1,1]

def active18483 : List Nat := [0,1,2,3]

def tree18483 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18483 : H12WitnessSearch.Good tree18483 := H12GlobalWitnessIndex.good

theorem leafIdentity18483 : H12AffineFastState.composeSystem env18483 rootObs = leafEnv18483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18483 rootObs == leafEnv18483) = true)

theorem terminalChecked18483 : H12PackedTerminal.terminalCheckFast leafEnv18483 active18483 tree18483 = true := by decide +kernel

def env18484 : List Nat := [2,4,8,16,0,17,8,256,1,273,0,0,8,0,260,3,0,261,272,261,1,1,17,3,8,16,1,0,0,260,20,261,257,261,0,1]

theorem envBound18484 : H12AffineFastState.Bounded env18484 := by
  intro p hp
  have h : env18484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18481_18484 : H12AffineEnvironment.transform 8 1 env18481 = env18484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env18481 == env18484) = true)

def env18485 : List Nat := [2,4,8,16,1,17,128,256,512,273,0,0,640,0,261,138,0,909,272,260,1,649,17,139,520,16,1,0,0,908,20,260,257,909,0,512]

theorem envBound18485 : H12AffineFastState.Bounded env18485 := by
  intro p hp
  have h : env18485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18479_18485 : H12AffineEnvironment.transform 4 1 env18479 = env18485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env18479 == env18485) = true)

theorem identity18485 : scanCanonicalize (H12AffineFastState.compose env18485 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound18485 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18486 : List Nat := [2,4,8,16,1,17,128,256,1,273,0,0,129,0,261,138,0,396,272,260,1,136,17,139,9,16,1,0,0,397,20,260,257,396,0,1]

theorem envBound18486 : H12AffineFastState.Bounded env18486 := by
  intro p hp
  have h : env18486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18485_18486 : H12AffineEnvironment.transform 8 1 env18485 = env18486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env18485 == env18486) = true)

def env18487 : List Nat := [2,4,8,16,1,17,8,256,1,273,0,0,9,0,261,2,0,260,272,260,1,0,17,3,9,16,1,0,0,261,20,260,257,260,0,1]

theorem envBound18487 : H12AffineFastState.Bounded env18487 := by
  intro p hp
  have h : env18487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18486_18487 : H12AffineEnvironment.transform 6 8 env18486 = env18487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18486 == env18487) = true)

def env18488 : List Nat := [2,4,8,16,1,17,9,256,1,273,0,0,8,0,261,3,0,261,272,260,1,1,17,2,9,16,1,0,0,260,20,260,257,261,0,1]

theorem envBound18488 : H12AffineFastState.Bounded env18488 := by
  intro p hp
  have h : env18488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18486_18488 : H12AffineEnvironment.transform 6 9 env18486 = env18488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18486 == env18488) = true)

theorem identity18488 : scanCanonicalize (H12AffineFastState.compose env18488 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound18488 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env18489 : List Nat := [2,4,8,16,1,17,9,5,1,20,0,0,8,0,0,3,0,0,21,1,1,1,17,2,9,16,1,0,0,1,20,1,4,0,0,1]

theorem envBound18489 : H12AffineFastState.Bounded env18489 := by
  intro p hp
  have h : env18489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18488_18489 : H12AffineEnvironment.transform 7 5 env18488 = env18489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env18488 == env18489) = true)

def leafEnv18489 : List Nat := [2,4,8,16,1,17,9,5,1,20,0,0,8,0,0,3,0,0,21,1,1,1,17,2,21,9,1,16,1,0,0,1,20,1,4,0,5,3,0,1,0,1,1]

def active18489 : List Nat := [0,1,2,3]

def tree18489 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18489 : H12WitnessSearch.Good tree18489 := H12GlobalWitnessIndex.good

theorem leafIdentity18489 : H12AffineFastState.composeSystem env18489 rootObs = leafEnv18489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18489 rootObs == leafEnv18489) = true)

theorem terminalChecked18489 : H12PackedTerminal.terminalCheckFast leafEnv18489 active18489 tree18489 = true := by decide +kernel

def env18490 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1344,8192,1344,32768,65536,1344,262144,304169,32769,1345,8201,64,98564,8328,303160,33060,1344,304488,41000,1285,4294967296,257,4295074215,1344,512]

theorem envBound18490 : H12AffineFastState.Bounded env18490 := by
  intro p hp
  have h : env18490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18422_18490 : H12AffineEnvironment.transform 18 304169 env18422 = env18490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 304169 env18422 == env18490) = true)

theorem identity18490 : scanCanonicalize (H12AffineFastState.compose env18490 (packedSelected [4,9,18] rootPS)) = affineNative (2^(17+1) ^^^ 33060) := by decide +kernel

theorem selectedBound18490 : packedSelected [4,9,18] rootPS < 2^1333 := by decide +kernel

def env18491 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1344,8192,1344,32768,65536,1344,33060,9485,32769,1345,8201,64,98564,8328,8476,33060,1344,9292,41000,1285,4294967296,257,4295074215,1344,512]

theorem envBound18491 : H12AffineFastState.Bounded env18491 := by
  intro p hp
  have h : env18491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18490_18491 : H12AffineEnvironment.transform 17 33060 env18490 = env18491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 33060 env18490 == env18491) = true)

theorem identity18491 : scanCanonicalize (H12AffineFastState.compose env18491 (packedSelected [5,8,13,15,19] rootPS)) = affineNative (2^(14+1) ^^^ 8313) := by decide +kernel

theorem selectedBound18491 : packedSelected [5,8,13,15,19] rootPS < 2^1333 := by decide +kernel

def env18492 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1344,8192,1344,8313,65536,1344,8541,9485,8312,1345,8201,64,74109,8328,8476,8541,1344,9292,81,1285,4294967296,257,4295033310,1344,512]

theorem envBound18492 : H12AffineFastState.Bounded env18492 := by
  intro p hp
  have h : env18492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18491_18492 : H12AffineEnvironment.transform 14 8313 env18491 = env18492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8313 env18491 == env18492) = true)

theorem identity18492 : scanCanonicalize (H12AffineFastState.compose env18492 (packedSelected [4,9] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound18492 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env18493 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1344,349,1344,292,65536,1344,0,1104,293,1345,340,64,65568,469,65,0,1344,1297,81,1285,4294967296,257,4295033310,1344,512]

theorem envBound18493 : H12AffineFastState.Bounded env18493 := by
  intro p hp
  have h : env18493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18492_18493 : H12AffineEnvironment.transform 12 349 env18492 = env18493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env18492 == env18493) = true)

theorem identity18493 : scanCanonicalize (H12AffineFastState.compose env18493 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound18493 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env18494 : List Nat := [2,4,8,16,32,16,128,256,512,1024,0,1296,269,1296,292,65536,1296,0,1024,293,1297,260,16,65568,389,17,0,1296,1297,1,1285,4294967296,257,4295033230,1296,512]

theorem envBound18494 : H12AffineFastState.Bounded env18494 := by
  intro p hp
  have h : env18494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18493_18494 : H12AffineEnvironment.transform 5 16 env18493 = env18494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env18493 == env18494) = true)

theorem identity18494 : scanCanonicalize (H12AffineFastState.compose env18494 (packedSelected [1,3] rootPS)) = affineNative (2^(15+1) ^^^ 1559) := by decide +kernel

theorem selectedBound18494 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env18495 : List Nat := [2,4,8,16,32,16,128,256,512,1024,0,1296,269,1296,292,1559,1296,0,1024,293,1297,260,16,1591,389,17,0,1296,1297,1,1285,4294967296,257,4294969241,1296,512]

theorem envBound18495 : H12AffineFastState.Bounded env18495 := by
  intro p hp
  have h : env18495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18494_18495 : H12AffineEnvironment.transform 15 1559 env18494 = env18495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1559 env18494 == env18495) = true)

theorem identity18495 : scanCanonicalize (H12AffineFastState.compose env18495 (packedSelected [5] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound18495 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env18496 : List Nat := [2,4,8,16,32,16,128,256,137,1024,0,1296,269,1296,292,1182,1296,0,1024,293,1297,260,16,1214,389,17,0,1296,1297,1,1285,4294967296,257,4294968592,1296,137]

theorem envBound18496 : H12AffineFastState.Bounded env18496 := by
  intro p hp
  have h : env18496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18495_18496 : H12AffineEnvironment.transform 8 137 env18495 = env18496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env18495 == env18496) = true)

theorem identity18496 : scanCanonicalize (H12AffineFastState.compose env18496 (packedSelected [8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound18496 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env18497 : List Nat := [2,4,8,16,32,16,128,256,137,52,0,292,269,292,292,170,292,0,52,293,293,260,16,138,389,17,0,292,293,1,305,4294967296,257,4294967588,292,137]

theorem envBound18497 : H12AffineFastState.Bounded env18497 := by
  intro p hp
  have h : env18497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18496_18497 : H12AffineEnvironment.transform 9 52 env18496 = env18497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env18496 == env18497) = true)

theorem identity18497 : scanCanonicalize (H12AffineFastState.compose env18497 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound18497 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18498 : List Nat := [2,4,8,16,32,16,128,14,137,52,0,42,3,42,42,170,42,0,52,43,43,10,16,138,139,17,0,42,43,1,63,4294967296,15,4294967338,42,137]

theorem envBound18498 : H12AffineFastState.Bounded env18498 := by
  intro p hp
  have h : env18498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18497_18498 : H12AffineEnvironment.transform 7 14 env18497 = env18498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env18497 == env18498) = true)

theorem identity18498 : scanCanonicalize (H12AffineFastState.compose env18498 (packedSelected [10] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound18498 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env18499 : List Nat := [2,4,8,16,11,16,128,14,137,31,0,1,3,1,1,129,1,0,31,0,0,10,16,138,139,17,0,1,0,1,20,4294967296,15,4294967297,1,137]

theorem envBound18499 : H12AffineFastState.Bounded env18499 := by
  intro p hp
  have h : env18499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18498_18499 : H12AffineEnvironment.transform 4 11 env18498 = env18499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env18498 == env18499) = true)

theorem identity18499 : scanCanonicalize (H12AffineFastState.compose env18499 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 136) := by decide +kernel

theorem selectedBound18499 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18500 : List Nat := [2,4,8,16,11,16,128,14,137,31,0,1,3,1,1,129,1,0,31,0,0,10,16,138,139,17,0,1,0,1,20,136,15,137,1,137]

theorem envBound18500 : H12AffineFastState.Bounded env18500 := by
  intro p hp
  have h : env18500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18499_18500 : H12AffineEnvironment.transform 31 136 env18499 = env18500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 136 env18499 == env18500) = true)

theorem identity18500 : scanCanonicalize (H12AffineFastState.compose env18500 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound18500 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18501 : List Nat := [2,4,8,16,11,16,24,14,17,31,0,1,3,1,1,25,1,0,31,0,0,10,16,18,19,17,0,1,0,1,20,16,15,17,1,17]

theorem envBound18501 : H12AffineFastState.Bounded env18501 := by
  intro p hp
  have h : env18501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18500_18501 : H12AffineEnvironment.transform 6 24 env18500 = env18501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env18500 == env18501) = true)

def env18502 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,4096,32768,65536,4096,262144,524288,32769,4097,8200,64,98564,8328,525329,798796,4096,529409,1073741824,1285,4294967296,257,4295074214,4096,512]

theorem envBound18502 : H12AffineFastState.Bounded env18502 := by
  intro p hp
  have h : env18502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18419_18502 : H12AffineEnvironment.transform 10 1 env18419 = env18502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env18419 == env18502) = true)

theorem identity18502 : scanCanonicalize (H12AffineFastState.compose env18502 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 787456) := by decide +kernel

theorem selectedBound18502 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env18503 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,4096,32768,65536,4096,262144,524288,32769,4097,8200,64,98564,8328,525329,798796,4096,529409,787456,1285,4294967296,257,4295074214,4096,512]

theorem envBound18503 : H12AffineFastState.Bounded env18503 := by
  intro p hp
  have h : env18503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18502_18503 : H12AffineEnvironment.transform 29 787456 env18502 = env18503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 787456 env18502 == env18503) = true)

theorem identity18503 : scanCanonicalize (H12AffineFastState.compose env18503 (packedSelected [0,3,4,7,9,10,18,19,23,24] rootPS)) = affineNative (2^(18+1) ^^^ 304169) := by decide +kernel

theorem selectedBound18503 : packedSelected [0,3,4,7,9,10,18,19,23,24] rootPS < 2^1333 := by decide +kernel

def env18504 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,4096,32768,65536,4096,262144,304169,32769,4097,8200,64,98564,8328,303160,37989,4096,307240,41001,1285,4294967296,257,4295074214,4096,512]

theorem envBound18504 : H12AffineFastState.Bounded env18504 := by
  intro p hp
  have h : env18504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18503_18504 : H12AffineEnvironment.transform 18 304169 env18503 = env18504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 304169 env18503 == env18504) = true)

theorem identity18504 : scanCanonicalize (H12AffineFastState.compose env18504 (packedSelected [4,9,18,20,23] rootPS)) = affineNative (2^(11+1) ^^^ 1344) := by decide +kernel

theorem selectedBound18504 : packedSelected [4,9,18,20,23] rootPS < 2^1333 := by decide +kernel

def env18505 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1344,8192,1344,32768,65536,1344,262144,304169,32769,1345,8200,64,98564,8328,303160,33061,1344,304488,41001,1285,4294967296,257,4295074214,1344,512]

theorem envBound18505 : H12AffineFastState.Bounded env18505 := by
  intro p hp
  have h : env18505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18504_18505 : H12AffineEnvironment.transform 11 1344 env18504 = env18505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env18504 == env18505) = true)

theorem identity18505 : scanCanonicalize (H12AffineFastState.compose env18505 (packedSelected [4,9,18] rootPS)) = affineNative (2^(17+1) ^^^ 8461) := by decide +kernel

theorem selectedBound18505 : packedSelected [4,9,18] rootPS < 2^1333 := by decide +kernel

def env18506 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1344,8192,1344,32768,65536,1344,8461,34084,32769,1345,8200,64,98564,8328,33077,33061,1344,33893,41001,1285,4294967296,257,4295074214,1344,512]

theorem envBound18506 : H12AffineFastState.Bounded env18506 := by
  intro p hp
  have h : env18506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18505_18506 : H12AffineEnvironment.transform 17 8461 env18505 = env18506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8461 env18505 == env18506) = true)

theorem identity18506 : scanCanonicalize (H12AffineFastState.compose env18506 (packedSelected [0,3,7,8,12,15,17] rootPS)) = affineNative (2^(14+1) ^^^ 293) := by decide +kernel

theorem selectedBound18506 : packedSelected [0,3,7,8,12,15,17] rootPS < 2^1333 := by decide +kernel

def env18507 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1344,8192,1344,293,65536,1344,8461,1025,292,1345,8200,64,65569,8328,16,0,1344,1344,8460,1285,4294967296,257,4295041155,1344,512]

theorem envBound18507 : H12AffineFastState.Bounded env18507 := by
  intro p hp
  have h : env18507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18506_18507 : H12AffineEnvironment.transform 14 293 env18506 = env18507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 293 env18506 == env18507) = true)

theorem identity18507 : scanCanonicalize (H12AffineFastState.compose env18507 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound18507 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env18508 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1,1297,8192,1297,293,65536,1297,8461,1025,292,1296,8200,17,65569,8328,16,0,1297,1297,8460,1285,4294967296,257,4295041155,1297,512]

theorem envBound18508 : H12AffineFastState.Bounded env18508 := by
  intro p hp
  have h : env18508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18507_18508 : H12AffineEnvironment.transform 5 17 env18507 = env18508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env18507 == env18508) = true)

def env18509 : List Nat := [2,4,8,16,32,17,128,256,512,272,1,1,8192,1,293,65536,1,8461,273,292,0,8200,17,65569,8328,16,0,1,1,8460,21,4294967296,257,4295041155,1,512]

theorem envBound18509 : H12AffineFastState.Bounded env18509 := by
  intro p hp
  have h : env18509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18508_18509 : H12AffineEnvironment.transform 9 272 env18508 = env18509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env18508 == env18509) = true)

def env18510 : List Nat := [2,4,8,16,32,17,128,36,512,52,1,1,8192,1,1,65536,1,8233,53,0,0,8200,17,65569,8328,16,0,1,1,8232,21,4294967296,37,4295041155,1,512]

theorem envBound18510 : H12AffineFastState.Bounded env18510 := by
  intro p hp
  have h : env18510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18509_18510 : H12AffineEnvironment.transform 7 36 env18509 = env18510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env18509 == env18510) = true)

def env18511 : List Nat := [2,4,8,16,32,17,128,36,0,52,1,1,8192,1,1,65536,1,8233,53,0,0,8200,17,65569,8328,16,0,1,1,8232,21,4294967296,37,4295041155,1,0]

theorem envBound18511 : H12AffineFastState.Bounded env18511 := by
  intro p hp
  have h : env18511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18510_18511 : H12AffineEnvironment.transform 8 0 env18510 = env18511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env18510 == env18511) = true)

theorem identity18511 : scanCanonicalize (H12AffineFastState.compose env18511 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 65707) := by decide +kernel

theorem selectedBound18511 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18512 : List Nat := [2,4,8,16,32,17,128,36,0,52,1,1,8192,1,1,65536,1,8233,53,0,0,8200,17,65569,8328,16,0,1,1,8232,21,65707,37,8232,1,0]

theorem envBound18512 : H12AffineFastState.Bounded env18512 := by
  intro p hp
  have h : env18512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18511_18512 : H12AffineEnvironment.transform 31 65707 env18511 = env18512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 65707 env18511 == env18512) = true)

def env18513 : List Nat := [2,4,8,16,0,17,128,4,0,20,1,1,8192,1,1,65536,1,8201,21,0,0,8200,17,65537,8328,16,0,1,1,8200,21,65675,5,8200,1,0]

theorem envBound18513 : H12AffineFastState.Bounded env18513 := by
  intro p hp
  have h : env18513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18512_18513 : H12AffineEnvironment.transform 4 0 env18512 = env18513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env18512 == env18513) = true)

theorem identity18513 : scanCanonicalize (H12AffineFastState.compose env18513 (packedSelected [4,6] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound18513 : packedSelected [4,6] rootPS < 2^1333 := by decide +kernel

def env18514 : List Nat := [2,4,8,16,0,17,128,4,0,20,1,1,8192,1,1,8322,1,8201,21,0,0,8200,17,8323,8328,16,0,1,1,8200,21,8201,5,8200,1,0]

theorem envBound18514 : H12AffineFastState.Bounded env18514 := by
  intro p hp
  have h : env18514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18513_18514 : H12AffineEnvironment.transform 15 8322 env18513 = env18514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env18513 == env18514) = true)

def env18515 : List Nat := [2,4,8,16,0,17,128,4,0,20,1,1,128,1,1,2,1,137,21,0,0,136,17,3,8,16,0,1,1,136,21,137,5,136,1,0]

theorem envBound18515 : H12AffineFastState.Bounded env18515 := by
  intro p hp
  have h : env18515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18514_18515 : H12AffineEnvironment.transform 12 128 env18514 = env18515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 128 env18514 == env18515) = true)

theorem identity18515 : scanCanonicalize (H12AffineFastState.compose env18515 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound18515 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18516 : List Nat := [2,4,8,16,0,17,8,4,0,20,1,1,8,1,1,2,1,1,21,0,0,0,17,3,8,16,0,1,1,0,21,1,5,0,1,0]

theorem envBound18516 : H12AffineFastState.Bounded env18516 := by
  intro p hp
  have h : env18516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18515_18516 : H12AffineEnvironment.transform 6 8 env18515 = env18516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18515 == env18516) = true)

def leafEnv18516 : List Nat := [2,4,8,16,0,17,8,4,0,20,1,1,8,1,1,2,1,1,21,0,0,0,17,3,20,8,1,16,0,1,1,0,21,1,5,0,5,3,1,0,0,0,1]

def active18516 : List Nat := [0,1,2,3]

def tree18516 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18516 : H12WitnessSearch.Good tree18516 := H12GlobalWitnessIndex.good

theorem leafIdentity18516 : H12AffineFastState.composeSystem env18516 rootObs = leafEnv18516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18516 rootObs == leafEnv18516) = true)

theorem terminalChecked18516 : H12PackedTerminal.terminalCheckFast leafEnv18516 active18516 tree18516 = true := by decide +kernel

def env18517 : List Nat := [2,4,8,16,0,17,128,4,0,20,1,1,129,1,1,3,1,136,21,0,0,137,17,2,9,16,0,1,1,137,21,136,5,137,1,0]

theorem envBound18517 : H12AffineFastState.Bounded env18517 := by
  intro p hp
  have h : env18517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18514_18517 : H12AffineEnvironment.transform 12 129 env18514 = env18517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 129 env18514 == env18517) = true)

def leafEnv18517 : List Nat := [2,4,8,16,0,17,128,4,0,20,1,1,129,1,1,3,1,136,21,0,0,137,17,2,20,9,1,16,0,1,1,137,21,136,5,137,5,3,1,0,0,0,1]

def active18517 : List Nat := [0,1,2,3,6]

def tree18517 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18517 : H12WitnessSearch.Good tree18517 := H12GlobalWitnessIndex.good

theorem leafIdentity18517 : H12AffineFastState.composeSystem env18517 rootObs = leafEnv18517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18517 rootObs == leafEnv18517) = true)

theorem terminalChecked18517 : H12PackedTerminal.terminalCheckFast leafEnv18517 active18517 tree18517 = true := by decide +kernel

def env18518 : List Nat := [2,4,8,16,1,17,128,5,0,21,1,1,8192,1,1,65536,1,8200,20,0,0,8200,17,65536,8328,16,0,1,1,8201,21,65674,4,8201,1,0]

theorem envBound18518 : H12AffineFastState.Bounded env18518 := by
  intro p hp
  have h : env18518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18512_18518 : H12AffineEnvironment.transform 4 1 env18512 = env18518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env18512 == env18518) = true)

theorem identity18518 : scanCanonicalize (H12AffineFastState.compose env18518 (packedSelected [4,6] rootPS)) = affineNative (2^(15+1) ^^^ 138) := by decide +kernel

theorem selectedBound18518 : packedSelected [4,6] rootPS < 2^1333 := by decide +kernel

def env18519 : List Nat := [2,4,8,16,1,17,128,5,0,21,1,1,8192,1,1,138,1,8200,20,0,0,8200,17,138,8328,16,0,1,1,8201,21,0,4,8201,1,0]

theorem envBound18519 : H12AffineFastState.Bounded env18519 := by
  intro p hp
  have h : env18519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18518_18519 : H12AffineEnvironment.transform 15 138 env18518 = env18519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 138 env18518 == env18519) = true)

theorem identity18519 : scanCanonicalize (H12AffineFastState.compose env18519 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound18519 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18520 : List Nat := [2,4,8,16,1,17,8,5,0,21,1,1,8192,1,1,2,1,8200,20,0,0,8200,17,2,8192,16,0,1,1,8201,21,0,4,8201,1,0]

theorem envBound18520 : H12AffineFastState.Bounded env18520 := by
  intro p hp
  have h : env18520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18519_18520 : H12AffineEnvironment.transform 6 8 env18519 = env18520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18519 == env18520) = true)

theorem identity18520 : scanCanonicalize (H12AffineFastState.compose env18520 (packedSelected [4] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound18520 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env18521 : List Nat := [2,4,8,16,1,17,8,5,0,21,1,1,9,1,1,2,1,1,20,0,0,1,17,2,9,16,0,1,1,0,21,0,4,0,1,0]

theorem envBound18521 : H12AffineFastState.Bounded env18521 := by
  intro p hp
  have h : env18521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18520_18521 : H12AffineEnvironment.transform 12 9 env18520 = env18521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env18520 == env18521) = true)

def leafEnv18521 : List Nat := [2,4,8,16,1,17,8,5,0,21,1,1,9,1,1,2,1,1,20,0,0,1,17,2,20,9,1,16,0,1,1,0,21,0,4,0,5,2,1,0,0,0,1]

def active18521 : List Nat := [0,1,2,3]

def tree18521 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18521 : H12WitnessSearch.Good tree18521 := H12GlobalWitnessIndex.good

theorem leafIdentity18521 : H12AffineFastState.composeSystem env18521 rootObs = leafEnv18521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18521 rootObs == leafEnv18521) = true)

theorem terminalChecked18521 : H12PackedTerminal.terminalCheckFast leafEnv18521 active18521 tree18521 = true := by decide +kernel

def env18522 : List Nat := [2,4,8,16,32,17,128,36,1,52,1,1,8192,1,1,65536,1,8233,53,0,0,8200,17,65569,8328,16,0,1,1,8232,21,4294967296,37,4295041155,1,1]

theorem envBound18522 : H12AffineFastState.Bounded env18522 := by
  intro p hp
  have h : env18522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18510_18522 : H12AffineEnvironment.transform 8 1 env18510 = env18522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env18510 == env18522) = true)

theorem identity18522 : scanCanonicalize (H12AffineFastState.compose env18522 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 73738) := by decide +kernel

theorem selectedBound18522 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18523 : List Nat := [2,4,8,16,32,17,128,36,1,52,1,1,8192,1,1,65536,1,8233,53,0,0,8200,17,65569,8328,16,0,1,1,8232,21,73738,37,137,1,1]

theorem envBound18523 : H12AffineFastState.Bounded env18523 := by
  intro p hp
  have h : env18523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18522_18523 : H12AffineEnvironment.transform 31 73738 env18522 = env18523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 73738 env18522 == env18523) = true)

def env18524 : List Nat := [2,4,8,16,32,17,128,36,1,52,1,1,40,1,1,65536,1,1,53,0,0,32,17,65569,160,16,0,1,1,0,21,65570,37,137,1,1]

theorem envBound18524 : H12AffineFastState.Bounded env18524 := by
  intro p hp
  have h : env18524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18523_18524 : H12AffineEnvironment.transform 12 40 env18523 = env18524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env18523 == env18524) = true)

theorem identity18524 : scanCanonicalize (H12AffineFastState.compose env18524 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound18524 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18525 : List Nat := [2,4,8,16,1,17,128,5,1,21,1,1,9,1,1,65536,1,1,20,0,0,1,17,65536,129,16,0,1,1,0,21,65539,4,137,1,1]

theorem envBound18525 : H12AffineFastState.Bounded env18525 := by
  intro p hp
  have h : env18525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18524_18525 : H12AffineEnvironment.transform 4 1 env18524 = env18525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env18524 == env18525) = true)

theorem identity18525 : scanCanonicalize (H12AffineFastState.compose env18525 (packedSelected [6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound18525 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env18526 : List Nat := [2,4,8,16,1,17,9,5,1,21,1,1,9,1,1,65536,1,1,20,0,0,1,17,65536,8,16,0,1,1,0,21,65539,4,0,1,1]

theorem envBound18526 : H12AffineFastState.Bounded env18526 := by
  intro p hp
  have h : env18526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18525_18526 : H12AffineEnvironment.transform 6 9 env18525 = env18526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18525 == env18526) = true)

def leafEnv18526 : List Nat := [2,4,8,16,1,17,9,5,1,21,1,1,9,1,1,65536,1,1,20,0,0,1,17,65536,20,8,1,16,0,1,1,0,21,65539,4,0,5,2,1,1,0,0,1]

def active18526 : List Nat := [0,1,2,3,15]

def tree18526 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18526 : H12WitnessSearch.Good tree18526 := H12GlobalWitnessIndex.good

theorem leafIdentity18526 : H12AffineFastState.composeSystem env18526 rootObs = leafEnv18526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18526 rootObs == leafEnv18526) = true)

theorem terminalChecked18526 : H12PackedTerminal.terminalCheckFast leafEnv18526 active18526 tree18526 = true := by decide +kernel

def env18527 : List Nat := [2,4,8,16,32,17,128,36,1,52,1,1,41,1,1,65536,1,0,53,0,0,33,17,65569,161,16,0,1,1,1,21,65571,37,137,1,1]

theorem envBound18527 : H12AffineFastState.Bounded env18527 := by
  intro p hp
  have h : env18527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18523_18527 : H12AffineEnvironment.transform 12 41 env18523 = env18527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env18523 == env18527) = true)

theorem identity18527 : scanCanonicalize (H12AffineFastState.compose env18527 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound18527 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18528 : List Nat := [2,4,8,16,32,17,128,36,1,52,1,1,41,1,1,34,1,0,53,0,0,33,17,3,161,16,0,1,1,1,21,1,37,137,1,1]

theorem envBound18528 : H12AffineFastState.Bounded env18528 := by
  intro p hp
  have h : env18528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18527_18528 : H12AffineEnvironment.transform 15 34 env18527 = env18528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env18527 == env18528) = true)

def env18529 : List Nat := [2,4,8,16,0,17,128,4,1,20,1,1,9,1,1,2,1,0,21,0,0,1,17,3,129,16,0,1,1,1,21,1,5,137,1,1]

theorem envBound18529 : H12AffineFastState.Bounded env18529 := by
  intro p hp
  have h : env18529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18528_18529 : H12AffineEnvironment.transform 4 0 env18528 = env18529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env18528 == env18529) = true)

theorem identity18529 : scanCanonicalize (H12AffineFastState.compose env18529 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound18529 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env18530 : List Nat := [2,4,8,16,0,17,9,4,1,20,1,1,9,1,1,2,1,0,21,0,0,1,17,3,8,16,0,1,1,1,21,1,5,0,1,1]

theorem envBound18530 : H12AffineFastState.Bounded env18530 := by
  intro p hp
  have h : env18530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18529_18530 : H12AffineEnvironment.transform 6 9 env18529 = env18530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18529 == env18530) = true)

def leafEnv18530 : List Nat := [2,4,8,16,0,17,9,4,1,20,1,1,9,1,1,2,1,0,21,0,0,1,17,3,20,8,1,16,0,1,1,1,21,1,5,0,5,3,1,1,0,0,1]

def active18530 : List Nat := [0,1,2,3]

def tree18530 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18530 : H12WitnessSearch.Good tree18530 := H12GlobalWitnessIndex.good

theorem leafIdentity18530 : H12AffineFastState.composeSystem env18530 rootObs = leafEnv18530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18530 rootObs == leafEnv18530) = true)

theorem terminalChecked18530 : H12PackedTerminal.terminalCheckFast leafEnv18530 active18530 tree18530 = true := by decide +kernel

def env18531 : List Nat := [2,4,8,16,1,17,128,5,1,21,1,1,8,1,1,3,1,0,20,0,0,0,17,3,128,16,0,1,1,1,21,1,4,137,1,1]

theorem envBound18531 : H12AffineFastState.Bounded env18531 := by
  intro p hp
  have h : env18531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18528_18531 : H12AffineEnvironment.transform 4 1 env18528 = env18531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env18528 == env18531) = true)

def env18532 : List Nat := [2,4,8,16,32,17,128,37,512,53,1,1,8192,1,0,65536,1,8232,52,1,0,8200,17,65569,8328,16,0,1,1,8233,21,4294967296,36,4295041155,1,512]

theorem envBound18532 : H12AffineFastState.Bounded env18532 := by
  intro p hp
  have h : env18532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18509_18532 : H12AffineEnvironment.transform 7 37 env18509 = env18532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env18509 == env18532) = true)

def env18533 : List Nat := [2,4,8,16,32,17,128,37,0,53,1,1,8192,1,0,65536,1,8232,52,1,0,8200,17,65569,8328,16,0,1,1,8233,21,4294967296,36,4295041155,1,0]

theorem envBound18533 : H12AffineFastState.Bounded env18533 := by
  intro p hp
  have h : env18533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18532_18533 : H12AffineEnvironment.transform 8 0 env18532 = env18533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env18532 == env18533) = true)

theorem identity18533 : scanCanonicalize (H12AffineFastState.compose env18533 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 8352) := by decide +kernel

theorem selectedBound18533 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18534 : List Nat := [2,4,8,16,32,17,128,37,0,53,1,1,8192,1,0,65536,1,8232,52,1,0,8200,17,65569,8328,16,0,1,1,8233,21,8352,36,65571,1,0]

theorem envBound18534 : H12AffineFastState.Bounded env18534 := by
  intro p hp
  have h : env18534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18533_18534 : H12AffineEnvironment.transform 31 8352 env18533 = env18534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 8352 env18533 == env18534) = true)

def env18535 : List Nat := [2,4,8,16,32,17,128,37,0,53,1,1,128,1,0,65536,1,168,52,1,0,136,17,65569,8,16,0,1,1,169,21,32,36,65571,1,0]

theorem envBound18535 : H12AffineFastState.Bounded env18535 := by
  intro p hp
  have h : env18535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18534_18535 : H12AffineEnvironment.transform 12 128 env18534 = env18535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 128 env18534 == env18535) = true)

theorem identity18535 : scanCanonicalize (H12AffineFastState.compose env18535 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound18535 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18536 : List Nat := [2,4,8,16,32,17,8,37,0,53,1,1,8,1,0,65536,1,32,52,1,0,0,17,65569,8,16,0,1,1,33,21,32,36,65571,1,0]

theorem envBound18536 : H12AffineFastState.Bounded env18536 := by
  intro p hp
  have h : env18536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18535_18536 : H12AffineEnvironment.transform 6 8 env18535 = env18536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18535 == env18536) = true)

def env18537 : List Nat := [2,4,8,16,0,17,8,5,0,21,1,1,8,1,0,65536,1,0,20,1,0,0,17,65537,8,16,0,1,1,1,21,0,4,65539,1,0]

theorem envBound18537 : H12AffineFastState.Bounded env18537 := by
  intro p hp
  have h : env18537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18536_18537 : H12AffineEnvironment.transform 4 0 env18536 = env18537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env18536 == env18537) = true)

def env18538 : List Nat := [2,4,8,16,1,17,8,4,0,20,1,1,8,1,0,65536,1,1,21,1,0,0,17,65536,8,16,0,1,1,0,21,1,5,65538,1,0]

theorem envBound18538 : H12AffineFastState.Bounded env18538 := by
  intro p hp
  have h : env18538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18536_18538 : H12AffineEnvironment.transform 4 1 env18536 = env18538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env18536 == env18538) = true)

theorem identity18538 : scanCanonicalize (H12AffineFastState.compose env18538 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 3) := by decide +kernel

theorem selectedBound18538 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env18539 : List Nat := [2,4,8,16,1,17,8,4,0,20,1,1,8,1,0,3,1,1,21,1,0,0,17,3,8,16,0,1,1,0,21,1,5,1,1,0]

theorem envBound18539 : H12AffineFastState.Bounded env18539 := by
  intro p hp
  have h : env18539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18538_18539 : H12AffineEnvironment.transform 15 3 env18538 = env18539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3 env18538 == env18539) = true)

def leafEnv18539 : List Nat := [2,4,8,16,1,17,8,4,0,20,1,1,8,1,0,3,1,1,21,1,0,0,17,3,20,8,1,16,0,1,1,0,21,1,5,1,5,2,1,0,0,0,1]

def active18539 : List Nat := [0,1,2,3]

def tree18539 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18539 : H12WitnessSearch.Good tree18539 := H12GlobalWitnessIndex.good

theorem leafIdentity18539 : H12AffineFastState.composeSystem env18539 rootObs = leafEnv18539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18539 rootObs == leafEnv18539) = true)

theorem terminalChecked18539 : H12PackedTerminal.terminalCheckFast leafEnv18539 active18539 tree18539 = true := by decide +kernel

def env18540 : List Nat := [2,4,8,16,32,17,128,37,0,53,1,1,129,1,0,65536,1,169,52,1,0,137,17,65569,9,16,0,1,1,168,21,33,36,65571,1,0]

theorem envBound18540 : H12AffineFastState.Bounded env18540 := by
  intro p hp
  have h : env18540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18534_18540 : H12AffineEnvironment.transform 12 129 env18534 = env18540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 129 env18534 == env18540) = true)

theorem identity18540 : scanCanonicalize (H12AffineFastState.compose env18540 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound18540 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18541 : List Nat := [2,4,8,16,0,17,128,5,0,21,1,1,129,1,0,65536,1,137,20,1,0,137,17,65537,9,16,0,1,1,136,21,1,4,65539,1,0]

theorem envBound18541 : H12AffineFastState.Bounded env18541 := by
  intro p hp
  have h : env18541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18540_18541 : H12AffineEnvironment.transform 4 0 env18540 = env18541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env18540 == env18541) = true)

def env18542 : List Nat := [2,4,8,16,0,17,8,5,0,21,1,1,9,1,0,65536,1,1,20,1,0,1,17,65537,9,16,0,1,1,0,21,1,4,65539,1,0]

theorem envBound18542 : H12AffineFastState.Bounded env18542 := by
  intro p hp
  have h : env18542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18541_18542 : H12AffineEnvironment.transform 6 8 env18541 = env18542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18541 == env18542) = true)

def leafEnv18542 : List Nat := [2,4,8,16,0,17,8,5,0,21,1,1,9,1,0,65536,1,1,20,1,0,1,17,65537,20,9,1,16,0,1,1,0,21,1,4,65539,5,3,1,0,0,0,1]

def active18542 : List Nat := [0,1,2,3,15]

def tree18542 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18542 : H12WitnessSearch.Good tree18542 := H12GlobalWitnessIndex.good

theorem leafIdentity18542 : H12AffineFastState.composeSystem env18542 rootObs = leafEnv18542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18542 rootObs == leafEnv18542) = true)

theorem terminalChecked18542 : H12PackedTerminal.terminalCheckFast leafEnv18542 active18542 tree18542 = true := by decide +kernel

def env18543 : List Nat := [2,4,8,16,0,17,9,5,0,21,1,1,8,1,0,65536,1,0,20,1,0,0,17,65537,9,16,0,1,1,1,21,1,4,65539,1,0]

theorem envBound18543 : H12AffineFastState.Bounded env18543 := by
  intro p hp
  have h : env18543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18541_18543 : H12AffineEnvironment.transform 6 9 env18541 = env18543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18541 == env18543) = true)

theorem identity18543 : scanCanonicalize (H12AffineFastState.compose env18543 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 3) := by decide +kernel

theorem selectedBound18543 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env18544 : List Nat := [2,4,8,16,0,17,9,5,0,21,1,1,8,1,0,3,1,0,20,1,0,0,17,2,9,16,0,1,1,1,21,1,4,0,1,0]

theorem envBound18544 : H12AffineFastState.Bounded env18544 := by
  intro p hp
  have h : env18544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18543_18544 : H12AffineEnvironment.transform 15 3 env18543 = env18544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3 env18543 == env18544) = true)

def leafEnv18544 : List Nat := [2,4,8,16,0,17,9,5,0,21,1,1,8,1,0,3,1,0,20,1,0,0,17,2,20,9,1,16,0,1,1,1,21,1,4,0,5,3,1,0,0,0,1]

def active18544 : List Nat := [0,1,2,3]

def tree18544 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18544 : H12WitnessSearch.Good tree18544 := H12GlobalWitnessIndex.good

theorem leafIdentity18544 : H12AffineFastState.composeSystem env18544 rootObs = leafEnv18544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18544 rootObs == leafEnv18544) = true)

theorem terminalChecked18544 : H12PackedTerminal.terminalCheckFast leafEnv18544 active18544 tree18544 = true := by decide +kernel

def env18545 : List Nat := [2,4,8,16,32,17,128,37,1,53,1,1,8192,1,0,65536,1,8232,52,1,0,8200,17,65569,8328,16,0,1,1,8233,21,4294967296,36,4295041155,1,1]

theorem envBound18545 : H12AffineFastState.Bounded env18545 := by
  intro p hp
  have h : env18545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18532_18545 : H12AffineEnvironment.transform 8 1 env18532 = env18545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env18532 == env18545) = true)

theorem identity18545 : scanCanonicalize (H12AffineFastState.compose env18545 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 0) := by decide +kernel

theorem selectedBound18545 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18546 : List Nat := [2,4,8,16,32,17,128,37,1,53,1,1,8192,1,0,65536,1,8232,52,1,0,8200,17,65569,8328,16,0,1,1,8233,21,0,36,73859,1,1]

theorem envBound18546 : H12AffineFastState.Bounded env18546 := by
  intro p hp
  have h : env18546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18545_18546 : H12AffineEnvironment.transform 31 0 env18545 = env18546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 0 env18545 == env18546) = true)

def env18547 : List Nat := [2,4,8,16,32,17,128,37,1,53,1,1,160,1,0,65536,1,136,52,1,0,168,17,65569,40,16,0,1,1,137,21,0,36,65571,1,1]

theorem envBound18547 : H12AffineFastState.Bounded env18547 := by
  intro p hp
  have h : env18547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18546_18547 : H12AffineEnvironment.transform 12 160 env18546 = env18547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env18546 == env18547) = true)

def env18548 : List Nat := [2,4,8,16,0,17,128,5,1,21,1,1,128,1,0,65536,1,136,20,1,0,136,17,65537,8,16,0,1,1,137,21,0,4,65539,1,1]

theorem envBound18548 : H12AffineFastState.Bounded env18548 := by
  intro p hp
  have h : env18548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18547_18548 : H12AffineEnvironment.transform 4 0 env18547 = env18548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env18547 == env18548) = true)

theorem identity18548 : scanCanonicalize (H12AffineFastState.compose env18548 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound18548 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18549 : List Nat := [2,4,8,16,0,17,9,5,1,21,1,1,9,1,0,65536,1,1,20,1,0,1,17,65537,8,16,0,1,1,0,21,0,4,65539,1,1]

theorem envBound18549 : H12AffineFastState.Bounded env18549 := by
  intro p hp
  have h : env18549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18548_18549 : H12AffineEnvironment.transform 6 9 env18548 = env18549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18548 == env18549) = true)

def leafEnv18549 : List Nat := [2,4,8,16,0,17,9,5,1,21,1,1,9,1,0,65536,1,1,20,1,0,1,17,65537,20,8,1,16,0,1,1,0,21,0,4,65539,5,3,1,1,0,0,1]

def active18549 : List Nat := [0,1,2,3,15]

def tree18549 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18549 : H12WitnessSearch.Good tree18549 := H12GlobalWitnessIndex.good

theorem leafIdentity18549 : H12AffineFastState.composeSystem env18549 rootObs = leafEnv18549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18549 rootObs == leafEnv18549) = true)

theorem terminalChecked18549 : H12PackedTerminal.terminalCheckFast leafEnv18549 active18549 tree18549 = true := by decide +kernel

def env18550 : List Nat := [2,4,8,16,1,17,128,4,1,20,1,1,129,1,0,65536,1,136,21,1,0,137,17,65536,9,16,0,1,1,137,21,0,5,65538,1,1]

theorem envBound18550 : H12AffineFastState.Bounded env18550 := by
  intro p hp
  have h : env18550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18547_18550 : H12AffineEnvironment.transform 4 1 env18547 = env18550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env18547 == env18550) = true)

theorem identity18550 : scanCanonicalize (H12AffineFastState.compose env18550 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 2) := by decide +kernel

theorem selectedBound18550 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env18551 : List Nat := [2,4,8,16,1,17,128,4,1,20,1,1,129,1,0,2,1,136,21,1,0,137,17,2,9,16,0,1,1,137,21,0,5,0,1,1]

theorem envBound18551 : H12AffineFastState.Bounded env18551 := by
  intro p hp
  have h : env18551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18550_18551 : H12AffineEnvironment.transform 15 2 env18550 = env18551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2 env18550 == env18551) = true)

theorem identity18551 : scanCanonicalize (H12AffineFastState.compose env18551 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound18551 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env18552 : List Nat := [2,4,8,16,1,17,9,4,1,20,1,1,8,1,0,2,1,1,21,1,0,0,17,2,9,16,0,1,1,0,21,0,5,0,1,1]

theorem envBound18552 : H12AffineFastState.Bounded env18552 := by
  intro p hp
  have h : env18552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18551_18552 : H12AffineEnvironment.transform 6 9 env18551 = env18552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18551 == env18552) = true)

def leafEnv18552 : List Nat := [2,4,8,16,1,17,9,4,1,20,1,1,8,1,0,2,1,1,21,1,0,0,17,2,20,9,1,16,0,1,1,0,21,0,5,0,5,2,1,1,0,0,1]

def active18552 : List Nat := [0,1,2,3]

def tree18552 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18552 : H12WitnessSearch.Good tree18552 := H12GlobalWitnessIndex.good

theorem leafIdentity18552 : H12AffineFastState.composeSystem env18552 rootObs = leafEnv18552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18552 rootObs == leafEnv18552) = true)

theorem terminalChecked18552 : H12PackedTerminal.terminalCheckFast leafEnv18552 active18552 tree18552 = true := by decide +kernel

def env18553 : List Nat := [2,4,8,16,32,17,128,37,1,53,1,1,161,1,0,65536,1,137,52,1,0,169,17,65569,41,16,0,1,1,136,21,0,36,65570,1,1]

theorem envBound18553 : H12AffineFastState.Bounded env18553 := by
  intro p hp
  have h : env18553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18546_18553 : H12AffineEnvironment.transform 12 161 env18546 = env18553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env18546 == env18553) = true)

def env18554 : List Nat := [2,4,8,16,0,17,128,5,1,21,1,1,129,1,0,65536,1,137,20,1,0,137,17,65537,9,16,0,1,1,136,21,0,4,65538,1,1]

theorem envBound18554 : H12AffineFastState.Bounded env18554 := by
  intro p hp
  have h : env18554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18553_18554 : H12AffineEnvironment.transform 4 0 env18553 = env18554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env18553 == env18554) = true)

theorem identity18554 : scanCanonicalize (H12AffineFastState.compose env18554 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 2) := by decide +kernel

theorem selectedBound18554 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18555 : List Nat := [2,4,8,16,0,17,128,5,1,21,1,1,129,1,0,2,1,137,20,1,0,137,17,3,9,16,0,1,1,136,21,0,4,0,1,1]

theorem envBound18555 : H12AffineFastState.Bounded env18555 := by
  intro p hp
  have h : env18555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18554_18555 : H12AffineEnvironment.transform 15 2 env18554 = env18555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2 env18554 == env18555) = true)

def env18556 : List Nat := [2,4,8,16,1,17,128,4,1,20,1,1,128,1,0,65536,1,137,21,1,0,136,17,65536,8,16,0,1,1,136,21,0,5,65539,1,1]

theorem envBound18556 : H12AffineFastState.Bounded env18556 := by
  intro p hp
  have h : env18556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18553_18556 : H12AffineEnvironment.transform 4 1 env18553 = env18556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env18553 == env18556) = true)

theorem identity18556 : scanCanonicalize (H12AffineFastState.compose env18556 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 139) := by decide +kernel

theorem selectedBound18556 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18557 : List Nat := [2,4,8,16,1,17,128,4,1,20,1,1,128,1,0,139,1,137,21,1,0,136,17,139,8,16,0,1,1,136,21,0,5,136,1,1]

theorem envBound18557 : H12AffineFastState.Bounded env18557 := by
  intro p hp
  have h : env18557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18556_18557 : H12AffineEnvironment.transform 15 139 env18556 = env18557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 139 env18556 == env18557) = true)

def env18558 : List Nat := [2,4,8,16,32,17,128,256,512,273,1,0,8192,0,293,65536,0,8461,272,292,1,8200,17,65569,8328,16,0,0,0,8460,20,4294967296,257,4295041155,0,512]

theorem envBound18558 : H12AffineFastState.Bounded env18558 := by
  intro p hp
  have h : env18558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18508_18558 : H12AffineEnvironment.transform 9 273 env18508 = env18558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env18508 == env18558) = true)

theorem identity18558 : scanCanonicalize (H12AffineFastState.compose env18558 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 170) := by decide +kernel

theorem selectedBound18558 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18559 : List Nat := [2,4,8,16,32,17,128,256,512,273,1,0,8192,0,293,170,0,8461,272,292,1,8200,17,139,8328,16,0,0,0,8460,20,4294967296,257,4294975529,0,512]

theorem envBound18559 : H12AffineFastState.Bounded env18559 := by
  intro p hp
  have h : env18559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18558_18559 : H12AffineEnvironment.transform 15 170 env18558 = env18559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 170 env18558 == env18559) = true)

def env18560 : List Nat := [2,4,8,16,32,17,128,256,512,273,1,0,672,0,293,170,0,941,272,292,1,680,17,139,552,16,0,0,0,940,20,4294967296,257,4294967945,0,512]

theorem envBound18560 : H12AffineFastState.Bounded env18560 := by
  intro p hp
  have h : env18560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18559_18560 : H12AffineEnvironment.transform 12 672 env18559 = env18560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 672 env18559 == env18560) = true)

theorem identity18560 : scanCanonicalize (H12AffineFastState.compose env18560 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 293) := by decide +kernel

theorem selectedBound18560 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18561 : List Nat := [2,4,8,16,32,17,128,256,512,273,1,0,672,0,293,170,0,941,272,292,1,680,17,139,552,16,0,0,0,940,20,293,257,940,0,512]

theorem envBound18561 : H12AffineFastState.Bounded env18561 := by
  intro p hp
  have h : env18561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18560_18561 : H12AffineEnvironment.transform 31 293 env18560 = env18561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 293 env18560 == env18561) = true)

def env18562 : List Nat := [2,4,8,16,0,17,128,256,512,273,1,0,640,0,261,138,0,909,272,260,1,648,17,139,520,16,0,0,0,908,20,261,257,908,0,512]

theorem envBound18562 : H12AffineFastState.Bounded env18562 := by
  intro p hp
  have h : env18562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18561_18562 : H12AffineEnvironment.transform 4 0 env18561 = env18562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env18561 == env18562) = true)

theorem identity18562 : scanCanonicalize (H12AffineFastState.compose env18562 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound18562 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18563 : List Nat := [2,4,8,16,0,17,8,256,512,273,1,0,520,0,261,2,0,773,272,260,1,512,17,3,520,16,0,0,0,772,20,261,257,772,0,512]

theorem envBound18563 : H12AffineFastState.Bounded env18563 := by
  intro p hp
  have h : env18563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18562_18563 : H12AffineEnvironment.transform 6 8 env18562 = env18563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18562 == env18563) = true)

def env18564 : List Nat := [2,4,8,16,0,17,8,256,0,273,1,0,8,0,261,2,0,261,272,260,1,0,17,3,8,16,0,0,0,260,20,261,257,260,0,0]

theorem envBound18564 : H12AffineFastState.Bounded env18564 := by
  intro p hp
  have h : env18564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18563_18564 : H12AffineEnvironment.transform 8 0 env18563 = env18564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env18563 == env18564) = true)

theorem identity18564 : scanCanonicalize (H12AffineFastState.compose env18564 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound18564 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env18565 : List Nat := [2,4,8,16,0,17,8,4,0,21,1,0,8,0,1,2,0,1,20,0,1,0,17,3,8,16,0,0,0,0,20,1,5,0,0,0]

theorem envBound18565 : H12AffineFastState.Bounded env18565 := by
  intro p hp
  have h : env18565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18564_18565 : H12AffineEnvironment.transform 7 4 env18564 = env18565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env18564 == env18565) = true)

def leafEnv18565 : List Nat := [2,4,8,16,0,17,8,4,0,21,1,0,8,0,1,2,0,1,20,0,1,0,17,3,21,8,1,16,0,0,0,0,20,1,5,0,5,3,0,0,0,1,1]

def active18565 : List Nat := [0,1,2,3]

def tree18565 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18565 : H12WitnessSearch.Good tree18565 := H12GlobalWitnessIndex.good

theorem leafIdentity18565 : H12AffineFastState.composeSystem env18565 rootObs = leafEnv18565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18565 rootObs == leafEnv18565) = true)

theorem terminalChecked18565 : H12PackedTerminal.terminalCheckFast leafEnv18565 active18565 tree18565 = true := by decide +kernel

def env18566 : List Nat := [2,4,8,16,0,17,8,256,1,273,1,0,9,0,261,2,0,260,272,260,1,1,17,3,9,16,0,0,0,261,20,261,257,261,0,1]

theorem envBound18566 : H12AffineFastState.Bounded env18566 := by
  intro p hp
  have h : env18566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18563_18566 : H12AffineEnvironment.transform 8 1 env18563 = env18566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env18563 == env18566) = true)

def env18567 : List Nat := [2,4,8,16,1,17,128,256,512,273,1,0,641,0,260,139,0,908,272,261,1,649,17,139,521,16,0,0,0,909,20,260,257,909,0,512]

theorem envBound18567 : H12AffineFastState.Bounded env18567 := by
  intro p hp
  have h : env18567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18561_18567 : H12AffineEnvironment.transform 4 1 env18561 = env18567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env18561 == env18567) = true)

theorem identity18567 : scanCanonicalize (H12AffineFastState.compose env18567 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound18567 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18568 : List Nat := [2,4,8,16,1,17,128,256,1,273,1,0,128,0,260,139,0,397,272,261,1,136,17,139,8,16,0,0,0,396,20,260,257,396,0,1]

theorem envBound18568 : H12AffineFastState.Bounded env18568 := by
  intro p hp
  have h : env18568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18567_18568 : H12AffineEnvironment.transform 8 1 env18567 = env18568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env18567 == env18568) = true)

def env18569 : List Nat := [2,4,8,16,1,17,8,256,1,273,1,0,8,0,260,3,0,261,272,261,1,0,17,3,8,16,0,0,0,260,20,260,257,260,0,1]

theorem envBound18569 : H12AffineFastState.Bounded env18569 := by
  intro p hp
  have h : env18569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18568_18569 : H12AffineEnvironment.transform 6 8 env18568 = env18569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18568 == env18569) = true)

def env18570 : List Nat := [2,4,8,16,1,17,9,256,1,273,1,0,9,0,260,2,0,260,272,261,1,1,17,2,8,16,0,0,0,261,20,260,257,261,0,1]

theorem envBound18570 : H12AffineFastState.Bounded env18570 := by
  intro p hp
  have h : env18570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18568_18570 : H12AffineEnvironment.transform 6 9 env18568 = env18570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env18568 == env18570) = true)

theorem identity18570 : scanCanonicalize (H12AffineFastState.compose env18570 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound18570 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env18571 : List Nat := [2,4,8,16,1,17,9,5,1,20,1,0,9,0,1,2,0,1,21,0,1,1,17,2,8,16,0,0,0,0,20,1,4,0,0,1]

theorem envBound18571 : H12AffineFastState.Bounded env18571 := by
  intro p hp
  have h : env18571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18570_18571 : H12AffineEnvironment.transform 7 5 env18570 = env18571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env18570 == env18571) = true)

def leafEnv18571 : List Nat := [2,4,8,16,1,17,9,5,1,20,1,0,9,0,1,2,0,1,21,0,1,1,17,2,21,8,1,16,0,0,0,0,20,1,4,0,5,2,0,1,0,1,1]

def active18571 : List Nat := [0,1,2,3]

def tree18571 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18571 : H12WitnessSearch.Good tree18571 := H12GlobalWitnessIndex.good

theorem leafIdentity18571 : H12AffineFastState.composeSystem env18571 rootObs = leafEnv18571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18571 rootObs == leafEnv18571) = true)

theorem terminalChecked18571 : H12PackedTerminal.terminalCheckFast leafEnv18571 active18571 tree18571 = true := by decide +kernel

def env18572 : List Nat := [2,4,8,16,32,17,128,256,512,273,1,0,673,0,293,170,0,940,272,292,1,681,17,139,553,16,0,0,0,941,20,4294967296,257,4294967944,0,512]

theorem envBound18572 : H12AffineFastState.Bounded env18572 := by
  intro p hp
  have h : env18572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18559_18572 : H12AffineEnvironment.transform 12 673 env18559 = env18572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 673 env18559 == env18572) = true)

theorem identity18572 : scanCanonicalize (H12AffineFastState.compose env18572 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 513) := by decide +kernel

theorem selectedBound18572 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18573 : List Nat := [2,4,8,16,32,17,128,256,512,273,1,0,673,0,293,170,0,940,272,292,1,681,17,139,553,16,0,0,0,941,20,513,257,137,0,512]

theorem envBound18573 : H12AffineFastState.Bounded env18573 := by
  intro p hp
  have h : env18573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18572_18573 : H12AffineEnvironment.transform 31 513 env18572 = env18573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 513 env18572 == env18573) = true)

def env18574 : List Nat := [2,4,8,16,32,17,128,256,136,273,1,0,41,0,293,170,0,292,272,292,1,33,17,139,161,16,0,0,0,293,20,137,257,137,0,136]

theorem envBound18574 : H12AffineFastState.Bounded env18574 := by
  intro p hp
  have h : env18574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18573_18574 : H12AffineEnvironment.transform 8 136 env18573 = env18574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env18573 == env18574) = true)

theorem identity18574 : scanCanonicalize (H12AffineFastState.compose env18574 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound18574 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18575 : List Nat := [2,4,8,16,32,17,128,37,136,52,1,0,41,0,0,170,0,1,53,1,1,33,17,139,161,16,0,0,0,0,20,137,36,137,0,136]

theorem envBound18575 : H12AffineFastState.Bounded env18575 := by
  intro p hp
  have h : env18575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18574_18575 : H12AffineEnvironment.transform 7 37 env18574 = env18575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env18574 == env18575) = true)

def leafEnv18575 : List Nat := [2,4,8,16,32,17,128,37,136,52,1,0,41,0,0,170,0,1,53,1,1,33,17,139,21,161,1,16,0,0,0,0,20,137,36,137,5,35,0,136,0,1,1]

def active18575 : List Nat := [0,1,2,3,4,6]

def tree18575 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18575 : H12WitnessSearch.Good tree18575 := H12GlobalWitnessIndex.good

theorem leafIdentity18575 : H12AffineFastState.composeSystem env18575 rootObs = leafEnv18575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18575 rootObs == leafEnv18575) = true)

theorem terminalChecked18575 : H12PackedTerminal.terminalCheckFast leafEnv18575 active18575 tree18575 = true := by decide +kernel

def env18576 : List Nat := [2,4,8,16,32,17,128,256,137,273,1,0,40,0,293,170,0,293,272,292,1,32,17,139,160,16,0,0,0,292,20,136,257,137,0,137]

theorem envBound18576 : H12AffineFastState.Bounded env18576 := by
  intro p hp
  have h : env18576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18573_18576 : H12AffineEnvironment.transform 8 137 env18573 = env18576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env18573 == env18576) = true)

theorem identity18576 : scanCanonicalize (H12AffineFastState.compose env18576 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound18576 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18577 : List Nat := [2,4,8,16,32,17,41,256,32,273,1,0,40,0,293,3,0,293,272,292,1,32,17,34,9,16,0,0,0,292,20,33,257,32,0,32]

theorem envBound18577 : H12AffineFastState.Bounded env18577 := by
  intro p hp
  have h : env18577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18576_18577 : H12AffineEnvironment.transform 6 41 env18576 = env18577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env18576 == env18577) = true)

theorem identity18577 : scanCanonicalize (H12AffineFastState.compose env18577 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound18577 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env18578 : List Nat := [2,4,8,16,0,17,9,256,0,273,1,0,8,0,261,3,0,261,272,260,1,0,17,2,9,16,0,0,0,260,20,1,257,0,0,0]

theorem envBound18578 : H12AffineFastState.Bounded env18578 := by
  intro p hp
  have h : env18578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18577_18578 : H12AffineEnvironment.transform 4 0 env18577 = env18578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env18577 == env18578) = true)

def leafEnv18578 : List Nat := [2,4,8,16,0,17,9,256,0,273,1,0,8,0,261,3,0,261,272,260,1,0,17,2,21,9,1,16,0,0,0,260,20,1,257,0,5,3,0,0,0,1,1]

def active18578 : List Nat := [0,1,2,3,7]

def tree18578 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18578 : H12WitnessSearch.Good tree18578 := H12GlobalWitnessIndex.good

theorem leafIdentity18578 : H12AffineFastState.composeSystem env18578 rootObs = leafEnv18578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18578 rootObs == leafEnv18578) = true)

theorem terminalChecked18578 : H12PackedTerminal.terminalCheckFast leafEnv18578 active18578 tree18578 = true := by decide +kernel

def env18579 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4097,32768,65536,4097,262144,524288,32769,4097,4194304,64,98564,8328,525329,4984901,4097,529409,1073741824,1285,4294967296,257,4299260334,4097,512]

theorem envBound18579 : H12AffineFastState.Bounded env18579 := by
  intro p hp
  have h : env18579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18402_18579 : H12AffineEnvironment.transform 13 4097 env18402 = env18579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4097 env18402 == env18579) = true)

theorem identity18579 : scanCanonicalize (H12AffineFastState.compose env18579 (packedSelected [9,22] rootPS)) = affineNative (2^(11+1) ^^^ 1345) := by decide +kernel

theorem selectedBound18579 : packedSelected [9,22] rootPS < 2^1333 := by decide +kernel

def env18580 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,65536,1344,262144,524288,32769,1344,4194304,64,98564,8328,525329,4982020,1344,524608,1073741824,1285,4294967296,257,4299260334,1344,512]

theorem envBound18580 : H12AffineFastState.Bounded env18580 := by
  intro p hp
  have h : env18580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18579_18580 : H12AffineEnvironment.transform 11 1345 env18579 = env18580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env18579 == env18580) = true)

def env18581 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,65536,1344,262144,1104,32769,1344,4194304,64,98564,8328,65,4456788,1344,1296,1073741824,1285,4294967296,257,4299260334,1344,512]

theorem envBound18581 : H12AffineFastState.Bounded env18581 := by
  intro p hp
  have h : env18581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18580_18581 : H12AffineEnvironment.transform 18 1104 env18580 = env18581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1104 env18580 == env18581) = true)

theorem identity18581 : scanCanonicalize (H12AffineFastState.compose env18581 (packedSelected [8,10,13,15] rootPS)) = affineNative (2^(29+1) ^^^ 107041) := by decide +kernel

theorem selectedBound18581 : packedSelected [8,10,13,15] rootPS < 2^1333 := by decide +kernel

def env18582 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,65536,1344,262144,1104,32769,1344,4194304,64,98564,8328,65,4456788,1344,1296,107041,1285,4294967296,257,4299260334,1344,512]

theorem envBound18582 : H12AffineFastState.Bounded env18582 := by
  intro p hp
  have h : env18582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18581_18582 : H12AffineEnvironment.transform 29 107041 env18581 = env18582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 107041 env18581 == env18582) = true)

theorem identity18582 : scanCanonicalize (H12AffineFastState.compose env18582 (packedSelected [3,8,10,13,17] rootPS)) = affineNative (2^(15+1) ^^^ 43860) := by decide +kernel

theorem selectedBound18582 : packedSelected [3,8,10,13,17] rootPS < 2^1333 := by decide +kernel

def env18583 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,43860,1344,262144,1104,32769,1344,4194304,64,10832,8328,65,4456788,1344,1296,2421,1285,4294967296,257,4299172602,1344,512]

theorem envBound18583 : H12AffineFastState.Bounded env18583 := by
  intro p hp
  have h : env18583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18582_18583 : H12AffineEnvironment.transform 15 43860 env18582 = env18583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 43860 env18582 == env18583) = true)

theorem identity18583 : scanCanonicalize (H12AffineFastState.compose env18583 (packedSelected [8,12,19,21] rootPS)) = affineNative (2^(12+1) ^^^ 2779) := by decide +kernel

theorem selectedBound18583 : packedSelected [8,12,19,21] rootPS < 2^1333 := by decide +kernel

def env18584 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,2779,1344,32768,33167,1344,262144,1104,32769,1344,4194304,64,139,2643,65,4456788,1344,1296,2421,1285,4294967296,257,4299161633,1344,512]

theorem envBound18584 : H12AffineFastState.Bounded env18584 := by
  intro p hp
  have h : env18584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18583_18584 : H12AffineEnvironment.transform 12 2779 env18583 = env18584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2779 env18583 == env18584) = true)

theorem identity18584 : scanCanonicalize (H12AffineFastState.compose env18584 (packedSelected [1,8,10,12,13,19] rootPS)) = affineNative (2^(21+1) ^^^ 295554) := by decide +kernel

theorem selectedBound18584 : packedSelected [1,8,10,12,13,19] rootPS < 2^1333 := by decide +kernel

def env18585 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,2779,1344,32768,33167,1344,262144,1104,32769,1344,295554,64,139,2643,65,33750,1344,1296,2421,1285,4294967296,257,4295262883,1344,512]

theorem envBound18585 : H12AffineFastState.Bounded env18585 := by
  intro p hp
  have h : env18585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18584_18585 : H12AffineEnvironment.transform 21 295554 env18584 = env18585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 295554 env18584 == env18585) = true)

theorem identity18585 : scanCanonicalize (H12AffineFastState.compose env18585 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 33443) := by decide +kernel

theorem selectedBound18585 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env18586 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,2779,1344,32768,33167,1344,33443,1104,32769,1344,33,64,139,2643,65,33750,1344,1296,2421,1285,4294967296,257,4294967296,1344,512]

theorem envBound18586 : H12AffineFastState.Bounded env18586 := by
  intro p hp
  have h : env18586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18585_18586 : H12AffineEnvironment.transform 17 33443 env18585 = env18586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 33443 env18585 == env18586) = true)

theorem identity18586 : scanCanonicalize (H12AffineFastState.compose env18586 (packedSelected [1,3,10] rootPS)) = affineNative (2^(14+1) ^^^ 3030) := by decide +kernel

theorem selectedBound18586 : packedSelected [1,3,10] rootPS < 2^1333 := by decide +kernel

def env18587 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,2779,1344,3030,2649,1344,2421,1104,3031,1344,33,64,139,2643,65,2048,1344,1296,2421,1285,4294967296,257,4294967296,1344,512]

theorem envBound18587 : H12AffineFastState.Bounded env18587 := by
  intro p hp
  have h : env18587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18586_18587 : H12AffineEnvironment.transform 14 3030 env18586 = env18587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 3030 env18586 == env18587) = true)

theorem identity18587 : scanCanonicalize (H12AffineFastState.compose env18587 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound18587 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env18588 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,2699,1296,2950,2569,1296,2341,1024,2951,1296,33,16,139,2563,17,2048,1296,1296,2341,1285,4294967296,257,4294967296,1296,512]

theorem envBound18588 : H12AffineFastState.Bounded env18588 := by
  intro p hp
  have h : env18588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18587_18588 : H12AffineEnvironment.transform 5 16 env18587 = env18588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env18587 == env18588) = true)

theorem identity18588 : scanCanonicalize (H12AffineFastState.compose env18588 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound18588 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18589 : List Nat := [2,4,8,16,10,16,128,256,512,1024,2048,1297,2699,1296,2950,2569,1296,2319,1024,2951,1296,11,16,139,2563,17,2048,1296,1296,2319,1285,4294967296,257,4294967296,1296,512]

theorem envBound18589 : H12AffineFastState.Bounded env18589 := by
  intro p hp
  have h : env18589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18588_18589 : H12AffineEnvironment.transform 4 10 env18588 = env18589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env18588 == env18589) = true)

theorem identity18589 : scanCanonicalize (H12AffineFastState.compose env18589 (packedSelected [2] rootPS)) = affineNative (2^(31+1) ^^^ 789) := by decide +kernel

theorem selectedBound18589 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18590 : List Nat := [2,4,8,16,10,16,128,256,512,1024,2048,1297,2699,1296,2950,2569,1296,2319,1024,2951,1296,11,16,139,2563,17,2048,1296,1296,2319,1285,789,257,789,1296,512]

theorem envBound18590 : H12AffineFastState.Bounded env18590 := by
  intro p hp
  have h : env18590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18589_18590 : H12AffineEnvironment.transform 31 789 env18589 = env18590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 789 env18589 == env18590) = true)

theorem identity18590 : scanCanonicalize (H12AffineFastState.compose env18590 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 157) := by decide +kernel

theorem selectedBound18590 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env18591 : List Nat := [2,4,8,16,10,16,128,157,512,1024,2048,1164,2699,1165,2587,2569,1165,2194,1024,2586,1165,11,16,139,2563,17,2048,1165,1165,2194,1176,648,156,648,1165,512]

theorem envBound18591 : H12AffineFastState.Bounded env18591 := by
  intro p hp
  have h : env18591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18590_18591 : H12AffineEnvironment.transform 7 157 env18590 = env18591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 157 env18590 == env18591) = true)

theorem identity18591 : scanCanonicalize (H12AffineFastState.compose env18591 (packedSelected [5] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound18591 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env18592 : List Nat := [2,4,8,16,10,16,128,157,136,1024,2048,1164,2051,1165,2195,2177,1165,2194,1024,2194,1165,11,16,139,2187,17,2048,1165,1165,2194,1176,0,156,0,1165,136]

theorem envBound18592 : H12AffineFastState.Bounded env18592 := by
  intro p hp
  have h : env18592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18591_18592 : H12AffineEnvironment.transform 8 136 env18591 = env18592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env18591 == env18592) = true)

theorem identity18592 : scanCanonicalize (H12AffineFastState.compose env18592 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound18592 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18593 : List Nat := [2,4,8,16,10,16,19,14,27,1024,2048,1055,2051,1054,2048,2066,1054,2049,1024,2049,1054,11,16,24,2072,17,2048,1054,1054,2049,1035,0,15,0,1054,27]

theorem envBound18593 : H12AffineFastState.Bounded env18593 := by
  intro p hp
  have h : env18593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18592_18593 : H12AffineEnvironment.transform 6 19 env18592 = env18593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env18592 == env18593) = true)

def env18594 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,65536,1344,262144,1105,32769,1344,4194304,64,98564,8328,64,4456789,1344,1297,1073741824,1285,4294967296,257,4299260334,1344,512]

theorem envBound18594 : H12AffineFastState.Bounded env18594 := by
  intro p hp
  have h : env18594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18580_18594 : H12AffineEnvironment.transform 18 1105 env18580 = env18594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1105 env18580 == env18594) = true)

theorem identity18594 : scanCanonicalize (H12AffineFastState.compose env18594 (packedSelected [8,10,13,15] rootPS)) = affineNative (2^(29+1) ^^^ 4467408) := by decide +kernel

theorem selectedBound18594 : packedSelected [8,10,13,15] rootPS < 2^1333 := by decide +kernel

def env18595 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,65536,1344,262144,1105,32769,1344,4194304,64,98564,8328,64,4456789,1344,1297,4467408,1285,4294967296,257,4299260334,1344,512]

theorem envBound18595 : H12AffineFastState.Bounded env18595 := by
  intro p hp
  have h : env18595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18594_18595 : H12AffineEnvironment.transform 29 4467408 env18594 = env18595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4467408 env18594 == env18595) = true)

theorem identity18595 : scanCanonicalize (H12AffineFastState.compose env18595 (packedSelected [8,12,19,21] rootPS)) = affineNative (2^(17+1) ^^^ 43129) := by decide +kernel

theorem selectedBound18595 : packedSelected [8,12,19,21] rootPS < 2^1333 := by decide +kernel

def env18596 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,65536,1344,43129,1105,32769,1344,4194304,64,98564,8328,64,4237612,1344,1297,4227753,1285,4294967296,257,4299260334,1344,512]

theorem envBound18596 : H12AffineFastState.Bounded env18596 := by
  intro p hp
  have h : env18596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18595_18596 : H12AffineEnvironment.transform 17 43129 env18595 = env18596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43129 env18595 == env18596) = true)

theorem identity18596 : scanCanonicalize (H12AffineFastState.compose env18596 (packedSelected [5,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 3068) := by decide +kernel

theorem selectedBound18596 : packedSelected [5,10,19] rootPS < 2^1333 := by decide +kernel

def env18597 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,3068,65536,1344,9093,1105,3069,1344,4194304,64,68344,8328,64,4203216,1344,1297,4196693,1285,4294967296,257,4299229778,1344,512]

theorem envBound18597 : H12AffineFastState.Bounded env18597 := by
  intro p hp
  have h : env18597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18596_18597 : H12AffineEnvironment.transform 14 3068 env18596 = env18597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 3068 env18596 == env18597) = true)

theorem identity18597 : scanCanonicalize (H12AffineFastState.compose env18597 (packedSelected [3,10] rootPS)) = affineNative (2^(21+1) ^^^ 10961) := by decide +kernel

theorem selectedBound18597 : packedSelected [3,10] rootPS < 2^1333 := by decide +kernel

def env18598 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,3068,65536,1344,9093,1105,3069,1344,10961,64,68344,8328,64,2049,1344,1297,9092,1285,4294967296,257,4295041155,1344,512]

theorem envBound18598 : H12AffineFastState.Bounded env18598 := by
  intro p hp
  have h : env18598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18597_18598 : H12AffineEnvironment.transform 21 10961 env18597 = env18598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10961 env18597 == env18598) = true)

theorem identity18598 : scanCanonicalize (H12AffineFastState.compose env18598 (packedSelected [11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound18598 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env18599 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1296,2988,65536,1296,9093,1025,2989,1296,10881,16,68264,8328,16,2049,1296,1297,9092,1285,4294967296,257,4295041155,1296,512]

theorem envBound18599 : H12AffineFastState.Bounded env18599 := by
  intro p hp
  have h : env18599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18598_18599 : H12AffineEnvironment.transform 5 16 env18598 = env18599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env18598 == env18599) = true)

theorem identity18599 : scanCanonicalize (H12AffineFastState.compose env18599 (packedSelected [1,3] rootPS)) = affineNative (2^(15+1) ^^^ 2595) := by decide +kernel

theorem selectedBound18599 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env18600 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1296,2988,2595,1296,9093,1025,2989,1296,10881,16,139,8328,16,2049,1296,1297,9092,1285,4294967296,257,4294978208,1296,512]

theorem envBound18600 : H12AffineFastState.Bounded env18600 := by
  intro p hp
  have h : env18600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18599_18600 : H12AffineEnvironment.transform 15 2595 env18599 = env18600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2595 env18599 == env18600) = true)

theorem identity18600 : scanCanonicalize (H12AffineFastState.compose env18600 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 2720) := by decide +kernel

theorem selectedBound18600 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18601 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,2720,1296,2988,2595,1296,2341,1025,2989,1296,33,16,139,2600,16,2049,1296,1297,2340,1285,4294967296,257,4294967296,1296,512]

theorem envBound18601 : H12AffineFastState.Bounded env18601 := by
  intro p hp
  have h : env18601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18600_18601 : H12AffineEnvironment.transform 12 2720 env18600 = env18601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2720 env18600 == env18601) = true)

theorem identity18601 : scanCanonicalize (H12AffineFastState.compose env18601 (packedSelected [2] rootPS)) = affineNative (2^(31+1) ^^^ 805) := by decide +kernel

theorem selectedBound18601 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18602 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,2720,1296,2988,2595,1296,2341,1025,2989,1296,33,16,139,2600,16,2049,1296,1297,2340,1285,805,257,805,1296,512]

theorem envBound18602 : H12AffineFastState.Bounded env18602 := by
  intro p hp
  have h : env18602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18601_18602 : H12AffineEnvironment.transform 31 805 env18601 = env18602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 805 env18601 == env18602) = true)

theorem identity18602 : scanCanonicalize (H12AffineFastState.compose env18602 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound18602 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env18603 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,1297,2088,1296,2340,2219,1296,2341,1025,2341,1296,33,16,139,2208,16,2049,1296,1297,2340,1285,429,257,429,1296,136]

theorem envBound18603 : H12AffineFastState.Bounded env18603 := by
  intro p hp
  have h : env18603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18602_18603 : H12AffineEnvironment.transform 8 136 env18602 = env18603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env18602 == env18603) = true)

theorem identity18603 : scanCanonicalize (H12AffineFastState.compose env18603 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound18603 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18604 : List Nat := [2,4,8,16,32,16,128,37,136,1024,2048,1076,2088,1077,2049,2219,1077,2048,1025,2048,1077,33,16,139,2208,16,2049,1077,1076,2049,1056,136,36,136,1077,136]

theorem envBound18604 : H12AffineFastState.Bounded env18604 := by
  intro p hp
  have h : env18604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18603_18604 : H12AffineEnvironment.transform 7 37 env18603 = env18604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env18603 == env18604) = true)

def leafEnv18604 : List Nat := [2,4,8,16,32,16,128,37,136,1024,2048,1076,2088,1077,2049,2219,1077,2048,1025,2048,1077,33,16,139,1057,2208,1,16,2049,1077,1076,2049,1056,136,36,136,5,2082,1077,136,0,1077,1]

def active18604 : List Nat := [0,1,2,3,4,6,9,10]

def tree18604 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18604 : H12WitnessSearch.Good tree18604 := H12GlobalWitnessIndex.good

theorem leafIdentity18604 : H12AffineFastState.composeSystem env18604 rootObs = leafEnv18604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18604 rootObs == leafEnv18604) = true)

theorem terminalChecked18604 : H12PackedTerminal.terminalCheckFast leafEnv18604 active18604 tree18604 = true := by decide +kernel

def env18605 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16385,262144,524288,32769,4097,4194304,65,98564,8328,525328,4997189,16384,529408,1073741824,1285,4294967296,257,4299260334,16385,512]

theorem envBound18605 : H12AffineFastState.Bounded env18605 := by
  intro p hp
  have h : env18605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18401_18605 : H12AffineEnvironment.transform 16 16385 env18401 = env18605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16385 env18401 == env18605) = true)

def env18606 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4096,32768,65536,4097,262144,524288,32769,4097,4194304,65,98564,8328,525328,4984901,4096,529408,1073741824,1285,4294967296,257,4299260334,4097,512]

theorem envBound18606 : H12AffineFastState.Bounded env18606 := by
  intro p hp
  have h : env18606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18605_18606 : H12AffineEnvironment.transform 13 4096 env18605 = env18606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4096 env18605 == env18606) = true)

theorem identity18606 : scanCanonicalize (H12AffineFastState.compose env18606 (packedSelected [9,22] rootPS)) = affineNative (2^(18+1) ^^^ 4369) := by decide +kernel

theorem selectedBound18606 : packedSelected [9,22] rootPS < 2^1333 := by decide +kernel

def env18607 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4096,32768,65536,4097,262144,4369,32769,4097,4194304,65,98564,8328,5377,4456788,4096,1297,1073741824,1285,4294967296,257,4299260334,4097,512]

theorem envBound18607 : H12AffineFastState.Bounded env18607 := by
  intro p hp
  have h : env18607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18606_18607 : H12AffineEnvironment.transform 18 4369 env18606 = env18607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4369 env18606 == env18607) = true)

def env18608 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,32768,65536,1345,262144,1105,32769,1345,4194304,65,98564,8328,65,4456788,1344,1297,1073741824,1285,4294967296,257,4299260334,1345,512]

theorem envBound18608 : H12AffineFastState.Bounded env18608 := by
  intro p hp
  have h : env18608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18607_18608 : H12AffineEnvironment.transform 11 1344 env18607 = env18608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env18607 == env18608) = true)

theorem identity18608 : scanCanonicalize (H12AffineFastState.compose env18608 (packedSelected [8,10,13,15] rootPS)) = affineNative (2^(21+1) ^^^ 370689) := by decide +kernel

theorem selectedBound18608 : packedSelected [8,10,13,15] rootPS < 2^1333 := by decide +kernel

def env18609 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,32768,65536,1345,262144,1105,32769,1345,370689,65,98564,8328,65,108885,1344,1297,1073741824,1285,4294967296,257,4295240111,1345,512]

theorem envBound18609 : H12AffineFastState.Bounded env18609 := by
  intro p hp
  have h : env18609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18608_18609 : H12AffineEnvironment.transform 21 370689 env18608 = env18609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 370689 env18608 == env18609) = true)

theorem identity18609 : scanCanonicalize (H12AffineFastState.compose env18609 (packedSelected [3,8,10,13,17] rootPS)) = affineNative (2^(31+1) ^^^ 35496) := by decide +kernel

theorem selectedBound18609 : packedSelected [3,8,10,13,17] rootPS < 2^1333 := by decide +kernel

def env18610 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,32768,65536,1345,262144,1105,32769,1345,370689,65,98564,8328,65,108885,1344,1297,1073741824,1285,35496,257,303879,1345,512]

theorem envBound18610 : H12AffineFastState.Bounded env18610 := by
  intro p hp
  have h : env18610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18609_18610 : H12AffineEnvironment.transform 31 35496 env18609 = env18610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 35496 env18609 == env18610) = true)

theorem identity18610 : scanCanonicalize (H12AffineFastState.compose env18610 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound18610 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env18611 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1296,32768,65536,1297,262144,1025,32769,1297,370689,17,98564,8328,17,108805,1296,1297,1073741824,1285,35496,257,303879,1297,512]

theorem envBound18611 : H12AffineFastState.Bounded env18611 := by
  intro p hp
  have h : env18611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18610_18611 : H12AffineEnvironment.transform 5 16 env18610 = env18611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env18610 == env18611) = true)

theorem identity18611 : scanCanonicalize (H12AffineFastState.compose env18611 (packedSelected [1,3,5] rootPS)) = affineNative (2^(29+1) ^^^ 10534) := by decide +kernel

theorem selectedBound18611 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env18612 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1296,32768,65536,1297,262144,1025,32769,1297,370689,17,98564,8328,17,108805,1296,1297,10534,1285,35496,257,303879,1297,512]

theorem envBound18612 : H12AffineFastState.Bounded env18612 := by
  intro p hp
  have h : env18612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18611_18612 : H12AffineEnvironment.transform 29 10534 env18611 = env18612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 10534 env18611 == env18612) = true)

theorem identity18612 : scanCanonicalize (H12AffineFastState.compose env18612 (packedSelected [1,3,8] rootPS)) = affineNative (2^(17+1) ^^^ 107311) := by decide +kernel

theorem selectedBound18612 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env18613 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1296,32768,65536,1297,107311,1025,32769,1297,2862,17,98564,8328,17,108805,1296,1297,10534,1285,35496,257,65576,1297,512]

theorem envBound18613 : H12AffineFastState.Bounded env18613 := by
  intro p hp
  have h : env18613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18612_18613 : H12AffineEnvironment.transform 17 107311 env18612 = env18613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 107311 env18612 == env18613) = true)

theorem identity18613 : scanCanonicalize (H12AffineFastState.compose env18613 (packedSelected [1,10] rootPS)) = affineNative (2^(14+1) ^^^ 270) := by decide +kernel

theorem selectedBound18613 : packedSelected [1,10] rootPS < 2^1333 := by decide +kernel

def env18614 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1296,270,65536,1297,74273,1025,271,1297,2862,17,65546,8328,17,75787,1296,1297,10534,1285,2982,257,65576,1297,512]

theorem envBound18614 : H12AffineFastState.Bounded env18614 := by
  intro p hp
  have h : env18614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18613_18614 : H12AffineEnvironment.transform 14 270 env18613 = env18614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 270 env18613 == env18614) = true)

theorem identity18614 : scanCanonicalize (H12AffineFastState.compose env18614 (packedSelected [1,12,13] rootPS)) = affineNative (2^(12+1) ^^^ 807) := by decide +kernel

theorem selectedBound18614 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env18615 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,807,1296,270,65536,1297,65798,1025,271,1297,2862,17,65546,943,17,68396,1296,1297,2561,1285,2982,257,65576,1297,512]

theorem envBound18615 : H12AffineFastState.Bounded env18615 := by
  intro p hp
  have h : env18615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18614_18615 : H12AffineEnvironment.transform 12 807 env18614 = env18615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 807 env18614 == env18615) = true)

def env18616 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,32768,65536,1344,262144,1104,32769,1344,4194304,65,98564,8328,64,4456788,1345,1297,1073741824,1285,4294967296,257,4299260334,1344,512]

theorem envBound18616 : H12AffineFastState.Bounded env18616 := by
  intro p hp
  have h : env18616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18607_18616 : H12AffineEnvironment.transform 11 1345 env18607 = env18616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env18607 == env18616) = true)

theorem identity18616 : scanCanonicalize (H12AffineFastState.compose env18616 (packedSelected [8,10,13,15] rootPS)) = affineNative (2^(17+1) ^^^ 107018) := by decide +kernel

theorem selectedBound18616 : packedSelected [8,10,13,15] rootPS < 2^1333 := by decide +kernel

def env18617 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,32768,65536,1344,107018,1104,32769,1344,4194304,65,98564,8328,64,4301662,1345,1297,1073741824,1285,4294967296,257,4299260334,1344,512]

theorem envBound18617 : H12AffineFastState.Bounded env18617 := by
  intro p hp
  have h : env18617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18616_18617 : H12AffineEnvironment.transform 17 107018 env18616 = env18617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 107018 env18616 == env18617) = true)

theorem identity18617 : scanCanonicalize (H12AffineFastState.compose env18617 (packedSelected [3,8,10,13,17] rootPS)) = affineNative (2^(29+1) ^^^ 4294875) := by decide +kernel

theorem selectedBound18617 : packedSelected [3,8,10,13,17] rootPS < 2^1333 := by decide +kernel

def env18618 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,32768,65536,1344,107018,1104,32769,1344,4194304,65,98564,8328,64,4301662,1345,1297,4294875,1285,4294967296,257,4299260334,1344,512]

theorem envBound18618 : H12AffineFastState.Bounded env18618 := by
  intro p hp
  have h : env18618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18617_18618 : H12AffineEnvironment.transform 29 4294875 env18617 = env18618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4294875 env18617 == env18618) = true)

theorem identity18618 : scanCanonicalize (H12AffineFastState.compose env18618 (packedSelected [1,3,5,10,12,21] rootPS)) = affineNative (2^(15+1) ^^^ 2674) := by decide +kernel

theorem selectedBound18618 : packedSelected [1,3,5,10,12,21] rootPS < 2^1333 := by decide +kernel

def env18619 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,32768,2674,1344,43128,1104,32769,1344,4194304,65,35702,8328,64,4237612,1345,1297,4227753,1285,4294967296,257,4299197404,1344,512]

theorem envBound18619 : H12AffineFastState.Bounded env18619 := by
  intro p hp
  have h : env18619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18618_18619 : H12AffineEnvironment.transform 15 2674 env18618 = env18619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2674 env18618 == env18619) = true)

theorem identity18619 : scanCanonicalize (H12AffineFastState.compose env18619 (packedSelected [3,5,24] rootPS)) = affineNative (2^(14+1) ^^^ 3069) := by decide +kernel

theorem selectedBound18619 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env18620 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,3069,2674,1344,9093,1104,3068,1344,4194304,65,139,8328,64,4203217,1345,1297,4196692,1285,4294967296,257,4299161633,1344,512]

theorem envBound18620 : H12AffineFastState.Bounded env18620 := by
  intro p hp
  have h : env18620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18619_18620 : H12AffineEnvironment.transform 14 3069 env18619 = env18620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 3069 env18619 == env18620) = true)

theorem identity18620 : scanCanonicalize (H12AffineFastState.compose env18620 (packedSelected [3,10] rootPS)) = affineNative (2^(12+1) ^^^ 2948) := by decide +kernel

theorem selectedBound18620 : packedSelected [3,10] rootPS < 2^1333 := by decide +kernel

def env18621 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,2948,1345,3069,2674,1344,2049,1104,3068,1344,4194304,65,139,2828,64,4196693,1345,1297,4196692,1285,4294967296,257,4299161633,1344,512]

theorem envBound18621 : H12AffineFastState.Bounded env18621 := by
  intro p hp
  have h : env18621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18620_18621 : H12AffineEnvironment.transform 12 2948 env18620 = env18621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2948 env18620 == env18621) = true)

theorem identity18621 : scanCanonicalize (H12AffineFastState.compose env18621 (packedSelected [0,7] rootPS)) = affineNative (2^(21+1) ^^^ 341) := by decide +kernel

theorem selectedBound18621 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env18622 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,2948,1345,3069,2674,1344,2049,1104,3068,1344,341,65,139,2828,64,2048,1345,1297,2049,1285,4294967296,257,4294967668,1344,512]

theorem envBound18622 : H12AffineFastState.Bounded env18622 := by
  intro p hp
  have h : env18622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18621_18622 : H12AffineEnvironment.transform 21 341 env18621 = env18622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 341 env18621 == env18622) = true)

theorem identity18622 : scanCanonicalize (H12AffineFastState.compose env18622 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound18622 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env18623 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,1345,2316,1345,2421,2298,1344,2049,1104,2420,1344,341,65,139,2436,64,2048,1345,1297,2049,1285,4294967296,257,4294967668,1344,136]

theorem envBound18623 : H12AffineFastState.Bounded env18623 := by
  intro p hp
  have h : env18623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18622_18623 : H12AffineEnvironment.transform 8 136 env18622 = env18623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env18622 == env18623) = true)

theorem identity18623 : scanCanonicalize (H12AffineFastState.compose env18623 (packedSelected [1,3,5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound18623 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env18624 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,1296,2316,1296,2340,2219,1297,2049,1025,2341,1297,260,16,139,2436,17,2048,1296,1297,2049,1285,4294967296,257,4294967589,1297,136]

theorem envBound18624 : H12AffineFastState.Bounded env18624 := by
  intro p hp
  have h : env18624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18623_18624 : H12AffineEnvironment.transform 5 17 env18623 = env18624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env18623 == env18624) = true)

theorem identity18624 : scanCanonicalize (H12AffineFastState.compose env18624 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound18624 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env18625 : List Nat := [2,4,8,16,32,17,128,173,136,1024,2048,1213,2209,1213,2185,2219,1212,2049,1025,2184,1212,169,16,139,2089,17,2048,1213,1212,2049,1192,4294967296,172,4294967432,1212,136]

theorem envBound18625 : H12AffineFastState.Bounded env18625 := by
  intro p hp
  have h : env18625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18624_18625 : H12AffineEnvironment.transform 7 173 env18624 = env18625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env18624 == env18625) = true)

theorem identity18625 : scanCanonicalize (H12AffineFastState.compose env18625 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 137) := by decide +kernel

theorem selectedBound18625 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env18626 : List Nat := [2,4,8,16,32,17,128,173,136,1024,2048,1213,2209,1213,2185,2219,1212,2049,1025,2184,1212,169,16,139,2089,17,2048,1213,1212,2049,1192,137,172,1,1212,136]

theorem envBound18626 : H12AffineFastState.Bounded env18626 := by
  intro p hp
  have h : env18626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18625_18626 : H12AffineEnvironment.transform 31 137 env18625 = env18626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 137 env18625 == env18626) = true)

def env18627 : List Nat := [2,4,8,16,0,17,128,141,136,1024,2048,1181,2177,1181,2185,2187,1180,2049,1025,2184,1180,137,16,139,2057,17,2048,1181,1180,2049,1160,137,140,1,1180,136]

theorem envBound18627 : H12AffineFastState.Bounded env18627 := by
  intro p hp
  have h : env18627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18626_18627 : H12AffineEnvironment.transform 4 0 env18626 = env18627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env18626 == env18627) = true)

theorem identity18627 : scanCanonicalize (H12AffineFastState.compose env18627 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound18627 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env18628 : List Nat := [2,4,8,16,0,17,8,5,0,1024,2048,1045,2057,1045,2049,2051,1044,2049,1025,2048,1044,1,16,3,2057,17,2048,1045,1044,2049,1024,1,4,1,1044,0]

theorem envBound18628 : H12AffineFastState.Bounded env18628 := by
  intro p hp
  have h : env18628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18627_18628 : H12AffineEnvironment.transform 6 8 env18627 = env18628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env18627 == env18628) = true)

def leafEnv18628 : List Nat := [2,4,8,16,0,17,8,5,0,1024,2048,1045,2057,1045,2049,2051,1044,2049,1025,2048,1044,1,16,3,1025,2057,1,17,2048,1045,1044,2049,1024,1,4,1,5,2050,1044,0,0,1045,1]

def active18628 : List Nat := [0,1,2,3,9,10]

def tree18628 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood18628 : H12WitnessSearch.Good tree18628 := H12GlobalWitnessIndex.good

theorem leafIdentity18628 : H12AffineFastState.composeSystem env18628 rootObs = leafEnv18628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env18628 rootObs == leafEnv18628) = true)

theorem terminalChecked18628 : H12PackedTerminal.terminalCheckFast leafEnv18628 active18628 tree18628 = true := by decide +kernel

def env18629 : List Nat := [2,4,8,16,1,17,128,140,136,1024,2048,1180,2176,1180,2185,2186,1181,2049,1025,2184,1181,136,16,139,2056,17,2048,1180,1181,2049,1161,137,141,1,1181,136]

end H12CloudChart2