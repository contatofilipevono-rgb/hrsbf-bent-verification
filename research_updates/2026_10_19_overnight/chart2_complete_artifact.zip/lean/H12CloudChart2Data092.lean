import H12CloudChart2Data091

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env22564 : List Nat := [2,4,8,16,0,17,128,4,0,20,2048,0,2057,0,2049,2187,1,2049,21,2048,1,136,16,139,2177,17,2185,1,0,2184,20,137,5,0,0,0]

theorem envBound22564 : H12AffineFastState.Bounded env22564 := by
  intro p hp
  have h : env22564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22563_22564 : H12AffineEnvironment.transform 12 2057 env22563 = env22564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2057 env22563 == env22564) = true)

theorem identity22564 : scanCanonicalize (H12AffineFastState.compose env22564 (packedSelected [7] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound22564 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env22565 : List Nat := [2,4,8,16,0,17,8,4,0,20,2048,0,2057,0,2049,2051,1,2049,21,2048,1,0,16,3,2057,17,2049,1,0,2048,20,1,5,0,0,0]

theorem envBound22565 : H12AffineFastState.Bounded env22565 := by
  intro p hp
  have h : env22565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22564_22565 : H12AffineEnvironment.transform 6 8 env22564 = env22565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22564 == env22565) = true)

def leafEnv22565 : List Nat := [2,4,8,16,0,17,8,4,0,20,2048,0,2057,0,2049,2051,1,2049,21,2048,1,0,16,3,21,2057,1,17,2049,1,0,2048,20,1,5,0,5,2050,0,0,0,1,1]

def active22565 : List Nat := [0,1,2,3,10]

def tree22565 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22565 : H12WitnessSearch.Good tree22565 := H12GlobalWitnessIndex.good

theorem leafIdentity22565 : H12AffineFastState.composeSystem env22565 rootObs = leafEnv22565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22565 rootObs == leafEnv22565) = true)

theorem terminalChecked22565 : H12PackedTerminal.terminalCheckFast leafEnv22565 active22565 tree22565 = true := by decide +kernel

def env22566 : List Nat := [2,4,8,16,1,17,128,4,512,20,2048,0,8192,0,32768,32906,1,43016,21,32769,1,41088,16,139,8328,17,2184,1,0,43136,20,136,5,40968,0,512]

theorem envBound22566 : H12AffineFastState.Bounded env22566 := by
  intro p hp
  have h : env22566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22558_22566 : H12AffineEnvironment.transform 4 1 env22558 = env22566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22558 == env22566) = true)

theorem identity22566 : scanCanonicalize (H12AffineFastState.compose env22566 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound22566 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22567 : List Nat := [2,4,8,16,1,17,128,4,136,20,2048,0,8192,0,32768,32906,1,43016,21,32769,1,41088,16,139,8328,17,2184,1,0,43136,20,136,5,40968,0,136]

theorem envBound22567 : H12AffineFastState.Bounded env22567 := by
  intro p hp
  have h : env22567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22566_22567 : H12AffineEnvironment.transform 8 136 env22566 = env22567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env22566 == env22567) = true)

def env22568 : List Nat := [2,4,8,16,1,17,128,4,136,20,2048,0,8192,0,8320,8202,1,2184,21,8321,1,0,16,139,8328,17,2184,1,0,2048,20,136,5,136,0,136]

theorem envBound22568 : H12AffineFastState.Bounded env22568 := by
  intro p hp
  have h : env22568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22567_22568 : H12AffineEnvironment.transform 14 8320 env22567 = env22568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8320 env22567 == env22568) = true)

theorem identity22568 : scanCanonicalize (H12AffineFastState.compose env22568 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 2176) := by decide +kernel

theorem selectedBound22568 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22569 : List Nat := [2,4,8,16,1,17,128,4,136,20,2048,0,2176,0,2048,2186,1,2184,21,2049,1,0,16,139,2056,17,2184,1,0,2048,20,136,5,136,0,136]

theorem envBound22569 : H12AffineFastState.Bounded env22569 := by
  intro p hp
  have h : env22569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22568_22569 : H12AffineEnvironment.transform 12 2176 env22568 = env22569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2176 env22568 == env22569) = true)

def leafEnv22569 : List Nat := [2,4,8,16,1,17,128,4,136,20,2048,0,2176,0,2048,2186,1,2184,21,2049,1,0,16,139,21,2056,1,17,2184,1,0,2048,20,136,5,136,5,2051,0,136,0,1,1]

def active22569 : List Nat := [0,1,2,3,6,10]

def tree22569 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22569 : H12WitnessSearch.Good tree22569 := H12GlobalWitnessIndex.good

theorem leafIdentity22569 : H12AffineFastState.composeSystem env22569 rootObs = leafEnv22569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22569 rootObs == leafEnv22569) = true)

theorem terminalChecked22569 : H12PackedTerminal.terminalCheckFast leafEnv22569 active22569 tree22569 = true := by decide +kernel

def env22570 : List Nat := [2,4,8,16,1,17,128,4,136,20,2048,0,8192,0,8321,8203,1,2185,21,8320,1,1,16,139,8328,17,2184,1,0,2049,20,136,5,137,0,136]

theorem envBound22570 : H12AffineFastState.Bounded env22570 := by
  intro p hp
  have h : env22570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22567_22570 : H12AffineEnvironment.transform 14 8321 env22567 = env22570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8321 env22567 == env22570) = true)

theorem identity22570 : scanCanonicalize (H12AffineFastState.compose env22570 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound22570 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22571 : List Nat := [2,4,8,16,1,17,8,4,0,20,2048,0,8192,0,8201,8203,1,2049,21,8200,1,1,16,3,8192,17,2048,1,0,2049,20,0,5,1,0,0]

theorem envBound22571 : H12AffineFastState.Bounded env22571 := by
  intro p hp
  have h : env22571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22570_22571 : H12AffineEnvironment.transform 6 8 env22570 = env22571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22570 == env22571) = true)

theorem identity22571 : scanCanonicalize (H12AffineFastState.compose env22571 (packedSelected [4] rootPS)) = affineNative (2^(12+1) ^^^ 2057) := by decide +kernel

theorem selectedBound22571 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env22572 : List Nat := [2,4,8,16,1,17,8,4,0,20,2048,0,2057,0,2048,2050,1,2049,21,2049,1,1,16,3,2057,17,2048,1,0,2049,20,0,5,1,0,0]

theorem envBound22572 : H12AffineFastState.Bounded env22572 := by
  intro p hp
  have h : env22572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22571_22572 : H12AffineEnvironment.transform 12 2057 env22571 = env22572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2057 env22571 == env22572) = true)

def env22573 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,8192,0,32768,33166,1,43049,273,32769,1,41089,16,139,8328,17,2476,1,0,43397,20,169,257,40969,0,512]

theorem envBound22573 : H12AffineFastState.Bounded env22573 := by
  intro p hp
  have h : env22573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22556_22573 : H12AffineEnvironment.transform 21 41089 env22556 = env22573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env22556 == env22573) = true)

theorem identity22573 : scanCanonicalize (H12AffineFastState.compose env22573 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 8201) := by decide +kernel

theorem selectedBound22573 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env22574 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,8192,0,8201,8583,1,2080,273,8200,1,136,16,139,8328,17,2476,1,0,2444,20,169,257,0,0,512]

theorem envBound22574 : H12AffineFastState.Bounded env22574 := by
  intro p hp
  have h : env22574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22573_22574 : H12AffineEnvironment.transform 14 8201 env22573 = env22574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8201 env22573 == env22574) = true)

def env22575 : List Nat := [2,4,8,16,32,17,8,256,512,272,2048,0,8192,0,8201,8463,1,2080,273,8200,1,0,16,3,8192,17,2340,1,0,2308,20,33,257,0,0,512]

theorem envBound22575 : H12AffineFastState.Bounded env22575 := by
  intro p hp
  have h : env22575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22574_22575 : H12AffineEnvironment.transform 6 8 env22574 = env22575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22574 == env22575) = true)

theorem identity22575 : scanCanonicalize (H12AffineFastState.compose env22575 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound22575 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22576 : List Nat := [2,4,8,16,32,17,8,256,0,272,2048,0,8192,0,8201,8463,1,2080,273,8200,1,0,16,3,8192,17,2340,1,0,2308,20,33,257,0,0,0]

theorem envBound22576 : H12AffineFastState.Bounded env22576 := by
  intro p hp
  have h : env22576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22575_22576 : H12AffineEnvironment.transform 8 0 env22575 = env22576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env22575 == env22576) = true)

def env22577 : List Nat := [2,4,8,16,32,17,8,256,0,272,2048,0,2056,0,2049,2311,1,2080,273,2048,1,0,16,3,2056,17,2340,1,0,2308,20,33,257,0,0,0]

theorem envBound22577 : H12AffineFastState.Bounded env22577 := by
  intro p hp
  have h : env22577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22576_22577 : H12AffineEnvironment.transform 12 2056 env22576 = env22577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2056 env22576 == env22577) = true)

theorem identity22577 : scanCanonicalize (H12AffineFastState.compose env22577 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound22577 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22578 : List Nat := [2,4,8,16,32,17,8,36,0,52,2048,0,2056,0,2049,2083,1,2080,53,2048,1,0,16,3,2056,17,2048,1,0,2080,20,33,37,0,0,0]

theorem envBound22578 : H12AffineFastState.Bounded env22578 := by
  intro p hp
  have h : env22578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22577_22578 : H12AffineEnvironment.transform 7 36 env22577 = env22578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env22577 == env22578) = true)

theorem identity22578 : scanCanonicalize (H12AffineFastState.compose env22578 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound22578 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env22579 : List Nat := [2,4,8,16,0,17,8,4,0,20,2048,0,2056,0,2049,2051,1,2048,21,2048,1,0,16,3,2056,17,2048,1,0,2048,20,1,5,0,0,0]

theorem envBound22579 : H12AffineFastState.Bounded env22579 := by
  intro p hp
  have h : env22579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22578_22579 : H12AffineEnvironment.transform 4 0 env22578 = env22579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22578 == env22579) = true)

def leafEnv22579 : List Nat := [2,4,8,16,0,17,8,4,0,20,2048,0,2056,0,2049,2051,1,2048,21,2048,1,0,16,3,21,2056,1,17,2048,1,0,2048,20,1,5,0,5,2050,0,0,0,1,1]

def active22579 : List Nat := [0,1,2,3,10]

def tree22579 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22579 : H12WitnessSearch.Good tree22579 := H12GlobalWitnessIndex.good

theorem leafIdentity22579 : H12AffineFastState.composeSystem env22579 rootObs = leafEnv22579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22579 rootObs == leafEnv22579) = true)

theorem terminalChecked22579 : H12PackedTerminal.terminalCheckFast leafEnv22579 active22579 tree22579 = true := by decide +kernel

def env22580 : List Nat := [2,4,8,16,32,17,8,256,0,272,2048,0,2057,0,2048,2310,1,2080,273,2049,1,0,16,3,2057,17,2340,1,0,2308,20,33,257,0,0,0]

theorem envBound22580 : H12AffineFastState.Bounded env22580 := by
  intro p hp
  have h : env22580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22576_22580 : H12AffineEnvironment.transform 12 2057 env22576 = env22580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2057 env22576 == env22580) = true)

theorem identity22580 : scanCanonicalize (H12AffineFastState.compose env22580 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound22580 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22581 : List Nat := [2,4,8,16,1,17,8,256,0,272,2048,0,2057,0,2048,2310,1,2049,273,2049,1,0,16,3,2057,17,2309,1,0,2308,20,0,257,0,0,0]

theorem envBound22581 : H12AffineFastState.Bounded env22581 := by
  intro p hp
  have h : env22581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22580_22581 : H12AffineEnvironment.transform 4 1 env22580 = env22581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22580 == env22581) = true)

theorem identity22581 : scanCanonicalize (H12AffineFastState.compose env22581 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound22581 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env22582 : List Nat := [2,4,8,16,1,17,8,4,0,20,2048,0,2057,0,2048,2050,1,2049,21,2049,1,0,16,3,2057,17,2049,1,0,2048,20,0,5,0,0,0]

theorem envBound22582 : H12AffineFastState.Bounded env22582 := by
  intro p hp
  have h : env22582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22581_22582 : H12AffineEnvironment.transform 7 4 env22581 = env22582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env22581 == env22582) = true)

def leafEnv22582 : List Nat := [2,4,8,16,1,17,8,4,0,20,2048,0,2057,0,2048,2050,1,2049,21,2049,1,0,16,3,21,2057,1,17,2049,1,0,2048,20,0,5,0,5,2051,0,0,0,1,1]

def active22582 : List Nat := [0,1,2,3,10]

def tree22582 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22582 : H12WitnessSearch.Good tree22582 := H12GlobalWitnessIndex.good

theorem leafIdentity22582 : H12AffineFastState.composeSystem env22582 rootObs = leafEnv22582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22582 rootObs == leafEnv22582) = true)

theorem terminalChecked22582 : H12PackedTerminal.terminalCheckFast leafEnv22582 active22582 tree22582 = true := by decide +kernel

def env22583 : List Nat := [2,4,8,16,32,17,9,256,512,272,2048,0,8192,0,8201,8462,1,2080,273,8200,1,1,16,2,8193,17,2341,1,0,2309,20,32,257,0,0,512]

theorem envBound22583 : H12AffineFastState.Bounded env22583 := by
  intro p hp
  have h : env22583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22574_22583 : H12AffineEnvironment.transform 6 9 env22574 = env22583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22574 == env22583) = true)

theorem identity22583 : scanCanonicalize (H12AffineFastState.compose env22583 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound22583 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22584 : List Nat := [2,4,8,16,32,17,9,256,293,272,2048,0,8192,0,8201,8462,1,2080,273,8200,1,1,16,2,8193,17,2341,1,0,2309,20,32,257,0,0,293]

theorem envBound22584 : H12AffineFastState.Bounded env22584 := by
  intro p hp
  have h : env22584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22583_22584 : H12AffineEnvironment.transform 8 293 env22583 = env22584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env22583 == env22584) = true)

def env22585 : List Nat := [2,4,8,16,32,17,9,256,293,272,2048,0,2088,0,2081,2342,1,2080,273,2080,1,1,16,2,2089,17,2341,1,0,2309,20,32,257,0,0,293]

theorem envBound22585 : H12AffineFastState.Bounded env22585 := by
  intro p hp
  have h : env22585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22584_22585 : H12AffineEnvironment.transform 12 2088 env22584 = env22585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2088 env22584 == env22585) = true)

theorem identity22585 : scanCanonicalize (H12AffineFastState.compose env22585 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound22585 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22586 : List Nat := [2,4,8,16,32,17,9,37,0,53,2048,0,2088,0,2081,2051,1,2080,52,2080,1,1,16,2,2089,17,2048,1,0,2080,20,32,36,0,0,0]

theorem envBound22586 : H12AffineFastState.Bounded env22586 := by
  intro p hp
  have h : env22586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22585_22586 : H12AffineEnvironment.transform 7 37 env22585 = env22586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env22585 == env22586) = true)

theorem identity22586 : scanCanonicalize (H12AffineFastState.compose env22586 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound22586 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env22587 : List Nat := [2,4,8,16,1,17,9,4,0,20,2048,0,2057,0,2048,2051,1,2049,21,2049,1,1,16,2,2056,17,2048,1,0,2049,20,1,5,0,0,0]

theorem envBound22587 : H12AffineFastState.Bounded env22587 := by
  intro p hp
  have h : env22587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22586_22587 : H12AffineEnvironment.transform 4 1 env22586 = env22587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22586 == env22587) = true)

def env22588 : List Nat := [2,4,8,16,32,17,9,256,293,272,2048,0,2089,0,2080,2343,1,2080,273,2081,1,1,16,2,2088,17,2341,1,0,2309,20,32,257,0,0,293]

theorem envBound22588 : H12AffineFastState.Bounded env22588 := by
  intro p hp
  have h : env22588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22584_22588 : H12AffineEnvironment.transform 12 2089 env22584 = env22588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2089 env22584 == env22588) = true)

theorem identity22588 : scanCanonicalize (H12AffineFastState.compose env22588 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound22588 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22589 : List Nat := [2,4,8,16,1,17,9,256,260,272,2048,0,2056,0,2049,2310,1,2049,273,2048,1,1,16,2,2057,17,2308,1,0,2309,20,1,257,0,0,260]

theorem envBound22589 : H12AffineFastState.Bounded env22589 := by
  intro p hp
  have h : env22589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22588_22589 : H12AffineEnvironment.transform 4 1 env22588 = env22589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22588 == env22589) = true)

theorem identity22589 : scanCanonicalize (H12AffineFastState.compose env22589 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound22589 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env22590 : List Nat := [2,4,8,16,1,17,9,5,1,21,2048,0,2056,0,2049,2051,1,2049,20,2048,1,1,16,2,2057,17,2049,1,0,2048,20,1,4,0,0,1]

theorem envBound22590 : H12AffineFastState.Bounded env22590 := by
  intro p hp
  have h : env22590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22589_22590 : H12AffineEnvironment.transform 7 5 env22589 = env22590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env22589 == env22590) = true)

def leafEnv22590 : List Nat := [2,4,8,16,1,17,9,5,1,21,2048,0,2056,0,2049,2051,1,2049,20,2048,1,1,16,2,21,2057,1,17,2049,1,0,2048,20,1,4,0,5,2051,0,1,0,1,1]

def active22590 : List Nat := [0,1,2,3,10]

def tree22590 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22590 : H12WitnessSearch.Good tree22590 := H12GlobalWitnessIndex.good

theorem leafIdentity22590 : H12AffineFastState.composeSystem env22590 rootObs = leafEnv22590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22590 rootObs == leafEnv22590) = true)

theorem terminalChecked22590 : H12PackedTerminal.terminalCheckFast leafEnv22590 active22590 tree22590 = true := by decide +kernel

def env22591 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,8192,1,32768,65536,0,262144,272,32769,0,4194304,16,98565,8328,17,4456708,0,1,4294794,21,98599,257,4194440,1,512]

theorem envBound22591 : H12AffineFastState.Bounded env22591 := by
  intro p hp
  have h : env22591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22553_22591 : H12AffineEnvironment.transform 9 273 env22553 = env22591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env22553 == env22591) = true)

theorem identity22591 : scanCanonicalize (H12AffineFastState.compose env22591 (packedSelected [1] rootPS)) = affineNative (2^(17+1) ^^^ 76199) := by decide +kernel

theorem selectedBound22591 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22592 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,8192,1,32768,65536,0,76199,272,32769,0,4194304,16,98565,8328,17,4270243,0,1,4294794,21,98599,257,4194440,1,512]

theorem envBound22592 : H12AffineFastState.Bounded env22592 := by
  intro p hp
  have h : env22592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22591_22592 : H12AffineEnvironment.transform 17 76199 env22591 = env22592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76199 env22591 == env22592) = true)

theorem identity22592 : scanCanonicalize (H12AffineFastState.compose env22592 (packedSelected [3] rootPS)) = affineNative (2^(15+1) ^^^ 33166) := by decide +kernel

theorem selectedBound22592 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env22593 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,8192,1,32768,33166,0,43049,272,32769,0,4194304,16,139,8328,17,4237613,0,1,4196612,21,169,257,4194440,1,512]

theorem envBound22593 : H12AffineFastState.Bounded env22593 := by
  intro p hp
  have h : env22593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22592_22593 : H12AffineEnvironment.transform 15 33166 env22592 = env22593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33166 env22592 == env22593) = true)

def env22594 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,8192,1,32768,33166,0,43049,272,32769,0,41088,16,139,8328,17,2477,0,1,43396,21,169,257,40968,1,512]

theorem envBound22594 : H12AffineFastState.Bounded env22594 := by
  intro p hp
  have h : env22594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22593_22594 : H12AffineEnvironment.transform 21 41088 env22593 = env22594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env22593 == env22594) = true)

theorem identity22594 : scanCanonicalize (H12AffineFastState.compose env22594 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound22594 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env22595 : List Nat := [2,4,8,16,32,17,128,4,512,21,2048,1,8192,1,32768,32906,0,43049,20,32769,0,41088,16,139,8328,17,2217,0,1,43136,21,169,5,40968,1,512]

theorem envBound22595 : H12AffineFastState.Bounded env22595 := by
  intro p hp
  have h : env22595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22594_22595 : H12AffineEnvironment.transform 7 4 env22594 = env22595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env22594 == env22595) = true)

def env22596 : List Nat := [2,4,8,16,0,17,128,4,512,21,2048,1,8192,1,32768,32906,0,43017,20,32769,0,41088,16,139,8328,17,2185,0,1,43136,21,137,5,40968,1,512]

theorem envBound22596 : H12AffineFastState.Bounded env22596 := by
  intro p hp
  have h : env22596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22595_22596 : H12AffineEnvironment.transform 4 0 env22595 = env22596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22595 == env22596) = true)

theorem identity22596 : scanCanonicalize (H12AffineFastState.compose env22596 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound22596 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22597 : List Nat := [2,4,8,16,0,17,128,4,0,21,2048,1,8192,1,32768,32906,0,43017,20,32769,0,41088,16,139,8328,17,2185,0,1,43136,21,137,5,40968,1,0]

theorem envBound22597 : H12AffineFastState.Bounded env22597 := by
  intro p hp
  have h : env22597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22596_22597 : H12AffineEnvironment.transform 8 0 env22596 = env22597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env22596 == env22597) = true)

def env22598 : List Nat := [2,4,8,16,0,17,128,4,0,21,2048,1,8192,1,2048,2186,0,8201,20,2049,0,10368,16,139,8328,17,2185,0,1,8320,21,137,5,10248,1,0]

theorem envBound22598 : H12AffineFastState.Bounded env22598 := by
  intro p hp
  have h : env22598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22597_22598 : H12AffineEnvironment.transform 14 2048 env22597 = env22598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2048 env22597 == env22598) = true)

theorem identity22598 : scanCanonicalize (H12AffineFastState.compose env22598 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound22598 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22599 : List Nat := [2,4,8,16,0,17,9,4,0,21,2048,1,8192,1,2048,2051,0,8201,20,2049,0,10249,16,2,8193,17,2048,0,1,8201,21,0,5,10248,1,0]

theorem envBound22599 : H12AffineFastState.Bounded env22599 := by
  intro p hp
  have h : env22599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22598_22599 : H12AffineEnvironment.transform 6 9 env22598 = env22599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22598 == env22599) = true)

def env22600 : List Nat := [2,4,8,16,0,17,128,4,0,21,2048,1,8192,1,2049,2187,0,8200,20,2048,0,10369,16,139,8328,17,2185,0,1,8321,21,137,5,10249,1,0]

theorem envBound22600 : H12AffineFastState.Bounded env22600 := by
  intro p hp
  have h : env22600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22597_22600 : H12AffineEnvironment.transform 14 2049 env22597 = env22600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2049 env22597 == env22600) = true)

theorem identity22600 : scanCanonicalize (H12AffineFastState.compose env22600 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 2057) := by decide +kernel

theorem selectedBound22600 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22601 : List Nat := [2,4,8,16,0,17,128,4,0,21,2048,1,2057,1,2049,2187,0,2049,20,2048,0,136,16,139,2177,17,2185,0,1,2184,21,137,5,0,1,0]

theorem envBound22601 : H12AffineFastState.Bounded env22601 := by
  intro p hp
  have h : env22601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22600_22601 : H12AffineEnvironment.transform 12 2057 env22600 = env22601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2057 env22600 == env22601) = true)

theorem identity22601 : scanCanonicalize (H12AffineFastState.compose env22601 (packedSelected [7] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound22601 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env22602 : List Nat := [2,4,8,16,0,17,8,4,0,21,2048,1,2057,1,2049,2051,0,2049,20,2048,0,0,16,3,2057,17,2049,0,1,2048,21,1,5,0,1,0]

theorem envBound22602 : H12AffineFastState.Bounded env22602 := by
  intro p hp
  have h : env22602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22601_22602 : H12AffineEnvironment.transform 6 8 env22601 = env22602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22601 == env22602) = true)

def leafEnv22602 : List Nat := [2,4,8,16,0,17,8,4,0,21,2048,1,2057,1,2049,2051,0,2049,20,2048,0,0,16,3,20,2057,1,17,2049,0,1,2048,21,1,5,0,5,2050,1,0,0,0,1]

def active22602 : List Nat := [0,1,2,3,10]

def tree22602 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22602 : H12WitnessSearch.Good tree22602 := H12GlobalWitnessIndex.good

theorem leafIdentity22602 : H12AffineFastState.composeSystem env22602 rootObs = leafEnv22602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22602 rootObs == leafEnv22602) = true)

theorem terminalChecked22602 : H12PackedTerminal.terminalCheckFast leafEnv22602 active22602 tree22602 = true := by decide +kernel

def env22603 : List Nat := [2,4,8,16,1,17,128,4,512,21,2048,1,8192,1,32768,32906,0,43016,20,32769,0,41088,16,139,8328,17,2184,0,1,43136,21,136,5,40968,1,512]

theorem envBound22603 : H12AffineFastState.Bounded env22603 := by
  intro p hp
  have h : env22603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22595_22603 : H12AffineEnvironment.transform 4 1 env22595 = env22603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22595 == env22603) = true)

theorem identity22603 : scanCanonicalize (H12AffineFastState.compose env22603 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound22603 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22604 : List Nat := [2,4,8,16,1,17,128,4,136,21,2048,1,8192,1,32768,32906,0,43016,20,32769,0,41088,16,139,8328,17,2184,0,1,43136,21,136,5,40968,1,136]

theorem envBound22604 : H12AffineFastState.Bounded env22604 := by
  intro p hp
  have h : env22604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22603_22604 : H12AffineEnvironment.transform 8 136 env22603 = env22604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env22603 == env22604) = true)

def env22605 : List Nat := [2,4,8,16,1,17,128,4,136,21,2048,1,8192,1,8320,8202,0,2184,20,8321,0,0,16,139,8328,17,2184,0,1,2048,21,136,5,136,1,136]

theorem envBound22605 : H12AffineFastState.Bounded env22605 := by
  intro p hp
  have h : env22605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22604_22605 : H12AffineEnvironment.transform 14 8320 env22604 = env22605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8320 env22604 == env22605) = true)

theorem identity22605 : scanCanonicalize (H12AffineFastState.compose env22605 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 2176) := by decide +kernel

theorem selectedBound22605 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22606 : List Nat := [2,4,8,16,1,17,128,4,136,21,2048,1,2176,1,2048,2186,0,2184,20,2049,0,0,16,139,2056,17,2184,0,1,2048,21,136,5,136,1,136]

theorem envBound22606 : H12AffineFastState.Bounded env22606 := by
  intro p hp
  have h : env22606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22605_22606 : H12AffineEnvironment.transform 12 2176 env22605 = env22606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2176 env22605 == env22606) = true)

def leafEnv22606 : List Nat := [2,4,8,16,1,17,128,4,136,21,2048,1,2176,1,2048,2186,0,2184,20,2049,0,0,16,139,20,2056,1,17,2184,0,1,2048,21,136,5,136,5,2051,1,136,0,0,1]

def active22606 : List Nat := [0,1,2,3,6,10]

def tree22606 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22606 : H12WitnessSearch.Good tree22606 := H12GlobalWitnessIndex.good

theorem leafIdentity22606 : H12AffineFastState.composeSystem env22606 rootObs = leafEnv22606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22606 rootObs == leafEnv22606) = true)

theorem terminalChecked22606 : H12PackedTerminal.terminalCheckFast leafEnv22606 active22606 tree22606 = true := by decide +kernel

def env22607 : List Nat := [2,4,8,16,1,17,128,4,136,21,2048,1,8192,1,8321,8203,0,2185,20,8320,0,1,16,139,8328,17,2184,0,1,2049,21,136,5,137,1,136]

theorem envBound22607 : H12AffineFastState.Bounded env22607 := by
  intro p hp
  have h : env22607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22604_22607 : H12AffineEnvironment.transform 14 8321 env22604 = env22607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8321 env22604 == env22607) = true)

theorem identity22607 : scanCanonicalize (H12AffineFastState.compose env22607 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound22607 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22608 : List Nat := [2,4,8,16,1,17,8,4,0,21,2048,1,8192,1,8201,8203,0,2049,20,8200,0,1,16,3,8192,17,2048,0,1,2049,21,0,5,1,1,0]

theorem envBound22608 : H12AffineFastState.Bounded env22608 := by
  intro p hp
  have h : env22608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22607_22608 : H12AffineEnvironment.transform 6 8 env22607 = env22608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22607 == env22608) = true)

theorem identity22608 : scanCanonicalize (H12AffineFastState.compose env22608 (packedSelected [4] rootPS)) = affineNative (2^(12+1) ^^^ 2057) := by decide +kernel

theorem selectedBound22608 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env22609 : List Nat := [2,4,8,16,1,17,8,4,0,21,2048,1,2057,1,2048,2050,0,2049,20,2049,0,1,16,3,2057,17,2048,0,1,2049,21,0,5,1,1,0]

theorem envBound22609 : H12AffineFastState.Bounded env22609 := by
  intro p hp
  have h : env22609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22608_22609 : H12AffineEnvironment.transform 12 2057 env22608 = env22609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2057 env22608 == env22609) = true)

def env22610 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,8192,1,32768,33166,0,43049,272,32769,0,41089,16,139,8328,17,2476,0,1,43397,21,169,257,40969,1,512]

theorem envBound22610 : H12AffineFastState.Bounded env22610 := by
  intro p hp
  have h : env22610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22593_22610 : H12AffineEnvironment.transform 21 41089 env22593 = env22610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env22593 == env22610) = true)

theorem identity22610 : scanCanonicalize (H12AffineFastState.compose env22610 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 8201) := by decide +kernel

theorem selectedBound22610 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env22611 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,8192,1,8201,8583,0,2080,272,8200,0,136,16,139,8328,17,2476,0,1,2444,21,169,257,0,1,512]

theorem envBound22611 : H12AffineFastState.Bounded env22611 := by
  intro p hp
  have h : env22611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22610_22611 : H12AffineEnvironment.transform 14 8201 env22610 = env22611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8201 env22610 == env22611) = true)

def env22612 : List Nat := [2,4,8,16,32,17,8,256,512,273,2048,1,8192,1,8201,8463,0,2080,272,8200,0,0,16,3,8192,17,2340,0,1,2308,21,33,257,0,1,512]

theorem envBound22612 : H12AffineFastState.Bounded env22612 := by
  intro p hp
  have h : env22612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22611_22612 : H12AffineEnvironment.transform 6 8 env22611 = env22612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22611 == env22612) = true)

theorem identity22612 : scanCanonicalize (H12AffineFastState.compose env22612 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound22612 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22613 : List Nat := [2,4,8,16,32,17,8,256,0,273,2048,1,8192,1,8201,8463,0,2080,272,8200,0,0,16,3,8192,17,2340,0,1,2308,21,33,257,0,1,0]

theorem envBound22613 : H12AffineFastState.Bounded env22613 := by
  intro p hp
  have h : env22613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22612_22613 : H12AffineEnvironment.transform 8 0 env22612 = env22613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env22612 == env22613) = true)

def env22614 : List Nat := [2,4,8,16,32,17,8,256,0,273,2048,1,2056,1,2049,2311,0,2080,272,2048,0,0,16,3,2056,17,2340,0,1,2308,21,33,257,0,1,0]

theorem envBound22614 : H12AffineFastState.Bounded env22614 := by
  intro p hp
  have h : env22614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22613_22614 : H12AffineEnvironment.transform 12 2056 env22613 = env22614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2056 env22613 == env22614) = true)

theorem identity22614 : scanCanonicalize (H12AffineFastState.compose env22614 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound22614 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22615 : List Nat := [2,4,8,16,32,17,8,36,0,53,2048,1,2056,1,2049,2083,0,2080,52,2048,0,0,16,3,2056,17,2048,0,1,2080,21,33,37,0,1,0]

theorem envBound22615 : H12AffineFastState.Bounded env22615 := by
  intro p hp
  have h : env22615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22614_22615 : H12AffineEnvironment.transform 7 36 env22614 = env22615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env22614 == env22615) = true)

theorem identity22615 : scanCanonicalize (H12AffineFastState.compose env22615 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound22615 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env22616 : List Nat := [2,4,8,16,0,17,8,4,0,21,2048,1,2056,1,2049,2051,0,2048,20,2048,0,0,16,3,2056,17,2048,0,1,2048,21,1,5,0,1,0]

theorem envBound22616 : H12AffineFastState.Bounded env22616 := by
  intro p hp
  have h : env22616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22615_22616 : H12AffineEnvironment.transform 4 0 env22615 = env22616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22615 == env22616) = true)

def leafEnv22616 : List Nat := [2,4,8,16,0,17,8,4,0,21,2048,1,2056,1,2049,2051,0,2048,20,2048,0,0,16,3,20,2056,1,17,2048,0,1,2048,21,1,5,0,5,2050,1,0,0,0,1]

def active22616 : List Nat := [0,1,2,3,10]

def tree22616 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22616 : H12WitnessSearch.Good tree22616 := H12GlobalWitnessIndex.good

theorem leafIdentity22616 : H12AffineFastState.composeSystem env22616 rootObs = leafEnv22616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22616 rootObs == leafEnv22616) = true)

theorem terminalChecked22616 : H12PackedTerminal.terminalCheckFast leafEnv22616 active22616 tree22616 = true := by decide +kernel

def env22617 : List Nat := [2,4,8,16,32,17,8,256,0,273,2048,1,2057,1,2048,2310,0,2080,272,2049,0,0,16,3,2057,17,2340,0,1,2308,21,33,257,0,1,0]

theorem envBound22617 : H12AffineFastState.Bounded env22617 := by
  intro p hp
  have h : env22617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22613_22617 : H12AffineEnvironment.transform 12 2057 env22613 = env22617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2057 env22613 == env22617) = true)

theorem identity22617 : scanCanonicalize (H12AffineFastState.compose env22617 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound22617 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22618 : List Nat := [2,4,8,16,1,17,8,256,0,273,2048,1,2057,1,2048,2310,0,2049,272,2049,0,0,16,3,2057,17,2309,0,1,2308,21,0,257,0,1,0]

theorem envBound22618 : H12AffineFastState.Bounded env22618 := by
  intro p hp
  have h : env22618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22617_22618 : H12AffineEnvironment.transform 4 1 env22617 = env22618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22617 == env22618) = true)

theorem identity22618 : scanCanonicalize (H12AffineFastState.compose env22618 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound22618 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env22619 : List Nat := [2,4,8,16,1,17,8,4,0,21,2048,1,2057,1,2048,2050,0,2049,20,2049,0,0,16,3,2057,17,2049,0,1,2048,21,0,5,0,1,0]

theorem envBound22619 : H12AffineFastState.Bounded env22619 := by
  intro p hp
  have h : env22619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22618_22619 : H12AffineEnvironment.transform 7 4 env22618 = env22619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env22618 == env22619) = true)

def leafEnv22619 : List Nat := [2,4,8,16,1,17,8,4,0,21,2048,1,2057,1,2048,2050,0,2049,20,2049,0,0,16,3,20,2057,1,17,2049,0,1,2048,21,0,5,0,5,2051,1,0,0,0,1]

def active22619 : List Nat := [0,1,2,3,10]

def tree22619 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22619 : H12WitnessSearch.Good tree22619 := H12GlobalWitnessIndex.good

theorem leafIdentity22619 : H12AffineFastState.composeSystem env22619 rootObs = leafEnv22619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22619 rootObs == leafEnv22619) = true)

theorem terminalChecked22619 : H12PackedTerminal.terminalCheckFast leafEnv22619 active22619 tree22619 = true := by decide +kernel

def env22620 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,1,8192,1,8201,8462,0,2080,272,8200,0,1,16,2,8193,17,2341,0,1,2309,21,32,257,0,1,512]

theorem envBound22620 : H12AffineFastState.Bounded env22620 := by
  intro p hp
  have h : env22620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22611_22620 : H12AffineEnvironment.transform 6 9 env22611 = env22620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22611 == env22620) = true)

theorem identity22620 : scanCanonicalize (H12AffineFastState.compose env22620 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound22620 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22621 : List Nat := [2,4,8,16,32,17,9,256,293,273,2048,1,8192,1,8201,8462,0,2080,272,8200,0,1,16,2,8193,17,2341,0,1,2309,21,32,257,0,1,293]

theorem envBound22621 : H12AffineFastState.Bounded env22621 := by
  intro p hp
  have h : env22621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22620_22621 : H12AffineEnvironment.transform 8 293 env22620 = env22621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env22620 == env22621) = true)

def env22622 : List Nat := [2,4,8,16,32,17,9,256,293,273,2048,1,2088,1,2081,2342,0,2080,272,2080,0,1,16,2,2089,17,2341,0,1,2309,21,32,257,0,1,293]

theorem envBound22622 : H12AffineFastState.Bounded env22622 := by
  intro p hp
  have h : env22622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22621_22622 : H12AffineEnvironment.transform 12 2088 env22621 = env22622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2088 env22621 == env22622) = true)

theorem identity22622 : scanCanonicalize (H12AffineFastState.compose env22622 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound22622 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22623 : List Nat := [2,4,8,16,32,17,9,37,0,52,2048,1,2088,1,2081,2051,0,2080,53,2080,0,1,16,2,2089,17,2048,0,1,2080,21,32,36,0,1,0]

theorem envBound22623 : H12AffineFastState.Bounded env22623 := by
  intro p hp
  have h : env22623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22622_22623 : H12AffineEnvironment.transform 7 37 env22622 = env22623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env22622 == env22623) = true)

theorem identity22623 : scanCanonicalize (H12AffineFastState.compose env22623 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound22623 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env22624 : List Nat := [2,4,8,16,1,17,9,4,0,21,2048,1,2057,1,2048,2051,0,2049,20,2049,0,1,16,2,2056,17,2048,0,1,2049,21,1,5,0,1,0]

theorem envBound22624 : H12AffineFastState.Bounded env22624 := by
  intro p hp
  have h : env22624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22623_22624 : H12AffineEnvironment.transform 4 1 env22623 = env22624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22623 == env22624) = true)

def env22625 : List Nat := [2,4,8,16,32,17,9,256,293,273,2048,1,2089,1,2080,2343,0,2080,272,2081,0,1,16,2,2088,17,2341,0,1,2309,21,32,257,0,1,293]

theorem envBound22625 : H12AffineFastState.Bounded env22625 := by
  intro p hp
  have h : env22625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22621_22625 : H12AffineEnvironment.transform 12 2089 env22621 = env22625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2089 env22621 == env22625) = true)

theorem identity22625 : scanCanonicalize (H12AffineFastState.compose env22625 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound22625 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22626 : List Nat := [2,4,8,16,1,17,9,256,260,273,2048,1,2056,1,2049,2310,0,2049,272,2048,0,1,16,2,2057,17,2308,0,1,2309,21,1,257,0,1,260]

theorem envBound22626 : H12AffineFastState.Bounded env22626 := by
  intro p hp
  have h : env22626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22625_22626 : H12AffineEnvironment.transform 4 1 env22625 = env22626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22625 == env22626) = true)

theorem identity22626 : scanCanonicalize (H12AffineFastState.compose env22626 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound22626 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env22627 : List Nat := [2,4,8,16,1,17,9,5,1,20,2048,1,2056,1,2049,2051,0,2049,21,2048,0,1,16,2,2057,17,2049,0,1,2048,21,1,4,0,1,1]

theorem envBound22627 : H12AffineFastState.Bounded env22627 := by
  intro p hp
  have h : env22627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22626_22627 : H12AffineEnvironment.transform 7 5 env22626 = env22627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env22626 == env22627) = true)

def leafEnv22627 : List Nat := [2,4,8,16,1,17,9,5,1,20,2048,1,2056,1,2049,2051,0,2049,21,2048,0,1,16,2,20,2057,1,17,2049,0,1,2048,21,1,4,0,5,2051,1,1,0,0,1]

def active22627 : List Nat := [0,1,2,3,10]

def tree22627 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22627 : H12WitnessSearch.Good tree22627 := H12GlobalWitnessIndex.good

theorem leafIdentity22627 : H12AffineFastState.composeSystem env22627 rootObs = leafEnv22627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22627 rootObs == leafEnv22627) = true)

theorem terminalChecked22627 : H12PackedTerminal.terminalCheckFast leafEnv22627 active22627 tree22627 = true := by decide +kernel

def env22628 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1297,32768,65536,1297,262144,1024,32769,1297,4194304,17,98565,8328,17,4456709,1296,1296,1073741824,1284,4294967296,257,4299260335,1296,512]

theorem envBound22628 : H12AffineFastState.Bounded env22628 := by
  intro p hp
  have h : env22628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22550_22628 : H12AffineEnvironment.transform 13 1297 env22550 = env22628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env22550 == env22628) = true)

theorem identity22628 : scanCanonicalize (H12AffineFastState.compose env22628 (packedSelected [1,3,5] rootPS)) = affineNative (2^(17+1) ^^^ 76591) := by decide +kernel

theorem selectedBound22628 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env22629 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1297,32768,65536,1297,76591,1024,32769,1297,4194304,17,98565,8328,17,4270634,1296,1296,1073741824,1284,4294967296,257,4299260335,1296,512]

theorem envBound22629 : H12AffineFastState.Bounded env22629 := by
  intro p hp
  have h : env22629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22628_22629 : H12AffineEnvironment.transform 17 76591 env22628 = env22629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76591 env22628 == env22629) = true)

theorem identity22629 : scanCanonicalize (H12AffineFastState.compose env22629 (packedSelected [1,3,8] rootPS)) = affineNative (2^(29+1) ^^^ 4196613) := by decide +kernel

theorem selectedBound22629 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env22630 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1297,32768,65536,1297,76591,1024,32769,1297,4194304,17,98565,8328,17,4270634,1296,1296,4196613,1284,4294967296,257,4299260335,1296,512]

theorem envBound22630 : H12AffineFastState.Bounded env22630 := by
  intro p hp
  have h : env22630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22629_22630 : H12AffineEnvironment.transform 29 4196613 env22629 = env22630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4196613 env22629 == env22630) = true)

theorem identity22630 : scanCanonicalize (H12AffineFastState.compose env22630 (packedSelected [1,3] rootPS)) = affineNative (2^(21+1) ^^^ 109098) := by decide +kernel

theorem selectedBound22630 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env22631 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1297,32768,65536,1297,76591,1024,32769,1297,109098,17,98565,8328,17,32768,1296,1296,107311,1284,4294967296,257,4294978437,1296,512]

theorem envBound22631 : H12AffineFastState.Bounded env22631 := by
  intro p hp
  have h : env22631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22630_22631 : H12AffineEnvironment.transform 21 109098 env22630 = env22631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 109098 env22630 == env22631) = true)

theorem identity22631 : scanCanonicalize (H12AffineFastState.compose env22631 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 33543) := by decide +kernel

theorem selectedBound22631 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env22632 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1297,32768,33543,1297,43048,1024,32769,1297,10541,17,514,8328,17,32768,1296,1296,8232,1284,4294967296,257,4294978437,1296,512]

theorem envBound22632 : H12AffineFastState.Bounded env22632 := by
  intro p hp
  have h : env22632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22631_22632 : H12AffineEnvironment.transform 15 33543 env22631 = env22632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33543 env22631 == env22632) = true)

theorem identity22632 : scanCanonicalize (H12AffineFastState.compose env22632 (packedSelected [1,10] rootPS)) = affineNative (2^(14+1) ^^^ 9092) := by decide +kernel

theorem selectedBound22632 : packedSelected [1,10] rootPS < 2^1333 := by decide +kernel

def env22633 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1297,9092,8323,1297,2988,1024,9093,1297,10541,17,514,8328,17,9092,1296,1296,8232,1284,4294967296,257,4294978437,1296,512]

theorem envBound22633 : H12AffineFastState.Bounded env22633 := by
  intro p hp
  have h : env22633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22632_22633 : H12AffineEnvironment.transform 14 9092 env22632 = env22633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9092 env22632 == env22633) = true)

theorem identity22633 : scanCanonicalize (H12AffineFastState.compose env22633 (packedSelected [0,2,4,6,11] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound22633 : packedSelected [0,2,4,6,11] rootPS < 2^1333 := by decide +kernel

def env22634 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,1296,8192,1297,8461,8323,1297,2341,1024,8460,1297,10541,17,139,8328,17,8461,1296,1296,8232,1284,4294967296,257,4294977804,1296,137]

theorem envBound22634 : H12AffineFastState.Bounded env22634 := by
  intro p hp
  have h : env22634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22633_22634 : H12AffineEnvironment.transform 8 137 env22633 = env22634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env22633 == env22634) = true)

theorem identity22634 : scanCanonicalize (H12AffineFastState.compose env22634 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 10503) := by decide +kernel

theorem selectedBound22634 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22635 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,1296,8192,1297,8461,8323,1297,2341,1024,8460,1297,10541,17,139,8328,17,8461,1296,1296,8232,1284,10503,257,11,1296,137]

theorem envBound22635 : H12AffineFastState.Bounded env22635 := by
  intro p hp
  have h : env22635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22634_22635 : H12AffineEnvironment.transform 31 10503 env22634 = env22635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 10503 env22634 == env22635) = true)

theorem identity22635 : scanCanonicalize (H12AffineFastState.compose env22635 (packedSelected [2,4] rootPS)) = affineNative (2^(12+1) ^^^ 2088) := by decide +kernel

theorem selectedBound22635 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env22636 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,1296,2088,1297,2341,2219,1297,2341,1024,2340,1297,261,17,139,2208,17,2341,1296,1296,2048,1284,303,257,11,1296,137]

theorem envBound22636 : H12AffineFastState.Bounded env22636 := by
  intro p hp
  have h : env22636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22635_22636 : H12AffineEnvironment.transform 12 2088 env22635 = env22636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2088 env22635 == env22636) = true)

theorem identity22636 : scanCanonicalize (H12AffineFastState.compose env22636 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound22636 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22637 : List Nat := [2,4,8,16,32,17,2,256,11,1024,2048,1296,2088,1297,2341,2089,1297,2341,1024,2340,1297,261,17,9,2082,17,2341,1296,1296,2048,1284,303,257,11,1296,11]

theorem envBound22637 : H12AffineFastState.Bounded env22637 := by
  intro p hp
  have h : env22637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22636_22637 : H12AffineEnvironment.transform 6 2 env22636 = env22637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env22636 == env22637) = true)

def env22638 : List Nat := [2,4,8,16,32,17,2,36,11,1024,2048,1076,2088,1077,2049,2089,1077,2049,1024,2048,1077,33,17,9,2082,17,2049,1076,1076,2048,1056,11,37,11,1076,11]

theorem envBound22638 : H12AffineFastState.Bounded env22638 := by
  intro p hp
  have h : env22638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22637_22638 : H12AffineEnvironment.transform 7 36 env22637 = env22638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env22637 == env22638) = true)

theorem identity22638 : scanCanonicalize (H12AffineFastState.compose env22638 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound22638 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22639 : List Nat := [2,4,8,16,17,17,2,21,11,1024,2048,1029,2073,1028,2049,2072,1028,2049,1024,2048,1028,16,17,9,2067,17,2049,1029,1029,2048,1041,11,20,11,1029,11]

theorem envBound22639 : H12AffineFastState.Bounded env22639 := by
  intro p hp
  have h : env22639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22638_22639 : H12AffineEnvironment.transform 4 17 env22638 = env22639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env22638 == env22639) = true)

def leafEnv22639 : List Nat := [2,4,8,16,17,17,2,21,11,1024,2048,1029,2073,1028,2049,2072,1028,2049,1024,2048,1028,16,17,9,1041,2067,1,17,2049,1029,1029,2048,1041,11,20,11,5,2067,1029,11,0,1028,1]

def active22639 : List Nat := [0,1,2,3,9,10]

def tree22639 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22639 : H12WitnessSearch.Good tree22639 := H12GlobalWitnessIndex.good

theorem leafIdentity22639 : H12AffineFastState.composeSystem env22639 rootObs = leafEnv22639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22639 rootObs == leafEnv22639) = true)

theorem terminalChecked22639 : H12PackedTerminal.terminalCheckFast leafEnv22639 active22639 tree22639 = true := by decide +kernel

def env22640 : List Nat := [2,4,8,16,32,17,2,37,11,1024,2048,1077,2088,1076,2048,2089,1076,2048,1024,2049,1076,32,17,9,2082,17,2048,1077,1077,2048,1057,10,36,11,1077,11]

theorem envBound22640 : H12AffineFastState.Bounded env22640 := by
  intro p hp
  have h : env22640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22637_22640 : H12AffineEnvironment.transform 7 37 env22637 = env22640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env22637 == env22640) = true)

theorem identity22640 : scanCanonicalize (H12AffineFastState.compose env22640 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound22640 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22641 : List Nat := [2,4,8,11,32,10,2,37,11,1024,2048,1070,2088,1071,2048,2089,1071,2048,1024,2049,1071,32,10,9,2082,10,2048,1070,1070,2048,1057,10,36,11,1070,11]

theorem envBound22641 : H12AffineFastState.Bounded env22641 := by
  intro p hp
  have h : env22641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22640_22641 : H12AffineEnvironment.transform 3 11 env22640 = env22641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env22640 == env22641) = true)

def leafEnv22641 : List Nat := [2,4,8,11,32,10,2,37,11,1024,2048,1070,2088,1071,2048,2089,1071,2048,1024,2049,1071,32,10,9,1057,2082,1,10,2048,1070,1070,2048,1057,10,36,11,5,2082,1070,11,0,1071,1]

def active22641 : List Nat := [0,1,2,4,9,10]

def tree22641 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22641 : H12WitnessSearch.Good tree22641 := H12GlobalWitnessIndex.good

theorem leafIdentity22641 : H12AffineFastState.composeSystem env22641 rootObs = leafEnv22641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22641 rootObs == leafEnv22641) = true)

theorem terminalChecked22641 : H12PackedTerminal.terminalCheckFast leafEnv22641 active22641 tree22641 = true := by decide +kernel

def env22642 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,16384,32768,65536,1297,262144,16656,32769,1296,4194304,17664,98565,8328,16,4473877,16385,1296,1073741824,1284,4294967296,257,4299260335,1296,512]

theorem envBound22642 : H12AffineFastState.Bounded env22642 := by
  intro p hp
  have h : env22642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22549_22642 : H12AffineEnvironment.transform 11 1297 env22549 = env22642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env22549 == env22642) = true)

theorem identity22642 : scanCanonicalize (H12AffineFastState.compose env22642 (packedSelected [3,15,17] rootPS)) = affineNative (2^(13+1) ^^^ 1945) := by decide +kernel

theorem selectedBound22642 : packedSelected [3,15,17] rootPS < 2^1333 := by decide +kernel

def env22643 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1945,32768,65536,1297,262144,1673,32769,1296,4194304,665,98565,8328,16,4457356,1944,1296,1073741824,1284,4294967296,257,4299260335,1296,512]

theorem envBound22643 : H12AffineFastState.Bounded env22643 := by
  intro p hp
  have h : env22643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22642_22643 : H12AffineEnvironment.transform 13 1945 env22642 = env22643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1945 env22642 == env22643) = true)

theorem identity22643 : scanCanonicalize (H12AffineFastState.compose env22643 (packedSelected [3,5,12,15,19] rootPS)) = affineNative (2^(29+1) ^^^ 4295170) := by decide +kernel

theorem selectedBound22643 : packedSelected [3,5,12,15,19] rootPS < 2^1333 := by decide +kernel

def env22644 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1945,32768,65536,1297,262144,1673,32769,1296,4194304,665,98565,8328,16,4457356,1944,1296,4295170,1284,4294967296,257,4299260335,1296,512]

theorem envBound22644 : H12AffineFastState.Bounded env22644 := by
  intro p hp
  have h : env22644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22643_22644 : H12AffineEnvironment.transform 29 4295170 env22643 = env22644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4295170 env22643 == env22644) = true)

def env22645 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1945,32768,65536,1297,262144,1673,32769,1296,41480,665,98565,8328,16,303492,1944,1296,75786,1284,4294967296,257,4295041959,1296,512]

theorem envBound22645 : H12AffineFastState.Bounded env22645 := by
  intro p hp
  have h : env22645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22644_22645 : H12AffineEnvironment.transform 21 41480 env22644 = env22645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41480 env22644 == env22645) = true)

theorem identity22645 : scanCanonicalize (H12AffineFastState.compose env22645 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 98986) := by decide +kernel

theorem selectedBound22645 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env22646 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1945,32768,65536,1297,262144,1673,32769,1296,41480,665,98565,8328,16,303492,1944,1296,75786,1284,98986,257,41229,1296,512]

theorem envBound22646 : H12AffineFastState.Bounded env22646 := by
  intro p hp
  have h : env22646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22645_22646 : H12AffineEnvironment.transform 31 98986 env22645 = env22646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 98986 env22645 == env22646) = true)

def env22647 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1945,32768,65536,1297,33280,1673,32769,1296,41480,665,98565,8328,16,9092,1944,1296,75786,1284,98986,257,41229,1296,512]

theorem envBound22647 : H12AffineFastState.Bounded env22647 := by
  intro p hp
  have h : env22647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22646_22647 : H12AffineEnvironment.transform 17 33280 env22646 = env22647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 33280 env22646 == env22647) = true)

theorem identity22647 : scanCanonicalize (H12AffineFastState.compose env22647 (packedSelected [7] rootPS)) = affineNative (2^(14+1) ^^^ 8580) := by decide +kernel

theorem selectedBound22647 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env22648 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1945,8580,65536,1297,9092,1673,8581,1296,908,665,73857,8328,16,9092,1944,1296,75786,1284,74542,257,137,1296,512]

theorem envBound22648 : H12AffineFastState.Bounded env22648 := by
  intro p hp
  have h : env22648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22647_22648 : H12AffineEnvironment.transform 14 8580 env22647 = env22648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8580 env22647 == env22648) = true)

def env22649 : List Nat := [2,4,8,16,32,17,128,256,512,1024,0,1297,8192,1945,8580,65536,1297,9092,1673,8581,1296,908,665,73857,8328,16,9092,1944,1296,73738,1284,74542,257,137,1296,512]

theorem envBound22649 : H12AffineFastState.Bounded env22649 := by
  intro p hp
  have h : env22649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22648_22649 : H12AffineEnvironment.transform 10 0 env22648 = env22649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env22648 == env22649) = true)

theorem identity22649 : scanCanonicalize (H12AffineFastState.compose env22649 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 171) := by decide +kernel

theorem selectedBound22649 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22650 : List Nat := [2,4,8,16,32,17,128,256,512,1024,0,1297,8192,1945,8580,171,1297,9092,1673,8581,1296,908,665,8234,8328,16,9092,1944,1296,8353,1284,9093,257,137,1296,512]

theorem envBound22650 : H12AffineFastState.Bounded env22650 := by
  intro p hp
  have h : env22650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22649_22650 : H12AffineEnvironment.transform 15 171 env22649 = env22650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 171 env22649 == env22650) = true)

theorem identity22650 : scanCanonicalize (H12AffineFastState.compose env22650 (packedSelected [1,3,5] rootPS)) = affineNative (2^(12+1) ^^^ 161) := by decide +kernel

theorem selectedBound22650 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env22651 : List Nat := [2,4,8,16,32,17,128,256,512,1024,0,1297,161,1945,293,171,1297,805,1673,292,1296,908,665,139,41,16,805,1944,1296,0,1284,804,257,137,1296,512]

theorem envBound22651 : H12AffineFastState.Bounded env22651 := by
  intro p hp
  have h : env22651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22650_22651 : H12AffineEnvironment.transform 12 161 env22650 = env22651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env22650 == env22651) = true)

def env22652 : List Nat := [2,4,8,16,32,17,128,256,136,1024,0,1297,161,1297,293,171,1297,429,1025,292,1296,260,17,139,41,16,429,1296,1296,0,1284,428,257,137,1296,136]

theorem envBound22652 : H12AffineFastState.Bounded env22652 := by
  intro p hp
  have h : env22652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22651_22652 : H12AffineEnvironment.transform 8 136 env22651 = env22652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env22651 == env22652) = true)

theorem identity22652 : scanCanonicalize (H12AffineFastState.compose env22652 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound22652 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22653 : List Nat := [2,4,8,16,32,17,128,4,136,1024,0,1045,161,1045,33,171,1045,169,1025,32,1044,0,17,139,41,16,169,1044,1044,0,1024,168,5,137,1044,136]

theorem envBound22653 : H12AffineFastState.Bounded env22653 := by
  intro p hp
  have h : env22653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22652_22653 : H12AffineEnvironment.transform 7 4 env22652 = env22653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env22652 == env22653) = true)

def env22654 : List Nat := [2,4,8,16,0,17,128,4,136,1024,0,1045,129,1045,1,139,1045,137,1025,0,1044,0,17,139,9,16,137,1044,1044,0,1024,136,5,137,1044,136]

theorem envBound22654 : H12AffineFastState.Bounded env22654 := by
  intro p hp
  have h : env22654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22653_22654 : H12AffineEnvironment.transform 4 0 env22653 = env22654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22653 == env22654) = true)

theorem identity22654 : scanCanonicalize (H12AffineFastState.compose env22654 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound22654 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22655 : List Nat := [2,4,8,16,0,17,9,4,1,1024,0,1045,8,1045,1,2,1045,0,1025,0,1044,0,17,2,9,16,0,1044,1044,0,1024,1,5,0,1044,1]

theorem envBound22655 : H12AffineFastState.Bounded env22655 := by
  intro p hp
  have h : env22655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22654_22655 : H12AffineEnvironment.transform 6 9 env22654 = env22655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22654 == env22655) = true)

def leafEnv22655 : List Nat := [2,4,8,16,0,17,9,4,1,1024,0,1045,8,1045,1,2,1045,0,1025,0,1044,0,17,2,1025,9,1,16,0,1044,1044,0,1024,1,5,0,5,2,1044,1,0,1045,1]

def active22655 : List Nat := [0,1,2,3,9]

def tree22655 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22655 : H12WitnessSearch.Good tree22655 := H12GlobalWitnessIndex.good

theorem leafIdentity22655 : H12AffineFastState.composeSystem env22655 rootObs = leafEnv22655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22655 rootObs == leafEnv22655) = true)

theorem terminalChecked22655 : H12PackedTerminal.terminalCheckFast leafEnv22655 active22655 tree22655 = true := by decide +kernel

def env22656 : List Nat := [2,4,8,16,1,17,128,4,136,1024,0,1045,128,1045,0,138,1045,136,1025,1,1044,0,17,139,8,16,136,1044,1044,0,1024,137,5,137,1044,136]

theorem envBound22656 : H12AffineFastState.Bounded env22656 := by
  intro p hp
  have h : env22656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22653_22656 : H12AffineEnvironment.transform 4 1 env22653 = env22656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22653 == env22656) = true)

def leafEnv22656 : List Nat := [2,4,8,16,1,17,128,4,136,1024,0,1045,128,1045,0,138,1045,136,1025,1,1044,0,17,139,1025,8,1,16,136,1044,1044,0,1024,137,5,137,5,3,1044,136,0,1045,1]

def active22656 : List Nat := [0,1,2,3,6,9]

def tree22656 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22656 : H12WitnessSearch.Good tree22656 := H12GlobalWitnessIndex.good

theorem leafIdentity22656 : H12AffineFastState.composeSystem env22656 rootObs = leafEnv22656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22656 rootObs == leafEnv22656) = true)

theorem terminalChecked22656 : H12PackedTerminal.terminalCheckFast leafEnv22656 active22656 tree22656 = true := by decide +kernel

def env22657 : List Nat := [2,4,8,16,32,17,128,256,137,1024,0,1297,161,1296,293,171,1297,428,1024,292,1296,261,16,139,41,16,428,1297,1296,0,1284,429,257,137,1296,137]

theorem envBound22657 : H12AffineFastState.Bounded env22657 := by
  intro p hp
  have h : env22657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22651_22657 : H12AffineEnvironment.transform 8 137 env22651 = env22657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env22651 == env22657) = true)

theorem identity22657 : scanCanonicalize (H12AffineFastState.compose env22657 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound22657 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22658 : List Nat := [2,4,2,16,32,17,128,256,131,1024,0,1297,161,1296,293,161,1297,422,1024,292,1296,261,16,129,35,16,422,1297,1296,0,1284,423,257,131,1296,131]

theorem envBound22658 : H12AffineFastState.Bounded env22658 := by
  intro p hp
  have h : env22658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22657_22658 : H12AffineEnvironment.transform 2 2 env22657 = env22658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env22657 == env22658) = true)

theorem identity22658 : scanCanonicalize (H12AffineFastState.compose env22658 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound22658 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env22659 : List Nat := [2,4,2,16,32,17,3,256,0,1024,0,1297,34,1296,293,34,1297,293,1024,292,1296,261,16,2,35,16,293,1297,1296,0,1284,292,257,0,1296,0]

theorem envBound22659 : H12AffineFastState.Bounded env22659 := by
  intro p hp
  have h : env22659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22658_22659 : H12AffineEnvironment.transform 6 3 env22658 = env22659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env22658 == env22659) = true)

def env22660 : List Nat := [2,4,2,16,0,17,3,256,0,1024,0,1297,2,1296,261,2,1297,261,1024,260,1296,261,16,2,3,16,261,1297,1296,0,1284,260,257,0,1296,0]

theorem envBound22660 : H12AffineFastState.Bounded env22660 := by
  intro p hp
  have h : env22660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22659_22660 : H12AffineEnvironment.transform 4 0 env22659 = env22660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22659 == env22660) = true)

theorem identity22660 : scanCanonicalize (H12AffineFastState.compose env22660 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound22660 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22661 : List Nat := [2,4,2,16,0,17,3,20,0,1024,0,1029,2,1028,17,2,1029,17,1024,16,1028,17,16,2,3,16,17,1029,1028,0,1040,16,21,0,1028,0]

theorem envBound22661 : H12AffineFastState.Bounded env22661 := by
  intro p hp
  have h : env22661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22660_22661 : H12AffineEnvironment.transform 7 20 env22660 = env22661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env22660 == env22661) = true)

def leafEnv22661 : List Nat := [2,4,2,16,0,17,3,20,0,1024,0,1029,2,1028,17,2,1029,17,1024,16,1028,17,16,2,1040,3,1,16,17,1029,1028,0,1040,16,21,0,5,2,1028,0,0,1029,1]

def active22661 : List Nat := [0,1,3,9]

def tree22661 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22661 : H12WitnessSearch.Good tree22661 := H12GlobalWitnessIndex.good

theorem leafIdentity22661 : H12AffineFastState.composeSystem env22661 rootObs = leafEnv22661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22661 rootObs == leafEnv22661) = true)

theorem terminalChecked22661 : H12PackedTerminal.terminalCheckFast leafEnv22661 active22661 tree22661 = true := by decide +kernel

def env22662 : List Nat := [2,4,2,16,1,17,3,256,0,1024,0,1297,3,1296,260,3,1297,260,1024,261,1296,261,16,2,2,16,260,1297,1296,0,1284,261,257,0,1296,0]

theorem envBound22662 : H12AffineFastState.Bounded env22662 := by
  intro p hp
  have h : env22662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22659_22662 : H12AffineEnvironment.transform 4 1 env22659 = env22662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22659 == env22662) = true)

theorem identity22662 : scanCanonicalize (H12AffineFastState.compose env22662 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound22662 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22663 : List Nat := [2,4,2,1,1,0,3,256,0,1024,0,1280,3,1281,260,3,1280,260,1024,261,1281,261,1,2,2,1,260,1280,1281,0,1284,261,257,0,1281,0]

theorem envBound22663 : H12AffineFastState.Bounded env22663 := by
  intro p hp
  have h : env22663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22662_22663 : H12AffineEnvironment.transform 3 1 env22662 = env22663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env22662 == env22663) = true)

def leafEnv22663 : List Nat := [2,4,2,1,1,0,3,256,0,1024,0,1280,3,1281,260,3,1280,260,1024,261,1281,261,1,2,1284,2,1,1,260,1280,1281,0,1284,261,257,0,5,3,1281,0,0,1280,1]

def active22663 : List Nat := [0,1,7,9]

def tree22663 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22663 : H12WitnessSearch.Good tree22663 := H12GlobalWitnessIndex.good

theorem leafIdentity22663 : H12AffineFastState.composeSystem env22663 rootObs = leafEnv22663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22663 rootObs == leafEnv22663) = true)

theorem terminalChecked22663 : H12PackedTerminal.terminalCheckFast leafEnv22663 active22663 tree22663 = true := by decide +kernel

def env22664 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1,1297,8192,1945,8580,65536,1297,9092,1673,8581,1296,908,665,73857,8328,16,9092,1944,1296,73739,1284,74542,257,137,1296,512]

theorem envBound22664 : H12AffineFastState.Bounded env22664 := by
  intro p hp
  have h : env22664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22648_22664 : H12AffineEnvironment.transform 10 1 env22648 = env22664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env22648 == env22664) = true)

theorem identity22664 : scanCanonicalize (H12AffineFastState.compose env22664 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 160) := by decide +kernel

theorem selectedBound22664 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22665 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1,1297,160,1945,292,65536,1297,804,1673,293,1296,908,665,65569,40,16,804,1944,1296,65707,1284,66446,257,137,1296,512]

theorem envBound22665 : H12AffineFastState.Bounded env22665 := by
  intro p hp
  have h : env22665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22664_22665 : H12AffineEnvironment.transform 12 160 env22664 = env22665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env22664 == env22665) = true)

theorem identity22665 : scanCanonicalize (H12AffineFastState.compose env22665 (packedSelected [5,8] rootPS)) = affineNative (2^(15+1) ^^^ 170) := by decide +kernel

theorem selectedBound22665 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env22666 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1,1297,160,1945,292,170,1297,804,1673,293,1296,908,665,139,40,16,804,1944,1296,1,1284,804,257,137,1296,512]

theorem envBound22666 : H12AffineFastState.Bounded env22666 := by
  intro p hp
  have h : env22666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22665_22666 : H12AffineEnvironment.transform 15 170 env22665 = env22666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 170 env22665 == env22666) = true)

def env22667 : List Nat := [2,4,8,16,32,17,128,256,136,1024,1,1297,160,1297,292,170,1297,428,1025,293,1296,260,17,139,40,16,428,1296,1296,1,1284,428,257,137,1296,136]

theorem envBound22667 : H12AffineFastState.Bounded env22667 := by
  intro p hp
  have h : env22667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22666_22667 : H12AffineEnvironment.transform 8 136 env22666 = env22667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env22666 == env22667) = true)

theorem identity22667 : scanCanonicalize (H12AffineFastState.compose env22667 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound22667 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22668 : List Nat := [2,4,8,16,32,17,128,4,136,1024,1,1045,160,1045,32,170,1045,168,1025,33,1044,0,17,139,40,16,168,1044,1044,1,1024,168,5,137,1044,136]

theorem envBound22668 : H12AffineFastState.Bounded env22668 := by
  intro p hp
  have h : env22668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22667_22668 : H12AffineEnvironment.transform 7 4 env22667 = env22668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env22667 == env22668) = true)

def env22669 : List Nat := [2,4,8,16,0,17,128,4,136,1024,1,1045,128,1045,0,138,1045,136,1025,1,1044,0,17,139,8,16,136,1044,1044,1,1024,136,5,137,1044,136]

theorem envBound22669 : H12AffineFastState.Bounded env22669 := by
  intro p hp
  have h : env22669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22668_22669 : H12AffineEnvironment.transform 4 0 env22668 = env22669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22668 == env22669) = true)

theorem identity22669 : scanCanonicalize (H12AffineFastState.compose env22669 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound22669 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22670 : List Nat := [2,4,8,16,0,17,9,4,1,1024,1,1045,9,1045,0,3,1045,1,1025,1,1044,0,17,2,8,16,1,1044,1044,1,1024,1,5,0,1044,1]

theorem envBound22670 : H12AffineFastState.Bounded env22670 := by
  intro p hp
  have h : env22670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22669_22670 : H12AffineEnvironment.transform 6 9 env22669 = env22670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22669 == env22670) = true)

def leafEnv22670 : List Nat := [2,4,8,16,0,17,9,4,1,1024,1,1045,9,1045,0,3,1045,1,1025,1,1044,0,17,2,1025,8,1,16,1,1044,1044,1,1024,1,5,0,5,3,1044,1,0,1045,1]

def active22670 : List Nat := [0,1,2,3,9]

def tree22670 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22670 : H12WitnessSearch.Good tree22670 := H12GlobalWitnessIndex.good

theorem leafIdentity22670 : H12AffineFastState.composeSystem env22670 rootObs = leafEnv22670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22670 rootObs == leafEnv22670) = true)

theorem terminalChecked22670 : H12PackedTerminal.terminalCheckFast leafEnv22670 active22670 tree22670 = true := by decide +kernel

def env22671 : List Nat := [2,4,8,16,1,17,128,4,136,1024,1,1045,129,1045,1,139,1045,137,1025,0,1044,0,17,139,9,16,137,1044,1044,1,1024,137,5,137,1044,136]

theorem envBound22671 : H12AffineFastState.Bounded env22671 := by
  intro p hp
  have h : env22671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22668_22671 : H12AffineEnvironment.transform 4 1 env22668 = env22671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22668 == env22671) = true)

def leafEnv22671 : List Nat := [2,4,8,16,1,17,128,4,136,1024,1,1045,129,1045,1,139,1045,137,1025,0,1044,0,17,139,1025,9,1,16,137,1044,1044,1,1024,137,5,137,5,2,1044,136,0,1045,1]

def active22671 : List Nat := [0,1,2,3,6,9]

def tree22671 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22671 : H12WitnessSearch.Good tree22671 := H12GlobalWitnessIndex.good

theorem leafIdentity22671 : H12AffineFastState.composeSystem env22671 rootObs = leafEnv22671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22671 rootObs == leafEnv22671) = true)

theorem terminalChecked22671 : H12PackedTerminal.terminalCheckFast leafEnv22671 active22671 tree22671 = true := by decide +kernel

def env22672 : List Nat := [2,4,8,16,32,17,128,256,137,1024,1,1297,160,1296,292,170,1297,429,1024,293,1296,261,16,139,40,16,429,1297,1296,1,1284,429,257,137,1296,137]

theorem envBound22672 : H12AffineFastState.Bounded env22672 := by
  intro p hp
  have h : env22672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22666_22672 : H12AffineEnvironment.transform 8 137 env22666 = env22672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env22666 == env22672) = true)

theorem identity22672 : scanCanonicalize (H12AffineFastState.compose env22672 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound22672 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22673 : List Nat := [2,4,2,16,32,17,128,256,131,1024,1,1297,160,1296,292,160,1297,423,1024,293,1296,261,16,129,34,16,423,1297,1296,1,1284,423,257,131,1296,131]

theorem envBound22673 : H12AffineFastState.Bounded env22673 := by
  intro p hp
  have h : env22673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22672_22673 : H12AffineEnvironment.transform 2 2 env22672 = env22673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env22672 == env22673) = true)

theorem identity22673 : scanCanonicalize (H12AffineFastState.compose env22673 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound22673 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env22674 : List Nat := [2,4,2,16,32,17,3,256,0,1024,1,1297,35,1296,292,35,1297,292,1024,293,1296,261,16,2,34,16,292,1297,1296,1,1284,292,257,0,1296,0]

theorem envBound22674 : H12AffineFastState.Bounded env22674 := by
  intro p hp
  have h : env22674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22673_22674 : H12AffineEnvironment.transform 6 3 env22673 = env22674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env22673 == env22674) = true)

def env22675 : List Nat := [2,4,2,16,0,17,3,256,0,1024,1,1297,3,1296,260,3,1297,260,1024,261,1296,261,16,2,2,16,260,1297,1296,1,1284,260,257,0,1296,0]

theorem envBound22675 : H12AffineFastState.Bounded env22675 := by
  intro p hp
  have h : env22675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22674_22675 : H12AffineEnvironment.transform 4 0 env22674 = env22675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22674 == env22675) = true)

theorem identity22675 : scanCanonicalize (H12AffineFastState.compose env22675 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound22675 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22676 : List Nat := [2,4,2,16,0,17,3,20,0,1024,1,1029,3,1028,16,3,1029,16,1024,17,1028,17,16,2,2,16,16,1029,1028,1,1040,16,21,0,1028,0]

theorem envBound22676 : H12AffineFastState.Bounded env22676 := by
  intro p hp
  have h : env22676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22675_22676 : H12AffineEnvironment.transform 7 20 env22675 = env22676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env22675 == env22676) = true)

def leafEnv22676 : List Nat := [2,4,2,16,0,17,3,20,0,1024,1,1029,3,1028,16,3,1029,16,1024,17,1028,17,16,2,1040,2,1,16,16,1029,1028,1,1040,16,21,0,5,3,1028,0,0,1029,1]

def active22676 : List Nat := [0,1,3,9]

def tree22676 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22676 : H12WitnessSearch.Good tree22676 := H12GlobalWitnessIndex.good

theorem leafIdentity22676 : H12AffineFastState.composeSystem env22676 rootObs = leafEnv22676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22676 rootObs == leafEnv22676) = true)

theorem terminalChecked22676 : H12PackedTerminal.terminalCheckFast leafEnv22676 active22676 tree22676 = true := by decide +kernel

def env22677 : List Nat := [2,4,2,16,1,17,3,256,0,1024,1,1297,2,1296,261,2,1297,261,1024,260,1296,261,16,2,3,16,261,1297,1296,1,1284,261,257,0,1296,0]

theorem envBound22677 : H12AffineFastState.Bounded env22677 := by
  intro p hp
  have h : env22677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22674_22677 : H12AffineEnvironment.transform 4 1 env22674 = env22677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22674 == env22677) = true)

theorem identity22677 : scanCanonicalize (H12AffineFastState.compose env22677 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound22677 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22678 : List Nat := [2,4,2,1,1,0,3,256,0,1024,1,1280,2,1281,261,2,1280,261,1024,260,1281,261,1,2,3,1,261,1280,1281,1,1284,261,257,0,1281,0]

theorem envBound22678 : H12AffineFastState.Bounded env22678 := by
  intro p hp
  have h : env22678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22677_22678 : H12AffineEnvironment.transform 3 1 env22677 = env22678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env22677 == env22678) = true)

def leafEnv22678 : List Nat := [2,4,2,1,1,0,3,256,0,1024,1,1280,2,1281,261,2,1280,261,1024,260,1281,261,1,2,1284,3,1,1,261,1280,1281,1,1284,261,257,0,5,2,1281,0,0,1280,1]

def active22678 : List Nat := [0,1,7,9]

def tree22678 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22678 : H12WitnessSearch.Good tree22678 := H12GlobalWitnessIndex.good

theorem leafIdentity22678 : H12AffineFastState.composeSystem env22678 rootObs = leafEnv22678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22678 rootObs == leafEnv22678) = true)

theorem terminalChecked22678 : H12PackedTerminal.terminalCheckFast leafEnv22678 active22678 tree22678 = true := by decide +kernel

def env22679 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1945,32768,65536,1297,33281,1673,32769,1296,41480,665,98565,8328,16,9093,1944,1296,75786,1284,98986,257,41229,1296,512]

theorem envBound22679 : H12AffineFastState.Bounded env22679 := by
  intro p hp
  have h : env22679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22646_22679 : H12AffineEnvironment.transform 17 33281 env22646 = env22679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 33281 env22646 == env22679) = true)

def env22680 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1945,32768,65536,1297,262144,1673,32769,1296,41481,665,98565,8328,16,303493,1944,1296,75787,1284,4294967296,257,4295041958,1296,512]

theorem envBound22680 : H12AffineFastState.Bounded env22680 := by
  intro p hp
  have h : env22680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22644_22680 : H12AffineEnvironment.transform 21 41481 env22644 = env22680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41481 env22644 == env22680) = true)

theorem identity22680 : scanCanonicalize (H12AffineFastState.compose env22680 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 74663) := by decide +kernel

theorem selectedBound22680 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env22681 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1945,32768,65536,1297,262144,1673,32769,1296,41481,665,98565,8328,16,303493,1944,1296,75787,1284,74663,257,1,1296,512]

theorem envBound22681 : H12AffineFastState.Bounded env22681 := by
  intro p hp
  have h : env22681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22680_22681 : H12AffineEnvironment.transform 31 74663 env22680 = env22681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 74663 env22680 == env22681) = true)

def env22682 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1945,32768,65536,1297,33280,1673,32769,1296,41481,665,98565,8328,16,9093,1944,1296,75787,1284,74663,257,1,1296,512]

theorem envBound22682 : H12AffineFastState.Bounded env22682 := by
  intro p hp
  have h : env22682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22681_22682 : H12AffineEnvironment.transform 17 33280 env22681 = env22682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 33280 env22681 == env22682) = true)

def env22683 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1945,32768,65536,1297,33281,1673,32769,1296,41481,665,98565,8328,16,9092,1944,1296,75787,1284,74663,257,1,1296,512]

theorem envBound22683 : H12AffineFastState.Bounded env22683 := by
  intro p hp
  have h : env22683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22681_22683 : H12AffineEnvironment.transform 17 33281 env22681 = env22683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 33281 env22681 == env22683) = true)

theorem identity22683 : scanCanonicalize (H12AffineFastState.compose env22683 (packedSelected [7] rootPS)) = affineNative (2^(14+1) ^^^ 8581) := by decide +kernel

theorem selectedBound22683 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env22684 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1945,8581,65536,1297,9092,1673,8580,1296,908,665,73856,8328,16,9092,1944,1296,75787,1284,74663,257,1,1296,512]

theorem envBound22684 : H12AffineFastState.Bounded env22684 := by
  intro p hp
  have h : env22684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22683_22684 : H12AffineEnvironment.transform 14 8581 env22683 = env22684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8581 env22683 == env22684) = true)

def env22685 : List Nat := [2,4,8,16,32,17,128,256,512,1024,0,1297,8192,1945,8581,65536,1297,9092,1673,8580,1296,908,665,73856,8328,16,9092,1944,1296,73739,1284,74663,257,1,1296,512]

theorem envBound22685 : H12AffineFastState.Bounded env22685 := by
  intro p hp
  have h : env22685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22684_22685 : H12AffineEnvironment.transform 10 0 env22684 = env22685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env22684 == env22685) = true)

theorem identity22685 : scanCanonicalize (H12AffineFastState.compose env22685 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 171) := by decide +kernel

theorem selectedBound22685 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22686 : List Nat := [2,4,8,16,32,17,128,256,512,1024,0,1297,8192,1945,8581,171,1297,9092,1673,8580,1296,908,665,8235,8328,16,9092,1944,1296,8352,1284,8972,257,1,1296,512]

theorem envBound22686 : H12AffineFastState.Bounded env22686 := by
  intro p hp
  have h : env22686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22685_22686 : H12AffineEnvironment.transform 15 171 env22685 = env22686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 171 env22685 == env22686) = true)

theorem identity22686 : scanCanonicalize (H12AffineFastState.compose env22686 (packedSelected [1,3,5] rootPS)) = affineNative (2^(12+1) ^^^ 160) := by decide +kernel

theorem selectedBound22686 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env22687 : List Nat := [2,4,8,16,32,17,128,256,512,1024,0,1297,160,1945,293,171,1297,804,1673,292,1296,908,665,139,40,16,804,1944,1296,0,1284,940,257,1,1296,512]

theorem envBound22687 : H12AffineFastState.Bounded env22687 := by
  intro p hp
  have h : env22687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22686_22687 : H12AffineEnvironment.transform 12 160 env22686 = env22687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env22686 == env22687) = true)

def env22688 : List Nat := [2,4,8,16,32,17,128,256,136,1024,0,1297,160,1297,293,171,1297,428,1025,292,1296,260,17,139,40,16,428,1296,1296,0,1284,292,257,1,1296,136]

theorem envBound22688 : H12AffineFastState.Bounded env22688 := by
  intro p hp
  have h : env22688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22687_22688 : H12AffineEnvironment.transform 8 136 env22687 = env22688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env22687 == env22688) = true)

theorem identity22688 : scanCanonicalize (H12AffineFastState.compose env22688 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 141) := by decide +kernel

theorem selectedBound22688 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22689 : List Nat := [2,4,8,16,32,17,128,141,136,1024,0,1180,160,1180,168,171,1180,33,1025,169,1181,137,17,139,40,16,33,1181,1181,0,1161,169,140,1,1181,136]

theorem envBound22689 : H12AffineFastState.Bounded env22689 := by
  intro p hp
  have h : env22689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22688_22689 : H12AffineEnvironment.transform 7 141 env22688 = env22689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 141 env22688 == env22689) = true)

def env22690 : List Nat := [2,4,8,16,0,17,128,141,136,1024,0,1180,128,1180,136,139,1180,1,1025,137,1181,137,17,139,8,16,1,1181,1181,0,1161,137,140,1,1181,136]

theorem envBound22690 : H12AffineFastState.Bounded env22690 := by
  intro p hp
  have h : env22690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22689_22690 : H12AffineEnvironment.transform 4 0 env22689 = env22690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22689 == env22690) = true)

def leafEnv22690 : List Nat := [2,4,8,16,0,17,128,141,136,1024,0,1180,128,1180,136,139,1180,1,1025,137,1181,137,17,139,1160,8,1,16,1,1181,1181,0,1161,137,140,1,5,2,1181,136,0,1180,1]

def active22690 : List Nat := [0,1,2,3,6,9]

def tree22690 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22690 : H12WitnessSearch.Good tree22690 := H12GlobalWitnessIndex.good

theorem leafIdentity22690 : H12AffineFastState.composeSystem env22690 rootObs = leafEnv22690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22690 rootObs == leafEnv22690) = true)

theorem terminalChecked22690 : H12PackedTerminal.terminalCheckFast leafEnv22690 active22690 tree22690 = true := by decide +kernel

def env22691 : List Nat := [2,4,8,16,1,17,128,141,136,1024,0,1180,129,1180,137,138,1180,0,1025,136,1181,137,17,139,9,16,0,1181,1181,0,1161,136,140,1,1181,136]

theorem envBound22691 : H12AffineFastState.Bounded env22691 := by
  intro p hp
  have h : env22691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22689_22691 : H12AffineEnvironment.transform 4 1 env22689 = env22691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22689 == env22691) = true)

theorem identity22691 : scanCanonicalize (H12AffineFastState.compose env22691 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound22691 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22692 : List Nat := [2,4,8,16,1,17,8,5,0,1024,0,1044,9,1044,1,2,1044,0,1025,0,1045,1,17,3,9,16,0,1045,1045,0,1025,0,4,1,1045,0]

theorem envBound22692 : H12AffineFastState.Bounded env22692 := by
  intro p hp
  have h : env22692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22691_22692 : H12AffineEnvironment.transform 6 8 env22691 = env22692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22691 == env22692) = true)

def leafEnv22692 : List Nat := [2,4,8,16,1,17,8,5,0,1024,0,1044,9,1044,1,2,1044,0,1025,0,1045,1,17,3,1024,9,1,16,0,1045,1045,0,1025,0,4,1,5,3,1045,0,0,1044,1]

def active22692 : List Nat := [0,1,2,3,9]

def tree22692 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22692 : H12WitnessSearch.Good tree22692 := H12GlobalWitnessIndex.good

theorem leafIdentity22692 : H12AffineFastState.composeSystem env22692 rootObs = leafEnv22692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22692 rootObs == leafEnv22692) = true)

theorem terminalChecked22692 : H12PackedTerminal.terminalCheckFast leafEnv22692 active22692 tree22692 = true := by decide +kernel

def env22693 : List Nat := [2,4,8,16,32,17,128,256,137,1024,0,1297,160,1296,293,171,1297,429,1024,292,1296,261,16,139,40,16,429,1297,1296,0,1284,293,257,1,1296,137]

theorem envBound22693 : H12AffineFastState.Bounded env22693 := by
  intro p hp
  have h : env22693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22687_22693 : H12AffineEnvironment.transform 8 137 env22687 = env22693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env22687 == env22693) = true)

theorem identity22693 : scanCanonicalize (H12AffineFastState.compose env22693 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound22693 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22694 : List Nat := [2,4,8,16,32,17,2,256,11,1024,0,1297,34,1296,293,41,1297,303,1024,292,1296,261,16,9,40,16,303,1297,1296,0,1284,293,257,1,1296,11]

theorem envBound22694 : H12AffineFastState.Bounded env22694 := by
  intro p hp
  have h : env22694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22693_22694 : H12AffineEnvironment.transform 6 2 env22693 = env22694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env22693 == env22694) = true)

theorem identity22694 : scanCanonicalize (H12AffineFastState.compose env22694 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound22694 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env22695 : List Nat := [2,4,2,16,32,17,2,256,1,1024,0,1297,34,1296,293,35,1297,293,1024,292,1296,261,16,3,34,16,293,1297,1296,0,1284,293,257,1,1296,1]

theorem envBound22695 : H12AffineFastState.Bounded env22695 := by
  intro p hp
  have h : env22695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22694_22695 : H12AffineEnvironment.transform 2 2 env22694 = env22695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env22694 == env22695) = true)

def env22696 : List Nat := [2,4,2,16,0,17,2,256,1,1024,0,1297,2,1296,261,3,1297,261,1024,260,1296,261,16,3,2,16,261,1297,1296,0,1284,261,257,1,1296,1]

theorem envBound22696 : H12AffineFastState.Bounded env22696 := by
  intro p hp
  have h : env22696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22695_22696 : H12AffineEnvironment.transform 4 0 env22695 = env22696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22695 == env22696) = true)

theorem identity22696 : scanCanonicalize (H12AffineFastState.compose env22696 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound22696 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22697 : List Nat := [2,4,2,0,0,1,2,256,1,1024,0,1281,2,1280,261,3,1281,261,1024,260,1280,261,0,3,2,0,261,1281,1280,0,1284,261,257,1,1280,1]

theorem envBound22697 : H12AffineFastState.Bounded env22697 := by
  intro p hp
  have h : env22697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22696_22697 : H12AffineEnvironment.transform 3 0 env22696 = env22697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env22696 == env22697) = true)

def leafEnv22697 : List Nat := [2,4,2,0,0,1,2,256,1,1024,0,1281,2,1280,261,3,1281,261,1024,260,1280,261,0,3,1284,2,1,0,261,1281,1280,0,1284,261,257,1,5,2,1280,1,0,1281,1]

def active22697 : List Nat := [0,1,7,9]

def tree22697 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22697 : H12WitnessSearch.Good tree22697 := H12GlobalWitnessIndex.good

theorem leafIdentity22697 : H12AffineFastState.composeSystem env22697 rootObs = leafEnv22697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22697 rootObs == leafEnv22697) = true)

theorem terminalChecked22697 : H12PackedTerminal.terminalCheckFast leafEnv22697 active22697 tree22697 = true := by decide +kernel

def env22698 : List Nat := [2,4,2,16,1,17,2,256,1,1024,0,1297,3,1296,260,2,1297,260,1024,261,1296,261,16,3,3,16,260,1297,1296,0,1284,260,257,1,1296,1]

theorem envBound22698 : H12AffineFastState.Bounded env22698 := by
  intro p hp
  have h : env22698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22695_22698 : H12AffineEnvironment.transform 4 1 env22695 = env22698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22695 == env22698) = true)

theorem identity22698 : scanCanonicalize (H12AffineFastState.compose env22698 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound22698 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22699 : List Nat := [2,4,2,16,1,17,2,20,1,1024,0,1029,3,1028,16,2,1029,16,1024,17,1028,17,16,3,3,16,16,1029,1028,0,1040,16,21,1,1028,1]

theorem envBound22699 : H12AffineFastState.Bounded env22699 := by
  intro p hp
  have h : env22699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22698_22699 : H12AffineEnvironment.transform 7 20 env22698 = env22699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env22698 == env22699) = true)

def leafEnv22699 : List Nat := [2,4,2,16,1,17,2,20,1,1024,0,1029,3,1028,16,2,1029,16,1024,17,1028,17,16,3,1040,3,1,16,16,1029,1028,0,1040,16,21,1,5,3,1028,1,0,1029,1]

def active22699 : List Nat := [0,1,3,9]

def tree22699 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22699 : H12WitnessSearch.Good tree22699 := H12GlobalWitnessIndex.good

theorem leafIdentity22699 : H12AffineFastState.composeSystem env22699 rootObs = leafEnv22699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22699 rootObs == leafEnv22699) = true)

theorem terminalChecked22699 : H12PackedTerminal.terminalCheckFast leafEnv22699 active22699 tree22699 = true := by decide +kernel

def env22700 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1,1297,8192,1945,8581,65536,1297,9092,1673,8580,1296,908,665,73856,8328,16,9092,1944,1296,73738,1284,74663,257,1,1296,512]

theorem envBound22700 : H12AffineFastState.Bounded env22700 := by
  intro p hp
  have h : env22700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22684_22700 : H12AffineEnvironment.transform 10 1 env22684 = env22700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env22684 == env22700) = true)

theorem identity22700 : scanCanonicalize (H12AffineFastState.compose env22700 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 161) := by decide +kernel

theorem selectedBound22700 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22701 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1,1297,161,1945,292,65536,1297,805,1673,293,1296,908,665,65569,41,16,805,1944,1296,65707,1284,66310,257,1,1296,512]

theorem envBound22701 : H12AffineFastState.Bounded env22701 := by
  intro p hp
  have h : env22701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22700_22701 : H12AffineEnvironment.transform 12 161 env22700 = env22701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env22700 == env22701) = true)

theorem identity22701 : scanCanonicalize (H12AffineFastState.compose env22701 (packedSelected [5,8] rootPS)) = affineNative (2^(15+1) ^^^ 170) := by decide +kernel

theorem selectedBound22701 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env22702 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1,1297,161,1945,292,170,1297,805,1673,293,1296,908,665,139,41,16,805,1944,1296,1,1284,940,257,1,1296,512]

theorem envBound22702 : H12AffineFastState.Bounded env22702 := by
  intro p hp
  have h : env22702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22701_22702 : H12AffineEnvironment.transform 15 170 env22701 = env22702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 170 env22701 == env22702) = true)

def env22703 : List Nat := [2,4,8,16,32,17,128,256,136,1024,1,1297,161,1297,292,170,1297,429,1025,293,1296,260,17,139,41,16,429,1296,1296,1,1284,292,257,1,1296,136]

theorem envBound22703 : H12AffineFastState.Bounded env22703 := by
  intro p hp
  have h : env22703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22702_22703 : H12AffineEnvironment.transform 8 136 env22702 = env22703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env22702 == env22703) = true)

theorem identity22703 : scanCanonicalize (H12AffineFastState.compose env22703 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 141) := by decide +kernel

theorem selectedBound22703 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22704 : List Nat := [2,4,8,16,32,17,128,141,136,1024,1,1180,161,1180,169,170,1180,32,1025,168,1181,137,17,139,41,16,32,1181,1181,1,1161,169,140,1,1181,136]

theorem envBound22704 : H12AffineFastState.Bounded env22704 := by
  intro p hp
  have h : env22704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22703_22704 : H12AffineEnvironment.transform 7 141 env22703 = env22704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 141 env22703 == env22704) = true)

def env22705 : List Nat := [2,4,8,16,0,17,128,141,136,1024,1,1180,129,1180,137,138,1180,0,1025,136,1181,137,17,139,9,16,0,1181,1181,1,1161,137,140,1,1181,136]

theorem envBound22705 : H12AffineFastState.Bounded env22705 := by
  intro p hp
  have h : env22705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22704_22705 : H12AffineEnvironment.transform 4 0 env22704 = env22705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22704 == env22705) = true)

def leafEnv22705 : List Nat := [2,4,8,16,0,17,128,141,136,1024,1,1180,129,1180,137,138,1180,0,1025,136,1181,137,17,139,1160,9,1,16,0,1181,1181,1,1161,137,140,1,5,3,1181,136,0,1180,1]

def active22705 : List Nat := [0,1,2,3,6,9]

def tree22705 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22705 : H12WitnessSearch.Good tree22705 := H12GlobalWitnessIndex.good

theorem leafIdentity22705 : H12AffineFastState.composeSystem env22705 rootObs = leafEnv22705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22705 rootObs == leafEnv22705) = true)

theorem terminalChecked22705 : H12PackedTerminal.terminalCheckFast leafEnv22705 active22705 tree22705 = true := by decide +kernel

def env22706 : List Nat := [2,4,8,16,1,17,128,141,136,1024,1,1180,128,1180,136,139,1180,1,1025,137,1181,137,17,139,8,16,1,1181,1181,1,1161,136,140,1,1181,136]

theorem envBound22706 : H12AffineFastState.Bounded env22706 := by
  intro p hp
  have h : env22706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22704_22706 : H12AffineEnvironment.transform 4 1 env22704 = env22706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22704 == env22706) = true)

theorem identity22706 : scanCanonicalize (H12AffineFastState.compose env22706 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound22706 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22707 : List Nat := [2,4,8,16,1,17,8,5,0,1024,1,1044,8,1044,0,3,1044,1,1025,1,1045,1,17,3,8,16,1,1045,1045,1,1025,0,4,1,1045,0]

theorem envBound22707 : H12AffineFastState.Bounded env22707 := by
  intro p hp
  have h : env22707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22706_22707 : H12AffineEnvironment.transform 6 8 env22706 = env22707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22706 == env22707) = true)

def leafEnv22707 : List Nat := [2,4,8,16,1,17,8,5,0,1024,1,1044,8,1044,0,3,1044,1,1025,1,1045,1,17,3,1024,8,1,16,1,1045,1045,1,1025,0,4,1,5,2,1045,0,0,1044,1]

def active22707 : List Nat := [0,1,2,3,9]

def tree22707 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22707 : H12WitnessSearch.Good tree22707 := H12GlobalWitnessIndex.good

theorem leafIdentity22707 : H12AffineFastState.composeSystem env22707 rootObs = leafEnv22707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22707 rootObs == leafEnv22707) = true)

theorem terminalChecked22707 : H12PackedTerminal.terminalCheckFast leafEnv22707 active22707 tree22707 = true := by decide +kernel

def env22708 : List Nat := [2,4,8,16,32,17,128,256,137,1024,1,1297,161,1296,292,170,1297,428,1024,293,1296,261,16,139,41,16,428,1297,1296,1,1284,293,257,1,1296,137]

theorem envBound22708 : H12AffineFastState.Bounded env22708 := by
  intro p hp
  have h : env22708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22702_22708 : H12AffineEnvironment.transform 8 137 env22702 = env22708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env22702 == env22708) = true)

theorem identity22708 : scanCanonicalize (H12AffineFastState.compose env22708 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound22708 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22709 : List Nat := [2,4,8,16,32,17,2,256,11,1024,1,1297,35,1296,292,40,1297,302,1024,293,1296,261,16,9,41,16,302,1297,1296,1,1284,293,257,1,1296,11]

theorem envBound22709 : H12AffineFastState.Bounded env22709 := by
  intro p hp
  have h : env22709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22708_22709 : H12AffineEnvironment.transform 6 2 env22708 = env22709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env22708 == env22709) = true)

theorem identity22709 : scanCanonicalize (H12AffineFastState.compose env22709 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound22709 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env22710 : List Nat := [2,4,2,16,32,17,2,256,1,1024,1,1297,35,1296,292,34,1297,292,1024,293,1296,261,16,3,35,16,292,1297,1296,1,1284,293,257,1,1296,1]

theorem envBound22710 : H12AffineFastState.Bounded env22710 := by
  intro p hp
  have h : env22710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22709_22710 : H12AffineEnvironment.transform 2 2 env22709 = env22710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env22709 == env22710) = true)

def env22711 : List Nat := [2,4,2,16,0,17,2,256,1,1024,1,1297,3,1296,260,2,1297,260,1024,261,1296,261,16,3,3,16,260,1297,1296,1,1284,261,257,1,1296,1]

theorem envBound22711 : H12AffineFastState.Bounded env22711 := by
  intro p hp
  have h : env22711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22710_22711 : H12AffineEnvironment.transform 4 0 env22710 = env22711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22710 == env22711) = true)

theorem identity22711 : scanCanonicalize (H12AffineFastState.compose env22711 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound22711 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22712 : List Nat := [2,4,2,0,0,1,2,256,1,1024,1,1281,3,1280,260,2,1281,260,1024,261,1280,261,0,3,3,0,260,1281,1280,1,1284,261,257,1,1280,1]

theorem envBound22712 : H12AffineFastState.Bounded env22712 := by
  intro p hp
  have h : env22712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22711_22712 : H12AffineEnvironment.transform 3 0 env22711 = env22712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env22711 == env22712) = true)

def leafEnv22712 : List Nat := [2,4,2,0,0,1,2,256,1,1024,1,1281,3,1280,260,2,1281,260,1024,261,1280,261,0,3,1284,3,1,0,260,1281,1280,1,1284,261,257,1,5,3,1280,1,0,1281,1]

def active22712 : List Nat := [0,1,7,9]

def tree22712 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22712 : H12WitnessSearch.Good tree22712 := H12GlobalWitnessIndex.good

theorem leafIdentity22712 : H12AffineFastState.composeSystem env22712 rootObs = leafEnv22712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22712 rootObs == leafEnv22712) = true)

theorem terminalChecked22712 : H12PackedTerminal.terminalCheckFast leafEnv22712 active22712 tree22712 = true := by decide +kernel

def env22713 : List Nat := [2,4,2,16,1,17,2,256,1,1024,1,1297,2,1296,261,3,1297,261,1024,260,1296,261,16,3,2,16,261,1297,1296,1,1284,260,257,1,1296,1]

theorem envBound22713 : H12AffineFastState.Bounded env22713 := by
  intro p hp
  have h : env22713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22710_22713 : H12AffineEnvironment.transform 4 1 env22710 = env22713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22710 == env22713) = true)

theorem identity22713 : scanCanonicalize (H12AffineFastState.compose env22713 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound22713 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22714 : List Nat := [2,4,2,16,1,17,2,20,1,1024,1,1029,2,1028,17,3,1029,17,1024,16,1028,17,16,3,2,16,17,1029,1028,1,1040,16,21,1,1028,1]

theorem envBound22714 : H12AffineFastState.Bounded env22714 := by
  intro p hp
  have h : env22714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22713_22714 : H12AffineEnvironment.transform 7 20 env22713 = env22714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env22713 == env22714) = true)

def leafEnv22714 : List Nat := [2,4,2,16,1,17,2,20,1,1024,1,1029,2,1028,17,3,1029,17,1024,16,1028,17,16,3,1040,2,1,16,17,1029,1028,1,1040,16,21,1,5,2,1028,1,0,1029,1]

def active22714 : List Nat := [0,1,3,9]

def tree22714 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22714 : H12WitnessSearch.Good tree22714 := H12GlobalWitnessIndex.good

theorem leafIdentity22714 : H12AffineFastState.composeSystem env22714 rootObs = leafEnv22714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22714 rootObs == leafEnv22714) = true)

theorem terminalChecked22714 : H12PackedTerminal.terminalCheckFast leafEnv22714 active22714 tree22714 = true := by decide +kernel

def env22715 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32769,4097,4194304,17665,16777216,8328,541008,21352528,16385,545089,1073741824,16876545,4294967296,257,4315938986,545041,512]

theorem envBound22715 : H12AffineFastState.Bounded env22715 := by
  intro p hp
  have h : env22715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22302_22715 : H12AffineEnvironment.transform 16 1345 env22302 = env22715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env22302 == env22715) = true)

theorem identity22715 : scanCanonicalize (H12AffineFastState.compose env22715 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(23+1) ^^^ 644436) := by decide +kernel

theorem selectedBound22715 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env22716 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32769,4097,4194304,17665,644436,8328,541008,4982020,16385,545089,1073741824,545109,4294967296,257,4299806206,545041,512]

theorem envBound22716 : H12AffineFastState.Bounded env22716 := by
  intro p hp
  have h : env22716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22715_22716 : H12AffineEnvironment.transform 23 644436 env22715 = env22716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 644436 env22715 == env22716) = true)

theorem identity22716 : scanCanonicalize (H12AffineFastState.compose env22716 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(18+1) ^^^ 1025) := by decide +kernel

theorem selectedBound22716 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env22717 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,1025,32769,4097,4194304,17665,119125,8328,17745,4456709,16385,21824,1073741824,21844,4294967296,257,4299280895,21776,512]

theorem envBound22717 : H12AffineFastState.Bounded env22717 := by
  intro p hp
  have h : env22717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22716_22717 : H12AffineEnvironment.transform 18 1025 env22716 = env22717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env22716 == env22717) = true)

def env22718 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,65536,1345,262144,1025,32769,4097,4194304,65,103445,8328,17,4456709,1345,4096,1073741824,4116,4294967296,257,4299265215,4176,512]

theorem envBound22718 : H12AffineFastState.Bounded env22718 := by
  intro p hp
  have h : env22718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22717_22718 : H12AffineEnvironment.transform 13 1344 env22717 = env22718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env22717 == env22718) = true)

theorem identity22718 : scanCanonicalize (H12AffineFastState.compose env22718 (packedSelected [0,7,20] rootPS)) = affineNative (2^(11+1) ^^^ 1345) := by decide +kernel

theorem selectedBound22718 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env22719 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,65536,1345,262144,1025,32769,1344,4194304,65,98644,8328,17,4456709,1345,1345,1073741824,1365,4294967296,257,4299260414,1297,512]

theorem envBound22719 : H12AffineFastState.Bounded env22719 := by
  intro p hp
  have h : env22719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22718_22719 : H12AffineEnvironment.transform 11 1345 env22718 = env22719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env22718 == env22719) = true)

theorem identity22719 : scanCanonicalize (H12AffineFastState.compose env22719 (packedSelected [17,21] rootPS)) = affineNative (2^(15+1) ^^^ 33246) := by decide +kernel

theorem selectedBound22719 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env22720 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,33246,1345,262144,1025,32769,1344,4194304,65,138,8328,17,4456709,1345,1345,1073741824,1365,4294967296,257,4299161632,1297,512]

theorem envBound22720 : H12AffineFastState.Bounded env22720 := by
  intro p hp
  have h : env22720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22719_22720 : H12AffineEnvironment.transform 15 33246 env22719 = env22720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33246 env22719 == env22720) = true)

theorem identity22720 : scanCanonicalize (H12AffineFastState.compose env22720 (packedSelected [1,5,10,13,15,17,24,28,38] rootPS)) = affineNative (2^(31+1) ^^^ 1074045428) := by decide +kernel

theorem selectedBound22720 : packedSelected [1,5,10,13,15,17,24,28,38] rootPS < 2^1333 := by decide +kernel

def env22721 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,33246,1345,262144,1025,32769,1344,4194304,65,138,8328,17,4456709,1345,1345,1073741824,1365,1074045428,257,1078239700,1297,512]

theorem envBound22721 : H12AffineFastState.Bounded env22721 := by
  intro p hp
  have h : env22721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22720_22721 : H12AffineEnvironment.transform 31 1074045428 env22720 = env22721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1074045428 env22720 == env22721) = true)

theorem identity22721 : scanCanonicalize (H12AffineFastState.compose env22721 (packedSelected [1,5,10,24,28] rootPS)) = affineNative (2^(17+1) ^^^ 43129) := by decide +kernel

theorem selectedBound22721 : packedSelected [1,5,10,24,28] rootPS < 2^1333 := by decide +kernel

def env22722 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,33246,1345,43129,1025,32769,1344,4194304,65,138,8328,17,4237692,1345,1345,1073741824,1365,1073744269,257,1077938605,1297,512]

theorem envBound22722 : H12AffineFastState.Bounded env22722 := by
  intro p hp
  have h : env22722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22721_22722 : H12AffineEnvironment.transform 17 43129 env22721 = env22722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43129 env22721 == env22722) = true)

theorem identity22722 : scanCanonicalize (H12AffineFastState.compose env22722 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(29+1) ^^^ 8461) := by decide +kernel

theorem selectedBound22722 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env22723 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,33246,1345,43129,1025,32769,1344,4194304,65,138,8328,17,4237692,1345,1345,8461,1365,10368,257,4204704,1297,512]

theorem envBound22723 : H12AffineFastState.Bounded env22723 := by
  intro p hp
  have h : env22723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22722_22723 : H12AffineEnvironment.transform 29 8461 env22722 = env22723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 8461 env22722 == env22723) = true)

theorem identity22723 : scanCanonicalize (H12AffineFastState.compose env22723 (packedSelected [0,4,7,9,11] rootPS)) = affineNative (2^(21+1) ^^^ 10329) := by decide +kernel

theorem selectedBound22723 : packedSelected [0,4,7,9,11] rootPS < 2^1333 := by decide +kernel

def env22724 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,33246,1345,43129,1025,32769,1344,10329,65,138,8328,17,33061,1345,1345,8461,1365,10368,257,249,1297,512]

theorem envBound22724 : H12AffineFastState.Bounded env22724 := by
  intro p hp
  have h : env22724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22723_22724 : H12AffineEnvironment.transform 21 10329 env22723 = env22724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10329 env22723 == env22724) = true)

theorem identity22724 : scanCanonicalize (H12AffineFastState.compose env22724 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(14+1) ^^^ 2421) := by decide +kernel

theorem selectedBound22724 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env22725 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,2421,2219,1345,8460,1025,2420,1344,10329,65,138,8328,17,2128,1345,1345,8461,1365,10368,257,249,1297,512]

theorem envBound22725 : H12AffineFastState.Bounded env22725 := by
  intro p hp
  have h : env22725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22724_22725 : H12AffineEnvironment.transform 14 2421 env22724 = env22725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2421 env22724 == env22725) = true)

theorem identity22725 : scanCanonicalize (H12AffineFastState.compose env22725 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 901) := by decide +kernel

theorem selectedBound22725 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env22726 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,901,1344,2421,2219,1345,649,1025,2420,1344,3036,65,138,781,17,2128,1345,1345,648,1365,2821,257,249,1297,512]

theorem envBound22726 : H12AffineFastState.Bounded env22726 := by
  intro p hp
  have h : env22726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22725_22726 : H12AffineEnvironment.transform 12 901 env22725 = env22726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 901 env22725 == env22726) = true)

theorem identity22726 : scanCanonicalize (H12AffineFastState.compose env22726 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 1345) := by decide +kernel

theorem selectedBound22726 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env22727 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1345,1345,901,1344,1076,1514,1345,649,1025,1077,1344,1693,65,138,781,17,1297,1345,1345,648,1365,1604,257,249,1297,512]

theorem envBound22727 : H12AffineFastState.Bounded env22727 := by
  intro p hp
  have h : env22727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22726_22727 : H12AffineEnvironment.transform 10 1345 env22726 = env22727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1345 env22726 == env22727) = true)

theorem identity22727 : scanCanonicalize (H12AffineFastState.compose env22727 (packedSelected [3,5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound22727 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env22728 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1296,1296,901,1297,1076,1467,1296,649,1025,1077,1297,1693,16,138,781,17,1297,1296,1296,648,1284,1557,257,168,1297,512]

theorem envBound22728 : H12AffineFastState.Bounded env22728 := by
  intro p hp
  have h : env22728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22727_22728 : H12AffineEnvironment.transform 5 17 env22727 = env22728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env22727 == env22728) = true)

theorem identity22728 : scanCanonicalize (H12AffineFastState.compose env22728 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 314) := by decide +kernel

theorem selectedBound22728 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22729 : List Nat := [2,4,8,16,32,17,128,256,512,314,42,42,901,43,270,129,42,649,315,271,43,935,16,138,781,17,43,42,42,648,62,815,257,168,43,512]

theorem envBound22729 : H12AffineFastState.Bounded env22729 := by
  intro p hp
  have h : env22729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22728_22729 : H12AffineEnvironment.transform 9 314 env22728 = env22729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 314 env22728 == env22729) = true)

theorem identity22729 : scanCanonicalize (H12AffineFastState.compose env22729 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound22729 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env22730 : List Nat := [2,4,8,16,32,17,9,256,512,314,42,42,780,43,270,8,42,512,315,271,43,814,16,3,781,17,43,42,42,513,62,815,257,33,43,512]

theorem envBound22730 : H12AffineFastState.Bounded env22730 := by
  intro p hp
  have h : env22730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22729_22730 : H12AffineEnvironment.transform 6 9 env22729 = env22730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22729 == env22730) = true)

theorem identity22730 : scanCanonicalize (H12AffineFastState.compose env22730 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound22730 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env22731 : List Nat := [2,4,8,16,32,17,9,256,1,314,42,42,269,43,270,8,42,1,315,271,43,303,16,3,268,17,43,42,42,0,62,302,257,33,43,1]

theorem envBound22731 : H12AffineFastState.Bounded env22731 := by
  intro p hp
  have h : env22731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22730_22731 : H12AffineEnvironment.transform 8 1 env22730 = env22731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env22730 == env22731) = true)

theorem identity22731 : scanCanonicalize (H12AffineFastState.compose env22731 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound22731 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env22732 : List Nat := [2,4,8,16,11,17,9,256,1,273,1,1,269,0,270,8,1,1,272,271,0,260,16,3,268,17,0,1,1,0,21,261,257,10,0,1]

theorem envBound22732 : H12AffineFastState.Bounded env22732 := by
  intro p hp
  have h : env22732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22731_22732 : H12AffineEnvironment.transform 4 11 env22731 = env22732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env22731 == env22732) = true)

theorem identity22732 : scanCanonicalize (H12AffineFastState.compose env22732 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound22732 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22733 : List Nat := [2,4,8,0,11,1,9,256,1,257,1,1,269,0,270,8,1,1,256,271,0,260,0,3,268,1,0,1,1,0,5,261,257,10,0,1]

theorem envBound22733 : H12AffineFastState.Bounded env22733 := by
  intro p hp
  have h : env22733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22732_22733 : H12AffineEnvironment.transform 3 0 env22732 = env22733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env22732 == env22733) = true)

theorem identity22733 : scanCanonicalize (H12AffineFastState.compose env22733 (packedSelected [13] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound22733 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env22734 : List Nat := [2,4,8,0,11,1,9,15,1,14,1,1,2,0,1,8,1,1,15,0,0,11,0,3,3,1,0,1,1,0,5,10,14,10,0,1]

theorem envBound22734 : H12AffineFastState.Bounded env22734 := by
  intro p hp
  have h : env22734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22733_22734 : H12AffineEnvironment.transform 7 15 env22733 = env22734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env22733 == env22734) = true)

def env22735 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,65536,1345,262144,1025,32769,4097,4194304,64,103444,8328,16,4456709,1344,4097,1073741824,4117,4294967296,257,4299265214,4177,512]

theorem envBound22735 : H12AffineFastState.Bounded env22735 := by
  intro p hp
  have h : env22735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22717_22735 : H12AffineEnvironment.transform 13 1345 env22717 = env22735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env22717 == env22735) = true)

theorem identity22735 : scanCanonicalize (H12AffineFastState.compose env22735 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound22735 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env22736 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,1296,32768,65536,1296,262144,1025,32769,4097,4194304,17,103444,8328,16,4456709,1297,4097,1073741824,4117,4294967296,257,4299265214,4096,512]

theorem envBound22736 : H12AffineFastState.Bounded env22736 := by
  intro p hp
  have h : env22736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22735_22736 : H12AffineEnvironment.transform 5 17 env22735 = env22736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env22735 == env22736) = true)

def env22737 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,4194304,147521,16777216,8328,672784,21352529,16384,676864,1073741824,16876544,4294967296,256,4315938986,545041,512]

theorem envBound22737 : H12AffineFastState.Bounded env22737 := by
  intro p hp
  have h : env22737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22301_22737 : H12AffineEnvironment.transform 22 147521 env22301 = env22737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147521 env22301 == env22737) = true)

def env22738 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,524288,32769,4097,4194304,17665,16777216,8328,541008,21352529,16384,545088,1073741824,16876544,4294967296,256,4315938986,545041,512]

theorem envBound22738 : H12AffineFastState.Bounded env22738 := by
  intro p hp
  have h : env22738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22737_22738 : H12AffineEnvironment.transform 16 1344 env22737 = env22738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env22737 == env22738) = true)

def env22739 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32769,4097,4194304,17664,16777216,8328,541009,21352529,16384,545089,1073741824,16876544,4294967296,256,4315938986,545041,512]

theorem envBound22739 : H12AffineFastState.Bounded env22739 := by
  intro p hp
  have h : env22739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22737_22739 : H12AffineEnvironment.transform 16 1345 env22737 = env22739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env22737 == env22739) = true)

theorem identity22739 : scanCanonicalize (H12AffineFastState.compose env22739 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(18+1) ^^^ 21585) := by decide +kernel

theorem selectedBound22739 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env22740 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,21585,32769,4097,4194304,17664,16777216,8328,5376,21352529,16384,1296,1073741824,16876544,4294967296,256,4315938986,1344,512]

theorem envBound22740 : H12AffineFastState.Bounded env22740 := by
  intro p hp
  have h : env22740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22739_22740 : H12AffineEnvironment.transform 18 21585 env22739 = env22740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21585 env22739 == env22740) = true)

theorem identity22740 : scanCanonicalize (H12AffineFastState.compose env22740 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 4177) := by decide +kernel

theorem selectedBound22740 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env22741 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,1345,262144,1024,32769,4097,4194304,5457,16777216,8328,5376,21331968,4177,1296,1073741824,16876544,4294967296,256,4315938986,1344,512]

theorem envBound22741 : H12AffineFastState.Bounded env22741 := by
  intro p hp
  have h : env22741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22740_22741 : H12AffineEnvironment.transform 13 4177 env22740 = env22741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env22740 == env22741) = true)

def env22742 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,65536,1345,262144,1024,32769,1345,4194304,17,16777216,8328,64,21331968,1297,1296,1073741824,16876544,4294967296,256,4315938986,1344,512]

theorem envBound22742 : H12AffineFastState.Bounded env22742 := by
  intro p hp
  have h : env22742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22741_22742 : H12AffineEnvironment.transform 11 1344 env22741 = env22742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env22741 == env22742) = true)

theorem identity22742 : scanCanonicalize (H12AffineFastState.compose env22742 (packedSelected [0,7,20] rootPS)) = affineNative (2^(23+1) ^^^ 98565) := by decide +kernel

theorem selectedBound22742 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env22743 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,65536,1345,262144,1024,32769,1345,4194304,17,98565,8328,64,4456709,1297,1296,1073741824,1285,4294967296,256,4299260335,1344,512]

theorem envBound22743 : H12AffineFastState.Bounded env22743 := by
  intro p hp
  have h : env22743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22742_22743 : H12AffineEnvironment.transform 23 98565 env22742 = env22743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98565 env22742 == env22743) = true)

theorem identity22743 : scanCanonicalize (H12AffineFastState.compose env22743 (packedSelected [3,5,10] rootPS)) = affineNative (2^(31+1) ^^^ 1073842179) := by decide +kernel

theorem selectedBound22743 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env22744 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,65536,1345,262144,1024,32769,1345,4194304,17,98565,8328,64,4456709,1297,1296,1073741824,1285,1073842179,256,1077938604,1344,512]

theorem envBound22744 : H12AffineFastState.Bounded env22744 := by
  intro p hp
  have h : env22744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22743_22744 : H12AffineEnvironment.transform 31 1073842179 env22743 = env22744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1073842179 env22743 == env22744) = true)

theorem identity22744 : scanCanonicalize (H12AffineFastState.compose env22744 (packedSelected [1,12,13] rootPS)) = affineNative (2^(8+1) ^^^ 397) := by decide +kernel

theorem selectedBound22744 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env22745 : List Nat := [2,4,8,16,32,64,128,256,397,1024,2048,1344,8192,1297,32768,65536,1345,262144,1024,32769,1345,4194304,17,98565,8328,64,4456709,1297,1296,1073741824,1285,1073842179,256,1077938604,1344,397]

theorem envBound22745 : H12AffineFastState.Bounded env22745 := by
  intro p hp
  have h : env22745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22744_22745 : H12AffineEnvironment.transform 8 397 env22744 = env22745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 397 env22744 == env22745) = true)

theorem identity22745 : scanCanonicalize (H12AffineFastState.compose env22745 (packedSelected [3,15,17] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound22745 : packedSelected [3,15,17] rootPS < 2^1333 := by decide +kernel

def env22746 : List Nat := [2,4,8,16,32,64,128,4,137,1024,2048,1092,8192,1045,32768,65536,1093,262144,1024,32769,1093,4194304,17,98305,8328,64,4456449,1045,1044,1073741824,1025,1073842179,4,1077938344,1092,137]

theorem envBound22746 : H12AffineFastState.Bounded env22746 := by
  intro p hp
  have h : env22746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22745_22746 : H12AffineEnvironment.transform 7 4 env22745 = env22746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env22745 == env22746) = true)

def env22747 : List Nat := [2,4,8,16,32,16,128,4,137,1024,2048,1044,8192,1045,32768,65536,1045,262144,1024,32769,1045,4194304,17,98305,8328,16,4456449,1045,1044,1073741824,1025,1073842179,4,1077938344,1044,137]

theorem envBound22747 : H12AffineFastState.Bounded env22747 := by
  intro p hp
  have h : env22747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22746_22747 : H12AffineEnvironment.transform 5 16 env22746 = env22747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env22746 == env22747) = true)

theorem identity22747 : scanCanonicalize (H12AffineFastState.compose env22747 (packedSelected [1,3,5] rootPS)) = affineNative (2^(21+1) ^^^ 362634) := by decide +kernel

theorem selectedBound22747 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env22748 : List Nat := [2,4,8,16,32,16,128,4,137,1024,2048,1044,8192,1045,32768,65536,1045,262144,1024,32769,1045,362634,17,98305,8328,16,100491,1045,1044,1073741824,1025,1073842179,4,1074102306,1044,137]

theorem envBound22748 : H12AffineFastState.Bounded env22748 := by
  intro p hp
  have h : env22748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22747_22748 : H12AffineEnvironment.transform 21 362634 env22747 = env22748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 362634 env22747 == env22748) = true)

theorem identity22748 : scanCanonicalize (H12AffineFastState.compose env22748 (packedSelected [1,3,8] rootPS)) = affineNative (2^(29+1) ^^^ 360587) := by decide +kernel

theorem selectedBound22748 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env22749 : List Nat := [2,4,8,16,32,16,128,4,137,1024,2048,1044,8192,1045,32768,65536,1045,262144,1024,32769,1045,362634,17,98305,8328,16,100491,1045,1044,360587,1025,264328,4,169,1044,137]

theorem envBound22749 : H12AffineFastState.Bounded env22749 := by
  intro p hp
  have h : env22749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22748_22749 : H12AffineEnvironment.transform 29 360587 env22748 = env22749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 360587 env22748 == env22749) = true)

theorem identity22749 : scanCanonicalize (H12AffineFastState.compose env22749 (packedSelected [1,3] rootPS)) = affineNative (2^(15+1) ^^^ 8355) := by decide +kernel

theorem selectedBound22749 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env22750 : List Nat := [2,4,8,16,32,16,128,4,137,1024,2048,1044,8192,1045,32768,8355,1045,262144,1024,32769,1045,305193,17,41122,8328,16,43048,1045,1044,303144,1025,264328,4,169,1044,137]

theorem envBound22750 : H12AffineFastState.Bounded env22750 := by
  intro p hp
  have h : env22750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22749_22750 : H12AffineEnvironment.transform 15 8355 env22749 = env22750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8355 env22749 == env22750) = true)

theorem identity22750 : scanCanonicalize (H12AffineFastState.compose env22750 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 43048) := by decide +kernel

theorem selectedBound22750 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env22751 : List Nat := [2,4,8,16,32,16,128,4,137,1024,2048,1044,8192,1045,32768,8355,1045,43048,1024,32769,1045,1,17,41122,8328,16,43048,1045,1044,2048,1025,41120,4,169,1044,137]

theorem envBound22751 : H12AffineFastState.Bounded env22751 := by
  intro p hp
  have h : env22751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22750_22751 : H12AffineEnvironment.transform 17 43048 env22750 = env22751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43048 env22750 == env22751) = true)

theorem identity22751 : scanCanonicalize (H12AffineFastState.compose env22751 (packedSelected [0,6] rootPS)) = affineNative (2^(14+1) ^^^ 2081) := by decide +kernel

theorem selectedBound22751 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env22752 : List Nat := [2,4,8,16,32,16,128,4,137,1024,2048,1044,8192,1045,2081,8355,1045,8201,1024,2080,1045,1,17,10371,8328,16,8201,1045,1044,2048,1025,10369,4,169,1044,137]

theorem envBound22752 : H12AffineFastState.Bounded env22752 := by
  intro p hp
  have h : env22752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22751_22752 : H12AffineEnvironment.transform 14 2081 env22751 = env22752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2081 env22751 == env22752) = true)

def env22753 : List Nat := [2,4,8,16,32,16,128,4,137,1024,2048,1044,2056,1045,2081,2219,1045,2049,1024,2080,1045,1,17,139,2176,16,2049,1045,1044,2048,1025,137,4,169,1044,137]

theorem envBound22753 : H12AffineFastState.Bounded env22753 := by
  intro p hp
  have h : env22753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22752_22753 : H12AffineEnvironment.transform 12 2056 env22752 = env22753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2056 env22752 == env22753) = true)

theorem identity22753 : scanCanonicalize (H12AffineFastState.compose env22753 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 169) := by decide +kernel

theorem selectedBound22753 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22754 : List Nat := [2,4,8,16,32,16,128,4,137,1024,169,1044,161,1045,136,2,1045,168,1024,137,1045,1,17,139,41,16,168,1045,1044,169,1025,137,4,169,1044,137]

theorem envBound22754 : H12AffineFastState.Bounded env22754 := by
  intro p hp
  have h : env22754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22753_22754 : H12AffineEnvironment.transform 10 169 env22753 = env22754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 169 env22753 == env22754) = true)

theorem identity22754 : scanCanonicalize (H12AffineFastState.compose env22754 (packedSelected [0,2] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound22754 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env22755 : List Nat := [2,4,8,16,32,16,128,4,137,53,169,33,161,32,136,2,32,168,53,137,32,1,17,139,41,16,168,32,33,169,52,137,4,169,33,137]

theorem envBound22755 : H12AffineFastState.Bounded env22755 := by
  intro p hp
  have h : env22755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22754_22755 : H12AffineEnvironment.transform 9 53 env22754 = env22755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env22754 == env22755) = true)

def env22756 : List Nat := [2,4,8,16,0,16,128,4,137,21,137,1,129,0,136,2,0,136,21,137,0,1,17,139,9,16,136,0,1,137,20,137,4,137,1,137]

theorem envBound22756 : H12AffineFastState.Bounded env22756 := by
  intro p hp
  have h : env22756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22755_22756 : H12AffineEnvironment.transform 4 0 env22755 = env22756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22755 == env22756) = true)

theorem identity22756 : scanCanonicalize (H12AffineFastState.compose env22756 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound22756 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22757 : List Nat := [2,4,8,1,0,1,128,4,137,4,137,1,129,0,136,2,0,136,4,137,0,1,0,139,9,1,136,0,1,137,5,137,4,137,1,137]

theorem envBound22757 : H12AffineFastState.Bounded env22757 := by
  intro p hp
  have h : env22757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22756_22757 : H12AffineEnvironment.transform 3 1 env22756 = env22757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env22756 == env22757) = true)

def leafEnv22757 : List Nat := [2,4,8,1,0,1,128,4,137,4,137,1,129,0,136,2,0,136,4,137,0,1,0,139,4,9,1,1,136,0,1,137,5,137,4,137,5,139,1,137,0,1,1]

def active22757 : List Nat := [0,1,2,6]

def tree22757 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22757 : H12WitnessSearch.Good tree22757 := H12GlobalWitnessIndex.good

theorem leafIdentity22757 : H12AffineFastState.composeSystem env22757 rootObs = leafEnv22757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22757 rootObs == leafEnv22757) = true)

theorem terminalChecked22757 : H12PackedTerminal.terminalCheckFast leafEnv22757 active22757 tree22757 = true := by decide +kernel

def env22758 : List Nat := [2,4,8,16,1,16,128,4,137,20,136,0,128,1,136,2,1,137,20,137,1,1,17,139,8,16,137,1,0,136,21,137,4,136,0,137]

theorem envBound22758 : H12AffineFastState.Bounded env22758 := by
  intro p hp
  have h : env22758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22755_22758 : H12AffineEnvironment.transform 4 1 env22755 = env22758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22755 == env22758) = true)

theorem identity22758 : scanCanonicalize (H12AffineFastState.compose env22758 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound22758 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22759 : List Nat := [2,4,8,16,1,16,25,4,16,20,17,0,25,1,17,2,1,16,20,16,1,1,17,18,8,16,16,1,0,17,21,16,4,17,0,16]

theorem envBound22759 : H12AffineFastState.Bounded env22759 := by
  intro p hp
  have h : env22759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22758_22759 : H12AffineEnvironment.transform 6 25 env22758 = env22759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env22758 == env22759) = true)

def leafEnv22759 : List Nat := [2,4,8,16,1,16,25,4,16,20,17,0,25,1,17,2,1,16,20,16,1,1,17,18,20,8,1,16,16,1,0,17,21,16,4,17,5,18,0,16,0,0,1]

def active22759 : List Nat := [0,1,2,3]

def tree22759 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22759 : H12WitnessSearch.Good tree22759 := H12GlobalWitnessIndex.good

theorem leafIdentity22759 : H12AffineFastState.composeSystem env22759 rootObs = leafEnv22759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22759 rootObs == leafEnv22759) = true)

theorem terminalChecked22759 : H12PackedTerminal.terminalCheckFast leafEnv22759 active22759 tree22759 = true := by decide +kernel

def env22760 : List Nat := [2,4,8,16,32,16,128,4,137,1024,2048,1044,2057,1045,2081,2218,1045,2048,1024,2080,1045,1,17,138,2177,16,2048,1045,1044,2048,1025,136,4,169,1044,137]

theorem envBound22760 : H12AffineFastState.Bounded env22760 := by
  intro p hp
  have h : env22760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22752_22760 : H12AffineEnvironment.transform 12 2057 env22752 = env22760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2057 env22752 == env22760) = true)

theorem identity22760 : scanCanonicalize (H12AffineFastState.compose env22760 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1213) := by decide +kernel

theorem selectedBound22760 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22761 : List Nat := [2,4,8,16,32,16,128,4,137,1024,1213,1044,1204,1045,1180,1047,1045,1213,1024,1181,1045,1,17,138,1084,16,1213,1045,1044,1213,1025,136,4,169,1044,137]

theorem envBound22761 : H12AffineFastState.Bounded env22761 := by
  intro p hp
  have h : env22761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22760_22761 : H12AffineEnvironment.transform 10 1213 env22760 = env22761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1213 env22760 == env22761) = true)

def env22762 : List Nat := [2,4,8,16,32,17,128,4,137,1024,2048,1045,8192,1045,32768,65536,1044,262144,1024,32769,1044,4194304,17,98305,8328,17,4456449,1045,1044,1073741824,1025,1073842179,4,1077938344,1045,137]

theorem envBound22762 : H12AffineFastState.Bounded env22762 := by
  intro p hp
  have h : env22762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22746_22762 : H12AffineEnvironment.transform 5 17 env22746 = env22762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env22746 == env22762) = true)

theorem identity22762 : scanCanonicalize (H12AffineFastState.compose env22762 (packedSelected [1,3,5] rootPS)) = affineNative (2^(29+1) ^^^ 43049) := by decide +kernel

theorem selectedBound22762 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env22763 : List Nat := [2,4,8,16,32,17,128,4,137,1024,2048,1045,8192,1045,32768,65536,1044,262144,1024,32769,1044,4194304,17,98305,8328,17,4456449,1045,1044,43049,1025,73770,4,4235393,1045,137]

theorem envBound22763 : H12AffineFastState.Bounded env22763 := by
  intro p hp
  have h : env22763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22762_22763 : H12AffineEnvironment.transform 29 43049 env22762 = env22763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 43049 env22762 == env22763) = true)

def env22764 : List Nat := [2,4,8,16,32,17,128,4,137,20,2048,1,8192,1,32768,65536,0,262144,20,32769,0,4194304,17,98305,8328,17,4456449,1,0,43049,21,73770,4,4235393,1,137]

theorem envBound22764 : H12AffineFastState.Bounded env22764 := by
  intro p hp
  have h : env22764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22763_22764 : H12AffineEnvironment.transform 9 20 env22763 = env22764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env22763 == env22764) = true)

theorem identity22764 : scanCanonicalize (H12AffineFastState.compose env22764 (packedSelected [1] rootPS)) = affineNative (2^(21+1) ^^^ 296960) := by decide +kernel

theorem selectedBound22764 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22765 : List Nat := [2,4,8,16,32,17,128,4,137,20,2048,1,8192,1,32768,65536,0,262144,20,32769,0,296960,17,98305,8328,17,34817,1,0,43049,21,73770,4,272513,1,137]

theorem envBound22765 : H12AffineFastState.Bounded env22765 := by
  intro p hp
  have h : env22765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22764_22765 : H12AffineEnvironment.transform 21 296960 env22764 = env22765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 296960 env22764 == env22765) = true)

theorem identity22765 : scanCanonicalize (H12AffineFastState.compose env22765 (packedSelected [3] rootPS)) = affineNative (2^(17+1) ^^^ 43048) := by decide +kernel

theorem selectedBound22765 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env22766 : List Nat := [2,4,8,16,32,17,128,4,137,20,2048,1,8192,1,32768,65536,0,43048,20,32769,0,8232,17,98305,8328,17,34817,1,0,43049,21,73770,4,32937,1,137]

theorem envBound22766 : H12AffineFastState.Bounded env22766 := by
  intro p hp
  have h : env22766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22765_22766 : H12AffineEnvironment.transform 17 43048 env22765 = env22766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43048 env22765 == env22766) = true)

theorem identity22766 : scanCanonicalize (H12AffineFastState.compose env22766 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound22766 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env22767 : List Nat := [2,4,8,16,32,17,128,4,137,20,2048,1,8192,1,0,65536,0,10280,20,1,0,8232,17,65537,8328,17,2049,1,0,10281,21,73770,4,169,1,137]

theorem envBound22767 : H12AffineFastState.Bounded env22767 := by
  intro p hp
  have h : env22767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22766_22767 : H12AffineEnvironment.transform 14 0 env22766 = env22767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env22766 == env22767) = true)

def env22768 : List Nat := [2,4,8,16,32,17,128,4,137,20,2048,1,8,1,0,65536,0,2080,20,1,0,32,17,65537,128,17,2049,1,0,2081,21,65570,4,169,1,137]

theorem envBound22768 : H12AffineFastState.Bounded env22768 := by
  intro p hp
  have h : env22768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22767_22768 : H12AffineEnvironment.transform 12 8 env22767 = env22768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env22767 == env22768) = true)

theorem identity22768 : scanCanonicalize (H12AffineFastState.compose env22768 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound22768 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22769 : List Nat := [2,4,8,16,32,17,56,4,49,20,2048,1,8,1,0,65536,0,2080,20,1,0,32,17,65537,56,17,2049,1,0,2081,21,65570,4,17,1,49]

theorem envBound22769 : H12AffineFastState.Bounded env22769 := by
  intro p hp
  have h : env22769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22768_22769 : H12AffineEnvironment.transform 6 56 env22768 = env22769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env22768 == env22769) = true)

theorem identity22769 : scanCanonicalize (H12AffineFastState.compose env22769 (packedSelected [0,4] rootPS)) = affineNative (2^(15+1) ^^^ 50) := by decide +kernel

theorem selectedBound22769 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env22770 : List Nat := [2,4,8,16,32,17,56,4,49,20,2048,1,8,1,0,50,0,2080,20,1,0,32,17,51,56,17,2049,1,0,2081,21,16,4,17,1,49]

theorem envBound22770 : H12AffineFastState.Bounded env22770 := by
  intro p hp
  have h : env22770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22769_22770 : H12AffineEnvironment.transform 15 50 env22769 = env22770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 50 env22769 == env22770) = true)

def env22771 : List Nat := [2,4,8,16,32,17,56,4,49,20,0,1,8,1,0,50,0,32,20,1,0,32,17,51,56,17,1,1,0,33,21,16,4,17,1,49]

theorem envBound22771 : H12AffineFastState.Bounded env22771 := by
  intro p hp
  have h : env22771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22770_22771 : H12AffineEnvironment.transform 10 0 env22770 = env22771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env22770 == env22771) = true)

theorem identity22771 : scanCanonicalize (H12AffineFastState.compose env22771 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound22771 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22772 : List Nat := [2,4,8,16,1,17,25,4,16,20,0,1,8,1,0,19,0,1,20,1,0,1,17,18,25,17,1,1,0,0,21,16,4,17,1,16]

theorem envBound22772 : H12AffineFastState.Bounded env22772 := by
  intro p hp
  have h : env22772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22771_22772 : H12AffineEnvironment.transform 4 1 env22771 = env22772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22771 == env22772) = true)

def leafEnv22772 : List Nat := [2,4,8,16,1,17,25,4,16,20,0,1,8,1,0,19,0,1,20,1,0,1,17,18,20,25,1,17,1,1,0,0,21,16,4,17,5,3,1,16,0,0,1]

def active22772 : List Nat := [0,1,2,3]

def tree22772 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22772 : H12WitnessSearch.Good tree22772 := H12GlobalWitnessIndex.good

theorem leafIdentity22772 : H12AffineFastState.composeSystem env22772 rootObs = leafEnv22772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22772 rootObs == leafEnv22772) = true)

theorem terminalChecked22772 : H12PackedTerminal.terminalCheckFast leafEnv22772 active22772 tree22772 = true := by decide +kernel

def env22773 : List Nat := [2,4,8,16,32,17,56,4,49,20,1,1,8,1,0,50,0,33,20,1,0,32,17,51,56,17,0,1,0,32,21,16,4,17,1,49]

theorem envBound22773 : H12AffineFastState.Bounded env22773 := by
  intro p hp
  have h : env22773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22770_22773 : H12AffineEnvironment.transform 10 1 env22770 = env22773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env22770 == env22773) = true)

def env22774 : List Nat := [2,4,8,16,32,17,128,4,137,20,2048,1,9,1,0,65536,0,2081,20,1,0,33,17,65537,129,17,2049,1,0,2080,21,65571,4,169,1,137]

theorem envBound22774 : H12AffineFastState.Bounded env22774 := by
  intro p hp
  have h : env22774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22767_22774 : H12AffineEnvironment.transform 12 9 env22767 = env22774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env22767 == env22774) = true)

theorem identity22774 : scanCanonicalize (H12AffineFastState.compose env22774 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 155) := by decide +kernel

theorem selectedBound22774 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22775 : List Nat := [2,4,8,16,32,17,128,4,137,20,2048,1,9,1,0,155,0,2081,20,1,0,33,17,154,129,17,2049,1,0,2080,21,184,4,169,1,137]

theorem envBound22775 : H12AffineFastState.Bounded env22775 := by
  intro p hp
  have h : env22775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22774_22775 : H12AffineEnvironment.transform 15 155 env22774 = env22775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 155 env22774 == env22775) = true)

def env22776 : List Nat := [2,4,8,16,32,17,128,4,137,21,2048,0,8192,0,32768,65536,1,262144,21,32769,1,4194304,17,98305,8328,17,4456449,0,1,43049,20,73770,4,4235393,0,137]

theorem envBound22776 : H12AffineFastState.Bounded env22776 := by
  intro p hp
  have h : env22776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22763_22776 : H12AffineEnvironment.transform 9 21 env22763 = env22776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env22763 == env22776) = true)

theorem identity22776 : scanCanonicalize (H12AffineFastState.compose env22776 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 138) := by decide +kernel

theorem selectedBound22776 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22777 : List Nat := [2,4,8,16,32,17,128,4,137,21,2048,0,8192,0,32768,138,1,262144,21,32769,1,4194304,17,32907,8328,17,4456449,0,1,43049,20,8352,4,4235393,0,137]

theorem envBound22777 : H12AffineFastState.Bounded env22777 := by
  intro p hp
  have h : env22777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22776_22777 : H12AffineEnvironment.transform 15 138 env22776 = env22777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 138 env22776 == env22777) = true)

theorem identity22777 : scanCanonicalize (H12AffineFastState.compose env22777 (packedSelected [3] rootPS)) = affineNative (2^(21+1) ^^^ 264192) := by decide +kernel

theorem selectedBound22777 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env22778 : List Nat := [2,4,8,16,32,17,128,4,137,21,2048,0,8192,0,32768,138,1,262144,21,32769,1,264192,17,32907,8328,17,2049,0,1,43049,20,8352,4,305281,0,137]

theorem envBound22778 : H12AffineFastState.Bounded env22778 := by
  intro p hp
  have h : env22778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22777_22778 : H12AffineEnvironment.transform 21 264192 env22777 = env22778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 264192 env22777 == env22778) = true)

theorem identity22778 : scanCanonicalize (H12AffineFastState.compose env22778 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 43048) := by decide +kernel

theorem selectedBound22778 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env22779 : List Nat := [2,4,8,16,32,17,128,4,137,21,2048,0,8192,0,32768,138,1,43048,21,32769,1,41000,17,32907,8328,17,2049,0,1,43049,20,8352,4,169,0,137]

theorem envBound22779 : H12AffineFastState.Bounded env22779 := by
  intro p hp
  have h : env22779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22778_22779 : H12AffineEnvironment.transform 17 43048 env22778 = env22779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43048 env22778 == env22779) = true)

def env22780 : List Nat := [2,4,8,16,32,17,128,4,137,21,2048,0,160,0,32768,138,1,34952,21,32769,1,32904,17,32907,40,17,2049,0,1,34953,20,0,4,169,0,137]

theorem envBound22780 : H12AffineFastState.Bounded env22780 := by
  intro p hp
  have h : env22780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22779_22780 : H12AffineEnvironment.transform 12 160 env22779 = env22780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env22779 == env22780) = true)

theorem identity22780 : scanCanonicalize (H12AffineFastState.compose env22780 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound22780 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22781 : List Nat := [2,4,8,16,32,17,56,4,49,21,2048,0,24,0,32768,50,1,34864,21,32769,1,32816,17,32819,40,17,2049,0,1,34865,20,0,4,17,0,49]

theorem envBound22781 : H12AffineFastState.Bounded env22781 := by
  intro p hp
  have h : env22781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22780_22781 : H12AffineEnvironment.transform 6 56 env22780 = env22781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env22780 == env22781) = true)

def env22782 : List Nat := [2,4,8,16,32,17,56,4,49,21,2048,0,24,0,2080,50,1,16,21,2081,1,2064,17,2067,40,17,2049,0,1,17,20,0,4,17,0,49]

theorem envBound22782 : H12AffineFastState.Bounded env22782 := by
  intro p hp
  have h : env22782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22781_22782 : H12AffineEnvironment.transform 14 2080 env22781 = env22782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2080 env22781 == env22782) = true)

def env22783 : List Nat := [2,4,8,16,32,17,56,4,49,21,2048,0,24,0,2081,50,1,17,21,2080,1,2065,17,2066,40,17,2049,0,1,16,20,0,4,17,0,49]

theorem envBound22783 : H12AffineFastState.Bounded env22783 := by
  intro p hp
  have h : env22783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22781_22783 : H12AffineEnvironment.transform 14 2081 env22781 = env22783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2081 env22781 == env22783) = true)

theorem identity22783 : scanCanonicalize (H12AffineFastState.compose env22783 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound22783 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env22784 : List Nat := [2,4,8,16,32,17,56,4,49,21,16,0,24,0,49,50,1,17,21,48,1,1,17,2,40,17,17,0,1,16,20,0,4,17,0,49]

theorem envBound22784 : H12AffineFastState.Bounded env22784 := by
  intro p hp
  have h : env22784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22783_22784 : H12AffineEnvironment.transform 10 16 env22783 = env22784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env22783 == env22784) = true)

def env22785 : List Nat := [2,4,8,16,0,17,24,4,17,21,16,0,24,0,17,18,1,17,21,16,1,1,17,2,8,17,17,0,1,16,20,0,4,17,0,17]

theorem envBound22785 : H12AffineFastState.Bounded env22785 := by
  intro p hp
  have h : env22785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22784_22785 : H12AffineEnvironment.transform 4 0 env22784 = env22785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22784 == env22785) = true)

theorem identity22785 : scanCanonicalize (H12AffineFastState.compose env22785 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound22785 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22786 : List Nat := [2,4,8,1,0,0,9,4,0,4,1,0,9,0,0,3,1,0,4,1,1,1,0,2,8,0,0,0,1,1,5,0,4,0,0,0]

theorem envBound22786 : H12AffineFastState.Bounded env22786 := by
  intro p hp
  have h : env22786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22785_22786 : H12AffineEnvironment.transform 3 1 env22785 = env22786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env22785 == env22786) = true)

def leafEnv22786 : List Nat := [2,4,8,1,0,0,9,4,0,4,1,0,9,0,0,3,1,0,4,1,1,1,0,2,4,8,1,0,0,0,1,1,5,0,4,0,5,3,0,0,0,1,1]

def active22786 : List Nat := [0,1,2]

def tree22786 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22786 : H12WitnessSearch.Good tree22786 := H12GlobalWitnessIndex.good

theorem leafIdentity22786 : H12AffineFastState.composeSystem env22786 rootObs = leafEnv22786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22786 rootObs == leafEnv22786) = true)

theorem terminalChecked22786 : H12PackedTerminal.terminalCheckFast leafEnv22786 active22786 tree22786 = true := by decide +kernel

def env22787 : List Nat := [2,4,8,16,1,17,25,4,16,21,16,0,24,0,16,19,1,17,21,17,1,1,17,2,9,17,17,0,1,16,20,0,4,17,0,16]

theorem envBound22787 : H12AffineFastState.Bounded env22787 := by
  intro p hp
  have h : env22787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22784_22787 : H12AffineEnvironment.transform 4 1 env22784 = env22787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22784 == env22787) = true)

def env22788 : List Nat := [2,4,8,16,32,17,128,4,137,21,2048,0,161,0,32768,138,1,34953,21,32769,1,32905,17,32907,41,17,2049,0,1,34952,20,1,4,169,0,137]

theorem envBound22788 : H12AffineFastState.Bounded env22788 := by
  intro p hp
  have h : env22788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22779_22788 : H12AffineEnvironment.transform 12 161 env22779 = env22788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env22779 == env22788) = true)

theorem identity22788 : scanCanonicalize (H12AffineFastState.compose env22788 (packedSelected [2] rootPS)) = affineNative (2^(14+1) ^^^ 17) := by decide +kernel

theorem selectedBound22788 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22789 : List Nat := [2,4,8,16,32,17,128,4,137,21,2048,0,161,0,17,138,1,2200,21,16,1,152,17,154,41,17,2049,0,1,2201,20,1,4,169,0,137]

theorem envBound22789 : H12AffineFastState.Bounded env22789 := by
  intro p hp
  have h : env22789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22788_22789 : H12AffineEnvironment.transform 14 17 env22788 = env22789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 17 env22788 == env22789) = true)

def env22790 : List Nat := [2,4,8,16,32,17,128,4,137,21,48,0,161,0,17,138,1,168,21,16,1,152,17,154,41,17,49,0,1,169,20,1,4,169,0,137]

theorem envBound22790 : H12AffineFastState.Bounded env22790 := by
  intro p hp
  have h : env22790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22789_22790 : H12AffineEnvironment.transform 10 48 env22789 = env22790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env22789 == env22790) = true)

theorem identity22790 : scanCanonicalize (H12AffineFastState.compose env22790 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound22790 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env22791 : List Nat := [2,4,8,16,32,17,25,4,16,21,48,0,56,0,17,19,1,49,21,16,1,1,17,3,41,17,49,0,1,48,20,1,4,48,0,16]

theorem envBound22791 : H12AffineFastState.Bounded env22791 := by
  intro p hp
  have h : env22791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22790_22791 : H12AffineEnvironment.transform 6 25 env22790 = env22791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env22790 == env22791) = true)

def env22792 : List Nat := [2,4,8,16,0,17,25,4,16,21,16,0,24,0,17,19,1,17,21,16,1,1,17,3,9,17,17,0,1,16,20,1,4,16,0,16]

theorem envBound22792 : H12AffineFastState.Bounded env22792 := by
  intro p hp
  have h : env22792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22791_22792 : H12AffineEnvironment.transform 4 0 env22791 = env22792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22791 == env22792) = true)

theorem identity22792 : scanCanonicalize (H12AffineFastState.compose env22792 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound22792 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22793 : List Nat := [2,4,8,1,0,0,8,4,1,4,1,0,9,0,0,2,1,0,4,1,1,1,0,3,9,0,0,0,1,1,5,1,4,1,0,1]

theorem envBound22793 : H12AffineFastState.Bounded env22793 := by
  intro p hp
  have h : env22793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22792_22793 : H12AffineEnvironment.transform 3 1 env22792 = env22793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env22792 == env22793) = true)

def leafEnv22793 : List Nat := [2,4,8,1,0,0,8,4,1,4,1,0,9,0,0,2,1,0,4,1,1,1,0,3,4,9,1,0,0,0,1,1,5,1,4,1,5,3,0,1,0,1,1]

def active22793 : List Nat := [0,1,2]

def tree22793 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22793 : H12WitnessSearch.Good tree22793 := H12GlobalWitnessIndex.good

theorem leafIdentity22793 : H12AffineFastState.composeSystem env22793 rootObs = leafEnv22793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22793 rootObs == leafEnv22793) = true)

theorem terminalChecked22793 : H12PackedTerminal.terminalCheckFast leafEnv22793 active22793 tree22793 = true := by decide +kernel

def env22794 : List Nat := [2,4,8,16,1,17,25,4,16,21,17,0,25,0,17,19,1,16,21,16,1,1,17,3,8,17,16,0,1,17,20,1,4,17,0,16]

theorem envBound22794 : H12AffineFastState.Bounded env22794 := by
  intro p hp
  have h : env22794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22791_22794 : H12AffineEnvironment.transform 4 1 env22791 = env22794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22791 == env22794) = true)

def env22795 : List Nat := [2,4,8,16,32,17,128,4,137,21,49,0,161,0,17,138,1,169,21,16,1,152,17,154,41,17,48,0,1,168,20,1,4,169,0,137]

theorem envBound22795 : H12AffineFastState.Bounded env22795 := by
  intro p hp
  have h : env22795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22789_22795 : H12AffineEnvironment.transform 10 49 env22789 = env22795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env22789 == env22795) = true)

def env22796 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,65536,1345,262144,1024,32769,1344,4194304,16,16777216,8328,65,21331968,1296,1296,1073741824,16876544,4294967296,256,4315938986,1344,512]

theorem envBound22796 : H12AffineFastState.Bounded env22796 := by
  intro p hp
  have h : env22796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22741_22796 : H12AffineEnvironment.transform 11 1345 env22741 = env22796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env22741 == env22796) = true)

theorem identity22796 : scanCanonicalize (H12AffineFastState.compose env22796 (packedSelected [13,21] rootPS)) = affineNative (2^(31+1) ^^^ 4194440) := by decide +kernel

theorem selectedBound22796 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env22797 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,65536,1345,262144,1024,32769,1344,4194304,16,16777216,8328,65,21331968,1296,1296,1073741824,16876544,4194440,256,16777250,1344,512]

theorem envBound22797 : H12AffineFastState.Bounded env22797 := by
  intro p hp
  have h : env22797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22796_22797 : H12AffineEnvironment.transform 31 4194440 env22796 = env22797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 4194440 env22796 == env22797) = true)

def env22798 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,128,1296,32768,65536,1345,262144,1024,32769,1344,4194304,16,16777216,8,65,21331968,1296,1296,1073741824,16876544,4194440,256,16777250,1344,512]

theorem envBound22798 : H12AffineFastState.Bounded env22798 := by
  intro p hp
  have h : env22798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22797_22798 : H12AffineEnvironment.transform 12 128 env22797 = env22798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 128 env22797 == env22798) = true)

theorem identity22798 : scanCanonicalize (H12AffineFastState.compose env22798 (packedSelected [3,5,24] rootPS)) = affineNative (2^(23+1) ^^^ 98952) := by decide +kernel

theorem selectedBound22798 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env22799 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,128,1296,32768,65536,1345,262144,1024,32769,1344,4194304,16,98952,8,65,4457096,1296,1296,1073741824,1672,4194440,256,98986,1344,512]

theorem envBound22799 : H12AffineFastState.Bounded env22799 := by
  intro p hp
  have h : env22799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22798_22799 : H12AffineEnvironment.transform 23 98952 env22798 = env22799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98952 env22798 == env22799) = true)

def env22800 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,128,1296,648,65536,1345,262144,1024,649,1344,4194304,16,65536,8,65,4457096,1296,1296,1073741824,1672,4194440,256,65570,1344,512]

theorem envBound22800 : H12AffineFastState.Bounded env22800 := by
  intro p hp
  have h : env22800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22799_22800 : H12AffineEnvironment.transform 14 648 env22799 = env22800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 648 env22799 == env22800) = true)

theorem identity22800 : scanCanonicalize (H12AffineFastState.compose env22800 (packedSelected [1,8,28] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound22800 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env22801 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,128,1296,1,65536,1345,262144,1024,0,1344,4194304,16,65536,8,65,4456449,1296,1296,1073741824,1025,4194440,256,65570,1344,137]

theorem envBound22801 : H12AffineFastState.Bounded env22801 := by
  intro p hp
  have h : env22801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22800_22801 : H12AffineEnvironment.transform 8 137 env22800 = env22801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env22800 == env22801) = true)

def env22802 : List Nat := [2,4,8,16,0,64,128,256,137,1024,2048,1345,128,1296,1,65536,1345,262144,1024,0,1344,4194304,16,65536,8,65,4456449,1296,1296,1073741824,1025,4194440,256,65538,1344,137]

theorem envBound22802 : H12AffineFastState.Bounded env22802 := by
  intro p hp
  have h : env22802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22801_22802 : H12AffineEnvironment.transform 4 0 env22801 = env22802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22801 == env22802) = true)

theorem identity22802 : scanCanonicalize (H12AffineFastState.compose env22802 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 463) := by decide +kernel

end H12CloudChart2