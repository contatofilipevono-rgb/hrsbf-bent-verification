import H12CloudChart2Data119

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env29620 : List Nat := [2,4,4,0,32,64,37,256,324,1024,2048,0,295,1281,1319,36,1376,0,320,1318,0,357,33,36,1095,1313,290,1313,1280,3141,294,258,257,1280,1345,1028]

theorem envBound29620 : H12AffineFastState.Bounded env29620 := by
  intro p hp
  have h : env29620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29619_29620 : H12AffineEnvironment.transform 2 4 env29619 = env29620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env29619 == env29620) = true)

theorem identity29620 : scanCanonicalize (H12AffineFastState.compose env29620 (packedSelected [2,3,5,7,8,9,10,11,13,16,17,18] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound29620 : packedSelected [2,3,5,7,8,9,10,11,13,16,17,18] rootPS < 2^1333 := by decide +kernel

def env29621 : List Nat := [2,4,4,0,32,64,37,256,324,5,2048,0,295,260,290,36,357,0,320,291,0,357,33,36,66,292,290,292,261,2112,294,258,257,261,324,1]

theorem envBound29621 : H12AffineFastState.Bounded env29621 := by
  intro p hp
  have h : env29621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29620_29621 : H12AffineEnvironment.transform 9 5 env29620 = env29621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env29620 == env29621) = true)

theorem identity29621 : scanCanonicalize (H12AffineFastState.compose env29621 (packedSelected [0,1,2,7,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound29621 : packedSelected [0,1,2,7,10,11] rootPS < 2^1333 := by decide +kernel

def env29622 : List Nat := [2,4,4,0,32,64,37,256,324,5,292,0,295,260,290,36,357,0,320,291,0,357,33,36,66,292,290,292,261,356,294,258,257,261,324,1]

theorem envBound29622 : H12AffineFastState.Bounded env29622 := by
  intro p hp
  have h : env29622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29621_29622 : H12AffineEnvironment.transform 10 292 env29621 = env29622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env29621 == env29622) = true)

theorem identity29622 : scanCanonicalize (H12AffineFastState.compose env29622 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound29622 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env29623 : List Nat := [2,4,4,0,1,64,4,256,324,5,261,0,262,260,259,5,324,0,320,258,0,324,0,5,66,261,259,261,261,325,263,258,257,261,324,1]

theorem envBound29623 : H12AffineFastState.Bounded env29623 := by
  intro p hp
  have h : env29623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29622_29623 : H12AffineEnvironment.transform 4 1 env29622 = env29623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env29622 == env29623) = true)

theorem identity29623 : scanCanonicalize (H12AffineFastState.compose env29623 (packedSelected [0,3,4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound29623 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env29624 : List Nat := [2,4,4,0,1,64,4,4,64,5,1,0,2,0,7,5,64,0,68,6,0,64,0,5,66,1,7,1,1,65,3,6,5,1,64,1]

theorem envBound29624 : H12AffineFastState.Bounded env29624 := by
  intro p hp
  have h : env29624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29623_29624 : H12AffineEnvironment.transform 7 4 env29623 = env29624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env29623 == env29624) = true)

theorem identity29624 : scanCanonicalize (H12AffineFastState.compose env29624 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 7) := by decide +kernel

theorem selectedBound29624 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29625 : List Nat := [2,4,4,0,1,7,4,4,7,5,1,0,2,0,7,5,7,0,3,6,0,7,0,5,5,1,7,1,1,6,3,6,5,1,7,1]

theorem envBound29625 : H12AffineFastState.Bounded env29625 := by
  intro p hp
  have h : env29625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29624_29625 : H12AffineEnvironment.transform 5 7 env29624 = env29625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 7 env29624 == env29625) = true)

def env29626 : List Nat := [2,4,8,0,32,64,37,256,324,1024,2048,0,299,1281,1319,41,1389,13,320,1318,0,361,44,41,1095,1324,302,1324,1280,3144,294,271,257,1280,1345,1028]

theorem envBound29626 : H12AffineFastState.Bounded env29626 := by
  intro p hp
  have h : env29626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29618_29626 : H12AffineEnvironment.transform 15 41 env29618 = env29626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41 env29618 == env29626) = true)

theorem identity29626 : scanCanonicalize (H12AffineFastState.compose env29626 (packedSelected [0,1,3,4,5,10,11,13,15,16,18,19,21,23] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound29626 : packedSelected [0,1,3,4,5,10,11,13,15,16,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env29627 : List Nat := [2,4,3,0,32,64,37,256,324,1024,2048,0,288,1281,1319,34,1382,6,320,1318,0,354,39,34,1095,1319,293,1319,1280,3139,294,260,257,1280,1345,1028]

theorem envBound29627 : H12AffineFastState.Bounded env29627 := by
  intro p hp
  have h : env29627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29626_29627 : H12AffineEnvironment.transform 2 3 env29626 = env29627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env29626 == env29627) = true)

theorem identity29627 : scanCanonicalize (H12AffineFastState.compose env29627 (packedSelected [0,1,2,5,8,9,10,13,15,17] rootPS)) = affineNative (2^(5+1) ^^^ 38) := by decide +kernel

theorem selectedBound29627 : packedSelected [0,1,2,5,8,9,10,13,15,17] rootPS < 2^1333 := by decide +kernel

def env29628 : List Nat := [2,4,3,0,32,38,37,256,290,1024,2048,0,288,1281,1319,34,1280,6,294,1318,0,260,39,34,1057,1319,293,1319,1280,3109,294,260,257,1280,1319,1028]

theorem envBound29628 : H12AffineFastState.Bounded env29628 := by
  intro p hp
  have h : env29628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29627_29628 : H12AffineEnvironment.transform 5 38 env29627 = env29628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 38 env29627 == env29628) = true)

theorem identity29628 : scanCanonicalize (H12AffineFastState.compose env29628 (packedSelected [0,1,2,3,5,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound29628 : packedSelected [0,1,2,3,5,9,10] rootPS < 2^1333 := by decide +kernel

def env29629 : List Nat := [2,4,3,0,32,38,37,256,290,5,2048,0,288,260,290,34,261,6,294,291,0,260,39,34,36,290,293,290,261,2080,294,260,257,261,290,1]

theorem envBound29629 : H12AffineFastState.Bounded env29629 := by
  intro p hp
  have h : env29629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29628_29629 : H12AffineEnvironment.transform 9 5 env29628 = env29629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env29628 == env29629) = true)

theorem identity29629 : scanCanonicalize (H12AffineFastState.compose env29629 (packedSelected [0,1,4] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound29629 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env29630 : List Nat := [2,4,3,0,32,38,37,256,290,5,33,0,288,260,290,34,261,6,294,291,0,260,39,34,36,290,293,290,261,1,294,260,257,261,290,1]

theorem envBound29630 : H12AffineFastState.Bounded env29630 := by
  intro p hp
  have h : env29630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29629_29630 : H12AffineEnvironment.transform 10 33 env29629 = env29630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env29629 == env29630) = true)

theorem identity29630 : scanCanonicalize (H12AffineFastState.compose env29630 (packedSelected [0,1,7] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound29630 : packedSelected [0,1,7] rootPS < 2^1333 := by decide +kernel

def env29631 : List Nat := [2,4,3,0,32,38,37,36,6,5,33,0,4,32,6,34,33,6,2,7,0,32,39,34,36,6,1,6,33,1,2,32,37,33,6,1]

theorem envBound29631 : H12AffineFastState.Bounded env29631 := by
  intro p hp
  have h : env29631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29630_29631 : H12AffineEnvironment.transform 7 36 env29630 = env29631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env29630 == env29631) = true)

theorem identity29631 : scanCanonicalize (H12AffineFastState.compose env29631 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound29631 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29632 : List Nat := [2,4,3,0,0,6,5,4,6,5,1,0,4,0,6,2,1,6,2,7,0,0,7,2,4,6,1,6,1,1,2,0,5,1,6,1]

theorem envBound29632 : H12AffineFastState.Bounded env29632 := by
  intro p hp
  have h : env29632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29631_29632 : H12AffineEnvironment.transform 4 0 env29631 = env29632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env29631 == env29632) = true)

theorem identity29632 : scanCanonicalize (H12AffineFastState.compose env29632 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound29632 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29633 : List Nat := [2,3,3,0,0,1,2,3,1,2,1,0,3,0,1,2,1,1,2,0,0,0,0,2,3,1,1,1,1,1,2,0,2,1,1,1]

theorem envBound29633 : H12AffineFastState.Bounded env29633 := by
  intro p hp
  have h : env29633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29632_29633 : H12AffineEnvironment.transform 1 3 env29632 = env29633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env29632 == env29633) = true)

def env29634 : List Nat := [2,4,8,1,32,64,128,256,325,1024,2048,0,8192,1280,9229,65536,74863,65665,320,9228,0,461,74031,65537,9673,74798,303,74799,1281,77130,8205,65830,257,1280,1345,1029]

theorem envBound29634 : H12AffineFastState.Bounded env29634 := by
  intro p hp
  have h : env29634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29598_29634 : H12AffineEnvironment.transform 3 1 env29598 = env29634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env29598 == env29634) = true)

theorem identity29634 : scanCanonicalize (H12AffineFastState.compose env29634 (packedSelected [1,8,28] rootPS)) = affineNative (2^(9+1) ^^^ 34) := by decide +kernel

theorem selectedBound29634 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env29635 : List Nat := [2,4,8,1,32,64,128,256,325,34,2048,0,8192,290,8239,65536,73805,65665,320,8238,0,461,74031,65537,8683,73740,303,73741,291,76136,8205,65830,257,290,355,39]

theorem envBound29635 : H12AffineFastState.Bounded env29635 := by
  intro p hp
  have h : env29635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29634_29635 : H12AffineEnvironment.transform 9 34 env29634 = env29635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 34 env29634 == env29635) = true)

def env29636 : List Nat := [2,4,8,1,32,64,128,224,165,34,2048,0,8192,194,8239,65536,73805,65665,160,8238,0,45,73935,65537,8203,73740,207,73741,195,75912,8205,65734,225,194,131,39]

theorem envBound29636 : H12AffineFastState.Bounded env29636 := by
  intro p hp
  have h : env29636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29635_29636 : H12AffineEnvironment.transform 7 224 env29635 = env29636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 224 env29635 == env29636) = true)

theorem identity29636 : scanCanonicalize (H12AffineFastState.compose env29636 (packedSelected [2,4,5,8,9,10,12,16,23,32,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 8268) := by decide +kernel

theorem selectedBound29636 : packedSelected [2,4,5,8,9,10,12,16,23,32,38,41] rootPS < 2^1333 := by decide +kernel

def env29637 : List Nat := [2,4,8,1,32,64,128,224,165,34,2048,0,8192,194,8239,8268,1,8397,160,8238,0,45,131,8269,8203,64,207,65,195,2244,8205,8330,225,194,131,39]

theorem envBound29637 : H12AffineFastState.Bounded env29637 := by
  intro p hp
  have h : env29637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29636_29637 : H12AffineEnvironment.transform 15 8268 env29636 = env29637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8268 env29636 == env29637) = true)

theorem identity29637 : scanCanonicalize (H12AffineFastState.compose env29637 (packedSelected [1,4,8,9,18,20,21,23,24] rootPS)) = affineNative (2^(6+1) ^^^ 105) := by decide +kernel

theorem selectedBound29637 : packedSelected [1,4,8,9,18,20,21,23,24] rootPS < 2^1333 := by decide +kernel

def env29638 : List Nat := [2,4,8,1,32,64,105,9,76,34,2048,0,8192,43,8239,8268,1,8228,73,8238,0,45,106,8269,8203,64,38,65,42,2093,8205,8291,8,43,106,39]

theorem envBound29638 : H12AffineFastState.Bounded env29638 := by
  intro p hp
  have h : env29638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29637_29638 : H12AffineEnvironment.transform 6 105 env29637 = env29638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 105 env29637 == env29638) = true)

theorem identity29638 : scanCanonicalize (H12AffineFastState.compose env29638 (packedSelected [1,3,4,5,8,9,15,16] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound29638 : packedSelected [1,3,4,5,8,9,15,16] rootPS < 2^1333 := by decide +kernel

def env29639 : List Nat := [2,4,8,1,12,64,69,9,76,14,2048,0,8192,7,8195,8268,1,8200,73,8194,0,1,70,8269,8203,64,10,65,6,2049,8205,8271,8,7,70,11]

theorem envBound29639 : H12AffineFastState.Bounded env29639 := by
  intro p hp
  have h : env29639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29638_29639 : H12AffineEnvironment.transform 4 12 env29638 = env29639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env29638 == env29639) = true)

theorem identity29639 : scanCanonicalize (H12AffineFastState.compose env29639 (packedSelected [1,7,9,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 2115) := by decide +kernel

theorem selectedBound29639 : packedSelected [1,7,9,10,11] rootPS < 2^1333 := by decide +kernel

def env29640 : List Nat := [2,4,8,1,12,64,69,9,76,14,2048,0,2115,7,2112,2063,1,2123,73,2113,0,1,70,2062,2120,64,10,65,6,2049,2126,2060,8,7,70,11]

theorem envBound29640 : H12AffineFastState.Bounded env29640 := by
  intro p hp
  have h : env29640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29639_29640 : H12AffineEnvironment.transform 12 2115 env29639 = env29640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2115 env29639 == env29640) = true)

theorem identity29640 : scanCanonicalize (H12AffineFastState.compose env29640 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 75) := by decide +kernel

theorem selectedBound29640 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env29641 : List Nat := [2,4,8,1,12,64,69,9,76,14,75,0,8,7,11,68,1,0,73,10,0,1,70,69,3,64,10,65,6,74,5,71,8,7,70,11]

theorem envBound29641 : H12AffineFastState.Bounded env29641 := by
  intro p hp
  have h : env29641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29640_29641 : H12AffineEnvironment.transform 10 75 env29640 = env29641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 75 env29640 == env29641) = true)

theorem identity29641 : scanCanonicalize (H12AffineFastState.compose env29641 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound29641 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29642 : List Nat := [2,4,8,1,12,1,4,9,13,14,10,0,8,7,11,5,1,0,8,10,0,1,7,4,3,1,10,0,6,11,5,6,8,7,7,11]

theorem envBound29642 : H12AffineFastState.Bounded env29642 := by
  intro p hp
  have h : env29642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29641_29642 : H12AffineEnvironment.transform 5 1 env29641 = env29642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env29641 == env29642) = true)

theorem identity29642 : scanCanonicalize (H12AffineFastState.compose env29642 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound29642 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env29643 : List Nat := [2,3,8,1,11,1,3,9,10,9,10,0,8,0,11,2,1,0,8,10,0,1,0,3,3,1,10,0,1,11,2,1,8,0,0,11]

theorem envBound29643 : H12AffineFastState.Bounded env29643 := by
  intro p hp
  have h : env29643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29642_29643 : H12AffineEnvironment.transform 1 3 env29642 = env29643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env29642 == env29643) = true)

theorem identity29643 : scanCanonicalize (H12AffineFastState.compose env29643 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound29643 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29644 : List Nat := [2,3,1,1,2,1,3,0,3,0,3,0,1,0,2,2,1,0,1,3,0,1,0,3,3,1,3,0,1,2,2,1,1,0,0,2]

theorem envBound29644 : H12AffineFastState.Bounded env29644 := by
  intro p hp
  have h : env29644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29643_29644 : H12AffineEnvironment.transform 2 1 env29643 = env29644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env29643 == env29644) = true)

theorem identity29644 : scanCanonicalize (H12AffineFastState.compose env29644 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound29644 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29645 : List Nat := [0,1,1,1,0,1,1,0,1,0,1,0,1,0,0,0,1,0,1,1,0,1,0,1,1,1,1,0,1,0,0,1,1,0,0,0]

theorem envBound29645 : H12AffineFastState.Bounded env29645 := by
  intro p hp
  have h : env29645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29644_29645 : H12AffineEnvironment.transform 0 0 env29644 = env29645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env29644 == env29645) = true)

def env29646 : List Nat := [2,4,8,1,32,64,128,225,164,34,2048,0,8192,195,8239,65536,73805,65665,161,8238,0,44,73934,65537,8202,73740,206,73741,194,75913,8205,65735,224,195,130,39]

theorem envBound29646 : H12AffineFastState.Bounded env29646 := by
  intro p hp
  have h : env29646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29635_29646 : H12AffineEnvironment.transform 7 225 env29635 = env29646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 225 env29635 == env29646) = true)

theorem identity29646 : scanCanonicalize (H12AffineFastState.compose env29646 (packedSelected [2,4,5,8,9,10,12,16,23,32,38,41] rootPS)) = affineNative (2^(12+1) ^^^ 73) := by decide +kernel

theorem selectedBound29646 : packedSelected [2,4,5,8,9,10,12,16,23,32,38,41] rootPS < 2^1333 := by decide +kernel

def env29647 : List Nat := [2,4,8,1,32,64,128,225,164,34,2048,0,73,195,102,65536,65540,65665,161,103,0,44,65671,65537,67,65605,206,65604,194,67776,68,65735,224,195,130,39]

theorem envBound29647 : H12AffineFastState.Bounded env29647 := by
  intro p hp
  have h : env29647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29646_29647 : H12AffineEnvironment.transform 12 73 env29646 = env29647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env29646 == env29647) = true)

theorem identity29647 : scanCanonicalize (H12AffineFastState.compose env29647 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 225) := by decide +kernel

theorem selectedBound29647 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env29648 : List Nat := [2,4,8,1,32,64,128,225,164,34,2048,0,73,195,102,225,229,96,161,103,0,44,102,224,67,164,206,165,194,2081,68,38,224,195,130,39]

theorem envBound29648 : H12AffineFastState.Bounded env29648 := by
  intro p hp
  have h : env29648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29647_29648 : H12AffineEnvironment.transform 15 225 env29647 = env29648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 225 env29647 == env29648) = true)

theorem identity29648 : scanCanonicalize (H12AffineFastState.compose env29648 (packedSelected [0,2,3,4,5,7,9,10,16,18] rootPS)) = affineNative (2^(10+1) ^^^ 97) := by decide +kernel

theorem selectedBound29648 : packedSelected [0,2,3,4,5,7,9,10,16,18] rootPS < 2^1333 := by decide +kernel

def env29649 : List Nat := [2,4,8,1,32,64,128,225,164,34,97,0,73,195,102,225,229,96,161,103,0,44,102,224,67,164,206,165,194,64,68,38,224,195,130,39]

theorem envBound29649 : H12AffineFastState.Bounded env29649 := by
  intro p hp
  have h : env29649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29648_29649 : H12AffineEnvironment.transform 10 97 env29648 = env29649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 97 env29648 == env29649) = true)

theorem identity29649 : scanCanonicalize (H12AffineFastState.compose env29649 (packedSelected [2,3,10] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound29649 : packedSelected [2,3,10] rootPS < 2^1333 := by decide +kernel

def env29650 : List Nat := [2,4,8,1,32,64,2,99,38,34,97,0,73,65,102,99,103,96,35,103,0,44,102,98,67,38,76,39,64,64,68,38,98,65,0,39]

theorem envBound29650 : H12AffineFastState.Bounded env29650 := by
  intro p hp
  have h : env29650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29649_29650 : H12AffineEnvironment.transform 6 2 env29649 = env29650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env29649 == env29650) = true)

theorem identity29650 : scanCanonicalize (H12AffineFastState.compose env29650 (packedSelected [1,2] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound29650 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env29651 : List Nat := [2,4,8,1,32,11,2,40,38,34,42,0,2,10,45,40,44,43,35,44,0,44,45,41,8,38,7,39,11,11,15,38,41,10,0,39]

theorem envBound29651 : H12AffineFastState.Bounded env29651 := by
  intro p hp
  have h : env29651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29650_29651 : H12AffineEnvironment.transform 5 11 env29650 = env29651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env29650 == env29651) = true)

theorem identity29651 : scanCanonicalize (H12AffineFastState.compose env29651 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 15) := by decide +kernel

theorem selectedBound29651 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env29652 : List Nat := [2,4,8,1,15,11,2,7,9,13,5,0,2,10,2,7,3,4,12,3,0,3,2,6,8,9,7,8,11,11,15,9,6,10,0,8]

theorem envBound29652 : H12AffineFastState.Bounded env29652 := by
  intro p hp
  have h : env29652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29651_29652 : H12AffineEnvironment.transform 4 15 env29651 = env29652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 15 env29651 == env29652) = true)

def env29653 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,0,8192,1297,9244,65536,74863,65665,320,9245,0,476,74046,65552,9673,74798,318,74814,1296,77130,8205,65830,257,1280,1345,1045]

theorem envBound29653 : H12AffineFastState.Bounded env29653 := by
  intro p hp
  have h : env29653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29597_29653 : H12AffineEnvironment.transform 8 341 env29597 = env29653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env29597 == env29653) = true)

def env29654 : List Nat := [2,4,8,0,32,64,128,256,325,1024,2048,0,8192,1281,9228,65536,74863,65665,320,9229,0,460,74030,65536,9673,74798,302,74798,1280,77130,8205,65830,257,1280,1345,1029]

theorem envBound29654 : H12AffineFastState.Bounded env29654 := by
  intro p hp
  have h : env29654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29653_29654 : H12AffineEnvironment.transform 3 0 env29653 = env29654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env29653 == env29654) = true)

theorem identity29654 : scanCanonicalize (H12AffineFastState.compose env29654 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 5) := by decide +kernel

theorem selectedBound29654 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env29655 : List Nat := [2,4,8,0,32,64,128,256,325,1024,2048,0,8192,1281,9228,5,9322,132,320,9229,0,460,8491,5,9673,9259,302,9259,1280,11599,8205,291,257,1280,1345,1029]

theorem envBound29655 : H12AffineFastState.Bounded env29655 := by
  intro p hp
  have h : env29655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29654_29655 : H12AffineEnvironment.transform 15 5 env29654 = env29655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5 env29654 == env29655) = true)

def env29656 : List Nat := [2,4,4,0,32,64,128,256,325,1024,2048,0,8192,1281,9216,5,9318,132,320,9217,0,448,8487,5,9669,9255,290,9255,1280,11587,8193,291,257,1280,1345,1029]

theorem envBound29656 : H12AffineFastState.Bounded env29656 := by
  intro p hp
  have h : env29656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29655_29656 : H12AffineEnvironment.transform 2 4 env29655 = env29656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env29655 == env29656) = true)

theorem identity29656 : scanCanonicalize (H12AffineFastState.compose env29656 (packedSelected [1,2,4,7,9,10,11,15,17,21,23,24,27] rootPS)) = affineNative (2^(12+1) ^^^ 2209) := by decide +kernel

theorem selectedBound29656 : packedSelected [1,2,4,7,9,10,11,15,17,21,23,24,27] rootPS < 2^1333 := by decide +kernel

def env29657 : List Nat := [2,4,4,0,32,64,128,256,325,1024,2048,0,2209,1281,3233,5,3271,132,320,3232,0,448,2438,5,3428,3206,290,3206,1280,1506,2208,291,257,1280,1345,1029]

theorem envBound29657 : H12AffineFastState.Bounded env29657 := by
  intro p hp
  have h : env29657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29656_29657 : H12AffineEnvironment.transform 12 2209 env29656 = env29657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2209 env29656 == env29657) = true)

theorem identity29657 : scanCanonicalize (H12AffineFastState.compose env29657 (packedSelected [2,4,9,10,15,18,19] rootPS)) = affineNative (2^(9+1) ^^^ 99) := by decide +kernel

theorem selectedBound29657 : packedSelected [2,4,9,10,15,18,19] rootPS < 2^1333 := by decide +kernel

def env29658 : List Nat := [2,4,4,0,32,64,128,256,325,99,2048,0,2209,354,2242,5,2212,132,320,2243,0,448,2438,5,2311,2277,290,2277,355,385,2208,291,257,355,290,102]

theorem envBound29658 : H12AffineFastState.Bounded env29658 := by
  intro p hp
  have h : env29658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29657_29658 : H12AffineEnvironment.transform 9 99 env29657 = env29658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 99 env29657 == env29658) = true)

theorem identity29658 : scanCanonicalize (H12AffineFastState.compose env29658 (packedSelected [1,3,8,10,15] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound29658 : packedSelected [1,3,8,10,15] rootPS < 2^1333 := by decide +kernel

def env29659 : List Nat := [2,4,4,0,32,64,5,256,325,99,2048,0,2084,354,2119,5,2081,1,320,2118,0,325,2307,5,2311,2144,290,2144,355,260,2085,291,257,355,290,102]

theorem envBound29659 : H12AffineFastState.Bounded env29659 := by
  intro p hp
  have h : env29659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29658_29659 : H12AffineEnvironment.transform 6 5 env29658 = env29659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env29658 == env29659) = true)

theorem identity29659 : scanCanonicalize (H12AffineFastState.compose env29659 (packedSelected [4,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 98) := by decide +kernel

theorem selectedBound29659 : packedSelected [4,8,9] rootPS < 2^1333 := by decide +kernel

def env29660 : List Nat := [2,4,4,0,32,64,5,98,39,99,2048,0,2084,0,2119,5,2081,1,34,2118,0,39,2145,5,2149,2144,64,2144,1,102,2085,65,99,1,64,102]

theorem envBound29660 : H12AffineFastState.Bounded env29660 := by
  intro p hp
  have h : env29660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29659_29660 : H12AffineEnvironment.transform 7 98 env29659 = env29660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 98 env29659 == env29660) = true)

theorem identity29660 : scanCanonicalize (H12AffineFastState.compose env29660 (packedSelected [0,2,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 64) := by decide +kernel

theorem selectedBound29660 : packedSelected [0,2,5,7] rootPS < 2^1333 := by decide +kernel

def env29661 : List Nat := [2,4,4,0,32,64,5,98,39,99,64,0,100,0,7,5,97,1,34,6,0,39,33,5,37,32,64,32,1,102,101,65,99,1,64,102]

theorem envBound29661 : H12AffineFastState.Bounded env29661 := by
  intro p hp
  have h : env29661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29660_29661 : H12AffineEnvironment.transform 10 64 env29660 = env29661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 64 env29660 == env29661) = true)

theorem identity29661 : scanCanonicalize (H12AffineFastState.compose env29661 (packedSelected [0,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound29661 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env29662 : List Nat := [2,4,4,0,1,64,5,67,6,66,64,0,69,0,7,5,64,1,3,6,0,6,0,5,4,1,64,1,1,71,68,65,66,1,64,71]

theorem envBound29662 : H12AffineFastState.Bounded env29662 := by
  intro p hp
  have h : env29662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29661_29662 : H12AffineEnvironment.transform 4 1 env29661 = env29662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env29661 == env29662) = true)

theorem identity29662 : scanCanonicalize (H12AffineFastState.compose env29662 (packedSelected [1,2] rootPS)) = affineNative (2^(5+1) ^^^ 7) := by decide +kernel

theorem selectedBound29662 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env29663 : List Nat := [2,4,4,0,1,7,5,4,6,5,7,0,2,0,7,5,7,1,3,6,0,6,0,5,4,1,7,1,1,0,3,6,5,1,7,0]

theorem envBound29663 : H12AffineFastState.Bounded env29663 := by
  intro p hp
  have h : env29663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29662_29663 : H12AffineEnvironment.transform 5 7 env29662 = env29663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 7 env29662 == env29663) = true)

theorem identity29663 : scanCanonicalize (H12AffineFastState.compose env29663 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound29663 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29664 : List Nat := [2,3,3,0,1,0,2,3,1,2,0,0,2,0,0,2,0,1,3,1,0,1,0,2,3,1,0,1,1,0,3,1,2,1,0,0]

theorem envBound29664 : H12AffineFastState.Bounded env29664 := by
  intro p hp
  have h : env29664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29663_29664 : H12AffineEnvironment.transform 1 3 env29663 = env29664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env29663 == env29664) = true)

theorem identity29664 : scanCanonicalize (H12AffineFastState.compose env29664 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound29664 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29665 : List Nat := [0,1,1,0,1,0,0,1,1,0,0,0,0,0,0,0,0,1,1,1,0,1,0,0,1,1,0,1,1,0,1,1,0,1,0,0]

theorem envBound29665 : H12AffineFastState.Bounded env29665 := by
  intro p hp
  have h : env29665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29664_29665 : H12AffineEnvironment.transform 0 0 env29664 = env29665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env29664 == env29665) = true)

def env29666 : List Nat := [2,4,5,0,32,64,128,256,325,1024,2048,0,8192,1281,9217,5,9319,132,320,9216,0,449,8486,5,9668,9254,291,9254,1280,11586,8192,291,257,1280,1345,1029]

theorem envBound29666 : H12AffineFastState.Bounded env29666 := by
  intro p hp
  have h : env29666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29655_29666 : H12AffineEnvironment.transform 2 5 env29655 = env29666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env29655 == env29666) = true)

theorem identity29666 : scanCanonicalize (H12AffineFastState.compose env29666 (packedSelected [1,2,4,7,9,10,11,15,17,21,23,24,27] rootPS)) = affineNative (2^(12+1) ^^^ 3202) := by decide +kernel

theorem selectedBound29666 : packedSelected [1,2,4,7,9,10,11,15,17,21,23,24,27] rootPS < 2^1333 := by decide +kernel

def env29667 : List Nat := [2,4,5,0,32,64,128,256,325,1024,2048,0,3202,1281,2179,5,2277,132,320,2178,0,449,3492,5,2374,2212,291,2212,1280,448,3202,291,257,1280,1345,1029]

theorem envBound29667 : H12AffineFastState.Bounded env29667 := by
  intro p hp
  have h : env29667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29666_29667 : H12AffineEnvironment.transform 12 3202 env29666 = env29667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3202 env29666 == env29667) = true)

theorem identity29667 : scanCanonicalize (H12AffineFastState.compose env29667 (packedSelected [0,1,5,7,8,10,11,13,18,19,21,23] rootPS)) = affineNative (2^(9+1) ^^^ 99) := by decide +kernel

theorem selectedBound29667 : packedSelected [0,1,5,7,8,10,11,13,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env29668 : List Nat := [2,4,5,0,32,64,128,256,325,99,2048,0,2273,354,2179,5,2277,132,320,2178,0,449,2503,5,2374,2212,291,2212,355,448,2273,291,257,355,290,102]

theorem envBound29668 : H12AffineFastState.Bounded env29668 := by
  intro p hp
  have h : env29668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29667_29668 : H12AffineEnvironment.transform 9 99 env29667 = env29668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 99 env29667 == env29668) = true)

theorem identity29668 : scanCanonicalize (H12AffineFastState.compose env29668 (packedSelected [0,1,5,7,8,10,11,12,15,16,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 357) := by decide +kernel

theorem selectedBound29668 : packedSelected [0,1,5,7,8,10,11,12,15,16,17,18] rootPS < 2^1333 := by decide +kernel

def env29669 : List Nat := [2,4,5,0,32,64,128,256,325,99,357,0,388,354,486,5,384,132,320,487,0,449,162,5,35,449,291,449,355,448,388,291,257,355,290,102]

theorem envBound29669 : H12AffineFastState.Bounded env29669 := by
  intro p hp
  have h : env29669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29668_29669 : H12AffineEnvironment.transform 10 357 env29668 = env29669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 357 env29668 == env29669) = true)

theorem identity29669 : scanCanonicalize (H12AffineFastState.compose env29669 (packedSelected [0,1,2,3,8,9,10,11] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound29669 : packedSelected [0,1,2,3,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env29670 : List Nat := [2,4,5,0,32,64,35,256,325,99,357,0,295,354,325,5,291,39,320,324,0,354,1,5,35,354,291,354,355,355,295,291,257,355,290,102]

theorem envBound29670 : H12AffineFastState.Bounded env29670 := by
  intro p hp
  have h : env29670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29669_29670 : H12AffineEnvironment.transform 6 35 env29669 = env29670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env29669 == env29670) = true)

theorem identity29670 : scanCanonicalize (H12AffineFastState.compose env29670 (packedSelected [1,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound29670 : packedSelected [1,5,8] rootPS < 2^1333 := by decide +kernel

def env29671 : List Nat := [2,4,5,0,32,64,35,37,96,99,64,0,2,71,96,5,6,39,101,97,0,71,1,5,35,71,6,71,70,70,2,6,36,70,7,102]

theorem envBound29671 : H12AffineFastState.Bounded env29671 := by
  intro p hp
  have h : env29671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29670_29671 : H12AffineEnvironment.transform 7 37 env29670 = env29671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env29670 == env29671) = true)

theorem identity29671 : scanCanonicalize (H12AffineFastState.compose env29671 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 38) := by decide +kernel

theorem selectedBound29671 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env29672 : List Nat := [2,4,5,0,32,38,35,37,6,5,38,0,2,33,6,5,6,39,3,7,0,33,1,5,35,33,6,33,32,32,2,6,36,32,7,0]

theorem envBound29672 : H12AffineFastState.Bounded env29672 := by
  intro p hp
  have h : env29672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29671_29672 : H12AffineEnvironment.transform 5 38 env29671 = env29672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 38 env29671 == env29672) = true)

def env29673 : List Nat := [2,4,8,1,32,64,128,256,324,1024,2048,0,8192,1280,9229,65536,74863,65665,320,9228,0,461,74031,65537,9673,74798,303,74799,1281,77130,8205,65830,257,1280,1345,1028]

theorem envBound29673 : H12AffineFastState.Bounded env29673 := by
  intro p hp
  have h : env29673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29653_29673 : H12AffineEnvironment.transform 3 1 env29653 = env29673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env29653 == env29673) = true)

theorem identity29673 : scanCanonicalize (H12AffineFastState.compose env29673 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 9484) := by decide +kernel

theorem selectedBound29673 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env29674 : List Nat := [2,4,8,1,32,64,128,256,324,1024,2048,0,8192,1280,9229,9484,355,9613,320,9228,0,461,1059,9485,9673,290,303,291,1281,2118,8205,9258,257,1280,1345,1028]

theorem envBound29674 : H12AffineFastState.Bounded env29674 := by
  intro p hp
  have h : env29674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29673_29674 : H12AffineEnvironment.transform 15 9484 env29673 = env29674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9484 env29673 == env29674) = true)

def env29675 : List Nat := [2,4,8,1,32,64,128,256,324,1024,2048,0,1284,1280,265,8,355,137,320,264,0,461,1059,9,205,290,303,291,1281,2118,1289,302,257,1280,1345,1028]

theorem envBound29675 : H12AffineFastState.Bounded env29675 := by
  intro p hp
  have h : env29675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29674_29675 : H12AffineEnvironment.transform 12 1284 env29674 = env29675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1284 env29674 == env29675) = true)

theorem identity29675 : scanCanonicalize (H12AffineFastState.compose env29675 (packedSelected [1,2,4,7,9,10,11,15,17,21,23,24,27] rootPS)) = affineNative (2^(10+1) ^^^ 1449) := by decide +kernel

theorem selectedBound29675 : packedSelected [1,2,4,7,9,10,11,15,17,21,23,24,27] rootPS < 2^1333 := by decide +kernel

def env29676 : List Nat := [2,4,8,1,32,64,128,256,324,1024,1449,0,1284,1280,265,8,355,137,320,264,0,461,1059,9,205,290,303,291,1281,1519,1289,302,257,1280,1345,1028]

theorem envBound29676 : H12AffineFastState.Bounded env29676 := by
  intro p hp
  have h : env29676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29675_29676 : H12AffineEnvironment.transform 10 1449 env29675 = env29676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1449 env29675 == env29676) = true)

theorem identity29676 : scanCanonicalize (H12AffineFastState.compose env29676 (packedSelected [4,8,9,10,11,13,17,19,20,32] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound29676 : packedSelected [4,8,9,10,11,13,17,19,20,32] rootPS < 2^1333 := by decide +kernel

def env29677 : List Nat := [2,4,8,1,32,64,128,256,324,5,428,0,257,261,265,8,355,137,320,264,0,461,38,9,205,290,303,291,260,490,268,302,257,261,324,1]

theorem envBound29677 : H12AffineFastState.Bounded env29677 := by
  intro p hp
  have h : env29677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29676_29677 : H12AffineEnvironment.transform 9 5 env29676 = env29677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env29676 == env29677) = true)

theorem identity29677 : scanCanonicalize (H12AffineFastState.compose env29677 (packedSelected [2,4,8,9,11,12,15,17] rootPS)) = affineNative (2^(7+1) ^^^ 78) := by decide +kernel

theorem selectedBound29677 : packedSelected [2,4,8,9,11,12,15,17] rootPS < 2^1333 := by decide +kernel

def env29678 : List Nat := [2,4,8,1,32,64,128,78,10,5,226,0,79,75,71,8,45,137,14,70,0,131,38,9,205,108,97,109,74,164,66,96,79,75,10,1]

theorem envBound29678 : H12AffineFastState.Bounded env29678 := by
  intro p hp
  have h : env29678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29677_29678 : H12AffineEnvironment.transform 7 78 env29677 = env29678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 78 env29677 == env29678) = true)

theorem identity29678 : scanCanonicalize (H12AffineFastState.compose env29678 (packedSelected [0,2,3,5,7,10,11] rootPS)) = affineNative (2^(6+1) ^^^ 101) := by decide +kernel

theorem selectedBound29678 : packedSelected [0,2,3,5,7,10,11] rootPS < 2^1333 := by decide +kernel

def env29679 : List Nat := [2,4,8,1,32,64,101,78,10,5,7,0,79,75,71,8,45,108,14,70,0,102,38,9,40,108,97,109,74,65,66,96,79,75,10,1]

theorem envBound29679 : H12AffineFastState.Bounded env29679 := by
  intro p hp
  have h : env29679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29678_29679 : H12AffineEnvironment.transform 6 101 env29678 = env29679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 101 env29678 == env29679) = true)

theorem identity29679 : scanCanonicalize (H12AffineFastState.compose env29679 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound29679 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env29680 : List Nat := [2,4,2,1,32,64,101,68,0,5,7,0,69,65,71,2,39,102,4,70,0,102,38,3,34,102,97,103,64,65,66,96,69,65,0,1]

theorem envBound29680 : H12AffineFastState.Bounded env29680 := by
  intro p hp
  have h : env29680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29679_29680 : H12AffineEnvironment.transform 2 2 env29679 = env29680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env29679 == env29680) = true)

theorem identity29680 : scanCanonicalize (H12AffineFastState.compose env29680 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 5) := by decide +kernel

theorem selectedBound29680 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env29681 : List Nat := [2,4,2,1,5,64,64,68,0,5,7,0,69,65,71,2,2,67,4,70,0,67,3,3,7,67,68,66,64,65,66,69,69,65,0,1]

theorem envBound29681 : H12AffineFastState.Bounded env29681 := by
  intro p hp
  have h : env29681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29680_29681 : H12AffineEnvironment.transform 4 5 env29680 = env29681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 5 env29680 == env29681) = true)

theorem identity29681 : scanCanonicalize (H12AffineFastState.compose env29681 (packedSelected [2,3] rootPS)) = affineNative (2^(5+1) ^^^ 6) := by decide +kernel

theorem selectedBound29681 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env29682 : List Nat := [2,4,2,1,5,6,6,2,0,5,7,0,3,7,1,2,2,5,4,0,0,5,3,3,7,5,2,4,6,7,4,3,3,7,0,1]

theorem envBound29682 : H12AffineFastState.Bounded env29682 := by
  intro p hp
  have h : env29682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29681_29682 : H12AffineEnvironment.transform 5 6 env29681 = env29682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 6 env29681 == env29682) = true)

theorem identity29682 : scanCanonicalize (H12AffineFastState.compose env29682 (packedSelected [2,4] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound29682 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env29683 : List Nat := [2,2,2,1,3,0,0,2,0,3,1,0,3,1,1,2,2,3,2,0,0,3,3,3,1,3,2,2,0,1,2,3,3,1,0,1]

theorem envBound29683 : H12AffineFastState.Bounded env29683 := by
  intro p hp
  have h : env29683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29682_29683 : H12AffineEnvironment.transform 1 2 env29682 = env29683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env29682 == env29683) = true)

theorem identity29683 : scanCanonicalize (H12AffineFastState.compose env29683 (packedSelected [7] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound29683 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env29684 : List Nat := [0,0,0,1,1,0,0,0,0,1,1,0,1,1,1,0,0,1,0,0,0,1,1,1,1,1,0,0,0,1,0,1,1,1,0,1]

theorem envBound29684 : H12AffineFastState.Bounded env29684 := by
  intro p hp
  have h : env29684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29683_29684 : H12AffineEnvironment.transform 0 0 env29683 = env29684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env29683 == env29684) = true)

def env29685 : List Nat := [2,4,8,1,32,64,128,256,324,1024,2048,0,1285,1280,264,9,355,136,320,265,0,461,1059,8,204,290,303,291,1281,2118,1288,303,257,1280,1345,1028]

theorem envBound29685 : H12AffineFastState.Bounded env29685 := by
  intro p hp
  have h : env29685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29674_29685 : H12AffineEnvironment.transform 12 1285 env29674 = env29685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1285 env29674 == env29685) = true)

theorem identity29685 : scanCanonicalize (H12AffineFastState.compose env29685 (packedSelected [1,2,4,7,9,10,11,15,17,21,23,24,27] rootPS)) = affineNative (2^(10+1) ^^^ 390) := by decide +kernel

theorem selectedBound29685 : packedSelected [1,2,4,7,9,10,11,15,17,21,23,24,27] rootPS < 2^1333 := by decide +kernel

def env29686 : List Nat := [2,4,8,1,32,64,128,256,324,1024,390,0,1285,1280,264,9,355,136,320,265,0,461,1059,8,204,290,303,291,1281,448,1288,303,257,1280,1345,1028]

theorem envBound29686 : H12AffineFastState.Bounded env29686 := by
  intro p hp
  have h : env29686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29685_29686 : H12AffineEnvironment.transform 10 390 env29685 = env29686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 390 env29685 == env29686) = true)

theorem identity29686 : scanCanonicalize (H12AffineFastState.compose env29686 (packedSelected [0,1,2,4,7,8,9,10,11,13,15,17,23] rootPS)) = affineNative (2^(9+1) ^^^ 399) := by decide +kernel

theorem selectedBound29686 : packedSelected [0,1,2,4,7,8,9,10,11,13,15,17,23] rootPS < 2^1333 := by decide +kernel

def env29687 : List Nat := [2,4,8,1,32,64,128,256,324,399,390,0,138,143,264,9,355,136,320,265,0,461,428,8,204,290,303,291,142,448,135,303,257,143,206,395]

theorem envBound29687 : H12AffineFastState.Bounded env29687 := by
  intro p hp
  have h : env29687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29686_29687 : H12AffineEnvironment.transform 9 399 env29686 = env29687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 399 env29686 == env29687) = true)

theorem identity29687 : scanCanonicalize (H12AffineFastState.compose env29687 (packedSelected [0,1,2,5,7,8,11] rootPS)) = affineNative (2^(7+1) ^^^ 78) := by decide +kernel

theorem selectedBound29687 : packedSelected [0,1,2,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env29688 : List Nat := [2,4,8,1,32,64,128,78,10,193,200,0,138,143,70,9,45,136,14,71,0,131,226,8,204,108,97,109,142,142,135,97,79,143,206,197]

theorem envBound29688 : H12AffineFastState.Bounded env29688 := by
  intro p hp
  have h : env29688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29687_29688 : H12AffineEnvironment.transform 7 78 env29687 = env29688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 78 env29687 == env29688) = true)

theorem identity29688 : scanCanonicalize (H12AffineFastState.compose env29688 (packedSelected [0,3,5,8,9,10,12] rootPS)) = affineNative (2^(6+1) ^^^ 37) := by decide +kernel

theorem selectedBound29688 : packedSelected [0,3,5,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env29689 : List Nat := [2,4,8,1,32,64,37,78,10,100,109,0,47,42,70,9,45,45,14,71,0,38,71,8,105,108,97,109,43,43,34,97,79,42,107,96]

theorem envBound29689 : H12AffineFastState.Bounded env29689 := by
  intro p hp
  have h : env29689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29688_29689 : H12AffineEnvironment.transform 6 37 env29688 = env29689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 37 env29688 == env29689) = true)

theorem identity29689 : scanCanonicalize (H12AffineFastState.compose env29689 (packedSelected [4,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound29689 : packedSelected [4,5,7] rootPS < 2^1333 := by decide +kernel

def env29690 : List Nat := [2,4,8,1,10,64,15,78,10,78,71,0,5,0,70,9,7,7,14,71,0,12,71,8,67,70,75,71,1,1,8,75,79,0,65,74]

theorem envBound29690 : H12AffineFastState.Bounded env29690 := by
  intro p hp
  have h : env29690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29689_29690 : H12AffineEnvironment.transform 4 10 env29689 = env29690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env29689 == env29690) = true)

theorem identity29690 : scanCanonicalize (H12AffineFastState.compose env29690 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound29690 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29691 : List Nat := [2,3,8,1,10,64,8,73,10,73,64,0,2,0,65,9,0,0,9,64,0,11,64,8,67,65,75,64,1,1,8,75,72,0,65,74]

theorem envBound29691 : H12AffineFastState.Bounded env29691 := by
  intro p hp
  have h : env29691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29690_29691 : H12AffineEnvironment.transform 1 3 env29690 = env29691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env29690 == env29691) = true)

theorem identity29691 : scanCanonicalize (H12AffineFastState.compose env29691 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound29691 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env29692 : List Nat := [2,3,8,1,10,10,8,3,10,3,10,0,2,0,11,9,0,0,9,10,0,11,10,8,9,11,1,10,1,1,8,1,2,0,11,0]

theorem envBound29692 : H12AffineFastState.Bounded env29692 := by
  intro p hp
  have h : env29692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29691_29692 : H12AffineEnvironment.transform 5 10 env29691 = env29692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env29691 == env29692) = true)

def env29693 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,16777216,533641,672784,17245633,148800,545089,96347,16876545,17363323,257,1280,1344,525824]

theorem envBound29693 : H12AffineFastState.Bounded env29693 := by
  intro p hp
  have h : env29693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29018_29693 : H12AffineEnvironment.transform 26 17245633 env29018 = env29693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245633 env29018 == env29693) = true)

theorem identity29693 : scanCanonicalize (H12AffineFastState.compose env29693 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(18+1) ^^^ 95615) := by decide +kernel

theorem selectedBound29693 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env29694 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95615,32769,4096,61649,147520,16777216,86518,209263,17245633,148800,74814,96347,16876545,16876548,257,1280,1344,95103]

theorem envBound29694 : H12AffineFastState.Bounded env29694 := by
  intro p hp
  have h : env29694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29693_29694 : H12AffineEnvironment.transform 18 95615 env29693 = env29694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 95615 env29693 == env29694) = true)

def env29695 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95615,32769,4096,61649,147520,284032,86518,209263,225345,148800,74814,96347,381313,381316,257,1280,1344,95103]

theorem envBound29695 : H12AffineFastState.Bounded env29695 := by
  intro p hp
  have h : env29695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29694_29695 : H12AffineEnvironment.transform 23 284032 env29694 = env29695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 284032 env29694 == env29695) = true)

def env29696 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16464,262144,95615,32769,4096,61649,16,284032,86518,94527,77841,1296,74814,96347,381313,381316,257,1280,1344,95103]

theorem envBound29696 : H12AffineFastState.Bounded env29696 := by
  intro p hp
  have h : env29696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29695_29696 : H12AffineEnvironment.transform 16 16464 env29695 = env29696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16464 env29695 == env29696) = true)

def env29697 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1344,262144,77935,32769,4096,46529,16,266384,70886,78895,77841,1296,74814,81227,365713,365716,257,1280,1344,79471]

theorem envBound29697 : H12AffineFastState.Bounded env29697 := by
  intro p hp
  have h : env29697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29696_29697 : H12AffineEnvironment.transform 13 1296 env29696 = env29697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env29696 == env29697) = true)

theorem identity29697 : scanCanonicalize (H12AffineFastState.compose env29697 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound29697 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env29698 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1344,262144,77935,13341,4096,477,16,266384,70886,78895,77841,1296,74814,81227,336013,336008,257,1280,1344,79471]

theorem envBound29698 : H12AffineFastState.Bounded env29698 := by
  intro p hp
  have h : env29698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29697_29698 : H12AffineEnvironment.transform 14 13340 env29697 = env29698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env29697 == env29698) = true)

def env29699 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1344,65664,77935,13341,4096,477,16,69648,70886,78895,77841,1296,74814,81227,8205,8200,257,1280,1344,79471]

theorem envBound29699 : H12AffineFastState.Bounded env29699 := by
  intro p hp
  have h : env29699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29698_29699 : H12AffineEnvironment.transform 17 65664 env29698 = env29699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env29698 == env29699) = true)

theorem identity29699 : scanCanonicalize (H12AffineFastState.compose env29699 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9327) := by decide +kernel

theorem selectedBound29699 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env29700 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,9327,1344,9455,5120,13341,4096,477,16,13439,12425,4160,5246,1296,81,6436,8205,8200,257,1280,1344,4608]

theorem envBound29700 : H12AffineFastState.Bounded env29700 := by
  intro p hp
  have h : env29700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29699_29700 : H12AffineEnvironment.transform 15 9327 env29699 = env29700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9327 env29699 == env29700) = true)

def env29701 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1296,9244,9327,1344,9455,1024,9245,0,477,16,9343,8329,64,1150,1296,81,2340,8205,8200,257,1280,1344,512]

theorem envBound29701 : H12AffineFastState.Bounded env29701 := by
  intro p hp
  have h : env29701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29700_29701 : H12AffineEnvironment.transform 11 0 env29700 = env29701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env29700 == env29701) = true)

theorem identity29701 : scanCanonicalize (H12AffineFastState.compose env29701 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound29701 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env29702 : List Nat := [2,4,8,16,32,64,128,21,512,1024,2048,0,8192,1029,9244,9327,1109,9455,1024,9245,0,200,16,9343,8329,64,1150,1029,81,2097,8205,8200,20,1045,1109,512]

theorem envBound29702 : H12AffineFastState.Bounded env29702 := by
  intro p hp
  have h : env29702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29701_29702 : H12AffineEnvironment.transform 7 21 env29701 = env29702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env29701 == env29702) = true)

theorem identity29702 : scanCanonicalize (H12AffineFastState.compose env29702 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound29702 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env29703 : List Nat := [2,4,8,16,32,16,128,21,512,1024,2048,0,8192,1029,9244,9279,1029,9407,1024,9245,0,152,16,9263,8329,16,1070,1029,1,2097,8205,8200,20,1045,1029,512]

theorem envBound29703 : H12AffineFastState.Bounded env29703 := by
  intro p hp
  have h : env29703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29702_29703 : H12AffineEnvironment.transform 5 16 env29702 = env29703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env29702 == env29703) = true)

theorem identity29703 : scanCanonicalize (H12AffineFastState.compose env29703 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 2089) := by decide +kernel

theorem selectedBound29703 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env29704 : List Nat := [2,4,8,16,32,16,128,21,512,1024,2048,0,2089,1029,3125,3094,1029,3222,1024,3124,0,152,16,3078,2208,16,1070,1029,1,2097,2084,2081,20,1045,1029,512]

theorem envBound29704 : H12AffineFastState.Bounded env29704 := by
  intro p hp
  have h : env29704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29703_29704 : H12AffineEnvironment.transform 12 2089 env29703 = env29704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2089 env29703 == env29704) = true)

theorem identity29704 : scanCanonicalize (H12AffineFastState.compose env29704 (packedSelected [0,7,11] rootPS)) = affineNative (2^(9+1) ^^^ 150) := by decide +kernel

theorem selectedBound29704 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env29705 : List Nat := [2,4,8,16,32,16,128,21,512,150,2048,0,2089,147,2211,2176,147,2048,150,2210,0,152,16,2192,2208,16,184,147,1,2097,2084,2081,20,131,147,512]

theorem envBound29705 : H12AffineFastState.Bounded env29705 := by
  intro p hp
  have h : env29705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29704_29705 : H12AffineEnvironment.transform 9 150 env29704 = env29705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 150 env29704 == env29705) = true)

theorem identity29705 : scanCanonicalize (H12AffineFastState.compose env29705 (packedSelected [1,2,3,4,5,8,9] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound29705 : packedSelected [1,2,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env29706 : List Nat := [2,4,8,16,32,16,128,21,26,150,2048,0,2089,147,2211,2176,147,2048,150,2210,0,152,16,2192,2208,16,184,147,1,2097,2084,2081,20,131,147,26]

theorem envBound29706 : H12AffineFastState.Bounded env29706 := by
  intro p hp
  have h : env29706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29705_29706 : H12AffineEnvironment.transform 8 26 env29705 = env29706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env29705 == env29706) = true)

theorem identity29706 : scanCanonicalize (H12AffineFastState.compose env29706 (packedSelected [0,1,4,5,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 137) := by decide +kernel

theorem selectedBound29706 : packedSelected [0,1,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env29707 : List Nat := [2,4,8,16,32,16,128,21,26,150,137,0,160,147,42,9,147,137,150,43,0,152,16,25,41,16,184,147,1,184,173,168,20,131,147,26]

theorem envBound29707 : H12AffineFastState.Bounded env29707 := by
  intro p hp
  have h : env29707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29706_29707 : H12AffineEnvironment.transform 10 137 env29706 = env29707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 137 env29706 == env29707) = true)

theorem identity29707 : scanCanonicalize (H12AffineFastState.compose env29707 (packedSelected [3,4] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound29707 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env29708 : List Nat := [2,4,8,10,32,10,128,15,0,140,137,0,160,137,42,9,137,137,140,43,0,130,10,3,41,10,162,137,1,162,173,168,14,131,137,0]

theorem envBound29708 : H12AffineFastState.Bounded env29708 := by
  intro p hp
  have h : env29708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29707_29708 : H12AffineEnvironment.transform 3 10 env29707 = env29708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env29707 == env29708) = true)

theorem identity29708 : scanCanonicalize (H12AffineFastState.compose env29708 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound29708 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env29709 : List Nat := [2,4,8,10,32,10,35,15,0,47,42,0,3,42,42,9,42,42,47,43,0,33,10,3,41,10,1,42,1,1,14,11,14,32,42,0]

theorem envBound29709 : H12AffineFastState.Bounded env29709 := by
  intro p hp
  have h : env29709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29708_29709 : H12AffineEnvironment.transform 6 35 env29708 = env29709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env29708 == env29709) = true)

theorem identity29709 : scanCanonicalize (H12AffineFastState.compose env29709 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound29709 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29710 : List Nat := [2,4,8,10,11,10,8,15,0,4,1,0,3,1,1,9,1,1,4,0,0,10,10,3,2,10,1,1,1,1,14,11,14,11,1,0]

theorem envBound29710 : H12AffineFastState.Bounded env29710 := by
  intro p hp
  have h : env29710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29709_29710 : H12AffineEnvironment.transform 4 11 env29709 = env29710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env29709 == env29710) = true)

theorem identity29710 : scanCanonicalize (H12AffineFastState.compose env29710 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound29710 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29711 : List Nat := [2,4,5,7,6,7,5,2,0,4,1,0,3,1,1,4,1,1,4,0,0,7,7,3,2,7,1,1,1,1,3,6,3,6,1,0]

theorem envBound29711 : H12AffineFastState.Bounded env29711 := by
  intro p hp
  have h : env29711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29710_29711 : H12AffineEnvironment.transform 2 5 env29710 = env29711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env29710 == env29711) = true)

def env29712 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1296,9245,9327,1344,9455,1025,9244,1,477,16,9342,8328,65,1151,1296,81,2341,8205,8200,257,1280,1344,513]

theorem envBound29712 : H12AffineFastState.Bounded env29712 := by
  intro p hp
  have h : env29712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29700_29712 : H12AffineEnvironment.transform 11 1 env29700 = env29712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env29700 == env29712) = true)

theorem identity29712 : scanCanonicalize (H12AffineFastState.compose env29712 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound29712 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env29713 : List Nat := [2,4,8,16,32,64,128,68,512,1024,2048,1,8192,1108,9245,9327,1028,9455,1025,9244,1,153,16,9342,8328,65,1151,1108,81,2145,8205,8200,69,1092,1028,513]

theorem envBound29713 : H12AffineFastState.Bounded env29713 := by
  intro p hp
  have h : env29713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29712_29713 : H12AffineEnvironment.transform 7 68 env29712 = env29713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env29712 == env29713) = true)

theorem identity29713 : scanCanonicalize (H12AffineFastState.compose env29713 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound29713 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env29714 : List Nat := [2,4,8,16,32,64,128,68,512,1024,2048,1,1052,1108,1,115,1028,243,1025,0,1,153,16,98,1172,65,1151,1108,81,2145,1041,1044,69,1092,1028,513]

theorem envBound29714 : H12AffineFastState.Bounded env29714 := by
  intro p hp
  have h : env29714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29713_29714 : H12AffineEnvironment.transform 12 1052 env29713 = env29714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env29713 == env29714) = true)

theorem identity29714 : scanCanonicalize (H12AffineFastState.compose env29714 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound29714 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env29715 : List Nat := [2,4,8,16,32,0,128,4,512,1024,2048,1,1052,1044,1,51,1028,179,1025,0,1,153,16,34,1172,1,1087,1044,17,2081,1041,1044,5,1028,1028,513]

theorem envBound29715 : H12AffineFastState.Bounded env29715 := by
  intro p hp
  have h : env29715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29714_29715 : H12AffineEnvironment.transform 5 0 env29714 = env29715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env29714 == env29715) = true)

theorem identity29715 : scanCanonicalize (H12AffineFastState.compose env29715 (packedSelected [1,2,3,5,13,15] rootPS)) = affineNative (2^(9+1) ^^^ 521) := by decide +kernel

theorem selectedBound29715 : packedSelected [1,2,3,5,13,15] rootPS < 2^1333 := by decide +kernel

def env29716 : List Nat := [2,4,8,16,32,0,128,4,512,521,2048,1,533,541,1,51,525,179,520,0,1,153,16,34,669,1,566,541,17,2081,536,541,5,525,525,513]

theorem envBound29716 : H12AffineFastState.Bounded env29716 := by
  intro p hp
  have h : env29716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29715_29716 : H12AffineEnvironment.transform 9 521 env29715 = env29716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 521 env29715 == env29716) = true)

theorem identity29716 : scanCanonicalize (H12AffineFastState.compose env29716 (packedSelected [1,3,5,11,12,18] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound29716 : packedSelected [1,3,5,11,12,18] rootPS < 2^1333 := by decide +kernel

def env29717 : List Nat := [2,4,8,16,32,0,128,4,137,128,2048,1,156,148,1,51,132,179,129,0,1,153,16,34,20,1,191,148,17,2081,145,148,5,132,132,136]

theorem envBound29717 : H12AffineFastState.Bounded env29717 := by
  intro p hp
  have h : env29717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29716_29717 : H12AffineEnvironment.transform 8 137 env29716 = env29717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env29716 == env29717) = true)

theorem identity29717 : scanCanonicalize (H12AffineFastState.compose env29717 (packedSelected [1,2,3,12] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound29717 : packedSelected [1,2,3,12] rootPS < 2^1333 := by decide +kernel

def env29718 : List Nat := [2,4,8,16,32,0,128,4,137,128,43,1,156,148,1,51,132,179,129,0,1,153,16,34,20,1,191,148,17,10,145,148,5,132,132,136]

theorem envBound29718 : H12AffineFastState.Bounded env29718 := by
  intro p hp
  have h : env29718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29717_29718 : H12AffineEnvironment.transform 10 43 env29717 = env29718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env29717 == env29718) = true)

theorem identity29718 : scanCanonicalize (H12AffineFastState.compose env29718 (packedSelected [1,2,4,8,9,11] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound29718 : packedSelected [1,2,4,8,9,11] rootPS < 2^1333 := by decide +kernel

def env29719 : List Nat := [2,4,8,16,32,0,57,4,48,57,43,1,37,45,1,51,61,10,56,0,1,32,16,34,20,1,6,45,17,10,40,45,5,61,61,49]

theorem envBound29719 : H12AffineFastState.Bounded env29719 := by
  intro p hp
  have h : env29719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29718_29719 : H12AffineEnvironment.transform 6 57 env29718 = env29719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env29718 == env29719) = true)

theorem identity29719 : scanCanonicalize (H12AffineFastState.compose env29719 (packedSelected [0,1,2,3,4,5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound29719 : packedSelected [0,1,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env29720 : List Nat := [2,4,3,16,32,0,50,4,48,50,32,1,37,38,1,51,54,1,51,0,1,32,16,34,20,1,6,38,17,1,35,38,5,54,54,49]

theorem envBound29720 : H12AffineFastState.Bounded env29720 := by
  intro p hp
  have h : env29720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29719_29720 : H12AffineEnvironment.transform 2 3 env29719 = env29720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env29719 == env29720) = true)

theorem identity29720 : scanCanonicalize (H12AffineFastState.compose env29720 (packedSelected [0,1,2] rootPS)) = affineNative (2^(4+1) ^^^ 20) := by decide +kernel

theorem selectedBound29720 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env29721 : List Nat := [2,4,3,16,20,0,6,4,4,6,20,1,17,18,1,7,2,1,7,0,1,20,16,22,20,1,6,18,17,1,23,18,5,2,2,5]

theorem envBound29721 : H12AffineFastState.Bounded env29721 := by
  intro p hp
  have h : env29721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29720_29721 : H12AffineEnvironment.transform 4 20 env29720 = env29721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 20 env29720 == env29721) = true)

theorem identity29721 : scanCanonicalize (H12AffineFastState.compose env29721 (packedSelected [0,3,4] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound29721 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env29722 : List Nat := [2,1,3,16,17,0,3,1,1,3,17,1,17,18,1,2,2,1,2,0,1,17,16,19,17,1,3,18,17,1,18,18,0,2,2,0]

theorem envBound29722 : H12AffineFastState.Bounded env29722 := by
  intro p hp
  have h : env29722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29721_29722 : H12AffineEnvironment.transform 1 1 env29721 = env29722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env29721 == env29722) = true)

def env29723 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1344,65665,77935,13341,4096,477,16,69649,70886,78895,77841,1296,74814,81227,8204,8201,257,1280,1344,79471]

theorem envBound29723 : H12AffineFastState.Bounded env29723 := by
  intro p hp
  have h : env29723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29698_29723 : H12AffineEnvironment.transform 17 65665 env29698 = env29723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env29698 == env29723) = true)

theorem identity29723 : scanCanonicalize (H12AffineFastState.compose env29723 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12590) := by decide +kernel

theorem selectedBound29723 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env29724 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,12590,1344,12719,321,13341,4096,477,16,8511,9672,1281,319,1296,5392,3173,8204,8201,257,1280,1344,1857]

theorem envBound29724 : H12AffineFastState.Bounded env29724 := by
  intro p hp
  have h : env29724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29723_29724 : H12AffineEnvironment.transform 15 12590 env29723 = env29724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12590 env29723 == env29724) = true)

def env29725 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,80,12636,12590,0,12719,321,12637,4096,477,16,8511,8328,65,319,80,4176,2341,8204,8201,257,64,0,513]

theorem envBound29725 : H12AffineFastState.Bounded env29725 := by
  intro p hp
  have h : env29725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29724_29725 : H12AffineEnvironment.transform 9 320 env29724 = env29725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env29724 == env29725) = true)

theorem identity29725 : scanCanonicalize (H12AffineFastState.compose env29725 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 325) := by decide +kernel

theorem selectedBound29725 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env29726 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,325,8192,80,8217,8299,0,8426,321,8216,325,477,16,8511,8328,65,319,80,277,2341,8204,8201,257,64,0,513]

theorem envBound29726 : H12AffineFastState.Bounded env29726 := by
  intro p hp
  have h : env29726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29725_29726 : H12AffineEnvironment.transform 11 325 env29725 = env29726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 325 env29725 == env29726) = true)

theorem identity29726 : scanCanonicalize (H12AffineFastState.compose env29726 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound29726 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env29727 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,325,25,80,0,114,0,243,321,1,325,477,16,294,145,65,319,80,277,2341,21,16,257,64,0,513]

theorem envBound29727 : H12AffineFastState.Bounded env29727 := by
  intro p hp
  have h : env29727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29726_29727 : H12AffineEnvironment.transform 12 25 env29726 = env29727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env29726 == env29727) = true)

theorem identity29727 : scanCanonicalize (H12AffineFastState.compose env29727 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound29727 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env29728 : List Nat := [2,4,8,16,32,1,128,256,512,257,2048,260,25,17,0,51,0,178,256,1,260,412,16,294,145,0,319,17,277,2341,21,16,257,1,0,513]

theorem envBound29728 : H12AffineFastState.Bounded env29728 := by
  intro p hp
  have h : env29728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29727_29728 : H12AffineEnvironment.transform 5 1 env29727 = env29728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env29727 == env29728) = true)

theorem identity29728 : scanCanonicalize (H12AffineFastState.compose env29728 (packedSelected [2,11,12,13,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 396) := by decide +kernel

theorem selectedBound29728 : packedSelected [2,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env29729 : List Nat := [2,4,8,16,32,1,128,256,396,257,2048,260,25,17,0,51,0,178,256,1,260,412,16,294,145,0,319,17,277,2341,21,16,257,1,0,397]

theorem envBound29729 : H12AffineFastState.Bounded env29729 := by
  intro p hp
  have h : env29729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29728_29729 : H12AffineEnvironment.transform 8 396 env29728 = env29729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 396 env29728 == env29729) = true)

theorem identity29729 : scanCanonicalize (H12AffineFastState.compose env29729 (packedSelected [0,2,3,7,8,11,12,13,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 302) := by decide +kernel

theorem selectedBound29729 : packedSelected [0,2,3,7,8,11,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env29730 : List Nat := [2,4,8,16,32,1,128,256,396,257,302,260,25,17,0,51,0,178,256,1,260,412,16,294,145,0,319,17,277,11,21,16,257,1,0,397]

theorem envBound29730 : H12AffineFastState.Bounded env29730 := by
  intro p hp
  have h : env29730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29729_29730 : H12AffineEnvironment.transform 10 302 env29729 = env29730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 302 env29729 == env29730) = true)

theorem identity29730 : scanCanonicalize (H12AffineFastState.compose env29730 (packedSelected [0,1,2,5,7,8,11] rootPS)) = affineNative (2^(7+1) ^^^ 56) := by decide +kernel

theorem selectedBound29730 : packedSelected [0,1,2,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env29731 : List Nat := [2,4,8,16,32,1,128,56,180,57,22,60,25,17,0,51,0,178,56,1,60,164,16,30,145,0,7,17,45,11,21,16,57,1,0,181]

theorem envBound29731 : H12AffineFastState.Bounded env29731 := by
  intro p hp
  have h : env29731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29730_29731 : H12AffineEnvironment.transform 7 56 env29730 = env29731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 56 env29730 == env29731) = true)

theorem identity29731 : scanCanonicalize (H12AffineFastState.compose env29731 (packedSelected [0,1,2,3,4,5,7,9,12] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound29731 : packedSelected [0,1,2,3,4,5,7,9,12] rootPS < 2^1333 := by decide +kernel

def env29732 : List Nat := [2,4,8,16,32,1,56,56,12,57,22,60,25,17,0,51,0,10,56,1,60,28,16,30,41,0,7,17,45,11,21,16,57,1,0,13]

theorem envBound29732 : H12AffineFastState.Bounded env29732 := by
  intro p hp
  have h : env29732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29731_29732 : H12AffineEnvironment.transform 6 56 env29731 = env29732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env29731 == env29732) = true)

theorem identity29732 : scanCanonicalize (H12AffineFastState.compose env29732 (packedSelected [0,2,4] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound29732 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env29733 : List Nat := [2,4,8,16,7,1,31,31,12,30,22,27,25,17,0,20,0,10,31,1,27,28,16,30,14,0,7,17,10,11,21,16,30,1,0,13]

theorem envBound29733 : H12AffineFastState.Bounded env29733 := by
  intro p hp
  have h : env29733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29732_29733 : H12AffineEnvironment.transform 4 7 env29732 = env29733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env29732 == env29733) = true)

theorem identity29733 : scanCanonicalize (H12AffineFastState.compose env29733 (packedSelected [1,2] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound29733 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env29734 : List Nat := [2,4,8,6,7,1,9,9,12,8,0,13,15,7,0,2,0,10,9,1,13,10,6,8,14,0,7,7,10,11,3,6,8,1,0,13]

theorem envBound29734 : H12AffineFastState.Bounded env29734 := by
  intro p hp
  have h : env29734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29733_29734 : H12AffineEnvironment.transform 3 6 env29733 = env29734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env29733 == env29734) = true)

def env29735 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,81,12637,12590,1,12719,321,12636,4096,477,16,8511,8329,64,319,81,4177,2340,8204,8201,257,65,1,512]

theorem envBound29735 : H12AffineFastState.Bounded env29735 := by
  intro p hp
  have h : env29735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29724_29735 : H12AffineEnvironment.transform 9 321 env29724 = env29735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env29724 == env29735) = true)

theorem identity29735 : scanCanonicalize (H12AffineFastState.compose env29735 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound29735 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env29736 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,277,8192,81,8264,8251,1,8378,321,8265,277,477,16,8511,8329,64,319,81,324,2340,8204,8201,257,65,1,512]

theorem envBound29736 : H12AffineFastState.Bounded env29736 := by
  intro p hp
  have h : env29736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29735_29736 : H12AffineEnvironment.transform 11 277 env29735 = env29736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env29735 == env29736) = true)

theorem identity29736 : scanCanonicalize (H12AffineFastState.compose env29736 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound29736 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env29737 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,277,8192,1,8216,8251,1,8378,273,8217,277,397,16,8511,8329,16,319,1,276,2340,8204,8201,257,17,1,512]

theorem envBound29737 : H12AffineFastState.Bounded env29737 := by
  intro p hp
  have h : env29737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29736_29737 : H12AffineEnvironment.transform 5 16 env29736 = env29737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env29736 == env29737) = true)

theorem identity29737 : scanCanonicalize (H12AffineFastState.compose env29737 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 136) := by decide +kernel

theorem selectedBound29737 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env29738 : List Nat := [2,4,8,16,32,16,128,256,512,273,136,277,8192,1,8216,8251,1,8378,273,8217,277,397,16,8511,8329,16,319,1,276,428,8204,8201,257,17,1,512]

theorem envBound29738 : H12AffineFastState.Bounded env29738 := by
  intro p hp
  have h : env29738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29737_29738 : H12AffineEnvironment.transform 10 136 env29737 = env29738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 136 env29737 == env29738) = true)

theorem identity29738 : scanCanonicalize (H12AffineFastState.compose env29738 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(12+1) ^^^ 780) := by decide +kernel

theorem selectedBound29738 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env29739 : List Nat := [2,4,8,16,32,16,128,256,512,273,136,277,780,1,788,823,1,950,273,789,277,397,16,563,901,16,319,1,276,428,768,773,257,17,1,512]

theorem envBound29739 : H12AffineFastState.Bounded env29739 := by
  intro p hp
  have h : env29739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29738_29739 : H12AffineEnvironment.transform 12 780 env29738 = env29739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 780 env29738 == env29739) = true)

theorem identity29739 : scanCanonicalize (H12AffineFastState.compose env29739 (packedSelected [2,3,8] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound29739 : packedSelected [2,3,8] rootPS < 2^1333 := by decide +kernel

def env29740 : List Nat := [2,4,8,16,32,16,56,256,512,273,48,277,780,1,788,823,1,782,273,789,277,309,16,563,829,16,319,1,276,276,768,773,257,17,1,512]

theorem envBound29740 : H12AffineFastState.Bounded env29740 := by
  intro p hp
  have h : env29740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29739_29740 : H12AffineEnvironment.transform 6 56 env29739 = env29740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env29739 == env29740) = true)

def env29741 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1345,262144,77934,32769,4096,46528,16,266385,70887,78894,77841,1296,74814,81226,365712,365717,257,1280,1344,79470]

theorem envBound29741 : H12AffineFastState.Bounded env29741 := by
  intro p hp
  have h : env29741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29696_29741 : H12AffineEnvironment.transform 13 1297 env29696 = env29741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env29696 == env29741) = true)

theorem identity29741 : scanCanonicalize (H12AffineFastState.compose env29741 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32883) := by decide +kernel

theorem selectedBound29741 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env29742 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,32883,1345,262144,45085,32769,4096,46528,16,266385,38036,46173,45154,1296,42061,48441,267491,267494,257,1280,1344,46621]

theorem envBound29742 : H12AffineFastState.Bounded env29742 := by
  intro p hp
  have h : env29742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29741_29742 : H12AffineEnvironment.transform 15 32883 env29741 = env29742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32883 env29741 == env29742) = true)

def env29743 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32883,1345,262144,42333,32769,1344,41088,16,263633,33236,41245,42274,1296,42061,43129,262563,262566,257,1280,1344,41821]

theorem envBound29743 : H12AffineFastState.Bounded env29743 := by
  intro p hp
  have h : env29743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29742_29743 : H12AffineEnvironment.transform 11 1344 env29742 = env29743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env29742 == env29743) = true)

theorem identity29743 : scanCanonicalize (H12AffineFastState.compose env29743 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 72) := by decide +kernel

theorem selectedBound29743 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env29744 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,72,1297,32768,32883,1345,262144,34069,32769,1344,32968,16,263633,33236,33109,34154,1296,33797,34865,262563,262566,257,1280,1344,33557]

theorem envBound29744 : H12AffineFastState.Bounded env29744 := by
  intro p hp
  have h : env29744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29743_29744 : H12AffineEnvironment.transform 12 72 env29743 = env29744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env29743 == env29744) = true)

theorem identity29744 : scanCanonicalize (H12AffineFastState.compose env29744 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(10+1) ^^^ 1782) := by decide +kernel

theorem selectedBound29744 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env29745 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1782,1344,72,1297,32768,32883,1345,262144,34069,32769,1344,32968,16,263633,33236,33109,34154,1296,33797,34503,262563,262566,257,1280,1344,33557]

theorem envBound29745 : H12AffineFastState.Bounded env29745 := by
  intro p hp
  have h : env29745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29744_29745 : H12AffineEnvironment.transform 10 1782 env29744 = env29745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1782 env29744 == env29745) = true)

def env29746 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32883,1345,262144,42332,32769,1345,41089,16,263632,33237,41244,42275,1296,42061,43128,262562,262567,257,1280,1344,41820]

theorem envBound29746 : H12AffineFastState.Bounded env29746 := by
  intro p hp
  have h : env29746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29742_29746 : H12AffineEnvironment.transform 11 1345 env29742 = env29746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env29742 == env29746) = true)

theorem identity29746 : scanCanonicalize (H12AffineFastState.compose env29746 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 41147) := by decide +kernel

theorem selectedBound29746 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env29747 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32883,1345,41147,42332,32769,1345,41089,16,42347,33237,41244,42275,1296,42061,43128,41241,41244,257,1280,1344,41820]

theorem envBound29747 : H12AffineFastState.Bounded env29747 := by
  intro p hp
  have h : env29747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29746_29747 : H12AffineEnvironment.transform 17 41147 env29746 = env29747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 41147 env29746 == env29747) = true)

theorem identity29747 : scanCanonicalize (H12AffineFastState.compose env29747 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound29747 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env29748 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,8540,8495,1345,487,1024,8541,1345,477,16,1079,8329,64,1151,1296,1297,2340,69,64,257,1280,1344,512]

theorem envBound29748 : H12AffineFastState.Bounded env29748 := by
  intro p hp
  have h : env29748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29747_29748 : H12AffineEnvironment.transform 14 8540 env29747 = env29748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env29747 == env29748) = true)

theorem identity29748 : scanCanonicalize (H12AffineFastState.compose env29748 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 84) := by decide +kernel

theorem selectedBound29748 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env29749 : List Nat := [2,4,8,16,32,64,128,256,512,84,2048,277,8192,325,8540,8495,277,487,84,8541,277,477,16,99,8329,64,43,324,325,2340,69,64,257,340,276,512]

theorem envBound29749 : H12AffineFastState.Bounded env29749 := by
  intro p hp
  have h : env29749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29748_29749 : H12AffineEnvironment.transform 9 84 env29748 = env29749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env29748 == env29749) = true)

theorem identity29749 : scanCanonicalize (H12AffineFastState.compose env29749 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 705) := by decide +kernel

theorem selectedBound29749 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env29750 : List Nat := [2,4,8,16,32,64,128,256,512,84,2048,277,705,325,925,1006,277,487,84,924,277,477,16,99,584,64,43,324,325,2340,69,64,257,340,276,512]

theorem envBound29750 : H12AffineFastState.Bounded env29750 := by
  intro p hp
  have h : env29750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29749_29750 : H12AffineEnvironment.transform 12 705 env29749 = env29750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 705 env29749 == env29750) = true)

theorem identity29750 : scanCanonicalize (H12AffineFastState.compose env29750 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound29750 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env29751 : List Nat := [2,4,8,16,32,16,128,256,512,4,2048,277,657,277,925,958,277,439,4,924,277,397,16,51,536,16,43,276,277,2340,21,16,257,260,276,512]

theorem envBound29751 : H12AffineFastState.Bounded env29751 := by
  intro p hp
  have h : env29751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29750_29751 : H12AffineEnvironment.transform 5 16 env29750 = env29751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env29750 == env29751) = true)

theorem identity29751 : scanCanonicalize (H12AffineFastState.compose env29751 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 271) := by decide +kernel

theorem selectedBound29751 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env29752 : List Nat := [2,4,8,16,32,16,128,256,512,4,271,277,657,277,925,958,277,439,4,924,277,397,16,51,536,16,43,276,277,43,21,16,257,260,276,512]

theorem envBound29752 : H12AffineFastState.Bounded env29752 := by
  intro p hp
  have h : env29752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29751_29752 : H12AffineEnvironment.transform 10 271 env29751 = env29752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 271 env29751 == env29752) = true)

theorem identity29752 : scanCanonicalize (H12AffineFastState.compose env29752 (packedSelected [1,3,13] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound29752 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env29753 : List Nat := [2,4,8,16,32,16,56,256,512,4,271,277,553,277,805,774,277,271,4,804,277,309,16,51,536,16,43,276,277,43,21,16,257,260,276,512]

theorem envBound29753 : H12AffineFastState.Bounded env29753 := by
  intro p hp
  have h : env29753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29752_29753 : H12AffineEnvironment.transform 6 56 env29752 = env29753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env29752 == env29753) = true)

theorem identity29753 : scanCanonicalize (H12AffineFastState.compose env29753 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 318) := by decide +kernel

theorem selectedBound29753 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29754 : List Nat := [2,4,8,16,32,16,56,256,318,4,271,277,279,277,27,56,277,271,4,26,277,309,16,51,294,16,43,276,277,43,21,16,257,260,276,318]

theorem envBound29754 : H12AffineFastState.Bounded env29754 := by
  intro p hp
  have h : env29754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29753_29754 : H12AffineEnvironment.transform 8 318 env29753 = env29754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 318 env29753 == env29754) = true)

theorem identity29754 : scanCanonicalize (H12AffineFastState.compose env29754 (packedSelected [0,1,3,5] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound29754 : packedSelected [0,1,3,5] rootPS < 2^1333 := by decide +kernel

def env29755 : List Nat := [2,4,8,16,32,16,56,21,43,4,26,0,2,0,27,56,0,26,4,26,0,32,16,51,51,16,43,1,0,43,21,16,20,17,1,43]

theorem envBound29755 : H12AffineFastState.Bounded env29755 := by
  intro p hp
  have h : env29755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29754_29755 : H12AffineEnvironment.transform 7 21 env29754 = env29755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env29754 == env29755) = true)

theorem identity29755 : scanCanonicalize (H12AffineFastState.compose env29755 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound29755 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29756 : List Nat := [2,4,4,16,32,16,52,21,39,4,22,0,2,0,23,52,0,22,4,22,0,32,16,51,51,16,39,1,0,39,21,16,20,17,1,39]

theorem envBound29756 : H12AffineFastState.Bounded env29756 := by
  intro p hp
  have h : env29756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29755_29756 : H12AffineEnvironment.transform 2 4 env29755 = env29756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env29755 == env29756) = true)

theorem identity29756 : scanCanonicalize (H12AffineFastState.compose env29756 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound29756 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29757 : List Nat := [2,4,4,16,6,16,18,21,1,4,22,0,2,0,23,18,0,22,4,22,0,6,16,21,21,16,1,1,0,1,21,16,20,17,1,1]

theorem envBound29757 : H12AffineFastState.Bounded env29757 := by
  intro p hp
  have h : env29757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29756_29757 : H12AffineEnvironment.transform 4 6 env29756 = env29757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env29756 == env29757) = true)

theorem identity29757 : scanCanonicalize (H12AffineFastState.compose env29757 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound29757 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env29758 : List Nat := [2,4,4,7,6,7,5,2,1,4,1,0,2,0,0,5,0,1,4,1,0,6,7,2,2,7,1,1,0,1,2,7,3,6,1,1]

theorem envBound29758 : H12AffineFastState.Bounded env29758 := by
  intro p hp
  have h : env29758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29757_29758 : H12AffineEnvironment.transform 3 7 env29757 = env29758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env29757 == env29758) = true)

def env29759 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16465,262144,95615,32769,4096,61649,17,284032,86518,94526,77840,1297,74814,96347,381313,381316,257,1280,1344,95103]

theorem envBound29759 : H12AffineFastState.Bounded env29759 := by
  intro p hp
  have h : env29759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29695_29759 : H12AffineEnvironment.transform 16 16465 env29695 = env29759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16465 env29695 == env29759) = true)

def env29760 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1345,262144,77935,32769,4096,46529,17,266384,70886,78894,77840,1297,74814,81227,365713,365716,257,1280,1344,79471]

theorem envBound29760 : H12AffineFastState.Bounded env29760 := by
  intro p hp
  have h : env29760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29759_29760 : H12AffineEnvironment.transform 13 1296 env29759 = env29760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env29759 == env29760) = true)

theorem identity29760 : scanCanonicalize (H12AffineFastState.compose env29760 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32882) := by decide +kernel

theorem selectedBound29760 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env29761 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,32882,1345,262144,45085,32769,4096,46529,17,266384,38036,46172,45154,1297,42060,48441,267491,267494,257,1280,1344,46621]

theorem envBound29761 : H12AffineFastState.Bounded env29761 := by
  intro p hp
  have h : env29761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29760_29761 : H12AffineEnvironment.transform 15 32882 env29760 = env29761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32882 env29760 == env29761) = true)

def env29762 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32882,1345,262144,42333,32769,1344,41089,17,263632,33236,41244,42274,1297,42060,43129,262563,262566,257,1280,1344,41821]

theorem envBound29762 : H12AffineFastState.Bounded env29762 := by
  intro p hp
  have h : env29762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29761_29762 : H12AffineEnvironment.transform 11 1344 env29761 = env29762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env29761 == env29762) = true)

theorem identity29762 : scanCanonicalize (H12AffineFastState.compose env29762 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 9244) := by decide +kernel

theorem selectedBound29762 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env29763 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,9244,9326,1345,262144,321,9245,1344,1181,17,263632,9672,1280,318,1297,80,3173,262563,262566,257,1280,1344,1857]

theorem envBound29763 : H12AffineFastState.Bounded env29763 := by
  intro p hp
  have h : env29763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29762_29763 : H12AffineEnvironment.transform 14 9244 env29762 = env29763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9244 env29762 == env29763) = true)

theorem identity29763 : scanCanonicalize (H12AffineFastState.compose env29763 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound29763 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env29764 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,1,8192,81,8541,8495,0,262144,321,8540,1,476,17,262289,8329,65,318,80,80,2340,262563,262566,257,65,1,512]

theorem envBound29764 : H12AffineFastState.Bounded env29764 := by
  intro p hp
  have h : env29764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29763_29764 : H12AffineEnvironment.transform 9 321 env29763 = env29764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env29763 == env29764) = true)

theorem identity29764 : scanCanonicalize (H12AffineFastState.compose env29764 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound29764 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env29765 : List Nat := [2,4,8,16,32,64,128,21,512,84,2048,1,8192,81,8264,8250,0,262144,84,8265,1,201,17,262289,8329,65,43,80,80,2097,262326,262323,20,65,1,512]

theorem envBound29765 : H12AffineFastState.Bounded env29765 := by
  intro p hp
  have h : env29765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29764_29765 : H12AffineEnvironment.transform 7 21 env29764 = env29765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env29764 == env29765) = true)

theorem identity29765 : scanCanonicalize (H12AffineFastState.compose env29765 (packedSelected [3,5,10] rootPS)) = affineNative (2^(17+1) ^^^ 8754) := by decide +kernel

theorem selectedBound29765 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env29766 : List Nat := [2,4,8,16,32,64,128,21,512,84,2048,1,8192,81,8264,8250,0,8754,84,8265,1,201,17,8867,8329,65,43,80,80,2097,8836,8833,20,65,1,512]

theorem envBound29766 : H12AffineFastState.Bounded env29766 := by
  intro p hp
  have h : env29766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29765_29766 : H12AffineEnvironment.transform 17 8754 env29765 = env29766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8754 env29765 == env29766) = true)

theorem identity29766 : scanCanonicalize (H12AffineFastState.compose env29766 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound29766 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env29767 : List Nat := [2,4,8,16,32,16,128,21,512,4,2048,1,8192,1,8216,8250,0,8754,4,8217,1,153,17,8867,8329,17,43,0,0,2097,8836,8833,20,17,1,512]

theorem envBound29767 : H12AffineFastState.Bounded env29767 := by
  intro p hp
  have h : env29767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29766_29767 : H12AffineEnvironment.transform 5 16 env29766 = env29767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env29766 == env29767) = true)

theorem identity29767 : scanCanonicalize (H12AffineFastState.compose env29767 (packedSelected [1,3,13] rootPS)) = affineNative (2^(12+1) ^^^ 2562) := by decide +kernel

theorem selectedBound29767 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env29768 : List Nat := [2,4,8,16,32,16,128,21,512,4,2048,1,2562,1,2586,2616,0,2096,4,2587,1,153,17,2209,2699,17,43,0,0,2097,2182,2179,20,17,1,512]

theorem envBound29768 : H12AffineFastState.Bounded env29768 := by
  intro p hp
  have h : env29768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29767_29768 : H12AffineEnvironment.transform 12 2562 env29767 = env29768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2562 env29767 == env29768) = true)

theorem identity29768 : scanCanonicalize (H12AffineFastState.compose env29768 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 146) := by decide +kernel

theorem selectedBound29768 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env29769 : List Nat := [2,4,8,16,32,16,128,21,512,4,146,1,656,1,648,682,0,162,4,649,1,153,17,51,537,17,43,0,0,163,20,17,20,17,1,512]

theorem envBound29769 : H12AffineFastState.Bounded env29769 := by
  intro p hp
  have h : env29769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29768_29769 : H12AffineEnvironment.transform 10 146 env29768 = env29769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 146 env29768 == env29769) = true)

theorem identity29769 : scanCanonicalize (H12AffineFastState.compose env29769 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 142) := by decide +kernel

theorem selectedBound29769 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29770 : List Nat := [2,4,8,16,32,16,128,21,142,4,146,1,30,1,6,36,0,162,4,7,1,153,17,51,151,17,43,0,0,163,20,17,20,17,1,142]

theorem envBound29770 : H12AffineFastState.Bounded env29770 := by
  intro p hp
  have h : env29770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29769_29770 : H12AffineEnvironment.transform 8 142 env29769 = env29770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 142 env29769 == env29770) = true)

theorem identity29770 : scanCanonicalize (H12AffineFastState.compose env29770 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound29770 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env29771 : List Nat := [2,4,8,16,32,16,56,21,54,4,42,1,30,1,6,36,0,26,4,7,1,33,17,51,47,17,43,0,0,27,20,17,20,17,1,54]

theorem envBound29771 : H12AffineFastState.Bounded env29771 := by
  intro p hp
  have h : env29771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29770_29771 : H12AffineEnvironment.transform 6 56 env29770 = env29771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env29770 == env29771) = true)

theorem identity29771 : scanCanonicalize (H12AffineFastState.compose env29771 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound29771 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29772 : List Nat := [2,4,8,13,32,13,37,8,43,4,42,1,3,1,6,36,0,7,4,7,1,33,12,46,47,12,43,0,0,6,9,12,9,12,1,43]

theorem envBound29772 : H12AffineFastState.Bounded env29772 := by
  intro p hp
  have h : env29772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29771_29772 : H12AffineEnvironment.transform 3 13 env29771 = env29772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env29771 == env29772) = true)

theorem identity29772 : scanCanonicalize (H12AffineFastState.compose env29772 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound29772 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29773 : List Nat := [2,4,8,13,12,13,9,8,7,4,6,1,3,1,6,8,0,7,4,7,1,13,12,2,3,12,7,0,0,6,9,12,9,12,1,7]

theorem envBound29773 : H12AffineFastState.Bounded env29773 := by
  intro p hp
  have h : env29773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29772_29773 : H12AffineEnvironment.transform 4 12 env29772 = env29773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env29772 == env29773) = true)

theorem identity29773 : scanCanonicalize (H12AffineFastState.compose env29773 (packedSelected [7] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound29773 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env29774 : List Nat := [2,2,8,11,10,11,9,8,1,2,0,1,3,1,0,8,0,1,2,1,1,11,10,2,3,10,1,0,0,0,9,10,9,10,1,1]

theorem envBound29774 : H12AffineFastState.Bounded env29774 := by
  intro p hp
  have h : env29774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29773_29774 : H12AffineEnvironment.transform 1 2 env29773 = env29774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env29773 == env29774) = true)

def env29775 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32882,1345,262144,42332,32769,1345,41088,17,263633,33237,41245,42275,1297,42060,43128,262562,262567,257,1280,1344,41820]

theorem envBound29775 : H12AffineFastState.Bounded env29775 := by
  intro p hp
  have h : env29775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29761_29775 : H12AffineEnvironment.transform 11 1345 env29761 = env29775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env29761 == env29775) = true)

theorem identity29775 : scanCanonicalize (H12AffineFastState.compose env29775 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 9454) := by decide +kernel

theorem selectedBound29775 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env29776 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32882,1345,9454,42332,32769,1345,41088,17,8511,33237,41245,42275,1297,42060,43128,9548,9545,257,1280,1344,41820]

theorem envBound29776 : H12AffineFastState.Bounded env29776 := by
  intro p hp
  have h : env29776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29775_29776 : H12AffineEnvironment.transform 17 9454 env29775 = env29776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 9454 env29775 == env29776) = true)

theorem identity29776 : scanCanonicalize (H12AffineFastState.compose env29776 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(10+1) ^^^ 1782) := by decide +kernel

theorem selectedBound29776 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env29777 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1782,1345,8192,1296,32768,32882,1345,9454,42332,32769,1345,41088,17,8511,33237,41245,42275,1297,42060,42638,9548,9545,257,1280,1344,41820]

theorem envBound29777 : H12AffineFastState.Bounded env29777 := by
  intro p hp
  have h : env29777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29776_29777 : H12AffineEnvironment.transform 10 1782 env29776 = env29777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1782 env29776 == env29777) = true)

def env29778 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1344,262144,77934,32769,4096,46528,17,266385,70887,78895,77840,1297,74814,81226,365712,365717,257,1280,1344,79470]

theorem envBound29778 : H12AffineFastState.Bounded env29778 := by
  intro p hp
  have h : env29778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29759_29778 : H12AffineEnvironment.transform 13 1297 env29759 = env29778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env29759 == env29778) = true)

theorem identity29778 : scanCanonicalize (H12AffineFastState.compose env29778 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound29778 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env29779 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1344,262144,77934,13341,4096,476,17,266385,70887,78895,77840,1297,74814,81226,336012,336009,257,1280,1344,79470]

theorem envBound29779 : H12AffineFastState.Bounded env29779 := by
  intro p hp
  have h : env29779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29778_29779 : H12AffineEnvironment.transform 14 13340 env29778 = env29779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env29778 == env29779) = true)

def env29780 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1344,65664,77934,13341,4096,476,17,69649,70887,78895,77840,1297,74814,81226,8204,8201,257,1280,1344,79470]

theorem envBound29780 : H12AffineFastState.Bounded env29780 := by
  intro p hp
  have h : env29780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29779_29780 : H12AffineEnvironment.transform 17 65664 env29779 = env29780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env29779 == env29780) = true)

theorem identity29780 : scanCanonicalize (H12AffineFastState.compose env29780 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5158) := by decide +kernel

theorem selectedBound29780 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env29781 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,5158,1344,5286,9288,13341,4096,476,17,1079,193,8201,9270,1297,12312,10604,8204,8201,257,1280,1344,8776]

theorem envBound29781 : H12AffineFastState.Bounded env29781 := by
  intro p hp
  have h : env29781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29780_29781 : H12AffineEnvironment.transform 15 5158 env29780 = env29781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5158 env29780 == env29781) = true)

def env29782 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,1297,13340,5158,1296,5286,9240,13341,4096,396,17,1079,145,8201,9270,1297,12312,10556,8204,8201,257,1280,1296,8728]

theorem envBound29782 : H12AffineFastState.Bounded env29782 := by
  intro p hp
  have h : env29782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29781_29782 : H12AffineEnvironment.transform 5 16 env29781 = env29782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env29781 == env29782) = true)

theorem identity29782 : scanCanonicalize (H12AffineFastState.compose env29782 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 4364) := by decide +kernel

theorem selectedBound29782 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env29783 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,4364,1297,1296,5158,1296,5286,5396,1297,4096,396,17,1079,145,4357,5434,1297,276,6192,4352,4357,257,1280,1296,4884]

theorem envBound29783 : H12AffineFastState.Bounded env29783 := by
  intro p hp
  have h : env29783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29782_29783 : H12AffineEnvironment.transform 12 4364 env29782 = env29783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4364 env29782 == env29783) = true)

theorem identity29783 : scanCanonicalize (H12AffineFastState.compose env29783 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound29783 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env29784 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,276,24,1297,1296,1330,1296,1458,1024,1297,276,396,17,1079,145,17,1070,1297,276,2340,20,17,257,1280,1296,512]

theorem envBound29784 : H12AffineFastState.Bounded env29784 := by
  intro p hp
  have h : env29784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29783_29784 : H12AffineEnvironment.transform 11 276 env29783 = env29784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env29783 == env29784) = true)

theorem identity29784 : scanCanonicalize (H12AffineFastState.compose env29784 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 276) := by decide +kernel

theorem selectedBound29784 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env29785 : List Nat := [2,4,8,16,32,16,128,256,512,1024,276,276,24,1297,1296,1330,1296,1458,1024,1297,276,396,17,1079,145,17,1070,1297,276,48,20,17,257,1280,1296,512]

theorem envBound29785 : H12AffineFastState.Bounded env29785 := by
  intro p hp
  have h : env29785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29784_29785 : H12AffineEnvironment.transform 10 276 env29784 = env29785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 276 env29784 == env29785) = true)

theorem identity29785 : scanCanonicalize (H12AffineFastState.compose env29785 (packedSelected [0,7,11] rootPS)) = affineNative (2^(7+1) ^^^ 157) := by decide +kernel

theorem selectedBound29785 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env29786 : List Nat := [2,4,8,16,32,16,128,157,512,1024,137,137,24,1164,1165,1199,1165,1071,1024,1164,137,17,17,1079,145,17,1070,1164,137,48,20,17,156,1181,1165,512]

theorem envBound29786 : H12AffineFastState.Bounded env29786 := by
  intro p hp
  have h : env29786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29785_29786 : H12AffineEnvironment.transform 7 157 env29785 = env29786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 157 env29785 == env29786) = true)

theorem identity29786 : scanCanonicalize (H12AffineFastState.compose env29786 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound29786 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env29787 : List Nat := [2,4,8,16,32,16,9,20,512,1024,0,0,24,1029,1028,1062,1028,1071,1024,1029,0,17,17,1079,24,17,1070,1029,0,48,20,17,21,1044,1028,512]

theorem envBound29787 : H12AffineFastState.Bounded env29787 := by
  intro p hp
  have h : env29787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29786_29787 : H12AffineEnvironment.transform 6 9 env29786 = env29787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env29786 == env29787) = true)

theorem identity29787 : scanCanonicalize (H12AffineFastState.compose env29787 (packedSelected [0,1] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound29787 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env29788 : List Nat := [2,4,8,16,32,16,9,20,512,52,0,0,24,49,48,18,48,27,52,49,0,17,17,3,24,17,26,49,0,48,20,17,21,32,48,512]

theorem envBound29788 : H12AffineFastState.Bounded env29788 := by
  intro p hp
  have h : env29788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29787_29788 : H12AffineEnvironment.transform 9 52 env29787 = env29788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env29787 == env29788) = true)

theorem identity29788 : scanCanonicalize (H12AffineFastState.compose env29788 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound29788 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29789 : List Nat := [2,4,8,16,32,16,9,20,1,52,0,0,24,49,48,18,48,27,52,49,0,17,17,3,24,17,26,49,0,48,20,17,21,32,48,1]

theorem envBound29789 : H12AffineFastState.Bounded env29789 := by
  intro p hp
  have h : env29789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29788_29789 : H12AffineEnvironment.transform 8 1 env29788 = env29789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env29788 == env29789) = true)

theorem identity29789 : scanCanonicalize (H12AffineFastState.compose env29789 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound29789 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env29790 : List Nat := [2,4,8,11,32,11,9,15,1,47,0,0,3,42,43,9,43,0,47,42,0,10,10,3,3,10,1,42,0,43,15,10,14,32,43,1]

theorem envBound29790 : H12AffineFastState.Bounded env29790 := by
  intro p hp
  have h : env29790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29789_29790 : H12AffineEnvironment.transform 3 11 env29789 = env29790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env29789 == env29790) = true)

def env29791 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,1297,13340,5158,1297,5286,9241,13341,4096,397,17,1079,144,8201,9270,1297,12312,10557,8204,8201,257,1280,1297,8729]

theorem envBound29791 : H12AffineFastState.Bounded env29791 := by
  intro p hp
  have h : env29791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29781_29791 : H12AffineEnvironment.transform 5 17 env29781 = env29791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env29781 == env29791) = true)

theorem identity29791 : scanCanonicalize (H12AffineFastState.compose env29791 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound29791 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env29792 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,276,8192,1297,9480,1330,1297,1458,9241,9481,276,397,17,1079,144,8201,9270,1297,8460,10557,8204,8201,257,1280,1297,8729]

theorem envBound29792 : H12AffineFastState.Bounded env29792 := by
  intro p hp
  have h : env29792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29791_29792 : H12AffineEnvironment.transform 11 276 env29791 = env29792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env29791 == env29792) = true)

theorem identity29792 : scanCanonicalize (H12AffineFastState.compose env29792 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound29792 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env29793 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,276,24,1297,1296,1330,1297,1458,1025,1297,276,397,17,1079,144,17,1070,1297,276,2341,20,17,257,1280,1297,513]

theorem envBound29793 : H12AffineFastState.Bounded env29793 := by
  intro p hp
  have h : env29793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29792_29793 : H12AffineEnvironment.transform 12 24 env29792 = env29793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env29792 == env29793) = true)

theorem identity29793 : scanCanonicalize (H12AffineFastState.compose env29793 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 549) := by decide +kernel

theorem selectedBound29793 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env29794 : List Nat := [2,4,8,16,32,17,128,256,512,549,2048,276,24,820,821,791,820,919,548,820,276,397,17,530,144,17,523,820,276,2341,20,17,257,805,820,513]

theorem envBound29794 : H12AffineFastState.Bounded env29794 := by
  intro p hp
  have h : env29794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29793_29794 : H12AffineEnvironment.transform 9 549 env29793 = env29794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 549 env29793 == env29794) = true)

theorem identity29794 : scanCanonicalize (H12AffineFastState.compose env29794 (packedSelected [0,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 798) := by decide +kernel

theorem selectedBound29794 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env29795 : List Nat := [2,4,8,16,32,17,128,256,512,549,798,276,24,820,821,791,820,919,548,820,276,397,17,530,144,17,523,820,276,571,20,17,257,805,820,513]

theorem envBound29795 : H12AffineFastState.Bounded env29795 := by
  intro p hp
  have h : env29795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29794_29795 : H12AffineEnvironment.transform 10 798 env29794 = env29795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 798 env29794 == env29795) = true)

theorem identity29795 : scanCanonicalize (H12AffineFastState.compose env29795 (packedSelected [12,13,15] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound29795 : packedSelected [12,13,15] rootPS < 2^1333 := by decide +kernel

def env29796 : List Nat := [2,4,8,16,32,17,128,20,512,549,522,0,24,544,545,515,544,643,548,544,0,153,17,530,144,17,523,544,0,571,20,17,21,561,544,513]

theorem envBound29796 : H12AffineFastState.Bounded env29796 := by
  intro p hp
  have h : env29796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29795_29796 : H12AffineEnvironment.transform 7 20 env29795 = env29796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env29795 == env29796) = true)

theorem identity29796 : scanCanonicalize (H12AffineFastState.compose env29796 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound29796 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29797 : List Nat := [2,4,8,1,32,0,128,5,512,549,522,0,9,544,545,515,544,643,548,544,0,136,0,515,129,0,523,544,0,554,5,0,4,544,544,513]

theorem envBound29797 : H12AffineFastState.Bounded env29797 := by
  intro p hp
  have h : env29797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29796_29797 : H12AffineEnvironment.transform 3 1 env29796 = env29797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env29796 == env29797) = true)

theorem identity29797 : scanCanonicalize (H12AffineFastState.compose env29797 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound29797 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env29798 : List Nat := [2,4,3,1,32,0,128,5,512,549,513,0,2,544,545,515,544,643,548,544,0,131,0,515,129,0,512,544,0,545,5,0,4,544,544,513]

theorem envBound29798 : H12AffineFastState.Bounded env29798 := by
  intro p hp
  have h : env29798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29797_29798 : H12AffineEnvironment.transform 2 3 env29797 = env29798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env29797 == env29798) = true)

theorem identity29798 : scanCanonicalize (H12AffineFastState.compose env29798 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 34) := by decide +kernel

theorem selectedBound29798 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env29799 : List Nat := [2,4,3,1,32,0,128,5,34,7,35,0,2,2,3,33,2,161,6,2,0,131,0,33,129,0,34,2,0,3,5,0,4,2,2,35]

theorem envBound29799 : H12AffineFastState.Bounded env29799 := by
  intro p hp
  have h : env29799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29798_29799 : H12AffineEnvironment.transform 8 34 env29798 = env29799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 34 env29798 == env29799) = true)

theorem identity29799 : scanCanonicalize (H12AffineFastState.compose env29799 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound29799 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env29800 : List Nat := [2,4,3,1,0,0,128,5,2,7,3,0,2,2,3,1,2,129,6,2,0,131,0,1,129,0,2,2,0,3,5,0,4,2,2,3]

theorem envBound29800 : H12AffineFastState.Bounded env29800 := by
  intro p hp
  have h : env29800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29799_29800 : H12AffineEnvironment.transform 4 0 env29799 = env29800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env29799 == env29800) = true)

theorem identity29800 : scanCanonicalize (H12AffineFastState.compose env29800 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound29800 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29801 : List Nat := [2,4,3,1,0,0,5,5,2,7,3,0,2,2,3,1,2,4,6,2,0,6,0,1,4,0,2,2,0,3,5,0,4,2,2,3]

theorem envBound29801 : H12AffineFastState.Bounded env29801 := by
  intro p hp
  have h : env29801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29800_29801 : H12AffineEnvironment.transform 6 5 env29800 = env29801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env29800 == env29801) = true)

theorem identity29801 : scanCanonicalize (H12AffineFastState.compose env29801 (packedSelected [5] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound29801 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env29802 : List Nat := [2,1,3,1,0,0,0,0,2,2,3,0,2,2,3,1,2,1,3,2,0,3,0,1,1,0,2,2,0,3,0,0,1,2,2,3]

theorem envBound29802 : H12AffineFastState.Bounded env29802 := by
  intro p hp
  have h : env29802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29801_29802 : H12AffineEnvironment.transform 1 1 env29801 = env29802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env29801 == env29802) = true)

theorem identity29802 : scanCanonicalize (H12AffineFastState.compose env29802 (packedSelected [7] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound29802 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env29803 : List Nat := [1,1,0,1,0,0,0,0,1,1,0,0,1,1,0,1,1,1,0,1,0,0,0,1,1,0,1,1,0,0,0,0,1,1,1,0]

theorem envBound29803 : H12AffineFastState.Bounded env29803 := by
  intro p hp
  have h : env29803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29802_29803 : H12AffineEnvironment.transform 0 1 env29802 = env29803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env29802 == env29803) = true)

def env29804 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1344,65665,77934,13341,4096,476,17,69648,70887,78895,77840,1297,74814,81226,8205,8200,257,1280,1344,79470]

theorem envBound29804 : H12AffineFastState.Bounded env29804 := by
  intro p hp
  have h : env29804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29779_29804 : H12AffineEnvironment.transform 17 65665 env29779 = env29804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env29779 == env29804) = true)

theorem identity29804 : scanCanonicalize (H12AffineFastState.compose env29804 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 359) := by decide +kernel

theorem selectedBound29804 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env29805 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,359,1344,486,12553,13341,4096,476,17,4471,5504,13640,12663,1297,9561,15405,8205,8200,257,1280,1344,14089]

theorem envBound29805 : H12AffineFastState.Bounded env29805 := by
  intro p hp
  have h : env29805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29804_29805 : H12AffineEnvironment.transform 15 359 env29804 = env29805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 359 env29804 == env29805) = true)

def env29806 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,7632,1297,2508,359,1344,486,3289,2509,4096,476,17,4471,5504,2200,3239,1297,6281,509,7645,7640,257,1280,1344,2777]

theorem envBound29806 : H12AffineFastState.Bounded env29806 := by
  intro p hp
  have h : env29806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29805_29806 : H12AffineEnvironment.transform 12 7632 env29805 = env29806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7632 env29805 == env29806) = true)

def env29807 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1344,4096,4240,1297,1164,359,1344,486,409,1165,4096,476,17,4471,5504,1496,487,1297,5577,509,4253,4248,257,1280,1344,1945]

theorem envBound29807 : H12AffineFastState.Bounded env29807 := by
  intro p hp
  have h : env29807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29806_29807 : H12AffineEnvironment.transform 10 1344 env29806 = env29807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1344 env29806 == env29807) = true)

theorem identity29807 : scanCanonicalize (H12AffineFastState.compose env29807 (packedSelected [13] rootPS)) = affineNative (2^(11+1) ^^^ 1313) := by decide +kernel

theorem selectedBound29807 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env29808 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1344,1313,1457,1297,1164,359,1344,486,409,1165,1313,476,17,1110,161,1496,487,1297,232,509,1468,1465,257,1280,1344,1945]

theorem envBound29808 : H12AffineFastState.Bounded env29808 := by
  intro p hp
  have h : env29808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29807_29808 : H12AffineEnvironment.transform 11 1313 env29807 = env29808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1313 env29807 == env29808) = true)

theorem identity29808 : scanCanonicalize (H12AffineFastState.compose env29808 (packedSelected [1,3,4,5,8,9,10,12,16,17,19,23] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound29808 : packedSelected [1,3,4,5,8,9,10,12,16,17,19,23] rootPS < 2^1333 := by decide +kernel

def env29809 : List Nat := [2,4,8,16,32,64,128,256,512,272,80,49,161,1,412,359,80,486,409,413,49,476,17,326,161,200,487,1,232,509,172,169,257,16,80,649]

theorem envBound29809 : H12AffineFastState.Bounded env29809 := by
  intro p hp
  have h : env29809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29808_29809 : H12AffineEnvironment.transform 9 272 env29808 = env29809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env29808 == env29809) = true)

theorem identity29809 : scanCanonicalize (H12AffineFastState.compose env29809 (packedSelected [0,1,2,4,7,8,9,10,11,15] rootPS)) = affineNative (2^(8+1) ^^^ 184) := by decide +kernel

theorem selectedBound29809 : packedSelected [0,1,2,4,7,8,9,10,11,15] rootPS < 2^1333 := by decide +kernel

def env29810 : List Nat := [2,4,8,16,32,64,128,256,184,272,80,49,161,1,412,359,80,486,409,413,49,476,17,326,161,200,487,1,232,509,172,169,257,16,80,49]

theorem envBound29810 : H12AffineFastState.Bounded env29810 := by
  intro p hp
  have h : env29810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29809_29810 : H12AffineEnvironment.transform 8 184 env29809 = env29810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 184 env29809 == env29810) = true)

theorem identity29810 : scanCanonicalize (H12AffineFastState.compose env29810 (packedSelected [0,2,4,5,7,8,9,12,16] rootPS)) = affineNative (2^(7+1) ^^^ 204) := by decide +kernel

theorem selectedBound29810 : packedSelected [0,2,4,5,7,8,9,12,16] rootPS < 2^1333 := by decide +kernel

def env29811 : List Nat := [2,4,8,16,32,64,128,204,184,220,80,49,161,1,80,171,80,42,85,81,49,16,17,138,161,200,43,1,232,49,172,169,205,16,80,49]

theorem envBound29811 : H12AffineFastState.Bounded env29811 := by
  intro p hp
  have h : env29811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29810_29811 : H12AffineEnvironment.transform 7 204 env29810 = env29811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 204 env29810 == env29811) = true)

theorem identity29811 : scanCanonicalize (H12AffineFastState.compose env29811 (packedSelected [1,4,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 66) := by decide +kernel

theorem selectedBound29811 : packedSelected [1,4,8,9] rootPS < 2^1333 := by decide +kernel

def env29812 : List Nat := [2,4,8,16,32,64,66,14,122,30,80,49,99,1,80,105,80,42,85,81,49,16,17,72,99,10,43,1,42,49,110,107,15,16,80,49]

theorem envBound29812 : H12AffineFastState.Bounded env29812 := by
  intro p hp
  have h : env29812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29811_29812 : H12AffineEnvironment.transform 6 66 env29811 = env29812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 66 env29811 == env29812) = true)

def env29813 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1345,4096,4241,1297,1165,359,1344,486,408,1164,4096,476,17,4471,5504,1497,486,1297,5576,509,4252,4249,257,1280,1344,1944]

theorem envBound29813 : H12AffineFastState.Bounded env29813 := by
  intro p hp
  have h : env29813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29806_29813 : H12AffineEnvironment.transform 10 1345 env29806 = env29813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1345 env29806 == env29813) = true)

theorem identity29813 : scanCanonicalize (H12AffineFastState.compose env29813 (packedSelected [13] rootPS)) = affineNative (2^(11+1) ^^^ 49) := by decide +kernel

theorem selectedBound29813 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env29814 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1345,49,160,1297,1165,359,1344,486,408,1164,49,476,17,326,1457,1497,486,1297,1529,509,173,168,257,1280,1344,1944]

theorem envBound29814 : H12AffineFastState.Bounded env29814 := by
  intro p hp
  have h : env29814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29813_29814 : H12AffineEnvironment.transform 11 49 env29813 = env29814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env29813 == env29814) = true)

theorem identity29814 : scanCanonicalize (H12AffineFastState.compose env29814 (packedSelected [0,1,2,4,7,8,9,10,11,15] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound29814 : packedSelected [0,1,2,4,7,8,9,10,11,15] rootPS < 2^1333 := by decide +kernel

def env29815 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1345,49,160,1297,1165,359,1344,486,408,1164,49,476,17,326,1457,1497,486,1297,1529,509,173,168,257,1280,1344,1297]

theorem envBound29815 : H12AffineFastState.Bounded env29815 := by
  intro p hp
  have h : env29815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29814_29815 : H12AffineEnvironment.transform 8 137 env29814 = env29815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env29814 == env29815) = true)

theorem identity29815 : scanCanonicalize (H12AffineFastState.compose env29815 (packedSelected [0,1,2,4,8,10,11,18,19,20,23] rootPS)) = affineNative (2^(7+1) ^^^ 183) := by decide +kernel

theorem selectedBound29815 : packedSelected [0,1,2,4,8,10,11,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env29816 : List Nat := [2,4,8,16,32,64,128,183,137,1024,1270,49,160,1190,1165,208,1271,81,47,1164,49,107,17,241,1030,1134,81,1190,1102,74,173,168,182,1207,1271,1190]

theorem envBound29816 : H12AffineFastState.Bounded env29816 := by
  intro p hp
  have h : env29816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29815_29816 : H12AffineEnvironment.transform 7 183 env29815 = env29816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 183 env29815 == env29816) = true)

theorem identity29816 : scanCanonicalize (H12AffineFastState.compose env29816 (packedSelected [0,3,4,8,12] rootPS)) = affineNative (2^(9+1) ^^^ 247) := by decide +kernel

theorem selectedBound29816 : packedSelected [0,3,4,8,12] rootPS < 2^1333 := by decide +kernel

def env29817 : List Nat := [2,4,8,16,32,64,128,183,137,247,1,49,160,81,122,208,0,81,47,123,49,107,17,241,241,153,81,81,185,74,173,168,182,64,0,81]

theorem envBound29817 : H12AffineFastState.Bounded env29817 := by
  intro p hp
  have h : env29817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29816_29817 : H12AffineEnvironment.transform 9 247 env29816 = env29817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 247 env29816 == env29817) = true)

theorem identity29817 : scanCanonicalize (H12AffineFastState.compose env29817 (packedSelected [0,4,5,7,8,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound29817 : packedSelected [0,4,5,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env29818 : List Nat := [2,4,8,16,32,11,128,183,137,188,1,49,160,26,49,155,0,26,47,48,49,32,17,186,186,153,26,26,185,1,173,168,182,11,0,26]

theorem envBound29818 : H12AffineFastState.Bounded env29818 := by
  intro p hp
  have h : env29818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29817_29818 : H12AffineEnvironment.transform 5 11 env29817 = env29818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env29817 == env29818) = true)

theorem identity29818 : scanCanonicalize (H12AffineFastState.compose env29818 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound29818 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env29819 : List Nat := [2,4,8,16,32,11,18,37,27,46,1,49,50,26,49,9,0,26,47,48,49,32,17,40,40,11,26,26,43,1,63,58,36,11,0,26]

theorem envBound29819 : H12AffineFastState.Bounded env29819 := by
  intro p hp
  have h : env29819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29818_29819 : H12AffineEnvironment.transform 6 18 env29818 = env29819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env29818 == env29819) = true)

theorem identity29819 : scanCanonicalize (H12AffineFastState.compose env29819 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound29819 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29820 : List Nat := [2,4,8,16,10,11,18,15,27,4,1,27,24,26,27,9,0,26,5,26,27,10,17,2,2,11,26,26,1,1,21,16,14,11,0,26]

theorem envBound29820 : H12AffineFastState.Bounded env29820 := by
  intro p hp
  have h : env29820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29819_29820 : H12AffineEnvironment.transform 4 10 env29819 = env29820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env29819 == env29820) = true)

theorem identity29820 : scanCanonicalize (H12AffineFastState.compose env29820 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound29820 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env29821 : List Nat := [2,4,0,16,2,3,18,7,19,4,1,19,16,18,19,1,0,18,5,18,19,2,17,2,2,3,18,18,1,1,21,16,6,3,0,18]

theorem envBound29821 : H12AffineFastState.Bounded env29821 := by
  intro p hp
  have h : env29821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29820_29821 : H12AffineEnvironment.transform 2 0 env29820 = env29821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env29820 == env29821) = true)

theorem identity29821 : scanCanonicalize (H12AffineFastState.compose env29821 (packedSelected [0,3] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound29821 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env29822 : List Nat := [2,4,0,2,2,3,0,7,1,4,1,1,2,0,1,1,0,0,5,0,1,2,3,2,2,3,0,0,1,1,7,2,6,3,0,0]

theorem envBound29822 : H12AffineFastState.Bounded env29822 := by
  intro p hp
  have h : env29822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29821_29822 : H12AffineEnvironment.transform 3 2 env29821 = env29822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env29821 == env29822) = true)

theorem identity29822 : scanCanonicalize (H12AffineFastState.compose env29822 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound29822 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29823 : List Nat := [2,2,0,2,2,3,0,1,1,2,1,1,2,0,1,1,0,0,3,0,1,2,3,2,2,3,0,0,1,1,1,2,0,3,0,0]

theorem envBound29823 : H12AffineFastState.Bounded env29823 := by
  intro p hp
  have h : env29823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29822_29823 : H12AffineEnvironment.transform 1 2 env29822 = env29823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env29822 == env29823) = true)

theorem identity29823 : scanCanonicalize (H12AffineFastState.compose env29823 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound29823 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env29824 : List Nat := [1,1,0,1,1,0,0,1,1,1,1,1,1,0,1,1,0,0,0,0,1,1,0,1,1,0,0,0,1,1,1,1,0,0,0,0]

theorem envBound29824 : H12AffineFastState.Bounded env29824 := by
  intro p hp
  have h : env29824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29823_29824 : H12AffineEnvironment.transform 0 1 env29823 = env29824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env29823 == env29824) = true)

def env29825 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,7633,1297,2509,359,1344,486,3288,2508,4096,476,17,4471,5504,2201,3238,1297,6280,508,7644,7641,257,1280,1344,2776]

theorem envBound29825 : H12AffineFastState.Bounded env29825 := by
  intro p hp
  have h : env29825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29805_29825 : H12AffineEnvironment.transform 12 7633 env29805 = env29825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7633 env29805 == env29825) = true)

def env29826 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1344,4096,4241,1297,1165,359,1344,486,408,1164,4096,476,17,4471,5504,1497,486,1297,5576,508,4252,4249,257,1280,1344,1944]

theorem envBound29826 : H12AffineFastState.Bounded env29826 := by
  intro p hp
  have h : env29826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29825_29826 : H12AffineEnvironment.transform 10 1344 env29825 = env29826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1344 env29825 == env29826) = true)

theorem identity29826 : scanCanonicalize (H12AffineFastState.compose env29826 (packedSelected [13] rootPS)) = affineNative (2^(11+1) ^^^ 1449) := by decide +kernel

theorem selectedBound29826 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env29827 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1344,1449,1336,1297,1165,359,1344,486,408,1164,1449,476,17,1246,41,1497,486,1297,97,508,1333,1328,257,1280,1344,1944]

theorem envBound29827 : H12AffineFastState.Bounded env29827 := by
  intro p hp
  have h : env29827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29826_29827 : H12AffineEnvironment.transform 11 1449 env29826 = env29827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1449 env29826 == env29827) = true)

theorem identity29827 : scanCanonicalize (H12AffineFastState.compose env29827 (packedSelected [3,5,7,8,9,10,15,16,20,24] rootPS)) = affineNative (2^(9+1) ^^^ 833) := by decide +kernel

theorem selectedBound29827 : packedSelected [3,5,7,8,9,10,15,16,20,24] rootPS < 2^1333 := by decide +kernel

def env29828 : List Nat := [2,4,8,16,32,64,128,256,512,833,513,744,633,592,972,359,513,486,408,973,744,476,17,927,41,664,486,592,97,508,628,625,257,577,513,217]

theorem envBound29828 : H12AffineFastState.Bounded env29828 := by
  intro p hp
  have h : env29828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29827_29828 : H12AffineEnvironment.transform 9 833 env29827 = env29828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 833 env29827 == env29828) = true)

theorem identity29828 : scanCanonicalize (H12AffineFastState.compose env29828 (packedSelected [0,1,2,4,8,10,11,12,15,17,18,20] rootPS)) = affineNative (2^(7+1) ^^^ 62) := by decide +kernel

theorem selectedBound29828 : packedSelected [0,1,2,4,8,10,11,12,15,17,18,20] rootPS < 2^1333 := by decide +kernel

def env29829 : List Nat := [2,4,8,16,32,64,128,62,512,639,513,744,633,592,754,89,513,216,166,755,744,226,17,673,41,664,216,592,97,194,628,625,63,577,513,217]

theorem envBound29829 : H12AffineFastState.Bounded env29829 := by
  intro p hp
  have h : env29829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29828_29829 : H12AffineEnvironment.transform 7 62 env29828 = env29829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 62 env29828 == env29829) = true)

theorem identity29829 : scanCanonicalize (H12AffineFastState.compose env29829 (packedSelected [1,2,3,5,8,10,15] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound29829 : packedSelected [1,2,3,5,8,10,15] rootPS < 2^1333 := by decide +kernel

def env29830 : List Nat := [2,4,8,16,32,32,128,62,512,543,513,648,537,560,658,57,513,184,166,659,648,130,17,673,41,664,184,560,1,162,532,529,63,545,513,185]

theorem envBound29830 : H12AffineFastState.Bounded env29830 := by
  intro p hp
  have h : env29830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29829_29830 : H12AffineEnvironment.transform 5 32 env29829 = env29830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env29829 == env29830) = true)

theorem identity29830 : scanCanonicalize (H12AffineFastState.compose env29830 (packedSelected [1,2,3,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound29830 : packedSelected [1,2,3,7,9] rootPS < 2^1333 := by decide +kernel

def env29831 : List Nat := [2,4,8,16,32,32,57,62,512,543,513,561,537,560,555,57,513,1,31,554,561,59,17,536,41,545,1,560,1,27,532,529,63,545,513,0]

theorem envBound29831 : H12AffineFastState.Bounded env29831 := by
  intro p hp
  have h : env29831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29830_29831 : H12AffineEnvironment.transform 6 57 env29830 = env29831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env29830 == env29831) = true)

theorem identity29831 : scanCanonicalize (H12AffineFastState.compose env29831 (packedSelected [1,2,5] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound29831 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env29832 : List Nat := [2,4,8,16,32,32,57,62,0,31,1,49,25,48,43,57,1,1,31,42,49,59,17,24,41,33,1,48,1,27,20,17,63,33,1,0]

theorem envBound29832 : H12AffineFastState.Bounded env29832 := by
  intro p hp
  have h : env29832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29831_29832 : H12AffineEnvironment.transform 8 0 env29831 = env29832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env29831 == env29832) = true)

theorem identity29832 : scanCanonicalize (H12AffineFastState.compose env29832 (packedSelected [0,1,2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound29832 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env29833 : List Nat := [2,4,8,10,32,32,35,36,0,5,1,43,3,42,43,35,1,1,5,42,43,33,11,2,41,33,1,42,1,1,14,11,37,33,1,0]

theorem envBound29833 : H12AffineFastState.Bounded env29833 := by
  intro p hp
  have h : env29833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29832_29833 : H12AffineEnvironment.transform 3 10 env29832 = env29833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env29832 == env29833) = true)

theorem identity29833 : scanCanonicalize (H12AffineFastState.compose env29833 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound29833 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env29834 : List Nat := [2,4,8,10,10,10,9,14,0,5,1,1,3,0,1,9,1,1,5,0,1,11,11,2,3,11,1,0,1,1,14,11,15,11,1,0]

theorem envBound29834 : H12AffineFastState.Bounded env29834 := by
  intro p hp
  have h : env29834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29833_29834 : H12AffineEnvironment.transform 4 10 env29833 = env29834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env29833 == env29834) = true)

theorem identity29834 : scanCanonicalize (H12AffineFastState.compose env29834 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound29834 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29835 : List Nat := [2,4,4,6,6,6,5,2,0,5,1,1,3,0,1,5,1,1,5,0,1,7,7,2,3,7,1,0,1,1,2,7,3,7,1,0]

theorem envBound29835 : H12AffineFastState.Bounded env29835 := by
  intro p hp
  have h : env29835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29834_29835 : H12AffineEnvironment.transform 2 4 env29834 = env29835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env29834 == env29835) = true)

def env29836 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1345,4096,4240,1297,1164,359,1344,486,409,1165,4096,476,17,4471,5504,1496,487,1297,5577,508,4253,4248,257,1280,1344,1945]

theorem envBound29836 : H12AffineFastState.Bounded env29836 := by
  intro p hp
  have h : env29836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29825_29836 : H12AffineEnvironment.transform 10 1345 env29825 = env29836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1345 env29825 == env29836) = true)

theorem identity29836 : scanCanonicalize (H12AffineFastState.compose env29836 (packedSelected [13] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound29836 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env29837 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1345,184,40,1297,1164,359,1344,486,409,1165,184,476,17,463,1336,1496,487,1297,1393,508,37,32,257,1280,1344,1945]

theorem envBound29837 : H12AffineFastState.Bounded env29837 := by
  intro p hp
  have h : env29837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29836_29837 : H12AffineEnvironment.transform 11 184 env29836 = env29837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env29836 == env29837) = true)

theorem identity29837 : scanCanonicalize (H12AffineFastState.compose env29837 (packedSelected [1,3,4,5,8,9,10,11,16,17,18,19,21] rootPS)) = affineNative (2^(9+1) ^^^ 386) := by decide +kernel

theorem selectedBound29837 : packedSelected [1,3,4,5,8,9,10,11,16,17,18,19,21] rootPS < 2^1333 := by decide +kernel

def env29838 : List Nat := [2,4,8,16,32,64,128,256,512,386,195,184,40,147,270,359,194,486,409,271,184,476,17,463,186,90,487,147,243,508,37,32,257,130,194,539]

theorem envBound29838 : H12AffineFastState.Bounded env29838 := by
  intro p hp
  have h : env29838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29837_29838 : H12AffineEnvironment.transform 9 386 env29837 = env29838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 386 env29837 == env29838) = true)

theorem identity29838 : scanCanonicalize (H12AffineFastState.compose env29838 (packedSelected [0,1,2,4,7,8,9,10,16] rootPS)) = affineNative (2^(8+1) ^^^ 81) := by decide +kernel

theorem selectedBound29838 : packedSelected [0,1,2,4,7,8,9,10,16] rootPS < 2^1333 := by decide +kernel

def env29839 : List Nat := [2,4,8,16,32,64,128,256,81,386,195,184,40,147,270,359,194,486,409,271,184,476,17,463,186,90,487,147,243,508,37,32,257,130,194,74]

theorem envBound29839 : H12AffineFastState.Bounded env29839 := by
  intro p hp
  have h : env29839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29838_29839 : H12AffineEnvironment.transform 8 81 env29838 = env29839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env29838 == env29839) = true)

theorem identity29839 : scanCanonicalize (H12AffineFastState.compose env29839 (packedSelected [2,3,4,5,9,11,15] rootPS)) = affineNative (2^(7+1) ^^^ 182) := by decide +kernel

theorem selectedBound29839 : packedSelected [2,3,4,5,9,11,15] rootPS < 2^1333 := by decide +kernel

def env29840 : List Nat := [2,4,8,16,32,64,128,182,81,52,195,184,40,147,184,209,194,80,47,185,184,106,17,121,186,90,81,147,243,74,37,32,183,130,194,74]

theorem envBound29840 : H12AffineFastState.Bounded env29840 := by
  intro p hp
  have h : env29840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29839_29840 : H12AffineEnvironment.transform 7 182 env29839 = env29840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 182 env29839 == env29840) = true)

theorem identity29840 : scanCanonicalize (H12AffineFastState.compose env29840 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound29840 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env29841 : List Nat := [2,4,8,16,32,64,18,36,81,52,81,42,40,1,42,67,80,80,47,43,42,106,17,121,40,90,81,1,97,74,37,32,37,16,80,74]

theorem envBound29841 : H12AffineFastState.Bounded env29841 := by
  intro p hp
  have h : env29841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29840_29841 : H12AffineEnvironment.transform 6 18 env29840 = env29841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env29840 == env29841) = true)

theorem identity29841 : scanCanonicalize (H12AffineFastState.compose env29841 (packedSelected [3,4,5,9] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound29841 : packedSelected [3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env29842 : List Nat := [2,4,8,16,11,64,18,15,81,31,81,1,3,1,1,67,80,80,4,0,1,65,17,82,3,90,81,1,74,74,14,11,14,16,80,74]

theorem envBound29842 : H12AffineFastState.Bounded env29842 := by
  intro p hp
  have h : env29842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29841_29842 : H12AffineEnvironment.transform 4 11 env29841 = env29842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env29841 == env29842) = true)

theorem identity29842 : scanCanonicalize (H12AffineFastState.compose env29842 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound29842 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env29843 : List Nat := [2,4,8,10,11,64,8,15,75,5,75,1,3,1,1,67,74,74,4,0,1,65,11,72,3,64,75,1,74,74,14,11,14,10,74,74]

theorem envBound29843 : H12AffineFastState.Bounded env29843 := by
  intro p hp
  have h : env29843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29842_29843 : H12AffineEnvironment.transform 3 10 env29842 = env29843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env29842 == env29843) = true)

theorem identity29843 : scanCanonicalize (H12AffineFastState.compose env29843 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 4) := by decide +kernel

theorem selectedBound29843 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29844 : List Nat := [2,4,8,10,11,4,8,15,15,5,15,1,3,1,1,7,14,14,4,0,1,5,11,12,3,4,15,1,14,14,14,11,14,10,14,14]

theorem envBound29844 : H12AffineFastState.Bounded env29844 := by
  intro p hp
  have h : env29844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29843_29844 : H12AffineEnvironment.transform 5 4 env29843 = env29844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 4 env29843 == env29844) = true)

theorem identity29844 : scanCanonicalize (H12AffineFastState.compose env29844 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound29844 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29845 : List Nat := [2,2,8,10,11,2,8,9,9,3,9,1,3,1,1,1,8,8,2,0,1,3,11,10,3,2,9,1,8,8,8,11,8,10,8,8]

theorem envBound29845 : H12AffineFastState.Bounded env29845 := by
  intro p hp
  have h : env29845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29844_29845 : H12AffineEnvironment.transform 1 2 env29844 = env29845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env29844 == env29845) = true)

theorem identity29845 : scanCanonicalize (H12AffineFastState.compose env29845 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound29845 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env29846 : List Nat := [2,2,2,0,1,2,2,3,3,3,3,1,3,1,1,1,2,2,2,0,1,3,1,0,3,2,3,1,2,2,2,1,2,0,2,2]

theorem envBound29846 : H12AffineFastState.Bounded env29846 := by
  intro p hp
  have h : env29846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29845_29846 : H12AffineEnvironment.transform 2 2 env29845 = env29846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env29845 == env29846) = true)

theorem identity29846 : scanCanonicalize (H12AffineFastState.compose env29846 (packedSelected [5] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound29846 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env29847 : List Nat := [1,1,1,0,1,1,1,0,0,0,0,1,0,1,1,1,1,1,1,0,1,0,1,0,0,1,0,1,1,1,1,1,1,0,1,1]

theorem envBound29847 : H12AffineFastState.Bounded env29847 := by
  intro p hp
  have h : env29847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29846_29847 : H12AffineEnvironment.transform 0 1 env29846 = env29847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env29846 == env29847) = true)

def env29848 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95615,32769,4096,61649,147520,284033,86518,209263,225344,148800,74814,96347,381312,381317,257,1280,1344,95103]

theorem envBound29848 : H12AffineFastState.Bounded env29848 := by
  intro p hp
  have h : env29848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29694_29848 : H12AffineEnvironment.transform 23 284033 env29694 = env29848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 284033 env29694 == env29848) = true)

def env29849 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16464,262144,95615,32769,4096,61649,16,284033,86518,94527,77840,1296,74814,96347,381312,381317,257,1280,1344,95103]

theorem envBound29849 : H12AffineFastState.Bounded env29849 := by
  intro p hp
  have h : env29849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29848_29849 : H12AffineEnvironment.transform 16 16464 env29848 = env29849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16464 env29848 == env29849) = true)

def env29850 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1344,262144,77935,32769,4096,46529,16,266385,70886,78895,77840,1296,74814,81227,365712,365717,257,1280,1344,79471]

theorem envBound29850 : H12AffineFastState.Bounded env29850 := by
  intro p hp
  have h : env29850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29849_29850 : H12AffineEnvironment.transform 13 1296 env29849 = env29850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env29849 == env29850) = true)

theorem identity29850 : scanCanonicalize (H12AffineFastState.compose env29850 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound29850 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env29851 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1344,262144,77935,13341,4096,477,16,266385,70886,78895,77840,1296,74814,81227,336012,336009,257,1280,1344,79471]

theorem envBound29851 : H12AffineFastState.Bounded env29851 := by
  intro p hp
  have h : env29851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29850_29851 : H12AffineEnvironment.transform 14 13340 env29850 = env29851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env29850 == env29851) = true)

def env29852 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1344,65664,77935,13341,4096,477,16,69649,70886,78895,77840,1296,74814,81227,8204,8201,257,1280,1344,79471]

theorem envBound29852 : H12AffineFastState.Bounded env29852 := by
  intro p hp
  have h : env29852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29851_29852 : H12AffineEnvironment.transform 17 65664 env29851 = env29852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env29851 == env29852) = true)

theorem identity29852 : scanCanonicalize (H12AffineFastState.compose env29852 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound29852 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env29853 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,80,12636,65536,0,65664,77935,12637,4096,477,16,69649,70054,78191,77840,80,74110,79883,8204,8201,257,64,0,78639]

theorem envBound29853 : H12AffineFastState.Bounded env29853 := by
  intro p hp
  have h : env29853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29852_29853 : H12AffineEnvironment.transform 9 320 env29852 = env29853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env29852 == env29853) = true)

def env29854 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,4096,8192,0,12556,65536,0,65664,77887,12557,4096,397,16,69649,70054,78143,77840,0,74030,79883,8204,8201,257,16,0,78639]

theorem envBound29854 : H12AffineFastState.Bounded env29854 := by
  intro p hp
  have h : env29854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29853_29854 : H12AffineEnvironment.transform 5 16 env29853 = env29854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env29853 == env29854) = true)

theorem identity29854 : scanCanonicalize (H12AffineFastState.compose env29854 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound29854 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env29855 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,277,8192,0,8217,65536,0,65664,74026,8216,277,397,16,65796,65715,73770,73989,0,74030,76062,8204,8201,257,16,0,74298]

theorem envBound29855 : H12AffineFastState.Bounded env29855 := by
  intro p hp
  have h : env29855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29854_29855 : H12AffineEnvironment.transform 11 277 env29854 = env29855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env29854 == env29855) = true)

theorem identity29855 : scanCanonicalize (H12AffineFastState.compose env29855 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 8250) := by decide +kernel

theorem selectedBound29855 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env29856 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,277,8192,0,8217,8250,0,8378,272,8216,277,397,16,8510,8329,16,319,0,276,2340,8204,8201,257,16,0,512]

theorem envBound29856 : H12AffineFastState.Bounded env29856 := by
  intro p hp
  have h : env29856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29855_29856 : H12AffineEnvironment.transform 15 8250 env29855 = env29856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8250 env29855 == env29856) = true)

theorem identity29856 : scanCanonicalize (H12AffineFastState.compose env29856 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 136) := by decide +kernel

theorem selectedBound29856 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env29857 : List Nat := [2,4,8,16,32,16,128,256,512,272,136,277,8192,0,8217,8250,0,8378,272,8216,277,397,16,8510,8329,16,319,0,276,428,8204,8201,257,16,0,512]

theorem envBound29857 : H12AffineFastState.Bounded env29857 := by
  intro p hp
  have h : env29857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29856_29857 : H12AffineEnvironment.transform 10 136 env29856 = env29857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 136 env29856 == env29857) = true)

theorem identity29857 : scanCanonicalize (H12AffineFastState.compose env29857 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound29857 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env29858 : List Nat := [2,4,8,16,32,16,128,256,1,272,136,277,8192,0,8217,8250,0,8378,272,8216,277,397,16,8510,8329,16,319,0,276,428,8204,8201,257,16,0,1]

theorem envBound29858 : H12AffineFastState.Bounded env29858 := by
  intro p hp
  have h : env29858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29857_29858 : H12AffineEnvironment.transform 8 1 env29857 = env29858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env29857 == env29858) = true)

theorem identity29858 : scanCanonicalize (H12AffineFastState.compose env29858 (packedSelected [3,8] rootPS)) = affineNative (2^(12+1) ^^^ 295) := by decide +kernel

theorem selectedBound29858 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env29859 : List Nat := [2,4,8,16,32,16,128,256,1,272,136,277,295,0,318,285,0,413,272,319,277,397,16,25,430,16,319,0,276,428,299,302,257,16,0,1]

theorem envBound29859 : H12AffineFastState.Bounded env29859 := by
  intro p hp
  have h : env29859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29858_29859 : H12AffineEnvironment.transform 12 295 env29858 = env29859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 295 env29858 == env29859) = true)

theorem identity29859 : scanCanonicalize (H12AffineFastState.compose env29859 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound29859 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env29860 : List Nat := [2,4,8,16,16,16,128,256,1,272,136,277,279,0,270,285,0,413,272,271,277,397,16,25,414,16,271,0,276,412,283,286,257,16,0,1]

theorem envBound29860 : H12AffineFastState.Bounded env29860 := by
  intro p hp
  have h : env29860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29859_29860 : H12AffineEnvironment.transform 4 16 env29859 = env29860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env29859 == env29860) = true)

theorem identity29860 : scanCanonicalize (H12AffineFastState.compose env29860 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound29860 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env29861 : List Nat := [2,4,8,16,16,16,9,256,1,272,1,277,279,0,270,285,0,276,272,271,277,260,16,25,279,16,271,0,276,277,283,286,257,16,0,1]

theorem envBound29861 : H12AffineFastState.Bounded env29861 := by
  intro p hp
  have h : env29861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29860_29861 : H12AffineEnvironment.transform 6 9 env29860 = env29861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env29860 == env29861) = true)

theorem identity29861 : scanCanonicalize (H12AffineFastState.compose env29861 (packedSelected [0,1,2] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound29861 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env29862 : List Nat := [2,4,8,16,16,16,9,15,1,31,1,26,24,0,1,18,0,27,31,0,26,11,16,25,24,16,0,0,27,26,20,17,14,16,0,1]

theorem envBound29862 : H12AffineFastState.Bounded env29862 := by
  intro p hp
  have h : env29862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29861_29862 : H12AffineEnvironment.transform 7 15 env29861 = env29862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env29861 == env29862) = true)

theorem identity29862 : scanCanonicalize (H12AffineFastState.compose env29862 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound29862 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29863 : List Nat := [2,4,8,12,12,12,9,15,1,3,1,6,4,0,1,14,0,7,3,0,6,11,12,5,4,12,0,0,7,6,8,13,14,12,0,1]

theorem envBound29863 : H12AffineFastState.Bounded env29863 := by
  intro p hp
  have h : env29863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29862_29863 : H12AffineEnvironment.transform 3 12 env29862 = env29863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env29862 == env29863) = true)

theorem identity29863 : scanCanonicalize (H12AffineFastState.compose env29863 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound29863 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29864 : List Nat := [2,3,8,11,11,11,9,8,1,3,1,1,3,0,1,9,0,0,3,0,1,11,11,2,3,11,0,0,0,1,8,10,9,11,0,1]

theorem envBound29864 : H12AffineFastState.Bounded env29864 := by
  intro p hp
  have h : env29864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29863_29864 : H12AffineEnvironment.transform 1 3 env29863 = env29864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env29863 == env29864) = true)

def env29865 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,4096,8192,1,12557,65536,0,65664,77886,12556,4096,396,16,69649,70054,78142,77840,1,74031,79883,8204,8201,257,17,0,78639]

theorem envBound29865 : H12AffineFastState.Bounded env29865 := by
  intro p hp
  have h : env29865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29853_29865 : H12AffineEnvironment.transform 5 17 env29853 = env29865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env29853 == env29865) = true)

theorem identity29865 : scanCanonicalize (H12AffineFastState.compose env29865 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 8250) := by decide +kernel

theorem selectedBound29865 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env29866 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,4096,8192,1,12557,8250,0,8378,4100,12556,4096,396,16,12331,12700,4356,4138,1,277,6193,8204,8201,257,17,0,4885]

theorem envBound29866 : H12AffineFastState.Bounded env29866 := by
  intro p hp
  have h : env29866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29865_29866 : H12AffineEnvironment.transform 15 8250 env29865 = env29866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8250 env29865 == env29866) = true)

theorem identity29866 : scanCanonicalize (H12AffineFastState.compose env29866 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound29866 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env29867 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,276,8192,1,8217,8250,0,8378,272,8216,276,396,16,8511,8328,16,318,1,277,2341,8204,8201,257,17,0,513]

theorem envBound29867 : H12AffineFastState.Bounded env29867 := by
  intro p hp
  have h : env29867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29866_29867 : H12AffineEnvironment.transform 11 276 env29866 = env29867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env29866 == env29867) = true)

theorem identity29867 : scanCanonicalize (H12AffineFastState.compose env29867 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 797) := by decide +kernel

theorem selectedBound29867 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env29868 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,276,797,1,772,807,0,935,272,773,276,396,16,546,917,16,318,1,277,2341,785,788,257,17,0,513]

theorem envBound29868 : H12AffineFastState.Bounded env29868 := by
  intro p hp
  have h : env29868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29867_29868 : H12AffineEnvironment.transform 12 797 env29867 = env29868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 797 env29867 == env29868) = true)

theorem identity29868 : scanCanonicalize (H12AffineFastState.compose env29868 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound29868 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env29869 : List Nat := [2,4,8,16,32,17,128,256,512,273,512,276,797,1,772,807,0,935,272,773,276,396,16,546,917,16,318,1,277,805,785,788,257,17,0,513]

theorem envBound29869 : H12AffineFastState.Bounded env29869 := by
  intro p hp
  have h : env29869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29868_29869 : H12AffineEnvironment.transform 10 512 env29868 = env29869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env29868 == env29869) = true)

theorem identity29869 : scanCanonicalize (H12AffineFastState.compose env29869 (packedSelected [2,3,5,8,12,13,17] rootPS)) = affineNative (2^(8+1) ^^^ 23) := by decide +kernel

theorem selectedBound29869 : packedSelected [2,3,5,8,12,13,17] rootPS < 2^1333 := by decide +kernel

def env29870 : List Nat := [2,4,8,16,32,17,128,256,23,273,23,276,266,1,275,304,0,432,272,274,276,396,16,53,386,16,318,1,277,306,262,259,257,17,0,22]

theorem envBound29870 : H12AffineFastState.Bounded env29870 := by
  intro p hp
  have h : env29870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29869_29870 : H12AffineEnvironment.transform 8 23 env29869 = env29870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 23 env29869 == env29870) = true)

theorem identity29870 : scanCanonicalize (H12AffineFastState.compose env29870 (packedSelected [0,2,7,18] rootPS)) = affineNative (2^(4+1) ^^^ 23) := by decide +kernel

theorem selectedBound29870 : packedSelected [0,2,7,18] rootPS < 2^1333 := by decide +kernel

def env29871 : List Nat := [2,4,8,16,23,17,128,256,23,273,23,276,266,1,275,263,0,391,272,274,276,396,16,2,386,16,265,1,277,261,262,259,257,17,0,22]

theorem envBound29871 : H12AffineFastState.Bounded env29871 := by
  intro p hp
  have h : env29871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29870_29871 : H12AffineEnvironment.transform 4 23 env29870 = env29871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 23 env29870 == env29871) = true)

theorem identity29871 : scanCanonicalize (H12AffineFastState.compose env29871 (packedSelected [0,2,3,5,12] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound29871 : packedSelected [0,2,3,5,12] rootPS < 2^1333 := by decide +kernel

def env29872 : List Nat := [2,4,8,3,4,2,128,256,4,258,4,263,266,1,256,263,0,391,259,257,263,396,3,2,386,3,265,1,262,261,262,259,257,2,0,5]

theorem envBound29872 : H12AffineFastState.Bounded env29872 := by
  intro p hp
  have h : env29872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29871_29872 : H12AffineEnvironment.transform 3 3 env29871 = env29872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env29871 == env29872) = true)

theorem identity29872 : scanCanonicalize (H12AffineFastState.compose env29872 (packedSelected [13] rootPS)) = affineNative (2^(7+1) ^^^ 129) := by decide +kernel

theorem selectedBound29872 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env29873 : List Nat := [2,4,8,3,4,2,128,129,4,131,4,134,139,1,129,134,0,6,130,128,134,13,3,2,3,3,136,1,135,132,135,130,128,2,0,5]

theorem envBound29873 : H12AffineFastState.Bounded env29873 := by
  intro p hp
  have h : env29873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29872_29873 : H12AffineEnvironment.transform 7 129 env29872 = env29873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 129 env29872 == env29873) = true)

theorem identity29873 : scanCanonicalize (H12AffineFastState.compose env29873 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 6) := by decide +kernel

theorem selectedBound29873 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env29874 : List Nat := [2,4,8,3,4,2,6,7,4,5,4,0,13,1,7,0,0,6,4,6,0,13,3,2,3,3,14,1,1,2,1,4,6,2,0,5]

theorem envBound29874 : H12AffineFastState.Bounded env29874 := by
  intro p hp
  have h : env29874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29873_29874 : H12AffineEnvironment.transform 6 6 env29873 = env29874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 6 env29873 == env29874) = true)

theorem identity29874 : scanCanonicalize (H12AffineFastState.compose env29874 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound29874 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29875 : List Nat := [2,0,8,3,0,2,2,3,0,1,0,0,9,1,3,0,0,2,0,2,0,9,3,2,3,3,10,1,1,2,1,0,2,2,0,1]

theorem envBound29875 : H12AffineFastState.Bounded env29875 := by
  intro p hp
  have h : env29875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29874_29875 : H12AffineEnvironment.transform 1 0 env29874 = env29875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env29874 == env29875) = true)

theorem identity29875 : scanCanonicalize (H12AffineFastState.compose env29875 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound29875 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29876 : List Nat := [2,0,2,3,0,2,2,3,0,1,0,0,3,1,3,0,0,2,0,2,0,3,3,2,3,3,0,1,1,2,1,0,2,2,0,1]

theorem envBound29876 : H12AffineFastState.Bounded env29876 := by
  intro p hp
  have h : env29876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29875_29876 : H12AffineEnvironment.transform 2 2 env29875 = env29876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env29875 == env29876) = true)

theorem identity29876 : scanCanonicalize (H12AffineFastState.compose env29876 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound29876 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env29877 : List Nat := [1,0,1,0,0,1,1,0,0,1,0,0,0,1,0,0,0,1,0,1,0,0,0,1,0,0,0,1,1,1,1,0,1,1,0,1]

theorem envBound29877 : H12AffineFastState.Bounded env29877 := by
  intro p hp
  have h : env29877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29876_29877 : H12AffineEnvironment.transform 0 1 env29876 = env29877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env29876 == env29877) = true)

def env29878 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1344,65665,77935,13341,4096,477,16,69648,70886,78895,77840,1296,74814,81227,8205,8200,257,1280,1344,79471]

theorem envBound29878 : H12AffineFastState.Bounded env29878 := by
  intro p hp
  have h : env29878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart2