import H12CloudChart2Data234

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans59347_59348 : H12AffineEnvironment.transform 7 172 env59347 = env59348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env59347 == env59348) = true)

def env59349 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61568,147472,41003,143497,20497,492566,148669,148668,96266,74795,90259,173,204946,1212,135680]

theorem envBound59349 : H12AffineFastState.Bounded env59349 := by
  intro p hp
  have h : env59349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59348_59349 : H12AffineEnvironment.transform 5 16 env59348 = env59349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env59348 == env59349) = true)

theorem identity59349 : scanCanonicalize (H12AffineFastState.compose env59349 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 45216) := by decide +kernel

theorem selectedBound59349 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env59350 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,45216,262144,42144,32769,4097,61568,61616,41003,32809,20497,341174,62493,62492,96266,74795,90259,173,102450,1212,41632]

theorem envBound59350 : H12AffineFastState.Bounded env59350 := by
  intro p hp
  have h : env59350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59349_59350 : H12AffineEnvironment.transform 16 45216 env59349 = env59350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45216 env59349 == env59350) = true)

theorem identity59350 : scanCanonicalize (H12AffineFastState.compose env59350 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound59350 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env59351 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1213,32768,65536,45216,262144,42144,32769,4097,46141,46093,41003,32809,5292,341174,45216,45217,81079,74795,74798,173,102450,1212,41632]

theorem envBound59351 : H12AffineFastState.Bounded env59351 := by
  intro p hp
  have h : env59351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59350_59351 : H12AffineEnvironment.transform 13 1213 env59350 = env59351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env59350 == env59351) = true)

theorem identity59351 : scanCanonicalize (H12AffineFastState.compose env59351 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound59351 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59352 : List Nat := [2,4,8,16,32,16,128,172,512,5,2048,4096,8192,184,32768,65536,45216,262144,41125,32769,4097,45112,45064,41003,32809,4265,340147,45216,45217,80050,73774,73771,173,102450,185,41632]

theorem envBound59352 : H12AffineFastState.Bounded env59352 := by
  intro p hp
  have h : env59352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59351_59352 : H12AffineEnvironment.transform 9 5 env59351 = env59352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env59351 == env59352) = true)

theorem identity59352 : scanCanonicalize (H12AffineFastState.compose env59352 (packedSelected [4,9,20] rootPS)) = affineNative (2^(15+1) ^^^ 37019) := by decide +kernel

theorem selectedBound59352 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env59353 : List Nat := [2,4,8,16,32,16,128,172,512,5,2048,4096,8192,184,32768,37019,45216,262144,41125,32769,4097,45112,45064,41003,32809,4265,303144,45216,45217,43049,45237,45232,173,169,185,41632]

theorem envBound59353 : H12AffineFastState.Bounded env59353 := by
  intro p hp
  have h : env59353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59352_59353 : H12AffineEnvironment.transform 15 37019 env59352 = env59353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 37019 env59352 == env59353) = true)

theorem identity59353 : scanCanonicalize (H12AffineFastState.compose env59353 (packedSelected [1,3,5,6,8,13] rootPS)) = affineNative (2^(17+1) ^^^ 2184) := by decide +kernel

theorem selectedBound59353 : packedSelected [1,3,5,6,8,13] rootPS < 2^1333 := by decide +kernel

def env59354 : List Nat := [2,4,8,16,32,16,128,172,512,5,2048,4096,8192,184,32768,37019,45216,2184,41125,32769,4097,45112,45064,41003,32809,4265,43168,45216,45217,43049,45237,45232,173,169,185,41632]

theorem envBound59354 : H12AffineFastState.Bounded env59354 := by
  intro p hp
  have h : env59354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59353_59354 : H12AffineEnvironment.transform 17 2184 env59353 = env59354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2184 env59353 == env59354) = true)

theorem identity59354 : scanCanonicalize (H12AffineFastState.compose env59354 (packedSelected [0,1,2,4,7,8,9,10] rootPS)) = affineNative (2^(14+1) ^^^ 2560) := by decide +kernel

theorem selectedBound59354 : packedSelected [0,1,2,4,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env59355 : List Nat := [2,4,8,16,32,16,128,172,512,5,2048,4096,8192,184,2560,6811,15008,2184,10917,2561,4097,14904,14856,10795,2601,4265,8864,15008,15009,8745,15029,15024,173,169,185,10400]

theorem envBound59355 : H12AffineFastState.Bounded env59355 := by
  intro p hp
  have h : env59355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59354_59355 : H12AffineEnvironment.transform 14 2560 env59354 = env59355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2560 env59354 == env59355) = true)

theorem identity59355 : scanCanonicalize (H12AffineFastState.compose env59355 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound59355 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env59356 : List Nat := [2,4,8,16,32,16,34,14,512,5,2048,4096,8192,26,2560,6713,14850,2090,10759,2561,4097,14904,14856,10795,2601,4107,8706,14850,14851,8745,14871,14866,15,11,27,10242]

theorem envBound59356 : H12AffineFastState.Bounded env59356 := by
  intro p hp
  have h : env59356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59355_59356 : H12AffineEnvironment.transform 6 34 env59355 = env59356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env59355 == env59356) = true)

theorem identity59356 : scanCanonicalize (H12AffineFastState.compose env59356 (packedSelected [5,6,8] rootPS)) = affineNative (2^(12+1) ^^^ 563) := by decide +kernel

theorem selectedBound59356 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59357 : List Nat := [2,4,8,16,32,16,34,14,512,5,2048,4096,563,26,2560,6713,6193,2090,2100,2561,4097,6155,6203,2072,2601,4107,49,6193,6192,26,6180,6177,15,11,27,2609]

theorem envBound59357 : H12AffineFastState.Bounded env59357 := by
  intro p hp
  have h : env59357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59356_59357 : H12AffineEnvironment.transform 12 563 env59356 = env59357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 563 env59356 == env59357) = true)

theorem identity59357 : scanCanonicalize (H12AffineFastState.compose env59357 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound59357 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59358 : List Nat := [2,4,8,16,10,16,8,14,512,5,2048,4096,537,26,2560,6675,6171,2048,2078,2561,4097,6155,6161,2072,2563,4107,27,6171,6170,26,6158,6155,15,11,27,2587]

theorem envBound59358 : H12AffineFastState.Bounded env59358 := by
  intro p hp
  have h : env59358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59357_59358 : H12AffineEnvironment.transform 4 10 env59357 = env59358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env59357 == env59358) = true)

theorem identity59358 : scanCanonicalize (H12AffineFastState.compose env59358 (packedSelected [1,6] rootPS)) = affineNative (2^(11+1) ^^^ 535) := by decide +kernel

theorem selectedBound59358 : packedSelected [1,6] rootPS < 2^1333 := by decide +kernel

def env59359 : List Nat := [2,4,8,16,10,16,8,14,512,5,2048,535,537,26,2560,2052,2572,2048,2078,2561,534,2588,2566,2072,2563,540,27,2572,2573,26,2585,2588,15,11,27,2587]

theorem envBound59359 : H12AffineFastState.Bounded env59359 := by
  intro p hp
  have h : env59359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59358_59359 : H12AffineEnvironment.transform 11 535 env59358 = env59359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 535 env59358 == env59359) = true)

theorem identity59359 : scanCanonicalize (H12AffineFastState.compose env59359 (packedSelected [1,4,5,9] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound59359 : packedSelected [1,4,5,9] rootPS < 2^1333 := by decide +kernel

def env59360 : List Nat := [2,4,8,16,10,16,8,14,512,5,1,535,537,26,513,5,525,1,31,512,534,541,519,25,514,540,27,525,524,26,536,541,15,11,27,538]

theorem envBound59360 : H12AffineFastState.Bounded env59360 := by
  intro p hp
  have h : env59360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59359_59360 : H12AffineEnvironment.transform 10 1 env59359 = env59360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env59359 == env59360) = true)

theorem identity59360 : scanCanonicalize (H12AffineFastState.compose env59360 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound59360 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env59361 : List Nat := [2,4,8,10,10,10,8,14,512,5,1,525,515,0,513,5,525,1,5,512,524,519,519,3,514,518,1,525,524,0,514,519,15,11,1,512]

theorem envBound59361 : H12AffineFastState.Bounded env59361 := by
  intro p hp
  have h : env59361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59360_59361 : H12AffineEnvironment.transform 3 10 env59360 = env59361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env59360 == env59361) = true)

theorem identity59361 : scanCanonicalize (H12AffineFastState.compose env59361 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 13) := by decide +kernel

theorem selectedBound59361 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59362 : List Nat := [2,4,8,10,10,10,8,14,13,5,1,0,14,0,12,5,0,1,5,13,1,10,10,3,15,11,1,0,1,0,15,10,15,11,1,13]

theorem envBound59362 : H12AffineFastState.Bounded env59362 := by
  intro p hp
  have h : env59362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59361_59362 : H12AffineEnvironment.transform 8 13 env59361 = env59362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 13 env59361 == env59362) = true)

theorem identity59362 : scanCanonicalize (H12AffineFastState.compose env59362 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound59362 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env59363 : List Nat := [2,4,5,7,7,7,5,3,0,5,1,0,3,0,1,5,0,1,5,0,1,7,7,3,2,6,1,0,1,0,2,7,2,6,1,0]

theorem envBound59363 : H12AffineFastState.Bounded env59363 := by
  intro p hp
  have h : env59363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59362_59363 : H12AffineEnvironment.transform 2 5 env59362 = env59363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env59362 == env59363) = true)

def env59364 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61569,147473,41003,143497,20497,492567,148668,148669,96267,74795,90259,173,204947,1213,135680]

theorem envBound59364 : H12AffineFastState.Bounded env59364 := by
  intro p hp
  have h : env59364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59348_59364 : H12AffineEnvironment.transform 5 17 env59348 = env59364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env59348 == env59364) = true)

theorem identity59364 : scanCanonicalize (H12AffineFastState.compose env59364 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 137352) := by decide +kernel

theorem selectedBound59364 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env59365 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,137352,136192,32769,4097,61569,147473,41003,143497,20497,105631,148668,148669,96267,74795,90259,173,204947,1213,135680]

theorem envBound59365 : H12AffineFastState.Bounded env59365 := by
  intro p hp
  have h : env59365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59364_59365 : H12AffineEnvironment.transform 17 137352 env59364 = env59365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137352 env59364 == env59365) = true)

theorem identity59365 : scanCanonicalize (H12AffineFastState.compose env59365 (packedSelected [1,5,8,18,19,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 13374) := by decide +kernel

theorem selectedBound59365 : packedSelected [1,5,8,18,19,23,24,26] rootPS < 2^1333 := by decide +kernel

def env59366 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,13374,131072,137352,136192,32769,4097,61569,147473,41003,143497,20497,43169,148668,148669,19509,4117,21677,173,136365,1213,135680]

theorem envBound59366 : H12AffineFastState.Bounded env59366 := by
  intro p hp
  have h : env59366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59365_59366 : H12AffineEnvironment.transform 15 13374 env59365 = env59366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13374 env59365 == env59366) = true)

theorem identity59366 : scanCanonicalize (H12AffineFastState.compose env59366 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound59366 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env59367 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1213,32768,13374,131072,137352,136192,32769,4097,46140,132268,41003,143497,5292,43169,131073,131072,2184,4117,4112,173,136365,1213,135680]

theorem envBound59367 : H12AffineFastState.Bounded env59367 := by
  intro p hp
  have h : env59367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59366_59367 : H12AffineEnvironment.transform 13 1213 env59366 = env59367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env59366 == env59367) = true)

theorem identity59367 : scanCanonicalize (H12AffineFastState.compose env59367 (packedSelected [13,17] rootPS)) = affineNative (2^(16+1) ^^^ 40985) := by decide +kernel

theorem selectedBound59367 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env59368 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1213,32768,13374,40985,47249,46105,32769,4097,46140,42165,41003,37008,5292,43169,40984,40985,2184,4117,4112,173,46260,1213,45593]

theorem envBound59368 : H12AffineFastState.Bounded env59368 := by
  intro p hp
  have h : env59368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59367_59368 : H12AffineEnvironment.transform 16 40985 env59367 = env59368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 40985 env59367 == env59368) = true)

theorem identity59368 : scanCanonicalize (H12AffineFastState.compose env59368 (packedSelected [0,4,5,7,8,9,10,13] rootPS)) = affineNative (2^(14+1) ^^^ 15551) := by decide +kernel

theorem selectedBound59368 : packedSelected [0,4,5,7,8,9,10,13] rootPS < 2^1333 := by decide +kernel

def env59369 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1213,15551,13374,7334,1070,2214,15550,4097,2179,6154,7316,11311,5292,5150,7335,7334,2184,4117,4112,173,2059,1213,3750]

theorem envBound59369 : H12AffineFastState.Bounded env59369 := by
  intro p hp
  have h : env59369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59368_59369 : H12AffineEnvironment.transform 14 15551 env59368 = env59369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 15551 env59368 == env59369) = true)

theorem identity59369 : scanCanonicalize (H12AffineFastState.compose env59369 (packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 3102) := by decide +kernel

theorem selectedBound59369 : packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env59370 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,3102,8192,1213,8353,10272,184,1070,2214,8352,3103,2179,1044,138,11311,2226,2048,185,184,2184,3083,3086,173,2059,1213,3750]

theorem envBound59370 : H12AffineFastState.Bounded env59370 := by
  intro p hp
  have h : env59370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59369_59370 : H12AffineEnvironment.transform 11 3102 env59369 = env59370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3102 env59369 == env59370) = true)

theorem identity59370 : scanCanonicalize (H12AffineFastState.compose env59370 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 1172) := by decide +kernel

theorem selectedBound59370 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env59371 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,3102,1172,1213,1077,3252,184,1070,2214,1076,3103,2179,1044,138,2235,2226,2048,185,184,2184,3083,3086,173,2059,1213,3750]

theorem envBound59371 : H12AffineFastState.Bounded env59371 := by
  intro p hp
  have h : env59371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59370_59371 : H12AffineEnvironment.transform 12 1172 env59370 = env59371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1172 env59370 == env59371) = true)

theorem identity59371 : scanCanonicalize (H12AffineFastState.compose env59371 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 663) := by decide +kernel

theorem selectedBound59371 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env59372 : List Nat := [2,4,8,16,32,17,128,172,512,663,2048,2697,515,554,674,2595,184,697,2214,675,2696,2179,643,138,2235,2226,2048,185,184,2184,2716,2713,173,2059,554,2097]

theorem envBound59372 : H12AffineFastState.Bounded env59372 := by
  intro p hp
  have h : env59372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59371_59372 : H12AffineEnvironment.transform 9 663 env59371 = env59372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 663 env59371 == env59372) = true)

theorem identity59372 : scanCanonicalize (H12AffineFastState.compose env59372 (packedSelected [1,2,3,4,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 658) := by decide +kernel

theorem selectedBound59372 : packedSelected [1,2,3,4,6,7] rootPS < 2^1333 := by decide +kernel

def env59373 : List Nat := [2,4,8,16,32,17,128,172,512,663,658,27,515,554,674,177,184,697,564,675,26,529,643,138,553,544,658,185,184,538,14,11,173,665,554,675]

theorem envBound59373 : H12AffineFastState.Bounded env59373 := by
  intro p hp
  have h : env59373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59372_59373 : H12AffineEnvironment.transform 10 658 env59372 = env59373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 658 env59372 == env59373) = true)

theorem identity59373 : scanCanonicalize (H12AffineFastState.compose env59373 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound59373 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59374 : List Nat := [2,4,8,16,32,17,128,172,137,30,27,27,138,163,43,177,184,48,189,42,26,152,10,138,160,169,27,185,184,147,14,11,173,16,163,42]

theorem envBound59374 : H12AffineFastState.Bounded env59374 := by
  intro p hp
  have h : env59374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59373_59374 : H12AffineEnvironment.transform 8 137 env59373 = env59374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env59373 == env59374) = true)

theorem identity59374 : scanCanonicalize (H12AffineFastState.compose env59374 (packedSelected [0,1,4] rootPS)) = affineNative (2^(6+1) ^^^ 21) := by decide +kernel

theorem selectedBound59374 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env59375 : List Nat := [2,4,8,16,32,17,21,57,28,30,27,27,31,54,43,36,45,48,40,42,26,13,10,31,53,60,27,44,45,6,14,11,56,16,54,42]

theorem envBound59375 : H12AffineFastState.Bounded env59375 := by
  intro p hp
  have h : env59375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59374_59375 : H12AffineEnvironment.transform 6 21 env59374 = env59375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 21 env59374 == env59375) = true)

theorem identity59375 : scanCanonicalize (H12AffineFastState.compose env59375 (packedSelected [1,5,6] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound59375 : packedSelected [1,5,6] rootPS < 2^1333 := by decide +kernel

def env59376 : List Nat := [2,3,8,16,32,17,18,57,27,25,27,27,24,49,43,35,42,48,40,42,26,10,10,24,50,59,27,43,42,1,9,11,56,16,49,42]

theorem envBound59376 : H12AffineFastState.Bounded env59376 := by
  intro p hp
  have h : env59376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59375_59376 : H12AffineEnvironment.transform 1 3 env59375 = env59376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env59375 == env59376) = true)

theorem identity59376 : scanCanonicalize (H12AffineFastState.compose env59376 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound59376 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env59377 : List Nat := [2,3,8,10,32,11,8,35,1,3,1,1,2,43,43,35,42,42,40,42,0,10,10,2,40,33,1,43,42,1,9,11,34,10,43,42]

theorem envBound59377 : H12AffineFastState.Bounded env59377 := by
  intro p hp
  have h : env59377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59376_59377 : H12AffineEnvironment.transform 3 10 env59376 = env59377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env59376 == env59377) = true)

theorem identity59377 : scanCanonicalize (H12AffineFastState.compose env59377 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound59377 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env59378 : List Nat := [2,3,8,10,10,11,8,9,1,3,1,1,2,1,1,9,0,0,2,0,0,10,10,2,2,11,1,1,0,1,9,11,8,10,1,0]

theorem envBound59378 : H12AffineFastState.Bounded env59378 := by
  intro p hp
  have h : env59378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59377_59378 : H12AffineEnvironment.transform 4 10 env59377 = env59378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env59377 == env59378) = true)

theorem identity59378 : scanCanonicalize (H12AffineFastState.compose env59378 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound59378 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59379 : List Nat := [0,1,8,8,8,9,8,9,1,1,1,1,0,1,1,9,0,0,0,0,0,8,8,0,0,9,1,1,0,1,9,9,8,8,1,0]

theorem envBound59379 : H12AffineFastState.Bounded env59379 := by
  intro p hp
  have h : env59379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59378_59379 : H12AffineEnvironment.transform 0 0 env59378 = env59379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env59378 == env59379) = true)

theorem identity59379 : scanCanonicalize (H12AffineFastState.compose env59379 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound59379 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env59380 : List Nat := [0,1,1,1,1,0,1,0,1,1,1,1,0,1,1,0,0,0,0,0,0,1,1,0,0,0,1,1,0,1,0,0,1,1,1,0]

theorem envBound59380 : H12AffineFastState.Bounded env59380 := by
  intro p hp
  have h : env59380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59379_59380 : H12AffineEnvironment.transform 2 1 env59379 = env59380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env59379 == env59380) = true)

def env59381 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147520,41003,143497,20497,492615,148716,148717,96346,74795,90258,172,204995,1261,135680]

theorem envBound59381 : H12AffineFastState.Bounded env59381 := by
  intro p hp
  have h : env59381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59347_59381 : H12AffineEnvironment.transform 7 173 env59347 = env59381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env59347 == env59381) = true)

def env59382 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61568,147472,41003,143497,20497,492567,148668,148669,96266,74795,90258,172,204947,1213,135680]

theorem envBound59382 : H12AffineFastState.Bounded env59382 := by
  intro p hp
  have h : env59382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59381_59382 : H12AffineEnvironment.transform 5 16 env59381 = env59382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env59381 == env59382) = true)

theorem identity59382 : scanCanonicalize (H12AffineFastState.compose env59382 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 114723) := by decide +kernel

theorem selectedBound59382 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env59383 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,114723,262144,119843,32769,4097,61568,98355,41003,127146,20497,279604,99487,99486,96266,74795,90258,172,57520,1213,119331]

theorem envBound59383 : H12AffineFastState.Bounded env59383 := by
  intro p hp
  have h : env59383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59382_59383 : H12AffineEnvironment.transform 16 114723 env59382 = env59383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114723 env59382 == env59383) = true)

theorem identity59383 : scanCanonicalize (H12AffineFastState.compose env59383 (packedSelected [3,10,16,18,19,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 104467) := by decide +kernel

theorem selectedBound59383 : packedSelected [3,10,16,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env59384 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,114723,104467,119843,32769,4097,61568,98355,41003,127146,20497,121895,99487,99486,96266,74795,90258,172,57520,1213,119331]

theorem envBound59384 : H12AffineFastState.Bounded env59384 := by
  intro p hp
  have h : env59384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59383_59384 : H12AffineEnvironment.transform 17 104467 env59383 = env59384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 104467 env59383 == env59384) = true)

theorem identity59384 : scanCanonicalize (H12AffineFastState.compose env59384 (packedSelected [7,16,18,19,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53283) := by decide +kernel

theorem selectedBound59384 : packedSelected [7,16,18,19,23,26,27] rootPS < 2^1333 := by decide +kernel

def env59385 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,53283,4096,18480,1024,32769,4097,61568,20496,41003,8329,20497,3076,21692,21693,43049,62472,45233,172,57520,1213,512]

theorem envBound59385 : H12AffineFastState.Bounded env59385 := by
  intro p hp
  have h : env59385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59384_59385 : H12AffineEnvironment.transform 15 53283 env59384 = env59385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53283 env59384 == env59385) = true)

theorem identity59385 : scanCanonicalize (H12AffineFastState.compose env59385 (packedSelected [4,9,16] rootPS)) = affineNative (2^(14+1) ^^^ 9380) := by decide +kernel

theorem selectedBound59385 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59386 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,9380,29831,4096,18480,1024,9381,4097,21540,20496,1167,8329,20497,3076,21692,21693,3213,20652,5141,172,17428,1213,512]

theorem envBound59386 : H12AffineFastState.Bounded env59386 := by
  intro p hp
  have h : env59386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59385_59386 : H12AffineEnvironment.transform 14 9380 env59385 = env59386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9380 env59385 == env59386) = true)

theorem identity59386 : scanCanonicalize (H12AffineFastState.compose env59386 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 8745) := by decide +kernel

theorem selectedBound59386 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env59387 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,8745,9380,5806,4096,10777,1024,9381,4097,13837,12857,1167,8329,12856,3076,13973,13972,3213,12933,5141,172,9789,1213,512]

theorem envBound59387 : H12AffineFastState.Bounded env59387 := by
  intro p hp
  have h : env59387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59386_59387 : H12AffineEnvironment.transform 13 8745 env59386 = env59387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8745 env59386 == env59387) = true)

theorem identity59387 : scanCanonicalize (H12AffineFastState.compose env59387 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound59387 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env59388 : List Nat := [2,4,8,16,32,16,128,173,27,1024,2048,4096,8192,8242,9380,5301,4096,10242,1024,9381,4097,13334,12322,1167,8329,12323,3076,13454,13455,3213,12446,5141,172,9254,1213,27]

theorem envBound59388 : H12AffineFastState.Bounded env59388 := by
  intro p hp
  have h : env59388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59387_59388 : H12AffineEnvironment.transform 8 27 env59387 = env59388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env59387 == env59388) = true)

theorem identity59388 : scanCanonicalize (H12AffineFastState.compose env59388 (packedSelected [0,2,3,5,9,11,12,15,17] rootPS)) = affineNative (2^(11+1) ^^^ 3077) := by decide +kernel

theorem selectedBound59388 : packedSelected [0,2,3,5,9,11,12,15,17] rootPS < 2^1333 := by decide +kernel

def env59389 : List Nat := [2,4,8,16,32,16,128,173,27,1024,2048,3077,8192,8242,9380,2224,3077,10242,1024,9381,3076,10259,11303,1167,8329,11302,3076,10379,10378,3213,11419,2064,172,9254,1213,27]

theorem envBound59389 : H12AffineFastState.Bounded env59389 := by
  intro p hp
  have h : env59389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59388_59389 : H12AffineEnvironment.transform 11 3077 env59388 = env59389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3077 env59388 == env59389) = true)

theorem identity59389 : scanCanonicalize (H12AffineFastState.compose env59389 (packedSelected [6,7,9,11,15] rootPS)) = affineNative (2^(12+1) ^^^ 3127) := by decide +kernel

theorem selectedBound59389 : packedSelected [6,7,9,11,15] rootPS < 2^1333 := by decide +kernel

def env59390 : List Nat := [2,4,8,16,32,16,128,173,27,1024,2048,3077,3127,3077,2195,2224,3077,1077,1024,2194,3076,1060,16,1167,3262,17,3076,1212,1213,3213,172,2064,172,2065,1213,27]

theorem envBound59390 : H12AffineFastState.Bounded env59390 := by
  intro p hp
  have h : env59390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59389_59390 : H12AffineEnvironment.transform 12 3127 env59389 = env59390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3127 env59389 == env59390) = true)

theorem identity59390 : scanCanonicalize (H12AffineFastState.compose env59390 (packedSelected [3,5,11] rootPS)) = affineNative (2^(9+1) ^^^ 150) := by decide +kernel

theorem selectedBound59390 : packedSelected [3,5,11] rootPS < 2^1333 := by decide +kernel

def env59391 : List Nat := [2,4,8,16,32,16,128,173,27,150,2048,2195,2209,2195,2195,2224,2195,163,150,2194,2194,178,16,25,2088,17,2194,42,43,2075,172,2064,172,2065,43,27]

theorem envBound59391 : H12AffineFastState.Bounded env59391 := by
  intro p hp
  have h : env59391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59390_59391 : H12AffineEnvironment.transform 9 150 env59390 = env59391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 150 env59390 == env59391) = true)

theorem identity59391 : scanCanonicalize (H12AffineFastState.compose env59391 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound59391 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env59392 : List Nat := [2,4,8,16,32,16,128,173,27,150,42,185,139,185,185,154,185,163,150,184,184,178,16,25,2,17,184,42,43,49,172,58,172,59,43,27]

theorem envBound59392 : H12AffineFastState.Bounded env59392 := by
  intro p hp
  have h : env59392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59391_59392 : H12AffineEnvironment.transform 10 42 env59391 = env59392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env59391 == env59392) = true)

theorem identity59392 : scanCanonicalize (H12AffineFastState.compose env59392 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 31) := by decide +kernel

theorem selectedBound59392 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env59393 : List Nat := [2,4,8,16,32,16,31,50,27,9,42,38,20,38,38,5,38,60,9,39,39,45,16,25,2,17,39,42,43,49,51,58,51,59,43,27]

theorem envBound59393 : H12AffineFastState.Bounded env59393 := by
  intro p hp
  have h : env59393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59392_59393 : H12AffineEnvironment.transform 6 31 env59392 = env59393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 31 env59392 == env59393) = true)

theorem identity59393 : scanCanonicalize (H12AffineFastState.compose env59393 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound59393 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env59394 : List Nat := [2,4,8,16,17,16,31,3,27,9,27,23,20,23,23,5,23,13,9,22,22,28,16,25,2,17,22,27,26,0,2,11,2,10,26,27]

theorem envBound59394 : H12AffineFastState.Bounded env59394 := by
  intro p hp
  have h : env59394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59393_59394 : H12AffineEnvironment.transform 4 17 env59393 = env59394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env59393 == env59394) = true)

theorem identity59394 : scanCanonicalize (H12AffineFastState.compose env59394 (packedSelected [0,2] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound59394 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env59395 : List Nat := [2,4,8,7,6,7,8,3,12,9,12,0,3,0,0,5,0,13,9,1,1,11,7,14,2,6,1,12,13,0,2,11,2,10,13,12]

theorem envBound59395 : H12AffineFastState.Bounded env59395 := by
  intro p hp
  have h : env59395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59394_59395 : H12AffineEnvironment.transform 3 7 env59394 = env59395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env59394 == env59395) = true)

theorem identity59395 : scanCanonicalize (H12AffineFastState.compose env59395 (packedSelected [6] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound59395 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env59396 : List Nat := [2,4,5,7,6,7,5,3,1,4,1,0,3,0,0,5,0,0,4,1,1,6,7,3,2,6,1,1,0,0,2,6,2,7,0,1]

theorem envBound59396 : H12AffineFastState.Bounded env59396 := by
  intro p hp
  have h : env59396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59395_59396 : H12AffineEnvironment.transform 2 5 env59395 = env59396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env59395 == env59396) = true)

def env59397 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61569,147473,41003,143497,20497,492566,148669,148668,96267,74795,90258,172,204946,1212,135680]

theorem envBound59397 : H12AffineFastState.Bounded env59397 := by
  intro p hp
  have h : env59397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59381_59397 : H12AffineEnvironment.transform 5 17 env59381 = env59397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env59381 == env59397) = true)

theorem identity59397 : scanCanonicalize (H12AffineFastState.compose env59397 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 223242) := by decide +kernel

theorem selectedBound59397 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env59398 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,223242,136192,32769,4097,61569,147473,41003,143497,20497,60444,148669,148668,96267,74795,90258,172,204946,1212,135680]

theorem envBound59398 : H12AffineFastState.Bounded env59398 := by
  intro p hp
  have h : env59398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59397_59398 : H12AffineEnvironment.transform 17 223242 env59397 = env59398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223242 env59397 == env59398) = true)

theorem identity59398 : scanCanonicalize (H12AffineFastState.compose env59398 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 28803) := by decide +kernel

theorem selectedBound59398 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env59399 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,28803,131072,137353,136192,32769,4097,61569,147473,41003,143497,20497,60444,148669,148668,2184,21672,4113,172,151569,1212,135680]

theorem envBound59399 : H12AffineFastState.Bounded env59399 := by
  intro p hp
  have h : env59399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59398_59399 : H12AffineEnvironment.transform 15 28803 env59398 = env59399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28803 env59398 == env59399) = true)

theorem identity59399 : scanCanonicalize (H12AffineFastState.compose env59399 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(16+1) ^^^ 61464) := by decide +kernel

theorem selectedBound59399 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env59400 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,28803,61464,59537,58392,32769,4097,61569,45065,41003,49297,20497,60444,46245,46244,2184,21672,4113,172,40969,1212,57880]

theorem envBound59400 : H12AffineFastState.Bounded env59400 := by
  intro p hp
  have h : env59400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59399_59400 : H12AffineEnvironment.transform 16 61464 env59399 = env59400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 61464 env59399 == env59400) = true)

theorem identity59400 : scanCanonicalize (H12AffineFastState.compose env59400 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound59400 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env59401 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1212,32768,13375,46244,44077,41124,32769,4097,46141,45065,41003,33837,5293,43168,46245,46244,2184,4116,4113,172,40969,1212,42660]

theorem envBound59401 : H12AffineFastState.Bounded env59401 := by
  intro p hp
  have h : env59401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59400_59401 : H12AffineEnvironment.transform 13 1212 env59400 = env59401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env59400 == env59401) = true)

theorem identity59401 : scanCanonicalize (H12AffineFastState.compose env59401 (packedSelected [6,12,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound59401 : packedSelected [6,12,13,15] rootPS < 2^1333 := by decide +kernel

def env59402 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,184,8192,1212,32768,9351,42012,44077,41124,32769,185,42117,41137,41003,33837,1045,43168,42013,42012,2184,172,169,172,40969,1212,42660]

theorem envBound59402 : H12AffineFastState.Bounded env59402 := by
  intro p hp
  have h : env59402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59401_59402 : H12AffineEnvironment.transform 11 184 env59401 = env59402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env59401 == env59402) = true)

theorem identity59402 : scanCanonicalize (H12AffineFastState.compose env59402 (packedSelected [1,2,3,6,10,11] rootPS)) = affineNative (2^(14+1) ^^^ 2707) := by decide +kernel

theorem selectedBound59402 : packedSelected [1,2,3,6,10,11] rootPS < 2^1333 := by decide +kernel

def env59403 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,184,8192,1212,2707,9351,11919,9918,10807,2706,185,11798,10786,10936,3774,1045,8755,11918,11919,2184,172,169,172,10906,1212,11319]

theorem envBound59403 : H12AffineFastState.Bounded env59403 := by
  intro p hp
  have h : env59403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59402_59403 : H12AffineEnvironment.transform 14 2707 env59402 = env59403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2707 env59402 == env59403) = true)

theorem identity59403 : scanCanonicalize (H12AffineFastState.compose env59403 (packedSelected [0,1,3,4,5,6,10,12] rootPS)) = affineNative (2^(8+1) ^^^ 180) := by decide +kernel

theorem selectedBound59403 : packedSelected [0,1,3,4,5,6,10,12] rootPS < 2^1333 := by decide +kernel

def env59404 : List Nat := [2,4,8,16,32,17,128,173,180,1024,2048,184,8192,1212,2087,9351,11323,9226,10371,2086,185,11426,10390,10252,3082,1045,8327,11322,11323,2184,172,169,172,10286,1212,11319]

theorem envBound59404 : H12AffineFastState.Bounded env59404 := by
  intro p hp
  have h : env59404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59403_59404 : H12AffineEnvironment.transform 8 180 env59403 = env59404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 180 env59403 == env59404) = true)

theorem identity59404 : scanCanonicalize (H12AffineFastState.compose env59404 (packedSelected [0,5,7,8,10,13,16] rootPS)) = affineNative (2^(9+1) ^^^ 176) := by decide +kernel

theorem selectedBound59404 : packedSelected [0,5,7,8,10,13,16] rootPS < 2^1333 := by decide +kernel

def env59405 : List Nat := [2,4,8,16,32,17,128,173,180,176,2048,184,8192,12,2087,8247,10379,8378,10371,2086,185,10258,10390,10252,2234,165,8327,10378,10379,2184,172,169,172,10286,12,10375]

theorem envBound59405 : H12AffineFastState.Bounded env59405 := by
  intro p hp
  have h : env59405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59404_59405 : H12AffineEnvironment.transform 9 176 env59404 = env59405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 176 env59404 == env59405) = true)

theorem identity59405 : scanCanonicalize (H12AffineFastState.compose env59405 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 163) := by decide +kernel

theorem selectedBound59405 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59406 : List Nat := [2,4,8,16,32,17,128,173,180,176,163,184,8192,12,132,8247,8232,8378,8224,133,185,8369,8245,8367,25,165,8327,8233,8232,43,172,169,172,8333,12,8228]

theorem envBound59406 : H12AffineFastState.Bounded env59406 := by
  intro p hp
  have h : env59406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59405_59406 : H12AffineEnvironment.transform 10 163 env59405 = env59406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 163 env59405 == env59406) = true)

def env59407 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147520,41003,143496,20496,493034,148801,148801,96346,74795,90430,257,205166,1344,135681]

theorem envBound59407 : H12AffineFastState.Bounded env59407 := by
  intro p hp
  have h : env59407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59346_59407 : H12AffineEnvironment.transform 18 136193 env59346 = env59407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136193 env59346 == env59407) = true)

def env59408 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147520,41003,143496,20496,492614,148717,148717,96346,74795,90258,173,204994,1260,135681]

theorem envBound59408 : H12AffineFastState.Bounded env59408 := by
  intro p hp
  have h : env59408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59407_59408 : H12AffineEnvironment.transform 7 172 env59407 = env59408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env59407 == env59408) = true)

def env59409 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61568,147472,41003,143496,20496,492566,148669,148669,96266,74795,90258,173,204946,1212,135681]

theorem envBound59409 : H12AffineFastState.Bounded env59409 := by
  intro p hp
  have h : env59409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59408_59409 : H12AffineEnvironment.transform 5 16 env59408 = env59409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env59408 == env59409) = true)

theorem identity59409 : scanCanonicalize (H12AffineFastState.compose env59409 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 137353) := by decide +kernel

theorem selectedBound59409 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env59410 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,137353,136193,32769,4097,61568,147472,41003,143496,20496,105631,148669,148669,96266,74795,90258,173,204946,1212,135681]

theorem envBound59410 : H12AffineFastState.Bounded env59410 := by
  intro p hp
  have h : env59410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59409_59410 : H12AffineEnvironment.transform 17 137353 env59409 = env59410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137353 env59409 == env59410) = true)

theorem identity59410 : scanCanonicalize (H12AffineFastState.compose env59410 (packedSelected [1,5,8,18,19,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 13374) := by decide +kernel

theorem selectedBound59410 : packedSelected [1,5,8,18,19,23,24,26] rootPS < 2^1333 := by decide +kernel

def env59411 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,13374,131072,137353,136193,32769,4097,61568,147472,41003,143496,20496,43169,148669,148669,19508,4117,21676,173,136364,1212,135681]

theorem envBound59411 : H12AffineFastState.Bounded env59411 := by
  intro p hp
  have h : env59411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59410_59411 : H12AffineEnvironment.transform 15 13374 env59410 = env59411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13374 env59410 == env59411) = true)

theorem identity59411 : scanCanonicalize (H12AffineFastState.compose env59411 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound59411 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env59412 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1212,32768,13374,131072,137353,136193,32769,4097,46140,132268,41003,143496,5292,43169,131073,131073,2184,4117,4112,173,136364,1212,135681]

theorem envBound59412 : H12AffineFastState.Bounded env59412 := by
  intro p hp
  have h : env59412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59411_59412 : H12AffineEnvironment.transform 13 1212 env59411 = env59412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env59411 == env59412) = true)

theorem identity59412 : scanCanonicalize (H12AffineFastState.compose env59412 (packedSelected [13,17] rootPS)) = affineNative (2^(14+1) ^^^ 12313) := by decide +kernel

theorem selectedBound59412 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env59413 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1212,12313,13374,131072,137353,136193,12312,4097,1061,132268,4146,143496,5292,6328,131073,131073,2184,4117,4112,173,136364,1212,135681]

theorem envBound59413 : H12AffineFastState.Bounded env59413 := by
  intro p hp
  have h : env59413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59412_59413 : H12AffineEnvironment.transform 14 12313 env59412 = env59413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12313 env59412 == env59413) = true)

theorem identity59413 : scanCanonicalize (H12AffineFastState.compose env59413 (packedSelected [0,4,5,7,8,9,10,13] rootPS)) = affineNative (2^(16+1) ^^^ 3102) := by decide +kernel

theorem selectedBound59413 : packedSelected [0,4,5,7,8,9,10,13] rootPS < 2^1333 := by decide +kernel

def env59414 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1212,12313,13374,3102,5271,6175,12312,4097,1061,2226,4146,15510,5292,6328,3103,3103,2184,4117,4112,173,6322,1212,7711]

theorem envBound59414 : H12AffineFastState.Bounded env59414 := by
  intro p hp
  have h : env59414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59413_59414 : H12AffineEnvironment.transform 16 3102 env59413 = env59414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 3102 env59413 == env59414) = true)

theorem identity59414 : scanCanonicalize (H12AffineFastState.compose env59414 (packedSelected [1,4,5,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound59414 : packedSelected [1,4,5,9,16] rootPS < 2^1333 := by decide +kernel

def env59415 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,1053,1212,5124,4131,3102,5271,6175,5125,4097,1061,2226,4146,6283,5292,6328,3103,3103,2184,4117,4112,173,6322,1212,7711]

theorem envBound59415 : H12AffineFastState.Bounded env59415 := by
  intro p hp
  have h : env59415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59414_59415 : H12AffineEnvironment.transform 12 1053 env59414 = env59415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env59414 == env59415) = true)

theorem identity59415 : scanCanonicalize (H12AffineFastState.compose env59415 (packedSelected [0,2,3,4,5,10,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 2194) := by decide +kernel

theorem selectedBound59415 : packedSelected [0,2,3,4,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env59416 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,2194,1053,1212,3222,2225,3102,3077,141,3223,2195,1061,2226,2208,25,3134,42,3103,3103,2184,2183,2178,173,32,1212,1677]

theorem envBound59416 : H12AffineFastState.Bounded env59416 := by
  intro p hp
  have h : env59416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59415_59416 : H12AffineEnvironment.transform 11 2194 env59415 = env59416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2194 env59415 == env59416) = true)

theorem identity59416 : scanCanonicalize (H12AffineFastState.compose env59416 (packedSelected [0,3,4,5,6,7,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound59416 : packedSelected [0,3,4,5,6,7,9,10] rootPS < 2^1333 := by decide +kernel

def env59417 : List Nat := [2,4,8,16,32,16,128,172,512,4,2048,2194,25,184,2194,2225,2074,2049,141,2195,2195,33,2226,2208,25,2106,42,2075,2075,2184,2183,2178,173,32,184,649]

theorem envBound59417 : H12AffineFastState.Bounded env59417 := by
  intro p hp
  have h : env59417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59416_59417 : H12AffineEnvironment.transform 9 4 env59416 = env59417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env59416 == env59417) = true)

theorem identity59417 : scanCanonicalize (H12AffineFastState.compose env59417 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(10+1) ^^^ 560) := by decide +kernel

theorem selectedBound59417 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env59418 : List Nat := [2,4,8,16,32,16,128,172,512,4,560,674,25,184,674,641,554,561,141,675,675,33,642,656,25,522,42,555,555,696,695,690,173,32,184,649]

theorem envBound59418 : H12AffineFastState.Bounded env59418 := by
  intro p hp
  have h : env59418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59417_59418 : H12AffineEnvironment.transform 10 560 env59417 = env59418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 560 env59417 == env59418) = true)

theorem identity59418 : scanCanonicalize (H12AffineFastState.compose env59418 (packedSelected [0,2,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 36) := by decide +kernel

theorem selectedBound59418 : packedSelected [0,2,5,7] rootPS < 2^1333 := by decide +kernel

def env59419 : List Nat := [2,4,8,16,32,16,36,8,512,4,560,518,25,28,518,549,554,561,41,519,519,33,550,564,25,522,42,555,555,540,531,534,9,32,28,557]

theorem envBound59419 : H12AffineFastState.Bounded env59419 := by
  intro p hp
  have h : env59419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59418_59419 : H12AffineEnvironment.transform 6 36 env59418 = env59419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 36 env59418 == env59419) = true)

theorem identity59419 : scanCanonicalize (H12AffineFastState.compose env59419 (packedSelected [0,1,2,4,5,11] rootPS)) = affineNative (2^(8+1) ^^^ 44) := by decide +kernel

theorem selectedBound59419 : packedSelected [0,1,2,4,5,11] rootPS < 2^1333 := by decide +kernel

def env59420 : List Nat := [2,4,8,16,32,16,36,8,44,4,28,42,25,28,42,9,6,29,41,43,43,33,10,24,25,38,42,7,7,48,63,58,9,32,28,1]

theorem envBound59420 : H12AffineFastState.Bounded env59420 := by
  intro p hp
  have h : env59420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59419_59420 : H12AffineEnvironment.transform 8 44 env59419 = env59420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 44 env59419 == env59420) = true)

theorem identity59420 : scanCanonicalize (H12AffineFastState.compose env59420 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound59420 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env59421 : List Nat := [2,4,8,16,13,16,9,8,1,4,28,7,25,28,7,9,6,29,4,6,6,12,10,24,25,11,7,7,7,29,18,23,9,13,28,1]

theorem envBound59421 : H12AffineFastState.Bounded env59421 := by
  intro p hp
  have h : env59421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59420_59421 : H12AffineEnvironment.transform 4 13 env59420 = env59421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env59420 == env59421) = true)

theorem identity59421 : scanCanonicalize (H12AffineFastState.compose env59421 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound59421 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59422 : List Nat := [2,4,8,11,13,11,9,8,1,4,7,7,2,7,7,9,6,6,4,6,6,12,10,3,2,11,7,7,7,6,9,12,9,13,7,1]

theorem envBound59422 : H12AffineFastState.Bounded env59422 := by
  intro p hp
  have h : env59422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59421_59422 : H12AffineEnvironment.transform 3 11 env59421 = env59422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env59421 == env59422) = true)

theorem identity59422 : scanCanonicalize (H12AffineFastState.compose env59422 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound59422 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59423 : List Nat := [2,3,8,11,10,11,9,8,1,3,0,0,2,0,0,9,1,1,3,1,1,11,10,3,2,11,0,0,0,1,9,11,9,10,0,1]

theorem envBound59423 : H12AffineFastState.Bounded env59423 := by
  intro p hp
  have h : env59423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59422_59423 : H12AffineEnvironment.transform 1 3 env59422 = env59423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env59422 == env59423) = true)

def env59424 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61569,147473,41003,143496,20496,492567,148668,148668,96267,74795,90258,173,204947,1213,135681]

theorem envBound59424 : H12AffineFastState.Bounded env59424 := by
  intro p hp
  have h : env59424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59408_59424 : H12AffineEnvironment.transform 5 17 env59408 = env59424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env59408 == env59424) = true)

theorem identity59424 : scanCanonicalize (H12AffineFastState.compose env59424 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 45217) := by decide +kernel

theorem selectedBound59424 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env59425 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,45217,262144,42144,32769,4097,61569,61616,41003,32809,20496,341174,62493,62493,96267,74795,90258,173,102450,1213,41632]

theorem envBound59425 : H12AffineFastState.Bounded env59425 := by
  intro p hp
  have h : env59425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59424_59425 : H12AffineEnvironment.transform 16 45217 env59424 = env59425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45217 env59424 == env59425) = true)

theorem identity59425 : scanCanonicalize (H12AffineFastState.compose env59425 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound59425 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env59426 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1212,32768,65536,45217,262144,42144,32769,4097,46141,46092,41003,32809,5292,341174,45217,45217,81079,74795,74798,173,102450,1213,41632]

theorem envBound59426 : H12AffineFastState.Bounded env59426 := by
  intro p hp
  have h : env59426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59425_59426 : H12AffineEnvironment.transform 13 1212 env59425 = env59426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env59425 == env59426) = true)

theorem identity59426 : scanCanonicalize (H12AffineFastState.compose env59426 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound59426 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59427 : List Nat := [2,4,8,16,32,17,128,172,512,4,2048,4096,8192,184,32768,65536,45217,262144,41124,32769,4097,45113,45064,41003,32809,4264,340146,45217,45217,80051,73775,73770,173,102450,185,41632]

theorem envBound59427 : H12AffineFastState.Bounded env59427 := by
  intro p hp
  have h : env59427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59426_59427 : H12AffineEnvironment.transform 9 4 env59426 = env59427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env59426 == env59427) = true)

theorem identity59427 : scanCanonicalize (H12AffineFastState.compose env59427 (packedSelected [4,9,20] rootPS)) = affineNative (2^(15+1) ^^^ 37018) := by decide +kernel

theorem selectedBound59427 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env59428 : List Nat := [2,4,8,16,32,17,128,172,512,4,2048,4096,8192,184,32768,37018,45217,262144,41124,32769,4097,45113,45064,41003,32809,4264,303144,45217,45217,43049,45237,45232,173,168,185,41632]

theorem envBound59428 : H12AffineFastState.Bounded env59428 := by
  intro p hp
  have h : env59428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59427_59428 : H12AffineEnvironment.transform 15 37018 env59427 = env59428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 37018 env59427 == env59428) = true)

theorem identity59428 : scanCanonicalize (H12AffineFastState.compose env59428 (packedSelected [1,3,5,6,8,13] rootPS)) = affineNative (2^(17+1) ^^^ 43048) := by decide +kernel

theorem selectedBound59428 : packedSelected [1,3,5,6,8,13] rootPS < 2^1333 := by decide +kernel

def env59429 : List Nat := [2,4,8,16,32,17,128,172,512,4,2048,4096,8192,184,32768,37018,45217,43048,41124,32769,4097,45113,45064,41003,32809,4264,2048,45217,45217,43049,45237,45232,173,168,185,41632]

theorem envBound59429 : H12AffineFastState.Bounded env59429 := by
  intro p hp
  have h : env59429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59428_59429 : H12AffineEnvironment.transform 17 43048 env59428 = env59429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43048 env59428 == env59429) = true)

theorem identity59429 : scanCanonicalize (H12AffineFastState.compose env59429 (packedSelected [2,3,4,6,8,9] rootPS)) = affineNative (2^(14+1) ^^^ 12987) := by decide +kernel

theorem selectedBound59429 : packedSelected [2,3,4,6,8,9] rootPS < 2^1333 := by decide +kernel

def env59430 : List Nat := [2,4,8,16,32,17,128,172,512,4,2048,4096,8192,184,12987,8737,538,6803,4639,12986,4097,642,691,4752,12946,4264,2048,538,538,6802,526,523,173,168,185,4123]

theorem envBound59430 : H12AffineFastState.Bounded env59430 := by
  intro p hp
  have h : env59430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59429_59430 : H12AffineEnvironment.transform 14 12987 env59429 = env59430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12987 env59429 == env59430) = true)

theorem identity59430 : scanCanonicalize (H12AffineFastState.compose env59430 (packedSelected [0,1,2,3,4,6,10] rootPS)) = affineNative (2^(10+1) ^^^ 162) := by decide +kernel

theorem selectedBound59430 : packedSelected [0,1,2,3,4,6,10] rootPS < 2^1333 := by decide +kernel

def env59431 : List Nat := [2,4,8,16,32,17,128,172,512,4,162,4096,8192,184,12987,8737,538,4657,4639,12986,4097,642,691,4752,12946,4264,162,538,538,4656,526,523,173,168,185,4123]

theorem envBound59431 : H12AffineFastState.Bounded env59431 := by
  intro p hp
  have h : env59431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59430_59431 : H12AffineEnvironment.transform 10 162 env59430 = env59431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 162 env59430 == env59431) = true)

theorem identity59431 : scanCanonicalize (H12AffineFastState.compose env59431 (packedSelected [2,3,8] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound59431 : packedSelected [2,3,8] rootPS < 2^1333 := by decide +kernel

def env59432 : List Nat := [2,4,8,10,32,11,128,172,512,4,162,4096,8192,162,12961,8737,512,4651,4613,12960,4097,642,681,4746,12936,4264,162,512,512,4650,526,523,173,168,163,4097]

theorem envBound59432 : H12AffineFastState.Bounded env59432 := by
  intro p hp
  have h : env59432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59431_59432 : H12AffineEnvironment.transform 3 10 env59431 = env59432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env59431 == env59432) = true)

theorem identity59432 : scanCanonicalize (H12AffineFastState.compose env59432 (packedSelected [1,2,5,6] rootPS)) = affineNative (2^(12+1) ^^^ 672) := by decide +kernel

theorem selectedBound59432 : packedSelected [1,2,5,6] rootPS < 2^1333 := by decide +kernel

def env59433 : List Nat := [2,4,8,10,32,11,128,172,512,4,162,4096,672,162,4097,129,512,4651,4613,4096,4097,642,681,4746,4136,4264,162,512,512,4650,526,523,173,168,163,4097]

theorem envBound59433 : H12AffineFastState.Bounded env59433 := by
  intro p hp
  have h : env59433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59432_59433 : H12AffineEnvironment.transform 12 672 env59432 = env59433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 672 env59432 == env59433) = true)

theorem identity59433 : scanCanonicalize (H12AffineFastState.compose env59433 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound59433 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env59434 : List Nat := [2,4,8,10,11,11,128,135,512,4,137,4096,651,137,4097,129,512,4608,4613,4096,4097,642,642,4746,4099,4227,137,512,512,4609,526,523,134,131,136,4097]

theorem envBound59434 : H12AffineFastState.Bounded env59434 := by
  intro p hp
  have h : env59434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59433_59434 : H12AffineEnvironment.transform 4 11 env59433 = env59434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env59433 == env59434) = true)

theorem identity59434 : scanCanonicalize (H12AffineFastState.compose env59434 (packedSelected [1,2,5] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound59434 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env59435 : List Nat := [2,4,8,10,11,11,128,135,512,4,137,1,651,137,0,129,512,513,516,1,0,642,642,651,2,130,137,512,512,512,526,523,134,131,136,0]

theorem envBound59435 : H12AffineFastState.Bounded env59435 := by
  intro p hp
  have h : env59435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59434_59435 : H12AffineEnvironment.transform 11 1 env59434 = env59435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env59434 == env59435) = true)

theorem identity59435 : scanCanonicalize (H12AffineFastState.compose env59435 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound59435 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env59436 : List Nat := [2,4,5,7,6,6,128,135,512,4,132,1,646,132,0,129,512,513,516,1,0,642,642,646,2,130,132,512,512,512,515,518,134,131,133,0]

theorem envBound59436 : H12AffineFastState.Bounded env59436 := by
  intro p hp
  have h : env59436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59435_59436 : H12AffineEnvironment.transform 2 5 env59435 = env59436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env59435 == env59436) = true)

theorem identity59436 : scanCanonicalize (H12AffineFastState.compose env59436 (packedSelected [4,7] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound59436 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env59437 : List Nat := [2,4,5,7,6,6,5,2,512,4,1,1,515,1,0,4,512,513,516,1,0,519,519,515,2,7,1,512,512,512,515,518,3,6,0,0]

theorem envBound59437 : H12AffineFastState.Bounded env59437 := by
  intro p hp
  have h : env59437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59436_59437 : H12AffineEnvironment.transform 6 5 env59436 = env59437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env59436 == env59437) = true)

theorem identity59437 : scanCanonicalize (H12AffineFastState.compose env59437 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound59437 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59438 : List Nat := [2,4,5,7,6,6,5,2,0,4,1,1,3,1,0,4,0,1,4,1,0,7,7,3,2,7,1,0,0,0,3,6,3,6,0,0]

theorem envBound59438 : H12AffineFastState.Bounded env59438 := by
  intro p hp
  have h : env59438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59437_59438 : H12AffineEnvironment.transform 8 0 env59437 = env59438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env59437 == env59438) = true)

def env59439 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147520,41003,143496,20496,492615,148716,148716,96346,74795,90259,172,204995,1261,135681]

theorem envBound59439 : H12AffineFastState.Bounded env59439 := by
  intro p hp
  have h : env59439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59407_59439 : H12AffineEnvironment.transform 7 173 env59407 = env59439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env59407 == env59439) = true)

def env59440 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61568,147472,41003,143496,20496,492567,148668,148668,96266,74795,90259,172,204947,1213,135681]

theorem envBound59440 : H12AffineFastState.Bounded env59440 := by
  intro p hp
  have h : env59440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59439_59440 : H12AffineEnvironment.transform 5 16 env59439 = env59440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env59439 == env59440) = true)

theorem identity59440 : scanCanonicalize (H12AffineFastState.compose env59440 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 223242) := by decide +kernel

theorem selectedBound59440 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env59441 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,223242,136193,32769,4097,61568,147472,41003,143496,20496,60445,148668,148668,96266,74795,90259,172,204947,1213,135681]

theorem envBound59441 : H12AffineFastState.Bounded env59441 := by
  intro p hp
  have h : env59441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59440_59441 : H12AffineEnvironment.transform 17 223242 env59440 = env59441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223242 env59440 == env59441) = true)

theorem identity59441 : scanCanonicalize (H12AffineFastState.compose env59441 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 28802) := by decide +kernel

theorem selectedBound59441 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env59442 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,28802,131072,137352,136193,32769,4097,61568,147472,41003,143496,20496,60445,148668,148668,2184,21673,4113,172,151569,1213,135681]

theorem envBound59442 : H12AffineFastState.Bounded env59442 := by
  intro p hp
  have h : env59442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59441_59442 : H12AffineEnvironment.transform 15 28802 env59441 = env59442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28802 env59441 == env59442) = true)

theorem identity59442 : scanCanonicalize (H12AffineFastState.compose env59442 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(16+1) ^^^ 61465) := by decide +kernel

theorem selectedBound59442 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env59443 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,28802,61465,59537,58392,32769,4097,61568,45065,41003,49297,20496,60445,46245,46245,2184,21673,4113,172,40968,1213,57880]

theorem envBound59443 : H12AffineFastState.Bounded env59443 := by
  intro p hp
  have h : env59443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59442_59443 : H12AffineEnvironment.transform 16 61465 env59442 = env59443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 61465 env59442 == env59443) = true)

theorem identity59443 : scanCanonicalize (H12AffineFastState.compose env59443 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound59443 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env59444 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1213,32768,13375,46244,44076,41125,32769,4097,46141,45065,41003,33836,5293,43168,46245,46245,2184,4116,4113,172,40968,1213,42661]

theorem envBound59444 : H12AffineFastState.Bounded env59444 := by
  intro p hp
  have h : env59444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59443_59444 : H12AffineEnvironment.transform 13 1213 env59443 = env59444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env59443 == env59444) = true)

theorem identity59444 : scanCanonicalize (H12AffineFastState.compose env59444 (packedSelected [6,12,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 1213) := by decide +kernel

theorem selectedBound59444 : packedSelected [6,12,13,15] rootPS < 2^1333 := by decide +kernel

def env59445 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,1213,8192,1213,32768,8322,40985,44076,41125,32769,1212,41088,42164,41003,33836,16,43168,40984,40984,2184,1193,1196,172,40968,1213,42661]

theorem envBound59445 : H12AffineFastState.Bounded env59445 := by
  intro p hp
  have h : env59445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59444_59445 : H12AffineEnvironment.transform 11 1213 env59444 = env59445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1213 env59444 == env59445) = true)

theorem identity59445 : scanCanonicalize (H12AffineFastState.compose env59445 (packedSelected [1,2,3,6,10,11] rootPS)) = affineNative (2^(14+1) ^^^ 2706) := by decide +kernel

theorem selectedBound59445 : packedSelected [1,2,3,6,10,11] rootPS < 2^1333 := by decide +kernel

def env59446 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,1213,8192,1213,2706,8322,10891,9918,10807,2707,1212,10770,11814,10937,3774,16,8754,10890,10890,2184,1193,1196,172,10906,1213,11319]

theorem envBound59446 : H12AffineFastState.Bounded env59446 := by
  intro p hp
  have h : env59446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59445_59446 : H12AffineEnvironment.transform 14 2706 env59445 = env59446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2706 env59445 == env59446) = true)

theorem identity59446 : scanCanonicalize (H12AffineFastState.compose env59446 (packedSelected [0,4,5,7,8,9,10,13] rootPS)) = affineNative (2^(12+1) ^^^ 3127) := by decide +kernel

theorem selectedBound59446 : packedSelected [0,4,5,7,8,9,10,13] rootPS < 2^1333 := by decide +kernel

def env59447 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,1213,3127,1213,2706,3253,1724,2697,1536,2707,1212,1573,529,1678,3774,16,3589,1725,1725,2184,1193,1196,172,1709,1213,0]

theorem envBound59447 : H12AffineFastState.Bounded env59447 := by
  intro p hp
  have h : env59447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59446_59447 : H12AffineEnvironment.transform 12 3127 env59446 = env59447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3127 env59446 == env59447) = true)

theorem identity59447 : scanCanonicalize (H12AffineFastState.compose env59447 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 675) := by decide +kernel

theorem selectedBound59447 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59448 : List Nat := [2,4,8,16,32,16,128,173,512,1024,675,1213,1684,1213,49,1558,1724,42,1536,48,1212,1573,529,1678,1053,16,1190,1725,1725,555,1193,1196,172,1709,1213,0]

theorem envBound59448 : H12AffineFastState.Bounded env59448 := by
  intro p hp
  have h : env59448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59447_59448 : H12AffineEnvironment.transform 10 675 env59447 = env59448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 675 env59447 == env59448) = true)

theorem identity59448 : scanCanonicalize (H12AffineFastState.compose env59448 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(8+1) ^^^ 146) := by decide +kernel

theorem selectedBound59448 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env59449 : List Nat := [2,4,8,16,32,16,128,173,146,1024,49,1213,1030,1213,49,1156,1070,42,1170,48,1212,1207,131,1052,1053,16,1190,1071,1071,185,1193,1196,172,1087,1213,0]

theorem envBound59449 : H12AffineFastState.Bounded env59449 := by
  intro p hp
  have h : env59449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59448_59449 : H12AffineEnvironment.transform 8 146 env59448 = env59449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 146 env59448 == env59449) = true)

theorem identity59449 : scanCanonicalize (H12AffineFastState.compose env59449 (packedSelected [0,2,3,7] rootPS)) = affineNative (2^(9+1) ^^^ 18) := by decide +kernel

theorem selectedBound59449 : packedSelected [0,2,3,7] rootPS < 2^1333 := by decide +kernel

def env59450 : List Nat := [2,4,8,16,32,16,128,173,146,18,49,175,20,175,49,150,60,42,128,48,174,165,131,14,15,16,180,61,61,185,187,190,172,45,175,0]

theorem envBound59450 : H12AffineFastState.Bounded env59450 := by
  intro p hp
  have h : env59450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59449_59450 : H12AffineEnvironment.transform 9 18 env59449 = env59450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 18 env59449 == env59450) = true)

theorem identity59450 : scanCanonicalize (H12AffineFastState.compose env59450 (packedSelected [3,4,5,9] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound59450 : packedSelected [3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env59451 : List Nat := [2,4,8,11,32,11,128,173,137,9,42,175,15,175,42,141,39,42,128,43,174,165,131,14,15,11,175,38,38,162,160,165,172,45,175,0]

theorem envBound59451 : H12AffineFastState.Bounded env59451 := by
  intro p hp
  have h : env59451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59450_59451 : H12AffineEnvironment.transform 3 11 env59450 = env59451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env59450 == env59451) = true)

theorem identity59451 : scanCanonicalize (H12AffineFastState.compose env59451 (packedSelected [1,10] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound59451 : packedSelected [1,10] rootPS < 2^1333 := by decide +kernel

def env59452 : List Nat := [2,4,8,11,32,11,5,40,12,9,42,42,15,42,42,8,39,42,5,43,43,32,6,14,15,11,42,38,38,39,37,32,41,45,42,0]

theorem envBound59452 : H12AffineFastState.Bounded env59452 := by
  intro p hp
  have h : env59452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59451_59452 : H12AffineEnvironment.transform 6 5 env59451 = env59452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env59451 == env59452) = true)

def env59453 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61569,147473,41003,143496,20496,492566,148669,148669,96267,74795,90259,172,204946,1212,135681]

theorem envBound59453 : H12AffineFastState.Bounded env59453 := by
  intro p hp
  have h : env59453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59439_59453 : H12AffineEnvironment.transform 5 17 env59439 = env59453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env59439 == env59453) = true)

theorem identity59453 : scanCanonicalize (H12AffineFastState.compose env59453 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 114723) := by decide +kernel

theorem selectedBound59453 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env59454 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,114723,262144,119842,32769,4097,61569,98354,41003,127147,20496,279605,99486,99486,96267,74795,90259,172,57521,1212,119330]

theorem envBound59454 : H12AffineFastState.Bounded env59454 := by
  intro p hp
  have h : env59454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59453_59454 : H12AffineEnvironment.transform 16 114723 env59453 = env59454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114723 env59453 == env59454) = true)

theorem identity59454 : scanCanonicalize (H12AffineFastState.compose env59454 (packedSelected [3,10,16,18,19,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 104466) := by decide +kernel

theorem selectedBound59454 : packedSelected [3,10,16,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env59455 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,114723,104466,119842,32769,4097,61569,98354,41003,127147,20496,121895,99486,99486,96267,74795,90259,172,57521,1212,119330]

theorem envBound59455 : H12AffineFastState.Bounded env59455 := by
  intro p hp
  have h : env59455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59454_59455 : H12AffineEnvironment.transform 17 104466 env59454 = env59455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 104466 env59454 == env59455) = true)

theorem identity59455 : scanCanonicalize (H12AffineFastState.compose env59455 (packedSelected [7,16,18,19,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53282) := by decide +kernel

theorem selectedBound59455 : packedSelected [7,16,18,19,23,26,27] rootPS < 2^1333 := by decide +kernel

def env59456 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,53282,4097,18480,1024,32769,4097,61569,20496,41003,8329,20496,3077,21692,21692,43049,62473,45233,172,57521,1212,512]

theorem envBound59456 : H12AffineFastState.Bounded env59456 := by
  intro p hp
  have h : env59456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59455_59456 : H12AffineEnvironment.transform 15 53282 env59455 = env59456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53282 env59455 == env59456) = true)

theorem identity59456 : scanCanonicalize (H12AffineFastState.compose env59456 (packedSelected [4,9,16] rootPS)) = affineNative (2^(14+1) ^^^ 9381) := by decide +kernel

theorem selectedBound59456 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59457 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,9381,29831,4097,18480,1024,9380,4097,21540,20496,1166,8329,20496,3077,21692,21692,3212,20652,5140,172,17428,1212,512]

theorem envBound59457 : H12AffineFastState.Bounded env59457 := by
  intro p hp
  have h : env59457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59456_59457 : H12AffineEnvironment.transform 14 9381 env59456 = env59457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9381 env59456 == env59457) = true)

theorem identity59457 : scanCanonicalize (H12AffineFastState.compose env59457 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 9773) := by decide +kernel

theorem selectedBound59457 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env59458 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,9773,9381,4778,4097,11805,1024,9380,4097,12809,13885,1166,8329,13885,3077,12945,12945,3212,13953,5140,172,8761,1212,512]

theorem envBound59458 : H12AffineFastState.Bounded env59458 := by
  intro p hp
  have h : env59458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59457_59458 : H12AffineEnvironment.transform 13 9773 env59457 = env59458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 9773 env59457 == env59458) = true)

theorem identity59458 : scanCanonicalize (H12AffineFastState.compose env59458 (packedSelected [0,3,4,8,13] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound59458 : packedSelected [0,3,4,8,13] rootPS < 2^1333 := by decide +kernel

def env59459 : List Nat := [2,4,8,16,32,17,128,173,27,1024,2048,4096,8192,9270,9381,4273,4097,11270,1024,9380,4097,12306,13350,1166,8329,13350,3077,12426,12426,3212,13466,5140,172,8226,1212,27]

theorem envBound59459 : H12AffineFastState.Bounded env59459 := by
  intro p hp
  have h : env59459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59458_59459 : H12AffineEnvironment.transform 8 27 env59458 = env59459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env59458 == env59459) = true)

theorem identity59459 : scanCanonicalize (H12AffineFastState.compose env59459 (packedSelected [0,2,5,7,8,11,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 6283) := by decide +kernel

theorem selectedBound59459 : packedSelected [0,2,5,7,8,11,12,15] rootPS < 2^1333 := by decide +kernel

def env59460 : List Nat := [2,4,8,16,32,17,128,173,27,1024,2048,4096,6283,7357,7214,4273,4097,5261,1024,7215,4097,2201,3245,1166,6146,3245,3077,2049,2049,3212,3089,5140,172,6313,1212,27]

theorem envBound59460 : H12AffineFastState.Bounded env59460 := by
  intro p hp
  have h : env59460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59459_59460 : H12AffineEnvironment.transform 12 6283 env59459 = env59460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6283 env59459 == env59460) = true)

theorem identity59460 : scanCanonicalize (H12AffineFastState.compose env59460 (packedSelected [0,2,5,6,8,9,12] rootPS)) = affineNative (2^(11+1) ^^^ 1212) := by decide +kernel

theorem selectedBound59460 : packedSelected [0,2,5,6,8,9,12] rootPS < 2^1333 := by decide +kernel

def env59461 : List Nat := [2,4,8,16,32,17,128,173,27,1024,2048,1212,3127,2049,2194,1037,1213,49,1024,2195,1213,2201,3245,1166,3262,3245,3077,2049,2049,3212,3089,168,172,3093,1212,27]

theorem envBound59461 : H12AffineFastState.Bounded env59461 := by
  intro p hp
  have h : env59461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59460_59461 : H12AffineEnvironment.transform 11 1212 env59460 = env59461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1212 env59460 == env59461) = true)

theorem identity59461 : scanCanonicalize (H12AffineFastState.compose env59461 (packedSelected [1,7,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound59461 : packedSelected [1,7,8,9] rootPS < 2^1333 := by decide +kernel

def env59462 : List Nat := [2,4,8,16,32,17,128,173,27,5,2048,185,2098,2049,2194,8,184,49,5,2195,184,2201,2216,139,2235,2216,2048,2049,2049,2185,2068,168,172,2064,185,27]

theorem envBound59462 : H12AffineFastState.Bounded env59462 := by
  intro p hp
  have h : env59462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59461_59462 : H12AffineEnvironment.transform 9 5 env59461 = env59462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env59461 == env59462) = true)

theorem identity59462 : scanCanonicalize (H12AffineFastState.compose env59462 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound59462 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env59463 : List Nat := [2,4,8,16,32,17,128,173,27,5,49,185,3,48,163,8,184,49,5,162,184,168,153,139,138,153,49,48,48,184,37,168,172,33,185,27]

theorem envBound59463 : H12AffineFastState.Bounded env59463 := by
  intro p hp
  have h : env59463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59462_59463 : H12AffineEnvironment.transform 10 49 env59462 = env59463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env59462 == env59463) = true)

theorem identity59463 : scanCanonicalize (H12AffineFastState.compose env59463 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound59463 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env59464 : List Nat := [2,4,8,16,32,17,8,37,27,5,49,49,3,48,43,8,48,49,5,42,48,32,17,3,2,17,49,48,48,48,37,32,36,33,49,27]

theorem envBound59464 : H12AffineFastState.Bounded env59464 := by
  intro p hp
  have h : env59464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59463_59464 : H12AffineEnvironment.transform 6 8 env59463 = env59464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env59463 == env59464) = true)

theorem identity59464 : scanCanonicalize (H12AffineFastState.compose env59464 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound59464 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59465 : List Nat := [2,3,8,16,32,17,8,34,27,2,49,49,3,48,43,8,48,49,2,42,48,32,17,3,2,17,49,48,48,48,34,32,35,33,49,27]

theorem envBound59465 : H12AffineFastState.Bounded env59465 := by
  intro p hp
  have h : env59465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59464_59465 : H12AffineEnvironment.transform 1 3 env59464 = env59465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env59464 == env59465) = true)

def env59466 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,2154705,147521,16777216,33554432,672784,134217728,148800,33584584,2189403,50962569,4294967296,34088328,4347445490,34359738368,33563273]

theorem envBound59466 : H12AffineFastState.Bounded env59466 := by
  intro p hp
  have h : env59466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54910_59466 : H12AffineEnvironment.transform 22 147521 env54910 = env59466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147521 env54910 == env59466) = true)

def env59467 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,2154705,147521,16777216,33554432,672784,134217728,148800,33584584,2189403,50962569,4294967296,34088328,4347445490,151462016,33563273]

theorem envBound59467 : H12AffineFastState.Bounded env59467 := by
  intro p hp
  have h : env59467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59466_59467 : H12AffineEnvironment.transform 34 151462016 env59466 = env59467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 151462016 env59466 == env59467) = true)

def env59468 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147521,16777216,33554432,672784,134217728,148800,33584584,96347,50962569,4294967296,34088328,4345352434,151462016,33563273]

theorem envBound59468 : H12AffineFastState.Bounded env59468 := by
  intro p hp
  have h : env59468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59467_59468 : H12AffineEnvironment.transform 20 4096 env59467 = env59468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env59467 == env59468) = true)

theorem identity59468 : scanCanonicalize (H12AffineFastState.compose env59468 (packedSelected [14] rootPS)) = affineNative (2^(31+1) ^^^ 74799) := by decide +kernel

theorem selectedBound59468 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env59469 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147521,16777216,33554432,672784,134217728,148800,33584584,96347,50962569,74799,34088328,50459869,151462016,33563273]

theorem envBound59469 : H12AffineFastState.Bounded env59469 := by
  intro p hp
  have h : env59469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59468_59469 : H12AffineEnvironment.transform 31 74799 env59468 = env59469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 74799 env59468 == env59469) = true)

def env59470 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147521,16777216,533640,672784,134217728,148800,545088,96347,16876545,74799,256,17420373,151462016,525825]

theorem envBound59470 : H12AffineFastState.Bounded env59470 := by
  intro p hp
  have h : env59470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59469_59470 : H12AffineEnvironment.transform 24 533640 env59469 = env59470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 533640 env59469 == env59470) = true)

def env59471 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147521,16777216,533640,672784,17245632,148800,545088,96347,16876545,74799,256,17420373,1344,525825]

theorem envBound59471 : H12AffineFastState.Bounded env59471 := by
  intro p hp
  have h : env59471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59470_59471 : H12AffineEnvironment.transform 26 17245632 env59470 = env59471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245632 env59470 == env59471) = true)

theorem identity59471 : scanCanonicalize (H12AffineFastState.compose env59471 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(18+1) ^^^ 95615) := by decide +kernel

theorem selectedBound59471 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env59472 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95615,32769,4096,61649,147521,16777216,86519,209263,17245632,148800,74815,96347,16876545,74799,256,16819498,1344,95102]

theorem envBound59472 : H12AffineFastState.Bounded env59472 := by
  intro p hp
  have h : env59472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59471_59472 : H12AffineEnvironment.transform 18 95615 env59471 = env59472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 95615 env59471 == env59472) = true)

def env59473 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95615,32769,4096,61649,147521,284032,86519,209263,225344,148800,74815,96347,381313,74799,256,323754,1344,95102]

theorem envBound59473 : H12AffineFastState.Bounded env59473 := by
  intro p hp
  have h : env59473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59472_59473 : H12AffineEnvironment.transform 23 284032 env59472 = env59473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 284032 env59472 == env59473) = true)

def env59474 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16464,262144,95615,32769,4096,61649,17,284032,86519,94527,77840,1296,74815,96347,381313,74799,256,323754,1344,95102]

theorem envBound59474 : H12AffineFastState.Bounded env59474 := by
  intro p hp
  have h : env59474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59473_59474 : H12AffineEnvironment.transform 16 16464 env59473 = env59474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16464 env59473 == env59474) = true)

def env59475 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1344,262144,77935,32769,4096,46529,17,266384,70887,78895,77840,1296,74815,81227,365713,74799,256,308666,1344,79470]

theorem envBound59475 : H12AffineFastState.Bounded env59475 := by
  intro p hp
  have h : env59475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59474_59475 : H12AffineEnvironment.transform 13 1296 env59474 = env59475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env59474 == env59475) = true)

theorem identity59475 : scanCanonicalize (H12AffineFastState.compose env59475 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32882) := by decide +kernel

theorem selectedBound59475 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env59476 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,32882,1344,262144,45085,32769,4096,46529,17,266384,38037,46173,45154,1296,42061,48441,267491,42077,256,308666,1344,46620]

theorem envBound59476 : H12AffineFastState.Bounded env59476 := by
  intro p hp
  have h : env59476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59475_59476 : H12AffineEnvironment.transform 15 32882 env59475 = env59476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32882 env59475 == env59476) = true)

def env59477 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32882,1344,262144,42333,32769,1344,41089,17,263632,33237,41245,42274,1296,42061,43129,262563,42077,256,303354,1344,41820]

theorem envBound59477 : H12AffineFastState.Bounded env59477 := by
  intro p hp
  have h : env59477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59476_59477 : H12AffineEnvironment.transform 11 1344 env59476 = env59477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env59476 == env59477) = true)

theorem identity59477 : scanCanonicalize (H12AffineFastState.compose env59477 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 41147) := by decide +kernel

theorem selectedBound59477 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env59478 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32882,1344,41147,42333,32769,1344,41089,17,42347,33237,41245,42274,1296,42061,43129,41240,42077,256,65,1344,41820]

theorem envBound59478 : H12AffineFastState.Bounded env59478 := by
  intro p hp
  have h : env59478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59477_59478 : H12AffineEnvironment.transform 17 41147 env59477 = env59478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 41147 env59477 == env59478) = true)

theorem identity59478 : scanCanonicalize (H12AffineFastState.compose env59478 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound59478 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env59479 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,8540,8494,1344,487,1025,8541,1344,477,17,1079,8329,65,1150,1296,1297,2341,68,1281,256,65,1344,512]

theorem envBound59479 : H12AffineFastState.Bounded env59479 := by
  intro p hp
  have h : env59479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59478_59479 : H12AffineEnvironment.transform 14 8540 env59478 = env59479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env59478 == env59479) = true)

theorem identity59479 : scanCanonicalize (H12AffineFastState.compose env59479 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound59479 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59480 : List Nat := [2,4,8,16,32,64,128,21,512,1024,2048,1109,8192,1029,8265,8251,1109,242,1025,8264,1109,200,17,1079,8329,65,1150,1029,1028,2096,68,1044,21,65,1109,512]

theorem envBound59480 : H12AffineFastState.Bounded env59480 := by
  intro p hp
  have h : env59480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59479_59480 : H12AffineEnvironment.transform 7 21 env59479 = env59480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env59479 == env59480) = true)

theorem identity59480 : scanCanonicalize (H12AffineFastState.compose env59480 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 1684) := by decide +kernel

theorem selectedBound59480 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env59481 : List Nat := [2,4,8,16,32,64,128,21,512,1024,2048,1109,1684,1029,1757,1711,1109,242,1025,1756,1109,200,17,1079,1565,65,1150,1029,1028,2096,68,1044,21,65,1109,512]

theorem envBound59481 : H12AffineFastState.Bounded env59481 := by
  intro p hp
  have h : env59481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59480_59481 : H12AffineEnvironment.transform 12 1684 env59480 = env59481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1684 env59480 == env59481) = true)

theorem identity59481 : scanCanonicalize (H12AffineFastState.compose env59481 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound59481 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env59482 : List Nat := [2,4,8,16,32,17,128,21,512,1024,2048,1028,1684,1029,1676,1711,1028,163,1025,1677,1028,153,17,1079,1565,16,1071,1029,1028,2096,21,1044,21,16,1028,512]

theorem envBound59482 : H12AffineFastState.Bounded env59482 := by
  intro p hp
  have h : env59482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59481_59482 : H12AffineEnvironment.transform 5 17 env59481 = env59482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env59481 == env59482) = true)

theorem identity59482 : scanCanonicalize (H12AffineFastState.compose env59482 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound59482 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env59483 : List Nat := [2,4,8,16,17,17,128,21,512,1024,2048,1028,1684,1029,1676,1694,1028,146,1025,1677,1028,153,17,1030,1565,16,1054,1029,1028,2049,21,1044,21,16,1028,512]

theorem envBound59483 : H12AffineFastState.Bounded env59483 := by
  intro p hp
  have h : env59483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59482_59483 : H12AffineEnvironment.transform 4 17 env59482 = env59483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env59482 == env59483) = true)

theorem identity59483 : scanCanonicalize (H12AffineFastState.compose env59483 (packedSelected [0,2,5] rootPS)) = affineNative (2^(10+1) ^^^ 1541) := by decide +kernel

theorem selectedBound59483 : packedSelected [0,2,5] rootPS < 2^1333 := by decide +kernel

def env59484 : List Nat := [2,4,8,16,17,17,128,21,512,1024,1541,1028,1684,1029,1676,1694,1028,146,1025,1677,1028,153,17,1030,1565,16,1054,1029,1028,1540,21,1044,21,16,1028,512]

theorem envBound59484 : H12AffineFastState.Bounded env59484 := by
  intro p hp
  have h : env59484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59483_59484 : H12AffineEnvironment.transform 10 1541 env59483 = env59484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1541 env59483 == env59484) = true)

theorem identity59484 : scanCanonicalize (H12AffineFastState.compose env59484 (packedSelected [2,4,9] rootPS)) = affineNative (2^(9+1) ^^^ 30) := by decide +kernel

theorem selectedBound59484 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env59485 : List Nat := [2,4,8,16,17,17,128,21,512,30,539,26,650,27,658,640,26,146,31,659,26,153,17,24,515,16,0,27,26,538,21,10,21,16,26,512]

theorem envBound59485 : H12AffineFastState.Bounded env59485 := by
  intro p hp
  have h : env59485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59484_59485 : H12AffineEnvironment.transform 9 30 env59484 = env59485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 30 env59484 == env59485) = true)

theorem identity59485 : scanCanonicalize (H12AffineFastState.compose env59485 (packedSelected [0,1,2] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound59485 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env59486 : List Nat := [2,4,8,16,17,17,128,21,137,30,146,26,3,27,27,9,26,146,31,26,26,153,17,24,138,16,0,27,26,147,21,10,21,16,26,137]

theorem envBound59486 : H12AffineFastState.Bounded env59486 := by
  intro p hp
  have h : env59486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59485_59486 : H12AffineEnvironment.transform 8 137 env59485 = env59486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env59485 == env59486) = true)

theorem identity59486 : scanCanonicalize (H12AffineFastState.compose env59486 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound59486 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env59487 : List Nat := [2,4,8,16,17,17,18,21,27,30,0,26,3,27,27,9,26,0,31,26,26,11,17,24,24,16,0,27,26,1,21,10,21,16,26,27]

theorem envBound59487 : H12AffineFastState.Bounded env59487 := by
  intro p hp
  have h : env59487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59486_59487 : H12AffineEnvironment.transform 6 18 env59486 = env59487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env59486 == env59487) = true)

theorem identity59487 : scanCanonicalize (H12AffineFastState.compose env59487 (packedSelected [0,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound59487 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env59488 : List Nat := [2,4,8,11,10,10,9,14,0,5,0,1,3,0,0,9,1,0,4,1,1,11,10,3,3,11,0,0,1,1,14,10,14,11,1,0]

theorem envBound59488 : H12AffineFastState.Bounded env59488 := by
  intro p hp
  have h : env59488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59487_59488 : H12AffineEnvironment.transform 3 11 env59487 = env59488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env59487 == env59488) = true)

theorem identity59488 : scanCanonicalize (H12AffineFastState.compose env59488 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound59488 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59489 : List Nat := [2,4,4,7,6,6,5,2,0,5,0,1,3,0,0,5,1,0,4,1,1,7,6,3,3,7,0,0,1,1,2,6,2,7,1,0]

theorem envBound59489 : H12AffineFastState.Bounded env59489 := by
  intro p hp
  have h : env59489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59488_59489 : H12AffineEnvironment.transform 2 4 env59488 = env59489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env59488 == env59489) = true)

def env59490 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32882,1344,262144,42332,32769,1345,41088,17,263633,33236,41244,42275,1296,42061,43128,262562,42077,256,303355,1344,41821]

theorem envBound59490 : H12AffineFastState.Bounded env59490 := by
  intro p hp
  have h : env59490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59476_59490 : H12AffineEnvironment.transform 11 1345 env59476 = env59490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env59476 == env59490) = true)

theorem identity59490 : scanCanonicalize (H12AffineFastState.compose env59490 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 72) := by decide +kernel

theorem selectedBound59490 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env59491 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,72,1296,32768,32882,1344,262144,34068,32769,1345,32968,17,263633,33236,33108,34155,1296,33797,34864,262562,33813,256,295091,1344,33557]

theorem envBound59491 : H12AffineFastState.Bounded env59491 := by
  intro p hp
  have h : env59491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59490_59491 : H12AffineEnvironment.transform 12 72 env59490 = env59491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env59490 == env59491) = true)

theorem identity59491 : scanCanonicalize (H12AffineFastState.compose env59491 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(14+1) ^^^ 560) := by decide +kernel

theorem selectedBound59491 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env59492 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,72,1296,560,578,1344,262144,1828,561,1345,760,17,263633,996,868,1883,1296,1589,2560,262562,1573,256,262787,1344,293]

theorem envBound59492 : H12AffineFastState.Bounded env59492 := by
  intro p hp
  have h : env59492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59491_59492 : H12AffineEnvironment.transform 14 560 env59491 = env59492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 560 env59491 == env59492) = true)

def env59493 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1345,262144,77934,32769,4096,46528,17,266385,70886,78894,77840,1296,74815,81226,365712,74799,256,308667,1344,79471]

theorem envBound59493 : H12AffineFastState.Bounded env59493 := by
  intro p hp
  have h : env59493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59474_59493 : H12AffineEnvironment.transform 13 1297 env59474 = env59493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env59474 == env59493) = true)

theorem identity59493 : scanCanonicalize (H12AffineFastState.compose env59493 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound59493 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env59494 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1345,262144,77934,13340,4096,477,17,266385,70886,78894,77840,1296,74815,81226,336013,74799,256,262566,1344,79471]

theorem envBound59494 : H12AffineFastState.Bounded env59494 := by
  intro p hp
  have h : env59494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59493_59494 : H12AffineEnvironment.transform 14 13341 env59493 = env59494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env59493 == env59494) = true)

def env59495 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1345,65664,77934,13340,4096,477,17,69649,70886,78894,77840,1296,74815,81226,8205,74799,256,65830,1344,79471]

theorem envBound59495 : H12AffineFastState.Bounded env59495 := by
  intro p hp
  have h : env59495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59494_59495 : H12AffineEnvironment.transform 17 65664 env59494 = env59495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env59494 == env59495) = true)

theorem identity59495 : scanCanonicalize (H12AffineFastState.compose env59495 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12590) := by decide +kernel

theorem selectedBound59495 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env59496 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,12590,1345,12718,320,13340,4096,477,17,8511,9672,1280,318,1296,5393,3172,8205,5377,256,12296,1344,1857]

theorem envBound59496 : H12AffineFastState.Bounded env59496 := by
  intro p hp
  have h : env59496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59495_59496 : H12AffineEnvironment.transform 15 12590 env59495 = env59496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12590 env59495 == env59496) = true)

def env59497 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,81,12637,12590,1,12718,320,12636,4096,477,17,8511,8328,64,318,80,4177,2340,8205,4161,256,12296,0,513]

theorem envBound59497 : H12AffineFastState.Bounded env59497 := by
  intro p hp
  have h : env59497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59496_59497 : H12AffineEnvironment.transform 9 320 env59496 = env59497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env59496 == env59497) = true)

theorem identity59497 : scanCanonicalize (H12AffineFastState.compose env59497 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound59497 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59498 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,269,81,4176,4131,1,4259,320,4177,4096,477,17,50,389,64,318,80,4177,2340,256,4161,256,4357,0,513]

theorem envBound59498 : H12AffineFastState.Bounded env59498 := by
  intro p hp
  have h : env59498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59497_59498 : H12AffineEnvironment.transform 12 269 env59497 = env59498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env59497 == env59498) = true)

theorem identity59498 : scanCanonicalize (H12AffineFastState.compose env59498 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound59498 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59499 : List Nat := [2,4,8,16,32,64,128,21,512,85,2048,4096,24,81,4176,4131,1,4259,85,4177,4096,200,17,50,144,64,43,80,4177,2097,21,4161,21,4112,0,513]

theorem envBound59499 : H12AffineFastState.Bounded env59499 := by
  intro p hp
  have h : env59499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59498_59499 : H12AffineEnvironment.transform 7 21 env59498 = env59499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env59498 == env59499) = true)

theorem identity59499 : scanCanonicalize (H12AffineFastState.compose env59499 (packedSelected [3,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound59499 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env59500 : List Nat := [2,4,8,16,32,64,128,21,512,85,2048,16,24,81,64,51,1,179,85,65,16,200,17,50,144,64,43,80,65,2097,21,81,21,0,0,513]

theorem envBound59500 : H12AffineFastState.Bounded env59500 := by
  intro p hp
  have h : env59500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59499_59500 : H12AffineEnvironment.transform 11 16 env59499 = env59500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env59499 == env59500) = true)

theorem identity59500 : scanCanonicalize (H12AffineFastState.compose env59500 (packedSelected [2,11,12,13,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 152) := by decide +kernel

theorem selectedBound59500 : packedSelected [2,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env59501 : List Nat := [2,4,8,16,32,64,128,21,152,85,2048,16,24,81,64,51,1,179,85,65,16,200,17,50,144,64,43,80,65,2097,21,81,21,0,0,153]

theorem envBound59501 : H12AffineFastState.Bounded env59501 := by
  intro p hp
  have h : env59501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59500_59501 : H12AffineEnvironment.transform 8 152 env59500 = env59501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 152 env59500 == env59501) = true)

theorem identity59501 : scanCanonicalize (H12AffineFastState.compose env59501 (packedSelected [0,1,2,5,7,8,11,12,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 228) := by decide +kernel

theorem selectedBound59501 : packedSelected [0,1,2,5,7,8,11,12,15,17] rootPS < 2^1333 := by decide +kernel

def env59502 : List Nat := [2,4,8,16,32,64,128,21,152,85,228,16,24,81,64,51,1,179,85,65,16,200,17,50,144,64,43,80,65,213,21,81,21,0,0,153]

theorem envBound59502 : H12AffineFastState.Bounded env59502 := by
  intro p hp
  have h : env59502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59501_59502 : H12AffineEnvironment.transform 10 228 env59501 = env59502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 228 env59501 == env59502) = true)

theorem identity59502 : scanCanonicalize (H12AffineFastState.compose env59502 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound59502 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env59503 : List Nat := [2,4,8,16,32,17,128,21,152,4,181,16,24,0,17,51,1,179,4,16,16,153,17,50,144,17,43,1,16,132,21,0,21,0,0,153]

theorem envBound59503 : H12AffineFastState.Bounded env59503 := by
  intro p hp
  have h : env59503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59502_59503 : H12AffineEnvironment.transform 5 17 env59502 = env59503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env59502 == env59503) = true)

theorem identity59503 : scanCanonicalize (H12AffineFastState.compose env59503 (packedSelected [2,5] rootPS)) = affineNative (2^(6+1) ^^^ 31) := by decide +kernel

theorem selectedBound59503 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env59504 : List Nat := [2,4,8,16,32,17,31,21,7,4,42,16,24,0,17,51,1,44,4,16,16,6,17,50,15,17,43,1,16,27,21,0,21,0,0,6]

theorem envBound59504 : H12AffineFastState.Bounded env59504 := by
  intro p hp
  have h : env59504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59503_59504 : H12AffineEnvironment.transform 6 31 env59503 = env59504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 31 env59503 == env59504) = true)

theorem identity59504 : scanCanonicalize (H12AffineFastState.compose env59504 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound59504 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env59505 : List Nat := [2,4,8,0,32,1,15,5,7,4,42,0,8,0,1,35,1,44,4,0,0,6,1,34,15,1,43,1,0,11,5,0,5,0,0,6]

theorem envBound59505 : H12AffineFastState.Bounded env59505 := by
  intro p hp
  have h : env59505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59504_59505 : H12AffineEnvironment.transform 3 0 env59504 = env59505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env59504 == env59505) = true)

theorem identity59505 : scanCanonicalize (H12AffineFastState.compose env59505 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound59505 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env59506 : List Nat := [2,4,5,0,32,1,2,5,7,4,39,0,5,0,1,35,1,33,4,0,0,6,1,34,2,1,38,1,0,6,5,0,5,0,0,6]

theorem envBound59506 : H12AffineFastState.Bounded env59506 := by
  intro p hp
  have h : env59506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59505_59506 : H12AffineEnvironment.transform 2 5 env59505 = env59506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env59505 == env59506) = true)

theorem identity59506 : scanCanonicalize (H12AffineFastState.compose env59506 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound59506 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59507 : List Nat := [2,4,5,0,6,1,2,5,7,4,1,0,5,0,1,5,1,7,4,0,0,6,1,4,2,1,0,1,0,6,5,0,5,0,0,6]

theorem envBound59507 : H12AffineFastState.Bounded env59507 := by
  intro p hp
  have h : env59507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59506_59507 : H12AffineEnvironment.transform 4 6 env59506 = env59507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env59506 == env59507) = true)

theorem identity59507 : scanCanonicalize (H12AffineFastState.compose env59507 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound59507 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59508 : List Nat := [2,1,0,0,3,1,2,0,2,1,1,0,0,0,1,0,1,2,1,0,0,3,1,1,2,1,0,1,0,3,0,0,0,0,0,3]

theorem envBound59508 : H12AffineFastState.Bounded env59508 := by
  intro p hp
  have h : env59508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59507_59508 : H12AffineEnvironment.transform 1 1 env59507 = env59508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env59507 == env59508) = true)

theorem identity59508 : scanCanonicalize (H12AffineFastState.compose env59508 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound59508 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env59509 : List Nat := [1,1,0,0,0,1,1,0,1,1,1,0,0,0,1,0,1,1,1,0,0,0,1,1,1,1,0,1,0,0,0,0,0,0,0,0]

theorem envBound59509 : H12AffineFastState.Bounded env59509 := by
  intro p hp
  have h : env59509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59508_59509 : H12AffineEnvironment.transform 0 1 env59508 = env59509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env59508 == env59509) = true)

def env59510 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,80,12636,12590,0,12718,320,12637,4096,477,17,8511,8329,65,318,81,4176,2341,8205,4160,256,12296,1,512]

theorem envBound59510 : H12AffineFastState.Bounded env59510 := by
  intro p hp
  have h : env59510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59496_59510 : H12AffineEnvironment.transform 9 321 env59496 = env59510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env59496 == env59510) = true)

theorem identity59510 : scanCanonicalize (H12AffineFastState.compose env59510 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound59510 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59511 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,349,80,4097,4211,0,4339,320,4096,4096,477,17,98,468,65,318,81,4176,2341,336,4160,256,4437,1,512]

theorem envBound59511 : H12AffineFastState.Bounded env59511 := by
  intro p hp
  have h : env59511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59510_59511 : H12AffineEnvironment.transform 12 349 env59510 = env59511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env59510 == env59511) = true)

theorem identity59511 : scanCanonicalize (H12AffineFastState.compose env59511 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound59511 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env59512 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,4096,268,1,4097,4130,0,4258,273,4096,4096,396,17,51,389,16,318,0,4097,2341,257,4113,256,4356,1,512]

theorem envBound59512 : H12AffineFastState.Bounded env59512 := by
  intro p hp
  have h : env59512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59511_59512 : H12AffineEnvironment.transform 5 17 env59511 = env59512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env59511 == env59512) = true)

theorem identity59512 : scanCanonicalize (H12AffineFastState.compose env59512 (packedSelected [2,13,17] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound59512 : packedSelected [2,13,17] rootPS < 2^1333 := by decide +kernel

def env59513 : List Nat := [2,4,8,16,32,17,128,256,512,272,512,4096,268,1,4097,4130,0,4258,273,4096,4096,396,17,51,389,16,318,0,4097,805,257,4113,256,4356,1,512]

theorem envBound59513 : H12AffineFastState.Bounded env59513 := by
  intro p hp
  have h : env59513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59512_59513 : H12AffineEnvironment.transform 10 512 env59512 = env59513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env59512 == env59513) = true)

theorem identity59513 : scanCanonicalize (H12AffineFastState.compose env59513 (packedSelected [0,1,2,5,7,11,12,13,15] rootPS)) = affineNative (2^(8+1) ^^^ 428) := by decide +kernel

theorem selectedBound59513 : packedSelected [0,1,2,5,7,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env59514 : List Nat := [2,4,8,16,32,17,128,256,428,272,428,4096,268,1,4097,4130,0,4258,273,4096,4096,396,17,51,389,16,318,0,4097,137,257,4113,256,4356,1,428]

theorem envBound59514 : H12AffineFastState.Bounded env59514 := by
  intro p hp
  have h : env59514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59513_59514 : H12AffineEnvironment.transform 8 428 env59513 = env59514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 428 env59513 == env59514) = true)

theorem identity59514 : scanCanonicalize (H12AffineFastState.compose env59514 (packedSelected [3,9,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 391) := by decide +kernel

theorem selectedBound59514 : packedSelected [3,9,11,12] rootPS < 2^1333 := by decide +kernel

def env59515 : List Nat := [2,4,8,16,32,17,128,256,428,272,428,391,268,1,390,421,0,293,273,391,391,396,17,51,389,16,318,0,390,137,257,406,256,131,1,428]

theorem envBound59515 : H12AffineFastState.Bounded env59515 := by
  intro p hp
  have h : env59515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59514_59515 : H12AffineEnvironment.transform 11 391 env59514 = env59515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 391 env59514 == env59515) = true)

theorem identity59515 : scanCanonicalize (H12AffineFastState.compose env59515 (packedSelected [0,3,4,7] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound59515 : packedSelected [0,3,4,7] rootPS < 2^1333 := by decide +kernel

def env59516 : List Nat := [2,4,8,16,32,17,9,256,293,272,293,270,268,1,271,300,0,293,273,270,270,261,17,51,268,16,318,0,271,0,257,287,256,10,1,293]

theorem envBound59516 : H12AffineFastState.Bounded env59516 := by
  intro p hp
  have h : env59516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59515_59516 : H12AffineEnvironment.transform 6 9 env59515 = env59516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env59515 == env59516) = true)

theorem identity59516 : scanCanonicalize (H12AffineFastState.compose env59516 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 62) := by decide +kernel

theorem selectedBound59516 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env59517 : List Nat := [2,4,8,16,32,17,9,62,27,46,27,48,50,1,49,18,0,27,47,48,48,59,17,51,50,16,0,0,49,0,63,33,62,10,1,27]

theorem envBound59517 : H12AffineFastState.Bounded env59517 := by
  intro p hp
  have h : env59517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59516_59517 : H12AffineEnvironment.transform 7 62 env59516 = env59517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 62 env59516 == env59517) = true)

theorem identity59517 : scanCanonicalize (H12AffineFastState.compose env59517 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound59517 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59518 : List Nat := [2,4,8,16,17,17,9,15,27,31,27,1,3,1,0,18,0,27,30,1,1,10,17,2,3,16,0,0,0,0,14,16,15,10,1,27]

theorem envBound59518 : H12AffineFastState.Bounded env59518 := by
  intro p hp
  have h : env59518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59517_59518 : H12AffineEnvironment.transform 4 17 env59517 = env59518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env59517 == env59518) = true)

theorem identity59518 : scanCanonicalize (H12AffineFastState.compose env59518 (packedSelected [0,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound59518 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env59519 : List Nat := [2,4,8,11,10,10,9,15,0,4,0,1,3,1,0,9,0,0,5,1,1,10,10,2,3,11,0,0,0,0,14,11,15,10,1,0]

theorem envBound59519 : H12AffineFastState.Bounded env59519 := by
  intro p hp
  have h : env59519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59518_59519 : H12AffineEnvironment.transform 3 11 env59518 = env59519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env59518 == env59519) = true)

theorem identity59519 : scanCanonicalize (H12AffineFastState.compose env59519 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound59519 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59520 : List Nat := [2,3,8,11,10,10,9,8,0,3,0,1,3,1,0,9,0,0,2,1,1,10,10,2,3,11,0,0,0,0,9,11,8,10,1,0]

theorem envBound59520 : H12AffineFastState.Bounded env59520 := by
  intro p hp
  have h : env59520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59519_59520 : H12AffineEnvironment.transform 1 3 env59519 = env59520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env59519 == env59520) = true)

def env59521 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1345,65665,77934,13340,4096,477,17,69648,70886,78894,77840,1296,74815,81226,8204,74799,256,65831,1344,79471]

theorem envBound59521 : H12AffineFastState.Bounded env59521 := by
  intro p hp
  have h : env59521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59494_59521 : H12AffineEnvironment.transform 17 65665 env59494 = env59521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env59494 == env59521) = true)

theorem identity59521 : scanCanonicalize (H12AffineFastState.compose env59521 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9326) := by decide +kernel

theorem selectedBound59521 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env59522 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,9326,1345,9455,5120,13340,4096,477,17,13438,12424,4160,5246,1296,81,6436,8204,65,256,9545,1344,4609]

theorem envBound59522 : H12AffineFastState.Bounded env59522 := by
  intro p hp
  have h : env59522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59521_59522 : H12AffineEnvironment.transform 15 9326 env59521 = env59522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9326 env59521 == env59522) = true)

def env59523 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1297,9245,9326,1345,9455,1024,9244,0,477,17,9342,8328,64,1150,1296,81,2340,8204,65,256,9545,1344,513]

theorem envBound59523 : H12AffineFastState.Bounded env59523 := by
  intro p hp
  have h : env59523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59522_59523 : H12AffineEnvironment.transform 11 0 env59522 = env59523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env59522 == env59523) = true)

theorem identity59523 : scanCanonicalize (H12AffineFastState.compose env59523 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound59523 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59524 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,268,1297,1297,1378,1345,1507,1024,1296,0,477,17,1394,388,64,1150,1296,81,2340,256,65,256,1093,1344,513]

theorem envBound59524 : H12AffineFastState.Bounded env59524 := by
  intro p hp
  have h : env59524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59523_59524 : H12AffineEnvironment.transform 12 268 env59523 = env59524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env59523 == env59524) = true)

theorem identity59524 : scanCanonicalize (H12AffineFastState.compose env59524 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(9+1) ^^^ 85) := by decide +kernel

theorem selectedBound59524 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59525 : List Nat := [2,4,8,16,32,64,128,256,512,85,2048,0,268,324,324,311,276,438,85,325,0,477,17,295,388,64,43,325,81,2340,256,65,256,16,277,513]

theorem envBound59525 : H12AffineFastState.Bounded env59525 := by
  intro p hp
  have h : env59525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59524_59525 : H12AffineEnvironment.transform 9 85 env59524 = env59525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env59524 == env59525) = true)

theorem identity59525 : scanCanonicalize (H12AffineFastState.compose env59525 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound59525 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env59526 : List Nat := [2,4,8,16,32,64,128,4,512,85,2048,0,8,64,64,51,16,178,85,65,0,217,17,35,128,64,43,65,81,2080,4,65,4,16,17,513]

theorem envBound59526 : H12AffineFastState.Bounded env59526 := by
  intro p hp
  have h : env59526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59525_59526 : H12AffineEnvironment.transform 7 4 env59525 = env59526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env59525 == env59526) = true)

theorem identity59526 : scanCanonicalize (H12AffineFastState.compose env59526 (packedSelected [2,11,12,13,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound59526 : packedSelected [2,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env59527 : List Nat := [2,4,8,16,32,64,128,4,136,85,2048,0,8,64,64,51,16,178,85,65,0,217,17,35,128,64,43,65,81,2080,4,65,4,16,17,137]

theorem envBound59527 : H12AffineFastState.Bounded env59527 := by
  intro p hp
  have h : env59527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59526_59527 : H12AffineEnvironment.transform 8 136 env59526 = env59527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env59526 == env59527) = true)

theorem identity59527 : scanCanonicalize (H12AffineFastState.compose env59527 (packedSelected [5,12,13,15] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound59527 : packedSelected [5,12,13,15] rootPS < 2^1333 := by decide +kernel

def env59528 : List Nat := [2,4,8,16,6,64,128,4,136,85,2048,0,8,64,64,21,16,148,85,65,0,217,17,5,128,64,13,65,81,2054,4,65,4,16,17,137]

theorem envBound59528 : H12AffineFastState.Bounded env59528 := by
  intro p hp
  have h : env59528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59527_59528 : H12AffineEnvironment.transform 4 6 env59527 = env59528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env59527 == env59528) = true)

theorem identity59528 : scanCanonicalize (H12AffineFastState.compose env59528 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound59528 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env59529 : List Nat := [2,4,8,16,6,16,128,4,136,5,2048,0,8,16,16,21,16,148,5,17,0,137,17,5,128,16,13,17,1,2054,4,17,4,16,17,137]

theorem envBound59529 : H12AffineFastState.Bounded env59529 := by
  intro p hp
  have h : env59529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59528_59529 : H12AffineEnvironment.transform 5 16 env59528 = env59529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env59528 == env59529) = true)

theorem identity59529 : scanCanonicalize (H12AffineFastState.compose env59529 (packedSelected [5] rootPS)) = affineNative (2^(6+1) ^^^ 15) := by decide +kernel

theorem selectedBound59529 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env59530 : List Nat := [2,4,8,16,6,16,15,4,7,5,2048,0,8,16,16,21,16,27,5,17,0,6,17,5,15,16,13,17,1,2054,4,17,4,16,17,6]

theorem envBound59530 : H12AffineFastState.Bounded env59530 := by
  intro p hp
  have h : env59530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59529_59530 : H12AffineEnvironment.transform 6 15 env59529 = env59530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 15 env59529 == env59530) = true)

theorem identity59530 : scanCanonicalize (H12AffineFastState.compose env59530 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound59530 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59531 : List Nat := [2,4,8,7,6,7,15,4,7,5,2048,0,8,7,7,2,7,12,5,6,0,6,6,5,15,7,13,6,1,2054,4,6,4,7,6,6]

theorem envBound59531 : H12AffineFastState.Bounded env59531 := by
  intro p hp
  have h : env59531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59530_59531 : H12AffineEnvironment.transform 3 7 env59530 = env59531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env59530 == env59531) = true)

theorem identity59531 : scanCanonicalize (H12AffineFastState.compose env59531 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound59531 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env59532 : List Nat := [2,4,1,7,6,7,6,4,7,5,2048,0,1,7,7,2,7,5,5,6,0,6,6,5,6,7,4,6,1,2054,4,6,4,7,6,6]

theorem envBound59532 : H12AffineFastState.Bounded env59532 := by
  intro p hp
  have h : env59532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59531_59532 : H12AffineEnvironment.transform 2 1 env59531 = env59532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env59531 == env59532) = true)

theorem identity59532 : scanCanonicalize (H12AffineFastState.compose env59532 (packedSelected [7] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound59532 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env59533 : List Nat := [2,0,1,3,2,3,2,0,3,1,2048,0,1,3,3,2,3,1,1,2,0,2,2,1,2,3,0,2,1,2050,0,2,0,3,2,2]

theorem envBound59533 : H12AffineFastState.Bounded env59533 := by
  intro p hp
  have h : env59533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59532_59533 : H12AffineEnvironment.transform 1 0 env59532 = env59533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env59532 == env59533) = true)

theorem identity59533 : scanCanonicalize (H12AffineFastState.compose env59533 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound59533 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env59534 : List Nat := [1,0,1,0,1,0,1,0,0,1,2048,0,1,0,0,1,0,1,1,1,0,1,1,1,1,0,0,1,1,2049,0,1,0,0,1,1]

theorem envBound59534 : H12AffineFastState.Bounded env59534 := by
  intro p hp
  have h : env59534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59533_59534 : H12AffineEnvironment.transform 0 1 env59533 = env59534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env59533 == env59534) = true)

def env59535 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1297,9244,9326,1345,9455,1025,9245,1,477,17,9343,8329,65,1151,1296,81,2341,8204,65,256,9545,1344,512]

theorem envBound59535 : H12AffineFastState.Bounded env59535 := by
  intro p hp
  have h : env59535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59522_59535 : H12AffineEnvironment.transform 11 1 env59522 = env59535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env59522 == env59535) = true)

theorem identity59535 : scanCanonicalize (H12AffineFastState.compose env59535 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound59535 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59536 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,348,1297,1344,1330,1345,1459,1025,1345,1,477,17,1315,469,65,1151,1296,81,2341,336,65,256,1045,1344,512]

theorem envBound59536 : H12AffineFastState.Bounded env59536 := by
  intro p hp
  have h : env59536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59535_59536 : H12AffineEnvironment.transform 12 348 env59535 = env59536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env59535 == env59536) = true)

theorem identity59536 : scanCanonicalize (H12AffineFastState.compose env59536 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound59536 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env59537 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1,269,1297,1297,1330,1296,1459,1025,1296,1,396,17,1315,388,16,1070,1296,0,2341,257,16,256,1045,1297,512]

theorem envBound59537 : H12AffineFastState.Bounded env59537 := by
  intro p hp
  have h : env59537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59536_59537 : H12AffineEnvironment.transform 5 17 env59536 = env59537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env59536 == env59537) = true)

theorem identity59537 : scanCanonicalize (H12AffineFastState.compose env59537 (packedSelected [2,13,17] rootPS)) = affineNative (2^(10+1) ^^^ 1960) := by decide +kernel

theorem selectedBound59537 : packedSelected [2,13,17] rootPS < 2^1333 := by decide +kernel

def env59538 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1960,1,269,1297,1297,1330,1296,1459,1025,1296,1,396,17,1315,388,16,1070,1296,0,1677,257,16,256,1045,1297,512]

theorem envBound59538 : H12AffineFastState.Bounded env59538 := by
  intro p hp
  have h : env59538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59537_59538 : H12AffineEnvironment.transform 10 1960 env59537 = env59538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1960 env59537 == env59538) = true)

theorem identity59538 : scanCanonicalize (H12AffineFastState.compose env59538 (packedSelected [2,11,18] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound59538 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env59539 : List Nat := [2,4,8,10,32,11,128,256,512,1024,1960,1,269,1291,1291,1320,1290,1449,1025,1290,1,396,11,1315,388,10,1070,1290,0,1677,257,10,256,1039,1291,512]

theorem envBound59539 : H12AffineFastState.Bounded env59539 := by
  intro p hp
  have h : env59539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59538_59539 : H12AffineEnvironment.transform 3 10 env59538 = env59539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env59538 == env59539) = true)

theorem identity59539 : scanCanonicalize (H12AffineFastState.compose env59539 (packedSelected [0,1,2,7,8,10,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 141) := by decide +kernel

theorem selectedBound59539 : packedSelected [0,1,2,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env59540 : List Nat := [2,4,8,10,32,11,128,256,512,141,805,1,269,390,390,421,391,292,140,391,1,396,11,430,388,10,163,391,0,512,257,10,256,130,390,512]

theorem envBound59540 : H12AffineFastState.Bounded env59540 := by
  intro p hp
  have h : env59540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59539_59540 : H12AffineEnvironment.transform 9 141 env59539 = env59540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 141 env59539 == env59540) = true)

def env59541 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16465,262144,95615,32769,4096,61649,16,284032,86519,94526,77841,1297,74815,96347,381313,74799,256,323754,1344,95102]

theorem envBound59541 : H12AffineFastState.Bounded env59541 := by
  intro p hp
  have h : env59541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59473_59541 : H12AffineEnvironment.transform 16 16465 env59473 = env59541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16465 env59473 == env59541) = true)

def env59542 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1345,262144,77935,32769,4096,46529,16,266384,70887,78894,77841,1297,74815,81227,365713,74799,256,308666,1344,79470]

theorem envBound59542 : H12AffineFastState.Bounded env59542 := by
  intro p hp
  have h : env59542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59541_59542 : H12AffineEnvironment.transform 13 1296 env59541 = env59542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env59541 == env59542) = true)

theorem identity59542 : scanCanonicalize (H12AffineFastState.compose env59542 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound59542 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env59543 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1345,262144,77935,13340,4096,476,16,266384,70887,78894,77841,1297,74815,81227,336012,74799,256,262567,1344,79470]

theorem envBound59543 : H12AffineFastState.Bounded env59543 := by
  intro p hp
  have h : env59543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59542_59543 : H12AffineEnvironment.transform 14 13341 env59542 = env59543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env59542 == env59543) = true)

def env59544 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1345,65664,77935,13340,4096,476,16,69648,70887,78894,77841,1297,74815,81227,8204,74799,256,65831,1344,79470]

theorem envBound59544 : H12AffineFastState.Bounded env59544 := by
  intro p hp
  have h : env59544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59543_59544 : H12AffineEnvironment.transform 17 65664 env59543 = env59544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env59543 == env59544) = true)

theorem identity59544 : scanCanonicalize (H12AffineFastState.compose env59544 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 358) := by decide +kernel

theorem selectedBound59544 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env59545 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,358,1345,486,12553,13340,4096,476,16,4470,5505,13640,12663,1297,9561,15405,8204,9545,256,65,1344,14088]

theorem envBound59545 : H12AffineFastState.Bounded env59545 := by
  intro p hp
  have h : env59545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59544_59545 : H12AffineEnvironment.transform 15 358 env59544 = env59545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 358 env59544 == env59545) = true)

def env59546 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,1296,13341,310,1297,438,12553,13340,4096,396,16,4390,5505,13592,12583,1297,9481,15405,8204,9497,256,17,1296,14088]

theorem envBound59546 : H12AffineFastState.Bounded env59546 := by
  intro p hp
  have h : env59546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59545_59546 : H12AffineEnvironment.transform 5 16 env59545 = env59546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env59545 == env59546) = true)

theorem identity59546 : scanCanonicalize (H12AffineFastState.compose env59546 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound59546 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59547 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1028,8192,1296,8217,310,1297,438,9485,8216,1028,396,16,1314,389,8476,9507,1297,9481,10281,8204,9497,256,17,1296,8972]

theorem envBound59547 : H12AffineFastState.Bounded env59547 := by
  intro p hp
  have h : env59547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59546_59547 : H12AffineEnvironment.transform 11 1028 env59546 = env59547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env59546 == env59547) = true)

theorem identity59547 : scanCanonicalize (H12AffineFastState.compose env59547 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound59547 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env59548 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1028,269,1296,276,310,1297,438,1024,277,1028,396,16,1314,389,17,1070,1297,1028,2340,257,1044,256,17,1296,513]

theorem envBound59548 : H12AffineFastState.Bounded env59548 := by
  intro p hp
  have h : env59548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59547_59548 : H12AffineEnvironment.transform 12 269 env59547 = env59548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env59547 == env59548) = true)

theorem identity59548 : scanCanonicalize (H12AffineFastState.compose env59548 (packedSelected [2,13,17] rootPS)) = affineNative (2^(10+1) ^^^ 1703) := by decide +kernel

theorem selectedBound59548 : packedSelected [2,13,17] rootPS < 2^1333 := by decide +kernel

def env59549 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1703,1028,269,1296,276,310,1297,438,1024,277,1028,396,16,1314,389,17,1070,1297,1028,1923,257,1044,256,17,1296,513]

theorem envBound59549 : H12AffineFastState.Bounded env59549 := by
  intro p hp
  have h : env59549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59548_59549 : H12AffineEnvironment.transform 10 1703 env59548 = env59549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1703 env59548 == env59549) = true)

theorem identity59549 : scanCanonicalize (H12AffineFastState.compose env59549 (packedSelected [1,3,13] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound59549 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env59550 : List Nat := [2,4,8,16,32,16,57,256,512,1024,1566,1028,269,1296,276,310,1297,271,1024,277,1028,309,16,1314,316,17,1070,1297,1028,1850,257,1044,256,17,1296,513]

theorem envBound59550 : H12AffineFastState.Bounded env59550 := by
  intro p hp
  have h : env59550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59549_59550 : H12AffineEnvironment.transform 6 57 env59549 = env59550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env59549 == env59550) = true)

theorem identity59550 : scanCanonicalize (H12AffineFastState.compose env59550 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 549) := by decide +kernel

theorem selectedBound59550 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env59551 : List Nat := [2,4,8,16,32,16,57,256,512,549,59,545,269,821,276,310,820,271,549,277,545,309,16,775,316,17,523,820,545,287,257,561,256,17,821,513]

theorem envBound59551 : H12AffineFastState.Bounded env59551 := by
  intro p hp
  have h : env59551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59550_59551 : H12AffineEnvironment.transform 9 549 env59550 = env59551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 549 env59550 == env59551) = true)

theorem identity59551 : scanCanonicalize (H12AffineFastState.compose env59551 (packedSelected [1,4,5,8,9,11] rootPS)) = affineNative (2^(7+1) ^^^ 34) := by decide +kernel

theorem selectedBound59551 : packedSelected [1,4,5,8,9,11] rootPS < 2^1333 := by decide +kernel

def env59552 : List Nat := [2,4,8,16,32,16,57,34,512,549,59,545,47,535,54,20,534,45,549,55,545,23,16,549,30,17,523,534,545,61,35,561,34,17,535,513]

theorem envBound59552 : H12AffineFastState.Bounded env59552 := by
  intro p hp
  have h : env59552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59551_59552 : H12AffineEnvironment.transform 7 34 env59551 = env59552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 34 env59551 == env59552) = true)

theorem identity59552 : scanCanonicalize (H12AffineFastState.compose env59552 (packedSelected [0,1,2,3,4,7,9,12,15] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound59552 : packedSelected [0,1,2,3,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env59553 : List Nat := [2,4,8,16,7,16,30,5,512,514,28,518,8,535,17,20,534,10,514,16,518,23,16,514,30,17,523,534,518,26,4,534,5,17,535,513]

theorem envBound59553 : H12AffineFastState.Bounded env59553 := by
  intro p hp
  have h : env59553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59552_59553 : H12AffineEnvironment.transform 4 7 env59552 = env59553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env59552 == env59553) = true)

theorem identity59553 : scanCanonicalize (H12AffineFastState.compose env59553 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound59553 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env59554 : List Nat := [2,3,8,16,0,16,25,2,512,514,27,513,8,528,17,19,529,10,514,16,513,16,16,514,25,17,523,529,513,26,3,529,2,17,528,513]

theorem envBound59554 : H12AffineFastState.Bounded env59554 := by
  intro p hp
  have h : env59554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59553_59554 : H12AffineEnvironment.transform 1 3 env59553 = env59554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env59553 == env59554) = true)

theorem identity59554 : scanCanonicalize (H12AffineFastState.compose env59554 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound59554 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59555 : List Nat := [0,1,8,16,0,16,25,0,512,512,25,513,8,528,17,17,529,8,512,16,513,16,16,512,25,17,521,529,513,24,1,529,0,17,528,513]

theorem envBound59555 : H12AffineFastState.Bounded env59555 := by
  intro p hp
  have h : env59555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59554_59555 : H12AffineEnvironment.transform 0 0 env59554 = env59555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env59554 == env59555) = true)

theorem identity59555 : scanCanonicalize (H12AffineFastState.compose env59555 (packedSelected [1,2,3] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound59555 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env59556 : List Nat := [0,1,1,16,0,16,16,0,512,512,16,513,1,528,17,17,529,1,512,16,513,16,16,512,16,17,512,529,513,17,1,529,0,17,528,513]

theorem envBound59556 : H12AffineFastState.Bounded env59556 := by
  intro p hp
  have h : env59556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59555_59556 : H12AffineEnvironment.transform 2 1 env59555 = env59556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env59555 == env59556) = true)

theorem identity59556 : scanCanonicalize (H12AffineFastState.compose env59556 (packedSelected [1,2] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound59556 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env59557 : List Nat := [0,1,1,16,0,16,16,0,1,1,16,0,1,17,17,17,16,1,1,16,0,16,16,1,16,17,1,16,0,17,1,16,0,17,17,0]

theorem envBound59557 : H12AffineFastState.Bounded env59557 := by
  intro p hp
  have h : env59557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59556_59557 : H12AffineEnvironment.transform 8 1 env59556 = env59557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env59556 == env59557) = true)

def env59558 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,1296,13341,311,1296,439,12553,13340,4096,397,16,4391,5505,13593,12582,1297,9480,15405,8204,9496,256,16,1297,14088]

theorem envBound59558 : H12AffineFastState.Bounded env59558 := by
  intro p hp
  have h : env59558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59545_59558 : H12AffineEnvironment.transform 5 17 env59545 = env59558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env59545 == env59558) = true)

theorem identity59558 : scanCanonicalize (H12AffineFastState.compose env59558 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound59558 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59559 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,269,1296,5392,311,1296,439,4100,5393,4096,397,16,4391,5505,5140,4139,1297,1029,7456,257,1045,256,16,1297,5637]

theorem envBound59559 : H12AffineFastState.Bounded env59559 := by
  intro p hp
  have h : env59559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59558_59559 : H12AffineEnvironment.transform 12 269 env59558 = env59559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env59558 == env59559) = true)

theorem identity59559 : scanCanonicalize (H12AffineFastState.compose env59559 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound59559 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env59560 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1029,269,1296,277,311,1296,439,1025,276,1029,397,16,1314,388,17,1070,1297,1029,2341,257,1045,256,16,1297,512]

theorem envBound59560 : H12AffineFastState.Bounded env59560 := by
  intro p hp
  have h : env59560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59559_59560 : H12AffineEnvironment.transform 11 1029 env59559 = env59560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env59559 == env59560) = true)

theorem identity59560 : scanCanonicalize (H12AffineFastState.compose env59560 (packedSelected [2,13,17] rootPS)) = affineNative (2^(10+1) ^^^ 1944) := by decide +kernel

theorem selectedBound59560 : packedSelected [2,13,17] rootPS < 2^1333 := by decide +kernel

def env59561 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1944,1029,269,1296,277,311,1296,439,1025,276,1029,397,16,1314,388,17,1070,1297,1029,1725,257,1045,256,16,1297,512]

theorem envBound59561 : H12AffineFastState.Bounded env59561 := by
  intro p hp
  have h : env59561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59560_59561 : H12AffineEnvironment.transform 10 1944 env59560 = env59561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1944 env59560 == env59561) = true)

theorem identity59561 : scanCanonicalize (H12AffineFastState.compose env59561 (packedSelected [3,8,10,13] rootPS)) = affineNative (2^(8+1) ^^^ 277) := by decide +kernel

theorem selectedBound59561 : packedSelected [3,8,10,13] rootPS < 2^1333 := by decide +kernel

def env59562 : List Nat := [2,4,8,16,32,17,128,256,277,1024,1165,1029,269,1296,277,311,1296,439,1025,276,1029,397,16,1314,388,17,1070,1297,1029,1448,257,1045,256,16,1297,277]

theorem envBound59562 : H12AffineFastState.Bounded env59562 := by
  intro p hp
  have h : env59562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59561_59562 : H12AffineEnvironment.transform 8 277 env59561 = env59562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env59561 == env59562) = true)

theorem identity59562 : scanCanonicalize (H12AffineFastState.compose env59562 (packedSelected [0,2,3,7,8,11] rootPS)) = affineNative (2^(9+1) ^^^ 288) := by decide +kernel

theorem selectedBound59562 : packedSelected [0,2,3,7,8,11] rootPS < 2^1333 := by decide +kernel

def env59563 : List Nat := [2,4,8,16,32,17,128,256,277,288,429,293,269,48,277,311,48,439,289,276,293,397,16,2,388,17,270,49,293,136,257,309,256,16,49,277]

theorem envBound59563 : H12AffineFastState.Bounded env59563 := by
  intro p hp
  have h : env59563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59562_59563 : H12AffineEnvironment.transform 9 288 env59562 = env59563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 288 env59562 == env59563) = true)

theorem identity59563 : scanCanonicalize (H12AffineFastState.compose env59563 (packedSelected [2,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound59563 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env59564 : List Nat := [2,4,8,16,32,17,128,37,48,5,136,0,40,48,48,18,48,146,4,49,0,168,16,2,161,17,43,49,0,136,36,16,37,16,49,48]

theorem envBound59564 : H12AffineFastState.Bounded env59564 := by
  intro p hp
  have h : env59564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59563_59564 : H12AffineEnvironment.transform 7 37 env59563 = env59564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env59563 == env59564) = true)

theorem identity59564 : scanCanonicalize (H12AffineFastState.compose env59564 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound59564 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59565 : List Nat := [2,4,4,16,32,17,128,37,48,5,132,0,36,48,48,18,48,146,4,49,0,164,16,2,161,17,39,49,0,132,36,16,37,16,49,48]

theorem envBound59565 : H12AffineFastState.Bounded env59565 := by
  intro p hp
  have h : env59565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59564_59565 : H12AffineEnvironment.transform 2 4 env59564 = env59565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env59564 == env59565) = true)

theorem identity59565 : scanCanonicalize (H12AffineFastState.compose env59565 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound59565 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env59566 : List Nat := [2,4,4,16,6,17,128,3,22,5,132,0,2,22,22,18,22,146,4,23,0,130,16,2,135,17,1,23,0,132,2,16,3,16,23,22]

theorem envBound59566 : H12AffineFastState.Bounded env59566 := by
  intro p hp
  have h : env59566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59565_59566 : H12AffineEnvironment.transform 4 6 env59565 = env59566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env59565 == env59566) = true)

def env59567 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1345,65665,77935,13340,4096,476,16,69649,70887,78894,77841,1297,74815,81227,8205,74799,256,65830,1344,79470]

theorem envBound59567 : H12AffineFastState.Bounded env59567 := by
  intro p hp
  have h : env59567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59543_59567 : H12AffineEnvironment.transform 17 65665 env59543 = env59567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env59543 == env59567) = true)

theorem identity59567 : scanCanonicalize (H12AffineFastState.compose env59567 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5158) := by decide +kernel

theorem selectedBound59567 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env59568 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,5158,1345,5287,9289,13340,4096,476,16,1079,193,8200,9271,1297,12313,10605,8205,12297,256,5376,1344,8776]

theorem envBound59568 : H12AffineFastState.Bounded env59568 := by
  intro p hp
  have h : env59568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59567_59568 : H12AffineEnvironment.transform 15 5158 env59567 = env59568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5158 env59567 == env59568) = true)

def env59569 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,1296,13341,5158,1297,5287,9241,13340,4096,396,16,1079,145,8200,9271,1297,12313,10557,8205,12297,256,5376,1296,8728]

theorem envBound59569 : H12AffineFastState.Bounded env59569 := by
  intro p hp
  have h : env59569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59568_59569 : H12AffineEnvironment.transform 5 16 env59568 = env59569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env59568 == env59569) = true)

theorem identity59569 : scanCanonicalize (H12AffineFastState.compose env59569 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound59569 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59570 : List Nat := [2,4,8,16,32,16,128,21,512,1024,2048,4096,8192,1029,13341,5158,1028,5287,9241,13340,4096,153,16,1079,145,8200,9271,1028,12313,10280,8205,12297,21,5141,1029,8728]

theorem envBound59570 : H12AffineFastState.Bounded env59570 := by
  intro p hp
  have h : env59570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59569_59570 : H12AffineEnvironment.transform 7 21 env59569 = env59570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env59569 == env59570) = true)

def env59571 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,1296,13341,5158,1296,5287,9240,13340,4096,397,16,1079,144,8200,9271,1297,12313,10556,8205,12297,256,5376,1297,8729]

theorem envBound59571 : H12AffineFastState.Bounded env59571 := by
  intro p hp
  have h : env59571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59568_59571 : H12AffineEnvironment.transform 5 17 env59568 = env59571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env59568 == env59571) = true)

theorem identity59571 : scanCanonicalize (H12AffineFastState.compose env59571 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound59571 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59572 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,268,1296,5393,5158,1296,5287,1300,5392,4096,397,16,1079,144,260,1339,1297,4373,2096,257,4357,256,5376,1297,789]

theorem envBound59572 : H12AffineFastState.Bounded env59572 := by
  intro p hp
  have h : env59572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59571_59572 : H12AffineEnvironment.transform 12 268 env59571 = env59572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env59571 == env59572) = true)

theorem identity59572 : scanCanonicalize (H12AffineFastState.compose env59572 (packedSelected [1,2,5,8,19,23,24,26,32] rootPS)) = affineNative (2^(11+1) ^^^ 1677) := by decide +kernel

theorem selectedBound59572 : packedSelected [1,2,5,8,19,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env59573 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1677,268,1296,924,683,1296,554,1300,925,1677,397,16,1079,144,260,1339,1297,1944,2096,257,1928,256,909,1297,789]

theorem envBound59573 : H12AffineFastState.Bounded env59573 := by
  intro p hp
  have h : env59573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59572_59573 : H12AffineEnvironment.transform 11 1677 env59572 = env59573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1677 env59572 == env59573) = true)

theorem identity59573 : scanCanonicalize (H12AffineFastState.compose env59573 (packedSelected [0,1,4,7,8,9,18,19,21,23,24,28] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound59573 : packedSelected [0,1,4,7,8,9,18,19,21,23,24,28] rootPS < 2^1333 := by decide +kernel

def env59574 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,1029,268,1296,276,35,1296,162,1300,277,1029,397,16,1079,144,260,1339,1297,1296,2096,257,1280,256,261,1297,413]

theorem envBound59574 : H12AffineFastState.Bounded env59574 := by
  intro p hp
  have h : env59574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59573_59574 : H12AffineEnvironment.transform 8 136 env59573 = env59574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env59573 == env59574) = true)

theorem identity59574 : scanCanonicalize (H12AffineFastState.compose env59574 (packedSelected [2,5,8,17] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound59574 : packedSelected [2,5,8,17] rootPS < 2^1333 := by decide +kernel

def env59575 : List Nat := [2,4,8,16,32,17,128,256,136,1024,1076,1029,268,1296,276,35,1296,162,1300,277,1029,397,16,1079,144,260,1339,1297,1296,1028,257,1280,256,261,1297,413]

theorem envBound59575 : H12AffineFastState.Bounded env59575 := by
  intro p hp
  have h : env59575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59574_59575 : H12AffineEnvironment.transform 10 1076 env59574 = env59575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env59574 == env59575) = true)

theorem identity59575 : scanCanonicalize (H12AffineFastState.compose env59575 (packedSelected [1,2,3,5,8,10,12,13] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound59575 : packedSelected [1,2,3,5,8,10,12,13] rootPS < 2^1333 := by decide +kernel

def env59576 : List Nat := [2,4,8,16,32,17,34,256,42,1024,1076,1029,268,1296,276,35,1296,0,1300,277,1029,303,16,1079,50,260,1339,1297,1296,1028,257,1280,256,261,1297,319]

theorem envBound59576 : H12AffineFastState.Bounded env59576 := by
  intro p hp
  have h : env59576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59575_59576 : H12AffineEnvironment.transform 6 34 env59575 = env59576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env59575 == env59576) = true)

theorem identity59576 : scanCanonicalize (H12AffineFastState.compose env59576 (packedSelected [3,4,5,9] rootPS)) = affineNative (2^(9+1) ^^^ 288) := by decide +kernel

theorem selectedBound59576 : packedSelected [3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env59577 : List Nat := [2,4,8,16,32,17,34,256,42,288,276,293,268,48,276,35,48,0,52,277,293,303,16,279,50,260,27,49,48,292,257,32,256,261,49,319]

theorem envBound59577 : H12AffineFastState.Bounded env59577 := by
  intro p hp
  have h : env59577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59576_59577 : H12AffineEnvironment.transform 9 288 env59576 = env59577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 288 env59576 == env59577) = true)

theorem identity59577 : scanCanonicalize (H12AffineFastState.compose env59577 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound59577 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env59578 : List Nat := [2,4,8,16,10,17,8,256,0,266,276,271,268,26,276,9,26,0,30,277,271,261,16,279,24,260,27,27,26,270,257,10,256,261,27,277]

theorem envBound59578 : H12AffineFastState.Bounded env59578 := by
  intro p hp
  have h : env59578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59577_59578 : H12AffineEnvironment.transform 4 10 env59577 = env59578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env59577 == env59578) = true)

theorem identity59578 : scanCanonicalize (H12AffineFastState.compose env59578 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound59578 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env59579 : List Nat := [2,4,8,16,10,17,8,20,0,30,0,27,24,26,0,9,26,0,30,1,27,17,16,3,24,16,27,27,26,26,21,10,20,17,27,1]

theorem envBound59579 : H12AffineFastState.Bounded env59579 := by
  intro p hp
  have h : env59579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59578_59579 : H12AffineEnvironment.transform 7 20 env59578 = env59579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env59578 == env59579) = true)

theorem identity59579 : scanCanonicalize (H12AffineFastState.compose env59579 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound59579 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env59580 : List Nat := [2,4,8,3,10,2,8,7,0,13,0,8,11,9,0,9,9,0,13,1,8,2,3,3,11,3,8,8,9,9,6,10,7,2,8,1]

theorem envBound59580 : H12AffineFastState.Bounded env59580 := by
  intro p hp
  have h : env59580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59579_59580 : H12AffineEnvironment.transform 3 3 env59579 = env59580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env59579 == env59580) = true)

theorem identity59580 : scanCanonicalize (H12AffineFastState.compose env59580 (packedSelected [0,4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound59580 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env59581 : List Nat := [0,4,8,1,8,0,8,5,0,13,0,8,9,9,0,9,9,0,13,1,8,0,1,1,9,1,8,8,9,9,4,8,5,0,8,1]

theorem envBound59581 : H12AffineFastState.Bounded env59581 := by
  intro p hp
  have h : env59581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59580_59581 : H12AffineEnvironment.transform 0 0 env59580 = env59581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env59580 == env59581) = true)

theorem identity59581 : scanCanonicalize (H12AffineFastState.compose env59581 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound59581 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59582 : List Nat := [0,1,8,1,8,0,8,0,0,8,0,8,9,9,0,9,9,0,8,1,8,0,1,1,9,1,8,8,9,9,1,8,0,0,8,1]

theorem envBound59582 : H12AffineFastState.Bounded env59582 := by
  intro p hp
  have h : env59582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59581_59582 : H12AffineEnvironment.transform 1 1 env59581 = env59582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env59581 == env59582) = true)

def env59583 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1344,262144,77934,32769,4096,46528,16,266385,70886,78895,77841,1297,74815,81226,365712,74799,256,308667,1344,79471]

theorem envBound59583 : H12AffineFastState.Bounded env59583 := by
  intro p hp
  have h : env59583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59541_59583 : H12AffineEnvironment.transform 13 1297 env59541 = env59583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env59541 == env59583) = true)

theorem identity59583 : scanCanonicalize (H12AffineFastState.compose env59583 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32883) := by decide +kernel

theorem selectedBound59583 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env59584 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,32883,1344,262144,45085,32769,4096,46528,16,266385,38037,46172,45154,1297,42060,48441,267491,42076,256,308667,1344,46620]

theorem envBound59584 : H12AffineFastState.Bounded env59584 := by
  intro p hp
  have h : env59584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59583_59584 : H12AffineEnvironment.transform 15 32883 env59583 = env59584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32883 env59583 == env59584) = true)

def env59585 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32883,1344,262144,42333,32769,1344,41088,16,263633,33237,41244,42274,1297,42060,43129,262563,42076,256,303355,1344,41820]

theorem envBound59585 : H12AffineFastState.Bounded env59585 := by
  intro p hp
  have h : env59585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59584_59585 : H12AffineEnvironment.transform 11 1344 env59584 = env59585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env59584 == env59585) = true)

theorem identity59585 : scanCanonicalize (H12AffineFastState.compose env59585 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 9454) := by decide +kernel

theorem selectedBound59585 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env59586 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32883,1344,9454,42333,32769,1344,41088,16,8511,33237,41244,42274,1297,42060,43129,9549,42076,256,33813,1344,41820]

theorem envBound59586 : H12AffineFastState.Bounded env59586 := by
  intro p hp
  have h : env59586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59585_59586 : H12AffineEnvironment.transform 17 9454 env59585 = env59586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 9454 env59585 == env59586) = true)

theorem identity59586 : scanCanonicalize (H12AffineFastState.compose env59586 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(14+1) ^^^ 8825) := by decide +kernel

theorem selectedBound59586 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env59587 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,8825,8714,1344,9454,1828,8824,1344,761,16,8511,9132,869,1883,1297,1589,2560,9549,1573,256,9836,1344,293]

theorem envBound59587 : H12AffineFastState.Bounded env59587 := by
  intro p hp
  have h : env59587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59586_59587 : H12AffineEnvironment.transform 14 8825 env59586 = env59587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8825 env59586 == env59587) = true)

def env59588 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32883,1344,262144,42332,32769,1345,41089,16,263632,33236,41245,42275,1297,42060,43128,262562,42076,256,303354,1344,41821]

theorem envBound59588 : H12AffineFastState.Bounded env59588 := by
  intro p hp
  have h : env59588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59584_59588 : H12AffineEnvironment.transform 11 1345 env59584 = env59588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env59584 == env59588) = true)

theorem identity59588 : scanCanonicalize (H12AffineFastState.compose env59588 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 9244) := by decide +kernel

theorem selectedBound59588 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env59589 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,9244,9327,1344,262144,320,9245,1345,1181,16,263632,9672,1281,319,1297,80,3172,262562,64,256,263398,1344,1857]

theorem envBound59589 : H12AffineFastState.Bounded env59589 := by
  intro p hp
  have h : env59589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59588_59589 : H12AffineEnvironment.transform 14 9244 env59588 = env59589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9244 env59588 == env59589) = true)

theorem identity59589 : scanCanonicalize (H12AffineFastState.compose env59589 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound59589 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env59590 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,0,8192,80,8541,8494,1,262144,320,8540,0,476,16,262289,8329,64,319,80,80,2341,262562,64,256,262567,1,512]

theorem envBound59590 : H12AffineFastState.Bounded env59590 := by
  intro p hp
  have h : env59590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59589_59590 : H12AffineEnvironment.transform 9 321 env59589 = env59590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env59589 == env59590) = true)

theorem identity59590 : scanCanonicalize (H12AffineFastState.compose env59590 (packedSelected [4,9,16] rootPS)) = affineNative (2^(17+1) ^^^ 243) := by decide +kernel

theorem selectedBound59590 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59591 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,0,8192,80,8541,8494,1,243,320,8540,0,476,16,98,8329,64,319,80,80,2341,337,64,256,340,1,512]

theorem envBound59591 : H12AffineFastState.Bounded env59591 := by
  intro p hp
  have h : env59591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59590_59591 : H12AffineEnvironment.transform 17 243 env59590 = env59591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 243 env59590 == env59591) = true)

theorem identity59591 : scanCanonicalize (H12AffineFastState.compose env59591 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 704) := by decide +kernel

theorem selectedBound59591 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env59592 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,0,704,80,925,1006,1,243,320,924,0,476,16,98,585,64,319,80,80,2341,337,64,256,340,1,512]

theorem envBound59592 : H12AffineFastState.Bounded env59592 := by
  intro p hp
  have h : env59592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59591_59592 : H12AffineEnvironment.transform 12 704 env59591 = env59592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 704 env59591 == env59592) = true)

theorem identity59592 : scanCanonicalize (H12AffineFastState.compose env59592 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound59592 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env59593 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,657,1,925,959,1,162,273,924,0,397,16,51,536,17,319,1,1,2341,256,17,256,261,1,512]

theorem envBound59593 : H12AffineFastState.Bounded env59593 := by
  intro p hp
  have h : env59593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59592_59593 : H12AffineEnvironment.transform 5 17 env59592 = env59593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env59592 == env59593) = true)

def env59594 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95615,32769,4096,61649,147521,284033,86519,209263,225345,148800,74815,96347,381312,74799,256,323755,1344,95102]

theorem envBound59594 : H12AffineFastState.Bounded env59594 := by
  intro p hp
  have h : env59594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59472_59594 : H12AffineEnvironment.transform 23 284033 env59472 = env59594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 284033 env59472 == env59594) = true)

def env59595 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16464,262144,95615,32769,4096,61649,17,284033,86519,94527,77841,1296,74815,96347,381312,74799,256,323755,1344,95102]

theorem envBound59595 : H12AffineFastState.Bounded env59595 := by
  intro p hp
  have h : env59595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59594_59595 : H12AffineEnvironment.transform 16 16464 env59594 = env59595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16464 env59594 == env59595) = true)

def env59596 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1344,262144,77935,32769,4096,46529,17,266385,70887,78895,77841,1296,74815,81227,365712,74799,256,308667,1344,79470]

theorem envBound59596 : H12AffineFastState.Bounded env59596 := by
  intro p hp
  have h : env59596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59595_59596 : H12AffineEnvironment.transform 13 1296 env59595 = env59596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env59595 == env59596) = true)

theorem identity59596 : scanCanonicalize (H12AffineFastState.compose env59596 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32882) := by decide +kernel

theorem selectedBound59596 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env59597 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,32882,1344,262144,45085,32769,4096,46529,17,266385,38037,46173,45155,1296,42061,48441,267490,42077,256,308667,1344,46620]

theorem envBound59597 : H12AffineFastState.Bounded env59597 := by
  intro p hp
  have h : env59597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59596_59597 : H12AffineEnvironment.transform 15 32882 env59596 = env59597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32882 env59596 == env59597) = true)

def env59598 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32882,1344,262144,42333,32769,1344,41089,17,263633,33237,41245,42275,1296,42061,43129,262562,42077,256,303355,1344,41820]

theorem envBound59598 : H12AffineFastState.Bounded env59598 := by
  intro p hp
  have h : env59598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59597_59598 : H12AffineEnvironment.transform 11 1344 env59597 = env59598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env59597 == env59598) = true)

theorem identity59598 : scanCanonicalize (H12AffineFastState.compose env59598 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 487) := by decide +kernel

theorem selectedBound59598 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env59599 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32882,1344,487,42333,32769,1344,41089,17,1078,33237,41245,42275,1296,42061,43129,69,42077,256,41244,1344,41820]

theorem envBound59599 : H12AffineFastState.Bounded env59599 := by
  intro p hp
  have h : env59599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59598_59599 : H12AffineEnvironment.transform 17 487 env59598 = env59599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 487 env59598 == env59599) = true)

theorem identity59599 : scanCanonicalize (H12AffineFastState.compose env59599 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound59599 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env59600 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,8540,8494,1344,487,1025,8541,1344,477,17,1078,8329,65,1151,1296,1297,2341,69,1281,256,64,1344,512]

theorem envBound59600 : H12AffineFastState.Bounded env59600 := by
  intro p hp
  have h : env59600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59599_59600 : H12AffineEnvironment.transform 14 8540 env59599 = env59600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env59599 == env59600) = true)

theorem identity59600 : scanCanonicalize (H12AffineFastState.compose env59600 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound59600 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59601 : List Nat := [2,4,8,16,32,64,128,20,512,1024,2048,1108,8192,1028,8264,8250,1108,243,1025,8265,1108,201,17,1078,8329,65,1151,1028,1029,2097,69,1045,20,64,1108,512]

theorem envBound59601 : H12AffineFastState.Bounded env59601 := by
  intro p hp
  have h : env59601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59600_59601 : H12AffineEnvironment.transform 7 20 env59600 = env59601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env59600 == env59601) = true)

theorem identity59601 : scanCanonicalize (H12AffineFastState.compose env59601 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 1684) := by decide +kernel

theorem selectedBound59601 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env59602 : List Nat := [2,4,8,16,32,64,128,20,512,1024,2048,1108,1684,1028,1756,1710,1108,243,1025,1757,1108,201,17,1078,1565,65,1151,1028,1029,2097,69,1045,20,64,1108,512]

theorem envBound59602 : H12AffineFastState.Bounded env59602 := by
  intro p hp
  have h : env59602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59601_59602 : H12AffineEnvironment.transform 12 1684 env59601 = env59602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1684 env59601 == env59602) = true)

theorem identity59602 : scanCanonicalize (H12AffineFastState.compose env59602 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound59602 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env59603 : List Nat := [2,4,8,16,32,17,128,20,512,1024,2048,1029,1684,1028,1677,1710,1029,162,1025,1676,1029,152,17,1078,1565,16,1070,1028,1029,2097,20,1045,20,17,1029,512]

theorem envBound59603 : H12AffineFastState.Bounded env59603 := by
  intro p hp
  have h : env59603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59602_59603 : H12AffineEnvironment.transform 5 17 env59602 = env59603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env59602 == env59603) = true)

theorem identity59603 : scanCanonicalize (H12AffineFastState.compose env59603 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 140) := by decide +kernel

theorem selectedBound59603 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env59604 : List Nat := [2,4,8,16,32,17,128,20,512,140,2048,137,536,136,513,546,137,162,141,512,137,152,17,186,657,16,162,136,137,2097,20,153,20,17,137,512]

theorem envBound59604 : H12AffineFastState.Bounded env59604 := by
  intro p hp
  have h : env59604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59603_59604 : H12AffineEnvironment.transform 9 140 env59603 = env59604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 140 env59603 == env59604) = true)

theorem identity59604 : scanCanonicalize (H12AffineFastState.compose env59604 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound59604 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env59605 : List Nat := [2,4,8,16,32,17,8,20,512,4,2048,1,536,0,513,546,1,42,5,512,1,16,17,50,537,16,42,0,1,2097,20,17,20,17,1,512]

theorem envBound59605 : H12AffineFastState.Bounded env59605 := by
  intro p hp
  have h : env59605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59604_59605 : H12AffineEnvironment.transform 6 8 env59604 = env59605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env59604 == env59605) = true)

theorem identity59605 : scanCanonicalize (H12AffineFastState.compose env59605 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 29) := by decide +kernel

theorem selectedBound59605 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

end H12CloudChart2