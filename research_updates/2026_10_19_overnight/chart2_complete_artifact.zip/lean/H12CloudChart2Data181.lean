import H12CloudChart2Data180

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound45388 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45389 : List Nat := [2,0,0,1,32,0,1,33,32,1,33,32,0,32,32,3,33,3,0,33,33,32,0,35,1,0,34,33,32,33,0,0,32,33,32,33]

theorem envBound45389 : H12AffineFastState.Bounded env45389 := by
  intro p hp
  have h : env45389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45388_45389 : H12AffineEnvironment.transform 1 0 env45388 = env45389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env45388 == env45389) = true)

theorem identity45389 : scanCanonicalize (H12AffineFastState.compose env45389 (packedSelected [8] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound45389 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env45390 : List Nat := [1,0,0,1,32,0,1,33,32,1,33,32,0,32,32,0,33,0,0,33,33,32,0,32,1,0,33,33,32,33,0,0,32,33,32,33]

theorem envBound45390 : H12AffineFastState.Bounded env45390 := by
  intro p hp
  have h : env45390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45389_45390 : H12AffineEnvironment.transform 0 1 env45389 = env45390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env45389 == env45390) = true)

theorem identity45390 : scanCanonicalize (H12AffineFastState.compose env45390 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound45390 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45391 : List Nat := [1,0,0,1,1,0,1,0,1,1,0,1,0,1,1,0,0,0,0,0,0,1,0,1,1,0,0,0,1,0,0,0,1,0,1,0]

theorem envBound45391 : H12AffineFastState.Bounded env45391 := by
  intro p hp
  have h : env45391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45390_45391 : H12AffineEnvironment.transform 4 1 env45390 = env45391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env45390 == env45391) = true)

def env45392 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16465,262144,95614,32769,4097,61648,16,284033,86519,94526,77841,1297,74815,96346,381312,323754,257,74799,1344,95102]

theorem envBound45392 : H12AffineFastState.Bounded env45392 := by
  intro p hp
  have h : env45392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45325_45392 : H12AffineEnvironment.transform 16 16465 env45325 = env45392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16465 env45325 == env45392) = true)

def env45393 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1345,262144,77934,32769,4097,46528,16,266385,70887,78894,77841,1297,74815,81226,365712,308666,257,74799,1344,79470]

theorem envBound45393 : H12AffineFastState.Bounded env45393 := by
  intro p hp
  have h : env45393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45392_45393 : H12AffineEnvironment.transform 13 1296 env45392 = env45393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env45392 == env45393) = true)

theorem identity45393 : scanCanonicalize (H12AffineFastState.compose env45393 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound45393 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env45394 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1345,262144,77934,13341,4097,476,16,266385,70887,78894,77841,1297,74815,81226,336012,262566,257,74799,1344,79470]

theorem envBound45394 : H12AffineFastState.Bounded env45394 := by
  intro p hp
  have h : env45394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45393_45394 : H12AffineEnvironment.transform 14 13340 env45393 = env45394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env45393 == env45394) = true)

def env45395 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1345,65664,77934,13341,4097,476,16,69649,70887,78894,77841,1297,74815,81226,8204,65830,257,74799,1344,79470]

theorem envBound45395 : H12AffineFastState.Bounded env45395 := by
  intro p hp
  have h : env45395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45394_45395 : H12AffineEnvironment.transform 17 65664 env45394 = env45395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env45394 == env45395) = true)

theorem identity45395 : scanCanonicalize (H12AffineFastState.compose env45395 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound45395 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env45396 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,81,12637,65536,0,65664,77934,12636,4097,476,16,69649,70054,78191,77841,80,74110,79883,8204,65830,257,74094,1,78639]

theorem envBound45396 : H12AffineFastState.Bounded env45396 := by
  intro p hp
  have h : env45396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45395_45396 : H12AffineEnvironment.transform 9 321 env45395 = env45396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env45395 == env45396) = true)

def env45397 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,4096,8192,1,12557,65536,0,65664,77886,12556,4097,396,16,69649,70054,78143,77841,0,74030,79883,8204,65830,257,74046,1,78639]

theorem envBound45397 : H12AffineFastState.Bounded env45397 := by
  intro p hp
  have h : env45397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45396_45397 : H12AffineEnvironment.transform 5 16 env45396 = env45397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env45396 == env45397) = true)

theorem identity45397 : scanCanonicalize (H12AffineFastState.compose env45397 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound45397 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env45398 : List Nat := [2,4,8,16,32,16,128,21,512,4,2048,4096,8192,1,12312,65536,0,65664,77886,12313,4097,153,16,69649,69811,77866,77841,0,73787,79883,8204,65587,20,73771,1,78394]

theorem envBound45398 : H12AffineFastState.Bounded env45398 := by
  intro p hp
  have h : env45398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45397_45398 : H12AffineEnvironment.transform 7 21 env45397 = env45398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env45397 == env45398) = true)

theorem identity45398 : scanCanonicalize (H12AffineFastState.compose env45398 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound45398 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env45399 : List Nat := [2,4,8,16,32,16,128,21,512,4,2048,1,8192,1,8217,65536,0,65664,73791,8216,0,153,16,65552,65714,73771,73744,0,73787,75786,8204,65587,20,73771,1,74299]

theorem envBound45399 : H12AffineFastState.Bounded env45399 := by
  intro p hp
  have h : env45399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45398_45399 : H12AffineEnvironment.transform 11 1 env45398 = env45399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env45398 == env45399) = true)

theorem identity45399 : scanCanonicalize (H12AffineFastState.compose env45399 (packedSelected [0,1,3,7,10,11,17,19] rootPS)) = affineNative (2^(15+1) ^^^ 2715) := by decide +kernel

theorem selectedBound45399 : packedSelected [0,1,3,7,10,11,17,19] rootPS < 2^1333 := by decide +kernel

def env45400 : List Nat := [2,4,8,16,32,16,128,21,512,4,2048,1,8192,1,8217,2715,0,2587,10916,8216,0,153,16,2699,2601,10928,10891,0,10912,8849,8204,2728,20,10928,1,10400]

theorem envBound45400 : H12AffineFastState.Bounded env45400 := by
  intro p hp
  have h : env45400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45399_45400 : H12AffineEnvironment.transform 15 2715 env45399 = env45400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2715 env45399 == env45400) = true)

theorem identity45400 : scanCanonicalize (H12AffineFastState.compose env45400 (packedSelected [1,8,13] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound45400 : packedSelected [1,8,13] rootPS < 2^1333 := by decide +kernel

def env45401 : List Nat := [2,4,8,16,32,16,19,21,512,4,2048,1,8192,1,8217,2568,0,2587,10807,8216,0,10,16,2584,2601,10787,10776,0,10803,8706,8204,2619,20,10787,1,10291]

theorem envBound45401 : H12AffineFastState.Bounded env45401 := by
  intro p hp
  have h : env45401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45400_45401 : H12AffineEnvironment.transform 6 19 env45400 = env45401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env45400 == env45401) = true)

theorem identity45401 : scanCanonicalize (H12AffineFastState.compose env45401 (packedSelected [1,2,3,10,15] rootPS)) = affineNative (2^(12+1) ^^^ 2562) := by decide +kernel

theorem selectedBound45401 : packedSelected [1,2,3,10,15] rootPS < 2^1333 := by decide +kernel

def env45402 : List Nat := [2,4,8,16,32,16,19,21,512,4,2048,1,2562,1,2587,2568,0,2587,53,2586,0,10,16,2584,2601,33,26,0,49,2048,2574,2619,20,33,1,561]

theorem envBound45402 : H12AffineFastState.Bounded env45402 := by
  intro p hp
  have h : env45402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45401_45402 : H12AffineEnvironment.transform 12 2562 env45401 = env45402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2562 env45401 == env45402) = true)

theorem identity45402 : scanCanonicalize (H12AffineFastState.compose env45402 (packedSelected [0,7,10] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound45402 : packedSelected [0,7,10] rootPS < 2^1333 := by decide +kernel

def env45403 : List Nat := [2,4,8,16,32,16,19,21,512,4,42,1,552,1,561,546,0,561,53,560,0,10,16,562,515,33,26,0,49,42,548,529,20,33,1,561]

theorem envBound45403 : H12AffineFastState.Bounded env45403 := by
  intro p hp
  have h : env45403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45402_45403 : H12AffineEnvironment.transform 10 42 env45402 = env45403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env45402 == env45403) = true)

def env45404 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,4096,8192,0,12556,65536,0,65664,77887,12557,4097,397,16,69649,70054,78142,77841,1,74031,79883,8204,65830,257,74047,1,78639]

theorem envBound45404 : H12AffineFastState.Bounded env45404 := by
  intro p hp
  have h : env45404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45396_45404 : H12AffineEnvironment.transform 5 17 env45396 = env45404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env45396 == env45404) = true)

theorem identity45404 : scanCanonicalize (H12AffineFastState.compose env45404 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 12346) := by decide +kernel

theorem selectedBound45404 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env45405 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,4096,8192,0,12556,12346,0,12474,5,12557,4097,397,16,8235,8604,260,43,1,4373,2097,8204,12572,257,4357,1,789]

theorem envBound45405 : H12AffineFastState.Bounded env45405 := by
  intro p hp
  have h : env45405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45404_45405 : H12AffineEnvironment.transform 15 12346 env45404 = env45405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12346 env45404 == env45405) = true)

theorem identity45405 : scanCanonicalize (H12AffineFastState.compose env45405 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound45405 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env45406 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,277,8192,0,8217,8495,0,8623,5,8216,276,397,16,8235,8604,260,43,1,0,2097,8204,8201,257,16,1,789]

theorem envBound45406 : H12AffineFastState.Bounded env45406 := by
  intro p hp
  have h : env45406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45405_45406 : H12AffineEnvironment.transform 11 277 env45405 = env45406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env45405 == env45406) = true)

theorem identity45406 : scanCanonicalize (H12AffineFastState.compose env45406 (packedSelected [0,2,3,7,8,11] rootPS)) = affineNative (2^(7+1) ^^^ 62) := by decide +kernel

theorem selectedBound45406 : packedSelected [0,2,3,7,8,11] rootPS < 2^1333 := by decide +kernel

def env45407 : List Nat := [2,4,8,16,32,17,128,62,512,46,2048,43,8192,0,8217,8209,0,8337,5,8216,42,179,16,8235,8354,58,43,1,0,2097,8204,8201,63,16,1,555]

theorem envBound45407 : H12AffineFastState.Bounded env45407 := by
  intro p hp
  have h : env45407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45406_45407 : H12AffineEnvironment.transform 7 62 env45406 = env45407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 62 env45406 == env45407) = true)

theorem identity45407 : scanCanonicalize (H12AffineFastState.compose env45407 (packedSelected [0,7,18] rootPS)) = affineNative (2^(12+1) ^^^ 144) := by decide +kernel

theorem selectedBound45407 : packedSelected [0,7,18] rootPS < 2^1333 := by decide +kernel

def env45408 : List Nat := [2,4,8,16,32,17,128,62,512,46,2048,43,144,0,137,129,0,1,5,136,42,179,16,187,50,58,43,1,0,2097,156,153,63,16,1,555]

theorem envBound45408 : H12AffineFastState.Bounded env45408 := by
  intro p hp
  have h : env45408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45407_45408 : H12AffineEnvironment.transform 12 144 env45407 = env45408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 144 env45407 == env45408) = true)

theorem identity45408 : scanCanonicalize (H12AffineFastState.compose env45408 (packedSelected [7,9] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound45408 : packedSelected [7,9] rootPS < 2^1333 := by decide +kernel

def env45409 : List Nat := [2,4,8,16,32,17,56,62,512,46,2048,43,40,0,49,57,0,1,5,48,42,11,16,3,50,58,43,1,0,2097,36,33,63,16,1,555]

theorem envBound45409 : H12AffineFastState.Bounded env45409 := by
  intro p hp
  have h : env45409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45408_45409 : H12AffineEnvironment.transform 6 56 env45408 = env45409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env45408 == env45409) = true)

theorem identity45409 : scanCanonicalize (H12AffineFastState.compose env45409 (packedSelected [2,4,7] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound45409 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env45410 : List Nat := [2,4,8,16,32,17,56,62,42,46,2048,43,40,0,49,57,0,1,5,48,42,11,16,3,50,58,43,1,0,2097,36,33,63,16,1,1]

theorem envBound45410 : H12AffineFastState.Bounded env45410 := by
  intro p hp
  have h : env45410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45409_45410 : H12AffineEnvironment.transform 8 42 env45409 = env45410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env45409 == env45410) = true)

theorem identity45410 : scanCanonicalize (H12AffineFastState.compose env45410 (packedSelected [3,5] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound45410 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env45411 : List Nat := [2,4,8,16,32,17,56,62,42,46,0,43,40,0,49,57,0,1,5,48,42,11,16,3,50,58,43,1,0,49,36,33,63,16,1,1]

theorem envBound45411 : H12AffineFastState.Bounded env45411 := by
  intro p hp
  have h : env45411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45410_45411 : H12AffineEnvironment.transform 10 0 env45410 = env45411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env45410 == env45411) = true)

theorem identity45411 : scanCanonicalize (H12AffineFastState.compose env45411 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound45411 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45412 : List Nat := [2,4,8,16,17,17,9,15,27,31,0,26,25,0,0,8,0,1,5,1,27,11,16,3,3,11,26,1,0,0,21,16,14,16,1,1]

theorem envBound45412 : H12AffineFastState.Bounded env45412 := by
  intro p hp
  have h : env45412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45411_45412 : H12AffineEnvironment.transform 4 17 env45411 = env45412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env45411 == env45412) = true)

theorem identity45412 : scanCanonicalize (H12AffineFastState.compose env45412 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound45412 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45413 : List Nat := [2,4,5,16,17,17,4,2,22,18,0,23,20,0,0,5,0,1,5,1,22,6,16,3,3,6,23,1,0,0,21,16,3,16,1,1]

theorem envBound45413 : H12AffineFastState.Bounded env45413 := by
  intro p hp
  have h : env45413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45412_45413 : H12AffineEnvironment.transform 2 5 env45412 = env45413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env45412 == env45413) = true)

theorem identity45413 : scanCanonicalize (H12AffineFastState.compose env45413 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound45413 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env45414 : List Nat := [2,4,5,7,6,6,4,2,1,5,0,0,3,0,0,5,0,1,5,1,1,6,7,3,3,6,0,1,0,0,2,7,3,7,1,1]

theorem envBound45414 : H12AffineFastState.Bounded env45414 := by
  intro p hp
  have h : env45414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45413_45414 : H12AffineEnvironment.transform 3 7 env45413 = env45414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env45413 == env45414) = true)

def env45415 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1345,65665,77934,13341,4097,476,16,69648,70887,78894,77841,1297,74815,81226,8205,65831,257,74799,1344,79470]

theorem envBound45415 : H12AffineFastState.Bounded env45415 := by
  intro p hp
  have h : env45415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45394_45415 : H12AffineEnvironment.transform 17 65665 env45394 = env45415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env45394 == env45415) = true)

theorem identity45415 : scanCanonicalize (H12AffineFastState.compose env45415 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound45415 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env45416 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1296,9244,65536,1345,65665,73838,9245,1,476,16,65552,66791,74798,73745,1297,74815,77130,8205,65831,257,74799,1344,75374]

theorem envBound45416 : H12AffineFastState.Bounded env45416 := by
  intro p hp
  have h : env45416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45415_45416 : H12AffineEnvironment.transform 11 0 env45415 = env45416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env45415 == env45416) = true)

def env45417 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,0,8192,1296,9244,65536,1297,65665,73790,9245,1,396,16,65552,66743,74798,73745,1297,74815,77082,8205,65831,257,74799,1296,75326]

theorem envBound45417 : H12AffineFastState.Bounded env45417 := by
  intro p hp
  have h : env45417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45416_45417 : H12AffineEnvironment.transform 5 16 env45416 = env45417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env45416 == env45417) = true)

theorem identity45417 : scanCanonicalize (H12AffineFastState.compose env45417 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound45417 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env45418 : List Nat := [2,4,8,16,32,16,128,256,512,4,2048,0,8192,276,8216,65536,277,65665,73790,8217,1,396,16,65552,65715,73770,73745,277,73787,76062,8205,65831,257,73771,276,74298]

theorem envBound45418 : H12AffineFastState.Bounded env45418 := by
  intro p hp
  have h : env45418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45417_45418 : H12AffineEnvironment.transform 9 4 env45417 = env45418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env45417 == env45418) = true)

theorem identity45418 : scanCanonicalize (H12AffineFastState.compose env45418 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 8494) := by decide +kernel

theorem selectedBound45418 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env45419 : List Nat := [2,4,8,16,32,16,128,256,512,4,2048,0,8192,276,8216,8494,277,8623,272,8217,1,396,16,8510,8605,260,319,277,277,2096,8205,8201,257,261,276,788]

theorem envBound45419 : H12AffineFastState.Bounded env45419 := by
  intro p hp
  have h : env45419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45418_45419 : H12AffineEnvironment.transform 15 8494 env45418 = env45419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8494 env45418 == env45419) = true)

theorem identity45419 : scanCanonicalize (H12AffineFastState.compose env45419 (packedSelected [0,2,3,7,8,11] rootPS)) = affineNative (2^(12+1) ^^^ 807) := by decide +kernel

theorem selectedBound45419 : packedSelected [0,2,3,7,8,11] rootPS < 2^1333 := by decide +kernel

def env45420 : List Nat := [2,4,8,16,32,16,128,256,512,4,2048,0,807,276,831,521,277,648,272,830,1,396,16,537,698,260,319,277,277,2096,810,814,257,261,276,788]

theorem envBound45420 : H12AffineFastState.Bounded env45420 := by
  intro p hp
  have h : env45420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45419_45420 : H12AffineEnvironment.transform 12 807 env45419 = env45420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 807 env45419 == env45420) = true)

theorem identity45420 : scanCanonicalize (H12AffineFastState.compose env45420 (packedSelected [1,2,3,13] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound45420 : packedSelected [1,2,3,13] rootPS < 2^1333 := by decide +kernel

def env45421 : List Nat := [2,4,8,16,32,16,128,15,512,4,2048,0,552,27,560,521,26,648,31,561,1,131,16,537,698,11,48,26,26,2096,549,545,14,10,27,539]

theorem envBound45421 : H12AffineFastState.Bounded env45421 := by
  intro p hp
  have h : env45421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45420_45421 : H12AffineEnvironment.transform 7 15 env45420 = env45421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env45420 == env45421) = true)

theorem identity45421 : scanCanonicalize (H12AffineFastState.compose env45421 (packedSelected [0,2,3,7,8,18] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound45421 : packedSelected [0,2,3,7,8,18] rootPS < 2^1333 := by decide +kernel

def env45422 : List Nat := [2,4,8,16,32,16,128,15,137,4,2048,0,161,27,185,128,26,1,31,184,1,131,16,144,51,11,48,26,26,2096,172,168,14,10,27,146]

theorem envBound45422 : H12AffineFastState.Bounded env45422 := by
  intro p hp
  have h : env45422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45421_45422 : H12AffineEnvironment.transform 8 137 env45421 = env45422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env45421 == env45422) = true)

theorem identity45422 : scanCanonicalize (H12AffineFastState.compose env45422 (packedSelected [2,4,7] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound45422 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env45423 : List Nat := [2,4,8,16,32,16,19,15,26,4,2048,0,50,27,42,19,26,1,31,43,1,16,16,3,51,11,48,26,26,2096,63,59,14,10,27,1]

theorem envBound45423 : H12AffineFastState.Bounded env45423 := by
  intro p hp
  have h : env45423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45422_45423 : H12AffineEnvironment.transform 6 19 env45422 = env45423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env45422 == env45423) = true)

theorem identity45423 : scanCanonicalize (H12AffineFastState.compose env45423 (packedSelected [2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound45423 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env45424 : List Nat := [2,4,8,16,32,16,19,15,26,4,1,0,50,27,42,19,26,1,31,43,1,16,16,3,51,11,48,26,26,49,63,59,14,10,27,1]

theorem envBound45424 : H12AffineFastState.Bounded env45424 := by
  intro p hp
  have h : env45424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45423_45424 : H12AffineEnvironment.transform 10 1 env45423 = env45424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env45423 == env45424) = true)

theorem identity45424 : scanCanonicalize (H12AffineFastState.compose env45424 (packedSelected [1,8] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound45424 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env45425 : List Nat := [2,4,8,16,17,16,19,15,26,4,1,0,3,27,27,19,26,1,31,26,1,16,16,3,2,11,1,26,26,0,14,10,14,10,27,1]

theorem envBound45425 : H12AffineFastState.Bounded env45425 := by
  intro p hp
  have h : env45425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45424_45425 : H12AffineEnvironment.transform 4 17 env45424 = env45425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env45424 == env45425) = true)

theorem identity45425 : scanCanonicalize (H12AffineFastState.compose env45425 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound45425 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45426 : List Nat := [2,4,8,7,6,7,4,15,13,4,1,0,3,12,12,4,13,1,8,13,1,7,7,3,2,11,1,13,13,0,14,10,14,10,12,1]

theorem envBound45426 : H12AffineFastState.Bounded env45426 := by
  intro p hp
  have h : env45426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45425_45426 : H12AffineEnvironment.transform 3 7 env45425 = env45426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env45425 == env45426) = true)

theorem identity45426 : scanCanonicalize (H12AffineFastState.compose env45426 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound45426 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env45427 : List Nat := [2,4,4,7,6,7,4,3,1,4,1,0,3,0,0,4,1,1,4,1,1,7,7,3,2,7,1,1,1,0,2,6,2,6,0,1]

theorem envBound45427 : H12AffineFastState.Bounded env45427 := by
  intro p hp
  have h : env45427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45426_45427 : H12AffineEnvironment.transform 2 4 env45426 = env45427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env45426 == env45427) = true)

def env45428 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,0,8192,1296,9244,65536,1296,65665,73791,9245,1,397,16,65552,66742,74798,73745,1297,74815,77083,8205,65831,257,74799,1297,75327]

theorem envBound45428 : H12AffineFastState.Bounded env45428 := by
  intro p hp
  have h : env45428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45416_45428 : H12AffineEnvironment.transform 5 17 env45416 = env45428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env45416 == env45428) = true)

theorem identity45428 : scanCanonicalize (H12AffineFastState.compose env45428 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 8250) := by decide +kernel

theorem selectedBound45428 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env45429 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,0,8192,1296,9244,8250,1296,8379,5,9245,1,397,16,8234,9356,1044,43,1297,1029,3361,8205,8477,257,1045,1297,1541]

theorem envBound45429 : H12AffineFastState.Bounded env45429 := by
  intro p hp
  have h : env45429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45428_45429 : H12AffineEnvironment.transform 15 8250 env45428 = env45429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8250 env45428 == env45429) = true)

theorem identity45429 : scanCanonicalize (H12AffineFastState.compose env45429 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound45429 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env45430 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,8192,0,8460,8250,0,8379,5,8461,1,397,16,8234,8604,260,43,1,277,2097,8205,8477,257,261,1,789]

theorem envBound45430 : H12AffineFastState.Bounded env45430 := by
  intro p hp
  have h : env45430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45429_45430 : H12AffineEnvironment.transform 9 272 env45429 = env45430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env45429 == env45430) = true)

theorem identity45430 : scanCanonicalize (H12AffineFastState.compose env45430 (packedSelected [0,2,5,7,8,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 648) := by decide +kernel

theorem selectedBound45430 : packedSelected [0,2,5,7,8,17,18] rootPS < 2^1333 := by decide +kernel

def env45431 : List Nat := [2,4,8,16,32,17,128,256,512,272,648,0,8192,0,8460,8250,0,8379,5,8461,1,397,16,8234,8604,260,43,1,277,697,8205,8477,257,261,1,789]

theorem envBound45431 : H12AffineFastState.Bounded env45431 := by
  intro p hp
  have h : env45431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45430_45431 : H12AffineEnvironment.transform 10 648 env45430 = env45431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 648 env45430 == env45431) = true)

theorem identity45431 : scanCanonicalize (H12AffineFastState.compose env45431 (packedSelected [3,5,17] rootPS)) = affineNative (2^(12+1) ^^^ 698) := by decide +kernel

theorem selectedBound45431 : packedSelected [3,5,17] rootPS < 2^1333 := by decide +kernel

def env45432 : List Nat := [2,4,8,16,32,17,128,256,512,272,648,0,698,0,950,640,0,513,5,951,1,397,16,656,806,260,43,1,277,697,695,935,257,261,1,789]

theorem envBound45432 : H12AffineFastState.Bounded env45432 := by
  intro p hp
  have h : env45432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45431_45432 : H12AffineEnvironment.transform 12 698 env45431 = env45432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 698 env45431 == env45432) = true)

theorem identity45432 : scanCanonicalize (H12AffineFastState.compose env45432 (packedSelected [0,3,7,8,11] rootPS)) = affineNative (2^(7+1) ^^^ 134) := by decide +kernel

theorem selectedBound45432 : packedSelected [0,3,7,8,11] rootPS < 2^1333 := by decide +kernel

def env45433 : List Nat := [2,4,8,16,32,17,128,134,512,150,648,0,698,0,560,640,0,513,5,561,1,11,16,656,672,130,43,1,147,697,695,545,135,131,1,659]

theorem envBound45433 : H12AffineFastState.Bounded env45433 := by
  intro p hp
  have h : env45433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45432_45433 : H12AffineEnvironment.transform 7 134 env45432 = env45433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 134 env45432 == env45433) = true)

def env45434 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1344,262144,77935,32769,4097,46529,16,266384,70886,78895,77841,1297,74815,81227,365713,308667,257,74799,1344,79471]

theorem envBound45434 : H12AffineFastState.Bounded env45434 := by
  intro p hp
  have h : env45434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45392_45434 : H12AffineEnvironment.transform 13 1297 env45392 = env45434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env45392 == env45434) = true)

theorem identity45434 : scanCanonicalize (H12AffineFastState.compose env45434 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32882) := by decide +kernel

theorem selectedBound45434 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env45435 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,32882,1344,262144,45085,32769,4097,46529,16,266384,38036,46173,45155,1297,42061,48441,267491,308667,257,42077,1344,46621]

theorem envBound45435 : H12AffineFastState.Bounded env45435 := by
  intro p hp
  have h : env45435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45434_45435 : H12AffineEnvironment.transform 15 32882 env45434 = env45435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32882 env45434 == env45435) = true)

def env45436 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32882,1344,262144,42333,32769,1345,41089,16,263632,33236,41245,42275,1297,42061,43129,262563,303355,257,42077,1344,41821]

theorem envBound45436 : H12AffineFastState.Bounded env45436 := by
  intro p hp
  have h : env45436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45435_45436 : H12AffineEnvironment.transform 11 1344 env45435 = env45436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env45435 == env45436) = true)

theorem identity45436 : scanCanonicalize (H12AffineFastState.compose env45436 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 73) := by decide +kernel

theorem selectedBound45436 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env45437 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,73,1297,32768,32882,1344,262144,34068,32769,1345,32968,16,263632,33236,33108,34154,1297,33796,34864,262563,295090,257,33812,1344,33556]

theorem envBound45437 : H12AffineFastState.Bounded env45437 := by
  intro p hp
  have h : env45437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45436_45437 : H12AffineEnvironment.transform 12 73 env45436 = env45437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env45436 == env45437) = true)

theorem identity45437 : scanCanonicalize (H12AffineFastState.compose env45437 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound45437 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env45438 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,1344,73,1297,32768,32882,1344,262144,34068,32769,1345,32968,16,263632,33236,33108,34154,1297,33796,34864,262563,295090,257,33812,1344,33180]

theorem envBound45438 : H12AffineFastState.Bounded env45438 := by
  intro p hp
  have h : env45438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45437_45438 : H12AffineEnvironment.transform 8 136 env45437 = env45438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env45437 == env45438) = true)

def env45439 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32882,1344,262144,42332,32769,1344,41088,16,263633,33237,41244,42274,1297,42061,43128,262562,303354,257,42077,1344,41820]

theorem envBound45439 : H12AffineFastState.Bounded env45439 := by
  intro p hp
  have h : env45439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45435_45439 : H12AffineEnvironment.transform 11 1345 env45435 = env45439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env45435 == env45439) = true)

theorem identity45439 : scanCanonicalize (H12AffineFastState.compose env45439 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 41146) := by decide +kernel

theorem selectedBound45439 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env45440 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32882,1344,41146,42332,32769,1344,41088,16,42347,33237,41244,42274,1297,42061,43128,41240,64,257,42077,1344,41820]

theorem envBound45440 : H12AffineFastState.Bounded env45440 := by
  intro p hp
  have h : env45440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45439_45440 : H12AffineEnvironment.transform 17 41146 env45439 = env45440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 41146 env45439 == env45440) = true)

theorem identity45440 : scanCanonicalize (H12AffineFastState.compose env45440 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound45440 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env45441 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,8540,8494,1344,486,1024,8541,1344,476,16,1079,8329,64,1150,1297,1297,2340,68,64,257,1281,1344,512]

theorem envBound45441 : H12AffineFastState.Bounded env45441 := by
  intro p hp
  have h : env45441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45440_45441 : H12AffineEnvironment.transform 14 8540 env45440 = env45441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env45440 == env45441) = true)

theorem identity45441 : scanCanonicalize (H12AffineFastState.compose env45441 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 85) := by decide +kernel

theorem selectedBound45441 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env45442 : List Nat := [2,4,8,16,32,64,128,256,512,85,2048,276,8192,324,8540,8494,277,486,85,8541,277,476,16,98,8329,64,43,324,324,2340,68,64,257,340,277,512]

theorem envBound45442 : H12AffineFastState.Bounded env45442 := by
  intro p hp
  have h : env45442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45441_45442 : H12AffineEnvironment.transform 9 85 env45441 = env45442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env45441 == env45442) = true)

theorem identity45442 : scanCanonicalize (H12AffineFastState.compose env45442 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 901) := by decide +kernel

theorem selectedBound45442 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env45443 : List Nat := [2,4,8,16,32,64,128,256,512,85,2048,276,901,324,729,683,277,486,85,728,277,476,16,98,780,64,43,324,324,2340,68,64,257,340,277,512]

theorem envBound45443 : H12AffineFastState.Bounded env45443 := by
  intro p hp
  have h : env45443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45442_45443 : H12AffineEnvironment.transform 12 901 env45442 = env45443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 901 env45442 == env45443) = true)

theorem identity45443 : scanCanonicalize (H12AffineFastState.compose env45443 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound45443 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env45444 : List Nat := [2,4,8,16,32,17,128,256,512,4,2048,276,901,277,648,683,277,439,4,649,277,397,16,51,780,17,43,277,277,2340,21,17,257,261,277,512]

theorem envBound45444 : H12AffineFastState.Bounded env45444 := by
  intro p hp
  have h : env45444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45443_45444 : H12AffineEnvironment.transform 5 17 env45443 = env45444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env45443 == env45444) = true)

theorem identity45444 : scanCanonicalize (H12AffineFastState.compose env45444 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 318) := by decide +kernel

theorem selectedBound45444 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env45445 : List Nat := [2,4,8,16,32,17,128,256,512,4,318,276,901,277,648,683,277,439,4,649,277,397,16,51,780,17,43,277,277,26,21,17,257,261,277,512]

theorem envBound45445 : H12AffineFastState.Bounded env45445 := by
  intro p hp
  have h : env45445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45444_45445 : H12AffineEnvironment.transform 10 318 env45444 = env45445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 318 env45444 == env45445) = true)

theorem identity45445 : scanCanonicalize (H12AffineFastState.compose env45445 (packedSelected [1,4,5,9,11] rootPS)) = affineNative (2^(8+1) ^^^ 277) := by decide +kernel

theorem selectedBound45445 : packedSelected [1,4,5,9,11] rootPS < 2^1333 := by decide +kernel

def env45446 : List Nat := [2,4,8,16,32,17,128,256,277,4,318,276,144,277,413,446,277,439,4,412,277,397,16,51,25,17,43,277,277,26,21,17,257,261,277,277]

theorem envBound45446 : H12AffineFastState.Bounded env45446 := by
  intro p hp
  have h : env45446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45445_45446 : H12AffineEnvironment.transform 8 277 env45445 = env45446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env45445 == env45446) = true)

theorem identity45446 : scanCanonicalize (H12AffineFastState.compose env45446 (packedSelected [0,3,4,5,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound45446 : packedSelected [0,3,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env45447 : List Nat := [2,4,8,16,32,17,57,256,277,4,318,276,41,277,292,263,277,270,4,293,277,308,16,51,25,17,43,277,277,26,21,17,257,261,277,277]

theorem envBound45447 : H12AffineFastState.Bounded env45447 := by
  intro p hp
  have h : env45447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45446_45447 : H12AffineEnvironment.transform 6 57 env45446 = env45447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env45446 == env45447) = true)

theorem identity45447 : scanCanonicalize (H12AffineFastState.compose env45447 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound45447 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45448 : List Nat := [2,4,8,16,32,17,57,15,26,4,49,27,41,26,43,8,26,1,4,42,26,59,16,51,25,17,43,26,26,26,21,17,14,10,26,26]

theorem envBound45448 : H12AffineFastState.Bounded env45448 := by
  intro p hp
  have h : env45448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45447_45448 : H12AffineEnvironment.transform 7 15 env45447 = env45448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env45447 == env45448) = true)

theorem identity45448 : scanCanonicalize (H12AffineFastState.compose env45448 (packedSelected [3,4] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound45448 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env45449 : List Nat := [2,4,8,16,10,17,19,15,26,4,27,27,3,26,1,8,26,1,4,0,26,17,16,25,25,17,1,26,26,26,21,17,14,10,26,26]

theorem envBound45449 : H12AffineFastState.Bounded env45449 := by
  intro p hp
  have h : env45449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45448_45449 : H12AffineEnvironment.transform 4 10 env45448 = env45449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env45448 == env45449) = true)

def env45450 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,2154705,8388608,16777216,33554432,8914001,134217728,268435456,302133384,2189403,50962569,4294967296,34088328,4347445490,34359738368,33563273]

theorem envBound45450 : H12AffineFastState.Bounded env45450 := by
  intro p hp
  have h : env45450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26408_45450 : H12AffineEnvironment.transform 25 8914001 env26408 = env45450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 8914001 env26408 == env45450) = true)

def env45451 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,2154705,8388608,16777216,33554432,8914001,134217728,8389888,42087816,2189403,50962569,4294967296,34088328,4347445490,34359738368,33563273]

theorem envBound45451 : H12AffineFastState.Bounded env45451 := by
  intro p hp
  have h : env45451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45450_45451 : H12AffineEnvironment.transform 27 8389888 env45450 = env45451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 8389888 env45450 == env45451) = true)

def env45452 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,2154705,147520,16777216,33554432,672785,134217728,148800,33584584,2189403,50962569,4294967296,34088328,4347445490,34359738368,33563273]

theorem envBound45452 : H12AffineFastState.Bounded env45452 := by
  intro p hp
  have h : env45452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45451_45452 : H12AffineEnvironment.transform 22 147520 env45451 = env45452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147520 env45451 == env45452) = true)

def env45453 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,2154705,147520,16777216,33554432,672785,134217728,148800,33584584,2189403,50962569,4294967296,34088328,4347445490,151462016,33563273]

theorem envBound45453 : H12AffineFastState.Bounded env45453 := by
  intro p hp
  have h : env45453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45452_45453 : H12AffineEnvironment.transform 34 151462016 env45452 = env45453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 151462016 env45452 == env45453) = true)

def env45454 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,16777216,33554432,672785,134217728,148800,33584584,96347,50962569,4294967296,34088328,4345352434,151462016,33563273]

theorem envBound45454 : H12AffineFastState.Bounded env45454 := by
  intro p hp
  have h : env45454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45453_45454 : H12AffineEnvironment.transform 20 4096 env45453 = env45454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env45453 == env45454) = true)

theorem identity45454 : scanCanonicalize (H12AffineFastState.compose env45454 (packedSelected [14] rootPS)) = affineNative (2^(31+1) ^^^ 33771959) := by decide +kernel

theorem selectedBound45454 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env45455 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,16777216,33554432,672785,134217728,148800,33584584,96347,50962569,33771959,34088328,17006917,151462016,33563273]

theorem envBound45455 : H12AffineFastState.Bounded env45455 := by
  intro p hp
  have h : env45455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45454_45455 : H12AffineEnvironment.transform 31 33771959 env45454 = env45455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 33771959 env45454 == env45455) = true)

def env45456 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,16777216,533640,672785,134217728,148800,545088,96347,16876545,750911,256,17006917,151462016,525825]

theorem envBound45456 : H12AffineFastState.Bounded env45456 := by
  intro p hp
  have h : env45456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45455_45456 : H12AffineEnvironment.transform 24 533640 env45455 = env45456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 533640 env45455 == env45456) = true)

def env45457 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,16777216,533640,672785,17245632,148800,545088,96347,16876545,750911,256,17006917,1344,525825]

theorem envBound45457 : H12AffineFastState.Bounded env45457 := by
  intro p hp
  have h : env45457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45456_45457 : H12AffineEnvironment.transform 26 17245632 env45456 = env45457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245632 env45456 == env45457) = true)

theorem identity45457 : scanCanonicalize (H12AffineFastState.compose env45457 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(18+1) ^^^ 95615) := by decide +kernel

theorem selectedBound45457 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env45458 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95615,32769,4096,61649,147520,16777216,86519,209262,17245632,148800,74815,96347,16876545,131136,256,17006917,1344,95102]

theorem envBound45458 : H12AffineFastState.Bounded env45458 := by
  intro p hp
  have h : env45458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45457_45458 : H12AffineEnvironment.transform 18 95615 env45457 = env45458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 95615 env45457 == env45458) = true)

def env45459 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95615,32769,4096,61649,147520,284032,86519,209262,225344,148800,74815,96347,381313,131136,256,513221,1344,95102]

theorem envBound45459 : H12AffineFastState.Bounded env45459 := by
  intro p hp
  have h : env45459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45458_45459 : H12AffineEnvironment.transform 23 284032 env45458 = env45459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 284032 env45458 == env45459) = true)

def env45460 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,75056,262144,95615,32769,4096,61649,91504,284032,86519,5214,21872,90224,74815,96347,381313,75120,256,324085,1344,95102]

theorem envBound45460 : H12AffineFastState.Bounded env45460 := by
  intro p hp
  have h : env45460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45459_45460 : H12AffineEnvironment.transform 16 75056 env45459 = env45460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 75056 env45459 == env45460) = true)

def env45461 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,28704,21776,262144,1375,32769,4096,61649,5456,284032,8663,5214,21872,4176,21535,2171,303521,21840,256,324085,1344,862]

theorem envBound45461 : H12AffineFastState.Bounded env45461 := by
  intro p hp
  have h : env45461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45460_45461 : H12AffineEnvironment.transform 15 28704 env45460 = env45461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28704 env45460 == env45461) = true)

theorem identity45461 : scanCanonicalize (H12AffineFastState.compose env45461 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 94) := by decide +kernel

theorem selectedBound45461 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env45462 : List Nat := [2,4,8,16,32,64,128,94,512,1024,2048,4096,8192,16384,32768,28704,21582,262144,1025,32769,4096,61649,5134,283870,8329,5214,21550,4176,21535,2171,303359,21518,94,323755,1054,512]

theorem envBound45462 : H12AffineFastState.Bounded env45462 := by
  intro p hp
  have h : env45462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45461_45462 : H12AffineEnvironment.transform 7 94 env45461 = env45462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 94 env45461 == env45462) = true)

theorem identity45462 : scanCanonicalize (H12AffineFastState.compose env45462 (packedSelected [4,9,16] rootPS)) = affineNative (2^(17+1) ^^^ 5356) := by decide +kernel

theorem selectedBound45462 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env45463 : List Nat := [2,4,8,16,32,64,128,94,512,1024,2048,4096,8192,16384,32768,28704,21582,5356,1025,32769,4096,61649,5134,16434,8329,5214,21550,4176,21535,2171,46099,21518,94,58439,1054,512]

theorem envBound45463 : H12AffineFastState.Bounded env45463 := by
  intro p hp
  have h : env45463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45462_45463 : H12AffineEnvironment.transform 17 5356 env45462 = env45463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 5356 env45462 == env45463) = true)

theorem identity45463 : scanCanonicalize (H12AffineFastState.compose env45463 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 25676) := by decide +kernel

theorem selectedBound45463 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env45464 : List Nat := [2,4,8,16,32,64,128,94,512,1024,2048,4096,8192,16384,25676,28704,21582,5356,1025,25677,4096,5277,5134,16434,8329,5214,21550,4176,21535,2171,20575,21518,94,11,1054,512]

theorem envBound45464 : H12AffineFastState.Bounded env45464 := by
  intro p hp
  have h : env45464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45463_45464 : H12AffineEnvironment.transform 14 25676 env45463 = env45464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25676 env45463 == env45464) = true)

theorem identity45464 : scanCanonicalize (H12AffineFastState.compose env45464 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound45464 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env45465 : List Nat := [2,4,8,16,32,17,128,15,512,1024,2048,4096,8192,16384,25629,28704,21535,5309,1025,25628,4096,5277,5134,16434,8329,5135,21550,4097,21535,2090,20494,21518,15,11,1054,512]

theorem envBound45465 : H12AffineFastState.Bounded env45465 := by
  intro p hp
  have h : env45465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45464_45465 : H12AffineEnvironment.transform 5 17 env45464 = env45465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env45464 == env45465) = true)

theorem identity45465 : scanCanonicalize (H12AffineFastState.compose env45465 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound45465 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env45466 : List Nat := [2,4,8,16,32,17,128,15,512,4,2048,4096,8192,16384,24601,28704,20507,4281,5,24600,4096,4249,4106,16434,8329,4107,20522,4097,20507,2090,20494,20490,15,11,26,512]

theorem envBound45466 : H12AffineFastState.Bounded env45466 := by
  intro p hp
  have h : env45466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45465_45466 : H12AffineEnvironment.transform 9 4 env45465 = env45466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env45465 == env45466) = true)

theorem identity45466 : scanCanonicalize (H12AffineFastState.compose env45466 (packedSelected [6] rootPS)) = affineNative (2^(13+1) ^^^ 1) := by decide +kernel

theorem selectedBound45466 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env45467 : List Nat := [2,4,8,16,32,17,128,15,512,4,2048,4096,8192,1,8216,12321,4122,4281,5,8217,4096,4249,4106,51,8329,4107,4139,4097,4122,2090,4111,4107,15,11,26,512]

theorem envBound45467 : H12AffineFastState.Bounded env45467 := by
  intro p hp
  have h : env45467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45466_45467 : H12AffineEnvironment.transform 13 1 env45466 = env45467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1 env45466 == env45467) = true)

theorem identity45467 : scanCanonicalize (H12AffineFastState.compose env45467 (packedSelected [1,3,5,8,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 697) := by decide +kernel

theorem selectedBound45467 : packedSelected [1,3,5,8,10,12] rootPS < 2^1333 := by decide +kernel

def env45468 : List Nat := [2,4,8,16,32,17,128,15,512,4,2048,697,8192,1,8216,8856,675,512,5,8217,697,544,691,51,8329,690,658,696,675,2090,694,690,15,11,26,512]

theorem envBound45468 : H12AffineFastState.Bounded env45468 := by
  intro p hp
  have h : env45468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45467_45468 : H12AffineEnvironment.transform 11 697 env45467 = env45468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 697 env45467 == env45468) = true)

theorem identity45468 : scanCanonicalize (H12AffineFastState.compose env45468 (packedSelected [10,15] rootPS)) = affineNative (2^(10+1) ^^^ 674) := by decide +kernel

theorem selectedBound45468 : packedSelected [10,15] rootPS < 2^1333 := by decide +kernel

def env45469 : List Nat := [2,4,8,16,32,17,128,15,512,4,674,697,8192,1,8216,8856,675,512,5,8217,697,544,691,51,8329,690,658,696,675,648,694,690,15,11,26,512]

theorem envBound45469 : H12AffineFastState.Bounded env45469 := by
  intro p hp
  have h : env45469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45468_45469 : H12AffineEnvironment.transform 10 674 env45468 = env45469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 674 env45468 == env45469) = true)

theorem identity45469 : scanCanonicalize (H12AffineFastState.compose env45469 (packedSelected [4,5,8,11] rootPS)) = affineNative (2^(8+1) ^^^ 61) := by decide +kernel

theorem selectedBound45469 : packedSelected [4,5,8,11] rootPS < 2^1333 := by decide +kernel

def env45470 : List Nat := [2,4,8,16,32,17,128,15,61,4,159,132,8192,1,8216,8357,158,61,5,8217,132,29,142,51,8329,143,175,133,158,181,139,143,15,11,26,61]

theorem envBound45470 : H12AffineFastState.Bounded env45470 := by
  intro p hp
  have h : env45470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45469_45470 : H12AffineEnvironment.transform 8 61 env45469 = env45470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 61 env45469 == env45470) = true)

theorem identity45470 : scanCanonicalize (H12AffineFastState.compose env45470 (packedSelected [1,2,4,5,7,13] rootPS)) = affineNative (2^(12+1) ^^^ 2) := by decide +kernel

theorem selectedBound45470 : packedSelected [1,2,4,5,7,13] rootPS < 2^1333 := by decide +kernel

def env45471 : List Nat := [2,4,8,16,32,17,128,15,61,4,159,132,2,1,26,167,158,61,5,27,132,29,142,51,139,143,175,133,158,181,139,143,15,11,26,61]

theorem envBound45471 : H12AffineFastState.Bounded env45471 := by
  intro p hp
  have h : env45471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45470_45471 : H12AffineEnvironment.transform 12 2 env45470 = env45471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2 env45470 == env45471) = true)

theorem identity45471 : scanCanonicalize (H12AffineFastState.compose env45471 (packedSelected [2,5] rootPS)) = affineNative (2^(4+1) ^^^ 29) := by decide +kernel

theorem selectedBound45471 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env45472 : List Nat := [2,4,8,16,29,17,128,15,0,4,159,132,2,1,26,154,158,0,5,27,132,29,142,14,139,143,146,133,158,136,139,143,15,11,26,0]

theorem envBound45472 : H12AffineFastState.Bounded env45472 := by
  intro p hp
  have h : env45472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45471_45472 : H12AffineEnvironment.transform 4 29 env45471 = env45472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 29 env45471 == env45472) = true)

theorem identity45472 : scanCanonicalize (H12AffineFastState.compose env45472 (packedSelected [1,2,4] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound45472 : packedSelected [1,2,4] rootPS < 2^1333 := by decide +kernel

def env45473 : List Nat := [2,4,8,11,6,10,128,15,0,4,132,132,2,1,1,129,133,0,5,0,132,6,142,14,139,143,137,133,133,136,139,143,15,11,1,0]

theorem envBound45473 : H12AffineFastState.Bounded env45473 := by
  intro p hp
  have h : env45473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45472_45473 : H12AffineEnvironment.transform 3 11 env45472 = env45473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env45472 == env45473) = true)

theorem identity45473 : scanCanonicalize (H12AffineFastState.compose env45473 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound45473 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45474 : List Nat := [2,4,8,11,6,10,9,15,0,4,13,13,2,1,1,8,12,0,5,0,13,6,7,14,2,6,0,12,12,1,2,6,15,11,1,0]

theorem envBound45474 : H12AffineFastState.Bounded env45474 := by
  intro p hp
  have h : env45474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45473_45474 : H12AffineEnvironment.transform 6 9 env45473 = env45474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env45473 == env45474) = true)

theorem identity45474 : scanCanonicalize (H12AffineFastState.compose env45474 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound45474 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45475 : List Nat := [2,4,5,6,6,7,4,2,0,4,0,0,2,1,1,5,1,0,5,0,0,6,7,3,2,6,0,1,1,1,2,6,2,6,1,0]

theorem envBound45475 : H12AffineFastState.Bounded env45475 := by
  intro p hp
  have h : env45475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45474_45475 : H12AffineEnvironment.transform 2 5 env45474 = env45475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env45474 == env45475) = true)

def env45476 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,28705,21777,262144,1374,32769,4096,61649,5457,284032,8662,5214,21872,4177,21534,2170,303520,21841,256,324085,1344,863]

theorem envBound45476 : H12AffineFastState.Bounded env45476 := by
  intro p hp
  have h : env45476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45460_45476 : H12AffineEnvironment.transform 15 28705 env45460 = env45476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28705 env45460 == env45476) = true)

def env45477 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,75057,262144,95615,32769,4096,61649,91505,284032,86519,5215,21873,90225,74815,96347,381313,75121,256,324084,1344,95102]

theorem envBound45477 : H12AffineFastState.Bounded env45477 := by
  intro p hp
  have h : env45477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45459_45477 : H12AffineEnvironment.transform 16 75057 env45459 = env45477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 75057 env45459 == env45477) = true)

def env45478 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,28704,21777,262144,1375,32769,4096,61649,5457,284032,8663,5215,21873,4177,21535,2171,303521,21841,256,324084,1344,862]

theorem envBound45478 : H12AffineFastState.Bounded env45478 := by
  intro p hp
  have h : env45478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45477_45478 : H12AffineEnvironment.transform 15 28704 env45477 = env45478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28704 env45477 == env45478) = true)

def env45479 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,28705,21776,262144,1374,32769,4096,61649,5456,284032,8662,5215,21873,4176,21534,2170,303520,21840,256,324084,1344,863]

theorem envBound45479 : H12AffineFastState.Bounded env45479 := by
  intro p hp
  have h : env45479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45477_45479 : H12AffineEnvironment.transform 15 28705 env45477 = env45479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28705 env45477 == env45479) = true)

theorem identity45479 : scanCanonicalize (H12AffineFastState.compose env45479 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 95) := by decide +kernel

theorem selectedBound45479 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env45480 : List Nat := [2,4,8,16,32,64,128,95,512,1024,2048,4096,8192,16384,32768,28705,21583,262144,1025,32769,4096,61649,5135,283871,8329,5215,21550,4176,21534,2170,303359,21519,95,323755,1055,512]

theorem envBound45480 : H12AffineFastState.Bounded env45480 := by
  intro p hp
  have h : env45480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45479_45480 : H12AffineEnvironment.transform 7 95 env45479 = env45480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 95 env45479 == env45480) = true)

theorem identity45480 : scanCanonicalize (H12AffineFastState.compose env45480 (packedSelected [4,9,16] rootPS)) = affineNative (2^(17+1) ^^^ 5357) := by decide +kernel

theorem selectedBound45480 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env45481 : List Nat := [2,4,8,16,32,64,128,95,512,1024,2048,4096,8192,16384,32768,28705,21583,5357,1025,32769,4096,61649,5135,16434,8329,5215,21550,4176,21534,2170,46098,21519,95,58438,1055,512]

theorem envBound45481 : H12AffineFastState.Bounded env45481 := by
  intro p hp
  have h : env45481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45480_45481 : H12AffineEnvironment.transform 17 5357 env45480 = env45481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 5357 env45480 == env45481) = true)

theorem identity45481 : scanCanonicalize (H12AffineFastState.compose env45481 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 25676) := by decide +kernel

theorem selectedBound45481 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env45482 : List Nat := [2,4,8,16,32,64,128,95,512,1024,2048,4096,8192,16384,25676,28705,21583,5357,1025,25677,4096,5277,5135,16434,8329,5215,21550,4176,21534,2170,20574,21519,95,10,1055,512]

theorem envBound45482 : H12AffineFastState.Bounded env45482 := by
  intro p hp
  have h : env45482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45481_45482 : H12AffineEnvironment.transform 14 25676 env45481 = env45482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25676 env45481 == env45482) = true)

theorem identity45482 : scanCanonicalize (H12AffineFastState.compose env45482 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound45482 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env45483 : List Nat := [2,4,8,16,32,17,128,14,512,1024,2048,4096,8192,16384,25629,28705,21534,5308,1025,25628,4096,5277,5135,16434,8329,5134,21550,4097,21534,2091,20495,21519,14,10,1055,512]

theorem envBound45483 : H12AffineFastState.Bounded env45483 := by
  intro p hp
  have h : env45483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45482_45483 : H12AffineEnvironment.transform 5 17 env45482 = env45483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env45482 == env45483) = true)

theorem identity45483 : scanCanonicalize (H12AffineFastState.compose env45483 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound45483 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env45484 : List Nat := [2,4,8,16,32,17,128,14,512,4,2048,4096,8192,16384,24601,28705,20506,4280,5,24600,4096,4249,4107,16434,8329,4106,20522,4097,20506,2091,20495,20491,14,10,27,512]

theorem envBound45484 : H12AffineFastState.Bounded env45484 := by
  intro p hp
  have h : env45484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45483_45484 : H12AffineEnvironment.transform 9 4 env45483 = env45484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env45483 == env45484) = true)

theorem identity45484 : scanCanonicalize (H12AffineFastState.compose env45484 (packedSelected [6] rootPS)) = affineNative (2^(13+1) ^^^ 1) := by decide +kernel

theorem selectedBound45484 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env45485 : List Nat := [2,4,8,16,32,17,128,14,512,4,2048,4096,8192,1,8216,12320,4123,4280,5,8217,4096,4249,4107,51,8329,4106,4139,4097,4123,2091,4110,4106,14,10,27,512]

theorem envBound45485 : H12AffineFastState.Bounded env45485 := by
  intro p hp
  have h : env45485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45484_45485 : H12AffineEnvironment.transform 13 1 env45484 = env45485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1 env45484 == env45485) = true)

theorem identity45485 : scanCanonicalize (H12AffineFastState.compose env45485 (packedSelected [1,3,5,8,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 696) := by decide +kernel

theorem selectedBound45485 : packedSelected [1,3,5,8,10,12] rootPS < 2^1333 := by decide +kernel

def env45486 : List Nat := [2,4,8,16,32,17,128,14,512,4,2048,696,8192,1,8216,8856,675,512,5,8217,696,545,691,51,8329,690,659,697,675,2091,694,690,14,10,27,512]

theorem envBound45486 : H12AffineFastState.Bounded env45486 := by
  intro p hp
  have h : env45486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45485_45486 : H12AffineEnvironment.transform 11 696 env45485 = env45486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 696 env45485 == env45486) = true)

theorem identity45486 : scanCanonicalize (H12AffineFastState.compose env45486 (packedSelected [10,15] rootPS)) = affineNative (2^(10+1) ^^^ 675) := by decide +kernel

theorem selectedBound45486 : packedSelected [10,15] rootPS < 2^1333 := by decide +kernel

def env45487 : List Nat := [2,4,8,16,32,17,128,14,512,4,675,696,8192,1,8216,8856,675,512,5,8217,696,545,691,51,8329,690,659,697,675,648,694,690,14,10,27,512]

theorem envBound45487 : H12AffineFastState.Bounded env45487 := by
  intro p hp
  have h : env45487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45486_45487 : H12AffineEnvironment.transform 10 675 env45486 = env45487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 675 env45486 == env45487) = true)

theorem identity45487 : scanCanonicalize (H12AffineFastState.compose env45487 (packedSelected [4,5,8,11] rootPS)) = affineNative (2^(8+1) ^^^ 38) := by decide +kernel

theorem selectedBound45487 : packedSelected [4,5,8,11] rootPS < 2^1333 := by decide +kernel

def env45488 : List Nat := [2,4,8,16,32,17,128,14,38,4,133,158,8192,1,8216,8382,133,38,5,8217,158,7,149,51,8329,148,181,159,133,174,144,148,14,10,27,38]

theorem envBound45488 : H12AffineFastState.Bounded env45488 := by
  intro p hp
  have h : env45488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45487_45488 : H12AffineEnvironment.transform 8 38 env45487 = env45488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 38 env45487 == env45488) = true)

theorem identity45488 : scanCanonicalize (H12AffineFastState.compose env45488 (packedSelected [1,2,4,5,7,13] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound45488 : packedSelected [1,2,4,5,7,13] rootPS < 2^1333 := by decide +kernel

def env45489 : List Nat := [2,4,8,16,32,17,128,14,38,4,133,158,41,1,49,151,133,38,5,48,158,7,149,51,160,148,181,159,133,174,144,148,14,10,27,38]

theorem envBound45489 : H12AffineFastState.Bounded env45489 := by
  intro p hp
  have h : env45489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45488_45489 : H12AffineEnvironment.transform 12 41 env45488 = env45489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env45488 == env45489) = true)

theorem identity45489 : scanCanonicalize (H12AffineFastState.compose env45489 (packedSelected [1,2,4,5,8] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound45489 : packedSelected [1,2,4,5,8] rootPS < 2^1333 := by decide +kernel

def env45490 : List Nat := [2,4,8,16,11,17,128,14,13,4,133,158,2,1,26,151,133,13,5,27,158,7,149,24,139,148,158,159,133,133,144,148,14,10,27,13]

theorem envBound45490 : H12AffineFastState.Bounded env45490 := by
  intro p hp
  have h : env45490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45489_45490 : H12AffineEnvironment.transform 4 11 env45489 = env45490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env45489 == env45490) = true)

theorem identity45490 : scanCanonicalize (H12AffineFastState.compose env45490 (packedSelected [2,3] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound45490 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env45491 : List Nat := [2,4,8,6,11,7,128,14,13,4,133,136,2,1,12,129,133,13,5,13,136,7,131,14,139,130,136,137,133,133,134,130,14,10,13,13]

theorem envBound45491 : H12AffineFastState.Bounded env45491 := by
  intro p hp
  have h : env45491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45490_45491 : H12AffineEnvironment.transform 3 6 env45490 = env45491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env45490 == env45491) = true)

def env45492 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95615,32769,4096,61649,147520,284033,86519,209262,225345,148800,74815,96347,381312,131136,256,513220,1344,95102]

theorem envBound45492 : H12AffineFastState.Bounded env45492 := by
  intro p hp
  have h : env45492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45458_45492 : H12AffineEnvironment.transform 23 284033 env45458 = env45492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 284033 env45458 == env45492) = true)

def env45493 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,75056,262144,95615,32769,4096,61649,91504,284033,86519,5214,21873,90224,74815,96347,381312,75120,256,324084,1344,95102]

theorem envBound45493 : H12AffineFastState.Bounded env45493 := by
  intro p hp
  have h : env45493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45492_45493 : H12AffineEnvironment.transform 16 75056 env45492 = env45493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 75056 env45492 == env45493) = true)

def env45494 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,28704,21776,262144,1375,32769,4096,61649,5456,284033,8663,5214,21873,4176,21535,2171,303520,21840,256,324084,1344,862]

theorem envBound45494 : H12AffineFastState.Bounded env45494 := by
  intro p hp
  have h : env45494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45493_45494 : H12AffineEnvironment.transform 15 28704 env45493 = env45494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28704 env45493 == env45494) = true)

theorem identity45494 : scanCanonicalize (H12AffineFastState.compose env45494 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 94) := by decide +kernel

theorem selectedBound45494 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env45495 : List Nat := [2,4,8,16,32,64,128,94,512,1024,2048,4096,8192,16384,32768,28704,21582,262144,1025,32769,4096,61649,5134,283871,8329,5214,21551,4176,21535,2171,303358,21518,94,323754,1054,512]

theorem envBound45495 : H12AffineFastState.Bounded env45495 := by
  intro p hp
  have h : env45495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45494_45495 : H12AffineEnvironment.transform 7 94 env45494 = env45495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 94 env45494 == env45495) = true)

theorem identity45495 : scanCanonicalize (H12AffineFastState.compose env45495 (packedSelected [4,9,16] rootPS)) = affineNative (2^(17+1) ^^^ 5357) := by decide +kernel

theorem selectedBound45495 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env45496 : List Nat := [2,4,8,16,32,64,128,94,512,1024,2048,4096,8192,16384,32768,28704,21582,5357,1025,32769,4096,61649,5134,16434,8329,5214,21551,4176,21535,2171,46099,21518,94,58439,1054,512]

theorem envBound45496 : H12AffineFastState.Bounded env45496 := by
  intro p hp
  have h : env45496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45495_45496 : H12AffineEnvironment.transform 17 5357 env45495 = env45496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 5357 env45495 == env45496) = true)

theorem identity45496 : scanCanonicalize (H12AffineFastState.compose env45496 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 25676) := by decide +kernel

theorem selectedBound45496 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env45497 : List Nat := [2,4,8,16,32,64,128,94,512,1024,2048,4096,8192,16384,25676,28704,21582,5357,1025,25677,4096,5277,5134,16434,8329,5214,21551,4176,21535,2171,20575,21518,94,11,1054,512]

theorem envBound45497 : H12AffineFastState.Bounded env45497 := by
  intro p hp
  have h : env45497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45496_45497 : H12AffineEnvironment.transform 14 25676 env45496 = env45497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25676 env45496 == env45497) = true)

theorem identity45497 : scanCanonicalize (H12AffineFastState.compose env45497 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound45497 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env45498 : List Nat := [2,4,8,16,32,17,128,15,512,1024,2048,4096,8192,16384,25629,28704,21535,5308,1025,25628,4096,5277,5134,16434,8329,5135,21551,4097,21535,2090,20494,21518,15,11,1054,512]

theorem envBound45498 : H12AffineFastState.Bounded env45498 := by
  intro p hp
  have h : env45498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45497_45498 : H12AffineEnvironment.transform 5 17 env45497 = env45498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env45497 == env45498) = true)

theorem identity45498 : scanCanonicalize (H12AffineFastState.compose env45498 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound45498 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env45499 : List Nat := [2,4,8,16,32,17,128,15,512,4,2048,4096,8192,16384,24601,28704,20507,4280,5,24600,4096,4249,4106,16434,8329,4107,20523,4097,20507,2090,20494,20490,15,11,26,512]

theorem envBound45499 : H12AffineFastState.Bounded env45499 := by
  intro p hp
  have h : env45499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45498_45499 : H12AffineEnvironment.transform 9 4 env45498 = env45499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env45498 == env45499) = true)

theorem identity45499 : scanCanonicalize (H12AffineFastState.compose env45499 (packedSelected [6] rootPS)) = affineNative (2^(13+1) ^^^ 0) := by decide +kernel

theorem selectedBound45499 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env45500 : List Nat := [2,4,8,16,32,17,128,15,512,4,2048,4096,8192,0,8217,12320,4123,4280,5,8216,4096,4249,4106,50,8329,4107,4139,4097,4123,2090,4110,4106,15,11,26,512]

theorem envBound45500 : H12AffineFastState.Bounded env45500 := by
  intro p hp
  have h : env45500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45499_45500 : H12AffineEnvironment.transform 13 0 env45499 = env45500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 0 env45499 == env45500) = true)

theorem identity45500 : scanCanonicalize (H12AffineFastState.compose env45500 (packedSelected [1,3,5,8,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 696) := by decide +kernel

theorem selectedBound45500 : packedSelected [1,3,5,8,10,12] rootPS < 2^1333 := by decide +kernel

def env45501 : List Nat := [2,4,8,16,32,17,128,15,512,4,2048,696,8192,0,8217,8856,675,512,5,8216,696,545,690,50,8329,691,659,697,675,2090,694,690,15,11,26,512]

theorem envBound45501 : H12AffineFastState.Bounded env45501 := by
  intro p hp
  have h : env45501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45500_45501 : H12AffineEnvironment.transform 11 696 env45500 = env45501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 696 env45500 == env45501) = true)

theorem identity45501 : scanCanonicalize (H12AffineFastState.compose env45501 (packedSelected [10,15] rootPS)) = affineNative (2^(10+1) ^^^ 674) := by decide +kernel

theorem selectedBound45501 : packedSelected [10,15] rootPS < 2^1333 := by decide +kernel

def env45502 : List Nat := [2,4,8,16,32,17,128,15,512,4,674,696,8192,0,8217,8856,675,512,5,8216,696,545,690,50,8329,691,659,697,675,648,694,690,15,11,26,512]

theorem envBound45502 : H12AffineFastState.Bounded env45502 := by
  intro p hp
  have h : env45502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45501_45502 : H12AffineEnvironment.transform 10 674 env45501 = env45502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 674 env45501 == env45502) = true)

theorem identity45502 : scanCanonicalize (H12AffineFastState.compose env45502 (packedSelected [4,5,8,11] rootPS)) = affineNative (2^(6+1) ^^^ 31) := by decide +kernel

theorem selectedBound45502 : packedSelected [4,5,8,11] rootPS < 2^1333 := by decide +kernel

def env45503 : List Nat := [2,4,8,16,32,17,31,15,512,4,573,551,8192,0,8217,8711,572,512,5,8216,551,545,557,50,8214,556,524,550,572,535,553,557,15,11,26,512]

theorem envBound45503 : H12AffineFastState.Bounded env45503 := by
  intro p hp
  have h : env45503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45502_45503 : H12AffineEnvironment.transform 6 31 env45502 = env45503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 31 env45502 == env45503) = true)

theorem identity45503 : scanCanonicalize (H12AffineFastState.compose env45503 (packedSelected [1,2,4,5,7,13] rootPS)) = affineNative (2^(12+1) ^^^ 36) := by decide +kernel

theorem selectedBound45503 : packedSelected [1,2,4,5,7,13] rootPS < 2^1333 := by decide +kernel

def env45504 : List Nat := [2,4,8,16,32,17,31,15,512,4,573,551,36,0,61,547,572,512,5,60,551,545,557,50,50,556,524,550,572,535,553,557,15,11,26,512]

theorem envBound45504 : H12AffineFastState.Bounded env45504 := by
  intro p hp
  have h : env45504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45503_45504 : H12AffineEnvironment.transform 12 36 env45503 = env45504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 36 env45503 == env45504) = true)

theorem identity45504 : scanCanonicalize (H12AffineFastState.compose env45504 (packedSelected [1,2,5] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound45504 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env45505 : List Nat := [2,4,8,16,32,17,31,15,1,4,60,38,36,0,61,34,61,1,5,60,38,32,44,50,50,45,13,39,61,22,40,44,15,11,26,1]

theorem envBound45505 : H12AffineFastState.Bounded env45505 := by
  intro p hp
  have h : env45505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45504_45505 : H12AffineEnvironment.transform 8 1 env45504 = env45505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env45504 == env45505) = true)

theorem identity45505 : scanCanonicalize (H12AffineFastState.compose env45505 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound45505 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45506 : List Nat := [2,4,8,16,6,17,31,15,1,4,26,0,2,0,27,4,27,1,5,26,0,6,10,20,20,11,13,1,27,22,14,10,15,11,26,1]

theorem envBound45506 : H12AffineFastState.Bounded env45506 := by
  intro p hp
  have h : env45506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45505_45506 : H12AffineEnvironment.transform 4 6 env45505 = env45506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env45505 == env45506) = true)

theorem identity45506 : scanCanonicalize (H12AffineFastState.compose env45506 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound45506 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45507 : List Nat := [2,4,4,16,6,17,19,3,1,4,22,0,2,0,23,4,23,1,5,22,0,6,6,20,20,7,1,1,23,22,2,6,3,7,22,1]

theorem envBound45507 : H12AffineFastState.Bounded env45507 := by
  intro p hp
  have h : env45507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45506_45507 : H12AffineEnvironment.transform 2 4 env45506 = env45507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env45506 == env45507) = true)

theorem identity45507 : scanCanonicalize (H12AffineFastState.compose env45507 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound45507 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45508 : List Nat := [2,4,4,6,6,7,5,3,1,4,0,0,2,0,1,4,1,1,5,0,0,6,6,2,2,7,1,1,1,0,2,6,3,7,0,1]

theorem envBound45508 : H12AffineFastState.Bounded env45508 := by
  intro p hp
  have h : env45508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45507_45508 : H12AffineEnvironment.transform 3 6 env45507 = env45508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env45507 == env45508) = true)

def env45509 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,28705,21777,262144,1374,32769,4096,61649,5457,284033,8662,5214,21873,4177,21534,2170,303521,21841,256,324084,1344,863]

theorem envBound45509 : H12AffineFastState.Bounded env45509 := by
  intro p hp
  have h : env45509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45493_45509 : H12AffineEnvironment.transform 15 28705 env45493 = env45509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28705 env45493 == env45509) = true)

def env45510 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,75057,262144,95615,32769,4096,61649,91505,284033,86519,5215,21872,90225,74815,96347,381312,75121,256,324085,1344,95102]

theorem envBound45510 : H12AffineFastState.Bounded env45510 := by
  intro p hp
  have h : env45510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45492_45510 : H12AffineEnvironment.transform 16 75057 env45492 = env45510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 75057 env45492 == env45510) = true)

def env45511 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,28704,21777,262144,1375,32769,4096,61649,5457,284033,8663,5215,21872,4177,21535,2171,303520,21841,256,324085,1344,862]

theorem envBound45511 : H12AffineFastState.Bounded env45511 := by
  intro p hp
  have h : env45511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45510_45511 : H12AffineEnvironment.transform 15 28704 env45510 = env45511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28704 env45510 == env45511) = true)

def env45512 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,28705,21776,262144,1374,32769,4096,61649,5456,284033,8662,5215,21872,4176,21534,2170,303521,21840,256,324085,1344,863]

theorem envBound45512 : H12AffineFastState.Bounded env45512 := by
  intro p hp
  have h : env45512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45510_45512 : H12AffineEnvironment.transform 15 28705 env45510 = env45512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28705 env45510 == env45512) = true)

theorem identity45512 : scanCanonicalize (H12AffineFastState.compose env45512 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 95) := by decide +kernel

theorem selectedBound45512 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env45513 : List Nat := [2,4,8,16,32,64,128,95,512,1024,2048,4096,8192,16384,32768,28705,21583,262144,1025,32769,4096,61649,5135,283870,8329,5215,21551,4176,21534,2170,303358,21519,95,323754,1055,512]

theorem envBound45513 : H12AffineFastState.Bounded env45513 := by
  intro p hp
  have h : env45513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45512_45513 : H12AffineEnvironment.transform 7 95 env45512 = env45513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 95 env45512 == env45513) = true)

theorem identity45513 : scanCanonicalize (H12AffineFastState.compose env45513 (packedSelected [4,9,16] rootPS)) = affineNative (2^(17+1) ^^^ 5356) := by decide +kernel

theorem selectedBound45513 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env45514 : List Nat := [2,4,8,16,32,64,128,95,512,1024,2048,4096,8192,16384,32768,28705,21583,5356,1025,32769,4096,61649,5135,16434,8329,5215,21551,4176,21534,2170,46098,21519,95,58438,1055,512]

theorem envBound45514 : H12AffineFastState.Bounded env45514 := by
  intro p hp
  have h : env45514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45513_45514 : H12AffineEnvironment.transform 17 5356 env45513 = env45514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 5356 env45513 == env45514) = true)

theorem identity45514 : scanCanonicalize (H12AffineFastState.compose env45514 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 25676) := by decide +kernel

theorem selectedBound45514 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env45515 : List Nat := [2,4,8,16,32,64,128,95,512,1024,2048,4096,8192,16384,25676,28705,21583,5356,1025,25677,4096,5277,5135,16434,8329,5215,21551,4176,21534,2170,20574,21519,95,10,1055,512]

theorem envBound45515 : H12AffineFastState.Bounded env45515 := by
  intro p hp
  have h : env45515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45514_45515 : H12AffineEnvironment.transform 14 25676 env45514 = env45515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25676 env45514 == env45515) = true)

theorem identity45515 : scanCanonicalize (H12AffineFastState.compose env45515 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound45515 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env45516 : List Nat := [2,4,8,16,32,17,128,14,512,1024,2048,4096,8192,16384,25629,28705,21534,5309,1025,25628,4096,5277,5135,16434,8329,5134,21551,4097,21534,2091,20495,21519,14,10,1055,512]

theorem envBound45516 : H12AffineFastState.Bounded env45516 := by
  intro p hp
  have h : env45516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45515_45516 : H12AffineEnvironment.transform 5 17 env45515 = env45516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env45515 == env45516) = true)

theorem identity45516 : scanCanonicalize (H12AffineFastState.compose env45516 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound45516 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env45517 : List Nat := [2,4,8,16,32,17,128,14,512,4,2048,4096,8192,16384,24601,28705,20506,4281,5,24600,4096,4249,4107,16434,8329,4106,20523,4097,20506,2091,20495,20491,14,10,27,512]

theorem envBound45517 : H12AffineFastState.Bounded env45517 := by
  intro p hp
  have h : env45517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45516_45517 : H12AffineEnvironment.transform 9 4 env45516 = env45517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env45516 == env45517) = true)

theorem identity45517 : scanCanonicalize (H12AffineFastState.compose env45517 (packedSelected [6] rootPS)) = affineNative (2^(13+1) ^^^ 0) := by decide +kernel

theorem selectedBound45517 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env45518 : List Nat := [2,4,8,16,32,17,128,14,512,4,2048,4096,8192,0,8217,12321,4122,4281,5,8216,4096,4249,4107,50,8329,4106,4139,4097,4122,2091,4111,4107,14,10,27,512]

theorem envBound45518 : H12AffineFastState.Bounded env45518 := by
  intro p hp
  have h : env45518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45517_45518 : H12AffineEnvironment.transform 13 0 env45517 = env45518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 0 env45517 == env45518) = true)

theorem identity45518 : scanCanonicalize (H12AffineFastState.compose env45518 (packedSelected [1,3,5,8,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 697) := by decide +kernel

theorem selectedBound45518 : packedSelected [1,3,5,8,10,12] rootPS < 2^1333 := by decide +kernel

def env45519 : List Nat := [2,4,8,16,32,17,128,14,512,4,2048,697,8192,0,8217,8856,675,512,5,8216,697,544,690,50,8329,691,658,696,675,2091,694,690,14,10,27,512]

theorem envBound45519 : H12AffineFastState.Bounded env45519 := by
  intro p hp
  have h : env45519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45518_45519 : H12AffineEnvironment.transform 11 697 env45518 = env45519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 697 env45518 == env45519) = true)

theorem identity45519 : scanCanonicalize (H12AffineFastState.compose env45519 (packedSelected [10,15] rootPS)) = affineNative (2^(10+1) ^^^ 675) := by decide +kernel

theorem selectedBound45519 : packedSelected [10,15] rootPS < 2^1333 := by decide +kernel

def env45520 : List Nat := [2,4,8,16,32,17,128,14,512,4,675,697,8192,0,8217,8856,675,512,5,8216,697,544,690,50,8329,691,658,696,675,648,694,690,14,10,27,512]

theorem envBound45520 : H12AffineFastState.Bounded env45520 := by
  intro p hp
  have h : env45520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45519_45520 : H12AffineEnvironment.transform 10 675 env45519 = env45520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 675 env45519 == env45520) = true)

theorem identity45520 : scanCanonicalize (H12AffineFastState.compose env45520 (packedSelected [4,5,8,11] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound45520 : packedSelected [4,5,8,11] rootPS < 2^1333 := by decide +kernel

def env45521 : List Nat := [2,4,8,16,32,17,5,14,512,4,550,572,8192,0,8217,8733,550,512,5,8216,572,544,567,50,8204,566,535,573,550,525,563,567,14,10,27,512]

theorem envBound45521 : H12AffineFastState.Bounded env45521 := by
  intro p hp
  have h : env45521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45520_45521 : H12AffineEnvironment.transform 6 5 env45520 = env45521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env45520 == env45521) = true)

theorem identity45521 : scanCanonicalize (H12AffineFastState.compose env45521 (packedSelected [1,2,4,5,7,13] rootPS)) = affineNative (2^(12+1) ^^^ 21) := by decide +kernel

theorem selectedBound45521 : packedSelected [1,2,4,5,7,13] rootPS < 2^1333 := by decide +kernel

def env45522 : List Nat := [2,4,8,16,32,17,5,14,512,4,550,572,21,0,12,520,550,512,5,13,572,544,567,50,25,566,535,573,550,525,563,567,14,10,27,512]

theorem envBound45522 : H12AffineFastState.Bounded env45522 := by
  intro p hp
  have h : env45522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45521_45522 : H12AffineEnvironment.transform 12 21 env45521 = env45522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 21 env45521 == env45522) = true)

theorem identity45522 : scanCanonicalize (H12AffineFastState.compose env45522 (packedSelected [1,2,3,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 28) := by decide +kernel

theorem selectedBound45522 : packedSelected [1,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env45523 : List Nat := [2,4,8,16,28,17,5,14,512,4,538,512,21,0,12,520,538,512,5,13,512,540,523,14,25,522,535,513,538,525,527,523,14,10,27,512]

theorem envBound45523 : H12AffineFastState.Bounded env45523 := by
  intro p hp
  have h : env45523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45522_45523 : H12AffineEnvironment.transform 4 28 env45522 = env45523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 28 env45522 == env45523) = true)

theorem identity45523 : scanCanonicalize (H12AffineFastState.compose env45523 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound45523 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45524 : List Nat := [2,4,8,16,28,17,5,14,0,4,26,0,21,0,12,8,26,0,5,13,0,28,11,14,25,10,23,1,26,13,15,11,14,10,27,0]

theorem envBound45524 : H12AffineFastState.Bounded env45524 := by
  intro p hp
  have h : env45524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45523_45524 : H12AffineEnvironment.transform 8 0 env45523 = env45524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env45523 == env45524) = true)

theorem identity45524 : scanCanonicalize (H12AffineFastState.compose env45524 (packedSelected [1,2] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound45524 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env45525 : List Nat := [2,4,5,16,17,17,5,3,0,4,23,0,21,0,1,5,23,0,5,0,0,17,6,3,20,7,23,1,23,0,2,6,3,7,22,0]

theorem envBound45525 : H12AffineFastState.Bounded env45525 := by
  intro p hp
  have h : env45525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45524_45525 : H12AffineEnvironment.transform 2 5 env45524 = env45525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env45524 == env45525) = true)

theorem identity45525 : scanCanonicalize (H12AffineFastState.compose env45525 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound45525 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45526 : List Nat := [2,4,5,6,7,7,5,3,0,4,1,0,3,0,1,5,1,0,5,0,0,7,6,3,2,7,1,1,1,0,2,6,3,7,0,0]

theorem envBound45526 : H12AffineFastState.Bounded env45526 := by
  intro p hp
  have h : env45526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45525_45526 : H12AffineEnvironment.transform 3 6 env45525 = env45526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env45525 == env45526) = true)

def env45527 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,16777216,533640,672785,17245633,148800,545088,96347,16876545,750911,256,17006917,1345,525825]

theorem envBound45527 : H12AffineFastState.Bounded env45527 := by
  intro p hp
  have h : env45527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45456_45527 : H12AffineEnvironment.transform 26 17245633 env45456 = env45527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245633 env45456 == env45527) = true)

theorem identity45527 : scanCanonicalize (H12AffineFastState.compose env45527 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 74863) := by decide +kernel

theorem selectedBound45527 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env45528 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,524288,32769,4096,61649,91183,16777216,533640,614526,17039790,90415,545088,96347,16876545,545104,256,16819498,1345,525825]

theorem envBound45528 : H12AffineFastState.Bounded env45528 := by
  intro p hp
  have h : env45528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45527_45528 : H12AffineEnvironment.transform 16 74863 env45527 = env45528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 74863 env45527 == env45528) = true)

def env45529 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,524288,32769,4096,61649,91183,123164,533640,614526,385202,90415,545088,96347,25885,545104,256,82998,1345,525825]

theorem envBound45529 : H12AffineFastState.Bounded env45529 := by
  intro p hp
  have h : env45529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45528_45529 : H12AffineEnvironment.transform 23 123164 env45528 = env45529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 123164 env45528 == env45529) = true)

def env45530 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,21584,32769,4096,61649,91183,123164,28888,78894,385202,90415,1296,96347,25885,1280,256,82998,1345,21073]

theorem envBound45530 : H12AffineFastState.Bounded env45530 := by
  intro p hp
  have h : env45530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45529_45530 : H12AffineEnvironment.transform 18 21584 env45529 = env45530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21584 env45529 == env45530) = true)

theorem identity45530 : scanCanonicalize (H12AffineFastState.compose env45530 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 25676) := by decide +kernel

theorem selectedBound45530 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env45531 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,25676,65536,74863,262144,21584,25677,4096,5277,91183,66896,28888,78894,328958,90415,1296,96347,25885,1280,256,82998,1345,21073]

theorem envBound45531 : H12AffineFastState.Bounded env45531 := by
  intro p hp
  have h : env45531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45530_45531 : H12AffineEnvironment.transform 14 25676 env45530 = env45531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25676 env45530 == env45531) = true)

def env45532 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74863,262144,4416,8541,4096,5277,74047,66896,13768,78894,328958,74815,1296,81227,8205,1280,256,65830,1345,5953]

theorem envBound45532 : H12AffineFastState.Bounded env45532 := by
  intro p hp
  have h : env45532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45531_45532 : H12AffineEnvironment.transform 13 1296 env45531 = env45532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env45531 == env45532) = true)

def env45533 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74863,65664,4416,8541,4096,5277,74047,66896,13768,78894,1150,74815,1296,81227,8205,1280,256,65830,1345,5953]

theorem envBound45533 : H12AffineFastState.Bounded env45533 := by
  intro p hp
  have h : env45533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45532_45533 : H12AffineEnvironment.transform 17 65664 env45532 = env45533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env45532 == env45533) = true)

theorem identity45533 : scanCanonicalize (H12AffineFastState.compose env45533 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound45533 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env45534 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,8192,1296,8540,65536,74863,65664,272,8541,80,1229,74047,66896,9624,74878,1150,74815,1296,77083,8205,1280,256,65830,1345,1809]

theorem envBound45534 : H12AffineFastState.Bounded env45534 := by
  intro p hp
  have h : env45534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45533_45534 : H12AffineEnvironment.transform 11 80 env45533 = env45534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env45533 == env45534) = true)

def env45535 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,80,8192,80,8540,65536,74031,65664,272,8541,80,397,74047,65552,8408,74046,318,74111,80,75867,8205,64,256,65830,1,593]

theorem envBound45535 : H12AffineFastState.Bounded env45535 := by
  intro p hp
  have h : env45535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45534_45535 : H12AffineEnvironment.transform 9 320 env45534 = env45535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env45534 == env45535) = true)

theorem identity45535 : scanCanonicalize (H12AffineFastState.compose env45535 (packedSelected [7,20,27] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound45535 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env45536 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,80,269,80,81,65536,65570,65664,272,80,80,397,65586,65552,469,65587,318,65650,80,67926,256,64,256,65830,1,593]

theorem envBound45536 : H12AffineFastState.Bounded env45536 := by
  intro p hp
  have h : env45536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45535_45536 : H12AffineEnvironment.transform 12 269 env45535 = env45536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env45535 == env45536) = true)

theorem identity45536 : scanCanonicalize (H12AffineFastState.compose env45536 (packedSelected [0,1,4,7,8,9,16,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound45536 : packedSelected [0,1,4,7,8,9,16,19,20] rootPS < 2^1333 := by decide +kernel

def env45537 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,80,269,80,81,115,81,243,272,80,80,397,65,99,469,64,318,1,80,2341,256,64,256,341,1,593]

theorem envBound45537 : H12AffineFastState.Bounded env45537 := by
  intro p hp
  have h : env45537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45536_45537 : H12AffineEnvironment.transform 15 115 env45536 = env45537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env45536 == env45537) = true)

theorem identity45537 : scanCanonicalize (H12AffineFastState.compose env45537 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound45537 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env45538 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,269,1,0,34,0,162,272,1,1,397,16,50,388,17,318,1,1,2341,256,17,256,260,1,512]

theorem envBound45538 : H12AffineFastState.Bounded env45538 := by
  intro p hp
  have h : env45538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45537_45538 : H12AffineEnvironment.transform 5 17 env45537 = env45538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env45537 == env45538) = true)

theorem identity45538 : scanCanonicalize (H12AffineFastState.compose env45538 (packedSelected [1,2,5] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound45538 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env45539 : List Nat := [2,4,8,16,32,17,128,256,512,273,1,1,269,1,0,34,0,162,272,1,1,397,16,50,388,17,318,1,1,292,256,17,256,260,1,512]

theorem envBound45539 : H12AffineFastState.Bounded env45539 := by
  intro p hp
  have h : env45539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45538_45539 : H12AffineEnvironment.transform 10 1 env45538 = env45539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env45538 == env45539) = true)

theorem identity45539 : scanCanonicalize (H12AffineFastState.compose env45539 (packedSelected [3,8] rootPS)) = affineNative (2^(8+1) ^^^ 162) := by decide +kernel

theorem selectedBound45539 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env45540 : List Nat := [2,4,8,16,32,17,128,256,162,273,1,1,269,1,0,34,0,162,272,1,1,397,16,50,388,17,318,1,1,292,256,17,256,260,1,162]

theorem envBound45540 : H12AffineFastState.Bounded env45540 := by
  intro p hp
  have h : env45540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45539_45540 : H12AffineEnvironment.transform 8 162 env45539 = env45540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 162 env45539 == env45540) = true)

theorem identity45540 : scanCanonicalize (H12AffineFastState.compose env45540 (packedSelected [1,2,3,10] rootPS)) = affineNative (2^(7+1) ^^^ 63) := by decide +kernel

theorem selectedBound45540 : packedSelected [1,2,3,10] rootPS < 2^1333 := by decide +kernel

def env45541 : List Nat := [2,4,8,16,32,17,128,63,162,46,1,1,50,1,0,34,0,162,47,1,1,178,16,50,187,17,1,1,1,27,63,17,63,59,1,162]

theorem envBound45541 : H12AffineFastState.Bounded env45541 := by
  intro p hp
  have h : env45541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45540_45541 : H12AffineEnvironment.transform 7 63 env45540 = env45541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 63 env45540 == env45541) = true)

theorem identity45541 : scanCanonicalize (H12AffineFastState.compose env45541 (packedSelected [0,1,2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound45541 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env45542 : List Nat := [2,4,8,16,32,17,9,63,43,46,1,1,50,1,0,34,0,43,47,1,1,59,16,50,50,17,1,1,1,27,63,17,63,59,1,43]

theorem envBound45542 : H12AffineFastState.Bounded env45542 := by
  intro p hp
  have h : env45542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45541_45542 : H12AffineEnvironment.transform 6 9 env45541 = env45542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env45541 == env45542) = true)

theorem identity45542 : scanCanonicalize (H12AffineFastState.compose env45542 (packedSelected [0,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound45542 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env45543 : List Nat := [2,4,8,10,32,11,9,37,43,46,1,1,40,1,0,34,0,43,47,1,1,33,10,40,40,11,1,1,1,1,37,11,37,33,1,43]

theorem envBound45543 : H12AffineFastState.Bounded env45543 := by
  intro p hp
  have h : env45543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45542_45543 : H12AffineEnvironment.transform 3 10 env45542 = env45543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env45542 == env45543) = true)

theorem identity45543 : scanCanonicalize (H12AffineFastState.compose env45543 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound45543 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env45544 : List Nat := [2,4,8,10,10,11,9,15,1,4,1,1,2,1,0,8,0,1,5,1,1,11,10,2,2,11,1,1,1,1,15,11,15,11,1,1]

theorem envBound45544 : H12AffineFastState.Bounded env45544 := by
  intro p hp
  have h : env45544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45543_45544 : H12AffineEnvironment.transform 4 10 env45543 = env45544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env45543 == env45544) = true)

theorem identity45544 : scanCanonicalize (H12AffineFastState.compose env45544 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound45544 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45545 : List Nat := [2,4,5,7,7,6,4,2,1,4,1,1,2,1,0,5,0,1,5,1,1,6,7,2,2,6,1,1,1,1,2,6,2,6,1,1]

theorem envBound45545 : H12AffineFastState.Bounded env45545 := by
  intro p hp
  have h : env45545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45544_45545 : H12AffineEnvironment.transform 2 5 env45544 = env45545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env45544 == env45545) = true)

def env45546 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,80,8192,81,8540,65536,74030,65664,272,8541,80,396,74047,65553,8409,74047,319,74110,81,75866,8205,65,256,65830,0,592]

theorem envBound45546 : H12AffineFastState.Bounded env45546 := by
  intro p hp
  have h : env45546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45534_45546 : H12AffineEnvironment.transform 9 321 env45534 = env45546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env45534 == env45546) = true)

theorem identity45546 : scanCanonicalize (H12AffineFastState.compose env45546 (packedSelected [7,20,27] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound45546 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env45547 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,80,348,81,0,65536,65650,65664,272,1,80,396,65635,65553,389,65635,319,65570,81,67846,337,65,256,65830,0,592]

theorem envBound45547 : H12AffineFastState.Bounded env45547 := by
  intro p hp
  have h : env45547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45546_45547 : H12AffineEnvironment.transform 12 348 env45546 = env45547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env45546 == env45547) = true)

theorem identity45547 : scanCanonicalize (H12AffineFastState.compose env45547 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound45547 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env45548 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,80,348,81,0,114,0,242,272,1,80,396,17,99,389,17,319,80,81,2420,337,65,256,340,0,592]

theorem envBound45548 : H12AffineFastState.Bounded env45548 := by
  intro p hp
  have h : env45548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45547_45548 : H12AffineEnvironment.transform 15 114 env45547 = env45548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env45547 == env45548) = true)

theorem identity45548 : scanCanonicalize (H12AffineFastState.compose env45548 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound45548 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env45549 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,0,268,1,0,34,0,162,272,1,0,396,17,51,389,17,319,0,1,2340,257,17,256,260,0,512]

theorem envBound45549 : H12AffineFastState.Bounded env45549 := by
  intro p hp
  have h : env45549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45548_45549 : H12AffineEnvironment.transform 5 16 env45548 = env45549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env45548 == env45549) = true)

theorem identity45549 : scanCanonicalize (H12AffineFastState.compose env45549 (packedSelected [1,2,5] rootPS)) = affineNative (2^(8+1) ^^^ 439) := by decide +kernel

theorem selectedBound45549 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env45550 : List Nat := [2,4,8,16,32,16,128,256,439,273,2048,0,268,1,0,34,0,162,272,1,0,396,17,51,389,17,319,0,1,2340,257,17,256,260,0,439]

theorem envBound45550 : H12AffineFastState.Bounded env45550 := by
  intro p hp
  have h : env45550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45549_45550 : H12AffineEnvironment.transform 8 439 env45549 = env45550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 439 env45549 == env45550) = true)

theorem identity45550 : scanCanonicalize (H12AffineFastState.compose env45550 (packedSelected [3,8] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound45550 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env45551 : List Nat := [2,4,8,16,32,16,19,256,292,273,2048,0,268,1,0,34,0,49,272,1,0,287,17,51,278,17,319,0,1,2340,257,17,256,260,0,292]

theorem envBound45551 : H12AffineFastState.Bounded env45551 := by
  intro p hp
  have h : env45551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45550_45551 : H12AffineEnvironment.transform 6 19 env45550 = env45551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env45550 == env45551) = true)

theorem identity45551 : scanCanonicalize (H12AffineFastState.compose env45551 (packedSelected [1,2,3,10] rootPS)) = affineNative (2^(7+1) ^^^ 63) := by decide +kernel

theorem selectedBound45551 : packedSelected [1,2,3,10] rootPS < 2^1333 := by decide +kernel

def env45552 : List Nat := [2,4,8,16,32,16,19,63,27,46,2048,0,51,1,0,34,0,49,47,1,0,32,17,51,41,17,0,0,1,2075,62,17,63,59,0,27]

theorem envBound45552 : H12AffineFastState.Bounded env45552 := by
  intro p hp
  have h : env45552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45551_45552 : H12AffineEnvironment.transform 7 63 env45551 = env45552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 63 env45551 == env45552) = true)

theorem identity45552 : scanCanonicalize (H12AffineFastState.compose env45552 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound45552 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45553 : List Nat := [2,4,8,16,32,16,19,63,27,46,48,0,51,1,0,34,0,49,47,1,0,32,17,51,41,17,0,0,1,43,62,17,63,59,0,27]

theorem envBound45553 : H12AffineFastState.Bounded env45553 := by
  intro p hp
  have h : env45553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45552_45553 : H12AffineEnvironment.transform 10 48 env45552 = env45553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env45552 == env45553) = true)

theorem identity45553 : scanCanonicalize (H12AffineFastState.compose env45553 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound45553 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env45554 : List Nat := [2,4,8,16,17,16,19,14,27,31,1,0,2,1,0,19,0,0,30,1,0,17,17,2,24,17,0,0,1,26,15,17,14,10,0,27]

theorem envBound45554 : H12AffineFastState.Bounded env45554 := by
  intro p hp
  have h : env45554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45553_45554 : H12AffineEnvironment.transform 4 17 env45553 = env45554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env45553 == env45554) = true)

def env45555 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74863,65665,4416,8541,4096,5277,74047,66896,13768,78894,1151,74815,1296,81227,8205,1280,256,65830,1345,5953]

theorem envBound45555 : H12AffineFastState.Bounded env45555 := by
  intro p hp
  have h : env45555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45532_45555 : H12AffineEnvironment.transform 17 65665 env45532 = env45555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env45532 == env45555) = true)

theorem identity45555 : scanCanonicalize (H12AffineFastState.compose env45555 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound45555 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env45556 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,8192,0,8540,65536,74111,65665,4416,8541,4096,4493,74047,65600,12504,78142,367,74031,0,79963,8205,16,256,65830,81,4689]

theorem envBound45556 : H12AffineFastState.Bounded env45556 := by
  intro p hp
  have h : env45556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45555_45556 : H12AffineEnvironment.transform 9 272 env45555 = env45556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env45555 == env45556) = true)

def env45557 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,772,8192,0,8540,65536,74111,65665,580,8541,772,649,74047,65600,9180,74298,367,74031,0,76639,8205,16,256,65830,81,341]

theorem envBound45557 : H12AffineFastState.Bounded env45557 := by
  intro p hp
  have h : env45557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45556_45557 : H12AffineEnvironment.transform 11 772 env45556 = env45557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 772 env45556 == env45557) = true)

def env45558 : List Nat := [2,4,8,16,32,0,128,256,512,272,2048,772,8192,0,8476,65536,74047,65665,516,8477,772,649,74047,65536,9116,74298,303,74031,0,76575,8205,16,256,65830,17,277]

theorem envBound45558 : H12AffineFastState.Bounded env45558 := by
  intro p hp
  have h : env45558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45557_45558 : H12AffineEnvironment.transform 5 0 env45557 = env45558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env45557 == env45558) = true)

theorem identity45558 : scanCanonicalize (H12AffineFastState.compose env45558 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 8221) := by decide +kernel

theorem selectedBound45558 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env45559 : List Nat := [2,4,8,16,32,0,128,256,512,272,2048,772,8192,0,8476,8221,290,8348,516,8477,772,649,290,8221,9116,551,303,306,0,2818,8205,16,256,8507,17,277]

theorem envBound45559 : H12AffineFastState.Bounded env45559 := by
  intro p hp
  have h : env45559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45558_45559 : H12AffineEnvironment.transform 15 8221 env45558 = env45559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8221 env45558 == env45559) = true)

def env45560 : List Nat := [2,4,8,16,32,0,128,256,512,272,2048,772,8,0,276,21,290,148,516,277,772,649,290,21,916,551,303,306,0,2818,5,16,256,307,17,277]

theorem envBound45560 : H12AffineFastState.Bounded env45560 := by
  intro p hp
  have h : env45560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45559_45560 : H12AffineEnvironment.transform 12 8 env45559 = env45560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env45559 == env45560) = true)

theorem identity45560 : scanCanonicalize (H12AffineFastState.compose env45560 (packedSelected [1,3,5,7,8,10,19,20,27] rootPS)) = affineNative (2^(8+1) ^^^ 277) := by decide +kernel

theorem selectedBound45560 : packedSelected [1,3,5,7,8,10,19,20,27] rootPS < 2^1333 := by decide +kernel

def env45561 : List Nat := [2,4,8,16,32,0,128,256,277,272,2048,17,8,0,276,21,290,148,273,277,17,412,290,21,129,306,303,306,0,2071,5,16,256,307,17,277]

theorem envBound45561 : H12AffineFastState.Bounded env45561 := by
  intro p hp
  have h : env45561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45560_45561 : H12AffineEnvironment.transform 8 277 env45560 = env45561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env45560 == env45561) = true)

theorem identity45561 : scanCanonicalize (H12AffineFastState.compose env45561 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound45561 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env45562 : List Nat := [2,4,8,16,32,0,128,20,1,4,2048,17,8,0,0,21,54,148,5,1,17,136,54,21,129,38,59,38,0,2071,5,16,20,39,17,1]

theorem envBound45562 : H12AffineFastState.Bounded env45562 := by
  intro p hp
  have h : env45562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45561_45562 : H12AffineEnvironment.transform 7 20 env45561 = env45562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env45561 == env45562) = true)

theorem identity45562 : scanCanonicalize (H12AffineFastState.compose env45562 (packedSelected [0,1,2,3,7,8,10,11,12,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound45562 : packedSelected [0,1,2,3,7,8,10,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env45563 : List Nat := [2,4,8,16,32,0,128,20,1,4,42,17,8,0,0,21,54,148,5,1,17,136,54,21,129,38,59,38,0,61,5,16,20,39,17,1]

theorem envBound45563 : H12AffineFastState.Bounded env45563 := by
  intro p hp
  have h : env45563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45562_45563 : H12AffineEnvironment.transform 10 42 env45562 = env45563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env45562 == env45563) = true)

theorem identity45563 : scanCanonicalize (H12AffineFastState.compose env45563 (packedSelected [1,2,3,4,8,9,10,11] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound45563 : packedSelected [1,2,3,4,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env45564 : List Nat := [2,4,8,16,32,0,25,20,1,4,42,17,8,0,0,21,54,13,5,1,17,17,54,21,24,38,59,38,0,61,5,16,20,39,17,1]

theorem envBound45564 : H12AffineFastState.Bounded env45564 := by
  intro p hp
  have h : env45564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45563_45564 : H12AffineEnvironment.transform 6 25 env45563 = env45564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env45563 == env45564) = true)

theorem identity45564 : scanCanonicalize (H12AffineFastState.compose env45564 (packedSelected [1,2,3] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound45564 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env45565 : List Nat := [2,4,5,16,32,0,20,20,1,4,39,17,5,0,0,21,54,0,5,1,17,17,54,21,21,38,54,38,0,48,5,16,20,39,17,1]

theorem envBound45565 : H12AffineFastState.Bounded env45565 := by
  intro p hp
  have h : env45565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45564_45565 : H12AffineEnvironment.transform 2 5 env45564 = env45565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env45564 == env45565) = true)

def env45566 : List Nat := [2,4,8,16,32,0,128,256,512,272,2048,772,9,0,277,20,290,149,516,276,772,649,290,20,917,551,303,306,0,2818,4,16,256,306,17,277]

theorem envBound45566 : H12AffineFastState.Bounded env45566 := by
  intro p hp
  have h : env45566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45559_45566 : H12AffineEnvironment.transform 12 9 env45559 = env45566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env45559 == env45566) = true)

theorem identity45566 : scanCanonicalize (H12AffineFastState.compose env45566 (packedSelected [0,2,3,4,5,7,9,10,12,13,16,20,23,32,38] rootPS)) = affineNative (2^(6+1) ^^^ 63) := by decide +kernel

theorem selectedBound45566 : packedSelected [0,2,3,4,5,7,9,10,12,13,16,20,23,32,38] rootPS < 2^1333 := by decide +kernel

def env45567 : List Nat := [2,4,8,16,32,0,63,256,512,272,2048,772,9,0,277,20,290,42,516,276,772,566,290,20,810,551,303,306,0,2818,4,16,256,306,17,277]

theorem envBound45567 : H12AffineFastState.Bounded env45567 := by
  intro p hp
  have h : env45567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45566_45567 : H12AffineEnvironment.transform 6 63 env45566 = env45567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 63 env45566 == env45567) = true)

theorem identity45567 : scanCanonicalize (H12AffineFastState.compose env45567 (packedSelected [0,1,3,7,12,13,15,16,18,21,23] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound45567 : packedSelected [0,1,3,7,12,13,15,16,18,21,23] rootPS < 2^1333 := by decide +kernel

def env45568 : List Nat := [2,2,8,16,32,0,57,256,512,272,2048,770,9,0,275,18,290,42,514,274,770,560,290,18,810,545,297,306,0,2818,2,16,256,306,17,275]

theorem envBound45568 : H12AffineFastState.Bounded env45568 := by
  intro p hp
  have h : env45568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45567_45568 : H12AffineEnvironment.transform 1 2 env45567 = env45568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env45567 == env45568) = true)

theorem identity45568 : scanCanonicalize (H12AffineFastState.compose env45568 (packedSelected [1,2,3,4,5,9,10,15,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 777) := by decide +kernel

theorem selectedBound45568 : packedSelected [1,2,3,4,5,9,10,15,17,18] rootPS < 2^1333 := by decide +kernel

def env45569 : List Nat := [2,2,8,16,32,0,57,256,512,272,777,770,9,0,275,18,290,42,514,274,770,560,290,18,810,545,297,306,0,11,2,16,256,306,17,275]

theorem envBound45569 : H12AffineFastState.Bounded env45569 := by
  intro p hp
  have h : env45569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45568_45569 : H12AffineEnvironment.transform 10 777 env45568 = env45569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 777 env45568 == env45569) = true)

theorem identity45569 : scanCanonicalize (H12AffineFastState.compose env45569 (packedSelected [0,1,2,3,5,7,8,10,11] rootPS)) = affineNative (2^(7+1) ^^^ 3) := by decide +kernel

theorem selectedBound45569 : packedSelected [0,1,2,3,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env45570 : List Nat := [2,2,8,16,32,0,57,3,512,19,522,513,9,0,16,18,33,42,514,17,513,560,33,18,553,545,42,49,0,11,2,16,3,49,17,16]

theorem envBound45570 : H12AffineFastState.Bounded env45570 := by
  intro p hp
  have h : env45570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45569_45570 : H12AffineEnvironment.transform 7 3 env45569 = env45570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 3 env45569 == env45570) = true)

theorem identity45570 : scanCanonicalize (H12AffineFastState.compose env45570 (packedSelected [0,2,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 59) := by decide +kernel

theorem selectedBound45570 : packedSelected [0,2,3,4] rootPS < 2^1333 := by decide +kernel

def env45571 : List Nat := [2,2,8,16,32,0,57,3,59,19,49,58,9,0,16,18,33,42,57,17,58,11,33,18,18,26,42,49,0,11,2,16,3,49,17,16]

theorem envBound45571 : H12AffineFastState.Bounded env45571 := by
  intro p hp
  have h : env45571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45570_45571 : H12AffineEnvironment.transform 8 59 env45570 = env45571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 59 env45570 == env45571) = true)

theorem identity45571 : scanCanonicalize (H12AffineFastState.compose env45571 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound45571 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env45572 : List Nat := [2,2,2,16,32,0,51,3,49,19,49,48,3,0,16,18,33,32,51,17,48,1,33,18,18,16,32,49,0,1,2,16,3,49,17,16]

theorem envBound45572 : H12AffineFastState.Bounded env45572 := by
  intro p hp
  have h : env45572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45571_45572 : H12AffineEnvironment.transform 2 2 env45571 = env45572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env45571 == env45572) = true)

theorem identity45572 : scanCanonicalize (H12AffineFastState.compose env45572 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound45572 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45573 : List Nat := [2,2,2,16,1,0,18,3,16,19,16,17,3,0,16,18,0,1,18,17,17,1,0,18,18,16,1,16,0,1,2,16,3,16,17,16]

theorem envBound45573 : H12AffineFastState.Bounded env45573 := by
  intro p hp
  have h : env45573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45572_45573 : H12AffineEnvironment.transform 4 1 env45572 = env45573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env45572 == env45573) = true)

theorem identity45573 : scanCanonicalize (H12AffineFastState.compose env45573 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound45573 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45574 : List Nat := [2,2,2,1,1,0,3,3,1,2,1,0,3,0,1,3,0,1,3,0,0,1,0,3,3,1,1,1,0,1,2,1,3,1,0,1]

theorem envBound45574 : H12AffineFastState.Bounded env45574 := by
  intro p hp
  have h : env45574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45573_45574 : H12AffineEnvironment.transform 3 1 env45573 = env45574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env45573 == env45574) = true)

def env45575 : List Nat := [2,4,8,16,32,1,128,256,512,272,2048,772,8192,0,8477,65536,74046,65665,517,8476,772,649,74047,65537,9117,74298,302,74031,0,76574,8205,16,256,65830,16,276]

theorem envBound45575 : H12AffineFastState.Bounded env45575 := by
  intro p hp
  have h : env45575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45557_45575 : H12AffineEnvironment.transform 5 1 env45557 = env45575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env45557 == env45575) = true)

theorem identity45575 : scanCanonicalize (H12AffineFastState.compose env45575 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 4) := by decide +kernel

theorem selectedBound45575 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env45576 : List Nat := [2,4,8,16,32,1,128,256,512,272,2048,772,8192,0,8477,4,8506,133,517,8476,772,649,8507,5,9117,8766,302,8491,0,11034,8205,16,256,290,16,276]

theorem envBound45576 : H12AffineFastState.Bounded env45576 := by
  intro p hp
  have h : env45576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45575_45576 : H12AffineEnvironment.transform 15 4 env45575 = env45576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4 env45575 == env45576) = true)

def env45577 : List Nat := [2,4,8,16,32,1,128,256,512,272,2048,772,2052,0,2329,4,2366,133,517,2328,772,649,2367,5,2969,2618,302,2351,0,798,2057,16,256,290,16,276]

theorem envBound45577 : H12AffineFastState.Bounded env45577 := by
  intro p hp
  have h : env45577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45576_45577 : H12AffineEnvironment.transform 12 2052 env45576 = env45577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2052 env45576 == env45577) = true)

theorem identity45577 : scanCanonicalize (H12AffineFastState.compose env45577 (packedSelected [0,1,2,3,8,10,12,13,15,16,17,20,21,23,24,27,32] rootPS)) = affineNative (2^(7+1) ^^^ 141) := by decide +kernel

theorem selectedBound45577 : packedSelected [0,1,2,3,8,10,12,13,15,16,17,20,21,23,24,27,32] rootPS < 2^1333 := by decide +kernel

def env45578 : List Nat := [2,4,8,16,32,1,128,141,512,157,2048,649,2052,0,2196,4,2227,133,517,2197,649,649,2226,5,2580,2618,163,2210,0,659,2057,16,141,175,16,153]

theorem envBound45578 : H12AffineFastState.Bounded env45578 := by
  intro p hp
  have h : env45578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45577_45578 : H12AffineEnvironment.transform 7 141 env45577 = env45578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 141 env45577 == env45578) = true)

theorem identity45578 : scanCanonicalize (H12AffineFastState.compose env45578 (packedSelected [1,2,4,7,8,10,16,18,19,21] rootPS)) = affineNative (2^(8+1) ^^^ 181) := by decide +kernel

theorem selectedBound45578 : packedSelected [1,2,4,7,8,10,16,18,19,21] rootPS < 2^1333 := by decide +kernel

def env45579 : List Nat := [2,4,8,16,32,1,128,141,181,157,2048,60,2052,0,2196,4,2227,133,176,2197,60,60,2226,5,2209,2191,163,2210,0,38,2057,16,141,175,16,153]

theorem envBound45579 : H12AffineFastState.Bounded env45579 := by
  intro p hp
  have h : env45579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45578_45579 : H12AffineEnvironment.transform 8 181 env45578 = env45579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 181 env45578 == env45579) = true)

theorem identity45579 : scanCanonicalize (H12AffineFastState.compose env45579 (packedSelected [1,2,4,5,7,13,15,16,17,18] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound45579 : packedSelected [1,2,4,5,7,13,15,16,17,18] rootPS < 2^1333 := by decide +kernel

def env45580 : List Nat := [2,4,8,16,0,1,128,141,149,157,2048,28,2052,0,2196,4,2195,133,144,2197,28,28,2194,5,2177,2191,131,2178,0,6,2057,16,141,143,16,153]

theorem envBound45580 : H12AffineFastState.Bounded env45580 := by
  intro p hp
  have h : env45580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45579_45580 : H12AffineEnvironment.transform 4 0 env45579 = env45580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env45579 == env45580) = true)

theorem identity45580 : scanCanonicalize (H12AffineFastState.compose env45580 (packedSelected [0,1,2,3,4,5,7,9] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound45580 : packedSelected [0,1,2,3,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env45581 : List Nat := [2,4,8,1,0,1,128,141,132,140,2048,13,2052,0,2181,4,2178,133,129,2180,13,13,2179,5,2177,2191,131,2178,0,6,2057,1,141,143,1,136]

theorem envBound45581 : H12AffineFastState.Bounded env45581 := by
  intro p hp
  have h : env45581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45580_45581 : H12AffineEnvironment.transform 3 1 env45580 = env45581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env45580 == env45581) = true)

theorem identity45581 : scanCanonicalize (H12AffineFastState.compose env45581 (packedSelected [0,2,3,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound45581 : packedSelected [0,2,3,7,8] rootPS < 2^1333 := by decide +kernel

def env45582 : List Nat := [2,4,8,1,0,1,4,9,0,8,2048,13,2052,0,2049,4,2054,1,5,2048,13,13,2055,5,2053,2059,7,2054,0,6,2057,1,9,11,1,12]

theorem envBound45582 : H12AffineFastState.Bounded env45582 := by
  intro p hp
  have h : env45582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45581_45582 : H12AffineEnvironment.transform 6 4 env45581 = env45582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env45581 == env45582) = true)

def env45583 : List Nat := [2,4,8,16,32,1,128,256,512,272,2048,772,2053,0,2328,4,2367,133,517,2329,772,649,2366,5,2968,2619,302,2350,0,799,2056,16,256,290,16,276]

theorem envBound45583 : H12AffineFastState.Bounded env45583 := by
  intro p hp
  have h : env45583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45576_45583 : H12AffineEnvironment.transform 12 2053 env45576 = env45583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2053 env45576 == env45583) = true)

theorem identity45583 : scanCanonicalize (H12AffineFastState.compose env45583 (packedSelected [0,1,2,3,8,10,12,13,15,16,17,20,21,23,24,27,32] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound45583 : packedSelected [0,1,2,3,8,10,12,13,15,16,17,20,21,23,24,27,32] rootPS < 2^1333 := by decide +kernel

def env45584 : List Nat := [2,4,8,16,32,1,128,256,512,272,522,772,527,0,786,4,821,133,517,787,772,649,820,5,402,49,302,804,0,799,514,16,256,290,16,276]

theorem envBound45584 : H12AffineFastState.Bounded env45584 := by
  intro p hp
  have h : env45584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45583_45584 : H12AffineEnvironment.transform 10 522 env45583 = env45584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env45583 == env45584) = true)

theorem identity45584 : scanCanonicalize (H12AffineFastState.compose env45584 (packedSelected [1,2,4,7,16,21,23] rootPS)) = affineNative (2^(8+1) ^^^ 142) := by decide +kernel

theorem selectedBound45584 : packedSelected [1,2,4,7,16,21,23] rootPS < 2^1333 := by decide +kernel

def env45585 : List Nat := [2,4,8,16,32,1,128,256,142,272,132,394,129,0,412,4,443,133,139,413,394,7,442,5,402,49,302,426,0,401,140,16,256,290,16,276]

theorem envBound45585 : H12AffineFastState.Bounded env45585 := by
  intro p hp
  have h : env45585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45584_45585 : H12AffineEnvironment.transform 8 142 env45584 = env45585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 142 env45584 == env45585) = true)

theorem identity45585 : scanCanonicalize (H12AffineFastState.compose env45585 (packedSelected [0,1,2,3,4,7,8,9,10,11,13,16] rootPS)) = affineNative (2^(7+1) ^^^ 188) := by decide +kernel

theorem selectedBound45585 : packedSelected [0,1,2,3,4,7,8,9,10,11,13,16] rootPS < 2^1333 := by decide +kernel

def env45586 : List Nat := [2,4,8,16,32,1,128,188,142,172,132,54,129,0,32,4,7,133,139,33,54,7,6,5,46,49,146,22,0,45,140,16,188,158,16,168]

theorem envBound45586 : H12AffineFastState.Bounded env45586 := by
  intro p hp
  have h : env45586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45585_45586 : H12AffineEnvironment.transform 7 188 env45585 = env45586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 188 env45585 == env45586) = true)

def env45587 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,773,8192,0,8540,65536,74111,65665,581,8541,773,648,74047,65600,9181,74299,367,74031,0,76638,8205,16,256,65830,81,340]

theorem envBound45587 : H12AffineFastState.Bounded env45587 := by
  intro p hp
  have h : env45587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45556_45587 : H12AffineEnvironment.transform 11 773 env45556 = env45587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 773 env45556 == env45587) = true)

def env45588 : List Nat := [2,4,8,16,32,0,128,256,512,272,2048,773,8192,0,8476,65536,74047,65665,517,8477,773,648,74047,65536,9117,74299,303,74031,0,76574,8205,16,256,65830,17,276]

theorem envBound45588 : H12AffineFastState.Bounded env45588 := by
  intro p hp
  have h : env45588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45587_45588 : H12AffineEnvironment.transform 5 0 env45587 = env45588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env45587 == env45588) = true)

theorem identity45588 : scanCanonicalize (H12AffineFastState.compose env45588 (packedSelected [1,8,28] rootPS)) = affineNative (2^(7+1) ^^^ 50) := by decide +kernel

theorem selectedBound45588 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env45589 : List Nat := [2,4,8,16,32,0,128,50,512,34,2048,567,8192,0,8238,65536,73741,65665,517,8239,567,648,73741,65536,8879,74299,29,73757,0,76332,8205,16,50,65556,17,38]

theorem envBound45589 : H12AffineFastState.Bounded env45589 := by
  intro p hp
  have h : env45589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45588_45589 : H12AffineEnvironment.transform 7 50 env45588 = env45589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 50 env45588 == env45589) = true)

def env45590 : List Nat := [2,4,8,16,32,0,128,50,512,34,676,567,8192,0,8238,65536,73741,65665,517,8239,567,648,73741,65536,8879,74299,29,73757,0,73864,8205,16,50,65556,17,38]

theorem envBound45590 : H12AffineFastState.Bounded env45590 := by
  intro p hp
  have h : env45590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45589_45590 : H12AffineEnvironment.transform 10 676 env45589 = env45590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 676 env45589 == env45590) = true)

theorem identity45590 : scanCanonicalize (H12AffineFastState.compose env45590 (packedSelected [3,4,7,8,9,15,17,18,21,23,24,27,38] rootPS)) = affineNative (2^(12+1) ^^^ 151) := by decide +kernel

theorem selectedBound45590 : packedSelected [3,4,7,8,9,15,17,18,21,23,24,27,38] rootPS < 2^1333 := by decide +kernel

def env45591 : List Nat := [2,4,8,16,32,0,128,50,512,34,676,567,151,0,185,65536,65690,65665,517,184,567,648,65690,65536,568,66220,29,65674,0,65567,154,16,50,65556,17,38]

theorem envBound45591 : H12AffineFastState.Bounded env45591 := by
  intro p hp
  have h : env45591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45590_45591 : H12AffineEnvironment.transform 12 151 env45590 = env45591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 151 env45590 == env45591) = true)

theorem identity45591 : scanCanonicalize (H12AffineFastState.compose env45591 (packedSelected [0,2,9,10,11,12,13,17] rootPS)) = affineNative (2^(15+1) ^^^ 20) := by decide +kernel

theorem selectedBound45591 : packedSelected [0,2,9,10,11,12,13,17] rootPS < 2^1333 := by decide +kernel

def env45592 : List Nat := [2,4,8,16,32,0,128,50,512,34,676,567,151,0,185,20,142,149,517,184,567,648,142,20,568,696,29,158,0,11,154,16,50,0,17,38]

theorem envBound45592 : H12AffineFastState.Bounded env45592 := by
  intro p hp
  have h : env45592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45591_45592 : H12AffineEnvironment.transform 15 20 env45591 = env45592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 20 env45591 == env45592) = true)

theorem identity45592 : scanCanonicalize (H12AffineFastState.compose env45592 (packedSelected [1,3,5] rootPS)) = affineNative (2^(8+1) ^^^ 184) := by decide +kernel

theorem selectedBound45592 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env45593 : List Nat := [2,4,8,16,32,0,128,50,184,34,28,143,151,0,185,20,142,149,189,184,143,48,142,20,128,0,29,158,0,11,154,16,50,0,17,38]

theorem envBound45593 : H12AffineFastState.Bounded env45593 := by
  intro p hp
  have h : env45593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45592_45593 : H12AffineEnvironment.transform 8 184 env45592 = env45593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 184 env45592 == env45593) = true)

theorem identity45593 : scanCanonicalize (H12AffineFastState.compose env45593 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(6+1) ^^^ 52) := by decide +kernel

theorem selectedBound45593 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env45594 : List Nat := [2,4,8,16,32,0,52,50,12,34,28,59,35,0,13,20,58,33,9,12,59,48,58,20,52,0,29,42,0,11,46,16,50,0,17,38]

theorem envBound45594 : H12AffineFastState.Bounded env45594 := by
  intro p hp
  have h : env45594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45593_45594 : H12AffineEnvironment.transform 6 52 env45593 = env45594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 52 env45593 == env45594) = true)

theorem identity45594 : scanCanonicalize (H12AffineFastState.compose env45594 (packedSelected [0,3,4] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound45594 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env45595 : List Nat := [2,4,8,11,32,0,47,41,12,34,7,32,35,0,13,15,33,33,9,12,32,43,33,15,47,0,6,42,0,11,46,11,41,0,10,38]

theorem envBound45595 : H12AffineFastState.Bounded env45595 := by
  intro p hp
  have h : env45595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45594_45595 : H12AffineEnvironment.transform 3 11 env45594 = env45595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env45594 == env45595) = true)

theorem identity45595 : scanCanonicalize (H12AffineFastState.compose env45595 (packedSelected [1,8,10] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound45595 : packedSelected [1,8,10] rootPS < 2^1333 := by decide +kernel

def env45596 : List Nat := [2,2,8,11,32,0,41,41,10,34,1,32,35,0,11,9,33,33,9,10,32,43,33,9,41,0,0,42,0,11,40,11,41,0,10,32]

theorem envBound45596 : H12AffineFastState.Bounded env45596 := by
  intro p hp
  have h : env45596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45595_45596 : H12AffineEnvironment.transform 1 2 env45595 = env45596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env45595 == env45596) = true)

theorem identity45596 : scanCanonicalize (H12AffineFastState.compose env45596 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound45596 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env45597 : List Nat := [2,2,8,11,1,0,8,8,10,3,1,1,2,0,11,9,0,0,9,10,1,10,0,9,8,0,0,11,0,11,9,11,8,0,10,1]

theorem envBound45597 : H12AffineFastState.Bounded env45597 := by
  intro p hp
  have h : env45597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45596_45597 : H12AffineEnvironment.transform 4 1 env45596 = env45597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env45596 == env45597) = true)

theorem identity45597 : scanCanonicalize (H12AffineFastState.compose env45597 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound45597 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45598 : List Nat := [2,2,3,0,1,0,3,3,1,3,1,1,2,0,0,2,0,0,2,1,1,1,0,2,3,0,0,0,0,0,2,0,3,0,1,1]

theorem envBound45598 : H12AffineFastState.Bounded env45598 := by
  intro p hp
  have h : env45598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45597_45598 : H12AffineEnvironment.transform 2 3 env45597 = env45598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env45597 == env45598) = true)

def env45599 : List Nat := [2,4,8,16,32,0,128,50,512,34,677,567,8192,0,8238,65536,73741,65665,517,8239,567,648,73741,65536,8879,74299,29,73757,0,73865,8205,16,50,65556,17,38]

theorem envBound45599 : H12AffineFastState.Bounded env45599 := by
  intro p hp
  have h : env45599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45589_45599 : H12AffineEnvironment.transform 10 677 env45589 = env45599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 677 env45589 == env45599) = true)

theorem identity45599 : scanCanonicalize (H12AffineFastState.compose env45599 (packedSelected [3,4,7,8,9,15,17,18,21,23,24,27,38] rootPS)) = affineNative (2^(8+1) ^^^ 168) := by decide +kernel

theorem selectedBound45599 : packedSelected [3,4,7,8,9,15,17,18,21,23,24,27,38] rootPS < 2^1333 := by decide +kernel

def env45600 : List Nat := [2,4,8,16,32,0,128,50,168,34,13,159,8192,0,8238,65536,73741,65665,173,8239,159,32,73741,65536,8199,73875,29,73757,0,73865,8205,16,50,65556,17,38]

theorem envBound45600 : H12AffineFastState.Bounded env45600 := by
  intro p hp
  have h : env45600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45599_45600 : H12AffineEnvironment.transform 8 168 env45599 = env45600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 168 env45599 == env45600) = true)

theorem identity45600 : scanCanonicalize (H12AffineFastState.compose env45600 (packedSelected [0,1,2,4,8,16] rootPS)) = affineNative (2^(12+1) ^^^ 173) := by decide +kernel

theorem selectedBound45600 : packedSelected [0,1,2,4,8,16] rootPS < 2^1333 := by decide +kernel

def env45601 : List Nat := [2,4,8,16,32,0,128,50,168,34,13,159,173,0,131,65536,65696,65665,173,130,159,32,65696,65536,170,65598,29,65712,0,65572,160,16,50,65556,17,38]

theorem envBound45601 : H12AffineFastState.Bounded env45601 := by
  intro p hp
  have h : env45601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45600_45601 : H12AffineEnvironment.transform 12 173 env45600 = env45601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 173 env45600 == env45601) = true)

theorem identity45601 : scanCanonicalize (H12AffineFastState.compose env45601 (packedSelected [0,1,3,4,5,8,10,11,15] rootPS)) = affineNative (2^(15+1) ^^^ 187) := by decide +kernel

theorem selectedBound45601 : packedSelected [0,1,3,4,5,8,10,11,15] rootPS < 2^1333 := by decide +kernel

def env45602 : List Nat := [2,4,8,16,32,0,128,50,168,34,13,159,173,0,131,187,27,58,173,130,159,32,27,187,170,133,29,11,0,159,160,16,50,175,17,38]

theorem envBound45602 : H12AffineFastState.Bounded env45602 := by
  intro p hp
  have h : env45602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45601_45602 : H12AffineEnvironment.transform 15 187 env45601 = env45602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 187 env45601 == env45602) = true)

theorem identity45602 : scanCanonicalize (H12AffineFastState.compose env45602 (packedSelected [0,2,5,7,8] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound45602 : packedSelected [0,2,5,7,8] rootPS < 2^1333 := by decide +kernel

def env45603 : List Nat := [2,4,3,16,32,0,128,50,163,34,6,148,166,0,131,176,16,49,166,130,148,32,16,176,161,133,22,0,0,148,160,16,50,164,17,38]

theorem envBound45603 : H12AffineFastState.Bounded env45603 := by
  intro p hp
  have h : env45603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45602_45603 : H12AffineEnvironment.transform 2 3 env45602 = env45603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env45602 == env45603) = true)

theorem identity45603 : scanCanonicalize (H12AffineFastState.compose env45603 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound45603 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env45604 : List Nat := [2,4,3,16,32,0,34,50,1,34,6,54,4,0,33,18,16,49,4,32,54,32,16,18,3,39,22,0,0,54,2,16,50,6,17,38]

theorem envBound45604 : H12AffineFastState.Bounded env45604 := by
  intro p hp
  have h : env45604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45603_45604 : H12AffineEnvironment.transform 6 34 env45603 = env45604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env45603 == env45604) = true)

theorem identity45604 : scanCanonicalize (H12AffineFastState.compose env45604 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound45604 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env45605 : List Nat := [2,4,3,16,1,0,3,19,1,3,6,23,4,0,0,18,16,16,4,1,23,1,16,18,3,6,22,0,0,23,2,16,19,6,17,7]

theorem envBound45605 : H12AffineFastState.Bounded env45605 := by
  intro p hp
  have h : env45605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45604_45605 : H12AffineEnvironment.transform 4 1 env45604 = env45605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env45604 == env45605) = true)

def env45606 : List Nat := [2,4,8,16,32,1,128,256,512,272,2048,773,8192,0,8477,65536,74046,65665,516,8476,773,648,74047,65537,9116,74299,302,74031,0,76575,8205,16,256,65830,16,277]

theorem envBound45606 : H12AffineFastState.Bounded env45606 := by
  intro p hp
  have h : env45606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45587_45606 : H12AffineEnvironment.transform 5 1 env45587 = env45606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env45587 == env45606) = true)

theorem identity45606 : scanCanonicalize (H12AffineFastState.compose env45606 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 299) := by decide +kernel

theorem selectedBound45606 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env45607 : List Nat := [2,4,8,16,32,1,128,256,512,272,2048,773,299,0,54,65536,65557,65665,516,55,773,648,65556,65537,695,66320,302,65540,0,68148,294,16,256,65830,16,277]

theorem envBound45607 : H12AffineFastState.Bounded env45607 := by
  intro p hp
  have h : env45607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45606_45607 : H12AffineEnvironment.transform 12 299 env45606 = env45607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 299 env45606 == env45607) = true)

def env45608 : List Nat := [2,4,8,16,32,1,128,256,180,272,2048,433,299,0,54,65536,65557,65665,176,55,433,60,65556,65537,3,65956,302,65540,0,67712,294,16,256,65830,16,277]

theorem envBound45608 : H12AffineFastState.Bounded env45608 := by
  intro p hp
  have h : env45608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45607_45608 : H12AffineEnvironment.transform 8 180 env45607 = env45608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 180 env45607 == env45608) = true)

def env45609 : List Nat := [2,4,8,16,32,1,128,256,180,272,2048,433,299,0,54,4,17,133,176,55,433,60,16,5,3,416,302,0,0,2180,294,16,256,290,16,277]

theorem envBound45609 : H12AffineFastState.Bounded env45609 := by
  intro p hp
  have h : env45609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45608_45609 : H12AffineEnvironment.transform 15 4 env45608 = env45609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4 env45608 == env45609) = true)

theorem identity45609 : scanCanonicalize (H12AffineFastState.compose env45609 (packedSelected [3,5,8,13,15] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound45609 : packedSelected [3,5,8,13,15] rootPS < 2^1333 := by decide +kernel

def env45610 : List Nat := [2,4,8,16,7,1,128,256,147,272,2048,406,268,0,17,4,17,133,151,16,406,27,16,5,3,391,265,0,0,2180,257,16,256,261,16,277]

theorem envBound45610 : H12AffineFastState.Bounded env45610 := by
  intro p hp
  have h : env45610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45609_45610 : H12AffineEnvironment.transform 4 7 env45609 = env45610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env45609 == env45610) = true)

theorem identity45610 : scanCanonicalize (H12AffineFastState.compose env45610 (packedSelected [0,3,4,7,9,10,12,13,16,17,18] rootPS)) = affineNative (2^(7+1) ^^^ 157) := by decide +kernel

theorem selectedBound45610 : packedSelected [0,3,4,7,9,10,12,13,16,17,18] rootPS < 2^1333 := by decide +kernel

def env45611 : List Nat := [2,4,8,16,7,1,128,157,147,141,2048,11,145,0,17,4,17,133,151,16,11,27,16,5,3,26,148,0,0,2180,156,16,157,152,16,136]

theorem envBound45611 : H12AffineFastState.Bounded env45611 := by
  intro p hp
  have h : env45611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45610_45611 : H12AffineEnvironment.transform 7 157 env45610 = env45611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 157 env45610 == env45611) = true)

theorem identity45611 : scanCanonicalize (H12AffineFastState.compose env45611 (packedSelected [0,1,3,8,9,10] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound45611 : packedSelected [0,1,3,8,9,10] rootPS < 2^1333 := by decide +kernel

def env45612 : List Nat := [2,4,8,7,7,1,128,138,132,141,2048,11,134,0,6,4,6,133,128,7,11,12,7,5,3,13,131,0,0,2180,139,7,138,143,7,136]

theorem envBound45612 : H12AffineFastState.Bounded env45612 := by
  intro p hp
  have h : env45612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45611_45612 : H12AffineEnvironment.transform 3 7 env45611 = env45612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env45611 == env45612) = true)

def env45613 : List Nat := [2,4,8,16,32,1,128,256,180,272,2048,433,299,0,54,5,16,132,176,55,433,60,17,4,3,417,302,1,0,2181,294,16,256,291,16,277]

theorem envBound45613 : H12AffineFastState.Bounded env45613 := by
  intro p hp
  have h : env45613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45608_45613 : H12AffineEnvironment.transform 15 5 env45608 = env45613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5 env45608 == env45613) = true)

theorem identity45613 : scanCanonicalize (H12AffineFastState.compose env45613 (packedSelected [3,5,8,13,15] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound45613 : packedSelected [3,5,8,13,15] rootPS < 2^1333 := by decide +kernel

def env45614 : List Nat := [2,4,8,16,0,1,128,256,148,272,2048,401,267,0,22,5,16,132,144,23,401,28,17,4,3,385,270,1,0,2181,262,16,256,259,16,277]

theorem envBound45614 : H12AffineFastState.Bounded env45614 := by
  intro p hp
  have h : env45614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45613_45614 : H12AffineEnvironment.transform 4 0 env45613 = env45614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env45613 == env45614) = true)

theorem identity45614 : scanCanonicalize (H12AffineFastState.compose env45614 (packedSelected [3,4,5,8,9,11,16,17] rootPS)) = affineNative (2^(10+1) ^^^ 142) := by decide +kernel

theorem selectedBound45614 : packedSelected [3,4,5,8,9,11,16,17] rootPS < 2^1333 := by decide +kernel

def env45615 : List Nat := [2,4,8,16,0,1,128,256,148,272,142,401,267,0,22,5,16,132,144,23,401,28,17,4,3,385,270,1,0,11,262,16,256,259,16,277]

theorem envBound45615 : H12AffineFastState.Bounded env45615 := by
  intro p hp
  have h : env45615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45614_45615 : H12AffineEnvironment.transform 10 142 env45614 = env45615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 142 env45614 == env45615) = true)

theorem identity45615 : scanCanonicalize (H12AffineFastState.compose env45615 (packedSelected [0,1,3,4,11] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound45615 : packedSelected [0,1,3,4,11] rootPS < 2^1333 := by decide +kernel

def env45616 : List Nat := [2,4,4,16,0,1,128,256,148,272,130,401,263,0,22,5,16,132,144,23,401,16,17,4,3,385,258,1,0,7,262,16,256,259,16,277]

theorem envBound45616 : H12AffineFastState.Bounded env45616 := by
  intro p hp
  have h : env45616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45615_45616 : H12AffineEnvironment.transform 2 4 env45615 = env45616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env45615 == env45616) = true)

theorem identity45616 : scanCanonicalize (H12AffineFastState.compose env45616 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(7+1) ^^^ 145) := by decide +kernel

theorem selectedBound45616 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env45617 : List Nat := [2,4,4,16,0,1,128,145,148,129,130,0,150,0,22,5,16,132,144,23,0,16,17,4,3,16,147,1,0,7,151,16,145,146,16,132]

theorem envBound45617 : H12AffineFastState.Bounded env45617 := by
  intro p hp
  have h : env45617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45616_45617 : H12AffineEnvironment.transform 7 145 env45616 = env45617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 145 env45616 == env45617) = true)

theorem identity45617 : scanCanonicalize (H12AffineFastState.compose env45617 (packedSelected [1,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound45617 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env45618 : List Nat := [2,4,4,16,0,1,2,19,22,3,0,0,20,0,22,5,16,6,18,23,0,16,17,4,3,16,17,1,0,7,21,16,19,16,16,6]

theorem envBound45618 : H12AffineFastState.Bounded env45618 := by
  intro p hp
  have h : env45618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45617_45618 : H12AffineEnvironment.transform 6 2 env45617 = env45618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env45617 == env45618) = true)

theorem identity45618 : scanCanonicalize (H12AffineFastState.compose env45618 (packedSelected [2,3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound45618 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env45619 : List Nat := [2,3,3,16,0,1,2,19,17,3,0,0,19,0,17,2,16,1,18,16,0,16,17,3,3,16,17,1,0,0,18,16,19,16,16,1]

theorem envBound45619 : H12AffineFastState.Bounded env45619 := by
  intro p hp
  have h : env45619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45618_45619 : H12AffineEnvironment.transform 1 3 env45618 = env45619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env45618 == env45619) = true)

def env45620 : List Nat := [2,4,8,16,32,1,128,256,181,272,2048,432,299,0,54,65536,65557,65665,177,55,432,61,65556,65537,2,65957,302,65540,0,67713,294,16,256,65830,16,277]

theorem envBound45620 : H12AffineFastState.Bounded env45620 := by
  intro p hp
  have h : env45620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45607_45620 : H12AffineEnvironment.transform 8 181 env45607 = env45620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 181 env45607 == env45620) = true)

def env45621 : List Nat := [2,4,8,16,32,1,128,256,181,272,2048,432,299,0,54,4,17,133,177,55,432,61,16,5,2,417,302,0,0,2181,294,16,256,290,16,277]

theorem envBound45621 : H12AffineFastState.Bounded env45621 := by
  intro p hp
  have h : env45621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45620_45621 : H12AffineEnvironment.transform 15 4 env45620 = env45621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4 env45620 == env45621) = true)

theorem identity45621 : scanCanonicalize (H12AffineFastState.compose env45621 (packedSelected [3,5,8,13,15] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound45621 : packedSelected [3,5,8,13,15] rootPS < 2^1333 := by decide +kernel

def env45622 : List Nat := [2,4,8,16,32,1,128,21,181,5,2048,165,62,0,54,4,17,133,177,55,165,61,16,5,2,180,59,0,0,2181,51,16,21,55,16,0]

theorem envBound45622 : H12AffineFastState.Bounded env45622 := by
  intro p hp
  have h : env45622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45621_45622 : H12AffineEnvironment.transform 7 21 env45621 = env45622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env45621 == env45622) = true)

theorem identity45622 : scanCanonicalize (H12AffineFastState.compose env45622 (packedSelected [0,1,3,4,7,8,9,10,13,16,17,18] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound45622 : packedSelected [0,1,3,4,7,8,9,10,13,16,17,18] rootPS < 2^1333 := by decide +kernel

def env45623 : List Nat := [2,4,8,16,32,1,24,21,45,5,2048,61,62,0,54,4,17,29,41,55,61,61,16,5,2,44,59,0,0,2077,51,16,21,55,16,0]

theorem envBound45623 : H12AffineFastState.Bounded env45623 := by
  intro p hp
  have h : env45623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45622_45623 : H12AffineEnvironment.transform 6 24 env45622 = env45623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env45622 == env45623) = true)

def env45624 : List Nat := [2,4,8,16,32,1,128,256,181,272,2048,432,299,0,54,5,16,132,177,55,432,61,17,4,2,416,302,1,0,2180,294,16,256,291,16,277]

theorem envBound45624 : H12AffineFastState.Bounded env45624 := by
  intro p hp
  have h : env45624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45620_45624 : H12AffineEnvironment.transform 15 5 env45620 = env45624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5 env45620 == env45624) = true)

theorem identity45624 : scanCanonicalize (H12AffineFastState.compose env45624 (packedSelected [3,5,8,13,15] rootPS)) = affineNative (2^(7+1) ^^^ 19) := by decide +kernel

theorem selectedBound45624 : packedSelected [3,5,8,13,15] rootPS < 2^1333 := by decide +kernel

def env45625 : List Nat := [2,4,8,16,32,1,128,19,181,3,2048,163,56,0,54,5,16,132,177,55,163,61,17,4,2,179,61,1,0,2180,53,16,19,48,16,6]

theorem envBound45625 : H12AffineFastState.Bounded env45625 := by
  intro p hp
  have h : env45625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45624_45625 : H12AffineEnvironment.transform 7 19 env45624 = env45625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 19 env45624 == env45625) = true)

theorem identity45625 : scanCanonicalize (H12AffineFastState.compose env45625 (packedSelected [2,3,4,9,11,13,16,18] rootPS)) = affineNative (2^(10+1) ^^^ 190) := by decide +kernel

theorem selectedBound45625 : packedSelected [2,3,4,9,11,13,16,18] rootPS < 2^1333 := by decide +kernel

def env45626 : List Nat := [2,4,8,16,32,1,128,19,181,3,190,163,56,0,54,5,16,132,177,55,163,61,17,4,2,179,61,1,0,58,53,16,19,48,16,6]

theorem envBound45626 : H12AffineFastState.Bounded env45626 := by
  intro p hp
  have h : env45626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45625_45626 : H12AffineEnvironment.transform 10 190 env45625 = env45626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 190 env45625 == env45626) = true)

theorem identity45626 : scanCanonicalize (H12AffineFastState.compose env45626 (packedSelected [3,4,7,8,10] rootPS)) = affineNative (2^(6+1) ^^^ 15) := by decide +kernel

theorem selectedBound45626 : packedSelected [3,4,7,8,10] rootPS < 2^1333 := by decide +kernel

def env45627 : List Nat := [2,4,8,16,32,1,15,19,58,3,49,44,56,0,54,5,16,11,62,55,44,61,17,4,2,60,61,1,0,58,53,16,19,48,16,6]

theorem envBound45627 : H12AffineFastState.Bounded env45627 := by
  intro p hp
  have h : env45627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45626_45627 : H12AffineEnvironment.transform 6 15 env45626 = env45627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 15 env45626 == env45627) = true)

theorem identity45627 : scanCanonicalize (H12AffineFastState.compose env45627 (packedSelected [1,3,4,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound45627 : packedSelected [1,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env45628 : List Nat := [2,4,8,16,27,1,15,19,1,3,10,23,3,0,13,5,16,11,5,12,23,6,17,4,2,7,6,1,0,1,14,16,19,11,16,6]

theorem envBound45628 : H12AffineFastState.Bounded env45628 := by
  intro p hp
  have h : env45628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45627_45628 : H12AffineEnvironment.transform 4 27 env45627 = env45628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env45627 == env45628) = true)

def env45629 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74863,262144,4417,8540,4096,5277,74046,66896,13769,78894,328958,74814,1296,81226,8204,1280,256,65831,1345,5952]

theorem envBound45629 : H12AffineFastState.Bounded env45629 := by
  intro p hp
  have h : env45629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45531_45629 : H12AffineEnvironment.transform 13 1297 env45531 = env45629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env45531 == env45629) = true)

def env45630 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74863,65664,4417,8540,4096,5277,74046,66896,13769,78894,1150,74814,1296,81226,8204,1280,256,65831,1345,5952]

theorem envBound45630 : H12AffineFastState.Bounded env45630 := by
  intro p hp
  have h : env45630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45629_45630 : H12AffineEnvironment.transform 17 65664 env45629 = env45630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env45629 == env45630) = true)

theorem identity45630 : scanCanonicalize (H12AffineFastState.compose env45630 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound45630 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env45631 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,24,1297,325,65536,66679,65664,4417,324,4096,5277,65830,66896,5585,70710,1150,66598,1296,73042,20,1280,256,65831,1345,5952]

theorem envBound45631 : H12AffineFastState.Bounded env45631 := by
  intro p hp
  have h : env45631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45630_45631 : H12AffineEnvironment.transform 12 24 env45630 = env45631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env45630 == env45631) = true)

def env45632 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1556,24,1297,325,65536,66679,65664,1877,324,1556,649,65830,66896,965,66082,1150,66598,1296,68422,20,1280,256,65831,1345,340]

theorem envBound45632 : H12AffineFastState.Bounded env45632 := by
  intro p hp
  have h : env45632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45631_45632 : H12AffineEnvironment.transform 11 1556 env45631 = env45632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1556 env45631 == env45632) = true)

def env45633 : List Nat := [2,4,8,16,32,0,128,256,512,1024,2048,1556,24,1297,261,65536,66615,65664,1813,260,1556,649,65830,66832,901,66082,1086,66598,1296,68358,20,1280,256,65831,1281,276]

theorem envBound45633 : H12AffineFastState.Bounded env45633 := by
  intro p hp
  have h : env45633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45632_45633 : H12AffineEnvironment.transform 5 0 env45632 = env45633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env45632 == env45633) = true)

theorem identity45633 : scanCanonicalize (H12AffineFastState.compose env45633 (packedSelected [1,8,28] rootPS)) = affineNative (2^(9+1) ^^^ 682) := by decide +kernel

theorem selectedBound45633 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env45634 : List Nat := [2,4,8,16,32,0,128,256,512,682,2048,190,24,955,261,65536,66205,65664,447,260,190,649,65830,66490,901,66082,660,66188,954,68358,20,938,256,65831,939,276]

theorem envBound45634 : H12AffineFastState.Bounded env45634 := by
  intro p hp
  have h : env45634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45633_45634 : H12AffineEnvironment.transform 9 682 env45633 = env45634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 682 env45633 == env45634) = true)

def env45635 : List Nat := [2,4,8,16,32,0,128,256,512,682,2048,190,24,955,261,408,773,280,447,260,190,649,190,546,901,954,660,788,954,2718,20,938,256,191,939,276]

theorem envBound45635 : H12AffineFastState.Bounded env45635 := by
  intro p hp
  have h : env45635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45634_45635 : H12AffineEnvironment.transform 15 408 env45634 = env45635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 408 env45634 == env45635) = true)

theorem identity45635 : scanCanonicalize (H12AffineFastState.compose env45635 (packedSelected [1,3,4,5,7,8,9,10,16,19,20,27] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound45635 : packedSelected [1,3,4,5,7,8,9,10,16,19,20,27] rootPS < 2^1333 := by decide +kernel

def env45636 : List Nat := [2,4,8,16,32,0,128,256,17,187,2048,190,24,426,261,408,276,280,447,260,190,152,190,51,404,427,133,261,427,2191,20,443,256,191,442,276]

theorem envBound45636 : H12AffineFastState.Bounded env45636 := by
  intro p hp
  have h : env45636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45635_45636 : H12AffineEnvironment.transform 8 17 env45635 = env45636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env45635 == env45636) = true)

theorem identity45636 : scanCanonicalize (H12AffineFastState.compose env45636 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 187) := by decide +kernel

theorem selectedBound45636 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env45637 : List Nat := [2,4,8,16,32,0,128,187,17,187,2048,190,24,17,190,35,175,163,4,191,190,152,190,51,47,16,133,190,16,2191,20,0,187,191,1,175]

theorem envBound45637 : H12AffineFastState.Bounded env45637 := by
  intro p hp
  have h : env45637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45636_45637 : H12AffineEnvironment.transform 7 187 env45636 = env45637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 187 env45636 == env45637) = true)

theorem identity45637 : scanCanonicalize (H12AffineFastState.compose env45637 (packedSelected [0,1,3,5,7,10,11,13,15] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound45637 : packedSelected [0,1,3,5,7,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env45638 : List Nat := [2,4,8,16,32,0,34,25,17,25,2048,28,24,17,28,35,13,1,4,29,28,58,28,51,47,16,39,28,16,2093,20,0,25,29,1,13]

theorem envBound45638 : H12AffineFastState.Bounded env45638 := by
  intro p hp
  have h : env45638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45637_45638 : H12AffineEnvironment.transform 6 34 env45637 = env45638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env45637 == env45638) = true)

theorem identity45638 : scanCanonicalize (H12AffineFastState.compose env45638 (packedSelected [0,2,3,5,7,8,10,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound45638 : packedSelected [0,2,3,5,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env45639 : List Nat := [2,4,8,16,32,0,34,25,17,25,32,28,24,17,28,35,13,1,4,29,28,58,28,51,47,16,39,28,16,13,20,0,25,29,1,13]

theorem envBound45639 : H12AffineFastState.Bounded env45639 := by
  intro p hp
  have h : env45639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45638_45639 : H12AffineEnvironment.transform 10 32 env45638 = env45639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env45638 == env45639) = true)

theorem identity45639 : scanCanonicalize (H12AffineFastState.compose env45639 (packedSelected [0,1,3,7,8] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound45639 : packedSelected [0,1,3,7,8] rootPS < 2^1333 := by decide +kernel

def env45640 : List Nat := [2,4,2,16,32,0,34,19,17,19,32,22,18,17,22,35,7,1,4,23,22,48,22,51,37,16,39,22,16,7,20,0,19,23,1,7]

theorem envBound45640 : H12AffineFastState.Bounded env45640 := by
  intro p hp
  have h : env45640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45639_45640 : H12AffineEnvironment.transform 2 2 env45639 = env45640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env45639 == env45640) = true)

theorem identity45640 : scanCanonicalize (H12AffineFastState.compose env45640 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound45640 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env45641 : List Nat := [2,4,2,6,32,0,34,5,7,5,32,0,4,7,0,35,7,1,4,1,0,38,0,37,37,6,39,0,6,7,2,0,5,1,1,7]

theorem envBound45641 : H12AffineFastState.Bounded env45641 := by
  intro p hp
  have h : env45641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45640_45641 : H12AffineEnvironment.transform 3 6 env45640 = env45641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env45640 == env45641) = true)

theorem identity45641 : scanCanonicalize (H12AffineFastState.compose env45641 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound45641 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env45642 : List Nat := [2,4,2,6,0,0,2,5,7,5,0,0,4,7,0,3,7,1,4,1,0,6,0,5,5,6,7,0,6,7,2,0,5,1,1,7]

theorem envBound45642 : H12AffineFastState.Bounded env45642 := by
  intro p hp
  have h : env45642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45641_45642 : H12AffineEnvironment.transform 4 0 env45641 = env45642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env45641 == env45642) = true)

theorem identity45642 : scanCanonicalize (H12AffineFastState.compose env45642 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound45642 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45643 : List Nat := [2,2,2,0,0,0,2,3,1,3,0,0,2,1,0,3,1,1,2,1,0,0,0,3,3,0,1,0,0,1,2,0,3,1,1,1]

theorem envBound45643 : H12AffineFastState.Bounded env45643 := by
  intro p hp
  have h : env45643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45642_45643 : H12AffineEnvironment.transform 1 2 env45642 = env45643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env45642 == env45643) = true)

def env45644 : List Nat := [2,4,8,16,32,0,128,256,512,682,2048,190,24,955,261,409,772,281,447,260,190,649,191,547,901,955,660,789,954,2719,20,938,256,190,939,276]

theorem envBound45644 : H12AffineFastState.Bounded env45644 := by
  intro p hp
  have h : env45644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45634_45644 : H12AffineEnvironment.transform 15 409 env45634 = env45644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 409 env45634 == env45644) = true)

theorem identity45644 : scanCanonicalize (H12AffineFastState.compose env45644 (packedSelected [1,3,4,5,7,8,9,10,16,19,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound45644 : packedSelected [1,3,4,5,7,8,9,10,16,19,20,27] rootPS < 2^1333 := by decide +kernel

def env45645 : List Nat := [2,4,8,16,32,0,128,5,512,682,2048,190,24,702,0,156,513,28,186,1,190,649,191,547,640,702,660,528,703,2719,20,687,5,190,686,17]

theorem envBound45645 : H12AffineFastState.Bounded env45645 := by
  intro p hp
  have h : env45645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45644_45645 : H12AffineEnvironment.transform 7 5 env45644 = env45645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env45644 == env45645) = true)

theorem identity45645 : scanCanonicalize (H12AffineFastState.compose env45645 (packedSelected [0,4,7,9,15,16,18] rootPS)) = affineNative (2^(10+1) ^^^ 58) := by decide +kernel

theorem selectedBound45645 : packedSelected [0,4,7,9,15,16,18] rootPS < 2^1333 := by decide +kernel

def env45646 : List Nat := [2,4,8,16,32,0,128,5,512,682,58,190,24,702,0,156,513,28,186,1,190,649,191,547,640,702,660,528,703,677,20,687,5,190,686,17]

theorem envBound45646 : H12AffineFastState.Bounded env45646 := by
  intro p hp
  have h : env45646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45645_45646 : H12AffineEnvironment.transform 10 58 env45645 = env45646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 58 env45645 == env45646) = true)

theorem identity45646 : scanCanonicalize (H12AffineFastState.compose env45646 (packedSelected [4,5,9,11,12,13] rootPS)) = affineNative (2^(8+1) ^^^ 29) := by decide +kernel

theorem selectedBound45646 : packedSelected [4,5,9,11,12,13] rootPS < 2^1333 := by decide +kernel

def env45647 : List Nat := [2,4,8,16,32,0,128,5,29,183,58,190,24,163,0,156,28,28,186,1,190,148,191,62,157,163,137,13,162,184,20,178,5,190,179,17]

theorem envBound45647 : H12AffineFastState.Bounded env45647 := by
  intro p hp
  have h : env45647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45646_45647 : H12AffineEnvironment.transform 8 29 env45646 = env45647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 29 env45646 == env45647) = true)

theorem identity45647 : scanCanonicalize (H12AffineFastState.compose env45647 (packedSelected [2,3,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 15) := by decide +kernel

theorem selectedBound45647 : packedSelected [2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env45648 : List Nat := [2,4,8,16,32,0,15,5,29,56,58,49,24,44,0,19,28,28,53,1,49,27,48,62,18,44,6,13,45,55,20,61,5,49,60,17]

theorem envBound45648 : H12AffineFastState.Bounded env45648 := by
  intro p hp
  have h : env45648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45647_45648 : H12AffineEnvironment.transform 6 15 env45647 = env45648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 15 env45647 == env45648) = true)

theorem identity45648 : scanCanonicalize (H12AffineFastState.compose env45648 (packedSelected [0,2,3,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound45648 : packedSelected [0,2,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env45649 : List Nat := [2,4,8,16,17,0,15,5,29,9,11,0,24,29,0,19,28,28,4,1,0,27,1,15,18,29,6,13,28,6,20,12,5,0,13,17]

theorem envBound45649 : H12AffineFastState.Bounded env45649 := by
  intro p hp
  have h : env45649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45648_45649 : H12AffineEnvironment.transform 4 17 env45648 = env45649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env45648 == env45649) = true)

theorem identity45649 : scanCanonicalize (H12AffineFastState.compose env45649 (packedSelected [2,3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound45649 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env45650 : List Nat := [2,2,8,16,17,0,9,3,27,9,11,0,24,27,0,19,26,26,2,1,0,27,1,9,18,27,0,11,26,0,18,10,3,0,11,17]

theorem envBound45650 : H12AffineFastState.Bounded env45650 := by
  intro p hp
  have h : env45650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45649_45650 : H12AffineEnvironment.transform 1 2 env45649 = env45650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env45649 == env45650) = true)

theorem identity45650 : scanCanonicalize (H12AffineFastState.compose env45650 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound45650 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45651 : List Nat := [2,2,8,11,10,0,9,3,0,9,11,0,3,0,0,8,1,1,2,1,0,0,1,9,9,0,0,11,1,0,9,10,3,0,11,10]

theorem envBound45651 : H12AffineFastState.Bounded env45651 := by
  intro p hp
  have h : env45651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45650_45651 : H12AffineEnvironment.transform 3 11 env45650 = env45651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env45650 == env45651) = true)

theorem identity45651 : scanCanonicalize (H12AffineFastState.compose env45651 (packedSelected [0,7] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound45651 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env45652 : List Nat := [2,2,2,1,0,0,3,3,0,3,1,0,3,0,0,2,1,1,2,1,0,0,1,3,3,0,0,1,1,0,3,0,3,0,1,0]

theorem envBound45652 : H12AffineFastState.Bounded env45652 := by
  intro p hp
  have h : env45652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45651_45652 : H12AffineEnvironment.transform 2 2 env45651 = env45652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env45651 == env45652) = true)

def env45653 : List Nat := [2,4,8,16,32,1,128,256,512,1024,2048,1556,24,1297,260,65536,66614,65664,1812,261,1556,649,65830,66833,900,66082,1087,66598,1296,68359,20,1280,256,65831,1280,277]

theorem envBound45653 : H12AffineFastState.Bounded env45653 := by
  intro p hp
  have h : env45653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45632_45653 : H12AffineEnvironment.transform 5 1 env45632 = env45653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env45632 == env45653) = true)

theorem identity45653 : scanCanonicalize (H12AffineFastState.compose env45653 (packedSelected [1,8,28] rootPS)) = affineNative (2^(8+1) ^^^ 442) := by decide +kernel

theorem selectedBound45653 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env45654 : List Nat := [2,4,8,16,32,1,128,256,442,1024,2048,1454,24,1297,260,65536,66614,65664,1198,261,1454,307,65830,66833,62,65944,1087,66598,1296,67773,20,1280,256,65831,1280,277]

theorem envBound45654 : H12AffineFastState.Bounded env45654 := by
  intro p hp
  have h : env45654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45653_45654 : H12AffineEnvironment.transform 8 442 env45653 = env45654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 442 env45653 == env45654) = true)

def env45655 : List Nat := [2,4,8,16,32,1,128,256,442,272,2048,190,24,1,260,65536,65830,65664,446,261,190,307,65830,65537,62,65944,303,65846,0,67773,20,16,256,65831,16,277]

end H12CloudChart2