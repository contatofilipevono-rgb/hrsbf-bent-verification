import H12CloudChart2Data100

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem leafIdentity24771 : H12AffineFastState.composeSystem env24771 rootObs = leafEnv24771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24771 rootObs == leafEnv24771) = true)

theorem terminalChecked24771 : H12PackedTerminal.terminalCheckFast leafEnv24771 active24771 tree24771 = true := by decide +kernel

def env24772 : List Nat := [2,4,8,16,32,64,128,253,137,1024,2048,4096,8192,16384,32768,65536,4097,262144,524288,32769,21741,41089,525328,70845,8328,525376,275517,33813,33812,634098,37052,602222,525564,558329,54292,137]

theorem envBound24772 : H12AffineFastState.Bounded env24772 := by
  intro p hp
  have h : env24772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24761_24772 : H12AffineEnvironment.transform 7 253 env24761 = env24772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env24761 == env24772) = true)

theorem identity24772 : scanCanonicalize (H12AffineFastState.compose env24772 (packedSelected [1,13,17,18,23,24] rootPS)) = affineNative (2^(18+1) ^^^ 102607) := by decide +kernel

theorem selectedBound24772 : packedSelected [1,13,17,18,23,24] rootPS < 2^1333 := by decide +kernel

def env24773 : List Nat := [2,4,8,16,32,64,128,253,137,1024,2048,4096,8192,16384,32768,65536,4097,262144,102607,32769,21741,41089,103647,70845,8328,103567,275517,33813,33812,15421,37052,41121,103475,70710,54292,137]

theorem envBound24773 : H12AffineFastState.Bounded env24773 := by
  intro p hp
  have h : env24773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24772_24773 : H12AffineEnvironment.transform 18 102607 env24772 = env24773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 102607 env24772 == env24773) = true)

theorem identity24773 : scanCanonicalize (H12AffineFastState.compose env24773 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound24773 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env24774 : List Nat := [2,4,8,16,32,64,128,253,137,1024,2048,4096,8192,16384,32768,65536,4097,43049,102607,32769,21741,41089,103647,70845,8328,103567,39956,33813,33812,15421,37052,41121,103475,70710,54292,137]

theorem envBound24774 : H12AffineFastState.Bounded env24774 := by
  intro p hp
  have h : env24774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24773_24774 : H12AffineEnvironment.transform 17 43049 env24773 = env24774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env24773 == env24774) = true)

theorem identity24774 : scanCanonicalize (H12AffineFastState.compose env24774 (packedSelected [0,2,4,11] rootPS)) = affineNative (2^(15+1) ^^^ 5175) := by decide +kernel

theorem selectedBound24774 : packedSelected [0,2,4,11] rootPS < 2^1333 := by decide +kernel

def env24775 : List Nat := [2,4,8,16,32,64,128,253,137,1024,2048,4096,8192,16384,32768,5175,4097,43049,34040,32769,21741,41089,33000,138,8328,32952,39956,33813,33812,15421,37052,41121,32772,1,54292,137]

theorem envBound24775 : H12AffineFastState.Bounded env24775 := by
  intro p hp
  have h : env24775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24774_24775 : H12AffineEnvironment.transform 15 5175 env24774 = env24775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5175 env24774 == env24775) = true)

theorem identity24775 : scanCanonicalize (H12AffineFastState.compose env24775 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound24775 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env24776 : List Nat := [2,4,8,16,32,64,128,253,137,1024,2048,4096,8192,16384,13341,5175,4097,7220,12517,13340,21741,5276,13557,138,8328,13477,10249,12296,12297,15421,9377,5308,13337,1,24585,137]

theorem envBound24776 : H12AffineFastState.Bounded env24776 := by
  intro p hp
  have h : env24776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24775_24776 : H12AffineEnvironment.transform 14 13341 env24775 = env24776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env24775 == env24776) = true)

theorem identity24776 : scanCanonicalize (H12AffineFastState.compose env24776 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(13+1) ^^^ 6338) := by decide +kernel

theorem selectedBound24776 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env24777 : List Nat := [2,4,8,16,32,64,128,253,137,1024,2048,4096,8192,6338,13341,5175,4097,7220,12517,13340,3119,5276,13557,138,8328,13477,10249,12296,12297,15421,9377,5308,13337,1,14539,137]

theorem envBound24777 : H12AffineFastState.Bounded env24777 := by
  intro p hp
  have h : env24777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24776_24777 : H12AffineEnvironment.transform 13 6338 env24776 = env24777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6338 env24776 == env24777) = true)

def env24778 : List Nat := [2,4,8,16,32,64,128,253,137,1024,2048,4096,8,6338,5141,5175,4097,7220,4333,5140,3119,5276,5373,138,128,5293,2049,4096,4097,7221,1193,5308,5137,1,6339,137]

theorem envBound24778 : H12AffineFastState.Bounded env24778 := by
  intro p hp
  have h : env24778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24777_24778 : H12AffineEnvironment.transform 12 8 env24777 = env24778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env24777 == env24778) = true)

theorem identity24778 : scanCanonicalize (H12AffineFastState.compose env24778 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1261) := by decide +kernel

theorem selectedBound24778 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24779 : List Nat := [2,4,8,16,32,64,128,253,137,1024,2048,1261,8,3119,248,218,1260,2265,1024,249,3119,113,16,138,128,64,2049,1261,1260,2264,1193,81,252,1,3118,137]

theorem envBound24779 : H12AffineFastState.Bounded env24779 := by
  intro p hp
  have h : env24779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24778_24779 : H12AffineEnvironment.transform 11 1261 env24778 = env24779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1261 env24778 == env24779) = true)

theorem identity24779 : scanCanonicalize (H12AffineFastState.compose env24779 (packedSelected [0,2,4] rootPS)) = affineNative (2^(10+1) ^^^ 194) := by decide +kernel

theorem selectedBound24779 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env24780 : List Nat := [2,4,8,16,32,64,128,253,137,1024,194,1261,8,1261,248,218,1260,27,1024,249,1261,113,16,138,128,64,195,1261,1260,26,1193,81,252,1,1260,137]

theorem envBound24780 : H12AffineFastState.Bounded env24780 := by
  intro p hp
  have h : env24780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24779_24780 : H12AffineEnvironment.transform 10 194 env24779 = env24780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 194 env24779 == env24780) = true)

theorem identity24780 : scanCanonicalize (H12AffineFastState.compose env24780 (packedSelected [1,2] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound24780 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env24781 : List Nat := [2,4,8,16,32,64,41,84,32,1024,107,1092,8,1092,81,115,1093,27,1024,80,1092,113,16,35,41,64,106,1092,1093,26,1024,81,85,1,1093,32]

theorem envBound24781 : H12AffineFastState.Bounded env24781 := by
  intro p hp
  have h : env24781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24780_24781 : H12AffineEnvironment.transform 6 41 env24780 = env24781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env24780 == env24781) = true)

theorem identity24781 : scanCanonicalize (H12AffineFastState.compose env24781 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound24781 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24782 : List Nat := [2,4,8,16,32,16,41,4,32,1024,59,1044,8,1044,1,35,1045,27,1024,0,1044,33,16,35,41,16,58,1044,1045,26,1024,1,5,1,1045,32]

theorem envBound24782 : H12AffineFastState.Bounded env24782 := by
  intro p hp
  have h : env24782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24781_24782 : H12AffineEnvironment.transform 5 16 env24781 = env24782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env24781 == env24782) = true)

def env24783 : List Nat := [2,4,8,16,0,16,9,4,0,1024,27,1044,8,1044,1,3,1045,27,1024,0,1044,1,16,3,9,16,26,1044,1045,26,1024,1,5,1,1045,0]

theorem envBound24783 : H12AffineFastState.Bounded env24783 := by
  intro p hp
  have h : env24783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24782_24783 : H12AffineEnvironment.transform 4 0 env24782 = env24783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env24782 == env24783) = true)

def env24784 : List Nat := [2,4,8,16,1,16,8,4,1,1024,26,1044,8,1044,1,2,1045,27,1024,0,1044,0,16,2,8,16,27,1044,1045,26,1024,1,5,1,1045,1]

theorem envBound24784 : H12AffineFastState.Bounded env24784 := by
  intro p hp
  have h : env24784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24782_24784 : H12AffineEnvironment.transform 4 1 env24782 = env24784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env24782 == env24784) = true)

theorem identity24784 : scanCanonicalize (H12AffineFastState.compose env24784 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound24784 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24785 : List Nat := [2,4,8,11,1,11,8,4,1,1024,1,1039,8,1039,1,2,1038,0,1024,0,1039,0,11,2,8,11,0,1039,1038,1,1024,1,5,1,1038,1]

theorem envBound24785 : H12AffineFastState.Bounded env24785 := by
  intro p hp
  have h : env24785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24784_24785 : H12AffineEnvironment.transform 3 11 env24784 = env24785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env24784 == env24785) = true)

def leafEnv24785 : List Nat := [2,4,8,11,1,11,8,4,1,1024,1,1039,8,1039,1,2,1038,0,1024,0,1039,0,11,2,1024,8,1,11,0,1039,1038,1,1024,1,5,1,5,2,1038,1,0,1038,1]

def active24785 : List Nat := [0,1,2,9]

def tree24785 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24785 : H12WitnessSearch.Good tree24785 := H12GlobalWitnessIndex.good

theorem leafIdentity24785 : H12AffineFastState.composeSystem env24785 rootObs = leafEnv24785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24785 rootObs == leafEnv24785) = true)

theorem terminalChecked24785 : H12PackedTerminal.terminalCheckFast leafEnv24785 active24785 tree24785 = true := by decide +kernel

def env24786 : List Nat := [2,4,8,16,32,64,128,253,137,1024,2048,4096,9,6338,5140,5175,4097,7220,4332,5141,3119,5276,5372,138,129,5292,2048,4097,4096,7220,1192,5308,5136,1,6338,137]

theorem envBound24786 : H12AffineFastState.Bounded env24786 := by
  intro p hp
  have h : env24786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24777_24786 : H12AffineEnvironment.transform 12 9 env24777 = env24786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env24777 == env24786) = true)

theorem identity24786 : scanCanonicalize (H12AffineFastState.compose env24786 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1076) := by decide +kernel

theorem selectedBound24786 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24787 : List Nat := [2,4,8,16,32,64,128,253,137,1024,2048,1076,9,3318,32,3,1077,2048,1240,33,3119,168,200,138,129,152,2048,1077,1076,2048,1192,136,36,1,3318,137]

theorem envBound24787 : H12AffineFastState.Bounded env24787 := by
  intro p hp
  have h : env24787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24786_24787 : H12AffineEnvironment.transform 11 1076 env24786 = env24787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1076 env24786 == env24787) = true)

theorem identity24787 : scanCanonicalize (H12AffineFastState.compose env24787 (packedSelected [0,2,4] rootPS)) = affineNative (2^(10+1) ^^^ 169) := by decide +kernel

theorem selectedBound24787 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env24788 : List Nat := [2,4,8,16,32,64,128,253,137,1024,169,1076,9,1119,32,3,1077,169,1240,33,1158,168,200,138,129,152,169,1077,1076,169,1192,136,36,1,1119,137]

theorem envBound24788 : H12AffineFastState.Bounded env24788 := by
  intro p hp
  have h : env24788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24787_24788 : H12AffineEnvironment.transform 10 169 env24787 = env24788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 169 env24787 == env24788) = true)

theorem identity24788 : scanCanonicalize (H12AffineFastState.compose env24788 (packedSelected [1,2] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound24788 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env24789 : List Nat := [2,4,8,16,32,64,40,85,33,1024,1,1076,9,1119,32,3,1077,1,1136,33,1070,0,96,34,41,48,1,1077,1076,1,1024,32,36,1,1119,33]

theorem envBound24789 : H12AffineFastState.Bounded env24789 := by
  intro p hp
  have h : env24789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24788_24789 : H12AffineEnvironment.transform 6 40 env24788 = env24789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env24788 == env24789) = true)

theorem identity24789 : scanCanonicalize (H12AffineFastState.compose env24789 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound24789 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24790 : List Nat := [2,4,8,16,0,64,8,85,1,1024,1,1044,9,1119,0,3,1045,1,1104,1,1038,0,64,2,9,16,1,1045,1044,1,1024,0,4,1,1119,1]

theorem envBound24790 : H12AffineFastState.Bounded env24790 := by
  intro p hp
  have h : env24790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24789_24790 : H12AffineEnvironment.transform 4 0 env24789 = env24790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env24789 == env24790) = true)

def env24791 : List Nat := [2,4,8,16,0,16,8,5,1,1024,1,1044,9,1039,0,3,1045,1,1024,1,1038,0,16,2,9,16,1,1045,1044,1,1024,0,4,1,1039,1]

theorem envBound24791 : H12AffineFastState.Bounded env24791 := by
  intro p hp
  have h : env24791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24790_24791 : H12AffineEnvironment.transform 5 16 env24790 = env24791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env24790 == env24791) = true)

theorem identity24791 : scanCanonicalize (H12AffineFastState.compose env24791 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound24791 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24792 : List Nat := [2,4,8,10,0,10,8,5,1,1024,1,1038,9,1039,0,3,1039,1,1024,1,1038,0,10,2,9,10,1,1039,1038,1,1024,0,4,1,1039,1]

theorem envBound24792 : H12AffineFastState.Bounded env24792 := by
  intro p hp
  have h : env24792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24791_24792 : H12AffineEnvironment.transform 3 10 env24791 = env24792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env24791 == env24792) = true)

def leafEnv24792 : List Nat := [2,4,8,10,0,10,8,5,1,1024,1,1038,9,1039,0,3,1039,1,1024,1,1038,0,10,2,1024,9,1,10,1,1039,1038,1,1024,0,4,1,5,3,1039,1,0,1038,1]

def active24792 : List Nat := [0,1,2,9]

def tree24792 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24792 : H12WitnessSearch.Good tree24792 := H12GlobalWitnessIndex.good

theorem leafIdentity24792 : H12AffineFastState.composeSystem env24792 rootObs = leafEnv24792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24792 rootObs == leafEnv24792) = true)

theorem terminalChecked24792 : H12PackedTerminal.terminalCheckFast leafEnv24792 active24792 tree24792 = true := by decide +kernel

def env24793 : List Nat := [2,4,8,16,0,17,8,4,1,1024,1,1044,9,1038,0,3,1045,1,1025,1,1038,0,17,2,9,16,1,1045,1044,1,1024,0,4,1,1038,1]

theorem envBound24793 : H12AffineFastState.Bounded env24793 := by
  intro p hp
  have h : env24793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24790_24793 : H12AffineEnvironment.transform 5 17 env24790 = env24793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env24790 == env24793) = true)

def env24794 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,16384,32768,65536,4097,262144,524288,32769,21776,4194304,525328,70977,8328,525376,4494656,33812,33813,634126,37184,4294967296,525569,4299232746,54293,137]

theorem envBound24794 : H12AffineFastState.Bounded env24794 := by
  intro p hp
  have h : env24794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24726_24794 : H12AffineEnvironment.transform 23 70977 env24726 = env24794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 70977 env24726 == env24794) = true)

def env24795 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,16384,32768,65536,4097,262144,524288,32769,21776,41088,525328,70977,8328,525376,275904,33812,33813,634126,37184,4294967296,525569,4295079274,54293,137]

theorem envBound24795 : H12AffineFastState.Bounded env24795 := by
  intro p hp
  have h : env24795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24794_24795 : H12AffineEnvironment.transform 21 41088 env24794 = env24795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env24794 == env24795) = true)

theorem identity24795 : scanCanonicalize (H12AffineFastState.compose env24795 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 103779) := by decide +kernel

theorem selectedBound24795 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env24796 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,16384,32768,65536,4097,262144,524288,32769,21776,41088,525328,70977,8328,525376,275904,33812,33813,634126,37184,103779,525569,8201,54293,137]

theorem envBound24796 : H12AffineFastState.Bounded env24796 := by
  intro p hp
  have h : env24796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24795_24796 : H12AffineEnvironment.transform 31 103779 env24795 = env24796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 103779 env24795 == env24796) = true)

def env24797 : List Nat := [2,4,8,16,32,64,128,252,137,1024,2048,4096,8192,16384,32768,65536,4097,262144,524288,32769,21740,41088,525328,70845,8328,525376,275516,33812,33813,634098,37052,103583,525565,8201,54293,137]

theorem envBound24797 : H12AffineFastState.Bounded env24797 := by
  intro p hp
  have h : env24797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24796_24797 : H12AffineEnvironment.transform 7 252 env24796 = env24797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env24796 == env24797) = true)

theorem identity24797 : scanCanonicalize (H12AffineFastState.compose env24797 (packedSelected [1,13,17,18,23,24] rootPS)) = affineNative (2^(18+1) ^^^ 102606) := by decide +kernel

theorem selectedBound24797 : packedSelected [1,13,17,18,23,24] rootPS < 2^1333 := by decide +kernel

def env24798 : List Nat := [2,4,8,16,32,64,128,252,137,1024,2048,4096,8192,16384,32768,65536,4097,262144,102606,32769,21740,41088,103646,70845,8328,103566,275516,33812,33813,15420,37052,103583,103475,8201,54293,137]

theorem envBound24798 : H12AffineFastState.Bounded env24798 := by
  intro p hp
  have h : env24798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24797_24798 : H12AffineEnvironment.transform 18 102606 env24797 = env24798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 102606 env24797 == env24798) = true)

theorem identity24798 : scanCanonicalize (H12AffineFastState.compose env24798 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound24798 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env24799 : List Nat := [2,4,8,16,32,64,128,252,137,1024,2048,4096,8192,16384,32768,65536,4097,43049,102606,32769,21740,41088,103646,70845,8328,103566,39957,33812,33813,15420,37052,103583,103475,8201,54293,137]

theorem envBound24799 : H12AffineFastState.Bounded env24799 := by
  intro p hp
  have h : env24799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24798_24799 : H12AffineEnvironment.transform 17 43049 env24798 = env24799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env24798 == env24799) = true)

theorem identity24799 : scanCanonicalize (H12AffineFastState.compose env24799 (packedSelected [0,2,4,11] rootPS)) = affineNative (2^(15+1) ^^^ 5175) := by decide +kernel

theorem selectedBound24799 : packedSelected [0,2,4,11] rootPS < 2^1333 := by decide +kernel

def env24800 : List Nat := [2,4,8,16,32,64,128,252,137,1024,2048,4096,8192,16384,32768,5175,4097,43049,34041,32769,21740,41088,33001,138,8328,32953,39957,33812,33813,15420,37052,32936,32772,8201,54293,137]

theorem envBound24800 : H12AffineFastState.Bounded env24800 := by
  intro p hp
  have h : env24800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24799_24800 : H12AffineEnvironment.transform 15 5175 env24799 = env24800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5175 env24799 == env24800) = true)

theorem identity24800 : scanCanonicalize (H12AffineFastState.compose env24800 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound24800 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env24801 : List Nat := [2,4,8,16,32,64,128,252,137,1024,2048,4096,8192,16384,13340,5175,4097,7221,12517,13341,21740,5276,13557,138,8328,13477,10249,12296,12297,15420,9376,13492,13336,8201,24585,137]

theorem envBound24801 : H12AffineFastState.Bounded env24801 := by
  intro p hp
  have h : env24801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24800_24801 : H12AffineEnvironment.transform 14 13340 env24800 = env24801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env24800 == env24801) = true)

theorem identity24801 : scanCanonicalize (H12AffineFastState.compose env24801 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(13+1) ^^^ 14538) := by decide +kernel

theorem selectedBound24801 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env24802 : List Nat := [2,4,8,16,32,64,128,252,137,1024,2048,4096,8192,14538,13340,5175,4097,7221,12517,13341,11302,5276,13557,138,8328,13477,10249,12296,12297,15420,9376,13492,13336,8201,6339,137]

theorem envBound24802 : H12AffineFastState.Bounded env24802 := by
  intro p hp
  have h : env24802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24801_24802 : H12AffineEnvironment.transform 13 14538 env24801 = env24802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 14538 env24801 == env24802) = true)

def env24803 : List Nat := [2,4,8,16,32,64,128,252,137,1024,2048,4096,8,6338,5140,5175,4097,7221,4333,5141,3118,5276,5373,138,128,5293,2049,4096,4097,7220,1192,5308,5136,1,6339,137]

theorem envBound24803 : H12AffineFastState.Bounded env24803 := by
  intro p hp
  have h : env24803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24802_24803 : H12AffineEnvironment.transform 12 8 env24802 = env24803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env24802 == env24803) = true)

theorem identity24803 : scanCanonicalize (H12AffineFastState.compose env24803 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1260) := by decide +kernel

theorem selectedBound24803 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24804 : List Nat := [2,4,8,16,32,64,128,252,137,1024,2048,1260,8,3118,248,219,1261,2265,1025,249,3118,112,17,138,128,65,2049,1260,1261,2264,1192,80,252,1,3119,137]

theorem envBound24804 : H12AffineFastState.Bounded env24804 := by
  intro p hp
  have h : env24804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24803_24804 : H12AffineEnvironment.transform 11 1260 env24803 = env24804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1260 env24803 == env24804) = true)

theorem identity24804 : scanCanonicalize (H12AffineFastState.compose env24804 (packedSelected [0,2,4] rootPS)) = affineNative (2^(10+1) ^^^ 195) := by decide +kernel

theorem selectedBound24804 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env24805 : List Nat := [2,4,8,16,32,64,128,252,137,1024,195,1260,8,1261,248,219,1261,26,1025,249,1261,112,17,138,128,65,194,1260,1261,27,1192,80,252,1,1260,137]

theorem envBound24805 : H12AffineFastState.Bounded env24805 := by
  intro p hp
  have h : env24805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24804_24805 : H12AffineEnvironment.transform 10 195 env24804 = env24805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 195 env24804 == env24805) = true)

theorem identity24805 : scanCanonicalize (H12AffineFastState.compose env24805 (packedSelected [1,2] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound24805 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env24806 : List Nat := [2,4,8,16,32,64,40,84,33,1024,107,1092,8,1093,80,115,1093,26,1025,81,1093,112,17,34,40,65,106,1092,1093,27,1024,80,84,1,1092,33]

theorem envBound24806 : H12AffineFastState.Bounded env24806 := by
  intro p hp
  have h : env24806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24805_24806 : H12AffineEnvironment.transform 6 40 env24805 = env24806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env24805 == env24806) = true)

def env24807 : List Nat := [2,4,8,16,32,64,128,252,137,1024,2048,4096,9,6339,5141,5175,4097,7221,4332,5140,3119,5276,5372,138,129,5292,2048,4097,4096,7221,1193,5309,5137,0,6339,137]

theorem envBound24807 : H12AffineFastState.Bounded env24807 := by
  intro p hp
  have h : env24807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24802_24807 : H12AffineEnvironment.transform 12 9 env24802 = env24807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env24802 == env24807) = true)

theorem identity24807 : scanCanonicalize (H12AffineFastState.compose env24807 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1077) := by decide +kernel

theorem selectedBound24807 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24808 : List Nat := [2,4,8,16,32,64,128,252,137,1024,2048,1077,9,3318,32,2,1076,2048,1241,33,3119,169,201,138,129,153,2048,1076,1077,2048,1193,136,36,0,3318,137]

theorem envBound24808 : H12AffineFastState.Bounded env24808 := by
  intro p hp
  have h : env24808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24807_24808 : H12AffineEnvironment.transform 11 1077 env24807 = env24808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1077 env24807 == env24808) = true)

theorem identity24808 : scanCanonicalize (H12AffineFastState.compose env24808 (packedSelected [0,2,4] rootPS)) = affineNative (2^(10+1) ^^^ 168) := by decide +kernel

theorem selectedBound24808 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env24809 : List Nat := [2,4,8,16,32,64,128,252,137,1024,168,1077,9,1118,32,2,1076,168,1241,33,1159,169,201,138,129,153,168,1076,1077,168,1193,136,36,0,1118,137]

theorem envBound24809 : H12AffineFastState.Bounded env24809 := by
  intro p hp
  have h : env24809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24808_24809 : H12AffineEnvironment.transform 10 168 env24808 = env24809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 168 env24808 == env24809) = true)

theorem identity24809 : scanCanonicalize (H12AffineFastState.compose env24809 (packedSelected [1,2] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound24809 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env24810 : List Nat := [2,4,8,16,32,64,41,85,32,1024,1,1077,9,1118,32,2,1076,1,1136,33,1070,0,96,35,40,48,1,1076,1077,1,1024,33,36,0,1118,32]

theorem envBound24810 : H12AffineFastState.Bounded env24810 := by
  intro p hp
  have h : env24810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24809_24810 : H12AffineEnvironment.transform 6 41 env24809 = env24810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env24809 == env24810) = true)

theorem identity24810 : scanCanonicalize (H12AffineFastState.compose env24810 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound24810 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24811 : List Nat := [2,4,8,16,1,64,8,85,1,1024,1,1044,9,1118,1,2,1045,1,1105,0,1039,0,65,2,9,17,1,1045,1044,1,1024,0,5,0,1118,1]

theorem envBound24811 : H12AffineFastState.Bounded env24811 := by
  intro p hp
  have h : env24811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24810_24811 : H12AffineEnvironment.transform 4 1 env24810 = env24811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env24810 == env24811) = true)

def env24812 : List Nat := [2,4,8,16,1,16,8,5,1,1024,1,1044,9,1038,1,2,1045,1,1025,0,1039,0,17,2,9,17,1,1045,1044,1,1024,0,5,0,1038,1]

theorem envBound24812 : H12AffineFastState.Bounded env24812 := by
  intro p hp
  have h : env24812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24811_24812 : H12AffineEnvironment.transform 5 16 env24811 = env24812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env24811 == env24812) = true)

theorem identity24812 : scanCanonicalize (H12AffineFastState.compose env24812 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound24812 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24813 : List Nat := [2,4,8,10,1,10,8,5,1,1024,1,1038,9,1038,1,2,1039,1,1025,0,1039,0,11,2,9,11,1,1039,1038,1,1024,0,5,0,1038,1]

theorem envBound24813 : H12AffineFastState.Bounded env24813 := by
  intro p hp
  have h : env24813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24812_24813 : H12AffineEnvironment.transform 3 10 env24812 = env24813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env24812 == env24813) = true)

def leafEnv24813 : List Nat := [2,4,8,10,1,10,8,5,1,1024,1,1038,9,1038,1,2,1039,1,1025,0,1039,0,11,2,1025,9,1,11,1,1039,1038,1,1024,0,5,0,4,2,1038,1,0,1039,1]

def active24813 : List Nat := [0,1,2,9]

def tree24813 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24813 : H12WitnessSearch.Good tree24813 := H12GlobalWitnessIndex.good

theorem leafIdentity24813 : H12AffineFastState.composeSystem env24813 rootObs = leafEnv24813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24813 rootObs == leafEnv24813) = true)

theorem terminalChecked24813 : H12PackedTerminal.terminalCheckFast leafEnv24813 active24813 tree24813 = true := by decide +kernel

def env24814 : List Nat := [2,4,8,16,1,17,8,4,1,1024,1,1044,9,1039,1,2,1045,1,1024,0,1039,0,16,2,9,17,1,1045,1044,1,1024,0,5,0,1039,1]

theorem envBound24814 : H12AffineFastState.Bounded env24814 := by
  intro p hp
  have h : env24814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24811_24814 : H12AffineEnvironment.transform 5 17 env24811 = env24814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env24811 == env24814) = true)

def env24815 : List Nat := [2,4,8,16,32,64,128,253,137,1024,2048,4096,8192,16384,32768,65536,4097,262144,524288,32769,21741,41088,525328,70844,8328,525376,275517,33812,33813,634099,37053,103582,525564,8201,54293,137]

theorem envBound24815 : H12AffineFastState.Bounded env24815 := by
  intro p hp
  have h : env24815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24796_24815 : H12AffineEnvironment.transform 7 253 env24796 = env24815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env24796 == env24815) = true)

theorem identity24815 : scanCanonicalize (H12AffineFastState.compose env24815 (packedSelected [1,13,17,18,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound24815 : packedSelected [1,13,17,18,23,24] rootPS < 2^1333 := by decide +kernel

def env24816 : List Nat := [2,4,8,16,32,64,128,253,137,1024,2048,4096,8192,16384,32768,65536,4097,43049,524288,32769,21741,41088,525328,70844,8328,525376,39956,33812,33813,634099,37053,103582,525564,8201,54293,137]

theorem envBound24816 : H12AffineFastState.Bounded env24816 := by
  intro p hp
  have h : env24816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24815_24816 : H12AffineEnvironment.transform 17 43049 env24815 = env24816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env24815 == env24816) = true)

theorem identity24816 : scanCanonicalize (H12AffineFastState.compose env24816 (packedSelected [11,15] rootPS)) = affineNative (2^(18+1) ^^^ 23665) := by decide +kernel

theorem selectedBound24816 : packedSelected [11,15] rootPS < 2^1333 := by decide +kernel

def env24817 : List Nat := [2,4,8,16,32,64,128,253,137,1024,2048,4096,8192,16384,32768,65536,4097,43049,23665,32769,21741,41088,22625,70844,8328,22577,39956,33812,33813,127106,37053,103582,22669,8201,54293,137]

theorem envBound24817 : H12AffineFastState.Bounded env24817 := by
  intro p hp
  have h : env24817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24816_24817 : H12AffineEnvironment.transform 18 23665 env24816 = env24817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 23665 env24816 == env24817) = true)

theorem identity24817 : scanCanonicalize (H12AffineFastState.compose env24817 (packedSelected [11] rootPS)) = affineNative (2^(15+1) ^^^ 52415) := by decide +kernel

theorem selectedBound24817 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env24818 : List Nat := [2,4,8,16,32,64,128,253,137,1024,2048,4096,8192,16384,32768,52415,4097,43049,23665,32769,21741,41088,22625,55299,8328,22577,39956,33812,33813,15421,37053,22561,22669,8201,54293,137]

theorem envBound24818 : H12AffineFastState.Bounded env24818 := by
  intro p hp
  have h : env24818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24817_24818 : H12AffineEnvironment.transform 15 52415 env24817 = env24818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 52415 env24817 == env24818) = true)

theorem identity24818 : scanCanonicalize (H12AffineFastState.compose env24818 (packedSelected [0,2,4] rootPS)) = affineNative (2^(14+1) ^^^ 22665) := by decide +kernel

theorem selectedBound24818 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env24819 : List Nat := [2,4,8,16,32,64,128,253,137,1024,2048,4096,8192,16384,22665,5174,4097,28832,23665,22664,21741,30729,22625,138,8328,22577,17565,23709,23708,15421,18484,22561,22669,8201,3228,137]

theorem envBound24819 : H12AffineFastState.Bounded env24819 := by
  intro p hp
  have h : env24819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24818_24819 : H12AffineEnvironment.transform 14 22665 env24818 = env24819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 22665 env24818 == env24819) = true)

theorem identity24819 : scanCanonicalize (H12AffineFastState.compose env24819 (packedSelected [0,5] rootPS)) = affineNative (2^(13+1) ^^^ 11413) := by decide +kernel

theorem selectedBound24819 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env24820 : List Nat := [2,4,8,16,32,64,128,253,137,1024,2048,4096,8192,11413,13340,5174,4097,7221,12516,13341,14456,5276,13556,138,8328,13476,10248,12296,12297,15421,9377,13492,13336,8201,3228,137]

theorem envBound24820 : H12AffineFastState.Bounded env24820 := by
  intro p hp
  have h : env24820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24819_24820 : H12AffineEnvironment.transform 13 11413 env24819 = env24820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11413 env24819 == env24820) = true)

theorem identity24820 : scanCanonicalize (H12AffineFastState.compose env24820 (packedSelected [0,1,2] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound24820 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env24821 : List Nat := [2,4,8,16,32,64,19,110,26,1024,2048,4096,8192,11270,13340,5174,4097,7221,12407,13341,14456,5135,13415,25,8219,13367,10248,12296,12297,15421,9266,13351,13336,8201,3087,26]

theorem envBound24821 : H12AffineFastState.Bounded env24821 := by
  intro p hp
  have h : env24821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24820_24821 : H12AffineEnvironment.transform 6 19 env24820 = env24821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env24820 == env24821) = true)

theorem identity24821 : scanCanonicalize (H12AffineFastState.compose env24821 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound24821 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env24822 : List Nat := [2,4,8,16,32,11,19,37,26,1024,2048,4096,8192,11270,13340,5174,4097,7221,12348,13341,14387,5135,13356,25,8219,13367,10248,12296,12297,15421,9266,13351,13336,8201,3087,26]

theorem envBound24822 : H12AffineFastState.Bounded env24822 := by
  intro p hp
  have h : env24822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24821_24822 : H12AffineEnvironment.transform 5 11 env24821 = env24822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env24821 == env24822) = true)

theorem identity24822 : scanCanonicalize (H12AffineFastState.compose env24822 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 50) := by decide +kernel

theorem selectedBound24822 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24823 : List Nat := [2,4,8,16,32,11,19,37,26,1024,2048,4096,50,3124,5166,5174,4097,7221,4110,5167,6145,5135,5150,25,41,5125,2106,4154,4155,7183,1024,5141,5162,59,3087,26]

theorem envBound24823 : H12AffineFastState.Bounded env24823 := by
  intro p hp
  have h : env24823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24822_24823 : H12AffineEnvironment.transform 12 50 env24822 = env24823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 50 env24822 == env24823) = true)

def env24824 : List Nat := [2,4,8,16,32,11,19,37,26,1024,2048,1044,50,3124,58,34,1045,2081,1050,59,3093,27,10,25,41,17,2106,1070,1071,2075,1024,1,62,59,3087,26]

theorem envBound24824 : H12AffineFastState.Bounded env24824 := by
  intro p hp
  have h : env24824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24823_24824 : H12AffineEnvironment.transform 11 1044 env24823 = env24824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1044 env24823 == env24824) = true)

def leafEnv24824 : List Nat := [2,4,8,16,32,11,19,37,26,1024,2048,1044,50,3124,58,34,1045,2081,1050,59,3093,27,10,25,1050,41,1,17,2106,1070,1071,2075,1024,1,62,59,31,57,3087,26,0,3118,1]

def active24824 : List Nat := [0,1,2,3,4,9,10]

def tree24824 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24824 : H12WitnessSearch.Good tree24824 := H12GlobalWitnessIndex.good

theorem leafIdentity24824 : H12AffineFastState.composeSystem env24824 rootObs = leafEnv24824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24824 rootObs == leafEnv24824) = true)

theorem terminalChecked24824 : H12PackedTerminal.terminalCheckFast leafEnv24824 active24824 tree24824 = true := by decide +kernel

def env24825 : List Nat := [2,4,8,16,32,11,19,37,26,1024,2048,1045,50,3124,59,35,1044,2080,1051,58,3092,26,11,25,41,16,2106,1071,1070,2074,1024,0,63,59,3087,26]

theorem envBound24825 : H12AffineFastState.Bounded env24825 := by
  intro p hp
  have h : env24825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24823_24825 : H12AffineEnvironment.transform 11 1045 env24823 = env24825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1045 env24823 == env24825) = true)

theorem identity24825 : scanCanonicalize (H12AffineFastState.compose env24825 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound24825 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24826 : List Nat := [2,4,8,16,26,11,19,31,26,1024,2048,1045,8,3086,1,25,1044,2074,1051,0,3092,26,11,25,19,16,2048,1045,1044,2074,1024,0,5,1,3087,26]

theorem envBound24826 : H12AffineFastState.Bounded env24826 := by
  intro p hp
  have h : env24826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24825_24826 : H12AffineEnvironment.transform 4 26 env24825 = env24826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env24825 == env24826) = true)

def leafEnv24826 : List Nat := [2,4,8,16,26,11,19,31,26,1024,2048,1045,8,3086,1,25,1044,2074,1051,0,3092,26,11,25,1051,19,1,16,2048,1045,1044,2074,1024,0,5,1,30,2,3087,26,0,3093,1]

def active24826 : List Nat := [0,1,2,3,9,10]

def tree24826 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24826 : H12WitnessSearch.Good tree24826 := H12GlobalWitnessIndex.good

theorem leafIdentity24826 : H12AffineFastState.composeSystem env24826 rootObs = leafEnv24826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24826 rootObs == leafEnv24826) = true)

theorem terminalChecked24826 : H12PackedTerminal.terminalCheckFast leafEnv24826 active24826 tree24826 = true := by decide +kernel

def env24827 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,16384,32768,65536,4097,262144,524288,32769,21776,41089,525328,70977,8328,525376,275905,33812,33813,634126,37184,4294967296,525569,4295079275,54293,137]

theorem envBound24827 : H12AffineFastState.Bounded env24827 := by
  intro p hp
  have h : env24827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24794_24827 : H12AffineEnvironment.transform 21 41089 env24794 = env24827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env24794 == env24827) = true)

theorem identity24827 : scanCanonicalize (H12AffineFastState.compose env24827 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 111979) := by decide +kernel

theorem selectedBound24827 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env24828 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,16384,32768,65536,4097,262144,524288,32769,21776,41089,525328,70977,8328,525376,275905,33812,33813,634126,37184,111979,525569,0,54293,137]

theorem envBound24828 : H12AffineFastState.Bounded env24828 := by
  intro p hp
  have h : env24828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24827_24828 : H12AffineEnvironment.transform 31 111979 env24827 = env24828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 111979 env24827 == env24828) = true)

def env24829 : List Nat := [2,4,8,16,32,64,128,252,137,1024,2048,4096,8192,16384,32768,65536,4097,262144,524288,32769,21740,41089,525328,70845,8328,525376,275517,33812,33813,634098,37052,111767,525565,0,54293,137]

theorem envBound24829 : H12AffineFastState.Bounded env24829 := by
  intro p hp
  have h : env24829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24828_24829 : H12AffineEnvironment.transform 7 252 env24828 = env24829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env24828 == env24829) = true)

theorem identity24829 : scanCanonicalize (H12AffineFastState.compose env24829 (packedSelected [1,13,17,18,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound24829 : packedSelected [1,13,17,18,23,24] rootPS < 2^1333 := by decide +kernel

def env24830 : List Nat := [2,4,8,16,32,64,128,252,137,1024,2048,4096,8192,16384,32768,65536,4097,43049,524288,32769,21740,41089,525328,70845,8328,525376,39956,33812,33813,634098,37052,111767,525565,0,54293,137]

theorem envBound24830 : H12AffineFastState.Bounded env24830 := by
  intro p hp
  have h : env24830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24829_24830 : H12AffineEnvironment.transform 17 43049 env24829 = env24830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env24829 == env24830) = true)

theorem identity24830 : scanCanonicalize (H12AffineFastState.compose env24830 (packedSelected [11,15] rootPS)) = affineNative (2^(18+1) ^^^ 23665) := by decide +kernel

theorem selectedBound24830 : packedSelected [11,15] rootPS < 2^1333 := by decide +kernel

def env24831 : List Nat := [2,4,8,16,32,64,128,252,137,1024,2048,4096,8192,16384,32768,65536,4097,43049,23665,32769,21740,41089,22625,70845,8328,22577,39956,33812,33813,127107,37052,111767,22668,0,54293,137]

theorem envBound24831 : H12AffineFastState.Bounded env24831 := by
  intro p hp
  have h : env24831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24830_24831 : H12AffineEnvironment.transform 18 23665 env24830 = env24831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 23665 env24830 == env24831) = true)

theorem identity24831 : scanCanonicalize (H12AffineFastState.compose env24831 (packedSelected [11] rootPS)) = affineNative (2^(15+1) ^^^ 52414) := by decide +kernel

theorem selectedBound24831 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env24832 : List Nat := [2,4,8,16,32,64,128,252,137,1024,2048,4096,8192,16384,32768,52414,4097,43049,23665,32769,21740,41089,22625,55299,8328,22577,39956,33812,33813,15421,37052,30761,22668,0,54293,137]

theorem envBound24832 : H12AffineFastState.Bounded env24832 := by
  intro p hp
  have h : env24832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24831_24832 : H12AffineEnvironment.transform 15 52414 env24831 = env24832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 52414 env24831 == env24832) = true)

theorem identity24832 : scanCanonicalize (H12AffineFastState.compose env24832 (packedSelected [0,2,4] rootPS)) = affineNative (2^(14+1) ^^^ 22665) := by decide +kernel

theorem selectedBound24832 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env24833 : List Nat := [2,4,8,16,32,64,128,252,137,1024,2048,4096,8192,16384,22665,5175,4097,28832,23665,22664,21740,30728,22625,138,8328,22577,17565,23709,23708,15421,18485,30761,22668,0,3228,137]

theorem envBound24833 : H12AffineFastState.Bounded env24833 := by
  intro p hp
  have h : env24833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24832_24833 : H12AffineEnvironment.transform 14 22665 env24832 = env24833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 22665 env24832 == env24833) = true)

theorem identity24833 : scanCanonicalize (H12AffineFastState.compose env24833 (packedSelected [0,5] rootPS)) = affineNative (2^(13+1) ^^^ 11412) := by decide +kernel

theorem selectedBound24833 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env24834 : List Nat := [2,4,8,16,32,64,128,252,137,1024,2048,4096,8192,11412,13341,5175,4097,7220,12517,13340,14456,5276,13557,138,8328,13477,10249,12297,12296,15421,9377,5309,13336,0,3228,137]

theorem envBound24834 : H12AffineFastState.Bounded env24834 := by
  intro p hp
  have h : env24834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24833_24834 : H12AffineEnvironment.transform 13 11412 env24833 = env24834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11412 env24833 == env24834) = true)

theorem identity24834 : scanCanonicalize (H12AffineFastState.compose env24834 (packedSelected [0,1,2] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound24834 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env24835 : List Nat := [2,4,8,16,32,64,18,110,27,1024,2048,4096,8192,11270,13341,5175,4097,7220,12407,13340,14456,5134,13415,24,8218,13367,10249,12297,12296,15421,9267,5167,13336,0,3086,27]

theorem envBound24835 : H12AffineFastState.Bounded env24835 := by
  intro p hp
  have h : env24835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24834_24835 : H12AffineEnvironment.transform 6 18 env24834 = env24835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env24834 == env24835) = true)

theorem identity24835 : scanCanonicalize (H12AffineFastState.compose env24835 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound24835 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env24836 : List Nat := [2,4,8,16,32,10,18,36,27,1024,2048,4096,8192,11270,13341,5175,4097,7220,12349,13340,14386,5134,13357,24,8218,13367,10249,12297,12296,15421,9267,5167,13336,0,3086,27]

theorem envBound24836 : H12AffineFastState.Bounded env24836 := by
  intro p hp
  have h : env24836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24835_24836 : H12AffineEnvironment.transform 5 10 env24835 = env24836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env24835 == env24836) = true)

theorem identity24836 : scanCanonicalize (H12AffineFastState.compose env24836 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 51) := by decide +kernel

theorem selectedBound24836 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24837 : List Nat := [2,4,8,16,32,10,18,36,27,1024,2048,4096,51,3125,5166,5175,4097,7220,4110,5167,6145,5134,5150,24,41,5124,2106,4154,4155,7182,1024,5167,5163,0,3086,27]

theorem envBound24837 : H12AffineFastState.Bounded env24837 := by
  intro p hp
  have h : env24837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24836_24837 : H12AffineEnvironment.transform 12 51 env24836 = env24837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 51 env24836 == env24837) = true)

theorem identity24837 : scanCanonicalize (H12AffineFastState.compose env24837 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound24837 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24838 : List Nat := [2,4,8,16,27,10,18,31,27,1024,2048,4096,8,3086,5141,5132,4097,7183,4110,5140,6145,5134,5150,24,18,5124,2049,4097,4096,7182,1024,5140,5136,0,3086,27]

theorem envBound24838 : H12AffineFastState.Bounded env24838 := by
  intro p hp
  have h : env24838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24837_24838 : H12AffineEnvironment.transform 4 27 env24837 = env24838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env24837 == env24838) = true)

def leafEnv24838 : List Nat := [2,4,8,16,27,10,18,31,27,1024,2048,4096,8,3086,5141,5132,4097,7183,4110,5140,6145,5134,5150,24,4110,18,1,5124,2049,4097,4096,7182,1024,5140,5136,0,5131,5142,3086,27,0,6145,1]

def active24838 : List Nat := [0,1,2,3,9,10,11]

def tree24838 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24838 : H12WitnessSearch.Good tree24838 := H12GlobalWitnessIndex.good

theorem leafIdentity24838 : H12AffineFastState.composeSystem env24838 rootObs = leafEnv24838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24838 rootObs == leafEnv24838) = true)

theorem terminalChecked24838 : H12PackedTerminal.terminalCheckFast leafEnv24838 active24838 tree24838 = true := by decide +kernel

def env24839 : List Nat := [2,4,8,16,32,64,128,253,137,1024,2048,4096,8192,16384,32768,65536,4097,262144,524288,32769,21741,41089,525328,70844,8328,525376,275516,33812,33813,634099,37053,111766,525564,0,54293,137]

theorem envBound24839 : H12AffineFastState.Bounded env24839 := by
  intro p hp
  have h : env24839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24828_24839 : H12AffineEnvironment.transform 7 253 env24828 = env24839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env24828 == env24839) = true)

theorem identity24839 : scanCanonicalize (H12AffineFastState.compose env24839 (packedSelected [1,13,17,18,23,24] rootPS)) = affineNative (2^(18+1) ^^^ 102607) := by decide +kernel

theorem selectedBound24839 : packedSelected [1,13,17,18,23,24] rootPS < 2^1333 := by decide +kernel

def env24840 : List Nat := [2,4,8,16,32,64,128,253,137,1024,2048,4096,8192,16384,32768,65536,4097,262144,102607,32769,21741,41089,103647,70844,8328,103567,275516,33812,33813,15420,37053,111766,103475,0,54293,137]

theorem envBound24840 : H12AffineFastState.Bounded env24840 := by
  intro p hp
  have h : env24840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24839_24840 : H12AffineEnvironment.transform 18 102607 env24839 = env24840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 102607 env24839 == env24840) = true)

theorem identity24840 : scanCanonicalize (H12AffineFastState.compose env24840 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound24840 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env24841 : List Nat := [2,4,8,16,32,64,128,253,137,1024,2048,4096,8192,16384,32768,65536,4097,43049,102607,32769,21741,41089,103647,70844,8328,103567,39957,33812,33813,15420,37053,111766,103475,0,54293,137]

theorem envBound24841 : H12AffineFastState.Bounded env24841 := by
  intro p hp
  have h : env24841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24840_24841 : H12AffineEnvironment.transform 17 43049 env24840 = env24841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env24840 == env24841) = true)

theorem identity24841 : scanCanonicalize (H12AffineFastState.compose env24841 (packedSelected [0,2,4,11] rootPS)) = affineNative (2^(15+1) ^^^ 5174) := by decide +kernel

theorem selectedBound24841 : packedSelected [0,2,4,11] rootPS < 2^1333 := by decide +kernel

def env24842 : List Nat := [2,4,8,16,32,64,128,253,137,1024,2048,4096,8192,16384,32768,5174,4097,43049,34041,32769,21741,41089,33001,138,8328,32953,39957,33812,33813,15420,37053,41120,32773,0,54293,137]

theorem envBound24842 : H12AffineFastState.Bounded env24842 := by
  intro p hp
  have h : env24842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24841_24842 : H12AffineEnvironment.transform 15 5174 env24841 = env24842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5174 env24841 == env24842) = true)

theorem identity24842 : scanCanonicalize (H12AffineFastState.compose env24842 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound24842 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env24843 : List Nat := [2,4,8,16,32,64,128,253,137,1024,2048,4096,8192,16384,13341,5174,4097,7220,12516,13340,21741,5276,13556,138,8328,13476,10248,12297,12296,15420,9376,5309,13336,0,24584,137]

theorem envBound24843 : H12AffineFastState.Bounded env24843 := by
  intro p hp
  have h : env24843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24842_24843 : H12AffineEnvironment.transform 14 13341 env24842 = env24843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env24842 == env24843) = true)

theorem identity24843 : scanCanonicalize (H12AffineFastState.compose env24843 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(13+1) ^^^ 6338) := by decide +kernel

theorem selectedBound24843 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env24844 : List Nat := [2,4,8,16,32,64,128,253,137,1024,2048,4096,8192,6338,13341,5174,4097,7220,12516,13340,3119,5276,13556,138,8328,13476,10248,12297,12296,15420,9376,5309,13336,0,14538,137]

theorem envBound24844 : H12AffineFastState.Bounded env24844 := by
  intro p hp
  have h : env24844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24843_24844 : H12AffineEnvironment.transform 13 6338 env24843 = env24844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6338 env24843 == env24844) = true)

def env24845 : List Nat := [2,4,8,16,32,64,128,253,137,1024,2048,4096,8,6338,5141,5174,4097,7220,4332,5140,3119,5276,5372,138,128,5292,2048,4097,4096,7220,1192,5309,5136,0,6338,137]

theorem envBound24845 : H12AffineFastState.Bounded env24845 := by
  intro p hp
  have h : env24845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24844_24845 : H12AffineEnvironment.transform 12 8 env24844 = env24845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env24844 == env24845) = true)

theorem identity24845 : scanCanonicalize (H12AffineFastState.compose env24845 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1076) := by decide +kernel

theorem selectedBound24845 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24846 : List Nat := [2,4,8,16,32,64,128,253,137,1024,2048,1076,8,3318,33,2,1077,2048,1240,32,3119,168,200,138,128,152,2048,1077,1076,2048,1192,137,36,0,3318,137]

theorem envBound24846 : H12AffineFastState.Bounded env24846 := by
  intro p hp
  have h : env24846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24845_24846 : H12AffineEnvironment.transform 11 1076 env24845 = env24846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1076 env24845 == env24846) = true)

theorem identity24846 : scanCanonicalize (H12AffineFastState.compose env24846 (packedSelected [0,2,4] rootPS)) = affineNative (2^(10+1) ^^^ 168) := by decide +kernel

theorem selectedBound24846 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env24847 : List Nat := [2,4,8,16,32,64,128,253,137,1024,168,1076,8,1118,33,2,1077,168,1240,32,1159,168,200,138,128,152,168,1077,1076,168,1192,137,36,0,1118,137]

theorem envBound24847 : H12AffineFastState.Bounded env24847 := by
  intro p hp
  have h : env24847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24846_24847 : H12AffineEnvironment.transform 10 168 env24846 = env24847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 168 env24846 == env24847) = true)

theorem identity24847 : scanCanonicalize (H12AffineFastState.compose env24847 (packedSelected [1,2] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound24847 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env24848 : List Nat := [2,4,8,16,32,64,40,85,33,1024,0,1076,8,1118,33,2,1077,0,1136,32,1071,0,96,34,40,48,0,1077,1076,0,1024,33,36,0,1118,33]

theorem envBound24848 : H12AffineFastState.Bounded env24848 := by
  intro p hp
  have h : env24848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24847_24848 : H12AffineEnvironment.transform 6 40 env24847 = env24848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env24847 == env24848) = true)

def env24849 : List Nat := [2,4,8,16,32,48,40,37,33,1024,0,1076,8,1070,33,2,1077,0,1024,32,1071,0,16,34,40,48,0,1077,1076,0,1024,33,36,0,1070,33]

theorem envBound24849 : H12AffineFastState.Bounded env24849 := by
  intro p hp
  have h : env24849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24848_24849 : H12AffineEnvironment.transform 5 48 env24848 = env24849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env24848 == env24849) = true)

theorem identity24849 : scanCanonicalize (H12AffineFastState.compose env24849 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound24849 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24850 : List Nat := [2,4,8,11,32,43,40,37,33,1024,0,1071,8,1070,33,2,1070,0,1024,32,1071,0,11,34,40,43,0,1070,1071,0,1024,33,36,0,1070,33]

theorem envBound24850 : H12AffineFastState.Bounded env24850 := by
  intro p hp
  have h : env24850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24849_24850 : H12AffineEnvironment.transform 3 11 env24849 = env24850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env24849 == env24850) = true)

def leafEnv24850 : List Nat := [2,4,8,11,32,43,40,37,33,1024,0,1071,8,1070,33,2,1070,0,1024,32,1071,0,11,34,1024,40,1,43,0,1070,1071,0,1024,33,36,0,5,34,1070,33,0,1071,1]

def active24850 : List Nat := [0,1,2,4,9]

def tree24850 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24850 : H12WitnessSearch.Good tree24850 := H12GlobalWitnessIndex.good

theorem leafIdentity24850 : H12AffineFastState.composeSystem env24850 rootObs = leafEnv24850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24850 rootObs == leafEnv24850) = true)

theorem terminalChecked24850 : H12PackedTerminal.terminalCheckFast leafEnv24850 active24850 tree24850 = true := by decide +kernel

def env24851 : List Nat := [2,4,8,16,32,49,40,36,33,1024,0,1076,8,1071,33,2,1077,0,1025,32,1071,0,17,34,40,48,0,1077,1076,0,1024,33,36,0,1071,33]

theorem envBound24851 : H12AffineFastState.Bounded env24851 := by
  intro p hp
  have h : env24851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24848_24851 : H12AffineEnvironment.transform 5 49 env24848 = env24851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env24848 == env24851) = true)

def env24852 : List Nat := [2,4,8,16,32,64,128,253,137,1024,2048,4096,9,6338,5140,5174,4097,7220,4333,5141,3119,5276,5373,138,129,5293,2049,4096,4097,7221,1193,5309,5137,0,6339,137]

theorem envBound24852 : H12AffineFastState.Bounded env24852 := by
  intro p hp
  have h : env24852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24844_24852 : H12AffineEnvironment.transform 12 9 env24844 = env24852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env24844 == env24852) = true)

theorem identity24852 : scanCanonicalize (H12AffineFastState.compose env24852 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1261) := by decide +kernel

theorem selectedBound24852 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24853 : List Nat := [2,4,8,16,32,64,128,253,137,1024,2048,1261,9,3119,249,219,1260,2265,1024,248,3119,113,16,138,129,64,2049,1261,1260,2264,1193,80,252,0,3118,137]

theorem envBound24853 : H12AffineFastState.Bounded env24853 := by
  intro p hp
  have h : env24853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24852_24853 : H12AffineEnvironment.transform 11 1261 env24852 = env24853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1261 env24852 == env24853) = true)

theorem identity24853 : scanCanonicalize (H12AffineFastState.compose env24853 (packedSelected [0,2,4] rootPS)) = affineNative (2^(10+1) ^^^ 194) := by decide +kernel

theorem selectedBound24853 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env24854 : List Nat := [2,4,8,16,32,64,128,253,137,1024,194,1261,9,1261,249,219,1260,27,1024,248,1261,113,16,138,129,64,195,1261,1260,26,1193,80,252,0,1260,137]

theorem envBound24854 : H12AffineFastState.Bounded env24854 := by
  intro p hp
  have h : env24854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24853_24854 : H12AffineEnvironment.transform 10 194 env24853 = env24854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 194 env24853 == env24854) = true)

theorem identity24854 : scanCanonicalize (H12AffineFastState.compose env24854 (packedSelected [1,2] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound24854 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env24855 : List Nat := [2,4,8,16,32,64,41,84,32,1024,107,1092,9,1092,80,114,1093,27,1024,81,1092,113,16,35,40,64,106,1092,1093,26,1024,80,85,0,1093,32]

theorem envBound24855 : H12AffineFastState.Bounded env24855 := by
  intro p hp
  have h : env24855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24854_24855 : H12AffineEnvironment.transform 6 41 env24854 = env24855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env24854 == env24855) = true)

def env24856 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,16384,32768,65536,4097,262144,524288,32769,2097152,4194304,525328,16777216,8328,2642257,21331969,16879957,16879956,17348687,18993424,4294967296,525569,4315938987,16892245,137]

theorem envBound24856 : H12AffineFastState.Bounded env24856 := by
  intro p hp
  have h : env24856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24724_24856 : H12AffineEnvironment.transform 25 2642257 env24724 = env24856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 2642257 env24724 == env24856) = true)

def env24857 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,1048576,2097152,4194304,8388608,16777216,33554432,67108864,134217728,268435456,536870912,1073741824,898831441,4294967296,8589934592,13745403171,34359738368,33563272]

theorem envBound24857 : H12AffineFastState.Bounded env24857 := by
  intro p hp
  have h : env24857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans2_24857 : H12AffineEnvironment.transform 30 898831441 env2 = env24857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 30 898831441 env2 == env24857) = true)

theorem identity24857 : scanCanonicalize (H12AffineFastState.compose env24857 (packedSelected [3,5,24,34] rootPS)) = affineNative (2^(24+1) ^^^ 8328) := by decide +kernel

theorem selectedBound24857 : packedSelected [3,5,24,34] rootPS < 2^1333 := by decide +kernel

def env24858 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,1048576,2097152,4194304,8388608,16777216,8328,67108864,134217728,268435456,536870912,1073741824,898831441,4294967296,8589934592,13711840683,34359738368,512]

theorem envBound24858 : H12AffineFastState.Bounded env24858 := by
  intro p hp
  have h : env24858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24857_24858 : H12AffineEnvironment.transform 24 8328 env24857 = env24858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8328 env24857 == env24858) = true)

theorem identity24858 : scanCanonicalize (H12AffineFastState.compose env24858 (packedSelected [4,9,22,29] rootPS)) = affineNative (2^(32+1) ^^^ 525568) := by decide +kernel

theorem selectedBound24858 : packedSelected [4,9,22,29] rootPS < 2^1333 := by decide +kernel

def env24859 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,1048576,2097152,4194304,8388608,16777216,8328,67108864,134217728,268435456,536870912,1073741824,898831441,4294967296,525568,5121380523,34359738368,512]

theorem envBound24859 : H12AffineFastState.Bounded env24859 := by
  intro p hp
  have h : env24859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24858_24859 : H12AffineEnvironment.transform 32 525568 env24858 = env24859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 32 525568 env24858 == env24859) = true)

theorem identity24859 : scanCanonicalize (H12AffineFastState.compose env24859 (packedSelected [6,25] rootPS)) = affineNative (2^(28+1) ^^^ 268570625) := by decide +kernel

theorem selectedBound24859 : packedSelected [6,25] rootPS < 2^1333 := by decide +kernel

def env24860 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,1048576,2097152,4194304,8388608,16777216,8328,67108864,134217728,268435456,268570625,1073741824,93389904,4294967296,525568,4315938986,34359738368,512]

theorem envBound24860 : H12AffineFastState.Bounded env24860 := by
  intro p hp
  have h : env24860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24859_24860 : H12AffineEnvironment.transform 28 268570625 env24859 = env24860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 28 268570625 env24859 == env24860) = true)

theorem identity24860 : scanCanonicalize (H12AffineFastState.compose env24860 (packedSelected [13,17,21,33] rootPS)) = affineNative (2^(19+1) ^^^ 32768) := by decide +kernel

theorem selectedBound24860 : packedSelected [13,17,21,33] rootPS < 2^1333 := by decide +kernel

def env24861 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,8328,67108864,134217728,268435456,268570625,1073741824,92374096,4294967296,525568,4315938986,34359738368,512]

theorem envBound24861 : H12AffineFastState.Bounded env24861 := by
  intro p hp
  have h : env24861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24860_24861 : H12AffineEnvironment.transform 19 32768 env24860 = env24861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 19 32768 env24860 == env24861) = true)

theorem identity24861 : scanCanonicalize (H12AffineFastState.compose env24861 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(26+1) ^^^ 9176216) := by decide +kernel

theorem selectedBound24861 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env24862 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,8328,67108864,9176216,268435456,268570625,1073741824,92374096,4294967296,525568,4315938986,34359738368,512]

theorem envBound24862 : H12AffineFastState.Bounded env24862 := by
  intro p hp
  have h : env24862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24861_24862 : H12AffineEnvironment.transform 26 9176216 env24861 = env24862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 9176216 env24861 == env24862) = true)

theorem identity24862 : scanCanonicalize (H12AffineFastState.compose env24862 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(31+1) ^^^ 1101622376) := by decide +kernel

theorem selectedBound24862 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env24863 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,8328,67108864,9176216,268435456,268570625,1073741824,92374096,1101622376,525568,1089039554,34359738368,512]

theorem envBound24863 : H12AffineFastState.Bounded env24863 := by
  intro p hp
  have h : env24863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24862_24863 : H12AffineEnvironment.transform 31 1101622376 env24862 = env24863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1101622376 env24862 == env24863) = true)

theorem identity24863 : scanCanonicalize (H12AffineFastState.compose env24863 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(29+1) ^^^ 71904663) := by decide +kernel

theorem selectedBound24863 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env24864 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,8328,67108864,9176216,268435456,268570625,71904663,92374096,98583039,525568,77611349,34359738368,512]

theorem envBound24864 : H12AffineFastState.Bounded env24864 := by
  intro p hp
  have h : env24864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24863_24864 : H12AffineEnvironment.transform 29 71904663 env24863 = env24864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 71904663 env24863 == env24864) = true)

theorem identity24864 : scanCanonicalize (H12AffineFastState.compose env24864 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(34+1) ^^^ 4834734) := by decide +kernel

theorem selectedBound24864 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env24865 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,8328,67108864,9176216,268435456,268570625,71904663,92374096,98583039,525568,77611349,4834734,512]

theorem envBound24865 : H12AffineFastState.Bounded env24865 := by
  intro p hp
  have h : env24865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24864_24865 : H12AffineEnvironment.transform 34 4834734 env24864 = env24865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 4834734 env24864 == env24865) = true)

theorem identity24865 : scanCanonicalize (H12AffineFastState.compose env24865 (packedSelected [3,5,8,10,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 13206681) := by decide +kernel

theorem selectedBound24865 : packedSelected [3,5,8,10,28,31] rootPS < 2^1333 := by decide +kernel

def env24866 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,13206681,8328,67108864,9176216,268435456,268570625,71904663,71827657,69846374,525568,77611349,4834734,512]

theorem envBound24866 : H12AffineFastState.Bounded env24866 := by
  intro p hp
  have h : env24866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24865_24866 : H12AffineEnvironment.transform 23 13206681 env24865 = env24866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 13206681 env24865 == env24866) = true)

theorem identity24866 : scanCanonicalize (H12AffineFastState.compose env24866 (packedSelected [7,20,27,35] rootPS)) = affineNative (2^(25+1) ^^^ 566556) := by decide +kernel

theorem selectedBound24866 : packedSelected [7,20,27,35] rootPS < 2^1333 := by decide +kernel

def env24867 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,13206681,8328,566556,9176216,268435456,268570625,4294795,4236757,2187386,525568,11068489,4834734,512]

theorem envBound24867 : H12AffineFastState.Bounded env24867 := by
  intro p hp
  have h : env24867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24866_24867 : H12AffineEnvironment.transform 25 566556 env24866 = env24867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 566556 env24866 == env24867) = true)

theorem identity24867 : scanCanonicalize (H12AffineFastState.compose env24867 (packedSelected [12,13,38] rootPS)) = affineNative (2^(16+1) ^^^ 4096) := by decide +kernel

theorem selectedBound24867 : packedSelected [12,13,38] rootPS < 2^1333 := by decide +kernel

def env24868 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4096,262144,524288,32768,2097152,4194304,8388608,13206681,8328,566556,9176216,268435456,268435457,4294795,4236757,2187386,525568,11068489,4834734,512]

theorem envBound24868 : H12AffineFastState.Bounded env24868 := by
  intro p hp
  have h : env24868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24867_24868 : H12AffineEnvironment.transform 16 4096 env24867 = env24868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4096 env24867 == env24868) = true)

def env24869 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,1048576,2097152,4194304,8388608,16777216,33554432,67108864,134217728,268435456,536870912,1073741824,2147483648,4294967296,8589934592,15147278706,34359738368,33563273]

theorem envBound24869 : H12AffineFastState.Bounded env24869 := by
  intro p hp
  have h : env24869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans1_24869 : H12AffineEnvironment.transform 35 33563273 env1 = env24869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 35 33563273 env1 == env24869) = true)

def env24870 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,1048576,2097152,4194304,8388608,16777216,33554432,67108864,134217728,268435456,536870912,1073741824,898831440,4294967296,8589934592,13745403170,34359738368,33563273]

theorem envBound24870 : H12AffineFastState.Bounded env24870 := by
  intro p hp
  have h : env24870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24869_24870 : H12AffineEnvironment.transform 30 898831440 env24869 = env24870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 30 898831440 env24869 == env24870) = true)

theorem identity24870 : scanCanonicalize (H12AffineFastState.compose env24870 (packedSelected [3,5,24,34] rootPS)) = affineNative (2^(32+1) ^^^ 525568) := by decide +kernel

theorem selectedBound24870 : packedSelected [3,5,24,34] rootPS < 2^1333 := by decide +kernel

def env24871 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,1048576,2097152,4194304,8388608,16777216,33554432,67108864,134217728,268435456,536870912,1073741824,898831440,4294967296,525568,5154943010,34359738368,33563273]

theorem envBound24871 : H12AffineFastState.Bounded env24871 := by
  intro p hp
  have h : env24871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24870_24871 : H12AffineEnvironment.transform 32 525568 env24870 = env24871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 32 525568 env24870 == env24871) = true)

def env24872 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,33554432,67108864,134217728,268435456,536870912,1073741824,897815632,4294967296,525568,5154943010,34359738368,33563273]

theorem envBound24872 : H12AffineFastState.Bounded env24872 := by
  intro p hp
  have h : env24872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24871_24872 : H12AffineEnvironment.transform 19 32768 env24871 = env24872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 19 32768 env24871 == env24872) = true)

theorem identity24872 : scanCanonicalize (H12AffineFastState.compose env24872 (packedSelected [4,6,7,9,14,16,20,25,27,35] rootPS)) = affineNative (2^(24+1) ^^^ 8329) := by decide +kernel

theorem selectedBound24872 : packedSelected [4,6,7,9,14,16,20,25,27,35] rootPS < 2^1333 := by decide +kernel

def env24873 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,8329,67108864,134217728,268435456,536870912,1073741824,897815632,4294967296,525568,5121380523,34359738368,512]

theorem envBound24873 : H12AffineFastState.Bounded env24873 := by
  intro p hp
  have h : env24873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24872_24873 : H12AffineEnvironment.transform 24 8329 env24872 = env24873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8329 env24872 == env24873) = true)

theorem identity24873 : scanCanonicalize (H12AffineFastState.compose env24873 (packedSelected [6,25] rootPS)) = affineNative (2^(29+1) ^^^ 956700811) := by decide +kernel

theorem selectedBound24873 : packedSelected [6,25] rootPS < 2^1333 := by decide +kernel

def env24874 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,8329,67108864,134217728,268435456,536870912,956700811,897815632,4294967296,525568,5121380523,34359738368,512]

theorem envBound24874 : H12AffineFastState.Bounded env24874 := by
  intro p hp
  have h : env24874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24873_24874 : H12AffineEnvironment.transform 29 956700811 env24873 = env24874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 956700811 env24873 == env24874) = true)

theorem identity24874 : scanCanonicalize (H12AffineFastState.compose env24874 (packedSelected [3,4,9,10,14,16,24,26] rootPS)) = affineNative (2^(34+1) ^^^ 4632740116) := by decide +kernel

theorem selectedBound24874 : packedSelected [3,4,9,10,14,16,24,26] rootPS < 2^1333 := by decide +kernel

def env24875 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,8329,67108864,134217728,268435456,536870912,956700811,897815632,4294967296,525568,5121380523,4632740116,512]

theorem envBound24875 : H12AffineFastState.Bounded env24875 := by
  intro p hp
  have h : env24875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24874_24875 : H12AffineEnvironment.transform 34 4632740116 env24874 = env24875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 4632740116 env24874 == env24875) = true)

theorem identity24875 : scanCanonicalize (H12AffineFastState.compose env24875 (packedSelected [1,4,9,14,16,19,28,31] rootPS)) = affineNative (2^(26+1) ^^^ 21331969) := by decide +kernel

theorem selectedBound24875 : packedSelected [1,4,9,14,16,19,28,31] rootPS < 2^1333 := by decide +kernel

def env24876 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,8329,67108864,21331969,268435456,536870912,809736330,897815632,4294967296,525568,5121380523,4632740116,512]

theorem envBound24876 : H12AffineFastState.Bounded env24876 := by
  intro p hp
  have h : env24876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24875_24876 : H12AffineEnvironment.transform 26 21331969 env24875 = env24876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 21331969 env24875 == env24876) = true)

theorem identity24876 : scanCanonicalize (H12AffineFastState.compose env24876 (packedSelected [0,1,3,5,7,8,9,10,14,19,20,22] rootPS)) = affineNative (2^(31+1) ^^^ 610915515) := by decide +kernel

theorem selectedBound24876 : packedSelected [0,1,3,5,7,8,9,10,14,19,20,22] rootPS < 2^1333 := by decide +kernel

def env24877 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,8329,67108864,21331969,268435456,536870912,809736330,897815632,610915515,525568,355189776,810276271,512]

theorem envBound24877 : H12AffineFastState.Bounded env24877 := by
  intro p hp
  have h : env24877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24876_24877 : H12AffineEnvironment.transform 31 610915515 env24876 = env24877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 610915515 env24876 == env24877) = true)

theorem identity24877 : scanCanonicalize (H12AffineFastState.compose env24877 (packedSelected [1,3,4,5,8,9,10,12,13,14,15,16,17,19,38,41] rootPS)) = affineNative (2^(28+1) ^^^ 268570624) := by decide +kernel

theorem selectedBound24877 : packedSelected [1,3,4,5,8,9,10,12,13,14,15,16,17,19,38,41] rootPS < 2^1333 := by decide +kernel

def env24878 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,8329,67108864,21331969,268435456,268570624,4294794,92374096,342607035,525568,355189776,4834735,512]

theorem envBound24878 : H12AffineFastState.Bounded env24878 := by
  intro p hp
  have h : env24878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24877_24878 : H12AffineEnvironment.transform 28 268570624 env24877 = env24878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 28 268570624 env24877 == env24878) = true)

theorem identity24878 : scanCanonicalize (H12AffineFastState.compose env24878 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(27+1) ^^^ 90850491) := by decide +kernel

theorem selectedBound24878 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env24879 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,8329,67108864,21331969,90850491,90723515,4294794,92374096,16875520,525568,4292779,4834735,512]

theorem envBound24879 : H12AffineFastState.Bounded env24879 := by
  intro p hp
  have h : env24879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24878_24879 : H12AffineEnvironment.transform 27 90850491 env24878 = env24879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 90850491 env24878 == env24879) = true)

theorem identity24879 : scanCanonicalize (H12AffineFastState.compose env24879 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(23+1) ^^^ 4194475) := by decide +kernel

theorem selectedBound24879 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env24880 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,4194475,8329,67108864,360618,69878800,69751824,4294794,79791355,4292779,525568,4292779,4834735,512]

theorem envBound24880 : H12AffineFastState.Bounded env24880 := by
  intro p hp
  have h : env24880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24879_24880 : H12AffineEnvironment.transform 23 4194475 env24879 = env24880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 4194475 env24879 == env24880) = true)

def env24881 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,305160,8388608,305315,8329,67108864,360618,69878800,69751824,336002,75836659,338083,525568,338083,880039,512]

theorem envBound24881 : H12AffineFastState.Bounded env24881 := by
  intro p hp
  have h : env24881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24880_24881 : H12AffineEnvironment.transform 21 305160 env24880 = env24881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 305160 env24880 == env24881) = true)

def env24882 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,305161,8388608,305314,8329,67108864,360618,69878800,69751824,336003,75836658,338082,525568,338082,880038,512]

theorem envBound24882 : H12AffineFastState.Bounded env24882 := by
  intro p hp
  have h : env24882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24880_24882 : H12AffineEnvironment.transform 21 305161 env24880 = env24882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 305161 env24880 == env24882) = true)

theorem identity24882 : scanCanonicalize (H12AffineFastState.compose env24882 (packedSelected [4,9,11,14,18,20,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 43048) := by decide +kernel

theorem selectedBound24882 : packedSelected [4,9,11,14,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env24883 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,43048,524288,32768,2097152,33,8388608,138,8329,67108864,75906,69878800,69751824,100523,75597018,98442,525568,98442,640398,512]

theorem envBound24883 : H12AffineFastState.Bounded env24883 := by
  intro p hp
  have h : env24883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24882_24883 : H12AffineEnvironment.transform 17 43048 env24882 = env24883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43048 env24882 == env24883) = true)

theorem identity24883 : scanCanonicalize (H12AffineFastState.compose env24883 (packedSelected [0,7,11,18] rootPS)) = affineNative (2^(25+1) ^^^ 10503029) := by decide +kernel

theorem selectedBound24883 : packedSelected [0,7,11,18] rootPS < 2^1333 := by decide +kernel

def env24884 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,43048,524288,32768,2097152,33,8388608,138,8329,10503029,75906,9045861,8918885,100523,2213807,98442,525568,98442,640398,512]

theorem envBound24884 : H12AffineFastState.Bounded env24884 := by
  intro p hp
  have h : env24884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24883_24884 : H12AffineEnvironment.transform 25 10503029 env24883 = env24884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 10503029 env24883 == env24884) = true)

def env24885 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,32768,65536,131072,43048,524288,32768,2097152,33,8388608,138,8329,10502793,75906,9045657,8918681,100523,2213459,98442,525564,98442,640114,512]

theorem envBound24885 : H12AffineFastState.Bounded env24885 := by
  intro p hp
  have h : env24885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24884_24885 : H12AffineEnvironment.transform 7 252 env24884 = env24885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env24884 == env24885) = true)

def env24886 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,32768,65536,131072,43048,524288,32768,2097152,33,2680032,138,8329,566889,75906,2286201,2159225,100523,2213459,98442,525564,98442,640114,512]

theorem envBound24886 : H12AffineFastState.Bounded env24886 := by
  intro p hp
  have h : env24886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24885_24886 : H12AffineEnvironment.transform 22 2680032 env24885 = env24886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2680032 env24885 == env24886) = true)

theorem identity24886 : scanCanonicalize (H12AffineFastState.compose env24886 (packedSelected [0,1,2,5,6,10,12,13,14,15,17,20,27] rootPS)) = affineNative (2^(20+1) ^^^ 102020) := by decide +kernel

theorem selectedBound24886 : packedSelected [0,1,2,5,6,10,12,13,14,15,17,20,27] rootPS < 2^1333 := by decide +kernel

def env24887 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,32768,65536,131072,43048,524288,32768,102020,33,617060,138,8329,566889,75906,224509,97533,100523,18647,98442,525564,98442,640114,512]

theorem envBound24887 : H12AffineFastState.Bounded env24887 := by
  intro p hp
  have h : env24887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24886_24887 : H12AffineEnvironment.transform 20 102020 env24886 = env24887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 102020 env24886 == env24887) = true)

def env24888 : List Nat := [2,4,8,16,32,64,128,252,136,1024,2048,4096,8192,16384,32768,65536,131072,43048,524288,32768,101388,33,616684,138,8329,566497,75906,224509,97533,100523,18647,98442,525564,98442,640114,136]

theorem envBound24888 : H12AffineFastState.Bounded env24888 := by
  intro p hp
  have h : env24888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24887_24888 : H12AffineEnvironment.transform 8 136 env24887 = env24888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env24887 == env24888) = true)

theorem identity24888 : scanCanonicalize (H12AffineFastState.compose env24888 (packedSelected [4,9,13,14,17,20] rootPS)) = affineNative (2^(18+1) ^^^ 42225) := by decide +kernel

theorem selectedBound24888 : packedSelected [4,9,13,14,17,20] rootPS < 2^1333 := by decide +kernel

def env24889 : List Nat := [2,4,8,16,32,64,128,252,136,1024,2048,4096,8192,16384,32768,65536,131072,43048,42225,32768,101388,33,117789,138,8329,16,75906,224509,97533,100523,18647,98442,40973,98442,90243,136]

theorem envBound24889 : H12AffineFastState.Bounded env24889 := by
  intro p hp
  have h : env24889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24888_24889 : H12AffineEnvironment.transform 18 42225 env24888 = env24889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 42225 env24888 == env24889) = true)

theorem identity24889 : scanCanonicalize (H12AffineFastState.compose env24889 (packedSelected [1,5,10,13] rootPS)) = affineNative (2^(15+1) ^^^ 52317) := by decide +kernel

theorem selectedBound24889 : packedSelected [1,5,10,13] rootPS < 2^1333 := by decide +kernel

def env24890 : List Nat := [2,4,8,16,32,64,128,252,136,1024,2048,4096,8192,16384,32768,52317,131072,43048,42225,32768,16465,33,64,138,8329,16,58591,172192,45216,17654,18647,19671,40973,19671,44254,136]

theorem envBound24890 : H12AffineFastState.Bounded env24890 := by
  intro p hp
  have h : env24890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24889_24890 : H12AffineEnvironment.transform 15 52317 env24889 = env24890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 52317 env24889 == env24890) = true)

theorem identity24890 : scanCanonicalize (H12AffineFastState.compose env24890 (packedSelected [1,2,4,5,6,7] rootPS)) = affineNative (2^(14+1) ^^^ 2264) := by decide +kernel

theorem selectedBound24890 : packedSelected [1,2,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env24891 : List Nat := [2,4,8,16,32,64,128,252,136,1024,2048,4096,8192,16384,2264,17541,131072,8432,11305,2264,16465,33,64,138,8329,16,27655,141432,14456,17654,18647,19671,10453,19671,9222,136]

theorem envBound24891 : H12AffineFastState.Bounded env24891 := by
  intro p hp
  have h : env24891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24890_24891 : H12AffineEnvironment.transform 14 2264 env24890 = env24891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2264 env24890 == env24891) = true)

theorem identity24891 : scanCanonicalize (H12AffineFastState.compose env24891 (packedSelected [0,2,3,4,6,8] rootPS)) = affineNative (2^(16+1) ^^^ 31773) := by decide +kernel

theorem selectedBound24891 : packedSelected [0,2,3,4,6,8] rootPS < 2^1333 := by decide +kernel

def env24892 : List Nat := [2,4,8,16,32,64,128,252,136,1024,2048,4096,8192,16384,2264,17541,31773,8432,11305,2264,16465,33,64,138,8329,16,27655,21605,14456,17654,18647,19671,10453,19671,9222,136]

theorem envBound24892 : H12AffineFastState.Bounded env24892 := by
  intro p hp
  have h : env24892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24891_24892 : H12AffineEnvironment.transform 16 31773 env24891 = env24892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 31773 env24891 == env24892) = true)

theorem identity24892 : scanCanonicalize (H12AffineFastState.compose env24892 (packedSelected [3,5,11] rootPS)) = affineNative (2^(12+1) ^^^ 7364) := by decide +kernel

theorem selectedBound24892 : packedSelected [3,5,11] rootPS < 2^1333 := by decide +kernel

def env24893 : List Nat := [2,4,8,16,32,64,128,252,136,1024,2048,4096,7364,16384,2264,17541,16601,7220,4333,2264,16465,33,64,138,7245,16,20675,21605,1212,17654,18647,19671,5137,19671,6338,136]

theorem envBound24893 : H12AffineFastState.Bounded env24893 := by
  intro p hp
  have h : env24893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24892_24893 : H12AffineEnvironment.transform 12 7364 env24892 = env24893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7364 env24892 == env24893) = true)

def env24894 : List Nat := [2,4,8,16,32,64,128,252,136,1024,2048,4096,7364,4312,2264,5213,4097,7220,4333,2264,4233,33,64,138,7245,16,27,1213,1212,5166,6159,7183,5137,7183,6338,136]

theorem envBound24894 : H12AffineFastState.Bounded env24894 := by
  intro p hp
  have h : env24894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24893_24894 : H12AffineEnvironment.transform 13 4312 env24893 = env24894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4312 env24893 == env24894) = true)

theorem identity24894 : scanCanonicalize (H12AffineFastState.compose env24894 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound24894 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env24895 : List Nat := [2,4,8,16,32,64,24,100,16,1024,2048,4096,7260,4160,2112,5213,4097,7220,4213,2112,4113,33,64,18,7245,16,27,1061,1060,5166,6159,7183,5137,7183,6234,16]

theorem envBound24895 : H12AffineFastState.Bounded env24895 := by
  intro p hp
  have h : env24895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24894_24895 : H12AffineEnvironment.transform 6 24 env24894 = env24895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env24894 == env24895) = true)

theorem identity24895 : scanCanonicalize (H12AffineFastState.compose env24895 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound24895 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env24896 : List Nat := [2,4,8,16,32,64,24,100,16,1024,43,4096,5239,4160,107,5213,4097,5151,4213,107,4113,33,64,18,5222,16,27,1061,1060,5166,4132,5156,5137,5156,4209,16]

theorem envBound24896 : H12AffineFastState.Bounded env24896 := by
  intro p hp
  have h : env24896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24895_24896 : H12AffineEnvironment.transform 10 43 env24895 = env24896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env24895 == env24896) = true)

def env24897 : List Nat := [2,4,8,16,32,64,128,252,136,1024,2048,4096,7364,4313,2264,5212,4096,7220,4333,2264,4232,33,64,138,7245,16,26,1212,1212,5167,6158,7182,5137,7182,6338,136]

theorem envBound24897 : H12AffineFastState.Bounded env24897 := by
  intro p hp
  have h : env24897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24893_24897 : H12AffineEnvironment.transform 13 4313 env24893 = env24897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4313 env24893 == env24897) = true)

theorem identity24897 : scanCanonicalize (H12AffineFastState.compose env24897 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 3134) := by decide +kernel

theorem selectedBound24897 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env24898 : List Nat := [2,4,8,16,32,64,128,252,136,1024,2048,3134,250,3303,2264,2146,3134,10,3283,2264,3254,33,64,138,115,16,26,1212,1212,2065,1072,48,2095,48,1276,136]

theorem envBound24898 : H12AffineFastState.Bounded env24898 := by
  intro p hp
  have h : env24898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24897_24898 : H12AffineEnvironment.transform 11 3134 env24897 = env24898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3134 env24897 == env24898) = true)

theorem identity24898 : scanCanonicalize (H12AffineFastState.compose env24898 (packedSelected [6] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound24898 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env24899 : List Nat := [2,4,8,16,32,64,41,85,33,1024,2048,3134,83,3150,2161,2146,3134,10,3194,2161,3103,33,64,35,115,16,26,1045,1045,2065,1072,48,2095,48,1109,33]

theorem envBound24899 : H12AffineFastState.Bounded env24899 := by
  intro p hp
  have h : env24899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24898_24899 : H12AffineEnvironment.transform 6 41 env24898 = env24899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env24898 == env24899) = true)

def env24900 : List Nat := [2,4,8,16,32,64,128,252,137,1024,2048,4096,8192,16384,32768,65536,131072,43048,524288,32768,101389,33,616685,138,8329,566496,75906,224509,97533,100523,18647,98442,525564,98442,640114,137]

theorem envBound24900 : H12AffineFastState.Bounded env24900 := by
  intro p hp
  have h : env24900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24887_24900 : H12AffineEnvironment.transform 8 137 env24887 = env24900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env24887 == env24900) = true)

theorem identity24900 : scanCanonicalize (H12AffineFastState.compose env24900 (packedSelected [4,9,13,14,17,20] rootPS)) = affineNative (2^(18+1) ^^^ 92333) := by decide +kernel

theorem selectedBound24900 : packedSelected [4,9,13,14,17,20] rootPS < 2^1333 := by decide +kernel

def env24901 : List Nat := [2,4,8,16,32,64,128,252,137,1024,2048,4096,8192,16384,32768,65536,131072,43048,92333,32768,101389,33,64,138,8329,117837,75906,224509,97533,100523,18647,98442,93265,98442,44255,137]

theorem envBound24901 : H12AffineFastState.Bounded env24901 := by
  intro p hp
  have h : env24901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24900_24901 : H12AffineEnvironment.transform 18 92333 env24900 = env24901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 92333 env24900 == env24901) = true)

theorem identity24901 : scanCanonicalize (H12AffineFastState.compose env24901 (packedSelected [1,2,3,4,5,6,8,9,11,12] rootPS)) = affineNative (2^(16+1) ^^^ 82097) := by decide +kernel

theorem selectedBound24901 : packedSelected [1,2,3,4,5,6,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env24902 : List Nat := [2,4,8,16,32,64,128,252,137,1024,2048,4096,8192,16384,32768,65536,82097,43048,92333,32768,101389,33,64,138,8329,117837,75906,11340,97533,100523,18647,98442,93265,98442,44255,137]

theorem envBound24902 : H12AffineFastState.Bounded env24902 := by
  intro p hp
  have h : env24902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24901_24902 : H12AffineEnvironment.transform 16 82097 env24901 = env24902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82097 env24901 == env24902) = true)

theorem identity24902 : scanCanonicalize (H12AffineFastState.compose env24902 (packedSelected [1,5,10,17] rootPS)) = affineNative (2^(15+1) ^^^ 52317) := by decide +kernel

theorem selectedBound24902 : packedSelected [1,5,10,17] rootPS < 2^1333 := by decide +kernel

def env24903 : List Nat := [2,4,8,16,32,64,128,252,137,1024,2048,4096,8192,16384,32768,52317,36076,43048,42224,32768,16464,33,64,138,8329,16,58591,11340,45216,17654,18647,19671,40972,19671,44255,137]

theorem envBound24903 : H12AffineFastState.Bounded env24903 := by
  intro p hp
  have h : env24903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24902_24903 : H12AffineEnvironment.transform 15 52317 env24902 = env24903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 52317 env24902 == env24903) = true)

theorem identity24903 : scanCanonicalize (H12AffineFastState.compose env24903 (packedSelected [1,2,4,5,6,7] rootPS)) = affineNative (2^(12+1) ^^^ 5126) := by decide +kernel

theorem selectedBound24903 : packedSelected [1,2,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env24904 : List Nat := [2,4,8,16,32,64,128,252,137,1024,2048,4096,5126,16384,32768,52317,36076,39982,37110,32768,16464,33,64,138,5263,16,53465,6218,33958,17654,18647,19671,37898,19671,39129,137]

theorem envBound24904 : H12AffineFastState.Bounded env24904 := by
  intro p hp
  have h : env24904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24903_24904 : H12AffineEnvironment.transform 12 5126 env24903 = env24904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5126 env24903 == env24904) = true)

theorem identity24904 : scanCanonicalize (H12AffineFastState.compose env24904 (packedSelected [0,2,3,4,6,8] rootPS)) = affineNative (2^(14+1) ^^^ 17455) := by decide +kernel

theorem selectedBound24904 : packedSelected [0,2,3,4,6,8] rootPS < 2^1333 := by decide +kernel

def env24905 : List Nat := [2,4,8,16,32,64,128,252,137,1024,2048,4096,5126,16384,17455,2162,18627,22529,21721,17455,16464,33,64,138,5263,16,5366,6218,16521,17654,18647,19671,20517,19671,23798,137]

theorem envBound24905 : H12AffineFastState.Bounded env24905 := by
  intro p hp
  have h : env24905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24904_24905 : H12AffineEnvironment.transform 14 17455 env24904 = env24905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 17455 env24904 == env24905) = true)

def env24906 : List Nat := [2,4,8,16,32,64,128,252,137,1024,2048,4096,5126,4232,5287,2162,6219,2185,1105,5287,4312,33,64,138,5263,16,5366,6218,4097,5246,6239,7263,173,7263,3198,137]

theorem envBound24906 : H12AffineFastState.Bounded env24906 := by
  intro p hp
  have h : env24906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24905_24906 : H12AffineEnvironment.transform 13 4232 env24905 = env24906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4232 env24905 == env24906) = true)

theorem identity24906 : scanCanonicalize (H12AffineFastState.compose env24906 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound24906 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env24907 : List Nat := [2,4,8,16,32,64,128,252,137,1024,42,4096,5126,4232,5287,88,4193,163,1105,5287,4312,33,64,138,5263,16,5366,4192,4097,5246,4213,5237,173,5237,1108,137]

theorem envBound24907 : H12AffineFastState.Bounded env24907 := by
  intro p hp
  have h : env24907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24906_24907 : H12AffineEnvironment.transform 10 42 env24906 = env24907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env24906 == env24907) = true)

theorem identity24907 : scanCanonicalize (H12AffineFastState.compose env24907 (packedSelected [6] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound24907 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env24908 : List Nat := [2,4,8,16,32,32,128,156,137,1024,42,4096,5126,4232,5287,56,4097,163,1073,5287,4280,33,32,138,5263,16,5270,4096,4097,5150,4117,5141,173,5141,1076,137]

theorem envBound24908 : H12AffineFastState.Bounded env24908 := by
  intro p hp
  have h : env24908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24907_24908 : H12AffineEnvironment.transform 5 32 env24907 = env24908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env24907 == env24908) = true)

theorem identity24908 : scanCanonicalize (H12AffineFastState.compose env24908 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 1045) := by decide +kernel

theorem selectedBound24908 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env24909 : List Nat := [2,4,8,16,32,32,128,156,137,1024,42,1045,19,1181,178,56,1044,163,1073,178,1197,33,32,138,154,16,131,1045,1044,11,1024,0,173,0,1076,137]

theorem envBound24909 : H12AffineFastState.Bounded env24909 := by
  intro p hp
  have h : env24909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24908_24909 : H12AffineEnvironment.transform 11 1045 env24908 = env24909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1045 env24908 == env24909) = true)

theorem identity24909 : scanCanonicalize (H12AffineFastState.compose env24909 (packedSelected [0,2] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound24909 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env24910 : List Nat := [2,4,8,16,32,32,41,53,32,1024,42,1045,19,1076,27,56,1044,10,1073,27,1028,33,32,35,51,16,42,1045,1044,11,1024,0,4,0,1076,32]

theorem envBound24910 : H12AffineFastState.Bounded env24910 := by
  intro p hp
  have h : env24910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24909_24910 : H12AffineEnvironment.transform 6 41 env24909 = env24910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env24909 == env24910) = true)

theorem identity24910 : scanCanonicalize (H12AffineFastState.compose env24910 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound24910 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24911 : List Nat := [2,4,8,0,32,32,41,37,32,1024,42,1029,3,1060,11,40,1028,10,1057,11,1028,33,32,35,35,0,42,1029,1028,11,1024,0,4,0,1060,32]

theorem envBound24911 : H12AffineFastState.Bounded env24911 := by
  intro p hp
  have h : env24911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24910_24911 : H12AffineEnvironment.transform 3 0 env24910 = env24911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env24910 == env24911) = true)

theorem identity24911 : scanCanonicalize (H12AffineFastState.compose env24911 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 43) := by decide +kernel

theorem selectedBound24911 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24912 : List Nat := [2,4,8,0,32,32,41,37,32,43,42,46,3,15,11,40,47,10,10,11,47,33,32,35,35,0,42,46,47,11,43,0,4,0,15,32]

theorem envBound24912 : H12AffineFastState.Bounded env24912 := by
  intro p hp
  have h : env24912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24911_24912 : H12AffineEnvironment.transform 9 43 env24911 = env24912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 43 env24911 == env24912) = true)

theorem identity24912 : scanCanonicalize (H12AffineFastState.compose env24912 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound24912 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env24913 : List Nat := [2,4,8,0,1,1,8,4,1,10,11,15,3,15,11,9,14,10,10,11,14,0,1,2,2,0,11,15,14,11,10,0,4,0,15,1]

theorem envBound24913 : H12AffineFastState.Bounded env24913 := by
  intro p hp
  have h : env24913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24912_24913 : H12AffineEnvironment.transform 4 1 env24912 = env24913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env24912 == env24913) = true)

def leafEnv24913 : List Nat := [2,4,8,0,1,1,8,4,1,10,11,15,3,15,11,9,14,10,10,11,14,0,1,2,10,2,1,0,11,15,14,11,10,0,4,0,4,8,15,1,0,14,1]

def active24913 : List Nat := [0,1,2]

def tree24913 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24913 : H12WitnessSearch.Good tree24913 := H12GlobalWitnessIndex.good

theorem leafIdentity24913 : H12AffineFastState.composeSystem env24913 rootObs = leafEnv24913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24913 rootObs == leafEnv24913) = true)

theorem terminalChecked24913 : H12PackedTerminal.terminalCheckFast leafEnv24913 active24913 tree24913 = true := by decide +kernel

def env24914 : List Nat := [2,4,8,16,32,64,128,252,137,1024,2048,4096,5126,4233,5286,2162,6218,2184,1104,5286,4313,33,64,138,5263,16,5366,6218,4096,5247,6238,7262,172,7262,3199,137]

theorem envBound24914 : H12AffineFastState.Bounded env24914 := by
  intro p hp
  have h : env24914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24905_24914 : H12AffineEnvironment.transform 13 4233 env24905 = env24914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4233 env24905 == env24914) = true)

theorem identity24914 : scanCanonicalize (H12AffineFastState.compose env24914 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 1245) := by decide +kernel

theorem selectedBound24914 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env24915 : List Nat := [2,4,8,16,32,64,128,252,137,1024,2048,1245,219,1108,123,2162,3223,2184,1104,123,1028,33,64,138,82,16,43,3223,1245,162,3203,2179,172,2179,3199,137]

theorem envBound24915 : H12AffineFastState.Bounded env24915 := by
  intro p hp
  have h : env24915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24914_24915 : H12AffineEnvironment.transform 11 1245 env24914 = env24915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1245 env24914 == env24915) = true)

theorem identity24915 : scanCanonicalize (H12AffineFastState.compose env24915 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound24915 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env24916 : List Nat := [2,4,8,16,32,64,128,252,137,1024,43,1245,219,1108,123,89,1212,163,1104,123,1028,33,64,138,82,16,43,1212,1245,162,1192,168,172,168,1108,137]

theorem envBound24916 : H12AffineFastState.Bounded env24916 := by
  intro p hp
  have h : env24916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24915_24916 : H12AffineEnvironment.transform 10 43 env24915 = env24916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env24915 == env24916) = true)

theorem identity24916 : scanCanonicalize (H12AffineFastState.compose env24916 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound24916 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24917 : List Nat := [2,4,8,1,32,64,128,237,137,1024,43,1228,202,1093,106,72,1197,163,1089,106,1028,33,64,138,67,1,43,1197,1228,162,1192,168,172,168,1093,137]

theorem envBound24917 : H12AffineFastState.Bounded env24917 := by
  intro p hp
  have h : env24917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24916_24917 : H12AffineEnvironment.transform 3 1 env24916 = env24917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env24916 == env24917) = true)

theorem identity24917 : scanCanonicalize (H12AffineFastState.compose env24917 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 72) := by decide +kernel

theorem selectedBound24917 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24918 : List Nat := [2,4,8,1,32,64,72,37,65,1024,43,1028,2,1093,106,72,1125,107,1089,106,1028,33,64,66,67,1,43,1125,1028,106,1120,96,100,96,1093,65]

theorem envBound24918 : H12AffineFastState.Bounded env24918 := by
  intro p hp
  have h : env24918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24917_24918 : H12AffineEnvironment.transform 6 72 env24917 = env24918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 72 env24917 == env24918) = true)

theorem identity24918 : scanCanonicalize (H12AffineFastState.compose env24918 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound24918 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24919 : List Nat := [2,4,8,1,32,32,40,37,33,1024,43,1028,2,1061,10,40,1029,11,1057,10,1028,33,32,34,35,1,43,1029,1028,10,1024,0,4,0,1061,33]

theorem envBound24919 : H12AffineFastState.Bounded env24919 := by
  intro p hp
  have h : env24919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24918_24919 : H12AffineEnvironment.transform 5 32 env24918 = env24919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env24918 == env24919) = true)

theorem identity24919 : scanCanonicalize (H12AffineFastState.compose env24919 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 43) := by decide +kernel

theorem selectedBound24919 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24920 : List Nat := [2,4,8,1,32,32,40,37,33,43,43,47,2,14,10,40,46,11,10,10,47,33,32,34,35,1,43,46,47,10,43,0,4,0,14,33]

theorem envBound24920 : H12AffineFastState.Bounded env24920 := by
  intro p hp
  have h : env24920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24919_24920 : H12AffineEnvironment.transform 9 43 env24919 = env24920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 43 env24919 == env24920) = true)

theorem identity24920 : scanCanonicalize (H12AffineFastState.compose env24920 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound24920 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env24921 : List Nat := [2,4,8,1,1,1,9,4,0,10,10,14,2,14,10,9,15,11,10,10,14,0,1,3,2,1,10,15,14,10,10,0,4,0,14,0]

theorem envBound24921 : H12AffineFastState.Bounded env24921 := by
  intro p hp
  have h : env24921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24920_24921 : H12AffineEnvironment.transform 4 1 env24920 = env24921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env24920 == env24921) = true)

def leafEnv24921 : List Nat := [2,4,8,1,1,1,9,4,0,10,10,14,2,14,10,9,15,11,10,10,14,0,1,3,10,2,1,1,10,15,14,10,10,0,4,0,4,9,14,0,0,14,1]

def active24921 : List Nat := [0,1,2]

def tree24921 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24921 : H12WitnessSearch.Good tree24921 := H12GlobalWitnessIndex.good

theorem leafIdentity24921 : H12AffineFastState.composeSystem env24921 rootObs = leafEnv24921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24921 rootObs == leafEnv24921) = true)

theorem terminalChecked24921 : H12PackedTerminal.terminalCheckFast leafEnv24921 active24921 tree24921 = true := by decide +kernel

def env24922 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,32768,65536,131072,43048,524288,32768,2097152,33,2680033,138,8329,566888,75906,2286200,2159224,100523,2213459,98442,525564,98442,640114,512]

theorem envBound24922 : H12AffineFastState.Bounded env24922 := by
  intro p hp
  have h : env24922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24885_24922 : H12AffineEnvironment.transform 22 2680033 env24885 = env24922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2680033 env24885 == env24922) = true)

theorem identity24922 : scanCanonicalize (H12AffineFastState.compose env24922 (packedSelected [0,1,2,5,6,10,12,13,14,15,17,20,27] rootPS)) = affineNative (2^(20+1) ^^^ 101388) := by decide +kernel

theorem selectedBound24922 : packedSelected [0,1,2,5,6,10,12,13,14,15,17,20,27] rootPS < 2^1333 := by decide +kernel

def env24923 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,32768,65536,131072,43048,524288,32768,101388,33,616685,138,8329,566888,75906,224884,97908,100523,19039,98442,525564,98442,640114,512]

theorem envBound24923 : H12AffineFastState.Bounded env24923 := by
  intro p hp
  have h : env24923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24922_24923 : H12AffineEnvironment.transform 20 101388 env24922 = env24923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 101388 env24922 == env24923) = true)

def env24924 : List Nat := [2,4,8,16,32,64,128,252,136,1024,2048,4096,8192,16384,32768,65536,131072,43048,524288,32768,101388,33,616685,138,8329,566496,75906,224508,97532,100523,18647,98442,525564,98442,640114,136]

theorem envBound24924 : H12AffineFastState.Bounded env24924 := by
  intro p hp
  have h : env24924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24923_24924 : H12AffineEnvironment.transform 8 136 env24923 = env24924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env24923 == env24924) = true)

theorem identity24924 : scanCanonicalize (H12AffineFastState.compose env24924 (packedSelected [4,9,13,14,17,20] rootPS)) = affineNative (2^(18+1) ^^^ 92333) := by decide +kernel

theorem selectedBound24924 : packedSelected [4,9,13,14,17,20] rootPS < 2^1333 := by decide +kernel

def env24925 : List Nat := [2,4,8,16,32,64,128,252,136,1024,2048,4096,8192,16384,32768,65536,131072,43048,92333,32768,101388,33,64,138,8329,117837,75906,224508,97532,100523,18647,98442,93265,98442,44255,136]

theorem envBound24925 : H12AffineFastState.Bounded env24925 := by
  intro p hp
  have h : env24925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24924_24925 : H12AffineEnvironment.transform 18 92333 env24924 = env24925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 92333 env24924 == env24925) = true)

theorem identity24925 : scanCanonicalize (H12AffineFastState.compose env24925 (packedSelected [1,2,3,4,5,6,8,9,11,12] rootPS)) = affineNative (2^(16+1) ^^^ 36077) := by decide +kernel

theorem selectedBound24925 : packedSelected [1,2,3,4,5,6,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env24926 : List Nat := [2,4,8,16,32,64,128,252,136,1024,2048,4096,8192,16384,32768,65536,36077,43048,92333,32768,101388,33,64,138,8329,117837,75906,122897,97532,100523,18647,98442,93265,98442,44255,136]

theorem envBound24926 : H12AffineFastState.Bounded env24926 := by
  intro p hp
  have h : env24926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24925_24926 : H12AffineEnvironment.transform 16 36077 env24925 = env24926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 36077 env24925 == env24926) = true)

theorem identity24926 : scanCanonicalize (H12AffineFastState.compose env24926 (packedSelected [1,5,10,17] rootPS)) = affineNative (2^(15+1) ^^^ 52317) := by decide +kernel

theorem selectedBound24926 : packedSelected [1,5,10,17] rootPS < 2^1333 := by decide +kernel

def env24927 : List Nat := [2,4,8,16,32,64,128,252,136,1024,2048,4096,8192,16384,32768,52317,36077,43048,42224,32768,16465,33,64,138,8329,16,58591,11340,45217,17654,18647,19671,40972,19671,44255,136]

theorem envBound24927 : H12AffineFastState.Bounded env24927 := by
  intro p hp
  have h : env24927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24926_24927 : H12AffineEnvironment.transform 15 52317 env24926 = env24927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 52317 env24926 == env24927) = true)

theorem identity24927 : scanCanonicalize (H12AffineFastState.compose env24927 (packedSelected [1,2,4,5,6,7] rootPS)) = affineNative (2^(12+1) ^^^ 5127) := by decide +kernel

theorem selectedBound24927 : packedSelected [1,2,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env24928 : List Nat := [2,4,8,16,32,64,128,252,136,1024,2048,4096,5127,16384,32768,52317,36077,39983,37111,32768,16465,33,64,138,5262,16,53464,6219,33958,17654,18647,19671,37899,19671,39128,136]

theorem envBound24928 : H12AffineFastState.Bounded env24928 := by
  intro p hp
  have h : env24928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24927_24928 : H12AffineEnvironment.transform 12 5127 env24927 = env24928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5127 env24927 == env24928) = true)

theorem identity24928 : scanCanonicalize (H12AffineFastState.compose env24928 (packedSelected [0,2,3,4,6,8] rootPS)) = affineNative (2^(14+1) ^^^ 17454) := by decide +kernel

theorem selectedBound24928 : packedSelected [0,2,3,4,6,8] rootPS < 2^1333 := by decide +kernel

def env24929 : List Nat := [2,4,8,16,32,64,128,252,136,1024,2048,4096,5127,16384,17454,2163,18627,22529,21721,17454,16465,33,64,138,5262,16,5366,6219,16520,17654,18647,19671,20517,19671,23798,136]

theorem envBound24929 : H12AffineFastState.Bounded env24929 := by
  intro p hp
  have h : env24929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24928_24929 : H12AffineEnvironment.transform 14 17454 env24928 = env24929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 17454 env24928 == env24929) = true)

def env24930 : List Nat := [2,4,8,16,32,64,128,252,136,1024,2048,4096,5127,4232,5286,2163,6219,2185,1105,5286,4313,33,64,138,5262,16,5366,6219,4096,5246,6239,7263,173,7263,3198,136]

theorem envBound24930 : H12AffineFastState.Bounded env24930 := by
  intro p hp
  have h : env24930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24929_24930 : H12AffineEnvironment.transform 13 4232 env24929 = env24930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4232 env24929 == env24930) = true)

theorem identity24930 : scanCanonicalize (H12AffineFastState.compose env24930 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 1244) := by decide +kernel

theorem selectedBound24930 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env24931 : List Nat := [2,4,8,16,32,64,128,252,136,1024,2048,1244,219,1108,122,2163,3223,2185,1105,122,1029,33,64,138,82,16,42,3223,1244,162,3203,2179,173,2179,3198,136]

theorem envBound24931 : H12AffineFastState.Bounded env24931 := by
  intro p hp
  have h : env24931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24930_24931 : H12AffineEnvironment.transform 11 1244 env24930 = env24931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1244 env24930 == env24931) = true)

def env24932 : List Nat := [2,4,8,16,32,64,128,252,136,1024,2048,4096,5127,4233,5287,2163,6218,2184,1104,5287,4312,33,64,138,5262,16,5366,6219,4097,5247,6238,7262,172,7262,3199,136]

theorem envBound24932 : H12AffineFastState.Bounded env24932 := by
  intro p hp
  have h : env24932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24929_24932 : H12AffineEnvironment.transform 13 4233 env24929 = env24932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4233 env24929 == env24932) = true)

theorem identity24932 : scanCanonicalize (H12AffineFastState.compose env24932 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound24932 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env24933 : List Nat := [2,4,8,16,32,64,128,252,136,1024,43,4096,5127,4233,5287,88,4193,163,1104,5287,4312,33,64,138,5262,16,5366,4192,4097,5247,4213,5237,172,5237,1108,136]

theorem envBound24933 : H12AffineFastState.Bounded env24933 := by
  intro p hp
  have h : env24933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24932_24933 : H12AffineEnvironment.transform 10 43 env24932 = env24933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env24932 == env24933) = true)

theorem identity24933 : scanCanonicalize (H12AffineFastState.compose env24933 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 1212) := by decide +kernel

theorem selectedBound24933 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env24934 : List Nat := [2,4,8,16,32,64,128,252,136,1024,43,1212,187,1077,27,88,1245,163,1104,27,1124,33,64,138,50,16,74,1244,1213,195,1225,201,172,201,1108,136]

theorem envBound24934 : H12AffineFastState.Bounded env24934 := by
  intro p hp
  have h : env24934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24933_24934 : H12AffineEnvironment.transform 11 1212 env24933 = env24934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1212 env24933 == env24934) = true)

theorem identity24934 : scanCanonicalize (H12AffineFastState.compose env24934 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 72) := by decide +kernel

theorem selectedBound24934 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env24935 : List Nat := [2,4,8,16,32,64,72,52,64,1024,43,1140,115,1077,27,88,1045,107,1104,27,1124,33,64,66,50,16,74,1044,1141,11,1025,1,100,1,1108,64]

theorem envBound24935 : H12AffineFastState.Bounded env24935 := by
  intro p hp
  have h : env24935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24934_24935 : H12AffineEnvironment.transform 6 72 env24934 = env24935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 72 env24934 == env24935) = true)

def env24936 : List Nat := [2,4,8,16,32,64,128,252,137,1024,2048,4096,8192,16384,32768,65536,131072,43048,524288,32768,101388,33,616685,138,8329,566497,75906,224509,97533,100523,18646,98442,525564,98442,640114,137]

theorem envBound24936 : H12AffineFastState.Bounded env24936 := by
  intro p hp
  have h : env24936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24923_24936 : H12AffineEnvironment.transform 8 137 env24923 = env24936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env24923 == env24936) = true)

theorem identity24936 : scanCanonicalize (H12AffineFastState.compose env24936 (packedSelected [4,9,13,14,17,20] rootPS)) = affineNative (2^(18+1) ^^^ 42225) := by decide +kernel

theorem selectedBound24936 : packedSelected [4,9,13,14,17,20] rootPS < 2^1333 := by decide +kernel

def env24937 : List Nat := [2,4,8,16,32,64,128,252,137,1024,2048,4096,8192,16384,32768,65536,131072,43048,42225,32768,101388,33,117788,138,8329,16,75906,224509,97533,100523,18646,98442,40973,98442,90243,137]

theorem envBound24937 : H12AffineFastState.Bounded env24937 := by
  intro p hp
  have h : env24937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24936_24937 : H12AffineEnvironment.transform 18 42225 env24936 = env24937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 42225 env24936 == env24937) = true)

theorem identity24937 : scanCanonicalize (H12AffineFastState.compose env24937 (packedSelected [1,5,10,13] rootPS)) = affineNative (2^(15+1) ^^^ 52316) := by decide +kernel

theorem selectedBound24937 : packedSelected [1,5,10,13] rootPS < 2^1333 := by decide +kernel

def env24938 : List Nat := [2,4,8,16,32,64,128,252,137,1024,2048,4096,8192,16384,32768,52316,131072,43048,42225,32768,16464,33,64,138,8329,16,58590,172193,45217,17655,18646,19670,40973,19670,44255,137]

theorem envBound24938 : H12AffineFastState.Bounded env24938 := by
  intro p hp
  have h : env24938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24937_24938 : H12AffineEnvironment.transform 15 52316 env24937 = env24938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 52316 env24937 == env24938) = true)

theorem identity24938 : scanCanonicalize (H12AffineFastState.compose env24938 (packedSelected [1,2,4,5,6,7] rootPS)) = affineNative (2^(14+1) ^^^ 2265) := by decide +kernel

theorem selectedBound24938 : packedSelected [1,2,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env24939 : List Nat := [2,4,8,16,32,64,128,252,137,1024,2048,4096,8192,16384,2265,17541,131072,8433,11304,2265,16464,33,64,138,8329,16,27655,141432,14456,17655,18646,19670,10452,19670,9222,137]

theorem envBound24939 : H12AffineFastState.Bounded env24939 := by
  intro p hp
  have h : env24939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24938_24939 : H12AffineEnvironment.transform 14 2265 env24938 = env24939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2265 env24938 == env24939) = true)

theorem identity24939 : scanCanonicalize (H12AffineFastState.compose env24939 (packedSelected [0,2,3,4,6,8] rootPS)) = affineNative (2^(16+1) ^^^ 31773) := by decide +kernel

theorem selectedBound24939 : packedSelected [0,2,3,4,6,8] rootPS < 2^1333 := by decide +kernel

def env24940 : List Nat := [2,4,8,16,32,64,128,252,137,1024,2048,4096,8192,16384,2265,17541,31773,8433,11304,2265,16464,33,64,138,8329,16,27655,21605,14456,17655,18646,19670,10452,19670,9222,137]

theorem envBound24940 : H12AffineFastState.Bounded env24940 := by
  intro p hp
  have h : env24940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24939_24940 : H12AffineEnvironment.transform 16 31773 env24939 = env24940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 31773 env24939 == env24940) = true)

theorem identity24940 : scanCanonicalize (H12AffineFastState.compose env24940 (packedSelected [3,5,11] rootPS)) = affineNative (2^(12+1) ^^^ 7364) := by decide +kernel

theorem selectedBound24940 : packedSelected [3,5,11] rootPS < 2^1333 := by decide +kernel

def env24941 : List Nat := [2,4,8,16,32,64,128,252,137,1024,2048,4096,7364,16384,2265,17541,16601,7221,4332,2265,16464,33,64,138,7245,16,20675,21605,1212,17655,18646,19670,5136,19670,6338,137]

theorem envBound24941 : H12AffineFastState.Bounded env24941 := by
  intro p hp
  have h : env24941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24940_24941 : H12AffineEnvironment.transform 12 7364 env24940 = env24941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7364 env24940 == env24941) = true)

def env24942 : List Nat := [2,4,8,16,32,64,128,252,137,1024,2048,4096,7364,4312,2265,5213,4097,7221,4332,2265,4232,33,64,138,7245,16,27,1213,1212,5167,6158,7182,5136,7182,6338,137]

theorem envBound24942 : H12AffineFastState.Bounded env24942 := by
  intro p hp
  have h : env24942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24941_24942 : H12AffineEnvironment.transform 13 4312 env24941 = env24942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4312 env24941 == env24942) = true)

theorem identity24942 : scanCanonicalize (H12AffineFastState.compose env24942 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 3134) := by decide +kernel

theorem selectedBound24942 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env24943 : List Nat := [2,4,8,16,32,64,128,252,137,1024,2048,3134,250,3302,2265,2147,3135,11,3282,2265,3254,33,64,138,115,16,27,1213,1212,2065,1072,48,2094,48,1276,137]

theorem envBound24943 : H12AffineFastState.Bounded env24943 := by
  intro p hp
  have h : env24943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24942_24943 : H12AffineEnvironment.transform 11 3134 env24942 = env24943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3134 env24942 == env24943) = true)

theorem identity24943 : scanCanonicalize (H12AffineFastState.compose env24943 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound24943 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env24944 : List Nat := [2,4,8,16,16,64,128,204,137,1024,2048,3086,202,3286,2265,2131,3087,11,3282,2265,3206,17,64,138,67,16,27,1165,1164,2065,1024,0,2078,0,1228,137]

theorem envBound24944 : H12AffineFastState.Bounded env24944 := by
  intro p hp
  have h : env24944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24943_24944 : H12AffineEnvironment.transform 4 16 env24943 = env24944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env24943 == env24944) = true)

theorem identity24944 : scanCanonicalize (H12AffineFastState.compose env24944 (packedSelected [0,2] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound24944 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env24945 : List Nat := [2,4,8,16,16,64,128,204,137,1024,26,1044,202,1228,195,73,1045,11,1224,195,1180,17,64,138,67,16,27,1165,1164,11,1024,0,4,0,1228,137]

theorem envBound24945 : H12AffineFastState.Bounded env24945 := by
  intro p hp
  have h : env24945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24944_24945 : H12AffineEnvironment.transform 10 26 env24944 = env24945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env24944 == env24945) = true)

theorem identity24945 : scanCanonicalize (H12AffineFastState.compose env24945 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound24945 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24946 : List Nat := [2,4,8,16,16,64,89,21,80,1024,26,1044,19,1045,26,73,1045,11,1041,26,1093,17,64,83,67,16,27,1108,1109,11,1024,0,4,0,1045,80]

theorem envBound24946 : H12AffineFastState.Bounded env24946 := by
  intro p hp
  have h : env24946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24945_24946 : H12AffineEnvironment.transform 6 89 env24945 = env24946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env24945 == env24946) = true)

theorem identity24946 : scanCanonicalize (H12AffineFastState.compose env24946 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 74) := by decide +kernel

theorem selectedBound24946 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24947 : List Nat := [2,4,8,16,16,64,89,21,80,74,26,94,19,95,26,73,95,11,91,26,15,17,64,83,67,16,27,30,31,11,74,0,4,0,95,80]

theorem envBound24947 : H12AffineFastState.Bounded env24947 := by
  intro p hp
  have h : env24947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24946_24947 : H12AffineEnvironment.transform 9 74 env24946 = env24947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 74 env24946 == env24947) = true)

theorem identity24947 : scanCanonicalize (H12AffineFastState.compose env24947 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound24947 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env24948 : List Nat := [2,4,8,1,1,64,72,4,65,74,11,79,2,78,11,73,78,11,74,11,15,0,64,66,67,1,10,15,14,11,74,0,4,0,78,65]

theorem envBound24948 : H12AffineFastState.Bounded env24948 := by
  intro p hp
  have h : env24948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24947_24948 : H12AffineEnvironment.transform 3 1 env24947 = env24948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env24947 == env24948) = true)

def leafEnv24948 : List Nat := [2,4,8,1,1,64,72,4,65,74,11,79,2,78,11,73,78,11,74,11,15,0,64,66,74,67,1,1,10,15,14,11,74,0,4,0,4,8,78,65,0,15,1]

def active24948 : List Nat := [0,1,2,5]

def tree24948 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24948 : H12WitnessSearch.Good tree24948 := H12GlobalWitnessIndex.good

theorem leafIdentity24948 : H12AffineFastState.composeSystem env24948 rootObs = leafEnv24948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24948 rootObs == leafEnv24948) = true)

theorem terminalChecked24948 : H12PackedTerminal.terminalCheckFast leafEnv24948 active24948 tree24948 = true := by decide +kernel

def env24949 : List Nat := [2,4,8,16,32,64,128,252,137,1024,2048,4096,7364,4313,2265,5212,4096,7221,4332,2265,4233,33,64,138,7245,16,26,1212,1212,5166,6159,7183,5136,7183,6338,137]

theorem envBound24949 : H12AffineFastState.Bounded env24949 := by
  intro p hp
  have h : env24949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24941_24949 : H12AffineEnvironment.transform 13 4313 env24941 = env24949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4313 env24941 == env24949) = true)

theorem identity24949 : scanCanonicalize (H12AffineFastState.compose env24949 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound24949 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env24950 : List Nat := [2,4,8,16,32,64,25,101,16,1024,2048,4096,7261,4160,2112,5212,4096,7221,4213,2112,4112,33,64,19,7245,16,26,1061,1061,5166,6159,7183,5136,7183,6235,16]

theorem envBound24950 : H12AffineFastState.Bounded env24950 := by
  intro p hp
  have h : env24950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24949_24950 : H12AffineEnvironment.transform 6 25 env24949 = env24950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env24949 == env24950) = true)

theorem identity24950 : scanCanonicalize (H12AffineFastState.compose env24950 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 1044) := by decide +kernel

theorem selectedBound24950 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env24951 : List Nat := [2,4,8,16,32,64,25,101,16,1024,2048,1044,2121,1108,2112,72,1044,2081,1121,2112,1028,33,64,19,2137,16,26,1061,1061,58,3099,2075,4,2075,3151,16]

theorem envBound24951 : H12AffineFastState.Bounded env24951 := by
  intro p hp
  have h : env24951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24950_24951 : H12AffineEnvironment.transform 11 1044 env24950 = env24951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1044 env24950 == env24951) = true)

def env24952 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,32768,65536,131072,43048,524288,32768,2097152,33,8388608,138,8329,10502792,75906,9045656,8918680,100523,2213458,98442,525565,98442,640115,512]

theorem envBound24952 : H12AffineFastState.Bounded env24952 := by
  intro p hp
  have h : env24952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24884_24952 : H12AffineEnvironment.transform 7 253 env24884 = env24952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env24884 == env24952) = true)

def env24953 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,32768,65536,131072,43048,524288,32768,2097152,33,2680032,138,8329,566888,75906,2286200,2159224,100523,2213458,98442,525565,98442,640115,512]

theorem envBound24953 : H12AffineFastState.Bounded env24953 := by
  intro p hp
  have h : env24953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24952_24953 : H12AffineEnvironment.transform 22 2680032 env24952 = env24953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2680032 env24952 == env24953) = true)

theorem identity24953 : scanCanonicalize (H12AffineFastState.compose env24953 (packedSelected [0,1,2,5,6,10,12,13,14,15,17,20,27] rootPS)) = affineNative (2^(20+1) ^^^ 44174) := by decide +kernel

theorem selectedBound24953 : packedSelected [0,1,2,5,6,10,12,13,14,15,17,20,27] rootPS < 2^1333 := by decide +kernel

def env24954 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,32768,65536,131072,43048,524288,32768,44174,33,542830,138,8329,566888,75906,151286,24310,100523,92892,98442,525565,98442,640115,512]

theorem envBound24954 : H12AffineFastState.Bounded env24954 := by
  intro p hp
  have h : env24954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24953_24954 : H12AffineEnvironment.transform 20 44174 env24953 = env24954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 44174 env24953 == env24954) = true)

def env24955 : List Nat := [2,4,8,16,32,64,128,253,136,1024,2048,4096,8192,16384,32768,65536,131072,43048,524288,32768,44174,33,542830,138,8329,566496,75906,150654,23678,100523,92244,98442,525565,98442,640115,136]

theorem envBound24955 : H12AffineFastState.Bounded env24955 := by
  intro p hp
  have h : env24955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24954_24955 : H12AffineEnvironment.transform 8 136 env24954 = env24955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env24954 == env24955) = true)

theorem identity24955 : scanCanonicalize (H12AffineFastState.compose env24955 (packedSelected [4,9,13,14,17,20] rootPS)) = affineNative (2^(18+1) ^^^ 42224) := by decide +kernel

theorem selectedBound24955 : packedSelected [4,9,13,14,17,20] rootPS < 2^1333 := by decide +kernel

def env24956 : List Nat := [2,4,8,16,32,64,128,253,136,1024,2048,4096,8192,16384,32768,65536,131072,43048,42224,32768,44174,33,60574,138,8329,16,75906,150654,23678,100523,92244,98442,40973,98442,90243,136]

theorem envBound24956 : H12AffineFastState.Bounded env24956 := by
  intro p hp
  have h : env24956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24955_24956 : H12AffineEnvironment.transform 18 42224 env24955 = env24956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 42224 env24955 == env24956) = true)

theorem identity24956 : scanCanonicalize (H12AffineFastState.compose env24956 (packedSelected [1,5,10,13] rootPS)) = affineNative (2^(14+1) ^^^ 27870) := by decide +kernel

theorem selectedBound24956 : packedSelected [1,5,10,13] rootPS < 2^1333 := by decide +kernel

def env24957 : List Nat := [2,4,8,16,32,64,128,253,136,1024,2048,4096,8192,16384,27870,65536,131072,17654,18478,27870,16464,33,64,138,8329,16,75906,150654,23678,91253,92244,93268,19667,93268,90243,136]

theorem envBound24957 : H12AffineFastState.Bounded env24957 := by
  intro p hp
  have h : env24957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24956_24957 : H12AffineEnvironment.transform 14 27870 env24956 = env24957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 27870 env24956 == env24957) = true)

theorem identity24957 : scanCanonicalize (H12AffineFastState.compose env24957 (packedSelected [1,2,4,5,6,7] rootPS)) = affineNative (2^(13+1) ^^^ 9222) := by decide +kernel

theorem selectedBound24957 : packedSelected [1,2,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env24958 : List Nat := [2,4,8,16,32,64,128,253,136,1024,2048,4096,8192,9222,2264,65536,131072,8432,11304,2264,9302,33,64,138,8329,16,75906,141432,14456,65651,68690,67666,10453,67666,66693,136]

theorem envBound24958 : H12AffineFastState.Bounded env24958 := by
  intro p hp
  have h : env24958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24957_24958 : H12AffineEnvironment.transform 13 9222 env24957 = env24958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 9222 env24957 == env24958) = true)

theorem identity24958 : scanCanonicalize (H12AffineFastState.compose env24958 (packedSelected [0,2,3,4,6,8] rootPS)) = affineNative (2^(16+1) ^^^ 6171) := by decide +kernel

theorem selectedBound24958 : packedSelected [0,2,3,4,6,8] rootPS < 2^1333 := by decide +kernel

def env24959 : List Nat := [2,4,8,16,32,64,128,253,136,1024,2048,4096,8192,9222,2264,65536,6171,8432,11304,2264,9302,33,64,138,8329,16,75906,12387,14456,65651,68690,67666,10453,67666,66693,136]

theorem envBound24959 : H12AffineFastState.Bounded env24959 := by
  intro p hp
  have h : env24959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24958_24959 : H12AffineEnvironment.transform 16 6171 env24958 = env24959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 6171 env24958 == env24959) = true)

theorem identity24959 : scanCanonicalize (H12AffineFastState.compose env24959 (packedSelected [3,5,11] rootPS)) = affineNative (2^(15+1) ^^^ 13374) := by decide +kernel

theorem selectedBound24959 : packedSelected [3,5,11] rootPS < 2^1333 := by decide +kernel

def env24960 : List Nat := [2,4,8,16,32,64,128,253,136,1024,2048,4096,8192,9222,2264,13374,6171,8432,11304,2264,9302,33,64,138,8329,16,7356,12387,14456,13389,14444,15468,10453,15468,12475,136]

theorem envBound24960 : H12AffineFastState.Bounded env24960 := by
  intro p hp
  have h : env24960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24959_24960 : H12AffineEnvironment.transform 15 13374 env24959 = env24960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13374 env24959 == env24960) = true)

def env24961 : List Nat := [2,4,8,16,32,64,128,253,136,1024,2048,4096,2168,3198,2264,7238,6171,2184,1104,2264,3118,33,64,138,2289,16,7356,6171,4096,7221,4116,5140,173,5140,6339,136]

theorem envBound24961 : H12AffineFastState.Bounded env24961 := by
  intro p hp
  have h : env24961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24960_24961 : H12AffineEnvironment.transform 12 2168 env24960 = env24961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2168 env24960 == env24961) = true)

theorem identity24961 : scanCanonicalize (H12AffineFastState.compose env24961 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 3223) := by decide +kernel

theorem selectedBound24961 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env24962 : List Nat := [2,4,8,16,32,64,128,253,136,1024,2048,3223,2168,3198,2264,209,1164,2184,1104,2264,3118,33,64,138,2289,16,43,1164,3223,162,3203,2179,173,2179,1108,136]

theorem envBound24962 : H12AffineFastState.Bounded env24962 := by
  intro p hp
  have h : env24962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24961_24962 : H12AffineEnvironment.transform 11 3223 env24961 = env24962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3223 env24961 == env24962) = true)

theorem identity24962 : scanCanonicalize (H12AffineFastState.compose env24962 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound24962 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env24963 : List Nat := [2,4,8,16,32,64,128,253,136,1024,42,1213,82,1108,242,209,1164,162,1104,242,1028,33,64,138,219,16,43,1164,1213,162,1193,169,173,169,1108,136]

theorem envBound24963 : H12AffineFastState.Bounded env24963 := by
  intro p hp
  have h : env24963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24962_24963 : H12AffineEnvironment.transform 10 42 env24962 = env24963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env24962 == env24963) = true)

theorem identity24963 : scanCanonicalize (H12AffineFastState.compose env24963 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound24963 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24964 : List Nat := [2,4,8,16,32,1,128,188,136,1024,42,1213,19,1045,179,144,1164,162,1041,179,1028,33,1,138,154,16,43,1164,1213,162,1193,169,173,169,1045,136]

theorem envBound24964 : H12AffineFastState.Bounded env24964 := by
  intro p hp
  have h : env24964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24963_24964 : H12AffineEnvironment.transform 5 1 env24963 = env24964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env24963 == env24964) = true)

theorem identity24964 : scanCanonicalize (H12AffineFastState.compose env24964 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound24964 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24965 : List Nat := [2,4,8,16,32,1,25,37,17,1024,42,1060,19,1045,42,9,1045,59,1041,42,1028,33,1,19,3,16,43,1045,1060,59,1072,48,52,48,1045,17]

theorem envBound24965 : H12AffineFastState.Bounded env24965 := by
  intro p hp
  have h : env24965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24964_24965 : H12AffineEnvironment.transform 6 25 env24964 = env24965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env24964 == env24965) = true)

theorem identity24965 : scanCanonicalize (H12AffineFastState.compose env24965 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound24965 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24966 : List Nat := [2,4,8,16,16,1,25,21,17,1024,26,1044,19,1045,26,9,1045,11,1041,26,1028,17,1,19,3,16,27,1045,1044,11,1024,0,4,0,1045,17]

theorem envBound24966 : H12AffineFastState.Bounded env24966 := by
  intro p hp
  have h : env24966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24965_24966 : H12AffineEnvironment.transform 4 16 env24965 = env24966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env24965 == env24966) = true)

theorem identity24966 : scanCanonicalize (H12AffineFastState.compose env24966 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 11) := by decide +kernel

theorem selectedBound24966 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24967 : List Nat := [2,4,8,16,16,1,25,21,17,11,26,31,19,30,26,9,30,11,26,26,15,17,1,19,3,16,27,30,31,11,11,0,4,0,30,17]

theorem envBound24967 : H12AffineFastState.Bounded env24967 := by
  intro p hp
  have h : env24967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24966_24967 : H12AffineEnvironment.transform 9 11 env24966 = env24967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 11 env24966 == env24967) = true)

theorem identity24967 : scanCanonicalize (H12AffineFastState.compose env24967 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound24967 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env24968 : List Nat := [2,4,8,1,1,1,8,4,0,11,11,14,2,15,11,9,15,11,11,11,15,0,1,2,3,1,10,15,14,11,11,0,4,0,15,0]

theorem envBound24968 : H12AffineFastState.Bounded env24968 := by
  intro p hp
  have h : env24968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24967_24968 : H12AffineEnvironment.transform 3 1 env24967 = env24968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env24967 == env24968) = true)

def leafEnv24968 : List Nat := [2,4,8,1,1,1,8,4,0,11,11,14,2,15,11,9,15,11,11,11,15,0,1,2,11,3,1,1,10,15,14,11,11,0,4,0,4,8,15,0,0,15,1]

def active24968 : List Nat := [0,1,2]

def tree24968 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24968 : H12WitnessSearch.Good tree24968 := H12GlobalWitnessIndex.good

theorem leafIdentity24968 : H12AffineFastState.composeSystem env24968 rootObs = leafEnv24968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24968 rootObs == leafEnv24968) = true)

theorem terminalChecked24968 : H12PackedTerminal.terminalCheckFast leafEnv24968 active24968 tree24968 = true := by decide +kernel

def env24969 : List Nat := [2,4,8,16,32,64,128,253,136,1024,2048,4096,2169,3199,2264,7239,6171,2185,1105,2264,3119,33,64,138,2288,16,7356,6170,4097,7220,4117,5141,172,5141,6338,136]

theorem envBound24969 : H12AffineFastState.Bounded env24969 := by
  intro p hp
  have h : env24969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24960_24969 : H12AffineEnvironment.transform 12 2169 env24960 = env24969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2169 env24960 == env24969) = true)

theorem identity24969 : scanCanonicalize (H12AffineFastState.compose env24969 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound24969 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env24970 : List Nat := [2,4,8,16,32,64,128,253,136,1024,42,4096,83,1109,242,5229,4145,163,1105,242,1029,33,64,138,218,16,5270,4144,4097,5150,4117,5141,172,5141,4328,136]

theorem envBound24970 : H12AffineFastState.Bounded env24970 := by
  intro p hp
  have h : env24970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24969_24970 : H12AffineEnvironment.transform 10 42 env24969 = env24970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env24969 == env24970) = true)

theorem identity24970 : scanCanonicalize (H12AffineFastState.compose env24970 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound24970 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env24971 : List Nat := [2,4,8,16,16,64,128,205,136,1024,26,4096,83,1109,194,5213,4097,147,1105,194,1029,17,64,138,218,16,5270,4096,4097,5150,4117,5141,156,5141,4312,136]

theorem envBound24971 : H12AffineFastState.Bounded env24971 := by
  intro p hp
  have h : env24971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24970_24971 : H12AffineEnvironment.transform 4 16 env24970 = env24971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env24970 == env24971) = true)

theorem identity24971 : scanCanonicalize (H12AffineFastState.compose env24971 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 1045) := by decide +kernel

theorem selectedBound24971 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env24972 : List Nat := [2,4,8,16,16,64,128,205,136,1024,26,1045,83,1109,194,72,1044,147,1105,194,1029,17,64,138,218,16,131,1045,1044,11,1024,0,156,0,1229,136]

theorem envBound24972 : H12AffineFastState.Bounded env24972 := by
  intro p hp
  have h : env24972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24971_24972 : H12AffineEnvironment.transform 11 1045 env24971 = env24972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1045 env24971 == env24972) = true)

theorem identity24972 : scanCanonicalize (H12AffineFastState.compose env24972 (packedSelected [0,2] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound24972 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env24973 : List Nat := [2,4,8,16,16,64,24,85,16,1024,26,1045,83,1109,90,72,1044,11,1105,90,1029,17,64,18,66,16,27,1045,1044,11,1024,0,4,0,1109,16]

theorem envBound24973 : H12AffineFastState.Bounded env24973 := by
  intro p hp
  have h : env24973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24972_24973 : H12AffineEnvironment.transform 6 24 env24972 = env24973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env24972 == env24973) = true)

theorem identity24973 : scanCanonicalize (H12AffineFastState.compose env24973 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound24973 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24974 : List Nat := [2,4,8,16,16,0,24,21,16,1024,26,1045,19,1045,26,8,1044,11,1041,26,1029,17,0,18,2,16,27,1045,1044,11,1024,0,4,0,1045,16]

theorem envBound24974 : H12AffineFastState.Bounded env24974 := by
  intro p hp
  have h : env24974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24973_24974 : H12AffineEnvironment.transform 5 0 env24973 = env24974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env24973 == env24974) = true)

theorem identity24974 : scanCanonicalize (H12AffineFastState.compose env24974 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 10) := by decide +kernel

theorem selectedBound24974 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24975 : List Nat := [2,4,8,16,16,0,24,21,16,10,26,31,19,31,26,8,30,11,27,26,15,17,0,18,2,16,27,31,30,11,10,0,4,0,31,16]

theorem envBound24975 : H12AffineFastState.Bounded env24975 := by
  intro p hp
  have h : env24975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24974_24975 : H12AffineEnvironment.transform 9 10 env24974 = env24975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 10 env24974 == env24975) = true)

theorem identity24975 : scanCanonicalize (H12AffineFastState.compose env24975 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound24975 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env24976 : List Nat := [2,4,8,1,1,0,9,4,1,10,11,14,2,14,11,8,15,11,10,11,15,0,0,3,2,1,10,14,15,11,10,0,4,0,14,1]

theorem envBound24976 : H12AffineFastState.Bounded env24976 := by
  intro p hp
  have h : env24976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24975_24976 : H12AffineEnvironment.transform 3 1 env24975 = env24976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env24975 == env24976) = true)

def leafEnv24976 : List Nat := [2,4,8,1,1,0,9,4,1,10,11,14,2,14,11,8,15,11,10,11,15,0,0,3,10,2,1,1,10,14,15,11,10,0,4,0,4,8,14,1,0,15,1]

def active24976 : List Nat := [0,1,2]

def tree24976 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24976 : H12WitnessSearch.Good tree24976 := H12GlobalWitnessIndex.good

theorem leafIdentity24976 : H12AffineFastState.composeSystem env24976 rootObs = leafEnv24976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24976 rootObs == leafEnv24976) = true)

theorem terminalChecked24976 : H12PackedTerminal.terminalCheckFast leafEnv24976 active24976 tree24976 = true := by decide +kernel

def env24977 : List Nat := [2,4,8,16,32,64,128,253,137,1024,2048,4096,8192,16384,32768,65536,131072,43048,524288,32768,44174,33,542830,138,8329,566497,75906,150655,23679,100523,92245,98442,525565,98442,640115,137]

theorem envBound24977 : H12AffineFastState.Bounded env24977 := by
  intro p hp
  have h : env24977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24954_24977 : H12AffineEnvironment.transform 8 137 env24954 = env24977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env24954 == env24977) = true)

theorem identity24977 : scanCanonicalize (H12AffineFastState.compose env24977 (packedSelected [4,9,13,14,17,20] rootPS)) = affineNative (2^(18+1) ^^^ 18478) := by decide +kernel

theorem selectedBound24977 : packedSelected [4,9,13,14,17,20] rootPS < 2^1333 := by decide +kernel

def env24978 : List Nat := [2,4,8,16,32,64,128,253,137,1024,2048,4096,8192,16384,32768,65536,131072,43048,18478,32768,44174,33,64,138,8329,60623,75906,150655,23679,100523,92245,98442,19667,98442,101469,137]

theorem envBound24978 : H12AffineFastState.Bounded env24978 := by
  intro p hp
  have h : env24978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24977_24978 : H12AffineEnvironment.transform 18 18478 env24977 = env24978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 18478 env24977 == env24978) = true)

theorem identity24978 : scanCanonicalize (H12AffineFastState.compose env24978 (packedSelected [1,2,3,4,5,6,8,9,11,12] rootPS)) = affineNative (2^(16+1) ^^^ 68814) := by decide +kernel

theorem selectedBound24978 : packedSelected [1,2,3,4,5,6,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env24979 : List Nat := [2,4,8,16,32,64,128,253,137,1024,2048,4096,8192,16384,32768,65536,68814,43048,18478,32768,44174,33,64,138,8329,60623,75906,82097,23679,100523,92245,98442,19667,98442,101469,137]

theorem envBound24979 : H12AffineFastState.Bounded env24979 := by
  intro p hp
  have h : env24979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24978_24979 : H12AffineEnvironment.transform 16 68814 env24978 = env24979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 68814 env24978 == env24979) = true)

theorem identity24979 : scanCanonicalize (H12AffineFastState.compose env24979 (packedSelected [1,5,10,17] rootPS)) = affineNative (2^(14+1) ^^^ 27871) := by decide +kernel

theorem selectedBound24979 : packedSelected [1,5,10,17] rootPS < 2^1333 := by decide +kernel

def env24980 : List Nat := [2,4,8,16,32,64,128,253,137,1024,2048,4096,8192,16384,27871,65536,68814,17655,18478,27871,16465,33,64,138,8329,16,75906,82097,23679,91252,92245,93269,19667,93269,90242,137]

theorem envBound24980 : H12AffineFastState.Bounded env24980 := by
  intro p hp
  have h : env24980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24979_24980 : H12AffineEnvironment.transform 14 27871 env24979 = env24980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 27871 env24979 == env24980) = true)

theorem identity24980 : scanCanonicalize (H12AffineFastState.compose env24980 (packedSelected [1,2,4,5,6,7] rootPS)) = affineNative (2^(13+1) ^^^ 14457) := by decide +kernel

theorem selectedBound24980 : packedSelected [1,2,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env24981 : List Nat := [2,4,8,16,32,64,128,253,137,1024,2048,4096,8192,14457,5286,65536,68814,15502,12375,5286,14376,33,64,138,8329,16,75906,80072,9222,72717,69676,70700,13482,70700,71931,137]

theorem envBound24981 : H12AffineFastState.Bounded env24981 := by
  intro p hp
  have h : env24981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24980_24981 : H12AffineEnvironment.transform 13 14457 env24980 = env24981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 14457 env24980 == env24981) = true)

theorem identity24981 : scanCanonicalize (H12AffineFastState.compose env24981 (packedSelected [0,2,3,4,6,8] rootPS)) = affineNative (2^(15+1) ^^^ 2162) := by decide +kernel

theorem selectedBound24981 : packedSelected [0,2,3,4,6,8] rootPS < 2^1333 := by decide +kernel

def env24982 : List Nat := [2,4,8,16,32,64,128,253,137,1024,2048,4096,8192,14457,5286,2162,1212,15502,12375,5286,14376,33,64,138,8329,16,8432,12474,9222,5247,6238,7262,13482,7262,4233,137]

theorem envBound24982 : H12AffineFastState.Bounded env24982 := by
  intro p hp
  have h : env24982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24981_24982 : H12AffineEnvironment.transform 15 2162 env24981 = env24982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2162 env24981 == env24982) = true)

def env24983 : List Nat := [2,4,8,16,32,64,128,253,137,1024,2048,1212,8192,11461,26,2162,1212,10290,9451,26,11412,33,64,138,8329,16,8432,9222,9222,195,3298,2274,8214,2274,1077,137]

theorem envBound24983 : H12AffineFastState.Bounded env24983 := by
  intro p hp
  have h : env24983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24982_24983 : H12AffineEnvironment.transform 11 1212 env24982 = env24983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1212 env24982 == env24983) = true)

theorem identity24983 : scanCanonicalize (H12AffineFastState.compose env24983 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 130) := by decide +kernel

theorem selectedBound24983 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env24984 : List Nat := [2,4,8,16,32,64,128,253,137,1024,130,1212,8192,9287,26,240,1212,8368,9451,26,9238,33,64,138,8329,16,8432,9222,9222,195,1120,96,8214,96,1077,137]

theorem envBound24984 : H12AffineFastState.Bounded env24984 := by
  intro p hp
  have h : env24984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24983_24984 : H12AffineEnvironment.transform 10 130 env24983 = env24984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 130 env24983 == env24984) = true)

theorem identity24984 : scanCanonicalize (H12AffineFastState.compose env24984 (packedSelected [6] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound24984 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env24985 : List Nat := [2,4,8,16,32,64,40,85,33,1024,42,1044,8192,9287,26,88,1044,8216,9283,26,9238,33,64,34,8225,16,8280,9222,9222,107,1120,96,8214,96,1077,33]

theorem envBound24985 : H12AffineFastState.Bounded env24985 := by
  intro p hp
  have h : env24985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24984_24985 : H12AffineEnvironment.transform 6 40 env24984 = env24985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env24984 == env24985) = true)

def env24986 : List Nat := [2,4,8,16,32,64,128,253,137,1024,2048,1213,8192,11460,27,2162,1212,10291,9450,27,11413,33,64,138,8329,16,8432,9223,9222,194,3299,2275,8215,2275,1076,137]

theorem envBound24986 : H12AffineFastState.Bounded env24986 := by
  intro p hp
  have h : env24986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24982_24986 : H12AffineEnvironment.transform 11 1213 env24982 = env24986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1213 env24982 == env24986) = true)

theorem identity24986 : scanCanonicalize (H12AffineFastState.compose env24986 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 73) := by decide +kernel

theorem selectedBound24986 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env24987 : List Nat := [2,4,8,16,32,64,73,52,64,1024,2048,1140,8192,11277,27,2162,1141,10291,9251,27,11356,33,64,67,8256,16,8249,9223,9222,11,3114,2090,8215,2090,1076,64]

theorem envBound24987 : H12AffineFastState.Bounded env24987 := by
  intro p hp
  have h : env24987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24986_24987 : H12AffineEnvironment.transform 6 73 env24986 = env24987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 73 env24986 == env24987) = true)

theorem identity24987 : scanCanonicalize (H12AffineFastState.compose env24987 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 2136) := by decide +kernel

theorem selectedBound24987 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env24988 : List Nat := [2,4,8,16,32,64,73,52,64,1024,2048,1140,2136,1109,27,2162,1141,107,3195,27,1028,33,64,67,2072,16,2145,3167,3166,11,3114,2090,2127,2090,1076,64]

theorem envBound24988 : H12AffineFastState.Bounded env24988 := by
  intro p hp
  have h : env24988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24987_24988 : H12AffineEnvironment.transform 12 2136 env24987 = env24988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2136 env24987 == env24988) = true)

def env24989 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,32768,65536,131072,43048,524288,32768,2097152,33,2680033,138,8329,566889,75906,2286201,2159225,100523,2213458,98442,525565,98442,640115,512]

theorem envBound24989 : H12AffineFastState.Bounded env24989 := by
  intro p hp
  have h : env24989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24952_24989 : H12AffineEnvironment.transform 22 2680033 env24952 = env24989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2680033 env24952 == env24989) = true)

theorem identity24989 : scanCanonicalize (H12AffineFastState.compose env24989 (packedSelected [0,1,2,5,6,10,12,13,14,15,17,20,27] rootPS)) = affineNative (2^(20+1) ^^^ 44551) := by decide +kernel

theorem selectedBound24989 : packedSelected [0,1,2,5,6,10,12,13,14,15,17,20,27] rootPS < 2^1333 := by decide +kernel

def env24990 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,32768,65536,131072,43048,524288,32768,44551,33,543462,138,8329,566889,75906,150654,23678,100523,92245,98442,525565,98442,640115,512]

theorem envBound24990 : H12AffineFastState.Bounded env24990 := by
  intro p hp
  have h : env24990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24989_24990 : H12AffineEnvironment.transform 20 44551 env24989 = env24990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 44551 env24989 == env24990) = true)

def env24991 : List Nat := [2,4,8,16,32,64,128,253,136,1024,2048,4096,8192,16384,32768,65536,131072,43048,524288,32768,44175,33,542830,138,8329,566497,75906,150654,23678,100523,92245,98442,525565,98442,640115,136]

theorem envBound24991 : H12AffineFastState.Bounded env24991 := by
  intro p hp
  have h : env24991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24990_24991 : H12AffineEnvironment.transform 8 136 env24990 = env24991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env24990 == env24991) = true)

theorem identity24991 : scanCanonicalize (H12AffineFastState.compose env24991 (packedSelected [4,9,13,14,17,20] rootPS)) = affineNative (2^(18+1) ^^^ 18478) := by decide +kernel

theorem selectedBound24991 : packedSelected [4,9,13,14,17,20] rootPS < 2^1333 := by decide +kernel

def env24992 : List Nat := [2,4,8,16,32,64,128,253,136,1024,2048,4096,8192,16384,32768,65536,131072,43048,18478,32768,44175,33,64,138,8329,60623,75906,150654,23678,100523,92245,98442,19667,98442,101469,136]

theorem envBound24992 : H12AffineFastState.Bounded env24992 := by
  intro p hp
  have h : env24992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24991_24992 : H12AffineEnvironment.transform 18 18478 env24991 = env24992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 18478 env24991 == env24992) = true)

theorem identity24992 : scanCanonicalize (H12AffineFastState.compose env24992 (packedSelected [1,2,3,4,5,6,8,9,11,12] rootPS)) = affineNative (2^(16+1) ^^^ 122897) := by decide +kernel

theorem selectedBound24992 : packedSelected [1,2,3,4,5,6,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env24993 : List Nat := [2,4,8,16,32,64,128,253,136,1024,2048,4096,8192,16384,32768,65536,122897,43048,18478,32768,44175,33,64,138,8329,60623,75906,109679,23678,100523,92245,98442,19667,98442,101469,136]

theorem envBound24993 : H12AffineFastState.Bounded env24993 := by
  intro p hp
  have h : env24993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24992_24993 : H12AffineEnvironment.transform 16 122897 env24992 = env24993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122897 env24992 == env24993) = true)

theorem identity24993 : scanCanonicalize (H12AffineFastState.compose env24993 (packedSelected [1,5,10,17] rootPS)) = affineNative (2^(14+1) ^^^ 27871) := by decide +kernel

theorem selectedBound24993 : packedSelected [1,5,10,17] rootPS < 2^1333 := by decide +kernel

def env24994 : List Nat := [2,4,8,16,32,64,128,253,136,1024,2048,4096,8192,16384,27871,65536,68814,17655,18478,27871,16464,33,64,138,8329,16,75906,82096,23678,91252,92245,93269,19667,93269,90242,136]

theorem envBound24994 : H12AffineFastState.Bounded env24994 := by
  intro p hp
  have h : env24994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24993_24994 : H12AffineEnvironment.transform 14 27871 env24993 = env24994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 27871 env24993 == env24994) = true)

theorem identity24994 : scanCanonicalize (H12AffineFastState.compose env24994 (packedSelected [1,2,4,5,6,7] rootPS)) = affineNative (2^(13+1) ^^^ 14457) := by decide +kernel

theorem selectedBound24994 : packedSelected [1,2,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env24995 : List Nat := [2,4,8,16,32,64,128,253,136,1024,2048,4096,8192,14457,5286,65536,68814,15502,12375,5286,14377,33,64,138,8329,16,75906,80073,9223,72717,69676,70700,13482,70700,71931,136]

theorem envBound24995 : H12AffineFastState.Bounded env24995 := by
  intro p hp
  have h : env24995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24994_24995 : H12AffineEnvironment.transform 13 14457 env24994 = env24995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 14457 env24994 == env24995) = true)

theorem identity24995 : scanCanonicalize (H12AffineFastState.compose env24995 (packedSelected [0,2,3,4,6,8] rootPS)) = affineNative (2^(15+1) ^^^ 2163) := by decide +kernel

theorem selectedBound24995 : packedSelected [0,2,3,4,6,8] rootPS < 2^1333 := by decide +kernel

def env24996 : List Nat := [2,4,8,16,32,64,128,253,136,1024,2048,4096,8192,14457,5286,2163,1213,15502,12375,5286,14377,33,64,138,8329,16,8433,12474,9223,5246,6239,7263,13482,7263,4232,136]

theorem envBound24996 : H12AffineFastState.Bounded env24996 := by
  intro p hp
  have h : env24996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24995_24996 : H12AffineEnvironment.transform 15 2163 env24995 = env24996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2163 env24995 == env24996) = true)

def env24997 : List Nat := [2,4,8,16,32,64,128,253,136,1024,2048,1212,8192,11461,26,2163,1213,10290,9451,26,11413,33,64,138,8329,16,8433,9222,9223,194,3299,2275,8214,2275,1076,136]

theorem envBound24997 : H12AffineFastState.Bounded env24997 := by
  intro p hp
  have h : env24997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24996_24997 : H12AffineEnvironment.transform 11 1212 env24996 = env24997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1212 env24996 == env24997) = true)

theorem identity24997 : scanCanonicalize (H12AffineFastState.compose env24997 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 131) := by decide +kernel

theorem selectedBound24997 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env24998 : List Nat := [2,4,8,16,32,64,128,253,136,1024,131,1212,8192,9286,26,240,1213,8369,9451,26,9238,33,64,138,8329,16,8433,9222,9223,194,1120,96,8214,96,1076,136]

theorem envBound24998 : H12AffineFastState.Bounded env24998 := by
  intro p hp
  have h : env24998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24997_24998 : H12AffineEnvironment.transform 10 131 env24997 = env24998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 131 env24997 == env24998) = true)

theorem identity24998 : scanCanonicalize (H12AffineFastState.compose env24998 (packedSelected [6] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound24998 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env24999 : List Nat := [2,4,8,16,32,32,128,157,136,1024,131,1212,8192,9254,26,144,1213,8369,9355,26,9238,33,32,138,8329,16,8337,9222,9223,162,1024,0,8214,0,1076,136]

theorem envBound24999 : H12AffineFastState.Bounded env24999 := by
  intro p hp
  have h : env24999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24998_24999 : H12AffineEnvironment.transform 5 32 env24998 = env24999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env24998 == env24999) = true)

theorem identity24999 : scanCanonicalize (H12AffineFastState.compose env24999 (packedSelected [0,2] rootPS)) = affineNative (2^(12+1) ^^^ 18) := by decide +kernel

theorem selectedBound24999 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env25000 : List Nat := [2,4,8,16,32,32,128,157,136,1024,131,1212,18,1076,26,144,1213,163,1177,26,1028,33,32,138,155,16,131,1044,1045,162,1024,0,4,0,1076,136]

theorem envBound25000 : H12AffineFastState.Bounded env25000 := by
  intro p hp
  have h : env25000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24999_25000 : H12AffineEnvironment.transform 12 18 env24999 = env25000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 18 env24999 == env25000) = true)

theorem identity25000 : scanCanonicalize (H12AffineFastState.compose env25000 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound25000 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25001 : List Nat := [2,4,8,16,32,32,56,37,48,1024,59,1028,18,1076,26,40,1029,27,1057,26,1028,33,32,50,35,16,59,1044,1045,26,1024,0,4,0,1076,48]

theorem envBound25001 : H12AffineFastState.Bounded env25001 := by
  intro p hp
  have h : env25001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25000_25001 : H12AffineEnvironment.transform 6 56 env25000 = env25001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env25000 == env25001) = true)

theorem identity25001 : scanCanonicalize (H12AffineFastState.compose env25001 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 42) := by decide +kernel

theorem selectedBound25001 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25002 : List Nat := [2,4,8,16,32,32,56,37,48,42,59,46,18,30,26,40,47,27,11,26,46,33,32,50,35,16,59,62,63,26,42,0,4,0,30,48]

theorem envBound25002 : H12AffineFastState.Bounded env25002 := by
  intro p hp
  have h : env25002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25001_25002 : H12AffineEnvironment.transform 9 42 env25001 = env25002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 42 env25001 == env25002) = true)

theorem identity25002 : scanCanonicalize (H12AffineFastState.compose env25002 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound25002 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env25003 : List Nat := [2,4,8,16,1,1,25,4,17,11,26,15,18,30,26,9,14,27,11,26,15,0,1,19,2,16,26,31,30,26,11,0,4,0,30,17]

theorem envBound25003 : H12AffineFastState.Bounded env25003 := by
  intro p hp
  have h : env25003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25002_25003 : H12AffineEnvironment.transform 4 1 env25002 = env25003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env25002 == env25003) = true)

def leafEnv25003 : List Nat := [2,4,8,16,1,1,25,4,17,11,26,15,18,30,26,9,14,27,11,26,15,0,1,19,11,2,1,16,26,31,30,26,11,0,4,0,4,25,30,17,0,15,1]

def active25003 : List Nat := [0,1,2,3]

def tree25003 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25003 : H12WitnessSearch.Good tree25003 := H12GlobalWitnessIndex.good

theorem leafIdentity25003 : H12AffineFastState.composeSystem env25003 rootObs = leafEnv25003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25003 rootObs == leafEnv25003) = true)

theorem terminalChecked25003 : H12PackedTerminal.terminalCheckFast leafEnv25003 active25003 tree25003 = true := by decide +kernel

def env25004 : List Nat := [2,4,8,16,32,64,128,253,136,1024,2048,1213,8192,11460,27,2163,1213,10291,9450,27,11412,33,64,138,8329,16,8433,9223,9223,195,3298,2274,8215,2274,1077,136]

theorem envBound25004 : H12AffineFastState.Bounded env25004 := by
  intro p hp
  have h : env25004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24996_25004 : H12AffineEnvironment.transform 11 1213 env24996 = env25004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1213 env24996 == env25004) = true)

theorem identity25004 : scanCanonicalize (H12AffineFastState.compose env25004 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 72) := by decide +kernel

theorem selectedBound25004 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env25005 : List Nat := [2,4,8,16,32,64,72,53,64,1024,2048,1141,8192,11276,27,2163,1141,10291,9250,27,11356,33,64,66,8257,16,8249,9223,9223,11,3114,2090,8215,2090,1077,64]

theorem envBound25005 : H12AffineFastState.Bounded env25005 := by
  intro p hp
  have h : env25005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25004_25005 : H12AffineEnvironment.transform 6 72 env25004 = env25005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 72 env25004 == env25005) = true)

theorem identity25005 : scanCanonicalize (H12AffineFastState.compose env25005 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 19) := by decide +kernel

theorem selectedBound25005 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env25006 : List Nat := [2,4,8,16,32,64,72,53,64,1024,2048,1141,19,3103,27,2163,1141,2080,1073,27,3151,33,64,66,82,16,42,1044,1044,11,3114,2090,4,2090,1077,64]

theorem envBound25006 : H12AffineFastState.Bounded env25006 := by
  intro p hp
  have h : env25006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25005_25006 : H12AffineEnvironment.transform 12 19 env25005 = env25006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 19 env25005 == env25006) = true)

def env25007 : List Nat := [2,4,8,16,32,64,128,253,137,1024,2048,4096,8192,16384,32768,65536,131072,43048,524288,32768,44174,33,542831,138,8329,566496,75906,150654,23678,100523,92245,98442,525565,98442,640115,137]

theorem envBound25007 : H12AffineFastState.Bounded env25007 := by
  intro p hp
  have h : env25007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24990_25007 : H12AffineEnvironment.transform 8 137 env24990 = env25007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env24990 == env25007) = true)

theorem identity25007 : scanCanonicalize (H12AffineFastState.compose env25007 (packedSelected [4,9,13,14,17,20] rootPS)) = affineNative (2^(18+1) ^^^ 42224) := by decide +kernel

theorem selectedBound25007 : packedSelected [4,9,13,14,17,20] rootPS < 2^1333 := by decide +kernel

def env25008 : List Nat := [2,4,8,16,32,64,128,253,137,1024,2048,4096,8192,16384,32768,65536,131072,43048,42224,32768,44174,33,60575,138,8329,16,75906,150654,23678,100523,92245,98442,40973,98442,90243,137]

theorem envBound25008 : H12AffineFastState.Bounded env25008 := by
  intro p hp
  have h : env25008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25007_25008 : H12AffineEnvironment.transform 18 42224 env25007 = env25008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 42224 env25007 == env25008) = true)

theorem identity25008 : scanCanonicalize (H12AffineFastState.compose env25008 (packedSelected [1,5,10,13] rootPS)) = affineNative (2^(14+1) ^^^ 27871) := by decide +kernel

theorem selectedBound25008 : packedSelected [1,5,10,13] rootPS < 2^1333 := by decide +kernel

def env25009 : List Nat := [2,4,8,16,32,64,128,253,137,1024,2048,4096,8192,16384,27871,65536,131072,17655,18479,27871,16465,33,64,138,8329,16,75906,150654,23678,91252,92245,93269,19666,93269,90243,137]

theorem envBound25009 : H12AffineFastState.Bounded env25009 := by
  intro p hp
  have h : env25009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25008_25009 : H12AffineEnvironment.transform 14 27871 env25008 = env25009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 27871 env25008 == env25009) = true)

theorem identity25009 : scanCanonicalize (H12AffineFastState.compose env25009 (packedSelected [1,2,4,5,6,7] rootPS)) = affineNative (2^(13+1) ^^^ 9222) := by decide +kernel

theorem selectedBound25009 : packedSelected [1,2,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env25010 : List Nat := [2,4,8,16,32,64,128,253,137,1024,2048,4096,8192,9222,2265,65536,131072,8433,11305,2265,9303,33,64,138,8329,16,75906,141432,14456,65650,68691,67667,10452,67667,66693,137]

theorem envBound25010 : H12AffineFastState.Bounded env25010 := by
  intro p hp
  have h : env25010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25009_25010 : H12AffineEnvironment.transform 13 9222 env25009 = env25010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 9222 env25009 == env25010) = true)

theorem identity25010 : scanCanonicalize (H12AffineFastState.compose env25010 (packedSelected [0,2,3,4,6,8] rootPS)) = affineNative (2^(16+1) ^^^ 6171) := by decide +kernel

theorem selectedBound25010 : packedSelected [0,2,3,4,6,8] rootPS < 2^1333 := by decide +kernel

def env25011 : List Nat := [2,4,8,16,32,64,128,253,137,1024,2048,4096,8192,9222,2265,65536,6171,8433,11305,2265,9303,33,64,138,8329,16,75906,12387,14456,65650,68691,67667,10452,67667,66693,137]

theorem envBound25011 : H12AffineFastState.Bounded env25011 := by
  intro p hp
  have h : env25011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25010_25011 : H12AffineEnvironment.transform 16 6171 env25010 = env25011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 6171 env25010 == env25011) = true)

theorem identity25011 : scanCanonicalize (H12AffineFastState.compose env25011 (packedSelected [3,5,11] rootPS)) = affineNative (2^(15+1) ^^^ 13374) := by decide +kernel

theorem selectedBound25011 : packedSelected [3,5,11] rootPS < 2^1333 := by decide +kernel

def env25012 : List Nat := [2,4,8,16,32,64,128,253,137,1024,2048,4096,8192,9222,2265,13374,6171,8433,11305,2265,9303,33,64,138,8329,16,7356,12387,14456,13388,14445,15469,10452,15469,12475,137]

theorem envBound25012 : H12AffineFastState.Bounded env25012 := by
  intro p hp
  have h : env25012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25011_25012 : H12AffineEnvironment.transform 15 13374 env25011 = env25012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13374 env25011 == env25012) = true)

def env25013 : List Nat := [2,4,8,16,32,64,128,253,137,1024,2048,4096,2168,3198,2265,7238,6171,2185,1105,2265,3119,33,64,138,2289,16,7356,6171,4096,7220,4117,5141,172,5141,6339,137]

theorem envBound25013 : H12AffineFastState.Bounded env25013 := by
  intro p hp
  have h : env25013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25012_25013 : H12AffineEnvironment.transform 12 2168 env25012 = env25013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2168 env25012 == env25013) = true)

theorem identity25013 : scanCanonicalize (H12AffineFastState.compose env25013 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 3223) := by decide +kernel

theorem selectedBound25013 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env25014 : List Nat := [2,4,8,16,32,64,128,253,137,1024,2048,3223,2168,3198,2265,209,1164,2185,1105,2265,3119,33,64,138,2289,16,43,1164,3223,163,3202,2178,172,2178,1108,137]

theorem envBound25014 : H12AffineFastState.Bounded env25014 := by
  intro p hp
  have h : env25014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25013_25014 : H12AffineEnvironment.transform 11 3223 env25013 = env25014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3223 env25013 == env25014) = true)

def env25015 : List Nat := [2,4,8,16,32,64,128,253,137,1024,2048,4096,2169,3199,2265,7239,6171,2184,1104,2265,3118,33,64,138,2288,16,7356,6170,4097,7221,4116,5140,173,5140,6338,137]

theorem envBound25015 : H12AffineFastState.Bounded env25015 := by
  intro p hp
  have h : env25015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25012_25015 : H12AffineEnvironment.transform 12 2169 env25012 = env25015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2169 env25012 == env25015) = true)

theorem identity25015 : scanCanonicalize (H12AffineFastState.compose env25015 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound25015 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env25016 : List Nat := [2,4,8,16,32,64,128,253,137,1024,42,4096,83,1109,243,5229,4145,162,1104,243,1028,33,64,138,218,16,5270,4144,4097,5151,4116,5140,173,5140,4328,137]

theorem envBound25016 : H12AffineFastState.Bounded env25016 := by
  intro p hp
  have h : env25016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25015_25016 : H12AffineEnvironment.transform 10 42 env25015 = env25016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env25015 == env25016) = true)

theorem identity25016 : scanCanonicalize (H12AffineFastState.compose env25016 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 1164) := by decide +kernel

theorem selectedBound25016 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env25017 : List Nat := [2,4,8,16,32,64,128,253,137,1024,42,1164,83,1109,243,225,1213,162,1104,243,1028,33,64,138,218,16,26,1212,1165,147,1176,152,173,152,1124,137]

theorem envBound25017 : H12AffineFastState.Bounded env25017 := by
  intro p hp
  have h : env25017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25016_25017 : H12AffineEnvironment.transform 11 1164 env25016 = env25017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1164 env25016 == env25017) = true)

theorem identity25017 : scanCanonicalize (H12AffineFastState.compose env25017 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound25017 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env25018 : List Nat := [2,4,8,16,32,64,25,100,16,1024,42,1045,83,1109,106,120,1060,59,1104,106,1028,33,64,19,67,16,26,1061,1044,10,1025,1,52,1,1124,16]

theorem envBound25018 : H12AffineFastState.Bounded env25018 := by
  intro p hp
  have h : env25018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25017_25018 : H12AffineEnvironment.transform 6 25 env25017 = env25018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env25017 == env25018) = true)

def env25019 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,33554432,67108864,134217728,268435456,536870912,1073741824,897815633,4294967296,525568,5154943010,34359738368,33563273]

theorem envBound25019 : H12AffineFastState.Bounded env25019 := by
  intro p hp
  have h : env25019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24871_25019 : H12AffineEnvironment.transform 19 32769 env24871 = env25019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 19 32769 env24871 == env25019) = true)

theorem identity25019 : scanCanonicalize (H12AffineFastState.compose env25019 (packedSelected [4,9,22,29] rootPS)) = affineNative (2^(24+1) ^^^ 8328) := by decide +kernel

theorem selectedBound25019 : packedSelected [4,9,22,29] rootPS < 2^1333 := by decide +kernel

def env25020 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,268435456,536870912,1073741824,897815633,4294967296,525568,5121380522,34359738368,513]

theorem envBound25020 : H12AffineFastState.Bounded env25020 := by
  intro p hp
  have h : env25020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart2