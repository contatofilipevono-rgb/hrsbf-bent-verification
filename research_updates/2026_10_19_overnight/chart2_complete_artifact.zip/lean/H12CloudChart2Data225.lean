import H12CloudChart2Data224

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans56765_56766 : H12AffineEnvironment.transform 1 2 env56765 = env56766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env56765 == env56766) = true)

theorem identity56766 : scanCanonicalize (H12AffineFastState.compose env56766 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound56766 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56767 : List Nat := [2,2,1,16,16,17,19,18,1,3,18,0,16,1,0,19,1,0,3,1,1,3,17,3,2,17,19,1,0,18,18,16,18,17,1,0]

theorem envBound56767 : H12AffineFastState.Bounded env56767 := by
  intro p hp
  have h : env56767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56766_56767 : H12AffineEnvironment.transform 2 1 env56766 = env56767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env56766 == env56767) = true)

def env56768 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1345,65665,77934,13341,4097,476,17,69649,70886,78894,77840,1296,74815,81226,8204,1281,256,8201,1345,79471]

theorem envBound56768 : H12AffineFastState.Bounded env56768 := by
  intro p hp
  have h : env56768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56741_56768 : H12AffineEnvironment.transform 17 65665 env56741 = env56768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env56741 == env56768) = true)

theorem identity56768 : scanCanonicalize (H12AffineFastState.compose env56768 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound56768 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env56769 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1296,9245,65536,1345,65665,73839,9244,0,476,17,65552,66791,74799,73745,1296,74815,77131,8204,1281,256,8201,1345,75374]

theorem envBound56769 : H12AffineFastState.Bounded env56769 := by
  intro p hp
  have h : env56769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56768_56769 : H12AffineEnvironment.transform 11 1 env56768 = env56769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env56768 == env56769) = true)

def env56770 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1,8192,1296,9245,65536,1297,65665,73791,9244,0,396,17,65552,66743,74799,73745,1296,74815,77083,8204,1281,256,8201,1297,75326]

theorem envBound56770 : H12AffineFastState.Bounded env56770 := by
  intro p hp
  have h : env56770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56769_56770 : H12AffineEnvironment.transform 5 16 env56769 = env56770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env56769 == env56770) = true)

theorem identity56770 : scanCanonicalize (H12AffineFastState.compose env56770 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound56770 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env56771 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1,1053,1296,0,65536,1297,65665,66594,1,0,396,17,65552,66743,65586,66572,1296,65570,67846,1041,1281,256,1044,1297,66083]

theorem envBound56771 : H12AffineFastState.Bounded env56771 := by
  intro p hp
  have h : env56771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56770_56771 : H12AffineEnvironment.transform 12 1053 env56770 = env56771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env56770 == env56771) = true)

theorem identity56771 : scanCanonicalize (H12AffineFastState.compose env56771 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound56771 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env56772 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,1,269,0,0,65536,1,65665,65842,1,0,396,17,65552,65959,65586,65820,0,65570,67846,257,17,256,260,1,66083]

theorem envBound56772 : H12AffineFastState.Bounded env56772 := by
  intro p hp
  have h : env56772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56771_56772 : H12AffineEnvironment.transform 9 272 env56771 = env56772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env56771 == env56772) = true)

theorem identity56772 : scanCanonicalize (H12AffineFastState.compose env56772 (packedSelected [0,1,3,5,7,8,11,12,15,17] rootPS)) = affineNative (2^(15+1) ^^^ 9) := by decide +kernel

theorem selectedBound56772 : packedSelected [0,1,3,5,7,8,11,12,15,17] rootPS < 2^1333 := by decide +kernel

def env56773 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,1,269,0,0,9,1,136,315,1,0,396,17,25,430,59,277,0,43,2319,257,17,256,260,1,554]

theorem envBound56773 : H12AffineFastState.Bounded env56773 := by
  intro p hp
  have h : env56773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56772_56773 : H12AffineEnvironment.transform 15 9 env56772 = env56773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9 env56772 == env56773) = true)

theorem identity56773 : scanCanonicalize (H12AffineFastState.compose env56773 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound56773 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env56774 : List Nat := [2,4,8,16,32,16,128,256,43,272,2048,1,269,0,0,9,1,136,315,1,0,396,17,25,430,59,277,0,43,2319,257,17,256,260,1,1]

theorem envBound56774 : H12AffineFastState.Bounded env56774 := by
  intro p hp
  have h : env56774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56773_56774 : H12AffineEnvironment.transform 8 43 env56773 = env56774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env56773 == env56774) = true)

theorem identity56774 : scanCanonicalize (H12AffineFastState.compose env56774 (packedSelected [1,5,10,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 163) := by decide +kernel

theorem selectedBound56774 : packedSelected [1,5,10,13,15] rootPS < 2^1333 := by decide +kernel

def env56775 : List Nat := [2,4,8,16,32,16,128,256,43,272,163,1,269,0,0,9,1,136,315,1,0,396,17,25,430,59,277,0,43,428,257,17,256,260,1,1]

theorem envBound56775 : H12AffineFastState.Bounded env56775 := by
  intro p hp
  have h : env56775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56774_56775 : H12AffineEnvironment.transform 10 163 env56774 = env56775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 163 env56774 == env56775) = true)

theorem identity56775 : scanCanonicalize (H12AffineFastState.compose env56775 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 156) := by decide +kernel

theorem selectedBound56775 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env56776 : List Nat := [2,4,8,16,32,16,128,156,43,140,163,1,145,0,0,9,1,136,167,1,0,16,17,25,50,59,137,0,43,48,157,17,156,152,1,1]

theorem envBound56776 : H12AffineFastState.Bounded env56776 := by
  intro p hp
  have h : env56776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56775_56776 : H12AffineEnvironment.transform 7 156 env56775 = env56776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 156 env56775 == env56776) = true)

theorem identity56776 : scanCanonicalize (H12AffineFastState.compose env56776 (packedSelected [2,4,7] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound56776 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env56777 : List Nat := [2,4,8,16,32,16,18,14,43,30,49,1,3,0,0,9,1,26,53,1,0,16,17,25,50,59,27,0,43,48,15,17,14,10,1,1]

theorem envBound56777 : H12AffineFastState.Bounded env56777 := by
  intro p hp
  have h : env56777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56776_56777 : H12AffineEnvironment.transform 6 18 env56776 = env56777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env56776 == env56777) = true)

theorem identity56777 : scanCanonicalize (H12AffineFastState.compose env56777 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound56777 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56778 : List Nat := [2,4,8,10,32,10,8,14,43,4,43,1,3,0,0,9,1,0,47,1,0,10,11,3,40,33,1,0,43,42,15,11,14,10,1,1]

theorem envBound56778 : H12AffineFastState.Bounded env56778 := by
  intro p hp
  have h : env56778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56777_56778 : H12AffineEnvironment.transform 3 10 env56777 = env56778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env56777 == env56778) = true)

theorem identity56778 : scanCanonicalize (H12AffineFastState.compose env56778 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound56778 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56779 : List Nat := [2,3,8,10,32,10,8,9,43,3,43,1,3,0,0,9,1,0,40,1,0,10,11,3,40,33,1,0,43,42,8,11,9,10,1,1]

theorem envBound56779 : H12AffineFastState.Bounded env56779 := by
  intro p hp
  have h : env56779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56778_56779 : H12AffineEnvironment.transform 1 3 env56778 = env56779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env56778 == env56779) = true)

theorem identity56779 : scanCanonicalize (H12AffineFastState.compose env56779 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound56779 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env56780 : List Nat := [2,3,8,10,11,10,8,9,0,3,0,1,3,0,0,9,1,0,3,1,0,10,11,3,3,10,1,0,0,1,8,11,9,10,1,1]

theorem envBound56780 : H12AffineFastState.Bounded env56780 := by
  intro p hp
  have h : env56780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56779_56780 : H12AffineEnvironment.transform 4 11 env56779 = env56780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env56779 == env56780) = true)

theorem identity56780 : scanCanonicalize (H12AffineFastState.compose env56780 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound56780 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56781 : List Nat := [2,3,0,2,3,2,0,1,0,3,0,1,3,0,0,1,1,0,3,1,0,2,3,3,3,2,1,0,0,1,0,3,1,2,1,1]

theorem envBound56781 : H12AffineFastState.Bounded env56781 := by
  intro p hp
  have h : env56781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56780_56781 : H12AffineEnvironment.transform 2 0 env56780 = env56781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env56780 == env56781) = true)

theorem identity56781 : scanCanonicalize (H12AffineFastState.compose env56781 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound56781 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env56782 : List Nat := [0,1,0,0,1,0,0,1,0,1,0,1,1,0,0,1,1,0,1,1,0,0,1,1,1,0,1,0,0,1,0,1,1,0,1,1]

theorem envBound56782 : H12AffineFastState.Bounded env56782 := by
  intro p hp
  have h : env56782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56781_56782 : H12AffineEnvironment.transform 0 0 env56781 = env56782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env56781 == env56782) = true)

def env56783 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1,8192,1296,9245,65536,1296,65665,73790,9244,0,397,17,65552,66742,74799,73745,1296,74815,77082,8204,1281,256,8201,1296,75327]

theorem envBound56783 : H12AffineFastState.Bounded env56783 := by
  intro p hp
  have h : env56783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56769_56783 : H12AffineEnvironment.transform 5 17 env56769 = env56783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env56769 == env56783) = true)

theorem identity56783 : scanCanonicalize (H12AffineFastState.compose env56783 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound56783 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env56784 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1,8192,1296,9245,34,1296,163,8220,9244,0,397,17,50,1172,9229,8243,1296,9245,11576,8204,1281,256,8201,1296,9757]

theorem envBound56784 : H12AffineFastState.Bounded env56784 := by
  intro p hp
  have h : env56784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56783_56784 : H12AffineEnvironment.transform 15 34 env56783 = env56784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env56783 == env56784) = true)

theorem identity56784 : scanCanonicalize (H12AffineFastState.compose env56784 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound56784 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env56785 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1,269,1296,1296,34,1296,163,273,1297,0,397,17,50,1172,1280,318,1296,1296,3125,257,1281,256,260,1296,1808]

theorem envBound56785 : H12AffineFastState.Bounded env56785 := by
  intro p hp
  have h : env56785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56784_56785 : H12AffineEnvironment.transform 12 269 env56784 = env56785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env56784 == env56785) = true)

theorem identity56785 : scanCanonicalize (H12AffineFastState.compose env56785 (packedSelected [0,2,3,7,8,10,12,15,17,18,19] rootPS)) = affineNative (2^(10+1) ^^^ 561) := by decide +kernel

theorem selectedBound56785 : packedSelected [0,2,3,7,8,10,12,15,17,18,19] rootPS < 2^1333 := by decide +kernel

def env56786 : List Nat := [2,4,8,16,32,17,128,256,512,1024,561,1,269,1296,1296,34,1296,163,273,1297,0,397,17,50,1172,1280,318,1296,1296,1540,257,1281,256,260,1296,1808]

theorem envBound56786 : H12AffineFastState.Bounded env56786 := by
  intro p hp
  have h : env56786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56785_56786 : H12AffineEnvironment.transform 10 561 env56785 = env56786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 561 env56785 == env56786) = true)

theorem identity56786 : scanCanonicalize (H12AffineFastState.compose env56786 (packedSelected [2,3,5,13] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound56786 : packedSelected [2,3,5,13] rootPS < 2^1333 := by decide +kernel

def env56787 : List Nat := [2,4,8,16,32,17,128,256,26,1024,43,1,269,1296,1296,34,1296,163,273,1297,0,397,17,50,1172,1280,318,1296,1296,1054,257,1281,256,260,1296,1290]

theorem envBound56787 : H12AffineFastState.Bounded env56787 := by
  intro p hp
  have h : env56787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56786_56787 : H12AffineEnvironment.transform 8 26 env56786 = env56787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env56786 == env56787) = true)

theorem identity56787 : scanCanonicalize (H12AffineFastState.compose env56787 (packedSelected [1,3,4,9,10,11] rootPS)) = affineNative (2^(9+1) ^^^ 314) := by decide +kernel

theorem selectedBound56787 : packedSelected [1,3,4,9,10,11] rootPS < 2^1333 := by decide +kernel

def env56788 : List Nat := [2,4,8,16,32,17,128,256,26,314,43,1,269,42,42,34,42,163,273,43,0,397,17,50,430,58,318,42,42,292,257,59,256,260,42,48]

theorem envBound56788 : H12AffineFastState.Bounded env56788 := by
  intro p hp
  have h : env56788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56787_56788 : H12AffineEnvironment.transform 9 314 env56787 = env56788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 314 env56787 == env56788) = true)

theorem identity56788 : scanCanonicalize (H12AffineFastState.compose env56788 (packedSelected [0,1,2,3,5,7,8,10] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound56788 : packedSelected [0,1,2,3,5,7,8,10] rootPS < 2^1333 := by decide +kernel

def env56789 : List Nat := [2,4,8,16,32,17,128,14,26,52,43,1,3,42,42,34,42,163,31,43,0,131,17,50,160,58,48,42,42,42,15,59,14,10,42,48]

theorem envBound56789 : H12AffineFastState.Bounded env56789 := by
  intro p hp
  have h : env56789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56788_56789 : H12AffineEnvironment.transform 7 14 env56788 = env56789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env56788 == env56789) = true)

theorem identity56789 : scanCanonicalize (H12AffineFastState.compose env56789 (packedSelected [2,3,5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound56789 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env56790 : List Nat := [2,4,8,11,32,10,128,14,1,47,43,1,3,42,42,34,42,163,4,43,0,131,10,41,160,33,43,42,42,42,15,32,14,10,42,43]

theorem envBound56790 : H12AffineFastState.Bounded env56790 := by
  intro p hp
  have h : env56790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56789_56790 : H12AffineEnvironment.transform 3 11 env56789 = env56790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env56789 == env56790) = true)

theorem identity56790 : scanCanonicalize (H12AffineFastState.compose env56790 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound56790 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env56791 : List Nat := [2,4,4,7,32,6,128,2,1,35,39,1,3,38,38,34,38,163,4,39,0,131,6,37,160,33,39,38,38,38,3,32,2,6,38,39]

theorem envBound56791 : H12AffineFastState.Bounded env56791 := by
  intro p hp
  have h : env56791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56790_56791 : H12AffineEnvironment.transform 2 4 env56790 = env56791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env56790 == env56791) = true)

def env56792 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1344,262144,77935,32769,4097,46529,17,266385,70887,78895,77840,1296,74815,81227,365712,1281,256,365717,1345,79470]

theorem envBound56792 : H12AffineFastState.Bounded env56792 := by
  intro p hp
  have h : env56792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56739_56792 : H12AffineEnvironment.transform 13 1297 env56739 = env56792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env56739 == env56792) = true)

theorem identity56792 : scanCanonicalize (H12AffineFastState.compose env56792 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32883) := by decide +kernel

theorem selectedBound56792 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env56793 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,32883,1344,262144,45084,32769,4097,46529,17,266385,38036,46172,45155,1296,42060,48440,267491,1281,256,267494,1345,46621]

theorem envBound56793 : H12AffineFastState.Bounded env56793 := by
  intro p hp
  have h : env56793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56792_56793 : H12AffineEnvironment.transform 15 32883 env56792 = env56793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32883 env56792 == env56793) = true)

def env56794 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32883,1344,262144,42332,32769,1345,41089,17,263633,33236,41244,42275,1296,42060,43128,262563,1281,256,262566,1345,41821]

theorem envBound56794 : H12AffineFastState.Bounded env56794 := by
  intro p hp
  have h : env56794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56793_56794 : H12AffineEnvironment.transform 11 1344 env56793 = env56794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env56793 == env56794) = true)

theorem identity56794 : scanCanonicalize (H12AffineFastState.compose env56794 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 72) := by decide +kernel

theorem selectedBound56794 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env56795 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,72,1297,32768,32883,1344,262144,34068,32769,1345,32969,17,263633,33236,33108,34155,1296,33796,34864,262563,1281,256,262566,1345,33557]

theorem envBound56795 : H12AffineFastState.Bounded env56795 := by
  intro p hp
  have h : env56795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56794_56795 : H12AffineEnvironment.transform 12 72 env56794 = env56795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env56794 == env56795) = true)

theorem identity56795 : scanCanonicalize (H12AffineFastState.compose env56795 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(17+1) ^^^ 35605) := by decide +kernel

theorem selectedBound56795 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env56796 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,72,1297,32768,32883,1344,35605,34068,32769,1345,32969,17,36548,33236,33108,34155,1296,33796,34864,35510,1281,256,35507,1345,33557]

theorem envBound56796 : H12AffineFastState.Bounded env56796 := by
  intro p hp
  have h : env56796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56795_56796 : H12AffineEnvironment.transform 17 35605 env56795 = env56796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35605 env56795 == env56796) = true)

def env56797 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32883,1344,262144,42333,32769,1344,41088,17,263632,33237,41245,42274,1296,42060,43129,262562,1281,256,262567,1345,41820]

theorem envBound56797 : H12AffineFastState.Bounded env56797 := by
  intro p hp
  have h : env56797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56793_56797 : H12AffineEnvironment.transform 11 1345 env56793 = env56797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env56793 == env56797) = true)

theorem identity56797 : scanCanonicalize (H12AffineFastState.compose env56797 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 41146) := by decide +kernel

theorem selectedBound56797 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env56798 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32883,1344,41146,42333,32769,1344,41088,17,42346,33237,41245,42274,1296,42060,43129,41240,1281,256,41245,1345,41820]

theorem envBound56798 : H12AffineFastState.Bounded env56798 := by
  intro p hp
  have h : env56798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56797_56798 : H12AffineEnvironment.transform 17 41146 env56797 = env56798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 41146 env56797 == env56798) = true)

theorem identity56798 : scanCanonicalize (H12AffineFastState.compose env56798 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound56798 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env56799 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,8540,8495,1344,486,1025,8541,1344,476,17,1078,8329,65,1150,1296,1296,2341,68,1281,256,65,1345,512]

theorem envBound56799 : H12AffineFastState.Bounded env56799 := by
  intro p hp
  have h : env56799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56798_56799 : H12AffineEnvironment.transform 14 8540 env56798 = env56799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env56798 == env56799) = true)

theorem identity56799 : scanCanonicalize (H12AffineFastState.compose env56799 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound56799 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env56800 : List Nat := [2,4,8,16,32,64,128,21,512,1024,2048,1108,8192,1028,8265,8250,1109,243,1025,8264,1109,201,17,1078,8329,65,1150,1029,1029,2096,68,1044,21,65,1108,512]

theorem envBound56800 : H12AffineFastState.Bounded env56800 := by
  intro p hp
  have h : env56800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56799_56800 : H12AffineEnvironment.transform 7 21 env56799 = env56800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env56799 == env56800) = true)

theorem identity56800 : scanCanonicalize (H12AffineFastState.compose env56800 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 657) := by decide +kernel

theorem selectedBound56800 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env56801 : List Nat := [2,4,8,16,32,64,128,21,512,1024,2048,1108,657,1028,728,683,1109,243,1025,729,1109,201,17,1078,536,65,1150,1029,1029,2096,68,1044,21,65,1108,512]

theorem envBound56801 : H12AffineFastState.Bounded env56801 := by
  intro p hp
  have h : env56801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56800_56801 : H12AffineEnvironment.transform 12 657 env56800 = env56801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 657 env56800 == env56801) = true)

theorem identity56801 : scanCanonicalize (H12AffineFastState.compose env56801 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound56801 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env56802 : List Nat := [2,4,8,16,32,16,128,21,512,1024,2048,1028,657,1028,648,683,1029,163,1025,649,1029,153,17,1078,536,17,1070,1029,1029,2096,20,1044,21,17,1028,512]

theorem envBound56802 : H12AffineFastState.Bounded env56802 := by
  intro p hp
  have h : env56802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56801_56802 : H12AffineEnvironment.transform 5 16 env56801 = env56802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env56801 == env56802) = true)

theorem identity56802 : scanCanonicalize (H12AffineFastState.compose env56802 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound56802 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env56803 : List Nat := [2,4,8,16,32,16,128,21,512,4,2048,0,657,0,648,683,1,163,5,649,1,153,17,50,536,17,42,1,1,2096,20,16,21,17,0,512]

theorem envBound56803 : H12AffineFastState.Bounded env56803 := by
  intro p hp
  have h : env56803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56802_56803 : H12AffineEnvironment.transform 9 4 env56802 = env56803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env56802 == env56803) = true)

theorem identity56803 : scanCanonicalize (H12AffineFastState.compose env56803 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 31) := by decide +kernel

theorem selectedBound56803 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56804 : List Nat := [2,4,8,16,32,16,31,21,512,4,2048,0,526,0,535,564,1,60,5,534,1,6,17,50,536,17,42,1,1,2096,20,16,21,17,0,512]

theorem envBound56804 : H12AffineFastState.Bounded env56804 := by
  intro p hp
  have h : env56804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56803_56804 : H12AffineEnvironment.transform 6 31 env56803 = env56804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 31 env56803 == env56804) = true)

theorem identity56804 : scanCanonicalize (H12AffineFastState.compose env56804 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound56804 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env56805 : List Nat := [2,4,8,16,17,16,31,21,512,4,2048,0,526,0,535,517,1,13,5,534,1,6,17,3,536,17,27,1,1,2049,20,16,21,17,0,512]

theorem envBound56805 : H12AffineFastState.Bounded env56805 := by
  intro p hp
  have h : env56805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56804_56805 : H12AffineEnvironment.transform 4 17 env56804 = env56805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env56804 == env56805) = true)

theorem identity56805 : scanCanonicalize (H12AffineFastState.compose env56805 (packedSelected [0,2] rootPS)) = affineNative (2^(10+1) ^^^ 539) := by decide +kernel

theorem selectedBound56805 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env56806 : List Nat := [2,4,8,16,17,16,31,21,512,4,539,0,526,0,535,517,1,13,5,534,1,6,17,3,536,17,27,1,1,538,20,16,21,17,0,512]

theorem envBound56806 : H12AffineFastState.Bounded env56806 := by
  intro p hp
  have h : env56806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56805_56806 : H12AffineEnvironment.transform 10 539 env56805 = env56806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 539 env56805 == env56806) = true)

theorem identity56806 : scanCanonicalize (H12AffineFastState.compose env56806 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound56806 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env56807 : List Nat := [2,4,8,6,7,6,9,3,512,4,525,0,526,0,513,517,1,13,5,512,1,6,7,3,526,7,13,1,1,524,2,6,3,7,0,512]

theorem envBound56807 : H12AffineFastState.Bounded env56807 := by
  intro p hp
  have h : env56807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56806_56807 : H12AffineEnvironment.transform 3 6 env56806 = env56807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env56806 == env56807) = true)

theorem identity56807 : scanCanonicalize (H12AffineFastState.compose env56807 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 13) := by decide +kernel

theorem selectedBound56807 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56808 : List Nat := [2,4,8,6,7,6,9,3,13,4,0,0,3,0,12,8,1,13,5,13,1,6,7,3,3,7,13,1,1,1,2,6,3,7,0,13]

theorem envBound56808 : H12AffineFastState.Bounded env56808 := by
  intro p hp
  have h : env56808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56807_56808 : H12AffineEnvironment.transform 8 13 env56807 = env56808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 13 env56807 == env56808) = true)

def env56809 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95614,32769,4097,61648,147520,284033,86518,209263,225344,148801,74815,96346,381312,1281,256,381317,1345,95103]

theorem envBound56809 : H12AffineFastState.Bounded env56809 := by
  intro p hp
  have h : env56809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56675_56809 : H12AffineEnvironment.transform 23 284033 env56675 = env56809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 284033 env56675 == env56809) = true)

def env56810 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16464,262144,95614,32769,4097,61648,16,284033,86518,94527,77840,1297,74815,96346,381312,1281,256,381317,1345,95103]

theorem envBound56810 : H12AffineFastState.Bounded env56810 := by
  intro p hp
  have h : env56810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56809_56810 : H12AffineEnvironment.transform 16 16464 env56809 = env56810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16464 env56809 == env56810) = true)

def env56811 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1344,262144,77934,32769,4097,46528,16,266385,70886,78895,77840,1297,74815,81226,365712,1281,256,365717,1345,79471]

theorem envBound56811 : H12AffineFastState.Bounded env56811 := by
  intro p hp
  have h : env56811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56810_56811 : H12AffineEnvironment.transform 13 1296 env56810 = env56811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env56810 == env56811) = true)

theorem identity56811 : scanCanonicalize (H12AffineFastState.compose env56811 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32882) := by decide +kernel

theorem selectedBound56811 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env56812 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,32882,1344,262144,45084,32769,4097,46528,16,266385,38036,46173,45154,1297,42061,48440,267490,1281,256,267495,1345,46621]

theorem envBound56812 : H12AffineFastState.Bounded env56812 := by
  intro p hp
  have h : env56812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56811_56812 : H12AffineEnvironment.transform 15 32882 env56811 = env56812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32882 env56811 == env56812) = true)

def env56813 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32882,1344,262144,42332,32769,1345,41088,16,263633,33236,41245,42274,1297,42061,43128,262562,1281,256,262567,1345,41821]

theorem envBound56813 : H12AffineFastState.Bounded env56813 := by
  intro p hp
  have h : env56813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56812_56813 : H12AffineEnvironment.transform 11 1344 env56812 = env56813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env56812 == env56813) = true)

theorem identity56813 : scanCanonicalize (H12AffineFastState.compose env56813 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound56813 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env56814 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,0,8192,80,32768,32882,0,262144,40988,32769,1,41088,16,262289,33236,41245,41058,81,41229,43128,262562,65,256,262567,1,41821]

theorem envBound56814 : H12AffineFastState.Bounded env56814 := by
  intro p hp
  have h : env56814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56813_56814 : H12AffineEnvironment.transform 9 320 env56813 = env56814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env56813 == env56814) = true)

theorem identity56814 : scanCanonicalize (H12AffineFastState.compose env56814 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound56814 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env56815 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,0,8192,80,8541,8495,0,262144,321,8540,1,477,16,262289,8329,64,319,81,80,2341,262562,65,256,262567,1,512]

theorem envBound56815 : H12AffineFastState.Bounded env56815 := by
  intro p hp
  have h : env56815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56814_56815 : H12AffineEnvironment.transform 14 8541 env56814 = env56815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env56814 == env56815) = true)

theorem identity56815 : scanCanonicalize (H12AffineFastState.compose env56815 (packedSelected [4,9,16] rootPS)) = affineNative (2^(17+1) ^^^ 243) := by decide +kernel

theorem selectedBound56815 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env56816 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,0,8192,80,8541,8495,0,243,321,8540,1,477,16,98,8329,64,319,81,80,2341,337,65,256,340,1,512]

theorem envBound56816 : H12AffineFastState.Bounded env56816 := by
  intro p hp
  have h : env56816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56815_56816 : H12AffineEnvironment.transform 17 243 env56815 = env56816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 243 env56815 == env56816) = true)

theorem identity56816 : scanCanonicalize (H12AffineFastState.compose env56816 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 900) := by decide +kernel

theorem selectedBound56816 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env56817 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,0,900,80,729,683,0,243,321,728,1,477,16,98,781,64,319,81,80,2341,337,65,256,340,1,512]

theorem envBound56817 : H12AffineFastState.Bounded env56817 := by
  intro p hp
  have h : env56817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56816_56817 : H12AffineEnvironment.transform 12 900 env56816 = env56817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 900 env56816 == env56817) = true)

theorem identity56817 : scanCanonicalize (H12AffineFastState.compose env56817 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound56817 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env56818 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,0,900,0,649,683,0,163,273,648,1,397,16,50,781,16,319,1,0,2341,257,17,256,260,1,512]

theorem envBound56818 : H12AffineFastState.Bounded env56818 := by
  intro p hp
  have h : env56818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56817_56818 : H12AffineEnvironment.transform 5 16 env56817 = env56818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env56817 == env56818) = true)

theorem identity56818 : scanCanonicalize (H12AffineFastState.compose env56818 (packedSelected [1,3,13] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound56818 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env56819 : List Nat := [2,4,8,16,32,16,57,256,512,272,2048,0,829,0,560,530,0,26,273,561,1,308,16,50,781,16,319,1,0,2341,257,17,256,260,1,512]

theorem envBound56819 : H12AffineFastState.Bounded env56819 := by
  intro p hp
  have h : env56819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56818_56819 : H12AffineEnvironment.transform 6 57 env56818 = env56819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env56818 == env56819) = true)

theorem identity56819 : scanCanonicalize (H12AffineFastState.compose env56819 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 561) := by decide +kernel

theorem selectedBound56819 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56820 : List Nat := [2,4,8,16,32,16,57,256,512,272,561,0,829,0,560,530,0,26,273,561,1,308,16,50,781,16,319,1,0,788,257,17,256,260,1,512]

theorem envBound56820 : H12AffineFastState.Bounded env56820 := by
  intro p hp
  have h : env56820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56819_56820 : H12AffineEnvironment.transform 10 561 env56819 = env56820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 561 env56819 == env56820) = true)

theorem identity56820 : scanCanonicalize (H12AffineFastState.compose env56820 (packedSelected [0,5] rootPS)) = affineNative (2^(8+1) ^^^ 318) := by decide +kernel

theorem selectedBound56820 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env56821 : List Nat := [2,4,8,16,32,16,57,256,318,272,271,0,3,0,270,300,0,26,273,271,1,308,16,50,51,16,319,1,0,42,257,17,256,260,1,318]

theorem envBound56821 : H12AffineFastState.Bounded env56821 := by
  intro p hp
  have h : env56821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56820_56821 : H12AffineEnvironment.transform 8 318 env56820 = env56821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 318 env56820 == env56821) = true)

theorem identity56821 : scanCanonicalize (H12AffineFastState.compose env56821 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound56821 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env56822 : List Nat := [2,4,8,16,32,16,57,15,49,31,0,0,3,0,1,35,0,26,30,0,1,59,16,50,51,16,48,1,0,42,14,17,15,11,1,49]

theorem envBound56822 : H12AffineFastState.Bounded env56822 := by
  intro p hp
  have h : env56822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56821_56822 : H12AffineEnvironment.transform 7 15 env56821 = env56822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env56821 == env56822) = true)

def env56823 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32882,1344,262144,42333,32769,1344,41089,16,263632,33237,41244,42275,1297,42061,43129,262563,1281,256,262566,1345,41820]

theorem envBound56823 : H12AffineFastState.Bounded env56823 := by
  intro p hp
  have h : env56823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56812_56823 : H12AffineEnvironment.transform 11 1345 env56812 = env56823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env56812 == env56823) = true)

theorem identity56823 : scanCanonicalize (H12AffineFastState.compose env56823 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 34227) := by decide +kernel

theorem selectedBound56823 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env56824 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32882,1344,34227,42333,32769,1344,41089,16,32867,33237,41244,42275,1297,42061,43129,33808,1281,256,33813,1345,41820]

theorem envBound56824 : H12AffineFastState.Bounded env56824 := by
  intro p hp
  have h : env56824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56823_56824 : H12AffineEnvironment.transform 17 34227 env56823 = env56824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 34227 env56823 == env56824) = true)

theorem identity56824 : scanCanonicalize (H12AffineFastState.compose env56824 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(12+1) ^^^ 3822) := by decide +kernel

theorem selectedBound56824 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env56825 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,3822,1296,32768,32882,1344,34227,35763,32769,1344,36463,16,32867,33237,36850,35789,1297,35491,34455,33808,1281,256,33813,1345,36274]

theorem envBound56825 : H12AffineFastState.Bounded env56825 := by
  intro p hp
  have h : env56825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56824_56825 : H12AffineEnvironment.transform 12 3822 env56824 = env56825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3822 env56824 == env56825) = true)

def env56826 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1345,262144,77935,32769,4097,46529,16,266384,70887,78894,77840,1297,74815,81227,365713,1281,256,365716,1345,79470]

theorem envBound56826 : H12AffineFastState.Bounded env56826 := by
  intro p hp
  have h : env56826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56810_56826 : H12AffineEnvironment.transform 13 1297 env56810 = env56826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env56810 == env56826) = true)

theorem identity56826 : scanCanonicalize (H12AffineFastState.compose env56826 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound56826 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env56827 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1345,262144,77935,13341,4097,477,16,266384,70887,78894,77840,1297,74815,81227,336013,1281,256,336008,1345,79470]

theorem envBound56827 : H12AffineFastState.Bounded env56827 := by
  intro p hp
  have h : env56827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56826_56827 : H12AffineEnvironment.transform 14 13340 env56826 = env56827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env56826 == env56827) = true)

def env56828 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1345,65664,77935,13341,4097,477,16,69648,70887,78894,77840,1297,74815,81227,8205,1281,256,8200,1345,79470]

theorem envBound56828 : H12AffineFastState.Bounded env56828 := by
  intro p hp
  have h : env56828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56827_56828 : H12AffineEnvironment.transform 17 65664 env56827 = env56828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env56827 == env56828) = true)

theorem identity56828 : scanCanonicalize (H12AffineFastState.compose env56828 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5158) := by decide +kernel

theorem selectedBound56828 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env56829 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,5158,1345,5286,9289,13341,4097,477,16,1078,193,8200,9270,1297,12313,10605,8205,1281,256,8200,1345,8776]

theorem envBound56829 : H12AffineFastState.Bounded env56829 := by
  intro p hp
  have h : env56829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56828_56829 : H12AffineEnvironment.transform 15 5158 env56828 = env56829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5158 env56828 == env56829) = true)

def env56830 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,1297,13340,5158,1297,5286,9241,13341,4097,397,16,1078,145,8200,9270,1297,12313,10557,8205,1281,256,8200,1297,8728]

theorem envBound56830 : H12AffineFastState.Bounded env56830 := by
  intro p hp
  have h : env56830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56829_56830 : H12AffineEnvironment.transform 5 16 env56829 = env56830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env56829 == env56830) = true)

theorem identity56830 : scanCanonicalize (H12AffineFastState.compose env56830 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound56830 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env56831 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1028,8192,1297,8216,34,1297,162,9241,8217,1029,397,16,1078,145,8200,9270,1297,9245,10557,8205,1281,256,8200,1297,8728]

theorem envBound56831 : H12AffineFastState.Bounded env56831 := by
  intro p hp
  have h : env56831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56830_56831 : H12AffineEnvironment.transform 11 1028 env56830 = env56831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env56830 == env56831) = true)

theorem identity56831 : scanCanonicalize (H12AffineFastState.compose env56831 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound56831 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env56832 : List Nat := [2,4,8,16,32,16,128,20,512,1024,2048,1028,8192,1029,8216,34,1029,162,9241,8217,1029,153,16,1078,145,8200,9270,1029,9245,10281,8205,1045,20,8200,1029,8728]

theorem envBound56832 : H12AffineFastState.Bounded env56832 := by
  intro p hp
  have h : env56832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56831_56832 : H12AffineEnvironment.transform 7 20 env56831 = env56832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env56831 == env56832) = true)

theorem identity56832 : scanCanonicalize (H12AffineFastState.compose env56832 (packedSelected [0,1,3,5,7,8,11,12,13,15] rootPS)) = affineNative (2^(12+1) ^^^ 2235) := by decide +kernel

theorem selectedBound56832 : packedSelected [0,1,3,5,7,8,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env56833 : List Nat := [2,4,8,16,32,16,128,20,512,1024,2048,1028,2235,1029,2211,34,1029,162,3234,2210,1029,153,16,1078,145,2227,3213,1029,3238,146,2230,1045,20,2227,1029,2723]

theorem envBound56833 : H12AffineFastState.Bounded env56833 := by
  intro p hp
  have h : env56833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56832_56833 : H12AffineEnvironment.transform 12 2235 env56832 = env56833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2235 env56832 == env56833) = true)

theorem identity56833 : scanCanonicalize (H12AffineFastState.compose env56833 (packedSelected [0,2,7,11,17] rootPS)) = affineNative (2^(10+1) ^^^ 696) := by decide +kernel

theorem selectedBound56833 : packedSelected [0,2,7,11,17] rootPS < 2^1333 := by decide +kernel

def env56834 : List Nat := [2,4,8,16,32,16,128,20,512,1024,696,1028,515,1029,539,34,1029,162,1562,538,1029,153,16,1078,145,523,1589,1029,1566,146,526,1045,20,523,1029,27]

theorem envBound56834 : H12AffineFastState.Bounded env56834 := by
  intro p hp
  have h : env56834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56833_56834 : H12AffineEnvironment.transform 10 696 env56833 = env56834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 696 env56833 == env56834) = true)

theorem identity56834 : scanCanonicalize (H12AffineFastState.compose env56834 (packedSelected [1,2,5,13] rootPS)) = affineNative (2^(9+1) ^^^ 564) := by decide +kernel

theorem selectedBound56834 : packedSelected [1,2,5,13] rootPS < 2^1333 := by decide +kernel

def env56835 : List Nat := [2,4,8,16,32,16,128,20,512,564,696,560,515,561,539,34,561,162,46,538,561,153,16,514,145,523,1,561,42,146,526,545,20,523,561,27]

theorem envBound56835 : H12AffineFastState.Bounded env56835 := by
  intro p hp
  have h : env56835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56834_56835 : H12AffineEnvironment.transform 9 564 env56834 = env56835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 564 env56834 == env56835) = true)

theorem identity56835 : scanCanonicalize (H12AffineFastState.compose env56835 (packedSelected [1,2,4,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound56835 : packedSelected [1,2,4,8,9] rootPS < 2^1333 := by decide +kernel

def env56836 : List Nat := [2,4,8,16,32,16,8,20,512,564,560,560,515,561,539,34,561,42,46,538,561,17,16,514,25,523,1,561,42,26,526,545,20,523,561,27]

theorem envBound56836 : H12AffineFastState.Bounded env56836 := by
  intro p hp
  have h : env56836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56835_56836 : H12AffineEnvironment.transform 6 8 env56835 = env56836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env56835 == env56836) = true)

theorem identity56836 : scanCanonicalize (H12AffineFastState.compose env56836 (packedSelected [1,2,5] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound56836 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env56837 : List Nat := [2,4,8,16,32,16,8,20,42,30,26,26,41,27,49,34,27,42,46,48,27,17,16,40,25,33,1,27,42,26,36,11,20,33,27,27]

theorem envBound56837 : H12AffineFastState.Bounded env56837 := by
  intro p hp
  have h : env56837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56836_56837 : H12AffineEnvironment.transform 8 42 env56836 = env56837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env56836 == env56837) = true)

def env56838 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,1297,13340,5158,1296,5286,9240,13341,4097,396,16,1078,144,8200,9270,1297,12313,10556,8205,1281,256,8200,1296,8729]

theorem envBound56838 : H12AffineFastState.Bounded env56838 := by
  intro p hp
  have h : env56838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56829_56838 : H12AffineEnvironment.transform 5 17 env56829 = env56838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env56829 == env56838) = true)

theorem identity56838 : scanCanonicalize (H12AffineFastState.compose env56838 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 5148) := by decide +kernel

theorem selectedBound56838 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env56839 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,5148,1297,0,5158,1296,5286,4100,1,4097,396,16,1078,144,5140,4138,1297,1029,7456,5137,1281,256,5140,1296,5637]

theorem envBound56839 : H12AffineFastState.Bounded env56839 := by
  intro p hp
  have h : env56839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56838_56839 : H12AffineEnvironment.transform 12 5148 env56838 = env56839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5148 env56838 == env56839) = true)

theorem identity56839 : scanCanonicalize (H12AffineFastState.compose env56839 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound56839 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env56840 : List Nat := [2,4,8,16,32,17,128,21,512,1024,2048,4096,5148,1028,0,5158,1029,5286,4100,1,4097,153,16,1078,144,5140,4138,1028,1029,7221,5137,1044,21,5140,1029,5637]

theorem envBound56840 : H12AffineFastState.Bounded env56840 := by
  intro p hp
  have h : env56840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56839_56840 : H12AffineEnvironment.transform 7 21 env56839 = env56840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env56839 == env56840) = true)

theorem identity56840 : scanCanonicalize (H12AffineFastState.compose env56840 (packedSelected [10,11,13,17,18,19] rootPS)) = affineNative (2^(11+1) ^^^ 49) := by decide +kernel

theorem selectedBound56840 : packedSelected [10,11,13,17,18,19] rootPS < 2^1333 := by decide +kernel

def env56841 : List Nat := [2,4,8,16,32,17,128,21,512,1024,2048,49,1069,1028,0,1047,1029,1175,53,1,48,153,16,1078,144,1061,27,1028,1029,3076,1056,1044,21,1061,1029,1588]

theorem envBound56841 : H12AffineFastState.Bounded env56841 := by
  intro p hp
  have h : env56841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56840_56841 : H12AffineEnvironment.transform 11 49 env56840 = env56841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env56840 == env56841) = true)

theorem identity56841 : scanCanonicalize (H12AffineFastState.compose env56841 (packedSelected [0,7,11,12,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 1165) := by decide +kernel

theorem selectedBound56841 : packedSelected [0,7,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env56842 : List Nat := [2,4,8,16,32,17,128,21,512,1024,1165,49,1069,1028,0,1047,1029,1175,53,1,48,153,16,1078,144,1061,27,1028,1029,137,1056,1044,21,1061,1029,1588]

theorem envBound56842 : H12AffineFastState.Bounded env56842 := by
  intro p hp
  have h : env56842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56841_56842 : H12AffineEnvironment.transform 10 1165 env56841 = env56842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1165 env56841 == env56842) = true)

theorem identity56842 : scanCanonicalize (H12AffineFastState.compose env56842 (packedSelected [1,4,5,9] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound56842 : packedSelected [1,4,5,9] rootPS < 2^1333 := by decide +kernel

def env56843 : List Nat := [2,4,8,16,32,17,57,21,512,1024,1076,49,1069,1028,0,1047,1029,1070,53,1,48,32,16,1078,41,1061,27,1028,1029,48,1056,1044,21,1061,1029,1588]

theorem envBound56843 : H12AffineFastState.Bounded env56843 := by
  intro p hp
  have h : env56843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56842_56843 : H12AffineEnvironment.transform 6 57 env56842 = env56843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env56842 == env56843) = true)

theorem identity56843 : scanCanonicalize (H12AffineFastState.compose env56843 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 516) := by decide +kernel

theorem selectedBound56843 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56844 : List Nat := [2,4,8,16,32,17,57,21,512,516,560,49,553,512,0,531,513,554,53,1,48,32,16,562,41,545,27,512,513,48,548,528,21,545,513,48]

theorem envBound56844 : H12AffineFastState.Bounded env56844 := by
  intro p hp
  have h : env56844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56843_56844 : H12AffineEnvironment.transform 9 516 env56843 = env56844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 516 env56843 == env56844) = true)

theorem identity56844 : scanCanonicalize (H12AffineFastState.compose env56844 (packedSelected [1,3,4,5,7,8] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound56844 : packedSelected [1,3,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env56845 : List Nat := [2,4,8,16,32,17,57,21,1,5,49,49,40,1,0,18,0,43,53,1,48,32,16,51,41,32,27,1,0,48,37,17,21,32,0,48]

theorem envBound56845 : H12AffineFastState.Bounded env56845 := by
  intro p hp
  have h : env56845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56844_56845 : H12AffineEnvironment.transform 8 1 env56844 = env56845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env56844 == env56845) = true)

theorem identity56845 : scanCanonicalize (H12AffineFastState.compose env56845 (packedSelected [0,1,4] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound56845 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env56846 : List Nat := [2,4,8,16,7,17,30,21,1,5,22,22,15,1,0,18,0,12,18,1,23,7,16,20,14,7,27,1,0,23,2,17,21,7,0,23]

theorem envBound56846 : H12AffineFastState.Bounded env56846 := by
  intro p hp
  have h : env56846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56845_56846 : H12AffineEnvironment.transform 4 7 env56845 = env56846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env56845 == env56846) = true)

theorem identity56846 : scanCanonicalize (H12AffineFastState.compose env56846 (packedSelected [1,5] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound56846 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env56847 : List Nat := [2,4,4,16,7,17,18,21,1,5,22,22,3,1,0,18,0,0,18,1,23,7,16,20,2,7,23,1,0,23,2,17,21,7,0,23]

theorem envBound56847 : H12AffineFastState.Bounded env56847 := by
  intro p hp
  have h : env56847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56846_56847 : H12AffineEnvironment.transform 2 4 env56846 = env56847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env56846 == env56847) = true)

theorem identity56847 : scanCanonicalize (H12AffineFastState.compose env56847 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound56847 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env56848 : List Nat := [2,4,4,6,7,7,4,3,1,5,0,0,3,1,0,4,0,0,4,1,1,7,6,2,2,7,1,1,0,1,2,7,3,7,0,1]

theorem envBound56848 : H12AffineFastState.Bounded env56848 := by
  intro p hp
  have h : env56848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56847_56848 : H12AffineEnvironment.transform 3 6 env56847 = env56848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env56847 == env56848) = true)

def env56849 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1345,65665,77935,13341,4097,477,16,69649,70887,78894,77840,1297,74815,81227,8204,1281,256,8201,1345,79470]

theorem envBound56849 : H12AffineFastState.Bounded env56849 := by
  intro p hp
  have h : env56849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56827_56849 : H12AffineEnvironment.transform 17 65665 env56827 = env56849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env56827 == env56849) = true)

theorem identity56849 : scanCanonicalize (H12AffineFastState.compose env56849 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 359) := by decide +kernel

theorem selectedBound56849 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env56850 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,359,1345,486,12552,13341,4097,477,16,4470,5504,13641,12663,1297,9560,15404,8204,1281,256,8201,1345,14089]

theorem envBound56850 : H12AffineFastState.Bounded env56850 := by
  intro p hp
  have h : env56850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56849_56850 : H12AffineEnvironment.transform 15 359 env56849 = env56850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 359 env56849 == env56850) = true)

def env56851 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,7632,1297,2508,359,1345,486,3288,2509,4097,477,16,4470,5504,2201,3239,1297,6280,508,7644,1281,256,7641,1345,2777]

theorem envBound56851 : H12AffineFastState.Bounded env56851 := by
  intro p hp
  have h : env56851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56850_56851 : H12AffineEnvironment.transform 12 7632 env56850 = env56851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7632 env56850 == env56851) = true)

def env56852 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1344,4096,4240,1297,1164,359,1345,486,408,1165,4097,477,16,4470,5504,1497,487,1297,5576,508,4252,1281,256,4249,1345,1945]

theorem envBound56852 : H12AffineFastState.Bounded env56852 := by
  intro p hp
  have h : env56852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56851_56852 : H12AffineEnvironment.transform 10 1344 env56851 = env56852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1344 env56851 == env56852) = true)

theorem identity56852 : scanCanonicalize (H12AffineFastState.compose env56852 (packedSelected [13] rootPS)) = affineNative (2^(11+1) ^^^ 96) := by decide +kernel

theorem selectedBound56852 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env56853 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1344,96,240,1297,1164,359,1345,486,408,1165,97,477,16,278,1504,1497,487,1297,1448,508,252,1281,256,249,1345,1945]

theorem envBound56853 : H12AffineFastState.Bounded env56853 := by
  intro p hp
  have h : env56853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56852_56853 : H12AffineEnvironment.transform 11 96 env56852 = env56853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 96 env56852 == env56853) = true)

theorem identity56853 : scanCanonicalize (H12AffineFastState.compose env56853 (packedSelected [1,2,5,8,10,11,15,16,17,19,21,24] rootPS)) = affineNative (2^(8+1) ^^^ 146) := by decide +kernel

theorem selectedBound56853 : packedSelected [1,2,5,8,10,11,15,16,17,19,21,24] rootPS < 2^1333 := by decide +kernel

def env56854 : List Nat := [2,4,8,16,32,64,128,256,146,1024,1344,96,240,1297,1164,359,1345,486,408,1165,97,477,16,278,1504,1497,487,1297,1448,508,252,1281,256,249,1345,1291]

theorem envBound56854 : H12AffineFastState.Bounded env56854 := by
  intro p hp
  have h : env56854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56853_56854 : H12AffineEnvironment.transform 8 146 env56853 = env56854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 146 env56853 == env56854) = true)

theorem identity56854 : scanCanonicalize (H12AffineFastState.compose env56854 (packedSelected [2,7,9,10,15,16,17] rootPS)) = affineNative (2^(9+1) ^^^ 140) := by decide +kernel

theorem selectedBound56854 : packedSelected [2,7,9,10,15,16,17] rootPS < 2^1333 := by decide +kernel

def env56855 : List Nat := [2,4,8,16,32,64,128,256,146,140,460,96,240,413,0,359,461,486,408,1,97,477,16,278,364,341,487,413,292,508,252,397,256,249,461,391]

theorem envBound56855 : H12AffineFastState.Bounded env56855 := by
  intro p hp
  have h : env56855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56854_56855 : H12AffineEnvironment.transform 9 140 env56854 = env56855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 140 env56854 == env56855) = true)

theorem identity56855 : scanCanonicalize (H12AffineFastState.compose env56855 (packedSelected [2,3,5,7,9,11,15] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound56855 : packedSelected [2,3,5,7,9,11,15] rootPS < 2^1333 := by decide +kernel

def env56856 : List Nat := [2,4,8,16,32,64,19,256,1,31,351,96,99,270,0,359,350,373,267,1,97,334,16,278,364,341,372,270,292,367,111,286,256,106,350,276]

theorem envBound56856 : H12AffineFastState.Bounded env56856 := by
  intro p hp
  have h : env56856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56855_56856 : H12AffineEnvironment.transform 6 19 env56855 = env56856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env56855 == env56856) = true)

theorem identity56856 : scanCanonicalize (H12AffineFastState.compose env56856 (packedSelected [1,4,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound56856 : packedSelected [1,4,7,8] rootPS < 2^1333 := by decide +kernel

def env56857 : List Nat := [2,4,8,16,32,64,19,14,1,31,81,96,99,0,0,105,80,123,5,1,97,64,16,24,98,91,122,0,42,97,111,16,14,106,80,26]

theorem envBound56857 : H12AffineFastState.Bounded env56857 := by
  intro p hp
  have h : env56857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56856_56857 : H12AffineEnvironment.transform 7 14 env56856 = env56857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env56856 == env56857) = true)

theorem identity56857 : scanCanonicalize (H12AffineFastState.compose env56857 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound56857 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56858 : List Nat := [2,4,8,16,11,64,19,14,1,31,81,75,72,0,0,66,80,80,5,1,74,64,16,24,73,91,81,0,1,74,68,16,14,65,80,26]

theorem envBound56858 : H12AffineFastState.Bounded env56858 := by
  intro p hp
  have h : env56858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56857_56858 : H12AffineEnvironment.transform 4 11 env56857 = env56858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env56857 == env56858) = true)

theorem identity56858 : scanCanonicalize (H12AffineFastState.compose env56858 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound56858 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env56859 : List Nat := [2,4,8,16,11,10,19,14,1,31,27,1,2,0,0,8,26,26,5,1,0,10,16,24,3,17,27,0,1,0,14,16,14,11,26,26]

theorem envBound56859 : H12AffineFastState.Bounded env56859 := by
  intro p hp
  have h : env56859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56858_56859 : H12AffineEnvironment.transform 5 10 env56858 = env56859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env56858 == env56859) = true)

def env56860 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1345,4096,4241,1297,1165,359,1345,486,409,1164,4097,477,16,4470,5504,1496,486,1297,5577,508,4253,1281,256,4248,1345,1944]

theorem envBound56860 : H12AffineFastState.Bounded env56860 := by
  intro p hp
  have h : env56860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56851_56860 : H12AffineEnvironment.transform 10 1345 env56851 = env56860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1345 env56851 == env56860) = true)

theorem identity56860 : scanCanonicalize (H12AffineFastState.compose env56860 (packedSelected [13] rootPS)) = affineNative (2^(11+1) ^^^ 1393) := by decide +kernel

theorem selectedBound56860 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env56861 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1345,1393,1504,1297,1165,359,1345,486,409,1164,1392,477,16,1031,241,1496,486,1297,184,508,1516,1281,256,1513,1345,1944]

theorem envBound56861 : H12AffineFastState.Bounded env56861 := by
  intro p hp
  have h : env56861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56860_56861 : H12AffineEnvironment.transform 11 1393 env56860 = env56861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1393 env56860 == env56861) = true)

theorem identity56861 : scanCanonicalize (H12AffineFastState.compose env56861 (packedSelected [1,2,3,5,8,10,11,12,16,19,20,21] rootPS)) = affineNative (2^(8+1) ^^^ 195) := by decide +kernel

theorem selectedBound56861 : packedSelected [1,2,3,5,8,10,11,12,16,19,20,21] rootPS < 2^1333 := by decide +kernel

def env56862 : List Nat := [2,4,8,16,32,64,128,256,195,1024,1345,1393,1504,1297,1165,359,1345,486,409,1164,1392,477,16,1031,241,1496,486,1297,184,508,1516,1281,256,1513,1345,1371]

theorem envBound56862 : H12AffineFastState.Bounded env56862 := by
  intro p hp
  have h : env56862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56861_56862 : H12AffineEnvironment.transform 8 195 env56861 = env56862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 195 env56861 == env56862) = true)

theorem identity56862 : scanCanonicalize (H12AffineFastState.compose env56862 (packedSelected [0,2,4,5,8,11,12,16,23] rootPS)) = affineNative (2^(9+1) ^^^ 289) := by decide +kernel

theorem selectedBound56862 : packedSelected [0,2,4,5,8,11,12,16,23] rootPS < 2^1333 := by decide +kernel

def env56863 : List Nat := [2,4,8,16,32,64,128,256,195,289,96,80,193,48,428,359,96,486,409,429,81,477,16,294,241,249,486,48,184,508,205,32,256,200,96,122]

theorem envBound56863 : H12AffineFastState.Bounded env56863 := by
  intro p hp
  have h : env56863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56862_56863 : H12AffineEnvironment.transform 9 289 env56862 = env56863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 289 env56862 == env56863) = true)

theorem identity56863 : scanCanonicalize (H12AffineFastState.compose env56863 (packedSelected [0,1,2,3,5,8,9,11,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound56863 : packedSelected [0,1,2,3,5,8,9,11,12,15] rootPS < 2^1333 := by decide +kernel

def env56864 : List Nat := [2,4,8,16,32,32,128,256,163,289,0,48,161,48,428,263,0,390,409,429,49,445,16,294,145,153,390,48,184,412,173,32,256,168,0,26]

theorem envBound56864 : H12AffineFastState.Bounded env56864 := by
  intro p hp
  have h : env56864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56863_56864 : H12AffineEnvironment.transform 5 32 env56863 = env56864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env56863 == env56864) = true)

theorem identity56864 : scanCanonicalize (H12AffineFastState.compose env56864 (packedSelected [0,2,3,4,8,10] rootPS)) = affineNative (2^(7+1) ^^^ 157) := by decide +kernel

theorem selectedBound56864 : packedSelected [0,2,3,4,8,10] rootPS < 2^1333 := by decide +kernel

def env56865 : List Nat := [2,4,8,16,32,32,128,157,163,188,0,48,161,48,49,154,0,27,4,48,49,32,16,187,145,153,27,48,184,1,173,32,157,168,0,26]

theorem envBound56865 : H12AffineFastState.Bounded env56865 := by
  intro p hp
  have h : env56865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56864_56865 : H12AffineEnvironment.transform 7 157 env56864 = env56865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 157 env56864 == env56865) = true)

def env56866 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,7633,1297,2509,359,1345,486,3289,2508,4097,477,16,4470,5504,2200,3238,1297,6281,509,7645,1281,256,7640,1345,2776]

theorem envBound56866 : H12AffineFastState.Bounded env56866 := by
  intro p hp
  have h : env56866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56850_56866 : H12AffineEnvironment.transform 12 7633 env56850 = env56866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7633 env56850 == env56866) = true)

def env56867 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1344,4096,4241,1297,1165,359,1345,486,409,1164,4097,477,16,4470,5504,1496,486,1297,5577,509,4253,1281,256,4248,1345,1944]

theorem envBound56867 : H12AffineFastState.Bounded env56867 := by
  intro p hp
  have h : env56867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56866_56867 : H12AffineEnvironment.transform 10 1344 env56866 = env56867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1344 env56866 == env56867) = true)

theorem identity56867 : scanCanonicalize (H12AffineFastState.compose env56867 (packedSelected [13] rootPS)) = affineNative (2^(11+1) ^^^ 233) := by decide +kernel

theorem selectedBound56867 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env56868 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1344,233,120,1297,1165,359,1345,486,409,1164,232,477,16,415,1385,1496,486,1297,1312,509,116,1281,256,113,1345,1944]

theorem envBound56868 : H12AffineFastState.Bounded env56868 := by
  intro p hp
  have h : env56868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56867_56868 : H12AffineEnvironment.transform 11 233 env56867 = env56868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 233 env56867 == env56868) = true)

theorem identity56868 : scanCanonicalize (H12AffineFastState.compose env56868 (packedSelected [2,12,16,18,21] rootPS)) = affineNative (2^(8+1) ^^^ 367) := by decide +kernel

theorem selectedBound56868 : packedSelected [2,12,16,18,21] rootPS < 2^1333 := by decide +kernel

def env56869 : List Nat := [2,4,8,16,32,64,128,256,367,1024,1344,233,120,1297,1165,359,1345,486,409,1164,232,477,16,415,1385,1496,486,1297,1312,509,116,1281,256,113,1345,1271]

theorem envBound56869 : H12AffineFastState.Bounded env56869 := by
  intro p hp
  have h : env56869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56868_56869 : H12AffineEnvironment.transform 8 367 env56868 = env56869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 367 env56868 == env56869) = true)

theorem identity56869 : scanCanonicalize (H12AffineFastState.compose env56869 (packedSelected [3,4,5,7,16,17,18,19,20] rootPS)) = affineNative (2^(6+1) ^^^ 104) := by decide +kernel

theorem selectedBound56869 : packedSelected [3,4,5,7,16,17,18,19,20] rootPS < 2^1333 := by decide +kernel

def env56870 : List Nat := [2,4,8,16,32,64,104,256,367,1024,1344,1,120,1297,1125,359,1345,270,369,1124,0,309,16,375,1385,1328,270,1297,1312,277,116,1281,256,113,1345,1055]

theorem envBound56870 : H12AffineFastState.Bounded env56870 := by
  intro p hp
  have h : env56870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56869_56870 : H12AffineEnvironment.transform 6 104 env56869 = env56870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 104 env56869 == env56870) = true)

theorem identity56870 : scanCanonicalize (H12AffineFastState.compose env56870 (packedSelected [1,2,3,4,7,10,12] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound56870 : packedSelected [1,2,3,4,7,10,12] rootPS < 2^1333 := by decide +kernel

def env56871 : List Nat := [2,4,8,16,32,64,104,256,367,101,293,1,120,372,0,359,292,270,369,1,0,309,16,375,268,341,270,372,325,277,116,356,256,113,292,122]

theorem envBound56871 : H12AffineFastState.Bounded env56871 := by
  intro p hp
  have h : env56871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56870_56871 : H12AffineEnvironment.transform 9 101 env56870 = env56871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env56870 == env56871) = true)

theorem identity56871 : scanCanonicalize (H12AffineFastState.compose env56871 (packedSelected [0,2,5,9] rootPS)) = affineNative (2^(5+1) ^^^ 44) := by decide +kernel

theorem selectedBound56871 : packedSelected [0,2,5,9] rootPS < 2^1333 := by decide +kernel

def env56872 : List Nat := [2,4,8,16,32,44,4,256,259,9,293,1,20,280,0,267,292,270,285,1,0,309,16,283,268,313,270,280,297,277,24,264,256,29,292,22]

theorem envBound56872 : H12AffineFastState.Bounded env56872 := by
  intro p hp
  have h : env56872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56871_56872 : H12AffineEnvironment.transform 5 44 env56871 = env56872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 44 env56871 == env56872) = true)

theorem identity56872 : scanCanonicalize (H12AffineFastState.compose env56872 (packedSelected [3,4,5,7,8,10] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound56872 : packedSelected [3,4,5,7,8,10] rootPS < 2^1333 := by decide +kernel

def env56873 : List Nat := [2,4,8,10,32,44,4,256,259,9,293,1,14,258,0,267,292,270,263,1,0,303,10,257,268,291,270,258,297,271,2,264,256,7,292,12]

theorem envBound56873 : H12AffineFastState.Bounded env56873 := by
  intro p hp
  have h : env56873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56872_56873 : H12AffineEnvironment.transform 3 10 env56872 = env56873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env56872 == env56873) = true)

theorem identity56873 : scanCanonicalize (H12AffineFastState.compose env56873 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound56873 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env56874 : List Nat := [2,4,8,10,7,11,4,256,259,9,258,1,14,258,0,267,259,270,263,1,0,264,10,257,268,260,270,258,270,271,2,264,256,7,259,12]

theorem envBound56874 : H12AffineFastState.Bounded env56874 := by
  intro p hp
  have h : env56874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56873_56874 : H12AffineEnvironment.transform 4 7 env56873 = env56874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env56873 == env56874) = true)

theorem identity56874 : scanCanonicalize (H12AffineFastState.compose env56874 (packedSelected [0,1,4] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound56874 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env56875 : List Nat := [2,4,4,6,7,7,4,256,259,5,258,1,2,258,0,263,259,258,263,1,0,260,6,257,256,260,258,258,258,259,2,260,256,7,259,0]

theorem envBound56875 : H12AffineFastState.Bounded env56875 := by
  intro p hp
  have h : env56875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56874_56875 : H12AffineEnvironment.transform 2 4 env56874 = env56875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env56874 == env56875) = true)

def env56876 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1345,4096,4240,1297,1164,359,1345,486,408,1165,4097,477,16,4470,5504,1497,487,1297,5576,509,4252,1281,256,4249,1345,1945]

theorem envBound56876 : H12AffineFastState.Bounded env56876 := by
  intro p hp
  have h : env56876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56866_56876 : H12AffineEnvironment.transform 10 1345 env56866 = env56876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1345 env56866 == env56876) = true)

theorem identity56876 : scanCanonicalize (H12AffineFastState.compose env56876 (packedSelected [13] rootPS)) = affineNative (2^(11+1) ^^^ 1529) := by decide +kernel

theorem selectedBound56876 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env56877 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1345,1529,1385,1297,1164,359,1345,486,408,1165,1528,477,16,1167,121,1497,487,1297,49,509,1381,1281,256,1376,1345,1945]

theorem envBound56877 : H12AffineFastState.Bounded env56877 := by
  intro p hp
  have h : env56877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56876_56877 : H12AffineEnvironment.transform 11 1529 env56876 = env56877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1529 env56876 == env56877) = true)

theorem identity56877 : scanCanonicalize (H12AffineFastState.compose env56877 (packedSelected [2,5,7,8,9,10,11] rootPS)) = affineNative (2^(9+1) ^^^ 221) := by decide +kernel

theorem selectedBound56877 : packedSelected [2,5,7,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env56878 : List Nat := [2,4,8,16,32,64,128,256,512,221,412,292,436,460,81,359,412,486,408,80,293,477,16,82,121,260,487,460,49,509,440,476,256,445,412,836]

theorem envBound56878 : H12AffineFastState.Bounded env56878 := by
  intro p hp
  have h : env56878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56877_56878 : H12AffineEnvironment.transform 9 221 env56877 = env56878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 221 env56877 == env56878) = true)

theorem identity56878 : scanCanonicalize (H12AffineFastState.compose env56878 (packedSelected [0,1,3,9,10,12,16,18] rootPS)) = affineNative (2^(8+1) ^^^ 428) := by decide +kernel

theorem selectedBound56878 : packedSelected [0,1,3,9,10,12,16,18] rootPS < 2^1333 := by decide +kernel

def env56879 : List Nat := [2,4,8,16,32,64,128,256,428,221,412,292,436,460,81,359,412,486,408,80,293,477,16,82,121,260,487,460,49,509,440,476,256,445,412,232]

theorem envBound56879 : H12AffineFastState.Bounded env56879 := by
  intro p hp
  have h : env56879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56878_56879 : H12AffineEnvironment.transform 8 428 env56878 = env56879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 428 env56878 == env56879) = true)

theorem identity56879 : scanCanonicalize (H12AffineFastState.compose env56879 (packedSelected [3,7,8,9,10,15] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound56879 : packedSelected [3,7,8,9,10,15] rootPS < 2^1333 := by decide +kernel

def env56880 : List Nat := [2,4,8,16,32,64,35,256,271,126,319,292,279,367,81,359,319,325,315,80,293,382,16,82,121,260,324,367,49,350,283,383,256,286,319,75]

theorem envBound56880 : H12AffineFastState.Bounded env56880 := by
  intro p hp
  have h : env56880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56879_56880 : H12AffineEnvironment.transform 6 35 env56879 = env56880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env56879 == env56880) = true)

theorem identity56880 : scanCanonicalize (H12AffineFastState.compose env56880 (packedSelected [2,4,7] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound56880 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env56881 : List Nat := [2,4,8,16,32,59,35,256,271,5,319,292,279,276,42,284,319,318,315,43,293,261,16,41,2,260,319,276,49,293,283,260,256,286,319,48]

theorem envBound56881 : H12AffineFastState.Bounded env56881 := by
  intro p hp
  have h : env56881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56880_56881 : H12AffineEnvironment.transform 5 59 env56880 = env56881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env56880 == env56881) = true)

theorem identity56881 : scanCanonicalize (H12AffineFastState.compose env56881 (packedSelected [1,2,5] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound56881 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env56882 : List Nat := [2,4,8,10,32,33,35,256,271,5,293,292,269,270,42,262,293,292,289,43,293,261,10,41,2,260,293,270,43,293,257,260,256,260,293,42]

theorem envBound56882 : H12AffineFastState.Bounded env56882 := by
  intro p hp
  have h : env56882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56881_56882 : H12AffineEnvironment.transform 3 10 env56881 = env56882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env56881 == env56882) = true)

theorem identity56882 : scanCanonicalize (H12AffineFastState.compose env56882 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound56882 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56883 : List Nat := [2,4,8,10,11,10,8,256,271,5,270,271,269,270,1,262,270,271,266,0,270,261,10,2,2,260,270,270,0,270,257,260,256,260,270,1]

theorem envBound56883 : H12AffineFastState.Bounded env56883 := by
  intro p hp
  have h : env56883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56882_56883 : H12AffineEnvironment.transform 4 11 env56882 = env56883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env56882 == env56883) = true)

theorem identity56883 : scanCanonicalize (H12AffineFastState.compose env56883 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 2) := by decide +kernel

theorem selectedBound56883 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56884 : List Nat := [2,4,8,10,11,10,8,2,13,5,12,13,15,12,1,4,12,13,8,0,12,7,10,2,2,6,12,12,0,12,3,6,2,6,12,1]

theorem envBound56884 : H12AffineFastState.Bounded env56884 := by
  intro p hp
  have h : env56884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56883_56884 : H12AffineEnvironment.transform 7 2 env56883 = env56884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 2 env56883 == env56884) = true)

theorem identity56884 : scanCanonicalize (H12AffineFastState.compose env56884 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound56884 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env56885 : List Nat := [2,4,4,6,7,6,4,2,1,5,0,1,3,0,1,4,0,1,4,0,0,7,6,2,2,6,0,0,0,0,3,6,2,6,0,1]

theorem envBound56885 : H12AffineFastState.Bounded env56885 := by
  intro p hp
  have h : env56885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56884_56885 : H12AffineEnvironment.transform 2 4 env56884 = env56885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env56884 == env56885) = true)

def env56886 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16465,262144,95614,32769,4097,61648,17,284033,86518,94526,77841,1296,74815,96346,381312,1281,256,381317,1345,95103]

theorem envBound56886 : H12AffineFastState.Bounded env56886 := by
  intro p hp
  have h : env56886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56809_56886 : H12AffineEnvironment.transform 16 16465 env56809 = env56886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16465 env56809 == env56886) = true)

def env56887 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1345,262144,77934,32769,4097,46528,17,266385,70886,78894,77841,1296,74815,81226,365712,1281,256,365717,1345,79471]

theorem envBound56887 : H12AffineFastState.Bounded env56887 := by
  intro p hp
  have h : env56887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56886_56887 : H12AffineEnvironment.transform 13 1296 env56886 = env56887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env56886 == env56887) = true)

theorem identity56887 : scanCanonicalize (H12AffineFastState.compose env56887 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound56887 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env56888 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1345,262144,77934,13341,4097,476,17,266385,70886,78894,77841,1296,74815,81226,336012,1281,256,336009,1345,79471]

theorem envBound56888 : H12AffineFastState.Bounded env56888 := by
  intro p hp
  have h : env56888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56887_56888 : H12AffineEnvironment.transform 14 13340 env56887 = env56888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env56887 == env56888) = true)

def env56889 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1345,65664,77934,13341,4097,476,17,69649,70886,78894,77841,1296,74815,81226,8204,1281,256,8201,1345,79471]

theorem envBound56889 : H12AffineFastState.Bounded env56889 := by
  intro p hp
  have h : env56889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56888_56889 : H12AffineEnvironment.transform 17 65664 env56888 = env56889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env56888 == env56889) = true)

theorem identity56889 : scanCanonicalize (H12AffineFastState.compose env56889 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9327) := by decide +kernel

theorem selectedBound56889 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env56890 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,9327,1345,9455,5121,13341,4097,476,17,13438,12425,4161,5246,1296,80,6437,8204,1281,256,8201,1345,4608]

theorem envBound56890 : H12AffineFastState.Bounded env56890 := by
  intro p hp
  have h : env56890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56889_56890 : H12AffineEnvironment.transform 15 9327 env56889 = env56890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9327 env56889 == env56890) = true)

def env56891 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1296,9244,9327,1345,9455,1025,9245,1,476,17,9342,8329,65,1150,1296,80,2341,8204,1281,256,8201,1345,512]

theorem envBound56891 : H12AffineFastState.Bounded env56891 := by
  intro p hp
  have h : env56891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56890_56891 : H12AffineEnvironment.transform 11 0 env56890 = env56891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env56890 == env56891) = true)

theorem identity56891 : scanCanonicalize (H12AffineFastState.compose env56891 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound56891 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env56892 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,1052,1296,0,115,1345,243,1025,1,1,476,17,98,1173,65,1150,1296,80,2341,1040,1281,256,1045,1345,512]

theorem envBound56892 : H12AffineFastState.Bounded env56892 := by
  intro p hp
  have h : env56892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56891_56892 : H12AffineEnvironment.transform 12 1052 env56891 = env56892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env56891 == env56892) = true)

theorem identity56892 : scanCanonicalize (H12AffineFastState.compose env56892 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound56892 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env56893 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,0,269,1,0,115,80,243,272,1,1,476,17,98,388,65,367,1,80,2341,257,16,256,260,80,512]

theorem envBound56893 : H12AffineFastState.Bounded env56893 := by
  intro p hp
  have h : env56893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56892_56893 : H12AffineEnvironment.transform 9 273 env56892 = env56893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env56892 == env56893) = true)

theorem identity56893 : scanCanonicalize (H12AffineFastState.compose env56893 (packedSelected [0,1,7,8,10,12,13,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 460) := by decide +kernel

theorem selectedBound56893 : packedSelected [0,1,7,8,10,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env56894 : List Nat := [2,4,8,16,32,64,128,256,460,273,2048,0,269,1,0,115,80,243,272,1,1,476,17,98,388,65,367,1,80,2341,257,16,256,260,80,460]

theorem envBound56894 : H12AffineFastState.Bounded env56894 := by
  intro p hp
  have h : env56894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56893_56894 : H12AffineEnvironment.transform 8 460 env56893 = env56894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 460 env56893 == env56894) = true)

theorem identity56894 : scanCanonicalize (H12AffineFastState.compose env56894 (packedSelected [1,5,10,13] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound56894 : packedSelected [1,5,10,13] rootPS < 2^1333 := by decide +kernel

def env56895 : List Nat := [2,4,8,16,32,64,128,172,96,189,2048,0,161,1,0,115,80,243,188,1,1,112,17,98,40,65,195,1,80,2185,173,16,172,168,80,96]

theorem envBound56895 : H12AffineFastState.Bounded env56895 := by
  intro p hp
  have h : env56895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56894_56895 : H12AffineEnvironment.transform 7 172 env56894 = env56895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env56894 == env56895) = true)

theorem identity56895 : scanCanonicalize (H12AffineFastState.compose env56895 (packedSelected [4,5,8,9,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 123) := by decide +kernel

theorem selectedBound56895 : packedSelected [4,5,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env56896 : List Nat := [2,4,8,16,32,64,128,172,96,189,123,0,161,1,0,115,80,243,188,1,1,112,17,98,40,65,195,1,80,242,173,16,172,168,80,96]

theorem envBound56896 : H12AffineFastState.Bounded env56896 := by
  intro p hp
  have h : env56896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56895_56896 : H12AffineEnvironment.transform 10 123 env56895 = env56896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 123 env56895 == env56896) = true)

theorem identity56896 : scanCanonicalize (H12AffineFastState.compose env56896 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound56896 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env56897 : List Nat := [2,4,8,16,32,64,8,36,96,53,123,0,41,1,0,115,80,123,52,1,1,112,17,98,40,65,75,1,80,122,37,16,36,32,80,96]

theorem envBound56897 : H12AffineFastState.Bounded env56897 := by
  intro p hp
  have h : env56897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56896_56897 : H12AffineEnvironment.transform 6 8 env56896 = env56897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env56896 == env56897) = true)

theorem identity56897 : scanCanonicalize (H12AffineFastState.compose env56897 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound56897 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env56898 : List Nat := [2,4,8,16,17,64,8,21,81,4,74,0,24,1,0,66,80,74,5,1,1,65,17,83,25,65,75,1,80,75,20,16,21,17,80,81]

theorem envBound56898 : H12AffineFastState.Bounded env56898 := by
  intro p hp
  have h : env56898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56897_56898 : H12AffineEnvironment.transform 4 17 env56897 = env56898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env56897 == env56898) = true)

theorem identity56898 : scanCanonicalize (H12AffineFastState.compose env56898 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 13) := by decide +kernel

theorem selectedBound56898 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56899 : List Nat := [2,4,8,16,17,13,8,21,28,4,7,0,24,1,0,15,29,7,5,1,1,12,17,30,25,12,6,1,29,6,20,16,21,17,29,28]

theorem envBound56899 : H12AffineFastState.Bounded env56899 := by
  intro p hp
  have h : env56899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56898_56899 : H12AffineEnvironment.transform 5 13 env56898 = env56899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 13 env56898 == env56899) = true)

theorem identity56899 : scanCanonicalize (H12AffineFastState.compose env56899 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound56899 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56900 : List Nat := [2,4,8,10,11,13,8,15,6,4,7,0,2,1,0,15,7,7,5,1,1,12,11,4,3,12,6,1,7,6,14,10,15,11,7,6]

theorem envBound56900 : H12AffineFastState.Bounded env56900 := by
  intro p hp
  have h : env56900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56899_56900 : H12AffineEnvironment.transform 3 10 env56899 = env56900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env56899 == env56900) = true)

theorem identity56900 : scanCanonicalize (H12AffineFastState.compose env56900 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound56900 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env56901 : List Nat := [2,3,8,10,11,10,8,8,1,3,0,0,2,1,0,8,0,0,2,1,1,11,11,3,3,11,1,1,0,1,9,10,8,11,0,1]

theorem envBound56901 : H12AffineFastState.Bounded env56901 := by
  intro p hp
  have h : env56901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56900_56901 : H12AffineEnvironment.transform 1 3 env56900 = env56901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env56900 == env56901) = true)

def env56902 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1296,9245,9327,1345,9455,1024,9244,0,476,17,9343,8328,64,1151,1296,80,2340,8204,1281,256,8201,1345,513]

theorem envBound56902 : H12AffineFastState.Bounded env56902 := by
  intro p hp
  have h : env56902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56890_56902 : H12AffineEnvironment.transform 11 1 env56890 = env56902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env56890 == env56902) = true)

theorem identity56902 : scanCanonicalize (H12AffineFastState.compose env56902 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound56902 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env56903 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,1101,1296,80,34,1345,162,1024,81,0,476,17,50,1221,64,1151,1296,80,2340,1089,1281,256,1092,1345,513]

theorem envBound56903 : H12AffineFastState.Bounded env56903 := by
  intro p hp
  have h : env56903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56902_56903 : H12AffineEnvironment.transform 12 1101 env56902 = env56903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env56902 == env56903) = true)

theorem identity56903 : scanCanonicalize (H12AffineFastState.compose env56903 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound56903 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env56904 : List Nat := [2,4,8,16,32,64,128,20,512,1024,2048,1,1101,1028,80,34,1109,162,1024,81,0,200,17,50,1221,64,1151,1028,80,2096,1089,1045,20,1092,1109,513]

theorem envBound56904 : H12AffineFastState.Bounded env56904 := by
  intro p hp
  have h : env56904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56903_56904 : H12AffineEnvironment.transform 7 20 env56903 = env56904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env56903 == env56904) = true)

theorem identity56904 : scanCanonicalize (H12AffineFastState.compose env56904 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound56904 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env56905 : List Nat := [2,4,8,16,32,0,128,20,512,1024,2048,1,1037,1028,16,34,1045,162,1024,17,0,136,17,50,1157,0,1087,1028,16,2096,1025,1045,20,1028,1045,513]

theorem envBound56905 : H12AffineFastState.Bounded env56905 := by
  intro p hp
  have h : env56905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56904_56905 : H12AffineEnvironment.transform 5 0 env56904 = env56905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env56904 == env56905) = true)

theorem identity56905 : scanCanonicalize (H12AffineFastState.compose env56905 (packedSelected [0,3,5,7,8,11,12,13,17] rootPS)) = affineNative (2^(10+1) ^^^ 1674) := by decide +kernel

theorem selectedBound56905 : packedSelected [0,3,5,7,8,11,12,13,17] rootPS < 2^1333 := by decide +kernel

def env56906 : List Nat := [2,4,8,16,32,0,128,20,512,1024,1674,1,1037,1028,16,34,1045,162,1024,17,0,136,17,50,1157,0,1087,1028,16,1722,1025,1045,20,1028,1045,513]

theorem envBound56906 : H12AffineFastState.Bounded env56906 := by
  intro p hp
  have h : env56906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56905_56906 : H12AffineEnvironment.transform 10 1674 env56905 = env56906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1674 env56905 == env56906) = true)

theorem identity56906 : scanCanonicalize (H12AffineFastState.compose env56906 (packedSelected [2,11,12,13,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound56906 : packedSelected [2,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env56907 : List Nat := [2,4,8,16,32,0,128,20,136,1024,1026,1,1037,1028,16,34,1045,162,1024,17,0,136,17,50,1157,0,1087,1028,16,1074,1025,1045,20,1028,1045,137]

theorem envBound56907 : H12AffineFastState.Bounded env56907 := by
  intro p hp
  have h : env56907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56906_56907 : H12AffineEnvironment.transform 8 136 env56906 = env56907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env56906 == env56907) = true)

theorem identity56907 : scanCanonicalize (H12AffineFastState.compose env56907 (packedSelected [1,2,3,13,15] rootPS)) = affineNative (2^(4+1) ^^^ 29) := by decide +kernel

theorem selectedBound56907 : packedSelected [1,2,3,13,15] rootPS < 2^1333 := by decide +kernel

def env56908 : List Nat := [2,4,8,16,29,0,128,20,136,1024,1026,1,1037,1028,16,31,1045,159,1024,17,0,136,17,15,1157,0,1026,1028,16,1039,1025,1045,20,1028,1045,137]

theorem envBound56908 : H12AffineFastState.Bounded env56908 := by
  intro p hp
  have h : env56908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56907_56908 : H12AffineEnvironment.transform 4 29 env56907 = env56908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 29 env56907 == env56908) = true)

theorem identity56908 : scanCanonicalize (H12AffineFastState.compose env56908 (packedSelected [0,1,2,3,4,5,7,9,12] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound56908 : packedSelected [0,1,2,3,4,5,7,9,12] rootPS < 2^1333 := by decide +kernel

def env56909 : List Nat := [2,4,8,16,29,0,128,20,136,20,22,1,25,16,16,31,1,159,20,17,0,136,17,15,145,0,22,16,16,27,21,1,20,16,1,137]

theorem envBound56909 : H12AffineFastState.Bounded env56909 := by
  intro p hp
  have h : env56909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56908_56909 : H12AffineEnvironment.transform 9 20 env56908 = env56909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env56908 == env56909) = true)

theorem identity56909 : scanCanonicalize (H12AffineFastState.compose env56909 (packedSelected [1,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 31) := by decide +kernel

theorem selectedBound56909 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env56910 : List Nat := [2,4,8,16,29,0,31,20,23,20,22,1,25,16,16,31,1,0,20,17,0,23,17,15,14,0,22,16,16,27,21,1,20,16,1,22]

theorem envBound56910 : H12AffineFastState.Bounded env56910 := by
  intro p hp
  have h : env56910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56909_56910 : H12AffineEnvironment.transform 6 31 env56909 = env56910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 31 env56909 == env56910) = true)

theorem identity56910 : scanCanonicalize (H12AffineFastState.compose env56910 (packedSelected [1,2] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound56910 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env56911 : List Nat := [2,4,8,6,11,0,9,2,1,2,0,1,15,6,6,9,1,0,2,7,0,1,7,15,14,0,0,6,6,13,3,1,2,6,1,0]

theorem envBound56911 : H12AffineFastState.Bounded env56911 := by
  intro p hp
  have h : env56911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56910_56911 : H12AffineEnvironment.transform 3 6 env56910 = env56911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env56910 == env56911) = true)

theorem identity56911 : scanCanonicalize (H12AffineFastState.compose env56911 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound56911 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56912 : List Nat := [2,1,8,3,11,0,9,2,1,2,0,1,10,3,3,9,1,0,2,2,0,1,2,10,11,0,0,3,3,8,3,1,2,3,1,0]

theorem envBound56912 : H12AffineFastState.Bounded env56912 := by
  intro p hp
  have h : env56912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56911_56912 : H12AffineEnvironment.transform 1 1 env56911 = env56912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env56911 == env56912) = true)

theorem identity56912 : scanCanonicalize (H12AffineFastState.compose env56912 (packedSelected [1,4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound56912 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env56913 : List Nat := [1,1,8,0,8,0,9,1,1,1,0,1,9,0,0,9,1,0,1,1,0,1,1,9,8,0,0,0,0,8,0,1,1,0,1,0]

theorem envBound56913 : H12AffineFastState.Bounded env56913 := by
  intro p hp
  have h : env56913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56912_56913 : H12AffineEnvironment.transform 0 1 env56912 = env56913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env56912 == env56913) = true)

def env56914 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1345,65665,77934,13341,4097,476,17,69648,70886,78894,77841,1296,74815,81226,8205,1281,256,8200,1345,79471]

theorem envBound56914 : H12AffineFastState.Bounded env56914 := by
  intro p hp
  have h : env56914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56888_56914 : H12AffineEnvironment.transform 17 65665 env56888 = env56914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env56888 == env56914) = true)

theorem identity56914 : scanCanonicalize (H12AffineFastState.compose env56914 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12590) := by decide +kernel

theorem selectedBound56914 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env56915 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,12590,1345,12719,320,13341,4097,476,17,8510,9672,1280,319,1296,5393,3172,8205,1281,256,8200,1345,1857]

theorem envBound56915 : H12AffineFastState.Bounded env56915 := by
  intro p hp
  have h : env56915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56914_56915 : H12AffineEnvironment.transform 15 12590 env56914 = env56915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12590 env56914 == env56915) = true)

def env56916 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,80,12636,12590,1,12719,320,12637,4097,476,17,8510,8328,64,319,80,4177,2340,8205,65,256,8200,1,513]

theorem envBound56916 : H12AffineFastState.Bounded env56916 := by
  intro p hp
  have h : env56916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56915_56916 : H12AffineEnvironment.transform 9 320 env56915 = env56916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env56915 == env56916) = true)

theorem identity56916 : scanCanonicalize (H12AffineFastState.compose env56916 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 4365) := by decide +kernel

theorem selectedBound56916 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env56917 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,4365,80,81,35,1,162,320,80,4097,476,17,4147,4485,64,319,80,4177,2340,4352,65,256,4357,1,513]

theorem envBound56917 : H12AffineFastState.Bounded env56917 := by
  intro p hp
  have h : env56917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56916_56917 : H12AffineEnvironment.transform 12 4365 env56916 = env56917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4365 env56916 == env56917) = true)

theorem identity56917 : scanCanonicalize (H12AffineFastState.compose env56917 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound56917 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env56918 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,277,24,80,81,35,1,162,320,80,276,476,17,294,144,64,319,80,324,2340,21,65,256,16,1,513]

theorem envBound56918 : H12AffineFastState.Bounded env56918 := by
  intro p hp
  have h : env56918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56917_56918 : H12AffineEnvironment.transform 11 277 env56917 = env56918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env56917 == env56918) = true)

theorem identity56918 : scanCanonicalize (H12AffineFastState.compose env56918 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound56918 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env56919 : List Nat := [2,4,8,16,32,1,128,256,512,257,2048,277,24,17,16,35,1,162,257,17,276,413,17,294,144,1,319,17,261,2340,21,0,256,16,1,513]

theorem envBound56919 : H12AffineFastState.Bounded env56919 := by
  intro p hp
  have h : env56919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56918_56919 : H12AffineEnvironment.transform 5 1 env56918 = env56919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env56918 == env56919) = true)

theorem identity56919 : scanCanonicalize (H12AffineFastState.compose env56919 (packedSelected [0,3,5,7,8,11,12,13,17] rootPS)) = affineNative (2^(8+1) ^^^ 432) := by decide +kernel

theorem selectedBound56919 : packedSelected [0,3,5,7,8,11,12,13,17] rootPS < 2^1333 := by decide +kernel

def env56920 : List Nat := [2,4,8,16,32,1,128,256,432,257,2048,277,24,17,16,35,1,162,257,17,276,413,17,294,144,1,319,17,261,2340,21,0,256,16,1,433]

theorem envBound56920 : H12AffineFastState.Bounded env56920 := by
  intro p hp
  have h : env56920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56919_56920 : H12AffineEnvironment.transform 8 432 env56919 = env56920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 432 env56919 == env56920) = true)

theorem identity56920 : scanCanonicalize (H12AffineFastState.compose env56920 (packedSelected [2,11,12,13,15,18] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound56920 : packedSelected [2,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env56921 : List Nat := [2,4,8,16,12,1,128,256,412,257,2048,277,24,17,16,15,1,142,257,17,276,413,17,266,144,1,275,17,261,2312,21,0,256,16,1,413]

theorem envBound56921 : H12AffineFastState.Bounded env56921 := by
  intro p hp
  have h : env56921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56920_56921 : H12AffineEnvironment.transform 4 12 env56920 = env56921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env56920 == env56921) = true)

theorem identity56921 : scanCanonicalize (H12AffineFastState.compose env56921 (packedSelected [0,3,7,8,11,13,15] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound56921 : packedSelected [0,3,7,8,11,13,15] rootPS < 2^1333 := by decide +kernel

def env56922 : List Nat := [2,4,8,16,12,1,128,20,136,21,2048,1,24,17,16,15,1,142,21,17,0,137,17,30,144,1,7,17,17,2076,21,0,20,16,1,137]

theorem envBound56922 : H12AffineFastState.Bounded env56922 := by
  intro p hp
  have h : env56922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56921_56922 : H12AffineEnvironment.transform 7 20 env56921 = env56922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env56921 == env56922) = true)

theorem identity56922 : scanCanonicalize (H12AffineFastState.compose env56922 (packedSelected [2,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound56922 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env56923 : List Nat := [2,4,8,16,12,1,19,20,27,21,2048,1,24,17,16,15,1,29,21,17,0,26,17,30,3,1,7,17,17,2076,21,0,20,16,1,26]

theorem envBound56923 : H12AffineFastState.Bounded env56923 := by
  intro p hp
  have h : env56923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56922_56923 : H12AffineEnvironment.transform 6 19 env56922 = env56923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env56922 == env56923) = true)

theorem identity56923 : scanCanonicalize (H12AffineFastState.compose env56923 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound56923 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56924 : List Nat := [2,4,8,1,12,1,2,5,10,4,2048,1,9,0,1,15,1,12,4,0,0,11,0,15,3,1,7,0,0,2061,4,0,5,1,1,11]

theorem envBound56924 : H12AffineFastState.Bounded env56924 := by
  intro p hp
  have h : env56924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56923_56924 : H12AffineEnvironment.transform 3 1 env56923 = env56924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env56923 == env56924) = true)

theorem identity56924 : scanCanonicalize (H12AffineFastState.compose env56924 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound56924 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56925 : List Nat := [2,4,4,1,0,1,2,5,6,4,2048,1,5,0,1,3,1,0,4,0,0,7,0,3,3,1,7,0,0,2049,4,0,5,1,1,7]

theorem envBound56925 : H12AffineFastState.Bounded env56925 := by
  intro p hp
  have h : env56925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56924_56925 : H12AffineEnvironment.transform 2 4 env56924 = env56925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env56924 == env56925) = true)

theorem identity56925 : scanCanonicalize (H12AffineFastState.compose env56925 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound56925 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56926 : List Nat := [0,4,4,1,0,1,0,5,4,4,2048,1,5,0,1,1,1,0,4,0,0,5,0,1,1,1,5,0,0,2049,4,0,5,1,1,5]

theorem envBound56926 : H12AffineFastState.Bounded env56926 := by
  intro p hp
  have h : env56926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56925_56926 : H12AffineEnvironment.transform 0 0 env56925 = env56926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env56925 == env56926) = true)

def env56927 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,81,12637,12590,0,12719,320,12636,4097,476,17,8510,8329,65,319,81,4176,2341,8205,64,256,8200,0,512]

theorem envBound56927 : H12AffineFastState.Bounded env56927 := by
  intro p hp
  have h : env56927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56915_56927 : H12AffineEnvironment.transform 9 321 env56915 = env56927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env56915 == env56927) = true)

theorem identity56927 : scanCanonicalize (H12AffineFastState.compose env56927 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 4444) := by decide +kernel

theorem selectedBound56927 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env56928 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,4444,81,1,114,0,243,320,0,4097,476,17,4194,4565,65,319,81,4176,2341,4433,64,256,4436,0,512]

theorem envBound56928 : H12AffineFastState.Bounded env56928 := by
  intro p hp
  have h : env56928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56927_56928 : H12AffineEnvironment.transform 12 4444 env56927 = env56928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4444 env56927 == env56928) = true)

theorem identity56928 : scanCanonicalize (H12AffineFastState.compose env56928 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound56928 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env56929 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,80,268,81,1,114,0,243,320,0,81,476,17,50,389,65,319,81,0,2341,257,64,256,260,0,512]

theorem envBound56929 : H12AffineFastState.Bounded env56929 := by
  intro p hp
  have h : env56929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56928_56929 : H12AffineEnvironment.transform 11 80 env56928 = env56929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env56928 == env56929) = true)

theorem identity56929 : scanCanonicalize (H12AffineFastState.compose env56929 (packedSelected [0,1,2,7,8,10,11,12,13,15] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound56929 : packedSelected [0,1,2,7,8,10,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env56930 : List Nat := [2,4,8,16,32,64,128,68,512,5,2048,80,72,81,1,114,0,243,4,0,81,152,17,50,193,65,123,81,0,2145,69,64,68,64,0,512]

theorem envBound56930 : H12AffineFastState.Bounded env56930 := by
  intro p hp
  have h : env56930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56929_56930 : H12AffineEnvironment.transform 7 68 env56929 = env56930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env56929 == env56930) = true)

theorem identity56930 : scanCanonicalize (H12AffineFastState.compose env56930 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 254) := by decide +kernel

theorem selectedBound56930 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56931 : List Nat := [2,4,8,16,32,64,128,68,512,5,254,80,72,81,1,114,0,243,4,0,81,152,17,50,193,65,123,81,0,159,69,64,68,64,0,512]

theorem envBound56931 : H12AffineFastState.Bounded env56931 := by
  intro p hp
  have h : env56931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56930_56931 : H12AffineEnvironment.transform 10 254 env56930 = env56931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 254 env56930 == env56931) = true)

theorem identity56931 : scanCanonicalize (H12AffineFastState.compose env56931 (packedSelected [2,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound56931 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env56932 : List Nat := [2,4,8,16,32,64,57,68,512,5,71,80,72,81,1,114,0,74,4,0,81,33,17,50,120,65,123,81,0,38,69,64,68,64,0,512]

theorem envBound56932 : H12AffineFastState.Bounded env56932 := by
  intro p hp
  have h : env56932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56931_56932 : H12AffineEnvironment.transform 6 57 env56931 = env56932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env56931 == env56932) = true)

theorem identity56932 : scanCanonicalize (H12AffineFastState.compose env56932 (packedSelected [2,10] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound56932 : packedSelected [2,10] rootPS < 2^1333 := by decide +kernel

def env56933 : List Nat := [2,4,8,16,32,64,57,68,49,5,71,80,72,81,1,114,0,74,4,0,81,33,17,50,120,65,123,81,0,38,69,64,68,64,0,49]

theorem envBound56933 : H12AffineFastState.Bounded env56933 := by
  intro p hp
  have h : env56933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56932_56933 : H12AffineEnvironment.transform 8 49 env56932 = env56933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env56932 == env56933) = true)

theorem identity56933 : scanCanonicalize (H12AffineFastState.compose env56933 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 44) := by decide +kernel

theorem selectedBound56933 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env56934 : List Nat := [2,4,8,16,32,44,57,40,49,5,43,60,36,61,1,30,0,38,4,0,61,33,17,50,20,45,23,61,0,38,41,44,40,44,0,49]

theorem envBound56934 : H12AffineFastState.Bounded env56934 := by
  intro p hp
  have h : env56934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56933_56934 : H12AffineEnvironment.transform 5 44 env56933 = env56934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 44 env56933 == env56934) = true)

theorem identity56934 : scanCanonicalize (H12AffineFastState.compose env56934 (packedSelected [0,2,4] rootPS)) = affineNative (2^(4+1) ^^^ 29) := by decide +kernel

theorem selectedBound56934 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env56935 : List Nat := [2,4,8,16,29,17,4,21,12,5,22,1,25,0,1,30,0,27,4,0,0,28,17,15,20,16,23,0,0,27,20,17,21,17,0,12]

theorem envBound56935 : H12AffineFastState.Bounded env56935 := by
  intro p hp
  have h : env56935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56934_56935 : H12AffineEnvironment.transform 4 29 env56934 = env56935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 29 env56934 == env56935) = true)

theorem identity56935 : scanCanonicalize (H12AffineFastState.compose env56935 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound56935 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56936 : List Nat := [2,4,8,10,7,11,4,15,12,5,12,1,3,0,1,4,0,1,4,0,0,6,11,15,14,10,13,0,0,1,14,11,15,11,0,12]

theorem envBound56936 : H12AffineFastState.Bounded env56936 := by
  intro p hp
  have h : env56936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56935_56936 : H12AffineEnvironment.transform 3 10 env56935 = env56936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env56935 == env56936) = true)

theorem identity56936 : scanCanonicalize (H12AffineFastState.compose env56936 (packedSelected [7] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound56936 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env56937 : List Nat := [2,4,5,7,7,6,4,2,1,5,1,1,3,0,1,4,0,1,4,0,0,6,6,2,3,7,0,0,0,1,3,6,2,6,0,1]

theorem envBound56937 : H12AffineFastState.Bounded env56937 := by
  intro p hp
  have h : env56937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56936_56937 : H12AffineEnvironment.transform 2 5 env56936 = env56937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env56936 == env56937) = true)

def env56938 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1344,262144,77935,32769,4097,46529,17,266384,70887,78895,77841,1296,74815,81227,365713,1281,256,365716,1345,79470]

theorem envBound56938 : H12AffineFastState.Bounded env56938 := by
  intro p hp
  have h : env56938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56886_56938 : H12AffineEnvironment.transform 13 1297 env56886 = env56938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env56886 == env56938) = true)

theorem identity56938 : scanCanonicalize (H12AffineFastState.compose env56938 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32883) := by decide +kernel

theorem selectedBound56938 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env56939 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,32883,1344,262144,45084,32769,4097,46529,17,266384,38036,46172,45154,1296,42060,48440,267490,1281,256,267495,1345,46621]

theorem envBound56939 : H12AffineFastState.Bounded env56939 := by
  intro p hp
  have h : env56939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56938_56939 : H12AffineEnvironment.transform 15 32883 env56938 = env56939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32883 env56938 == env56939) = true)

def env56940 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32883,1344,262144,42332,32769,1345,41089,17,263632,33236,41244,42274,1296,42060,43128,262562,1281,256,262567,1345,41821]

theorem envBound56940 : H12AffineFastState.Bounded env56940 := by
  intro p hp
  have h : env56940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56939_56940 : H12AffineEnvironment.transform 11 1344 env56939 = env56940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env56939 == env56940) = true)

theorem identity56940 : scanCanonicalize (H12AffineFastState.compose env56940 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 276) := by decide +kernel

theorem selectedBound56940 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env56941 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,276,359,1344,262144,9288,277,1345,8597,17,263632,192,8200,9270,1296,9560,10604,262562,1281,256,262567,1345,8777]

theorem envBound56941 : H12AffineFastState.Bounded env56941 := by
  intro p hp
  have h : env56941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56940_56941 : H12AffineEnvironment.transform 14 276 env56940 = env56941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 276 env56940 == env56941) = true)

theorem identity56941 : scanCanonicalize (H12AffineFastState.compose env56941 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(17+1) ^^^ 10824) := by decide +kernel

theorem selectedBound56941 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env56942 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,276,359,1344,10824,9288,277,1345,8597,17,12184,192,8200,9270,1296,9560,10604,11242,1281,256,11247,1345,8777]

theorem envBound56942 : H12AffineFastState.Bounded env56942 := by
  intro p hp
  have h : env56942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56941_56942 : H12AffineEnvironment.transform 17 10824 env56941 = env56942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10824 env56941 == env56942) = true)

def env56943 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32883,1344,262144,42333,32769,1344,41088,17,263633,33237,41245,42275,1296,42060,43129,262563,1281,256,262566,1345,41820]

theorem envBound56943 : H12AffineFastState.Bounded env56943 := by
  intro p hp
  have h : env56943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56939_56943 : H12AffineEnvironment.transform 11 1345 env56939 = env56943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env56939 == env56943) = true)

theorem identity56943 : scanCanonicalize (H12AffineFastState.compose env56943 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 486) := by decide +kernel

theorem selectedBound56943 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env56944 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32883,1344,486,42333,32769,1344,41088,17,1079,33237,41245,42275,1296,42060,43129,69,1281,256,64,1345,41820]

theorem envBound56944 : H12AffineFastState.Bounded env56944 := by
  intro p hp
  have h : env56944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56943_56944 : H12AffineEnvironment.transform 17 486 env56943 = env56944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 486 env56943 == env56944) = true)

theorem identity56944 : scanCanonicalize (H12AffineFastState.compose env56944 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound56944 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env56945 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,8540,8495,1344,486,1025,8541,1344,476,17,1079,8329,65,1151,1296,1296,2341,69,1281,256,64,1345,512]

theorem envBound56945 : H12AffineFastState.Bounded env56945 := by
  intro p hp
  have h : env56945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56944_56945 : H12AffineEnvironment.transform 14 8540 env56944 = env56945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env56944 == env56945) = true)

theorem identity56945 : scanCanonicalize (H12AffineFastState.compose env56945 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound56945 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env56946 : List Nat := [2,4,8,16,32,64,128,20,512,1024,2048,1109,8192,1029,8264,8251,1108,242,1025,8265,1108,200,17,1079,8329,65,1151,1028,1028,2097,69,1045,20,64,1109,512]

theorem envBound56946 : H12AffineFastState.Bounded env56946 := by
  intro p hp
  have h : env56946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56945_56946 : H12AffineEnvironment.transform 7 20 env56945 = env56946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env56945 == env56946) = true)

theorem identity56946 : scanCanonicalize (H12AffineFastState.compose env56946 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 657) := by decide +kernel

theorem selectedBound56946 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env56947 : List Nat := [2,4,8,16,32,64,128,20,512,1024,2048,1109,657,1029,729,682,1108,242,1025,728,1108,200,17,1079,536,65,1151,1028,1028,2097,69,1045,20,64,1109,512]

theorem envBound56947 : H12AffineFastState.Bounded env56947 := by
  intro p hp
  have h : env56947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56946_56947 : H12AffineEnvironment.transform 12 657 env56946 = env56947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 657 env56946 == env56947) = true)

theorem identity56947 : scanCanonicalize (H12AffineFastState.compose env56947 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound56947 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env56948 : List Nat := [2,4,8,16,32,16,128,20,512,1024,2048,1029,657,1029,649,682,1028,162,1025,648,1028,152,17,1079,536,17,1071,1028,1028,2097,21,1045,20,16,1029,512]

theorem envBound56948 : H12AffineFastState.Bounded env56948 := by
  intro p hp
  have h : env56948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56947_56948 : H12AffineEnvironment.transform 5 16 env56947 = env56948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env56947 == env56948) = true)

theorem identity56948 : scanCanonicalize (H12AffineFastState.compose env56948 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound56948 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env56949 : List Nat := [2,4,8,16,32,16,57,20,512,1024,2048,1029,552,1029,560,531,1028,27,1025,561,1028,33,17,1079,536,17,1071,1028,1028,2097,21,1045,20,16,1029,512]

theorem envBound56949 : H12AffineFastState.Bounded env56949 := by
  intro p hp
  have h : env56949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56948_56949 : H12AffineEnvironment.transform 6 57 env56948 = env56949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env56948 == env56949) = true)

theorem identity56949 : scanCanonicalize (H12AffineFastState.compose env56949 (packedSelected [0,1,2,4,5,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound56949 : packedSelected [0,1,2,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env56950 : List Nat := [2,4,8,16,32,16,57,20,512,1024,512,1029,552,1029,560,531,1028,27,1025,561,1028,33,17,1079,536,17,1071,1028,1028,561,21,1045,20,16,1029,512]

theorem envBound56950 : H12AffineFastState.Bounded env56950 := by
  intro p hp
  have h : env56950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56949_56950 : H12AffineEnvironment.transform 10 512 env56949 = env56950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env56949 == env56950) = true)

theorem identity56950 : scanCanonicalize (H12AffineFastState.compose env56950 (packedSelected [0,2,5] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound56950 : packedSelected [0,2,5] rootPS < 2^1333 := by decide +kernel

def env56951 : List Nat := [2,4,8,16,32,16,57,20,512,5,512,0,552,0,560,531,1,27,4,561,1,33,17,50,536,17,42,1,1,561,21,16,20,16,0,512]

theorem envBound56951 : H12AffineFastState.Bounded env56951 := by
  intro p hp
  have h : env56951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56950_56951 : H12AffineEnvironment.transform 9 5 env56950 = env56951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env56950 == env56951) = true)

theorem identity56951 : scanCanonicalize (H12AffineFastState.compose env56951 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 45) := by decide +kernel

theorem selectedBound56951 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56952 : List Nat := [2,4,8,16,32,16,57,20,45,5,45,0,5,0,29,62,1,27,4,28,1,33,17,50,53,17,42,1,1,28,21,16,20,16,0,45]

theorem envBound56952 : H12AffineFastState.Bounded env56952 := by
  intro p hp
  have h : env56952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56951_56952 : H12AffineEnvironment.transform 8 45 env56951 = env56952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 45 env56951 == env56952) = true)

theorem identity56952 : scanCanonicalize (H12AffineFastState.compose env56952 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound56952 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56953 : List Nat := [2,2,8,16,32,16,57,18,43,3,43,0,3,0,27,56,1,27,2,26,1,33,17,50,51,17,42,1,1,26,19,16,18,16,0,43]

theorem envBound56953 : H12AffineFastState.Bounded env56953 := by
  intro p hp
  have h : env56953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56952_56953 : H12AffineEnvironment.transform 1 2 env56952 = env56953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env56952 == env56953) = true)

def env56954 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,16777216,533641,672785,134217728,148801,545088,96346,16876544,151934398,257,134652356,151462016,525824]

theorem envBound56954 : H12AffineFastState.Bounded env56954 := by
  intro p hp
  have h : env56954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56001_56954 : H12AffineEnvironment.transform 24 533641 env56001 = env56954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 533641 env56001 == env56954) = true)

def env56955 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,16777216,533641,672785,17245632,148801,545088,96346,16876544,618622,257,16876548,1344,525824]

theorem envBound56955 : H12AffineFastState.Bounded env56955 := by
  intro p hp
  have h : env56955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56954_56955 : H12AffineEnvironment.transform 26 17245632 env56954 = env56955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245632 env56954 == env56955) = true)

theorem identity56955 : scanCanonicalize (H12AffineFastState.compose env56955 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 41002) := by decide +kernel

theorem selectedBound56955 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env56956 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,41002,533641,672785,493034,148801,545088,96346,74794,618622,257,74798,1344,525824]

theorem envBound56956 : H12AffineFastState.Bounded env56956 := by
  intro p hp
  have h : env56956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56955_56956 : H12AffineEnvironment.transform 23 41002 env56955 = env56956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41002 env56955 == env56956) = true)

def env56957 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147520,41002,143497,20497,493034,148801,148800,96346,74794,222334,257,74798,1344,135680]

theorem envBound56957 : H12AffineFastState.Bounded env56957 := by
  intro p hp
  have h : env56957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56956_56957 : H12AffineEnvironment.transform 18 136192 env56956 = env56957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136192 env56956 == env56957) = true)

def env56958 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147520,41002,143497,20497,492614,148717,148716,96346,74794,222334,173,74798,1260,135680]

theorem envBound56958 : H12AffineFastState.Bounded env56958 := by
  intro p hp
  have h : env56958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56957_56958 : H12AffineEnvironment.transform 7 172 env56957 = env56958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env56957 == env56958) = true)

def env56959 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61568,147472,41002,143497,20497,492566,148669,148668,96266,74794,222254,173,74798,1212,135680]

theorem envBound56959 : H12AffineFastState.Bounded env56959 := by
  intro p hp
  have h : env56959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56958_56959 : H12AffineEnvironment.transform 5 16 env56958 = env56959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env56958 == env56959) = true)

theorem identity56959 : scanCanonicalize (H12AffineFastState.compose env56959 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 223243) := by decide +kernel

theorem selectedBound56959 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env56960 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,223243,136192,32769,4097,61568,147472,41002,143497,20497,60445,148669,148668,96266,74794,222254,173,74798,1212,135680]

theorem envBound56960 : H12AffineFastState.Bounded env56960 := by
  intro p hp
  have h : env56960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56959_56960 : H12AffineEnvironment.transform 17 223243 env56959 = env56960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223243 env56959 == env56960) = true)

theorem identity56960 : scanCanonicalize (H12AffineFastState.compose env56960 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 28803) := by decide +kernel

theorem selectedBound56960 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env56961 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,28803,131072,137352,136192,32769,4097,61568,147472,41002,143497,20497,60445,148669,148668,2185,21673,136365,173,21677,1212,135680]

theorem envBound56961 : H12AffineFastState.Bounded env56961 := by
  intro p hp
  have h : env56961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56960_56961 : H12AffineEnvironment.transform 15 28803 env56960 = env56961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28803 env56960 == env56961) = true)

theorem identity56961 : scanCanonicalize (H12AffineFastState.compose env56961 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(16+1) ^^^ 58533) := by decide +kernel

theorem selectedBound56961 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env56962 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,28803,58533,64557,61605,32769,4097,61568,42165,41002,54316,20497,60445,40984,40985,2185,21673,61448,173,21677,1212,63141]

theorem envBound56962 : H12AffineFastState.Bounded env56962 := by
  intro p hp
  have h : env56962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56961_56962 : H12AffineEnvironment.transform 16 58533 env56961 = env56962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 58533 env56961 == env56962) = true)

theorem identity56962 : scanCanonicalize (H12AffineFastState.compose env56962 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound56962 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env56963 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1212,32768,13375,40985,47249,46105,32769,4097,46140,42165,41002,37008,5293,43169,40984,40985,2185,4117,46260,173,4113,1212,45593]

theorem envBound56963 : H12AffineFastState.Bounded env56963 := by
  intro p hp
  have h : env56963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56962_56963 : H12AffineEnvironment.transform 13 1212 env56962 = env56963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env56962 == env56963) = true)

theorem identity56963 : scanCanonicalize (H12AffineFastState.compose env56963 (packedSelected [0,4,5,7,8,9,10,13] rootPS)) = affineNative (2^(12+1) ^^^ 6283) := by decide +kernel

theorem selectedBound56963 : packedSelected [0,4,5,7,8,9,10,13] rootPS < 2^1333 := by decide +kernel

def env56964 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,6283,1212,32768,3252,39058,32794,35986,32769,4097,36023,39998,39073,37008,5293,36906,39059,39058,2185,4117,35903,173,4113,1212,35474]

theorem envBound56964 : H12AffineFastState.Bounded env56964 := by
  intro p hp
  have h : env56964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56963_56964 : H12AffineEnvironment.transform 12 6283 env56963 = env56964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6283 env56963 == env56964) = true)

theorem identity56964 : scanCanonicalize (H12AffineFastState.compose env56964 (packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 1213) := by decide +kernel

theorem selectedBound56964 : packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env56965 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,1213,3126,1212,32768,3252,35887,32794,35986,32769,1212,36023,34947,35868,33837,16,33943,35886,35887,2185,1192,35903,173,1196,1212,35474]

theorem envBound56965 : H12AffineFastState.Bounded env56965 := by
  intro p hp
  have h : env56965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56964_56965 : H12AffineEnvironment.transform 11 1213 env56964 = env56965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1213 env56964 == env56965) = true)

theorem identity56965 : scanCanonicalize (H12AffineFastState.compose env56965 (packedSelected [1,2,3,6,10,11] rootPS)) = affineNative (2^(14+1) ^^^ 2706) := by decide +kernel

theorem selectedBound56965 : packedSelected [1,2,3,6,10,11] rootPS < 2^1333 := by decide +kernel

def env56966 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,1213,3126,1212,2706,3252,1725,2696,1536,2707,1212,1573,529,1678,3775,16,3589,1724,1725,2185,1192,1709,173,1196,1212,0]

theorem envBound56966 : H12AffineFastState.Bounded env56966 := by
  intro p hp
  have h : env56966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56965_56966 : H12AffineEnvironment.transform 14 2706 env56965 = env56966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2706 env56965 == env56966) = true)

theorem identity56966 : scanCanonicalize (H12AffineFastState.compose env56966 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1703) := by decide +kernel

theorem selectedBound56966 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env56967 : List Nat := [2,4,8,16,32,16,128,172,512,1024,1703,1213,657,1212,1077,531,1725,1071,1536,1076,1212,1573,529,1678,24,16,162,1724,1725,1582,1192,1709,173,1196,1212,0]

theorem envBound56967 : H12AffineFastState.Bounded env56967 := by
  intro p hp
  have h : env56967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56966_56967 : H12AffineEnvironment.transform 10 1703 env56966 = env56967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1703 env56966 == env56967) = true)

theorem identity56967 : scanCanonicalize (H12AffineFastState.compose env56967 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(9+1) ^^^ 150) := by decide +kernel

theorem selectedBound56967 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env56968 : List Nat := [2,4,8,16,32,16,128,172,512,150,561,43,657,42,163,531,555,185,662,162,42,691,529,536,24,16,162,554,555,696,62,571,173,58,42,0]

theorem envBound56968 : H12AffineFastState.Bounded env56968 := by
  intro p hp
  have h : env56968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56967_56968 : H12AffineEnvironment.transform 9 150 env56967 = env56968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 150 env56967 == env56968) = true)

theorem identity56968 : scanCanonicalize (H12AffineFastState.compose env56968 (packedSelected [1,3,4,9] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound56968 : packedSelected [1,3,4,9] rootPS < 2^1333 := by decide +kernel

def env56969 : List Nat := [2,4,8,16,32,16,128,172,26,150,43,43,139,42,163,9,49,185,140,162,42,169,11,2,24,16,162,48,49,162,62,33,173,58,42,0]

theorem envBound56969 : H12AffineFastState.Bounded env56969 := by
  intro p hp
  have h : env56969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56968_56969 : H12AffineEnvironment.transform 8 26 env56968 = env56969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env56968 == env56969) = true)

theorem identity56969 : scanCanonicalize (H12AffineFastState.compose env56969 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound56969 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env56970 : List Nat := [2,4,8,16,32,16,9,37,26,31,43,43,2,42,42,9,49,48,5,43,42,32,11,2,24,16,43,48,49,43,62,33,36,58,42,0]

theorem envBound56970 : H12AffineFastState.Bounded env56970 := by
  intro p hp
  have h : env56970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56969_56970 : H12AffineEnvironment.transform 6 9 env56969 = env56970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env56969 == env56970) = true)

theorem identity56970 : scanCanonicalize (H12AffineFastState.compose env56970 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(4+1) ^^^ 29) := by decide +kernel

theorem selectedBound56970 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env56971 : List Nat := [2,4,8,16,29,16,9,24,26,31,22,22,2,23,23,9,12,13,5,22,23,29,11,2,24,16,22,13,12,22,3,28,25,7,23,0]

theorem envBound56971 : H12AffineFastState.Bounded env56971 := by
  intro p hp
  have h : env56971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56970_56971 : H12AffineEnvironment.transform 4 29 env56970 = env56971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 29 env56970 == env56971) = true)

theorem identity56971 : scanCanonicalize (H12AffineFastState.compose env56971 (packedSelected [1,10] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound56971 : packedSelected [1,10] rootPS < 2^1333 := by decide +kernel

def env56972 : List Nat := [2,4,8,10,7,10,9,2,0,5,12,12,2,13,13,9,12,13,5,12,13,7,11,2,2,10,12,13,12,12,3,6,3,7,13,0]

theorem envBound56972 : H12AffineFastState.Bounded env56972 := by
  intro p hp
  have h : env56972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56971_56972 : H12AffineEnvironment.transform 3 10 env56971 = env56972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env56971 == env56972) = true)

def env56973 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61569,147473,41002,143497,20497,492567,148668,148669,96267,74794,222255,173,74798,1213,135680]

theorem envBound56973 : H12AffineFastState.Bounded env56973 := by
  intro p hp
  have h : env56973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56958_56973 : H12AffineEnvironment.transform 5 17 env56958 = env56973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env56958 == env56973) = true)

theorem identity56973 : scanCanonicalize (H12AffineFastState.compose env56973 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 114722) := by decide +kernel

theorem selectedBound56973 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env56974 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,114722,262144,119842,32769,4097,61569,98355,41002,127147,20497,279605,99486,99487,96267,74794,41997,173,74798,1213,119330]

theorem envBound56974 : H12AffineFastState.Bounded env56974 := by
  intro p hp
  have h : env56974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56973_56974 : H12AffineEnvironment.transform 16 114722 env56973 = env56974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114722 env56973 == env56974) = true)

theorem identity56974 : scanCanonicalize (H12AffineFastState.compose env56974 (packedSelected [3,10,16,18,19,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 101550) := by decide +kernel

theorem selectedBound56974 : packedSelected [3,10,16,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env56975 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,114722,101550,119842,32769,4097,61569,98355,41002,127147,20497,116891,99486,99487,96267,74794,41997,173,74798,1213,119330]

theorem envBound56975 : H12AffineFastState.Bounded env56975 := by
  intro p hp
  have h : env56975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56974_56975 : H12AffineEnvironment.transform 17 101550 env56974 = env56975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 101550 env56974 == env56975) = true)

theorem identity56975 : scanCanonicalize (H12AffineFastState.compose env56975 (packedSelected [7,16,18,19,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53282) := by decide +kernel

theorem selectedBound56975 : packedSelected [7,16,18,19,23,26,27] rootPS < 2^1333 := by decide +kernel

def env56976 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,53282,4096,23692,1024,32769,4097,61569,20497,41002,8329,20497,6329,21692,21693,43049,62472,41997,173,62476,1213,512]

theorem envBound56976 : H12AffineFastState.Bounded env56976 := by
  intro p hp
  have h : env56976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56975_56976 : H12AffineEnvironment.transform 15 53282 env56975 = env56976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53282 env56975 == env56976) = true)

theorem identity56976 : scanCanonicalize (H12AffineFastState.compose env56976 (packedSelected [4,9,16] rootPS)) = affineNative (2^(14+1) ^^^ 12312) := by decide +kernel

theorem selectedBound56976 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env56977 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,12312,24634,4096,23692,1024,12313,4097,16537,20497,4146,8329,20497,6329,21692,21693,6193,17424,5141,173,17428,1213,512]

theorem envBound56977 : H12AffineFastState.Bounded env56977 := by
  intro p hp
  have h : env56977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56976_56977 : H12AffineEnvironment.transform 14 12312 env56976 = env56977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12312 env56976 == env56977) = true)

theorem identity56977 : scanCanonicalize (H12AffineFastState.compose env56977 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 8744) := by decide +kernel

theorem selectedBound56977 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env56978 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,8744,12312,530,4096,16036,1024,12313,4097,8881,12857,4146,8329,12857,6329,13972,13973,6193,9784,5141,173,9788,1213,512]

theorem envBound56978 : H12AffineFastState.Bounded env56978 := by
  intro p hp
  have h : env56978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56977_56978 : H12AffineEnvironment.transform 13 8744 env56977 = env56978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8744 env56977 == env56978) = true)

theorem identity56978 : scanCanonicalize (H12AffineFastState.compose env56978 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(11+1) ^^^ 675) := by decide +kernel

theorem selectedBound56978 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env56979 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,675,8192,8744,8891,530,675,11271,1024,8890,674,8881,8346,657,8329,8346,2586,9271,9270,2706,9784,1718,173,9788,1213,512]

theorem envBound56979 : H12AffineFastState.Bounded env56979 := by
  intro p hp
  have h : env56979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56978_56979 : H12AffineEnvironment.transform 11 675 env56978 = env56979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 675 env56978 == env56979) = true)

theorem identity56979 : scanCanonicalize (H12AffineFastState.compose env56979 (packedSelected [1,3,13] rootPS)) = affineNative (2^(12+1) ^^^ 1167) := by decide +kernel

theorem selectedBound56979 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env56980 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,675,1167,1703,1588,530,675,2184,1024,1589,674,1598,1045,657,1030,1045,2586,184,185,2706,695,1718,173,691,1213,512]

theorem envBound56980 : H12AffineFastState.Bounded env56980 := by
  intro p hp
  have h : env56980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56979_56980 : H12AffineEnvironment.transform 12 1167 env56979 = env56980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1167 env56979 == env56980) = true)

theorem identity56980 : scanCanonicalize (H12AffineFastState.compose env56980 (packedSelected [1,2,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound56980 : packedSelected [1,2,5,6] rootPS < 2^1333 := by decide +kernel

def env56981 : List Nat := [2,4,8,16,32,17,128,172,512,1024,1,675,1167,1703,1588,530,675,137,1024,1589,674,1598,1045,657,1030,1045,539,184,185,659,695,1718,173,691,1213,512]

theorem envBound56981 : H12AffineFastState.Bounded env56981 := by
  intro p hp
  have h : env56981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56980_56981 : H12AffineEnvironment.transform 10 1 env56980 = env56981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env56980 == env56981) = true)

theorem identity56981 : scanCanonicalize (H12AffineFastState.compose env56981 (packedSelected [0,1,2,3,7] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound56981 : packedSelected [0,1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env56982 : List Nat := [2,4,8,16,16,17,128,156,512,1024,1,659,1167,1687,1540,530,659,137,1024,1541,658,1550,1045,657,1030,1045,539,136,137,659,647,1670,157,643,1165,512]

theorem envBound56982 : H12AffineFastState.Bounded env56982 := by
  intro p hp
  have h : env56982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56981_56982 : H12AffineEnvironment.transform 4 16 env56981 = env56982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env56981 == env56982) = true)

theorem identity56982 : scanCanonicalize (H12AffineFastState.compose env56982 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound56982 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env56983 : List Nat := [2,4,8,10,10,11,128,134,512,1024,1,649,1167,1677,1540,520,649,137,1024,1541,648,1550,1039,651,1030,1039,513,136,137,649,647,1670,135,643,1165,512]

theorem envBound56983 : H12AffineFastState.Bounded env56983 := by
  intro p hp
  have h : env56983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56982_56983 : H12AffineEnvironment.transform 3 10 env56982 = env56983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env56982 == env56983) = true)

theorem identity56983 : scanCanonicalize (H12AffineFastState.compose env56983 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound56983 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env56984 : List Nat := [2,4,8,10,10,11,128,134,136,1024,1,1,1167,1029,1164,128,1,137,1024,1165,0,1158,1039,3,1030,1039,137,136,137,1,15,1038,135,11,1165,136]

theorem envBound56984 : H12AffineFastState.Bounded env56984 := by
  intro p hp
  have h : env56984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56983_56984 : H12AffineEnvironment.transform 8 136 env56983 = env56984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env56983 == env56984) = true)

theorem identity56984 : scanCanonicalize (H12AffineFastState.compose env56984 (packedSelected [0,2] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound56984 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env56985 : List Nat := [2,4,4,6,6,7,128,134,132,1024,1,1,1155,1029,1152,128,1,133,1024,1153,0,1158,1027,3,1030,1027,133,132,133,1,3,1026,135,7,1153,132]

theorem envBound56985 : H12AffineFastState.Bounded env56985 := by
  intro p hp
  have h : env56985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56984_56985 : H12AffineEnvironment.transform 2 4 env56984 = env56985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env56984 == env56985) = true)

theorem identity56985 : scanCanonicalize (H12AffineFastState.compose env56985 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound56985 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env56986 : List Nat := [2,4,4,6,6,7,4,2,0,1024,1,1,1031,1029,1028,4,1,1,1024,1029,0,1026,1027,3,1030,1027,1,0,1,1,3,1026,3,7,1029,0]

theorem envBound56986 : H12AffineFastState.Bounded env56986 := by
  intro p hp
  have h : env56986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56985_56986 : H12AffineEnvironment.transform 6 4 env56985 = env56986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env56985 == env56986) = true)

theorem identity56986 : scanCanonicalize (H12AffineFastState.compose env56986 (packedSelected [11] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound56986 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env56987 : List Nat := [2,4,4,6,6,7,4,2,0,4,1,1,3,1,0,4,1,1,4,1,0,6,7,3,2,7,1,0,1,1,3,6,3,7,1,0]

theorem envBound56987 : H12AffineFastState.Bounded env56987 := by
  intro p hp
  have h : env56987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56986_56987 : H12AffineEnvironment.transform 9 4 env56986 = env56987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env56986 == env56987) = true)

def env56988 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147520,41002,143497,20497,492615,148716,148717,96346,74794,222334,172,74798,1261,135680]

theorem envBound56988 : H12AffineFastState.Bounded env56988 := by
  intro p hp
  have h : env56988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56957_56988 : H12AffineEnvironment.transform 7 173 env56957 = env56988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env56957 == env56988) = true)

def env56989 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61568,147472,41002,143497,20497,492567,148668,148669,96266,74794,222254,172,74798,1213,135680]

theorem envBound56989 : H12AffineFastState.Bounded env56989 := by
  intro p hp
  have h : env56989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56988_56989 : H12AffineEnvironment.transform 5 16 env56988 = env56989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env56988 == env56989) = true)

theorem identity56989 : scanCanonicalize (H12AffineFastState.compose env56989 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 137353) := by decide +kernel

theorem selectedBound56989 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env56990 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,137353,136192,32769,4097,61568,147472,41002,143497,20497,105630,148668,148669,96266,74794,222254,172,74798,1213,135680]

theorem envBound56990 : H12AffineFastState.Bounded env56990 := by
  intro p hp
  have h : env56990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56989_56990 : H12AffineEnvironment.transform 17 137353 env56989 = env56990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137353 env56989 == env56990) = true)

theorem identity56990 : scanCanonicalize (H12AffineFastState.compose env56990 (packedSelected [1,5,8,18,19,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 13374) := by decide +kernel

theorem selectedBound56990 : packedSelected [1,5,8,18,19,23,24,26] rootPS < 2^1333 := by decide +kernel

def env56991 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,13374,131072,137353,136192,32769,4097,61568,147472,41002,143497,20497,43168,148668,148669,19508,4116,151568,172,4112,1213,135680]

theorem envBound56991 : H12AffineFastState.Bounded env56991 := by
  intro p hp
  have h : env56991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56990_56991 : H12AffineEnvironment.transform 15 13374 env56990 = env56991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13374 env56990 == env56991) = true)

theorem identity56991 : scanCanonicalize (H12AffineFastState.compose env56991 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound56991 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env56992 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1213,32768,13374,131072,137353,136192,32769,4097,46141,132269,41002,143497,5292,43168,131073,131072,2185,4116,136365,172,4112,1213,135680]

theorem envBound56992 : H12AffineFastState.Bounded env56992 := by
  intro p hp
  have h : env56992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56991_56992 : H12AffineEnvironment.transform 13 1213 env56991 = env56992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env56991 == env56992) = true)

theorem identity56992 : scanCanonicalize (H12AffineFastState.compose env56992 (packedSelected [13,17] rootPS)) = affineNative (2^(14+1) ^^^ 9380) := by decide +kernel

theorem selectedBound56992 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env56993 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1213,9380,13374,131072,137353,136192,9381,4097,4249,132269,1166,143497,5292,3076,131073,131072,2185,4116,136365,172,4112,1213,135680]

theorem envBound56993 : H12AffineFastState.Bounded env56993 := by
  intro p hp
  have h : env56993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56992_56993 : H12AffineEnvironment.transform 14 9380 env56992 = env56993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9380 env56992 == env56993) = true)

theorem identity56993 : scanCanonicalize (H12AffineFastState.compose env56993 (packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 3103) := by decide +kernel

theorem selectedBound56993 : packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env56994 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,3103,8192,1213,9380,10273,131072,132246,133151,9381,3102,3206,132269,1166,142486,2227,3076,131073,131072,2185,3083,133298,172,3087,1213,134687]

theorem envBound56994 : H12AffineFastState.Bounded env56994 := by
  intro p hp
  have h : env56994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56993_56994 : H12AffineEnvironment.transform 11 3103 env56993 = env56994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3103 env56993 == env56994) = true)

theorem identity56994 : scanCanonicalize (H12AffineFastState.compose env56994 (packedSelected [1,4,5,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound56994 : packedSelected [1,4,5,9,16] rootPS < 2^1333 := by decide +kernel

def env56995 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,3103,1053,1213,185,3132,131072,132246,133151,184,3102,3206,132269,1166,133259,2227,3076,131073,131072,2185,3083,133298,172,3087,1213,134687]

theorem envBound56995 : H12AffineFastState.Bounded env56995 := by
  intro p hp
  have h : env56995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56994_56995 : H12AffineEnvironment.transform 12 1053 env56994 = env56995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env56994 == env56995) = true)

theorem identity56995 : scanCanonicalize (H12AffineFastState.compose env56995 (packedSelected [0,2,3,4,5,6,10,13] rootPS)) = affineNative (2^(16+1) ^^^ 2194) := by decide +kernel

theorem selectedBound56995 : packedSelected [0,2,3,4,5,6,10,13] rootPS < 2^1333 := by decide +kernel

def env56996 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,3103,1053,1213,185,3132,2194,3076,141,184,3102,3206,3135,1166,25,2227,3076,2195,2194,2185,3083,32,172,3087,1213,1677]

theorem envBound56996 : H12AffineFastState.Bounded env56996 := by
  intro p hp
  have h : env56996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56995_56996 : H12AffineEnvironment.transform 16 2194 env56995 = env56996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 2194 env56995 == env56996) = true)

theorem identity56996 : scanCanonicalize (H12AffineFastState.compose env56996 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 1588) := by decide +kernel

theorem selectedBound56996 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env56997 : List Nat := [2,4,8,16,32,16,128,173,512,1024,1588,555,1053,1213,185,520,1702,560,141,184,554,690,523,1166,25,1671,560,1703,1702,1725,575,32,172,571,1213,1677]

theorem envBound56997 : H12AffineFastState.Bounded env56997 := by
  intro p hp
  have h : env56997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56996_56997 : H12AffineEnvironment.transform 10 1588 env56996 = env56997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1588 env56996 == env56997) = true)

theorem identity56997 : scanCanonicalize (H12AffineFastState.compose env56997 (packedSelected [0,1,3,4,6,10] rootPS)) = affineNative (2^(9+1) ^^^ 543) := by decide +kernel

theorem selectedBound56997 : packedSelected [0,1,3,4,6,10] rootPS < 2^1333 := by decide +kernel

def env56998 : List Nat := [2,4,8,16,32,16,128,173,512,543,43,555,514,674,185,520,185,560,141,184,554,690,523,657,25,152,560,184,185,162,575,32,172,571,674,146]

theorem envBound56998 : H12AffineFastState.Bounded env56998 := by
  intro p hp
  have h : env56998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56997_56998 : H12AffineEnvironment.transform 9 543 env56997 = env56998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 543 env56997 == env56998) = true)

theorem identity56998 : scanCanonicalize (H12AffineFastState.compose env56998 (packedSelected [0,3,7] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound56998 : packedSelected [0,3,7] rootPS < 2^1333 := by decide +kernel

def env56999 : List Nat := [2,4,8,16,12,16,128,129,512,543,7,519,514,654,149,520,149,540,141,148,518,670,523,657,25,152,540,148,149,142,531,12,128,535,654,146]

theorem envBound56999 : H12AffineFastState.Bounded env56999 := by
  intro p hp
  have h : env56999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56998_56999 : H12AffineEnvironment.transform 4 12 env56998 = env56999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env56998 == env56999) = true)

theorem identity56999 : scanCanonicalize (H12AffineFastState.compose env56999 (packedSelected [0,2,4,11] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound56999 : packedSelected [0,2,4,11] rootPS < 2^1333 := by decide +kernel

def env57000 : List Nat := [2,4,8,16,12,16,18,19,512,543,7,519,514,540,7,520,7,540,31,6,518,524,523,515,25,10,540,6,7,28,531,12,18,535,540,0]

theorem envBound57000 : H12AffineFastState.Bounded env57000 := by
  intro p hp
  have h : env57000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56999_57000 : H12AffineEnvironment.transform 6 18 env56999 = env57000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env56999 == env57000) = true)

theorem identity57000 : scanCanonicalize (H12AffineFastState.compose env57000 (packedSelected [0,1,4] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound57000 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env57001 : List Nat := [2,4,8,16,12,16,18,19,27,4,7,28,25,7,7,19,7,7,31,6,29,23,16,24,25,10,7,6,7,28,8,12,18,12,7,0]

theorem envBound57001 : H12AffineFastState.Bounded env57001 := by
  intro p hp
  have h : env57001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57000_57001 : H12AffineEnvironment.transform 8 27 env57000 = env57001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env57000 == env57001) = true)

theorem identity57001 : scanCanonicalize (H12AffineFastState.compose env57001 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound57001 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env57002 : List Nat := [2,4,8,13,12,13,15,14,6,4,7,1,4,7,7,14,7,7,2,6,0,10,13,5,4,10,7,6,7,1,8,12,15,12,7,0]

theorem envBound57002 : H12AffineFastState.Bounded env57002 := by
  intro p hp
  have h : env57002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57001_57002 : H12AffineEnvironment.transform 3 13 env57001 = env57002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env57001 == env57002) = true)

def env57003 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61569,147473,41002,143497,20497,492566,148669,148668,96267,74794,222255,172,74798,1212,135680]

theorem envBound57003 : H12AffineFastState.Bounded env57003 := by
  intro p hp
  have h : env57003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56988_57003 : H12AffineEnvironment.transform 5 17 env56988 = env57003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env56988 == env57003) = true)

theorem identity57003 : scanCanonicalize (H12AffineFastState.compose env57003 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 45217) := by decide +kernel

theorem selectedBound57003 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env57004 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,45217,262144,42145,32769,4097,61569,61616,41002,32808,20497,341175,62492,62493,96267,74794,119950,172,74798,1212,41633]

theorem envBound57004 : H12AffineFastState.Bounded env57004 := by
  intro p hp
  have h : env57004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57003_57004 : H12AffineEnvironment.transform 16 45217 env57003 = env57004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45217 env57003 == env57004) = true)

theorem identity57004 : scanCanonicalize (H12AffineFastState.compose env57004 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound57004 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env57005 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1213,32768,65536,45217,262144,42145,32769,4097,46140,46093,41002,32808,5292,341175,45217,45216,81078,74794,102451,172,74798,1212,41633]

theorem envBound57005 : H12AffineFastState.Bounded env57005 := by
  intro p hp
  have h : env57005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57004_57005 : H12AffineEnvironment.transform 13 1213 env57004 = env57005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env57004 == env57005) = true)

theorem identity57005 : scanCanonicalize (H12AffineFastState.compose env57005 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 185) := by decide +kernel

theorem selectedBound57005 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env57006 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,185,8192,1213,32768,65536,40984,262144,42145,32769,184,42117,42164,41002,32808,1045,336910,40984,40985,76815,74794,98442,172,74798,1212,41633]

theorem envBound57006 : H12AffineFastState.Bounded env57006 := by
  intro p hp
  have h : env57006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57005_57006 : H12AffineEnvironment.transform 11 185 env57005 = env57006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 185 env57005 == env57006) = true)

theorem identity57006 : scanCanonicalize (H12AffineFastState.compose env57006 (packedSelected [4,9,20] rootPS)) = affineNative (2^(15+1) ^^^ 33830) := by decide +kernel

theorem selectedBound57006 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env57007 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,185,8192,1213,32768,33830,40984,262144,42145,32769,184,42117,42164,41002,32808,1045,303144,40984,40985,43049,40972,1196,172,40968,1212,41633]

theorem envBound57007 : H12AffineFastState.Bounded env57007 := by
  intro p hp
  have h : env57007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57006_57007 : H12AffineEnvironment.transform 15 33830 env57006 = env57007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33830 env57006 == env57007) = true)

theorem identity57007 : scanCanonicalize (H12AffineFastState.compose env57007 (packedSelected [1,3,5,6,8,13] rootPS)) = affineNative (2^(14+1) ^^^ 8352) := by decide +kernel

theorem selectedBound57007 : packedSelected [1,3,5,6,8,13] rootPS < 2^1333 := by decide +kernel

def env57008 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,185,8192,1213,8352,9350,184,262144,1025,8353,184,1061,1044,138,8328,1045,262280,184,185,2185,172,1196,172,168,1212,513]

theorem envBound57008 : H12AffineFastState.Bounded env57008 := by
  intro p hp
  have h : env57008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57007_57008 : H12AffineEnvironment.transform 14 8352 env57007 = env57008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8352 env57007 == env57008) = true)

theorem identity57008 : scanCanonicalize (H12AffineFastState.compose env57008 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 1564) := by decide +kernel

theorem selectedBound57008 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57009 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,185,1564,1213,1724,666,184,262144,1025,1725,184,1061,1044,138,1684,1045,262280,184,185,2185,172,1196,172,168,1212,513]

theorem envBound57009 : H12AffineFastState.Bounded env57009 := by
  intro p hp
  have h : env57009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57008_57009 : H12AffineEnvironment.transform 12 1564 env57008 = env57009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1564 env57008 == env57009) = true)

theorem identity57009 : scanCanonicalize (H12AffineFastState.compose env57009 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 189) := by decide +kernel

theorem selectedBound57009 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57010 : List Nat := [2,4,8,16,32,17,128,173,512,189,2048,185,673,0,513,666,184,262144,188,512,184,152,169,138,553,168,262280,184,185,2185,172,17,172,168,1,513]

theorem envBound57010 : H12AffineFastState.Bounded env57010 := by
  intro p hp
  have h : env57010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57009_57010 : H12AffineEnvironment.transform 9 189 env57009 = env57010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 189 env57009 == env57010) = true)

theorem identity57010 : scanCanonicalize (H12AffineFastState.compose env57010 (packedSelected [1,5] rootPS)) = affineNative (2^(17+1) ^^^ 2195) := by decide +kernel

theorem selectedBound57010 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env57011 : List Nat := [2,4,8,16,32,17,128,173,512,189,2048,185,673,0,513,666,184,2195,188,512,184,152,169,138,553,168,2075,184,185,2185,172,17,172,168,1,513]

theorem envBound57011 : H12AffineFastState.Bounded env57011 := by
  intro p hp
  have h : env57011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57010_57011 : H12AffineEnvironment.transform 17 2195 env57010 = env57011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2195 env57010 == env57011) = true)

theorem identity57011 : scanCanonicalize (H12AffineFastState.compose env57011 (packedSelected [1,8] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound57011 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env57012 : List Nat := [2,4,8,16,32,17,128,173,512,189,42,185,673,0,513,666,184,185,188,512,184,152,169,138,553,168,49,184,185,163,172,17,172,168,1,513]

theorem envBound57012 : H12AffineFastState.Bounded env57012 := by
  intro p hp
  have h : env57012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57011_57012 : H12AffineEnvironment.transform 10 42 env57011 = env57012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env57011 == env57012) = true)

theorem identity57012 : scanCanonicalize (H12AffineFastState.compose env57012 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound57012 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env57013 : List Nat := [2,4,8,16,11,17,128,134,512,150,1,146,650,0,513,666,147,146,151,512,147,152,130,138,514,131,26,147,146,136,135,17,135,131,1,513]

theorem envBound57013 : H12AffineFastState.Bounded env57013 := by
  intro p hp
  have h : env57013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57012_57013 : H12AffineEnvironment.transform 4 11 env57012 = env57013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env57012 == env57013) = true)

theorem identity57013 : scanCanonicalize (H12AffineFastState.compose env57013 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 31) := by decide +kernel

theorem selectedBound57013 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env57014 : List Nat := [2,4,8,16,11,17,31,25,512,9,1,13,533,0,513,517,12,13,8,512,12,7,29,21,514,28,26,12,13,23,24,17,24,28,1,513]

theorem envBound57014 : H12AffineFastState.Bounded env57014 := by
  intro p hp
  have h : env57014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57013_57014 : H12AffineEnvironment.transform 6 31 env57013 = env57014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 31 env57013 == env57014) = true)

theorem identity57014 : scanCanonicalize (H12AffineFastState.compose env57014 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 28) := by decide +kernel

theorem selectedBound57014 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env57015 : List Nat := [2,4,8,16,11,17,31,25,28,9,1,13,9,0,29,25,12,13,8,28,12,7,29,21,30,28,26,12,13,23,24,17,24,28,1,29]

theorem envBound57015 : H12AffineFastState.Bounded env57015 := by
  intro p hp
  have h : env57015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57014_57015 : H12AffineEnvironment.transform 8 28 env57014 = env57015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 28 env57014 == env57015) = true)

theorem identity57015 : scanCanonicalize (H12AffineFastState.compose env57015 (packedSelected [0,1,9] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound57015 : packedSelected [0,1,9] rootPS < 2^1333 := by decide +kernel

def env57016 : List Nat := [2,4,8,0,11,1,15,9,12,9,1,13,9,0,13,9,12,13,8,12,12,7,13,5,14,12,10,12,13,7,8,1,8,12,1,13]

theorem envBound57016 : H12AffineFastState.Bounded env57016 := by
  intro p hp
  have h : env57016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57015_57016 : H12AffineEnvironment.transform 3 0 env57015 = env57016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env57015 == env57016) = true)

theorem identity57016 : scanCanonicalize (H12AffineFastState.compose env57016 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound57016 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57017 : List Nat := [2,0,8,0,11,1,11,9,8,9,1,9,9,0,9,9,8,9,8,8,8,3,9,1,10,8,10,8,9,3,8,1,8,8,1,9]

theorem envBound57017 : H12AffineFastState.Bounded env57017 := by
  intro p hp
  have h : env57017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57016_57017 : H12AffineEnvironment.transform 1 0 env57016 = env57017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env57016 == env57017) = true)

theorem identity57017 : scanCanonicalize (H12AffineFastState.compose env57017 (packedSelected [1,10] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound57017 : packedSelected [1,10] rootPS < 2^1333 := by decide +kernel

def env57018 : List Nat := [2,0,0,0,3,1,3,1,0,1,1,1,1,0,1,1,0,1,0,0,0,3,1,1,2,0,2,0,1,3,0,1,0,0,1,1]

theorem envBound57018 : H12AffineFastState.Bounded env57018 := by
  intro p hp
  have h : env57018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57017_57018 : H12AffineEnvironment.transform 2 0 env57017 = env57018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env57017 == env57018) = true)

theorem identity57018 : scanCanonicalize (H12AffineFastState.compose env57018 (packedSelected [11] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound57018 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env57019 : List Nat := [1,0,0,0,0,1,0,1,0,1,1,1,1,0,1,1,0,1,0,0,0,0,1,1,1,0,1,0,1,0,0,1,0,0,1,1]

theorem envBound57019 : H12AffineFastState.Bounded env57019 := by
  intro p hp
  have h : env57019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57018_57019 : H12AffineEnvironment.transform 0 1 env57018 = env57019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env57018 == env57019) = true)

def env57020 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147520,41002,143496,20496,493034,148801,148801,96346,74794,222335,257,74798,1344,135681]

theorem envBound57020 : H12AffineFastState.Bounded env57020 := by
  intro p hp
  have h : env57020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56956_57020 : H12AffineEnvironment.transform 18 136193 env56956 = env57020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136193 env56956 == env57020) = true)

def env57021 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147520,41002,143496,20496,492614,148717,148717,96346,74794,222335,173,74798,1260,135681]

theorem envBound57021 : H12AffineFastState.Bounded env57021 := by
  intro p hp
  have h : env57021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57020_57021 : H12AffineEnvironment.transform 7 172 env57020 = env57021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env57020 == env57021) = true)

def env57022 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61568,147472,41002,143496,20496,492566,148669,148669,96266,74794,222255,173,74798,1212,135681]

theorem envBound57022 : H12AffineFastState.Bounded env57022 := by
  intro p hp
  have h : env57022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57021_57022 : H12AffineEnvironment.transform 5 16 env57021 = env57022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env57021 == env57022) = true)

theorem identity57022 : scanCanonicalize (H12AffineFastState.compose env57022 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 114722) := by decide +kernel

theorem selectedBound57022 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env57023 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,114722,262144,119843,32769,4097,61568,98354,41002,127146,20496,279604,99487,99487,96266,74794,41997,173,74798,1212,119331]

theorem envBound57023 : H12AffineFastState.Bounded env57023 := by
  intro p hp
  have h : env57023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57022_57023 : H12AffineEnvironment.transform 16 114722 env57022 = env57023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114722 env57022 == env57023) = true)

theorem identity57023 : scanCanonicalize (H12AffineFastState.compose env57023 (packedSelected [3,10,16,18,19,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 101551) := by decide +kernel

theorem selectedBound57023 : packedSelected [3,10,16,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env57024 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,114722,101551,119843,32769,4097,61568,98354,41002,127146,20496,116891,99487,99487,96266,74794,41997,173,74798,1212,119331]

theorem envBound57024 : H12AffineFastState.Bounded env57024 := by
  intro p hp
  have h : env57024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart2