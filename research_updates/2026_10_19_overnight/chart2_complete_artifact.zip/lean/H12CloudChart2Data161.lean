import H12CloudChart2Data160

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans40213_40214 : H12AffineEnvironment.transform 3 10 env40213 = env40214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env40213 == env40214) = true)

theorem identity40214 : scanCanonicalize (H12AffineFastState.compose env40214 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound40214 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40215 : List Nat := [2,3,8,10,10,11,9,9,1,3,0,0,2,0,1,8,1,1,3,0,1,11,10,3,2,11,0,1,1,1,8,10,8,11,1,1]

theorem envBound40215 : H12AffineFastState.Bounded env40215 := by
  intro p hp
  have h : env40215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40214_40215 : H12AffineEnvironment.transform 1 3 env40214 = env40215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env40214 == env40215) = true)

def env40216 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,8192,1,8540,8495,80,8623,4417,8541,4097,4493,17,8558,12505,4113,366,1,0,6516,8205,8200,257,17,81,4688]

theorem envBound40216 : H12AffineFastState.Bounded env40216 := by
  intro p hp
  have h : env40216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40204_40216 : H12AffineEnvironment.transform 9 273 env40204 = env40216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env40204 == env40216) = true)

theorem identity40216 : scanCanonicalize (H12AffineFastState.compose env40216 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 4121) := by decide +kernel

theorem selectedBound40216 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env40217 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,4121,1,4421,4406,80,4534,4417,4420,4097,4493,17,4471,192,4113,366,1,0,6516,4116,4113,257,17,81,4688]

theorem envBound40217 : H12AffineFastState.Bounded env40217 := by
  intro p hp
  have h : env40217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40216_40217 : H12AffineEnvironment.transform 12 4121 env40216 = env40217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4121 env40216 == env40217) = true)

theorem identity40217 : scanCanonicalize (H12AffineFastState.compose env40217 (packedSelected [0,2,3,5,7,10,11,12,13,15,18,20] rootPS)) = affineNative (2^(11+1) ^^^ 925) := by decide +kernel

theorem selectedBound40217 : packedSelected [0,2,3,5,7,10,11,12,13,15,18,20] rootPS < 2^1333 := by decide +kernel

def env40218 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,925,900,1,728,683,80,555,732,729,924,528,17,746,192,908,366,1,0,2793,905,908,257,17,81,461]

theorem envBound40218 : H12AffineFastState.Bounded env40218 := by
  intro p hp
  have h : env40218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40217_40218 : H12AffineEnvironment.transform 11 925 env40217 = env40218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 925 env40217 == env40218) = true)

theorem identity40218 : scanCanonicalize (H12AffineFastState.compose env40218 (packedSelected [0,1,2,3,4,7,8,9,10,11,12,13,15,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound40218 : packedSelected [0,1,2,3,4,7,8,9,10,11,12,13,15,23,24] rootPS < 2^1333 := by decide +kernel

def env40219 : List Nat := [2,4,8,16,32,64,128,68,512,85,2048,729,704,1,728,683,80,555,732,729,728,528,17,746,192,712,42,1,0,2793,717,712,69,17,81,137]

theorem envBound40219 : H12AffineFastState.Bounded env40219 := by
  intro p hp
  have h : env40219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40218_40219 : H12AffineEnvironment.transform 7 68 env40218 = env40219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env40218 == env40219) = true)

theorem identity40219 : scanCanonicalize (H12AffineFastState.compose env40219 (packedSelected [0,3,5,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 217) := by decide +kernel

theorem selectedBound40219 : packedSelected [0,3,5,7,11] rootPS < 2^1333 := by decide +kernel

def env40220 : List Nat := [2,4,8,16,32,64,128,68,512,85,217,729,704,1,728,683,80,555,732,729,728,528,17,746,192,712,42,1,0,560,717,712,69,17,81,137]

theorem envBound40220 : H12AffineFastState.Bounded env40220 := by
  intro p hp
  have h : env40220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40219_40220 : H12AffineEnvironment.transform 10 217 env40219 = env40220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 217 env40219 == env40220) = true)

theorem identity40220 : scanCanonicalize (H12AffineFastState.compose env40220 (packedSelected [3,4,8,9,10,12,16] rootPS)) = affineNative (2^(8+1) ^^^ 194) := by decide +kernel

theorem selectedBound40220 : packedSelected [3,4,8,9,10,12,16] rootPS < 2^1333 := by decide +kernel

def env40221 : List Nat := [2,4,8,16,32,64,128,68,194,85,217,27,2,1,26,105,80,233,30,27,26,210,17,40,192,10,42,1,0,242,15,10,69,17,81,137]

theorem envBound40221 : H12AffineFastState.Bounded env40221 := by
  intro p hp
  have h : env40221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40220_40221 : H12AffineEnvironment.transform 8 194 env40220 = env40221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 194 env40220 == env40221) = true)

theorem identity40221 : scanCanonicalize (H12AffineFastState.compose env40221 (packedSelected [2,5,8] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound40221 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env40222 : List Nat := [2,4,8,16,17,64,128,68,194,85,217,27,2,1,26,88,80,216,30,27,26,210,17,25,192,10,27,1,0,195,15,10,69,17,81,137]

theorem envBound40222 : H12AffineFastState.Bounded env40222 := by
  intro p hp
  have h : env40222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40221_40222 : H12AffineEnvironment.transform 4 17 env40221 = env40222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env40221 == env40222) = true)

theorem identity40222 : scanCanonicalize (H12AffineFastState.compose env40222 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound40222 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env40223 : List Nat := [2,4,8,16,17,64,88,68,26,85,1,27,2,1,26,88,80,0,30,27,26,10,17,25,24,10,27,1,0,27,15,10,69,17,81,81]

theorem envBound40223 : H12AffineFastState.Bounded env40223 := by
  intro p hp
  have h : env40223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40222_40223 : H12AffineEnvironment.transform 6 88 env40222 = env40223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env40222 == env40223) = true)

theorem identity40223 : scanCanonicalize (H12AffineFastState.compose env40223 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound40223 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env40224 : List Nat := [2,4,8,16,17,16,8,20,26,5,1,27,2,1,26,8,0,0,30,27,26,10,17,25,24,10,27,1,0,27,15,10,21,17,1,1]

theorem envBound40224 : H12AffineFastState.Bounded env40224 := by
  intro p hp
  have h : env40224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40223_40224 : H12AffineEnvironment.transform 5 16 env40223 = env40224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env40223 == env40224) = true)

theorem identity40224 : scanCanonicalize (H12AffineFastState.compose env40224 (packedSelected [0,1,4] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound40224 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env40225 : List Nat := [2,4,4,16,17,16,4,20,22,5,1,23,2,1,22,4,0,0,18,23,22,6,17,21,20,6,23,1,0,23,3,6,21,17,1,1]

theorem envBound40225 : H12AffineFastState.Bounded env40225 := by
  intro p hp
  have h : env40225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40224_40225 : H12AffineEnvironment.transform 2 4 env40224 = env40225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env40224 == env40225) = true)

theorem identity40225 : scanCanonicalize (H12AffineFastState.compose env40225 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound40225 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env40226 : List Nat := [2,4,4,7,6,7,4,3,1,5,1,0,2,1,1,4,0,0,5,0,1,6,6,2,3,6,0,1,0,0,3,6,2,6,1,1]

theorem envBound40226 : H12AffineFastState.Bounded env40226 := by
  intro p hp
  have h : env40226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40225_40226 : H12AffineEnvironment.transform 3 7 env40225 = env40226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env40225 == env40226) = true)

def env40227 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74862,65665,4417,8541,4097,5276,74046,66896,13768,78895,1150,74815,1297,81226,8205,8200,257,74799,1344,5953]

theorem envBound40227 : H12AffineFastState.Bounded env40227 := by
  intro p hp
  have h : env40227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40202_40227 : H12AffineEnvironment.transform 17 65665 env40202 = env40227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env40202 == env40227) = true)

theorem identity40227 : scanCanonicalize (H12AffineFastState.compose env40227 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12670) := by decide +kernel

theorem selectedBound40227 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env40228 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,12670,5392,12799,4417,8541,4097,5276,4160,13358,13768,1361,1150,5441,1297,3124,8205,8200,257,5457,1344,5953]

theorem envBound40228 : H12AffineFastState.Bounded env40228 := by
  intro p hp
  have h : env40228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40227_40228 : H12AffineEnvironment.transform 15 12670 env40227 = env40228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12670 env40227 == env40228) = true)

def env40229 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,8192,1296,8540,8494,1344,8623,273,8541,81,1228,16,9342,9624,1361,1150,1297,1297,3124,8205,8200,257,1281,1344,1809]

theorem envBound40229 : H12AffineFastState.Bounded env40229 := by
  intro p hp
  have h : env40229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40228_40229 : H12AffineEnvironment.transform 11 80 env40228 = env40229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env40228 == env40229) = true)

theorem identity40229 : scanCanonicalize (H12AffineFastState.compose env40229 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound40229 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env40230 : List Nat := [2,4,8,16,32,64,128,21,512,1024,2048,80,8192,1029,8265,8251,1109,8378,4,8264,81,1228,16,9342,9357,1092,1150,1028,1028,3124,8205,8200,20,1044,1109,1540]

theorem envBound40230 : H12AffineFastState.Bounded env40230 := by
  intro p hp
  have h : env40230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40229_40230 : H12AffineEnvironment.transform 7 21 env40229 = env40230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env40229 == env40230) = true)

theorem identity40230 : scanCanonicalize (H12AffineFastState.compose env40230 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound40230 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env40231 : List Nat := [2,4,8,16,32,64,128,21,512,4,2048,80,8192,1,8265,8251,81,8378,4,8264,81,200,16,8314,8329,64,122,0,0,2096,8205,8200,20,16,81,512]

theorem envBound40231 : H12AffineFastState.Bounded env40231 := by
  intro p hp
  have h : env40231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40230_40231 : H12AffineEnvironment.transform 9 4 env40230 = env40231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env40230 == env40231) = true)

theorem identity40231 : scanCanonicalize (H12AffineFastState.compose env40231 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound40231 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env40232 : List Nat := [2,4,8,16,32,17,128,21,512,4,2048,1,8192,1,8216,8251,0,8378,4,8217,0,153,16,8235,8329,17,43,0,0,2096,8205,8200,20,16,0,512]

theorem envBound40232 : H12AffineFastState.Bounded env40232 := by
  intro p hp
  have h : env40232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40231_40232 : H12AffineEnvironment.transform 5 17 env40231 = env40232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env40231 == env40232) = true)

theorem identity40232 : scanCanonicalize (H12AffineFastState.compose env40232 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound40232 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40233 : List Nat := [2,4,8,16,32,17,128,21,512,4,512,1,8192,1,8216,8251,0,8378,4,8217,0,153,16,8235,8329,17,43,0,0,560,8205,8200,20,16,0,512]

theorem envBound40233 : H12AffineFastState.Bounded env40233 := by
  intro p hp
  have h : env40233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40232_40233 : H12AffineEnvironment.transform 10 512 env40232 = env40233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env40232 == env40233) = true)

theorem identity40233 : scanCanonicalize (H12AffineFastState.compose env40233 (packedSelected [3,8] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound40233 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env40234 : List Nat := [2,4,8,16,32,17,128,21,1,4,1,1,8192,1,8216,8251,0,8378,4,8217,0,153,16,8235,8329,17,43,0,0,49,8205,8200,20,16,0,1]

theorem envBound40234 : H12AffineFastState.Bounded env40234 := by
  intro p hp
  have h : env40234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40233_40234 : H12AffineEnvironment.transform 8 1 env40233 = env40234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env40233 == env40234) = true)

theorem identity40234 : scanCanonicalize (H12AffineFastState.compose env40234 (packedSelected [0,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound40234 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env40235 : List Nat := [2,4,8,16,16,17,128,21,1,4,1,1,8192,1,8216,8203,0,8330,4,8217,0,153,16,8219,8329,17,27,0,0,1,8205,8200,20,16,0,1]

theorem envBound40235 : H12AffineFastState.Bounded env40235 := by
  intro p hp
  have h : env40235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40234_40235 : H12AffineEnvironment.transform 4 16 env40234 = env40235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env40234 == env40235) = true)

theorem identity40235 : scanCanonicalize (H12AffineFastState.compose env40235 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound40235 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env40236 : List Nat := [2,4,8,16,16,17,8,21,1,4,1,1,8192,1,8216,8203,0,8194,4,8217,0,17,16,8219,8193,17,27,0,0,1,8205,8200,20,16,0,1]

theorem envBound40236 : H12AffineFastState.Bounded env40236 := by
  intro p hp
  have h : env40236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40235_40236 : H12AffineEnvironment.transform 6 8 env40235 = env40236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env40235 == env40236) = true)

theorem identity40236 : scanCanonicalize (H12AffineFastState.compose env40236 (packedSelected [0,1] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound40236 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env40237 : List Nat := [2,4,8,16,16,17,8,21,1,4,1,1,25,1,1,18,0,27,4,0,0,17,16,2,24,17,27,0,0,1,20,17,20,16,0,1]

theorem envBound40237 : H12AffineFastState.Bounded env40237 := by
  intro p hp
  have h : env40237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40236_40237 : H12AffineEnvironment.transform 12 25 env40236 = env40237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env40236 == env40237) = true)

theorem identity40237 : scanCanonicalize (H12AffineFastState.compose env40237 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound40237 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40238 : List Nat := [2,4,8,12,12,13,8,9,1,4,1,1,5,1,1,14,0,7,4,0,0,13,12,2,4,13,7,0,0,1,8,13,8,12,0,1]

theorem envBound40238 : H12AffineFastState.Bounded env40238 := by
  intro p hp
  have h : env40238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40237_40238 : H12AffineEnvironment.transform 3 12 env40237 = env40238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env40237 == env40238) = true)

theorem identity40238 : scanCanonicalize (H12AffineFastState.compose env40238 (packedSelected [7] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound40238 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env40239 : List Nat := [2,2,8,10,10,11,8,9,1,2,1,1,3,1,1,8,0,1,2,0,0,11,10,2,2,11,1,0,0,1,8,11,8,10,0,1]

theorem envBound40239 : H12AffineFastState.Bounded env40239 := by
  intro p hp
  have h : env40239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40238_40239 : H12AffineEnvironment.transform 1 2 env40238 = env40239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env40238 == env40239) = true)

def env40240 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,8192,1296,8540,8495,1345,8622,272,8541,80,1229,17,9343,9625,1361,1150,1296,1297,3124,8205,8200,257,1280,1344,1808]

theorem envBound40240 : H12AffineFastState.Bounded env40240 := by
  intro p hp
  have h : env40240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40228_40240 : H12AffineEnvironment.transform 11 81 env40228 = env40240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env40228 == env40240) = true)

theorem identity40240 : scanCanonicalize (H12AffineFastState.compose env40240 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 72) := by decide +kernel

theorem selectedBound40240 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env40241 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,72,1296,276,359,1345,486,272,277,80,1229,17,1079,1489,1361,1150,1296,1297,3124,69,64,257,1280,1344,1808]

theorem envBound40241 : H12AffineFastState.Bounded env40241 := by
  intro p hp
  have h : env40241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40240_40241 : H12AffineEnvironment.transform 12 72 env40240 = env40241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env40240 == env40241) = true)

theorem identity40241 : scanCanonicalize (H12AffineFastState.compose env40241 (packedSelected [0,2,3,5,7,10,11,12,13,15,18,20] rootPS)) = affineNative (2^(8+1) ^^^ 460) := by decide +kernel

theorem selectedBound40241 : packedSelected [0,2,3,5,7,10,11,12,13,15,18,20] rootPS < 2^1333 := by decide +kernel

def env40242 : List Nat := [2,4,8,16,32,64,128,256,460,1024,2048,81,72,1296,276,359,1345,486,272,277,80,1229,17,1079,1489,1361,1150,1296,1297,3124,69,64,257,1280,1344,1244]

theorem envBound40242 : H12AffineFastState.Bounded env40242 := by
  intro p hp
  have h : env40242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40241_40242 : H12AffineEnvironment.transform 8 460 env40241 = env40242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 460 env40241 == env40242) = true)

theorem identity40242 : scanCanonicalize (H12AffineFastState.compose env40242 (packedSelected [0,1,2,3,4,7,8,9,10,11,12,13,15,23,24] rootPS)) = affineNative (2^(9+1) ^^^ 85) := by decide +kernel

theorem selectedBound40242 : packedSelected [0,1,2,3,4,7,8,9,10,11,12,13,15,23,24] rootPS < 2^1333 := by decide +kernel

def env40243 : List Nat := [2,4,8,16,32,64,128,256,460,85,2048,81,72,325,276,359,276,486,272,277,80,152,17,98,388,260,43,325,324,2145,69,64,257,341,277,137]

theorem envBound40243 : H12AffineFastState.Bounded env40243 := by
  intro p hp
  have h : env40243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40242_40243 : H12AffineEnvironment.transform 9 85 env40242 = env40243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env40242 == env40243) = true)

theorem identity40243 : scanCanonicalize (H12AffineFastState.compose env40243 (packedSelected [0,3,4,5,7,9,11,13,16,17] rootPS)) = affineNative (2^(7+1) ^^^ 182) := by decide +kernel

theorem selectedBound40243 : packedSelected [0,3,4,5,7,9,11,13,16,17] rootPS < 2^1333 := by decide +kernel

def env40244 : List Nat := [2,4,8,16,32,64,128,182,122,85,2048,81,72,243,162,209,162,80,166,163,80,152,17,98,50,178,43,243,242,2145,69,64,183,227,163,137]

theorem envBound40244 : H12AffineFastState.Bounded env40244 := by
  intro p hp
  have h : env40244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40243_40244 : H12AffineEnvironment.transform 7 182 env40243 = env40244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 182 env40243 == env40244) = true)

theorem identity40244 : scanCanonicalize (H12AffineFastState.compose env40244 (packedSelected [3,8,10,12] rootPS)) = affineNative (2^(6+1) ^^^ 105) := by decide +kernel

theorem selectedBound40244 : packedSelected [3,8,10,12] rootPS < 2^1333 := by decide +kernel

def env40245 : List Nat := [2,4,8,16,32,64,105,95,122,85,2048,81,72,26,75,56,75,80,79,74,80,113,17,98,50,91,43,26,27,2145,69,64,94,10,74,96]

theorem envBound40245 : H12AffineFastState.Bounded env40245 := by
  intro p hp
  have h : env40245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40244_40245 : H12AffineEnvironment.transform 6 105 env40244 = env40245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 105 env40244 == env40245) = true)

theorem identity40245 : scanCanonicalize (H12AffineFastState.compose env40245 (packedSelected [0,1,5,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound40245 : packedSelected [0,1,5,9,10] rootPS < 2^1333 := by decide +kernel

def env40246 : List Nat := [2,4,8,16,32,17,56,14,43,4,2048,0,25,26,26,56,26,1,30,27,1,32,17,51,50,10,43,26,27,2096,20,17,15,10,27,49]

theorem envBound40246 : H12AffineFastState.Bounded env40246 := by
  intro p hp
  have h : env40246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40245_40246 : H12AffineEnvironment.transform 5 17 env40245 = env40246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env40245 == env40246) = true)

theorem identity40246 : scanCanonicalize (H12AffineFastState.compose env40246 (packedSelected [1,2,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound40246 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env40247 : List Nat := [2,4,8,16,16,17,8,14,27,4,2048,0,25,26,26,8,26,1,30,27,1,16,17,3,2,10,27,26,27,2048,20,17,15,10,27,1]

theorem envBound40247 : H12AffineFastState.Bounded env40247 := by
  intro p hp
  have h : env40247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40246_40247 : H12AffineEnvironment.transform 4 16 env40246 = env40247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env40246 == env40247) = true)

theorem identity40247 : scanCanonicalize (H12AffineFastState.compose env40247 (packedSelected [0,1,4] rootPS)) = affineNative (2^(10+1) ^^^ 28) := by decide +kernel

theorem selectedBound40247 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env40248 : List Nat := [2,4,8,16,16,17,8,14,27,4,28,0,25,26,26,8,26,1,30,27,1,16,17,3,2,10,27,26,27,28,20,17,15,10,27,1]

theorem envBound40248 : H12AffineFastState.Bounded env40248 := by
  intro p hp
  have h : env40248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40247_40248 : H12AffineEnvironment.transform 10 28 env40247 = env40248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 28 env40247 == env40248) = true)

theorem identity40248 : scanCanonicalize (H12AffineFastState.compose env40248 (packedSelected [0,1,2,7] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound40248 : packedSelected [0,1,2,7] rootPS < 2^1333 := by decide +kernel

def env40249 : List Nat := [2,4,8,11,11,10,8,14,0,4,7,0,2,1,1,8,1,1,5,0,1,11,10,3,2,10,0,1,0,7,15,10,15,10,0,1]

theorem envBound40249 : H12AffineFastState.Bounded env40249 := by
  intro p hp
  have h : env40249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40248_40249 : H12AffineEnvironment.transform 3 11 env40248 = env40249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env40248 == env40249) = true)

theorem identity40249 : scanCanonicalize (H12AffineFastState.compose env40249 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound40249 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40250 : List Nat := [1,4,8,8,8,9,8,13,0,4,4,0,1,1,1,8,1,1,5,0,1,8,9,0,1,9,0,1,0,4,12,9,12,9,0,1]

theorem envBound40250 : H12AffineFastState.Bounded env40250 := by
  intro p hp
  have h : env40250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40249_40250 : H12AffineEnvironment.transform 0 1 env40249 = env40250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env40249 == env40250) = true)

theorem identity40250 : scanCanonicalize (H12AffineFastState.compose env40250 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound40250 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40251 : List Nat := [1,4,4,4,4,5,4,1,0,4,4,0,1,1,1,4,1,1,5,0,1,4,5,0,1,5,0,1,0,4,0,5,0,5,0,1]

theorem envBound40251 : H12AffineFastState.Bounded env40251 := by
  intro p hp
  have h : env40251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40250_40251 : H12AffineEnvironment.transform 2 4 env40250 = env40251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env40250 == env40251) = true)

theorem identity40251 : scanCanonicalize (H12AffineFastState.compose env40251 (packedSelected [8] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound40251 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env40252 : List Nat := [1,1,1,1,1,0,1,1,0,1,1,0,1,1,1,1,1,1,0,0,1,1,0,0,1,0,0,1,0,1,0,0,0,0,0,1]

theorem envBound40252 : H12AffineFastState.Bounded env40252 := by
  intro p hp
  have h : env40252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40251_40252 : H12AffineEnvironment.transform 1 1 env40251 = env40252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env40251 == env40252) = true)

def env40253 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74862,262144,4416,8540,4097,5276,74047,66896,13769,78895,328959,74814,1297,81227,8204,8201,257,74799,1344,5952]

theorem envBound40253 : H12AffineFastState.Bounded env40253 := by
  intro p hp
  have h : env40253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40201_40253 : H12AffineEnvironment.transform 13 1297 env40201 = env40253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env40201 == env40253) = true)

def env40254 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74862,65664,4416,8540,4097,5276,74047,66896,13769,78895,1151,74814,1297,81227,8204,8201,257,74799,1344,5952]

theorem envBound40254 : H12AffineFastState.Bounded env40254 := by
  intro p hp
  have h : env40254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40253_40254 : H12AffineEnvironment.transform 17 65664 env40253 = env40254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env40253 == env40254) = true)

theorem identity40254 : scanCanonicalize (H12AffineFastState.compose env40254 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5238) := by decide +kernel

theorem selectedBound40254 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env40255 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,5238,12312,5366,4416,8540,4097,5276,13641,4390,13769,8281,1151,12360,1297,10557,8204,8201,257,12377,1344,5952]

theorem envBound40255 : H12AffineFastState.Bounded env40255 := by
  intro p hp
  have h : env40255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40254_40255 : H12AffineEnvironment.transform 15 5238 env40254 = env40255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5238 env40254 == env40255) = true)

def env40256 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5464,1297,5125,5238,1344,5366,4416,5124,4097,5276,17,4390,145,5377,1151,1296,1297,7269,5460,5457,257,1281,1344,5952]

theorem envBound40256 : H12AffineFastState.Bounded env40256 := by
  intro p hp
  have h : env40256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40255_40256 : H12AffineEnvironment.transform 12 5464 env40255 = env40256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5464 env40255 == env40256) = true)

theorem identity40256 : scanCanonicalize (H12AffineFastState.compose env40256 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound40256 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env40257 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,4096,4444,277,4097,4210,324,4338,4416,4096,4097,4248,17,4390,145,4357,123,276,277,6241,4432,4437,257,261,324,4932]

theorem envBound40257 : H12AffineFastState.Bounded env40257 := by
  intro p hp
  have h : env40257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40256_40257 : H12AffineEnvironment.transform 9 4 env40256 = env40257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env40256 == env40257) = true)

theorem identity40257 : scanCanonicalize (H12AffineFastState.compose env40257 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 324) := by decide +kernel

theorem selectedBound40257 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env40258 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,324,24,277,325,310,324,438,4,324,325,476,17,98,145,65,123,276,277,2341,20,17,257,261,324,512]

theorem envBound40258 : H12AffineFastState.Bounded env40258 := by
  intro p hp
  have h : env40258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40257_40258 : H12AffineEnvironment.transform 11 324 env40257 = env40258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 324 env40257 == env40258) = true)

theorem identity40258 : scanCanonicalize (H12AffineFastState.compose env40258 (packedSelected [2,5,8,13] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound40258 : packedSelected [2,5,8,13] rootPS < 2^1333 := by decide +kernel

def env40259 : List Nat := [2,4,8,16,32,64,128,172,512,4,2048,232,24,185,233,154,232,26,4,232,233,112,17,98,145,65,123,184,185,2185,20,17,173,169,232,512]

theorem envBound40259 : H12AffineFastState.Bounded env40259 := by
  intro p hp
  have h : env40259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40258_40259 : H12AffineEnvironment.transform 7 172 env40258 = env40259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env40258 == env40259) = true)

theorem identity40259 : scanCanonicalize (H12AffineFastState.compose env40259 (packedSelected [2,4,5,8,9,10,11] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound40259 : packedSelected [2,4,5,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env40260 : List Nat := [2,4,8,16,32,64,128,172,137,4,2048,232,24,185,233,154,232,26,4,232,233,112,17,98,145,65,123,184,185,2185,20,17,173,169,232,137]

theorem envBound40260 : H12AffineFastState.Bounded env40260 := by
  intro p hp
  have h : env40260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40259_40260 : H12AffineEnvironment.transform 8 137 env40259 = env40260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env40259 == env40260) = true)

theorem identity40260 : scanCanonicalize (H12AffineFastState.compose env40260 (packedSelected [0,2,3,4,7,8,9,10,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 194) := by decide +kernel

theorem selectedBound40260 : packedSelected [0,2,3,4,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env40261 : List Nat := [2,4,8,16,32,64,128,172,137,4,194,232,24,185,233,154,232,26,4,232,233,112,17,98,145,65,123,184,185,75,20,17,173,169,232,137]

theorem envBound40261 : H12AffineFastState.Bounded env40261 := by
  intro p hp
  have h : env40261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40260_40261 : H12AffineEnvironment.transform 10 194 env40260 = env40261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 194 env40260 == env40261) = true)

theorem identity40261 : scanCanonicalize (H12AffineFastState.compose env40261 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound40261 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env40262 : List Nat := [2,4,8,16,32,16,128,172,137,4,146,184,24,185,185,154,184,26,4,184,185,32,17,50,145,17,43,184,185,27,20,17,173,169,184,137]

theorem envBound40262 : H12AffineFastState.Bounded env40262 := by
  intro p hp
  have h : env40262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40261_40262 : H12AffineEnvironment.transform 5 16 env40261 = env40262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env40261 == env40262) = true)

theorem identity40262 : scanCanonicalize (H12AffineFastState.compose env40262 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound40262 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40263 : List Nat := [2,4,8,16,32,16,34,14,43,4,48,26,24,27,27,56,26,26,4,26,27,32,17,50,51,17,43,26,27,27,20,17,15,11,26,43]

theorem envBound40263 : H12AffineFastState.Bounded env40263 := by
  intro p hp
  have h : env40263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40262_40263 : H12AffineEnvironment.transform 6 34 env40262 = env40263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env40262 == env40263) = true)

def env40264 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5465,1297,5124,5238,1345,5366,4416,5125,4097,5276,16,4390,144,5376,1151,1297,1297,7268,5461,5456,257,1280,1344,5952]

theorem envBound40264 : H12AffineFastState.Bounded env40264 := by
  intro p hp
  have h : env40264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40255_40264 : H12AffineEnvironment.transform 12 5465 env40255 = env40264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5465 env40255 == env40264) = true)

theorem identity40264 : scanCanonicalize (H12AffineFastState.compose env40264 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound40264 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env40265 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,1369,1297,1028,1142,1345,1270,320,1029,1,1180,16,294,144,1280,1151,1297,1297,3172,1365,1360,257,1280,1344,1856]

theorem envBound40265 : H12AffineFastState.Bounded env40265 := by
  intro p hp
  have h : env40265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40264_40265 : H12AffineEnvironment.transform 11 0 env40264 = env40265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env40264 == env40265) = true)

theorem identity40265 : scanCanonicalize (H12AffineFastState.compose env40265 (packedSelected [0,2,3,4,5,7,9,10,11,12,15,16,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 950) := by decide +kernel

theorem selectedBound40265 : packedSelected [0,2,3,4,5,7,9,10,11,12,15,16,17,18,20] rootPS < 2^1333 := by decide +kernel

def env40266 : List Nat := [2,4,8,16,32,64,128,256,512,1024,950,0,1369,1297,1028,1142,1345,1270,320,1029,1,1180,16,294,144,1280,1151,1297,1297,2002,1365,1360,257,1280,1344,1856]

theorem envBound40266 : H12AffineFastState.Bounded env40266 := by
  intro p hp
  have h : env40266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40265_40266 : H12AffineEnvironment.transform 10 950 env40265 = env40266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 950 env40265 == env40266) = true)

theorem identity40266 : scanCanonicalize (H12AffineFastState.compose env40266 (packedSelected [0,1,2,4,5,7,9,10,11,13,23] rootPS)) = affineNative (2^(9+1) ^^^ 237) := by decide +kernel

theorem selectedBound40266 : packedSelected [0,1,2,4,5,7,9,10,11,13,23] rootPS < 2^1333 := by decide +kernel

def env40267 : List Nat := [2,4,8,16,32,64,128,256,512,237,950,0,436,508,233,155,428,27,320,232,1,113,16,294,144,493,146,508,508,831,440,445,257,493,429,941]

theorem envBound40267 : H12AffineFastState.Bounded env40267 := by
  intro p hp
  have h : env40267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40266_40267 : H12AffineEnvironment.transform 9 237 env40266 = env40267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 237 env40266 == env40267) = true)

theorem identity40267 : scanCanonicalize (H12AffineFastState.compose env40267 (packedSelected [0,1,2,3,7,12,16] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound40267 : packedSelected [0,1,2,3,7,12,16] rootPS < 2^1333 := by decide +kernel

def env40268 : List Nat := [2,4,8,16,32,64,128,256,48,237,390,0,436,508,233,155,428,27,320,232,1,113,16,294,144,493,146,508,508,271,440,445,257,493,429,413]

theorem envBound40268 : H12AffineFastState.Bounded env40268 := by
  intro p hp
  have h : env40268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40267_40268 : H12AffineEnvironment.transform 8 48 env40267 = env40268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env40267 == env40268) = true)

theorem identity40268 : scanCanonicalize (H12AffineFastState.compose env40268 (packedSelected [2,4,5,8,9,10,11,13] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound40268 : packedSelected [2,4,5,8,9,10,11,13] rootPS < 2^1333 := by decide +kernel

def env40269 : List Nat := [2,4,8,16,32,64,128,69,48,237,195,0,241,185,233,155,233,27,5,232,1,113,16,99,144,168,146,185,185,74,253,248,68,168,232,216]

theorem envBound40269 : H12AffineFastState.Bounded env40269 := by
  intro p hp
  have h : env40269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40268_40269 : H12AffineEnvironment.transform 7 69 env40268 = env40269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env40268 == env40269) = true)

theorem identity40269 : scanCanonicalize (H12AffineFastState.compose env40269 (packedSelected [1,2,3,4,9] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound40269 : packedSelected [1,2,3,4,9] rootPS < 2^1333 := by decide +kernel

def env40270 : List Nat := [2,4,8,16,32,64,19,69,48,126,80,0,98,42,122,8,122,27,5,123,1,113,16,99,3,59,1,42,42,74,110,107,68,59,123,75]

theorem envBound40270 : H12AffineFastState.Bounded env40270 := by
  intro p hp
  have h : env40270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40269_40270 : H12AffineEnvironment.transform 6 19 env40269 = env40270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env40269 == env40270) = true)

theorem identity40270 : scanCanonicalize (H12AffineFastState.compose env40270 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound40270 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env40271 : List Nat := [2,4,8,16,32,17,19,20,48,47,1,0,51,42,43,8,43,27,5,42,1,32,16,50,3,59,1,42,42,27,63,58,21,59,42,26]

theorem envBound40271 : H12AffineFastState.Bounded env40271 := by
  intro p hp
  have h : env40271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40270_40271 : H12AffineEnvironment.transform 5 17 env40270 = env40271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env40270 == env40271) = true)

theorem identity40271 : scanCanonicalize (H12AffineFastState.compose env40271 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound40271 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40272 : List Nat := [2,3,8,16,32,17,19,19,48,40,1,0,51,42,43,8,43,27,2,42,1,32,16,50,3,59,1,42,42,27,56,58,18,59,42,26]

theorem envBound40272 : H12AffineFastState.Bounded env40272 := by
  intro p hp
  have h : env40272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40271_40272 : H12AffineEnvironment.transform 1 3 env40271 = env40272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env40271 == env40272) = true)

theorem identity40272 : scanCanonicalize (H12AffineFastState.compose env40272 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound40272 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40273 : List Nat := [2,3,8,16,10,17,19,19,26,2,1,0,25,0,1,8,1,27,2,0,1,10,16,24,3,17,1,0,0,27,18,16,18,17,0,26]

theorem envBound40273 : H12AffineFastState.Bounded env40273 := by
  intro p hp
  have h : env40273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40272_40273 : H12AffineEnvironment.transform 4 10 env40272 = env40273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env40272 == env40273) = true)

theorem identity40273 : scanCanonicalize (H12AffineFastState.compose env40273 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound40273 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env40274 : List Nat := [2,3,8,10,10,11,9,9,0,2,1,0,3,0,1,8,1,1,2,0,1,10,10,2,3,11,1,0,0,1,8,10,8,11,0,0]

theorem envBound40274 : H12AffineFastState.Bounded env40274 := by
  intro p hp
  have h : env40274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40273_40274 : H12AffineEnvironment.transform 3 10 env40273 = env40274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env40273 == env40274) = true)

def env40275 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74862,65665,4416,8540,4097,5276,74047,66896,13769,78895,1150,74814,1297,81227,8204,8201,257,74799,1344,5952]

theorem envBound40275 : H12AffineFastState.Bounded env40275 := by
  intro p hp
  have h : env40275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40253_40275 : H12AffineEnvironment.transform 17 65665 env40253 = env40275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env40253 == env40275) = true)

theorem identity40275 : scanCanonicalize (H12AffineFastState.compose env40275 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 311) := by decide +kernel

theorem selectedBound40275 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env40276 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,311,9561,438,4416,8540,4097,5276,8200,1127,13769,13592,1150,9481,1297,15484,8204,8201,257,9496,1344,5952]

theorem envBound40276 : H12AffineFastState.Bounded env40276 := by
  intro p hp
  have h : env40276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40275_40276 : H12AffineEnvironment.transform 15 311 env40275 = env40276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 311 env40275 == env40276) = true)

def env40277 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,24,1297,325,311,1345,438,4416,324,4097,5276,16,1127,5585,5376,1150,1297,1297,7268,20,17,257,1280,1344,5952]

theorem envBound40277 : H12AffineFastState.Bounded env40277 := by
  intro p hp
  have h : env40277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40276_40277 : H12AffineEnvironment.transform 12 24 env40276 = env40277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env40276 == env40277) = true)

theorem identity40277 : scanCanonicalize (H12AffineFastState.compose env40277 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound40277 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env40278 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,24,80,325,311,0,438,4416,324,4097,4573,16,294,4240,4161,319,80,80,6437,20,17,257,65,1,4609]

theorem envBound40278 : H12AffineFastState.Bounded env40278 := by
  intro p hp
  have h : env40278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40277_40278 : H12AffineEnvironment.transform 9 321 env40277 = env40278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env40277 == env40278) = true)

theorem identity40278 : scanCanonicalize (H12AffineFastState.compose env40278 (packedSelected [0,2,3,4,5,7,9,10,11,12,15,16,17,18,20] rootPS)) = affineNative (2^(11+1) ^^^ 2999) := by decide +kernel

theorem selectedBound40278 : packedSelected [0,2,3,4,5,7,9,10,11,12,15,16,17,18,20] rootPS < 2^1333 := by decide +kernel

def env40279 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,2999,24,80,325,311,0,438,2807,324,2998,2666,16,294,2855,3062,319,80,80,658,20,17,257,65,1,2486]

theorem envBound40279 : H12AffineFastState.Bounded env40279 := by
  intro p hp
  have h : env40279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40278_40279 : H12AffineEnvironment.transform 11 2999 env40278 = env40279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2999 env40278 == env40279) = true)

theorem identity40279 : scanCanonicalize (H12AffineFastState.compose env40279 (packedSelected [0,1,2,4,5,7,9,10,11,13,23] rootPS)) = affineNative (2^(10+1) ^^^ 538) := by decide +kernel

theorem selectedBound40279 : packedSelected [0,1,2,4,5,7,9,10,11,13,23] rootPS < 2^1333 := by decide +kernel

def env40280 : List Nat := [2,4,8,16,32,64,128,256,512,321,538,429,24,80,325,311,0,438,237,324,428,112,16,294,317,492,319,80,80,658,20,17,257,65,1,940]

theorem envBound40280 : H12AffineFastState.Bounded env40280 := by
  intro p hp
  have h : env40280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40279_40280 : H12AffineEnvironment.transform 10 538 env40279 = env40280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 538 env40279 == env40280) = true)

theorem identity40280 : scanCanonicalize (H12AffineFastState.compose env40280 (packedSelected [0,1,2,3,7,12,13,16,17] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound40280 : packedSelected [0,1,2,3,7,12,13,16,17] rootPS < 2^1333 := by decide +kernel

def env40281 : List Nat := [2,4,8,16,32,64,128,256,293,321,319,429,24,80,325,311,0,438,237,324,428,112,16,294,317,492,319,80,80,439,20,17,257,65,1,137]

theorem envBound40281 : H12AffineFastState.Bounded env40281 := by
  intro p hp
  have h : env40281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40280_40281 : H12AffineEnvironment.transform 8 293 env40280 = env40281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env40280 == env40281) = true)

theorem identity40281 : scanCanonicalize (H12AffineFastState.compose env40281 (packedSelected [0,2,3,4,8,10] rootPS)) = affineNative (2^(7+1) ^^^ 134) := by decide +kernel

theorem selectedBound40281 : packedSelected [0,2,3,4,8,10] rootPS < 2^1333 := by decide +kernel

def env40282 : List Nat := [2,4,8,16,32,64,128,134,163,199,185,43,24,80,195,177,0,48,237,194,42,112,16,160,187,106,185,80,80,49,20,17,135,65,1,137]

theorem envBound40282 : H12AffineFastState.Bounded env40282 := by
  intro p hp
  have h : env40282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40281_40282 : H12AffineEnvironment.transform 7 134 env40281 = env40282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 134 env40281 == env40282) = true)

theorem identity40282 : scanCanonicalize (H12AffineFastState.compose env40282 (packedSelected [1,4,5,9] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound40282 : packedSelected [1,4,5,9] rootPS < 2^1333 := by decide +kernel

def env40283 : List Nat := [2,4,8,16,32,64,88,94,123,31,97,43,24,80,27,105,0,48,53,26,42,112,16,120,99,106,97,80,80,49,20,17,95,65,1,81]

theorem envBound40283 : H12AffineFastState.Bounded env40283 := by
  intro p hp
  have h : env40283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40282_40283 : H12AffineEnvironment.transform 6 88 env40282 = env40283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env40282 == env40283) = true)

theorem identity40283 : scanCanonicalize (H12AffineFastState.compose env40283 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound40283 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env40284 : List Nat := [2,4,8,11,32,64,67,69,96,4,97,43,3,75,0,105,0,43,46,1,42,107,11,99,99,106,97,75,75,42,15,10,68,65,1,74]

theorem envBound40284 : H12AffineFastState.Bounded env40284 := by
  intro p hp
  have h : env40284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40283_40284 : H12AffineEnvironment.transform 3 11 env40283 = env40284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env40283 == env40284) = true)

theorem identity40284 : scanCanonicalize (H12AffineFastState.compose env40284 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound40284 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40285 : List Nat := [2,4,8,11,11,64,67,69,75,4,74,0,3,75,0,66,0,0,5,1,1,64,11,72,72,65,74,75,75,1,15,10,68,65,1,74]

theorem envBound40285 : H12AffineFastState.Bounded env40285 := by
  intro p hp
  have h : env40285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40284_40285 : H12AffineEnvironment.transform 4 11 env40284 = env40285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env40284 == env40285) = true)

theorem identity40285 : scanCanonicalize (H12AffineFastState.compose env40285 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound40285 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env40286 : List Nat := [2,4,1,2,2,64,67,69,66,4,67,0,3,66,0,66,0,0,5,1,1,64,2,65,65,65,67,66,66,1,6,3,68,65,1,67]

theorem envBound40286 : H12AffineFastState.Bounded env40286 := by
  intro p hp
  have h : env40286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40285_40286 : H12AffineEnvironment.transform 2 1 env40285 = env40286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env40285 == env40286) = true)

theorem identity40286 : scanCanonicalize (H12AffineFastState.compose env40286 (packedSelected [0,3] rootPS)) = affineNative (2^(5+1) ^^^ 3) := by decide +kernel

theorem selectedBound40286 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env40287 : List Nat := [2,4,1,2,2,3,0,6,1,4,0,0,3,1,0,1,0,0,5,1,1,3,2,2,2,2,0,1,1,1,6,3,7,2,1,0]

theorem envBound40287 : H12AffineFastState.Bounded env40287 := by
  intro p hp
  have h : env40287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40286_40287 : H12AffineEnvironment.transform 5 3 env40286 = env40287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 3 env40286 == env40287) = true)

theorem identity40287 : scanCanonicalize (H12AffineFastState.compose env40287 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound40287 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40288 : List Nat := [2,2,1,2,2,3,0,0,1,2,0,0,3,1,0,1,0,0,3,1,1,3,2,2,2,2,0,1,1,1,0,3,1,2,1,0]

theorem envBound40288 : H12AffineFastState.Bounded env40288 := by
  intro p hp
  have h : env40288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40287_40288 : H12AffineEnvironment.transform 1 2 env40287 = env40288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env40287 == env40288) = true)

theorem identity40288 : scanCanonicalize (H12AffineFastState.compose env40288 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound40288 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env40289 : List Nat := [0,0,1,0,0,1,0,0,1,0,0,0,1,1,0,1,0,0,1,1,1,1,0,0,0,0,0,1,1,1,0,1,1,0,1,0]

theorem envBound40289 : H12AffineFastState.Bounded env40289 := by
  intro p hp
  have h : env40289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40288_40289 : H12AffineEnvironment.transform 0 0 env40288 = env40289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env40288 == env40289) = true)

def env40290 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,25,1297,324,311,1344,438,4416,325,4097,5276,17,1127,5584,5377,1150,1296,1297,7269,21,16,257,1281,1344,5952]

theorem envBound40290 : H12AffineFastState.Bounded env40290 := by
  intro p hp
  have h : env40290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40276_40290 : H12AffineEnvironment.transform 12 25 env40276 = env40290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env40276 == env40290) = true)

theorem identity40290 : scanCanonicalize (H12AffineFastState.compose env40290 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound40290 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env40291 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,4096,25,277,324,311,324,438,4416,325,4097,4248,17,99,4564,4357,122,276,277,6241,21,16,257,261,324,4932]

theorem envBound40291 : H12AffineFastState.Bounded env40291 := by
  intro p hp
  have h : env40291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40290_40291 : H12AffineEnvironment.transform 9 4 env40290 = env40291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env40290 == env40291) = true)

theorem identity40291 : scanCanonicalize (H12AffineFastState.compose env40291 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 324) := by decide +kernel

theorem selectedBound40291 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env40292 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,324,25,277,324,311,324,438,4,325,325,476,17,99,144,65,122,276,277,2341,21,16,257,261,324,512]

theorem envBound40292 : H12AffineFastState.Bounded env40292 := by
  intro p hp
  have h : env40292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40291_40292 : H12AffineEnvironment.transform 11 324 env40291 = env40292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 324 env40291 == env40292) = true)

theorem identity40292 : scanCanonicalize (H12AffineFastState.compose env40292 (packedSelected [2,5,8,13] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound40292 : packedSelected [2,5,8,13] rootPS < 2^1333 := by decide +kernel

def env40293 : List Nat := [2,4,8,16,32,64,128,68,512,4,2048,0,25,81,0,115,0,242,4,1,1,152,17,99,144,65,122,80,81,2145,21,16,69,65,0,512]

theorem envBound40293 : H12AffineFastState.Bounded env40293 := by
  intro p hp
  have h : env40293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40292_40293 : H12AffineEnvironment.transform 7 68 env40292 = env40293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env40292 == env40293) = true)

theorem identity40293 : scanCanonicalize (H12AffineFastState.compose env40293 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 217) := by decide +kernel

theorem selectedBound40293 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env40294 : List Nat := [2,4,8,16,32,64,128,68,217,4,2048,0,25,81,0,115,0,242,4,1,1,152,17,99,144,65,122,80,81,2145,21,16,69,65,0,217]

theorem envBound40294 : H12AffineFastState.Bounded env40294 := by
  intro p hp
  have h : env40294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40293_40294 : H12AffineEnvironment.transform 8 217 env40293 = env40294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env40293 == env40294) = true)

theorem identity40294 : scanCanonicalize (H12AffineFastState.compose env40294 (packedSelected [0,2,3,7,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound40294 : packedSelected [0,2,3,7,8,11] rootPS < 2^1333 := by decide +kernel

def env40295 : List Nat := [2,4,8,16,32,64,128,68,217,4,43,0,25,81,0,115,0,242,4,1,1,152,17,99,144,65,122,80,81,74,21,16,69,65,0,217]

theorem envBound40295 : H12AffineFastState.Bounded env40295 := by
  intro p hp
  have h : env40295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40294_40295 : H12AffineEnvironment.transform 10 43 env40294 = env40295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env40294 == env40295) = true)

theorem identity40295 : scanCanonicalize (H12AffineFastState.compose env40295 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound40295 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env40296 : List Nat := [2,4,8,16,32,16,128,20,137,4,43,0,25,1,0,35,0,162,4,1,1,152,17,51,144,17,42,0,1,26,21,16,21,17,0,137]

theorem envBound40296 : H12AffineFastState.Bounded env40296 := by
  intro p hp
  have h : env40296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40295_40296 : H12AffineEnvironment.transform 5 16 env40295 = env40296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env40295 == env40296) = true)

theorem identity40296 : scanCanonicalize (H12AffineFastState.compose env40296 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 63) := by decide +kernel

theorem selectedBound40296 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40297 : List Nat := [2,4,8,16,32,16,63,20,54,4,43,0,25,1,0,35,0,29,4,1,1,39,17,51,47,17,42,0,1,26,21,16,21,17,0,54]

theorem envBound40297 : H12AffineFastState.Bounded env40297 := by
  intro p hp
  have h : env40297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40296_40297 : H12AffineEnvironment.transform 6 63 env40296 = env40297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 63 env40296 == env40297) = true)

theorem identity40297 : scanCanonicalize (H12AffineFastState.compose env40297 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound40297 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40298 : List Nat := [2,4,8,11,32,11,36,15,45,4,43,0,2,1,0,35,0,6,4,1,1,39,10,40,47,10,42,0,1,1,14,11,14,10,0,45]

theorem envBound40298 : H12AffineFastState.Bounded env40298 := by
  intro p hp
  have h : env40298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40297_40298 : H12AffineEnvironment.transform 3 11 env40297 = env40298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env40297 == env40298) = true)

theorem identity40298 : scanCanonicalize (H12AffineFastState.compose env40298 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound40298 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40299 : List Nat := [2,4,8,11,12,11,8,15,1,4,7,0,2,1,0,15,0,6,4,1,1,11,10,4,3,10,6,0,1,1,14,11,14,10,0,1]

theorem envBound40299 : H12AffineFastState.Bounded env40299 := by
  intro p hp
  have h : env40299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40298_40299 : H12AffineEnvironment.transform 4 12 env40298 = env40299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env40298 == env40299) = true)

theorem identity40299 : scanCanonicalize (H12AffineFastState.compose env40299 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound40299 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env40300 : List Nat := [2,3,8,11,11,11,8,8,1,3,0,0,2,1,0,8,0,1,3,1,1,11,10,3,3,10,1,0,1,1,9,11,9,10,0,1]

theorem envBound40300 : H12AffineFastState.Bounded env40300 := by
  intro p hp
  have h : env40300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40299_40300 : H12AffineEnvironment.transform 1 3 env40299 = env40300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env40299 == env40300) = true)

def env40301 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,524288,32769,4097,61648,91182,123165,533641,614526,385202,90415,545088,96346,25884,536904,257,74799,1344,525824]

theorem envBound40301 : H12AffineFastState.Bounded env40301 := by
  intro p hp
  have h : env40301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40100_40301 : H12AffineEnvironment.transform 23 123165 env40100 = env40301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 123165 env40100 == env40301) = true)

def env40302 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,21584,32769,4097,61648,91182,123165,28889,78894,385202,90415,1296,96346,25884,25880,257,74799,1344,21072]

theorem envBound40302 : H12AffineFastState.Bounded env40302 := by
  intro p hp
  have h : env40302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40301_40302 : H12AffineEnvironment.transform 18 21584 env40301 = env40302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21584 env40301 == env40302) = true)

theorem identity40302 : scanCanonicalize (H12AffineFastState.compose env40302 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound40302 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env40303 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,13340,65536,74862,262144,21584,13341,4097,17612,91182,87297,28889,78894,349358,90415,1296,96346,25884,25880,257,74799,1344,21072]

theorem envBound40303 : H12AffineFastState.Bounded env40303 := by
  intro p hp
  have h : env40303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40302_40303 : H12AffineEnvironment.transform 14 13340 env40302 = env40303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env40302 == env40303) = true)

def env40304 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74862,262144,4416,13341,4097,476,74046,69649,13769,78894,332222,74815,1296,81226,8204,8200,257,74799,1344,5952]

theorem envBound40304 : H12AffineFastState.Bounded env40304 := by
  intro p hp
  have h : env40304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40303_40304 : H12AffineEnvironment.transform 13 1296 env40303 = env40304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env40303 == env40304) = true)

def env40305 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74862,65664,4416,13341,4097,476,74046,69649,13769,78894,4414,74815,1296,81226,8204,8200,257,74799,1344,5952]

theorem envBound40305 : H12AffineFastState.Bounded env40305 := by
  intro p hp
  have h : env40305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40304_40305 : H12AffineEnvironment.transform 17 65664 env40304 = env40305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env40304 == env40305) = true)

theorem identity40305 : scanCanonicalize (H12AffineFastState.compose env40305 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound40305 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env40306 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,8192,1296,9293,65536,74862,65664,273,9292,80,476,74046,65600,9624,74879,367,74815,1296,77083,8204,8200,257,74799,1344,1809]

theorem envBound40306 : H12AffineFastState.Bounded env40306 := by
  intro p hp
  have h : env40306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40305_40306 : H12AffineEnvironment.transform 11 81 env40305 = env40306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env40305 == env40306) = true)

def env40307 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,81,8192,80,8461,65536,74030,65664,273,8460,80,476,74046,65600,8408,74047,367,74111,80,75867,8204,8200,257,74095,0,593]

theorem envBound40307 : H12AffineFastState.Bounded env40307 := by
  intro p hp
  have h : env40307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40306_40307 : H12AffineEnvironment.transform 9 320 env40306 = env40307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env40306 == env40307) = true)

theorem identity40307 : scanCanonicalize (H12AffineFastState.compose env40307 (packedSelected [7,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound40307 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env40308 : List Nat := [2,4,8,16,32,64,128,69,512,5,2048,81,8192,80,8264,65536,73835,65664,84,8265,80,153,73851,65600,8408,73850,42,73786,80,75867,8204,8200,68,73770,0,593]

theorem envBound40308 : H12AffineFastState.Bounded env40308 := by
  intro p hp
  have h : env40308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40307_40308 : H12AffineEnvironment.transform 7 69 env40307 = env40308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env40307 == env40308) = true)

theorem identity40308 : scanCanonicalize (H12AffineFastState.compose env40308 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 8299) := by decide +kernel

theorem selectedBound40308 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env40309 : List Nat := [2,4,8,16,32,64,128,69,512,5,2048,81,8192,80,8264,8299,0,8427,84,8265,80,153,16,8235,8408,17,42,81,80,2096,8204,8200,68,65,0,593]

theorem envBound40309 : H12AffineFastState.Bounded env40309 := by
  intro p hp
  have h : env40309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40308_40309 : H12AffineEnvironment.transform 15 8299 env40308 = env40309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8299 env40308 == env40309) = true)

theorem identity40309 : scanCanonicalize (H12AffineFastState.compose env40309 (packedSelected [0,1,2,5,7,13,17,18] rootPS)) = affineNative (2^(12+1) ^^^ 83) := by decide +kernel

theorem selectedBound40309 : packedSelected [0,1,2,5,7,13,17,18] rootPS < 2^1333 := by decide +kernel

def env40310 : List Nat := [2,4,8,16,32,64,128,69,512,5,2048,81,83,80,27,56,0,184,84,26,80,153,16,120,139,17,42,81,80,2096,95,91,68,65,0,593]

theorem envBound40310 : H12AffineFastState.Bounded env40310 := by
  intro p hp
  have h : env40310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40309_40310 : H12AffineEnvironment.transform 12 83 env40309 = env40310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 83 env40309 == env40310) = true)

theorem identity40310 : scanCanonicalize (H12AffineFastState.compose env40310 (packedSelected [1,2,8,10,15,17] rootPS)) = affineNative (2^(8+1) ^^^ 96) := by decide +kernel

theorem selectedBound40310 : packedSelected [1,2,8,10,15,17] rootPS < 2^1333 := by decide +kernel

def env40311 : List Nat := [2,4,8,16,32,64,128,69,96,5,2048,81,83,80,27,56,0,184,84,26,80,153,16,120,139,17,42,81,80,2096,95,91,68,65,0,49]

theorem envBound40311 : H12AffineFastState.Bounded env40311 := by
  intro p hp
  have h : env40311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40310_40311 : H12AffineEnvironment.transform 8 96 env40310 = env40311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 96 env40310 == env40311) = true)

theorem identity40311 : scanCanonicalize (H12AffineFastState.compose env40311 (packedSelected [1,5,10,15] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound40311 : packedSelected [1,5,10,15] rootPS < 2^1333 := by decide +kernel

def env40312 : List Nat := [2,4,8,16,32,64,88,69,96,5,2048,81,83,80,27,56,0,96,84,26,80,65,16,120,83,17,42,81,80,2096,95,91,68,65,0,49]

theorem envBound40312 : H12AffineFastState.Bounded env40312 := by
  intro p hp
  have h : env40312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40311_40312 : H12AffineEnvironment.transform 6 88 env40311 = env40312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env40311 == env40312) = true)

theorem identity40312 : scanCanonicalize (H12AffineFastState.compose env40312 (packedSelected [2,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound40312 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env40313 : List Nat := [2,4,8,16,16,64,88,69,80,5,2048,81,83,80,27,8,0,80,84,26,80,65,16,72,83,17,26,81,80,2048,95,91,68,65,0,1]

theorem envBound40313 : H12AffineFastState.Bounded env40313 := by
  intro p hp
  have h : env40313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40312_40313 : H12AffineEnvironment.transform 4 16 env40312 = env40313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env40312 == env40313) = true)

theorem identity40313 : scanCanonicalize (H12AffineFastState.compose env40313 (packedSelected [4,7] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound40313 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env40314 : List Nat := [2,4,8,16,16,64,88,69,80,5,1,81,83,80,27,8,0,80,84,26,80,65,16,72,83,17,26,81,80,1,95,91,68,65,0,1]

theorem envBound40314 : H12AffineFastState.Bounded env40314 := by
  intro p hp
  have h : env40314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40313_40314 : H12AffineEnvironment.transform 10 1 env40313 = env40314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env40313 == env40314) = true)

theorem identity40314 : scanCanonicalize (H12AffineFastState.compose env40314 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound40314 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40315 : List Nat := [2,4,8,10,10,64,66,69,74,5,1,75,73,74,1,8,0,74,78,0,74,65,10,72,73,11,0,75,74,1,69,65,68,65,0,1]

theorem envBound40315 : H12AffineFastState.Bounded env40315 := by
  intro p hp
  have h : env40315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40314_40315 : H12AffineEnvironment.transform 3 10 env40314 = env40315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env40314 == env40315) = true)

theorem identity40315 : scanCanonicalize (H12AffineFastState.compose env40315 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 13) := by decide +kernel

theorem selectedBound40315 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40316 : List Nat := [2,4,8,10,10,13,15,8,7,5,1,6,4,7,1,8,0,7,3,0,7,12,10,5,4,11,0,6,7,1,8,12,9,12,0,1]

theorem envBound40316 : H12AffineFastState.Bounded env40316 := by
  intro p hp
  have h : env40316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40315_40316 : H12AffineEnvironment.transform 5 13 env40315 = env40316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 13 env40315 == env40316) = true)

def env40317 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,81,8192,81,8460,65536,74031,65664,273,8461,80,476,74046,65600,8409,74046,367,74110,81,75866,8204,8200,257,74094,1,592]

theorem envBound40317 : H12AffineFastState.Bounded env40317 := by
  intro p hp
  have h : env40317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40306_40317 : H12AffineEnvironment.transform 9 321 env40306 = env40317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env40306 == env40317) = true)

theorem identity40317 : scanCanonicalize (H12AffineFastState.compose env40317 (packedSelected [7,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound40317 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env40318 : List Nat := [2,4,8,16,32,64,128,21,512,84,2048,81,8192,81,8217,65536,73786,65664,4,8216,80,201,73771,65600,8409,73771,122,73835,81,75866,8204,8200,20,73851,1,592]

theorem envBound40318 : H12AffineFastState.Bounded env40318 := by
  intro p hp
  have h : env40318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40317_40318 : H12AffineEnvironment.transform 7 21 env40317 = env40318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env40317 == env40318) = true)

theorem identity40318 : scanCanonicalize (H12AffineFastState.compose env40318 (packedSelected [0,1,4,7,8,9,16,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 8250) := by decide +kernel

theorem selectedBound40318 : packedSelected [0,1,4,7,8,9,16,19,20] rootPS < 2^1333 := by decide +kernel

def env40319 : List Nat := [2,4,8,16,32,64,128,21,512,84,2048,81,8192,81,8217,8250,0,8378,4,8216,80,201,17,8314,8409,17,122,81,81,2144,8204,8200,20,65,1,592]

theorem envBound40319 : H12AffineFastState.Bounded env40319 := by
  intro p hp
  have h : env40319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40318_40319 : H12AffineEnvironment.transform 15 8250 env40318 = env40319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8250 env40318 == env40319) = true)

theorem identity40319 : scanCanonicalize (H12AffineFastState.compose env40319 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound40319 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env40320 : List Nat := [2,4,8,16,32,16,128,21,512,4,2048,1,8192,1,8217,8250,0,8378,4,8216,0,153,17,8234,8329,17,42,1,1,2096,8204,8200,20,17,1,512]

theorem envBound40320 : H12AffineFastState.Bounded env40320 := by
  intro p hp
  have h : env40320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40319_40320 : H12AffineEnvironment.transform 5 16 env40319 = env40320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env40319 == env40320) = true)

theorem identity40320 : scanCanonicalize (H12AffineFastState.compose env40320 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 561) := by decide +kernel

theorem selectedBound40320 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40321 : List Nat := [2,4,8,16,32,16,128,21,512,4,561,1,8192,1,8217,8250,0,8378,4,8216,0,153,17,8234,8329,17,42,1,1,513,8204,8200,20,17,1,512]

theorem envBound40321 : H12AffineFastState.Bounded env40321 := by
  intro p hp
  have h : env40321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40320_40321 : H12AffineEnvironment.transform 10 561 env40320 = env40321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 561 env40320 == env40321) = true)

theorem identity40321 : scanCanonicalize (H12AffineFastState.compose env40321 (packedSelected [3,8] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound40321 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env40322 : List Nat := [2,4,8,16,32,16,128,21,512,4,561,1,40,1,49,18,0,146,4,48,0,153,17,2,161,17,42,1,1,513,36,32,20,17,1,512]

theorem envBound40322 : H12AffineFastState.Bounded env40322 := by
  intro p hp
  have h : env40322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40321_40322 : H12AffineEnvironment.transform 12 40 env40321 = env40322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env40321 == env40322) = true)

theorem identity40322 : scanCanonicalize (H12AffineFastState.compose env40322 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound40322 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env40323 : List Nat := [2,4,8,16,32,16,128,21,48,4,1,1,40,1,49,18,0,146,4,48,0,153,17,2,161,17,42,1,1,49,36,32,20,17,1,48]

theorem envBound40323 : H12AffineFastState.Bounded env40323 := by
  intro p hp
  have h : env40323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40322_40323 : H12AffineEnvironment.transform 8 48 env40322 = env40323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env40322 == env40323) = true)

theorem identity40323 : scanCanonicalize (H12AffineFastState.compose env40323 (packedSelected [1,4] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound40323 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env40324 : List Nat := [2,4,8,16,32,16,35,21,48,4,1,1,40,1,49,18,0,49,4,48,0,58,17,2,2,17,42,1,1,49,36,32,20,17,1,48]

theorem envBound40324 : H12AffineFastState.Bounded env40324 := by
  intro p hp
  have h : env40324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40323_40324 : H12AffineEnvironment.transform 6 35 env40323 = env40324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env40323 == env40324) = true)

theorem identity40324 : scanCanonicalize (H12AffineFastState.compose env40324 (packedSelected [0,5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound40324 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env40325 : List Nat := [2,4,8,16,17,16,18,21,1,4,1,1,25,1,0,18,0,0,4,1,0,11,17,2,2,17,27,1,1,0,21,17,20,17,1,1]

theorem envBound40325 : H12AffineFastState.Bounded env40325 := by
  intro p hp
  have h : env40325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40324_40325 : H12AffineEnvironment.transform 4 17 env40324 = env40325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env40324 == env40325) = true)

theorem identity40325 : scanCanonicalize (H12AffineFastState.compose env40325 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound40325 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40326 : List Nat := [2,3,8,16,17,16,18,18,1,3,1,1,25,1,0,18,0,0,3,1,0,11,17,2,2,17,27,1,1,0,18,17,19,17,1,1]

theorem envBound40326 : H12AffineFastState.Bounded env40326 := by
  intro p hp
  have h : env40326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40325_40326 : H12AffineEnvironment.transform 1 3 env40325 = env40326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env40325 == env40326) = true)

def env40327 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74862,65665,4416,13341,4097,476,74046,69649,13769,78894,4415,74815,1296,81226,8204,8200,257,74799,1344,5952]

theorem envBound40327 : H12AffineFastState.Bounded env40327 := by
  intro p hp
  have h : env40327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40304_40327 : H12AffineEnvironment.transform 17 65665 env40304 = env40327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env40304 == env40327) = true)

theorem identity40327 : scanCanonicalize (H12AffineFastState.compose env40327 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound40327 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env40328 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,8192,0,12556,65536,74110,65665,4416,12557,4097,476,74046,69649,12505,78142,4415,74031,0,79962,8204,8200,257,74047,80,4688]

theorem envBound40328 : H12AffineFastState.Bounded env40328 := by
  intro p hp
  have h : env40328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40327_40328 : H12AffineEnvironment.transform 9 272 env40327 = env40328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env40327 == env40328) = true)

def env40329 : List Nat := [2,4,8,16,32,64,128,256,340,272,2048,4096,8192,0,12556,65536,74110,65665,4416,12557,4097,476,74046,69649,12505,78142,4415,74031,0,79962,8204,8200,257,74047,80,4356]

theorem envBound40329 : H12AffineFastState.Bounded env40329 := by
  intro p hp
  have h : env40329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40328_40329 : H12AffineEnvironment.transform 8 340 env40328 = env40329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env40328 == env40329) = true)

def env40330 : List Nat := [2,4,8,16,32,64,128,256,340,272,2048,16,8192,0,8476,65536,74110,65665,336,8477,17,476,74046,65537,8393,74030,303,74031,0,75850,8204,8200,257,74047,80,276]

theorem envBound40330 : H12AffineFastState.Bounded env40330 := by
  intro p hp
  have h : env40330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40329_40330 : H12AffineEnvironment.transform 11 16 env40329 = env40330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env40329 == env40330) = true)

theorem identity40330 : scanCanonicalize (H12AffineFastState.compose env40330 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 298) := by decide +kernel

theorem selectedBound40330 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env40331 : List Nat := [2,4,8,16,32,64,128,256,340,272,2048,16,298,0,54,65536,65620,65665,336,55,17,476,65556,65537,483,65540,303,65541,0,67936,294,290,257,65557,80,276]

theorem envBound40331 : H12AffineFastState.Bounded env40331 := by
  intro p hp
  have h : env40331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40330_40331 : H12AffineEnvironment.transform 12 298 env40330 = env40331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 298 env40330 == env40331) = true)

def env40332 : List Nat := [2,4,4,16,32,64,128,256,340,272,2048,16,294,0,54,65536,65620,65665,336,55,17,464,65556,65537,483,65540,291,65541,0,67936,294,290,257,65557,80,276]

theorem envBound40332 : H12AffineFastState.Bounded env40332 := by
  intro p hp
  have h : env40332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40331_40332 : H12AffineEnvironment.transform 2 4 env40331 = env40332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env40331 == env40332) = true)

theorem identity40332 : scanCanonicalize (H12AffineFastState.compose env40332 (packedSelected [1,2,4,9,10,11,15,17,20,21,23,24] rootPS)) = affineNative (2^(10+1) ^^^ 481) := by decide +kernel

theorem selectedBound40332 : packedSelected [1,2,4,9,10,11,15,17,20,21,23,24] rootPS < 2^1333 := by decide +kernel

def env40333 : List Nat := [2,4,4,16,32,64,128,256,340,272,481,16,294,0,54,65536,65620,65665,336,55,17,464,65556,65537,483,65540,291,65541,0,65665,294,290,257,65557,80,276]

theorem envBound40333 : H12AffineFastState.Bounded env40333 := by
  intro p hp
  have h : env40333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40332_40333 : H12AffineEnvironment.transform 10 481 env40332 = env40333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 481 env40332 == env40333) = true)

theorem identity40333 : scanCanonicalize (H12AffineFastState.compose env40333 (packedSelected [0,3,7,9,10,11,12,16,17,21,23,27] rootPS)) = affineNative (2^(15+1) ^^^ 485) := by decide +kernel

theorem selectedBound40333 : packedSelected [0,3,7,9,10,11,12,16,17,21,23,27] rootPS < 2^1333 := by decide +kernel

def env40334 : List Nat := [2,4,4,16,32,64,128,256,340,272,481,16,294,0,54,485,433,356,336,55,17,464,497,484,483,481,291,480,0,356,294,290,257,496,80,276]

theorem envBound40334 : H12AffineFastState.Bounded env40334 := by
  intro p hp
  have h : env40334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40333_40334 : H12AffineEnvironment.transform 15 485 env40333 = env40334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 485 env40333 == env40334) = true)

theorem identity40334 : scanCanonicalize (H12AffineFastState.compose env40334 (packedSelected [0,1,2,4,7,8,9,16] rootPS)) = affineNative (2^(6+1) ^^^ 20) := by decide +kernel

theorem selectedBound40334 : packedSelected [0,1,2,4,7,8,9,16] rootPS < 2^1333 := by decide +kernel

def env40335 : List Nat := [2,4,4,16,32,64,20,256,340,272,373,16,294,0,54,369,293,356,336,55,17,324,357,368,375,373,291,372,0,356,294,290,257,356,80,276]

theorem envBound40335 : H12AffineFastState.Bounded env40335 := by
  intro p hp
  have h : env40335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40334_40335 : H12AffineEnvironment.transform 6 20 env40334 = env40335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 20 env40334 == env40335) = true)

theorem identity40335 : scanCanonicalize (H12AffineFastState.compose env40335 (packedSelected [1,2,5,8] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound40335 : packedSelected [1,2,5,8] rootPS < 2^1333 := by decide +kernel

def env40336 : List Nat := [2,3,3,16,32,64,19,256,339,272,370,16,289,0,49,369,290,355,336,48,17,323,354,368,368,370,291,371,0,355,289,290,257,355,80,275]

theorem envBound40336 : H12AffineFastState.Bounded env40336 := by
  intro p hp
  have h : env40336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40335_40336 : H12AffineEnvironment.transform 1 3 env40335 = env40336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env40335 == env40336) = true)

theorem identity40336 : scanCanonicalize (H12AffineFastState.compose env40336 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound40336 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env40337 : List Nat := [2,3,3,16,17,64,19,256,339,272,323,16,272,0,0,320,275,338,336,1,17,323,339,321,321,323,274,322,0,338,272,275,257,338,80,275]

theorem envBound40337 : H12AffineFastState.Bounded env40337 := by
  intro p hp
  have h : env40337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40336_40337 : H12AffineEnvironment.transform 4 17 env40336 = env40337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env40336 == env40337) = true)

theorem identity40337 : scanCanonicalize (H12AffineFastState.compose env40337 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 2) := by decide +kernel

theorem selectedBound40337 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40338 : List Nat := [2,3,3,16,17,64,19,2,81,18,65,16,18,0,0,66,17,80,82,1,17,65,81,67,67,65,16,64,0,80,18,17,3,80,80,17]

theorem envBound40338 : H12AffineFastState.Bounded env40338 := by
  intro p hp
  have h : env40338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40337_40338 : H12AffineEnvironment.transform 7 2 env40337 = env40338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 2 env40337 == env40338) = true)

theorem identity40338 : scanCanonicalize (H12AffineFastState.compose env40338 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound40338 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40339 : List Nat := [2,3,3,16,17,1,19,2,16,18,0,16,18,0,0,3,17,17,19,1,17,0,16,2,2,0,16,1,0,17,18,17,3,17,17,17]

theorem envBound40339 : H12AffineFastState.Bounded env40339 := by
  intro p hp
  have h : env40339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40338_40339 : H12AffineEnvironment.transform 5 1 env40338 = env40339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env40338 == env40339) = true)

theorem identity40339 : scanCanonicalize (H12AffineFastState.compose env40339 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound40339 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40340 : List Nat := [2,3,3,2,3,1,1,2,2,0,0,2,0,0,0,3,3,3,1,1,3,0,2,2,2,0,2,1,0,3,0,3,3,3,3,3]

theorem envBound40340 : H12AffineFastState.Bounded env40340 := by
  intro p hp
  have h : env40340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40339_40340 : H12AffineEnvironment.transform 3 2 env40339 = env40340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env40339 == env40340) = true)

theorem identity40340 : scanCanonicalize (H12AffineFastState.compose env40340 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound40340 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env40341 : List Nat := [1,0,0,1,0,1,1,1,1,0,0,1,0,0,0,0,0,0,1,1,0,0,1,1,1,0,1,1,0,0,0,0,0,0,0,0]

theorem envBound40341 : H12AffineFastState.Bounded env40341 := by
  intro p hp
  have h : env40341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40340_40341 : H12AffineEnvironment.transform 0 1 env40340 = env40341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env40340 == env40341) = true)

def env40342 : List Nat := [2,4,5,16,32,64,128,256,340,272,2048,16,295,0,54,65536,65620,65665,336,55,17,465,65556,65537,483,65540,290,65541,0,67936,294,290,257,65557,80,276]

theorem envBound40342 : H12AffineFastState.Bounded env40342 := by
  intro p hp
  have h : env40342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40331_40342 : H12AffineEnvironment.transform 2 5 env40331 = env40342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env40331 == env40342) = true)

theorem identity40342 : scanCanonicalize (H12AffineFastState.compose env40342 (packedSelected [1,2,4,9,10,11,15,17,20,21,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 2263) := by decide +kernel

theorem selectedBound40342 : packedSelected [1,2,4,9,10,11,15,17,20,21,23,24] rootPS < 2^1333 := by decide +kernel

def env40343 : List Nat := [2,4,5,16,32,64,128,256,340,272,2048,16,295,0,54,2263,2179,2134,336,55,17,465,2243,2262,483,2259,290,2258,0,439,294,290,257,2242,80,276]

theorem envBound40343 : H12AffineFastState.Bounded env40343 := by
  intro p hp
  have h : env40343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40342_40343 : H12AffineEnvironment.transform 15 2263 env40342 = env40343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2263 env40342 == env40343) = true)

theorem identity40343 : scanCanonicalize (H12AffineFastState.compose env40343 (packedSelected [1,5,7,8,9,11,13,16,18,20,23] rootPS)) = affineNative (2^(10+1) ^^^ 325) := by decide +kernel

theorem selectedBound40343 : packedSelected [1,5,7,8,9,11,13,16,18,20,23] rootPS < 2^1333 := by decide +kernel

def env40344 : List Nat := [2,4,5,16,32,64,128,256,340,272,325,16,295,0,54,402,454,275,336,55,17,465,390,403,483,406,290,407,0,439,294,290,257,391,80,276]

theorem envBound40344 : H12AffineFastState.Bounded env40344 := by
  intro p hp
  have h : env40344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40343_40344 : H12AffineEnvironment.transform 10 325 env40343 = env40344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 325 env40343 == env40344) = true)

theorem identity40344 : scanCanonicalize (H12AffineFastState.compose env40344 (packedSelected [0,5,8,9,10,11,12,15,16] rootPS)) = affineNative (2^(6+1) ^^^ 82) := by decide +kernel

theorem selectedBound40344 : packedSelected [0,5,8,9,10,11,12,15,16] rootPS < 2^1333 := by decide +kernel

def env40345 : List Nat := [2,4,5,16,32,64,82,256,340,272,325,16,295,0,54,320,276,275,336,55,17,259,340,321,305,324,290,325,0,357,294,290,257,341,80,276]

theorem envBound40345 : H12AffineFastState.Bounded env40345 := by
  intro p hp
  have h : env40345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40344_40345 : H12AffineEnvironment.transform 6 82 env40344 = env40345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 82 env40344 == env40345) = true)

theorem identity40345 : scanCanonicalize (H12AffineFastState.compose env40345 (packedSelected [0,1,2,4,5,7,8,9,10,11] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound40345 : packedSelected [0,1,2,4,5,7,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env40346 : List Nat := [2,4,5,16,16,64,82,256,340,272,325,16,279,0,6,320,276,275,336,7,17,259,340,321,257,324,274,325,0,341,278,274,257,341,80,276]

theorem envBound40346 : H12AffineFastState.Bounded env40346 := by
  intro p hp
  have h : env40346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40345_40346 : H12AffineEnvironment.transform 4 16 env40345 = env40346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env40345 == env40346) = true)

theorem identity40346 : scanCanonicalize (H12AffineFastState.compose env40346 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound40346 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40347 : List Nat := [2,4,5,16,16,0,18,256,276,272,261,16,279,0,6,256,276,275,272,7,17,259,276,257,257,260,274,261,0,277,278,274,257,277,16,276]

theorem envBound40347 : H12AffineFastState.Bounded env40347 := by
  intro p hp
  have h : env40347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40346_40347 : H12AffineEnvironment.transform 5 0 env40346 = env40347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env40346 == env40347) = true)

def env40348 : List Nat := [2,4,8,16,32,64,128,256,340,272,2048,17,8192,0,8477,65536,74110,65665,337,8476,16,476,74046,65536,8392,74031,302,74031,0,75851,8204,8200,257,74047,80,277]

theorem envBound40348 : H12AffineFastState.Bounded env40348 := by
  intro p hp
  have h : env40348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40329_40348 : H12AffineEnvironment.transform 11 17 env40329 = env40348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env40329 == env40348) = true)

theorem identity40348 : scanCanonicalize (H12AffineFastState.compose env40348 (packedSelected [1,8,28] rootPS)) = affineNative (2^(7+1) ^^^ 50) := by decide +kernel

theorem selectedBound40348 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env40349 : List Nat := [2,4,8,16,32,64,128,50,102,34,2048,17,8192,0,8239,65536,73804,65665,99,8238,16,238,73740,65536,8392,73757,28,73757,0,75851,8204,8200,51,73741,80,39]

theorem envBound40349 : H12AffineFastState.Bounded env40349 := by
  intro p hp
  have h : env40349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40348_40349 : H12AffineEnvironment.transform 7 50 env40348 = env40349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 50 env40348 == env40349) = true)

def env40350 : List Nat := [2,4,8,16,32,64,128,50,102,34,2048,17,8192,0,8239,10440,2180,10313,99,8238,16,238,2244,10440,8392,2261,28,2261,0,131,8204,8200,51,2245,80,39]

theorem envBound40350 : H12AffineFastState.Bounded env40350 := by
  intro p hp
  have h : env40350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40349_40350 : H12AffineEnvironment.transform 15 10440 env40349 = env40350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 10440 env40349 == env40350) = true)

theorem identity40350 : scanCanonicalize (H12AffineFastState.compose env40350 (packedSelected [0,4,5,8,9,10,11,15,17,19,20,21,27,32,41] rootPS)) = affineNative (2^(12+1) ^^^ 2084) := by decide +kernel

theorem selectedBound40350 : packedSelected [0,4,5,8,9,10,11,15,17,19,20,21,27,32,41] rootPS < 2^1333 := by decide +kernel

def env40351 : List Nat := [2,4,8,16,32,64,128,50,102,34,2048,17,2084,0,2059,236,2180,109,99,2058,16,238,2244,236,2284,2261,28,2261,0,131,2088,2092,51,2245,80,39]

theorem envBound40351 : H12AffineFastState.Bounded env40351 := by
  intro p hp
  have h : env40351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40350_40351 : H12AffineEnvironment.transform 12 2084 env40350 = env40351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2084 env40350 == env40351) = true)

theorem identity40351 : scanCanonicalize (H12AffineFastState.compose env40351 (packedSelected [1,3,4,9,11,12,13,15,16,17,18,21] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound40351 : packedSelected [1,3,4,9,11,12,13,15,16,17,18,21] rootPS < 2^1333 := by decide +kernel

def env40352 : List Nat := [2,4,8,16,32,10,128,50,44,34,2048,17,2084,0,2059,166,2180,39,41,2058,16,164,2190,166,2214,2207,28,2207,0,131,2088,2092,51,2191,26,39]

theorem envBound40352 : H12AffineFastState.Bounded env40352 := by
  intro p hp
  have h : env40352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40351_40352 : H12AffineEnvironment.transform 5 10 env40351 = env40352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env40351 == env40352) = true)

theorem identity40352 : scanCanonicalize (H12AffineFastState.compose env40352 (packedSelected [0,1,2,3,4,7,8,9,11,12,15,16,18] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound40352 : packedSelected [0,1,2,3,4,7,8,9,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env40353 : List Nat := [2,4,2,16,32,0,128,50,38,34,2048,17,2084,0,2049,166,2180,39,35,2048,16,164,2180,166,2214,2197,22,2197,0,131,2082,2086,51,2181,16,39]

theorem envBound40353 : H12AffineFastState.Bounded env40353 := by
  intro p hp
  have h : env40353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40352_40353 : H12AffineEnvironment.transform 2 2 env40352 = env40353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env40352 == env40353) = true)

theorem identity40353 : scanCanonicalize (H12AffineFastState.compose env40353 (packedSelected [0,1,2,3,4,5,7,8,9,10,11] rootPS)) = affineNative (2^(6+1) ^^^ 36) := by decide +kernel

theorem selectedBound40353 : packedSelected [0,1,2,3,4,5,7,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env40354 : List Nat := [2,4,2,16,32,0,36,50,38,34,2048,17,2084,0,2049,2,2080,39,35,2048,16,0,2080,2,2050,2097,22,2097,0,39,2082,2086,51,2081,16,39]

theorem envBound40354 : H12AffineFastState.Bounded env40354 := by
  intro p hp
  have h : env40354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40353_40354 : H12AffineEnvironment.transform 6 36 env40353 = env40354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 36 env40353 == env40354) = true)

theorem identity40354 : scanCanonicalize (H12AffineFastState.compose env40354 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound40354 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40355 : List Nat := [2,4,2,16,32,0,36,50,38,34,32,17,4,0,33,2,0,39,35,32,16,0,0,2,34,17,22,17,0,39,2,6,51,1,16,39]

theorem envBound40355 : H12AffineFastState.Bounded env40355 := by
  intro p hp
  have h : env40355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40354_40355 : H12AffineEnvironment.transform 10 32 env40354 = env40355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env40354 == env40355) = true)

theorem identity40355 : scanCanonicalize (H12AffineFastState.compose env40355 (packedSelected [3,4] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound40355 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env40356 : List Nat := [2,4,2,16,2,0,6,16,4,0,2,17,4,0,3,2,0,5,1,2,16,0,0,2,0,17,22,17,0,5,2,6,17,1,16,5]

theorem envBound40356 : H12AffineFastState.Bounded env40356 := by
  intro p hp
  have h : env40356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40355_40356 : H12AffineEnvironment.transform 4 2 env40355 = env40356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env40355 == env40356) = true)

theorem identity40356 : scanCanonicalize (H12AffineFastState.compose env40356 (packedSelected [2,5] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound40356 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env40357 : List Nat := [2,3,2,16,2,0,1,16,3,0,2,17,3,0,3,2,0,2,1,2,16,0,0,2,0,17,17,17,0,2,2,1,17,1,16,2]

theorem envBound40357 : H12AffineFastState.Bounded env40357 := by
  intro p hp
  have h : env40357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40356_40357 : H12AffineEnvironment.transform 1 3 env40356 = env40357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env40356 == env40357) = true)

theorem identity40357 : scanCanonicalize (H12AffineFastState.compose env40357 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound40357 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40358 : List Nat := [2,3,2,3,2,0,1,3,3,0,2,2,3,0,3,2,0,2,1,2,3,0,0,2,0,2,2,2,0,2,2,1,2,1,3,2]

theorem envBound40358 : H12AffineFastState.Bounded env40358 := by
  intro p hp
  have h : env40358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40357_40358 : H12AffineEnvironment.transform 3 3 env40357 = env40358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env40357 == env40358) = true)

theorem identity40358 : scanCanonicalize (H12AffineFastState.compose env40358 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound40358 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40359 : List Nat := [0,1,0,1,0,0,1,1,1,0,0,0,1,0,1,0,0,0,1,0,1,0,0,0,0,0,0,0,0,0,0,1,0,1,1,0]

theorem envBound40359 : H12AffineFastState.Bounded env40359 := by
  intro p hp
  have h : env40359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40358_40359 : H12AffineEnvironment.transform 0 0 env40358 = env40359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env40358 == env40359) = true)

def env40360 : List Nat := [2,4,8,16,32,64,128,50,102,34,2048,17,8192,0,8239,10441,2181,10312,99,8238,16,238,2245,10441,8392,2260,28,2260,0,130,8204,8200,51,2244,80,39]

theorem envBound40360 : H12AffineFastState.Bounded env40360 := by
  intro p hp
  have h : env40360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40349_40360 : H12AffineEnvironment.transform 15 10441 env40349 = env40360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 10441 env40349 == env40360) = true)

theorem identity40360 : scanCanonicalize (H12AffineFastState.compose env40360 (packedSelected [0,4,5,8,9,10,11,15,17,19,20,21,27,32,41] rootPS)) = affineNative (2^(12+1) ^^^ 241) := by decide +kernel

theorem selectedBound40360 : packedSelected [0,4,5,8,9,10,11,15,17,19,20,21,27,32,41] rootPS < 2^1333 := by decide +kernel

def env40361 : List Nat := [2,4,8,16,32,64,128,50,102,34,2048,17,241,0,222,2104,2181,2233,99,223,16,238,2245,2104,57,2260,28,2260,0,130,253,249,51,2244,80,39]

theorem envBound40361 : H12AffineFastState.Bounded env40361 := by
  intro p hp
  have h : env40361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40360_40361 : H12AffineEnvironment.transform 12 241 env40360 = env40361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 241 env40360 == env40361) = true)

theorem identity40361 : scanCanonicalize (H12AffineFastState.compose env40361 (packedSelected [1,10,11,12,13,15,16,19,20,23,24] rootPS)) = affineNative (2^(6+1) ^^^ 98) := by decide +kernel

theorem selectedBound40361 : packedSelected [1,10,11,12,13,15,16,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env40362 : List Nat := [2,4,8,16,32,64,98,50,102,34,2048,17,19,0,60,2104,2151,2139,99,61,16,12,2087,2104,57,2102,28,2102,0,96,31,27,51,2086,80,39]

theorem envBound40362 : H12AffineFastState.Bounded env40362 := by
  intro p hp
  have h : env40362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40361_40362 : H12AffineEnvironment.transform 6 98 env40361 = env40362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 98 env40361 == env40362) = true)

theorem identity40362 : scanCanonicalize (H12AffineFastState.compose env40362 (packedSelected [3,4,8,9,10,11,15] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound40362 : packedSelected [3,4,8,9,10,11,15] rootPS < 2^1333 := by decide +kernel

def env40363 : List Nat := [2,4,8,16,32,64,98,50,102,34,0,17,19,0,60,56,103,91,99,61,16,12,39,56,57,54,28,54,0,96,31,27,51,38,80,39]

theorem envBound40363 : H12AffineFastState.Bounded env40363 := by
  intro p hp
  have h : env40363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40362_40363 : H12AffineEnvironment.transform 10 0 env40362 = env40363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env40362 == env40363) = true)

theorem identity40363 : scanCanonicalize (H12AffineFastState.compose env40363 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(4+1) ^^^ 28) := by decide +kernel

theorem selectedBound40363 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env40364 : List Nat := [2,4,8,16,28,64,94,14,90,30,0,17,19,0,0,4,91,91,95,1,16,12,27,4,5,10,28,10,0,92,31,27,15,26,80,27]

theorem envBound40364 : H12AffineFastState.Bounded env40364 := by
  intro p hp
  have h : env40364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40363_40364 : H12AffineEnvironment.transform 4 28 env40363 = env40364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 28 env40363 == env40364) = true)

theorem identity40364 : scanCanonicalize (H12AffineFastState.compose env40364 (packedSelected [0,1,3,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 13) := by decide +kernel

theorem selectedBound40364 : packedSelected [0,1,3,7,8] rootPS < 2^1333 := by decide +kernel

def env40365 : List Nat := [2,4,8,16,28,13,19,14,23,30,0,17,19,0,0,4,22,22,18,1,16,12,27,4,5,10,28,10,0,17,31,27,15,26,29,27]

theorem envBound40365 : H12AffineFastState.Bounded env40365 := by
  intro p hp
  have h : env40365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40364_40365 : H12AffineEnvironment.transform 5 13 env40364 = env40365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 13 env40364 == env40365) = true)

theorem identity40365 : scanCanonicalize (H12AffineFastState.compose env40365 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound40365 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env40366 : List Nat := [2,4,8,0,12,13,3,14,7,14,0,1,3,0,0,4,6,6,2,1,0,12,11,4,5,10,12,10,0,1,15,11,15,10,13,11]

theorem envBound40366 : H12AffineFastState.Bounded env40366 := by
  intro p hp
  have h : env40366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40365_40366 : H12AffineEnvironment.transform 3 0 env40365 = env40366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env40365 == env40366) = true)

theorem identity40366 : scanCanonicalize (H12AffineFastState.compose env40366 (packedSelected [0,1,4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound40366 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env40367 : List Nat := [2,4,2,0,6,7,3,4,7,4,0,1,3,0,0,4,6,6,2,1,0,6,1,4,5,0,6,0,0,1,5,1,5,0,7,1]

theorem envBound40367 : H12AffineFastState.Bounded env40367 := by
  intro p hp
  have h : env40367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40366_40367 : H12AffineEnvironment.transform 2 2 env40366 = env40367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env40366 == env40367) = true)

theorem identity40367 : scanCanonicalize (H12AffineFastState.compose env40367 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound40367 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40368 : List Nat := [2,2,2,0,0,1,3,2,1,2,0,1,3,0,0,2,0,0,2,1,0,0,1,2,3,0,0,0,0,1,3,1,3,0,1,1]

theorem envBound40368 : H12AffineFastState.Bounded env40368 := by
  intro p hp
  have h : env40368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40367_40368 : H12AffineEnvironment.transform 1 2 env40367 = env40368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env40367 == env40368) = true)

def env40369 : List Nat := [2,4,8,16,32,64,128,256,341,272,2048,4096,8192,0,12556,65536,74110,65665,4416,12557,4097,476,74046,69649,12505,78142,4415,74031,0,79962,8204,8200,257,74047,80,4357]

theorem envBound40369 : H12AffineFastState.Bounded env40369 := by
  intro p hp
  have h : env40369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40328_40369 : H12AffineEnvironment.transform 8 341 env40328 = env40369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env40328 == env40369) = true)

def env40370 : List Nat := [2,4,8,16,32,64,128,256,341,272,2048,16,8192,0,8476,65536,74110,65665,336,8477,17,476,74046,65537,8393,74030,303,74031,0,75850,8204,8200,257,74047,80,277]

theorem envBound40370 : H12AffineFastState.Bounded env40370 := by
  intro p hp
  have h : env40370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40369_40370 : H12AffineEnvironment.transform 11 16 env40369 = env40370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env40369 == env40370) = true)

theorem identity40370 : scanCanonicalize (H12AffineFastState.compose env40370 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 4) := by decide +kernel

theorem selectedBound40370 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env40371 : List Nat := [2,4,8,16,32,64,128,256,341,272,2048,16,8192,0,8476,4,8570,133,336,8477,17,476,8506,5,8393,8490,303,8491,0,10318,8204,8200,257,8507,80,277]

theorem envBound40371 : H12AffineFastState.Bounded env40371 := by
  intro p hp
  have h : env40371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40370_40371 : H12AffineEnvironment.transform 15 4 env40370 = env40371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4 env40370 == env40371) = true)

def env40372 : List Nat := [2,4,8,16,32,64,128,256,341,272,2048,16,24,0,260,4,354,133,336,261,17,476,290,5,209,306,303,307,0,2134,20,16,257,291,80,277]

theorem envBound40372 : H12AffineFastState.Bounded env40372 := by
  intro p hp
  have h : env40372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40371_40372 : H12AffineEnvironment.transform 12 24 env40371 = env40372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env40371 == env40372) = true)

theorem identity40372 : scanCanonicalize (H12AffineFastState.compose env40372 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound40372 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env40373 : List Nat := [2,4,8,16,32,64,128,4,81,20,2048,16,24,0,0,4,102,133,84,1,17,216,38,5,209,54,43,55,0,2134,20,16,5,39,80,17]

theorem envBound40373 : H12AffineFastState.Bounded env40373 := by
  intro p hp
  have h : env40373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40372_40373 : H12AffineEnvironment.transform 7 4 env40372 = env40373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env40372 == env40373) = true)

theorem identity40373 : scanCanonicalize (H12AffineFastState.compose env40373 (packedSelected [0,1,2,4,7,8,9,10,12,13,16,18] rootPS)) = affineNative (2^(10+1) ^^^ 222) := by decide +kernel

theorem selectedBound40373 : packedSelected [0,1,2,4,7,8,9,10,12,13,16,18] rootPS < 2^1333 := by decide +kernel

def env40374 : List Nat := [2,4,8,16,32,64,128,4,81,20,222,16,24,0,0,4,102,133,84,1,17,216,38,5,209,54,43,55,0,136,20,16,5,39,80,17]

theorem envBound40374 : H12AffineFastState.Bounded env40374 := by
  intro p hp
  have h : env40374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40373_40374 : H12AffineEnvironment.transform 10 222 env40373 = env40374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 222 env40373 == env40374) = true)

theorem identity40374 : scanCanonicalize (H12AffineFastState.compose env40374 (packedSelected [0,1,2,5,7,11,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 47) := by decide +kernel

theorem selectedBound40374 : packedSelected [0,1,2,5,7,11,12,15] rootPS < 2^1333 := by decide +kernel

def env40375 : List Nat := [2,4,8,16,32,64,47,4,81,20,113,16,24,0,0,4,102,42,84,1,17,119,38,5,126,54,43,55,0,39,20,16,5,39,80,17]

theorem envBound40375 : H12AffineFastState.Bounded env40375 := by
  intro p hp
  have h : env40375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40374_40375 : H12AffineEnvironment.transform 6 47 env40374 = env40375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 47 env40374 == env40375) = true)

theorem identity40375 : scanCanonicalize (H12AffineFastState.compose env40375 (packedSelected [0,2,3,5,7,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound40375 : packedSelected [0,2,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env40376 : List Nat := [2,4,8,16,32,17,47,4,0,20,32,16,24,0,0,4,55,42,5,1,17,38,38,5,47,54,43,55,0,39,20,16,5,39,1,17]

theorem envBound40376 : H12AffineFastState.Bounded env40376 := by
  intro p hp
  have h : env40376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40375_40376 : H12AffineEnvironment.transform 5 17 env40375 = env40376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env40375 == env40376) = true)

def env40377 : List Nat := [2,4,8,16,32,64,128,256,341,272,2048,16,25,0,261,4,355,133,336,260,17,476,291,5,208,307,303,306,0,2135,21,17,257,290,80,277]

theorem envBound40377 : H12AffineFastState.Bounded env40377 := by
  intro p hp
  have h : env40377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40371_40377 : H12AffineEnvironment.transform 12 25 env40371 = env40377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env40371 == env40377) = true)

theorem identity40377 : scanCanonicalize (H12AffineFastState.compose env40377 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound40377 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env40378 : List Nat := [2,4,8,16,32,64,128,68,17,84,2048,16,25,0,65,4,39,133,20,64,17,152,103,5,208,119,107,118,0,2135,21,17,69,102,80,81]

theorem envBound40378 : H12AffineFastState.Bounded env40378 := by
  intro p hp
  have h : env40378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40377_40378 : H12AffineEnvironment.transform 7 68 env40377 = env40378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env40377 == env40378) = true)

theorem identity40378 : scanCanonicalize (H12AffineFastState.compose env40378 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound40378 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env40379 : List Nat := [2,4,8,16,32,0,128,4,17,20,2048,16,25,0,1,4,39,133,20,0,17,152,39,5,144,55,43,54,0,2071,21,17,5,38,16,17]

theorem envBound40379 : H12AffineFastState.Bounded env40379 := by
  intro p hp
  have h : env40379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40378_40379 : H12AffineEnvironment.transform 5 0 env40378 = env40379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env40378 == env40379) = true)

theorem identity40379 : scanCanonicalize (H12AffineFastState.compose env40379 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound40379 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env40380 : List Nat := [2,4,8,16,32,0,8,4,17,20,2048,16,25,0,1,4,39,13,20,0,17,16,39,5,24,55,43,54,0,2071,21,17,5,38,16,17]

theorem envBound40380 : H12AffineFastState.Bounded env40380 := by
  intro p hp
  have h : env40380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40379_40380 : H12AffineEnvironment.transform 6 8 env40379 = env40380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env40379 == env40380) = true)

theorem identity40380 : scanCanonicalize (H12AffineFastState.compose env40380 (packedSelected [1,2,12] rootPS)) = affineNative (2^(10+1) ^^^ 61) := by decide +kernel

theorem selectedBound40380 : packedSelected [1,2,12] rootPS < 2^1333 := by decide +kernel

def env40381 : List Nat := [2,4,8,16,32,0,8,4,17,20,61,16,25,0,1,4,39,13,20,0,17,16,39,5,24,55,43,54,0,42,21,17,5,38,16,17]

theorem envBound40381 : H12AffineFastState.Bounded env40381 := by
  intro p hp
  have h : env40381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40380_40381 : H12AffineEnvironment.transform 10 61 env40380 = env40381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 61 env40380 == env40381) = true)

theorem identity40381 : scanCanonicalize (H12AffineFastState.compose env40381 (packedSelected [1,3,5] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound40381 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env40382 : List Nat := [2,4,8,7,32,0,8,4,6,3,42,7,14,0,1,4,39,13,3,0,6,7,39,5,15,32,43,33,0,42,2,6,5,38,7,6]

theorem envBound40382 : H12AffineFastState.Bounded env40382 := by
  intro p hp
  have h : env40382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40381_40382 : H12AffineEnvironment.transform 3 7 env40381 = env40382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env40381 == env40382) = true)

theorem identity40382 : scanCanonicalize (H12AffineFastState.compose env40382 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound40382 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40383 : List Nat := [2,2,8,1,32,0,8,2,0,3,42,1,8,0,1,2,33,11,3,0,0,1,33,3,9,32,43,33,0,42,2,0,3,32,1,0]

theorem envBound40383 : H12AffineFastState.Bounded env40383 := by
  intro p hp
  have h : env40383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40382_40383 : H12AffineEnvironment.transform 1 2 env40382 = env40383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env40382 == env40383) = true)

theorem identity40383 : scanCanonicalize (H12AffineFastState.compose env40383 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound40383 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40384 : List Nat := [2,2,2,1,32,0,2,2,0,3,32,1,2,0,1,2,33,1,3,0,0,1,33,3,3,32,33,33,0,32,2,0,3,32,1,0]

theorem envBound40384 : H12AffineFastState.Bounded env40384 := by
  intro p hp
  have h : env40384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40383_40384 : H12AffineEnvironment.transform 2 2 env40383 = env40384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env40383 == env40384) = true)

theorem identity40384 : scanCanonicalize (H12AffineFastState.compose env40384 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound40384 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40385 : List Nat := [2,2,2,1,1,0,2,2,0,3,1,1,2,0,1,2,0,1,3,0,0,1,0,3,3,1,0,0,0,1,2,0,3,1,1,0]

theorem envBound40385 : H12AffineFastState.Bounded env40385 := by
  intro p hp
  have h : env40385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40384_40385 : H12AffineEnvironment.transform 4 1 env40384 = env40385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env40384 == env40385) = true)

def env40386 : List Nat := [2,4,8,16,32,64,128,256,341,272,2048,17,8192,0,8477,65536,74110,65665,337,8476,16,476,74046,65536,8392,74031,302,74031,0,75851,8204,8200,257,74047,80,276]

theorem envBound40386 : H12AffineFastState.Bounded env40386 := by
  intro p hp
  have h : env40386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40369_40386 : H12AffineEnvironment.transform 11 17 env40369 = env40386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env40369 == env40386) = true)

theorem identity40386 : scanCanonicalize (H12AffineFastState.compose env40386 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 8220) := by decide +kernel

theorem selectedBound40386 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env40387 : List Nat := [2,4,8,16,32,64,128,256,341,272,2048,17,8192,0,8477,8220,354,8349,337,8476,16,476,290,8220,8392,307,302,307,0,2135,8204,8200,257,291,80,276]

theorem envBound40387 : H12AffineFastState.Bounded env40387 := by
  intro p hp
  have h : env40387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40386_40387 : H12AffineEnvironment.transform 15 8220 env40386 = env40387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8220 env40386 == env40387) = true)

def env40388 : List Nat := [2,4,4,16,32,64,128,256,341,272,2048,17,8192,0,8465,8208,354,8337,337,8464,16,464,290,8208,8388,307,290,307,0,2135,8192,8196,257,291,80,276]

theorem envBound40388 : H12AffineFastState.Bounded env40388 := by
  intro p hp
  have h : env40388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40387_40388 : H12AffineEnvironment.transform 2 4 env40387 = env40388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env40387 == env40388) = true)

theorem identity40388 : scanCanonicalize (H12AffineFastState.compose env40388 (packedSelected [1,2,4,9,10,11,15,17,20,21,23,24] rootPS)) = affineNative (2^(10+1) ^^^ 480) := by decide +kernel

theorem selectedBound40388 : packedSelected [1,2,4,9,10,11,15,17,20,21,23,24] rootPS < 2^1333 := by decide +kernel

def env40389 : List Nat := [2,4,4,16,32,64,128,256,341,272,480,17,8192,0,8465,8208,354,8337,337,8464,16,464,290,8208,8388,307,290,307,0,439,8192,8196,257,291,80,276]

theorem envBound40389 : H12AffineFastState.Bounded env40389 := by
  intro p hp
  have h : env40389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40388_40389 : H12AffineEnvironment.transform 10 480 env40388 = env40389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 480 env40388 == env40389) = true)

theorem identity40389 : scanCanonicalize (H12AffineFastState.compose env40389 (packedSelected [0,1,2,4,5,7,8,9,10,11,15,17,19,20,21] rootPS)) = affineNative (2^(12+1) ^^^ 387) := by decide +kernel

theorem selectedBound40389 : packedSelected [0,1,2,4,5,7,8,9,10,11,15,17,19,20,21] rootPS < 2^1333 := by decide +kernel

def env40390 : List Nat := [2,4,4,16,32,64,128,256,341,272,480,17,387,0,146,403,354,274,337,147,16,464,290,403,327,307,290,307,0,439,387,391,257,291,80,276]

theorem envBound40390 : H12AffineFastState.Bounded env40390 := by
  intro p hp
  have h : env40390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40389_40390 : H12AffineEnvironment.transform 12 387 env40389 = env40390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 387 env40389 == env40390) = true)

theorem identity40390 : scanCanonicalize (H12AffineFastState.compose env40390 (packedSelected [0,5,8,9,10,11,12,13,17,18] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound40390 : packedSelected [0,5,8,9,10,11,12,13,17,18] rootPS < 2^1333 := by decide +kernel

def env40391 : List Nat := [2,4,4,16,32,64,34,256,341,272,322,17,289,0,48,305,354,274,337,49,16,370,290,305,327,307,290,307,0,277,289,293,257,291,80,276]

theorem envBound40391 : H12AffineFastState.Bounded env40391 := by
  intro p hp
  have h : env40391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40390_40391 : H12AffineEnvironment.transform 6 34 env40390 = env40391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env40390 == env40391) = true)

theorem identity40391 : scanCanonicalize (H12AffineFastState.compose env40391 (packedSelected [0,1,3,5,8,9,10] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound40391 : packedSelected [0,1,3,5,8,9,10] rootPS < 2^1333 := by decide +kernel

def env40392 : List Nat := [2,4,4,16,17,64,19,256,341,272,322,17,272,0,1,256,339,274,337,0,16,323,275,256,327,258,275,258,0,277,272,276,257,274,80,276]

theorem envBound40392 : H12AffineFastState.Bounded env40392 := by
  intro p hp
  have h : env40392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40391_40392 : H12AffineEnvironment.transform 4 17 env40391 = env40392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env40391 == env40392) = true)

theorem identity40392 : scanCanonicalize (H12AffineFastState.compose env40392 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(7+1) ^^^ 82) := by decide +kernel

theorem selectedBound40392 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env40393 : List Nat := [2,4,4,16,17,64,19,82,7,66,16,17,66,0,1,82,1,64,3,0,16,17,65,82,21,80,65,80,0,71,66,70,83,64,80,70]

theorem envBound40393 : H12AffineFastState.Bounded env40393 := by
  intro p hp
  have h : env40393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40392_40393 : H12AffineEnvironment.transform 7 82 env40392 = env40393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 82 env40392 == env40393) = true)

theorem identity40393 : scanCanonicalize (H12AffineFastState.compose env40393 (packedSelected [2,5] rootPS)) = affineNative (2^(5+1) ^^^ 7) := by decide +kernel

theorem selectedBound40393 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env40394 : List Nat := [2,4,4,16,17,7,19,21,7,5,16,17,5,0,1,21,1,7,3,0,16,17,6,21,21,23,6,23,0,0,5,1,20,7,23,1]

theorem envBound40394 : H12AffineFastState.Bounded env40394 := by
  intro p hp
  have h : env40394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40393_40394 : H12AffineEnvironment.transform 5 7 env40393 = env40394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 7 env40393 == env40394) = true)

theorem identity40394 : scanCanonicalize (H12AffineFastState.compose env40394 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound40394 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40395 : List Nat := [2,4,4,0,1,7,3,5,7,5,0,1,5,0,1,5,1,7,3,0,0,1,6,5,5,7,6,7,0,0,5,1,4,7,7,1]

theorem envBound40395 : H12AffineFastState.Bounded env40395 := by
  intro p hp
  have h : env40395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40394_40395 : H12AffineEnvironment.transform 3 0 env40394 = env40395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env40394 == env40395) = true)

theorem identity40395 : scanCanonicalize (H12AffineFastState.compose env40395 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound40395 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40396 : List Nat := [2,2,2,0,1,1,3,3,1,3,0,1,3,0,1,3,1,1,3,0,0,1,0,3,3,1,0,1,0,0,3,1,2,1,1,1]

theorem envBound40396 : H12AffineFastState.Bounded env40396 := by
  intro p hp
  have h : env40396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40395_40396 : H12AffineEnvironment.transform 1 2 env40395 = env40396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env40395 == env40396) = true)

def env40397 : List Nat := [2,4,5,16,32,64,128,256,341,272,2048,17,8192,0,8464,8209,354,8336,337,8465,16,465,290,8209,8389,307,291,307,0,2135,8193,8197,257,291,80,276]

theorem envBound40397 : H12AffineFastState.Bounded env40397 := by
  intro p hp
  have h : env40397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40387_40397 : H12AffineEnvironment.transform 2 5 env40387 = env40397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env40387 == env40397) = true)

theorem identity40397 : scanCanonicalize (H12AffineFastState.compose env40397 (packedSelected [1,2,4,9,10,11,15,17,20,21,23,24] rootPS)) = affineNative (2^(12+1) ^^^ 2247) := by decide +kernel

theorem selectedBound40397 : packedSelected [1,2,4,9,10,11,15,17,20,21,23,24] rootPS < 2^1333 := by decide +kernel

def env40398 : List Nat := [2,4,5,16,32,64,128,256,341,272,2048,17,2247,0,2519,2262,354,2135,337,2518,16,465,290,2262,2050,307,291,307,0,2135,2246,2242,257,291,80,276]

theorem envBound40398 : H12AffineFastState.Bounded env40398 := by
  intro p hp
  have h : env40398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40397_40398 : H12AffineEnvironment.transform 12 2247 env40397 = env40398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2247 env40397 == env40398) = true)

theorem identity40398 : scanCanonicalize (H12AffineFastState.compose env40398 (packedSelected [4,7,9,10,17,19,20,21,23,27] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound40398 : packedSelected [4,7,9,10,17,19,20,21,23,27] rootPS < 2^1333 := by decide +kernel

def env40399 : List Nat := [2,4,5,1,32,64,128,256,324,257,2048,0,2247,0,2502,2247,354,2118,320,2503,1,448,290,2247,2050,290,291,290,0,2118,2246,2242,257,291,65,261]

theorem envBound40399 : H12AffineFastState.Bounded env40399 := by
  intro p hp
  have h : env40399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40398_40399 : H12AffineEnvironment.transform 3 1 env40398 = env40399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env40398 == env40399) = true)

theorem identity40399 : scanCanonicalize (H12AffineFastState.compose env40399 (packedSelected [0,3,8,9,10,11,16,17] rootPS)) = affineNative (2^(10+1) ^^^ 162) := by decide +kernel

theorem selectedBound40399 : packedSelected [0,3,8,9,10,11,16,17] rootPS < 2^1333 := by decide +kernel

def env40400 : List Nat := [2,4,5,1,32,64,128,256,324,257,162,0,101,0,356,101,354,228,320,357,1,448,290,101,160,290,291,290,0,228,100,96,257,291,65,261]

theorem envBound40400 : H12AffineFastState.Bounded env40400 := by
  intro p hp
  have h : env40400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40399_40400 : H12AffineEnvironment.transform 10 162 env40399 = env40400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 162 env40399 == env40400) = true)

theorem identity40400 : scanCanonicalize (H12AffineFastState.compose env40400 (packedSelected [0,3,4,5,7,9,12] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound40400 : packedSelected [0,3,4,5,7,9,12] rootPS < 2^1333 := by decide +kernel

def env40401 : List Nat := [2,4,5,1,32,64,128,37,97,36,162,0,101,0,65,101,71,228,101,64,1,229,7,101,160,7,6,7,0,228,100,96,36,6,65,32]

theorem envBound40401 : H12AffineFastState.Bounded env40401 := by
  intro p hp
  have h : env40401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40400_40401 : H12AffineEnvironment.transform 7 37 env40400 = env40401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env40400 == env40401) = true)

theorem identity40401 : scanCanonicalize (H12AffineFastState.compose env40401 (packedSelected [3,4,5,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 99) := by decide +kernel

theorem selectedBound40401 : packedSelected [3,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env40402 : List Nat := [2,4,5,1,32,64,99,37,97,36,65,0,101,0,65,101,71,7,101,64,1,6,7,101,67,7,6,7,0,7,100,96,36,6,65,32]

theorem envBound40402 : H12AffineFastState.Bounded env40402 := by
  intro p hp
  have h : env40402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40401_40402 : H12AffineEnvironment.transform 6 99 env40401 = env40402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 99 env40401 == env40402) = true)

theorem identity40402 : scanCanonicalize (H12AffineFastState.compose env40402 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound40402 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40403 : List Nat := [2,4,5,1,32,32,3,37,1,36,33,0,5,0,33,5,39,7,5,32,1,6,7,5,35,7,6,7,0,7,4,0,36,6,33,32]

theorem envBound40403 : H12AffineFastState.Bounded env40403 := by
  intro p hp
  have h : env40403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40402_40403 : H12AffineEnvironment.transform 5 32 env40402 = env40403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env40402 == env40403) = true)

theorem identity40403 : scanCanonicalize (H12AffineFastState.compose env40403 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound40403 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40404 : List Nat := [2,2,3,1,32,32,3,35,1,34,33,0,3,0,33,3,33,1,3,32,1,0,1,3,35,1,0,1,0,1,2,0,34,0,33,32]

theorem envBound40404 : H12AffineFastState.Bounded env40404 := by
  intro p hp
  have h : env40404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40403_40404 : H12AffineEnvironment.transform 1 2 env40403 = env40404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env40403 == env40404) = true)

theorem identity40404 : scanCanonicalize (H12AffineFastState.compose env40404 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound40404 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env40405 : List Nat := [2,2,3,1,1,1,3,2,1,3,0,0,3,0,0,3,0,1,3,1,1,0,1,3,2,1,0,1,0,1,2,0,3,0,0,1]

theorem envBound40405 : H12AffineFastState.Bounded env40405 := by
  intro p hp
  have h : env40405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40404_40405 : H12AffineEnvironment.transform 4 1 env40404 = env40405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env40404 == env40405) = true)

def env40406 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74862,262144,4417,13341,4097,477,74047,69648,13768,78894,332223,74814,1296,81227,8205,8201,257,74799,1344,5953]

theorem envBound40406 : H12AffineFastState.Bounded env40406 := by
  intro p hp
  have h : env40406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40303_40406 : H12AffineEnvironment.transform 13 1297 env40303 = env40406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env40303 == env40406) = true)

def env40407 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74862,65664,4417,13341,4097,477,74047,69648,13768,78894,4415,74814,1296,81227,8205,8201,257,74799,1344,5953]

theorem envBound40407 : H12AffineFastState.Bounded env40407 := by
  intro p hp
  have h : env40407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40406_40407 : H12AffineEnvironment.transform 17 65664 env40406 = env40407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env40406 == env40407) = true)

theorem identity40407 : scanCanonicalize (H12AffineFastState.compose env40407 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound40407 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env40408 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,25,1297,5125,65536,66679,65664,4417,5124,4097,477,65830,69648,5585,70711,4415,66599,1296,73042,20,16,257,66614,1344,5953]

theorem envBound40408 : H12AffineFastState.Bounded env40408 := by
  intro p hp
  have h : env40408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40407_40408 : H12AffineEnvironment.transform 12 25 env40407 = env40408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env40407 == env40408) = true)

def env40409 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,25,1297,5125,1052,107,1180,4417,5124,4097,477,1338,5132,5585,4139,4415,59,1296,6478,20,16,257,42,1344,5953]

theorem envBound40409 : H12AffineFastState.Bounded env40409 := by
  intro p hp
  have h : env40409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40408_40409 : H12AffineEnvironment.transform 15 1052 env40408 = env40409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1052 env40408 == env40409) = true)

theorem identity40409 : scanCanonicalize (H12AffineFastState.compose env40409 (packedSelected [0,1,2,4,7,9,10,11,15,17,19,21,23,24,28] rootPS)) = affineNative (2^(10+1) ^^^ 1641) := by decide +kernel

theorem selectedBound40409 : packedSelected [0,1,2,4,7,9,10,11,15,17,19,21,23,24,28] rootPS < 2^1333 := by decide +kernel

def env40410 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1641,4096,25,1297,5125,1052,107,1180,4417,5124,4097,477,1338,5132,5585,4139,4415,59,1296,5927,20,16,257,42,1344,5953]

theorem envBound40410 : H12AffineFastState.Bounded env40410 := by
  intro p hp
  have h : env40410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40409_40410 : H12AffineEnvironment.transform 10 1641 env40409 = env40410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1641 env40409 == env40410) = true)

def env40411 : List Nat := [2,4,8,16,32,64,128,256,340,1024,1341,4096,25,1297,5125,1052,107,1180,4417,5124,4097,477,1338,5132,5585,4139,4415,59,1296,5235,20,16,257,42,1344,5141]

theorem envBound40411 : H12AffineFastState.Bounded env40411 := by
  intro p hp
  have h : env40411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40410_40411 : H12AffineEnvironment.transform 8 340 env40410 = env40411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env40410 == env40411) = true)

def env40412 : List Nat := [2,4,8,16,32,64,128,256,340,1024,1341,1280,25,1297,261,1052,107,1180,1089,260,1281,477,1338,268,209,1323,1087,59,1296,371,20,16,257,42,1344,277]

theorem envBound40412 : H12AffineFastState.Bounded env40412 := by
  intro p hp
  have h : env40412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40411_40412 : H12AffineEnvironment.transform 11 1280 env40411 = env40412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env40411 == env40412) = true)

theorem identity40412 : scanCanonicalize (H12AffineFastState.compose env40412 (packedSelected [0,2,4,7,8,9,10,11,15,17,19,21,23,24] rootPS)) = affineNative (2^(9+1) ^^^ 510) := by decide +kernel

theorem selectedBound40412 : packedSelected [0,2,4,7,8,9,10,11,15,17,19,21,23,24] rootPS < 2^1333 := by decide +kernel

def env40413 : List Nat := [2,4,8,16,32,64,128,256,340,510,195,254,25,239,261,482,107,354,447,260,255,477,196,268,209,213,449,59,238,371,20,16,257,42,190,277]

theorem envBound40413 : H12AffineFastState.Bounded env40413 := by
  intro p hp
  have h : env40413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40412_40413 : H12AffineEnvironment.transform 9 510 env40412 = env40413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 510 env40412 == env40413) = true)

theorem identity40413 : scanCanonicalize (H12AffineFastState.compose env40413 (packedSelected [1,2,3,4,9,10,11,12,13,15,16,17,18,21] rootPS)) = affineNative (2^(7+1) ^^^ 141) := by decide +kernel

theorem selectedBound40413 : packedSelected [1,2,3,4,9,10,11,12,13,15,16,17,18,21] rootPS < 2^1333 := by decide +kernel

def env40414 : List Nat := [2,4,8,16,32,64,128,141,217,115,195,254,25,239,136,111,107,239,50,137,255,80,196,129,209,213,76,59,238,254,20,16,140,42,190,152]

theorem envBound40414 : H12AffineFastState.Bounded env40414 := by
  intro p hp
  have h : env40414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40413_40414 : H12AffineEnvironment.transform 7 141 env40413 = env40414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 141 env40413 == env40414) = true)

theorem identity40414 : scanCanonicalize (H12AffineFastState.compose env40414 (packedSelected [0,1,3,9,10,12,13,15,16,18] rootPS)) = affineNative (2^(6+1) ^^^ 72) := by decide +kernel

theorem selectedBound40414 : packedSelected [0,1,3,9,10,12,13,15,16,18] rootPS < 2^1333 := by decide +kernel

def env40415 : List Nat := [2,4,8,16,32,64,72,69,17,115,11,54,25,39,64,111,107,39,50,65,55,80,12,73,25,29,76,59,38,54,20,16,68,42,118,80]

theorem envBound40415 : H12AffineFastState.Bounded env40415 := by
  intro p hp
  have h : env40415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40414_40415 : H12AffineEnvironment.transform 6 72 env40414 = env40415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 72 env40414 == env40415) = true)

theorem identity40415 : scanCanonicalize (H12AffineFastState.compose env40415 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 39) := by decide +kernel

theorem selectedBound40415 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env40416 : List Nat := [2,4,8,16,32,39,47,34,17,20,11,54,25,39,39,8,12,39,50,38,55,55,12,46,25,29,43,59,38,54,20,16,35,42,17,55]

theorem envBound40416 : H12AffineFastState.Bounded env40416 := by
  intro p hp
  have h : env40416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40415_40416 : H12AffineEnvironment.transform 5 39 env40415 = env40416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 39 env40415 == env40416) = true)

theorem identity40416 : scanCanonicalize (H12AffineFastState.compose env40416 (packedSelected [0,1,2,3,7] rootPS)) = affineNative (2^(4+1) ^^^ 28) := by decide +kernel

theorem selectedBound40416 : packedSelected [0,1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env40417 : List Nat := [2,4,8,16,28,27,19,30,17,20,11,10,25,27,27,8,12,27,14,26,11,11,12,18,25,29,23,7,26,10,20,16,31,22,17,11]

theorem envBound40417 : H12AffineFastState.Bounded env40417 := by
  intro p hp
  have h : env40417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40416_40417 : H12AffineEnvironment.transform 4 28 env40416 = env40417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 28 env40416 == env40417) = true)

theorem identity40417 : scanCanonicalize (H12AffineFastState.compose env40417 (packedSelected [1,5] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound40417 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env40418 : List Nat := [2,4,4,16,16,23,19,18,17,20,7,6,21,23,23,4,0,23,2,22,7,7,0,18,21,17,23,7,22,6,20,16,19,22,17,7]

theorem envBound40418 : H12AffineFastState.Bounded env40418 := by
  intro p hp
  have h : env40418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40417_40418 : H12AffineEnvironment.transform 2 4 env40417 = env40418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env40417 == env40418) = true)

theorem identity40418 : scanCanonicalize (H12AffineFastState.compose env40418 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound40418 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40419 : List Nat := [2,3,3,16,16,16,19,18,17,19,0,1,18,16,16,3,0,16,2,17,0,0,0,18,18,17,16,0,17,1,19,16,19,17,17,0]

theorem envBound40419 : H12AffineFastState.Bounded env40419 := by
  intro p hp
  have h : env40419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40418_40419 : H12AffineEnvironment.transform 1 3 env40418 = env40419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env40418 == env40419) = true)

theorem identity40419 : scanCanonicalize (H12AffineFastState.compose env40419 (packedSelected [8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound40419 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env40420 : List Nat := [2,3,3,0,0,0,3,2,1,3,0,1,2,0,0,3,0,0,2,1,0,0,0,2,2,1,0,0,1,1,3,0,3,1,1,0]

theorem envBound40420 : H12AffineFastState.Bounded env40420 := by
  intro p hp
  have h : env40420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40419_40420 : H12AffineEnvironment.transform 3 0 env40419 = env40420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env40419 == env40420) = true)

theorem identity40420 : scanCanonicalize (H12AffineFastState.compose env40420 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound40420 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40421 : List Nat := [1,0,0,0,0,0,0,1,1,0,0,1,1,0,0,0,0,0,1,1,0,0,0,1,1,1,0,0,1,1,0,0,0,1,1,0]

theorem envBound40421 : H12AffineFastState.Bounded env40421 := by
  intro p hp
  have h : env40421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40420_40421 : H12AffineEnvironment.transform 0 1 env40420 = env40421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env40420 == env40421) = true)

def env40422 : List Nat := [2,4,8,16,32,64,128,256,340,1024,1341,1281,25,1297,260,1052,107,1180,1088,261,1280,477,1338,269,208,1322,1086,59,1296,370,20,16,257,42,1344,276]

theorem envBound40422 : H12AffineFastState.Bounded env40422 := by
  intro p hp
  have h : env40422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40411_40422 : H12AffineEnvironment.transform 11 1281 env40411 = env40422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1281 env40411 == env40422) = true)

theorem identity40422 : scanCanonicalize (H12AffineFastState.compose env40422 (packedSelected [0,2,4,7,8,9,10,11,15,17,19,21,23,24] rootPS)) = affineNative (2^(6+1) ^^^ 110) := by decide +kernel

theorem selectedBound40422 : packedSelected [0,2,4,7,8,9,10,11,15,17,19,21,23,24] rootPS < 2^1333 := by decide +kernel

def env40423 : List Nat := [2,4,8,16,32,64,110,256,340,1024,1341,1281,25,1297,260,1052,107,1138,1088,261,1280,307,1338,269,62,1322,1086,59,1296,370,20,16,257,42,1344,276]

theorem envBound40423 : H12AffineFastState.Bounded env40423 := by
  intro p hp
  have h : env40423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40422_40423 : H12AffineEnvironment.transform 6 110 env40422 = env40423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 110 env40422 == env40423) = true)

theorem identity40423 : scanCanonicalize (H12AffineFastState.compose env40423 (packedSelected [0,2,3,4,10,11,12,15,16,17,23] rootPS)) = affineNative (2^(9+1) ^^^ 267) := by decide +kernel

theorem selectedBound40423 : packedSelected [0,2,3,4,10,11,12,15,16,17,23] rootPS < 2^1333 := by decide +kernel

def env40424 : List Nat := [2,4,8,16,32,64,110,256,340,267,54,10,25,26,260,279,107,377,331,261,11,307,49,269,62,33,309,59,27,370,20,16,257,42,75,276]

theorem envBound40424 : H12AffineFastState.Bounded env40424 := by
  intro p hp
  have h : env40424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40423_40424 : H12AffineEnvironment.transform 9 267 env40423 = env40424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 267 env40423 == env40424) = true)

theorem identity40424 : scanCanonicalize (H12AffineFastState.compose env40424 (packedSelected [1,2,4,8,9,11,12,13,16,17,18] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound40424 : packedSelected [1,2,4,8,9,11,12,13,16,17,18] rootPS < 2^1333 := by decide +kernel

def env40425 : List Nat := [2,4,8,16,0,64,78,256,340,267,22,10,25,26,260,279,75,345,331,261,11,275,17,269,30,1,277,27,27,338,20,16,257,10,75,276]

theorem envBound40425 : H12AffineFastState.Bounded env40425 := by
  intro p hp
  have h : env40425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40424_40425 : H12AffineEnvironment.transform 4 0 env40424 = env40425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env40424 == env40425) = true)

theorem identity40425 : scanCanonicalize (H12AffineFastState.compose env40425 (packedSelected [1,2,3,8,11] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound40425 : packedSelected [1,2,3,8,11] rootPS < 2^1333 := by decide +kernel

def env40426 : List Nat := [2,4,8,16,0,64,78,4,80,15,22,10,25,26,0,19,75,93,79,1,11,23,17,9,30,1,17,27,27,86,20,16,5,10,75,16]

theorem envBound40426 : H12AffineFastState.Bounded env40426 := by
  intro p hp
  have h : env40426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40425_40426 : H12AffineEnvironment.transform 7 4 env40425 = env40426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env40425 == env40426) = true)

theorem identity40426 : scanCanonicalize (H12AffineFastState.compose env40426 (packedSelected [0,2,4,8] rootPS)) = affineNative (2^(5+1) ^^^ 22) := by decide +kernel

theorem selectedBound40426 : packedSelected [0,2,4,8] rootPS < 2^1333 := by decide +kernel

def env40427 : List Nat := [2,4,8,16,0,22,24,4,6,15,22,10,25,26,0,19,29,11,25,1,11,23,17,9,30,1,17,27,27,0,20,16,5,10,29,16]

theorem envBound40427 : H12AffineFastState.Bounded env40427 := by
  intro p hp
  have h : env40427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40426_40427 : H12AffineEnvironment.transform 5 22 env40426 = env40427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 22 env40426 == env40427) = true)

theorem identity40427 : scanCanonicalize (H12AffineFastState.compose env40427 (packedSelected [2,3] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound40427 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env40428 : List Nat := [2,4,8,13,0,11,5,4,6,15,11,10,4,7,0,14,0,11,4,1,11,10,12,9,3,1,12,6,6,0,9,13,5,10,0,13]

theorem envBound40428 : H12AffineFastState.Bounded env40428 := by
  intro p hp
  have h : env40428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40427_40428 : H12AffineEnvironment.transform 3 13 env40427 = env40428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env40427 == env40428) = true)

def env40429 : List Nat := [2,4,8,16,32,64,128,256,341,1024,1340,4096,25,1297,5125,1052,107,1180,4417,5124,4097,477,1338,5132,5585,4139,4415,59,1296,5234,20,16,257,42,1344,5140]

theorem envBound40429 : H12AffineFastState.Bounded env40429 := by
  intro p hp
  have h : env40429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40410_40429 : H12AffineEnvironment.transform 8 341 env40410 = env40429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env40410 == env40429) = true)

def env40430 : List Nat := [2,4,8,16,32,64,128,256,341,1024,1340,1280,25,1297,261,1052,107,1180,1089,260,1281,477,1338,268,209,1323,1087,59,1296,370,20,16,257,42,1344,276]

theorem envBound40430 : H12AffineFastState.Bounded env40430 := by
  intro p hp
  have h : env40430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40429_40430 : H12AffineEnvironment.transform 11 1280 env40429 = env40430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env40429 == env40430) = true)

theorem identity40430 : scanCanonicalize (H12AffineFastState.compose env40430 (packedSelected [0,2,4,7,8,9,10,11,15,17,19,21,23,24] rootPS)) = affineNative (2^(6+1) ^^^ 84) := by decide +kernel

theorem selectedBound40430 : packedSelected [0,2,4,7,8,9,10,11,15,17,19,21,23,24] rootPS < 2^1333 := by decide +kernel

def env40431 : List Nat := [2,4,8,16,32,64,84,256,341,1024,1340,1280,25,1297,261,1052,107,1096,1089,260,1281,265,1338,268,5,1323,1087,59,1296,370,20,16,257,42,1344,276]

theorem envBound40431 : H12AffineFastState.Bounded env40431 := by
  intro p hp
  have h : env40431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40430_40431 : H12AffineEnvironment.transform 6 84 env40430 = env40431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 84 env40430 == env40431) = true)

theorem identity40431 : scanCanonicalize (H12AffineFastState.compose env40431 (packedSelected [1,2,3,4,9,10,11,12,13,15,16,17,18,21] rootPS)) = affineNative (2^(7+1) ^^^ 25) := by decide +kernel

theorem selectedBound40431 : packedSelected [1,2,3,4,9,10,11,12,13,15,16,17,18,21] rootPS < 2^1333 := by decide +kernel

def env40432 : List Nat := [2,4,8,16,32,64,84,25,76,1024,1061,1049,25,1032,28,1052,107,1096,1089,29,1048,16,1059,21,5,1074,1087,59,1033,107,20,16,24,42,1113,13]

theorem envBound40432 : H12AffineFastState.Bounded env40432 := by
  intro p hp
  have h : env40432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40431_40432 : H12AffineEnvironment.transform 7 25 env40431 = env40432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 25 env40431 == env40432) = true)

theorem identity40432 : scanCanonicalize (H12AffineFastState.compose env40432 (packedSelected [2,3,4,7,11,12,16,18] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound40432 : packedSelected [2,3,4,7,11,12,16,18] rootPS < 2^1333 := by decide +kernel

def env40433 : List Nat := [2,4,8,16,32,48,36,25,60,1024,1061,1049,25,1032,28,1052,27,1080,1073,29,1048,16,1059,21,5,1074,1087,59,1033,27,20,16,24,42,1065,13]

theorem envBound40433 : H12AffineFastState.Bounded env40433 := by
  intro p hp
  have h : env40433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40432_40433 : H12AffineEnvironment.transform 5 48 env40432 = env40433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env40432 == env40433) = true)

theorem identity40433 : scanCanonicalize (H12AffineFastState.compose env40433 (packedSelected [4,5,7,8,10] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound40433 : packedSelected [4,5,7,8,10] rootPS < 2^1333 := by decide +kernel

def env40434 : List Nat := [2,3,8,16,32,48,35,25,59,1024,1058,1049,25,1032,27,1051,27,1080,1073,26,1048,16,1059,18,2,1074,1080,59,1033,27,19,16,24,42,1065,10]

theorem envBound40434 : H12AffineFastState.Bounded env40434 := by
  intro p hp
  have h : env40434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40433_40434 : H12AffineEnvironment.transform 1 3 env40433 = env40434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env40433 == env40434) = true)

theorem identity40434 : scanCanonicalize (H12AffineFastState.compose env40434 (packedSelected [1,3,4,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound40434 : packedSelected [1,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env40435 : List Nat := [2,3,8,16,17,1,18,25,10,1024,1043,1049,25,1032,27,1051,27,1033,1024,26,1048,16,1042,18,2,1027,1033,10,1033,27,19,16,24,27,1048,10]

theorem envBound40435 : H12AffineFastState.Bounded env40435 := by
  intro p hp
  have h : env40435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40434_40435 : H12AffineEnvironment.transform 4 17 env40434 = env40435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env40434 == env40435) = true)

theorem identity40435 : scanCanonicalize (H12AffineFastState.compose env40435 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 9) := by decide +kernel

theorem selectedBound40435 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40436 : List Nat := [2,3,8,16,17,1,18,25,10,9,26,16,25,1,27,18,27,0,9,26,17,16,27,18,2,10,0,10,0,27,19,16,24,27,17,10]

theorem envBound40436 : H12AffineFastState.Bounded env40436 := by
  intro p hp
  have h : env40436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40435_40436 : H12AffineEnvironment.transform 9 9 env40435 = env40436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 9 env40435 == env40436) = true)

theorem identity40436 : scanCanonicalize (H12AffineFastState.compose env40436 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound40436 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env40437 : List Nat := [2,3,8,1,0,1,3,8,10,9,11,1,8,1,10,3,10,0,9,11,0,1,10,3,2,10,0,10,0,10,2,1,9,10,0,10]

theorem envBound40437 : H12AffineFastState.Bounded env40437 := by
  intro p hp
  have h : env40437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40436_40437 : H12AffineEnvironment.transform 3 1 env40436 = env40437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env40436 == env40437) = true)

def env40438 : List Nat := [2,4,8,16,32,64,128,256,341,1024,1340,1281,25,1297,260,1052,107,1180,1088,261,1280,477,1338,269,208,1322,1086,59,1296,371,20,16,257,42,1344,277]

theorem envBound40438 : H12AffineFastState.Bounded env40438 := by
  intro p hp
  have h : env40438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40429_40438 : H12AffineEnvironment.transform 11 1281 env40429 = env40438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1281 env40429 == env40438) = true)

theorem identity40438 : scanCanonicalize (H12AffineFastState.compose env40438 (packedSelected [0,2,4,7,8,9,10,11,15,17,19,21,23,24] rootPS)) = affineNative (2^(9+1) ^^^ 452) := by decide +kernel

theorem selectedBound40438 : packedSelected [0,2,4,7,8,9,10,11,15,17,19,21,23,24] rootPS < 2^1333 := by decide +kernel

def env40439 : List Nat := [2,4,8,16,32,64,128,256,341,452,248,197,25,213,260,472,107,344,388,261,196,477,254,269,208,238,506,59,212,371,20,16,257,42,132,277]

theorem envBound40439 : H12AffineFastState.Bounded env40439 := by
  intro p hp
  have h : env40439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40438_40439 : H12AffineEnvironment.transform 9 452 env40438 = env40439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 452 env40438 == env40439) = true)

theorem identity40439 : scanCanonicalize (H12AffineFastState.compose env40439 (packedSelected [1,4,7,13,18,19,20] rootPS)) = affineNative (2^(7+1) ^^^ 88) := by decide +kernel

theorem selectedBound40439 : packedSelected [1,4,7,13,18,19,20] rootPS < 2^1333 := by decide +kernel

def env40440 : List Nat := [2,4,8,16,32,64,128,88,13,156,248,197,25,213,92,128,107,0,220,93,196,133,254,85,208,238,162,59,212,43,20,16,89,42,132,77]

theorem envBound40440 : H12AffineFastState.Bounded env40440 := by
  intro p hp
  have h : env40440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40439_40440 : H12AffineEnvironment.transform 7 88 env40439 = env40440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 88 env40439 == env40440) = true)

theorem identity40440 : scanCanonicalize (H12AffineFastState.compose env40440 (packedSelected [0,1,4,5,7,9,12,13,17,18] rootPS)) = affineNative (2^(5+1) ^^^ 27) := by decide +kernel

theorem selectedBound40440 : packedSelected [0,1,4,5,7,9,12,13,17,18] rootPS < 2^1333 := by decide +kernel

def env40441 : List Nat := [2,4,8,16,32,27,128,3,13,156,163,158,25,142,7,128,48,0,135,6,159,133,165,14,139,181,162,59,143,43,20,16,2,42,132,22]

theorem envBound40441 : H12AffineFastState.Bounded env40441 := by
  intro p hp
  have h : env40441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40440_40441 : H12AffineEnvironment.transform 5 27 env40440 = env40441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 27 env40440 == env40441) = true)

theorem identity40441 : scanCanonicalize (H12AffineFastState.compose env40441 (packedSelected [1,2,4,5,7,10,11] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound40441 : packedSelected [1,2,4,5,7,10,11] rootPS < 2^1333 := by decide +kernel

def env40442 : List Nat := [2,4,8,6,32,13,128,3,13,138,163,136,15,142,7,128,38,0,135,6,137,133,165,14,139,163,162,45,143,43,2,6,2,42,132,0]

theorem envBound40442 : H12AffineFastState.Bounded env40442 := by
  intro p hp
  have h : env40442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40441_40442 : H12AffineEnvironment.transform 3 6 env40441 = env40442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env40441 == env40442) = true)

theorem identity40442 : scanCanonicalize (H12AffineFastState.compose env40442 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound40442 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40443 : List Nat := [2,4,8,6,10,13,128,3,13,138,137,136,15,142,7,128,12,0,135,6,137,133,143,14,139,137,136,7,143,1,2,6,2,0,132,0]

theorem envBound40443 : H12AffineFastState.Bounded env40443 := by
  intro p hp
  have h : env40443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40442_40443 : H12AffineEnvironment.transform 4 10 env40442 = env40443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env40442 == env40443) = true)

theorem identity40443 : scanCanonicalize (H12AffineFastState.compose env40443 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 14) := by decide +kernel

theorem selectedBound40443 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env40444 : List Nat := [2,4,8,6,10,13,14,3,13,4,7,6,15,0,7,14,12,0,9,6,7,11,1,14,5,7,6,7,1,1,2,6,2,0,10,0]

theorem envBound40444 : H12AffineFastState.Bounded env40444 := by
  intro p hp
  have h : env40444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40443_40444 : H12AffineEnvironment.transform 6 14 env40443 = env40444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 14 env40443 == env40444) = true)

theorem identity40444 : scanCanonicalize (H12AffineFastState.compose env40444 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound40444 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env40445 : List Nat := [2,2,8,0,10,11,8,3,11,2,1,0,9,0,1,8,10,0,9,0,1,11,1,8,3,1,0,1,1,1,2,0,2,0,10,0]

theorem envBound40445 : H12AffineFastState.Bounded env40445 := by
  intro p hp
  have h : env40445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40444_40445 : H12AffineEnvironment.transform 1 2 env40444 = env40445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env40444 == env40445) = true)

theorem identity40445 : scanCanonicalize (H12AffineFastState.compose env40445 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound40445 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40446 : List Nat := [2,2,3,0,1,0,3,3,0,2,1,0,2,0,1,3,1,0,2,0,1,0,1,3,3,1,0,1,1,1,2,0,2,0,1,0]

theorem envBound40446 : H12AffineFastState.Bounded env40446 := by
  intro p hp
  have h : env40446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40445_40446 : H12AffineEnvironment.transform 2 3 env40445 = env40446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env40445 == env40446) = true)

def env40447 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,25,1297,5125,1053,106,1181,4417,5124,4097,477,1339,5133,5585,4138,4415,58,1296,6479,20,16,257,43,1344,5953]

theorem envBound40447 : H12AffineFastState.Bounded env40447 := by
  intro p hp
  have h : env40447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40408_40447 : H12AffineEnvironment.transform 15 1053 env40408 = env40447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1053 env40408 == env40447) = true)

theorem identity40447 : scanCanonicalize (H12AffineFastState.compose env40447 (packedSelected [0,1,2,4,7,9,10,11,15,17,19,21,23,24,28] rootPS)) = affineNative (2^(10+1) ^^^ 1619) := by decide +kernel

theorem selectedBound40447 : packedSelected [0,1,2,4,7,9,10,11,15,17,19,21,23,24,28] rootPS < 2^1333 := by decide +kernel

def env40448 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1619,4096,25,1297,5125,1053,106,1181,4417,5124,4097,477,1339,5133,5585,4138,4415,58,1296,5916,20,16,257,43,1344,5953]

theorem envBound40448 : H12AffineFastState.Bounded env40448 := by
  intro p hp
  have h : env40448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40447_40448 : H12AffineEnvironment.transform 10 1619 env40447 = env40448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1619 env40447 == env40448) = true)

def env40449 : List Nat := [2,4,8,16,32,64,128,256,340,1024,1287,4096,25,1297,5125,1053,106,1181,4417,5124,4097,477,1339,5133,5585,4138,4415,58,1296,5192,20,16,257,43,1344,5141]

theorem envBound40449 : H12AffineFastState.Bounded env40449 := by
  intro p hp
  have h : env40449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40448_40449 : H12AffineEnvironment.transform 8 340 env40448 = env40449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env40448 == env40449) = true)

def env40450 : List Nat := [2,4,8,16,32,64,128,256,340,1024,1287,1280,25,1297,261,1053,106,1181,1089,260,1281,477,1339,269,209,1322,1087,58,1296,328,20,16,257,43,1344,277]

theorem envBound40450 : H12AffineFastState.Bounded env40450 := by
  intro p hp
  have h : env40450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40449_40450 : H12AffineEnvironment.transform 11 1280 env40449 = env40450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env40449 == env40450) = true)

theorem identity40450 : scanCanonicalize (H12AffineFastState.compose env40450 (packedSelected [0,2,4,7,8,9,10,11,15,17,19,21,23,24] rootPS)) = affineNative (2^(9+1) ^^^ 510) := by decide +kernel

theorem selectedBound40450 : packedSelected [0,2,4,7,8,9,10,11,15,17,19,21,23,24] rootPS < 2^1333 := by decide +kernel

def env40451 : List Nat := [2,4,8,16,32,64,128,256,340,510,249,254,25,239,261,483,106,355,447,260,255,477,197,269,209,212,449,58,238,328,20,16,257,43,190,277]

theorem envBound40451 : H12AffineFastState.Bounded env40451 := by
  intro p hp
  have h : env40451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40450_40451 : H12AffineEnvironment.transform 9 510 env40450 = env40451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 510 env40450 == env40451) = true)

theorem identity40451 : scanCanonicalize (H12AffineFastState.compose env40451 (packedSelected [1,4,7,13,18,19,20] rootPS)) = affineNative (2^(7+1) ^^^ 99) := by decide +kernel

theorem selectedBound40451 : packedSelected [1,4,7,13,18,19,20] rootPS < 2^1333 := by decide +kernel

def env40452 : List Nat := [2,4,8,16,32,64,128,99,55,157,249,254,25,239,102,128,106,0,220,103,255,190,197,110,209,212,162,58,238,43,20,16,98,43,190,118]

theorem envBound40452 : H12AffineFastState.Bounded env40452 := by
  intro p hp
  have h : env40452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40451_40452 : H12AffineEnvironment.transform 7 99 env40451 = env40452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 99 env40451 == env40452) = true)

theorem identity40452 : scanCanonicalize (H12AffineFastState.compose env40452 (packedSelected [0,1,4,5,7,9,12,13,17,18] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound40452 : packedSelected [0,1,4,5,7,9,12,13,17,18] rootPS < 2^1333 := by decide +kernel

def env40453 : List Nat := [2,4,8,11,32,64,128,99,44,134,226,229,2,239,102,128,106,0,199,103,228,165,197,110,202,207,162,33,238,43,15,11,98,43,165,109]

theorem envBound40453 : H12AffineFastState.Bounded env40453 := by
  intro p hp
  have h : env40453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40452_40453 : H12AffineEnvironment.transform 3 11 env40452 = env40453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env40452 == env40453) = true)

theorem identity40453 : scanCanonicalize (H12AffineFastState.compose env40453 (packedSelected [1,3,4,7,8,10] rootPS)) = affineNative (2^(6+1) ^^^ 99) := by decide +kernel

theorem selectedBound40453 : packedSelected [1,3,4,7,8,10] rootPS < 2^1333 := by decide +kernel

def env40454 : List Nat := [2,4,8,11,32,64,99,99,44,101,1,6,2,12,102,99,106,0,36,103,7,70,38,110,41,44,65,33,13,43,15,11,98,43,70,109]

theorem envBound40454 : H12AffineFastState.Bounded env40454 := by
  intro p hp
  have h : env40454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40453_40454 : H12AffineEnvironment.transform 6 99 env40453 = env40454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 99 env40453 == env40454) = true)

theorem identity40454 : scanCanonicalize (H12AffineFastState.compose env40454 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 6) := by decide +kernel

theorem selectedBound40454 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env40455 : List Nat := [2,4,8,11,32,6,37,37,44,35,1,6,2,12,32,37,44,0,36,33,7,0,38,40,41,44,7,33,13,43,15,11,36,43,0,43]

theorem envBound40455 : H12AffineFastState.Bounded env40455 := by
  intro p hp
  have h : env40455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40454_40455 : H12AffineEnvironment.transform 5 6 env40454 = env40455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 6 env40454 == env40455) = true)

theorem identity40455 : scanCanonicalize (H12AffineFastState.compose env40455 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound40455 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env40456 : List Nat := [2,4,3,0,32,6,37,37,39,35,1,6,2,7,32,37,39,0,36,33,7,0,38,35,34,39,7,33,6,32,4,0,36,32,0,32]

theorem envBound40456 : H12AffineFastState.Bounded env40456 := by
  intro p hp
  have h : env40456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40455_40456 : H12AffineEnvironment.transform 2 3 env40455 = env40456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env40455 == env40456) = true)

theorem identity40456 : scanCanonicalize (H12AffineFastState.compose env40456 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound40456 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40457 : List Nat := [2,4,3,0,6,6,3,3,1,5,1,6,2,7,6,3,1,0,2,7,7,0,0,5,4,1,7,7,6,6,4,0,2,6,0,6]

theorem envBound40457 : H12AffineFastState.Bounded env40457 := by
  intro p hp
  have h : env40457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40456_40457 : H12AffineEnvironment.transform 4 6 env40456 = env40457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env40456 == env40457) = true)

theorem identity40457 : scanCanonicalize (H12AffineFastState.compose env40457 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound40457 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40458 : List Nat := [2,3,3,0,1,1,3,3,1,2,1,1,2,0,1,3,1,0,2,0,0,0,0,2,3,1,0,0,1,1,3,0,2,1,0,1]

theorem envBound40458 : H12AffineFastState.Bounded env40458 := by
  intro p hp
  have h : env40458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40457_40458 : H12AffineEnvironment.transform 1 3 env40457 = env40458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env40457 == env40458) = true)

def env40459 : List Nat := [2,4,8,16,32,64,128,256,340,1024,1287,1281,25,1297,260,1053,106,1181,1088,261,1280,477,1339,268,208,1323,1086,58,1296,329,20,16,257,43,1344,276]

theorem envBound40459 : H12AffineFastState.Bounded env40459 := by
  intro p hp
  have h : env40459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40449_40459 : H12AffineEnvironment.transform 11 1281 env40449 = env40459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1281 env40449 == env40459) = true)

theorem identity40459 : scanCanonicalize (H12AffineFastState.compose env40459 (packedSelected [0,2,4,7,8,9,10,11,15,17,19,21,23,24] rootPS)) = affineNative (2^(6+1) ^^^ 110) := by decide +kernel

theorem selectedBound40459 : packedSelected [0,2,4,7,8,9,10,11,15,17,19,21,23,24] rootPS < 2^1333 := by decide +kernel

def env40460 : List Nat := [2,4,8,16,32,64,110,256,340,1024,1287,1281,25,1297,260,1053,106,1139,1088,261,1280,307,1339,268,62,1323,1086,58,1296,329,20,16,257,43,1344,276]

theorem envBound40460 : H12AffineFastState.Bounded env40460 := by
  intro p hp
  have h : env40460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40459_40460 : H12AffineEnvironment.transform 6 110 env40459 = env40460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 110 env40459 == env40460) = true)

theorem identity40460 : scanCanonicalize (H12AffineFastState.compose env40460 (packedSelected [1,2,3,4,9,10,11,12,13,15,16,17,18,21] rootPS)) = affineNative (2^(7+1) ^^^ 99) := by decide +kernel

theorem selectedBound40460 : packedSelected [1,2,3,4,9,10,11,12,13,15,16,17,18,21] rootPS < 2^1333 := by decide +kernel

def env40461 : List Nat := [2,4,8,16,32,64,110,99,55,1024,1124,1122,25,1138,103,1053,106,1139,1088,102,1123,80,1112,111,62,1096,1086,58,1139,42,20,16,98,43,1059,119]

theorem envBound40461 : H12AffineFastState.Bounded env40461 := by
  intro p hp
  have h : env40461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40460_40461 : H12AffineEnvironment.transform 7 99 env40460 = env40461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 99 env40460 == env40461) = true)

theorem identity40461 : scanCanonicalize (H12AffineFastState.compose env40461 (packedSelected [3,4,5,7,10,16] rootPS)) = affineNative (2^(9+1) ^^^ 50) := by decide +kernel

theorem selectedBound40461 : packedSelected [3,4,5,7,10,16] rootPS < 2^1333 := by decide +kernel

def env40462 : List Nat := [2,4,8,16,32,64,110,99,55,50,86,80,25,64,103,47,106,65,114,102,81,80,106,111,62,122,12,58,65,42,20,16,98,43,17,119]

theorem envBound40462 : H12AffineFastState.Bounded env40462 := by
  intro p hp
  have h : env40462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40461_40462 : H12AffineEnvironment.transform 9 50 env40461 = env40462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 50 env40461 == env40462) = true)

theorem identity40462 : scanCanonicalize (H12AffineFastState.compose env40462 (packedSelected [1,2,3,5,8,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound40462 : packedSelected [1,2,3,5,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env40463 : List Nat := [2,4,8,16,32,33,15,2,55,50,55,49,25,33,6,47,11,32,19,7,48,49,11,14,62,27,12,58,32,42,20,16,3,43,17,22]

theorem envBound40463 : H12AffineFastState.Bounded env40463 := by
  intro p hp
  have h : env40463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40462_40463 : H12AffineEnvironment.transform 5 33 env40462 = env40463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env40462 == env40463) = true)

theorem identity40463 : scanCanonicalize (H12AffineFastState.compose env40463 (packedSelected [1,2,3,5] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound40463 : packedSelected [1,2,3,5] rootPS < 2^1333 := by decide +kernel

def env40464 : List Nat := [2,4,8,12,32,33,15,2,43,46,43,45,5,33,6,47,11,32,15,7,44,45,11,14,34,7,12,38,32,42,8,12,3,43,13,10]

theorem envBound40464 : H12AffineFastState.Bounded env40464 := by
  intro p hp
  have h : env40464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40463_40464 : H12AffineEnvironment.transform 3 12 env40463 = env40464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env40463 == env40464) = true)

theorem identity40464 : scanCanonicalize (H12AffineFastState.compose env40464 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound40464 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env40465 : List Nat := [2,4,8,12,0,1,15,2,11,14,11,13,5,1,6,15,11,0,15,7,12,13,11,14,2,7,12,6,0,10,8,12,3,11,13,10]

theorem envBound40465 : H12AffineFastState.Bounded env40465 := by
  intro p hp
  have h : env40465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40464_40465 : H12AffineEnvironment.transform 4 0 env40464 = env40465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env40464 == env40465) = true)

theorem identity40465 : scanCanonicalize (H12AffineFastState.compose env40465 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound40465 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40466 : List Nat := [1,4,8,12,0,1,12,1,8,13,8,13,5,1,5,12,8,0,12,4,12,13,8,13,1,4,12,5,0,9,8,12,0,8,13,9]

theorem envBound40466 : H12AffineFastState.Bounded env40466 := by
  intro p hp
  have h : env40466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40465_40466 : H12AffineEnvironment.transform 0 1 env40465 = env40466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env40465 == env40466) = true)

theorem identity40466 : scanCanonicalize (H12AffineFastState.compose env40466 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound40466 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40467 : List Nat := [1,0,8,8,0,1,8,1,8,9,8,9,1,1,1,8,8,0,8,0,8,9,8,9,1,0,8,1,0,9,8,8,0,8,9,9]

theorem envBound40467 : H12AffineFastState.Bounded env40467 := by
  intro p hp
  have h : env40467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40466_40467 : H12AffineEnvironment.transform 1 0 env40466 = env40467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env40466 == env40467) = true)

theorem identity40467 : scanCanonicalize (H12AffineFastState.compose env40467 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound40467 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40468 : List Nat := [1,0,1,1,0,1,1,1,1,0,1,0,1,1,1,1,1,0,1,0,1,0,1,0,1,0,1,1,0,0,1,1,0,1,0,0]

theorem envBound40468 : H12AffineFastState.Bounded env40468 := by
  intro p hp
  have h : env40468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40467_40468 : H12AffineEnvironment.transform 2 1 env40467 = env40468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env40467 == env40468) = true)

def env40469 : List Nat := [2,4,8,16,32,64,128,256,341,1024,1286,4096,25,1297,5125,1053,106,1181,4417,5124,4097,477,1339,5133,5585,4138,4415,58,1296,5193,20,16,257,43,1344,5140]

theorem envBound40469 : H12AffineFastState.Bounded env40469 := by
  intro p hp
  have h : env40469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40448_40469 : H12AffineEnvironment.transform 8 341 env40448 = env40469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env40448 == env40469) = true)

def env40470 : List Nat := [2,4,8,16,32,64,128,256,341,1024,1286,1280,25,1297,261,1053,106,1181,1089,260,1281,477,1339,269,209,1322,1087,58,1296,329,20,16,257,43,1344,276]

theorem envBound40470 : H12AffineFastState.Bounded env40470 := by
  intro p hp
  have h : env40470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40469_40470 : H12AffineEnvironment.transform 11 1280 env40469 = env40470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env40469 == env40470) = true)

theorem identity40470 : scanCanonicalize (H12AffineFastState.compose env40470 (packedSelected [0,2,4,7,8,9,10,11,15,17,19,21,23,24] rootPS)) = affineNative (2^(6+1) ^^^ 85) := by decide +kernel

theorem selectedBound40470 : packedSelected [0,2,4,7,8,9,10,11,15,17,19,21,23,24] rootPS < 2^1333 := by decide +kernel

def env40471 : List Nat := [2,4,8,16,32,64,85,256,341,1024,1286,1280,25,1297,261,1053,106,1096,1089,260,1281,264,1339,269,4,1322,1087,58,1296,329,20,16,257,43,1344,276]

theorem envBound40471 : H12AffineFastState.Bounded env40471 := by
  intro p hp
  have h : env40471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40470_40471 : H12AffineEnvironment.transform 6 85 env40470 = env40471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 85 env40470 == env40471) = true)

theorem identity40471 : scanCanonicalize (H12AffineFastState.compose env40471 (packedSelected [0,2,3,4,10,11,12,15,16,17,23] rootPS)) = affineNative (2^(9+1) ^^^ 267) := by decide +kernel

theorem selectedBound40471 : packedSelected [0,2,3,4,10,11,12,15,16,17,23] rootPS < 2^1333 := by decide +kernel

def env40472 : List Nat := [2,4,8,16,32,64,85,256,341,267,13,11,25,26,261,278,106,323,330,260,10,264,48,269,4,33,308,58,27,329,20,16,257,43,75,276]

theorem envBound40472 : H12AffineFastState.Bounded env40472 := by
  intro p hp
  have h : env40472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40471_40472 : H12AffineEnvironment.transform 9 267 env40471 = env40472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 267 env40471 == env40472) = true)

theorem identity40472 : scanCanonicalize (H12AffineFastState.compose env40472 (packedSelected [1,2,4,8,9,11,12,13,16,17,18] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound40472 : packedSelected [1,2,4,8,9,11,12,13,16,17,18] rootPS < 2^1333 := by decide +kernel

def env40473 : List Nat := [2,4,8,16,32,32,53,256,309,267,13,11,25,26,261,278,10,291,298,260,10,264,48,269,4,33,308,58,27,297,20,16,257,43,43,276]

end H12CloudChart2