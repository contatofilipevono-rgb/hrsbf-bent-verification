import H12CloudChart2Data143

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound35825 : H12AffineFastState.Bounded env35825 := by
  intro p hp
  have h : env35825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35824_35825 : H12AffineEnvironment.transform 4 10 env35824 = env35825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env35824 == env35825) = true)

theorem identity35825 : scanCanonicalize (H12AffineFastState.compose env35825 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound35825 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env35826 : List Nat := [2,4,8,16,10,17,128,256,136,5,391,277,25,276,277,284,277,412,5,276,276,396,17,25,144,16,0,276,277,136,20,17,257,260,276,136]

theorem envBound35826 : H12AffineFastState.Bounded env35826 := by
  intro p hp
  have h : env35826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35825_35826 : H12AffineEnvironment.transform 8 136 env35825 = env35826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env35825 == env35826) = true)

theorem identity35826 : scanCanonicalize (H12AffineFastState.compose env35826 (packedSelected [1,5] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound35826 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env35827 : List Nat := [2,4,8,16,10,17,9,256,1,5,270,277,25,276,277,284,277,277,5,276,276,261,17,25,25,16,0,276,277,1,20,17,257,260,276,1]

theorem envBound35827 : H12AffineFastState.Bounded env35827 := by
  intro p hp
  have h : env35827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35826_35827 : H12AffineEnvironment.transform 6 9 env35826 = env35827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env35826 == env35827) = true)

theorem identity35827 : scanCanonicalize (H12AffineFastState.compose env35827 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound35827 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env35828 : List Nat := [2,4,8,16,10,17,9,20,1,5,26,1,25,0,1,8,1,1,5,0,0,17,17,25,25,16,0,0,1,1,20,17,21,16,0,1]

theorem envBound35828 : H12AffineFastState.Bounded env35828 := by
  intro p hp
  have h : env35828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35827_35828 : H12AffineEnvironment.transform 7 20 env35827 = env35828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env35827 == env35828) = true)

theorem identity35828 : scanCanonicalize (H12AffineFastState.compose env35828 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound35828 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35829 : List Nat := [2,2,8,16,10,17,9,18,1,3,26,1,25,0,1,8,1,1,3,0,0,17,17,25,25,16,0,0,1,1,18,17,19,16,0,1]

theorem envBound35829 : H12AffineFastState.Bounded env35829 := by
  intro p hp
  have h : env35829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35828_35829 : H12AffineEnvironment.transform 1 2 env35828 = env35829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env35828 == env35829) = true)

theorem identity35829 : scanCanonicalize (H12AffineFastState.compose env35829 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound35829 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35830 : List Nat := [2,2,8,11,10,10,9,9,1,3,1,1,2,0,1,8,1,1,3,0,0,10,10,2,2,11,0,0,1,1,9,10,8,11,0,1]

theorem envBound35830 : H12AffineFastState.Bounded env35830 := by
  intro p hp
  have h : env35830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35829_35830 : H12AffineEnvironment.transform 3 11 env35829 = env35830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env35829 == env35830) = true)

def env35831 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,73,1297,276,359,1344,487,4417,277,4097,5276,16,1078,5505,5377,1150,1296,1296,7269,68,64,257,1281,1344,5953]

theorem envBound35831 : H12AffineFastState.Bounded env35831 := by
  intro p hp
  have h : env35831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35819_35831 : H12AffineEnvironment.transform 12 73 env35819 = env35831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env35819 == env35831) = true)

theorem identity35831 : scanCanonicalize (H12AffineFastState.compose env35831 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound35831 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env35832 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,73,0,276,359,81,487,4417,277,4097,4493,16,295,4240,4112,367,1,1,6516,68,64,257,16,81,4688]

theorem envBound35832 : H12AffineFastState.Bounded env35832 := by
  intro p hp
  have h : env35832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35831_35832 : H12AffineEnvironment.transform 9 273 env35831 = env35832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env35831 == env35832) = true)

theorem identity35832 : scanCanonicalize (H12AffineFastState.compose env35832 (packedSelected [0,2,3,5,7,10,11,12,15,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 674) := by decide +kernel

theorem selectedBound35832 : packedSelected [0,2,3,5,7,10,11,12,15,17,18,20] rootPS < 2^1333 := by decide +kernel

def env35833 : List Nat := [2,4,8,16,32,64,128,256,512,273,674,4096,73,0,276,359,81,487,4417,277,4097,4493,16,295,4240,4112,367,1,1,5078,68,64,257,16,81,4688]

theorem envBound35833 : H12AffineFastState.Bounded env35833 := by
  intro p hp
  have h : env35833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35832_35833 : H12AffineEnvironment.transform 10 674 env35832 = env35833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 674 env35832 == env35833) = true)

theorem identity35833 : scanCanonicalize (H12AffineFastState.compose env35833 (packedSelected [1,4,5,8,9,13,16,28] rootPS)) = affineNative (2^(11+1) ^^^ 560) := by decide +kernel

theorem selectedBound35833 : packedSelected [1,4,5,8,9,13,16,28] rootPS < 2^1333 := by decide +kernel

def env35834 : List Nat := [2,4,8,16,32,64,128,256,512,273,674,560,73,0,276,359,81,487,881,277,561,957,16,295,672,544,367,1,1,486,68,64,257,16,81,96]

theorem envBound35834 : H12AffineFastState.Bounded env35834 := by
  intro p hp
  have h : env35834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35833_35834 : H12AffineEnvironment.transform 11 560 env35833 = env35834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 560 env35833 == env35834) = true)

theorem identity35834 : scanCanonicalize (H12AffineFastState.compose env35834 (packedSelected [0,1,2,7,8,11,12,13,15] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound35834 : packedSelected [0,1,2,7,8,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env35835 : List Nat := [2,4,8,16,32,64,128,256,49,273,147,1,73,0,276,359,81,487,320,277,0,396,16,295,145,17,367,1,1,486,68,64,257,16,81,96]

theorem envBound35835 : H12AffineFastState.Bounded env35835 := by
  intro p hp
  have h : env35835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35834_35835 : H12AffineEnvironment.transform 8 49 env35834 = env35835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env35834 == env35835) = true)

theorem identity35835 : scanCanonicalize (H12AffineFastState.compose env35835 (packedSelected [1,3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound35835 : packedSelected [1,3,5,10] rootPS < 2^1333 := by decide +kernel

def env35836 : List Nat := [2,4,8,13,32,64,128,256,44,268,142,1,73,0,265,359,76,487,320,264,0,396,13,295,140,12,367,1,1,486,68,64,257,13,76,96]

theorem envBound35836 : H12AffineFastState.Bounded env35836 := by
  intro p hp
  have h : env35836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35835_35836 : H12AffineEnvironment.transform 3 13 env35835 = env35836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env35835 == env35836) = true)

theorem identity35836 : scanCanonicalize (H12AffineFastState.compose env35836 (packedSelected [2,4,8,9,11] rootPS)) = affineNative (2^(7+1) ^^^ 225) := by decide +kernel

theorem selectedBound35836 : packedSelected [2,4,8,9,11] rootPS < 2^1333 := by decide +kernel

def env35837 : List Nat := [2,4,8,13,32,64,128,225,44,237,142,1,73,0,232,134,76,6,161,233,0,109,13,198,140,12,142,1,1,7,68,64,224,13,76,96]

theorem envBound35837 : H12AffineFastState.Bounded env35837 := by
  intro p hp
  have h : env35837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35836_35837 : H12AffineEnvironment.transform 7 225 env35836 = env35837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 225 env35836 == env35837) = true)

theorem identity35837 : scanCanonicalize (H12AffineFastState.compose env35837 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound35837 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env35838 : List Nat := [2,4,8,13,32,64,34,67,44,79,44,1,73,0,74,36,76,6,3,75,0,109,13,100,46,12,44,1,1,7,68,64,66,13,76,96]

theorem envBound35838 : H12AffineFastState.Bounded env35838 := by
  intro p hp
  have h : env35838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35837_35838 : H12AffineEnvironment.transform 6 34 env35837 = env35838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env35837 == env35838) = true)

theorem identity35838 : scanCanonicalize (H12AffineFastState.compose env35838 (packedSelected [1,2,5] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound35838 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env35839 : List Nat := [2,4,8,13,11,64,9,67,7,79,7,1,73,0,74,15,76,6,3,75,0,70,13,79,5,12,7,1,1,7,68,64,66,13,76,75]

theorem envBound35839 : H12AffineFastState.Bounded env35839 := by
  intro p hp
  have h : env35839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35838_35839 : H12AffineEnvironment.transform 4 11 env35838 = env35839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env35838 == env35839) = true)

def env35840 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74862,65665,4417,8540,4097,5276,74046,66897,13768,78895,1151,74814,1296,81227,8205,65831,257,1281,1344,5953]

theorem envBound35840 : H12AffineFastState.Bounded env35840 := by
  intro p hp
  have h : env35840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35817_35840 : H12AffineEnvironment.transform 17 65665 env35817 = env35840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env35817 == env35840) = true)

theorem identity35840 : scanCanonicalize (H12AffineFastState.compose env35840 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5159) := by decide +kernel

theorem selectedBound35840 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env35841 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,5159,12361,5286,4417,8540,4097,5276,13593,4470,13768,8200,1151,12313,1296,10604,8205,5376,257,1281,1344,5953]

theorem envBound35841 : H12AffineFastState.Bounded env35841 := by
  intro p hp
  have h : env35841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35840_35841 : H12AffineEnvironment.transform 15 5159 env35840 = env35841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5159 env35840 == env35841) = true)

def env35842 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5384,1297,5205,5159,1345,5286,4417,5204,4097,5276,17,4470,192,5376,1151,1297,1296,7268,5381,5376,257,1281,1344,5953]

theorem envBound35842 : H12AffineFastState.Bounded env35842 := by
  intro p hp
  have h : env35842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35841_35842 : H12AffineEnvironment.transform 12 5384 env35841 = env35842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5384 env35841 == env35842) = true)

theorem identity35842 : scanCanonicalize (H12AffineFastState.compose env35842 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound35842 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env35843 : List Nat := [2,4,8,16,32,64,128,256,512,5,2048,4096,4365,276,4176,4130,324,4259,4417,4177,4097,4249,17,4470,192,4357,122,276,277,6241,4352,4357,257,260,325,4932]

theorem envBound35843 : H12AffineFastState.Bounded env35843 := by
  intro p hp
  have h : env35843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35842_35843 : H12AffineEnvironment.transform 9 5 env35842 = env35843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env35842 == env35843) = true)

theorem identity35843 : scanCanonicalize (H12AffineFastState.compose env35843 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 324) := by decide +kernel

theorem selectedBound35843 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env35844 : List Nat := [2,4,8,16,32,64,128,256,512,5,2048,324,73,276,276,358,324,487,5,277,325,477,17,50,192,65,122,276,277,2341,68,65,257,260,325,512]

theorem envBound35844 : H12AffineFastState.Bounded env35844 := by
  intro p hp
  have h : env35844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35843_35844 : H12AffineEnvironment.transform 11 324 env35843 = env35844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 324 env35843 == env35844) = true)

theorem identity35844 : scanCanonicalize (H12AffineFastState.compose env35844 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound35844 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env35845 : List Nat := [2,4,8,16,32,17,128,256,512,5,2048,277,24,276,276,311,277,438,5,277,276,396,17,50,145,16,43,276,277,2341,21,16,257,260,276,512]

theorem envBound35845 : H12AffineFastState.Bounded env35845 := by
  intro p hp
  have h : env35845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35844_35845 : H12AffineEnvironment.transform 5 17 env35844 = env35845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env35844 == env35845) = true)

theorem identity35845 : scanCanonicalize (H12AffineFastState.compose env35845 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 804) := by decide +kernel

theorem selectedBound35845 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35846 : List Nat := [2,4,8,16,32,17,128,256,512,5,804,277,24,276,276,311,277,438,5,277,276,396,17,50,145,16,43,276,277,513,21,16,257,260,276,512]

theorem envBound35846 : H12AffineFastState.Bounded env35846 := by
  intro p hp
  have h : env35846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35845_35846 : H12AffineEnvironment.transform 10 804 env35845 = env35846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 804 env35845 == env35846) = true)

theorem identity35846 : scanCanonicalize (H12AffineFastState.compose env35846 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound35846 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env35847 : List Nat := [2,4,8,16,32,17,18,256,512,5,804,277,24,276,276,311,277,292,5,277,276,286,17,50,3,16,43,276,277,513,21,16,257,260,276,512]

theorem envBound35847 : H12AffineFastState.Bounded env35847 := by
  intro p hp
  have h : env35847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35846_35847 : H12AffineEnvironment.transform 6 18 env35846 = env35847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env35846 == env35847) = true)

theorem identity35847 : scanCanonicalize (H12AffineFastState.compose env35847 (packedSelected [0,3,4,7] rootPS)) = affineNative (2^(8+1) ^^^ 318) := by decide +kernel

theorem selectedBound35847 : packedSelected [0,3,4,7] rootPS < 2^1333 := by decide +kernel

def env35848 : List Nat := [2,4,8,16,32,17,18,256,318,5,26,277,24,276,276,311,277,292,5,277,276,286,17,50,3,16,43,276,277,319,21,16,257,260,276,318]

theorem envBound35848 : H12AffineFastState.Bounded env35848 := by
  intro p hp
  have h : env35848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35847_35848 : H12AffineEnvironment.transform 8 318 env35847 = env35848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 318 env35847 == env35848) = true)

theorem identity35848 : scanCanonicalize (H12AffineFastState.compose env35848 (packedSelected [3,5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound35848 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env35849 : List Nat := [2,4,8,11,32,10,9,256,293,5,1,270,3,271,271,300,270,292,5,270,271,261,10,41,3,11,43,271,270,292,14,11,257,260,271,293]

theorem envBound35849 : H12AffineFastState.Bounded env35849 := by
  intro p hp
  have h : env35849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35848_35849 : H12AffineEnvironment.transform 3 11 env35848 = env35849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env35848 == env35849) = true)

theorem identity35849 : scanCanonicalize (H12AffineFastState.compose env35849 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound35849 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env35850 : List Nat := [2,4,8,11,10,10,9,256,271,5,1,270,3,271,271,262,270,270,5,270,271,261,10,3,3,11,1,271,270,270,14,11,257,260,271,271]

theorem envBound35850 : H12AffineFastState.Bounded env35850 := by
  intro p hp
  have h : env35850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35849_35850 : H12AffineEnvironment.transform 4 10 env35849 = env35850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env35849 == env35850) = true)

theorem identity35850 : scanCanonicalize (H12AffineFastState.compose env35850 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound35850 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env35851 : List Nat := [2,4,8,11,10,10,9,14,1,5,1,0,3,1,1,8,0,0,5,0,1,11,10,3,3,11,1,1,0,0,14,11,15,10,1,1]

theorem envBound35851 : H12AffineFastState.Bounded env35851 := by
  intro p hp
  have h : env35851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35850_35851 : H12AffineEnvironment.transform 7 14 env35850 = env35851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env35850 == env35851) = true)

theorem identity35851 : scanCanonicalize (H12AffineFastState.compose env35851 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound35851 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35852 : List Nat := [2,2,8,11,10,10,9,8,1,3,1,0,3,1,1,8,0,0,3,0,1,11,10,3,3,11,1,1,0,0,8,11,9,10,1,1]

theorem envBound35852 : H12AffineFastState.Bounded env35852 := by
  intro p hp
  have h : env35852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35851_35852 : H12AffineEnvironment.transform 1 2 env35851 = env35852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env35851 == env35852) = true)

def env35853 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5385,1297,5204,5159,1344,5286,4417,5205,4097,5276,16,4470,193,5377,1151,1296,1296,7269,5380,5376,257,1281,1344,5953]

theorem envBound35853 : H12AffineFastState.Bounded env35853 := by
  intro p hp
  have h : env35853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35841_35853 : H12AffineEnvironment.transform 12 5385 env35841 = env35853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5385 env35841 == env35853) = true)

theorem identity35853 : scanCanonicalize (H12AffineFastState.compose env35853 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound35853 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env35854 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,1368,1297,1029,1142,1344,1271,272,1028,80,1229,16,295,193,1360,1151,1296,1296,3124,1365,1361,257,1281,1344,1808]

theorem envBound35854 : H12AffineFastState.Bounded env35854 := by
  intro p hp
  have h : env35854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35853_35854 : H12AffineEnvironment.transform 11 81 env35853 = env35854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env35853 == env35854) = true)

theorem identity35854 : scanCanonicalize (H12AffineFastState.compose env35854 (packedSelected [0,2,3,5,7,10,11,12,15,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 675) := by decide +kernel

theorem selectedBound35854 : packedSelected [0,2,3,5,7,10,11,12,15,17,18,20] rootPS < 2^1333 := by decide +kernel

def env35855 : List Nat := [2,4,8,16,32,64,128,256,512,1024,675,81,1368,1297,1029,1142,1344,1271,272,1028,80,1229,16,295,193,1360,1151,1296,1296,1687,1365,1361,257,1281,1344,1808]

theorem envBound35855 : H12AffineFastState.Bounded env35855 := by
  intro p hp
  have h : env35855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35854_35855 : H12AffineEnvironment.transform 10 675 env35854 = env35855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 675 env35854 == env35855) = true)

theorem identity35855 : scanCanonicalize (H12AffineFastState.compose env35855 (packedSelected [1,4,5,8,9,13,16,28] rootPS)) = affineNative (2^(9+1) ^^^ 881) := by decide +kernel

theorem selectedBound35855 : packedSelected [1,4,5,8,9,13,16,28] rootPS < 2^1333 := by decide +kernel

def env35856 : List Nat := [2,4,8,16,32,64,128,256,512,881,675,81,553,608,884,775,561,902,272,885,80,956,16,295,193,545,782,609,609,486,548,544,257,624,561,97]

theorem envBound35856 : H12AffineFastState.Bounded env35856 := by
  intro p hp
  have h : env35856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35855_35856 : H12AffineEnvironment.transform 9 881 env35855 = env35856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 881 env35855 == env35856) = true)

theorem identity35856 : scanCanonicalize (H12AffineFastState.compose env35856 (packedSelected [0,2,3,4,7,8,9,11,16,17] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound35856 : packedSelected [0,2,3,4,7,8,9,11,16,17] rootPS < 2^1333 := by decide +kernel

def env35857 : List Nat := [2,4,8,16,32,64,56,256,512,881,539,81,553,608,884,775,561,830,272,885,80,772,16,295,121,545,782,609,609,350,548,544,257,624,561,97]

theorem envBound35857 : H12AffineFastState.Bounded env35857 := by
  intro p hp
  have h : env35857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35856_35857 : H12AffineEnvironment.transform 6 56 env35856 = env35857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env35856 == env35857) = true)

theorem identity35857 : scanCanonicalize (H12AffineFastState.compose env35857 (packedSelected [0,1,2,3,4,7,9,12] rootPS)) = affineNative (2^(8+1) ^^^ 96) := by decide +kernel

theorem selectedBound35857 : packedSelected [0,1,2,3,4,7,9,12] rootPS < 2^1333 := by decide +kernel

def env35858 : List Nat := [2,4,8,16,32,64,56,256,96,273,123,81,73,0,276,359,81,350,272,277,80,356,16,295,121,65,366,1,1,350,68,64,257,16,81,97]

theorem envBound35858 : H12AffineFastState.Bounded env35858 := by
  intro p hp
  have h : env35858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35857_35858 : H12AffineEnvironment.transform 8 96 env35857 = env35858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 96 env35857 == env35858) = true)

theorem identity35858 : scanCanonicalize (H12AffineFastState.compose env35858 (packedSelected [2,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound35858 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env35859 : List Nat := [2,4,8,16,32,64,56,116,96,101,123,81,73,0,96,19,81,42,100,97,80,16,16,83,121,65,26,1,1,42,68,64,117,16,81,97]

theorem envBound35859 : H12AffineFastState.Bounded env35859 := by
  intro p hp
  have h : env35859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35858_35859 : H12AffineEnvironment.transform 7 116 env35858 = env35859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env35858 == env35859) = true)

theorem identity35859 : scanCanonicalize (H12AffineFastState.compose env35859 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound35859 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env35860 : List Nat := [2,4,1,16,32,64,49,116,96,101,114,81,64,0,96,19,81,35,100,97,80,16,16,83,112,65,19,1,1,35,68,64,117,16,81,97]

theorem envBound35860 : H12AffineFastState.Bounded env35860 := by
  intro p hp
  have h : env35860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35859_35860 : H12AffineEnvironment.transform 2 1 env35859 = env35860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env35859 == env35860) = true)

theorem identity35860 : scanCanonicalize (H12AffineFastState.compose env35860 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound35860 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35861 : List Nat := [2,4,1,16,32,16,49,36,48,53,34,1,16,0,48,19,1,35,52,49,0,16,16,3,32,17,19,1,1,35,20,16,37,16,1,49]

theorem envBound35861 : H12AffineFastState.Bounded env35861 := by
  intro p hp
  have h : env35861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35860_35861 : H12AffineEnvironment.transform 5 16 env35860 = env35861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env35860 == env35861) = true)

theorem identity35861 : scanCanonicalize (H12AffineFastState.compose env35861 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound35861 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35862 : List Nat := [2,0,1,16,32,16,49,32,48,49,34,1,16,0,48,19,1,35,48,49,0,16,16,3,32,17,19,1,1,35,16,16,33,16,1,49]

theorem envBound35862 : H12AffineFastState.Bounded env35862 := by
  intro p hp
  have h : env35862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35861_35862 : H12AffineEnvironment.transform 1 0 env35861 = env35862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env35861 == env35862) = true)

theorem identity35862 : scanCanonicalize (H12AffineFastState.compose env35862 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound35862 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env35863 : List Nat := [2,0,1,3,32,3,34,32,35,34,34,1,3,0,35,0,1,35,35,34,0,3,3,3,32,2,0,1,1,35,3,3,33,3,1,34]

theorem envBound35863 : H12AffineFastState.Bounded env35863 := by
  intro p hp
  have h : env35863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35862_35863 : H12AffineEnvironment.transform 3 3 env35862 = env35863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env35862 == env35863) = true)

theorem identity35863 : scanCanonicalize (H12AffineFastState.compose env35863 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound35863 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env35864 : List Nat := [1,0,1,0,32,0,33,32,32,33,33,1,0,0,32,0,1,32,32,33,0,0,0,0,32,1,0,1,1,32,0,0,33,0,1,33]

theorem envBound35864 : H12AffineFastState.Bounded env35864 := by
  intro p hp
  have h : env35864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35863_35864 : H12AffineEnvironment.transform 0 1 env35863 = env35864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env35863 == env35864) = true)

theorem identity35864 : scanCanonicalize (H12AffineFastState.compose env35864 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound35864 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env35865 : List Nat := [1,0,1,0,1,0,0,1,1,0,0,1,0,0,1,0,1,1,1,0,0,0,0,0,1,1,0,1,1,1,0,0,0,0,1,0]

theorem envBound35865 : H12AffineFastState.Bounded env35865 := by
  intro p hp
  have h : env35865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35864_35865 : H12AffineEnvironment.transform 4 1 env35864 = env35865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env35864 == env35865) = true)

def env35866 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,21585,32769,4097,61648,91183,123165,28888,78894,385202,90415,1297,96346,25884,82998,257,1280,1344,21073]

theorem envBound35866 : H12AffineFastState.Bounded env35866 := by
  intro p hp
  have h : env35866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35769_35866 : H12AffineEnvironment.transform 18 21585 env35769 = env35866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21585 env35769 == env35866) = true)

theorem identity35866 : scanCanonicalize (H12AffineFastState.compose env35866 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound35866 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env35867 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,13341,65536,74862,262144,21585,13340,4097,17613,91183,87296,28888,78894,349359,90415,1297,96346,25884,82998,257,1280,1344,21073]

theorem envBound35867 : H12AffineFastState.Bounded env35867 := by
  intro p hp
  have h : env35867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35866_35867 : H12AffineEnvironment.transform 14 13341 env35866 = env35867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env35866 == env35867) = true)

def env35868 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74862,262144,4417,13340,4097,477,74047,69648,13768,78894,332223,74815,1297,81226,8204,65830,257,1280,1344,5953]

theorem envBound35868 : H12AffineFastState.Bounded env35868 := by
  intro p hp
  have h : env35868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35867_35868 : H12AffineEnvironment.transform 13 1296 env35867 = env35868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env35867 == env35868) = true)

def env35869 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74862,65664,4417,13340,4097,477,74047,69648,13768,78894,4415,74815,1297,81226,8204,65830,257,1280,1344,5953]

theorem envBound35869 : H12AffineFastState.Bounded env35869 := by
  intro p hp
  have h : env35869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35868_35869 : H12AffineEnvironment.transform 17 65664 env35868 = env35869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env35868 == env35869) = true)

theorem identity35869 : scanCanonicalize (H12AffineFastState.compose env35869 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12590) := by decide +kernel

theorem selectedBound35869 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env35870 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,12590,5440,12718,4417,13340,4097,477,4113,8510,13768,1280,4415,5393,1297,3172,8204,12296,257,1280,1344,5953]

theorem envBound35870 : H12AffineFastState.Bounded env35870 := by
  intro p hp
  have h : env35870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35869_35870 : H12AffineEnvironment.transform 15 12590 env35869 = env35870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12590 env35869 == env35870) = true)

def env35871 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1296,9245,8494,1344,8622,321,9244,1,477,17,8510,9672,1280,319,1297,1297,3172,8204,8200,257,1280,1344,1857]

theorem envBound35871 : H12AffineFastState.Bounded env35871 := by
  intro p hp
  have h : env35871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35870_35871 : H12AffineEnvironment.transform 11 0 env35870 = env35871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env35870 == env35871) = true)

theorem identity35871 : scanCanonicalize (H12AffineFastState.compose env35871 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound35871 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env35872 : List Nat := [2,4,8,16,32,64,128,68,512,1024,2048,0,8192,1108,9245,8298,1028,8426,5,9244,1,153,17,8314,9356,1092,123,1109,1109,3172,8204,8200,69,1092,1028,1541]

theorem envBound35872 : H12AffineFastState.Bounded env35872 := by
  intro p hp
  have h : env35872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35871_35872 : H12AffineEnvironment.transform 7 68 env35871 = env35872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env35871 == env35872) = true)

theorem identity35872 : scanCanonicalize (H12AffineFastState.compose env35872 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound35872 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env35873 : List Nat := [2,4,8,16,32,64,128,68,512,5,2048,0,8192,81,8216,8298,1,8426,5,8217,1,153,17,8314,8329,65,123,80,80,2145,8204,8200,69,65,1,512]

theorem envBound35873 : H12AffineFastState.Bounded env35873 := by
  intro p hp
  have h : env35873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35872_35873 : H12AffineEnvironment.transform 9 5 env35872 = env35873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env35872 == env35873) = true)

theorem identity35873 : scanCanonicalize (H12AffineFastState.compose env35873 (packedSelected [0,2,5,7,8,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 147) := by decide +kernel

theorem selectedBound35873 : packedSelected [0,2,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env35874 : List Nat := [2,4,8,16,32,64,128,68,512,5,147,0,8192,81,8216,8298,1,8426,5,8217,1,153,17,8314,8329,65,123,80,80,242,8204,8200,69,65,1,512]

theorem envBound35874 : H12AffineFastState.Bounded env35874 := by
  intro p hp
  have h : env35874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35873_35874 : H12AffineEnvironment.transform 10 147 env35873 = env35874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 147 env35873 == env35874) = true)

theorem identity35874 : scanCanonicalize (H12AffineFastState.compose env35874 (packedSelected [0,2,4,5,7,8,9,13] rootPS)) = affineNative (2^(12+1) ^^^ 553) := by decide +kernel

theorem selectedBound35874 : packedSelected [0,2,4,5,7,8,9,13] rootPS < 2^1333 := by decide +kernel

def env35875 : List Nat := [2,4,8,16,32,64,128,68,512,5,147,0,553,81,561,579,1,707,5,560,1,153,17,595,672,65,123,80,80,242,549,545,69,65,1,512]

theorem envBound35875 : H12AffineFastState.Bounded env35875 := by
  intro p hp
  have h : env35875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35874_35875 : H12AffineEnvironment.transform 12 553 env35874 = env35875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 553 env35874 == env35875) = true)

theorem identity35875 : scanCanonicalize (H12AffineFastState.compose env35875 (packedSelected [0,1,3,4,7,9,12,15] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound35875 : packedSelected [0,1,3,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env35876 : List Nat := [2,4,8,16,32,64,128,68,137,5,147,0,160,81,184,202,1,74,5,185,1,153,17,218,41,65,123,80,80,242,172,168,69,65,1,137]

theorem envBound35876 : H12AffineFastState.Bounded env35876 := by
  intro p hp
  have h : env35876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35875_35876 : H12AffineEnvironment.transform 8 137 env35875 = env35876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env35875 == env35876) = true)

theorem identity35876 : scanCanonicalize (H12AffineFastState.compose env35876 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound35876 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env35877 : List Nat := [2,4,8,16,32,64,88,68,81,5,75,0,120,81,96,18,1,74,5,97,1,65,17,2,41,65,123,80,80,42,116,112,69,65,1,81]

theorem envBound35877 : H12AffineFastState.Bounded env35877 := by
  intro p hp
  have h : env35877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35876_35877 : H12AffineEnvironment.transform 6 88 env35876 = env35877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env35876 == env35877) = true)

theorem identity35877 : scanCanonicalize (H12AffineFastState.compose env35877 (packedSelected [2,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound35877 : packedSelected [2,4,5] rootPS < 2^1333 := by decide +kernel

def env35878 : List Nat := [2,4,8,16,32,32,56,36,49,5,43,0,24,49,0,18,1,42,5,1,1,33,17,2,41,33,27,48,48,42,20,16,37,33,1,49]

theorem envBound35878 : H12AffineFastState.Bounded env35878 := by
  intro p hp
  have h : env35878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35877_35878 : H12AffineEnvironment.transform 5 32 env35877 = env35878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env35877 == env35878) = true)

theorem identity35878 : scanCanonicalize (H12AffineFastState.compose env35878 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound35878 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35879 : List Nat := [2,4,8,10,32,32,34,36,43,5,43,0,2,43,0,8,1,42,5,1,1,33,11,2,41,33,1,42,42,42,14,10,37,33,1,43]

theorem envBound35879 : H12AffineFastState.Bounded env35879 := by
  intro p hp
  have h : env35879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35878_35879 : H12AffineEnvironment.transform 3 10 env35878 = env35879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env35878 == env35879) = true)

theorem identity35879 : scanCanonicalize (H12AffineFastState.compose env35879 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound35879 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env35880 : List Nat := [2,4,8,10,11,11,9,15,0,5,0,0,2,0,0,8,1,1,5,1,1,10,11,2,2,10,1,1,1,1,14,10,14,10,1,0]

theorem envBound35880 : H12AffineFastState.Bounded env35880 := by
  intro p hp
  have h : env35880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35879_35880 : H12AffineEnvironment.transform 4 11 env35879 = env35880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env35879 == env35880) = true)

theorem identity35880 : scanCanonicalize (H12AffineFastState.compose env35880 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound35880 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35881 : List Nat := [2,2,8,10,11,11,9,9,0,3,0,0,2,0,0,8,1,1,3,1,1,10,11,2,2,10,1,1,1,1,8,10,8,10,1,0]

theorem envBound35881 : H12AffineFastState.Bounded env35881 := by
  intro p hp
  have h : env35881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35880_35881 : H12AffineEnvironment.transform 1 2 env35880 = env35881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env35880 == env35881) = true)

def env35882 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1296,9244,8495,1345,8623,320,9245,0,477,16,8510,9673,1280,318,1296,1297,3172,8204,8201,257,1280,1344,1856]

theorem envBound35882 : H12AffineFastState.Bounded env35882 := by
  intro p hp
  have h : env35882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35870_35882 : H12AffineEnvironment.transform 11 1 env35870 = env35882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env35870 == env35882) = true)

theorem identity35882 : scanCanonicalize (H12AffineFastState.compose env35882 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 1368) := by decide +kernel

theorem selectedBound35882 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env35883 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,1368,1296,324,1143,1345,1271,320,325,0,477,16,1126,145,1280,318,1296,1297,3172,1364,1361,257,1280,1344,1856]

theorem envBound35883 : H12AffineFastState.Bounded env35883 := by
  intro p hp
  have h : env35883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35882_35883 : H12AffineEnvironment.transform 12 1368 env35882 = env35883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1368 env35882 == env35883) = true)

theorem identity35883 : scanCanonicalize (H12AffineFastState.compose env35883 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(9+1) ^^^ 236) := by decide +kernel

theorem selectedBound35883 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env35884 : List Nat := [2,4,8,16,32,64,128,256,512,236,2048,1,436,508,324,155,429,27,320,325,0,477,16,138,145,492,318,508,509,2184,440,445,257,492,428,940]

theorem envBound35884 : H12AffineFastState.Bounded env35884 := by
  intro p hp
  have h : env35884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35883_35884 : H12AffineEnvironment.transform 9 236 env35883 = env35884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 236 env35883 == env35884) = true)

theorem identity35884 : scanCanonicalize (H12AffineFastState.compose env35884 (packedSelected [0,2,3,5,7,10,11,12,13,15,16,18] rootPS)) = affineNative (2^(8+1) ^^^ 96) := by decide +kernel

theorem selectedBound35884 : packedSelected [0,2,3,5,7,10,11,12,13,15,16,18] rootPS < 2^1333 := by decide +kernel

def env35885 : List Nat := [2,4,8,16,32,64,128,256,96,236,2048,1,436,508,324,155,429,27,320,325,0,477,16,138,145,492,318,508,509,2184,440,445,257,492,428,460]

theorem envBound35885 : H12AffineFastState.Bounded env35885 := by
  intro p hp
  have h : env35885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35884_35885 : H12AffineEnvironment.transform 8 96 env35884 = env35885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 96 env35884 == env35885) = true)

theorem identity35885 : scanCanonicalize (H12AffineFastState.compose env35885 (packedSelected [0,2,3,4,7,8,9,10,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound35885 : packedSelected [0,2,3,4,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env35886 : List Nat := [2,4,8,16,32,64,128,256,96,236,81,1,436,508,324,155,429,27,320,325,0,477,16,138,145,492,318,508,509,217,440,445,257,492,428,460]

theorem envBound35886 : H12AffineFastState.Bounded env35886 := by
  intro p hp
  have h : env35886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35885_35886 : H12AffineEnvironment.transform 10 81 env35885 = env35886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env35885 == env35886) = true)

theorem identity35886 : scanCanonicalize (H12AffineFastState.compose env35886 (packedSelected [3,7,8,9,10,12] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound35886 : packedSelected [3,7,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env35887 : List Nat := [2,4,8,16,32,64,128,37,96,236,81,1,145,217,97,155,136,27,101,96,0,248,16,138,145,201,27,217,216,217,157,152,36,201,137,233]

theorem envBound35887 : H12AffineFastState.Bounded env35887 := by
  intro p hp
  have h : env35887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35886_35887 : H12AffineEnvironment.transform 7 37 env35886 = env35887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env35886 == env35887) = true)

theorem identity35887 : scanCanonicalize (H12AffineFastState.compose env35887 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound35887 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env35888 : List Nat := [2,4,8,11,32,64,128,37,96,236,74,1,138,194,97,128,136,0,101,96,0,227,11,138,138,201,0,194,195,194,134,131,36,201,137,233]

theorem envBound35888 : H12AffineFastState.Bounded env35888 := by
  intro p hp
  have h : env35888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35887_35888 : H12AffineEnvironment.transform 3 11 env35887 = env35888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env35887 == env35888) = true)

theorem identity35888 : scanCanonicalize (H12AffineFastState.compose env35888 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound35888 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env35889 : List Nat := [2,4,8,11,10,64,128,15,74,198,74,1,138,194,75,128,136,0,79,74,0,201,11,138,138,201,0,194,195,194,134,131,14,201,137,195]

theorem envBound35889 : H12AffineFastState.Bounded env35889 := by
  intro p hp
  have h : env35889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35888_35889 : H12AffineEnvironment.transform 4 10 env35888 = env35889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env35888 == env35889) = true)

theorem identity35889 : scanCanonicalize (H12AffineFastState.compose env35889 (packedSelected [1,2,5] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound35889 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env35890 : List Nat := [2,4,8,11,10,64,8,15,74,78,74,1,2,74,75,8,0,0,79,74,0,65,11,2,2,65,0,74,75,74,14,11,14,65,1,75]

theorem envBound35890 : H12AffineFastState.Bounded env35890 := by
  intro p hp
  have h : env35890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35889_35890 : H12AffineEnvironment.transform 6 8 env35889 = env35890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env35889 == env35890) = true)

theorem identity35890 : scanCanonicalize (H12AffineFastState.compose env35890 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound35890 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env35891 : List Nat := [2,4,0,3,2,64,0,7,66,70,66,1,2,66,67,0,0,0,71,66,0,65,3,2,2,65,0,66,67,66,6,3,6,65,1,67]

theorem envBound35891 : H12AffineFastState.Bounded env35891 := by
  intro p hp
  have h : env35891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35890_35891 : H12AffineEnvironment.transform 2 0 env35890 = env35891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env35890 == env35891) = true)

theorem identity35891 : scanCanonicalize (H12AffineFastState.compose env35891 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 3) := by decide +kernel

theorem selectedBound35891 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35892 : List Nat := [2,4,0,3,2,3,0,7,1,5,1,1,2,1,0,0,0,0,4,1,0,2,3,2,2,2,0,1,0,1,6,3,6,2,1,0]

theorem envBound35892 : H12AffineFastState.Bounded env35892 := by
  intro p hp
  have h : env35892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35891_35892 : H12AffineEnvironment.transform 5 3 env35891 = env35892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 3 env35891 == env35892) = true)

theorem identity35892 : scanCanonicalize (H12AffineFastState.compose env35892 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound35892 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35893 : List Nat := [2,0,0,3,2,3,0,3,1,1,1,1,2,1,0,0,0,0,0,1,0,2,3,2,2,2,0,1,0,1,2,3,2,2,1,0]

theorem envBound35893 : H12AffineFastState.Bounded env35893 := by
  intro p hp
  have h : env35893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35892_35893 : H12AffineEnvironment.transform 1 0 env35892 = env35893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env35892 == env35893) = true)

theorem identity35893 : scanCanonicalize (H12AffineFastState.compose env35893 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound35893 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env35894 : List Nat := [0,0,0,1,0,1,0,1,1,1,1,1,0,1,0,0,0,0,0,1,0,0,1,0,0,0,0,1,0,1,0,1,0,0,1,0]

theorem envBound35894 : H12AffineFastState.Bounded env35894 := by
  intro p hp
  have h : env35894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35893_35894 : H12AffineEnvironment.transform 0 0 env35893 = env35894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env35893 == env35894) = true)

def env35895 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74862,65665,4417,13340,4097,477,74047,69648,13768,78894,4414,74815,1297,81226,8204,65830,257,1280,1344,5953]

theorem envBound35895 : H12AffineFastState.Bounded env35895 := by
  intro p hp
  have h : env35895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35868_35895 : H12AffineEnvironment.transform 17 65665 env35868 = env35895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env35868 == env35895) = true)

theorem identity35895 : scanCanonicalize (H12AffineFastState.compose env35895 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9326) := by decide +kernel

theorem selectedBound35895 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env35896 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,9326,0,9455,4417,13340,4097,477,1361,13438,13768,4160,4414,81,1297,6436,8204,9544,257,1280,1344,5953]

theorem envBound35896 : H12AffineFastState.Bounded env35896 := by
  intro p hp
  have h : env35896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35895_35896 : H12AffineEnvironment.transform 15 9326 env35895 = env35896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9326 env35895 == env35896) = true)

def env35897 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,80,12637,8494,0,8623,4417,12636,4097,477,17,12606,12424,4160,4414,81,81,6436,8204,8200,257,64,0,4609]

theorem envBound35897 : H12AffineFastState.Bounded env35897 := by
  intro p hp
  have h : env35897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35896_35897 : H12AffineEnvironment.transform 9 320 env35896 = env35897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env35896 == env35897) = true)

theorem identity35897 : scanCanonicalize (H12AffineFastState.compose env35897 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 324) := by decide +kernel

theorem selectedBound35897 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env35898 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,324,8192,80,8217,8494,0,8623,5,8216,325,477,17,8314,8652,260,122,81,81,2144,8204,8200,257,64,0,837]

theorem envBound35898 : H12AffineFastState.Bounded env35898 := by
  intro p hp
  have h : env35898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35897_35898 : H12AffineEnvironment.transform 11 324 env35897 = env35898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 324 env35897 == env35898) = true)

theorem identity35898 : scanCanonicalize (H12AffineFastState.compose env35898 (packedSelected [2,5,8,10,11,20] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound35898 : packedSelected [2,5,8,10,11,20] rootPS < 2^1333 := by decide +kernel

def env35899 : List Nat := [2,4,8,16,32,64,128,256,136,320,2048,324,8192,80,8217,8494,0,8623,5,8216,325,477,17,8314,8652,260,122,81,81,2144,8204,8200,257,64,0,461]

theorem envBound35899 : H12AffineFastState.Bounded env35899 := by
  intro p hp
  have h : env35899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35898_35899 : H12AffineEnvironment.transform 8 136 env35898 = env35899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env35898 == env35899) = true)

theorem identity35899 : scanCanonicalize (H12AffineFastState.compose env35899 (packedSelected [2,4,5,8,9,16,17] rootPS)) = affineNative (2^(12+1) ^^^ 484) := by decide +kernel

theorem selectedBound35899 : packedSelected [2,4,5,8,9,16,17] rootPS < 2^1333 := by decide +kernel

def env35900 : List Nat := [2,4,8,16,32,64,128,256,136,320,2048,324,484,80,509,202,0,75,5,508,325,477,17,414,40,260,122,81,81,2144,488,492,257,64,0,461]

theorem envBound35900 : H12AffineFastState.Bounded env35900 := by
  intro p hp
  have h : env35900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35899_35900 : H12AffineEnvironment.transform 12 484 env35899 = env35900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 484 env35899 == env35900) = true)

theorem identity35900 : scanCanonicalize (H12AffineFastState.compose env35900 (packedSelected [1,3,10,11,16] rootPS)) = affineNative (2^(10+1) ^^^ 122) := by decide +kernel

theorem selectedBound35900 : packedSelected [1,3,10,11,16] rootPS < 2^1333 := by decide +kernel

def env35901 : List Nat := [2,4,8,16,32,64,128,256,136,320,122,324,484,80,509,202,0,75,5,508,325,477,17,414,40,260,122,81,81,26,488,492,257,64,0,461]

theorem envBound35901 : H12AffineFastState.Bounded env35901 := by
  intro p hp
  have h : env35901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35900_35901 : H12AffineEnvironment.transform 10 122 env35900 = env35901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 122 env35900 == env35901) = true)

theorem identity35901 : scanCanonicalize (H12AffineFastState.compose env35901 (packedSelected [0,1,2,3,4,10] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound35901 : packedSelected [0,1,2,3,4,10] rootPS < 2^1333 := by decide +kernel

def env35902 : List Nat := [2,4,8,16,32,64,57,256,49,320,122,324,349,80,324,115,0,75,5,325,325,356,17,295,40,260,122,81,81,26,337,341,257,64,0,372]

theorem envBound35902 : H12AffineFastState.Bounded env35902 := by
  intro p hp
  have h : env35902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35901_35902 : H12AffineEnvironment.transform 6 57 env35901 = env35902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env35901 == env35902) = true)

def env35903 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,81,12636,8495,0,8622,4417,12637,4097,477,16,12607,12425,4160,4414,81,80,6436,8204,8201,257,65,1,4608]

theorem envBound35903 : H12AffineFastState.Bounded env35903 := by
  intro p hp
  have h : env35903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35896_35903 : H12AffineEnvironment.transform 9 321 env35896 = env35903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env35896 == env35903) = true)

theorem identity35903 : scanCanonicalize (H12AffineFastState.compose env35903 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound35903 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env35904 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,25,81,4421,310,0,439,4417,4420,4097,477,16,4390,4240,4160,4414,81,80,6436,21,16,257,65,1,4608]

theorem envBound35904 : H12AffineFastState.Bounded env35904 := by
  intro p hp
  have h : env35904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35903_35904 : H12AffineEnvironment.transform 12 25 env35903 = env35904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env35903 == env35904) = true)

theorem identity35904 : scanCanonicalize (H12AffineFastState.compose env35904 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(11+1) ^^^ 428) := by decide +kernel

theorem selectedBound35904 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env35905 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,428,25,81,233,310,0,439,237,232,429,477,16,138,316,492,146,81,80,2184,21,16,257,65,1,940]

theorem envBound35905 : H12AffineFastState.Bounded env35905 := by
  intro p hp
  have h : env35905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35904_35905 : H12AffineEnvironment.transform 11 428 env35904 = env35905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 428 env35904 == env35905) = true)

theorem identity35905 : scanCanonicalize (H12AffineFastState.compose env35905 (packedSelected [0,2,3,5,7,10,11,12,13,15,16,18] rootPS)) = affineNative (2^(8+1) ^^^ 461) := by decide +kernel

theorem selectedBound35905 : packedSelected [0,2,3,5,7,10,11,12,13,15,16,18] rootPS < 2^1333 := by decide +kernel

def env35906 : List Nat := [2,4,8,16,32,64,128,256,461,321,2048,428,25,81,233,310,0,439,237,232,429,477,16,138,316,492,146,81,80,2184,21,16,257,65,1,97]

theorem envBound35906 : H12AffineFastState.Bounded env35906 := by
  intro p hp
  have h : env35906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35905_35906 : H12AffineEnvironment.transform 8 461 env35905 = env35906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 461 env35905 == env35906) = true)

theorem identity35906 : scanCanonicalize (H12AffineFastState.compose env35906 (packedSelected [0,2,3,4,7,8,9,10,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 509) := by decide +kernel

theorem selectedBound35906 : packedSelected [0,2,3,4,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env35907 : List Nat := [2,4,8,16,32,64,128,256,461,321,509,428,25,81,233,310,0,439,237,232,429,477,16,138,316,492,146,81,80,373,21,16,257,65,1,97]

theorem envBound35907 : H12AffineFastState.Bounded env35907 := by
  intro p hp
  have h : env35907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35906_35907 : H12AffineEnvironment.transform 10 509 env35906 = env35907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 509 env35906 == env35907) = true)

theorem identity35907 : scanCanonicalize (H12AffineFastState.compose env35907 (packedSelected [3,7,8,9,10,12] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound35907 : packedSelected [3,7,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env35908 : List Nat := [2,4,8,16,32,11,128,256,390,266,438,428,25,26,162,310,0,439,166,163,429,406,16,138,316,423,146,26,27,318,21,16,257,10,1,42]

theorem envBound35908 : H12AffineFastState.Bounded env35908 := by
  intro p hp
  have h : env35908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35907_35908 : H12AffineEnvironment.transform 5 11 env35907 = env35908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env35907 == env35908) = true)

theorem identity35908 : scanCanonicalize (H12AffineFastState.compose env35908 (packedSelected [1,2,4,5,9] rootPS)) = affineNative (2^(7+1) ^^^ 134) := by decide +kernel

theorem selectedBound35908 : packedSelected [1,2,4,5,9] rootPS < 2^1333 := by decide +kernel

def env35909 : List Nat := [2,4,8,16,32,11,128,134,0,140,48,42,25,26,162,176,0,49,166,163,43,16,16,138,186,33,146,26,27,184,21,16,135,10,1,42]

theorem envBound35909 : H12AffineFastState.Bounded env35909 := by
  intro p hp
  have h : env35909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35908_35909 : H12AffineEnvironment.transform 7 134 env35908 = env35909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 134 env35908 == env35909) = true)

def env35910 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74862,262144,4416,13340,4097,476,74046,69649,13769,78894,332222,74814,1297,81227,8205,65831,257,1280,1344,5952]

theorem envBound35910 : H12AffineFastState.Bounded env35910 := by
  intro p hp
  have h : env35910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35867_35910 : H12AffineEnvironment.transform 13 1297 env35867 = env35910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env35867 == env35910) = true)

def env35911 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74862,65664,4416,13340,4097,476,74046,69649,13769,78894,4414,74814,1297,81227,8205,65831,257,1280,1344,5952]

theorem envBound35911 : H12AffineFastState.Bounded env35911 := by
  intro p hp
  have h : env35911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35910_35911 : H12AffineEnvironment.transform 17 65664 env35910 = env35911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env35910 == env35911) = true)

theorem identity35911 : scanCanonicalize (H12AffineFastState.compose env35911 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 358) := by decide +kernel

theorem selectedBound35911 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env35912 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,358,9480,486,4416,13340,4097,476,8280,4471,13769,13640,4414,9560,1297,15405,8205,65,257,1280,1344,5952]

theorem envBound35912 : H12AffineFastState.Bounded env35912 := by
  intro p hp
  have h : env35912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35911_35912 : H12AffineEnvironment.transform 15 358 env35911 = env35912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 358 env35911 == env35912) = true)

def env35913 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,72,1297,5205,358,1344,486,4416,5204,4097,476,16,4471,5505,5376,4414,1296,1297,7269,69,65,257,1280,1344,5952]

theorem envBound35913 : H12AffineFastState.Bounded env35913 := by
  intro p hp
  have h : env35913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35912_35913 : H12AffineEnvironment.transform 12 72 env35912 = env35913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env35912 == env35913) = true)

theorem identity35913 : scanCanonicalize (H12AffineFastState.compose env35913 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound35913 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env35914 : List Nat := [2,4,8,16,32,64,128,256,512,5,2048,4096,72,276,4176,358,325,486,4416,4177,4097,476,16,4471,4484,4357,4414,277,276,6240,69,65,257,261,325,4933]

theorem envBound35914 : H12AffineFastState.Bounded env35914 := by
  intro p hp
  have h : env35914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35913_35914 : H12AffineEnvironment.transform 9 5 env35913 = env35914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env35913 == env35914) = true)

theorem identity35914 : scanCanonicalize (H12AffineFastState.compose env35914 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 325) := by decide +kernel

theorem selectedBound35914 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env35915 : List Nat := [2,4,8,16,32,64,128,256,512,5,2048,325,72,276,277,358,325,486,5,276,324,476,16,50,193,64,123,277,276,2341,69,65,257,261,325,512]

theorem envBound35915 : H12AffineFastState.Bounded env35915 := by
  intro p hp
  have h : env35915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35914_35915 : H12AffineEnvironment.transform 11 325 env35914 = env35915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 325 env35914 == env35915) = true)

theorem identity35915 : scanCanonicalize (H12AffineFastState.compose env35915 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound35915 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env35916 : List Nat := [2,4,8,16,32,16,128,256,512,5,2048,277,24,276,277,310,277,438,5,276,276,396,16,50,145,16,43,277,276,2341,21,17,257,261,277,512]

theorem envBound35916 : H12AffineFastState.Bounded env35916 := by
  intro p hp
  have h : env35916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35915_35916 : H12AffineEnvironment.transform 5 16 env35915 = env35916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env35915 == env35916) = true)

theorem identity35916 : scanCanonicalize (H12AffineFastState.compose env35916 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 697) := by decide +kernel

theorem selectedBound35916 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35917 : List Nat := [2,4,8,16,32,16,128,256,512,5,697,277,24,276,277,310,277,438,5,276,276,396,16,50,145,16,43,277,276,924,21,17,257,261,277,512]

theorem envBound35917 : H12AffineFastState.Bounded env35917 := by
  intro p hp
  have h : env35917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35916_35917 : H12AffineEnvironment.transform 10 697 env35916 = env35917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 697 env35916 == env35917) = true)

theorem identity35917 : scanCanonicalize (H12AffineFastState.compose env35917 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound35917 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env35918 : List Nat := [2,4,8,11,32,11,128,256,512,5,674,270,3,271,270,301,270,429,5,271,271,396,11,41,138,11,43,270,271,903,14,10,257,261,270,512]

theorem envBound35918 : H12AffineFastState.Bounded env35918 := by
  intro p hp
  have h : env35918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35917_35918 : H12AffineEnvironment.transform 3 11 env35917 = env35918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env35917 == env35918) = true)

theorem identity35918 : scanCanonicalize (H12AffineFastState.compose env35918 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound35918 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env35919 : List Nat := [2,4,8,11,32,11,128,256,137,5,43,270,3,271,270,301,270,429,5,271,271,396,11,41,138,11,43,270,271,270,14,10,257,261,270,137]

theorem envBound35919 : H12AffineFastState.Bounded env35919 := by
  intro p hp
  have h : env35919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35918_35919 : H12AffineEnvironment.transform 8 137 env35918 = env35919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env35918 == env35919) = true)

theorem identity35919 : scanCanonicalize (H12AffineFastState.compose env35919 (packedSelected [0,5] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound35919 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env35920 : List Nat := [2,4,8,11,32,11,128,173,137,5,43,163,3,162,163,128,163,0,5,162,162,33,11,41,138,11,43,163,162,163,14,10,172,168,163,137]

theorem envBound35920 : H12AffineFastState.Bounded env35920 := by
  intro p hp
  have h : env35920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35919_35920 : H12AffineEnvironment.transform 7 173 env35919 = env35920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env35919 == env35920) = true)

theorem identity35920 : scanCanonicalize (H12AffineFastState.compose env35920 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound35920 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env35921 : List Nat := [2,4,8,11,11,11,128,134,137,5,0,136,3,137,136,128,136,0,5,137,137,10,11,2,138,11,0,136,137,136,14,10,135,131,136,137]

theorem envBound35921 : H12AffineFastState.Bounded env35921 := by
  intro p hp
  have h : env35921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35920_35921 : H12AffineEnvironment.transform 4 11 env35920 = env35921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env35920 == env35921) = true)

theorem identity35921 : scanCanonicalize (H12AffineFastState.compose env35921 (packedSelected [0,3] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound35921 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env35922 : List Nat := [2,4,8,11,11,11,9,15,0,5,0,1,3,0,1,9,1,0,5,0,0,10,11,2,3,11,0,1,0,1,14,10,14,10,1,0]

theorem envBound35922 : H12AffineFastState.Bounded env35922 := by
  intro p hp
  have h : env35922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35921_35922 : H12AffineEnvironment.transform 6 9 env35921 = env35922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env35921 == env35922) = true)

theorem identity35922 : scanCanonicalize (H12AffineFastState.compose env35922 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound35922 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35923 : List Nat := [2,3,8,11,11,11,9,8,0,2,0,1,3,0,1,9,1,0,2,0,0,10,11,2,3,11,0,1,0,1,9,10,9,10,1,0]

theorem envBound35923 : H12AffineFastState.Bounded env35923 := by
  intro p hp
  have h : env35923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35922_35923 : H12AffineEnvironment.transform 1 3 env35922 = env35923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env35922 == env35923) = true)

def env35924 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,73,1297,5204,358,1345,486,4416,5205,4097,476,17,4471,5504,5377,4414,1297,1297,7268,68,65,257,1280,1344,5952]

theorem envBound35924 : H12AffineFastState.Bounded env35924 := by
  intro p hp
  have h : env35924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35912_35924 : H12AffineEnvironment.transform 12 73 env35912 = env35924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env35912 == env35924) = true)

theorem identity35924 : scanCanonicalize (H12AffineFastState.compose env35924 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound35924 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env35925 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,73,1297,1028,358,1345,486,272,1029,81,476,17,295,1488,1361,366,1297,1297,3124,68,65,257,1280,1344,1808]

theorem envBound35925 : H12AffineFastState.Bounded env35925 := by
  intro p hp
  have h : env35925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35924_35925 : H12AffineEnvironment.transform 11 80 env35924 = env35925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env35924 == env35925) = true)

theorem identity35925 : scanCanonicalize (H12AffineFastState.compose env35925 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound35925 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env35926 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,80,73,1212,1028,203,1260,75,189,1029,81,113,17,138,1149,1276,195,1212,1212,3124,68,65,172,1197,1261,1725]

theorem envBound35926 : H12AffineFastState.Bounded env35926 := by
  intro p hp
  have h : env35926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35925_35926 : H12AffineEnvironment.transform 7 173 env35925 = env35926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env35925 == env35926) = true)

theorem identity35926 : scanCanonicalize (H12AffineFastState.compose env35926 (packedSelected [0,2,3,4,5,7,9,10,11,12,15,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 539) := by decide +kernel

theorem selectedBound35926 : packedSelected [0,2,3,4,5,7,9,10,11,12,15,17,18] rootPS < 2^1333 := by decide +kernel

def env35927 : List Nat := [2,4,8,16,32,64,128,173,512,1024,539,80,73,1212,1028,203,1260,75,189,1029,81,113,17,138,1149,1276,195,1212,1212,1583,68,65,172,1197,1261,1725]

theorem envBound35927 : H12AffineFastState.Bounded env35927 := by
  intro p hp
  have h : env35927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35926_35927 : H12AffineEnvironment.transform 10 539 env35926 = env35927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 539 env35926 == env35927) = true)

theorem identity35927 : scanCanonicalize (H12AffineFastState.compose env35927 (packedSelected [0,2,3,7,8,10,16,17] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound35927 : packedSelected [0,2,3,7,8,10,16,17] rootPS < 2^1333 := by decide +kernel

def env35928 : List Nat := [2,4,8,16,32,64,18,63,512,1024,539,80,73,1070,1028,89,1150,75,47,1029,81,113,17,24,1149,1134,81,1070,1070,1583,68,65,62,1087,1151,1583]

theorem envBound35928 : H12AffineFastState.Bounded env35928 := by
  intro p hp
  have h : env35928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35927_35928 : H12AffineEnvironment.transform 6 18 env35927 = env35928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env35927 == env35928) = true)

theorem identity35928 : scanCanonicalize (H12AffineFastState.compose env35928 (packedSelected [0,2,3,4,7,8,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound35928 : packedSelected [0,2,3,4,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env35929 : List Nat := [2,4,8,16,32,64,18,63,512,53,539,80,73,27,49,89,75,75,47,48,81,113,17,24,72,91,81,27,27,538,68,65,62,10,74,538]

theorem envBound35929 : H12AffineFastState.Bounded env35929 := by
  intro p hp
  have h : env35929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35928_35929 : H12AffineEnvironment.transform 9 53 env35928 = env35929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env35928 == env35929) = true)

theorem identity35929 : scanCanonicalize (H12AffineFastState.compose env35929 (packedSelected [2,3,4,5,9] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound35929 : packedSelected [2,3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env35930 : List Nat := [2,4,8,16,32,64,18,63,49,53,42,80,73,27,49,89,75,75,47,48,81,113,17,24,72,91,81,27,27,43,68,65,62,10,74,43]

theorem envBound35930 : H12AffineFastState.Bounded env35930 := by
  intro p hp
  have h : env35930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35929_35930 : H12AffineEnvironment.transform 8 49 env35929 = env35930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env35929 == env35930) = true)

theorem identity35930 : scanCanonicalize (H12AffineFastState.compose env35930 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound35930 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env35931 : List Nat := [2,4,8,16,32,32,18,63,49,53,42,48,41,27,49,57,43,43,47,48,49,17,17,24,40,59,49,27,27,43,36,33,62,10,42,43]

theorem envBound35931 : H12AffineFastState.Bounded env35931 := by
  intro p hp
  have h : env35931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35930_35931 : H12AffineEnvironment.transform 5 32 env35930 = env35931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env35930 == env35931) = true)

theorem identity35931 : scanCanonicalize (H12AffineFastState.compose env35931 (packedSelected [1,2,5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound35931 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env35932 : List Nat := [2,4,8,11,32,32,9,36,42,46,42,43,41,0,42,34,43,43,47,43,42,10,10,3,40,32,42,0,0,43,36,33,37,10,42,43]

theorem envBound35932 : H12AffineFastState.Bounded env35932 := by
  intro p hp
  have h : env35932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35931_35932 : H12AffineEnvironment.transform 3 11 env35931 = env35932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env35931 == env35932) = true)

theorem identity35932 : scanCanonicalize (H12AffineFastState.compose env35932 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound35932 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env35933 : List Nat := [2,4,1,2,32,32,0,36,35,39,35,34,32,0,35,34,34,34,38,34,35,3,3,3,33,32,35,0,0,34,36,33,37,3,35,34]

theorem envBound35933 : H12AffineFastState.Bounded env35933 := by
  intro p hp
  have h : env35933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35932_35933 : H12AffineEnvironment.transform 2 1 env35932 = env35933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env35932 == env35933) = true)

theorem identity35933 : scanCanonicalize (H12AffineFastState.compose env35933 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound35933 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35934 : List Nat := [2,4,1,2,2,2,0,6,1,5,1,0,2,0,1,0,0,0,4,0,1,3,3,3,3,2,1,0,0,0,6,3,7,3,1,0]

theorem envBound35934 : H12AffineFastState.Bounded env35934 := by
  intro p hp
  have h : env35934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35933_35934 : H12AffineEnvironment.transform 4 2 env35933 = env35934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env35933 == env35934) = true)

theorem identity35934 : scanCanonicalize (H12AffineFastState.compose env35934 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound35934 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35935 : List Nat := [2,3,1,2,2,2,0,1,1,2,1,0,2,0,1,0,0,0,3,0,1,3,3,3,3,2,1,0,0,0,1,3,0,3,1,0]

theorem envBound35935 : H12AffineFastState.Bounded env35935 := by
  intro p hp
  have h : env35935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35934_35935 : H12AffineEnvironment.transform 1 3 env35934 = env35935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env35934 == env35935) = true)

theorem identity35935 : scanCanonicalize (H12AffineFastState.compose env35935 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound35935 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env35936 : List Nat := [0,1,1,0,0,0,0,1,1,0,1,0,0,0,1,0,0,0,1,0,1,1,1,1,1,0,1,0,0,0,1,1,0,1,1,0]

theorem envBound35936 : H12AffineFastState.Bounded env35936 := by
  intro p hp
  have h : env35936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35935_35936 : H12AffineEnvironment.transform 0 0 env35935 = env35936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env35935 == env35936) = true)

def env35937 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74862,65665,4416,13340,4097,476,74046,69649,13769,78894,4415,74814,1297,81227,8205,65831,257,1280,1344,5952]

theorem envBound35937 : H12AffineFastState.Bounded env35937 := by
  intro p hp
  have h : env35937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35910_35937 : H12AffineEnvironment.transform 17 65665 env35910 = env35937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env35910 == env35937) = true)

theorem identity35937 : scanCanonicalize (H12AffineFastState.compose env35937 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5159) := by decide +kernel

theorem selectedBound35937 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env35938 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,5159,12361,5286,4416,13340,4097,476,13593,1078,13769,8201,4415,12313,1297,10604,8205,5376,257,1280,1344,5952]

theorem envBound35938 : H12AffineFastState.Bounded env35938 := by
  intro p hp
  have h : env35938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35937_35938 : H12AffineEnvironment.transform 15 5159 env35937 = env35938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5159 env35937 == env35938) = true)

def env35939 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5384,1297,277,5159,1345,5286,4416,276,4097,476,17,1078,193,5377,4415,1297,1297,7268,5381,5376,257,1280,1344,5952]

theorem envBound35939 : H12AffineFastState.Bounded env35939 := by
  intro p hp
  have h : env35939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35938_35939 : H12AffineEnvironment.transform 12 5384 env35938 = env35939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5384 env35938 == env35939) = true)

theorem identity35939 : scanCanonicalize (H12AffineFastState.compose env35939 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound35939 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env35940 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,4121,0,277,4406,80,4535,4416,276,4097,476,17,295,193,4112,4415,0,0,6517,4116,4113,257,17,81,4689]

theorem envBound35940 : H12AffineFastState.Bounded env35940 := by
  intro p hp
  have h : env35940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35939_35940 : H12AffineEnvironment.transform 9 273 env35939 = env35940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env35939 == env35940) = true)

theorem identity35940 : scanCanonicalize (H12AffineFastState.compose env35940 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound35940 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env35941 : List Nat := [2,4,8,16,32,64,128,173,512,188,2048,4096,4121,0,184,4251,80,4122,4333,185,4097,113,17,138,193,4112,4242,0,0,6360,4116,4113,172,17,81,4689]

theorem envBound35941 : H12AffineFastState.Bounded env35941 := by
  intro p hp
  have h : env35941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35940_35941 : H12AffineEnvironment.transform 7 173 env35940 = env35941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env35940 == env35941) = true)

theorem identity35941 : scanCanonicalize (H12AffineFastState.compose env35941 (packedSelected [0,2,3,4,5,7,9,10,11,12,15,17,18] rootPS)) = affineNative (2^(11+1) ^^^ 2634) := by decide +kernel

theorem selectedBound35941 : packedSelected [0,2,3,4,5,7,9,10,11,12,15,17,18] rootPS < 2^1333 := by decide +kernel

def env35942 : List Nat := [2,4,8,16,32,64,128,173,512,188,2048,2634,2643,0,184,2769,80,2640,2727,185,2635,113,17,138,193,2650,2776,0,0,658,2654,2651,172,17,81,2075]

theorem envBound35942 : H12AffineFastState.Bounded env35942 := by
  intro p hp
  have h : env35942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35941_35942 : H12AffineEnvironment.transform 11 2634 env35941 = env35942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2634 env35941 == env35942) = true)

theorem identity35942 : scanCanonicalize (H12AffineFastState.compose env35942 (packedSelected [0,2,3,7,8,10,16,17] rootPS)) = affineNative (2^(10+1) ^^^ 648) := by decide +kernel

theorem selectedBound35942 : packedSelected [0,2,3,7,8,10,16,17] rootPS < 2^1333 := by decide +kernel

def env35943 : List Nat := [2,4,8,16,32,64,128,173,512,188,648,194,219,0,184,89,80,216,47,185,195,113,17,138,193,210,80,0,0,658,214,211,172,17,81,659]

theorem envBound35943 : H12AffineFastState.Bounded env35943 := by
  intro p hp
  have h : env35943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35942_35943 : H12AffineEnvironment.transform 10 648 env35942 = env35943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 648 env35942 == env35943) = true)

theorem identity35943 : scanCanonicalize (H12AffineFastState.compose env35943 (packedSelected [1,2,7,8,9] rootPS)) = affineNative (2^(8+1) ^^^ 96) := by decide +kernel

theorem selectedBound35943 : packedSelected [1,2,7,8,9] rootPS < 2^1333 := by decide +kernel

def env35944 : List Nat := [2,4,8,16,32,64,128,173,96,188,232,194,219,0,184,89,80,216,47,185,195,113,17,138,193,210,80,0,0,242,214,211,172,17,81,243]

theorem envBound35944 : H12AffineFastState.Bounded env35944 := by
  intro p hp
  have h : env35944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35943_35944 : H12AffineEnvironment.transform 8 96 env35943 = env35944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 96 env35943 == env35944) = true)

theorem identity35944 : scanCanonicalize (H12AffineFastState.compose env35944 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 66) := by decide +kernel

theorem selectedBound35944 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env35945 : List Nat := [2,4,8,16,32,64,66,111,96,126,42,0,25,0,122,89,80,26,47,123,1,113,17,72,3,16,80,0,0,48,20,17,110,17,81,49]

theorem envBound35945 : H12AffineFastState.Bounded env35945 := by
  intro p hp
  have h : env35945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35944_35945 : H12AffineEnvironment.transform 6 66 env35944 = env35945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 66 env35944 == env35945) = true)

theorem identity35945 : scanCanonicalize (H12AffineFastState.compose env35945 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound35945 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env35946 : List Nat := [2,4,8,16,17,64,66,94,81,79,27,0,25,0,75,89,80,26,30,74,1,64,17,72,3,16,80,0,0,1,20,17,95,17,81,0]

theorem envBound35946 : H12AffineFastState.Bounded env35946 := by
  intro p hp
  have h : env35946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35945_35946 : H12AffineEnvironment.transform 4 17 env35945 = env35946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env35945 == env35946) = true)

theorem identity35946 : scanCanonicalize (H12AffineFastState.compose env35946 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound35946 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35947 : List Nat := [2,4,8,13,12,64,66,67,76,79,6,0,4,0,75,68,77,7,3,74,1,64,12,72,3,13,77,0,0,1,9,12,66,12,76,0]

theorem envBound35947 : H12AffineFastState.Bounded env35947 := by
  intro p hp
  have h : env35947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35946_35947 : H12AffineEnvironment.transform 3 13 env35946 = env35947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env35946 == env35947) = true)

theorem identity35947 : scanCanonicalize (H12AffineFastState.compose env35947 (packedSelected [5] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound35947 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env35948 : List Nat := [2,3,8,10,11,64,66,67,75,72,1,0,3,0,75,67,74,0,3,74,1,64,11,72,3,10,74,0,0,1,9,11,66,11,75,0]

theorem envBound35948 : H12AffineFastState.Bounded env35948 := by
  intro p hp
  have h : env35948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35947_35948 : H12AffineEnvironment.transform 1 3 env35947 = env35948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env35947 == env35948) = true)

theorem identity35948 : scanCanonicalize (H12AffineFastState.compose env35948 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound35948 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35949 : List Nat := [2,3,8,10,11,11,9,8,0,3,1,0,3,0,0,8,1,0,3,1,1,11,11,3,3,10,1,0,0,1,9,11,9,11,0,0]

theorem envBound35949 : H12AffineFastState.Bounded env35949 := by
  intro p hp
  have h : env35949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35948_35949 : H12AffineEnvironment.transform 5 11 env35948 = env35949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env35948 == env35949) = true)

def env35950 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5385,1297,276,5159,1344,5286,4416,277,4097,476,16,1078,192,5376,4415,1296,1297,7269,5380,5376,257,1280,1344,5952]

theorem envBound35950 : H12AffineFastState.Bounded env35950 := by
  intro p hp
  have h : env35950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35938_35950 : H12AffineEnvironment.transform 12 5385 env35938 = env35950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5385 env35938 == env35950) = true)

theorem identity35950 : scanCanonicalize (H12AffineFastState.compose env35950 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound35950 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env35951 : List Nat := [2,4,8,16,32,64,128,256,512,5,2048,4096,4364,276,276,4130,325,4259,4416,277,4097,476,16,51,192,4357,4415,277,276,6240,4353,4357,257,261,325,4933]

theorem envBound35951 : H12AffineFastState.Bounded env35951 := by
  intro p hp
  have h : env35951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35950_35951 : H12AffineEnvironment.transform 9 5 env35950 = env35951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env35950 == env35951) = true)

theorem identity35951 : scanCanonicalize (H12AffineFastState.compose env35951 (packedSelected [1,2,3,10,12,15,17,18,20] rootPS)) = affineNative (2^(11+1) ^^^ 885) := by decide +kernel

theorem selectedBound35951 : packedSelected [1,2,3,10,12,15,17,18,20] rootPS < 2^1333 := by decide +kernel

def env35952 : List Nat := [2,4,8,16,32,64,128,256,512,5,2048,885,633,276,276,855,325,982,565,277,884,476,16,51,192,624,586,277,276,2837,628,624,257,261,325,48]

theorem envBound35952 : H12AffineFastState.Bounded env35952 := by
  intro p hp
  have h : env35952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35951_35952 : H12AffineEnvironment.transform 11 885 env35951 = env35952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 885 env35951 == env35952) = true)

theorem identity35952 : scanCanonicalize (H12AffineFastState.compose env35952 (packedSelected [1,3,12,15,16,17,19,23] rootPS)) = affineNative (2^(10+1) ^^^ 470) := by decide +kernel

theorem selectedBound35952 : packedSelected [1,3,12,15,16,17,19,23] rootPS < 2^1333 := by decide +kernel

def env35953 : List Nat := [2,4,8,16,32,64,128,256,512,5,470,885,633,276,276,855,325,982,565,277,884,476,16,51,192,624,586,277,276,707,628,624,257,261,325,48]

theorem envBound35953 : H12AffineFastState.Bounded env35953 := by
  intro p hp
  have h : env35953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35952_35953 : H12AffineEnvironment.transform 10 470 env35952 = env35953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 470 env35952 == env35953) = true)

theorem identity35953 : scanCanonicalize (H12AffineFastState.compose env35953 (packedSelected [2,4,5,8,9,10,11,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound35953 : packedSelected [2,4,5,8,9,10,11,13,17] rootPS < 2^1333 := by decide +kernel

def env35954 : List Nat := [2,4,8,16,32,64,128,172,512,5,122,729,633,184,184,763,233,634,565,185,728,112,16,51,192,624,586,185,184,707,628,624,173,169,233,48]

theorem envBound35954 : H12AffineFastState.Bounded env35954 := by
  intro p hp
  have h : env35954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35953_35954 : H12AffineEnvironment.transform 7 172 env35953 = env35954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env35953 == env35954) = true)

theorem identity35954 : scanCanonicalize (H12AffineFastState.compose env35954 (packedSelected [0,1,4,5,7,9,10,13] rootPS)) = affineNative (2^(8+1) ^^^ 216) := by decide +kernel

theorem selectedBound35954 : packedSelected [0,1,4,5,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env35955 : List Nat := [2,4,8,16,32,64,128,172,216,5,122,1,161,184,184,35,233,162,237,185,0,112,16,51,192,168,146,185,184,27,172,168,173,169,233,48]

theorem envBound35955 : H12AffineFastState.Bounded env35955 := by
  intro p hp
  have h : env35955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35954_35955 : H12AffineEnvironment.transform 8 216 env35954 = env35955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env35954 == env35955) = true)

theorem identity35955 : scanCanonicalize (H12AffineFastState.compose env35955 (packedSelected [1,3,5] rootPS)) = affineNative (2^(5+1) ^^^ 28) := by decide +kernel

theorem selectedBound35955 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env35956 : List Nat := [2,4,8,16,32,28,128,172,132,5,38,1,161,184,184,35,181,162,177,185,0,44,16,51,156,168,146,185,184,27,172,168,173,169,181,48]

theorem envBound35956 : H12AffineFastState.Bounded env35956 := by
  intro p hp
  have h : env35956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35955_35956 : H12AffineEnvironment.transform 5 28 env35955 = env35956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 28 env35955 == env35956) = true)

theorem identity35956 : scanCanonicalize (H12AffineFastState.compose env35956 (packedSelected [0,2,3,4,7,9,10] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound35956 : packedSelected [0,2,3,4,7,9,10] rootPS < 2^1333 := by decide +kernel

def env35957 : List Nat := [2,4,8,10,32,6,128,172,132,5,38,1,161,162,162,35,175,162,171,163,0,44,10,41,134,168,136,163,162,1,172,168,173,169,175,42]

theorem envBound35957 : H12AffineFastState.Bounded env35957 := by
  intro p hp
  have h : env35957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35956_35957 : H12AffineEnvironment.transform 3 10 env35956 = env35957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env35956 == env35957) = true)

theorem identity35957 : scanCanonicalize (H12AffineFastState.compose env35957 (packedSelected [2,4,7] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound35957 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env35958 : List Nat := [2,4,8,10,32,6,8,36,12,5,38,1,41,42,42,35,39,42,35,43,0,44,10,41,14,32,0,43,42,1,36,32,37,33,39,42]

theorem envBound35958 : H12AffineFastState.Bounded env35958 := by
  intro p hp
  have h : env35958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35957_35958 : H12AffineEnvironment.transform 6 8 env35957 = env35958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env35957 == env35958) = true)

theorem identity35958 : scanCanonicalize (H12AffineFastState.compose env35958 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound35958 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env35959 : List Nat := [2,4,8,10,7,6,8,3,12,5,1,1,14,13,13,4,0,13,4,12,0,11,10,14,14,7,0,12,13,1,3,7,2,6,0,13]

theorem envBound35959 : H12AffineFastState.Bounded env35959 := by
  intro p hp
  have h : env35959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35958_35959 : H12AffineEnvironment.transform 4 7 env35958 = env35959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env35958 == env35959) = true)

theorem identity35959 : scanCanonicalize (H12AffineFastState.compose env35959 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound35959 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35960 : List Nat := [2,4,1,3,7,6,1,3,5,5,1,1,7,4,4,4,0,4,4,5,0,2,3,7,7,7,0,5,4,1,3,7,2,6,0,4]

theorem envBound35960 : H12AffineFastState.Bounded env35960 := by
  intro p hp
  have h : env35960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35959_35960 : H12AffineEnvironment.transform 2 1 env35959 = env35960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env35959 == env35960) = true)

def env35961 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,2154705,8388608,16777216,33554432,8914000,134217728,8389889,42087817,2189403,50962568,4294967296,34088328,4347445490,34359738368,33563273]

theorem envBound35961 : H12AffineFastState.Bounded env35961 := by
  intro p hp
  have h : env35961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26409_35961 : H12AffineEnvironment.transform 27 8389889 env26409 = env35961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 8389889 env26409 == env35961) = true)

def env35962 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,2154705,147520,16777216,33554432,672784,134217728,148801,33584585,2189403,50962568,4294967296,34088328,4347445490,34359738368,33563273]

theorem envBound35962 : H12AffineFastState.Bounded env35962 := by
  intro p hp
  have h : env35962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35961_35962 : H12AffineEnvironment.transform 22 147520 env35961 = env35962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147520 env35961 == env35962) = true)

def env35963 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,2154705,147520,16777216,33554432,672784,134217728,148801,33584585,2189403,50962568,4294967296,34088328,4347445490,151462016,33563273]

theorem envBound35963 : H12AffineFastState.Bounded env35963 := by
  intro p hp
  have h : env35963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35962_35963 : H12AffineEnvironment.transform 34 151462016 env35962 = env35963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 151462016 env35962 == env35963) = true)

def env35964 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,16777216,33554432,672784,134217728,148801,33584585,96347,50962568,4294967296,34088328,4345352434,151462016,33563273]

theorem envBound35964 : H12AffineFastState.Bounded env35964 := by
  intro p hp
  have h : env35964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35963_35964 : H12AffineEnvironment.transform 20 4096 env35963 = env35964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env35963 == env35964) = true)

theorem identity35964 : scanCanonicalize (H12AffineFastState.compose env35964 (packedSelected [14] rootPS)) = affineNative (2^(31+1) ^^^ 50516146) := by decide +kernel

theorem selectedBound35964 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env35965 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,16777216,33554432,672784,134217728,148801,33584585,96347,50962568,50516146,34088328,131136,151462016,33563273]

theorem envBound35965 : H12AffineFastState.Bounded env35965 := by
  intro p hp
  have h : env35965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35964_35965 : H12AffineEnvironment.transform 31 50516146 env35964 = env35965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 50516146 env35964 == env35965) = true)

def env35966 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,16777216,533640,672784,134217728,148801,545089,96347,16876544,17495098,256,131136,151462016,525825]

theorem envBound35966 : H12AffineFastState.Bounded env35966 := by
  intro p hp
  have h : env35966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35965_35966 : H12AffineEnvironment.transform 24 533640 env35965 = env35966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 533640 env35965 == env35966) = true)

def env35967 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,16777216,533640,672784,17245632,148801,545089,96347,16876544,17495098,256,131136,1344,525825]

theorem envBound35967 : H12AffineFastState.Bounded env35967 := by
  intro p hp
  have h : env35967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35966_35967 : H12AffineEnvironment.transform 26 17245632 env35966 = env35967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245632 env35966 == env35967) = true)

theorem identity35967 : scanCanonicalize (H12AffineFastState.compose env35967 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 41002) := by decide +kernel

theorem selectedBound35967 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env35968 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,41002,533640,672784,493034,148801,545089,96347,74794,676880,256,131136,1344,525825]

theorem envBound35968 : H12AffineFastState.Bounded env35968 := by
  intro p hp
  have h : env35968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35967_35968 : H12AffineEnvironment.transform 23 41002 env35967 = env35968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41002 env35967 == env35968) = true)

def env35969 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147520,41002,143496,20496,493034,148801,148801,96347,74794,16400,256,131136,1344,135681]

theorem envBound35969 : H12AffineFastState.Bounded env35969 := by
  intro p hp
  have h : env35969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35968_35969 : H12AffineEnvironment.transform 18 136192 env35968 = env35969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136192 env35968 == env35969) = true)

def env35970 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147520,41002,143496,20496,492614,148717,148717,96347,74794,16400,172,131136,1260,135681]

theorem envBound35970 : H12AffineFastState.Bounded env35970 := by
  intro p hp
  have h : env35970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35969_35970 : H12AffineEnvironment.transform 7 172 env35969 = env35970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env35969 == env35970) = true)

def env35971 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61569,147472,41002,143496,20496,492566,148669,148669,96267,74794,16400,172,131088,1212,135681]

theorem envBound35971 : H12AffineFastState.Bounded env35971 := by
  intro p hp
  have h : env35971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35970_35971 : H12AffineEnvironment.transform 5 16 env35970 = env35971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env35970 == env35971) = true)

theorem identity35971 : scanCanonicalize (H12AffineFastState.compose env35971 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 137352) := by decide +kernel

theorem selectedBound35971 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env35972 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,137352,136192,32769,4096,61569,147472,41002,143496,20496,105630,148669,148669,96267,74794,16400,172,131088,1212,135681]

theorem envBound35972 : H12AffineFastState.Bounded env35972 := by
  intro p hp
  have h : env35972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35971_35972 : H12AffineEnvironment.transform 17 137352 env35971 = env35972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137352 env35971 == env35972) = true)

theorem identity35972 : scanCanonicalize (H12AffineFastState.compose env35972 (packedSelected [1,5,8,18,19,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 13374) := by decide +kernel

theorem selectedBound35972 : packedSelected [1,5,8,18,19,23,24,26] rootPS < 2^1333 := by decide +kernel

def env35973 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,13374,131072,137352,136192,32769,4096,61569,147472,41002,143496,20496,43168,148669,148669,19509,4116,16400,172,131088,1212,135681]

theorem envBound35973 : H12AffineFastState.Bounded env35973 := by
  intro p hp
  have h : env35973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35972_35973 : H12AffineEnvironment.transform 15 13374 env35972 = env35973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13374 env35972 == env35973) = true)

theorem identity35973 : scanCanonicalize (H12AffineFastState.compose env35973 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound35973 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env35974 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1212,32768,13374,131072,137352,136192,32769,4096,46141,132268,41002,143496,5292,43168,131073,131073,2185,4116,1196,172,131088,1212,135681]

theorem envBound35974 : H12AffineFastState.Bounded env35974 := by
  intro p hp
  have h : env35974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35973_35974 : H12AffineEnvironment.transform 13 1212 env35973 = env35974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env35973 == env35974) = true)

theorem identity35974 : scanCanonicalize (H12AffineFastState.compose env35974 (packedSelected [13,17] rootPS)) = affineNative (2^(14+1) ^^^ 9381) := by decide +kernel

theorem selectedBound35974 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env35975 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1212,9381,13374,131072,137352,136192,9380,4096,4248,132268,1167,143496,5292,3077,131073,131073,2185,4116,1196,172,131088,1212,135681]

theorem envBound35975 : H12AffineFastState.Bounded env35975 := by
  intro p hp
  have h : env35975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35974_35975 : H12AffineEnvironment.transform 14 9381 env35974 = env35975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9381 env35974 == env35975) = true)

theorem identity35975 : scanCanonicalize (H12AffineFastState.compose env35975 (packedSelected [6,12,13,15] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound35975 : packedSelected [6,12,13,15] rootPS < 2^1333 := by decide +kernel

def env35976 : List Nat := [2,4,8,16,32,16,128,172,512,5,2048,4096,8192,185,8352,12347,131072,137352,135173,8353,4096,4248,131241,138,143496,4265,2048,131073,131073,2185,4116,169,172,131088,185,135681]

theorem envBound35976 : H12AffineFastState.Bounded env35976 := by
  intro p hp
  have h : env35976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35975_35976 : H12AffineEnvironment.transform 9 5 env35975 = env35976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env35975 == env35976) = true)

theorem identity35976 : scanCanonicalize (H12AffineFastState.compose env35976 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 144) := by decide +kernel

theorem selectedBound35976 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env35977 : List Nat := [2,4,8,16,32,16,128,172,512,5,2048,4096,144,185,48,4267,131072,137352,135173,49,4096,4248,131241,138,135192,4265,2048,131073,131073,2185,4116,169,172,131088,185,135681]

theorem envBound35977 : H12AffineFastState.Bounded env35977 := by
  intro p hp
  have h : env35977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35976_35977 : H12AffineEnvironment.transform 12 144 env35976 = env35977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 144 env35976 == env35977) = true)

theorem identity35977 : scanCanonicalize (H12AffineFastState.compose env35977 (packedSelected [0,1,3,4,6,10] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound35977 : packedSelected [0,1,3,4,6,10] rootPS < 2^1333 := by decide +kernel

def env35978 : List Nat := [2,4,8,16,32,16,128,172,27,5,2048,4096,144,185,48,4267,131072,137352,135173,49,4096,4248,131241,138,135192,4265,2048,131073,131073,2185,4116,169,172,131088,185,135194]

theorem envBound35978 : H12AffineFastState.Bounded env35978 := by
  intro p hp
  have h : env35978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35977_35978 : H12AffineEnvironment.transform 8 27 env35977 = env35978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env35977 == env35978) = true)

theorem identity35978 : scanCanonicalize (H12AffineFastState.compose env35978 (packedSelected [3,5] rootPS)) = affineNative (2^(11+1) ^^^ 2232) := by decide +kernel

theorem selectedBound35978 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env35979 : List Nat := [2,4,8,16,32,16,128,172,27,5,2048,2232,144,185,48,2067,131072,131120,133309,49,2232,2080,131241,138,133280,2065,2048,131073,131073,2185,2220,169,172,131088,185,133282]

theorem envBound35979 : H12AffineFastState.Bounded env35979 := by
  intro p hp
  have h : env35979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35978_35979 : H12AffineEnvironment.transform 11 2232 env35978 = env35979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2232 env35978 == env35979) = true)

theorem identity35979 : scanCanonicalize (H12AffineFastState.compose env35979 (packedSelected [2] rootPS)) = affineNative (2^(16+1) ^^^ 2090) := by decide +kernel

theorem selectedBound35979 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35980 : List Nat := [2,4,8,16,32,16,128,172,27,5,2048,2232,144,185,48,2067,2090,2074,151,49,2232,2080,2179,138,138,2065,2048,2091,2091,2185,2220,169,172,2106,185,136]

theorem envBound35980 : H12AffineFastState.Bounded env35980 := by
  intro p hp
  have h : env35980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35979_35980 : H12AffineEnvironment.transform 16 2090 env35979 = env35980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 2090 env35979 == env35980) = true)

theorem identity35980 : scanCanonicalize (H12AffineFastState.compose env35980 (packedSelected [1,4,6,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound35980 : packedSelected [1,4,6,7,8] rootPS < 2^1333 := by decide +kernel

def env35981 : List Nat := [2,4,8,16,32,16,128,172,27,5,26,162,144,185,48,9,48,0,151,49,162,58,153,138,138,11,26,49,49,147,182,169,172,32,185,136]

theorem envBound35981 : H12AffineFastState.Bounded env35981 := by
  intro p hp
  have h : env35981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35980_35981 : H12AffineEnvironment.transform 10 26 env35980 = env35981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env35980 == env35981) = true)

theorem identity35981 : scanCanonicalize (H12AffineFastState.compose env35981 (packedSelected [0,1,4] rootPS)) = affineNative (2^(6+1) ^^^ 21) := by decide +kernel

theorem selectedBound35981 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env35982 : List Nat := [2,4,8,16,32,16,21,57,27,5,26,55,5,44,48,9,48,0,2,49,55,58,12,31,31,11,26,49,49,6,35,60,57,32,44,29]

theorem envBound35982 : H12AffineFastState.Bounded env35982 := by
  intro p hp
  have h : env35982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35981_35982 : H12AffineEnvironment.transform 6 21 env35981 = env35982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 21 env35981 == env35982) = true)

theorem identity35982 : scanCanonicalize (H12AffineFastState.compose env35982 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound35982 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env35983 : List Nat := [2,4,8,16,17,16,21,8,27,5,26,6,5,29,1,9,1,0,2,0,6,11,12,31,31,11,26,0,0,6,18,13,8,17,29,29]

theorem envBound35983 : H12AffineFastState.Bounded env35983 := by
  intro p hp
  have h : env35983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35982_35983 : H12AffineEnvironment.transform 4 17 env35982 = env35983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env35982 == env35983) = true)

def env35984 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61568,147473,41002,143496,20496,492567,148668,148668,96266,74794,16400,172,131089,1213,135681]

theorem envBound35984 : H12AffineFastState.Bounded env35984 := by
  intro p hp
  have h : env35984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35970_35984 : H12AffineEnvironment.transform 5 17 env35970 = env35984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env35970 == env35984) = true)

theorem identity35984 : scanCanonicalize (H12AffineFastState.compose env35984 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 45216) := by decide +kernel

theorem selectedBound35984 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env35985 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,45216,262144,42144,32769,4096,61568,61617,41002,32808,20496,341175,62492,62492,96266,74794,16400,172,45233,1213,41633]

theorem envBound35985 : H12AffineFastState.Bounded env35985 := by
  intro p hp
  have h : env35985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35984_35985 : H12AffineEnvironment.transform 16 45216 env35984 = env35985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45216 env35984 == env35985) = true)

theorem identity35985 : scanCanonicalize (H12AffineFastState.compose env35985 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound35985 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env35986 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1212,32768,65536,45216,262144,42144,32769,4096,46140,46093,41002,32808,5292,341175,45216,45216,81078,74794,1196,172,45233,1213,41633]

theorem envBound35986 : H12AffineFastState.Bounded env35986 := by
  intro p hp
  have h : env35986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35985_35986 : H12AffineEnvironment.transform 13 1212 env35985 = env35986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env35985 == env35986) = true)

theorem identity35986 : scanCanonicalize (H12AffineFastState.compose env35986 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 33831) := by decide +kernel

theorem selectedBound35986 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env35987 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1212,32768,33831,45216,262144,42144,32769,4096,46140,46093,41002,32808,5292,307344,45216,45216,47249,40973,1196,172,45233,1213,41633]

theorem envBound35987 : H12AffineFastState.Bounded env35987 := by
  intro p hp
  have h : env35987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35986_35987 : H12AffineEnvironment.transform 15 33831 env35986 = env35987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33831 env35986 == env35987) = true)

theorem identity35987 : scanCanonicalize (H12AffineFastState.compose env35987 (packedSelected [4,9,20] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound35987 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env35988 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,184,8192,1212,32768,33831,40984,262144,42144,32769,184,42116,42165,41002,32808,1044,303144,40984,40984,43049,40973,1196,172,40969,1213,41633]

theorem envBound35988 : H12AffineFastState.Bounded env35988 := by
  intro p hp
  have h : env35988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35987_35988 : H12AffineEnvironment.transform 11 184 env35987 = env35988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env35987 == env35988) = true)

theorem identity35988 : scanCanonicalize (H12AffineFastState.compose env35988 (packedSelected [1,3,5,6,8,13] rootPS)) = affineNative (2^(17+1) ^^^ 2185) := by decide +kernel

theorem selectedBound35988 : packedSelected [1,3,5,6,8,13] rootPS < 2^1333 := by decide +kernel

def env35989 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,184,8192,1212,32768,33831,40984,2185,42144,32769,184,42116,42165,41002,32808,1044,43169,40984,40984,43049,40973,1196,172,40969,1213,41633]

theorem envBound35989 : H12AffineFastState.Bounded env35989 := by
  intro p hp
  have h : env35989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35988_35989 : H12AffineEnvironment.transform 17 2185 env35988 = env35989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2185 env35988 == env35989) = true)

theorem identity35989 : scanCanonicalize (H12AffineFastState.compose env35989 (packedSelected [0,3,5,7,10] rootPS)) = affineNative (2^(14+1) ^^^ 3212) := by decide +kernel

theorem selectedBound35989 : packedSelected [0,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env35990 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,184,8192,1212,3212,2219,11412,2185,10284,3213,184,10248,10297,11430,3236,1044,9261,11412,11412,9381,11393,1196,172,11397,1213,11821]

theorem envBound35990 : H12AffineFastState.Bounded env35990 := by
  intro p hp
  have h : env35990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35989_35990 : H12AffineEnvironment.transform 14 3212 env35989 = env35990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 3212 env35989 == env35990) = true)

theorem identity35990 : scanCanonicalize (H12AffineFastState.compose env35990 (packedSelected [1,3,4,5,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound35990 : packedSelected [1,3,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env35991 : List Nat := [2,4,8,16,32,17,128,172,512,1024,512,184,8192,1212,1676,683,9876,649,8748,1677,184,8712,8761,9894,1700,1044,9261,9876,9876,9381,9857,1196,172,9861,1213,9261]

theorem envBound35991 : H12AffineFastState.Bounded env35991 := by
  intro p hp
  have h : env35991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35990_35991 : H12AffineEnvironment.transform 10 512 env35990 = env35991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env35990 == env35991) = true)

theorem identity35991 : scanCanonicalize (H12AffineFastState.compose env35991 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 558) := by decide +kernel

theorem selectedBound35991 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env35992 : List Nat := [2,4,8,16,32,17,128,172,512,558,512,184,8192,658,162,683,8378,649,8748,163,184,8712,8761,8328,138,570,8707,8378,8378,8843,8367,642,172,8363,659,8707]

theorem envBound35992 : H12AffineFastState.Bounded env35992 := by
  intro p hp
  have h : env35992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35991_35992 : H12AffineEnvironment.transform 9 558 env35991 = env35992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 558 env35991 == env35992) = true)

theorem identity35992 : scanCanonicalize (H12AffineFastState.compose env35992 (packedSelected [2,4,6,7] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound35992 : packedSelected [2,4,6,7] rootPS < 2^1333 := by decide +kernel

def env35993 : List Nat := [2,4,8,16,32,17,56,20,512,558,512,0,8192,554,26,531,8194,561,8748,27,0,8712,8761,8240,50,570,8707,8194,8194,8755,8215,570,20,8211,555,8707]

theorem envBound35993 : H12AffineFastState.Bounded env35993 := by
  intro p hp
  have h : env35993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35992_35993 : H12AffineEnvironment.transform 6 56 env35992 = env35993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env35992 == env35993) = true)

theorem identity35993 : scanCanonicalize (H12AffineFastState.compose env35993 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 536) := by decide +kernel

theorem selectedBound35993 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env35994 : List Nat := [2,4,8,16,32,17,56,20,512,558,512,0,536,554,26,531,538,561,52,27,0,16,33,552,50,570,27,538,538,43,527,570,20,523,555,27]

theorem envBound35994 : H12AffineFastState.Bounded env35994 := by
  intro p hp
  have h : env35994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35993_35994 : H12AffineEnvironment.transform 12 536 env35993 = env35994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 536 env35993 == env35994) = true)

theorem identity35994 : scanCanonicalize (H12AffineFastState.compose env35994 (packedSelected [1,2,5] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound35994 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env35995 : List Nat := [2,4,8,10,32,11,34,14,512,558,512,0,514,554,0,521,512,555,46,1,0,10,33,552,40,544,1,512,512,43,527,544,14,523,555,1]

theorem envBound35995 : H12AffineFastState.Bounded env35995 := by
  intro p hp
  have h : env35995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35994_35995 : H12AffineEnvironment.transform 3 10 env35994 = env35995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env35994 == env35995) = true)

theorem identity35995 : scanCanonicalize (H12AffineFastState.compose env35995 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound35995 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35996 : List Nat := [2,4,8,10,11,11,9,14,512,517,512,0,514,513,0,521,512,512,5,1,0,10,10,515,3,523,1,512,512,0,527,523,14,523,512,1]

theorem envBound35996 : H12AffineFastState.Bounded env35996 := by
  intro p hp
  have h : env35996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35995_35996 : H12AffineEnvironment.transform 4 11 env35995 = env35996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env35995 == env35996) = true)

theorem identity35996 : scanCanonicalize (H12AffineFastState.compose env35996 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound35996 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35997 : List Nat := [2,4,4,6,7,7,5,2,512,517,512,0,514,513,0,517,512,512,5,1,0,6,6,515,3,519,1,512,512,0,515,519,2,519,512,1]

theorem envBound35997 : H12AffineFastState.Bounded env35997 := by
  intro p hp
  have h : env35997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35996_35997 : H12AffineEnvironment.transform 2 4 env35996 = env35997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env35996 == env35997) = true)

def env35998 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147520,41002,143496,20496,492615,148716,148716,96347,74794,16400,173,131136,1261,135681]

theorem envBound35998 : H12AffineFastState.Bounded env35998 := by
  intro p hp
  have h : env35998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35969_35998 : H12AffineEnvironment.transform 7 173 env35969 = env35998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env35969 == env35998) = true)

def env35999 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61569,147472,41002,143496,20496,492567,148668,148668,96267,74794,16400,173,131088,1213,135681]

theorem envBound35999 : H12AffineFastState.Bounded env35999 := by
  intro p hp
  have h : env35999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35998_35999 : H12AffineEnvironment.transform 5 16 env35998 = env35999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env35998 == env35999) = true)

theorem identity35999 : scanCanonicalize (H12AffineFastState.compose env35999 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 223243) := by decide +kernel

theorem selectedBound35999 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env36000 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,223243,136192,32769,4096,61569,147472,41002,143496,20496,60444,148668,148668,96267,74794,16400,173,131088,1213,135681]

theorem envBound36000 : H12AffineFastState.Bounded env36000 := by
  intro p hp
  have h : env36000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35999_36000 : H12AffineEnvironment.transform 17 223243 env35999 = env36000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223243 env35999 == env36000) = true)

theorem identity36000 : scanCanonicalize (H12AffineFastState.compose env36000 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 28802) := by decide +kernel

theorem selectedBound36000 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env36001 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,28802,131072,137353,136192,32769,4096,61569,147472,41002,143496,20496,60444,148668,148668,2185,21672,16400,173,131088,1213,135681]

theorem envBound36001 : H12AffineFastState.Bounded env36001 := by
  intro p hp
  have h : env36001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36000_36001 : H12AffineEnvironment.transform 15 28802 env36000 = env36001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28802 env36000 == env36001) = true)

theorem identity36001 : scanCanonicalize (H12AffineFastState.compose env36001 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(14+1) ^^^ 12312) := by decide +kernel

theorem selectedBound36001 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env36002 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,12312,28802,131072,137353,136192,12313,4096,16537,147472,4146,143496,20496,23556,148668,148668,2185,21672,16400,173,131088,1213,135681]

theorem envBound36002 : H12AffineFastState.Bounded env36002 := by
  intro p hp
  have h : env36002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36001_36002 : H12AffineEnvironment.transform 14 12312 env36001 = env36002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12312 env36001 == env36002) = true)

theorem identity36002 : scanCanonicalize (H12AffineFastState.compose env36002 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound36002 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env36003 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1213,12312,13375,131072,137353,136192,12313,4096,1060,132269,4146,143496,5293,6329,131073,131073,2185,4117,1197,173,131088,1213,135681]

theorem envBound36003 : H12AffineFastState.Bounded env36003 := by
  intro p hp
  have h : env36003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36002_36003 : H12AffineEnvironment.transform 13 1213 env36002 = env36003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env36002 == env36003) = true)

theorem identity36003 : scanCanonicalize (H12AffineFastState.compose env36003 (packedSelected [0,4,5,7,8,9,10,13] rootPS)) = affineNative (2^(12+1) ^^^ 2099) := by decide +kernel

theorem selectedBound36003 : packedSelected [0,4,5,7,8,9,10,13] rootPS < 2^1333 := by decide +kernel

def env36004 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,2099,1213,6187,7180,131072,137353,136192,6186,4096,1060,132269,4146,137403,5293,6329,131073,131073,2185,4117,1197,173,131088,1213,135681]

theorem envBound36004 : H12AffineFastState.Bounded env36004 := by
  intro p hp
  have h : env36004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36003_36004 : H12AffineEnvironment.transform 12 2099 env36003 = env36004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2099 env36003 == env36004) = true)

theorem identity36004 : scanCanonicalize (H12AffineFastState.compose env36004 (packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound36004 : packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env36005 : List Nat := [2,4,8,16,32,16,128,173,512,5,2048,4096,2099,184,6187,6153,131072,137353,135173,6186,4096,33,131240,4146,137403,4264,6329,131073,131073,2185,4117,168,173,131088,184,135681]

theorem envBound36005 : H12AffineFastState.Bounded env36005 := by
  intro p hp
  have h : env36005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36004_36005 : H12AffineEnvironment.transform 9 5 env36004 = env36005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env36004 == env36005) = true)

theorem identity36005 : scanCanonicalize (H12AffineFastState.compose env36005 (packedSelected [1,2,3,6,10,11] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound36005 : packedSelected [1,2,3,6,10,11] rootPS < 2^1333 := by decide +kernel

def env36006 : List Nat := [2,4,8,16,32,16,128,173,1,5,2048,4096,2099,184,6187,6153,131072,137353,135173,6186,4096,33,131240,4146,137403,4264,6329,131073,131073,2185,4117,168,173,131088,184,135168]

theorem envBound36006 : H12AffineFastState.Bounded env36006 := by
  intro p hp
  have h : env36006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36005_36006 : H12AffineEnvironment.transform 8 1 env36005 = env36006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env36005 == env36006) = true)

theorem identity36006 : scanCanonicalize (H12AffineFastState.compose env36006 (packedSelected [5,8] rootPS)) = affineNative (2^(16+1) ^^^ 2074) := by decide +kernel

theorem selectedBound36006 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env36007 : List Nat := [2,4,8,16,32,16,128,173,1,5,2048,4096,2099,184,6187,6153,2074,4243,6175,6186,4096,33,2226,4146,4257,4264,6329,2075,2075,2185,4117,168,173,2058,184,6170]

theorem envBound36007 : H12AffineFastState.Bounded env36007 := by
  intro p hp
  have h : env36007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36006_36007 : H12AffineEnvironment.transform 16 2074 env36006 = env36007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 2074 env36006 == env36007) = true)

theorem identity36007 : scanCanonicalize (H12AffineFastState.compose env36007 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(11+1) ^^^ 2184) := by decide +kernel

theorem selectedBound36007 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env36008 : List Nat := [2,4,8,16,32,16,128,173,1,5,2048,2184,2099,184,163,129,2074,2075,151,162,2184,33,2226,2234,2089,2080,49,2075,2075,2185,2205,168,173,2058,184,146]

theorem envBound36008 : H12AffineFastState.Bounded env36008 := by
  intro p hp
  have h : env36008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36007_36008 : H12AffineEnvironment.transform 11 2184 env36007 = env36008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2184 env36007 == env36008) = true)

theorem identity36008 : scanCanonicalize (H12AffineFastState.compose env36008 (packedSelected [0,2,3,4] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound36008 : packedSelected [0,2,3,4] rootPS < 2^1333 := by decide +kernel

def env36009 : List Nat := [2,4,5,16,32,16,128,160,1,5,2048,2181,2099,181,163,129,2071,2070,151,162,2181,33,2226,2231,2084,2080,49,2070,2070,2180,2192,165,160,2055,181,146]

theorem envBound36009 : H12AffineFastState.Bounded env36009 := by
  intro p hp
  have h : env36009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36008_36009 : H12AffineEnvironment.transform 2 5 env36008 = env36009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env36008 == env36009) = true)

theorem identity36009 : scanCanonicalize (H12AffineFastState.compose env36009 (packedSelected [0,1,2,9] rootPS)) = affineNative (2^(10+1) ^^^ 180) := by decide +kernel

theorem selectedBound36009 : packedSelected [0,1,2,9] rootPS < 2^1333 := by decide +kernel

def env36010 : List Nat := [2,4,5,16,32,16,128,160,1,5,180,49,135,181,163,129,163,162,151,162,49,33,6,3,144,148,49,162,162,48,36,165,160,179,181,146]

theorem envBound36010 : H12AffineFastState.Bounded env36010 := by
  intro p hp
  have h : env36010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36009_36010 : H12AffineEnvironment.transform 10 180 env36009 = env36010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 180 env36009 == env36010) = true)

theorem identity36010 : scanCanonicalize (H12AffineFastState.compose env36010 (packedSelected [0,2,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound36010 : packedSelected [0,2,5,7] rootPS < 2^1333 := by decide +kernel

def env36011 : List Nat := [2,4,5,16,32,16,19,51,1,5,39,49,20,38,48,18,48,49,4,49,49,33,6,3,3,7,49,49,49,48,36,54,51,32,38,1]

theorem envBound36011 : H12AffineFastState.Bounded env36011 := by
  intro p hp
  have h : env36011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36010_36011 : H12AffineEnvironment.transform 6 19 env36010 = env36011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env36010 == env36011) = true)

theorem identity36011 : scanCanonicalize (H12AffineFastState.compose env36011 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound36011 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36012 : List Nat := [2,4,5,7,32,7,4,36,1,5,39,38,3,38,39,5,39,38,4,38,38,33,6,3,3,7,38,38,38,39,36,33,36,32,38,1]

theorem envBound36012 : H12AffineFastState.Bounded env36012 := by
  intro p hp
  have h : env36012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36011_36012 : H12AffineEnvironment.transform 3 7 env36011 = env36012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env36011 == env36012) = true)

theorem identity36012 : scanCanonicalize (H12AffineFastState.compose env36012 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound36012 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36013 : List Nat := [2,4,5,7,7,7,4,3,1,5,0,1,3,1,0,5,0,1,4,1,1,6,6,3,3,7,1,1,1,0,3,6,3,7,1,1]

theorem envBound36013 : H12AffineFastState.Bounded env36013 := by
  intro p hp
  have h : env36013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36012_36013 : H12AffineEnvironment.transform 4 7 env36012 = env36013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env36012 == env36013) = true)

def env36014 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61568,147473,41002,143496,20496,492566,148669,148669,96266,74794,16400,173,131089,1212,135681]

theorem envBound36014 : H12AffineFastState.Bounded env36014 := by
  intro p hp
  have h : env36014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35998_36014 : H12AffineEnvironment.transform 5 17 env35998 = env36014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env35998 == env36014) = true)

theorem identity36014 : scanCanonicalize (H12AffineFastState.compose env36014 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 114722) := by decide +kernel

theorem selectedBound36014 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env36015 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,114722,262144,119842,32769,4096,61568,98355,41002,127146,20496,279604,99487,99487,96266,74794,16400,173,114739,1212,119331]

theorem envBound36015 : H12AffineFastState.Bounded env36015 := by
  intro p hp
  have h : env36015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36014_36015 : H12AffineEnvironment.transform 16 114722 env36014 = env36015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114722 env36014 == env36015) = true)

theorem identity36015 : scanCanonicalize (H12AffineFastState.compose env36015 (packedSelected [3,10,16,18,19,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 92338) := by decide +kernel

theorem selectedBound36015 : packedSelected [3,10,16,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env36016 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,114722,92338,119842,32769,4096,61568,98355,41002,127146,20496,76934,99487,99487,96266,74794,16400,173,114739,1212,119331]

theorem envBound36016 : H12AffineFastState.Bounded env36016 := by
  intro p hp
  have h : env36016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36015_36016 : H12AffineEnvironment.transform 17 92338 env36015 = env36016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 92338 env36015 == env36016) = true)

theorem identity36016 : scanCanonicalize (H12AffineFastState.compose env36016 (packedSelected [7,16,18,19,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53283) := by decide +kernel

theorem selectedBound36016 : packedSelected [7,16,18,19,23,26,27] rootPS < 2^1333 := by decide +kernel

def env36017 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,53283,4097,47249,1025,32769,4096,61568,20496,41002,8329,20496,64677,21692,21692,43049,62473,16400,173,4112,1212,512]

theorem envBound36017 : H12AffineFastState.Bounded env36017 := by
  intro p hp
  have h : env36017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36016_36017 : H12AffineEnvironment.transform 15 53283 env36016 = env36017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53283 env36016 == env36017) = true)

theorem identity36017 : scanCanonicalize (H12AffineFastState.compose env36017 (packedSelected [4,9,16] rootPS)) = affineNative (2^(13+1) ^^^ 5124) := by decide +kernel

theorem selectedBound36017 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env36018 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,5124,32768,33831,4097,47249,1025,32769,4096,42116,1044,41002,8329,1044,43169,184,184,43049,40973,5140,173,4112,1212,512]

theorem envBound36018 : H12AffineFastState.Bounded env36018 := by
  intro p hp
  have h : env36018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36017_36018 : H12AffineEnvironment.transform 13 5124 env36017 = env36018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5124 env36017 == env36018) = true)

theorem identity36018 : scanCanonicalize (H12AffineFastState.compose env36018 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 5773) := by decide +kernel

theorem selectedBound36018 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env36019 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,5124,5773,4778,4097,11804,1025,5772,4096,12809,1044,13991,8329,1044,15916,184,184,16036,13952,5140,173,4112,1212,512]

theorem envBound36019 : H12AffineFastState.Bounded env36019 := by
  intro p hp
  have h : env36019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36018_36019 : H12AffineEnvironment.transform 14 5773 env36018 = env36019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 5773 env36018 == env36019) = true)

theorem identity36019 : scanCanonicalize (H12AffineFastState.compose env36019 (packedSelected [0,3,4,8,13] rootPS)) = affineNative (2^(11+1) ^^^ 675) := by decide +kernel

theorem selectedBound36019 : packedSelected [0,3,4,8,13] rootPS < 2^1333 := by decide +kernel

def env36020 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,675,8192,1703,1070,9,674,11804,1025,1071,675,8362,1044,9220,8329,1044,11407,184,184,11271,9251,1719,173,691,1212,512]

theorem envBound36020 : H12AffineFastState.Bounded env36020 := by
  intro p hp
  have h : env36020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36019_36020 : H12AffineEnvironment.transform 11 675 env36019 = env36020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 675 env36019 == env36020) = true)

theorem identity36020 : scanCanonicalize (H12AffineFastState.compose env36020 (packedSelected [2,4,5,8,9,11,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 2601) := by decide +kernel

theorem selectedBound36020 : packedSelected [2,4,5,8,9,11,12,15] rootPS < 2^1333 := by decide +kernel

def env36021 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,675,2601,1703,1070,9,674,1077,1025,1071,675,2691,1044,3629,2720,1044,1702,184,184,1582,3594,1719,173,691,1212,512]

theorem envBound36021 : H12AffineFastState.Bounded env36021 := by
  intro p hp
  have h : env36021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36020_36021 : H12AffineEnvironment.transform 12 2601 env36020 = env36021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2601 env36020 == env36021) = true)

theorem identity36021 : scanCanonicalize (H12AffineFastState.compose env36021 (packedSelected [1,3,5,7,8,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 561) := by decide +kernel

theorem selectedBound36021 : packedSelected [1,3,5,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env36022 : List Nat := [2,4,8,16,32,17,128,173,512,1024,561,675,24,1703,1070,9,674,1077,1025,1071,675,178,1044,1052,145,1044,1702,184,184,1582,1083,1719,173,691,1212,512]

theorem envBound36022 : H12AffineFastState.Bounded env36022 := by
  intro p hp
  have h : env36022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36021_36022 : H12AffineEnvironment.transform 10 561 env36021 = env36022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 561 env36021 == env36022) = true)

theorem identity36022 : scanCanonicalize (H12AffineFastState.compose env36022 (packedSelected [1,3,4,5,6,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 140) := by decide +kernel

theorem selectedBound36022 : packedSelected [1,3,4,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env36023 : List Nat := [2,4,8,16,32,17,128,173,512,140,561,675,24,555,162,9,674,185,141,163,675,178,152,144,145,152,554,184,184,674,183,571,173,691,48,512]

theorem envBound36023 : H12AffineFastState.Bounded env36023 := by
  intro p hp
  have h : env36023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36022_36023 : H12AffineEnvironment.transform 9 140 env36022 = env36023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 140 env36022 == env36023) = true)

theorem identity36023 : scanCanonicalize (H12AffineFastState.compose env36023 (packedSelected [0,5,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound36023 : packedSelected [0,5,6] rootPS < 2^1333 := by decide +kernel

def env36024 : List Nat := [2,4,8,16,32,17,9,36,512,5,561,554,24,555,43,9,555,48,4,42,554,59,17,25,24,17,554,49,49,555,62,571,36,570,48,512]

theorem envBound36024 : H12AffineFastState.Bounded env36024 := by
  intro p hp
  have h : env36024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36023_36024 : H12AffineEnvironment.transform 6 9 env36023 = env36024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env36023 == env36024) = true)

theorem identity36024 : scanCanonicalize (H12AffineFastState.compose env36024 (packedSelected [2,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound36024 : packedSelected [2,3,4] rootPS < 2^1333 := by decide +kernel

def env36025 : List Nat := [2,4,8,16,32,17,9,36,0,5,49,42,24,43,43,9,43,48,4,42,42,59,17,25,24,17,42,49,49,43,62,59,36,58,48,0]

theorem envBound36025 : H12AffineFastState.Bounded env36025 := by
  intro p hp
  have h : env36025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36024_36025 : H12AffineEnvironment.transform 8 0 env36024 = env36025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env36024 == env36025) = true)

theorem identity36025 : scanCanonicalize (H12AffineFastState.compose env36025 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound36025 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env36026 : List Nat := [2,4,8,10,32,11,9,36,0,5,43,42,2,43,43,9,43,42,4,42,42,33,11,3,2,11,42,43,43,43,36,33,36,32,42,0]

theorem envBound36026 : H12AffineFastState.Bounded env36026 := by
  intro p hp
  have h : env36026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36025_36026 : H12AffineEnvironment.transform 3 10 env36025 = env36026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env36025 == env36026) = true)

theorem identity36026 : scanCanonicalize (H12AffineFastState.compose env36026 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound36026 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36027 : List Nat := [2,4,4,6,32,7,5,36,0,5,39,38,2,39,39,5,39,38,4,38,38,33,7,3,2,7,38,39,39,39,36,33,36,32,38,0]

theorem envBound36027 : H12AffineFastState.Bounded env36027 := by
  intro p hp
  have h : env36027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36026_36027 : H12AffineEnvironment.transform 2 4 env36026 = env36027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env36026 == env36027) = true)

theorem identity36027 : scanCanonicalize (H12AffineFastState.compose env36027 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound36027 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36028 : List Nat := [2,4,4,6,7,7,5,3,0,5,0,1,2,0,0,5,0,1,4,1,1,6,7,3,2,7,1,0,0,0,3,6,3,7,1,0]

theorem envBound36028 : H12AffineFastState.Bounded env36028 := by
  intro p hp
  have h : env36028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36027_36028 : H12AffineEnvironment.transform 4 7 env36027 = env36028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env36027 == env36028) = true)

def env36029 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147520,41002,143497,20497,493034,148801,148800,96347,74794,16401,256,131136,1344,135680]

theorem envBound36029 : H12AffineFastState.Bounded env36029 := by
  intro p hp
  have h : env36029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35968_36029 : H12AffineEnvironment.transform 18 136193 env35968 = env36029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136193 env35968 == env36029) = true)

def env36030 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147520,41002,143497,20497,492614,148717,148716,96347,74794,16401,172,131136,1260,135680]

theorem envBound36030 : H12AffineFastState.Bounded env36030 := by
  intro p hp
  have h : env36030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36029_36030 : H12AffineEnvironment.transform 7 172 env36029 = env36030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env36029 == env36030) = true)

def env36031 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61569,147472,41002,143497,20497,492566,148669,148668,96267,74794,16401,172,131088,1212,135680]

theorem envBound36031 : H12AffineFastState.Bounded env36031 := by
  intro p hp
  have h : env36031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36030_36031 : H12AffineEnvironment.transform 5 16 env36030 = env36031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env36030 == env36031) = true)

theorem identity36031 : scanCanonicalize (H12AffineFastState.compose env36031 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 45217) := by decide +kernel

theorem selectedBound36031 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env36032 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,45217,262144,42144,32769,4096,61569,61617,41002,32808,20497,341175,62492,62493,96267,74794,16401,172,45233,1212,41633]

theorem envBound36032 : H12AffineFastState.Bounded env36032 := by
  intro p hp
  have h : env36032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36031_36032 : H12AffineEnvironment.transform 16 45217 env36031 = env36032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45217 env36031 == env36032) = true)

theorem identity36032 : scanCanonicalize (H12AffineFastState.compose env36032 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound36032 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env36033 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1213,32768,65536,45217,262144,42144,32769,4096,46140,46092,41002,32808,5292,341175,45217,45216,81078,74794,1196,172,45233,1212,41633]

theorem envBound36033 : H12AffineFastState.Bounded env36033 := by
  intro p hp
  have h : env36033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36032_36033 : H12AffineEnvironment.transform 13 1213 env36032 = env36033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env36032 == env36033) = true)

theorem identity36033 : scanCanonicalize (H12AffineFastState.compose env36033 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 33830) := by decide +kernel

theorem selectedBound36033 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env36034 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1213,32768,33830,45217,262144,42144,32769,4096,46140,46092,41002,32808,5292,307345,45217,45216,47248,40972,1196,172,45233,1212,41633]

theorem envBound36034 : H12AffineFastState.Bounded env36034 := by
  intro p hp
  have h : env36034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36033_36034 : H12AffineEnvironment.transform 15 33830 env36033 = env36034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33830 env36033 == env36034) = true)

theorem identity36034 : scanCanonicalize (H12AffineFastState.compose env36034 (packedSelected [4,9,20] rootPS)) = affineNative (2^(11+1) ^^^ 185) := by decide +kernel

theorem selectedBound36034 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env36035 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,185,8192,1213,32768,33830,40984,262144,42144,32769,185,42117,42165,41002,32808,1045,303144,40984,40985,43049,40972,1196,172,40968,1212,41633]

theorem envBound36035 : H12AffineFastState.Bounded env36035 := by
  intro p hp
  have h : env36035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36034_36035 : H12AffineEnvironment.transform 11 185 env36034 = env36035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 185 env36034 == env36035) = true)

theorem identity36035 : scanCanonicalize (H12AffineFastState.compose env36035 (packedSelected [1,3,5,6,8,13] rootPS)) = affineNative (2^(17+1) ^^^ 43048) := by decide +kernel

theorem selectedBound36035 : packedSelected [1,3,5,6,8,13] rootPS < 2^1333 := by decide +kernel

def env36036 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,185,8192,1213,32768,33830,40984,43048,42144,32769,185,42117,42165,41002,32808,1045,2048,40984,40985,43049,40972,1196,172,40968,1212,41633]

theorem envBound36036 : H12AffineFastState.Bounded env36036 := by
  intro p hp
  have h : env36036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36035_36036 : H12AffineEnvironment.transform 17 43048 env36035 = env36036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43048 env36035 == env36036) = true)

theorem identity36036 : scanCanonicalize (H12AffineFastState.compose env36036 (packedSelected [2,3,4,6,8,9] rootPS)) = affineNative (2^(8+1) ^^^ 162) := by decide +kernel

theorem selectedBound36036 : packedSelected [2,3,4,6,8,9] rootPS < 2^1333 := by decide +kernel

def env36037 : List Nat := [2,4,8,16,32,16,128,172,162,1024,2048,185,8192,1213,32768,33830,40984,43048,42144,32769,185,42117,42165,41002,32808,1045,2048,40984,40985,43049,40972,1196,172,40968,1212,40963]

theorem envBound36037 : H12AffineFastState.Bounded env36037 := by
  intro p hp
  have h : env36037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36036_36037 : H12AffineEnvironment.transform 8 162 env36036 = env36037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 162 env36036 == env36037) = true)

theorem identity36037 : scanCanonicalize (H12AffineFastState.compose env36037 (packedSelected [0,1,3,6,7,10] rootPS)) = affineNative (2^(12+1) ^^^ 2051) := by decide +kernel

theorem selectedBound36037 : packedSelected [0,1,3,6,7,10] rootPS < 2^1333 := by decide +kernel

def env36038 : List Nat := [2,4,8,16,32,16,128,172,162,1024,2048,185,2051,1213,32768,33830,34843,32811,36003,32769,185,35974,36022,34857,32808,1045,2048,34843,34842,32810,34831,1196,172,34827,1212,34816]

theorem envBound36038 : H12AffineFastState.Bounded env36038 := by
  intro p hp
  have h : env36038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36037_36038 : H12AffineEnvironment.transform 12 2051 env36037 = env36038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2051 env36037 == env36038) = true)

theorem identity36038 : scanCanonicalize (H12AffineFastState.compose env36038 (packedSelected [1,2,4,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 185) := by decide +kernel

theorem selectedBound36038 : packedSelected [1,2,4,5,7] rootPS < 2^1333 := by decide +kernel

def env36039 : List Nat := [2,4,8,16,32,16,128,172,162,1024,185,185,186,1213,32768,33830,32930,32811,33818,32769,185,33855,33807,32912,32808,1045,185,32930,32931,32810,32950,1196,172,32946,1212,32953]

theorem envBound36039 : H12AffineFastState.Bounded env36039 := by
  intro p hp
  have h : env36039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36038_36039 : H12AffineEnvironment.transform 10 185 env36038 = env36039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 185 env36038 == env36039) = true)

theorem identity36039 : scanCanonicalize (H12AffineFastState.compose env36039 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound36039 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env36040 : List Nat := [2,4,8,16,32,16,57,21,27,1024,0,0,3,1028,32768,33830,32795,32811,33818,32769,0,33855,33807,32809,32808,1045,0,32795,32794,32810,32783,1045,21,32779,1029,32768]

theorem envBound36040 : H12AffineFastState.Bounded env36040 := by
  intro p hp
  have h : env36040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36039_36040 : H12AffineEnvironment.transform 6 57 env36039 = env36040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env36039 == env36040) = true)

theorem identity36040 : scanCanonicalize (H12AffineFastState.compose env36040 (packedSelected [3,5] rootPS)) = affineNative (2^(9+1) ^^^ 46) := by decide +kernel

theorem selectedBound36040 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env36041 : List Nat := [2,4,8,16,32,16,57,21,27,46,0,0,3,42,32768,32776,32795,32811,32820,32769,0,32785,32801,32809,32808,59,0,32795,32794,32810,32783,59,21,32779,43,32768]

theorem envBound36041 : H12AffineFastState.Bounded env36041 := by
  intro p hp
  have h : env36041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36040_36041 : H12AffineEnvironment.transform 9 46 env36040 = env36041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 46 env36040 == env36041) = true)

theorem identity36041 : scanCanonicalize (H12AffineFastState.compose env36041 (packedSelected [3,8] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound36041 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env36042 : List Nat := [2,4,8,16,10,16,19,21,27,4,0,0,3,0,32768,32776,32795,32769,32798,32769,0,32785,32779,32771,32770,17,0,32795,32794,32768,32783,17,21,32779,1,32768]

theorem envBound36042 : H12AffineFastState.Bounded env36042 := by
  intro p hp
  have h : env36042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36041_36042 : H12AffineEnvironment.transform 4 10 env36041 = env36042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env36041 == env36042) = true)

theorem identity36042 : scanCanonicalize (H12AffineFastState.compose env36042 (packedSelected [1,2] rootPS)) = affineNative (2^(14+1) ^^^ 22) := by decide +kernel

theorem selectedBound36042 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env36043 : List Nat := [2,4,8,16,10,16,19,21,27,4,0,0,3,0,22,30,13,23,8,23,0,7,29,21,20,17,0,13,12,22,25,17,21,29,1,22]

theorem envBound36043 : H12AffineFastState.Bounded env36043 := by
  intro p hp
  have h : env36043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36042_36043 : H12AffineEnvironment.transform 14 22 env36042 = env36043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 22 env36042 == env36043) = true)

theorem identity36043 : scanCanonicalize (H12AffineFastState.compose env36043 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound36043 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env36044 : List Nat := [2,4,8,10,10,10,9,15,1,4,0,0,3,0,12,4,13,13,8,13,0,7,7,15,14,11,0,13,12,12,3,11,15,7,1,12]

theorem envBound36044 : H12AffineFastState.Bounded env36044 := by
  intro p hp
  have h : env36044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36043_36044 : H12AffineEnvironment.transform 3 10 env36043 = env36044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env36043 == env36044) = true)

def env36045 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61568,147473,41002,143497,20497,492567,148668,148669,96266,74794,16401,172,131089,1213,135680]

theorem envBound36045 : H12AffineFastState.Bounded env36045 := by
  intro p hp
  have h : env36045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36030_36045 : H12AffineEnvironment.transform 5 17 env36030 = env36045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env36030 == env36045) = true)

theorem identity36045 : scanCanonicalize (H12AffineFastState.compose env36045 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 137353) := by decide +kernel

theorem selectedBound36045 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env36046 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,137353,136193,32769,4096,61568,147473,41002,143497,20497,105630,148668,148669,96266,74794,16401,172,131089,1213,135680]

theorem envBound36046 : H12AffineFastState.Bounded env36046 := by
  intro p hp
  have h : env36046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36045_36046 : H12AffineEnvironment.transform 17 137353 env36045 = env36046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137353 env36045 == env36046) = true)

theorem identity36046 : scanCanonicalize (H12AffineFastState.compose env36046 (packedSelected [1,5,8,18,19,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 13374) := by decide +kernel

theorem selectedBound36046 : packedSelected [1,5,8,18,19,23,24,26] rootPS < 2^1333 := by decide +kernel

def env36047 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,13374,131072,137353,136193,32769,4096,61568,147473,41002,143497,20497,43168,148668,148669,19508,4116,16401,172,131089,1213,135680]

theorem envBound36047 : H12AffineFastState.Bounded env36047 := by
  intro p hp
  have h : env36047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36046_36047 : H12AffineEnvironment.transform 15 13374 env36046 = env36047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13374 env36046 == env36047) = true)

theorem identity36047 : scanCanonicalize (H12AffineFastState.compose env36047 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound36047 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env36048 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1213,32768,13374,131072,137353,136193,32769,4096,46141,132268,41002,143497,5292,43168,131073,131072,2185,4116,1196,172,131089,1213,135680]

theorem envBound36048 : H12AffineFastState.Bounded env36048 := by
  intro p hp
  have h : env36048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36047_36048 : H12AffineEnvironment.transform 13 1213 env36047 = env36048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env36047 == env36048) = true)

theorem identity36048 : scanCanonicalize (H12AffineFastState.compose env36048 (packedSelected [13,17] rootPS)) = affineNative (2^(16+1) ^^^ 46245) := by decide +kernel

theorem selectedBound36048 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env36049 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1213,32768,13374,46245,44076,41124,32769,4096,46141,45065,41002,33836,5292,43168,46244,46245,2185,4116,1196,172,46260,1213,42661]

theorem envBound36049 : H12AffineFastState.Bounded env36049 := by
  intro p hp
  have h : env36049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36048_36049 : H12AffineEnvironment.transform 16 46245 env36048 = env36049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46245 env36048 == env36049) = true)

theorem identity36049 : scanCanonicalize (H12AffineFastState.compose env36049 (packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 14523) := by decide +kernel

theorem selectedBound36049 : packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env36050 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1213,14523,13374,3102,5271,6175,14522,4096,3206,2226,6289,15511,5292,4123,3103,3102,2185,4116,1196,172,3087,1213,7710]

theorem envBound36050 : H12AffineFastState.Bounded env36050 := by
  intro p hp
  have h : env36050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36049_36050 : H12AffineEnvironment.transform 14 14523 env36049 = env36050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 14523 env36049 == env36050) = true)

theorem identity36050 : scanCanonicalize (H12AffineFastState.compose env36050 (packedSelected [1,4,5,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound36050 : packedSelected [1,4,5,9,16] rootPS < 2^1333 := by decide +kernel

def env36051 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,24,1213,6307,5158,3102,5271,6175,6306,4096,3206,2226,6289,7311,5292,4123,3103,3102,2185,4116,1196,172,3087,1213,7710]

theorem envBound36051 : H12AffineFastState.Bounded env36051 := by
  intro p hp
  have h : env36051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36050_36051 : H12AffineEnvironment.transform 12 24 env36050 = env36051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env36050 == env36051) = true)

theorem identity36051 : scanCanonicalize (H12AffineFastState.compose env36051 (packedSelected [0,2,3,4,5,6,10,13] rootPS)) = affineNative (2^(11+1) ^^^ 3223) := by decide +kernel

theorem selectedBound36051 : packedSelected [0,2,3,4,5,6,10,13] rootPS < 2^1333 := by decide +kernel

def env36052 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,3223,24,1213,1076,2225,3102,2048,1160,1077,3223,3206,2226,1030,24,2107,3212,3103,3102,2185,3203,1196,172,3087,1213,649]

theorem envBound36052 : H12AffineFastState.Bounded env36052 := by
  intro p hp
  have h : env36052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36051_36052 : H12AffineEnvironment.transform 11 3223 env36051 = env36052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3223 env36051 == env36052) = true)

theorem identity36052 : scanCanonicalize (H12AffineFastState.compose env36052 (packedSelected [7,9] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound36052 : packedSelected [7,9] rootPS < 2^1333 := by decide +kernel

def env36053 : List Nat := [2,4,8,16,32,17,128,172,26,1024,2048,3223,24,1213,1076,2225,3102,2048,1160,1077,3223,3206,2226,1030,24,2107,3212,3103,3102,2185,3203,1196,172,3087,1213,147]

theorem envBound36053 : H12AffineFastState.Bounded env36053 := by
  intro p hp
  have h : env36053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36052_36053 : H12AffineEnvironment.transform 8 26 env36052 = env36053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env36052 == env36053) = true)

theorem identity36053 : scanCanonicalize (H12AffineFastState.compose env36053 (packedSelected [0,1,3,4,6,10] rootPS)) = affineNative (2^(9+1) ^^^ 140) := by decide +kernel

theorem selectedBound36053 : packedSelected [0,1,3,4,6,10] rootPS < 2^1333 := by decide +kernel

def env36054 : List Nat := [2,4,8,16,32,17,128,172,26,140,2048,2075,24,49,184,2225,2194,2048,4,185,2075,2058,2226,138,24,2107,2048,2195,2194,2185,2063,32,172,2179,49,147]

theorem envBound36054 : H12AffineFastState.Bounded env36054 := by
  intro p hp
  have h : env36054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36053_36054 : H12AffineEnvironment.transform 9 140 env36053 = env36054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 140 env36053 == env36054) = true)

theorem identity36054 : scanCanonicalize (H12AffineFastState.compose env36054 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 163) := by decide +kernel

theorem selectedBound36054 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env36055 : List Nat := [2,4,8,16,32,17,128,172,26,140,163,184,24,49,184,18,49,163,4,185,184,169,17,138,24,152,163,48,49,42,172,32,172,32,49,147]

theorem envBound36055 : H12AffineFastState.Bounded env36055 := by
  intro p hp
  have h : env36055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36054_36055 : H12AffineEnvironment.transform 10 163 env36054 = env36055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 163 env36054 == env36055) = true)

theorem identity36055 : scanCanonicalize (H12AffineFastState.compose env36055 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound36055 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env36056 : List Nat := [2,4,8,16,10,17,128,134,26,140,137,146,24,27,146,18,27,137,4,147,146,131,17,138,24,152,137,26,27,0,134,10,134,10,27,147]

theorem envBound36056 : H12AffineFastState.Bounded env36056 := by
  intro p hp
  have h : env36056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36055_36056 : H12AffineEnvironment.transform 4 10 env36055 = env36056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env36055 == env36056) = true)

theorem identity36056 : scanCanonicalize (H12AffineFastState.compose env36056 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound36056 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36057 : List Nat := [2,4,8,16,10,17,19,21,26,31,26,1,24,27,1,18,27,26,4,0,1,16,17,25,24,11,26,26,27,0,21,10,21,10,27,0]

theorem envBound36057 : H12AffineFastState.Bounded env36057 := by
  intro p hp
  have h : env36057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36056_36057 : H12AffineEnvironment.transform 6 19 env36056 = env36057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env36056 == env36057) = true)

theorem identity36057 : scanCanonicalize (H12AffineFastState.compose env36057 (packedSelected [0,1,4] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound36057 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env36058 : List Nat := [2,4,8,13,10,12,14,8,7,2,7,1,5,6,1,15,6,7,4,0,1,13,12,4,5,11,7,7,6,0,8,10,8,10,6,0]

theorem envBound36058 : H12AffineFastState.Bounded env36058 := by
  intro p hp
  have h : env36058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36057_36058 : H12AffineEnvironment.transform 3 13 env36057 = env36058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env36057 == env36058) = true)

def env36059 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147520,41002,143497,20497,492615,148716,148717,96347,74794,16401,173,131136,1261,135680]

theorem envBound36059 : H12AffineFastState.Bounded env36059 := by
  intro p hp
  have h : env36059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36029_36059 : H12AffineEnvironment.transform 7 173 env36029 = env36059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env36029 == env36059) = true)

def env36060 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61569,147472,41002,143497,20497,492567,148668,148669,96267,74794,16401,173,131088,1213,135680]

theorem envBound36060 : H12AffineFastState.Bounded env36060 := by
  intro p hp
  have h : env36060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36059_36060 : H12AffineEnvironment.transform 5 16 env36059 = env36060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env36059 == env36060) = true)

theorem identity36060 : scanCanonicalize (H12AffineFastState.compose env36060 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 114722) := by decide +kernel

theorem selectedBound36060 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env36061 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,114722,262144,119843,32769,4096,61569,98354,41002,127147,20497,279605,99486,99487,96267,74794,16401,173,114738,1213,119330]

theorem envBound36061 : H12AffineFastState.Bounded env36061 := by
  intro p hp
  have h : env36061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36060_36061 : H12AffineEnvironment.transform 16 114722 env36060 = env36061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114722 env36060 == env36061) = true)

theorem identity36061 : scanCanonicalize (H12AffineFastState.compose env36061 (packedSelected [3,10,16,18,19,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 92338) := by decide +kernel

theorem selectedBound36061 : packedSelected [3,10,16,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env36062 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,114722,92338,119843,32769,4096,61569,98354,41002,127147,20497,76935,99486,99487,96267,74794,16401,173,114738,1213,119330]

theorem envBound36062 : H12AffineFastState.Bounded env36062 := by
  intro p hp
  have h : env36062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36061_36062 : H12AffineEnvironment.transform 17 92338 env36061 = env36062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 92338 env36061 == env36062) = true)

theorem identity36062 : scanCanonicalize (H12AffineFastState.compose env36062 (packedSelected [7,16,18,19,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53282) := by decide +kernel

theorem selectedBound36062 : packedSelected [7,16,18,19,23,26,27] rootPS < 2^1333 := by decide +kernel

def env36063 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,53282,4096,47248,1025,32769,4096,61569,20496,41002,8329,20497,64677,21692,21693,43049,62472,16401,173,4112,1213,512]

theorem envBound36063 : H12AffineFastState.Bounded env36063 := by
  intro p hp
  have h : env36063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36062_36063 : H12AffineEnvironment.transform 15 53282 env36062 = env36063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53282 env36062 == env36063) = true)

theorem identity36063 : scanCanonicalize (H12AffineFastState.compose env36063 (packedSelected [4,9,16] rootPS)) = affineNative (2^(13+1) ^^^ 5124) := by decide +kernel

theorem selectedBound36063 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env36064 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,5124,32768,33830,4096,47248,1025,32769,4096,42117,1044,41002,8329,1045,43169,184,185,43049,40972,5141,173,4112,1213,512]

theorem envBound36064 : H12AffineFastState.Bounded env36064 := by
  intro p hp
  have h : env36064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36063_36064 : H12AffineEnvironment.transform 13 5124 env36063 = env36064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5124 env36063 == env36064) = true)

theorem identity36064 : scanCanonicalize (H12AffineFastState.compose env36064 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 5677) := by decide +kernel

theorem selectedBound36064 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env36065 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,5677,5124,32768,33830,4096,36541,1025,32769,4096,37544,1044,38407,5796,1045,40588,184,185,40452,38433,5141,173,4112,1213,512]

theorem envBound36065 : H12AffineFastState.Bounded env36065 := by
  intro p hp
  have h : env36065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36064_36065 : H12AffineEnvironment.transform 12 5677 env36064 = env36065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5677 env36064 == env36065) = true)

theorem identity36065 : scanCanonicalize (H12AffineFastState.compose env36065 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(14+1) ^^^ 5270) := by decide +kernel

theorem selectedBound36065 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env36066 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,5677,5124,5270,4272,4096,6699,1025,5271,4096,1598,1044,657,5796,1045,2586,184,185,2706,695,5141,173,4112,1213,512]

theorem envBound36066 : H12AffineFastState.Bounded env36066 := by
  intro p hp
  have h : env36066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36065_36066 : H12AffineEnvironment.transform 14 5270 env36065 = env36066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 5270 env36065 == env36066) = true)

theorem identity36066 : scanCanonicalize (H12AffineFastState.compose env36066 (packedSelected [1,3,13] rootPS)) = affineNative (2^(11+1) ^^^ 674) := by decide +kernel

theorem selectedBound36066 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env36067 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,674,1167,1702,1588,530,674,2185,1025,1589,674,1598,1044,657,1030,1045,2586,184,185,2706,695,1719,173,690,1213,512]

theorem envBound36067 : H12AffineFastState.Bounded env36067 := by
  intro p hp
  have h : env36067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36066_36067 : H12AffineEnvironment.transform 11 674 env36066 = env36067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 674 env36066 == env36067) = true)

theorem identity36067 : scanCanonicalize (H12AffineFastState.compose env36067 (packedSelected [1,2,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 1703) := by decide +kernel

theorem selectedBound36067 : packedSelected [1,2,5,6] rootPS < 2^1333 := by decide +kernel

def env36068 : List Nat := [2,4,8,16,32,16,128,173,512,1024,1703,674,1167,1702,1588,530,674,1582,1025,1589,674,1598,1044,657,1030,1045,1213,184,185,1077,695,1719,173,690,1213,512]

theorem envBound36068 : H12AffineFastState.Bounded env36068 := by
  intro p hp
  have h : env36068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36067_36068 : H12AffineEnvironment.transform 10 1703 env36067 = env36068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1703 env36067 == env36068) = true)

theorem identity36068 : scanCanonicalize (H12AffineFastState.compose env36068 (packedSelected [0,1,2,3,7] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound36068 : packedSelected [0,1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env36069 : List Nat := [2,4,8,16,32,16,128,173,0,1024,1191,162,1167,1190,1076,18,162,1070,1025,1077,162,1086,1044,145,1030,1045,1213,184,185,1077,183,1207,173,178,1213,0]

theorem envBound36069 : H12AffineFastState.Bounded env36069 := by
  intro p hp
  have h : env36069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36068_36069 : H12AffineEnvironment.transform 8 0 env36068 = env36069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env36068 == env36069) = true)

theorem identity36069 : scanCanonicalize (H12AffineFastState.compose env36069 (packedSelected [0,1,2] rootPS)) = affineNative (2^(9+1) ^^^ 151) := by decide +kernel

theorem selectedBound36069 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env36070 : List Nat := [2,4,8,16,32,16,128,173,0,151,48,162,24,49,163,18,162,185,150,162,162,169,131,145,145,130,42,184,185,162,183,32,173,178,42,0]

theorem envBound36070 : H12AffineFastState.Bounded env36070 := by
  intro p hp
  have h : env36070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36069_36070 : H12AffineEnvironment.transform 9 151 env36069 = env36070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 151 env36069 == env36070) = true)

theorem identity36070 : scanCanonicalize (H12AffineFastState.compose env36070 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound36070 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env36071 : List Nat := [2,4,8,11,32,11,128,173,0,140,43,162,3,42,163,9,162,162,141,162,162,169,131,138,138,130,42,163,162,162,172,32,173,169,42,0]

theorem envBound36071 : H12AffineFastState.Bounded env36071 := by
  intro p hp
  have h : env36071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36070_36071 : H12AffineEnvironment.transform 3 11 env36070 = env36071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env36070 == env36071) = true)

theorem identity36071 : scanCanonicalize (H12AffineFastState.compose env36071 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound36071 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env36072 : List Nat := [2,4,8,11,11,11,128,134,0,140,0,137,3,1,136,9,137,137,141,137,137,130,131,138,138,130,1,136,137,137,135,11,134,130,1,0]

theorem envBound36072 : H12AffineFastState.Bounded env36072 := by
  intro p hp
  have h : env36072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36071_36072 : H12AffineEnvironment.transform 4 11 env36071 = env36072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env36071 == env36072) = true)

theorem identity36072 : scanCanonicalize (H12AffineFastState.compose env36072 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 14) := by decide +kernel

theorem selectedBound36072 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36073 : List Nat := [2,4,8,11,11,11,14,8,0,2,0,7,3,1,6,9,7,7,3,7,7,12,13,4,4,12,1,6,7,7,9,11,8,12,1,0]

theorem envBound36073 : H12AffineFastState.Bounded env36073 := by
  intro p hp
  have h : env36073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36072_36073 : H12AffineEnvironment.transform 6 14 env36072 = env36073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 14 env36072 == env36073) = true)

theorem identity36073 : scanCanonicalize (H12AffineFastState.compose env36073 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound36073 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env36074 : List Nat := [2,2,8,11,11,11,8,8,0,2,0,1,3,1,0,9,1,1,3,1,1,10,11,2,2,10,1,0,1,1,9,11,8,10,1,0]

theorem envBound36074 : H12AffineFastState.Bounded env36074 := by
  intro p hp
  have h : env36074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36073_36074 : H12AffineEnvironment.transform 1 2 env36073 = env36074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env36073 == env36074) = true)

def env36075 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61568,147473,41002,143497,20497,492566,148669,148668,96266,74794,16401,173,131089,1212,135680]

theorem envBound36075 : H12AffineFastState.Bounded env36075 := by
  intro p hp
  have h : env36075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36059_36075 : H12AffineEnvironment.transform 5 17 env36059 = env36075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env36059 == env36075) = true)

theorem identity36075 : scanCanonicalize (H12AffineFastState.compose env36075 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 223243) := by decide +kernel

theorem selectedBound36075 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env36076 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,223243,136193,32769,4096,61568,147473,41002,143497,20497,60445,148669,148668,96266,74794,16401,173,131089,1212,135680]

theorem envBound36076 : H12AffineFastState.Bounded env36076 := by
  intro p hp
  have h : env36076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36075_36076 : H12AffineEnvironment.transform 17 223243 env36075 = env36076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223243 env36075 == env36076) = true)

theorem identity36076 : scanCanonicalize (H12AffineFastState.compose env36076 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 28803) := by decide +kernel

theorem selectedBound36076 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env36077 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,28803,131072,137352,136193,32769,4096,61568,147473,41002,143497,20497,60445,148669,148668,2185,21673,16401,173,131089,1212,135680]

theorem envBound36077 : H12AffineFastState.Bounded env36077 := by
  intro p hp
  have h : env36077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36076_36077 : H12AffineEnvironment.transform 15 28803 env36076 = env36077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28803 env36076 == env36077) = true)

theorem identity36077 : scanCanonicalize (H12AffineFastState.compose env36077 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(14+1) ^^^ 12313) := by decide +kernel

theorem selectedBound36077 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env36078 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,12313,28803,131072,137352,136193,12312,4096,16537,147473,4147,143497,20497,23556,148669,148668,2185,21673,16401,173,131089,1212,135680]

theorem envBound36078 : H12AffineFastState.Bounded env36078 := by
  intro p hp
  have h : env36078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36077_36078 : H12AffineEnvironment.transform 14 12313 env36077 = env36078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12313 env36077 == env36078) = true)

theorem identity36078 : scanCanonicalize (H12AffineFastState.compose env36078 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound36078 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env36079 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1212,12313,13375,131072,137352,136193,12312,4096,1061,132269,4147,143497,5293,6328,131073,131072,2185,4117,1197,173,131089,1212,135680]

theorem envBound36079 : H12AffineFastState.Bounded env36079 := by
  intro p hp
  have h : env36079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36078_36079 : H12AffineEnvironment.transform 13 1212 env36078 = env36079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env36078 == env36079) = true)

theorem identity36079 : scanCanonicalize (H12AffineFastState.compose env36079 (packedSelected [0,4,5,7,8,9,10,13] rootPS)) = affineNative (2^(12+1) ^^^ 6282) := by decide +kernel

theorem selectedBound36079 : packedSelected [0,4,5,7,8,9,10,13] rootPS < 2^1333 := by decide +kernel

def env36080 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,6282,1212,2195,3253,131072,137352,136193,2194,4096,1061,132269,4147,133123,5293,6328,131073,131072,2185,4117,1197,173,131089,1212,135680]

theorem envBound36080 : H12AffineFastState.Bounded env36080 := by
  intro p hp
  have h : env36080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36079_36080 : H12AffineEnvironment.transform 12 6282 env36079 = env36080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6282 env36079 == env36080) = true)

theorem identity36080 : scanCanonicalize (H12AffineFastState.compose env36080 (packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS)) = affineNative (2^(16+1) ^^^ 1213) := by decide +kernel

end H12CloudChart2