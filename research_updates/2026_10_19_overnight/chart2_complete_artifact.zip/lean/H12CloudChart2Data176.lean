import H12CloudChart2Data175

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env44100 : List Nat := [2,4,8,16,32,16,9,20,512,5,2048,2049,2099,1,42,8,0,1,5,43,2049,17,16,2073,2099,16,42,0,2048,2096,2111,58,21,2065,1,512]

theorem envBound44100 : H12AffineFastState.Bounded env44100 := by
  intro p hp
  have h : env44100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44099_44100 : H12AffineEnvironment.transform 11 2049 env44099 = env44100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2049 env44099 == env44100) = true)

theorem identity44100 : scanCanonicalize (H12AffineFastState.compose env44100 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 539) := by decide +kernel

theorem selectedBound44100 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env44101 : List Nat := [2,4,8,16,32,16,9,20,512,5,539,538,552,1,42,8,0,1,5,43,538,17,16,514,552,16,42,0,539,555,548,58,21,522,1,512]

theorem envBound44101 : H12AffineFastState.Bounded env44101 := by
  intro p hp
  have h : env44101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44100_44101 : H12AffineEnvironment.transform 10 539 env44100 = env44101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 539 env44100 == env44101) = true)

theorem identity44101 : scanCanonicalize (H12AffineFastState.compose env44101 (packedSelected [3,5] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound44101 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env44102 : List Nat := [2,4,8,16,32,16,9,20,43,5,48,49,3,1,42,8,0,1,5,43,49,17,16,41,3,16,42,0,48,0,15,58,21,33,1,43]

theorem envBound44102 : H12AffineFastState.Bounded env44102 := by
  intro p hp
  have h : env44102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44101_44102 : H12AffineEnvironment.transform 8 43 env44101 = env44102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env44101 == env44102) = true)

theorem identity44102 : scanCanonicalize (H12AffineFastState.compose env44102 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound44102 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44103 : List Nat := [2,4,8,16,16,16,9,20,27,5,0,1,3,1,26,8,0,1,5,27,1,17,16,25,3,16,26,0,0,0,15,10,21,17,1,27]

theorem envBound44103 : H12AffineFastState.Bounded env44103 := by
  intro p hp
  have h : env44103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44102_44103 : H12AffineEnvironment.transform 4 16 env44102 = env44103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env44102 == env44103) = true)

def env44104 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,4096,8192,1,12556,65536,1,65664,77886,12557,4096,397,16,69648,70054,78142,77840,0,74031,79883,8204,65830,257,74046,0,78639]

theorem envBound44104 : H12AffineFastState.Bounded env44104 := by
  intro p hp
  have h : env44104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44094_44104 : H12AffineEnvironment.transform 5 17 env44094 = env44104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env44094 == env44104) = true)

theorem identity44104 : scanCanonicalize (H12AffineFastState.compose env44104 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 12346) := by decide +kernel

theorem selectedBound44104 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env44105 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,4096,8192,1,12556,12346,1,12474,4,12557,4096,397,16,8234,8604,260,42,0,4373,2097,8204,12572,257,4356,0,789]

theorem envBound44105 : H12AffineFastState.Bounded env44105 := by
  intro p hp
  have h : env44105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44104_44105 : H12AffineEnvironment.transform 15 12346 env44104 = env44105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12346 env44104 == env44105) = true)

def env44106 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1345,65665,77935,13340,4096,476,16,69649,70886,78895,77840,1297,74814,81227,8205,65831,257,74799,1344,79471]

theorem envBound44106 : H12AffineFastState.Bounded env44106 := by
  intro p hp
  have h : env44106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44092_44106 : H12AffineEnvironment.transform 17 65665 env44092 = env44106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env44092 == env44106) = true)

theorem identity44106 : scanCanonicalize (H12AffineFastState.compose env44106 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound44106 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env44107 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,8192,1296,9292,65536,1345,65665,73790,9293,81,476,16,65600,66743,74878,73793,1297,74814,77082,8205,65831,257,74799,1344,75326]

theorem envBound44107 : H12AffineFastState.Bounded env44107 := by
  intro p hp
  have h : env44107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44106_44107 : H12AffineEnvironment.transform 11 81 env44106 = env44107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env44106 == env44107) = true)

def env44108 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1,8192,1296,9244,65536,1297,65665,73790,9245,1,396,16,65552,66743,74798,73745,1297,74814,77082,8205,65831,257,74799,1296,75326]

theorem envBound44108 : H12AffineFastState.Bounded env44108 := by
  intro p hp
  have h : env44108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44107_44108 : H12AffineEnvironment.transform 5 16 env44107 = env44108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env44107 == env44108) = true)

theorem identity44108 : scanCanonicalize (H12AffineFastState.compose env44108 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound44108 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env44109 : List Nat := [2,4,8,16,32,16,128,256,512,5,2048,1,8192,277,8217,65536,276,65665,73790,8216,1,396,16,65552,65714,73771,73745,276,73787,76063,8205,65831,257,73770,277,74299]

theorem envBound44109 : H12AffineFastState.Bounded env44109 := by
  intro p hp
  have h : env44109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44108_44109 : H12AffineEnvironment.transform 9 5 env44108 = env44109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env44108 == env44109) = true)

theorem identity44109 : scanCanonicalize (H12AffineFastState.compose env44109 (packedSelected [2,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 682) := by decide +kernel

theorem selectedBound44109 : packedSelected [2,23,32] rootPS < 2^1333 := by decide +kernel

def env44110 : List Nat := [2,4,8,16,32,16,128,256,512,5,2048,1,8192,277,8217,682,276,555,8852,8216,1,396,16,698,536,8833,8891,276,8849,11189,8205,909,257,8832,277,8337]

theorem envBound44110 : H12AffineFastState.Bounded env44110 := by
  intro p hp
  have h : env44110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44109_44110 : H12AffineEnvironment.transform 15 682 env44109 = env44110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 682 env44109 == env44110) = true)

theorem identity44110 : scanCanonicalize (H12AffineFastState.compose env44110 (packedSelected [0,1,4,7,8,9,13,18,19,23,24,28] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound44110 : packedSelected [0,1,4,7,8,9,13,18,19,23,24,28] rootPS < 2^1333 := by decide +kernel

def env44111 : List Nat := [2,4,8,16,32,16,128,20,512,5,2048,1,8192,1,8217,682,0,555,8852,8216,1,152,16,698,536,8833,8891,0,8849,10913,8205,665,21,8832,1,8337]

theorem envBound44111 : H12AffineFastState.Bounded env44111 := by
  intro p hp
  have h : env44111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44110_44111 : H12AffineEnvironment.transform 7 20 env44110 = env44111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env44110 == env44111) = true)

theorem identity44111 : scanCanonicalize (H12AffineFastState.compose env44111 (packedSelected [0,2,3,5,7,11,17] rootPS)) = affineNative (2^(12+1) ^^^ 2072) := by decide +kernel

theorem selectedBound44111 : packedSelected [0,2,3,5,7,11,17] rootPS < 2^1333 := by decide +kernel

def env44112 : List Nat := [2,4,8,16,32,16,128,20,512,5,2048,1,2072,1,2049,682,0,555,2700,2048,1,152,16,698,536,2713,2723,0,2697,697,2069,665,21,2712,1,2185]

theorem envBound44112 : H12AffineFastState.Bounded env44112 := by
  intro p hp
  have h : env44112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44111_44112 : H12AffineEnvironment.transform 12 2072 env44111 = env44112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2072 env44111 == env44112) = true)

theorem identity44112 : scanCanonicalize (H12AffineFastState.compose env44112 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound44112 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env44113 : List Nat := [2,4,8,16,32,16,128,20,137,5,2048,1,2072,1,2049,35,0,162,2053,2048,1,152,16,51,145,2064,2090,0,2048,48,2069,16,21,2065,1,2185]

theorem envBound44113 : H12AffineFastState.Bounded env44113 := by
  intro p hp
  have h : env44113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44112_44113 : H12AffineEnvironment.transform 8 137 env44112 = env44113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env44112 == env44113) = true)

theorem identity44113 : scanCanonicalize (H12AffineFastState.compose env44113 (packedSelected [2,3,8] rootPS)) = affineNative (2^(10+1) ^^^ 27) := by decide +kernel

theorem selectedBound44113 : packedSelected [2,3,8] rootPS < 2^1333 := by decide +kernel

def env44114 : List Nat := [2,4,8,16,32,16,128,20,137,5,27,1,3,1,26,35,0,162,30,27,1,152,16,51,145,11,49,0,27,48,14,16,21,10,1,146]

theorem envBound44114 : H12AffineFastState.Bounded env44114 := by
  intro p hp
  have h : env44114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44113_44114 : H12AffineEnvironment.transform 10 27 env44113 = env44114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 27 env44113 == env44114) = true)

theorem identity44114 : scanCanonicalize (H12AffineFastState.compose env44114 (packedSelected [1,2,5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound44114 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env44115 : List Nat := [2,4,8,16,17,16,128,20,137,5,27,1,3,1,26,18,0,147,30,27,1,152,16,2,145,11,0,0,27,1,14,16,21,10,1,146]

theorem envBound44115 : H12AffineFastState.Bounded env44115 := by
  intro p hp
  have h : env44115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44114_44115 : H12AffineEnvironment.transform 4 17 env44114 = env44115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env44114 == env44115) = true)

theorem identity44115 : scanCanonicalize (H12AffineFastState.compose env44115 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound44115 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env44116 : List Nat := [2,4,8,16,17,16,9,20,0,5,27,1,3,1,26,18,0,26,30,27,1,17,16,2,24,11,0,0,27,1,14,16,21,10,1,27]

theorem envBound44116 : H12AffineFastState.Bounded env44116 := by
  intro p hp
  have h : env44116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44115_44116 : H12AffineEnvironment.transform 6 9 env44115 = env44116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env44115 == env44116) = true)

theorem identity44116 : scanCanonicalize (H12AffineFastState.compose env44116 (packedSelected [0,1,4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound44116 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env44117 : List Nat := [2,3,8,16,17,16,9,19,0,2,27,1,3,1,26,18,0,26,25,27,1,17,16,2,24,11,0,0,27,1,9,16,18,10,1,27]

theorem envBound44117 : H12AffineFastState.Bounded env44117 := by
  intro p hp
  have h : env44117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44116_44117 : H12AffineEnvironment.transform 1 3 env44116 = env44117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env44116 == env44117) = true)

theorem identity44117 : scanCanonicalize (H12AffineFastState.compose env44117 (packedSelected [0,1,7] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound44117 : packedSelected [0,1,7] rootPS < 2^1333 := by decide +kernel

def env44118 : List Nat := [2,3,8,10,11,10,9,9,0,2,1,1,3,1,0,8,0,0,3,1,1,11,10,2,2,11,0,0,1,1,9,10,8,10,1,1]

theorem envBound44118 : H12AffineFastState.Bounded env44118 := by
  intro p hp
  have h : env44118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44117_44118 : H12AffineEnvironment.transform 3 10 env44117 = env44118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env44117 == env44118) = true)

theorem identity44118 : scanCanonicalize (H12AffineFastState.compose env44118 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound44118 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44119 : List Nat := [0,1,8,8,9,8,9,9,0,0,1,1,1,1,0,8,0,0,1,1,1,9,8,0,0,9,0,0,1,1,9,8,8,8,1,1]

theorem envBound44119 : H12AffineFastState.Bounded env44119 := by
  intro p hp
  have h : env44119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44118_44119 : H12AffineEnvironment.transform 0 0 env44118 = env44119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env44118 == env44119) = true)

theorem identity44119 : scanCanonicalize (H12AffineFastState.compose env44119 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound44119 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44120 : List Nat := [0,1,1,1,0,1,0,0,0,0,1,1,1,1,0,1,0,0,1,1,1,0,1,0,0,0,0,0,1,1,0,1,1,1,1,1]

theorem envBound44120 : H12AffineFastState.Bounded env44120 := by
  intro p hp
  have h : env44120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44119_44120 : H12AffineEnvironment.transform 2 1 env44119 = env44120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env44119 == env44120) = true)

def env44121 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,0,8192,1296,9245,65536,1296,65665,73790,9244,0,397,16,65553,66743,74799,73744,1297,74814,77082,8205,65831,257,74799,1297,75326]

theorem envBound44121 : H12AffineFastState.Bounded env44121 := by
  intro p hp
  have h : env44121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44107_44121 : H12AffineEnvironment.transform 5 17 env44107 = env44121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env44107 == env44121) = true)

theorem identity44121 : scanCanonicalize (H12AffineFastState.compose env44121 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 8250) := by decide +kernel

theorem selectedBound44121 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env44122 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,0,8192,1296,9245,8250,1296,8379,4,9244,0,397,16,8235,9357,1045,42,1297,1028,3360,8205,8477,257,1045,1297,1540]

theorem envBound44122 : H12AffineFastState.Bounded env44122 := by
  intro p hp
  have h : env44122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44121_44122 : H12AffineEnvironment.transform 15 8250 env44121 = env44122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8250 env44121 == env44122) = true)

theorem identity44122 : scanCanonicalize (H12AffineFastState.compose env44122 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound44122 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env44123 : List Nat := [2,4,8,16,32,17,128,256,512,5,2048,0,8192,277,8216,8250,277,8379,4,8217,0,397,16,8235,8328,16,42,276,1,2341,8205,8477,257,16,276,513]

theorem envBound44123 : H12AffineFastState.Bounded env44123 := by
  intro p hp
  have h : env44123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44122_44123 : H12AffineEnvironment.transform 9 5 env44122 = env44123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env44122 == env44123) = true)

theorem identity44123 : scanCanonicalize (H12AffineFastState.compose env44123 (packedSelected [2,3,5,10,11,18] rootPS)) = affineNative (2^(12+1) ^^^ 813) := by decide +kernel

theorem selectedBound44123 : packedSelected [2,3,5,10,11,18] rootPS < 2^1333 := by decide +kernel

def env44124 : List Nat := [2,4,8,16,32,17,128,256,512,5,2048,0,813,277,821,791,277,918,4,820,0,397,16,774,933,16,42,276,1,2341,800,560,257,16,276,513]

theorem envBound44124 : H12AffineFastState.Bounded env44124 := by
  intro p hp
  have h : env44124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44123_44124 : H12AffineEnvironment.transform 12 813 env44123 = env44124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 813 env44123 == env44124) = true)

theorem identity44124 : scanCanonicalize (H12AffineFastState.compose env44124 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound44124 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env44125 : List Nat := [2,4,8,16,32,17,128,256,33,5,2048,0,268,277,276,310,277,439,4,277,0,397,16,295,388,16,42,276,1,2341,257,17,257,16,276,32]

theorem envBound44125 : H12AffineFastState.Bounded env44125 := by
  intro p hp
  have h : env44125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44124_44125 : H12AffineEnvironment.transform 8 33 env44124 = env44125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env44124 == env44125) = true)

theorem identity44125 : scanCanonicalize (H12AffineFastState.compose env44125 (packedSelected [1,2,8] rootPS)) = affineNative (2^(10+1) ^^^ 444) := by decide +kernel

theorem selectedBound44125 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env44126 : List Nat := [2,4,8,16,32,17,128,256,33,5,444,0,268,277,276,310,277,439,4,277,0,397,16,295,388,16,42,276,1,153,257,17,257,16,276,32]

theorem envBound44126 : H12AffineFastState.Bounded env44126 := by
  intro p hp
  have h : env44126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44125_44126 : H12AffineEnvironment.transform 10 444 env44125 = env44126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 444 env44125 == env44126) = true)

theorem identity44126 : scanCanonicalize (H12AffineFastState.compose env44126 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound44126 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env44127 : List Nat := [2,4,8,16,32,17,128,5,33,5,185,0,9,16,17,51,16,178,4,16,0,136,16,34,129,16,42,17,1,153,4,17,4,16,17,32]

theorem envBound44127 : H12AffineFastState.Bounded env44127 := by
  intro p hp
  have h : env44127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44126_44127 : H12AffineEnvironment.transform 7 5 env44126 = env44127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env44126 == env44127) = true)

theorem identity44127 : scanCanonicalize (H12AffineFastState.compose env44127 (packedSelected [2,5] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound44127 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env44128 : List Nat := [2,2,8,16,32,17,128,3,33,3,185,0,9,16,17,51,16,178,2,16,0,136,16,34,129,16,42,17,1,153,2,17,2,16,17,32]

theorem envBound44128 : H12AffineFastState.Bounded env44128 := by
  intro p hp
  have h : env44128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44127_44128 : H12AffineEnvironment.transform 1 2 env44127 = env44128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env44127 == env44128) = true)

theorem identity44128 : scanCanonicalize (H12AffineFastState.compose env44128 (packedSelected [0,1,2,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 11) := by decide +kernel

theorem selectedBound44128 : packedSelected [0,1,2,7,9] rootPS < 2^1333 := by decide +kernel

def env44129 : List Nat := [2,2,8,16,32,17,11,3,33,3,50,0,9,16,17,51,16,57,2,16,0,3,16,34,10,16,42,17,1,18,2,17,2,16,17,32]

theorem envBound44129 : H12AffineFastState.Bounded env44129 := by
  intro p hp
  have h : env44129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44128_44129 : H12AffineEnvironment.transform 6 11 env44128 = env44129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 11 env44128 == env44129) = true)

theorem identity44129 : scanCanonicalize (H12AffineFastState.compose env44129 (packedSelected [0,2,3,7,11] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound44129 : packedSelected [0,2,3,7,11] rootPS < 2^1333 := by decide +kernel

def env44130 : List Nat := [2,2,2,16,32,17,1,3,33,3,50,0,3,16,17,51,16,51,2,16,0,3,16,34,0,16,32,17,1,18,2,17,2,16,17,32]

theorem envBound44130 : H12AffineFastState.Bounded env44130 := by
  intro p hp
  have h : env44130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44129_44130 : H12AffineEnvironment.transform 2 2 env44129 = env44130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env44129 == env44130) = true)

def env44131 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1344,262144,77934,32769,4096,46528,16,266385,70887,78894,77840,1297,74814,81226,365712,308667,257,74798,1344,79470]

theorem envBound44131 : H12AffineFastState.Bounded env44131 := by
  intro p hp
  have h : env44131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44090_44131 : H12AffineEnvironment.transform 13 1297 env44090 = env44131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env44090 == env44131) = true)

theorem identity44131 : scanCanonicalize (H12AffineFastState.compose env44131 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32882) := by decide +kernel

theorem selectedBound44131 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env44132 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,32882,1344,262144,45084,32769,4096,46528,16,266385,38037,46172,45154,1297,42060,48440,267490,308667,257,42076,1344,46620]

theorem envBound44132 : H12AffineFastState.Bounded env44132 := by
  intro p hp
  have h : env44132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44131_44132 : H12AffineEnvironment.transform 15 32882 env44131 = env44132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32882 env44131 == env44132) = true)

def env44133 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32882,1344,262144,42332,32769,1344,41088,16,263633,33237,41244,42274,1297,42060,43128,262562,303355,257,42076,1344,41820]

theorem envBound44133 : H12AffineFastState.Bounded env44133 := by
  intro p hp
  have h : env44133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44132_44133 : H12AffineEnvironment.transform 11 1344 env44132 = env44133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env44132 == env44133) = true)

theorem identity44133 : scanCanonicalize (H12AffineFastState.compose env44133 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 41194) := by decide +kernel

theorem selectedBound44133 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env44134 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32882,1344,41194,42332,32769,1344,41088,16,42299,33237,41244,42274,1297,42060,43128,41288,17,257,42076,1344,41820]

theorem envBound44134 : H12AffineFastState.Bounded env44134 := by
  intro p hp
  have h : env44134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44133_44134 : H12AffineEnvironment.transform 17 41194 env44133 = env44134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 41194 env44133 == env44134) = true)

theorem identity44134 : scanCanonicalize (H12AffineFastState.compose env44134 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound44134 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env44135 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,8540,8494,1344,438,1024,8541,1344,476,16,1127,8329,64,1150,1297,1296,2340,20,17,257,1280,1344,512]

theorem envBound44135 : H12AffineFastState.Bounded env44135 := by
  intro p hp
  have h : env44135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44134_44135 : H12AffineEnvironment.transform 14 8540 env44134 = env44135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env44134 == env44135) = true)

theorem identity44135 : scanCanonicalize (H12AffineFastState.compose env44135 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 85) := by decide +kernel

theorem selectedBound44135 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env44136 : List Nat := [2,4,8,16,32,64,128,256,512,85,2048,277,8192,324,8540,8494,277,438,85,8541,277,476,16,50,8329,64,43,324,325,2340,20,17,257,341,277,512]

theorem envBound44136 : H12AffineFastState.Bounded env44136 := by
  intro p hp
  have h : env44136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44135_44136 : H12AffineEnvironment.transform 9 85 env44135 = env44136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env44135 == env44136) = true)

theorem identity44136 : scanCanonicalize (H12AffineFastState.compose env44136 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 705) := by decide +kernel

theorem selectedBound44136 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env44137 : List Nat := [2,4,8,16,32,64,128,256,512,85,2048,277,705,324,925,1007,277,438,85,924,277,476,16,50,584,64,43,324,325,2340,20,17,257,341,277,512]

theorem envBound44137 : H12AffineFastState.Bounded env44137 := by
  intro p hp
  have h : env44137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44136_44137 : H12AffineEnvironment.transform 12 705 env44136 = env44137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 705 env44136 == env44137) = true)

theorem identity44137 : scanCanonicalize (H12AffineFastState.compose env44137 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound44137 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env44138 : List Nat := [2,4,8,16,32,16,128,256,512,5,2048,277,657,276,925,959,277,438,5,924,277,396,16,50,536,16,43,276,277,2340,20,17,257,261,277,512]

theorem envBound44138 : H12AffineFastState.Bounded env44138 := by
  intro p hp
  have h : env44138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44137_44138 : H12AffineEnvironment.transform 5 16 env44137 = env44138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env44137 == env44138) = true)

theorem identity44138 : scanCanonicalize (H12AffineFastState.compose env44138 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 157) := by decide +kernel

theorem selectedBound44138 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env44139 : List Nat := [2,4,8,16,32,16,128,157,512,5,2048,136,657,137,512,546,136,43,5,513,136,17,16,50,536,16,43,137,136,2233,20,17,156,152,136,512]

theorem envBound44139 : H12AffineFastState.Bounded env44139 := by
  intro p hp
  have h : env44139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44138_44139 : H12AffineEnvironment.transform 7 157 env44138 = env44139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 157 env44138 == env44139) = true)

theorem identity44139 : scanCanonicalize (H12AffineFastState.compose env44139 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound44139 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env44140 : List Nat := [2,4,8,16,32,16,8,21,512,5,2048,0,537,1,512,546,0,43,5,513,0,17,16,50,536,16,43,1,0,2097,20,17,20,16,0,512]

theorem envBound44140 : H12AffineFastState.Bounded env44140 := by
  intro p hp
  have h : env44140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44139_44140 : H12AffineEnvironment.transform 6 8 env44139 = env44140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env44139 == env44140) = true)

theorem identity44140 : scanCanonicalize (H12AffineFastState.compose env44140 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 38) := by decide +kernel

theorem selectedBound44140 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44141 : List Nat := [2,4,8,16,32,16,8,21,38,5,2048,0,63,1,38,4,0,43,5,39,0,17,16,50,62,16,43,1,0,2097,20,17,20,16,0,38]

theorem envBound44141 : H12AffineFastState.Bounded env44141 := by
  intro p hp
  have h : env44141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44140_44141 : H12AffineEnvironment.transform 8 38 env44140 = env44141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 38 env44140 == env44141) = true)

theorem identity44141 : scanCanonicalize (H12AffineFastState.compose env44141 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound44141 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env44142 : List Nat := [2,4,8,10,32,10,8,15,38,5,2048,0,37,1,38,4,0,43,5,39,0,11,10,40,36,10,43,1,0,2091,14,11,14,10,0,38]

theorem envBound44142 : H12AffineFastState.Bounded env44142 := by
  intro p hp
  have h : env44142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44141_44142 : H12AffineEnvironment.transform 3 10 env44141 = env44142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env44141 == env44142) = true)

theorem identity44142 : scanCanonicalize (H12AffineFastState.compose env44142 (packedSelected [0,2,4] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound44142 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env44143 : List Nat := [2,4,8,10,10,10,8,15,12,5,2048,0,15,1,12,4,0,1,5,13,0,11,10,2,14,10,1,1,0,2049,14,11,14,10,0,12]

theorem envBound44143 : H12AffineFastState.Bounded env44143 := by
  intro p hp
  have h : env44143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44142_44143 : H12AffineEnvironment.transform 4 10 env44142 = env44143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env44142 == env44143) = true)

theorem identity44143 : scanCanonicalize (H12AffineFastState.compose env44143 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound44143 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44144 : List Nat := [2,4,4,6,6,6,4,3,0,5,2048,0,3,1,0,4,0,1,5,1,0,7,6,2,2,6,1,1,0,2049,2,7,2,6,0,0]

theorem envBound44144 : H12AffineFastState.Bounded env44144 := by
  intro p hp
  have h : env44144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44143_44144 : H12AffineEnvironment.transform 2 4 env44143 = env44144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env44143 == env44144) = true)

theorem identity44144 : scanCanonicalize (H12AffineFastState.compose env44144 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound44144 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44145 : List Nat := [2,4,4,6,6,6,4,3,0,5,0,0,3,1,0,4,0,1,5,1,0,7,6,2,2,6,1,1,0,1,2,7,2,6,0,0]

theorem envBound44145 : H12AffineFastState.Bounded env44145 := by
  intro p hp
  have h : env44145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44144_44145 : H12AffineEnvironment.transform 10 0 env44144 = env44145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env44144 == env44145) = true)

def env44146 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32882,1344,262144,42333,32769,1345,41089,16,263632,33236,41245,42275,1297,42060,43129,262563,303354,257,42076,1344,41821]

theorem envBound44146 : H12AffineFastState.Bounded env44146 := by
  intro p hp
  have h : env44146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44132_44146 : H12AffineEnvironment.transform 11 1345 env44132 = env44146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env44132 == env44146) = true)

theorem identity44146 : scanCanonicalize (H12AffineFastState.compose env44146 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound44146 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env44147 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,25,1297,32768,32882,1344,262144,34116,32769,1345,32920,16,263632,33236,33028,34106,1297,33877,34912,262563,295139,257,33861,1344,33604]

theorem envBound44147 : H12AffineFastState.Bounded env44147 := by
  intro p hp
  have h : env44147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44146_44147 : H12AffineEnvironment.transform 12 25 env44146 = env44147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env44146 == env44147) = true)

theorem identity44147 : scanCanonicalize (H12AffineFastState.compose env44147 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound44147 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env44148 : List Nat := [2,4,8,16,32,64,128,256,292,1024,2048,1345,25,1297,32768,32882,1344,262144,34116,32769,1345,32920,16,263632,33236,33028,34106,1297,33877,34912,262563,295139,257,33861,1344,32864]

theorem envBound44148 : H12AffineFastState.Bounded env44148 := by
  intro p hp
  have h : env44148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44147_44148 : H12AffineEnvironment.transform 8 292 env44147 = env44148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env44147 == env44148) = true)

def env44149 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95615,32769,4096,61649,147521,284033,86518,209262,225344,148800,74814,96347,381312,456171,257,205166,1344,95103]

theorem envBound44149 : H12AffineFastState.Bounded env44149 := by
  intro p hp
  have h : env44149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44041_44149 : H12AffineEnvironment.transform 23 284033 env44041 = env44149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 284033 env44041 == env44149) = true)

def env44150 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16464,262144,95615,32769,4096,61649,17,284033,86518,94526,77840,1296,74814,96347,381312,308667,257,90430,1344,95103]

theorem envBound44150 : H12AffineFastState.Bounded env44150 := by
  intro p hp
  have h : env44150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44149_44150 : H12AffineEnvironment.transform 16 16464 env44149 = env44150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16464 env44149 == env44150) = true)

def env44151 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1344,262144,77935,32769,4096,46529,17,266385,70886,78894,77840,1296,74814,81227,365712,308667,257,74798,1344,79471]

theorem envBound44151 : H12AffineFastState.Bounded env44151 := by
  intro p hp
  have h : env44151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44150_44151 : H12AffineEnvironment.transform 13 1296 env44150 = env44151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env44150 == env44151) = true)

theorem identity44151 : scanCanonicalize (H12AffineFastState.compose env44151 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32883) := by decide +kernel

theorem selectedBound44151 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env44152 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,32883,1344,262144,45084,32769,4096,46529,17,266385,38037,46173,45155,1296,42061,48440,267491,308667,257,42077,1344,46620]

theorem envBound44152 : H12AffineFastState.Bounded env44152 := by
  intro p hp
  have h : env44152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44151_44152 : H12AffineEnvironment.transform 15 32883 env44151 = env44152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32883 env44151 == env44152) = true)

def env44153 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32883,1344,262144,42332,32769,1344,41089,17,263633,33237,41245,42275,1296,42061,43128,262563,303355,257,42077,1344,41820]

theorem envBound44153 : H12AffineFastState.Bounded env44153 := by
  intro p hp
  have h : env44153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44152_44153 : H12AffineEnvironment.transform 11 1344 env44152 = env44153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env44152 == env44153) = true)

theorem identity44153 : scanCanonicalize (H12AffineFastState.compose env44153 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 34274) := by decide +kernel

theorem selectedBound44153 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env44154 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32883,1344,34274,42332,32769,1344,41089,17,32819,33237,41245,42275,1296,42061,43128,33857,9497,257,42077,1344,41820]

theorem envBound44154 : H12AffineFastState.Bounded env44154 := by
  intro p hp
  have h : env44154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44153_44154 : H12AffineEnvironment.transform 17 34274 env44153 = env44154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 34274 env44153 == env44154) = true)

theorem identity44154 : scanCanonicalize (H12AffineFastState.compose env44154 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound44154 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env44155 : List Nat := [2,4,8,16,32,64,128,256,293,1024,2048,1344,8192,1296,32768,32883,1344,34274,42332,32769,1344,41089,17,32819,33237,41245,42275,1296,42061,43128,33857,9497,257,42077,1344,41081]

theorem envBound44155 : H12AffineFastState.Bounded env44155 := by
  intro p hp
  have h : env44155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44154_44155 : H12AffineEnvironment.transform 8 293 env44154 = env44155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env44154 == env44155) = true)

def env44156 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32883,1344,262144,42333,32769,1345,41088,17,263632,33236,41244,42274,1296,42061,43129,262562,303354,257,42077,1344,41821]

theorem envBound44156 : H12AffineFastState.Bounded env44156 := by
  intro p hp
  have h : env44156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44152_44156 : H12AffineEnvironment.transform 11 1345 env44152 = env44156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env44152 == env44156) = true)

theorem identity44156 : scanCanonicalize (H12AffineFastState.compose env44156 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound44156 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env44157 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,81,8192,0,32768,32883,80,262144,41037,32769,81,41088,17,262336,33236,41244,41010,0,41309,43129,262562,303354,257,41293,80,41821]

theorem envBound44157 : H12AffineFastState.Bounded env44157 := by
  intro p hp
  have h : env44157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44156_44157 : H12AffineEnvironment.transform 9 272 env44156 = env44157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env44156 == env44157) = true)

theorem identity44157 : scanCanonicalize (H12AffineFastState.compose env44157 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound44157 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env44158 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,81,8192,0,8541,8494,80,262144,272,8540,81,477,17,262336,8329,65,367,0,0,2340,262562,262567,257,16,80,512]

theorem envBound44158 : H12AffineFastState.Bounded env44158 := by
  intro p hp
  have h : env44158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44157_44158 : H12AffineEnvironment.transform 14 8541 env44157 = env44158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env44157 == env44158) = true)

theorem identity44158 : scanCanonicalize (H12AffineFastState.compose env44158 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound44158 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env44159 : List Nat := [2,4,8,16,32,64,128,69,512,85,2048,81,8192,0,8216,8299,80,262144,85,8217,81,152,17,262336,8329,65,42,0,0,2145,262375,262370,68,16,80,512]

theorem envBound44159 : H12AffineFastState.Bounded env44159 := by
  intro p hp
  have h : env44159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44158_44159 : H12AffineEnvironment.transform 7 69 env44158 = env44159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env44158 == env44159) = true)

theorem identity44159 : scanCanonicalize (H12AffineFastState.compose env44159 (packedSelected [3,5,10] rootPS)) = affineNative (2^(17+1) ^^^ 8754) := by decide +kernel

theorem selectedBound44159 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env44160 : List Nat := [2,4,8,16,32,64,128,69,512,85,2048,81,8192,0,8216,8299,80,8754,85,8217,81,152,17,8946,8329,65,42,0,0,2145,8917,8912,68,16,80,512]

theorem envBound44160 : H12AffineFastState.Bounded env44160 := by
  intro p hp
  have h : env44160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44159_44160 : H12AffineEnvironment.transform 17 8754 env44159 = env44160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8754 env44159 == env44160) = true)

theorem identity44160 : scanCanonicalize (H12AffineFastState.compose env44160 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound44160 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env44161 : List Nat := [2,4,8,16,32,16,128,21,512,5,2048,1,8192,0,8216,8251,0,8754,5,8217,1,152,17,8866,8329,17,42,0,0,2097,8837,8832,20,16,0,512]

theorem envBound44161 : H12AffineFastState.Bounded env44161 := by
  intro p hp
  have h : env44161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44160_44161 : H12AffineEnvironment.transform 5 16 env44160 = env44161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env44160 == env44161) = true)

theorem identity44161 : scanCanonicalize (H12AffineFastState.compose env44161 (packedSelected [5,8,17] rootPS)) = affineNative (2^(12+1) ^^^ 553) := by decide +kernel

theorem selectedBound44161 : packedSelected [5,8,17] rootPS < 2^1333 := by decide +kernel

def env44162 : List Nat := [2,4,8,16,32,16,128,21,512,5,2048,1,553,0,561,530,0,27,5,560,1,152,17,139,672,17,42,0,0,2097,172,169,20,16,0,512]

theorem envBound44162 : H12AffineFastState.Bounded env44162 := by
  intro p hp
  have h : env44162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44161_44162 : H12AffineEnvironment.transform 12 553 env44161 = env44162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 553 env44161 == env44162) = true)

theorem identity44162 : scanCanonicalize (H12AffineFastState.compose env44162 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 696) := by decide +kernel

theorem selectedBound44162 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44163 : List Nat := [2,4,8,16,32,16,128,21,512,5,696,1,553,0,561,530,0,27,5,560,1,152,17,139,672,17,42,0,0,649,172,169,20,16,0,512]

theorem envBound44163 : H12AffineFastState.Bounded env44163 := by
  intro p hp
  have h : env44163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44162_44163 : H12AffineEnvironment.transform 10 696 env44162 = env44163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 696 env44162 == env44163) = true)

theorem identity44163 : scanCanonicalize (H12AffineFastState.compose env44163 (packedSelected [0,1,3,5] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound44163 : packedSelected [0,1,3,5] rootPS < 2^1333 := by decide +kernel

def env44164 : List Nat := [2,4,8,16,32,16,128,21,42,5,146,1,3,0,27,56,0,27,5,26,1,152,17,139,138,17,42,0,0,163,172,169,20,16,0,42]

theorem envBound44164 : H12AffineFastState.Bounded env44164 := by
  intro p hp
  have h : env44164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44163_44164 : H12AffineEnvironment.transform 8 42 env44163 = env44164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env44163 == env44164) = true)

theorem identity44164 : scanCanonicalize (H12AffineFastState.compose env44164 (packedSelected [1,4] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound44164 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env44165 : List Nat := [2,4,8,16,32,16,56,21,42,5,42,1,3,0,27,56,0,27,5,26,1,32,17,51,50,17,42,0,0,27,20,17,20,16,0,42]

theorem envBound44165 : H12AffineFastState.Bounded env44165 := by
  intro p hp
  have h : env44165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44164_44165 : H12AffineEnvironment.transform 6 56 env44164 = env44165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env44164 == env44165) = true)

theorem identity44165 : scanCanonicalize (H12AffineFastState.compose env44165 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound44165 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44166 : List Nat := [2,4,5,16,32,16,53,21,39,5,39,1,3,0,22,53,0,22,5,23,1,32,17,51,50,17,39,0,0,22,20,17,20,16,0,39]

theorem envBound44166 : H12AffineFastState.Bounded env44166 := by
  intro p hp
  have h : env44166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44165_44166 : H12AffineEnvironment.transform 2 5 env44165 = env44166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env44165 == env44166) = true)

theorem identity44166 : scanCanonicalize (H12AffineFastState.compose env44166 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound44166 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44167 : List Nat := [2,4,5,16,7,16,18,21,0,5,0,1,3,0,22,18,0,22,5,23,1,7,17,20,21,17,0,0,0,22,20,17,20,16,0,0]

theorem envBound44167 : H12AffineFastState.Bounded env44167 := by
  intro p hp
  have h : env44167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44166_44167 : H12AffineEnvironment.transform 4 7 env44166 = env44167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env44166 == env44167) = true)

theorem identity44167 : scanCanonicalize (H12AffineFastState.compose env44167 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound44167 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env44168 : List Nat := [2,4,5,6,7,6,4,3,0,5,0,1,3,0,0,4,0,0,5,1,1,7,7,2,3,7,0,0,0,0,2,7,2,6,0,0]

theorem envBound44168 : H12AffineFastState.Bounded env44168 := by
  intro p hp
  have h : env44168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44167_44168 : H12AffineEnvironment.transform 3 6 env44167 = env44168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env44167 == env44168) = true)

def env44169 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1345,262144,77934,32769,4096,46528,17,266384,70887,78895,77840,1296,74814,81226,365713,308667,257,74799,1344,79470]

theorem envBound44169 : H12AffineFastState.Bounded env44169 := by
  intro p hp
  have h : env44169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44150_44169 : H12AffineEnvironment.transform 13 1297 env44150 = env44169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env44150 == env44169) = true)

theorem identity44169 : scanCanonicalize (H12AffineFastState.compose env44169 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound44169 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env44170 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1345,262144,77934,13340,4096,477,17,266384,70887,78895,77840,1296,74814,81226,336012,262566,257,74799,1344,79470]

theorem envBound44170 : H12AffineFastState.Bounded env44170 := by
  intro p hp
  have h : env44170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44169_44170 : H12AffineEnvironment.transform 14 13341 env44169 = env44170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env44169 == env44170) = true)

def env44171 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1345,65664,77934,13340,4096,477,17,69648,70887,78895,77840,1296,74814,81226,8204,65830,257,74799,1344,79470]

theorem envBound44171 : H12AffineFastState.Bounded env44171 := by
  intro p hp
  have h : env44171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44170_44171 : H12AffineEnvironment.transform 17 65664 env44170 = env44171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env44170 == env44171) = true)

theorem identity44171 : scanCanonicalize (H12AffineFastState.compose env44171 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5238) := by decide +kernel

theorem selectedBound44171 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env44172 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,5238,1345,5366,9240,13340,4096,477,17,1126,145,8281,9318,1296,12360,10556,8204,5456,257,12377,1344,8728]

theorem envBound44172 : H12AffineFastState.Bounded env44172 := by
  intro p hp
  have h : env44172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44171_44172 : H12AffineEnvironment.transform 15 5238 env44171 = env44172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5238 env44171 == env44172) = true)

def env44173 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,1297,13341,5158,1297,5286,9240,13340,4096,397,17,1078,145,8201,9270,1296,12312,10556,8204,5376,257,12297,1296,8728]

theorem envBound44173 : H12AffineFastState.Bounded env44173 := by
  intro p hp
  have h : env44173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44172_44173 : H12AffineEnvironment.transform 5 16 env44172 = env44173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env44172 == env44173) = true)

theorem identity44173 : scanCanonicalize (H12AffineFastState.compose env44173 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound44173 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env44174 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,1053,1297,4096,5158,1297,5286,5,4097,4096,397,17,1078,145,1044,43,1296,5125,3361,1041,5376,257,5140,1296,1541]

theorem envBound44174 : H12AffineFastState.Bounded env44174 := by
  intro p hp
  have h : env44174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44173_44174 : H12AffineEnvironment.transform 12 1053 env44173 = env44174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env44173 == env44174) = true)

theorem identity44174 : scanCanonicalize (H12AffineFastState.compose env44174 (packedSelected [1,2,5,8,13,19,21,23,24,26,32] rootPS)) = affineNative (2^(11+1) ^^^ 648) := by decide +kernel

theorem selectedBound44174 : packedSelected [1,2,5,8,13,19,21,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env44175 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,648,1053,1297,648,1710,1297,1582,5,649,648,397,17,1078,145,1044,43,1296,1677,3361,1041,1928,257,1692,1296,1541]

theorem envBound44175 : H12AffineFastState.Bounded env44175 := by
  intro p hp
  have h : env44175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44174_44175 : H12AffineEnvironment.transform 11 648 env44174 = env44175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 648 env44174 == env44175) = true)

theorem identity44175 : scanCanonicalize (H12AffineFastState.compose env44175 (packedSelected [0,3,4,5,7,9,10,18,21,23,24,28] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound44175 : packedSelected [0,3,4,5,7,9,10,18,21,23,24,28] rootPS < 2^1333 := by decide +kernel

def env44176 : List Nat := [2,4,8,16,32,16,128,256,512,5,2048,648,24,276,648,683,276,555,5,649,648,397,17,51,145,17,43,277,648,2340,20,909,257,665,277,512]

theorem envBound44176 : H12AffineFastState.Bounded env44176 := by
  intro p hp
  have h : env44176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44175_44176 : H12AffineEnvironment.transform 9 5 env44175 = env44176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env44175 == env44176) = true)

theorem identity44176 : scanCanonicalize (H12AffineFastState.compose env44176 (packedSelected [0,1,3,7,11,13] rootPS)) = affineNative (2^(10+1) ^^^ 788) := by decide +kernel

theorem selectedBound44176 : packedSelected [0,1,3,7,11,13] rootPS < 2^1333 := by decide +kernel

def env44177 : List Nat := [2,4,8,16,32,16,128,256,512,5,788,648,24,276,648,683,276,555,5,649,648,397,17,51,145,17,43,277,648,560,20,909,257,665,277,512]

theorem envBound44177 : H12AffineFastState.Bounded env44177 := by
  intro p hp
  have h : env44177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44176_44177 : H12AffineEnvironment.transform 10 788 env44176 = env44177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 788 env44176 == env44177) = true)

theorem identity44177 : scanCanonicalize (H12AffineFastState.compose env44177 (packedSelected [5,8,10,12] rootPS)) = affineNative (2^(8+1) ^^^ 428) := by decide +kernel

theorem selectedBound44177 : packedSelected [5,8,10,12] rootPS < 2^1333 := by decide +kernel

def env44178 : List Nat := [2,4,8,16,32,16,128,256,428,5,184,292,24,276,292,263,276,391,5,293,292,397,17,51,145,17,43,277,292,412,20,33,257,309,277,428]

theorem envBound44178 : H12AffineFastState.Bounded env44178 := by
  intro p hp
  have h : env44178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44177_44178 : H12AffineEnvironment.transform 8 428 env44177 = env44178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 428 env44177 == env44178) = true)

theorem identity44178 : scanCanonicalize (H12AffineFastState.compose env44178 (packedSelected [2,3,4,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound44178 : packedSelected [2,3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env44179 : List Nat := [2,4,8,16,32,16,35,256,271,5,27,292,24,276,292,263,276,292,5,293,292,302,17,51,50,17,43,277,292,319,20,33,257,309,277,271]

theorem envBound44179 : H12AffineFastState.Bounded env44179 := by
  intro p hp
  have h : env44179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44178_44179 : H12AffineEnvironment.transform 6 35 env44178 = env44179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env44178 == env44179) = true)

theorem identity44179 : scanCanonicalize (H12AffineFastState.compose env44179 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound44179 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env44180 : List Nat := [2,4,8,10,32,10,35,256,271,5,1,292,2,270,292,263,270,292,5,293,292,302,11,41,40,11,43,271,292,293,14,33,257,303,271,271]

theorem envBound44180 : H12AffineFastState.Bounded env44180 := by
  intro p hp
  have h : env44180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44179_44180 : H12AffineEnvironment.transform 3 10 env44179 = env44180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env44179 == env44180) = true)

theorem identity44180 : scanCanonicalize (H12AffineFastState.compose env44180 (packedSelected [0,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound44180 : packedSelected [0,2,3] rootPS < 2^1333 := by decide +kernel

def env44181 : List Nat := [2,4,8,10,32,10,35,36,43,5,1,0,2,42,0,35,42,0,5,1,0,10,11,41,40,11,43,43,0,1,14,33,37,11,43,43]

theorem envBound44181 : H12AffineFastState.Bounded env44181 := by
  intro p hp
  have h : env44181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44180_44181 : H12AffineEnvironment.transform 7 36 env44180 = env44181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env44180 == env44181) = true)

theorem identity44181 : scanCanonicalize (H12AffineFastState.compose env44181 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound44181 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44182 : List Nat := [2,4,8,10,11,10,8,15,0,5,1,0,2,1,0,8,1,0,5,1,0,10,11,2,3,11,0,0,0,1,14,10,14,11,0,0]

theorem envBound44182 : H12AffineFastState.Bounded env44182 := by
  intro p hp
  have h : env44182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44181_44182 : H12AffineEnvironment.transform 4 11 env44181 = env44182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env44181 == env44182) = true)

theorem identity44182 : scanCanonicalize (H12AffineFastState.compose env44182 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound44182 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44183 : List Nat := [2,3,8,10,11,10,8,8,0,2,1,0,2,1,0,8,1,0,2,1,0,10,11,2,3,11,0,0,0,1,9,10,9,11,0,0]

theorem envBound44183 : H12AffineFastState.Bounded env44183 := by
  intro p hp
  have h : env44183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44182_44183 : H12AffineEnvironment.transform 1 3 env44182 = env44183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env44182 == env44183) = true)

def env44184 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,1297,13341,5159,1296,5287,9240,13340,4096,396,17,1079,145,8200,9271,1296,12313,10556,8204,5377,257,12296,1297,8728]

theorem envBound44184 : H12AffineFastState.Bounded env44184 := by
  intro p hp
  have h : env44184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44172_44184 : H12AffineEnvironment.transform 5 17 env44172 = env44184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env44172 == env44184) = true)

theorem identity44184 : scanCanonicalize (H12AffineFastState.compose env44184 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound44184 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env44185 : List Nat := [2,4,8,16,32,17,128,256,512,4,2048,4096,8192,277,12313,4131,276,4259,8220,12312,4096,396,17,51,145,8200,8243,276,12313,10556,8204,4357,257,12296,277,8728]

theorem envBound44185 : H12AffineFastState.Bounded env44185 := by
  intro p hp
  have h : env44185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44184_44185 : H12AffineEnvironment.transform 9 4 env44184 = env44185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env44184 == env44185) = true)

theorem identity44185 : scanCanonicalize (H12AffineFastState.compose env44185 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound44185 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env44186 : List Nat := [2,4,8,16,32,17,128,256,512,4,2048,4096,25,277,4096,4131,276,4259,5,4097,4096,396,17,51,145,17,42,276,4096,2341,21,4357,257,4113,277,513]

theorem envBound44186 : H12AffineFastState.Bounded env44186 := by
  intro p hp
  have h : env44186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44185_44186 : H12AffineEnvironment.transform 12 25 env44185 = env44186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env44185 == env44186) = true)

theorem identity44186 : scanCanonicalize (H12AffineFastState.compose env44186 (packedSelected [2,11,18] rootPS)) = affineNative (2^(11+1) ^^^ 648) := by decide +kernel

theorem selectedBound44186 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env44187 : List Nat := [2,4,8,16,32,17,128,256,512,4,2048,648,25,277,648,683,276,555,5,649,648,396,17,51,145,17,42,276,648,2341,21,909,257,665,277,513]

theorem envBound44187 : H12AffineFastState.Bounded env44187 := by
  intro p hp
  have h : env44187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44186_44187 : H12AffineEnvironment.transform 11 648 env44186 = env44187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 648 env44186 == env44187) = true)

theorem identity44187 : scanCanonicalize (H12AffineFastState.compose env44187 (packedSelected [0,1,3,7,11,13] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound44187 : packedSelected [0,1,3,7,11,13] rootPS < 2^1333 := by decide +kernel

def env44188 : List Nat := [2,4,8,16,32,17,128,256,49,4,2048,185,25,277,185,154,276,26,5,184,185,396,17,51,145,17,42,276,185,2341,21,444,257,168,277,48]

theorem envBound44188 : H12AffineFastState.Bounded env44188 := by
  intro p hp
  have h : env44188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44187_44188 : H12AffineEnvironment.transform 8 49 env44187 = env44188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env44187 == env44188) = true)

theorem identity44188 : scanCanonicalize (H12AffineFastState.compose env44188 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound44188 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44189 : List Nat := [2,4,8,16,32,17,128,172,49,4,2048,185,25,185,185,154,184,26,5,184,185,32,17,51,145,17,42,184,185,2185,21,16,173,168,185,48]

theorem envBound44189 : H12AffineFastState.Bounded env44189 := by
  intro p hp
  have h : env44189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44188_44189 : H12AffineEnvironment.transform 7 172 env44188 = env44189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env44188 == env44189) = true)

theorem identity44189 : scanCanonicalize (H12AffineFastState.compose env44189 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 136) := by decide +kernel

theorem selectedBound44189 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env44190 : List Nat := [2,4,8,16,32,17,128,172,49,4,136,185,25,185,185,154,184,26,5,184,185,32,17,51,145,17,42,184,185,1,21,16,173,168,185,48]

theorem envBound44190 : H12AffineFastState.Bounded env44190 := by
  intro p hp
  have h : env44190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44189_44190 : H12AffineEnvironment.transform 10 136 env44189 = env44190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 136 env44189 == env44190) = true)

theorem identity44190 : scanCanonicalize (H12AffineFastState.compose env44190 (packedSelected [0,1,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 43) := by decide +kernel

theorem selectedBound44190 : packedSelected [0,1,3,5] rootPS < 2^1333 := by decide +kernel

def env44191 : List Nat := [2,4,8,16,32,17,43,7,49,4,35,18,25,18,18,49,19,26,5,19,18,32,17,51,58,17,42,19,18,1,21,16,6,3,18,48]

theorem envBound44191 : H12AffineFastState.Bounded env44191 := by
  intro p hp
  have h : env44191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44190_44191 : H12AffineEnvironment.transform 6 43 env44190 = env44191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 43 env44190 == env44191) = true)

theorem identity44191 : scanCanonicalize (H12AffineFastState.compose env44191 (packedSelected [0,1,4,7] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound44191 : packedSelected [0,1,4,7] rootPS < 2^1333 := by decide +kernel

def env44192 : List Nat := [2,4,8,16,16,17,27,7,1,4,19,18,25,18,18,1,19,26,5,19,18,16,17,3,10,17,26,19,18,1,21,16,6,3,18,0]

theorem envBound44192 : H12AffineFastState.Bounded env44192 := by
  intro p hp
  have h : env44192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44191_44192 : H12AffineEnvironment.transform 4 16 env44191 = env44192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env44191 == env44192) = true)

theorem identity44192 : scanCanonicalize (H12AffineFastState.compose env44192 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound44192 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env44193 : List Nat := [2,4,8,10,10,11,1,7,1,4,9,8,3,8,8,1,9,0,5,9,8,10,11,3,10,11,0,9,8,1,15,10,6,3,8,0]

theorem envBound44193 : H12AffineFastState.Bounded env44193 := by
  intro p hp
  have h : env44193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44192_44193 : H12AffineEnvironment.transform 3 10 env44192 = env44193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env44192 == env44193) = true)

theorem identity44193 : scanCanonicalize (H12AffineFastState.compose env44193 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound44193 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env44194 : List Nat := [2,4,1,3,3,2,1,7,1,4,0,1,3,1,1,1,0,0,5,0,1,3,2,3,3,2,0,0,1,1,6,3,6,3,1,0]

theorem envBound44194 : H12AffineFastState.Bounded env44194 := by
  intro p hp
  have h : env44194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44193_44194 : H12AffineEnvironment.transform 2 1 env44193 = env44194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env44193 == env44194) = true)

theorem identity44194 : scanCanonicalize (H12AffineFastState.compose env44194 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound44194 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44195 : List Nat := [2,0,1,3,3,2,1,3,1,0,0,1,3,1,1,1,0,0,1,0,1,3,2,3,3,2,0,0,1,1,2,3,2,3,1,0]

theorem envBound44195 : H12AffineFastState.Bounded env44195 := by
  intro p hp
  have h : env44195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44194_44195 : H12AffineEnvironment.transform 1 0 env44194 = env44195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env44194 == env44195) = true)

theorem identity44195 : scanCanonicalize (H12AffineFastState.compose env44195 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound44195 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env44196 : List Nat := [0,0,1,1,1,0,1,1,1,0,0,1,1,1,1,1,0,0,1,0,1,1,0,1,1,0,0,0,1,1,0,1,0,1,1,0]

theorem envBound44196 : H12AffineFastState.Bounded env44196 := by
  intro p hp
  have h : env44196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44195_44196 : H12AffineEnvironment.transform 0 0 env44195 = env44196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env44195 == env44196) = true)

def env44197 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1345,65665,77934,13340,4096,477,17,69649,70887,78895,77840,1296,74814,81226,8205,65831,257,74799,1344,79470]

theorem envBound44197 : H12AffineFastState.Bounded env44197 := by
  intro p hp
  have h : env44197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44170_44197 : H12AffineEnvironment.transform 17 65665 env44170 = env44197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env44170 == env44197) = true)

theorem identity44197 : scanCanonicalize (H12AffineFastState.compose env44197 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 310) := by decide +kernel

theorem selectedBound44197 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env44198 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,310,1345,439,12632,13340,4096,477,17,4391,5585,13593,12582,1296,9480,15484,8205,17,257,9497,1344,14168]

theorem envBound44198 : H12AffineFastState.Bounded env44198 := by
  intro p hp
  have h : env44198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44197_44198 : H12AffineEnvironment.transform 15 310 env44197 = env44198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 310 env44197 == env44198) = true)

def env44199 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,1297,13341,310,1297,439,12552,13340,4096,397,17,4391,5505,13593,12582,1296,9480,15404,8205,17,257,9497,1296,14088]

theorem envBound44199 : H12AffineFastState.Bounded env44199 := by
  intro p hp
  have h : env44199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44198_44199 : H12AffineEnvironment.transform 5 16 env44198 = env44199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env44198 == env44199) = true)

theorem identity44199 : scanCanonicalize (H12AffineFastState.compose env44199 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 4365) := by decide +kernel

theorem selectedBound44199 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env44200 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,4365,1297,1296,310,1297,439,5,1297,4096,397,17,4391,5505,1044,43,1296,5125,3361,4352,17,257,5140,1296,1541]

theorem envBound44200 : H12AffineFastState.Bounded env44200 := by
  intro p hp
  have h : env44200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44199_44200 : H12AffineEnvironment.transform 12 4365 env44199 = env44200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4365 env44199 == env44200) = true)

theorem identity44200 : scanCanonicalize (H12AffineFastState.compose env44200 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound44200 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env44201 : List Nat := [2,4,8,16,32,16,128,256,512,5,2048,4096,4365,276,277,310,276,439,5,276,4096,397,17,4391,4484,17,43,277,4096,2340,4352,17,257,4113,277,512]

theorem envBound44201 : H12AffineFastState.Bounded env44201 := by
  intro p hp
  have h : env44201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44200_44201 : H12AffineEnvironment.transform 9 5 env44200 = env44201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env44200 == env44201) = true)

theorem identity44201 : scanCanonicalize (H12AffineFastState.compose env44201 (packedSelected [2,11,18] rootPS)) = affineNative (2^(10+1) ^^^ 539) := by decide +kernel

theorem selectedBound44201 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env44202 : List Nat := [2,4,8,16,32,16,128,256,512,5,539,4096,4365,276,277,310,276,439,5,276,4096,397,17,4391,4484,17,43,277,4096,831,4352,17,257,4113,277,512]

theorem envBound44202 : H12AffineFastState.Bounded env44202 := by
  intro p hp
  have h : env44202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44201_44202 : H12AffineEnvironment.transform 10 539 env44201 = env44202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 539 env44201 == env44202) = true)

theorem identity44202 : scanCanonicalize (H12AffineFastState.compose env44202 (packedSelected [1,2,3,13] rootPS)) = affineNative (2^(8+1) ^^^ 438) := by decide +kernel

theorem selectedBound44202 : packedSelected [1,2,3,13] rootPS < 2^1333 := by decide +kernel

def env44203 : List Nat := [2,4,8,16,32,16,128,256,438,5,429,4096,4365,276,277,310,276,439,5,276,4096,397,17,4391,4484,17,43,277,4096,137,4352,17,257,4113,277,438]

theorem envBound44203 : H12AffineFastState.Bounded env44203 := by
  intro p hp
  have h : env44203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44202_44203 : H12AffineEnvironment.transform 8 438 env44202 = env44203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 438 env44202 == env44203) = true)

theorem identity44203 : scanCanonicalize (H12AffineFastState.compose env44203 (packedSelected [0,1,2,7,8,10,11] rootPS)) = affineNative (2^(7+1) ^^^ 135) := by decide +kernel

theorem selectedBound44203 : packedSelected [0,1,2,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env44204 : List Nat := [2,4,8,16,32,16,128,135,49,5,42,4096,4234,147,146,177,147,48,5,147,4096,10,17,4256,4099,17,43,146,4096,137,4231,17,134,4113,146,49]

theorem envBound44204 : H12AffineFastState.Bounded env44204 := by
  intro p hp
  have h : env44204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44203_44204 : H12AffineEnvironment.transform 7 135 env44203 = env44204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 135 env44203 == env44204) = true)

theorem identity44204 : scanCanonicalize (H12AffineFastState.compose env44204 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 137) := by decide +kernel

theorem selectedBound44204 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env44205 : List Nat := [2,4,8,16,32,16,128,135,49,5,42,137,3,147,146,177,147,48,5,147,137,10,17,41,138,17,43,146,137,137,14,17,134,152,146,49]

theorem envBound44205 : H12AffineFastState.Bounded env44205 := by
  intro p hp
  have h : env44205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44204_44205 : H12AffineEnvironment.transform 11 137 env44204 = env44205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 137 env44204 == env44205) = true)

theorem identity44205 : scanCanonicalize (H12AffineFastState.compose env44205 (packedSelected [0,1,2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound44205 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env44206 : List Nat := [2,4,8,16,17,16,128,135,0,5,27,137,3,147,146,128,147,1,5,147,137,10,17,24,138,17,26,146,137,137,14,17,134,152,146,0]

theorem envBound44206 : H12AffineFastState.Bounded env44206 := by
  intro p hp
  have h : env44206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44205_44206 : H12AffineEnvironment.transform 4 17 env44205 = env44206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env44205 == env44206) = true)

def env44207 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,1297,13341,310,1296,439,12553,13340,4096,396,17,4391,5504,13593,12582,1296,9480,15405,8205,17,257,9497,1297,14089]

theorem envBound44207 : H12AffineFastState.Bounded env44207 := by
  intro p hp
  have h : env44207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44198_44207 : H12AffineEnvironment.transform 5 17 env44198 = env44207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env44198 == env44207) = true)

theorem identity44207 : scanCanonicalize (H12AffineFastState.compose env44207 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound44207 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env44208 : List Nat := [2,4,8,16,32,17,128,256,512,4,2048,4096,8192,277,12313,310,276,439,12553,12312,4096,396,17,4391,4484,12573,12582,276,8460,14377,8205,17,257,8477,277,13069]

theorem envBound44208 : H12AffineFastState.Bounded env44208 := by
  intro p hp
  have h : env44208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44207_44208 : H12AffineEnvironment.transform 9 4 env44207 = env44208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env44207 == env44208) = true)

def env44209 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16465,262144,95615,32769,4096,61649,16,284033,86518,94527,77841,1297,74814,96347,381312,308666,257,90431,1344,95103]

theorem envBound44209 : H12AffineFastState.Bounded env44209 := by
  intro p hp
  have h : env44209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44149_44209 : H12AffineEnvironment.transform 16 16465 env44149 = env44209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16465 env44149 == env44209) = true)

def env44210 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1345,262144,77935,32769,4096,46529,16,266385,70886,78895,77841,1297,74814,81227,365712,308666,257,74799,1344,79471]

theorem envBound44210 : H12AffineFastState.Bounded env44210 := by
  intro p hp
  have h : env44210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44209_44210 : H12AffineEnvironment.transform 13 1296 env44209 = env44210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env44209 == env44210) = true)

theorem identity44210 : scanCanonicalize (H12AffineFastState.compose env44210 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound44210 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env44211 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1345,262144,77935,13340,4096,476,16,266385,70886,78895,77841,1297,74814,81227,336013,262567,257,74799,1344,79471]

theorem envBound44211 : H12AffineFastState.Bounded env44211 := by
  intro p hp
  have h : env44211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44210_44211 : H12AffineEnvironment.transform 14 13341 env44210 = env44211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env44210 == env44211) = true)

def env44212 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1345,65664,77935,13340,4096,476,16,69649,70886,78895,77841,1297,74814,81227,8205,65831,257,74799,1344,79471]

theorem envBound44212 : H12AffineFastState.Bounded env44212 := by
  intro p hp
  have h : env44212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44211_44212 : H12AffineEnvironment.transform 17 65664 env44211 = env44212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env44211 == env44212) = true)

theorem identity44212 : scanCanonicalize (H12AffineFastState.compose env44212 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9279) := by decide +kernel

theorem selectedBound44212 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env44213 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,9279,1345,9407,5200,13340,4096,476,16,13358,12505,4112,5166,1297,1,6516,8205,9496,257,16,1344,4688]

theorem envBound44213 : H12AffineFastState.Bounded env44213 := by
  intro p hp
  have h : env44213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44212_44213 : H12AffineEnvironment.transform 15 9279 env44212 = env44213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9279 env44212 == env44213) = true)

def env44214 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1296,9245,9279,1345,9407,1104,9244,0,476,16,9262,8409,16,1070,1297,1,2420,8205,9496,257,16,1344,592]

theorem envBound44214 : H12AffineFastState.Bounded env44214 := by
  intro p hp
  have h : env44214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44213_44214 : H12AffineEnvironment.transform 11 0 env44213 = env44214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env44213 == env44214) = true)

theorem identity44214 : scanCanonicalize (H12AffineFastState.compose env44214 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound44214 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env44215 : List Nat := [2,4,8,16,32,64,128,256,512,5,2048,0,8192,277,8216,8250,324,8378,85,8217,0,476,16,8235,8409,16,43,276,1,2420,8205,8477,257,16,325,592]

theorem envBound44215 : H12AffineFastState.Bounded env44215 := by
  intro p hp
  have h : env44215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44214_44215 : H12AffineEnvironment.transform 9 5 env44214 = env44215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env44214 == env44215) = true)

theorem identity44215 : scanCanonicalize (H12AffineFastState.compose env44215 (packedSelected [2,23,32] rootPS)) = affineNative (2^(12+1) ^^^ 980) := by decide +kernel

theorem selectedBound44215 : packedSelected [2,23,32] rootPS < 2^1333 := by decide +kernel

def env44216 : List Nat := [2,4,8,16,32,64,128,256,512,5,2048,0,980,277,972,1006,324,878,85,973,0,476,16,1023,781,16,43,276,1,2420,985,713,257,16,325,592]

theorem envBound44216 : H12AffineFastState.Bounded env44216 := by
  intro p hp
  have h : env44216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44215_44216 : H12AffineEnvironment.transform 12 980 env44215 = env44216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 980 env44215 == env44216) = true)

def env44217 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1296,9244,9279,1345,9407,1105,9245,1,476,16,9263,8408,17,1071,1297,1,2421,8205,9496,257,16,1344,593]

theorem envBound44217 : H12AffineFastState.Bounded env44217 := by
  intro p hp
  have h : env44217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44213_44217 : H12AffineEnvironment.transform 11 1 env44213 = env44217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env44213 == env44217) = true)

theorem identity44217 : scanCanonicalize (H12AffineFastState.compose env44217 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 85) := by decide +kernel

theorem selectedBound44217 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env44218 : List Nat := [2,4,8,16,32,64,128,256,512,85,2048,1,8192,325,8265,8298,276,8426,4,8264,1,476,16,8314,8408,17,122,324,1,2421,8205,8525,257,16,277,593]

theorem envBound44218 : H12AffineFastState.Bounded env44218 := by
  intro p hp
  have h : env44218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44217_44218 : H12AffineEnvironment.transform 9 85 env44217 = env44218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env44217 == env44218) = true)

theorem identity44218 : scanCanonicalize (H12AffineFastState.compose env44218 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound44218 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env44219 : List Nat := [2,4,8,16,32,16,128,256,512,5,2048,1,8192,277,8217,8250,276,8378,4,8216,1,396,16,8234,8328,17,42,276,1,2341,8205,8477,257,16,277,513]

theorem envBound44219 : H12AffineFastState.Bounded env44219 := by
  intro p hp
  have h : env44219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44218_44219 : H12AffineEnvironment.transform 5 16 env44218 = env44219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env44218 == env44219) = true)

theorem identity44219 : scanCanonicalize (H12AffineFastState.compose env44219 (packedSelected [2,3,5,10,11,18] rootPS)) = affineNative (2^(12+1) ^^^ 641) := by decide +kernel

theorem selectedBound44219 : packedSelected [2,3,5,10,11,18] rootPS < 2^1333 := by decide +kernel

def env44220 : List Nat := [2,4,8,16,32,16,128,256,512,5,2048,1,641,277,664,699,276,571,4,665,1,396,16,683,521,17,42,276,1,2341,652,924,257,16,277,513]

theorem envBound44220 : H12AffineFastState.Bounded env44220 := by
  intro p hp
  have h : env44220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44219_44220 : H12AffineEnvironment.transform 12 641 env44219 = env44220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 641 env44219 == env44220) = true)

theorem identity44220 : scanCanonicalize (H12AffineFastState.compose env44220 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 396) := by decide +kernel

theorem selectedBound44220 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env44221 : List Nat := [2,4,8,16,32,16,128,256,396,5,2048,1,269,277,276,311,276,439,4,277,1,396,16,295,389,17,42,276,1,2341,256,16,257,16,277,397]

theorem envBound44221 : H12AffineFastState.Bounded env44221 := by
  intro p hp
  have h : env44221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44220_44221 : H12AffineEnvironment.transform 8 396 env44220 = env44221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 396 env44220 == env44221) = true)

theorem identity44221 : scanCanonicalize (H12AffineFastState.compose env44221 (packedSelected [1,2,8] rootPS)) = affineNative (2^(7+1) ^^^ 189) := by decide +kernel

theorem selectedBound44221 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env44222 : List Nat := [2,4,8,16,32,16,128,189,49,5,2048,1,176,168,169,138,169,10,4,168,1,49,16,154,56,17,42,169,1,2200,189,16,188,16,168,48]

theorem envBound44222 : H12AffineFastState.Bounded env44222 := by
  intro p hp
  have h : env44222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44221_44222 : H12AffineEnvironment.transform 7 189 env44221 = env44222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 189 env44221 == env44222) = true)

theorem identity44222 : scanCanonicalize (H12AffineFastState.compose env44222 (packedSelected [2,5] rootPS)) = affineNative (2^(4+1) ^^^ 23) := by decide +kernel

theorem selectedBound44222 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env44223 : List Nat := [2,4,8,16,23,16,128,138,6,5,2048,1,135,159,158,138,158,10,4,159,1,6,16,154,15,17,29,158,1,2200,138,16,139,16,159,7]

theorem envBound44223 : H12AffineFastState.Bounded env44223 := by
  intro p hp
  have h : env44223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44222_44223 : H12AffineEnvironment.transform 4 23 env44222 = env44223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 23 env44222 == env44223) = true)

theorem identity44223 : scanCanonicalize (H12AffineFastState.compose env44223 (packedSelected [2,3,10] rootPS)) = affineNative (2^(6+1) ^^^ 15) := by decide +kernel

theorem selectedBound44223 : packedSelected [2,3,10] rootPS < 2^1333 := by decide +kernel

def env44224 : List Nat := [2,4,8,16,23,16,15,5,6,5,2048,1,8,16,17,5,17,10,4,16,1,6,16,21,15,17,29,17,1,2071,5,16,4,16,16,7]

theorem envBound44224 : H12AffineFastState.Bounded env44224 := by
  intro p hp
  have h : env44224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44223_44224 : H12AffineEnvironment.transform 6 15 env44223 = env44224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 15 env44223 == env44224) = true)

theorem identity44224 : scanCanonicalize (H12AffineFastState.compose env44224 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 13) := by decide +kernel

theorem selectedBound44224 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env44225 : List Nat := [2,4,8,16,23,16,15,5,6,5,13,1,8,16,17,5,17,10,4,16,1,6,16,21,15,17,29,17,1,26,5,16,4,16,16,7]

theorem envBound44225 : H12AffineFastState.Bounded env44225 := by
  intro p hp
  have h : env44225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44224_44225 : H12AffineEnvironment.transform 10 13 env44224 = env44225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 13 env44224 == env44225) = true)

theorem identity44225 : scanCanonicalize (H12AffineFastState.compose env44225 (packedSelected [0,3,4] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound44225 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env44226 : List Nat := [2,4,8,11,12,11,15,5,6,5,13,1,8,11,10,5,10,10,4,11,1,6,11,14,15,10,6,10,1,1,5,11,4,11,11,7]

theorem envBound44226 : H12AffineFastState.Bounded env44226 := by
  intro p hp
  have h : env44226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44225_44226 : H12AffineEnvironment.transform 3 11 env44225 = env44226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env44225 == env44226) = true)

theorem identity44226 : scanCanonicalize (H12AffineFastState.compose env44226 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound44226 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44227 : List Nat := [2,3,8,11,11,11,8,2,1,2,10,1,8,11,10,2,10,10,3,11,1,1,11,9,8,10,1,10,1,1,2,11,3,11,11,0]

theorem envBound44227 : H12AffineFastState.Bounded env44227 := by
  intro p hp
  have h : env44227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44226_44227 : H12AffineEnvironment.transform 1 3 env44226 = env44227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env44226 == env44227) = true)

theorem identity44227 : scanCanonicalize (H12AffineFastState.compose env44227 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound44227 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44228 : List Nat := [1,0,8,8,8,8,8,1,1,1,9,1,8,8,9,1,9,9,0,8,1,1,8,9,8,9,1,9,1,1,1,8,0,8,8,0]

theorem envBound44228 : H12AffineFastState.Bounded env44228 := by
  intro p hp
  have h : env44228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44227_44228 : H12AffineEnvironment.transform 0 1 env44227 = env44228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env44227 == env44228) = true)

theorem identity44228 : scanCanonicalize (H12AffineFastState.compose env44228 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound44228 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env44229 : List Nat := [1,0,0,0,0,0,0,1,1,1,1,1,0,0,1,1,1,1,0,0,1,1,0,1,0,1,1,1,1,1,1,0,0,0,0,0]

theorem envBound44229 : H12AffineFastState.Bounded env44229 := by
  intro p hp
  have h : env44229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44228_44229 : H12AffineEnvironment.transform 2 0 env44228 = env44229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env44228 == env44229) = true)

def env44230 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1345,65665,77935,13340,4096,476,16,69648,70886,78895,77841,1297,74814,81227,8204,65830,257,74799,1344,79471]

theorem envBound44230 : H12AffineFastState.Bounded env44230 := by
  intro p hp
  have h : env44230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44211_44230 : H12AffineEnvironment.transform 17 65665 env44211 = env44230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env44211 == env44230) = true)

theorem identity44230 : scanCanonicalize (H12AffineFastState.compose env44230 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12671) := by decide +kernel

theorem selectedBound44230 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env44231 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,12671,1345,12798,272,13340,4096,476,16,8559,9625,1360,366,1297,5441,3124,8204,12377,257,5456,1344,1808]

theorem envBound44231 : H12AffineFastState.Bounded env44231 := by
  intro p hp
  have h : env44231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44230_44231 : H12AffineEnvironment.transform 15 12671 env44230 = env44231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12671 env44230 == env44231) = true)

def env44232 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,80,12637,12671,1,12798,272,12636,4096,476,16,8559,8409,16,366,81,4097,2420,8204,12377,257,4112,0,592]

theorem envBound44232 : H12AffineFastState.Bounded env44232 := by
  intro p hp
  have h : env44232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44231_44232 : H12AffineEnvironment.transform 9 320 env44231 = env44232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env44231 == env44232) = true)

theorem identity44232 : scanCanonicalize (H12AffineFastState.compose env44232 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound44232 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env44233 : List Nat := [2,4,8,16,32,64,128,69,512,5,2048,4096,8192,80,12312,12346,1,12475,85,12313,4096,153,16,8234,8409,16,43,81,4097,2097,8204,12377,68,4112,0,592]

theorem envBound44233 : H12AffineFastState.Bounded env44233 := by
  intro p hp
  have h : env44233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44232_44233 : H12AffineEnvironment.transform 7 69 env44232 = env44233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env44232 == env44233) = true)

theorem identity44233 : scanCanonicalize (H12AffineFastState.compose env44233 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound44233 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env44234 : List Nat := [2,4,8,16,32,16,128,21,512,5,2048,4096,8192,0,12312,12346,1,12475,5,12313,4096,153,16,8234,8329,16,43,1,4097,2097,8204,12297,20,4112,0,512]

theorem envBound44234 : H12AffineFastState.Bounded env44234 := by
  intro p hp
  have h : env44234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44233_44234 : H12AffineEnvironment.transform 5 16 env44233 = env44234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env44233 == env44234) = true)

theorem identity44234 : scanCanonicalize (H12AffineFastState.compose env44234 (packedSelected [2,3,5,10,11,18] rootPS)) = affineNative (2^(12+1) ^^^ 6195) := by decide +kernel

theorem selectedBound44234 : packedSelected [2,3,5,10,11,18] rootPS < 2^1333 := by decide +kernel

def env44235 : List Nat := [2,4,8,16,32,16,128,21,512,5,2048,4096,6195,0,2091,2057,1,2184,5,2090,4096,153,16,6169,6330,16,43,1,4097,2097,6207,2106,20,4112,0,512]

theorem envBound44235 : H12AffineFastState.Bounded env44235 := by
  intro p hp
  have h : env44235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44234_44235 : H12AffineEnvironment.transform 12 6195 env44234 = env44235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6195 env44234 == env44235) = true)

theorem identity44235 : scanCanonicalize (H12AffineFastState.compose env44235 (packedSelected [0,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 162) := by decide +kernel

theorem selectedBound44235 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env44236 : List Nat := [2,4,8,16,32,16,128,21,512,5,162,4096,4241,0,137,171,1,42,5,136,4096,153,16,4283,4120,16,43,1,4097,147,4253,152,20,4112,0,512]

theorem envBound44236 : H12AffineFastState.Bounded env44236 := by
  intro p hp
  have h : env44236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44235_44236 : H12AffineEnvironment.transform 10 162 env44235 = env44236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 162 env44235 == env44236) = true)

theorem identity44236 : scanCanonicalize (H12AffineFastState.compose env44236 (packedSelected [0,1,3,4,5,7,8,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 697) := by decide +kernel

theorem selectedBound44236 : packedSelected [0,1,3,4,5,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env44237 : List Nat := [2,4,8,16,32,16,128,21,512,5,162,697,552,0,137,171,1,42,5,136,697,153,16,514,673,16,43,1,696,147,548,152,20,681,0,512]

theorem envBound44237 : H12AffineFastState.Bounded env44237 := by
  intro p hp
  have h : env44237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44236_44237 : H12AffineEnvironment.transform 11 697 env44236 = env44237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 697 env44236 == env44237) = true)

theorem identity44237 : scanCanonicalize (H12AffineFastState.compose env44237 (packedSelected [1,2,3,5,7] rootPS)) = affineNative (2^(8+1) ^^^ 162) := by decide +kernel

theorem selectedBound44237 : packedSelected [1,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env44238 : List Nat := [2,4,8,16,32,16,128,21,162,5,162,27,138,0,137,171,1,42,5,136,27,153,16,160,3,16,43,1,26,147,134,152,20,11,0,162]

theorem envBound44238 : H12AffineFastState.Bounded env44238 := by
  intro p hp
  have h : env44238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44237_44238 : H12AffineEnvironment.transform 8 162 env44237 = env44238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 162 env44237 == env44238) = true)

theorem identity44238 : scanCanonicalize (H12AffineFastState.compose env44238 (packedSelected [0,3] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound44238 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env44239 : List Nat := [2,4,8,16,32,16,34,21,0,5,0,27,40,0,43,9,1,42,5,42,27,59,16,2,3,16,43,1,26,49,36,58,20,11,0,0]

theorem envBound44239 : H12AffineFastState.Bounded env44239 := by
  intro p hp
  have h : env44239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44238_44239 : H12AffineEnvironment.transform 6 34 env44238 = env44239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env44238 == env44239) = true)

theorem identity44239 : scanCanonicalize (H12AffineFastState.compose env44239 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound44239 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44240 : List Nat := [2,4,8,16,17,16,19,21,0,5,0,27,25,0,26,9,1,27,5,27,27,10,16,2,3,16,26,1,26,0,21,11,20,11,0,0]

theorem envBound44240 : H12AffineFastState.Bounded env44240 := by
  intro p hp
  have h : env44240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44239_44240 : H12AffineEnvironment.transform 4 17 env44239 = env44240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env44239 == env44240) = true)

theorem identity44240 : scanCanonicalize (H12AffineFastState.compose env44240 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound44240 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44241 : List Nat := [2,4,8,6,7,6,5,3,0,5,0,13,15,0,12,9,1,13,5,13,13,10,6,2,3,6,12,1,12,0,3,11,2,11,0,0]

theorem envBound44241 : H12AffineFastState.Bounded env44241 := by
  intro p hp
  have h : env44241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44240_44241 : H12AffineEnvironment.transform 3 6 env44240 = env44241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env44240 == env44241) = true)

theorem identity44241 : scanCanonicalize (H12AffineFastState.compose env44241 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound44241 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env44242 : List Nat := [2,4,4,6,7,6,5,3,0,5,0,1,3,0,0,5,1,1,5,1,1,6,6,2,3,6,0,1,0,0,3,7,2,7,0,0]

theorem envBound44242 : H12AffineFastState.Bounded env44242 := by
  intro p hp
  have h : env44242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44241_44242 : H12AffineEnvironment.transform 2 4 env44241 = env44242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env44241 == env44242) = true)

def env44243 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,81,12636,12671,0,12798,272,12637,4096,476,16,8559,8408,17,366,80,4096,2421,8204,12377,257,4113,1,593]

theorem envBound44243 : H12AffineFastState.Bounded env44243 := by
  intro p hp
  have h : env44243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44231_44243 : H12AffineEnvironment.transform 9 321 env44231 = env44243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env44231 == env44243) = true)

theorem identity44243 : scanCanonicalize (H12AffineFastState.compose env44243 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound44243 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env44244 : List Nat := [2,4,8,16,32,64,128,20,512,85,2048,4096,8192,81,12360,12395,0,12522,4,12361,4096,200,16,8315,8408,17,122,80,4096,2145,8204,12377,21,4113,1,593]

theorem envBound44244 : H12AffineFastState.Bounded env44244 := by
  intro p hp
  have h : env44244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44243_44244 : H12AffineEnvironment.transform 7 20 env44243 = env44244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env44243 == env44244) = true)

def env44245 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1344,262144,77934,32769,4096,46528,16,266384,70887,78894,77841,1297,74814,81226,365713,308666,257,74798,1344,79470]

theorem envBound44245 : H12AffineFastState.Bounded env44245 := by
  intro p hp
  have h : env44245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44209_44245 : H12AffineEnvironment.transform 13 1297 env44209 = env44245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env44209 == env44245) = true)

theorem identity44245 : scanCanonicalize (H12AffineFastState.compose env44245 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32882) := by decide +kernel

theorem selectedBound44245 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env44246 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,32882,1344,262144,45084,32769,4096,46528,16,266384,38037,46172,45155,1297,42060,48440,267491,308666,257,42076,1344,46620]

theorem envBound44246 : H12AffineFastState.Bounded env44246 := by
  intro p hp
  have h : env44246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44245_44246 : H12AffineEnvironment.transform 15 32882 env44245 = env44246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32882 env44245 == env44246) = true)

def env44247 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32882,1344,262144,42332,32769,1344,41088,16,263632,33237,41244,42275,1297,42060,43128,262563,303354,257,42076,1344,41820]

theorem envBound44247 : H12AffineFastState.Bounded env44247 := by
  intro p hp
  have h : env44247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44246_44247 : H12AffineEnvironment.transform 11 1344 env44246 = env44247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env44246 == env44247) = true)

theorem identity44247 : scanCanonicalize (H12AffineFastState.compose env44247 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 438) := by decide +kernel

theorem selectedBound44247 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env44248 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32882,1344,438,42332,32769,1344,41088,16,1126,33237,41244,42275,1297,42060,43128,21,41292,257,42076,1344,41820]

theorem envBound44248 : H12AffineFastState.Bounded env44248 := by
  intro p hp
  have h : env44248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44247_44248 : H12AffineEnvironment.transform 17 438 env44247 = env44248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 438 env44247 == env44248) = true)

theorem identity44248 : scanCanonicalize (H12AffineFastState.compose env44248 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound44248 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env44249 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,8540,8494,1344,438,1024,8541,1344,476,16,1126,8329,64,1151,1297,1296,2340,21,16,257,1280,1344,512]

theorem envBound44249 : H12AffineFastState.Bounded env44249 := by
  intro p hp
  have h : env44249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44248_44249 : H12AffineEnvironment.transform 14 8540 env44248 = env44249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env44248 == env44249) = true)

theorem identity44249 : scanCanonicalize (H12AffineFastState.compose env44249 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 85) := by decide +kernel

theorem selectedBound44249 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env44250 : List Nat := [2,4,8,16,32,64,128,256,512,85,2048,277,8192,324,8540,8494,277,438,85,8541,277,476,16,51,8329,64,42,324,325,2340,21,16,257,341,277,512]

theorem envBound44250 : H12AffineFastState.Bounded env44250 := by
  intro p hp
  have h : env44250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44249_44250 : H12AffineEnvironment.transform 9 85 env44249 = env44250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env44249 == env44250) = true)

theorem identity44250 : scanCanonicalize (H12AffineFastState.compose env44250 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 705) := by decide +kernel

theorem selectedBound44250 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env44251 : List Nat := [2,4,8,16,32,64,128,256,512,85,2048,277,705,324,925,1007,277,438,85,924,277,476,16,51,584,64,42,324,325,2340,21,16,257,341,277,512]

theorem envBound44251 : H12AffineFastState.Bounded env44251 := by
  intro p hp
  have h : env44251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44250_44251 : H12AffineEnvironment.transform 12 705 env44250 = env44251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 705 env44250 == env44251) = true)

theorem identity44251 : scanCanonicalize (H12AffineFastState.compose env44251 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound44251 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env44252 : List Nat := [2,4,8,16,32,16,128,256,512,5,2048,277,657,276,925,959,277,438,5,924,277,396,16,51,536,16,42,276,277,2340,21,16,257,261,277,512]

theorem envBound44252 : H12AffineFastState.Bounded env44252 := by
  intro p hp
  have h : env44252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44251_44252 : H12AffineEnvironment.transform 5 16 env44251 = env44252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env44251 == env44252) = true)

theorem identity44252 : scanCanonicalize (H12AffineFastState.compose env44252 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound44252 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env44253 : List Nat := [2,4,8,16,32,16,128,37,512,5,2048,48,657,49,696,666,48,147,5,697,48,169,16,51,536,16,42,49,48,2049,21,16,36,32,48,512]

theorem envBound44253 : H12AffineFastState.Bounded env44253 := by
  intro p hp
  have h : env44253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44252_44253 : H12AffineEnvironment.transform 7 37 env44252 = env44253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env44252 == env44253) = true)

theorem identity44253 : scanCanonicalize (H12AffineFastState.compose env44253 (packedSelected [0,2,5] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound44253 : packedSelected [0,2,5] rootPS < 2^1333 := by decide +kernel

def env44254 : List Nat := [2,4,8,16,32,16,128,37,512,5,513,48,657,49,696,666,48,147,5,697,48,169,16,51,536,16,42,49,48,512,21,16,36,32,48,512]

theorem envBound44254 : H12AffineFastState.Bounded env44254 := by
  intro p hp
  have h : env44254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44253_44254 : H12AffineEnvironment.transform 10 513 env44253 = env44254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env44253 == env44254) = true)

theorem identity44254 : scanCanonicalize (H12AffineFastState.compose env44254 (packedSelected [1,2,3,4,9] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound44254 : packedSelected [1,2,3,4,9] rootPS < 2^1333 := by decide +kernel

def env44255 : List Nat := [2,4,8,16,32,16,18,37,512,5,513,48,515,49,554,520,48,1,5,555,48,59,16,51,536,16,42,49,48,512,21,16,36,32,48,512]

theorem envBound44255 : H12AffineFastState.Bounded env44255 := by
  intro p hp
  have h : env44255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44254_44255 : H12AffineEnvironment.transform 6 18 env44254 = env44255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env44254 == env44255) = true)

theorem identity44255 : scanCanonicalize (H12AffineFastState.compose env44255 (packedSelected [0,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound44255 : packedSelected [0,2,3] rootPS < 2^1333 := by decide +kernel

def env44256 : List Nat := [2,4,8,16,32,16,18,37,49,5,48,48,50,49,27,57,48,1,5,26,48,59,16,51,41,16,42,49,48,49,21,16,36,32,48,49]

theorem envBound44256 : H12AffineFastState.Bounded env44256 := by
  intro p hp
  have h : env44256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44255_44256 : H12AffineEnvironment.transform 8 49 env44255 = env44256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env44255 == env44256) = true)

theorem identity44256 : scanCanonicalize (H12AffineFastState.compose env44256 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound44256 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44257 : List Nat := [2,4,8,16,16,16,18,21,1,5,0,0,2,1,27,9,0,1,5,26,0,11,16,3,25,16,26,1,0,1,21,16,20,16,0,1]

theorem envBound44257 : H12AffineFastState.Bounded env44257 := by
  intro p hp
  have h : env44257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44256_44257 : H12AffineEnvironment.transform 4 16 env44256 = env44257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env44256 == env44257) = true)

theorem identity44257 : scanCanonicalize (H12AffineFastState.compose env44257 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound44257 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44258 : List Nat := [2,4,8,12,12,12,14,9,1,5,0,0,2,1,7,9,0,1,5,6,0,11,12,3,5,12,6,1,0,1,9,12,8,12,0,1]

theorem envBound44258 : H12AffineFastState.Bounded env44258 := by
  intro p hp
  have h : env44258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44257_44258 : H12AffineEnvironment.transform 3 12 env44257 = env44258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env44257 == env44258) = true)

theorem identity44258 : scanCanonicalize (H12AffineFastState.compose env44258 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound44258 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env44259 : List Nat := [2,3,8,11,11,11,9,9,1,2,0,0,2,1,0,9,0,1,2,1,0,11,11,3,2,11,1,1,0,1,9,11,8,11,0,1]

theorem envBound44259 : H12AffineFastState.Bounded env44259 := by
  intro p hp
  have h : env44259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44258_44259 : H12AffineEnvironment.transform 1 3 env44258 = env44259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env44258 == env44259) = true)

def env44260 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32882,1344,262144,42333,32769,1345,41089,16,263633,33236,41245,42274,1297,42060,43129,262562,303355,257,42076,1344,41821]

theorem envBound44260 : H12AffineFastState.Bounded env44260 := by
  intro p hp
  have h : env44260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44246_44260 : H12AffineEnvironment.transform 11 1345 env44246 = env44260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env44246 == env44260) = true)

theorem identity44260 : scanCanonicalize (H12AffineFastState.compose env44260 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 325) := by decide +kernel

theorem selectedBound44260 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env44261 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,325,311,1344,262144,9240,324,1345,8644,16,263633,145,8280,9319,1297,9481,10556,262562,270782,257,9497,1344,8728]

theorem envBound44261 : H12AffineFastState.Bounded env44261 := by
  intro p hp
  have h : env44261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44260_44261 : H12AffineEnvironment.transform 14 325 env44260 = env44261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 325 env44260 == env44261) = true)

theorem identity44261 : scanCanonicalize (H12AffineFastState.compose env44261 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound44261 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env44262 : List Nat := [2,4,8,16,32,64,128,256,293,1024,2048,1345,8192,1297,325,311,1344,262144,9240,324,1345,8644,16,263633,145,8280,9319,1297,9481,10556,262562,270782,257,9497,1344,8509]

theorem envBound44262 : H12AffineFastState.Bounded env44262 := by
  intro p hp
  have h : env44262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44261_44262 : H12AffineEnvironment.transform 8 293 env44261 = env44262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env44261 == env44262) = true)

def env44263 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147521,16777216,33554432,672785,134217728,148800,33584584,96346,50962568,4294967296,34088328,4345352435,151462017,33563273]

theorem envBound44263 : H12AffineFastState.Bounded env44263 := by
  intro p hp
  have h : env44263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43151_44263 : H12AffineEnvironment.transform 20 4097 env43151 = env44263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env43151 == env44263) = true)

theorem identity44263 : scanCanonicalize (H12AffineFastState.compose env44263 (packedSelected [14] rootPS)) = affineNative (2^(31+1) ^^^ 168797283) := by decide +kernel

theorem selectedBound44263 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env44264 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147521,16777216,33554432,672785,134217728,148800,33584584,96346,50962568,168797283,34088328,152007824,151462017,33563273]

theorem envBound44264 : H12AffineFastState.Bounded env44264 := by
  intro p hp
  have h : env44264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44263_44264 : H12AffineEnvironment.transform 31 168797283 env44263 = env44264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 168797283 env44263 == env44264) = true)

def env44265 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147521,16777216,533640,672785,134217728,148800,545088,96346,16876544,134709483,256,152007824,151462017,525825]

theorem envBound44265 : H12AffineFastState.Bounded env44265 := by
  intro p hp
  have h : env44265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44264_44265 : H12AffineEnvironment.transform 24 533640 env44264 = env44265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 533640 env44264 == env44265) = true)

def env44266 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147521,16777216,533640,672785,17245632,148800,545088,96346,16876544,16819499,256,545104,1345,525825]

theorem envBound44266 : H12AffineFastState.Bounded env44266 := by
  intro p hp
  have h : env44266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44265_44266 : H12AffineEnvironment.transform 26 17245632 env44265 = env44266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245632 env44265 == env44266) = true)

theorem identity44266 : scanCanonicalize (H12AffineFastState.compose env44266 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 41002) := by decide +kernel

theorem selectedBound44266 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env44267 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147521,41002,533640,672785,493034,148800,545088,96346,74794,1281,256,545104,1345,525825]

theorem envBound44267 : H12AffineFastState.Bounded env44267 := by
  intro p hp
  have h : env44267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44266_44267 : H12AffineEnvironment.transform 23 41002 env44266 = env44267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41002 env44266 == env44267) = true)

def env44268 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147521,41002,143496,20497,493034,148800,148800,96346,74794,1281,256,148816,1345,135681]

theorem envBound44268 : H12AffineFastState.Bounded env44268 := by
  intro p hp
  have h : env44268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44267_44268 : H12AffineEnvironment.transform 18 136192 env44267 = env44268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136192 env44267 == env44268) = true)

def env44269 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147521,41002,143496,20497,492614,148716,148716,96346,74794,1197,172,148732,1261,135681]

theorem envBound44269 : H12AffineFastState.Bounded env44269 := by
  intro p hp
  have h : env44269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44268_44269 : H12AffineEnvironment.transform 7 172 env44268 = env44269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env44268 == env44269) = true)

def env44270 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61568,147473,41002,143496,20497,492566,148668,148668,96266,74794,1197,172,148652,1213,135681]

theorem envBound44270 : H12AffineFastState.Bounded env44270 := by
  intro p hp
  have h : env44270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44269_44270 : H12AffineEnvironment.transform 5 16 env44269 = env44270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env44269 == env44270) = true)

theorem identity44270 : scanCanonicalize (H12AffineFastState.compose env44270 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 137352) := by decide +kernel

theorem selectedBound44270 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env44271 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,137352,136192,32769,4097,61568,147473,41002,143496,20497,105630,148668,148668,96266,74794,1197,172,148652,1213,135681]

theorem envBound44271 : H12AffineFastState.Bounded env44271 := by
  intro p hp
  have h : env44271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44270_44271 : H12AffineEnvironment.transform 17 137352 env44270 = env44271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137352 env44270 == env44271) = true)

theorem identity44271 : scanCanonicalize (H12AffineFastState.compose env44271 (packedSelected [1,5,8,18,19,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 13374) := by decide +kernel

theorem selectedBound44271 : packedSelected [1,5,8,18,19,23,24,26] rootPS < 2^1333 := by decide +kernel

def env44272 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,13374,131072,137352,136192,32769,4097,61568,147473,41002,143496,20497,43168,148668,148668,19508,4116,1197,172,148652,1213,135681]

theorem envBound44272 : H12AffineFastState.Bounded env44272 := by
  intro p hp
  have h : env44272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44271_44272 : H12AffineEnvironment.transform 15 13374 env44271 = env44272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13374 env44271 == env44272) = true)

theorem identity44272 : scanCanonicalize (H12AffineFastState.compose env44272 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound44272 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env44273 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1213,32768,13374,131072,137352,136192,32769,4097,46141,132268,41002,143496,5292,43168,131073,131073,2185,4116,1197,172,131089,1213,135681]

theorem envBound44273 : H12AffineFastState.Bounded env44273 := by
  intro p hp
  have h : env44273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44272_44273 : H12AffineEnvironment.transform 13 1213 env44272 = env44273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env44272 == env44273) = true)

theorem identity44273 : scanCanonicalize (H12AffineFastState.compose env44273 (packedSelected [13,17] rootPS)) = affineNative (2^(14+1) ^^^ 9380) := by decide +kernel

theorem selectedBound44273 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env44274 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1213,9380,13374,131072,137352,136192,9381,4097,4249,132268,1166,143496,5292,3076,131073,131073,2185,4116,1197,172,131089,1213,135681]

theorem envBound44274 : H12AffineFastState.Bounded env44274 := by
  intro p hp
  have h : env44274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44273_44274 : H12AffineEnvironment.transform 14 9380 env44273 = env44274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9380 env44273 == env44274) = true)

theorem identity44274 : scanCanonicalize (H12AffineFastState.compose env44274 (packedSelected [6,12,13,15] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound44274 : packedSelected [6,12,13,15] rootPS < 2^1333 := by decide +kernel

def env44275 : List Nat := [2,4,8,16,32,16,128,172,512,4,2048,4096,8192,185,8352,12346,131072,137352,135172,8353,4097,4249,131240,138,143496,4264,2048,131073,131073,2185,4116,169,172,131089,185,135681]

theorem envBound44275 : H12AffineFastState.Bounded env44275 := by
  intro p hp
  have h : env44275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44274_44275 : H12AffineEnvironment.transform 9 4 env44274 = env44275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env44274 == env44275) = true)

theorem identity44275 : scanCanonicalize (H12AffineFastState.compose env44275 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 145) := by decide +kernel

theorem selectedBound44275 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env44276 : List Nat := [2,4,8,16,32,16,128,172,512,4,2048,4096,145,185,49,4267,131072,137352,135172,48,4097,4249,131240,138,135193,4264,2048,131073,131073,2185,4116,169,172,131089,185,135681]

theorem envBound44276 : H12AffineFastState.Bounded env44276 := by
  intro p hp
  have h : env44276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44275_44276 : H12AffineEnvironment.transform 12 145 env44275 = env44276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 145 env44275 == env44276) = true)

theorem identity44276 : scanCanonicalize (H12AffineFastState.compose env44276 (packedSelected [0,1,3,4,6,10] rootPS)) = affineNative (2^(16+1) ^^^ 4634) := by decide +kernel

theorem selectedBound44276 : packedSelected [0,1,3,4,6,10] rootPS < 2^1333 := by decide +kernel

def env44277 : List Nat := [2,4,8,16,32,16,128,172,512,4,2048,4096,145,185,49,4267,4634,2706,542,48,4097,4249,4786,138,515,4264,2048,4635,4635,2185,4116,169,172,4619,185,27]

theorem envBound44277 : H12AffineFastState.Bounded env44277 := by
  intro p hp
  have h : env44277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44276_44277 : H12AffineEnvironment.transform 16 4634 env44276 = env44277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4634 env44276 == env44277) = true)

theorem identity44277 : scanCanonicalize (H12AffineFastState.compose env44277 (packedSelected [3,5] rootPS)) = affineNative (2^(11+1) ^^^ 2723) := by decide +kernel

theorem selectedBound44277 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env44278 : List Nat := [2,4,8,16,32,16,128,172,512,4,2048,2723,145,185,49,2568,2233,2706,542,48,2722,2618,2065,138,515,2571,2048,2232,2232,2185,2743,169,172,2216,185,27]

theorem envBound44278 : H12AffineFastState.Bounded env44278 := by
  intro p hp
  have h : env44278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44277_44278 : H12AffineEnvironment.transform 11 2723 env44277 = env44278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2723 env44277 == env44278) = true)

theorem identity44278 : scanCanonicalize (H12AffineFastState.compose env44278 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound44278 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44279 : List Nat := [2,4,8,16,32,16,18,62,512,4,2048,2609,3,43,49,2568,2091,2560,542,48,2608,2618,2065,24,515,2571,2048,2090,2090,2075,2597,59,62,2106,43,27]

theorem envBound44279 : H12AffineFastState.Bounded env44279 := by
  intro p hp
  have h : env44279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44278_44279 : H12AffineEnvironment.transform 6 18 env44278 = env44279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env44278 == env44279) = true)

theorem identity44279 : scanCanonicalize (H12AffineFastState.compose env44279 (packedSelected [1,4,6,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound44279 : packedSelected [1,4,6,7,8] rootPS < 2^1333 := by decide +kernel

def env44280 : List Nat := [2,4,8,16,32,16,18,62,512,4,26,555,3,43,49,530,49,538,542,48,554,544,11,24,515,529,26,48,48,1,575,59,62,32,43,27]

theorem envBound44280 : H12AffineFastState.Bounded env44280 := by
  intro p hp
  have h : env44280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44279_44280 : H12AffineEnvironment.transform 10 26 env44279 = env44280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env44279 == env44280) = true)

theorem identity44280 : scanCanonicalize (H12AffineFastState.compose env44280 (packedSelected [0,1,4] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound44280 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env44281 : List Nat := [2,4,8,13,32,13,15,35,512,4,7,555,3,43,44,527,44,519,515,45,554,544,11,5,515,524,7,45,45,1,546,38,35,32,43,6]

theorem envBound44281 : H12AffineFastState.Bounded env44281 := by
  intro p hp
  have h : env44281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44280_44281 : H12AffineEnvironment.transform 3 13 env44280 = env44281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env44280 == env44281) = true)

theorem identity44281 : scanCanonicalize (H12AffineFastState.compose env44281 (packedSelected [6] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound44281 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env44282 : List Nat := [2,4,8,13,32,13,15,35,42,4,7,1,3,43,44,37,44,45,41,45,0,10,11,5,41,38,7,45,45,1,8,38,35,32,43,6]

theorem envBound44282 : H12AffineFastState.Bounded env44282 := by
  intro p hp
  have h : env44282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44281_44282 : H12AffineEnvironment.transform 8 42 env44281 = env44282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env44281 == env44282) = true)

theorem identity44282 : scanCanonicalize (H12AffineFastState.compose env44282 (packedSelected [3,11] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound44282 : packedSelected [3,11] rootPS < 2^1333 := by decide +kernel

def env44283 : List Nat := [2,4,8,13,13,13,15,14,7,4,7,1,3,6,1,8,1,0,4,0,0,10,11,5,4,11,7,0,0,1,8,11,14,13,6,6]

theorem envBound44283 : H12AffineFastState.Bounded env44283 := by
  intro p hp
  have h : env44283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44282_44283 : H12AffineEnvironment.transform 4 13 env44282 = env44283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env44282 == env44283) = true)

theorem identity44283 : scanCanonicalize (H12AffineFastState.compose env44283 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound44283 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44284 : List Nat := [0,4,8,13,13,13,13,12,5,4,5,1,1,4,1,8,1,0,4,0,0,8,9,5,4,9,5,0,0,1,8,9,12,13,4,4]

theorem envBound44284 : H12AffineFastState.Bounded env44284 := by
  intro p hp
  have h : env44284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44283_44284 : H12AffineEnvironment.transform 0 0 env44283 = env44284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env44283 == env44284) = true)

theorem identity44284 : scanCanonicalize (H12AffineFastState.compose env44284 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound44284 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44285 : List Nat := [0,4,0,5,5,5,5,4,5,4,5,1,1,4,1,0,1,0,4,0,0,0,1,5,4,1,5,0,0,1,0,1,4,5,4,4]

theorem envBound44285 : H12AffineFastState.Bounded env44285 := by
  intro p hp
  have h : env44285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44284_44285 : H12AffineEnvironment.transform 2 0 env44284 = env44285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env44284 == env44285) = true)

def env44286 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61569,147472,41002,143496,20497,492567,148669,148669,96267,74794,1197,172,148653,1212,135681]

theorem envBound44286 : H12AffineFastState.Bounded env44286 := by
  intro p hp
  have h : env44286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44269_44286 : H12AffineEnvironment.transform 5 17 env44269 = env44286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env44269 == env44286) = true)

theorem identity44286 : scanCanonicalize (H12AffineFastState.compose env44286 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 45216) := by decide +kernel

theorem selectedBound44286 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env44287 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,45216,262144,42144,32769,4097,61569,61616,41002,32808,20497,341175,62493,62493,96267,74794,1197,172,62477,1212,41633]

theorem envBound44287 : H12AffineFastState.Bounded env44287 := by
  intro p hp
  have h : env44287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44286_44287 : H12AffineEnvironment.transform 16 45216 env44286 = env44287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45216 env44286 == env44287) = true)

theorem identity44287 : scanCanonicalize (H12AffineFastState.compose env44287 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound44287 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env44288 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1213,32768,65536,45216,262144,42144,32769,4097,46140,46093,41002,32808,5292,341175,45216,45216,81078,74794,1197,172,45232,1212,41633]

theorem envBound44288 : H12AffineFastState.Bounded env44288 := by
  intro p hp
  have h : env44288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44287_44288 : H12AffineEnvironment.transform 13 1213 env44287 = env44288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env44287 == env44288) = true)

theorem identity44288 : scanCanonicalize (H12AffineFastState.compose env44288 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 33830) := by decide +kernel

theorem selectedBound44288 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env44289 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1213,32768,33830,45216,262144,42144,32769,4097,46140,46093,41002,32808,5292,307345,45216,45216,47248,40972,1197,172,45232,1212,41633]

theorem envBound44289 : H12AffineFastState.Bounded env44289 := by
  intro p hp
  have h : env44289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44288_44289 : H12AffineEnvironment.transform 15 33830 env44288 = env44289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33830 env44288 == env44289) = true)

theorem identity44289 : scanCanonicalize (H12AffineFastState.compose env44289 (packedSelected [4,9,20] rootPS)) = affineNative (2^(11+1) ^^^ 185) := by decide +kernel

theorem selectedBound44289 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env44290 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,185,8192,1213,32768,33830,40985,262144,42144,32769,184,42117,42164,41002,32808,1045,303144,40985,40985,43049,40972,1197,172,40969,1212,41633]

theorem envBound44290 : H12AffineFastState.Bounded env44290 := by
  intro p hp
  have h : env44290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44289_44290 : H12AffineEnvironment.transform 11 185 env44289 = env44290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 185 env44289 == env44290) = true)

theorem identity44290 : scanCanonicalize (H12AffineFastState.compose env44290 (packedSelected [1,3,5,6,8,13] rootPS)) = affineNative (2^(17+1) ^^^ 43048) := by decide +kernel

theorem selectedBound44290 : packedSelected [1,3,5,6,8,13] rootPS < 2^1333 := by decide +kernel

def env44291 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,185,8192,1213,32768,33830,40985,43048,42144,32769,184,42117,42164,41002,32808,1045,2048,40985,40985,43049,40972,1197,172,40969,1212,41633]

theorem envBound44291 : H12AffineFastState.Bounded env44291 := by
  intro p hp
  have h : env44291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44290_44291 : H12AffineEnvironment.transform 17 43048 env44290 = env44291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43048 env44290 == env44291) = true)

theorem identity44291 : scanCanonicalize (H12AffineFastState.compose env44291 (packedSelected [2,3,4,6,8,9] rootPS)) = affineNative (2^(14+1) ^^^ 8707) := by decide +kernel

theorem selectedBound44291 : packedSelected [2,3,4,6,8,9] rootPS < 2^1333 := by decide +kernel

def env44292 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,185,8192,1213,8707,9765,538,2603,1699,8706,184,1670,1719,553,8747,1045,2048,538,538,2602,527,1197,172,522,1212,162]

theorem envBound44292 : H12AffineFastState.Bounded env44292 := by
  intro p hp
  have h : env44292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44291_44292 : H12AffineEnvironment.transform 14 8707 env44291 = env44292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8707 env44291 == env44292) = true)

theorem identity44292 : scanCanonicalize (H12AffineFastState.compose env44292 (packedSelected [0,1,3,6,7,10] rootPS)) = affineNative (2^(12+1) ^^^ 2051) := by decide +kernel

theorem selectedBound44292 : packedSelected [0,1,3,6,7,10] rootPS < 2^1333 := by decide +kernel

def env44293 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,185,2051,1213,2560,3622,538,2603,1699,2561,184,1670,1719,553,2600,1045,2048,538,538,2602,527,1197,172,522,1212,162]

theorem envBound44293 : H12AffineFastState.Bounded env44293 := by
  intro p hp
  have h : env44293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44292_44293 : H12AffineEnvironment.transform 12 2051 env44292 = env44293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2051 env44292 == env44293) = true)

theorem identity44293 : scanCanonicalize (H12AffineFastState.compose env44293 (packedSelected [1,2,4,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 185) := by decide +kernel

theorem selectedBound44293 : packedSelected [1,2,4,5,7] rootPS < 2^1333 := by decide +kernel

def env44294 : List Nat := [2,4,8,16,32,17,128,172,512,1024,185,185,186,1213,697,1695,538,658,1699,696,184,1670,1719,553,657,1045,185,538,538,659,527,1197,172,522,1212,162]

theorem envBound44294 : H12AffineFastState.Bounded env44294 := by
  intro p hp
  have h : env44294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44293_44294 : H12AffineEnvironment.transform 10 185 env44293 = env44294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 185 env44293 == env44294) = true)

theorem identity44294 : scanCanonicalize (H12AffineFastState.compose env44294 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound44294 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env44295 : List Nat := [2,4,8,16,32,17,56,20,512,1024,1,1,2,1029,513,1575,538,554,1563,512,0,1598,1551,553,553,1045,1,538,538,555,527,1045,20,522,1028,26]

theorem envBound44295 : H12AffineFastState.Bounded env44295 := by
  intro p hp
  have h : env44295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44294_44295 : H12AffineEnvironment.transform 6 56 env44294 = env44295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env44294 == env44295) = true)

theorem identity44295 : scanCanonicalize (H12AffineFastState.compose env44295 (packedSelected [3,5] rootPS)) = affineNative (2^(9+1) ^^^ 47) := by decide +kernel

theorem selectedBound44295 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env44296 : List Nat := [2,4,8,16,32,17,56,20,512,47,1,1,2,42,513,520,538,554,564,512,0,529,544,553,553,58,1,538,538,555,527,58,20,522,43,26]

theorem envBound44296 : H12AffineFastState.Bounded env44296 := by
  intro p hp
  have h : env44296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44295_44296 : H12AffineEnvironment.transform 9 47 env44295 = env44296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 47 env44295 == env44296) = true)

theorem identity44296 : scanCanonicalize (H12AffineFastState.compose env44296 (packedSelected [3,8] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound44296 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env44297 : List Nat := [2,4,8,16,32,17,56,20,49,47,1,1,2,42,48,57,43,27,5,49,0,32,17,24,24,58,1,43,43,26,62,58,20,59,43,26]

theorem envBound44297 : H12AffineFastState.Bounded env44297 := by
  intro p hp
  have h : env44297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44296_44297 : H12AffineEnvironment.transform 8 49 env44296 = env44297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env44296 == env44297) = true)

theorem identity44297 : scanCanonicalize (H12AffineFastState.compose env44297 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound44297 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44298 : List Nat := [2,4,8,16,6,17,30,20,23,9,1,1,2,12,22,31,13,27,5,23,0,6,17,24,24,28,1,13,13,26,24,28,20,29,13,26]

theorem envBound44298 : H12AffineFastState.Bounded env44298 := by
  intro p hp
  have h : env44298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44297_44298 : H12AffineEnvironment.transform 4 6 env44297 = env44298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env44297 == env44298) = true)

theorem identity44298 : scanCanonicalize (H12AffineFastState.compose env44298 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound44298 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env44299 : List Nat := [2,4,8,7,6,6,9,3,0,9,1,1,2,12,1,8,13,12,5,0,0,6,6,15,15,11,1,13,13,13,15,11,3,10,13,13]

theorem envBound44299 : H12AffineFastState.Bounded env44299 := by
  intro p hp
  have h : env44299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44298_44299 : H12AffineEnvironment.transform 3 7 env44298 = env44299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env44298 == env44299) = true)

theorem identity44299 : scanCanonicalize (H12AffineFastState.compose env44299 (packedSelected [0,4,11] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound44299 : packedSelected [0,4,11] rootPS < 2^1333 := by decide +kernel

def env44300 : List Nat := [2,4,5,7,6,6,4,3,0,4,1,1,2,1,1,5,0,1,5,0,0,6,6,2,2,6,1,0,0,0,2,6,3,7,0,0]

theorem envBound44300 : H12AffineFastState.Bounded env44300 := by
  intro p hp
  have h : env44300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44299_44300 : H12AffineEnvironment.transform 2 5 env44299 = env44300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env44299 == env44300) = true)

def env44301 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147521,41002,143496,20497,492615,148717,148717,96346,74794,1196,173,148733,1260,135681]

theorem envBound44301 : H12AffineFastState.Bounded env44301 := by
  intro p hp
  have h : env44301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44268_44301 : H12AffineEnvironment.transform 7 173 env44268 = env44301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env44268 == env44301) = true)

def env44302 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61568,147473,41002,143496,20497,492567,148669,148669,96266,74794,1196,173,148653,1212,135681]

theorem envBound44302 : H12AffineFastState.Bounded env44302 := by
  intro p hp
  have h : env44302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44301_44302 : H12AffineEnvironment.transform 5 16 env44301 = env44302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env44301 == env44302) = true)

theorem identity44302 : scanCanonicalize (H12AffineFastState.compose env44302 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 223242) := by decide +kernel

theorem selectedBound44302 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env44303 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,223242,136192,32769,4097,61568,147473,41002,143496,20497,60445,148669,148669,96266,74794,1196,173,148653,1212,135681]

theorem envBound44303 : H12AffineFastState.Bounded env44303 := by
  intro p hp
  have h : env44303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44302_44303 : H12AffineEnvironment.transform 17 223242 env44302 = env44303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223242 env44302 == env44303) = true)

theorem identity44303 : scanCanonicalize (H12AffineFastState.compose env44303 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 28803) := by decide +kernel

theorem selectedBound44303 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env44304 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,28803,131072,137353,136192,32769,4097,61568,147473,41002,143496,20497,60445,148669,148669,2185,21673,1196,173,148653,1212,135681]

theorem envBound44304 : H12AffineFastState.Bounded env44304 := by
  intro p hp
  have h : env44304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44303_44304 : H12AffineEnvironment.transform 15 28803 env44303 = env44304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28803 env44303 == env44304) = true)

theorem identity44304 : scanCanonicalize (H12AffineFastState.compose env44304 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(14+1) ^^^ 29861) := by decide +kernel

theorem selectedBound44304 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env44305 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,29861,28803,131072,137353,136192,29860,4097,1061,147473,21647,143496,20497,6328,148669,148669,2185,21673,1196,173,148653,1212,135681]

theorem envBound44305 : H12AffineFastState.Bounded env44305 := by
  intro p hp
  have h : env44305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44304_44305 : H12AffineEnvironment.transform 14 29861 env44304 = env44305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29861 env44304 == env44305) = true)

theorem identity44305 : scanCanonicalize (H12AffineFastState.compose env44305 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound44305 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env44306 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1212,12313,13375,131072,137353,136192,12312,4097,1061,132269,4147,143496,5293,6328,131073,131073,2185,4117,1196,173,131089,1212,135681]

theorem envBound44306 : H12AffineFastState.Bounded env44306 := by
  intro p hp
  have h : env44306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44305_44306 : H12AffineEnvironment.transform 13 1212 env44305 = env44306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env44305 == env44306) = true)

theorem identity44306 : scanCanonicalize (H12AffineFastState.compose env44306 (packedSelected [0,4,5,7,8,9,10,13] rootPS)) = affineNative (2^(16+1) ^^^ 10378) := by decide +kernel

theorem selectedBound44306 : packedSelected [0,4,5,7,8,9,10,13] rootPS < 2^1333 := by decide +kernel

def env44307 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1212,12313,13375,10378,12291,15498,12312,4097,1061,11303,4147,6146,5293,6328,10379,10379,2185,4117,1196,173,10395,1212,14987]

theorem envBound44307 : H12AffineFastState.Bounded env44307 := by
  intro p hp
  have h : env44307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44306_44307 : H12AffineEnvironment.transform 16 10378 env44306 = env44307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 10378 env44306 == env44307) = true)

theorem identity44307 : scanCanonicalize (H12AffineFastState.compose env44307 (packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound44307 : packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env44308 : List Nat := [2,4,8,16,32,16,128,173,512,4,2048,4096,8192,184,12313,12347,10378,12291,14478,12312,4097,33,10275,4147,6146,4265,6328,10379,10379,2185,4117,168,173,10395,184,14987]

theorem envBound44308 : H12AffineFastState.Bounded env44308 := by
  intro p hp
  have h : env44308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44307_44308 : H12AffineEnvironment.transform 9 4 env44307 = env44308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env44307 == env44308) = true)

theorem identity44308 : scanCanonicalize (H12AffineFastState.compose env44308 (packedSelected [1,2,3,6,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 2611) := by decide +kernel

theorem selectedBound44308 : packedSelected [1,2,3,6,10,11] rootPS < 2^1333 := by decide +kernel

def env44309 : List Nat := [2,4,8,16,32,16,128,173,512,4,2048,4096,2611,184,6698,6664,697,6704,4797,6699,4097,33,528,4147,6146,4265,6328,696,696,2185,4117,168,173,680,184,4280]

theorem envBound44309 : H12AffineFastState.Bounded env44309 := by
  intro p hp
  have h : env44309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44308_44309 : H12AffineEnvironment.transform 12 2611 env44308 = env44309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2611 env44308 == env44309) = true)

theorem identity44309 : scanCanonicalize (H12AffineFastState.compose env44309 (packedSelected [5,6,7,9,12] rootPS)) = affineNative (2^(8+1) ^^^ 132) := by decide +kernel

theorem selectedBound44309 : packedSelected [5,6,7,9,12] rootPS < 2^1333 := by decide +kernel

def env44310 : List Nat := [2,4,8,16,32,16,128,173,132,4,2048,4096,2231,184,6318,6284,61,6324,4153,6319,4097,33,148,4147,6146,4265,6328,60,60,2185,4117,168,173,44,184,4280]

theorem envBound44310 : H12AffineFastState.Bounded env44310 := by
  intro p hp
  have h : env44310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44309_44310 : H12AffineEnvironment.transform 8 132 env44309 = env44310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 132 env44309 == env44310) = true)

theorem identity44310 : scanCanonicalize (H12AffineFastState.compose env44310 (packedSelected [4,5,8,9,16] rootPS)) = affineNative (2^(10+1) ^^^ 163) := by decide +kernel

theorem selectedBound44310 : packedSelected [4,5,8,9,16] rootPS < 2^1333 := by decide +kernel

def env44311 : List Nat := [2,4,8,16,32,16,128,173,132,4,163,4096,20,184,4109,4143,61,4119,4153,4108,4097,33,148,4147,4257,4265,4123,60,60,42,4117,168,173,44,184,4280]

theorem envBound44311 : H12AffineFastState.Bounded env44311 := by
  intro p hp
  have h : env44311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44310_44311 : H12AffineEnvironment.transform 10 163 env44310 = env44311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 163 env44310 == env44311) = true)

theorem identity44311 : scanCanonicalize (H12AffineFastState.compose env44311 (packedSelected [1,5] rootPS)) = affineNative (2^(11+1) ^^^ 185) := by decide +kernel

theorem selectedBound44311 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env44312 : List Nat := [2,4,8,16,32,16,128,173,132,4,163,185,20,184,180,150,61,174,128,181,184,33,148,138,24,16,162,60,60,42,172,168,173,44,184,1]

theorem envBound44312 : H12AffineFastState.Bounded env44312 := by
  intro p hp
  have h : env44312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44311_44312 : H12AffineEnvironment.transform 11 185 env44311 = env44312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 185 env44311 == env44312) = true)

theorem identity44312 : scanCanonicalize (H12AffineFastState.compose env44312 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound44312 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env44313 : List Nat := [2,4,8,16,32,16,18,63,22,4,49,43,20,42,38,4,61,60,18,39,42,33,6,24,24,16,48,60,60,42,62,58,63,44,42,1]

theorem envBound44313 : H12AffineFastState.Bounded env44313 := by
  intro p hp
  have h : env44313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44312_44313 : H12AffineEnvironment.transform 6 18 env44312 = env44313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env44312 == env44313) = true)

def env44314 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61569,147472,41002,143496,20497,492566,148668,148668,96267,74794,1196,173,148652,1213,135681]

theorem envBound44314 : H12AffineFastState.Bounded env44314 := by
  intro p hp
  have h : env44314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44301_44314 : H12AffineEnvironment.transform 5 17 env44301 = env44314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env44301 == env44314) = true)

theorem identity44314 : scanCanonicalize (H12AffineFastState.compose env44314 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 114723) := by decide +kernel

theorem selectedBound44314 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env44315 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,114723,262144,119843,32769,4097,61569,98355,41002,127147,20497,279605,99487,99487,96267,74794,1196,173,99471,1213,119330]

theorem envBound44315 : H12AffineFastState.Bounded env44315 := by
  intro p hp
  have h : env44315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44314_44315 : H12AffineEnvironment.transform 16 114723 env44314 = env44315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114723 env44314 == env44315) = true)

theorem identity44315 : scanCanonicalize (H12AffineFastState.compose env44315 (packedSelected [3,10,16,18,19,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 76814) := by decide +kernel

theorem selectedBound44315 : packedSelected [3,10,16,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env44316 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,114723,76814,119843,32769,4097,61569,98355,41002,127147,20497,92219,99487,99487,96267,74794,1196,173,99471,1213,119330]

theorem envBound44316 : H12AffineFastState.Bounded env44316 := by
  intro p hp
  have h : env44316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44315_44316 : H12AffineEnvironment.transform 17 76814 env44315 = env44316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76814 env44315 == env44316) = true)

theorem identity44316 : scanCanonicalize (H12AffineFastState.compose env44316 (packedSelected [7,16,18,19,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53282) := by decide +kernel

theorem selectedBound44316 : packedSelected [7,16,18,19,23,26,27] rootPS < 2^1333 := by decide +kernel

def env44317 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,53282,4097,64556,1025,32769,4097,61569,20497,41002,8329,20497,47129,21693,21693,43049,62472,1196,173,21677,1213,512]

theorem envBound44317 : H12AffineFastState.Bounded env44317 := by
  intro p hp
  have h : env44317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44316_44317 : H12AffineEnvironment.transform 15 53282 env44316 = env44317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53282 env44316 == env44317) = true)

theorem identity44317 : scanCanonicalize (H12AffineFastState.compose env44317 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound44317 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env44318 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,184,8192,16384,32768,49306,185,60564,1025,32769,185,57401,16553,41002,8329,16553,43169,17413,17413,43049,58544,1196,173,17429,1213,512]

theorem envBound44318 : H12AffineFastState.Bounded env44318 := by
  intro p hp
  have h : env44318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44317_44318 : H12AffineEnvironment.transform 11 184 env44317 = env44318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env44317 == env44318) = true)

theorem identity44318 : scanCanonicalize (H12AffineFastState.compose env44318 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 17032) := by decide +kernel

theorem selectedBound44318 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env44319 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,184,8192,16384,17032,530,185,11804,1025,17033,185,8881,16553,25250,8329,16553,27177,17413,17413,27297,9784,1196,173,17429,1213,512]

theorem envBound44319 : H12AffineFastState.Bounded env44319 := by
  intro p hp
  have h : env44319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44318_44319 : H12AffineEnvironment.transform 14 17032 env44318 = env44319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 17032 env44318 == env44319) = true)

theorem identity44319 : scanCanonicalize (H12AffineFastState.compose env44319 (packedSelected [0,3,4,8,13] rootPS)) = affineNative (2^(13+1) ^^^ 8243) := by decide +kernel

theorem selectedBound44319 : packedSelected [0,3,4,8,13] rootPS < 2^1333 := by decide +kernel

def env44320 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,184,8192,8243,8891,530,185,11804,1025,8890,185,8881,8346,657,8329,8346,2586,9270,9270,2706,9784,1196,173,9254,1213,512]

theorem envBound44320 : H12AffineFastState.Bounded env44320 := by
  intro p hp
  have h : env44320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44319_44320 : H12AffineEnvironment.transform 13 8243 env44319 = env44320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8243 env44319 == env44320) = true)

theorem identity44320 : scanCanonicalize (H12AffineFastState.compose env44320 (packedSelected [2,4,5,8,9,11,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 2600) := by decide +kernel

theorem selectedBound44320 : packedSelected [2,4,5,8,9,11,12,15] rootPS < 2^1333 := by decide +kernel

def env44321 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,184,2600,2587,2195,530,185,1076,1025,2194,185,2201,2738,657,2721,2738,2586,3614,3614,2706,3088,1196,173,3598,1213,512]

theorem envBound44321 : H12AffineFastState.Bounded env44321 := by
  intro p hp
  have h : env44321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44320_44321 : H12AffineEnvironment.transform 12 2600 env44320 = env44321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2600 env44320 == env44321) = true)

theorem identity44321 : scanCanonicalize (H12AffineFastState.compose env44321 (packedSelected [1,3,5,7,8,9,11] rootPS)) = affineNative (2^(9+1) ^^^ 652) := by decide +kernel

theorem selectedBound44321 : packedSelected [1,3,5,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env44322 : List Nat := [2,4,8,16,32,17,128,173,512,652,2048,184,2600,2587,2195,530,185,696,653,2194,185,2201,2738,657,2721,2738,2586,2194,2194,2706,2716,544,173,2178,561,512]

theorem envBound44322 : H12AffineFastState.Bounded env44322 := by
  intro p hp
  have h : env44322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44321_44322 : H12AffineEnvironment.transform 9 652 env44321 = env44322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 652 env44321 == env44322) = true)

theorem identity44322 : scanCanonicalize (H12AffineFastState.compose env44322 (packedSelected [0,3,5,6,7] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound44322 : packedSelected [0,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env44323 : List Nat := [2,4,8,16,32,17,128,173,0,140,2048,184,2088,2075,2195,18,185,184,141,2194,185,2201,2226,145,2209,2226,2074,2194,2194,2194,2204,32,173,2178,49,0]

theorem envBound44323 : H12AffineFastState.Bounded env44323 := by
  intro p hp
  have h : env44323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44322_44323 : H12AffineEnvironment.transform 8 0 env44322 = env44323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env44322 == env44323) = true)

theorem identity44323 : scanCanonicalize (H12AffineFastState.compose env44323 (packedSelected [1,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound44323 : packedSelected [1,5,6] rootPS < 2^1333 := by decide +kernel

def env44324 : List Nat := [2,4,8,16,32,17,128,173,0,140,48,184,24,43,163,18,185,184,141,162,185,169,130,145,145,130,42,162,162,162,172,32,173,178,49,0]

theorem envBound44324 : H12AffineFastState.Bounded env44324 := by
  intro p hp
  have h : env44324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44323_44324 : H12AffineEnvironment.transform 10 48 env44323 = env44324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env44323 == env44324) = true)

theorem identity44324 : scanCanonicalize (H12AffineFastState.compose env44324 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound44324 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env44325 : List Nat := [2,4,8,11,32,10,128,173,0,140,43,163,3,43,163,9,162,163,141,162,162,169,130,138,138,130,42,162,162,162,172,32,173,169,42,0]

theorem envBound44325 : H12AffineFastState.Bounded env44325 := by
  intro p hp
  have h : env44325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44324_44325 : H12AffineEnvironment.transform 3 11 env44324 = env44325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env44324 == env44325) = true)

theorem identity44325 : scanCanonicalize (H12AffineFastState.compose env44325 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound44325 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44326 : List Nat := [2,4,8,11,10,10,128,135,0,140,1,137,3,1,137,9,136,137,141,136,136,131,130,138,138,130,0,136,136,136,134,10,135,131,0,0]

theorem envBound44326 : H12AffineFastState.Bounded env44326 := by
  intro p hp
  have h : env44326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44325_44326 : H12AffineEnvironment.transform 4 10 env44325 = env44326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env44325 == env44326) = true)

theorem identity44326 : scanCanonicalize (H12AffineFastState.compose env44326 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound44326 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44327 : List Nat := [2,4,5,6,7,7,128,135,0,129,1,132,3,1,132,4,133,132,128,133,133,131,130,135,135,130,0,133,133,133,134,7,135,131,0,0]

theorem envBound44327 : H12AffineFastState.Bounded env44327 := by
  intro p hp
  have h : env44327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44326_44327 : H12AffineEnvironment.transform 2 5 env44326 = env44327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env44326 == env44327) = true)

def env44328 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147521,41002,143497,20496,493034,148800,148801,96346,74794,1281,256,148817,1345,135680]

theorem envBound44328 : H12AffineFastState.Bounded env44328 := by
  intro p hp
  have h : env44328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44267_44328 : H12AffineEnvironment.transform 18 136193 env44267 = env44328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136193 env44267 == env44328) = true)

def env44329 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147521,41002,143497,20496,492614,148716,148717,96346,74794,1197,172,148733,1261,135680]

theorem envBound44329 : H12AffineFastState.Bounded env44329 := by
  intro p hp
  have h : env44329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44328_44329 : H12AffineEnvironment.transform 7 172 env44328 = env44329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env44328 == env44329) = true)

def env44330 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61568,147473,41002,143497,20496,492566,148668,148669,96266,74794,1197,172,148653,1213,135680]

theorem envBound44330 : H12AffineFastState.Bounded env44330 := by
  intro p hp
  have h : env44330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44329_44330 : H12AffineEnvironment.transform 5 16 env44329 = env44330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env44329 == env44330) = true)

theorem identity44330 : scanCanonicalize (H12AffineFastState.compose env44330 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 45217) := by decide +kernel

theorem selectedBound44330 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env44331 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,45217,262144,42144,32769,4097,61568,61616,41002,32808,20496,341175,62493,62492,96266,74794,1197,172,62476,1213,41633]

theorem envBound44331 : H12AffineFastState.Bounded env44331 := by
  intro p hp
  have h : env44331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44330_44331 : H12AffineEnvironment.transform 16 45217 env44330 = env44331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45217 env44330 == env44331) = true)

theorem identity44331 : scanCanonicalize (H12AffineFastState.compose env44331 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound44331 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env44332 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1212,32768,65536,45217,262144,42144,32769,4097,46140,46092,41002,32808,5292,341175,45217,45216,81078,74794,1197,172,45232,1213,41633]

theorem envBound44332 : H12AffineFastState.Bounded env44332 := by
  intro p hp
  have h : env44332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44331_44332 : H12AffineEnvironment.transform 13 1212 env44331 = env44332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env44331 == env44332) = true)

theorem identity44332 : scanCanonicalize (H12AffineFastState.compose env44332 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 33831) := by decide +kernel

theorem selectedBound44332 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env44333 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1212,32768,33831,45217,262144,42144,32769,4097,46140,46092,41002,32808,5292,307344,45217,45216,47249,40973,1197,172,45232,1213,41633]

theorem envBound44333 : H12AffineFastState.Bounded env44333 := by
  intro p hp
  have h : env44333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44332_44333 : H12AffineEnvironment.transform 15 33831 env44332 = env44333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33831 env44332 == env44333) = true)

theorem identity44333 : scanCanonicalize (H12AffineFastState.compose env44333 (packedSelected [4,9,20] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound44333 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env44334 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,184,8192,1212,32768,33831,40985,262144,42144,32769,185,42116,42164,41002,32808,1044,303144,40985,40984,43049,40973,1197,172,40968,1213,41633]

theorem envBound44334 : H12AffineFastState.Bounded env44334 := by
  intro p hp
  have h : env44334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44333_44334 : H12AffineEnvironment.transform 11 184 env44333 = env44334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env44333 == env44334) = true)

theorem identity44334 : scanCanonicalize (H12AffineFastState.compose env44334 (packedSelected [1,3,5,6,8,13] rootPS)) = affineNative (2^(17+1) ^^^ 2185) := by decide +kernel

theorem selectedBound44334 : packedSelected [1,3,5,6,8,13] rootPS < 2^1333 := by decide +kernel

def env44335 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,184,8192,1212,32768,33831,40985,2185,42144,32769,185,42116,42164,41002,32808,1044,43169,40985,40984,43049,40973,1197,172,40968,1213,41633]

theorem envBound44335 : H12AffineFastState.Bounded env44335 := by
  intro p hp
  have h : env44335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44334_44335 : H12AffineEnvironment.transform 17 2185 env44334 = env44335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2185 env44334 == env44335) = true)

theorem identity44335 : scanCanonicalize (H12AffineFastState.compose env44335 (packedSelected [0,3,5,7,10] rootPS)) = affineNative (2^(14+1) ^^^ 3212) := by decide +kernel

theorem selectedBound44335 : packedSelected [0,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env44336 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,184,8192,1212,3212,2219,11413,2185,10284,3213,185,10248,10296,11430,3236,1044,9261,11413,11412,9381,11393,1197,172,11396,1213,11821]

theorem envBound44336 : H12AffineFastState.Bounded env44336 := by
  intro p hp
  have h : env44336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44335_44336 : H12AffineEnvironment.transform 14 3212 env44335 = env44336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 3212 env44335 == env44336) = true)

theorem identity44336 : scanCanonicalize (H12AffineFastState.compose env44336 (packedSelected [1,3,4,5,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound44336 : packedSelected [1,3,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env44337 : List Nat := [2,4,8,16,32,16,128,172,512,1024,513,184,8192,1212,1677,682,9876,648,8749,1676,185,8713,8761,9895,1701,1044,9261,9876,9877,9381,9856,1197,172,9861,1213,9260]

theorem envBound44337 : H12AffineFastState.Bounded env44337 := by
  intro p hp
  have h : env44337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44336_44337 : H12AffineEnvironment.transform 10 513 env44336 = env44337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env44336 == env44337) = true)

theorem identity44337 : scanCanonicalize (H12AffineFastState.compose env44337 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 559) := by decide +kernel

theorem selectedBound44337 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env44338 : List Nat := [2,4,8,16,32,16,128,172,512,559,513,184,8192,659,162,682,8379,648,8749,163,185,8713,8761,8328,138,571,8706,8379,8378,8842,8367,642,172,8362,658,8707]

theorem envBound44338 : H12AffineFastState.Bounded env44338 := by
  intro p hp
  have h : env44338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44337_44338 : H12AffineEnvironment.transform 9 559 env44337 = env44338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 559 env44337 == env44338) = true)

theorem identity44338 : scanCanonicalize (H12AffineFastState.compose env44338 (packedSelected [2,4,6,7] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound44338 : packedSelected [2,4,6,7] rootPS < 2^1333 := by decide +kernel

def env44339 : List Nat := [2,4,8,16,32,16,56,20,512,559,513,0,8192,555,26,530,8195,560,8749,27,1,8713,8761,8240,50,571,8706,8195,8194,8754,8215,570,20,8210,554,8707]

theorem envBound44339 : H12AffineFastState.Bounded env44339 := by
  intro p hp
  have h : env44339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44338_44339 : H12AffineEnvironment.transform 6 56 env44338 = env44339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env44338 == env44339) = true)

theorem identity44339 : scanCanonicalize (H12AffineFastState.compose env44339 (packedSelected [2,6] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound44339 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env44340 : List Nat := [2,4,8,16,32,16,56,20,26,53,27,0,8192,49,26,8,8195,42,8247,27,1,8211,8227,8240,50,33,8216,8195,8194,8232,8215,32,20,8210,48,8217]

theorem envBound44340 : H12AffineFastState.Bounded env44340 := by
  intro p hp
  have h : env44340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44339_44340 : H12AffineEnvironment.transform 8 26 env44339 = env44340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env44339 == env44340) = true)

theorem identity44340 : scanCanonicalize (H12AffineFastState.compose env44340 (packedSelected [1,2,5] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound44340 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env44341 : List Nat := [2,4,8,16,32,16,56,20,26,53,27,0,25,49,26,8,26,42,46,27,1,10,58,41,50,33,1,26,27,49,14,32,20,11,48,0]

theorem envBound44341 : H12AffineFastState.Bounded env44341 := by
  intro p hp
  have h : env44341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44340_44341 : H12AffineEnvironment.transform 12 25 env44340 = env44341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env44340 == env44341) = true)

theorem identity44341 : scanCanonicalize (H12AffineFastState.compose env44341 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound44341 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44342 : List Nat := [2,4,8,16,17,16,9,20,26,4,27,0,25,0,26,8,26,27,31,27,1,10,11,24,3,16,1,26,27,0,14,17,20,11,1,0]

theorem envBound44342 : H12AffineFastState.Bounded env44342 := by
  intro p hp
  have h : env44342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44341_44342 : H12AffineEnvironment.transform 4 17 env44341 = env44342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env44341 == env44342) = true)

theorem identity44342 : scanCanonicalize (H12AffineFastState.compose env44342 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound44342 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44343 : List Nat := [2,4,8,6,7,6,9,2,12,4,13,0,15,0,12,8,12,13,9,13,1,10,11,14,3,6,1,12,13,0,14,7,2,11,1,0]

theorem envBound44343 : H12AffineFastState.Bounded env44343 := by
  intro p hp
  have h : env44343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44342_44343 : H12AffineEnvironment.transform 3 6 env44342 = env44343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env44342 == env44343) = true)

theorem identity44343 : scanCanonicalize (H12AffineFastState.compose env44343 (packedSelected [0,4,11] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound44343 : packedSelected [0,4,11] rootPS < 2^1333 := by decide +kernel

def env44344 : List Nat := [2,4,4,6,7,6,5,2,0,4,1,0,3,0,0,4,0,1,5,1,1,6,7,2,3,6,1,0,1,0,2,7,2,7,1,0]

theorem envBound44344 : H12AffineFastState.Bounded env44344 := by
  intro p hp
  have h : env44344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44343_44344 : H12AffineEnvironment.transform 2 4 env44343 = env44344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env44343 == env44344) = true)

def env44345 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61569,147472,41002,143497,20496,492567,148669,148668,96267,74794,1197,172,148652,1212,135680]

theorem envBound44345 : H12AffineFastState.Bounded env44345 := by
  intro p hp
  have h : env44345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44329_44345 : H12AffineEnvironment.transform 5 17 env44329 = env44345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env44329 == env44345) = true)

theorem identity44345 : scanCanonicalize (H12AffineFastState.compose env44345 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 137353) := by decide +kernel

theorem selectedBound44345 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env44346 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,137353,136193,32769,4097,61569,147472,41002,143497,20496,105630,148669,148668,96267,74794,1197,172,148652,1212,135680]

theorem envBound44346 : H12AffineFastState.Bounded env44346 := by
  intro p hp
  have h : env44346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44345_44346 : H12AffineEnvironment.transform 17 137353 env44345 = env44346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137353 env44345 == env44346) = true)

theorem identity44346 : scanCanonicalize (H12AffineFastState.compose env44346 (packedSelected [1,5,8,18,19,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 13374) := by decide +kernel

theorem selectedBound44346 : packedSelected [1,5,8,18,19,23,24,26] rootPS < 2^1333 := by decide +kernel

def env44347 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,13374,131072,137353,136193,32769,4097,61569,147472,41002,143497,20496,43168,148669,148668,19509,4116,1197,172,148652,1212,135680]

theorem envBound44347 : H12AffineFastState.Bounded env44347 := by
  intro p hp
  have h : env44347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44346_44347 : H12AffineEnvironment.transform 15 13374 env44346 = env44347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13374 env44346 == env44347) = true)

theorem identity44347 : scanCanonicalize (H12AffineFastState.compose env44347 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound44347 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env44348 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1212,32768,13374,131072,137353,136193,32769,4097,46141,132268,41002,143497,5292,43168,131073,131072,2185,4116,1197,172,131088,1212,135680]

theorem envBound44348 : H12AffineFastState.Bounded env44348 := by
  intro p hp
  have h : env44348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44347_44348 : H12AffineEnvironment.transform 13 1212 env44347 = env44348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env44347 == env44348) = true)

theorem identity44348 : scanCanonicalize (H12AffineFastState.compose env44348 (packedSelected [13,17] rootPS)) = affineNative (2^(16+1) ^^^ 46244) := by decide +kernel

theorem selectedBound44348 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env44349 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1212,32768,13374,46244,44077,41125,32769,4097,46141,45064,41002,33837,5292,43168,46245,46244,2185,4116,1197,172,46260,1212,42660]

theorem envBound44349 : H12AffineFastState.Bounded env44349 := by
  intro p hp
  have h : env44349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44348_44349 : H12AffineEnvironment.transform 16 46244 env44348 = env44349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46244 env44348 == env44349) = true)

theorem identity44349 : scanCanonicalize (H12AffineFastState.compose env44349 (packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 15551) := by decide +kernel

theorem selectedBound44349 : packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env44350 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1212,15551,13374,2075,4242,7194,15550,4097,2178,3255,7317,14482,5292,5151,2074,2075,2185,4116,1197,172,2059,1212,6683]

theorem envBound44350 : H12AffineFastState.Bounded env44350 := by
  intro p hp
  have h : env44350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44349_44350 : H12AffineEnvironment.transform 14 15551 env44349 = env44350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 15551 env44349 == env44350) = true)

theorem identity44350 : scanCanonicalize (H12AffineFastState.compose env44350 (packedSelected [1,5] rootPS)) = affineNative (2^(12+1) ^^^ 5284) := by decide +kernel

theorem selectedBound44350 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env44351 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,5284,1212,2075,154,2075,4242,7194,2074,4097,2178,3255,7317,3126,5292,5151,2074,2075,2185,4116,1197,172,2059,1212,6683]

theorem envBound44351 : H12AffineFastState.Bounded env44351 := by
  intro p hp
  have h : env44351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44350_44351 : H12AffineEnvironment.transform 12 5284 env44350 = env44351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5284 env44350 == env44351) = true)

theorem identity44351 : scanCanonicalize (H12AffineFastState.compose env44351 (packedSelected [0,4,11,13] rootPS)) = affineNative (2^(9+1) ^^^ 652) := by decide +kernel

theorem selectedBound44351 : packedSelected [0,4,11,13] rootPS < 2^1333 := by decide +kernel

def env44352 : List Nat := [2,4,8,16,32,17,128,172,512,652,2048,4096,4648,560,2075,154,2075,4242,6806,2074,4097,2178,2619,6681,2746,4640,4755,2074,2075,2185,4116,545,172,2059,560,6683]

theorem envBound44352 : H12AffineFastState.Bounded env44352 := by
  intro p hp
  have h : env44352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44351_44352 : H12AffineEnvironment.transform 9 652 env44351 = env44352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 652 env44351 == env44352) = true)

theorem identity44352 : scanCanonicalize (H12AffineFastState.compose env44352 (packedSelected [0,2,9,10,16] rootPS)) = affineNative (2^(10+1) ^^^ 162) := by decide +kernel

theorem selectedBound44352 : packedSelected [0,2,9,10,16] rootPS < 2^1333 := by decide +kernel

def env44353 : List Nat := [2,4,8,16,32,17,128,172,512,652,162,4096,4648,560,185,154,185,4242,4660,184,4097,32,665,4795,536,4640,4755,184,185,43,4116,545,172,169,560,4793]

theorem envBound44353 : H12AffineFastState.Bounded env44353 := by
  intro p hp
  have h : env44353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44352_44353 : H12AffineEnvironment.transform 10 162 env44352 = env44353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 162 env44352 == env44353) = true)

theorem identity44353 : scanCanonicalize (H12AffineFastState.compose env44353 (packedSelected [2,3,6,7,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 48) := by decide +kernel

theorem selectedBound44353 : packedSelected [2,3,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env44354 : List Nat := [2,4,8,16,32,17,128,172,512,652,162,48,536,560,185,154,185,162,516,184,49,32,665,651,536,528,675,184,185,43,36,545,172,169,560,649]

theorem envBound44354 : H12AffineFastState.Bounded env44354 := by
  intro p hp
  have h : env44354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44353_44354 : H12AffineEnvironment.transform 11 48 env44353 = env44354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env44353 == env44354) = true)

theorem identity44354 : scanCanonicalize (H12AffineFastState.compose env44354 (packedSelected [2,3,6,8] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound44354 : packedSelected [2,3,6,8] rootPS < 2^1333 := by decide +kernel

def env44355 : List Nat := [2,4,8,16,32,17,19,63,512,543,49,48,536,560,42,9,42,49,516,43,49,32,522,536,536,528,560,43,42,43,36,545,63,58,560,538]

theorem envBound44355 : H12AffineFastState.Bounded env44355 := by
  intro p hp
  have h : env44355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44354_44355 : H12AffineEnvironment.transform 6 19 env44354 = env44355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env44354 == env44355) = true)

theorem identity44355 : scanCanonicalize (H12AffineFastState.compose env44355 (packedSelected [0,1,4,6] rootPS)) = affineNative (2^(8+1) ^^^ 44) := by decide +kernel

theorem selectedBound44355 : packedSelected [0,1,4,6] rootPS < 2^1333 := by decide +kernel

def env44356 : List Nat := [2,4,8,16,32,17,19,63,44,51,49,48,52,28,42,9,42,49,40,43,49,32,38,52,52,60,28,43,42,43,36,13,63,58,28,54]

theorem envBound44356 : H12AffineFastState.Bounded env44356 := by
  intro p hp
  have h : env44356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44355_44356 : H12AffineEnvironment.transform 8 44 env44355 = env44356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 44 env44355 == env44356) = true)

def env44357 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147521,41002,143497,20496,492615,148717,148716,96346,74794,1196,173,148732,1260,135680]

theorem envBound44357 : H12AffineFastState.Bounded env44357 := by
  intro p hp
  have h : env44357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44328_44357 : H12AffineEnvironment.transform 7 173 env44328 = env44357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env44328 == env44357) = true)

def env44358 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61568,147473,41002,143497,20496,492567,148669,148668,96266,74794,1196,173,148652,1212,135680]

theorem envBound44358 : H12AffineFastState.Bounded env44358 := by
  intro p hp
  have h : env44358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart2