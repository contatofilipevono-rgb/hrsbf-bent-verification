import H12CloudChart2Data190

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound47975 : H12AffineFastState.Bounded env47975 := by
  intro p hp
  have h : env47975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47974_47975 : H12AffineEnvironment.transform 18 21584 env47974 = env47975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21584 env47974 == env47975) = true)

theorem identity47975 : scanCanonicalize (H12AffineFastState.compose env47975 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound47975 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env47976 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,13341,65536,74862,262144,21584,13340,4096,17612,91182,87296,28888,78895,349358,90414,1296,96347,25884,74799,256,25880,1345,21073]

theorem envBound47976 : H12AffineFastState.Bounded env47976 := by
  intro p hp
  have h : env47976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47975_47976 : H12AffineEnvironment.transform 14 13341 env47975 = env47976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env47975 == env47976) = true)

def env47977 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74862,262144,4416,13340,4096,476,74046,69648,13768,78895,332222,74814,1296,81227,8204,74799,256,8200,1345,5953]

theorem envBound47977 : H12AffineFastState.Bounded env47977 := by
  intro p hp
  have h : env47977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47976_47977 : H12AffineEnvironment.transform 13 1296 env47976 = env47977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env47976 == env47977) = true)

def env47978 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74862,65664,4416,13340,4096,476,74046,69648,13768,78895,4414,74814,1296,81227,8204,74799,256,8200,1345,5953]

theorem envBound47978 : H12AffineFastState.Bounded env47978 := by
  intro p hp
  have h : env47978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47977_47978 : H12AffineEnvironment.transform 17 65664 env47977 = env47978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env47977 == env47978) = true)

theorem identity47978 : scanCanonicalize (H12AffineFastState.compose env47978 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound47978 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env47979 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,8192,1,12556,65536,74111,65664,4416,12557,4096,476,74046,69648,12505,78142,4414,74031,1,79962,8204,74046,256,8200,80,4688]

theorem envBound47979 : H12AffineFastState.Bounded env47979 := by
  intro p hp
  have h : env47979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47978_47979 : H12AffineEnvironment.transform 9 273 env47978 = env47979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env47978 == env47979) = true)

def env47980 : List Nat := [2,4,8,16,32,64,128,256,340,273,2048,4096,8192,1,12556,65536,74111,65664,4416,12557,4096,476,74046,69648,12505,78142,4414,74031,1,79962,8204,74046,256,8200,80,4356]

theorem envBound47980 : H12AffineFastState.Bounded env47980 := by
  intro p hp
  have h : env47980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47979_47980 : H12AffineEnvironment.transform 8 340 env47979 = env47980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env47979 == env47980) = true)

def env47981 : List Nat := [2,4,8,16,32,64,128,256,340,273,2048,16,8192,1,8476,65536,74111,65664,336,8477,16,476,74046,65536,8393,74030,302,74031,1,75850,8204,74046,256,8200,80,276]

theorem envBound47981 : H12AffineFastState.Bounded env47981 := by
  intro p hp
  have h : env47981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47980_47981 : H12AffineEnvironment.transform 11 16 env47980 = env47981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env47980 == env47981) = true)

theorem identity47981 : scanCanonicalize (H12AffineFastState.compose env47981 (packedSelected [1,8,28] rootPS)) = affineNative (2^(7+1) ^^^ 8) := by decide +kernel

theorem selectedBound47981 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env47982 : List Nat := [2,4,8,16,32,64,128,8,92,25,2048,16,8192,1,8212,65536,73847,65664,88,8213,16,212,73782,65536,8393,73766,38,73767,1,75850,8204,73782,8,8200,80,28]

theorem envBound47982 : H12AffineFastState.Bounded env47982 := by
  intro p hp
  have h : env47982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47981_47982 : H12AffineEnvironment.transform 7 8 env47981 = env47982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 8 env47981 == env47982) = true)

def env47983 : List Nat := [2,4,8,16,32,64,128,8,92,25,2048,16,24,1,12,65536,65647,65664,88,13,16,212,65582,65536,209,65598,38,65599,1,67666,20,65582,8,16,80,28]

theorem envBound47983 : H12AffineFastState.Bounded env47983 := by
  intro p hp
  have h : env47983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47982_47983 : H12AffineEnvironment.transform 12 24 env47982 = env47983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env47982 == env47983) = true)

theorem identity47983 : scanCanonicalize (H12AffineFastState.compose env47983 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 50) := by decide +kernel

theorem selectedBound47983 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env47984 : List Nat := [2,4,8,16,32,64,128,8,92,25,2048,16,24,1,12,50,93,178,88,13,16,212,28,50,209,12,38,13,1,2144,20,28,8,16,80,28]

theorem envBound47984 : H12AffineFastState.Bounded env47984 := by
  intro p hp
  have h : env47984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47983_47984 : H12AffineEnvironment.transform 15 50 env47983 = env47984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 50 env47983 == env47984) = true)

theorem identity47984 : scanCanonicalize (H12AffineFastState.compose env47984 (packedSelected [1,2,3,4,9,10,12,16,17] rootPS)) = affineNative (2^(10+1) ^^^ 29) := by decide +kernel

theorem selectedBound47984 : packedSelected [1,2,3,4,9,10,12,16,17] rootPS < 2^1333 := by decide +kernel

def env47985 : List Nat := [2,4,8,16,32,64,128,8,92,25,29,16,24,1,12,50,93,178,88,13,16,212,28,50,209,12,38,13,1,125,20,28,8,16,80,28]

theorem envBound47985 : H12AffineFastState.Bounded env47985 := by
  intro p hp
  have h : env47985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47984_47985 : H12AffineEnvironment.transform 10 29 env47984 = env47985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 29 env47984 == env47985) = true)

theorem identity47985 : scanCanonicalize (H12AffineFastState.compose env47985 (packedSelected [0,3,4,7,9,11,16] rootPS)) = affineNative (2^(5+1) ^^^ 38) := by decide +kernel

theorem selectedBound47985 : packedSelected [0,3,4,7,9,11,16] rootPS < 2^1333 := by decide +kernel

def env47986 : List Nat := [2,4,8,16,32,38,128,8,58,25,29,16,24,1,12,50,59,178,62,13,16,178,28,50,183,12,38,13,1,27,20,28,8,16,54,28]

theorem envBound47986 : H12AffineFastState.Bounded env47986 := by
  intro p hp
  have h : env47986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47985_47986 : H12AffineEnvironment.transform 5 38 env47985 = env47986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 38 env47985 == env47986) = true)

theorem identity47986 : scanCanonicalize (H12AffineFastState.compose env47986 (packedSelected [0,1,2,3,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 22) := by decide +kernel

theorem selectedBound47986 : packedSelected [0,1,2,3,7,8] rootPS < 2^1333 := by decide +kernel

def env47987 : List Nat := [2,4,8,16,22,16,128,8,12,25,29,16,24,1,12,4,13,132,8,13,16,132,28,4,129,12,16,13,1,27,20,28,8,16,0,28]

theorem envBound47987 : H12AffineFastState.Bounded env47987 := by
  intro p hp
  have h : env47987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47986_47987 : H12AffineEnvironment.transform 4 22 env47986 = env47987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 22 env47986 == env47987) = true)

theorem identity47987 : scanCanonicalize (H12AffineFastState.compose env47987 (packedSelected [2,3] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound47987 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env47988 : List Nat := [2,4,8,16,22,16,25,8,12,25,29,16,24,1,12,4,13,29,8,13,16,29,28,4,24,12,16,13,1,27,20,28,8,16,0,28]

theorem envBound47988 : H12AffineFastState.Bounded env47988 := by
  intro p hp
  have h : env47988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47987_47988 : H12AffineEnvironment.transform 6 25 env47987 = env47988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env47987 == env47988) = true)

theorem identity47988 : scanCanonicalize (H12AffineFastState.compose env47988 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound47988 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47989 : List Nat := [2,4,4,16,22,16,21,4,0,21,17,16,20,1,0,4,1,17,4,1,16,17,16,4,20,0,16,1,1,23,20,16,4,16,0,16]

theorem envBound47989 : H12AffineFastState.Bounded env47989 := by
  intro p hp
  have h : env47989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47988_47989 : H12AffineEnvironment.transform 2 4 env47988 = env47989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env47988 == env47989) = true)

def env47990 : List Nat := [2,4,8,16,32,64,128,8,92,25,2048,16,25,1,13,65536,65646,65664,88,12,16,212,65583,65536,208,65599,38,65598,1,67667,21,65583,8,17,80,28]

theorem envBound47990 : H12AffineFastState.Bounded env47990 := by
  intro p hp
  have h : env47990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47982_47990 : H12AffineEnvironment.transform 12 25 env47982 = env47990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env47982 == env47990) = true)

theorem identity47990 : scanCanonicalize (H12AffineFastState.compose env47990 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound47990 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env47991 : List Nat := [2,4,8,16,32,64,128,8,92,25,2048,16,25,1,13,114,28,242,88,12,16,212,93,114,208,77,38,76,1,2081,21,93,8,17,80,28]

theorem envBound47991 : H12AffineFastState.Bounded env47991 := by
  intro p hp
  have h : env47991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47990_47991 : H12AffineEnvironment.transform 15 114 env47990 = env47991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env47990 == env47991) = true)

theorem identity47991 : scanCanonicalize (H12AffineFastState.compose env47991 (packedSelected [0,2,3,4,7,9,11,12,23] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound47991 : packedSelected [0,2,3,4,7,9,11,12,23] rootPS < 2^1333 := by decide +kernel

def env47992 : List Nat := [2,4,8,16,32,64,128,8,92,25,32,16,25,1,13,114,28,242,88,12,16,212,93,114,208,77,38,76,1,1,21,93,8,17,80,28]

theorem envBound47992 : H12AffineFastState.Bounded env47992 := by
  intro p hp
  have h : env47992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47991_47992 : H12AffineEnvironment.transform 10 32 env47991 = env47992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env47991 == env47992) = true)

theorem identity47992 : scanCanonicalize (H12AffineFastState.compose env47992 (packedSelected [0,2,4,5,7,8,9,12,13,15,16,17,18] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound47992 : packedSelected [0,2,4,5,7,8,9,12,13,15,16,17,18] rootPS < 2^1333 := by decide +kernel

def env47993 : List Nat := [2,4,8,16,17,64,128,8,92,25,17,16,25,1,13,67,28,195,88,12,16,212,93,67,208,77,23,76,1,1,21,93,8,17,80,28]

theorem envBound47993 : H12AffineFastState.Bounded env47993 := by
  intro p hp
  have h : env47993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47992_47993 : H12AffineEnvironment.transform 4 17 env47992 = env47993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env47992 == env47993) = true)

theorem identity47993 : scanCanonicalize (H12AffineFastState.compose env47993 (packedSelected [0,2,3,4,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 82) := by decide +kernel

theorem selectedBound47993 : packedSelected [0,2,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env47994 : List Nat := [2,4,8,16,17,64,82,8,92,25,17,16,25,1,13,67,28,17,88,12,16,6,93,67,2,77,23,76,1,1,21,93,8,17,80,28]

theorem envBound47994 : H12AffineFastState.Bounded env47994 := by
  intro p hp
  have h : env47994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47993_47994 : H12AffineEnvironment.transform 6 82 env47993 = env47994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 82 env47993 == env47994) = true)

theorem identity47994 : scanCanonicalize (H12AffineFastState.compose env47994 (packedSelected [0,2,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 6) := by decide +kernel

theorem selectedBound47994 : packedSelected [0,2,5,7] rootPS < 2^1333 := by decide +kernel

def env47995 : List Nat := [2,4,8,16,17,6,20,8,26,25,17,16,25,1,13,5,28,17,30,12,16,6,27,5,2,11,23,10,1,1,21,27,8,17,22,28]

theorem envBound47995 : H12AffineFastState.Bounded env47995 := by
  intro p hp
  have h : env47995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47994_47995 : H12AffineEnvironment.transform 5 6 env47994 = env47995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 6 env47994 == env47995) = true)

theorem identity47995 : scanCanonicalize (H12AffineFastState.compose env47995 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound47995 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env47996 : List Nat := [2,4,4,16,17,6,20,4,22,21,17,16,21,1,1,5,16,17,18,0,16,6,23,5,2,7,23,6,1,1,21,23,4,17,22,16]

theorem envBound47996 : H12AffineFastState.Bounded env47996 := by
  intro p hp
  have h : env47996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47995_47996 : H12AffineEnvironment.transform 2 4 env47995 = env47996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env47995 == env47996) = true)

theorem identity47996 : scanCanonicalize (H12AffineFastState.compose env47996 (packedSelected [1,2] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound47996 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env47997 : List Nat := [2,4,4,7,6,6,3,4,1,2,6,7,2,1,1,5,7,6,5,0,7,6,0,5,2,7,0,6,1,1,2,0,4,6,1,7]

theorem envBound47997 : H12AffineFastState.Bounded env47997 := by
  intro p hp
  have h : env47997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47996_47997 : H12AffineEnvironment.transform 3 7 env47996 = env47997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env47996 == env47997) = true)

theorem identity47997 : scanCanonicalize (H12AffineFastState.compose env47997 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound47997 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47998 : List Nat := [2,3,3,0,1,1,3,3,1,2,1,0,2,1,1,2,0,1,2,0,0,1,0,2,2,0,0,1,1,1,2,0,3,1,1,0]

theorem envBound47998 : H12AffineFastState.Bounded env47998 := by
  intro p hp
  have h : env47998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47997_47998 : H12AffineEnvironment.transform 1 3 env47997 = env47998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env47997 == env47998) = true)

theorem identity47998 : scanCanonicalize (H12AffineFastState.compose env47998 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound47998 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47999 : List Nat := [1,0,0,0,1,1,0,0,1,1,1,0,1,1,1,1,0,1,1,0,0,1,0,1,1,0,0,1,1,1,1,0,0,1,1,0]

theorem envBound47999 : H12AffineFastState.Bounded env47999 := by
  intro p hp
  have h : env47999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47998_47999 : H12AffineEnvironment.transform 0 1 env47998 = env47999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env47998 == env47999) = true)

def env48000 : List Nat := [2,4,8,16,32,64,128,256,340,273,2048,17,8192,1,8477,65536,74111,65664,337,8476,17,476,74046,65537,8392,74031,303,74031,1,75851,8204,74046,256,8200,80,277]

theorem envBound48000 : H12AffineFastState.Bounded env48000 := by
  intro p hp
  have h : env48000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47980_48000 : H12AffineEnvironment.transform 11 17 env47980 = env48000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env47980 == env48000) = true)

theorem identity48000 : scanCanonicalize (H12AffineFastState.compose env48000 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 273) := by decide +kernel

theorem selectedBound48000 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env48001 : List Nat := [2,4,8,16,32,64,128,256,340,273,2048,17,273,1,12,65536,65646,65664,337,13,17,476,65583,65537,473,65598,303,65598,1,67930,285,65583,256,281,80,277]

theorem envBound48001 : H12AffineFastState.Bounded env48001 := by
  intro p hp
  have h : env48001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48000_48001 : H12AffineEnvironment.transform 12 273 env48000 = env48001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 273 env48000 == env48001) = true)

def env48002 : List Nat := [2,4,8,16,32,64,128,8,92,25,2048,17,25,1,12,65536,65646,65664,89,13,17,212,65583,65537,209,65598,39,65598,1,67666,21,65583,8,17,80,29]

theorem envBound48002 : H12AffineFastState.Bounded env48002 := by
  intro p hp
  have h : env48002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48001_48002 : H12AffineEnvironment.transform 7 8 env48001 = env48002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 8 env48001 == env48002) = true)

theorem identity48002 : scanCanonicalize (H12AffineFastState.compose env48002 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound48002 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env48003 : List Nat := [2,4,8,16,32,64,128,8,92,25,2048,17,25,1,12,114,28,242,89,13,17,212,93,115,209,76,39,76,1,2080,21,93,8,17,80,29]

theorem envBound48003 : H12AffineFastState.Bounded env48003 := by
  intro p hp
  have h : env48003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48002_48003 : H12AffineEnvironment.transform 15 114 env48002 = env48003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env48002 == env48003) = true)

theorem identity48003 : scanCanonicalize (H12AffineFastState.compose env48003 (packedSelected [0,2,3,4,7,9,11,12,23] rootPS)) = affineNative (2^(10+1) ^^^ 109) := by decide +kernel

theorem selectedBound48003 : packedSelected [0,2,3,4,7,9,11,12,23] rootPS < 2^1333 := by decide +kernel

def env48004 : List Nat := [2,4,8,16,32,64,128,8,92,25,109,17,25,1,12,114,28,242,89,13,17,212,93,115,209,76,39,76,1,77,21,93,8,17,80,29]

theorem envBound48004 : H12AffineFastState.Bounded env48004 := by
  intro p hp
  have h : env48004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48003_48004 : H12AffineEnvironment.transform 10 109 env48003 = env48004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 109 env48003 == env48004) = true)

theorem identity48004 : scanCanonicalize (H12AffineFastState.compose env48004 (packedSelected [0,5,7,8,11,12,15] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound48004 : packedSelected [0,5,7,8,11,12,15] rootPS < 2^1333 := by decide +kernel

def env48005 : List Nat := [2,4,8,6,32,64,128,8,74,15,109,7,15,1,12,100,10,228,79,13,7,194,75,101,199,76,39,76,1,77,3,75,8,7,70,11]

theorem envBound48005 : H12AffineFastState.Bounded env48005 := by
  intro p hp
  have h : env48005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48004_48005 : H12AffineEnvironment.transform 3 6 env48004 = env48005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env48004 == env48005) = true)

theorem identity48005 : scanCanonicalize (H12AffineFastState.compose env48005 (packedSelected [0,1,2,3,5,7,8,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound48005 : packedSelected [0,1,2,3,5,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env48006 : List Nat := [2,4,8,6,32,10,128,8,0,15,39,7,15,1,12,46,10,174,5,13,7,136,1,47,141,6,39,6,1,7,3,1,8,7,12,11]

theorem envBound48006 : H12AffineFastState.Bounded env48006 := by
  intro p hp
  have h : env48006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48005_48006 : H12AffineEnvironment.transform 5 10 env48005 = env48006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env48005 == env48006) = true)

theorem identity48006 : scanCanonicalize (H12AffineFastState.compose env48006 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound48006 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48007 : List Nat := [2,4,8,6,32,10,40,8,0,15,39,7,15,1,12,46,10,6,5,13,7,32,1,47,37,6,39,6,1,7,3,1,8,7,12,11]

theorem envBound48007 : H12AffineFastState.Bounded env48007 := by
  intro p hp
  have h : env48007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48006_48007 : H12AffineEnvironment.transform 6 40 env48006 = env48007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env48006 == env48007) = true)

theorem identity48007 : scanCanonicalize (H12AffineFastState.compose env48007 (packedSelected [3,5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound48007 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env48008 : List Nat := [2,4,2,6,32,0,34,2,0,5,39,7,5,1,6,36,0,6,5,7,7,32,1,37,37,6,39,6,1,7,3,1,2,7,6,1]

theorem envBound48008 : H12AffineFastState.Bounded env48008 := by
  intro p hp
  have h : env48008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48007_48008 : H12AffineEnvironment.transform 2 2 env48007 = env48008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env48007 == env48008) = true)

theorem identity48008 : scanCanonicalize (H12AffineFastState.compose env48008 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound48008 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48009 : List Nat := [2,0,2,2,32,0,34,2,0,1,35,3,1,1,2,32,0,2,1,3,3,32,1,33,33,2,35,2,1,3,3,1,2,3,2,1]

theorem envBound48009 : H12AffineFastState.Bounded env48009 := by
  intro p hp
  have h : env48009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48008_48009 : H12AffineEnvironment.transform 1 0 env48008 = env48009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env48008 == env48009) = true)

theorem identity48009 : scanCanonicalize (H12AffineFastState.compose env48009 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound48009 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env48010 : List Nat := [2,0,2,2,0,0,2,2,0,1,3,3,1,1,2,0,0,2,1,3,3,0,1,1,1,2,3,2,1,3,3,1,2,3,2,1]

theorem envBound48010 : H12AffineFastState.Bounded env48010 := by
  intro p hp
  have h : env48010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48009_48010 : H12AffineEnvironment.transform 4 0 env48009 = env48010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env48009 == env48010) = true)

theorem identity48010 : scanCanonicalize (H12AffineFastState.compose env48010 (packedSelected [2] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound48010 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48011 : List Nat := [0,0,0,0,0,0,0,0,0,1,1,1,1,1,0,0,0,0,1,1,1,0,1,1,1,0,1,0,1,1,1,1,0,1,0,1]

theorem envBound48011 : H12AffineFastState.Bounded env48011 := by
  intro p hp
  have h : env48011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48010_48011 : H12AffineEnvironment.transform 0 0 env48010 = env48011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env48010 == env48011) = true)

def env48012 : List Nat := [2,4,8,16,32,64,128,9,93,24,2048,17,24,1,12,65536,65646,65664,88,13,17,213,65583,65537,208,65598,38,65598,1,67667,20,65583,9,16,80,28]

theorem envBound48012 : H12AffineFastState.Bounded env48012 := by
  intro p hp
  have h : env48012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48001_48012 : H12AffineEnvironment.transform 7 9 env48001 = env48012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 9 env48001 == env48012) = true)

theorem identity48012 : scanCanonicalize (H12AffineFastState.compose env48012 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 51) := by decide +kernel

theorem selectedBound48012 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env48013 : List Nat := [2,4,8,16,32,64,128,9,93,24,2048,17,24,1,12,51,93,179,88,13,17,213,28,50,208,13,38,13,1,2144,20,28,9,16,80,28]

theorem envBound48013 : H12AffineFastState.Bounded env48013 := by
  intro p hp
  have h : env48013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48012_48013 : H12AffineEnvironment.transform 15 51 env48012 = env48013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 51 env48012 == env48013) = true)

theorem identity48013 : scanCanonicalize (H12AffineFastState.compose env48013 (packedSelected [1,2,3,4,9,10,12,16,17] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound48013 : packedSelected [1,2,3,4,9,10,12,16,17] rootPS < 2^1333 := by decide +kernel

def env48014 : List Nat := [2,4,8,16,32,64,128,9,93,24,17,17,24,1,12,51,93,179,88,13,17,213,28,50,208,13,38,13,1,113,20,28,9,16,80,28]

theorem envBound48014 : H12AffineFastState.Bounded env48014 := by
  intro p hp
  have h : env48014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48013_48014 : H12AffineEnvironment.transform 10 17 env48013 = env48014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env48013 == env48014) = true)

theorem identity48014 : scanCanonicalize (H12AffineFastState.compose env48014 (packedSelected [0,3,4,7,9,11,16] rootPS)) = affineNative (2^(5+1) ^^^ 38) := by decide +kernel

theorem selectedBound48014 : packedSelected [0,3,4,7,9,11,16] rootPS < 2^1333 := by decide +kernel

def env48015 : List Nat := [2,4,8,16,32,38,128,9,59,24,17,17,24,1,12,51,59,179,62,13,17,179,28,50,182,13,38,13,1,23,20,28,9,16,54,28]

theorem envBound48015 : H12AffineFastState.Bounded env48015 := by
  intro p hp
  have h : env48015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48014_48015 : H12AffineEnvironment.transform 5 38 env48014 = env48015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 38 env48014 == env48015) = true)

theorem identity48015 : scanCanonicalize (H12AffineFastState.compose env48015 (packedSelected [2,5,8,10] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound48015 : packedSelected [2,5,8,10] rootPS < 2^1333 := by decide +kernel

def env48016 : List Nat := [2,4,8,16,0,6,128,9,27,24,17,17,24,1,12,19,27,147,30,13,17,147,28,18,150,13,6,13,1,23,20,28,9,16,22,28]

theorem envBound48016 : H12AffineFastState.Bounded env48016 := by
  intro p hp
  have h : env48016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48015_48016 : H12AffineEnvironment.transform 4 0 env48015 = env48016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env48015 == env48016) = true)

theorem identity48016 : scanCanonicalize (H12AffineFastState.compose env48016 (packedSelected [1,2,8] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound48016 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env48017 : List Nat := [2,4,8,16,0,6,3,9,27,24,17,17,24,1,12,19,27,16,30,13,17,16,28,18,21,13,6,13,1,23,20,28,9,16,22,28]

theorem envBound48017 : H12AffineFastState.Bounded env48017 := by
  intro p hp
  have h : env48017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48016_48017 : H12AffineEnvironment.transform 6 3 env48016 = env48017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env48016 == env48017) = true)

theorem identity48017 : scanCanonicalize (H12AffineFastState.compose env48017 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound48017 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env48018 : List Nat := [2,4,8,10,0,6,3,9,1,2,11,11,2,1,12,9,1,10,4,13,11,10,6,8,15,13,6,13,1,13,14,6,9,10,12,6]

theorem envBound48018 : H12AffineFastState.Bounded env48018 := by
  intro p hp
  have h : env48018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48017_48018 : H12AffineEnvironment.transform 3 10 env48017 = env48018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env48017 == env48018) = true)

theorem identity48018 : scanCanonicalize (H12AffineFastState.compose env48018 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound48018 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48019 : List Nat := [2,2,8,10,0,0,3,9,1,2,11,11,2,1,10,9,1,10,2,11,11,10,0,8,9,11,0,11,1,11,8,0,9,10,10,0]

theorem envBound48019 : H12AffineFastState.Bounded env48019 := by
  intro p hp
  have h : env48019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48018_48019 : H12AffineEnvironment.transform 1 2 env48018 = env48019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env48018 == env48019) = true)

theorem identity48019 : scanCanonicalize (H12AffineFastState.compose env48019 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound48019 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48020 : List Nat := [0,0,8,8,0,0,1,9,1,0,9,9,0,1,8,9,1,8,0,9,9,8,0,8,9,9,0,9,1,9,8,0,9,8,8,0]

theorem envBound48020 : H12AffineFastState.Bounded env48020 := by
  intro p hp
  have h : env48020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48019_48020 : H12AffineEnvironment.transform 0 0 env48019 = env48020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env48019 == env48020) = true)

theorem identity48020 : scanCanonicalize (H12AffineFastState.compose env48020 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound48020 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48021 : List Nat := [0,0,0,0,0,0,1,1,1,0,1,1,0,1,0,1,1,0,0,1,1,0,0,0,1,1,0,1,1,1,0,0,1,0,0,0]

theorem envBound48021 : H12AffineFastState.Bounded env48021 := by
  intro p hp
  have h : env48021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48020_48021 : H12AffineEnvironment.transform 2 0 env48020 = env48021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env48020 == env48021) = true)

def env48022 : List Nat := [2,4,8,16,32,64,128,256,341,273,2048,4096,8192,1,12556,65536,74111,65664,4416,12557,4096,476,74046,69648,12505,78142,4414,74031,1,79962,8204,74046,256,8200,80,4357]

theorem envBound48022 : H12AffineFastState.Bounded env48022 := by
  intro p hp
  have h : env48022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47979_48022 : H12AffineEnvironment.transform 8 341 env47979 = env48022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env47979 == env48022) = true)

def env48023 : List Nat := [2,4,8,16,32,64,128,256,341,273,2048,16,8192,1,8476,65536,74111,65664,336,8477,16,476,74046,65536,8393,74030,302,74031,1,75850,8204,74046,256,8200,80,277]

theorem envBound48023 : H12AffineFastState.Bounded env48023 := by
  intro p hp
  have h : env48023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48022_48023 : H12AffineEnvironment.transform 11 16 env48022 = env48023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env48022 == env48023) = true)

theorem identity48023 : scanCanonicalize (H12AffineFastState.compose env48023 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 8231) := by decide +kernel

theorem selectedBound48023 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env48024 : List Nat := [2,4,8,16,32,64,128,256,341,273,2048,16,8192,1,8476,8231,344,8359,336,8477,16,476,281,8231,8393,265,302,264,1,2157,8204,281,256,8200,80,277]

theorem envBound48024 : H12AffineFastState.Bounded env48024 := by
  intro p hp
  have h : env48024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48023_48024 : H12AffineEnvironment.transform 15 8231 env48023 = env48024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8231 env48023 == env48024) = true)

def env48025 : List Nat := [2,4,8,16,32,64,128,8,93,25,2048,16,8192,1,8212,8231,80,8359,88,8213,16,212,17,8231,8393,1,38,0,1,2157,8204,17,8,8200,80,29]

theorem envBound48025 : H12AffineFastState.Bounded env48025 := by
  intro p hp
  have h : env48025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48024_48025 : H12AffineEnvironment.transform 7 8 env48024 = env48025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 8 env48024 == env48025) = true)

theorem identity48025 : scanCanonicalize (H12AffineFastState.compose env48025 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 73) := by decide +kernel

theorem selectedBound48025 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env48026 : List Nat := [2,4,8,16,32,64,128,8,93,25,2048,16,73,1,93,110,80,238,88,92,16,212,17,110,128,1,38,0,1,2157,69,17,8,65,80,29]

theorem envBound48026 : H12AffineFastState.Bounded env48026 := by
  intro p hp
  have h : env48026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48025_48026 : H12AffineEnvironment.transform 12 73 env48025 = env48026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env48025 == env48026) = true)

theorem identity48026 : scanCanonicalize (H12AffineFastState.compose env48026 (packedSelected [2,8,11,15,18] rootPS)) = affineNative (2^(10+1) ^^^ 194) := by decide +kernel

theorem selectedBound48026 : packedSelected [2,8,11,15,18] rootPS < 2^1333 := by decide +kernel

def env48027 : List Nat := [2,4,8,16,32,64,128,8,93,25,194,16,73,1,93,110,80,238,88,92,16,212,17,110,128,1,38,0,1,175,69,17,8,65,80,29]

theorem envBound48027 : H12AffineFastState.Bounded env48027 := by
  intro p hp
  have h : env48027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48026_48027 : H12AffineEnvironment.transform 10 194 env48026 = env48027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 194 env48026 == env48027) = true)

theorem identity48027 : scanCanonicalize (H12AffineFastState.compose env48027 (packedSelected [0,1,3,4,7,9,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 68) := by decide +kernel

theorem selectedBound48027 : packedSelected [0,1,3,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env48028 : List Nat := [2,4,8,16,32,64,68,8,93,25,6,16,73,1,93,110,80,42,88,92,16,16,17,110,68,1,38,0,1,107,69,17,8,65,80,29]

theorem envBound48028 : H12AffineFastState.Bounded env48028 := by
  intro p hp
  have h : env48028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48027_48028 : H12AffineEnvironment.transform 6 68 env48027 = env48028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 68 env48027 == env48028) = true)

theorem identity48028 : scanCanonicalize (H12AffineFastState.compose env48028 (packedSelected [3,7,8,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound48028 : packedSelected [3,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env48029 : List Nat := [2,4,8,16,32,0,4,8,29,25,6,16,9,1,29,46,16,42,24,28,16,16,17,46,4,1,38,0,1,43,5,17,8,1,16,29]

theorem envBound48029 : H12AffineFastState.Bounded env48029 := by
  intro p hp
  have h : env48029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48028_48029 : H12AffineEnvironment.transform 5 0 env48028 = env48029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env48028 == env48029) = true)

def env48030 : List Nat := [2,4,8,16,32,64,128,9,92,24,2048,16,8192,1,8213,8231,81,8359,89,8212,16,213,16,8231,8393,0,39,1,1,2157,8204,16,9,8200,80,28]

theorem envBound48030 : H12AffineFastState.Bounded env48030 := by
  intro p hp
  have h : env48030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48024_48030 : H12AffineEnvironment.transform 7 9 env48024 = env48030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 9 env48024 == env48030) = true)

theorem identity48030 : scanCanonicalize (H12AffineFastState.compose env48030 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 68) := by decide +kernel

theorem selectedBound48030 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env48031 : List Nat := [2,4,8,16,32,64,128,9,92,24,2048,16,68,1,81,99,81,227,89,80,16,213,16,99,141,0,39,1,1,2157,72,16,9,76,80,28]

theorem envBound48031 : H12AffineFastState.Bounded env48031 := by
  intro p hp
  have h : env48031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48030_48031 : H12AffineEnvironment.transform 12 68 env48030 = env48031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 68 env48030 == env48031) = true)

theorem identity48031 : scanCanonicalize (H12AffineFastState.compose env48031 (packedSelected [0,1,3,7,8,10,17,19,20] rootPS)) = affineNative (2^(10+1) ^^^ 210) := by decide +kernel

theorem selectedBound48031 : packedSelected [0,1,3,7,8,10,17,19,20] rootPS < 2^1333 := by decide +kernel

def env48032 : List Nat := [2,4,8,16,32,64,128,9,92,24,210,16,68,1,81,99,81,227,89,80,16,213,16,99,141,0,39,1,1,191,72,16,9,76,80,28]

theorem envBound48032 : H12AffineFastState.Bounded env48032 := by
  intro p hp
  have h : env48032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48031_48032 : H12AffineEnvironment.transform 10 210 env48031 = env48032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 210 env48031 == env48032) = true)

theorem identity48032 : scanCanonicalize (H12AffineFastState.compose env48032 (packedSelected [0,1,2,3,7,8,13,16] rootPS)) = affineNative (2^(6+1) ^^^ 21) := by decide +kernel

theorem selectedBound48032 : packedSelected [0,1,2,3,7,8,13,16] rootPS < 2^1333 := by decide +kernel

def env48033 : List Nat := [2,4,8,16,32,64,21,9,92,24,71,16,68,1,81,99,81,118,89,80,16,64,16,99,24,0,39,1,1,42,72,16,9,76,80,28]

theorem envBound48033 : H12AffineFastState.Bounded env48033 := by
  intro p hp
  have h : env48033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48032_48033 : H12AffineEnvironment.transform 6 21 env48032 = env48033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 21 env48032 == env48033) = true)

theorem identity48033 : scanCanonicalize (H12AffineFastState.compose env48033 (packedSelected [1,7,9,12] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound48033 : packedSelected [1,7,9,12] rootPS < 2^1333 := by decide +kernel

def env48034 : List Nat := [2,4,2,16,32,64,21,3,86,18,71,16,68,1,81,99,81,118,83,80,16,64,16,99,18,0,39,1,1,32,66,16,3,70,80,22]

theorem envBound48034 : H12AffineFastState.Bounded env48034 := by
  intro p hp
  have h : env48034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48033_48034 : H12AffineEnvironment.transform 2 2 env48033 = env48034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env48033 == env48034) = true)

theorem identity48034 : scanCanonicalize (H12AffineFastState.compose env48034 (packedSelected [0,2,5,7] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound48034 : packedSelected [0,2,5,7] rootPS < 2^1333 := by decide +kernel

def env48035 : List Nat := [2,4,2,6,32,64,3,3,64,4,71,6,68,1,71,99,71,96,69,70,6,64,6,99,4,0,39,1,1,32,66,6,3,70,70,0]

theorem envBound48035 : H12AffineFastState.Bounded env48035 := by
  intro p hp
  have h : env48035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48034_48035 : H12AffineEnvironment.transform 3 6 env48034 = env48035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env48034 == env48035) = true)

theorem identity48035 : scanCanonicalize (H12AffineFastState.compose env48035 (packedSelected [0,2,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound48035 : packedSelected [0,2,3,4] rootPS < 2^1333 := by decide +kernel

def env48036 : List Nat := [2,4,2,6,7,64,3,3,64,4,71,6,68,1,71,68,71,71,69,70,6,64,6,68,4,0,0,1,1,7,66,6,3,70,70,0]

theorem envBound48036 : H12AffineFastState.Bounded env48036 := by
  intro p hp
  have h : env48036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48035_48036 : H12AffineEnvironment.transform 4 7 env48035 = env48036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env48035 == env48036) = true)

def env48037 : List Nat := [2,4,8,16,32,64,128,256,341,273,2048,17,8192,1,8477,65536,74111,65664,337,8476,17,476,74046,65537,8392,74031,303,74031,1,75851,8204,74046,256,8200,80,276]

theorem envBound48037 : H12AffineFastState.Bounded env48037 := by
  intro p hp
  have h : env48037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48022_48037 : H12AffineEnvironment.transform 11 17 env48022 = env48037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env48022 == env48037) = true)

theorem identity48037 : scanCanonicalize (H12AffineFastState.compose env48037 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 62) := by decide +kernel

theorem selectedBound48037 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env48038 : List Nat := [2,4,8,16,32,64,128,256,341,273,2048,17,8192,1,8477,62,8513,190,337,8476,17,476,8448,63,8392,8465,303,8465,1,10357,8204,8448,256,8200,80,276]

theorem envBound48038 : H12AffineFastState.Bounded env48038 := by
  intro p hp
  have h : env48038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48037_48038 : H12AffineEnvironment.transform 15 62 env48037 = env48038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62 env48037 == env48038) = true)

def env48039 : List Nat := [2,4,8,16,32,64,128,8,93,25,2048,17,8192,1,8213,62,8265,190,89,8212,17,212,8200,63,8392,8217,39,8217,1,10357,8204,8200,8,8200,80,28]

theorem envBound48039 : H12AffineFastState.Bounded env48039 := by
  intro p hp
  have h : env48039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48038_48039 : H12AffineEnvironment.transform 7 8 env48038 = env48039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 8 env48038 == env48039) = true)

theorem identity48039 : scanCanonicalize (H12AffineFastState.compose env48039 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(12+1) ^^^ 73) := by decide +kernel

theorem selectedBound48039 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env48040 : List Nat := [2,4,8,16,32,64,128,8,93,25,2048,17,73,1,92,62,0,190,89,93,17,212,65,63,129,80,39,80,1,2108,69,65,8,65,80,28]

theorem envBound48040 : H12AffineFastState.Bounded env48040 := by
  intro p hp
  have h : env48040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48039_48040 : H12AffineEnvironment.transform 12 73 env48039 = env48040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env48039 == env48040) = true)

theorem identity48040 : scanCanonicalize (H12AffineFastState.compose env48040 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 12) := by decide +kernel

theorem selectedBound48040 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env48041 : List Nat := [2,4,8,16,32,12,128,8,17,25,2048,17,5,1,16,62,0,190,21,17,17,152,13,63,129,28,39,28,1,2108,9,13,8,13,28,28]

theorem envBound48041 : H12AffineFastState.Bounded env48041 := by
  intro p hp
  have h : env48041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48040_48041 : H12AffineEnvironment.transform 5 12 env48040 = env48041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 12 env48040 == env48041) = true)

theorem identity48041 : scanCanonicalize (H12AffineFastState.compose env48041 (packedSelected [0,2,3,7,11,12,13] rootPS)) = affineNative (2^(10+1) ^^^ 158) := by decide +kernel

theorem selectedBound48041 : packedSelected [0,2,3,7,11,12,13] rootPS < 2^1333 := by decide +kernel

def env48042 : List Nat := [2,4,8,16,32,12,128,8,17,25,158,17,5,1,16,62,0,190,21,17,17,152,13,63,129,28,39,28,1,162,9,13,8,13,28,28]

theorem envBound48042 : H12AffineFastState.Bounded env48042 := by
  intro p hp
  have h : env48042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48041_48042 : H12AffineEnvironment.transform 10 158 env48041 = env48042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 158 env48041 == env48042) = true)

theorem identity48042 : scanCanonicalize (H12AffineFastState.compose env48042 (packedSelected [0,2,4,5,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 47) := by decide +kernel

theorem selectedBound48042 : packedSelected [0,2,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env48043 : List Nat := [2,4,8,16,32,12,47,8,17,25,49,17,5,1,16,62,0,17,21,17,17,55,13,63,46,28,39,28,1,13,9,13,8,13,28,28]

theorem envBound48043 : H12AffineFastState.Bounded env48043 := by
  intro p hp
  have h : env48043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48042_48043 : H12AffineEnvironment.transform 6 47 env48042 = env48043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 47 env48042 == env48043) = true)

theorem identity48043 : scanCanonicalize (H12AffineFastState.compose env48043 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound48043 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env48044 : List Nat := [2,4,8,16,10,12,5,8,17,25,27,17,5,1,16,20,0,17,21,17,17,29,13,21,4,28,13,28,1,13,9,13,8,13,28,28]

theorem envBound48044 : H12AffineFastState.Bounded env48044 := by
  intro p hp
  have h : env48044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48043_48044 : H12AffineEnvironment.transform 4 10 env48043 = env48044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env48043 == env48044) = true)

theorem identity48044 : scanCanonicalize (H12AffineFastState.compose env48044 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound48044 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48045 : List Nat := [2,4,8,12,10,12,5,8,13,5,7,13,5,1,12,8,0,13,9,13,13,1,13,9,4,0,13,0,1,13,9,13,8,13,0,0]

theorem envBound48045 : H12AffineFastState.Bounded env48045 := by
  intro p hp
  have h : env48045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48044_48045 : H12AffineEnvironment.transform 3 12 env48044 = env48045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env48044 == env48045) = true)

theorem identity48045 : scanCanonicalize (H12AffineFastState.compose env48045 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound48045 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env48046 : List Nat := [2,4,5,1,7,1,5,5,0,5,7,0,5,1,1,5,0,0,4,0,0,1,0,4,4,0,0,0,1,0,4,0,5,0,0,0]

theorem envBound48046 : H12AffineFastState.Bounded env48046 := by
  intro p hp
  have h : env48046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48045_48046 : H12AffineEnvironment.transform 2 5 env48045 = env48046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env48045 == env48046) = true)

def env48047 : List Nat := [2,4,8,16,32,64,128,9,92,24,2048,17,8192,1,8212,62,8264,190,88,8213,17,213,8201,63,8392,8216,38,8216,1,10357,8204,8201,9,8200,80,29]

theorem envBound48047 : H12AffineFastState.Bounded env48047 := by
  intro p hp
  have h : env48047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48038_48047 : H12AffineEnvironment.transform 7 9 env48038 = env48047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 9 env48038 == env48047) = true)

theorem identity48047 : scanCanonicalize (H12AffineFastState.compose env48047 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(12+1) ^^^ 69) := by decide +kernel

theorem selectedBound48047 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env48048 : List Nat := [2,4,8,16,32,64,128,9,92,24,2048,17,69,1,81,62,13,190,88,80,17,213,76,63,141,93,38,93,1,2096,73,76,9,77,80,29]

theorem envBound48048 : H12AffineFastState.Bounded env48048 := by
  intro p hp
  have h : env48048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48047_48048 : H12AffineEnvironment.transform 12 69 env48047 = env48048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 69 env48047 == env48048) = true)

theorem identity48048 : scanCanonicalize (H12AffineFastState.compose env48048 (packedSelected [1,3,13,15,17,19] rootPS)) = affineNative (2^(5+1) ^^^ 45) := by decide +kernel

theorem selectedBound48048 : packedSelected [1,3,13,15,17,19] rootPS < 2^1333 := by decide +kernel

def env48049 : List Nat := [2,4,8,16,32,45,128,9,49,24,2048,17,40,1,60,62,13,190,53,61,17,184,33,63,141,48,38,48,1,2096,36,33,9,32,61,29]

theorem envBound48049 : H12AffineFastState.Bounded env48049 := by
  intro p hp
  have h : env48049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48048_48049 : H12AffineEnvironment.transform 5 45 env48048 = env48049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 45 env48048 == env48049) = true)

theorem identity48049 : scanCanonicalize (H12AffineFastState.compose env48049 (packedSelected [0,1,2,3,5,7,11,13,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 142) := by decide +kernel

theorem selectedBound48049 : packedSelected [0,1,2,3,5,7,11,13,15,17] rootPS < 2^1333 := by decide +kernel

def env48050 : List Nat := [2,4,8,16,32,45,128,9,49,24,142,17,40,1,60,62,13,190,53,61,17,184,33,63,141,48,38,48,1,190,36,33,9,32,61,29]

theorem envBound48050 : H12AffineFastState.Bounded env48050 := by
  intro p hp
  have h : env48050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48049_48050 : H12AffineEnvironment.transform 10 142 env48049 = env48050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 142 env48049 == env48050) = true)

theorem identity48050 : scanCanonicalize (H12AffineFastState.compose env48050 (packedSelected [1,2,5,8,12] rootPS)) = affineNative (2^(6+1) ^^^ 30) := by decide +kernel

theorem selectedBound48050 : packedSelected [1,2,5,8,12] rootPS < 2^1333 := by decide +kernel

def env48051 : List Nat := [2,4,8,16,32,45,30,9,49,24,16,17,40,1,60,62,13,32,53,61,17,38,33,63,19,48,38,48,1,32,36,33,9,32,61,29]

theorem envBound48051 : H12AffineFastState.Bounded env48051 := by
  intro p hp
  have h : env48051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48050_48051 : H12AffineEnvironment.transform 6 30 env48050 = env48051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 30 env48050 == env48051) = true)

theorem identity48051 : scanCanonicalize (H12AffineFastState.compose env48051 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(4+1) ^^^ 29) := by decide +kernel

theorem selectedBound48051 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env48052 : List Nat := [2,4,8,16,29,16,30,9,12,24,16,17,21,1,1,3,13,29,8,0,17,27,28,2,19,13,27,13,1,29,25,28,9,29,0,29]

theorem envBound48052 : H12AffineFastState.Bounded env48052 := by
  intro p hp
  have h : env48052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48051_48052 : H12AffineEnvironment.transform 4 29 env48051 = env48052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 29 env48051 == env48052) = true)

theorem identity48052 : scanCanonicalize (H12AffineFastState.compose env48052 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound48052 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env48053 : List Nat := [2,4,8,0,13,0,14,9,12,8,0,1,5,1,1,3,13,13,8,0,1,11,12,2,3,13,11,13,1,13,9,12,9,13,0,13]

theorem envBound48053 : H12AffineFastState.Bounded env48053 := by
  intro p hp
  have h : env48053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48052_48053 : H12AffineEnvironment.transform 3 0 env48052 = env48053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env48052 == env48053) = true)

theorem identity48053 : scanCanonicalize (H12AffineFastState.compose env48053 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound48053 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48054 : List Nat := [2,4,0,0,5,0,6,1,4,0,0,1,5,1,1,3,5,5,0,0,1,3,4,2,3,5,3,5,1,5,1,4,1,5,0,5]

theorem envBound48054 : H12AffineFastState.Bounded env48054 := by
  intro p hp
  have h : env48054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48053_48054 : H12AffineEnvironment.transform 2 0 env48053 = env48054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env48053 == env48054) = true)

theorem identity48054 : scanCanonicalize (H12AffineFastState.compose env48054 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound48054 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48055 : List Nat := [1,4,0,0,5,0,5,1,4,0,0,1,5,1,1,0,5,5,0,0,1,0,4,1,0,5,0,5,1,5,1,4,1,5,0,5]

theorem envBound48055 : H12AffineFastState.Bounded env48055 := by
  intro p hp
  have h : env48055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48054_48055 : H12AffineEnvironment.transform 0 1 env48054 = env48055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env48054 == env48055) = true)

def env48056 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74862,65665,4416,13340,4096,476,74046,69648,13768,78895,4415,74814,1296,81227,8204,74799,256,8200,1345,5953]

theorem envBound48056 : H12AffineFastState.Bounded env48056 := by
  intro p hp
  have h : env48056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47977_48056 : H12AffineEnvironment.transform 17 65665 env47977 = env48056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env47977 == env48056) = true)

theorem identity48056 : scanCanonicalize (H12AffineFastState.compose env48056 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound48056 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env48057 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,8192,1296,9292,65536,74862,65665,273,9293,81,476,74046,65601,9625,74878,366,74814,1296,77082,8204,74799,256,8200,1345,1808]

theorem envBound48057 : H12AffineFastState.Bounded env48057 := by
  intro p hp
  have h : env48057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48056_48057 : H12AffineEnvironment.transform 11 81 env48056 = env48057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env48056 == env48057) = true)

def env48058 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,81,8192,1296,9292,65536,74862,65665,273,9293,81,476,74046,65601,9625,74878,366,74814,1296,77082,8204,74799,256,8200,1345,1092]

theorem envBound48058 : H12AffineFastState.Bounded env48058 := by
  intro p hp
  have h : env48058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48057_48058 : H12AffineEnvironment.transform 8 340 env48057 = env48058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env48057 == env48058) = true)

def env48059 : List Nat := [2,4,8,16,32,0,128,256,276,1024,2048,17,8192,1296,9228,65536,74798,65665,273,9229,17,412,74046,65537,9625,74814,302,74814,1296,77082,8204,74799,256,8200,1281,1028]

theorem envBound48059 : H12AffineFastState.Bounded env48059 := by
  intro p hp
  have h : env48059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48058_48059 : H12AffineEnvironment.transform 5 0 env48058 = env48059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env48058 == env48059) = true)

theorem identity48059 : scanCanonicalize (H12AffineFastState.compose env48059 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 272) := by decide +kernel

theorem selectedBound48059 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env48060 : List Nat := [2,4,8,16,32,0,128,256,276,1024,2048,17,272,1296,1308,65536,66878,65665,273,1309,17,412,65582,65537,1161,66862,302,66862,1296,68618,284,66879,256,280,1281,1028]

theorem envBound48060 : H12AffineFastState.Bounded env48060 := by
  intro p hp
  have h : env48060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48059_48060 : H12AffineEnvironment.transform 12 272 env48059 = env48060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 272 env48059 == env48060) = true)

def env48061 : List Nat := [2,4,8,16,32,0,128,256,276,24,2048,17,272,264,260,65536,65830,65665,273,261,17,412,65582,65537,145,65846,302,65846,264,67602,284,65831,256,280,281,28]

theorem envBound48061 : H12AffineFastState.Bounded env48061 := by
  intro p hp
  have h : env48061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48060_48061 : H12AffineEnvironment.transform 9 24 env48060 = env48061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 24 env48060 == env48061) = true)

theorem identity48061 : scanCanonicalize (H12AffineFastState.compose env48061 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 50) := by decide +kernel

theorem selectedBound48061 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env48062 : List Nat := [2,4,8,16,32,0,128,256,276,24,2048,17,272,264,260,50,276,179,273,261,17,412,28,51,145,260,302,260,264,2080,284,277,256,280,281,28]

theorem envBound48062 : H12AffineFastState.Bounded env48062 := by
  intro p hp
  have h : env48062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48061_48062 : H12AffineEnvironment.transform 15 50 env48061 = env48062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 50 env48061 == env48062) = true)

theorem identity48062 : scanCanonicalize (H12AffineFastState.compose env48062 (packedSelected [1,2,3,4,9,10,12,16,17] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound48062 : packedSelected [1,2,3,4,9,10,12,16,17] rootPS < 2^1333 := by decide +kernel

def env48063 : List Nat := [2,4,8,13,32,0,128,256,265,5,2048,12,269,264,260,47,265,174,268,261,12,385,1,46,140,260,302,260,264,2080,257,264,256,261,260,1]

theorem envBound48063 : H12AffineFastState.Bounded env48063 := by
  intro p hp
  have h : env48063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48062_48063 : H12AffineEnvironment.transform 3 13 env48062 = env48063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env48062 == env48063) = true)

theorem identity48063 : scanCanonicalize (H12AffineFastState.compose env48063 (packedSelected [0,3,7,8,11,15] rootPS)) = affineNative (2^(10+1) ^^^ 296) := by decide +kernel

theorem selectedBound48063 : packedSelected [0,3,7,8,11,15] rootPS < 2^1333 := by decide +kernel

def env48064 : List Nat := [2,4,8,13,32,0,128,256,265,5,296,12,269,264,260,47,265,174,268,261,12,385,1,46,140,260,302,260,264,264,257,264,256,261,260,1]

theorem envBound48064 : H12AffineFastState.Bounded env48064 := by
  intro p hp
  have h : env48064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48063_48064 : H12AffineEnvironment.transform 10 296 env48063 = env48064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 296 env48063 == env48064) = true)

theorem identity48064 : scanCanonicalize (H12AffineFastState.compose env48064 (packedSelected [3,5] rootPS)) = affineNative (2^(7+1) ^^^ 161) := by decide +kernel

theorem selectedBound48064 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env48065 : List Nat := [2,4,8,13,32,0,128,161,168,5,137,12,172,169,165,47,168,174,173,164,12,32,1,46,140,165,143,165,169,169,160,169,161,164,165,1]

theorem envBound48065 : H12AffineFastState.Bounded env48065 := by
  intro p hp
  have h : env48065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48064_48065 : H12AffineEnvironment.transform 7 161 env48064 = env48065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 161 env48064 == env48065) = true)

theorem identity48065 : scanCanonicalize (H12AffineFastState.compose env48065 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound48065 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48066 : List Nat := [2,4,8,13,32,0,40,9,0,5,33,12,4,1,13,47,0,6,5,12,12,32,1,46,36,13,39,13,1,1,8,1,9,12,13,1]

theorem envBound48066 : H12AffineFastState.Bounded env48066 := by
  intro p hp
  have h : env48066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48065_48066 : H12AffineEnvironment.transform 6 40 env48065 = env48066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env48065 == env48066) = true)

theorem identity48066 : scanCanonicalize (H12AffineFastState.compose env48066 (packedSelected [0,2] rootPS)) = affineNative (2^(4+1) ^^^ 4) := by decide +kernel

theorem selectedBound48066 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env48067 : List Nat := [2,4,8,13,4,0,12,9,0,5,5,12,4,1,13,11,0,6,5,12,12,4,1,10,0,13,3,13,1,1,8,1,9,12,13,1]

theorem envBound48067 : H12AffineFastState.Bounded env48067 := by
  intro p hp
  have h : env48067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48066_48067 : H12AffineEnvironment.transform 4 4 env48066 = env48067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 4 env48066 == env48067) = true)

theorem identity48067 : scanCanonicalize (H12AffineFastState.compose env48067 (packedSelected [3,8] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound48067 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env48068 : List Nat := [2,2,8,11,2,0,10,9,0,3,3,10,2,1,11,11,0,0,3,10,10,2,1,10,0,11,3,11,1,1,8,1,9,10,11,1]

theorem envBound48068 : H12AffineFastState.Bounded env48068 := by
  intro p hp
  have h : env48068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48067_48068 : H12AffineEnvironment.transform 1 2 env48067 = env48068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env48067 == env48068) = true)

theorem identity48068 : scanCanonicalize (H12AffineFastState.compose env48068 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound48068 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env48069 : List Nat := [2,2,0,3,2,0,2,1,0,3,3,2,2,1,3,3,0,0,3,2,2,2,1,2,0,3,3,3,1,1,0,1,1,2,3,1]

theorem envBound48069 : H12AffineFastState.Bounded env48069 := by
  intro p hp
  have h : env48069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48068_48069 : H12AffineEnvironment.transform 2 0 env48068 = env48069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env48068 == env48069) = true)

def env48070 : List Nat := [2,4,8,16,32,0,128,256,276,25,2048,17,272,265,261,65536,65831,65665,273,260,17,412,65582,65537,144,65847,302,65847,265,67603,284,65830,256,280,280,29]

theorem envBound48070 : H12AffineFastState.Bounded env48070 := by
  intro p hp
  have h : env48070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48060_48070 : H12AffineEnvironment.transform 9 25 env48060 = env48070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 25 env48060 == env48070) = true)

theorem identity48070 : scanCanonicalize (H12AffineFastState.compose env48070 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 315) := by decide +kernel

theorem selectedBound48070 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env48071 : List Nat := [2,4,8,16,32,0,128,256,276,25,2048,17,272,265,261,315,28,442,273,260,17,412,277,314,144,12,302,12,265,2344,284,29,256,280,280,29]

theorem envBound48071 : H12AffineFastState.Bounded env48071 := by
  intro p hp
  have h : env48071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48070_48071 : H12AffineEnvironment.transform 15 315 env48070 = env48071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 315 env48070 == env48071) = true)

theorem identity48071 : scanCanonicalize (H12AffineFastState.compose env48071 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound48071 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env48072 : List Nat := [2,4,8,16,32,0,128,20,0,25,2048,17,4,29,17,47,28,174,5,16,17,136,1,46,144,12,58,12,29,2108,8,29,20,12,12,29]

theorem envBound48072 : H12AffineFastState.Bounded env48072 := by
  intro p hp
  have h : env48072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48071_48072 : H12AffineEnvironment.transform 7 20 env48071 = env48072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env48071 == env48072) = true)

theorem identity48072 : scanCanonicalize (H12AffineFastState.compose env48072 (packedSelected [0,1,2,7,8,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 137) := by decide +kernel

theorem selectedBound48072 : packedSelected [0,1,2,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env48073 : List Nat := [2,4,8,16,32,0,128,20,0,25,137,17,4,29,17,47,28,174,5,16,17,136,1,46,144,12,58,12,29,181,8,29,20,12,12,29]

theorem envBound48073 : H12AffineFastState.Bounded env48073 := by
  intro p hp
  have h : env48073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48072_48073 : H12AffineEnvironment.transform 10 137 env48072 = env48073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 137 env48072 == env48073) = true)

theorem identity48073 : scanCanonicalize (H12AffineFastState.compose env48073 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 20) := by decide +kernel

theorem selectedBound48073 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48074 : List Nat := [2,4,8,16,32,0,20,20,0,25,29,17,4,29,17,47,28,58,5,16,17,28,1,46,4,12,58,12,29,33,8,29,20,12,12,29]

theorem envBound48074 : H12AffineFastState.Bounded env48074 := by
  intro p hp
  have h : env48074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48073_48074 : H12AffineEnvironment.transform 6 20 env48073 = env48074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 20 env48073 == env48074) = true)

theorem identity48074 : scanCanonicalize (H12AffineFastState.compose env48074 (packedSelected [0,3,4,8] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound48074 : packedSelected [0,3,4,8] rootPS < 2^1333 := by decide +kernel

def env48075 : List Nat := [2,4,8,16,26,0,20,20,0,25,29,17,4,29,17,21,28,0,5,16,17,28,1,20,4,12,0,12,29,27,8,29,20,12,12,29]

theorem envBound48075 : H12AffineFastState.Bounded env48075 := by
  intro p hp
  have h : env48075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48074_48075 : H12AffineEnvironment.transform 4 26 env48074 = env48075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env48074 == env48075) = true)

def env48076 : List Nat := [2,4,8,16,32,1,128,256,277,1024,2048,16,8192,1296,9229,65536,74799,65665,273,9228,16,413,74046,65536,9625,74815,303,74814,1296,77082,8204,74799,256,8200,1280,1029]

theorem envBound48076 : H12AffineFastState.Bounded env48076 := by
  intro p hp
  have h : env48076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48058_48076 : H12AffineEnvironment.transform 5 1 env48058 = env48076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env48058 == env48076) = true)

theorem identity48076 : scanCanonicalize (H12AffineFastState.compose env48076 (packedSelected [1,8,28] rootPS)) = affineNative (2^(9+1) ^^^ 24) := by decide +kernel

theorem selectedBound48076 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env48077 : List Nat := [2,4,8,16,32,1,128,256,277,24,2048,16,8192,264,8213,65536,73783,65665,273,8212,16,413,74046,65536,8577,73767,303,73766,264,76034,8204,73783,256,8200,280,29]

theorem envBound48077 : H12AffineFastState.Bounded env48077 := by
  intro p hp
  have h : env48077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48076_48077 : H12AffineEnvironment.transform 9 24 env48076 = env48077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 24 env48076 == env48077) = true)

def env48078 : List Nat := [2,4,8,16,32,1,128,256,277,24,2048,16,272,264,261,65536,65831,65665,273,260,16,413,65582,65536,145,65847,303,65846,264,67602,284,65831,256,280,280,29]

theorem envBound48078 : H12AffineFastState.Bounded env48078 := by
  intro p hp
  have h : env48078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48077_48078 : H12AffineEnvironment.transform 12 272 env48077 = env48078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 272 env48077 == env48078) = true)

theorem identity48078 : scanCanonicalize (H12AffineFastState.compose env48078 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 51) := by decide +kernel

theorem selectedBound48078 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env48079 : List Nat := [2,4,8,16,32,1,128,256,277,24,2048,16,272,264,261,51,276,178,273,260,16,413,29,51,145,260,303,261,264,2081,284,276,256,280,280,29]

theorem envBound48079 : H12AffineFastState.Bounded env48079 := by
  intro p hp
  have h : env48079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48078_48079 : H12AffineEnvironment.transform 15 51 env48078 = env48079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 51 env48078 == env48079) = true)

theorem identity48079 : scanCanonicalize (H12AffineFastState.compose env48079 (packedSelected [1,2,3,4,9,10,12,16,17] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound48079 : packedSelected [1,2,3,4,9,10,12,16,17] rootPS < 2^1333 := by decide +kernel

def env48080 : List Nat := [2,4,8,1,32,1,128,256,260,9,2048,1,257,264,261,34,261,163,256,260,1,396,12,34,128,260,303,261,264,2081,269,261,256,265,265,12]

theorem envBound48080 : H12AffineFastState.Bounded env48080 := by
  intro p hp
  have h : env48080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48079_48080 : H12AffineEnvironment.transform 3 1 env48079 = env48080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env48079 == env48080) = true)

theorem identity48080 : scanCanonicalize (H12AffineFastState.compose env48080 (packedSelected [0,1,2,5,7,11,12,13] rootPS)) = affineNative (2^(10+1) ^^^ 142) := by decide +kernel

theorem selectedBound48080 : packedSelected [0,1,2,5,7,11,12,13] rootPS < 2^1333 := by decide +kernel

def env48081 : List Nat := [2,4,8,1,32,1,128,256,260,9,142,1,257,264,261,34,261,163,256,260,1,396,12,34,128,260,303,261,264,175,269,261,256,265,265,12]

theorem envBound48081 : H12AffineFastState.Bounded env48081 := by
  intro p hp
  have h : env48081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48080_48081 : H12AffineEnvironment.transform 10 142 env48080 = env48081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 142 env48080 == env48081) = true)

theorem identity48081 : scanCanonicalize (H12AffineFastState.compose env48081 (packedSelected [0,1,2,4,5,7,8,9] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound48081 : packedSelected [0,1,2,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env48082 : List Nat := [2,4,8,1,12,1,128,256,260,9,142,1,257,264,261,14,261,143,256,260,1,396,12,14,128,260,259,261,264,131,269,261,256,265,265,12]

theorem envBound48082 : H12AffineFastState.Bounded env48082 := by
  intro p hp
  have h : env48082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48081_48082 : H12AffineEnvironment.transform 4 12 env48081 = env48082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env48081 == env48082) = true)

theorem identity48082 : scanCanonicalize (H12AffineFastState.compose env48082 (packedSelected [2,5] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound48082 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env48083 : List Nat := [2,3,8,1,11,1,128,256,259,9,137,1,257,264,258,9,258,136,256,259,1,395,11,9,128,259,259,258,264,131,266,258,256,265,265,11]

theorem envBound48083 : H12AffineFastState.Bounded env48083 := by
  intro p hp
  have h : env48083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48082_48083 : H12AffineEnvironment.transform 1 3 env48082 = env48083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env48082 == env48083) = true)

theorem identity48083 : scanCanonicalize (H12AffineFastState.compose env48083 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(7+1) ^^^ 138) := by decide +kernel

theorem selectedBound48083 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env48084 : List Nat := [2,3,8,1,11,1,128,138,137,9,137,1,139,130,136,9,136,136,138,137,1,1,11,9,128,137,137,136,130,131,128,136,138,131,131,11]

theorem envBound48084 : H12AffineFastState.Bounded env48084 := by
  intro p hp
  have h : env48084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48083_48084 : H12AffineEnvironment.transform 7 138 env48083 = env48084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 138 env48083 == env48084) = true)

theorem identity48084 : scanCanonicalize (H12AffineFastState.compose env48084 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound48084 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48085 : List Nat := [2,3,2,1,1,1,128,128,131,3,131,1,129,130,130,3,130,130,128,131,1,1,1,3,128,131,131,130,130,131,128,130,128,131,131,1]

theorem envBound48085 : H12AffineFastState.Bounded env48085 := by
  intro p hp
  have h : env48085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48084_48085 : H12AffineEnvironment.transform 2 2 env48084 = env48085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env48084 == env48085) = true)

def env48086 : List Nat := [2,4,8,16,32,1,128,256,277,24,2048,16,273,264,260,65536,65830,65665,273,261,16,413,65583,65536,144,65846,303,65847,264,67603,285,65830,256,281,280,29]

theorem envBound48086 : H12AffineFastState.Bounded env48086 := by
  intro p hp
  have h : env48086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48077_48086 : H12AffineEnvironment.transform 12 273 env48077 = env48086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 273 env48077 == env48086) = true)

theorem identity48086 : scanCanonicalize (H12AffineFastState.compose env48086 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 315) := by decide +kernel

theorem selectedBound48086 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env48087 : List Nat := [2,4,8,16,32,1,128,256,277,24,2048,16,273,264,260,315,29,442,273,261,16,413,276,315,144,13,303,12,264,2344,285,29,256,281,280,29]

theorem envBound48087 : H12AffineFastState.Bounded env48087 := by
  intro p hp
  have h : env48087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48086_48087 : H12AffineEnvironment.transform 15 315 env48086 = env48087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 315 env48086 == env48087) = true)

theorem identity48087 : scanCanonicalize (H12AffineFastState.compose env48087 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound48087 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env48088 : List Nat := [2,4,8,16,32,1,128,20,1,24,2048,16,5,28,16,47,29,174,5,17,16,137,0,47,144,13,59,12,28,2108,9,29,20,13,12,29]

theorem envBound48088 : H12AffineFastState.Bounded env48088 := by
  intro p hp
  have h : env48088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48087_48088 : H12AffineEnvironment.transform 7 20 env48087 = env48088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env48087 == env48088) = true)

theorem identity48088 : scanCanonicalize (H12AffineFastState.compose env48088 (packedSelected [0,1,2,7,8,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 137) := by decide +kernel

theorem selectedBound48088 : packedSelected [0,1,2,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env48089 : List Nat := [2,4,8,16,32,1,128,20,1,24,137,16,5,28,16,47,29,174,5,17,16,137,0,47,144,13,59,12,28,181,9,29,20,13,12,29]

theorem envBound48089 : H12AffineFastState.Bounded env48089 := by
  intro p hp
  have h : env48089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48088_48089 : H12AffineEnvironment.transform 10 137 env48088 = env48089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 137 env48088 == env48089) = true)

theorem identity48089 : scanCanonicalize (H12AffineFastState.compose env48089 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound48089 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48090 : List Nat := [2,4,8,16,32,1,8,20,1,24,1,16,5,28,16,47,29,38,5,17,16,1,0,47,24,13,59,12,28,61,9,29,20,13,12,29]

theorem envBound48090 : H12AffineFastState.Bounded env48090 := by
  intro p hp
  have h : env48090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48089_48090 : H12AffineEnvironment.transform 6 8 env48089 = env48090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env48089 == env48090) = true)

theorem identity48090 : scanCanonicalize (H12AffineFastState.compose env48090 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound48090 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env48091 : List Nat := [2,4,5,16,32,1,5,20,1,21,1,16,5,17,16,34,16,38,5,17,16,1,0,34,21,0,54,1,17,48,4,16,20,0,1,16]

theorem envBound48091 : H12AffineFastState.Bounded env48091 := by
  intro p hp
  have h : env48091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48090_48091 : H12AffineEnvironment.transform 2 5 env48090 = env48091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env48090 == env48091) = true)

theorem identity48091 : scanCanonicalize (H12AffineFastState.compose env48091 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound48091 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env48092 : List Nat := [2,4,5,1,32,1,5,5,1,4,1,1,5,0,1,34,1,38,5,0,1,1,0,34,4,0,39,1,0,33,4,1,5,0,1,1]

theorem envBound48092 : H12AffineFastState.Bounded env48092 := by
  intro p hp
  have h : env48092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48091_48092 : H12AffineEnvironment.transform 3 1 env48091 = env48092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env48091 == env48092) = true)

theorem identity48092 : scanCanonicalize (H12AffineFastState.compose env48092 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound48092 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48093 : List Nat := [2,4,5,1,0,1,5,5,1,4,1,1,5,0,1,2,1,6,5,0,1,1,0,2,4,0,7,1,0,1,4,1,5,0,1,1]

theorem envBound48093 : H12AffineFastState.Bounded env48093 := by
  intro p hp
  have h : env48093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48092_48093 : H12AffineEnvironment.transform 4 0 env48092 = env48093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env48092 == env48093) = true)

def env48094 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,81,8192,1296,9292,65536,74862,65665,273,9293,81,476,74046,65601,9625,74878,366,74814,1296,77082,8204,74799,256,8200,1345,1093]

theorem envBound48094 : H12AffineFastState.Bounded env48094 := by
  intro p hp
  have h : env48094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48057_48094 : H12AffineEnvironment.transform 8 341 env48057 = env48094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env48057 == env48094) = true)

def env48095 : List Nat := [2,4,8,16,32,0,128,256,277,1024,2048,17,8192,1296,9228,65536,74798,65665,273,9229,17,412,74046,65537,9625,74814,302,74814,1296,77082,8204,74799,256,8200,1281,1029]

theorem envBound48095 : H12AffineFastState.Bounded env48095 := by
  intro p hp
  have h : env48095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48094_48095 : H12AffineEnvironment.transform 5 0 env48094 = env48095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env48094 == env48095) = true)

theorem identity48095 : scanCanonicalize (H12AffineFastState.compose env48095 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 63) := by decide +kernel

theorem selectedBound48095 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env48096 : List Nat := [2,4,8,16,32,0,128,256,277,1024,2048,17,8192,1296,9228,63,9233,190,273,9229,17,412,8449,62,9625,9217,302,9217,1296,11557,8204,9232,256,8200,1281,1029]

theorem envBound48096 : H12AffineFastState.Bounded env48096 := by
  intro p hp
  have h : env48096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48095_48096 : H12AffineEnvironment.transform 15 63 env48095 = env48096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 63 env48095 == env48096) = true)

def env48097 : List Nat := [2,4,8,16,32,0,128,256,277,24,2048,17,8192,264,8212,63,8201,190,273,8213,17,412,8449,62,8577,8217,302,8217,264,10557,8204,8200,256,8200,281,29]

theorem envBound48097 : H12AffineFastState.Bounded env48097 := by
  intro p hp
  have h : env48097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48096_48097 : H12AffineEnvironment.transform 9 24 env48096 = env48097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 24 env48096 == env48097) = true)

theorem identity48097 : scanCanonicalize (H12AffineFastState.compose env48097 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(12+1) ^^^ 256) := by decide +kernel

theorem selectedBound48097 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env48098 : List Nat := [2,4,8,16,32,0,128,256,277,24,2048,17,256,264,276,63,265,190,273,277,17,412,1,62,129,281,302,281,264,2109,268,264,256,264,281,29]

theorem envBound48098 : H12AffineFastState.Bounded env48098 := by
  intro p hp
  have h : env48098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48097_48098 : H12AffineEnvironment.transform 12 256 env48097 = env48098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 256 env48097 == env48098) = true)

theorem identity48098 : scanCanonicalize (H12AffineFastState.compose env48098 (packedSelected [4,9,16] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound48098 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env48099 : List Nat := [2,4,5,16,32,0,128,256,277,21,2048,17,256,261,276,50,260,179,273,277,17,401,1,51,129,276,291,276,261,2096,257,261,256,261,276,16]

theorem envBound48099 : H12AffineFastState.Bounded env48099 := by
  intro p hp
  have h : env48099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48098_48099 : H12AffineEnvironment.transform 2 5 env48098 = env48099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env48098 == env48099) = true)

theorem identity48099 : scanCanonicalize (H12AffineFastState.compose env48099 (packedSelected [2,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound48099 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env48100 : List Nat := [2,4,5,16,1,0,128,256,277,21,2048,17,256,261,276,19,260,146,273,277,17,401,1,18,129,276,258,276,261,2065,257,261,256,261,276,16]

theorem envBound48100 : H12AffineFastState.Bounded env48100 := by
  intro p hp
  have h : env48100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48099_48100 : H12AffineEnvironment.transform 4 1 env48099 = env48100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env48099 == env48100) = true)

theorem identity48100 : scanCanonicalize (H12AffineFastState.compose env48100 (packedSelected [0,3,7,10,11,12,13] rootPS)) = affineNative (2^(10+1) ^^^ 130) := by decide +kernel

theorem selectedBound48100 : packedSelected [0,3,7,10,11,12,13] rootPS < 2^1333 := by decide +kernel

def env48101 : List Nat := [2,4,5,16,1,0,128,256,277,21,130,17,256,261,276,19,260,146,273,277,17,401,1,18,129,276,258,276,261,147,257,261,256,261,276,16]

theorem envBound48101 : H12AffineFastState.Bounded env48101 := by
  intro p hp
  have h : env48101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48100_48101 : H12AffineEnvironment.transform 10 130 env48100 = env48101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 130 env48100 == env48101) = true)

theorem identity48101 : scanCanonicalize (H12AffineFastState.compose env48101 (packedSelected [0,1,2,3,4,7,9] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound48101 : packedSelected [0,1,2,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env48102 : List Nat := [2,4,5,6,1,0,128,256,259,3,130,7,256,261,258,5,260,132,263,259,7,391,1,4,129,258,258,258,261,133,257,261,256,261,258,6]

theorem envBound48102 : H12AffineFastState.Bounded env48102 := by
  intro p hp
  have h : env48102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48101_48102 : H12AffineEnvironment.transform 3 6 env48101 = env48102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env48101 == env48102) = true)

theorem identity48102 : scanCanonicalize (H12AffineFastState.compose env48102 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(7+1) ^^^ 2) := by decide +kernel

theorem selectedBound48102 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env48103 : List Nat := [2,4,5,6,1,0,128,2,1,3,130,7,2,7,0,5,6,132,5,1,7,133,1,4,129,0,0,0,7,133,3,7,2,7,0,6]

theorem envBound48103 : H12AffineFastState.Bounded env48103 := by
  intro p hp
  have h : env48103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48102_48103 : H12AffineEnvironment.transform 7 2 env48102 = env48103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 2 env48102 == env48103) = true)

theorem identity48103 : scanCanonicalize (H12AffineFastState.compose env48103 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound48103 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48104 : List Nat := [2,4,5,6,1,0,4,2,1,3,6,7,2,7,0,5,6,0,5,1,7,1,1,4,5,0,0,0,7,1,3,7,2,7,0,6]

theorem envBound48104 : H12AffineFastState.Bounded env48104 := by
  intro p hp
  have h : env48104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48103_48104 : H12AffineEnvironment.transform 6 4 env48103 = env48104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env48103 == env48104) = true)

theorem identity48104 : scanCanonicalize (H12AffineFastState.compose env48104 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound48104 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48105 : List Nat := [2,2,3,0,1,0,2,2,1,3,0,1,2,1,0,3,0,0,3,1,1,1,1,2,3,0,0,0,1,1,3,1,2,1,0,0]

theorem envBound48105 : H12AffineFastState.Bounded env48105 := by
  intro p hp
  have h : env48105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48104_48105 : H12AffineEnvironment.transform 1 2 env48104 = env48105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env48104 == env48105) = true)

theorem identity48105 : scanCanonicalize (H12AffineFastState.compose env48105 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound48105 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48106 : List Nat := [1,1,0,0,1,0,1,1,1,0,0,1,1,1,0,0,0,0,0,1,1,1,1,1,0,0,0,0,1,1,0,1,1,1,0,0]

theorem envBound48106 : H12AffineFastState.Bounded env48106 := by
  intro p hp
  have h : env48106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48105_48106 : H12AffineEnvironment.transform 0 1 env48105 = env48106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env48105 == env48106) = true)

def env48107 : List Nat := [2,4,8,16,32,0,128,256,277,25,2048,17,8192,265,8213,63,8200,190,273,8212,17,412,8449,62,8576,8216,302,8216,265,10556,8204,8201,256,8200,280,28]

theorem envBound48107 : H12AffineFastState.Bounded env48107 := by
  intro p hp
  have h : env48107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48096_48107 : H12AffineEnvironment.transform 9 25 env48096 = env48107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 25 env48096 == env48107) = true)

theorem identity48107 : scanCanonicalize (H12AffineFastState.compose env48107 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(12+1) ^^^ 4) := by decide +kernel

theorem selectedBound48107 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env48108 : List Nat := [2,4,8,16,32,0,128,256,277,25,2048,17,4,265,17,63,12,190,273,16,17,412,261,62,388,28,302,28,265,2360,8,13,256,12,280,28]

theorem envBound48108 : H12AffineFastState.Bounded env48108 := by
  intro p hp
  have h : env48108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48107_48108 : H12AffineEnvironment.transform 12 4 env48107 = env48108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4 env48107 == env48108) = true)

theorem identity48108 : scanCanonicalize (H12AffineFastState.compose env48108 (packedSelected [5,8,10,13,15,17] rootPS)) = affineNative (2^(4+1) ^^^ 29) := by decide +kernel

theorem selectedBound48108 : packedSelected [5,8,10,13,15,17] rootPS < 2^1333 := by decide +kernel

def env48109 : List Nat := [2,4,8,16,29,0,128,256,277,25,2048,17,4,265,17,2,12,131,273,16,17,412,261,3,388,28,275,28,265,2309,8,13,256,12,280,28]

theorem envBound48109 : H12AffineFastState.Bounded env48109 := by
  intro p hp
  have h : env48109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48108_48109 : H12AffineEnvironment.transform 4 29 env48108 = env48109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 29 env48108 == env48109) = true)

theorem identity48109 : scanCanonicalize (H12AffineFastState.compose env48109 (packedSelected [1,10,13,15,19] rootPS)) = affineNative (2^(10+1) ^^^ 146) := by decide +kernel

theorem selectedBound48109 : packedSelected [1,10,13,15,19] rootPS < 2^1333 := by decide +kernel

def env48110 : List Nat := [2,4,8,16,29,0,128,256,277,25,146,17,4,265,17,2,12,131,273,16,17,412,261,3,388,28,275,28,265,407,8,13,256,12,280,28]

theorem envBound48110 : H12AffineFastState.Bounded env48110 := by
  intro p hp
  have h : env48110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48109_48110 : H12AffineEnvironment.transform 10 146 env48109 = env48110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 146 env48109 == env48110) = true)

theorem identity48110 : scanCanonicalize (H12AffineFastState.compose env48110 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 19) := by decide +kernel

theorem selectedBound48110 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env48111 : List Nat := [2,4,8,16,29,0,128,19,6,25,146,17,4,26,17,2,12,131,2,16,17,143,22,3,151,28,0,28,26,132,8,13,19,12,11,28]

theorem envBound48111 : H12AffineFastState.Bounded env48111 := by
  intro p hp
  have h : env48111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48110_48111 : H12AffineEnvironment.transform 7 19 env48110 = env48111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 19 env48110 == env48111) = true)

theorem identity48111 : scanCanonicalize (H12AffineFastState.compose env48111 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound48111 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env48112 : List Nat := [2,4,8,6,11,0,128,5,6,15,132,7,4,12,7,2,12,131,2,6,7,143,0,3,129,10,0,10,12,132,8,13,5,12,11,10]

theorem envBound48112 : H12AffineFastState.Bounded env48112 := by
  intro p hp
  have h : env48112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48111_48112 : H12AffineEnvironment.transform 3 6 env48111 = env48112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env48111 == env48112) = true)

theorem identity48112 : scanCanonicalize (H12AffineFastState.compose env48112 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound48112 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48113 : List Nat := [2,4,3,6,0,0,128,5,6,4,132,7,4,7,7,2,7,131,2,6,7,132,0,3,129,1,0,1,7,132,3,6,5,7,0,1]

theorem envBound48113 : H12AffineFastState.Bounded env48113 := by
  intro p hp
  have h : env48113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48112_48113 : H12AffineEnvironment.transform 2 3 env48112 = env48113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env48112 == env48113) = true)

theorem identity48113 : scanCanonicalize (H12AffineFastState.compose env48113 (packedSelected [0,4] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound48113 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env48114 : List Nat := [2,2,3,0,0,0,128,3,0,2,130,1,2,1,1,2,1,131,2,0,1,130,0,3,129,1,0,1,1,130,3,0,3,1,0,1]

theorem envBound48114 : H12AffineFastState.Bounded env48114 := by
  intro p hp
  have h : env48114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48113_48114 : H12AffineEnvironment.transform 1 2 env48113 = env48114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env48113 == env48114) = true)

theorem identity48114 : scanCanonicalize (H12AffineFastState.compose env48114 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 0) := by decide +kernel

theorem selectedBound48114 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48115 : List Nat := [2,2,3,0,0,0,0,3,0,2,2,1,2,1,1,2,1,3,2,0,1,2,0,3,1,1,0,1,1,2,3,0,3,1,0,1]

theorem envBound48115 : H12AffineFastState.Bounded env48115 := by
  intro p hp
  have h : env48115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48114_48115 : H12AffineEnvironment.transform 6 0 env48114 = env48115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 0 env48114 == env48115) = true)

theorem identity48115 : scanCanonicalize (H12AffineFastState.compose env48115 (packedSelected [2] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound48115 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48116 : List Nat := [1,1,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,0,1,0,1,1,0,0,1,1,0,1,1,1,0,0,0,1,0,1]

theorem envBound48116 : H12AffineFastState.Bounded env48116 := by
  intro p hp
  have h : env48116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48115_48116 : H12AffineEnvironment.transform 0 1 env48115 = env48116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env48115 == env48116) = true)

def env48117 : List Nat := [2,4,8,16,32,1,128,256,276,1024,2048,16,8192,1296,9229,65536,74799,65665,273,9228,16,413,74046,65536,9625,74815,303,74814,1296,77082,8204,74799,256,8200,1280,1028]

theorem envBound48117 : H12AffineFastState.Bounded env48117 := by
  intro p hp
  have h : env48117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48094_48117 : H12AffineEnvironment.transform 5 1 env48094 = env48117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env48094 == env48117) = true)

theorem identity48117 : scanCanonicalize (H12AffineFastState.compose env48117 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 9527) := by decide +kernel

theorem selectedBound48117 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env48118 : List Nat := [2,4,8,16,32,1,128,256,276,1024,2048,16,8192,1296,9229,9527,280,9654,273,9228,16,413,1033,9527,9625,264,303,265,1296,2093,8204,280,256,8200,1280,1028]

theorem envBound48118 : H12AffineFastState.Bounded env48118 := by
  intro p hp
  have h : env48118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48117_48118 : H12AffineEnvironment.transform 15 9527 env48117 = env48118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9527 env48117 == env48118) = true)

def env48119 : List Nat := [2,4,8,16,32,1,128,256,276,1024,2048,16,1288,1296,261,63,280,190,273,260,16,413,1033,63,145,264,303,265,1296,2093,1284,280,256,1280,1280,1028]

theorem envBound48119 : H12AffineFastState.Bounded env48119 := by
  intro p hp
  have h : env48119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48118_48119 : H12AffineEnvironment.transform 12 1288 env48118 = env48119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1288 env48118 == env48119) = true)

theorem identity48119 : scanCanonicalize (H12AffineFastState.compose env48119 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound48119 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env48120 : List Nat := [2,4,4,16,32,1,128,256,276,1024,2048,16,1284,1296,261,51,276,178,273,260,16,401,1029,51,145,260,291,261,1296,2081,1284,276,256,1280,1280,1028]

theorem envBound48120 : H12AffineFastState.Bounded env48120 := by
  intro p hp
  have h : env48120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48119_48120 : H12AffineEnvironment.transform 2 4 env48119 = env48120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env48119 == env48120) = true)

theorem identity48120 : scanCanonicalize (H12AffineFastState.compose env48120 (packedSelected [1,2,3,4,9,10,12,16,17] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound48120 : packedSelected [1,2,3,4,9,10,12,16,17] rootPS < 2^1333 := by decide +kernel

def env48121 : List Nat := [2,4,4,16,32,1,128,256,276,5,2048,16,257,277,261,51,276,178,273,260,16,401,0,51,145,260,291,261,277,2081,257,276,256,261,261,1]

theorem envBound48121 : H12AffineFastState.Bounded env48121 := by
  intro p hp
  have h : env48121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48120_48121 : H12AffineEnvironment.transform 9 5 env48120 = env48121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env48120 == env48121) = true)

theorem identity48121 : scanCanonicalize (H12AffineFastState.compose env48121 (packedSelected [0,3,7,8,11,15] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound48121 : packedSelected [0,3,7,8,11,15] rootPS < 2^1333 := by decide +kernel

def env48122 : List Nat := [2,4,4,16,32,1,128,256,276,5,33,16,257,277,261,51,276,178,273,260,16,401,0,51,145,260,291,261,277,0,257,276,256,261,261,1]

theorem envBound48122 : H12AffineFastState.Bounded env48122 := by
  intro p hp
  have h : env48122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48121_48122 : H12AffineEnvironment.transform 10 33 env48121 = env48122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env48121 == env48122) = true)

theorem identity48122 : scanCanonicalize (H12AffineFastState.compose env48122 (packedSelected [3,5] rootPS)) = affineNative (2^(7+1) ^^^ 177) := by decide +kernel

theorem selectedBound48122 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env48123 : List Nat := [2,4,4,16,32,1,128,177,165,5,33,16,176,164,180,51,165,178,160,181,16,32,0,51,145,181,146,180,164,0,176,165,177,180,180,1]

theorem envBound48123 : H12AffineFastState.Bounded env48123 := by
  intro p hp
  have h : env48123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48122_48123 : H12AffineEnvironment.transform 7 177 env48122 = env48123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 177 env48122 == env48123) = true)

theorem identity48123 : scanCanonicalize (H12AffineFastState.compose env48123 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 37) := by decide +kernel

theorem selectedBound48123 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48124 : List Nat := [2,4,4,16,32,1,37,20,0,5,33,16,21,1,17,51,0,23,5,16,16,32,0,51,52,16,55,17,1,0,21,0,20,17,17,1]

theorem envBound48124 : H12AffineFastState.Bounded env48124 := by
  intro p hp
  have h : env48124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48123_48124 : H12AffineEnvironment.transform 6 37 env48123 = env48124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 37 env48123 == env48124) = true)

theorem identity48124 : scanCanonicalize (H12AffineFastState.compose env48124 (packedSelected [0,2] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound48124 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env48125 : List Nat := [2,4,4,5,32,1,37,1,0,5,33,5,0,1,4,38,0,2,5,5,5,32,0,38,33,5,34,4,1,0,0,0,1,4,4,1]

theorem envBound48125 : H12AffineFastState.Bounded env48125 := by
  intro p hp
  have h : env48125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48124_48125 : H12AffineEnvironment.transform 3 5 env48124 = env48125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env48124 == env48125) = true)

theorem identity48125 : scanCanonicalize (H12AffineFastState.compose env48125 (packedSelected [0,4,7] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound48125 : packedSelected [0,4,7] rootPS < 2^1333 := by decide +kernel

def env48126 : List Nat := [1,4,4,5,32,1,37,1,0,5,33,5,0,1,4,37,0,1,5,5,5,32,0,37,33,5,33,4,1,0,0,0,1,4,4,1]

theorem envBound48126 : H12AffineFastState.Bounded env48126 := by
  intro p hp
  have h : env48126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48125_48126 : H12AffineEnvironment.transform 0 1 env48125 = env48126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env48125 == env48126) = true)

theorem identity48126 : scanCanonicalize (H12AffineFastState.compose env48126 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 5) := by decide +kernel

theorem selectedBound48126 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env48127 : List Nat := [1,4,4,5,5,1,0,1,0,5,4,5,0,1,4,0,0,1,5,5,5,5,0,0,4,5,4,4,1,0,0,0,1,4,4,1]

theorem envBound48127 : H12AffineFastState.Bounded env48127 := by
  intro p hp
  have h : env48127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48126_48127 : H12AffineEnvironment.transform 4 5 env48126 = env48127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 5 env48126 == env48127) = true)

theorem identity48127 : scanCanonicalize (H12AffineFastState.compose env48127 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound48127 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48128 : List Nat := [1,0,0,1,1,1,0,1,0,1,0,1,0,1,0,0,0,1,1,1,1,1,0,0,0,1,0,0,1,0,0,0,1,0,0,1]

theorem envBound48128 : H12AffineFastState.Bounded env48128 := by
  intro p hp
  have h : env48128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48127_48128 : H12AffineEnvironment.transform 1 0 env48127 = env48128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env48127 == env48128) = true)

def env48129 : List Nat := [2,4,8,16,32,1,128,256,276,1024,2048,16,1289,1296,260,62,280,191,273,261,16,413,1033,62,144,264,303,265,1296,2093,1285,280,256,1281,1280,1028]

theorem envBound48129 : H12AffineFastState.Bounded env48129 := by
  intro p hp
  have h : env48129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48118_48129 : H12AffineEnvironment.transform 12 1289 env48118 = env48129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1289 env48118 == env48129) = true)

theorem identity48129 : scanCanonicalize (H12AffineFastState.compose env48129 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(9+1) ^^^ 285) := by decide +kernel

theorem selectedBound48129 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env48130 : List Nat := [2,4,8,16,32,1,128,256,276,285,2048,16,20,13,260,62,280,191,273,261,16,413,276,62,144,264,303,265,13,2093,24,280,256,28,29,281]

theorem envBound48130 : H12AffineFastState.Bounded env48130 := by
  intro p hp
  have h : env48130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48129_48130 : H12AffineEnvironment.transform 9 285 env48129 = env48130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 285 env48129 == env48130) = true)

theorem identity48130 : scanCanonicalize (H12AffineFastState.compose env48130 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound48130 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env48131 : List Nat := [2,4,8,16,32,1,128,20,0,9,2048,16,20,13,16,62,12,191,5,17,16,137,0,62,144,28,59,29,13,2093,24,12,20,28,29,13]

theorem envBound48131 : H12AffineFastState.Bounded env48131 := by
  intro p hp
  have h : env48131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48130_48131 : H12AffineEnvironment.transform 7 20 env48130 = env48131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env48130 == env48131) = true)

theorem identity48131 : scanCanonicalize (H12AffineFastState.compose env48131 (packedSelected [0,1,2,7,8,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 132) := by decide +kernel

theorem selectedBound48131 : packedSelected [0,1,2,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env48132 : List Nat := [2,4,8,16,32,1,128,20,0,9,132,16,20,13,16,62,12,191,5,17,16,137,0,62,144,28,59,29,13,169,24,12,20,28,29,13]

theorem envBound48132 : H12AffineFastState.Bounded env48132 := by
  intro p hp
  have h : env48132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48131_48132 : H12AffineEnvironment.transform 10 132 env48131 = env48132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 132 env48131 == env48132) = true)

theorem identity48132 : scanCanonicalize (H12AffineFastState.compose env48132 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound48132 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48133 : List Nat := [2,4,8,16,32,1,4,20,0,9,0,16,20,13,16,62,12,59,5,17,16,13,0,62,20,28,59,29,13,45,24,12,20,28,29,13]

theorem envBound48133 : H12AffineFastState.Bounded env48133 := by
  intro p hp
  have h : env48133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48132_48133 : H12AffineEnvironment.transform 6 4 env48132 = env48133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env48132 == env48133) = true)

theorem identity48133 : scanCanonicalize (H12AffineFastState.compose env48133 (packedSelected [0,2,4] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound48133 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env48134 : List Nat := [2,4,8,16,11,1,4,20,0,9,0,16,20,13,16,21,12,16,5,17,16,13,0,21,20,28,16,29,13,6,24,12,20,28,29,13]

theorem envBound48134 : H12AffineFastState.Bounded env48134 := by
  intro p hp
  have h : env48134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48133_48134 : H12AffineEnvironment.transform 4 11 env48133 = env48134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env48133 == env48134) = true)

theorem identity48134 : scanCanonicalize (H12AffineFastState.compose env48134 (packedSelected [0,3,7] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound48134 : packedSelected [0,3,7] rootPS < 2^1333 := by decide +kernel

def env48135 : List Nat := [2,4,8,1,11,1,4,5,0,9,0,1,5,13,1,4,12,1,5,0,1,13,0,4,5,13,1,12,13,6,9,12,5,13,12,13]

theorem envBound48135 : H12AffineFastState.Bounded env48135 := by
  intro p hp
  have h : env48135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48134_48135 : H12AffineEnvironment.transform 3 1 env48134 = env48135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env48134 == env48135) = true)

theorem identity48135 : scanCanonicalize (H12AffineFastState.compose env48135 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound48135 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48136 : List Nat := [2,4,4,1,7,1,4,5,0,5,0,1,5,1,1,4,0,1,5,0,1,1,0,4,5,1,1,0,1,6,5,0,5,1,0,1]

theorem envBound48136 : H12AffineFastState.Bounded env48136 := by
  intro p hp
  have h : env48136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48135_48136 : H12AffineEnvironment.transform 2 4 env48135 = env48136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env48135 == env48136) = true)

theorem identity48136 : scanCanonicalize (H12AffineFastState.compose env48136 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound48136 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48137 : List Nat := [2,1,1,1,2,1,1,0,0,0,0,1,0,1,1,1,0,1,0,0,1,1,0,1,0,1,1,0,1,3,0,0,0,1,0,1]

theorem envBound48137 : H12AffineFastState.Bounded env48137 := by
  intro p hp
  have h : env48137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48136_48137 : H12AffineEnvironment.transform 1 1 env48136 = env48137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env48136 == env48137) = true)

def env48138 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74862,262144,4417,13340,4096,477,74047,69649,13769,78895,332223,74815,1296,81226,8205,74799,256,8201,1345,5952]

theorem envBound48138 : H12AffineFastState.Bounded env48138 := by
  intro p hp
  have h : env48138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47976_48138 : H12AffineEnvironment.transform 13 1297 env47976 = env48138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env47976 == env48138) = true)

def env48139 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74862,65664,4417,13340,4096,477,74047,69649,13769,78895,4415,74815,1296,81226,8205,74799,256,8201,1345,5952]

theorem envBound48139 : H12AffineFastState.Bounded env48139 := by
  intro p hp
  have h : env48139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48138_48139 : H12AffineEnvironment.transform 17 65664 env48138 = env48139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env48138 == env48139) = true)

theorem identity48139 : scanCanonicalize (H12AffineFastState.compose env48139 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5464) := by decide +kernel

theorem selectedBound48139 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env48140 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5464,1297,325,65536,69942,65664,4417,324,4096,477,70759,69649,145,65911,4415,69991,1296,67602,5461,70007,256,5457,1345,5952]

theorem envBound48140 : H12AffineFastState.Bounded env48140 := by
  intro p hp
  have h : env48140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48139_48140 : H12AffineEnvironment.transform 12 5464 env48139 = env48140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5464 env48139 == env48140) = true)

def env48141 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,4096,5464,1297,325,65536,69942,65664,4417,324,4096,477,70759,69649,145,65911,4415,69991,1296,67602,5461,70007,256,5457,1345,5140]

theorem envBound48141 : H12AffineFastState.Bounded env48141 := by
  intro p hp
  have h : env48141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48140_48141 : H12AffineEnvironment.transform 8 340 env48140 = env48141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env48140 == env48141) = true)

def env48142 : List Nat := [2,4,8,16,32,0,128,256,276,1024,2048,4096,5400,1297,261,65536,69942,65664,4353,260,4096,413,70695,69649,145,65847,4415,69927,1296,67602,5397,69943,256,5393,1281,5140]

theorem envBound48142 : H12AffineFastState.Bounded env48142 := by
  intro p hp
  have h : env48142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48141_48142 : H12AffineEnvironment.transform 5 0 env48141 = env48142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env48141 == env48142) = true)

theorem identity48142 : scanCanonicalize (H12AffineFastState.compose env48142 (packedSelected [1,8,28] rootPS)) = affineNative (2^(11+1) ^^^ 1429) := by decide +kernel

theorem selectedBound48142 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env48143 : List Nat := [2,4,8,16,32,0,128,256,276,1024,2048,1429,141,1297,261,65536,66723,65664,1172,260,1429,413,65970,66948,145,65847,1194,66738,1296,67602,128,66722,256,132,1281,385]

theorem envBound48143 : H12AffineFastState.Bounded env48143 := by
  intro p hp
  have h : env48143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48142_48143 : H12AffineEnvironment.transform 11 1429 env48142 = env48143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1429 env48142 == env48143) = true)

def env48144 : List Nat := [2,4,8,16,32,0,128,256,276,1024,2048,1429,141,1297,261,1056,131,1184,1172,260,1429,413,1426,420,145,1303,1194,146,1296,3122,128,130,256,132,1281,385]

theorem envBound48144 : H12AffineFastState.Bounded env48144 := by
  intro p hp
  have h : env48144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48143_48144 : H12AffineEnvironment.transform 15 1056 env48143 = env48144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1056 env48143 == env48144) = true)

def env48145 : List Nat := [2,4,8,16,32,0,20,256,276,1024,2048,1281,25,1297,261,1056,23,1076,1024,260,1281,265,1286,304,5,1303,1086,6,1296,3122,20,22,256,16,1281,277]

theorem envBound48145 : H12AffineFastState.Bounded env48145 := by
  intro p hp
  have h : env48145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48144_48145 : H12AffineEnvironment.transform 6 20 env48144 = env48145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 20 env48144 == env48145) = true)

theorem identity48145 : scanCanonicalize (H12AffineFastState.compose env48145 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound48145 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env48146 : List Nat := [2,4,8,16,32,0,20,20,0,1024,2048,1045,25,1029,17,1056,23,1076,1024,16,1045,29,1042,36,5,1027,1086,6,1028,3122,20,22,20,16,1045,1]

theorem envBound48146 : H12AffineFastState.Bounded env48146 := by
  intro p hp
  have h : env48146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48145_48146 : H12AffineEnvironment.transform 7 20 env48145 = env48146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env48145 == env48146) = true)

theorem identity48146 : scanCanonicalize (H12AffineFastState.compose env48146 (packedSelected [1,4,5,8,11,13,15] rootPS)) = affineNative (2^(9+1) ^^^ 33) := by decide +kernel

theorem selectedBound48146 : packedSelected [1,4,5,8,11,13,15] rootPS < 2^1333 := by decide +kernel

def env48147 : List Nat := [2,4,8,16,32,0,20,20,0,33,2048,52,25,36,17,1,23,21,33,16,52,29,51,36,5,34,31,6,37,2067,20,22,20,16,52,1]

theorem envBound48147 : H12AffineFastState.Bounded env48147 := by
  intro p hp
  have h : env48147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48146_48147 : H12AffineEnvironment.transform 9 33 env48146 = env48147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 33 env48146 == env48147) = true)

theorem identity48147 : scanCanonicalize (H12AffineFastState.compose env48147 (packedSelected [1,3,4,5,11,17] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound48147 : packedSelected [1,3,4,5,11,17] rootPS < 2^1333 := by decide +kernel

def env48148 : List Nat := [2,4,8,16,17,0,20,20,0,16,2048,5,25,21,17,1,23,21,16,16,5,29,2,21,5,19,31,6,20,2067,20,22,20,16,5,1]

theorem envBound48148 : H12AffineFastState.Bounded env48148 := by
  intro p hp
  have h : env48148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48147_48148 : H12AffineEnvironment.transform 4 17 env48147 = env48148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env48147 == env48148) = true)

theorem identity48148 : scanCanonicalize (H12AffineFastState.compose env48148 (packedSelected [0,4,5,7,8,10] rootPS)) = affineNative (2^(10+1) ^^^ 7) := by decide +kernel

theorem selectedBound48148 : packedSelected [0,4,5,7,8,10] rootPS < 2^1333 := by decide +kernel

def env48149 : List Nat := [2,4,8,16,17,0,20,20,0,16,7,5,25,21,17,1,23,21,16,16,5,29,2,21,5,19,31,6,20,20,20,22,20,16,5,1]

theorem envBound48149 : H12AffineFastState.Bounded env48149 := by
  intro p hp
  have h : env48149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48148_48149 : H12AffineEnvironment.transform 10 7 env48148 = env48149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 7 env48148 == env48149) = true)

theorem identity48149 : scanCanonicalize (H12AffineFastState.compose env48149 (packedSelected [1,3,7] rootPS)) = affineNative (2^(3+1) ^^^ 8) := by decide +kernel

theorem selectedBound48149 : packedSelected [1,3,7] rootPS < 2^1333 := by decide +kernel

def env48150 : List Nat := [2,4,8,8,9,0,12,12,0,8,7,5,1,13,9,1,15,13,8,8,5,5,2,13,5,11,7,6,12,12,12,14,12,8,5,1]

theorem envBound48150 : H12AffineFastState.Bounded env48150 := by
  intro p hp
  have h : env48150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48149_48150 : H12AffineEnvironment.transform 3 8 env48149 = env48150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 8 env48149 == env48150) = true)

theorem identity48150 : scanCanonicalize (H12AffineFastState.compose env48150 (packedSelected [0,3] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound48150 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env48151 : List Nat := [2,4,6,6,7,0,2,2,0,6,7,5,1,3,7,1,1,3,6,6,5,5,2,3,5,5,7,6,2,2,2,0,2,6,5,1]

theorem envBound48151 : H12AffineFastState.Bounded env48151 := by
  intro p hp
  have h : env48151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48150_48151 : H12AffineEnvironment.transform 2 6 env48150 = env48151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env48150 == env48151) = true)

theorem identity48151 : scanCanonicalize (H12AffineFastState.compose env48151 (packedSelected [0,1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound48151 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env48152 : List Nat := [2,3,1,1,0,0,2,2,0,1,0,2,1,3,0,1,1,3,1,1,2,2,2,3,2,2,0,1,2,2,2,0,2,1,2,1]

theorem envBound48152 : H12AffineFastState.Bounded env48152 := by
  intro p hp
  have h : env48152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48151_48152 : H12AffineEnvironment.transform 1 3 env48151 = env48152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env48151 == env48152) = true)

theorem identity48152 : scanCanonicalize (H12AffineFastState.compose env48152 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound48152 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48153 : List Nat := [0,1,1,1,0,0,0,0,0,1,0,0,1,1,0,1,1,1,1,1,0,0,0,1,0,0,0,1,0,0,0,0,0,1,0,1]

theorem envBound48153 : H12AffineFastState.Bounded env48153 := by
  intro p hp
  have h : env48153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48152_48153 : H12AffineEnvironment.transform 0 0 env48152 = env48153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env48152 == env48153) = true)

def env48154 : List Nat := [2,4,8,16,32,0,21,256,276,1024,2048,1280,24,1297,261,1056,22,1077,1025,260,1280,264,1287,305,4,1303,1087,7,1296,3122,21,23,256,17,1281,276]

theorem envBound48154 : H12AffineFastState.Bounded env48154 := by
  intro p hp
  have h : env48154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48144_48154 : H12AffineEnvironment.transform 6 21 env48144 = env48154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 21 env48144 == env48154) = true)

theorem identity48154 : scanCanonicalize (H12AffineFastState.compose env48154 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 19) := by decide +kernel

theorem selectedBound48154 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env48155 : List Nat := [2,4,8,16,32,0,21,256,276,19,2048,275,24,258,261,51,22,38,18,260,275,264,276,305,4,260,44,7,259,2081,21,23,256,17,274,276]

theorem envBound48155 : H12AffineFastState.Bounded env48155 := by
  intro p hp
  have h : env48155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48154_48155 : H12AffineEnvironment.transform 9 19 env48154 = env48155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 19 env48154 == env48155) = true)

theorem identity48155 : scanCanonicalize (H12AffineFastState.compose env48155 (packedSelected [3,8,13,15,17] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound48155 : packedSelected [3,8,13,15,17] rootPS < 2^1333 := by decide +kernel

def env48156 : List Nat := [2,4,8,16,27,0,21,256,276,19,2048,275,24,258,261,8,22,29,18,260,275,264,276,266,4,260,23,7,259,2074,21,23,256,17,274,276]

theorem envBound48156 : H12AffineFastState.Bounded env48156 := by
  intro p hp
  have h : env48156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48155_48156 : H12AffineEnvironment.transform 4 27 env48155 = env48156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env48155 == env48156) = true)

theorem identity48156 : scanCanonicalize (H12AffineFastState.compose env48156 (packedSelected [1,4,5,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound48156 : packedSelected [1,4,5,9,11] rootPS < 2^1333 := by decide +kernel

def env48157 : List Nat := [2,4,8,16,27,0,21,256,276,19,10,275,24,258,261,8,22,29,18,260,275,264,276,266,4,260,23,7,259,16,21,23,256,17,274,276]

theorem envBound48157 : H12AffineFastState.Bounded env48157 := by
  intro p hp
  have h : env48157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48156_48157 : H12AffineEnvironment.transform 10 10 env48156 = env48157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env48156 == env48157) = true)

theorem identity48157 : scanCanonicalize (H12AffineFastState.compose env48157 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(7+1) ^^^ 18) := by decide +kernel

theorem selectedBound48157 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env48158 : List Nat := [2,4,8,16,27,0,21,18,6,19,10,1,24,16,23,8,22,29,18,22,1,26,6,24,4,22,23,7,17,16,21,23,18,17,0,6]

theorem envBound48158 : H12AffineFastState.Bounded env48158 := by
  intro p hp
  have h : env48158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48157_48158 : H12AffineEnvironment.transform 7 18 env48157 = env48158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 18 env48157 == env48158) = true)

theorem identity48158 : scanCanonicalize (H12AffineFastState.compose env48158 (packedSelected [0,3] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound48158 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env48159 : List Nat := [2,4,8,7,12,0,2,5,6,4,10,1,15,7,0,8,1,10,5,1,1,13,6,15,4,1,0,7,6,7,2,0,5,6,0,6]

theorem envBound48159 : H12AffineFastState.Bounded env48159 := by
  intro p hp
  have h : env48159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48158_48159 : H12AffineEnvironment.transform 3 7 env48158 = env48159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env48158 == env48159) = true)

theorem identity48159 : scanCanonicalize (H12AffineFastState.compose env48159 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound48159 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48160 : List Nat := [2,3,8,0,11,0,2,2,1,3,10,1,8,0,0,8,1,10,2,1,1,10,1,8,3,1,0,0,1,0,2,0,2,1,0,1]

theorem envBound48160 : H12AffineFastState.Bounded env48160 := by
  intro p hp
  have h : env48160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48159_48160 : H12AffineEnvironment.transform 1 3 env48159 = env48160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env48159 == env48160) = true)

def env48161 : List Nat := [2,4,8,16,32,0,128,256,276,1024,2048,1429,141,1297,261,1057,130,1185,1172,260,1429,413,1427,421,145,1302,1194,147,1296,3123,128,131,256,132,1281,385]

theorem envBound48161 : H12AffineFastState.Bounded env48161 := by
  intro p hp
  have h : env48161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48143_48161 : H12AffineEnvironment.transform 15 1057 env48143 = env48161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1057 env48143 == env48161) = true)

def env48162 : List Nat := [2,4,8,16,32,0,20,256,276,1024,2048,1281,25,1297,261,1057,22,1077,1024,260,1281,265,1287,305,5,1302,1086,7,1296,3123,20,23,256,16,1281,277]

theorem envBound48162 : H12AffineFastState.Bounded env48162 := by
  intro p hp
  have h : env48162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48161_48162 : H12AffineEnvironment.transform 6 20 env48161 = env48162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 20 env48161 == env48162) = true)

theorem identity48162 : scanCanonicalize (H12AffineFastState.compose env48162 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound48162 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env48163 : List Nat := [2,4,8,16,32,0,20,20,0,1024,2048,1045,25,1029,17,1057,22,1077,1024,16,1045,29,1043,37,5,1026,1086,7,1028,3123,20,23,20,16,1045,1]

theorem envBound48163 : H12AffineFastState.Bounded env48163 := by
  intro p hp
  have h : env48163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48162_48163 : H12AffineEnvironment.transform 7 20 env48162 = env48163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env48162 == env48163) = true)

theorem identity48163 : scanCanonicalize (H12AffineFastState.compose env48163 (packedSelected [1,4,5,8,11,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 1083) := by decide +kernel

theorem selectedBound48163 : packedSelected [1,4,5,8,11,13,15] rootPS < 2^1333 := by decide +kernel

def env48164 : List Nat := [2,4,8,16,32,0,20,20,0,1024,1083,1045,25,1029,17,1057,22,1077,1024,16,1045,29,1043,37,5,1026,1086,7,1028,8,20,23,20,16,1045,1]

theorem envBound48164 : H12AffineFastState.Bounded env48164 := by
  intro p hp
  have h : env48164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48163_48164 : H12AffineEnvironment.transform 10 1083 env48163 = env48164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1083 env48163 == env48164) = true)

theorem identity48164 : scanCanonicalize (H12AffineFastState.compose env48164 (packedSelected [1,3,4,5,11,17] rootPS)) = affineNative (2^(4+1) ^^^ 23) := by decide +kernel

theorem selectedBound48164 : packedSelected [1,3,4,5,11,17] rootPS < 2^1333 := by decide +kernel

def env48165 : List Nat := [2,4,8,16,23,0,20,20,0,1024,1036,1045,25,1029,17,1046,22,1026,1024,16,1045,29,1043,18,5,1026,1033,7,1028,8,20,23,20,16,1045,1]

theorem envBound48165 : H12AffineFastState.Bounded env48165 := by
  intro p hp
  have h : env48165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48164_48165 : H12AffineEnvironment.transform 4 23 env48164 = env48165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 23 env48164 == env48165) = true)

theorem identity48165 : scanCanonicalize (H12AffineFastState.compose env48165 (packedSelected [0,1,3,4,7,8,10,11] rootPS)) = affineNative (2^(9+1) ^^^ 14) := by decide +kernel

theorem selectedBound48165 : packedSelected [0,1,3,4,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env48166 : List Nat := [2,4,8,16,23,0,20,20,0,14,2,27,25,11,17,24,22,12,14,16,27,29,29,18,5,12,7,7,10,8,20,23,20,16,27,1]

theorem envBound48166 : H12AffineFastState.Bounded env48166 := by
  intro p hp
  have h : env48166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48165_48166 : H12AffineEnvironment.transform 9 14 env48165 = env48166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 14 env48165 == env48166) = true)

theorem identity48166 : scanCanonicalize (H12AffineFastState.compose env48166 (packedSelected [0,3,4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound48166 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env48167 : List Nat := [2,4,8,0,7,0,4,4,0,14,2,11,9,11,1,8,6,12,14,0,11,13,13,2,5,12,7,7,10,8,4,7,4,0,11,1]

theorem envBound48167 : H12AffineFastState.Bounded env48167 := by
  intro p hp
  have h : env48167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48166_48167 : H12AffineEnvironment.transform 3 0 env48166 = env48167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env48166 == env48167) = true)

def env48168 : List Nat := [2,4,8,16,32,0,21,256,276,1024,2048,1280,24,1297,261,1057,23,1076,1025,260,1280,264,1286,304,4,1302,1087,6,1296,3123,21,22,256,17,1281,276]

theorem envBound48168 : H12AffineFastState.Bounded env48168 := by
  intro p hp
  have h : env48168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48161_48168 : H12AffineEnvironment.transform 6 21 env48161 = env48168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 21 env48161 == env48168) = true)

theorem identity48168 : scanCanonicalize (H12AffineFastState.compose env48168 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 18) := by decide +kernel

theorem selectedBound48168 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env48169 : List Nat := [2,4,8,16,32,0,21,256,276,18,2048,274,24,259,261,51,23,38,19,260,274,264,276,304,4,260,45,6,258,2081,21,22,256,17,275,276]

theorem envBound48169 : H12AffineFastState.Bounded env48169 := by
  intro p hp
  have h : env48169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48168_48169 : H12AffineEnvironment.transform 9 18 env48168 = env48169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 18 env48168 == env48169) = true)

theorem identity48169 : scanCanonicalize (H12AffineFastState.compose env48169 (packedSelected [3,8,13,15,17] rootPS)) = affineNative (2^(4+1) ^^^ 28) := by decide +kernel

theorem selectedBound48169 : packedSelected [3,8,13,15,17] rootPS < 2^1333 := by decide +kernel

def env48170 : List Nat := [2,4,8,16,28,0,21,256,276,18,2048,274,24,259,261,15,23,26,19,260,274,264,276,268,4,260,17,6,258,2077,21,22,256,17,275,276]

theorem envBound48170 : H12AffineFastState.Bounded env48170 := by
  intro p hp
  have h : env48170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48169_48170 : H12AffineEnvironment.transform 4 28 env48169 = env48170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 28 env48169 == env48170) = true)

theorem identity48170 : scanCanonicalize (H12AffineFastState.compose env48170 (packedSelected [1,2,3,9] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound48170 : packedSelected [1,2,3,9] rootPS < 2^1333 := by decide +kernel

def env48171 : List Nat := [2,4,5,16,17,0,21,256,276,18,2048,274,21,259,261,2,23,23,19,260,274,261,276,257,4,260,17,6,258,2064,21,22,256,17,275,276]

theorem envBound48171 : H12AffineFastState.Bounded env48171 := by
  intro p hp
  have h : env48171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48170_48171 : H12AffineEnvironment.transform 2 5 env48170 = env48171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env48170 == env48171) = true)

theorem identity48171 : scanCanonicalize (H12AffineFastState.compose env48171 (packedSelected [0,1,2,3,7] rootPS)) = affineNative (2^(7+1) ^^^ 19) := by decide +kernel

theorem selectedBound48171 : packedSelected [0,1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env48172 : List Nat := [2,4,5,16,17,0,21,19,7,18,2048,1,21,16,22,2,23,23,19,23,1,22,7,18,4,23,17,6,17,2064,21,22,19,17,0,7]

theorem envBound48172 : H12AffineFastState.Bounded env48172 := by
  intro p hp
  have h : env48172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48171_48172 : H12AffineEnvironment.transform 7 19 env48171 = env48172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 19 env48171 == env48172) = true)

theorem identity48172 : scanCanonicalize (H12AffineFastState.compose env48172 (packedSelected [0,1,3] rootPS)) = affineNative (2^(10+1) ^^^ 6) := by decide +kernel

theorem selectedBound48172 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env48173 : List Nat := [2,4,5,16,17,0,21,19,7,18,6,1,21,16,22,2,23,23,19,23,1,22,7,18,4,23,17,6,17,22,21,22,19,17,0,7]

theorem envBound48173 : H12AffineFastState.Bounded env48173 := by
  intro p hp
  have h : env48173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48172_48173 : H12AffineEnvironment.transform 10 6 env48172 = env48173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 6 env48172 == env48173) = true)

theorem identity48173 : scanCanonicalize (H12AffineFastState.compose env48173 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound48173 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48174 : List Nat := [2,4,5,6,7,0,3,5,7,4,6,1,3,6,0,2,1,1,5,1,1,0,7,4,4,1,7,6,7,0,3,0,5,7,0,7]

theorem envBound48174 : H12AffineFastState.Bounded env48174 := by
  intro p hp
  have h : env48174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48173_48174 : H12AffineEnvironment.transform 3 6 env48173 = env48174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env48173 == env48174) = true)

def env48175 : List Nat := [2,4,8,16,32,1,128,256,277,1024,2048,4096,5401,1297,260,65536,69942,65664,4352,261,4096,412,70694,69649,145,65846,4415,69926,1296,67602,5396,69942,256,5392,1280,5140]

theorem envBound48175 : H12AffineFastState.Bounded env48175 := by
  intro p hp
  have h : env48175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48141_48175 : H12AffineEnvironment.transform 5 1 env48141 = env48175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env48141 == env48175) = true)

theorem identity48175 : scanCanonicalize (H12AffineFastState.compose env48175 (packedSelected [1,8,28] rootPS)) = affineNative (2^(9+1) ^^^ 389) := by decide +kernel

theorem selectedBound48175 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env48176 : List Nat := [2,4,8,16,32,1,128,256,277,389,2048,4096,4252,148,260,65536,69942,65664,4352,261,4096,412,70051,69649,145,65846,4415,69926,149,67602,4241,69942,256,4245,133,4497]

theorem envBound48176 : H12AffineFastState.Bounded env48176 := by
  intro p hp
  have h : env48176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48175_48176 : H12AffineEnvironment.transform 9 389 env48175 = env48176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 389 env48175 == env48176) = true)

def env48177 : List Nat := [2,4,8,16,32,1,128,256,277,389,2048,4096,4252,148,260,4532,130,4404,4352,261,4096,412,23,421,145,4226,4415,146,149,6566,4241,130,256,4245,133,4497]

theorem envBound48177 : H12AffineFastState.Bounded env48177 := by
  intro p hp
  have h : env48177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48176_48177 : H12AffineEnvironment.transform 15 4532 env48176 = env48177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4532 env48176 == env48177) = true)

def env48178 : List Nat := [2,4,8,16,32,1,128,256,277,389,2048,432,300,148,260,4,130,132,176,261,432,412,23,421,145,306,143,146,149,2070,289,130,256,293,133,33]

theorem envBound48178 : H12AffineFastState.Bounded env48178 := by
  intro p hp
  have h : env48178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48177_48178 : H12AffineEnvironment.transform 11 432 env48177 = env48178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 432 env48177 == env48178) = true)

theorem identity48178 : scanCanonicalize (H12AffineFastState.compose env48178 (packedSelected [3,5,8,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 259) := by decide +kernel

theorem selectedBound48178 : packedSelected [3,5,8,13,15] rootPS < 2^1333 := by decide +kernel

def env48179 : List Nat := [2,4,8,16,32,1,128,256,277,389,259,432,300,148,260,4,130,132,176,261,432,412,23,421,145,306,143,146,149,277,289,130,256,293,133,33]

theorem envBound48179 : H12AffineFastState.Bounded env48179 := by
  intro p hp
  have h : env48179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48178_48179 : H12AffineEnvironment.transform 10 259 env48178 = env48179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 259 env48178 == env48179) = true)

theorem identity48179 : scanCanonicalize (H12AffineFastState.compose env48179 (packedSelected [2,3,4,7,8,11,16,18] rootPS)) = affineNative (2^(7+1) ^^^ 160) := by decide +kernel

theorem selectedBound48179 : packedSelected [2,3,4,7,8,11,16,18] rootPS < 2^1333 := by decide +kernel

def env48180 : List Nat := [2,4,8,16,32,1,128,160,181,37,163,16,140,148,164,4,130,132,176,165,16,60,23,5,145,146,143,146,149,181,129,130,160,133,133,33]

theorem envBound48180 : H12AffineFastState.Bounded env48180 := by
  intro p hp
  have h : env48180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48179_48180 : H12AffineEnvironment.transform 7 160 env48179 = env48180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 160 env48179 == env48180) = true)

theorem identity48180 : scanCanonicalize (H12AffineFastState.compose env48180 (packedSelected [1,2,4,5,8,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound48180 : packedSelected [1,2,4,5,8,9,10] rootPS < 2^1333 := by decide +kernel

def env48181 : List Nat := [2,4,8,16,32,1,5,37,48,37,38,16,9,17,33,4,7,1,53,32,16,60,23,5,20,23,10,23,16,48,4,7,37,0,0,33]

theorem envBound48181 : H12AffineFastState.Bounded env48181 := by
  intro p hp
  have h : env48181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48180_48181 : H12AffineEnvironment.transform 6 5 env48180 = env48181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env48180 == env48181) = true)

theorem identity48181 : scanCanonicalize (H12AffineFastState.compose env48181 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound48181 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env48182 : List Nat := [2,4,8,16,26,1,5,31,10,31,28,16,9,17,27,4,7,1,15,26,16,6,23,5,20,23,10,23,16,10,4,7,31,0,0,27]

theorem envBound48182 : H12AffineFastState.Bounded env48182 := by
  intro p hp
  have h : env48182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48181_48182 : H12AffineEnvironment.transform 4 26 env48181 = env48182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env48181 == env48182) = true)

theorem identity48182 : scanCanonicalize (H12AffineFastState.compose env48182 (packedSelected [1,2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound48182 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env48183 : List Nat := [2,4,8,10,0,1,5,5,10,5,6,10,9,11,1,4,7,1,15,0,10,6,13,5,14,13,10,13,10,10,4,7,5,0,0,1]

theorem envBound48183 : H12AffineFastState.Bounded env48183 := by
  intro p hp
  have h : env48183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48182_48183 : H12AffineEnvironment.transform 3 10 env48182 = env48183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env48182 == env48183) = true)

theorem identity48183 : scanCanonicalize (H12AffineFastState.compose env48183 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound48183 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env48184 : List Nat := [2,4,5,7,0,1,5,5,7,5,6,7,4,6,1,4,7,1,2,0,7,6,0,5,3,0,7,0,7,7,4,7,5,0,0,1]

theorem envBound48184 : H12AffineFastState.Bounded env48184 := by
  intro p hp
  have h : env48184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48183_48184 : H12AffineEnvironment.transform 2 5 env48183 = env48184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env48183 == env48184) = true)

def env48185 : List Nat := [2,4,8,16,32,1,128,256,277,389,2048,433,301,148,260,5,130,133,177,261,433,412,23,421,145,307,142,146,149,2071,288,130,256,292,133,32]

theorem envBound48185 : H12AffineFastState.Bounded env48185 := by
  intro p hp
  have h : env48185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48177_48185 : H12AffineEnvironment.transform 11 433 env48177 = env48185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 433 env48177 == env48185) = true)

theorem identity48185 : scanCanonicalize (H12AffineFastState.compose env48185 (packedSelected [3,5,8,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 260) := by decide +kernel

theorem selectedBound48185 : packedSelected [3,5,8,13,15] rootPS < 2^1333 := by decide +kernel

def env48186 : List Nat := [2,4,8,16,32,1,128,256,277,389,260,433,301,148,260,5,130,133,177,261,433,412,23,421,145,307,142,146,149,275,288,130,256,292,133,32]

theorem envBound48186 : H12AffineFastState.Bounded env48186 := by
  intro p hp
  have h : env48186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48185_48186 : H12AffineEnvironment.transform 10 260 env48185 = env48186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env48185 == env48186) = true)

theorem identity48186 : scanCanonicalize (H12AffineFastState.compose env48186 (packedSelected [0,2,3,4,5,11,13,16,17] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound48186 : packedSelected [0,2,3,4,5,11,13,16,17] rootPS < 2^1333 := by decide +kernel

def env48187 : List Nat := [2,4,8,16,32,1,3,256,277,262,260,306,301,23,260,5,1,6,50,261,306,287,23,294,18,307,13,17,22,275,288,1,256,292,6,32]

theorem envBound48187 : H12AffineFastState.Bounded env48187 := by
  intro p hp
  have h : env48187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48186_48187 : H12AffineEnvironment.transform 6 3 env48186 = env48187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env48186 == env48187) = true)

theorem identity48187 : scanCanonicalize (H12AffineFastState.compose env48187 (packedSelected [1,2,3,7,8,9,11] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound48187 : packedSelected [1,2,3,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env48188 : List Nat := [2,4,8,16,32,1,3,36,49,34,32,22,9,23,32,5,1,6,50,33,22,59,23,2,18,23,13,17,22,55,4,1,36,0,6,32]

theorem envBound48188 : H12AffineFastState.Bounded env48188 := by
  intro p hp
  have h : env48188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48187_48188 : H12AffineEnvironment.transform 7 36 env48187 = env48188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env48187 == env48188) = true)

theorem identity48188 : scanCanonicalize (H12AffineFastState.compose env48188 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound48188 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env48189 : List Nat := [2,4,4,16,32,1,3,36,49,34,32,22,5,23,32,5,1,6,50,33,22,55,23,2,18,23,1,17,22,55,4,1,36,0,6,32]

theorem envBound48189 : H12AffineFastState.Bounded env48189 := by
  intro p hp
  have h : env48189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48188_48189 : H12AffineEnvironment.transform 2 4 env48188 = env48189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env48188 == env48189) = true)

theorem identity48189 : scanCanonicalize (H12AffineFastState.compose env48189 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(4+1) ^^^ 23) := by decide +kernel

theorem selectedBound48189 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env48190 : List Nat := [2,4,4,16,23,1,3,19,6,21,23,22,5,23,23,5,1,6,5,22,22,0,23,2,18,23,1,17,22,0,4,1,19,0,6,23]

theorem envBound48190 : H12AffineFastState.Bounded env48190 := by
  intro p hp
  have h : env48190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48189_48190 : H12AffineEnvironment.transform 4 23 env48189 = env48190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 23 env48189 == env48190) = true)

theorem identity48190 : scanCanonicalize (H12AffineFastState.compose env48190 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound48190 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48191 : List Nat := [2,4,4,6,1,1,3,5,6,3,1,0,5,1,1,5,1,6,5,0,0,0,1,2,4,1,1,7,0,0,4,1,5,0,6,1]

theorem envBound48191 : H12AffineFastState.Bounded env48191 := by
  intro p hp
  have h : env48191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48190_48191 : H12AffineEnvironment.transform 3 6 env48190 = env48191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env48190 == env48191) = true)

theorem identity48191 : scanCanonicalize (H12AffineFastState.compose env48191 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound48191 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48192 : List Nat := [2,2,2,0,1,1,3,3,0,3,1,0,3,1,1,3,1,0,3,0,0,0,1,2,2,1,1,1,0,0,2,1,3,0,0,1]

theorem envBound48192 : H12AffineFastState.Bounded env48192 := by
  intro p hp
  have h : env48192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48191_48192 : H12AffineEnvironment.transform 1 2 env48191 = env48192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env48191 == env48192) = true)

theorem identity48192 : scanCanonicalize (H12AffineFastState.compose env48192 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound48192 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48193 : List Nat := [0,0,0,0,1,1,1,1,0,1,1,0,1,1,1,1,1,0,1,0,0,0,1,0,0,1,1,1,0,0,0,1,1,0,0,1]

theorem envBound48193 : H12AffineFastState.Bounded env48193 := by
  intro p hp
  have h : env48193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48192_48193 : H12AffineEnvironment.transform 0 0 env48192 = env48193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env48192 == env48193) = true)

def env48194 : List Nat := [2,4,8,16,32,1,128,256,277,389,2048,4096,4252,148,260,4533,131,4405,4352,261,4096,412,22,420,145,4227,4415,147,149,6567,4241,131,256,4245,133,4497]

theorem envBound48194 : H12AffineFastState.Bounded env48194 := by
  intro p hp
  have h : env48194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48176_48194 : H12AffineEnvironment.transform 15 4533 env48176 = env48194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4533 env48176 == env48194) = true)

def env48195 : List Nat := [2,4,8,16,32,1,128,256,277,389,2048,432,300,148,260,5,131,133,176,261,432,412,22,420,145,307,143,147,149,2071,289,131,256,293,133,33]

theorem envBound48195 : H12AffineFastState.Bounded env48195 := by
  intro p hp
  have h : env48195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48194_48195 : H12AffineEnvironment.transform 11 432 env48194 = env48195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 432 env48194 == env48195) = true)

theorem identity48195 : scanCanonicalize (H12AffineFastState.compose env48195 (packedSelected [3,5,8,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 164) := by decide +kernel

theorem selectedBound48195 : packedSelected [3,5,8,13,15] rootPS < 2^1333 := by decide +kernel

def env48196 : List Nat := [2,4,8,16,32,1,128,256,277,389,164,432,300,148,260,5,131,133,176,261,432,412,22,420,145,307,143,147,149,179,289,131,256,293,133,33]

theorem envBound48196 : H12AffineFastState.Bounded env48196 := by
  intro p hp
  have h : env48196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48195_48196 : H12AffineEnvironment.transform 10 164 env48195 = env48196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 164 env48195 == env48196) = true)

theorem identity48196 : scanCanonicalize (H12AffineFastState.compose env48196 (packedSelected [0,1,2,3,7,10,11] rootPS)) = affineNative (2^(6+1) ^^^ 21) := by decide +kernel

theorem selectedBound48196 : packedSelected [0,1,2,3,7,10,11] rootPS < 2^1333 := by decide +kernel

def env48197 : List Nat := [2,4,8,16,32,1,21,256,277,272,49,293,300,1,260,5,22,16,37,261,293,265,22,305,4,307,26,6,0,38,289,22,256,293,16,33]

theorem envBound48197 : H12AffineFastState.Bounded env48197 := by
  intro p hp
  have h : env48197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48196_48197 : H12AffineEnvironment.transform 6 21 env48196 = env48197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 21 env48196 == env48197) = true)

theorem identity48197 : scanCanonicalize (H12AffineFastState.compose env48197 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound48197 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env48198 : List Nat := [2,4,8,11,32,1,14,256,270,267,42,293,300,1,260,5,13,11,37,261,293,265,13,298,4,296,1,6,0,38,289,13,256,293,11,33]

theorem envBound48198 : H12AffineFastState.Bounded env48198 := by
  intro p hp
  have h : env48198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48197_48198 : H12AffineEnvironment.transform 3 11 env48197 = env48198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env48197 == env48198) = true)

theorem identity48198 : scanCanonicalize (H12AffineFastState.compose env48198 (packedSelected [1,4,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 47) := by decide +kernel

theorem selectedBound48198 : packedSelected [1,4,7,8] rootPS < 2^1333 := by decide +kernel

def env48199 : List Nat := [2,4,8,11,32,1,14,47,33,36,42,10,3,1,43,5,13,11,37,42,10,38,13,5,4,7,1,6,0,38,14,13,47,10,11,33]

theorem envBound48199 : H12AffineFastState.Bounded env48199 := by
  intro p hp
  have h : env48199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48198_48199 : H12AffineEnvironment.transform 7 47 env48198 = env48199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 47 env48198 == env48199) = true)

theorem identity48199 : scanCanonicalize (H12AffineFastState.compose env48199 (packedSelected [0,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound48199 : packedSelected [0,2,3] rootPS < 2^1333 := by decide +kernel

def env48200 : List Nat := [2,4,8,11,12,1,14,3,13,8,6,10,3,1,7,5,13,11,9,6,10,10,13,5,4,7,1,6,0,10,14,13,3,10,11,13]

theorem envBound48200 : H12AffineFastState.Bounded env48200 := by
  intro p hp
  have h : env48200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48199_48200 : H12AffineEnvironment.transform 4 12 env48199 = env48200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env48199 == env48200) = true)

theorem identity48200 : scanCanonicalize (H12AffineFastState.compose env48200 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound48200 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env48201 : List Nat := [2,4,4,7,0,1,2,3,1,4,6,6,3,1,7,5,1,7,5,6,6,6,1,5,4,7,1,6,0,6,2,1,3,6,7,1]

theorem envBound48201 : H12AffineFastState.Bounded env48201 := by
  intro p hp
  have h : env48201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48200_48201 : H12AffineEnvironment.transform 2 4 env48200 = env48201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env48200 == env48201) = true)

def env48202 : List Nat := [2,4,8,16,32,1,128,256,277,389,2048,433,301,148,260,4,131,132,177,261,433,412,22,420,145,306,142,147,149,2070,288,131,256,292,133,32]

theorem envBound48202 : H12AffineFastState.Bounded env48202 := by
  intro p hp
  have h : env48202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48194_48202 : H12AffineEnvironment.transform 11 433 env48194 = env48202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 433 env48194 == env48202) = true)

theorem identity48202 : scanCanonicalize (H12AffineFastState.compose env48202 (packedSelected [3,5,8,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 163) := by decide +kernel

theorem selectedBound48202 : packedSelected [3,5,8,13,15] rootPS < 2^1333 := by decide +kernel

def env48203 : List Nat := [2,4,8,16,32,1,128,256,277,389,163,433,301,148,260,4,131,132,177,261,433,412,22,420,145,306,142,147,149,181,288,131,256,292,133,32]

theorem envBound48203 : H12AffineFastState.Bounded env48203 := by
  intro p hp
  have h : env48203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48202_48203 : H12AffineEnvironment.transform 10 163 env48202 = env48203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 163 env48202 == env48203) = true)

theorem identity48203 : scanCanonicalize (H12AffineFastState.compose env48203 (packedSelected [1,5,7,9,10,11,13,16] rootPS)) = affineNative (2^(7+1) ^^^ 151) := by decide +kernel

theorem selectedBound48203 : packedSelected [1,5,7,9,10,11,13,16] rootPS < 2^1333 := by decide +kernel

def env48204 : List Nat := [2,4,8,16,32,1,128,151,130,18,163,38,186,148,147,4,131,132,177,146,38,11,22,51,145,165,142,147,149,181,183,131,151,179,133,32]

theorem envBound48204 : H12AffineFastState.Bounded env48204 := by
  intro p hp
  have h : env48204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48203_48204 : H12AffineEnvironment.transform 7 151 env48203 = env48204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 151 env48203 == env48204) = true)

theorem identity48204 : scanCanonicalize (H12AffineFastState.compose env48204 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound48204 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env48205 : List Nat := [2,3,8,16,32,1,128,144,130,18,163,33,186,147,147,3,131,131,177,146,33,11,17,51,145,162,137,147,146,178,176,131,144,179,130,32]

theorem envBound48205 : H12AffineFastState.Bounded env48205 := by
  intro p hp
  have h : env48205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48204_48205 : H12AffineEnvironment.transform 1 3 env48204 = env48205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env48204 == env48205) = true)

theorem identity48205 : scanCanonicalize (H12AffineFastState.compose env48205 (packedSelected [2,3,5,8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound48205 : packedSelected [2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env48206 : List Nat := [2,3,8,1,32,1,128,129,130,3,163,33,171,130,130,3,131,131,160,131,33,11,0,34,128,162,137,130,131,163,161,131,129,162,130,32]

theorem envBound48206 : H12AffineFastState.Bounded env48206 := by
  intro p hp
  have h : env48206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48205_48206 : H12AffineEnvironment.transform 3 1 env48205 = env48206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env48205 == env48206) = true)

theorem identity48206 : scanCanonicalize (H12AffineFastState.compose env48206 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound48206 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48207 : List Nat := [2,3,8,1,11,1,128,129,130,3,136,10,128,130,130,3,131,131,139,131,10,11,0,9,128,137,137,130,131,136,138,131,129,137,130,11]

theorem envBound48207 : H12AffineFastState.Bounded env48207 := by
  intro p hp
  have h : env48207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48206_48207 : H12AffineEnvironment.transform 4 11 env48206 = env48207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env48206 == env48207) = true)

theorem identity48207 : scanCanonicalize (H12AffineFastState.compose env48207 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound48207 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env48208 : List Nat := [2,3,8,1,11,1,2,3,0,3,10,10,2,0,0,3,1,1,9,1,10,11,0,9,2,11,11,0,1,10,8,1,3,11,0,11]

theorem envBound48208 : H12AffineFastState.Bounded env48208 := by
  intro p hp
  have h : env48208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48207_48208 : H12AffineEnvironment.transform 6 2 env48207 = env48208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env48207 == env48208) = true)

theorem identity48208 : scanCanonicalize (H12AffineFastState.compose env48208 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound48208 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48209 : List Nat := [2,3,2,1,1,1,2,3,0,3,0,0,2,0,0,3,1,1,3,1,0,1,0,3,2,1,1,0,1,0,2,1,3,1,0,1]

theorem envBound48209 : H12AffineFastState.Bounded env48209 := by
  intro p hp
  have h : env48209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48208_48209 : H12AffineEnvironment.transform 2 2 env48208 = env48209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env48208 == env48209) = true)

theorem identity48209 : scanCanonicalize (H12AffineFastState.compose env48209 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound48209 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48210 : List Nat := [0,1,0,1,1,1,0,1,0,1,0,0,0,0,0,1,1,1,1,1,0,1,0,1,0,1,1,0,1,0,0,1,1,1,0,1]

theorem envBound48210 : H12AffineFastState.Bounded env48210 := by
  intro p hp
  have h : env48210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48209_48210 : H12AffineEnvironment.transform 0 0 env48209 = env48210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env48209 == env48210) = true)

def env48211 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,4096,5464,1297,325,65536,69942,65664,4417,324,4096,477,70759,69649,145,65911,4415,69991,1296,67602,5461,70007,256,5457,1345,5141]

theorem envBound48211 : H12AffineFastState.Bounded env48211 := by
  intro p hp
  have h : env48211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48140_48211 : H12AffineEnvironment.transform 8 341 env48140 = env48211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env48140 == env48211) = true)

def env48212 : List Nat := [2,4,8,16,32,0,128,256,277,1024,2048,4096,5400,1297,261,65536,69942,65664,4353,260,4096,413,70695,69649,145,65847,4415,69927,1296,67602,5397,69943,256,5393,1281,5141]

theorem envBound48212 : H12AffineFastState.Bounded env48212 := by
  intro p hp
  have h : env48212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48211_48212 : H12AffineEnvironment.transform 5 0 env48211 = env48212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env48211 == env48212) = true)

theorem identity48212 : scanCanonicalize (H12AffineFastState.compose env48212 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 419) := by decide +kernel

theorem selectedBound48212 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env48213 : List Nat := [2,4,8,16,32,0,128,256,277,1024,2048,4096,5400,1297,261,419,4245,291,4353,260,4096,413,5508,4530,145,148,4415,4228,1296,2481,5397,4244,256,5393,1281,5141]

theorem envBound48213 : H12AffineFastState.Bounded env48213 := by
  intro p hp
  have h : env48213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48212_48213 : H12AffineEnvironment.transform 15 419 env48212 = env48213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 419 env48212 == env48213) = true)

def env48214 : List Nat := [2,4,8,16,32,0,128,256,277,1024,2048,1428,140,1297,261,419,1281,291,1173,260,1428,413,16,1062,145,148,1195,1296,1296,2481,129,1280,256,133,1281,385]

theorem envBound48214 : H12AffineFastState.Bounded env48214 := by
  intro p hp
  have h : env48214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48213_48214 : H12AffineEnvironment.transform 11 1428 env48213 = env48214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1428 env48213 == env48214) = true)

theorem identity48214 : scanCanonicalize (H12AffineFastState.compose env48214 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 257) := by decide +kernel

theorem selectedBound48214 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env48215 : List Nat := [2,4,8,16,32,0,128,256,277,257,2048,149,140,16,261,419,0,291,404,260,149,413,16,295,145,148,426,17,17,2481,129,1,256,133,0,385]

theorem envBound48215 : H12AffineFastState.Bounded env48215 := by
  intro p hp
  have h : env48215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48214_48215 : H12AffineEnvironment.transform 9 257 env48214 = env48215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 257 env48214 == env48215) = true)

theorem identity48215 : scanCanonicalize (H12AffineFastState.compose env48215 (packedSelected [1,2,3,4,5,8,9,11,12,16,18] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound48215 : packedSelected [1,2,3,4,5,8,9,11,12,16,18] rootPS < 2^1333 := by decide +kernel

def env48216 : List Nat := [2,4,8,16,32,0,128,14,27,15,2048,149,140,16,11,173,0,45,154,10,149,147,16,41,145,148,164,17,17,2239,129,1,14,133,0,143]

theorem envBound48216 : H12AffineFastState.Bounded env48216 := by
  intro p hp
  have h : env48216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48215_48216 : H12AffineEnvironment.transform 7 14 env48215 = env48216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env48215 == env48216) = true)

theorem identity48216 : scanCanonicalize (H12AffineFastState.compose env48216 (packedSelected [1,4,8,9,12,13,15,16,17] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound48216 : packedSelected [1,4,8,9,12,13,15,16,17] rootPS < 2^1333 := by decide +kernel

def env48217 : List Nat := [2,4,8,16,32,0,128,14,27,15,17,149,140,16,11,173,0,45,154,10,149,147,16,41,145,148,164,17,17,174,129,1,14,133,0,143]

theorem envBound48217 : H12AffineFastState.Bounded env48217 := by
  intro p hp
  have h : env48217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48216_48217 : H12AffineEnvironment.transform 10 17 env48216 = env48217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env48216 == env48217) = true)

theorem identity48217 : scanCanonicalize (H12AffineFastState.compose env48217 (packedSelected [10,13] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound48217 : packedSelected [10,13] rootPS < 2^1333 := by decide +kernel

def env48218 : List Nat := [2,3,8,16,32,0,128,9,27,8,17,146,139,16,11,170,0,42,154,10,146,147,16,41,145,147,163,17,17,169,129,1,9,130,0,136]

theorem envBound48218 : H12AffineFastState.Bounded env48218 := by
  intro p hp
  have h : env48218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48217_48218 : H12AffineEnvironment.transform 1 3 env48217 = env48218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env48217 == env48218) = true)

theorem identity48218 : scanCanonicalize (H12AffineFastState.compose env48218 (packedSelected [0,2,3,7] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound48218 : packedSelected [0,2,3,7] rootPS < 2^1333 := by decide +kernel

def env48219 : List Nat := [2,3,8,16,32,0,34,9,27,8,17,48,41,16,11,8,0,42,56,10,48,49,16,41,51,49,1,17,17,11,35,1,9,32,0,42]

theorem envBound48219 : H12AffineFastState.Bounded env48219 := by
  intro p hp
  have h : env48219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48218_48219 : H12AffineEnvironment.transform 6 34 env48218 = env48219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env48218 == env48219) = true)

theorem identity48219 : scanCanonicalize (H12AffineFastState.compose env48219 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound48219 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48220 : List Nat := [2,3,3,16,32,0,34,2,16,3,17,48,34,16,0,3,0,33,51,1,48,49,16,34,51,49,1,17,17,0,35,1,2,32,0,33]

theorem envBound48220 : H12AffineFastState.Bounded env48220 := by
  intro p hp
  have h : env48220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48219_48220 : H12AffineEnvironment.transform 2 3 env48219 = env48220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env48219 == env48220) = true)

theorem identity48220 : scanCanonicalize (H12AffineFastState.compose env48220 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound48220 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48221 : List Nat := [2,3,3,16,1,0,3,2,16,3,17,17,3,16,0,3,0,0,18,1,17,16,16,3,18,16,1,17,17,0,2,1,2,1,0,0]

theorem envBound48221 : H12AffineFastState.Bounded env48221 := by
  intro p hp
  have h : env48221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48220_48221 : H12AffineEnvironment.transform 4 1 env48220 = env48221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env48220 == env48221) = true)

def env48222 : List Nat := [2,4,8,16,32,0,128,256,277,1024,2048,1429,141,1297,261,419,1280,291,1172,260,1429,413,17,1063,145,148,1194,1297,1296,2481,128,1281,256,132,1281,384]

theorem envBound48222 : H12AffineFastState.Bounded env48222 := by
  intro p hp
  have h : env48222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48213_48222 : H12AffineEnvironment.transform 11 1429 env48213 = env48222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1429 env48213 == env48222) = true)

theorem identity48222 : scanCanonicalize (H12AffineFastState.compose env48222 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 129) := by decide +kernel

theorem selectedBound48222 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env48223 : List Nat := [2,4,8,16,32,0,128,129,148,1024,2048,1044,141,1168,132,34,1153,162,1172,133,1044,28,17,1063,145,148,1194,1168,1169,2096,128,1152,129,132,1152,1]

theorem envBound48223 : H12AffineFastState.Bounded env48223 := by
  intro p hp
  have h : env48223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48222_48223 : H12AffineEnvironment.transform 7 129 env48222 = env48223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 129 env48222 == env48223) = true)

theorem identity48223 : scanCanonicalize (H12AffineFastState.compose env48223 (packedSelected [0,5,7,17,20] rootPS)) = affineNative (2^(10+1) ^^^ 1175) := by decide +kernel

theorem selectedBound48223 : packedSelected [0,5,7,17,20] rootPS < 2^1333 := by decide +kernel

def env48224 : List Nat := [2,4,8,16,32,0,128,129,148,1024,1175,1044,141,1168,132,34,1153,162,1172,133,1044,28,17,1063,145,148,1194,1168,1169,1191,128,1152,129,132,1152,1]

theorem envBound48224 : H12AffineFastState.Bounded env48224 := by
  intro p hp
  have h : env48224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48223_48224 : H12AffineEnvironment.transform 10 1175 env48223 = env48224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1175 env48223 == env48224) = true)

theorem identity48224 : scanCanonicalize (H12AffineFastState.compose env48224 (packedSelected [0,1,2,4,5,7,8,9,11,12,13,15,16] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound48224 : packedSelected [0,1,2,4,5,7,8,9,11,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env48225 : List Nat := [2,4,8,16,32,0,128,129,148,53,162,33,141,165,132,34,180,162,161,133,33,28,17,18,145,148,159,165,164,146,128,181,129,132,181,1]

theorem envBound48225 : H12AffineFastState.Bounded env48225 := by
  intro p hp
  have h : env48225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48224_48225 : H12AffineEnvironment.transform 9 53 env48224 = env48225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env48224 == env48225) = true)

theorem identity48225 : scanCanonicalize (H12AffineFastState.compose env48225 (packedSelected [1,3,5,7,9,10,12] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound48225 : packedSelected [1,3,5,7,9,10,12] rootPS < 2^1333 := by decide +kernel

def env48226 : List Nat := [2,4,8,16,16,0,128,129,148,5,146,17,141,149,132,18,132,146,145,133,17,28,17,18,145,148,159,149,148,146,128,133,129,132,133,1]

theorem envBound48226 : H12AffineFastState.Bounded env48226 := by
  intro p hp
  have h : env48226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48225_48226 : H12AffineEnvironment.transform 4 16 env48225 = env48226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env48225 == env48226) = true)

theorem identity48226 : scanCanonicalize (H12AffineFastState.compose env48226 (packedSelected [0,2,4,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound48226 : packedSelected [0,2,4,5,8] rootPS < 2^1333 := by decide +kernel

def env48227 : List Nat := [2,4,8,16,16,0,19,18,7,5,1,17,30,6,23,18,23,1,2,22,17,28,17,18,2,7,12,6,7,1,19,22,18,23,22,1]

theorem envBound48227 : H12AffineFastState.Bounded env48227 := by
  intro p hp
  have h : env48227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48226_48227 : H12AffineEnvironment.transform 6 19 env48226 = env48227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env48226 == env48227) = true)

def env48228 : List Nat := [2,4,8,16,32,1,128,256,276,1024,2048,4096,5401,1297,260,65536,69942,65664,4352,261,4096,412,70694,69649,145,65846,4415,69926,1296,67602,5396,69942,256,5392,1280,5141]

theorem envBound48228 : H12AffineFastState.Bounded env48228 := by
  intro p hp
  have h : env48228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48211_48228 : H12AffineEnvironment.transform 5 1 env48211 = env48228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env48211 == env48228) = true)

theorem identity48228 : scanCanonicalize (H12AffineFastState.compose env48228 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 4530) := by decide +kernel

theorem selectedBound48228 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env48229 : List Nat := [2,4,8,16,32,1,128,256,276,1024,2048,4096,5401,1297,260,4530,132,4402,4352,261,4096,412,1428,419,145,4228,4415,148,1296,6560,5396,132,256,5392,1280,5141]

theorem envBound48229 : H12AffineFastState.Bounded env48229 := by
  intro p hp
  have h : env48229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48228_48229 : H12AffineEnvironment.transform 15 4530 env48228 = env48229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4530 env48228 == env48229) = true)

def env48230 : List Nat := [2,4,8,16,32,1,128,256,276,1024,2048,1428,141,1297,260,1062,132,1190,1172,261,1428,412,1428,419,145,1296,1195,148,1296,3124,128,132,256,132,1280,385]

theorem envBound48230 : H12AffineFastState.Bounded env48230 := by
  intro p hp
  have h : env48230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48229_48230 : H12AffineEnvironment.transform 11 1428 env48229 = env48230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1428 env48229 == env48230) = true)

theorem identity48230 : scanCanonicalize (H12AffineFastState.compose env48230 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 256) := by decide +kernel

theorem selectedBound48230 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env48231 : List Nat := [2,4,8,16,32,1,128,256,276,256,2048,148,141,17,260,294,132,422,404,261,148,412,148,419,145,16,427,148,16,2356,128,132,256,132,0,385]

theorem envBound48231 : H12AffineFastState.Bounded env48231 := by
  intro p hp
  have h : env48231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48230_48231 : H12AffineEnvironment.transform 9 256 env48230 = env48231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env48230 == env48231) = true)

theorem identity48231 : scanCanonicalize (H12AffineFastState.compose env48231 (packedSelected [1,3,10,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 179) := by decide +kernel

theorem selectedBound48231 : packedSelected [1,3,10,12,15] rootPS < 2^1333 := by decide +kernel

def env48232 : List Nat := [2,4,8,16,32,1,128,256,276,256,179,148,141,17,260,294,132,422,404,261,148,412,148,419,145,16,427,148,16,391,128,132,256,132,0,385]

theorem envBound48232 : H12AffineFastState.Bounded env48232 := by
  intro p hp
  have h : env48232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48231_48232 : H12AffineEnvironment.transform 10 179 env48231 = env48232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 179 env48231 == env48232) = true)

theorem identity48232 : scanCanonicalize (H12AffineFastState.compose env48232 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound48232 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env48233 : List Nat := [2,4,8,16,32,1,128,20,0,20,179,148,141,17,16,50,132,178,128,17,148,136,148,183,145,16,191,148,16,147,128,132,20,132,0,149]

theorem envBound48233 : H12AffineFastState.Bounded env48233 := by
  intro p hp
  have h : env48233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48232_48233 : H12AffineEnvironment.transform 7 20 env48232 = env48233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env48232 == env48233) = true)

theorem identity48233 : scanCanonicalize (H12AffineFastState.compose env48233 (packedSelected [0,3,5,7,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound48233 : packedSelected [0,3,5,7,11,12] rootPS < 2^1333 := by decide +kernel

def env48234 : List Nat := [2,4,8,16,32,1,5,20,0,20,54,17,8,17,16,50,1,55,5,17,17,13,17,50,20,16,58,17,16,22,5,1,20,1,0,16]

theorem envBound48234 : H12AffineFastState.Bounded env48234 := by
  intro p hp
  have h : env48234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48233_48234 : H12AffineEnvironment.transform 6 5 env48233 = env48234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env48233 == env48234) = true)

theorem identity48234 : scanCanonicalize (H12AffineFastState.compose env48234 (packedSelected [1,2,5] rootPS)) = affineNative (2^(4+1) ^^^ 23) := by decide +kernel

theorem selectedBound48234 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env48235 : List Nat := [2,4,8,16,23,1,5,20,0,20,1,17,8,17,16,5,1,0,5,17,17,13,17,5,20,16,13,17,16,22,5,1,20,1,0,16]

theorem envBound48235 : H12AffineFastState.Bounded env48235 := by
  intro p hp
  have h : env48235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48234_48235 : H12AffineEnvironment.transform 4 23 env48234 = env48235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 23 env48234 == env48235) = true)

def env48236 : List Nat := [2,4,8,16,32,1,128,256,276,1024,2048,1429,140,1297,260,1063,132,1191,1173,261,1429,412,1428,419,145,1297,1194,148,1296,3125,129,132,256,133,1280,384]

theorem envBound48236 : H12AffineFastState.Bounded env48236 := by
  intro p hp
  have h : env48236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48229_48236 : H12AffineEnvironment.transform 11 1429 env48229 = env48236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1429 env48229 == env48236) = true)

theorem identity48236 : scanCanonicalize (H12AffineFastState.compose env48236 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 128) := by decide +kernel

theorem selectedBound48236 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env48237 : List Nat := [2,4,8,16,32,1,128,128,148,1024,2048,1045,140,1169,132,1063,132,1191,1173,133,1045,28,1044,35,145,1169,1194,148,1168,3125,129,132,128,133,1152,0]

end H12CloudChart2