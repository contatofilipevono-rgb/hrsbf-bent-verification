import H12CloudChart2Data087

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def leafEnv21591 : List Nat := [2,4,8,1,1,0,8,5,1,4,0,0,8,0,0,3,1,1,4,1,0,0,0,3,5,8,1,0,1,0,1,0,4,0,5,0,5,2,0,1,0,0,1]

def active21591 : List Nat := [0,1,2]

def tree21591 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21591 : H12WitnessSearch.Good tree21591 := H12GlobalWitnessIndex.good

theorem leafIdentity21591 : H12AffineFastState.composeSystem env21591 rootObs = leafEnv21591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21591 rootObs == leafEnv21591) = true)

theorem terminalChecked21591 : H12PackedTerminal.terminalCheckFast leafEnv21591 active21591 tree21591 = true := by decide +kernel

def env21592 : List Nat := [2,4,8,16,32,17,8,53,1,37,1,0,9,0,32,51,1,0,37,33,0,48,17,35,9,17,0,0,1,1,21,16,53,33,0,1]

theorem envBound21592 : H12AffineFastState.Bounded env21592 := by
  intro p hp
  have h : env21592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21587_21592 : H12AffineEnvironment.transform 10 1 env21587 = env21592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env21587 == env21592) = true)

theorem identity21592 : scanCanonicalize (H12AffineFastState.compose env21592 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound21592 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21593 : List Nat := [2,4,8,16,1,17,8,20,1,4,1,0,9,0,1,18,1,0,4,0,0,17,17,2,9,17,0,0,1,1,21,16,20,0,0,1]

theorem envBound21593 : H12AffineFastState.Bounded env21593 := by
  intro p hp
  have h : env21593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21592_21593 : H12AffineEnvironment.transform 4 1 env21592 = env21593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env21592 == env21593) = true)

def env21594 : List Nat := [2,4,8,16,32,17,9,256,0,272,2048,0,2056,0,2081,263,1,2049,272,2080,0,261,17,2083,2057,17,2049,0,1,2048,21,2341,256,32,0,0]

theorem envBound21594 : H12AffineFastState.Bounded env21594 := by
  intro p hp
  have h : env21594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21585_21594 : H12AffineEnvironment.transform 6 9 env21585 = env21594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21585 == env21594) = true)

theorem identity21594 : scanCanonicalize (H12AffineFastState.compose env21594 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound21594 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21595 : List Nat := [2,4,8,1,32,0,9,256,0,257,2048,0,2056,0,2081,263,1,2049,257,2080,0,261,0,2083,2057,0,2049,0,1,2048,4,2341,256,32,0,0]

theorem envBound21595 : H12AffineFastState.Bounded env21595 := by
  intro p hp
  have h : env21595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21594_21595 : H12AffineEnvironment.transform 3 1 env21594 = env21595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env21594 == env21595) = true)

def env21596 : List Nat := [2,4,8,1,32,0,9,256,0,257,0,0,8,0,33,263,1,1,257,32,0,261,0,35,9,0,1,0,1,0,4,293,256,32,0,0]

theorem envBound21596 : H12AffineFastState.Bounded env21596 := by
  intro p hp
  have h : env21596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21595_21596 : H12AffineEnvironment.transform 10 0 env21595 = env21596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env21595 == env21596) = true)

def env21597 : List Nat := [2,4,8,1,0,0,9,256,0,257,0,0,8,0,1,263,1,1,257,0,0,261,0,3,9,0,1,0,1,0,4,261,256,0,0,0]

theorem envBound21597 : H12AffineFastState.Bounded env21597 := by
  intro p hp
  have h : env21597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21596_21597 : H12AffineEnvironment.transform 4 0 env21596 = env21597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env21596 == env21597) = true)

def env21598 : List Nat := [2,4,8,1,1,0,9,256,0,257,0,0,8,0,0,263,1,1,257,1,0,261,0,2,9,0,1,0,1,0,4,260,256,1,0,0]

theorem envBound21598 : H12AffineFastState.Bounded env21598 := by
  intro p hp
  have h : env21598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21596_21598 : H12AffineEnvironment.transform 4 1 env21596 = env21598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env21596 == env21598) = true)

theorem identity21598 : scanCanonicalize (H12AffineFastState.compose env21598 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound21598 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env21599 : List Nat := [2,4,8,1,1,0,9,5,0,4,0,0,8,0,0,2,1,1,4,1,0,0,0,2,9,0,1,0,1,0,4,1,5,1,0,0]

theorem envBound21599 : H12AffineFastState.Bounded env21599 := by
  intro p hp
  have h : env21599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21598_21599 : H12AffineEnvironment.transform 7 5 env21598 = env21599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env21598 == env21599) = true)

def leafEnv21599 : List Nat := [2,4,8,1,1,0,9,5,0,4,0,0,8,0,0,2,1,1,4,1,0,0,0,2,5,9,1,0,1,0,1,0,4,1,5,1,5,2,0,0,0,0,1]

def active21599 : List Nat := [0,1,2]

def tree21599 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21599 : H12WitnessSearch.Good tree21599 := H12GlobalWitnessIndex.good

theorem leafIdentity21599 : H12AffineFastState.composeSystem env21599 rootObs = leafEnv21599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21599 rootObs == leafEnv21599) = true)

theorem terminalChecked21599 : H12PackedTerminal.terminalCheckFast leafEnv21599 active21599 tree21599 = true := by decide +kernel

def env21600 : List Nat := [2,4,8,1,32,0,9,256,0,257,1,0,9,0,32,263,1,0,257,33,0,261,0,34,8,0,0,0,1,1,4,292,256,32,0,0]

theorem envBound21600 : H12AffineFastState.Bounded env21600 := by
  intro p hp
  have h : env21600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21595_21600 : H12AffineEnvironment.transform 10 1 env21595 = env21600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env21595 == env21600) = true)

theorem identity21600 : scanCanonicalize (H12AffineFastState.compose env21600 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound21600 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21601 : List Nat := [2,4,8,1,1,0,9,256,0,257,1,0,9,0,1,263,1,0,257,0,0,261,0,3,8,0,0,0,1,1,4,261,256,1,0,0]

theorem envBound21601 : H12AffineFastState.Bounded env21601 := by
  intro p hp
  have h : env21601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21600_21601 : H12AffineEnvironment.transform 4 1 env21600 = env21601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env21600 == env21601) = true)

def env21602 : List Nat := [2,4,8,16,32,17,128,256,137,273,2048,1,2056,1,2081,65536,0,2049,273,2080,1,261,17,67876,2176,17,2049,1,0,2048,20,67618,256,169,1,137]

theorem envBound21602 : H12AffineFastState.Bounded env21602 := by
  intro p hp
  have h : env21602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21583_21602 : H12AffineEnvironment.transform 9 273 env21583 = env21602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env21583 == env21602) = true)

theorem identity21602 : scanCanonicalize (H12AffineFastState.compose env21602 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound21602 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21603 : List Nat := [2,4,8,16,32,17,128,256,137,273,33,1,41,1,0,65536,0,32,273,1,1,261,17,65797,161,17,32,1,0,33,20,65539,256,169,1,137]

theorem envBound21603 : H12AffineFastState.Bounded env21603 := by
  intro p hp
  have h : env21603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21602_21603 : H12AffineEnvironment.transform 10 33 env21602 = env21603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env21602 == env21603) = true)

def env21604 : List Nat := [2,4,8,16,32,17,8,256,1,273,33,1,41,1,0,65536,0,32,273,1,1,261,17,65797,41,17,32,1,0,33,20,65539,256,33,1,1]

theorem envBound21604 : H12AffineFastState.Bounded env21604 := by
  intro p hp
  have h : env21604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21603_21604 : H12AffineEnvironment.transform 6 8 env21603 = env21604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21603 == env21604) = true)

theorem identity21604 : scanCanonicalize (H12AffineFastState.compose env21604 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 50) := by decide +kernel

theorem selectedBound21604 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21605 : List Nat := [2,4,8,16,32,17,8,256,1,273,33,1,41,1,0,50,0,32,273,1,1,261,17,311,41,17,32,1,0,33,20,49,256,33,1,1]

theorem envBound21605 : H12AffineFastState.Bounded env21605 := by
  intro p hp
  have h : env21605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21604_21605 : H12AffineEnvironment.transform 15 50 env21604 = env21605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 50 env21604 == env21605) = true)

def env21606 : List Nat := [2,4,8,16,0,17,8,256,1,273,1,1,9,1,0,18,0,0,273,1,1,261,17,279,9,17,0,1,0,1,20,17,256,1,1,1]

theorem envBound21606 : H12AffineFastState.Bounded env21606 := by
  intro p hp
  have h : env21606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21605_21606 : H12AffineEnvironment.transform 4 0 env21605 = env21606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env21605 == env21606) = true)

def env21607 : List Nat := [2,4,8,0,0,1,8,256,1,257,1,1,9,1,0,2,0,0,257,1,1,261,1,263,9,1,0,1,0,1,4,1,256,1,1,1]

theorem envBound21607 : H12AffineFastState.Bounded env21607 := by
  intro p hp
  have h : env21607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21606_21607 : H12AffineEnvironment.transform 3 0 env21606 = env21607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env21606 == env21607) = true)

def env21608 : List Nat := [2,4,8,1,0,0,8,256,1,256,1,1,9,1,0,3,0,0,256,1,1,261,0,262,9,0,0,1,0,1,5,0,256,1,1,1]

theorem envBound21608 : H12AffineFastState.Bounded env21608 := by
  intro p hp
  have h : env21608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21606_21608 : H12AffineEnvironment.transform 3 1 env21606 = env21608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env21606 == env21608) = true)

theorem identity21608 : scanCanonicalize (H12AffineFastState.compose env21608 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound21608 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env21609 : List Nat := [2,4,8,1,0,0,8,5,1,5,1,1,9,1,0,3,0,0,5,1,1,0,0,3,9,0,0,1,0,1,5,0,5,1,1,1]

theorem envBound21609 : H12AffineFastState.Bounded env21609 := by
  intro p hp
  have h : env21609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21608_21609 : H12AffineEnvironment.transform 7 5 env21608 = env21609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env21608 == env21609) = true)

def leafEnv21609 : List Nat := [2,4,8,1,0,0,8,5,1,5,1,1,9,1,0,3,0,0,5,1,1,0,0,3,4,9,1,0,0,1,0,1,5,0,5,1,5,2,1,1,0,1,1]

def active21609 : List Nat := [0,1,2]

def tree21609 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21609 : H12WitnessSearch.Good tree21609 := H12GlobalWitnessIndex.good

theorem leafIdentity21609 : H12AffineFastState.composeSystem env21609 rootObs = leafEnv21609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21609 rootObs == leafEnv21609) = true)

theorem terminalChecked21609 : H12PackedTerminal.terminalCheckFast leafEnv21609 active21609 tree21609 = true := by decide +kernel

def env21610 : List Nat := [2,4,8,16,1,17,8,256,1,273,0,1,8,1,0,19,0,1,273,1,1,261,17,278,8,17,1,1,0,0,20,16,256,0,1,1]

theorem envBound21610 : H12AffineFastState.Bounded env21610 := by
  intro p hp
  have h : env21610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21605_21610 : H12AffineEnvironment.transform 4 1 env21605 = env21610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env21605 == env21610) = true)

theorem identity21610 : scanCanonicalize (H12AffineFastState.compose env21610 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound21610 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21611 : List Nat := [2,4,8,16,1,17,8,20,1,5,0,1,8,1,0,19,0,1,5,1,1,17,17,2,8,17,1,1,0,0,20,16,20,0,1,1]

theorem envBound21611 : H12AffineFastState.Bounded env21611 := by
  intro p hp
  have h : env21611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21610_21611 : H12AffineEnvironment.transform 7 20 env21610 = env21611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env21610 == env21611) = true)

def env21612 : List Nat := [2,4,8,16,32,17,9,256,0,273,33,1,41,1,0,65536,0,32,273,1,1,261,17,65797,40,17,32,1,0,33,20,65539,256,32,1,0]

theorem envBound21612 : H12AffineFastState.Bounded env21612 := by
  intro p hp
  have h : env21612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21603_21612 : H12AffineEnvironment.transform 6 9 env21603 = env21612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21603 == env21612) = true)

theorem identity21612 : scanCanonicalize (H12AffineFastState.compose env21612 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 279) := by decide +kernel

theorem selectedBound21612 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21613 : List Nat := [2,4,8,16,32,17,9,256,0,273,33,1,41,1,0,279,0,32,273,1,1,261,17,18,40,17,32,1,0,33,20,276,256,32,1,0]

theorem envBound21613 : H12AffineFastState.Bounded env21613 := by
  intro p hp
  have h : env21613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21612_21613 : H12AffineEnvironment.transform 15 279 env21612 = env21613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 279 env21612 == env21613) = true)

def env21614 : List Nat := [2,4,8,16,0,17,9,256,0,273,1,1,9,1,0,279,0,0,273,1,1,261,17,18,8,17,0,1,0,1,20,276,256,0,1,0]

theorem envBound21614 : H12AffineFastState.Bounded env21614 := by
  intro p hp
  have h : env21614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21613_21614 : H12AffineEnvironment.transform 4 0 env21613 = env21614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env21613 == env21614) = true)

def env21615 : List Nat := [2,4,8,0,0,1,9,256,0,257,1,1,9,1,0,263,0,0,257,1,1,261,1,2,8,1,0,1,0,1,4,260,256,0,1,0]

theorem envBound21615 : H12AffineFastState.Bounded env21615 := by
  intro p hp
  have h : env21615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21614_21615 : H12AffineEnvironment.transform 3 0 env21614 = env21615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env21614 == env21615) = true)

theorem identity21615 : scanCanonicalize (H12AffineFastState.compose env21615 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound21615 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env21616 : List Nat := [2,4,8,0,0,1,9,5,0,4,1,1,9,1,0,2,0,0,4,1,1,0,1,2,8,1,0,1,0,1,4,1,5,0,1,0]

theorem envBound21616 : H12AffineFastState.Bounded env21616 := by
  intro p hp
  have h : env21616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21615_21616 : H12AffineEnvironment.transform 7 5 env21615 = env21616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env21615 == env21616) = true)

def leafEnv21616 : List Nat := [2,4,8,0,0,1,9,5,0,4,1,1,9,1,0,2,0,0,4,1,1,0,1,2,5,8,1,1,0,1,0,1,4,1,5,0,5,2,1,0,0,1,1]

def active21616 : List Nat := [0,1,2]

def tree21616 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21616 : H12WitnessSearch.Good tree21616 := H12GlobalWitnessIndex.good

theorem leafIdentity21616 : H12AffineFastState.composeSystem env21616 rootObs = leafEnv21616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21616 rootObs == leafEnv21616) = true)

theorem terminalChecked21616 : H12PackedTerminal.terminalCheckFast leafEnv21616 active21616 tree21616 = true := by decide +kernel

def env21617 : List Nat := [2,4,8,1,0,0,9,256,0,256,1,1,9,1,0,262,0,0,256,1,1,261,0,3,8,0,0,1,0,1,5,261,256,0,1,0]

theorem envBound21617 : H12AffineFastState.Bounded env21617 := by
  intro p hp
  have h : env21617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21614_21617 : H12AffineEnvironment.transform 3 1 env21614 = env21617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env21614 == env21617) = true)

def env21618 : List Nat := [2,4,8,16,1,17,9,256,0,273,0,1,8,1,0,279,0,1,273,1,1,261,17,18,9,17,1,1,0,0,20,276,256,1,1,0]

theorem envBound21618 : H12AffineFastState.Bounded env21618 := by
  intro p hp
  have h : env21618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21613_21618 : H12AffineEnvironment.transform 4 1 env21613 = env21618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env21613 == env21618) = true)

theorem identity21618 : scanCanonicalize (H12AffineFastState.compose env21618 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound21618 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21619 : List Nat := [2,4,8,1,1,0,9,256,0,256,0,1,8,1,0,262,0,1,256,1,1,261,0,3,9,0,1,1,0,0,5,261,256,1,1,0]

theorem envBound21619 : H12AffineFastState.Bounded env21619 := by
  intro p hp
  have h : env21619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21618_21619 : H12AffineEnvironment.transform 3 1 env21618 = env21619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env21618 == env21619) = true)

def env21620 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,21584,32769,4096,4194304,17664,16777216,8328,5377,134217728,16384,1297,1073741824,16876544,4294967296,256,4315938986,155571473,512]

theorem envBound21620 : H12AffineFastState.Bounded env21620 := by
  intro p hp
  have h : env21620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21361_21620 : H12AffineEnvironment.transform 16 1345 env21361 = env21620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env21361 == env21620) = true)

def env21621 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,4194304,8388608,16777216,8328,8914001,134217728,8519745,676865,1073741824,25412672,4294967296,8536384,4315938986,164610304,512]

theorem envBound21621 : H12AffineFastState.Bounded env21621 := by
  intro p hp
  have h : env21621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21102_21621 : H12AffineEnvironment.transform 20 4097 env21102 = env21621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env21102 == env21621) = true)

theorem identity21621 : scanCanonicalize (H12AffineFastState.compose env21621 (packedSelected [14] rootPS)) = affineNative (2^(26+1) ^^^ 21484816) := by decide +kernel

theorem selectedBound21621 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env21622 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,4194304,8388608,16777216,8328,8914001,21484816,8519745,676865,1073741824,25412672,4294967296,8536384,4315938986,8918032,512]

theorem envBound21622 : H12AffineFastState.Bounded env21622 := by
  intro p hp
  have h : env21622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21621_21622 : H12AffineEnvironment.transform 26 21484816 env21621 = env21622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 21484816 env21621 == env21622) = true)

def env21623 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,4194304,147520,16777216,8328,672785,21484816,16385,676865,1073741824,16876544,4294967296,256,4315938986,676944,512]

theorem envBound21623 : H12AffineFastState.Bounded env21623 := by
  intro p hp
  have h : env21623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21622_21623 : H12AffineEnvironment.transform 22 147520 env21622 = env21623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147520 env21622 == env21623) = true)

def env21624 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,524288,32769,4097,4194304,17664,16777216,8328,541009,21352528,16385,545089,1073741824,16876544,4294967296,256,4315938986,545040,512]

theorem envBound21624 : H12AffineFastState.Bounded env21624 := by
  intro p hp
  have h : env21624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21623_21624 : H12AffineEnvironment.transform 16 1344 env21623 = env21624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env21623 == env21624) = true)

theorem identity21624 : scanCanonicalize (H12AffineFastState.compose env21624 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(18+1) ^^^ 21584) := by decide +kernel

theorem selectedBound21624 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env21625 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,21584,32769,4097,4194304,17664,16777216,8328,5377,21352528,16385,1297,1073741824,16876544,4294967296,256,4315938986,1344,512]

theorem envBound21625 : H12AffineFastState.Bounded env21625 := by
  intro p hp
  have h : env21625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21624_21625 : H12AffineEnvironment.transform 18 21584 env21624 = env21625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21584 env21624 == env21625) = true)

theorem identity21625 : scanCanonicalize (H12AffineFastState.compose env21625 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 4176) := by decide +kernel

theorem selectedBound21625 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env21626 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,1344,262144,1024,32769,4097,4194304,5456,16777216,8328,5377,21331968,4177,1297,1073741824,16876544,4294967296,256,4315938986,1344,512]

theorem envBound21626 : H12AffineFastState.Bounded env21626 := by
  intro p hp
  have h : env21626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21625_21626 : H12AffineEnvironment.transform 13 4176 env21625 = env21626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env21625 == env21626) = true)

def env21627 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,65536,1344,262144,1024,32769,1345,4194304,16,16777216,8328,65,21331968,1297,1297,1073741824,16876544,4294967296,256,4315938986,1344,512]

theorem envBound21627 : H12AffineFastState.Bounded env21627 := by
  intro p hp
  have h : env21627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21626_21627 : H12AffineEnvironment.transform 11 1344 env21626 = env21627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env21626 == env21627) = true)

theorem identity21627 : scanCanonicalize (H12AffineFastState.compose env21627 (packedSelected [13,21] rootPS)) = affineNative (2^(31+1) ^^^ 4194440) := by decide +kernel

theorem selectedBound21627 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env21628 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,65536,1344,262144,1024,32769,1345,4194304,16,16777216,8328,65,21331968,1297,1297,1073741824,16876544,4194440,256,16777250,1344,512]

theorem envBound21628 : H12AffineFastState.Bounded env21628 := by
  intro p hp
  have h : env21628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21627_21628 : H12AffineEnvironment.transform 31 4194440 env21627 = env21628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 4194440 env21627 == env21628) = true)

def env21629 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,128,1296,32768,65536,1344,262144,1024,32769,1345,4194304,16,16777216,8,65,21331968,1297,1297,1073741824,16876544,4194440,256,16777250,1344,512]

theorem envBound21629 : H12AffineFastState.Bounded env21629 := by
  intro p hp
  have h : env21629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21628_21629 : H12AffineEnvironment.transform 12 128 env21628 = env21629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 128 env21628 == env21629) = true)

theorem identity21629 : scanCanonicalize (H12AffineFastState.compose env21629 (packedSelected [3,5,24] rootPS)) = affineNative (2^(17+1) ^^^ 137) := by decide +kernel

theorem selectedBound21629 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env21630 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,128,1296,32768,65536,1344,137,1024,32769,1345,4194304,16,16777216,8,65,21069961,1297,1297,1073741824,16876544,4194440,256,16777250,1344,512]

theorem envBound21630 : H12AffineFastState.Bounded env21630 := by
  intro p hp
  have h : env21630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21629_21630 : H12AffineEnvironment.transform 17 137 env21629 = env21630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137 env21629 == env21630) = true)

def env21631 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,128,1296,32768,65536,1344,137,1024,32769,1345,4194304,16,65536,8,65,4227209,1297,1297,1073741824,33792,4194440,256,65570,1344,512]

theorem envBound21631 : H12AffineFastState.Bounded env21631 := by
  intro p hp
  have h : env21631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21630_21631 : H12AffineEnvironment.transform 23 65536 env21630 = env21631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 65536 env21630 == env21631) = true)

theorem identity21631 : scanCanonicalize (H12AffineFastState.compose env21631 (packedSelected [1,8,28] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound21631 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env21632 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1344,128,1296,32768,65536,1344,137,1024,32769,1345,4194304,16,65536,8,65,4227209,1297,1297,1073741824,33792,4194440,256,65570,1344,137]

theorem envBound21632 : H12AffineFastState.Bounded env21632 := by
  intro p hp
  have h : env21632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21631_21632 : H12AffineEnvironment.transform 8 137 env21631 = env21632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env21631 == env21632) = true)

def env21633 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1344,128,1296,32768,65536,1344,137,1024,32769,1345,32768,16,65536,8,65,137,1297,1297,1073741824,33792,32904,256,65570,1344,137]

theorem envBound21633 : H12AffineFastState.Bounded env21633 := by
  intro p hp
  have h : env21633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21632_21633 : H12AffineEnvironment.transform 21 32768 env21632 = env21633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32768 env21632 == env21633) = true)

theorem identity21633 : scanCanonicalize (H12AffineFastState.compose env21633 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 33831) := by decide +kernel

theorem selectedBound21633 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env21634 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1344,128,1296,32768,33831,1344,137,1024,32769,1345,32768,16,33831,8,65,137,1297,1297,1073741824,33792,32904,256,33797,1344,137]

theorem envBound21634 : H12AffineFastState.Bounded env21634 := by
  intro p hp
  have h : env21634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21633_21634 : H12AffineEnvironment.transform 15 33831 env21633 = env21634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33831 env21633 == env21634) = true)

theorem identity21634 : scanCanonicalize (H12AffineFastState.compose env21634 (packedSelected [5,15,41] rootPS)) = affineNative (2^(14+1) ^^^ 2081) := by decide +kernel

theorem selectedBound21634 : packedSelected [5,15,41] rootPS < 2^1333 := by decide +kernel

def env21635 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1344,128,1296,2081,3078,1344,137,1024,2080,1345,2081,16,3078,8,65,137,1297,1297,1073741824,3105,2217,256,3108,1344,137]

theorem envBound21635 : H12AffineFastState.Bounded env21635 := by
  intro p hp
  have h : env21635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21634_21635 : H12AffineEnvironment.transform 14 2081 env21634 = env21635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2081 env21634 == env21635) = true)

theorem identity21635 : scanCanonicalize (H12AffineFastState.compose env21635 (packedSelected [0,2,9,18] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound21635 : packedSelected [0,2,9,18] rootPS < 2^1333 := by decide +kernel

def env21636 : List Nat := [2,4,8,16,32,64,128,256,137,1024,292,1344,128,1296,261,1314,1344,137,1024,260,1345,261,16,1314,8,65,137,1297,1297,1073741824,1285,397,256,1280,1344,137]

theorem envBound21636 : H12AffineFastState.Bounded env21636 := by
  intro p hp
  have h : env21636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21635_21636 : H12AffineEnvironment.transform 10 292 env21635 = env21636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env21635 == env21636) = true)

theorem identity21636 : scanCanonicalize (H12AffineFastState.compose env21636 (packedSelected [1,12,13] rootPS)) = affineNative (2^(29+1) ^^^ 292) := by decide +kernel

theorem selectedBound21636 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env21637 : List Nat := [2,4,8,16,32,64,128,256,137,1024,292,1344,128,1296,261,1314,1344,137,1024,260,1345,261,16,1314,8,65,137,1297,1297,292,1285,397,256,1280,1344,137]

theorem envBound21637 : H12AffineFastState.Bounded env21637 := by
  intro p hp
  have h : env21637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21636_21637 : H12AffineEnvironment.transform 29 292 env21636 = env21637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 292 env21636 == env21637) = true)

theorem identity21637 : scanCanonicalize (H12AffineFastState.compose env21637 (packedSelected [5] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound21637 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env21638 : List Nat := [2,4,8,16,32,64,128,172,137,1024,136,1260,128,1212,169,1166,1260,137,1024,168,1261,169,16,1166,8,65,137,1213,1213,136,1193,33,172,1196,1260,137]

theorem envBound21638 : H12AffineFastState.Bounded env21638 := by
  intro p hp
  have h : env21638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21637_21638 : H12AffineEnvironment.transform 7 172 env21637 = env21638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env21637 == env21638) = true)

theorem identity21638 : scanCanonicalize (H12AffineFastState.compose env21638 (packedSelected [0,2] rootPS)) = affineNative (2^(9+1) ^^^ 156) := by decide +kernel

theorem selectedBound21638 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env21639 : List Nat := [2,4,8,16,32,64,128,172,137,156,136,112,128,32,169,18,112,137,156,168,113,169,16,18,8,65,137,33,33,136,53,33,172,48,112,137]

theorem envBound21639 : H12AffineFastState.Bounded env21639 := by
  intro p hp
  have h : env21639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21638_21639 : H12AffineEnvironment.transform 9 156 env21638 = env21639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 156 env21638 == env21639) = true)

theorem identity21639 : scanCanonicalize (H12AffineFastState.compose env21639 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound21639 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env21640 : List Nat := [2,4,8,16,32,16,128,172,137,156,136,32,128,32,169,18,32,137,156,168,33,169,16,18,8,17,137,33,33,136,53,33,172,48,32,137]

theorem envBound21640 : H12AffineFastState.Bounded env21640 := by
  intro p hp
  have h : env21640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21639_21640 : H12AffineEnvironment.transform 5 16 env21639 = env21640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env21639 == env21640) = true)

def env21641 : List Nat := [2,4,8,16,16,16,128,156,137,156,136,16,128,16,153,18,16,137,156,152,17,153,16,18,8,17,137,17,17,136,5,17,156,0,16,137]

theorem envBound21641 : H12AffineFastState.Bounded env21641 := by
  intro p hp
  have h : env21641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21640_21641 : H12AffineEnvironment.transform 4 16 env21640 = env21641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env21640 == env21641) = true)

theorem identity21641 : scanCanonicalize (H12AffineFastState.compose env21641 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound21641 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21642 : List Nat := [2,4,8,16,16,16,25,5,16,5,17,16,25,16,0,18,16,16,5,1,17,0,16,18,8,17,16,17,17,17,5,17,5,0,16,16]

theorem envBound21642 : H12AffineFastState.Bounded env21642 := by
  intro p hp
  have h : env21642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21641_21642 : H12AffineEnvironment.transform 6 25 env21641 = env21642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env21641 == env21642) = true)

theorem identity21642 : scanCanonicalize (H12AffineFastState.compose env21642 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound21642 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21643 : List Nat := [2,4,8,1,1,1,8,5,1,5,0,1,8,1,0,3,1,1,5,1,0,0,1,3,8,0,1,0,0,0,5,0,5,0,1,1]

theorem envBound21643 : H12AffineFastState.Bounded env21643 := by
  intro p hp
  have h : env21643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21642_21643 : H12AffineEnvironment.transform 3 1 env21642 = env21643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env21642 == env21643) = true)

def leafEnv21643 : List Nat := [2,4,8,1,1,1,8,5,1,5,0,1,8,1,0,3,1,1,5,1,0,0,1,3,4,8,1,0,1,0,0,0,5,0,5,0,5,2,1,1,0,0,1]

def active21643 : List Nat := [0,1,2]

def tree21643 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21643 : H12WitnessSearch.Good tree21643 := H12GlobalWitnessIndex.good

theorem leafIdentity21643 : H12AffineFastState.composeSystem env21643 rootObs = leafEnv21643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21643 rootObs == leafEnv21643) = true)

theorem terminalChecked21643 : H12PackedTerminal.terminalCheckFast leafEnv21643 active21643 tree21643 = true := by decide +kernel

def env21644 : List Nat := [2,4,8,16,17,16,128,157,137,156,136,17,128,17,152,18,17,137,156,153,16,152,16,18,8,17,137,16,16,136,4,16,157,1,17,137]

theorem envBound21644 : H12AffineFastState.Bounded env21644 := by
  intro p hp
  have h : env21644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21640_21644 : H12AffineEnvironment.transform 4 17 env21640 = env21644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env21640 == env21644) = true)

def env21645 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1344,128,1296,32768,65536,1344,137,1024,32769,1345,32769,16,65536,8,65,136,1297,1297,1073741824,33792,32905,256,65570,1344,137]

theorem envBound21645 : H12AffineFastState.Bounded env21645 := by
  intro p hp
  have h : env21645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21632_21645 : H12AffineEnvironment.transform 21 32769 env21632 = env21645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32769 env21632 == env21645) = true)

theorem identity21645 : scanCanonicalize (H12AffineFastState.compose env21645 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 33966) := by decide +kernel

theorem selectedBound21645 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env21646 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1344,128,1296,32768,33966,1344,137,1024,32769,1345,32769,16,33966,8,65,136,1297,1297,1073741824,33792,32905,256,33932,1344,137]

theorem envBound21646 : H12AffineFastState.Bounded env21646 := by
  intro p hp
  have h : env21646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21645_21646 : H12AffineEnvironment.transform 15 33966 env21645 = env21646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33966 env21645 == env21646) = true)

theorem identity21646 : scanCanonicalize (H12AffineFastState.compose env21646 (packedSelected [5,15,41] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound21646 : packedSelected [5,15,41] rootPS < 2^1333 := by decide +kernel

def env21647 : List Nat := [2,4,8,16,32,64,128,256,137,1024,292,1344,128,1296,32768,33966,1344,137,1024,32769,1345,32769,16,33966,8,65,136,1297,1297,1073741824,33792,32905,256,33932,1344,137]

theorem envBound21647 : H12AffineFastState.Bounded env21647 := by
  intro p hp
  have h : env21647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21646_21647 : H12AffineEnvironment.transform 10 292 env21646 = env21647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env21646 == env21647) = true)

theorem identity21647 : scanCanonicalize (H12AffineFastState.compose env21647 (packedSelected [11,15,32,38] rootPS)) = affineNative (2^(29+1) ^^^ 293) := by decide +kernel

theorem selectedBound21647 : packedSelected [11,15,32,38] rootPS < 2^1333 := by decide +kernel

def env21648 : List Nat := [2,4,8,16,32,64,128,256,137,1024,292,1344,128,1296,32768,33966,1344,137,1024,32769,1345,32769,16,33966,8,65,136,1297,1297,293,33792,32905,256,33932,1344,137]

theorem envBound21648 : H12AffineFastState.Bounded env21648 := by
  intro p hp
  have h : env21648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21647_21648 : H12AffineEnvironment.transform 29 293 env21647 = env21648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 293 env21647 == env21648) = true)

theorem identity21648 : scanCanonicalize (H12AffineFastState.compose env21648 (packedSelected [5] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound21648 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env21649 : List Nat := [2,4,8,16,32,64,128,253,137,1024,217,1213,128,1261,32768,33966,1213,137,1024,32769,1212,32769,16,33966,8,65,136,1260,1260,216,33792,32905,253,33932,1213,137]

theorem envBound21649 : H12AffineFastState.Bounded env21649 := by
  intro p hp
  have h : env21649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21648_21649 : H12AffineEnvironment.transform 7 253 env21648 = env21649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env21648 == env21649) = true)

theorem identity21649 : scanCanonicalize (H12AffineFastState.compose env21649 (packedSelected [0,7] rootPS)) = affineNative (2^(14+1) ^^^ 248) := by decide +kernel

theorem selectedBound21649 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env21650 : List Nat := [2,4,8,16,32,64,128,253,137,1024,217,1213,128,1261,248,1110,1213,137,1024,249,1212,249,16,1110,8,65,136,1260,1260,216,1272,113,253,1140,1213,137]

theorem envBound21650 : H12AffineFastState.Bounded env21650 := by
  intro p hp
  have h : env21650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21649_21650 : H12AffineEnvironment.transform 14 248 env21649 = env21650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 248 env21649 == env21650) = true)

def env21651 : List Nat := [2,4,8,16,32,64,120,5,113,1024,33,1093,120,1045,0,1110,1093,113,1024,1,1092,1,16,1110,8,65,112,1044,1044,32,1024,113,5,1140,1093,113]

theorem envBound21651 : H12AffineFastState.Bounded env21651 := by
  intro p hp
  have h : env21651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21650_21651 : H12AffineEnvironment.transform 6 120 env21650 = env21651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env21650 == env21651) = true)

theorem identity21651 : scanCanonicalize (H12AffineFastState.compose env21651 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound21651 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21652 : List Nat := [2,4,8,16,32,64,120,5,113,37,33,96,120,48,0,115,96,113,37,1,97,1,16,115,8,65,112,49,49,32,37,113,5,81,96,113]

theorem envBound21652 : H12AffineFastState.Bounded env21652 := by
  intro p hp
  have h : env21652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21651_21652 : H12AffineEnvironment.transform 9 37 env21651 = env21652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env21651 == env21652) = true)

theorem identity21652 : scanCanonicalize (H12AffineFastState.compose env21652 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound21652 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env21653 : List Nat := [2,4,8,16,17,64,73,5,64,20,16,81,73,1,0,66,81,64,20,1,80,1,16,66,8,65,65,0,0,17,20,64,5,81,81,64]

theorem envBound21653 : H12AffineFastState.Bounded env21653 := by
  intro p hp
  have h : env21653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21652_21653 : H12AffineEnvironment.transform 4 17 env21652 = env21653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env21652 == env21653) = true)

theorem identity21653 : scanCanonicalize (H12AffineFastState.compose env21653 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound21653 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env21654 : List Nat := [2,4,8,16,17,16,25,5,16,20,16,1,25,1,0,18,1,16,20,1,0,1,16,18,8,17,17,0,0,17,20,16,5,1,1,16]

theorem envBound21654 : H12AffineFastState.Bounded env21654 := by
  intro p hp
  have h : env21654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21653_21654 : H12AffineEnvironment.transform 5 16 env21653 = env21654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env21653 == env21654) = true)

theorem identity21654 : scanCanonicalize (H12AffineFastState.compose env21654 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound21654 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21655 : List Nat := [2,4,8,1,0,1,8,5,1,5,1,1,8,1,0,3,1,1,5,1,0,1,1,3,8,0,0,0,0,0,5,1,5,1,1,1]

theorem envBound21655 : H12AffineFastState.Bounded env21655 := by
  intro p hp
  have h : env21655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21654_21655 : H12AffineEnvironment.transform 3 1 env21654 = env21655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env21654 == env21655) = true)

def leafEnv21655 : List Nat := [2,4,8,1,0,1,8,5,1,5,1,1,8,1,0,3,1,1,5,1,0,1,1,3,4,8,1,0,0,0,0,0,5,1,5,1,5,2,1,1,0,0,1]

def active21655 : List Nat := [0,1,2]

def tree21655 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21655 : H12WitnessSearch.Good tree21655 := H12GlobalWitnessIndex.good

theorem leafIdentity21655 : H12AffineFastState.composeSystem env21655 rootObs = leafEnv21655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21655 rootObs == leafEnv21655) = true)

theorem terminalChecked21655 : H12PackedTerminal.terminalCheckFast leafEnv21655 active21655 tree21655 = true := by decide +kernel

def env21656 : List Nat := [2,4,8,16,32,64,121,4,112,1024,32,1092,121,1044,1,1110,1092,112,1024,0,1093,0,16,1110,8,65,113,1045,1045,33,1025,113,4,1140,1092,112]

theorem envBound21656 : H12AffineFastState.Bounded env21656 := by
  intro p hp
  have h : env21656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21650_21656 : H12AffineEnvironment.transform 6 121 env21650 = env21656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env21650 == env21656) = true)

def env21657 : List Nat := [2,4,8,16,0,64,89,4,80,1024,0,1092,89,1044,1,1110,1092,80,1024,0,1093,0,16,1110,8,65,81,1045,1045,1,1025,81,4,1108,1092,80]

theorem envBound21657 : H12AffineFastState.Bounded env21657 := by
  intro p hp
  have h : env21657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21656_21657 : H12AffineEnvironment.transform 4 0 env21656 = env21657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env21656 == env21657) = true)

theorem identity21657 : scanCanonicalize (H12AffineFastState.compose env21657 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 68) := by decide +kernel

theorem selectedBound21657 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21658 : List Nat := [2,4,8,16,0,64,89,4,80,68,0,0,89,80,1,18,0,80,68,0,1,0,16,18,8,65,81,81,81,1,69,81,4,16,0,80]

theorem envBound21658 : H12AffineFastState.Bounded env21658 := by
  intro p hp
  have h : env21658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21657_21658 : H12AffineEnvironment.transform 9 68 env21657 = env21658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 68 env21657 == env21658) = true)

theorem identity21658 : scanCanonicalize (H12AffineFastState.compose env21658 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound21658 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21659 : List Nat := [2,4,8,16,0,0,25,4,16,4,0,0,25,16,1,18,0,16,4,0,1,0,16,18,8,1,17,17,17,1,5,17,4,16,0,16]

theorem envBound21659 : H12AffineFastState.Bounded env21659 := by
  intro p hp
  have h : env21659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21658_21659 : H12AffineEnvironment.transform 5 0 env21658 = env21659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env21658 == env21659) = true)

theorem identity21659 : scanCanonicalize (H12AffineFastState.compose env21659 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound21659 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env21660 : List Nat := [2,4,8,0,0,0,9,4,0,4,0,0,9,0,1,2,0,0,4,0,1,0,0,2,8,1,1,1,1,1,5,1,4,0,0,0]

theorem envBound21660 : H12AffineFastState.Bounded env21660 := by
  intro p hp
  have h : env21660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21659_21660 : H12AffineEnvironment.transform 3 0 env21659 = env21660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env21659 == env21660) = true)

def leafEnv21660 : List Nat := [2,4,8,0,0,0,9,4,0,4,0,0,9,0,1,2,0,0,4,0,1,0,0,2,4,8,1,1,1,1,1,1,5,1,4,0,5,2,0,0,0,1,1]

def active21660 : List Nat := [0,1,2]

def tree21660 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21660 : H12WitnessSearch.Good tree21660 := H12GlobalWitnessIndex.good

theorem leafIdentity21660 : H12AffineFastState.composeSystem env21660 rootObs = leafEnv21660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21660 rootObs == leafEnv21660) = true)

theorem terminalChecked21660 : H12PackedTerminal.terminalCheckFast leafEnv21660 active21660 tree21660 = true := by decide +kernel

def env21661 : List Nat := [2,4,8,16,1,64,88,4,81,1024,1,1092,88,1044,1,1110,1092,81,1024,0,1093,0,16,1110,8,65,80,1045,1045,0,1025,80,4,1109,1092,81]

theorem envBound21661 : H12AffineFastState.Bounded env21661 := by
  intro p hp
  have h : env21661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21656_21661 : H12AffineEnvironment.transform 4 1 env21656 = env21661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env21656 == env21661) = true)

theorem identity21661 : scanCanonicalize (H12AffineFastState.compose env21661 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound21661 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21662 : List Nat := [2,4,8,16,1,64,88,4,81,21,1,81,88,1,1,67,81,81,21,0,80,0,16,67,8,65,80,0,0,0,20,80,4,64,81,81]

theorem envBound21662 : H12AffineFastState.Bounded env21662 := by
  intro p hp
  have h : env21662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21661_21662 : H12AffineEnvironment.transform 9 21 env21661 = env21662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env21661 == env21662) = true)

def env21663 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,128,1296,32768,65536,1344,137,1024,32769,1345,4194304,16,65537,8,65,4227208,1297,1297,1073741824,33793,4194440,256,65571,1344,512]

theorem envBound21663 : H12AffineFastState.Bounded env21663 := by
  intro p hp
  have h : env21663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21630_21663 : H12AffineEnvironment.transform 23 65537 env21630 = env21663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 65537 env21630 == env21663) = true)

theorem identity21663 : scanCanonicalize (H12AffineFastState.compose env21663 (packedSelected [1,8,28] rootPS)) = affineNative (2^(14+1) ^^^ 909) := by decide +kernel

theorem selectedBound21663 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env21664 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,128,1296,909,65536,1344,137,1024,908,1345,4194304,16,65537,8,65,4195077,1297,1297,1073741824,1932,4194440,256,65571,1344,512]

theorem envBound21664 : H12AffineFastState.Bounded env21664 := by
  intro p hp
  have h : env21664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21663_21664 : H12AffineEnvironment.transform 14 909 env21663 = env21664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 909 env21663 == env21664) = true)

def env21665 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1344,8,1296,773,65536,1344,1,1024,772,1345,4194304,16,65537,8,65,4195077,1297,1297,1073741824,1796,4194304,256,65571,1344,512]

theorem envBound21665 : H12AffineFastState.Bounded env21665 := by
  intro p hp
  have h : env21665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21664_21665 : H12AffineEnvironment.transform 6 8 env21664 = env21665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21664 == env21665) = true)

theorem identity21665 : scanCanonicalize (H12AffineFastState.compose env21665 (packedSelected [6] rootPS)) = affineNative (2^(29+1) ^^^ 4197412) := by decide +kernel

theorem selectedBound21665 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env21666 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1344,8,1296,773,65536,1344,1,1024,772,1345,4194304,16,65537,8,65,4195077,1297,1297,4197412,1796,4194304,256,65571,1344,512]

theorem envBound21666 : H12AffineFastState.Bounded env21666 := by
  intro p hp
  have h : env21666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21665_21666 : H12AffineEnvironment.transform 29 4197412 env21665 = env21666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4197412 env21665 == env21666) = true)

def env21667 : List Nat := [2,4,8,16,32,64,8,256,260,1024,2048,1344,8,1296,1,65536,1344,1,1024,0,1345,4194304,16,65537,8,65,4194305,1297,1297,4197412,1024,4194304,256,65571,1344,260]

theorem envBound21667 : H12AffineFastState.Bounded env21667 := by
  intro p hp
  have h : env21667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21666_21667 : H12AffineEnvironment.transform 8 260 env21666 = env21667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env21666 == env21667) = true)

theorem identity21667 : scanCanonicalize (H12AffineFastState.compose env21667 (packedSelected [2] rootPS)) = affineNative (2^(21+1) ^^^ 324) := by decide +kernel

theorem selectedBound21667 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21668 : List Nat := [2,4,8,16,32,64,8,256,260,1024,2048,1344,8,1296,1,65536,1344,1,1024,0,1345,324,16,65537,8,65,325,1297,1297,3424,1024,324,256,65571,1344,260]

theorem envBound21668 : H12AffineFastState.Bounded env21668 := by
  intro p hp
  have h : env21668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21667_21668 : H12AffineEnvironment.transform 21 324 env21667 = env21668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 324 env21667 == env21668) = true)

theorem identity21668 : scanCanonicalize (H12AffineFastState.compose env21668 (packedSelected [3,15,17] rootPS)) = affineNative (2^(9+1) ^^^ 289) := by decide +kernel

theorem selectedBound21668 : packedSelected [3,15,17] rootPS < 2^1333 := by decide +kernel

def env21669 : List Nat := [2,4,8,16,32,64,8,256,260,289,2048,97,8,49,1,65536,97,1,289,0,96,324,16,65537,8,65,325,48,48,2113,289,324,256,65571,97,260]

theorem envBound21669 : H12AffineFastState.Bounded env21669 := by
  intro p hp
  have h : env21669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21668_21669 : H12AffineEnvironment.transform 9 289 env21668 = env21669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 289 env21668 == env21669) = true)

theorem identity21669 : scanCanonicalize (H12AffineFastState.compose env21669 (packedSelected [5,7,8] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound21669 : packedSelected [5,7,8] rootPS < 2^1333 := by decide +kernel

def env21670 : List Nat := [2,4,8,16,32,64,8,256,260,289,2048,97,8,49,1,263,97,1,289,0,96,324,16,262,8,65,325,48,48,2113,289,324,256,292,97,260]

theorem envBound21670 : H12AffineFastState.Bounded env21670 := by
  intro p hp
  have h : env21670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21669_21670 : H12AffineEnvironment.transform 15 263 env21669 = env21670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env21669 == env21670) = true)

theorem identity21670 : scanCanonicalize (H12AffineFastState.compose env21670 (packedSelected [0,1,4,5,7,11,13] rootPS)) = affineNative (2^(10+1) ^^^ 373) := by decide +kernel

theorem selectedBound21670 : packedSelected [0,1,4,5,7,11,13] rootPS < 2^1333 := by decide +kernel

def env21671 : List Nat := [2,4,8,16,32,64,8,256,260,289,373,97,8,49,1,263,97,1,289,0,96,324,16,262,8,65,325,48,48,308,289,324,256,292,97,260]

theorem envBound21671 : H12AffineFastState.Bounded env21671 := by
  intro p hp
  have h : env21671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21670_21671 : H12AffineEnvironment.transform 10 373 env21670 = env21671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 373 env21670 == env21671) = true)

theorem identity21671 : scanCanonicalize (H12AffineFastState.compose env21671 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(7+1) ^^^ 100) := by decide +kernel

theorem selectedBound21671 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env21672 : List Nat := [2,4,8,16,32,64,8,100,96,69,17,97,8,49,1,99,97,1,69,0,96,32,16,98,8,65,33,48,48,80,69,32,100,64,97,96]

theorem envBound21672 : H12AffineFastState.Bounded env21672 := by
  intro p hp
  have h : env21672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21671_21672 : H12AffineEnvironment.transform 7 100 env21671 = env21672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 100 env21671 == env21672) = true)

theorem identity21672 : scanCanonicalize (H12AffineFastState.compose env21672 (packedSelected [0,1,3] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound21672 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env21673 : List Nat := [2,4,8,16,32,33,8,5,1,36,17,0,8,49,1,2,0,1,36,0,1,32,16,3,8,32,33,48,48,49,36,32,5,33,0,1]

theorem envBound21673 : H12AffineFastState.Bounded env21673 := by
  intro p hp
  have h : env21673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21672_21673 : H12AffineEnvironment.transform 5 33 env21672 = env21673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env21672 == env21673) = true)

theorem identity21673 : scanCanonicalize (H12AffineFastState.compose env21673 (packedSelected [0,5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound21673 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env21674 : List Nat := [2,4,8,16,17,16,8,5,1,21,17,0,8,0,1,2,0,1,21,0,1,17,16,3,8,17,16,1,1,0,21,17,5,16,0,1]

theorem envBound21674 : H12AffineFastState.Bounded env21674 := by
  intro p hp
  have h : env21674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21673_21674 : H12AffineEnvironment.transform 4 17 env21673 = env21674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env21673 == env21674) = true)

def leafEnv21674 : List Nat := [2,4,8,16,17,16,8,5,1,21,17,0,8,0,1,2,0,1,21,0,1,17,16,3,20,8,1,17,16,1,1,0,21,17,5,16,5,3,0,1,0,1,1]

def active21674 : List Nat := [0,1,2,3]

def tree21674 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21674 : H12WitnessSearch.Good tree21674 := H12GlobalWitnessIndex.good

theorem leafIdentity21674 : H12AffineFastState.composeSystem env21674 rootObs = leafEnv21674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21674 rootObs == leafEnv21674) = true)

theorem terminalChecked21674 : H12PackedTerminal.terminalCheckFast leafEnv21674 active21674 tree21674 = true := by decide +kernel

def env21675 : List Nat := [2,4,8,16,32,64,8,256,261,1024,2048,1344,8,1296,0,65536,1344,1,1024,1,1345,4194304,16,65537,8,65,4194304,1297,1297,4197412,1025,4194304,256,65571,1344,261]

theorem envBound21675 : H12AffineFastState.Bounded env21675 := by
  intro p hp
  have h : env21675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21666_21675 : H12AffineEnvironment.transform 8 261 env21666 = env21675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env21666 == env21675) = true)

theorem identity21675 : scanCanonicalize (H12AffineFastState.compose env21675 (packedSelected [2] rootPS)) = affineNative (2^(21+1) ^^^ 65863) := by decide +kernel

theorem selectedBound21675 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21676 : List Nat := [2,4,8,16,32,64,8,256,261,1024,2048,1344,8,1296,0,65536,1344,1,1024,1,1345,65863,16,65537,8,65,65863,1297,1297,68963,1025,65863,256,65571,1344,261]

theorem envBound21676 : H12AffineFastState.Bounded env21676 := by
  intro p hp
  have h : env21676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21675_21676 : H12AffineEnvironment.transform 21 65863 env21675 = env21676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 65863 env21675 == env21676) = true)

theorem identity21676 : scanCanonicalize (H12AffineFastState.compose env21676 (packedSelected [3,15,17] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound21676 : packedSelected [3,15,17] rootPS < 2^1333 := by decide +kernel

def env21677 : List Nat := [2,4,8,16,32,64,8,256,261,37,2048,357,8,309,0,65536,357,1,37,1,356,65863,16,65537,8,65,65863,308,308,67910,36,65863,256,65571,357,261]

theorem envBound21677 : H12AffineFastState.Bounded env21677 := by
  intro p hp
  have h : env21677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21676_21677 : H12AffineEnvironment.transform 9 37 env21676 = env21677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env21676 == env21677) = true)

theorem identity21677 : scanCanonicalize (H12AffineFastState.compose env21677 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound21677 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env21678 : List Nat := [2,4,8,16,32,64,8,256,261,37,293,357,8,309,0,65536,357,1,37,1,356,65863,16,65537,8,65,65863,308,308,65635,36,65863,256,65571,357,261]

theorem envBound21678 : H12AffineFastState.Bounded env21678 := by
  intro p hp
  have h : env21678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21677_21678 : H12AffineEnvironment.transform 10 293 env21677 = env21678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env21677 == env21678) = true)

theorem identity21678 : scanCanonicalize (H12AffineFastState.compose env21678 (packedSelected [1,5,7,11,13] rootPS)) = affineNative (2^(15+1) ^^^ 327) := by decide +kernel

theorem selectedBound21678 : packedSelected [1,5,7,11,13] rootPS < 2^1333 := by decide +kernel

def env21679 : List Nat := [2,4,8,16,32,64,8,256,261,37,293,357,8,309,0,327,357,1,37,1,356,0,16,326,8,65,0,308,308,292,36,0,256,356,357,261]

theorem envBound21679 : H12AffineFastState.Bounded env21679 := by
  intro p hp
  have h : env21679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21678_21679 : H12AffineEnvironment.transform 15 327 env21678 = env21679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 327 env21678 == env21679) = true)

theorem identity21679 : scanCanonicalize (H12AffineFastState.compose env21679 (packedSelected [5] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound21679 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env21680 : List Nat := [2,4,8,16,32,64,8,116,113,37,81,17,8,65,0,51,17,1,37,1,16,0,16,50,8,65,0,64,64,80,36,0,116,16,17,113]

theorem envBound21680 : H12AffineFastState.Bounded env21680 := by
  intro p hp
  have h : env21680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21679_21680 : H12AffineEnvironment.transform 7 116 env21679 = env21680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env21679 == env21680) = true)

theorem identity21680 : scanCanonicalize (H12AffineFastState.compose env21680 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound21680 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env21681 : List Nat := [2,4,8,16,32,49,8,5,0,37,32,17,8,48,0,51,17,1,37,1,16,0,16,50,8,48,0,49,49,33,36,0,5,16,17,0]

theorem envBound21681 : H12AffineFastState.Bounded env21681 := by
  intro p hp
  have h : env21681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21680_21681 : H12AffineEnvironment.transform 5 49 env21680 = env21681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env21680 == env21681) = true)

theorem identity21681 : scanCanonicalize (H12AffineFastState.compose env21681 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound21681 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21682 : List Nat := [2,4,8,0,32,33,8,5,0,37,32,1,8,32,0,35,1,1,37,1,0,0,0,34,8,32,0,33,33,33,36,0,5,0,1,0]

theorem envBound21682 : H12AffineFastState.Bounded env21682 := by
  intro p hp
  have h : env21682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21681_21682 : H12AffineEnvironment.transform 3 0 env21681 = env21682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env21681 == env21682) = true)

def env21683 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1344,9,1296,772,65536,1344,0,1024,773,1345,4194304,16,65537,8,65,4195077,1297,1297,1073741824,1797,4194305,256,65571,1344,512]

theorem envBound21683 : H12AffineFastState.Bounded env21683 := by
  intro p hp
  have h : env21683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21664_21683 : H12AffineEnvironment.transform 6 9 env21664 = env21683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21664 == env21683) = true)

theorem identity21683 : scanCanonicalize (H12AffineFastState.compose env21683 (packedSelected [6] rootPS)) = affineNative (2^(29+1) ^^^ 3873) := by decide +kernel

theorem selectedBound21683 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env21684 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1344,9,1296,772,65536,1344,0,1024,773,1345,4194304,16,65537,8,65,4195077,1297,1297,3873,1797,4194305,256,65571,1344,512]

theorem envBound21684 : H12AffineFastState.Bounded env21684 := by
  intro p hp
  have h : env21684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21683_21684 : H12AffineEnvironment.transform 29 3873 env21683 = env21684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 3873 env21683 == env21684) = true)

def env21685 : List Nat := [2,4,8,16,32,64,9,256,260,1024,2048,1344,9,1296,0,65536,1344,0,1024,1,1345,4194304,16,65537,8,65,4194305,1297,1297,3109,1025,4194305,256,65571,1344,260]

theorem envBound21685 : H12AffineFastState.Bounded env21685 := by
  intro p hp
  have h : env21685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21684_21685 : H12AffineEnvironment.transform 8 260 env21684 = env21685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env21684 == env21685) = true)

theorem identity21685 : scanCanonicalize (H12AffineFastState.compose env21685 (packedSelected [2] rootPS)) = affineNative (2^(21+1) ^^^ 65894) := by decide +kernel

theorem selectedBound21685 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21686 : List Nat := [2,4,8,16,32,64,9,256,260,1024,2048,1344,9,1296,0,65536,1344,0,1024,1,1345,65894,16,65537,8,65,65895,1297,1297,3109,1025,65895,256,65571,1344,260]

theorem envBound21686 : H12AffineFastState.Bounded env21686 := by
  intro p hp
  have h : env21686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21685_21686 : H12AffineEnvironment.transform 21 65894 env21685 = env21686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 65894 env21685 == env21686) = true)

theorem identity21686 : scanCanonicalize (H12AffineFastState.compose env21686 (packedSelected [3,15,17] rootPS)) = affineNative (2^(15+1) ^^^ 1094) := by decide +kernel

theorem selectedBound21686 : packedSelected [3,15,17] rootPS < 2^1333 := by decide +kernel

def env21687 : List Nat := [2,4,8,16,32,64,9,256,260,1024,2048,1344,9,1296,0,1094,1344,0,1024,1,1345,1312,16,1095,8,65,1313,1297,1297,3109,1025,1313,256,1125,1344,260]

theorem envBound21687 : H12AffineFastState.Bounded env21687 := by
  intro p hp
  have h : env21687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21686_21687 : H12AffineEnvironment.transform 15 1094 env21686 = env21687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1094 env21686 == env21687) = true)

theorem identity21687 : scanCanonicalize (H12AffineFastState.compose env21687 (packedSelected [0,1,4,5,8,9,12] rootPS)) = affineNative (2^(9+1) ^^^ 304) := by decide +kernel

theorem selectedBound21687 : packedSelected [0,1,4,5,8,9,12] rootPS < 2^1333 := by decide +kernel

def env21688 : List Nat := [2,4,8,16,32,64,9,256,260,304,2048,112,9,32,0,374,112,0,304,1,113,16,16,375,8,65,17,33,33,2325,305,17,256,341,112,260]

theorem envBound21688 : H12AffineFastState.Bounded env21688 := by
  intro p hp
  have h : env21688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21687_21688 : H12AffineEnvironment.transform 9 304 env21687 = env21688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env21687 == env21688) = true)

theorem identity21688 : scanCanonicalize (H12AffineFastState.compose env21688 (packedSelected [7] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound21688 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env21689 : List Nat := [2,4,8,0,32,64,9,256,260,288,2048,96,9,32,0,358,96,0,288,1,97,0,0,359,8,65,1,33,33,2309,289,1,256,325,96,260]

theorem envBound21689 : H12AffineFastState.Bounded env21689 := by
  intro p hp
  have h : env21689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21688_21689 : H12AffineEnvironment.transform 3 0 env21688 = env21689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env21688 == env21689) = true)

theorem identity21689 : scanCanonicalize (H12AffineFastState.compose env21689 (packedSelected [4,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound21689 : packedSelected [4,5,8] rootPS < 2^1333 := by decide +kernel

def env21690 : List Nat := [2,4,8,0,32,33,9,256,260,288,2048,1,9,32,0,263,1,0,288,1,0,0,0,262,8,32,1,33,33,2309,289,1,256,292,1,260]

theorem envBound21690 : H12AffineFastState.Bounded env21690 := by
  intro p hp
  have h : env21690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21689_21690 : H12AffineEnvironment.transform 5 33 env21689 = env21690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env21689 == env21690) = true)

theorem identity21690 : scanCanonicalize (H12AffineFastState.compose env21690 (packedSelected [1,4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound21690 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env21691 : List Nat := [2,4,8,0,32,33,9,4,0,36,2048,1,9,32,0,3,1,0,36,1,0,0,0,2,8,32,1,33,33,2049,37,1,4,32,1,0]

theorem envBound21691 : H12AffineFastState.Bounded env21691 := by
  intro p hp
  have h : env21691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21690_21691 : H12AffineEnvironment.transform 7 4 env21690 = env21691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env21690 == env21691) = true)

theorem identity21691 : scanCanonicalize (H12AffineFastState.compose env21691 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound21691 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env21692 : List Nat := [2,4,8,0,32,33,9,4,0,36,33,1,9,32,0,3,1,0,36,1,0,0,0,2,8,32,1,33,33,32,37,1,4,32,1,0]

theorem envBound21692 : H12AffineFastState.Bounded env21692 := by
  intro p hp
  have h : env21692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21691_21692 : H12AffineEnvironment.transform 10 33 env21691 = env21692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env21691 == env21692) = true)

theorem identity21692 : scanCanonicalize (H12AffineFastState.compose env21692 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound21692 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env21693 : List Nat := [2,4,8,0,1,0,9,4,0,5,0,1,9,1,0,3,1,0,5,1,0,0,0,2,8,1,1,0,0,1,4,1,4,1,1,0]

theorem envBound21693 : H12AffineFastState.Bounded env21693 := by
  intro p hp
  have h : env21693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21692_21693 : H12AffineEnvironment.transform 4 1 env21692 = env21693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env21692 == env21693) = true)

def leafEnv21693 : List Nat := [2,4,8,0,1,0,9,4,0,5,0,1,9,1,0,3,1,0,5,1,0,0,0,2,5,8,1,1,1,0,0,1,4,1,4,1,5,3,1,0,0,0,1]

def active21693 : List Nat := [0,1,2]

def tree21693 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21693 : H12WitnessSearch.Good tree21693 := H12GlobalWitnessIndex.good

theorem leafIdentity21693 : H12AffineFastState.composeSystem env21693 rootObs = leafEnv21693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21693 rootObs == leafEnv21693) = true)

theorem terminalChecked21693 : H12PackedTerminal.terminalCheckFast leafEnv21693 active21693 tree21693 = true := by decide +kernel

def env21694 : List Nat := [2,4,8,16,32,64,9,256,261,1024,2048,1344,9,1296,1,65536,1344,0,1024,0,1345,4194304,16,65537,8,65,4194304,1297,1297,3108,1024,4194305,256,65571,1344,261]

theorem envBound21694 : H12AffineFastState.Bounded env21694 := by
  intro p hp
  have h : env21694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21684_21694 : H12AffineEnvironment.transform 8 261 env21684 = env21694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env21684 == env21694) = true)

theorem identity21694 : scanCanonicalize (H12AffineFastState.compose env21694 (packedSelected [2] rootPS)) = affineNative (2^(21+1) ^^^ 357) := by decide +kernel

theorem selectedBound21694 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21695 : List Nat := [2,4,8,16,32,64,9,256,261,1024,2048,1344,9,1296,1,65536,1344,0,1024,0,1345,357,16,65537,8,65,357,1297,1297,3108,1024,356,256,65571,1344,261]

theorem envBound21695 : H12AffineFastState.Bounded env21695 := by
  intro p hp
  have h : env21695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21694_21695 : H12AffineEnvironment.transform 21 357 env21694 = env21695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 357 env21694 == env21695) = true)

theorem identity21695 : scanCanonicalize (H12AffineFastState.compose env21695 (packedSelected [3,15,17] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound21695 : packedSelected [3,15,17] rootPS < 2^1333 := by decide +kernel

def env21696 : List Nat := [2,4,8,16,32,64,9,256,261,321,2048,1,9,81,1,65536,1,0,321,0,0,357,16,65537,8,65,357,80,80,2405,321,356,256,65571,1,261]

theorem envBound21696 : H12AffineFastState.Bounded env21696 := by
  intro p hp
  have h : env21696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21695_21696 : H12AffineEnvironment.transform 9 321 env21695 = env21696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env21695 == env21696) = true)

theorem identity21696 : scanCanonicalize (H12AffineFastState.compose env21696 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound21696 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env21697 : List Nat := [2,4,8,16,32,64,9,256,261,321,293,1,9,81,1,65536,1,0,321,0,0,357,16,65537,8,65,357,80,80,64,321,356,256,65571,1,261]

theorem envBound21697 : H12AffineFastState.Bounded env21697 := by
  intro p hp
  have h : env21697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21696_21697 : H12AffineEnvironment.transform 10 293 env21696 = env21697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env21696 == env21697) = true)

theorem identity21697 : scanCanonicalize (H12AffineFastState.compose env21697 (packedSelected [7,11] rootPS)) = affineNative (2^(15+1) ^^^ 327) := by decide +kernel

theorem selectedBound21697 : packedSelected [7,11] rootPS < 2^1333 := by decide +kernel

def env21698 : List Nat := [2,4,8,16,32,64,9,256,261,321,293,1,9,81,1,327,1,0,321,0,0,357,16,326,8,65,357,80,80,64,321,356,256,356,1,261]

theorem envBound21698 : H12AffineFastState.Bounded env21698 := by
  intro p hp
  have h : env21698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21697_21698 : H12AffineEnvironment.transform 15 327 env21697 = env21698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 327 env21697 == env21698) = true)

theorem identity21698 : scanCanonicalize (H12AffineFastState.compose env21698 (packedSelected [5,12,13] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound21698 : packedSelected [5,12,13] rootPS < 2^1333 := by decide +kernel

def env21699 : List Nat := [2,4,8,16,32,0,9,256,261,257,293,1,9,17,1,263,1,0,257,0,0,293,16,262,8,1,293,16,16,0,257,292,256,292,1,261]

theorem envBound21699 : H12AffineFastState.Bounded env21699 := by
  intro p hp
  have h : env21699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21698_21699 : H12AffineEnvironment.transform 5 0 env21698 = env21699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env21698 == env21699) = true)

theorem identity21699 : scanCanonicalize (H12AffineFastState.compose env21699 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound21699 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env21700 : List Nat := [2,4,8,16,16,0,9,256,261,257,277,1,9,17,1,263,1,0,257,0,0,277,16,262,8,1,277,16,16,0,257,276,256,276,1,261]

theorem envBound21700 : H12AffineFastState.Bounded env21700 := by
  intro p hp
  have h : env21700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21699_21700 : H12AffineEnvironment.transform 4 16 env21699 = env21700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env21699 == env21700) = true)

theorem identity21700 : scanCanonicalize (H12AffineFastState.compose env21700 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound21700 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21701 : List Nat := [2,4,8,16,16,0,9,4,1,5,17,1,9,17,1,3,1,0,5,0,0,17,16,2,8,1,17,16,16,0,5,16,4,16,1,1]

theorem envBound21701 : H12AffineFastState.Bounded env21701 := by
  intro p hp
  have h : env21701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21700_21701 : H12AffineEnvironment.transform 7 4 env21700 = env21701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env21700 == env21701) = true)

theorem identity21701 : scanCanonicalize (H12AffineFastState.compose env21701 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound21701 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21702 : List Nat := [2,4,8,0,0,0,9,4,1,5,1,1,9,1,1,3,1,0,5,0,0,1,0,2,8,1,1,0,0,0,5,0,4,0,1,1]

theorem envBound21702 : H12AffineFastState.Bounded env21702 := by
  intro p hp
  have h : env21702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21701_21702 : H12AffineEnvironment.transform 3 0 env21701 = env21702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env21701 == env21702) = true)

def env21703 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,129,1296,32768,65536,1344,262144,1024,32769,1345,4194304,16,16777216,9,65,21331968,1297,1297,1073741824,16876544,4194440,256,16777250,1344,512]

theorem envBound21703 : H12AffineFastState.Bounded env21703 := by
  intro p hp
  have h : env21703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21628_21703 : H12AffineEnvironment.transform 12 129 env21628 = env21703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 129 env21628 == env21703) = true)

theorem identity21703 : scanCanonicalize (H12AffineFastState.compose env21703 (packedSelected [3,5,24] rootPS)) = affineNative (2^(23+1) ^^^ 360845) := by decide +kernel

theorem selectedBound21703 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env21704 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,129,1296,32768,65536,1344,262144,1024,32769,1345,4194304,16,360845,9,65,4194701,1297,1297,1073741824,263565,4194440,256,360879,1344,512]

theorem envBound21704 : H12AffineFastState.Bounded env21704 := by
  intro p hp
  have h : env21704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21703_21704 : H12AffineEnvironment.transform 23 360845 env21703 = env21704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 360845 env21703 == env21704) = true)

def env21705 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,129,1296,32768,65536,1344,136,1024,32769,1345,4194304,16,98565,9,65,4194701,1297,1297,1073741824,1285,4194440,256,98599,1344,512]

theorem envBound21705 : H12AffineFastState.Bounded env21705 := by
  intro p hp
  have h : env21705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21704_21705 : H12AffineEnvironment.transform 17 136 env21704 = env21705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 136 env21704 == env21705) = true)

theorem identity21705 : scanCanonicalize (H12AffineFastState.compose env21705 (packedSelected [1,12,13] rootPS)) = affineNative (2^(29+1) ^^^ 4228013) := by decide +kernel

theorem selectedBound21705 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env21706 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,129,1296,32768,65536,1344,136,1024,32769,1345,4194304,16,98565,9,65,4194701,1297,1297,4228013,1285,4194440,256,98599,1344,512]

theorem envBound21706 : H12AffineFastState.Bounded env21706 := by
  intro p hp
  have h : env21706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21705_21706 : H12AffineEnvironment.transform 29 4228013 env21705 = env21706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4228013 env21705 == env21706) = true)

theorem identity21706 : scanCanonicalize (H12AffineFastState.compose env21706 (packedSelected [3,15,17] rootPS)) = affineNative (2^(14+1) ^^^ 2728) := by decide +kernel

theorem selectedBound21706 : packedSelected [3,15,17] rootPS < 2^1333 := by decide +kernel

def env21707 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,129,1296,2728,65536,1344,136,1024,2729,1345,4194304,16,68525,9,65,4194701,1297,1297,4196613,1285,4194440,256,68495,1344,512]

theorem envBound21707 : H12AffineFastState.Bounded env21707 := by
  intro p hp
  have h : env21707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21706_21707 : H12AffineEnvironment.transform 14 2728 env21706 = env21707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2728 env21706 == env21707) = true)

theorem identity21707 : scanCanonicalize (H12AffineFastState.compose env21707 (packedSelected [5,8] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound21707 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env21708 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1344,129,1296,2081,65536,1344,136,1024,2080,1345,4194304,16,67876,9,65,4194701,1297,1297,4196613,1285,4194440,256,67846,1344,137]

theorem envBound21708 : H12AffineFastState.Bounded env21708 := by
  intro p hp
  have h : env21708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21707_21708 : H12AffineEnvironment.transform 8 137 env21707 = env21708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env21707 == env21708) = true)

def env21709 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,129,1296,2081,65536,1296,136,1024,2080,1297,4194304,16,67876,9,17,4194701,1297,1297,4196613,1285,4194440,256,67846,1296,137]

theorem envBound21709 : H12AffineFastState.Bounded env21709 := by
  intro p hp
  have h : env21709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21708_21709 : H12AffineEnvironment.transform 5 16 env21708 = env21709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env21708 == env21709) = true)

theorem identity21709 : scanCanonicalize (H12AffineFastState.compose env21709 (packedSelected [5] rootPS)) = affineNative (2^(21+1) ^^^ 2444) := by decide +kernel

theorem selectedBound21709 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env21710 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,129,1296,2081,65536,1296,136,1024,2080,1297,2444,16,67876,9,17,2049,1297,1297,137,1285,2308,256,67846,1296,137]

theorem envBound21710 : H12AffineFastState.Bounded env21710 := by
  intro p hp
  have h : env21710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21709_21710 : H12AffineEnvironment.transform 21 2444 env21709 = env21710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2444 env21709 == env21710) = true)

def env21711 : List Nat := [2,4,8,16,32,16,128,256,137,272,2048,0,129,0,2081,65536,0,136,272,2080,1,2444,16,67876,9,17,2049,1,1,137,21,2308,256,67846,0,137]

theorem envBound21711 : H12AffineFastState.Bounded env21711 := by
  intro p hp
  have h : env21711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21710_21711 : H12AffineEnvironment.transform 9 272 env21710 = env21711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env21710 == env21711) = true)

theorem identity21711 : scanCanonicalize (H12AffineFastState.compose env21711 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 2083) := by decide +kernel

theorem selectedBound21711 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21712 : List Nat := [2,4,8,16,32,16,128,256,137,272,2048,0,129,0,2081,2083,0,136,272,2080,1,2444,16,263,9,17,2049,1,1,137,21,2308,256,293,0,137]

theorem envBound21712 : H12AffineFastState.Bounded env21712 := by
  intro p hp
  have h : env21712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21711_21712 : H12AffineEnvironment.transform 15 2083 env21711 = env21712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2083 env21711 == env21712) = true)

def env21713 : List Nat := [2,4,8,16,32,16,128,256,137,272,168,0,129,0,137,139,0,136,272,136,1,292,16,263,9,17,169,1,1,137,21,428,256,293,0,137]

theorem envBound21713 : H12AffineFastState.Bounded env21713 := by
  intro p hp
  have h : env21713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21712_21713 : H12AffineEnvironment.transform 10 168 env21712 = env21713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 168 env21712 == env21713) = true)

theorem identity21713 : scanCanonicalize (H12AffineFastState.compose env21713 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound21713 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21714 : List Nat := [2,4,8,16,32,16,25,256,16,272,49,0,24,0,16,18,0,17,272,17,1,292,16,263,9,17,48,1,1,16,21,309,256,293,0,16]

theorem envBound21714 : H12AffineFastState.Bounded env21714 := by
  intro p hp
  have h : env21714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21713_21714 : H12AffineEnvironment.transform 6 25 env21713 = env21714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env21713 == env21714) = true)

def env21715 : List Nat := [2,4,8,16,0,16,25,256,16,272,17,0,24,0,16,18,0,17,272,17,1,260,16,263,9,17,16,1,1,16,21,277,256,261,0,16]

theorem envBound21715 : H12AffineFastState.Bounded env21715 := by
  intro p hp
  have h : env21715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21714_21715 : H12AffineEnvironment.transform 4 0 env21714 = env21715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env21714 == env21715) = true)

theorem identity21715 : scanCanonicalize (H12AffineFastState.compose env21715 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound21715 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21716 : List Nat := [2,4,8,1,0,1,8,256,1,257,0,0,9,0,1,3,0,0,257,0,1,260,1,263,9,0,1,1,1,1,4,260,256,261,0,1]

theorem envBound21716 : H12AffineFastState.Bounded env21716 := by
  intro p hp
  have h : env21716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21715_21716 : H12AffineEnvironment.transform 3 1 env21715 = env21716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env21715 == env21716) = true)

theorem identity21716 : scanCanonicalize (H12AffineFastState.compose env21716 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound21716 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env21717 : List Nat := [2,4,8,1,0,1,8,4,1,5,0,0,9,0,1,3,0,0,5,0,1,0,1,3,9,0,1,1,1,1,4,0,4,1,0,1]

theorem envBound21717 : H12AffineFastState.Bounded env21717 := by
  intro p hp
  have h : env21717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21716_21717 : H12AffineEnvironment.transform 7 4 env21716 = env21717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env21716 == env21717) = true)

def leafEnv21717 : List Nat := [2,4,8,1,0,1,8,4,1,5,0,0,9,0,1,3,0,0,5,0,1,0,1,3,5,9,1,0,1,1,1,1,4,0,4,1,5,2,0,1,0,1,1]

def active21717 : List Nat := [0,1,2]

def tree21717 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21717 : H12WitnessSearch.Good tree21717 := H12GlobalWitnessIndex.good

theorem leafIdentity21717 : H12AffineFastState.composeSystem env21717 rootObs = leafEnv21717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21717 rootObs == leafEnv21717) = true)

theorem terminalChecked21717 : H12PackedTerminal.terminalCheckFast leafEnv21717 active21717 tree21717 = true := by decide +kernel

def env21718 : List Nat := [2,4,8,16,1,16,25,256,16,272,16,0,24,0,16,18,0,17,272,17,1,261,16,263,9,17,17,1,1,16,21,276,256,260,0,16]

theorem envBound21718 : H12AffineFastState.Bounded env21718 := by
  intro p hp
  have h : env21718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21714_21718 : H12AffineEnvironment.transform 4 1 env21714 = env21718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env21714 == env21718) = true)

theorem identity21718 : scanCanonicalize (H12AffineFastState.compose env21718 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound21718 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21719 : List Nat := [2,4,8,16,1,16,25,20,16,4,16,0,24,0,16,18,0,17,4,17,1,17,16,19,9,17,17,1,1,16,21,0,20,16,0,16]

theorem envBound21719 : H12AffineFastState.Bounded env21719 := by
  intro p hp
  have h : env21719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21718_21719 : H12AffineEnvironment.transform 7 20 env21718 = env21719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env21718 == env21719) = true)

def env21720 : List Nat := [2,4,8,16,32,16,128,256,137,272,169,0,129,0,136,138,0,136,272,137,1,293,16,263,9,17,168,1,1,137,21,429,256,293,0,137]

theorem envBound21720 : H12AffineFastState.Bounded env21720 := by
  intro p hp
  have h : env21720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21712_21720 : H12AffineEnvironment.transform 10 169 env21712 = env21720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 169 env21712 == env21720) = true)

theorem identity21720 : scanCanonicalize (H12AffineFastState.compose env21720 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 188) := by decide +kernel

theorem selectedBound21720 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21721 : List Nat := [2,4,8,16,32,16,128,188,137,172,169,0,129,0,136,138,0,136,172,137,1,153,16,187,9,17,168,1,1,137,21,17,188,153,0,137]

theorem envBound21721 : H12AffineFastState.Bounded env21721 := by
  intro p hp
  have h : env21721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21720_21721 : H12AffineEnvironment.transform 7 188 env21720 = env21721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 188 env21720 == env21721) = true)

def env21722 : List Nat := [2,4,8,16,0,16,128,156,137,140,137,0,129,0,136,138,0,136,140,137,1,153,16,155,9,17,136,1,1,137,21,17,156,153,0,137]

theorem envBound21722 : H12AffineFastState.Bounded env21722 := by
  intro p hp
  have h : env21722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21721_21722 : H12AffineEnvironment.transform 4 0 env21721 = env21722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env21721 == env21722) = true)

def env21723 : List Nat := [2,4,8,0,0,0,128,140,137,140,137,0,129,0,136,138,0,136,140,137,1,137,0,139,9,1,136,1,1,137,5,1,140,137,0,137]

theorem envBound21723 : H12AffineFastState.Bounded env21723 := by
  intro p hp
  have h : env21723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21722_21723 : H12AffineEnvironment.transform 3 0 env21722 = env21723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env21722 == env21723) = true)

theorem identity21723 : scanCanonicalize (H12AffineFastState.compose env21723 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound21723 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env21724 : List Nat := [2,4,8,0,0,0,9,5,0,5,0,0,8,0,1,3,0,1,5,0,1,0,0,2,9,1,1,1,1,0,5,1,5,0,0,0]

theorem envBound21724 : H12AffineFastState.Bounded env21724 := by
  intro p hp
  have h : env21724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21723_21724 : H12AffineEnvironment.transform 6 9 env21723 = env21724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21723 == env21724) = true)

def leafEnv21724 : List Nat := [2,4,8,0,0,0,9,5,0,5,0,0,8,0,1,3,0,1,5,0,1,0,0,2,4,9,1,1,1,1,1,0,5,1,5,0,5,3,0,0,0,1,1]

def active21724 : List Nat := [0,1,2]

def tree21724 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21724 : H12WitnessSearch.Good tree21724 := H12GlobalWitnessIndex.good

theorem leafIdentity21724 : H12AffineFastState.composeSystem env21724 rootObs = leafEnv21724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21724 rootObs == leafEnv21724) = true)

theorem terminalChecked21724 : H12PackedTerminal.terminalCheckFast leafEnv21724 active21724 tree21724 = true := by decide +kernel

def env21725 : List Nat := [2,4,8,1,0,1,128,141,137,140,137,0,129,0,136,138,0,136,140,137,1,136,1,138,9,0,136,1,1,137,4,0,141,136,0,137]

theorem envBound21725 : H12AffineFastState.Bounded env21725 := by
  intro p hp
  have h : env21725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21722_21725 : H12AffineEnvironment.transform 3 1 env21722 = env21725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env21722 == env21725) = true)

def env21726 : List Nat := [2,4,8,16,1,16,128,157,137,141,136,0,129,0,136,138,0,136,141,137,1,153,16,154,9,17,137,1,1,137,21,17,157,153,0,137]

theorem envBound21726 : H12AffineFastState.Bounded env21726 := by
  intro p hp
  have h : env21726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21721_21726 : H12AffineEnvironment.transform 4 1 env21721 = env21726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env21721 == env21726) = true)

theorem identity21726 : scanCanonicalize (H12AffineFastState.compose env21726 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound21726 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21727 : List Nat := [2,4,8,16,1,16,24,5,17,21,16,0,25,0,16,18,0,16,21,17,1,1,16,2,9,17,17,1,1,17,21,17,5,1,0,17]

theorem envBound21727 : H12AffineFastState.Bounded env21727 := by
  intro p hp
  have h : env21727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21726_21727 : H12AffineEnvironment.transform 6 24 env21726 = env21727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env21726 == env21727) = true)

theorem identity21727 : scanCanonicalize (H12AffineFastState.compose env21727 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound21727 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env21728 : List Nat := [2,4,8,1,1,1,9,5,0,4,1,0,8,0,1,3,0,1,4,0,1,1,1,2,9,0,0,1,1,0,4,0,5,1,0,0]

theorem envBound21728 : H12AffineFastState.Bounded env21728 := by
  intro p hp
  have h : env21728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21727_21728 : H12AffineEnvironment.transform 3 1 env21727 = env21728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env21727 == env21728) = true)

def leafEnv21728 : List Nat := [2,4,8,1,1,1,9,5,0,4,1,0,8,0,1,3,0,1,4,0,1,1,1,2,5,9,1,0,0,1,1,0,4,0,5,1,5,3,0,0,0,1,1]

def active21728 : List Nat := [0,1,2]

def tree21728 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21728 : H12WitnessSearch.Good tree21728 := H12GlobalWitnessIndex.good

theorem leafIdentity21728 : H12AffineFastState.composeSystem env21728 rootObs = leafEnv21728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21728 rootObs == leafEnv21728) = true)

theorem terminalChecked21728 : H12PackedTerminal.terminalCheckFast leafEnv21728 active21728 tree21728 = true := by decide +kernel

def env21729 : List Nat := [2,4,8,16,32,16,128,256,137,273,2048,1,129,1,2081,65536,1,136,273,2080,0,2444,16,67876,9,17,2049,0,0,137,20,2308,256,67846,1,137]

theorem envBound21729 : H12AffineFastState.Bounded env21729 := by
  intro p hp
  have h : env21729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21710_21729 : H12AffineEnvironment.transform 9 273 env21710 = env21729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env21710 == env21729) = true)

theorem identity21729 : scanCanonicalize (H12AffineFastState.compose env21729 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 140) := by decide +kernel

theorem selectedBound21729 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21730 : List Nat := [2,4,8,16,32,16,128,140,137,157,2048,1,129,1,2081,65536,1,136,157,2080,0,2048,16,67752,9,17,2049,0,0,137,20,2184,140,67722,1,137]

theorem envBound21730 : H12AffineFastState.Bounded env21730 := by
  intro p hp
  have h : env21730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21729_21730 : H12AffineEnvironment.transform 7 140 env21729 = env21730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 140 env21729 == env21730) = true)

def env21731 : List Nat := [2,4,8,16,32,16,128,140,137,157,0,1,129,1,33,65536,1,136,157,32,0,0,16,65704,9,17,1,0,0,137,20,136,140,65674,1,137]

theorem envBound21731 : H12AffineFastState.Bounded env21731 := by
  intro p hp
  have h : env21731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21730_21731 : H12AffineEnvironment.transform 10 0 env21730 = env21731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env21730 == env21731) = true)

theorem identity21731 : scanCanonicalize (H12AffineFastState.compose env21731 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 154) := by decide +kernel

theorem selectedBound21731 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env21732 : List Nat := [2,4,8,16,32,16,128,140,137,157,0,1,129,1,33,154,1,136,157,32,0,0,16,50,9,17,1,0,0,137,20,136,140,16,1,137]

theorem envBound21732 : H12AffineFastState.Bounded env21732 := by
  intro p hp
  have h : env21732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21731_21732 : H12AffineEnvironment.transform 15 154 env21731 = env21732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 154 env21731 == env21732) = true)

def env21733 : List Nat := [2,4,8,16,0,16,128,140,137,157,0,1,129,1,1,154,1,136,157,0,0,0,16,18,9,17,1,0,0,137,20,136,140,16,1,137]

theorem envBound21733 : H12AffineFastState.Bounded env21733 := by
  intro p hp
  have h : env21733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21732_21733 : H12AffineEnvironment.transform 4 0 env21732 = env21733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env21732 == env21733) = true)

def env21734 : List Nat := [2,4,8,16,1,16,128,140,137,157,0,1,129,1,0,154,1,136,157,1,0,0,16,19,9,17,1,0,0,137,20,136,140,16,1,137]

theorem envBound21734 : H12AffineFastState.Bounded env21734 := by
  intro p hp
  have h : env21734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21732_21734 : H12AffineEnvironment.transform 4 1 env21732 = env21734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env21732 == env21734) = true)

theorem identity21734 : scanCanonicalize (H12AffineFastState.compose env21734 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound21734 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21735 : List Nat := [2,4,8,16,1,16,24,20,17,5,0,1,25,1,0,2,1,16,5,1,0,0,16,19,9,17,1,0,0,17,20,16,20,16,1,17]

theorem envBound21735 : H12AffineFastState.Bounded env21735 := by
  intro p hp
  have h : env21735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21734_21735 : H12AffineEnvironment.transform 6 24 env21734 = env21735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env21734 == env21735) = true)

def leafEnv21735 : List Nat := [2,4,8,16,1,16,24,20,17,5,0,1,25,1,0,2,1,16,5,1,0,0,16,19,21,9,1,17,1,0,0,17,20,16,20,16,5,19,1,17,0,0,1]

def active21735 : List Nat := [0,1,2,3]

def tree21735 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21735 : H12WitnessSearch.Good tree21735 := H12GlobalWitnessIndex.good

theorem leafIdentity21735 : H12AffineFastState.composeSystem env21735 rootObs = leafEnv21735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21735 rootObs == leafEnv21735) = true)

theorem terminalChecked21735 : H12PackedTerminal.terminalCheckFast leafEnv21735 active21735 tree21735 = true := by decide +kernel

def env21736 : List Nat := [2,4,8,16,32,16,128,140,137,157,1,1,129,1,32,65536,1,136,157,33,0,1,16,65705,9,17,0,0,0,137,20,137,140,65675,1,137]

theorem envBound21736 : H12AffineFastState.Bounded env21736 := by
  intro p hp
  have h : env21736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21730_21736 : H12AffineEnvironment.transform 10 1 env21730 = env21736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env21730 == env21736) = true)

theorem identity21736 : scanCanonicalize (H12AffineFastState.compose env21736 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 51) := by decide +kernel

theorem selectedBound21736 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env21737 : List Nat := [2,4,8,16,32,16,128,140,137,157,1,1,129,1,32,51,1,136,157,33,0,1,16,154,9,17,0,0,0,137,20,137,140,184,1,137]

theorem envBound21737 : H12AffineFastState.Bounded env21737 := by
  intro p hp
  have h : env21737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21736_21737 : H12AffineEnvironment.transform 15 51 env21736 = env21737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 51 env21736 == env21737) = true)

def env21738 : List Nat := [2,4,8,16,0,16,128,140,137,157,1,1,129,1,0,19,1,136,157,1,0,1,16,154,9,17,0,0,0,137,20,137,140,152,1,137]

theorem envBound21738 : H12AffineFastState.Bounded env21738 := by
  intro p hp
  have h : env21738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21737_21738 : H12AffineEnvironment.transform 4 0 env21737 = env21738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env21737 == env21738) = true)

theorem identity21738 : scanCanonicalize (H12AffineFastState.compose env21738 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound21738 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21739 : List Nat := [2,4,8,1,0,1,128,140,137,140,1,1,129,1,0,2,1,136,140,1,0,1,1,139,9,0,0,0,0,137,5,137,140,137,1,137]

theorem envBound21739 : H12AffineFastState.Bounded env21739 := by
  intro p hp
  have h : env21739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21738_21739 : H12AffineEnvironment.transform 3 1 env21738 = env21739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env21738 == env21739) = true)

theorem identity21739 : scanCanonicalize (H12AffineFastState.compose env21739 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound21739 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21740 : List Nat := [2,4,8,1,0,1,9,5,0,5,1,1,8,1,0,2,1,1,5,1,0,1,1,2,9,0,0,0,0,0,5,0,5,0,1,0]

theorem envBound21740 : H12AffineFastState.Bounded env21740 := by
  intro p hp
  have h : env21740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21739_21740 : H12AffineEnvironment.transform 6 9 env21739 = env21740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21739 == env21740) = true)

def leafEnv21740 : List Nat := [2,4,8,1,0,1,9,5,0,5,1,1,8,1,0,2,1,1,5,1,0,1,1,2,4,9,1,0,0,0,0,0,5,0,5,0,5,2,1,0,0,0,1]

def active21740 : List Nat := [0,1,2]

def tree21740 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21740 : H12WitnessSearch.Good tree21740 := H12GlobalWitnessIndex.good

theorem leafIdentity21740 : H12AffineFastState.composeSystem env21740 rootObs = leafEnv21740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21740 rootObs == leafEnv21740) = true)

theorem terminalChecked21740 : H12PackedTerminal.terminalCheckFast leafEnv21740 active21740 tree21740 = true := by decide +kernel

def env21741 : List Nat := [2,4,8,16,1,16,128,140,137,157,1,1,129,1,1,18,1,136,157,0,0,1,16,154,9,17,0,0,0,137,20,137,140,153,1,137]

theorem envBound21741 : H12AffineFastState.Bounded env21741 := by
  intro p hp
  have h : env21741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21737_21741 : H12AffineEnvironment.transform 4 1 env21737 = env21741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env21737 == env21741) = true)

def env21742 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,1297,129,1296,2081,65536,1297,136,1024,2080,1296,4194304,16,67876,9,16,4194701,1297,1297,4196613,1285,4194440,256,67846,1297,137]

theorem envBound21742 : H12AffineFastState.Bounded env21742 := by
  intro p hp
  have h : env21742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21708_21742 : H12AffineEnvironment.transform 5 17 env21708 = env21742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env21708 == env21742) = true)

theorem identity21742 : scanCanonicalize (H12AffineFastState.compose env21742 (packedSelected [1,3] rootPS)) = affineNative (2^(21+1) ^^^ 67754) := by decide +kernel

theorem selectedBound21742 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env21743 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,1297,129,1296,2081,65536,1297,136,1024,2080,1296,67754,16,67876,9,16,67879,1297,1297,65967,1285,67618,256,67846,1297,137]

theorem envBound21743 : H12AffineFastState.Bounded env21743 := by
  intro p hp
  have h : env21743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21742_21743 : H12AffineEnvironment.transform 21 67754 env21742 = env21743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 67754 env21742 == env21743) = true)

theorem identity21743 : scanCanonicalize (H12AffineFastState.compose env21743 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 137) := by decide +kernel

theorem selectedBound21743 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env21744 : List Nat := [2,4,8,16,32,17,128,256,137,1024,137,1297,129,1296,168,65536,1297,136,1024,169,1296,65571,16,65965,9,16,65966,1297,1297,65967,1285,65707,256,65935,1297,137]

theorem envBound21744 : H12AffineFastState.Bounded env21744 := by
  intro p hp
  have h : env21744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21743_21744 : H12AffineEnvironment.transform 10 137 env21743 = env21744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 137 env21743 == env21744) = true)

theorem identity21744 : scanCanonicalize (H12AffineFastState.compose env21744 (packedSelected [0,6] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound21744 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env21745 : List Nat := [2,4,8,16,32,17,128,4,137,1024,137,1045,129,1044,168,65536,1045,136,1024,169,1044,65571,16,65705,9,16,65706,1045,1045,65707,1025,65707,4,65675,1045,137]

theorem envBound21745 : H12AffineFastState.Bounded env21745 := by
  intro p hp
  have h : env21745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21744_21745 : H12AffineEnvironment.transform 7 4 env21744 = env21745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env21744 == env21745) = true)

theorem identity21745 : scanCanonicalize (H12AffineFastState.compose env21745 (packedSelected [0,7] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound21745 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env21746 : List Nat := [2,4,8,16,32,17,128,4,137,1024,137,1045,129,1044,168,35,1045,136,1024,169,1044,0,16,138,9,16,137,1045,1045,136,1025,136,4,168,1045,137]

theorem envBound21746 : H12AffineFastState.Bounded env21746 := by
  intro p hp
  have h : env21746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21745_21746 : H12AffineEnvironment.transform 15 35 env21745 = env21746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env21745 == env21746) = true)

theorem identity21746 : scanCanonicalize (H12AffineFastState.compose env21746 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound21746 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21747 : List Nat := [2,4,8,16,32,17,128,4,137,21,137,0,129,1,168,35,0,136,21,169,1,0,16,138,9,16,137,0,0,136,20,136,4,168,0,137]

theorem envBound21747 : H12AffineFastState.Bounded env21747 := by
  intro p hp
  have h : env21747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21746_21747 : H12AffineEnvironment.transform 9 21 env21746 = env21747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env21746 == env21747) = true)

def env21748 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,129,1296,32768,65536,1344,137,1024,32769,1345,4194304,16,98564,9,65,4194701,1297,1297,1073741824,1284,4194440,256,98598,1344,512]

theorem envBound21748 : H12AffineFastState.Bounded env21748 := by
  intro p hp
  have h : env21748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21704_21748 : H12AffineEnvironment.transform 17 137 env21704 = env21748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137 env21704 == env21748) = true)

theorem identity21748 : scanCanonicalize (H12AffineFastState.compose env21748 (packedSelected [1,12,13] rootPS)) = affineNative (2^(21+1) ^^^ 66187) := by decide +kernel

theorem selectedBound21748 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env21749 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,129,1296,32768,65536,1344,137,1024,32769,1345,66187,16,98564,9,65,66310,1297,1297,1073741824,1284,66051,256,98598,1344,512]

theorem envBound21749 : H12AffineFastState.Bounded env21749 := by
  intro p hp
  have h : env21749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21748_21749 : H12AffineEnvironment.transform 21 66187 env21748 = env21749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 66187 env21748 == env21749) = true)

theorem identity21749 : scanCanonicalize (H12AffineFastState.compose env21749 (packedSelected [3,15,17] rootPS)) = affineNative (2^(29+1) ^^^ 68099) := by decide +kernel

theorem selectedBound21749 : packedSelected [3,15,17] rootPS < 2^1333 := by decide +kernel

def env21750 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,129,1296,32768,65536,1344,137,1024,32769,1345,66187,16,98564,9,65,66310,1297,1297,68099,1284,66051,256,98598,1344,512]

theorem envBound21750 : H12AffineFastState.Bounded env21750 := by
  intro p hp
  have h : env21750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21749_21750 : H12AffineEnvironment.transform 29 68099 env21749 = env21750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 68099 env21749 == env21750) = true)

theorem identity21750 : scanCanonicalize (H12AffineFastState.compose env21750 (packedSelected [1,8,28] rootPS)) = affineNative (2^(14+1) ^^^ 908) := by decide +kernel

theorem selectedBound21750 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env21751 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,129,1296,908,65536,1344,137,1024,909,1345,66187,16,66184,9,65,66310,1297,1297,68099,1284,66051,256,66218,1344,512]

theorem envBound21751 : H12AffineFastState.Bounded env21751 := by
  intro p hp
  have h : env21751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21750_21751 : H12AffineEnvironment.transform 14 908 env21750 = env21751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 908 env21750 == env21751) = true)

theorem identity21751 : scanCanonicalize (H12AffineFastState.compose env21751 (packedSelected [8,12,38] rootPS)) = affineNative (2^(15+1) ^^^ 2479) := by decide +kernel

theorem selectedBound21751 : packedSelected [8,12,38] rootPS < 2^1333 := by decide +kernel

def env21752 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,129,1296,908,2479,1344,137,1024,909,1345,2852,16,2855,9,65,2729,1297,1297,940,1284,2988,256,2821,1344,512]

theorem envBound21752 : H12AffineFastState.Bounded env21752 := by
  intro p hp
  have h : env21752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21751_21752 : H12AffineEnvironment.transform 15 2479 env21751 = env21752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2479 env21751 == env21752) = true)

theorem identity21752 : scanCanonicalize (H12AffineFastState.compose env21752 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 141) := by decide +kernel

theorem selectedBound21752 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env21753 : List Nat := [2,4,8,16,32,64,128,141,512,1024,2048,1229,129,1181,513,2082,1229,137,1024,512,1228,2729,16,2730,9,65,2729,1180,1180,545,1161,2593,141,2696,1229,512]

theorem envBound21753 : H12AffineFastState.Bounded env21753 := by
  intro p hp
  have h : env21753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21752_21753 : H12AffineEnvironment.transform 7 141 env21752 = env21753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 141 env21752 == env21753) = true)

theorem identity21753 : scanCanonicalize (H12AffineFastState.compose env21753 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound21753 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env21754 : List Nat := [2,4,8,16,32,16,128,141,512,1024,2048,1181,129,1181,513,2082,1181,137,1024,512,1180,2729,16,2730,9,17,2729,1180,1180,545,1161,2593,141,2696,1181,512]

theorem envBound21754 : H12AffineFastState.Bounded env21754 := by
  intro p hp
  have h : env21754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21753_21754 : H12AffineEnvironment.transform 5 16 env21753 = env21754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env21753 == env21754) = true)

theorem identity21754 : scanCanonicalize (H12AffineFastState.compose env21754 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 565) := by decide +kernel

theorem selectedBound21754 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21755 : List Nat := [2,4,8,16,32,16,128,141,512,565,2048,680,129,680,513,2082,680,137,565,512,681,2729,16,2730,9,17,2729,681,681,545,700,2593,141,2696,680,512]

theorem envBound21755 : H12AffineFastState.Bounded env21755 := by
  intro p hp
  have h : env21755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21754_21755 : H12AffineEnvironment.transform 9 565 env21754 = env21755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 565 env21754 == env21755) = true)

theorem identity21755 : scanCanonicalize (H12AffineFastState.compose env21755 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 169) := by decide +kernel

theorem selectedBound21755 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env21756 : List Nat := [2,4,8,16,32,16,128,141,169,156,2048,1,129,1,168,2082,1,137,156,169,0,2048,16,2051,9,17,2048,0,0,136,21,2184,141,2081,1,169]

theorem envBound21756 : H12AffineFastState.Bounded env21756 := by
  intro p hp
  have h : env21756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21755_21756 : H12AffineEnvironment.transform 8 169 env21755 = env21756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 169 env21755 == env21756) = true)

theorem identity21756 : scanCanonicalize (H12AffineFastState.compose env21756 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound21756 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env21757 : List Nat := [2,4,8,16,32,16,128,141,169,156,0,1,129,1,168,34,1,137,156,169,0,0,16,3,9,17,0,0,0,136,21,136,141,33,1,169]

theorem envBound21757 : H12AffineFastState.Bounded env21757 := by
  intro p hp
  have h : env21757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21756_21757 : H12AffineEnvironment.transform 10 0 env21756 = env21757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env21756 == env21757) = true)

theorem identity21757 : scanCanonicalize (H12AffineFastState.compose env21757 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound21757 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21758 : List Nat := [2,4,8,1,32,1,128,141,169,141,0,1,129,1,168,34,1,137,141,169,0,0,1,3,9,0,0,0,0,136,4,136,141,33,1,169]

theorem envBound21758 : H12AffineFastState.Bounded env21758 := by
  intro p hp
  have h : env21758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21757_21758 : H12AffineEnvironment.transform 3 1 env21757 = env21758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env21757 == env21758) = true)

theorem identity21758 : scanCanonicalize (H12AffineFastState.compose env21758 (packedSelected [0,6] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound21758 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env21759 : List Nat := [2,4,8,1,32,1,41,36,0,36,0,1,40,1,1,34,1,32,36,0,0,0,1,3,9,0,0,0,0,33,4,33,36,33,1,0]

theorem envBound21759 : H12AffineFastState.Bounded env21759 := by
  intro p hp
  have h : env21759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21758_21759 : H12AffineEnvironment.transform 6 41 env21758 = env21759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env21758 == env21759) = true)

theorem identity21759 : scanCanonicalize (H12AffineFastState.compose env21759 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound21759 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21760 : List Nat := [2,4,8,1,0,1,9,4,0,4,0,1,8,1,1,2,1,0,4,0,0,0,1,3,9,0,0,0,0,1,4,1,4,1,1,0]

theorem envBound21760 : H12AffineFastState.Bounded env21760 := by
  intro p hp
  have h : env21760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21759_21760 : H12AffineEnvironment.transform 4 0 env21759 = env21760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env21759 == env21760) = true)

def env21761 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,65536,1344,262144,1024,32769,1344,4194304,17,16777216,8328,64,21331968,1296,1297,1073741824,16876544,4294967296,256,4315938986,1344,512]

theorem envBound21761 : H12AffineFastState.Bounded env21761 := by
  intro p hp
  have h : env21761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21626_21761 : H12AffineEnvironment.transform 11 1345 env21626 = env21761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env21626 == env21761) = true)

theorem identity21761 : scanCanonicalize (H12AffineFastState.compose env21761 (packedSelected [0,7,20] rootPS)) = affineNative (2^(23+1) ^^^ 98565) := by decide +kernel

theorem selectedBound21761 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env21762 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,65536,1344,262144,1024,32769,1344,4194304,17,98565,8328,64,4456709,1296,1297,1073741824,1285,4294967296,256,4299260335,1344,512]

theorem envBound21762 : H12AffineFastState.Bounded env21762 := by
  intro p hp
  have h : env21762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21761_21762 : H12AffineEnvironment.transform 23 98565 env21761 = env21762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98565 env21761 == env21762) = true)

theorem identity21762 : scanCanonicalize (H12AffineFastState.compose env21762 (packedSelected [3,5,10] rootPS)) = affineNative (2^(31+1) ^^^ 1073842179) := by decide +kernel

theorem selectedBound21762 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env21763 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,65536,1344,262144,1024,32769,1344,4194304,17,98565,8328,64,4456709,1296,1297,1073741824,1285,1073842179,256,1077938604,1344,512]

theorem envBound21763 : H12AffineFastState.Bounded env21763 := by
  intro p hp
  have h : env21763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21762_21763 : H12AffineEnvironment.transform 31 1073842179 env21762 = env21763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1073842179 env21762 == env21763) = true)

theorem identity21763 : scanCanonicalize (H12AffineFastState.compose env21763 (packedSelected [1,12,13] rootPS)) = affineNative (2^(29+1) ^^^ 4227364) := by decide +kernel

theorem selectedBound21763 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env21764 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,65536,1344,262144,1024,32769,1344,4194304,17,98565,8328,64,4456709,1296,1297,4227364,1285,4262183,256,34952,1344,512]

theorem envBound21764 : H12AffineFastState.Bounded env21764 := by
  intro p hp
  have h : env21764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21763_21764 : H12AffineEnvironment.transform 29 4227364 env21763 = env21764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4227364 env21763 == env21764) = true)

theorem identity21764 : scanCanonicalize (H12AffineFastState.compose env21764 (packedSelected [3,15,17] rootPS)) = affineNative (2^(17+1) ^^^ 43681) := by decide +kernel

theorem selectedBound21764 : packedSelected [3,15,17] rootPS < 2^1333 := by decide +kernel

def env21765 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,65536,1344,43681,1024,32769,1344,4194304,17,98565,8328,64,4238244,1296,1297,4227364,1285,4262183,256,34952,1344,512]

theorem envBound21765 : H12AffineFastState.Bounded env21765 := by
  intro p hp
  have h : env21765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21764_21765 : H12AffineEnvironment.transform 17 43681 env21764 = env21765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43681 env21764 == env21765) = true)

theorem identity21765 : scanCanonicalize (H12AffineFastState.compose env21765 (packedSelected [3,5,24] rootPS)) = affineNative (2^(14+1) ^^^ 2081) := by decide +kernel

theorem selectedBound21765 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env21766 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,2081,65536,1344,8832,1024,2080,1344,4194304,17,67876,8328,64,4203397,1296,1297,4196613,1285,4262183,256,169,1344,512]

theorem envBound21766 : H12AffineFastState.Bounded env21766 := by
  intro p hp
  have h : env21766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21765_21766 : H12AffineEnvironment.transform 14 2081 env21765 = env21766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2081 env21765 == env21766) = true)

theorem identity21766 : scanCanonicalize (H12AffineFastState.compose env21766 (packedSelected [5,8] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound21766 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env21767 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,8192,1297,2081,65536,1344,8201,1024,2080,1344,4194304,17,67876,8328,64,4202764,1296,1297,4196613,1285,4262183,256,169,1344,137]

theorem envBound21767 : H12AffineFastState.Bounded env21767 := by
  intro p hp
  have h : env21767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21766_21767 : H12AffineEnvironment.transform 8 137 env21766 = env21767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env21766 == env21767) = true)

def env21768 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1297,8192,1297,2081,65536,1296,8201,1024,2080,1296,4194304,17,67876,8328,16,4202764,1296,1297,4196613,1285,4262183,256,169,1296,137]

theorem envBound21768 : H12AffineFastState.Bounded env21768 := by
  intro p hp
  have h : env21768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21767_21768 : H12AffineEnvironment.transform 5 16 env21767 = env21768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env21767 == env21768) = true)

theorem identity21768 : scanCanonicalize (H12AffineFastState.compose env21768 (packedSelected [1,3] rootPS)) = affineNative (2^(21+1) ^^^ 67754) := by decide +kernel

theorem selectedBound21768 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env21769 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1297,8192,1297,2081,65536,1296,8201,1024,2080,1296,67754,17,67876,8328,16,76198,1296,1297,65967,1285,397,256,169,1296,137]

theorem envBound21769 : H12AffineFastState.Bounded env21769 := by
  intro p hp
  have h : env21769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21768_21769 : H12AffineEnvironment.transform 21 67754 env21768 = env21769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 67754 env21768 == env21769) = true)

theorem identity21769 : scanCanonicalize (H12AffineFastState.compose env21769 (packedSelected [5] rootPS)) = affineNative (2^(12+1) ^^^ 2056) := by decide +kernel

theorem selectedBound21769 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env21770 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1297,2056,1297,2081,65536,1296,2049,1024,2080,1296,67754,17,67876,2176,16,65966,1296,1297,65967,1285,397,256,169,1296,137]

theorem envBound21770 : H12AffineFastState.Bounded env21770 := by
  intro p hp
  have h : env21770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21769_21770 : H12AffineEnvironment.transform 12 2056 env21769 = env21770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2056 env21769 == env21770) = true)

theorem identity21770 : scanCanonicalize (H12AffineFastState.compose env21770 (packedSelected [0,6] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound21770 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env21771 : List Nat := [2,4,8,16,32,16,128,4,137,1024,2048,1045,2056,1045,2081,65536,1044,2049,1024,2080,1044,67754,17,67616,2176,16,65706,1044,1045,65707,1025,137,4,169,1044,137]

theorem envBound21771 : H12AffineFastState.Bounded env21771 := by
  intro p hp
  have h : env21771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21770_21771 : H12AffineEnvironment.transform 7 4 env21770 = env21771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env21770 == env21771) = true)

theorem identity21771 : scanCanonicalize (H12AffineFastState.compose env21771 (packedSelected [0,7] rootPS)) = affineNative (2^(15+1) ^^^ 2218) := by decide +kernel

theorem selectedBound21771 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env21772 : List Nat := [2,4,8,16,32,16,128,4,137,1024,2048,1045,2056,1045,2081,2218,1044,2049,1024,2080,1044,0,17,138,2176,16,2048,1044,1045,2049,1025,137,4,169,1044,137]

theorem envBound21772 : H12AffineFastState.Bounded env21772 := by
  intro p hp
  have h : env21772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21771_21772 : H12AffineEnvironment.transform 15 2218 env21771 = env21772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2218 env21771 == env21772) = true)

theorem identity21772 : scanCanonicalize (H12AffineFastState.compose env21772 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1212) := by decide +kernel

theorem selectedBound21772 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21773 : List Nat := [2,4,8,16,32,16,128,4,137,1024,1212,1045,1204,1045,1181,1046,1044,1213,1024,1180,1044,0,17,138,1084,16,1212,1044,1045,1213,1025,137,4,169,1044,137]

theorem envBound21773 : H12AffineFastState.Bounded env21773 := by
  intro p hp
  have h : env21773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21772_21773 : H12AffineEnvironment.transform 10 1212 env21772 = env21773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1212 env21772 == env21773) = true)

def env21774 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,1296,8192,1297,2081,65536,1297,8201,1024,2080,1297,4194304,17,67876,8328,17,4202764,1296,1297,4196613,1285,4262183,256,169,1297,137]

theorem envBound21774 : H12AffineFastState.Bounded env21774 := by
  intro p hp
  have h : env21774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21767_21774 : H12AffineEnvironment.transform 5 17 env21767 = env21774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env21767 == env21774) = true)

theorem identity21774 : scanCanonicalize (H12AffineFastState.compose env21774 (packedSelected [5] rootPS)) = affineNative (2^(21+1) ^^^ 10509) := by decide +kernel

theorem selectedBound21774 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env21775 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,1296,8192,1297,2081,65536,1297,8201,1024,2080,1297,10509,17,67876,8328,17,2049,1296,1297,8200,1285,73770,256,169,1297,137]

theorem envBound21775 : H12AffineFastState.Bounded env21775 := by
  intro p hp
  have h : env21775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21774_21775 : H12AffineEnvironment.transform 21 10509 env21774 = env21775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10509 env21774 == env21775) = true)

def env21776 : List Nat := [2,4,8,16,32,17,128,256,137,272,2048,0,8192,1,2081,65536,1,8201,272,2080,1,10509,17,67876,8328,17,2049,0,1,8200,21,73770,256,169,1,137]

theorem envBound21776 : H12AffineFastState.Bounded env21776 := by
  intro p hp
  have h : env21776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21775_21776 : H12AffineEnvironment.transform 9 272 env21775 = env21776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env21775 == env21776) = true)

theorem identity21776 : scanCanonicalize (H12AffineFastState.compose env21776 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 398) := by decide +kernel

theorem selectedBound21776 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21777 : List Nat := [2,4,8,16,32,17,128,256,137,272,2048,0,8192,1,2081,398,1,8201,272,2080,1,10509,17,2218,8328,17,2049,0,1,8200,21,8612,256,169,1,137]

theorem envBound21777 : H12AffineFastState.Bounded env21777 := by
  intro p hp
  have h : env21777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21776_21777 : H12AffineEnvironment.transform 15 398 env21776 = env21777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 398 env21776 == env21777) = true)

def env21778 : List Nat := [2,4,8,16,32,17,128,256,137,272,2048,0,40,1,2081,398,1,33,272,2080,1,2341,17,2218,160,17,2049,0,1,32,21,396,256,169,1,137]

theorem envBound21778 : H12AffineFastState.Bounded env21778 := by
  intro p hp
  have h : env21778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21777_21778 : H12AffineEnvironment.transform 12 40 env21777 = env21778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env21777 == env21778) = true)

theorem identity21778 : scanCanonicalize (H12AffineFastState.compose env21778 (packedSelected [2,4] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound21778 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env21779 : List Nat := [2,4,8,16,32,17,128,256,137,272,33,0,40,1,0,398,1,33,272,1,1,260,17,139,160,17,32,0,1,32,21,396,256,169,1,137]

theorem envBound21779 : H12AffineFastState.Bounded env21779 := by
  intro p hp
  have h : env21779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21778_21779 : H12AffineEnvironment.transform 10 33 env21778 = env21779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env21778 == env21779) = true)

theorem identity21779 : scanCanonicalize (H12AffineFastState.compose env21779 (packedSelected [0,2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound21779 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env21780 : List Nat := [2,4,8,16,32,17,128,37,137,53,33,0,40,1,0,171,1,33,53,1,1,33,17,139,160,17,32,0,1,32,21,169,37,169,1,137]

theorem envBound21780 : H12AffineFastState.Bounded env21780 := by
  intro p hp
  have h : env21780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21779_21780 : H12AffineEnvironment.transform 7 37 env21779 = env21780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env21779 == env21780) = true)

theorem identity21780 : scanCanonicalize (H12AffineFastState.compose env21780 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound21780 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21781 : List Nat := [2,4,8,16,16,17,128,21,137,5,17,0,24,1,0,155,1,17,5,1,1,17,17,139,144,17,16,0,1,16,21,153,21,153,1,137]

theorem envBound21781 : H12AffineFastState.Bounded env21781 := by
  intro p hp
  have h : env21781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21780_21781 : H12AffineEnvironment.transform 4 16 env21780 = env21781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env21780 == env21781) = true)

def leafEnv21781 : List Nat := [2,4,8,16,16,17,128,21,137,5,17,0,24,1,0,155,1,17,5,1,1,17,17,139,20,144,1,17,16,0,1,16,21,153,21,153,5,18,1,137,0,1,1]

def active21781 : List Nat := [0,1,2,3,6]

def tree21781 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21781 : H12WitnessSearch.Good tree21781 := H12GlobalWitnessIndex.good

theorem leafIdentity21781 : H12AffineFastState.composeSystem env21781 rootObs = leafEnv21781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21781 rootObs == leafEnv21781) = true)

theorem terminalChecked21781 : H12PackedTerminal.terminalCheckFast leafEnv21781 active21781 tree21781 = true := by decide +kernel

def env21782 : List Nat := [2,4,8,16,32,17,128,256,137,272,2048,0,41,1,2081,398,1,32,272,2080,1,2340,17,2218,161,17,2049,0,1,33,21,397,256,169,1,137]

theorem envBound21782 : H12AffineFastState.Bounded env21782 := by
  intro p hp
  have h : env21782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21777_21782 : H12AffineEnvironment.transform 12 41 env21777 = env21782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env21777 == env21782) = true)

theorem identity21782 : scanCanonicalize (H12AffineFastState.compose env21782 (packedSelected [2,4] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound21782 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env21783 : List Nat := [2,4,8,16,32,17,128,256,137,272,292,0,41,1,261,398,1,32,272,260,1,0,17,398,161,17,293,0,1,33,21,397,256,169,1,137]

theorem envBound21783 : H12AffineFastState.Bounded env21783 := by
  intro p hp
  have h : env21783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21782_21783 : H12AffineEnvironment.transform 10 292 env21782 = env21783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env21782 == env21783) = true)

def env21784 : List Nat := [2,4,8,16,0,17,128,256,137,272,260,0,9,1,261,398,1,0,272,260,1,0,17,398,129,17,261,0,1,1,21,397,256,137,1,137]

theorem envBound21784 : H12AffineFastState.Bounded env21784 := by
  intro p hp
  have h : env21784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21783_21784 : H12AffineEnvironment.transform 4 0 env21783 = env21784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env21783 == env21784) = true)

theorem identity21784 : scanCanonicalize (H12AffineFastState.compose env21784 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound21784 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21785 : List Nat := [2,4,8,16,0,17,25,256,16,272,260,0,9,1,261,279,1,0,272,260,1,0,17,279,24,17,261,0,1,1,21,276,256,16,1,16]

theorem envBound21785 : H12AffineFastState.Bounded env21785 := by
  intro p hp
  have h : env21785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21784_21785 : H12AffineEnvironment.transform 6 25 env21784 = env21785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env21784 == env21785) = true)

def env21786 : List Nat := [2,4,8,16,1,17,128,256,137,272,261,0,8,1,261,398,1,1,272,260,1,0,17,398,128,17,260,0,1,0,21,397,256,136,1,137]

theorem envBound21786 : H12AffineFastState.Bounded env21786 := by
  intro p hp
  have h : env21786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21783_21786 : H12AffineEnvironment.transform 4 1 env21783 = env21786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env21783 == env21786) = true)

theorem identity21786 : scanCanonicalize (H12AffineFastState.compose env21786 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound21786 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21787 : List Nat := [2,4,8,16,1,17,128,21,137,5,16,0,8,1,16,155,1,1,5,17,1,0,17,155,128,17,17,0,1,0,21,152,21,136,1,137]

theorem envBound21787 : H12AffineFastState.Bounded env21787 := by
  intro p hp
  have h : env21787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21786_21787 : H12AffineEnvironment.transform 7 21 env21786 = env21787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env21786 == env21787) = true)

theorem identity21787 : scanCanonicalize (H12AffineFastState.compose env21787 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound21787 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21788 : List Nat := [2,4,8,0,1,1,128,5,137,5,0,0,8,1,0,139,1,1,5,1,1,0,1,139,128,1,1,0,1,0,5,136,5,136,1,137]

theorem envBound21788 : H12AffineFastState.Bounded env21788 := by
  intro p hp
  have h : env21788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21787_21788 : H12AffineEnvironment.transform 3 0 env21787 = env21788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env21787 == env21788) = true)

def leafEnv21788 : List Nat := [2,4,8,0,1,1,128,5,137,5,0,0,8,1,0,139,1,1,5,1,1,0,1,139,4,128,1,1,1,0,1,0,5,136,5,136,5,2,1,137,0,1,1]

def active21788 : List Nat := [0,1,2,6]

def tree21788 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21788 : H12WitnessSearch.Good tree21788 := H12GlobalWitnessIndex.good

theorem leafIdentity21788 : H12AffineFastState.composeSystem env21788 rootObs = leafEnv21788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21788 rootObs == leafEnv21788) = true)

theorem terminalChecked21788 : H12PackedTerminal.terminalCheckFast leafEnv21788 active21788 tree21788 = true := by decide +kernel

def env21789 : List Nat := [2,4,8,16,32,17,128,256,137,273,2048,1,8192,0,2081,65536,0,8201,273,2080,0,10509,17,67876,8328,17,2049,1,0,8200,20,73770,256,169,0,137]

theorem envBound21789 : H12AffineFastState.Bounded env21789 := by
  intro p hp
  have h : env21789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21775_21789 : H12AffineEnvironment.transform 9 273 env21775 = env21789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env21775 == env21789) = true)

theorem identity21789 : scanCanonicalize (H12AffineFastState.compose env21789 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound21789 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21790 : List Nat := [2,4,8,16,32,17,128,256,137,273,33,1,8192,0,0,65536,0,8201,273,1,0,8492,17,65797,8328,17,32,1,0,8200,20,73770,256,169,0,137]

theorem envBound21790 : H12AffineFastState.Bounded env21790 := by
  intro p hp
  have h : env21790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21789_21790 : H12AffineEnvironment.transform 10 33 env21789 = env21790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env21789 == env21790) = true)

def env21791 : List Nat := [2,4,8,16,32,17,128,4,137,21,33,1,8192,0,0,65536,0,8201,21,1,0,8232,17,65537,8328,17,32,1,0,8200,20,73770,4,169,0,137]

theorem envBound21791 : H12AffineFastState.Bounded env21791 := by
  intro p hp
  have h : env21791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21790_21791 : H12AffineEnvironment.transform 7 4 env21790 = env21791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env21790 == env21791) = true)

theorem identity21791 : scanCanonicalize (H12AffineFastState.compose env21791 (packedSelected [2,4] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound21791 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env21792 : List Nat := [2,4,8,16,32,17,128,4,137,21,33,1,40,0,0,65536,0,33,21,1,0,0,17,65537,160,17,32,1,0,32,20,65538,4,169,0,137]

theorem envBound21792 : H12AffineFastState.Bounded env21792 := by
  intro p hp
  have h : env21792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21791_21792 : H12AffineEnvironment.transform 12 40 env21791 = env21792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env21791 == env21792) = true)

def env21793 : List Nat := [2,4,8,16,0,17,128,4,137,21,1,1,8,0,0,65536,0,1,21,1,0,0,17,65537,128,17,0,1,0,0,20,65538,4,137,0,137]

theorem envBound21793 : H12AffineFastState.Bounded env21793 := by
  intro p hp
  have h : env21793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21792_21793 : H12AffineEnvironment.transform 4 0 env21792 = env21793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env21792 == env21793) = true)

theorem identity21793 : scanCanonicalize (H12AffineFastState.compose env21793 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 18) := by decide +kernel

theorem selectedBound21793 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21794 : List Nat := [2,4,8,16,0,17,128,4,137,21,1,1,8,0,0,18,0,1,21,1,0,0,17,19,128,17,0,1,0,0,20,16,4,137,0,137]

theorem envBound21794 : H12AffineFastState.Bounded env21794 := by
  intro p hp
  have h : env21794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21793_21794 : H12AffineEnvironment.transform 15 18 env21793 = env21794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 18 env21793 == env21794) = true)

theorem identity21794 : scanCanonicalize (H12AffineFastState.compose env21794 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound21794 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21795 : List Nat := [2,4,8,16,0,17,24,4,17,21,1,1,8,0,0,18,0,1,21,1,0,0,17,19,24,17,0,1,0,0,20,16,4,17,0,17]

theorem envBound21795 : H12AffineFastState.Bounded env21795 := by
  intro p hp
  have h : env21795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21794_21795 : H12AffineEnvironment.transform 6 24 env21794 = env21795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env21794 == env21795) = true)

def leafEnv21795 : List Nat := [2,4,8,16,0,17,24,4,17,21,1,1,8,0,0,18,0,1,21,1,0,0,17,19,21,24,1,17,0,1,0,0,20,16,4,17,5,3,0,17,0,0,1]

def active21795 : List Nat := [0,1,2,3]

def tree21795 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21795 : H12WitnessSearch.Good tree21795 := H12GlobalWitnessIndex.good

theorem leafIdentity21795 : H12AffineFastState.composeSystem env21795 rootObs = leafEnv21795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21795 rootObs == leafEnv21795) = true)

theorem terminalChecked21795 : H12PackedTerminal.terminalCheckFast leafEnv21795 active21795 tree21795 = true := by decide +kernel

def env21796 : List Nat := [2,4,8,16,1,17,128,4,137,21,0,1,9,0,0,65536,0,0,21,1,0,0,17,65537,129,17,1,1,0,1,20,65538,4,136,0,137]

theorem envBound21796 : H12AffineFastState.Bounded env21796 := by
  intro p hp
  have h : env21796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21792_21796 : H12AffineEnvironment.transform 4 1 env21792 = env21796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env21792 == env21796) = true)

theorem identity21796 : scanCanonicalize (H12AffineFastState.compose env21796 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 154) := by decide +kernel

theorem selectedBound21796 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21797 : List Nat := [2,4,8,16,1,17,128,4,137,21,0,1,9,0,0,154,0,0,21,1,0,0,17,155,129,17,1,1,0,1,20,152,4,136,0,137]

theorem envBound21797 : H12AffineFastState.Bounded env21797 := by
  intro p hp
  have h : env21797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21796_21797 : H12AffineEnvironment.transform 15 154 env21796 = env21797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 154 env21796 == env21797) = true)

def env21798 : List Nat := [2,4,8,16,32,17,128,5,137,20,33,1,8192,0,0,65536,0,8201,20,1,0,8233,17,65536,8328,17,32,1,0,8200,20,73770,5,169,0,137]

theorem envBound21798 : H12AffineFastState.Bounded env21798 := by
  intro p hp
  have h : env21798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21790_21798 : H12AffineEnvironment.transform 7 5 env21790 = env21798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env21790 == env21798) = true)

theorem identity21798 : scanCanonicalize (H12AffineFastState.compose env21798 (packedSelected [2,4] rootPS)) = affineNative (2^(15+1) ^^^ 139) := by decide +kernel

theorem selectedBound21798 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env21799 : List Nat := [2,4,8,16,32,17,128,5,137,20,33,1,8192,0,0,139,0,8201,20,1,0,8233,17,139,8328,17,32,1,0,8200,20,8353,5,169,0,137]

theorem envBound21799 : H12AffineFastState.Bounded env21799 := by
  intro p hp
  have h : env21799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21798_21799 : H12AffineEnvironment.transform 15 139 env21798 = env21799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 139 env21798 == env21799) = true)

theorem identity21799 : scanCanonicalize (H12AffineFastState.compose env21799 (packedSelected [0,2] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound21799 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env21800 : List Nat := [2,4,8,16,32,17,128,5,137,20,33,1,9,0,0,139,0,0,20,1,0,32,17,139,129,17,32,1,0,1,20,168,5,169,0,137]

theorem envBound21800 : H12AffineFastState.Bounded env21800 := by
  intro p hp
  have h : env21800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21799_21800 : H12AffineEnvironment.transform 12 9 env21799 = env21800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env21799 == env21800) = true)

theorem identity21800 : scanCanonicalize (H12AffineFastState.compose env21800 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound21800 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21801 : List Nat := [2,4,8,16,32,17,56,5,49,20,33,1,9,0,0,51,0,0,20,1,0,32,17,51,57,17,32,1,0,1,20,16,5,17,0,49]

theorem envBound21801 : H12AffineFastState.Bounded env21801 := by
  intro p hp
  have h : env21801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21800_21801 : H12AffineEnvironment.transform 6 56 env21800 = env21801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env21800 == env21801) = true)

def leafEnv21801 : List Nat := [2,4,8,16,32,17,56,5,49,20,33,1,9,0,0,51,0,0,20,1,0,32,17,51,21,57,1,17,32,1,0,1,20,16,5,17,5,2,0,49,0,0,1]

def active21801 : List Nat := [0,1,2,3,4]

def tree21801 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21801 : H12WitnessSearch.Good tree21801 := H12GlobalWitnessIndex.good

theorem leafIdentity21801 : H12AffineFastState.composeSystem env21801 rootObs = leafEnv21801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21801 rootObs == leafEnv21801) = true)

theorem terminalChecked21801 : H12PackedTerminal.terminalCheckFast leafEnv21801 active21801 tree21801 = true := by decide +kernel

def env21802 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32769,4097,4194304,17665,16777216,8328,541008,21352529,16385,545088,1073741824,16876544,4294967296,256,4315938986,545041,512]

theorem envBound21802 : H12AffineFastState.Bounded env21802 := by
  intro p hp
  have h : env21802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21623_21802 : H12AffineEnvironment.transform 16 1345 env21623 = env21802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env21623 == env21802) = true)

def env21803 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,4194304,147521,16777216,8328,672784,21484816,16384,676865,1073741824,16876545,4294967296,257,4315938986,676945,512]

theorem envBound21803 : H12AffineFastState.Bounded env21803 := by
  intro p hp
  have h : env21803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21622_21803 : H12AffineEnvironment.transform 22 147521 env21622 = env21803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147521 env21622 == env21803) = true)

def env21804 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,524288,32769,4097,4194304,17665,16777216,8328,541008,21352528,16384,545089,1073741824,16876545,4294967296,257,4315938986,545041,512]

theorem envBound21804 : H12AffineFastState.Bounded env21804 := by
  intro p hp
  have h : env21804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21803_21804 : H12AffineEnvironment.transform 16 1344 env21803 = env21804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env21803 == env21804) = true)

theorem identity21804 : scanCanonicalize (H12AffineFastState.compose env21804 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(23+1) ^^^ 644436) := by decide +kernel

theorem selectedBound21804 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env21805 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,524288,32769,4097,4194304,17665,644436,8328,541008,4982020,16384,545089,1073741824,545109,4294967296,257,4299806206,545041,512]

theorem envBound21805 : H12AffineFastState.Bounded env21805 := by
  intro p hp
  have h : env21805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21804_21805 : H12AffineEnvironment.transform 23 644436 env21804 = env21805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 644436 env21804 == env21805) = true)

theorem identity21805 : scanCanonicalize (H12AffineFastState.compose env21805 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(18+1) ^^^ 1025) := by decide +kernel

theorem selectedBound21805 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env21806 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,1025,32769,4097,4194304,17665,119125,8328,17745,4456709,16384,21824,1073741824,21844,4294967296,257,4299280895,21776,512]

theorem envBound21806 : H12AffineFastState.Bounded env21806 := by
  intro p hp
  have h : env21806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21805_21806 : H12AffineEnvironment.transform 18 1025 env21805 = env21806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env21805 == env21806) = true)

def env21807 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,65536,1344,262144,1025,32769,4097,4194304,65,103445,8328,17,4456709,1344,4096,1073741824,4116,4294967296,257,4299265215,4176,512]

theorem envBound21807 : H12AffineFastState.Bounded env21807 := by
  intro p hp
  have h : env21807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21806_21807 : H12AffineEnvironment.transform 13 1344 env21806 = env21807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env21806 == env21807) = true)

theorem identity21807 : scanCanonicalize (H12AffineFastState.compose env21807 (packedSelected [0,7,20] rootPS)) = affineNative (2^(11+1) ^^^ 1344) := by decide +kernel

theorem selectedBound21807 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env21808 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,32768,65536,1344,262144,1025,32769,1345,4194304,65,98645,8328,17,4456709,1344,1344,1073741824,1364,4294967296,257,4299260415,1296,512]

theorem envBound21808 : H12AffineFastState.Bounded env21808 := by
  intro p hp
  have h : env21808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21807_21808 : H12AffineEnvironment.transform 11 1344 env21807 = env21808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env21807 == env21808) = true)

theorem identity21808 : scanCanonicalize (H12AffineFastState.compose env21808 (packedSelected [17,21] rootPS)) = affineNative (2^(15+1) ^^^ 33247) := by decide +kernel

theorem selectedBound21808 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env21809 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,32768,33247,1344,262144,1025,32769,1345,4194304,65,138,8328,17,4456709,1344,1344,1073741824,1364,4294967296,257,4299161632,1296,512]

theorem envBound21809 : H12AffineFastState.Bounded env21809 := by
  intro p hp
  have h : env21809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21808_21809 : H12AffineEnvironment.transform 15 33247 env21808 = env21809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33247 env21808 == env21809) = true)

theorem identity21809 : scanCanonicalize (H12AffineFastState.compose env21809 (packedSelected [1,5,10,13,15,17,24,28,38] rootPS)) = affineNative (2^(31+1) ^^^ 264588) := by decide +kernel

theorem selectedBound21809 : packedSelected [1,5,10,13,15,17,24,28,38] rootPS < 2^1333 := by decide +kernel

def env21810 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,32768,33247,1344,262144,1025,32769,1345,4194304,65,138,8328,17,4456709,1344,1344,1073741824,1364,264588,257,4458924,1296,512]

theorem envBound21810 : H12AffineFastState.Bounded env21810 := by
  intro p hp
  have h : env21810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21809_21810 : H12AffineEnvironment.transform 31 264588 env21809 = env21810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 264588 env21809 == env21810) = true)

theorem identity21810 : scanCanonicalize (H12AffineFastState.compose env21810 (packedSelected [12,13,17,41] rootPS)) = affineNative (2^(17+1) ^^^ 43128) := by decide +kernel

theorem selectedBound21810 : packedSelected [12,13,17,41] rootPS < 2^1333 := by decide +kernel

def env21811 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,32768,33247,1344,43128,1025,32769,1345,4194304,65,138,8328,17,4237693,1344,1344,1073741824,1364,41460,257,4235732,1296,512]

theorem envBound21811 : H12AffineFastState.Bounded env21811 := by
  intro p hp
  have h : env21811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21810_21811 : H12AffineEnvironment.transform 17 43128 env21810 = env21811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43128 env21810 == env21811) = true)

theorem identity21811 : scanCanonicalize (H12AffineFastState.compose env21811 (packedSelected [1,3,5,8,12,13,17] rootPS)) = affineNative (2^(29+1) ^^^ 4227185) := by decide +kernel

theorem selectedBound21811 : packedSelected [1,3,5,8,12,13,17] rootPS < 2^1333 := by decide +kernel

def env21812 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,32768,33247,1344,43128,1025,32769,1345,4194304,65,138,8328,17,4237693,1344,1344,4227185,1364,41460,257,4235732,1296,512]

theorem envBound21812 : H12AffineFastState.Bounded env21812 := by
  intro p hp
  have h : env21812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21811_21812 : H12AffineEnvironment.transform 29 4227185 env21811 = env21812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4227185 env21811 == env21812) = true)

theorem identity21812 : scanCanonicalize (H12AffineFastState.compose env21812 (packedSelected [0,4,7,9,11] rootPS)) = affineNative (2^(21+1) ^^^ 10248) := by decide +kernel

theorem selectedBound21812 : packedSelected [0,4,7,9,11] rootPS < 2^1333 := by decide +kernel

def env21813 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,32768,33247,1344,43128,1025,32769,1345,10248,65,138,8328,17,33141,1344,1344,43129,1364,41460,257,35292,1296,512]

theorem envBound21813 : H12AffineFastState.Bounded env21813 := by
  intro p hp
  have h : env21813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21812_21813 : H12AffineEnvironment.transform 21 10248 env21812 = env21813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10248 env21812 == env21813) = true)

theorem identity21813 : scanCanonicalize (H12AffineFastState.compose env21813 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 10912) := by decide +kernel

theorem selectedBound21813 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env21814 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,10912,11135,1344,728,1025,10913,1345,10248,65,138,8328,17,11221,1344,1344,729,1364,2900,257,9084,1296,512]

theorem envBound21814 : H12AffineFastState.Bounded env21814 := by
  intro p hp
  have h : env21814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21813_21814 : H12AffineEnvironment.transform 14 10912 env21813 = env21814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 10912 env21813 == env21814) = true)

theorem identity21814 : scanCanonicalize (H12AffineFastState.compose env21814 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 980) := by decide +kernel

theorem selectedBound21814 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env21815 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,980,1344,2420,2219,1344,728,1025,2421,1345,3036,65,138,860,17,2049,1344,1344,729,1364,2900,257,168,1296,512]

theorem envBound21815 : H12AffineFastState.Bounded env21815 := by
  intro p hp
  have h : env21815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21814_21815 : H12AffineEnvironment.transform 12 980 env21814 = env21815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 980 env21814 == env21815) = true)

theorem identity21815 : scanCanonicalize (H12AffineFastState.compose env21815 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 217) := by decide +kernel

theorem selectedBound21815 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env21816 : List Nat := [2,4,8,16,32,64,128,256,217,1024,2048,1344,269,1344,2420,2219,1344,1,1025,2421,1345,2309,65,138,389,17,2049,1344,1344,0,1364,2445,257,168,1296,217]

theorem envBound21816 : H12AffineFastState.Bounded env21816 := by
  intro p hp
  have h : env21816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21815_21816 : H12AffineEnvironment.transform 8 217 env21815 = env21816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env21815 == env21816) = true)

theorem identity21816 : scanCanonicalize (H12AffineFastState.compose env21816 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound21816 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env21817 : List Nat := [2,4,8,16,32,64,128,256,217,1024,0,1344,269,1344,372,171,1344,1,1025,373,1345,261,65,138,389,17,1,1344,1344,0,1364,397,257,168,1296,217]

theorem envBound21817 : H12AffineFastState.Bounded env21817 := by
  intro p hp
  have h : env21817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21816_21817 : H12AffineEnvironment.transform 10 0 env21816 = env21817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env21816 == env21817) = true)

theorem identity21817 : scanCanonicalize (H12AffineFastState.compose env21817 (packedSelected [3,5] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound21817 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env21818 : List Nat := [2,4,8,16,32,64,128,256,217,320,0,0,269,0,372,171,0,1,321,373,1,261,65,138,389,17,1,0,0,0,20,397,257,168,80,217]

theorem envBound21818 : H12AffineFastState.Bounded env21818 := by
  intro p hp
  have h : env21818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21817_21818 : H12AffineEnvironment.transform 9 320 env21817 = env21818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env21817 == env21818) = true)

theorem identity21818 : scanCanonicalize (H12AffineFastState.compose env21818 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound21818 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env21819 : List Nat := [2,4,8,16,32,16,128,256,137,272,0,0,269,0,292,171,0,1,273,293,1,261,17,138,389,17,1,0,0,0,20,397,257,168,0,137]

theorem envBound21819 : H12AffineFastState.Bounded env21819 := by
  intro p hp
  have h : env21819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21818_21819 : H12AffineEnvironment.transform 5 16 env21818 = env21819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env21818 == env21819) = true)

theorem identity21819 : scanCanonicalize (H12AffineFastState.compose env21819 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound21819 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21820 : List Nat := [2,4,8,16,32,16,128,36,137,52,0,0,41,0,0,171,0,1,53,1,1,33,17,138,161,17,1,0,0,0,20,169,37,168,0,137]

theorem envBound21820 : H12AffineFastState.Bounded env21820 := by
  intro p hp
  have h : env21820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21819_21820 : H12AffineEnvironment.transform 7 36 env21819 = env21820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env21819 == env21820) = true)

theorem identity21820 : scanCanonicalize (H12AffineFastState.compose env21820 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound21820 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21821 : List Nat := [2,4,8,16,1,16,128,5,137,21,0,0,8,0,0,138,0,1,20,1,1,0,17,138,128,17,1,0,0,0,20,136,4,137,0,137]

theorem envBound21821 : H12AffineFastState.Bounded env21821 := by
  intro p hp
  have h : env21821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21820_21821 : H12AffineEnvironment.transform 4 1 env21820 = env21821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env21820 == env21821) = true)

theorem identity21821 : scanCanonicalize (H12AffineFastState.compose env21821 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound21821 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21822 : List Nat := [2,4,8,0,1,0,128,5,137,5,0,0,8,0,0,138,0,1,4,1,1,0,1,138,128,1,1,0,0,0,4,136,4,137,0,137]

theorem envBound21822 : H12AffineFastState.Bounded env21822 := by
  intro p hp
  have h : env21822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21821_21822 : H12AffineEnvironment.transform 3 0 env21821 = env21822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env21821 == env21822) = true)

theorem identity21822 : scanCanonicalize (H12AffineFastState.compose env21822 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound21822 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env21823 : List Nat := [2,4,8,0,1,0,9,5,0,5,0,0,8,0,0,3,0,1,4,1,1,0,1,3,9,1,1,0,0,0,4,1,4,0,0,0]

theorem envBound21823 : H12AffineFastState.Bounded env21823 := by
  intro p hp
  have h : env21823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21822_21823 : H12AffineEnvironment.transform 6 9 env21822 = env21823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21822 == env21823) = true)

def env21824 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,65536,1344,262144,1025,32769,4097,4194304,64,103444,8328,16,4456709,1345,4097,1073741824,4117,4294967296,257,4299265214,4177,512]

theorem envBound21824 : H12AffineFastState.Bounded env21824 := by
  intro p hp
  have h : env21824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21806_21824 : H12AffineEnvironment.transform 13 1345 env21806 = env21824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env21806 == env21824) = true)

theorem identity21824 : scanCanonicalize (H12AffineFastState.compose env21824 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound21824 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env21825 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,1296,32768,65536,1297,262144,1025,32769,4097,4194304,17,103444,8328,16,4456709,1296,4097,1073741824,4117,4294967296,257,4299265214,4096,512]

theorem envBound21825 : H12AffineFastState.Bounded env21825 := by
  intro p hp
  have h : env21825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21824_21825 : H12AffineEnvironment.transform 5 17 env21824 = env21825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env21824 == env21825) = true)

def env21826 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32769,4097,4194304,17664,16777216,8328,541009,21352529,16384,545088,1073741824,16876545,4294967296,257,4315938986,545040,512]

theorem envBound21826 : H12AffineFastState.Bounded env21826 := by
  intro p hp
  have h : env21826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21803_21826 : H12AffineEnvironment.transform 16 1345 env21803 = env21826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env21803 == env21826) = true)

theorem identity21826 : scanCanonicalize (H12AffineFastState.compose env21826 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(23+1) ^^^ 98565) := by decide +kernel

theorem selectedBound21826 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env21827 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32769,4097,4194304,17664,98565,8328,541009,4477268,16384,545088,1073741824,1284,4294967296,257,4299260335,545040,512]

theorem envBound21827 : H12AffineFastState.Bounded env21827 := by
  intro p hp
  have h : env21827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21826_21827 : H12AffineEnvironment.transform 23 98565 env21826 = env21827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98565 env21826 == env21827) = true)

def env21828 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,21504,32769,4097,4194304,17664,98565,8328,5457,4477268,16384,1344,1073741824,1284,4294967296,257,4299260335,1296,512]

theorem envBound21828 : H12AffineFastState.Bounded env21828 := by
  intro p hp
  have h : env21828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21827_21828 : H12AffineEnvironment.transform 18 21504 env21827 = env21828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21504 env21827 == env21828) = true)

theorem identity21828 : scanCanonicalize (H12AffineFastState.compose env21828 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound21828 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env21829 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,1296,262144,21504,32769,4097,4194304,17664,98565,8328,5376,4477189,16384,1297,1073741824,1284,4294967296,257,4299260335,1296,512]

theorem envBound21829 : H12AffineFastState.Bounded env21829 := by
  intro p hp
  have h : env21829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21828_21829 : H12AffineEnvironment.transform 5 17 env21828 = env21829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env21828 == env21829) = true)

theorem identity21829 : scanCanonicalize (H12AffineFastState.compose env21829 (packedSelected [3,8,12,15,17,19,21] rootPS)) = affineNative (2^(17+1) ^^^ 63528) := by decide +kernel

theorem selectedBound21829 : packedSelected [3,8,12,15,17,19,21] rootPS < 2^1333 := by decide +kernel

def env21830 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,1296,63528,21504,32769,4097,4194304,17664,98565,8328,5376,4237613,16384,1297,1073741824,1284,4294967296,257,4299260335,1296,512]

theorem envBound21830 : H12AffineFastState.Bounded env21830 := by
  intro p hp
  have h : env21830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21829_21830 : H12AffineEnvironment.transform 17 63528 env21829 = env21830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 63528 env21829 == env21830) = true)

theorem identity21830 : scanCanonicalize (H12AffineFastState.compose env21830 (packedSelected [5,15,17,24] rootPS)) = affineNative (2^(29+1) ^^^ 4217093) := by decide +kernel

theorem selectedBound21830 : packedSelected [5,15,17,24] rootPS < 2^1333 := by decide +kernel

def env21831 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,1296,63528,21504,32769,4097,4194304,17664,98565,8328,5376,4237613,16384,1297,4217093,1284,4294967296,257,4299260335,1296,512]

theorem envBound21831 : H12AffineFastState.Bounded env21831 := by
  intro p hp
  have h : env21831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21830_21831 : H12AffineEnvironment.transform 29 4217093 env21830 = env21831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4217093 env21830 == env21831) = true)

def env21832 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,1296,63528,21504,32769,4097,10248,17664,98565,8328,5376,33061,16384,1297,28941,1284,4294967296,257,4295076263,1296,512]

theorem envBound21832 : H12AffineFastState.Bounded env21832 := by
  intro p hp
  have h : env21832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21831_21832 : H12AffineEnvironment.transform 21 10248 env21831 = env21832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10248 env21831 == env21832) = true)

theorem identity21832 : scanCanonicalize (H12AffineFastState.compose env21832 (packedSelected [11] rootPS)) = affineNative (2^(13+1) ^^^ 4097) := by decide +kernel

theorem selectedBound21832 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env21833 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,32768,65536,1296,43049,1025,32769,4097,10248,5377,98565,8328,5376,33061,4097,1297,8460,1284,4294967296,257,4295076263,1296,512]

theorem envBound21833 : H12AffineFastState.Bounded env21833 := by
  intro p hp
  have h : env21833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21832_21833 : H12AffineEnvironment.transform 13 4097 env21832 = env21833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4097 env21832 == env21833) = true)

theorem identity21833 : scanCanonicalize (H12AffineFastState.compose env21833 (packedSelected [10,12,13] rootPS)) = affineNative (2^(15+1) ^^^ 33166) := by decide +kernel

theorem selectedBound21833 : packedSelected [10,12,13] rootPS < 2^1333 := by decide +kernel

def env21834 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,32768,33166,1296,43049,1025,32769,4097,10248,5377,139,8328,5376,33061,4097,1297,8460,1284,4294967296,257,4294977577,1296,512]

theorem envBound21834 : H12AffineFastState.Bounded env21834 := by
  intro p hp
  have h : env21834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21833_21834 : H12AffineEnvironment.transform 15 33166 env21833 = env21834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33166 env21833 == env21834) = true)

def env21835 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,2560,2958,1296,8745,1025,2561,4097,10248,5377,139,8328,5376,2853,4097,1297,8460,1284,4294967296,257,4294977577,1296,512]

theorem envBound21835 : H12AffineFastState.Bounded env21835 := by
  intro p hp
  have h : env21835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21834_21835 : H12AffineEnvironment.transform 14 2560 env21834 = env21835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2560 env21834 == env21835) = true)

theorem identity21835 : scanCanonicalize (H12AffineFastState.compose env21835 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 648) := by decide +kernel

theorem selectedBound21835 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21836 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,2560,2958,1296,8745,1025,2561,4097,10248,5377,139,8328,5376,2853,4097,1297,8460,1284,648,257,10913,1296,512]

theorem envBound21836 : H12AffineFastState.Bounded env21836 := by
  intro p hp
  have h : env21836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21835_21836 : H12AffineEnvironment.transform 31 648 env21835 = env21836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 648 env21835 == env21836) = true)

theorem identity21836 : scanCanonicalize (H12AffineFastState.compose env21836 (packedSelected [3,12] rootPS)) = affineNative (2^(11+1) ^^^ 1465) := by decide +kernel

theorem selectedBound21836 : packedSelected [3,12] rootPS < 2^1333 := by decide +kernel

def env21837 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1465,8192,1464,2560,2958,1296,8745,1025,2561,1464,10248,184,139,8328,185,2853,1464,1297,8460,1284,648,257,10913,1296,512]

theorem envBound21837 : H12AffineFastState.Bounded env21837 := by
  intro p hp
  have h : env21837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21836_21837 : H12AffineEnvironment.transform 11 1465 env21836 = env21837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1465 env21836 == env21837) = true)

def env21838 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,1297,8192,1296,2560,2854,1296,8745,1025,2561,1296,10248,16,35,8224,17,2853,1296,1297,8460,1284,544,257,10761,1296,512]

theorem envBound21838 : H12AffineFastState.Bounded env21838 := by
  intro p hp
  have h : env21838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21837_21838 : H12AffineEnvironment.transform 6 40 env21837 = env21838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env21837 == env21838) = true)

theorem identity21838 : scanCanonicalize (H12AffineFastState.compose env21838 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound21838 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env21839 : List Nat := [2,4,8,16,32,17,40,256,292,1024,2048,1297,8192,1296,2340,2050,1296,8461,1025,2341,1296,10248,16,35,8224,17,2049,1296,1297,8460,1284,260,257,10541,1296,292]

theorem envBound21839 : H12AffineFastState.Bounded env21839 := by
  intro p hp
  have h : env21839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21838_21839 : H12AffineEnvironment.transform 8 292 env21838 = env21839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env21838 == env21839) = true)

theorem identity21839 : scanCanonicalize (H12AffineFastState.compose env21839 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 2349) := by decide +kernel

theorem selectedBound21839 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21840 : List Nat := [2,4,8,16,32,17,40,256,292,1024,2048,1297,2349,1296,2340,2050,1296,2080,1025,2341,1296,293,16,35,2317,17,2049,1296,1297,2081,1284,260,257,0,1296,292]

theorem envBound21840 : H12AffineFastState.Bounded env21840 := by
  intro p hp
  have h : env21840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21839_21840 : H12AffineEnvironment.transform 12 2349 env21839 = env21840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2349 env21839 == env21840) = true)

theorem identity21840 : scanCanonicalize (H12AffineFastState.compose env21840 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound21840 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env21841 : List Nat := [2,4,8,16,32,17,40,4,32,1024,2048,1045,2089,1044,2080,2050,1044,2080,1025,2081,1044,33,16,35,2057,17,2049,1044,1045,2081,1024,0,5,0,1044,32]

theorem envBound21841 : H12AffineFastState.Bounded env21841 := by
  intro p hp
  have h : env21841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21840_21841 : H12AffineEnvironment.transform 7 4 env21840 = env21841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env21840 == env21841) = true)

def env21842 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,1296,8192,1297,2560,2855,1296,8745,1025,2561,1297,10248,17,34,8225,16,2853,1297,1297,8460,1284,545,257,10760,1296,512]

theorem envBound21842 : H12AffineFastState.Bounded env21842 := by
  intro p hp
  have h : env21842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21837_21842 : H12AffineEnvironment.transform 6 41 env21837 = env21842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env21837 == env21842) = true)

theorem identity21842 : scanCanonicalize (H12AffineFastState.compose env21842 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound21842 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21843 : List Nat := [2,4,8,16,32,17,41,256,293,1024,2048,1296,8192,1297,2341,2050,1296,8460,1025,2340,1297,10248,17,34,8225,16,2048,1297,1297,8460,1284,260,257,10541,1296,293]

theorem envBound21843 : H12AffineFastState.Bounded env21843 := by
  intro p hp
  have h : env21843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21842_21843 : H12AffineEnvironment.transform 8 293 env21842 = env21843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env21842 == env21843) = true)

end H12CloudChart2