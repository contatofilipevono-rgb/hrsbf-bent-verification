import H12CloudChart2Data104

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans25743_25744 : H12AffineEnvironment.transform 14 12556 env25743 = env25744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12556 env25743 == env25744) = true)

theorem identity25744 : scanCanonicalize (H12AffineFastState.compose env25744 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(12+1) ^^^ 1732) := by decide +kernel

theorem selectedBound25744 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env25745 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1732,5205,6088,6075,81,242,1025,6088,1108,4573,16,4390,1612,64,122,80,4097,6437,5460,260,257,340,1108,513]

theorem envBound25745 : H12AffineFastState.Bounded env25745 := by
  intro p hp
  have h : env25745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25744_25745 : H12AffineEnvironment.transform 12 1732 env25744 = env25745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1732 env25744 == env25745) = true)

def env25746 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,1732,1109,1992,1979,81,242,1025,1992,1108,477,16,294,1612,64,122,80,1,2341,1364,260,257,340,1108,513]

theorem envBound25746 : H12AffineFastState.Bounded env25746 := by
  intro p hp
  have h : env25746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25745_25746 : H12AffineEnvironment.transform 11 0 env25745 = env25746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env25745 == env25746) = true)

theorem identity25746 : scanCanonicalize (H12AffineFastState.compose env25746 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 122) := by decide +kernel

theorem selectedBound25746 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env25747 : List Nat := [2,4,8,16,32,64,128,256,512,1024,122,0,1732,1109,1992,1979,81,242,1025,1992,1108,477,16,294,1612,64,122,80,1,351,1364,260,257,340,1108,513]

theorem envBound25747 : H12AffineFastState.Bounded env25747 := by
  intro p hp
  have h : env25747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25746_25747 : H12AffineEnvironment.transform 10 122 env25746 = env25747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 122 env25746 == env25747) = true)

theorem identity25747 : scanCanonicalize (H12AffineFastState.compose env25747 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 564) := by decide +kernel

theorem selectedBound25747 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env25748 : List Nat := [2,4,8,16,32,64,128,256,512,564,122,0,240,609,508,399,81,242,565,508,608,477,16,294,120,64,122,80,1,351,864,260,257,340,608,513]

theorem envBound25748 : H12AffineFastState.Bounded env25748 := by
  intro p hp
  have h : env25748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25747_25748 : H12AffineEnvironment.transform 9 564 env25747 = env25748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 564 env25747 == env25748) = true)

theorem identity25748 : scanCanonicalize (H12AffineFastState.compose env25748 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound25748 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25749 : List Nat := [2,4,8,16,32,64,128,21,512,564,122,0,240,609,233,154,81,242,565,233,608,200,16,51,120,64,122,80,1,74,629,17,20,65,608,513]

theorem envBound25749 : H12AffineFastState.Bounded env25749 := by
  intro p hp
  have h : env25749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25748_25749 : H12AffineEnvironment.transform 7 21 env25748 = env25749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env25748 == env25749) = true)

theorem identity25749 : scanCanonicalize (H12AffineFastState.compose env25749 (packedSelected [1,5] rootPS)) = affineNative (2^(6+1) ^^^ 114) := by decide +kernel

theorem selectedBound25749 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env25750 : List Nat := [2,4,8,16,32,64,114,21,512,564,122,0,2,609,27,104,81,0,565,27,608,58,16,51,120,64,122,80,1,74,629,17,20,65,608,513]

theorem envBound25750 : H12AffineFastState.Bounded env25750 := by
  intro p hp
  have h : env25750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25749_25750 : H12AffineEnvironment.transform 6 114 env25749 = env25750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 114 env25749 == env25750) = true)

theorem identity25750 : scanCanonicalize (H12AffineFastState.compose env25750 (packedSelected [1,3,10] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound25750 : packedSelected [1,3,10] rootPS < 2^1333 := by decide +kernel

def env25751 : List Nat := [2,4,8,16,32,10,56,21,512,564,48,0,2,555,27,34,27,0,565,27,554,58,16,51,50,10,48,26,1,0,575,17,20,11,554,513]

theorem envBound25751 : H12AffineFastState.Bounded env25751 := by
  intro p hp
  have h : env25751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25750_25751 : H12AffineEnvironment.transform 5 10 env25750 = env25751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env25750 == env25751) = true)

theorem identity25751 : scanCanonicalize (H12AffineFastState.compose env25751 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound25751 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env25752 : List Nat := [2,4,8,16,16,10,8,21,512,516,0,0,2,539,27,18,27,0,517,27,538,10,16,3,2,10,0,26,1,0,527,17,20,11,538,513]

theorem envBound25752 : H12AffineFastState.Bounded env25752 := by
  intro p hp
  have h : env25752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25751_25752 : H12AffineEnvironment.transform 4 16 env25751 = env25752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env25751 == env25752) = true)

def env25753 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,1732,1108,1993,1978,81,242,1025,1993,1108,476,16,295,1612,64,122,80,0,2340,1365,260,257,340,1108,513]

theorem envBound25753 : H12AffineFastState.Bounded env25753 := by
  intro p hp
  have h : env25753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25745_25753 : H12AffineEnvironment.transform 11 1 env25745 = env25753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env25745 == env25753) = true)

theorem identity25753 : scanCanonicalize (H12AffineFastState.compose env25753 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 470) := by decide +kernel

theorem selectedBound25753 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env25754 : List Nat := [2,4,8,16,32,64,128,256,512,1024,470,1,1732,1108,1993,1978,81,242,1025,1993,1108,476,16,295,1612,64,122,80,0,242,1365,260,257,340,1108,513]

theorem envBound25754 : H12AffineFastState.Bounded env25754 := by
  intro p hp
  have h : env25754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25753_25754 : H12AffineEnvironment.transform 10 470 env25753 = env25754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 470 env25753 == env25754) = true)

theorem identity25754 : scanCanonicalize (H12AffineFastState.compose env25754 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 612) := by decide +kernel

theorem selectedBound25754 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env25755 : List Nat := [2,4,8,16,32,64,128,256,512,612,470,1,160,560,429,478,81,242,613,429,560,476,16,295,40,64,122,80,0,242,817,260,257,340,560,513]

theorem envBound25755 : H12AffineFastState.Bounded env25755 := by
  intro p hp
  have h : env25755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25754_25755 : H12AffineEnvironment.transform 9 612 env25754 = env25755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 612 env25754 == env25755) = true)

theorem identity25755 : scanCanonicalize (H12AffineFastState.compose env25755 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound25755 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env25756 : List Nat := [2,4,8,16,32,64,128,172,512,612,122,1,160,560,1,114,81,242,613,1,560,112,16,139,40,64,122,80,0,242,669,168,173,248,560,513]

theorem envBound25756 : H12AffineFastState.Bounded env25756 := by
  intro p hp
  have h : env25756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25755_25756 : H12AffineEnvironment.transform 7 172 env25755 = env25756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env25755 == env25756) = true)

theorem identity25756 : scanCanonicalize (H12AffineFastState.compose env25756 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound25756 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25757 : List Nat := [2,4,8,16,32,64,57,21,512,612,122,1,25,560,1,114,81,75,613,1,560,112,16,50,40,64,122,80,0,75,548,17,20,65,560,513]

theorem envBound25757 : H12AffineFastState.Bounded env25757 := by
  intro p hp
  have h : env25757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25756_25757 : H12AffineEnvironment.transform 6 57 env25756 = env25757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env25756 == env25757) = true)

theorem identity25757 : scanCanonicalize (H12AffineFastState.compose env25757 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound25757 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env25758 : List Nat := [2,4,8,11,32,64,34,14,512,612,97,1,2,555,1,105,74,75,613,1,555,107,11,41,40,64,97,75,0,75,548,10,15,65,555,513]

theorem envBound25758 : H12AffineFastState.Bounded env25758 := by
  intro p hp
  have h : env25758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25757_25758 : H12AffineEnvironment.transform 3 11 env25757 = env25758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env25757 == env25758) = true)

theorem identity25758 : scanCanonicalize (H12AffineFastState.compose env25758 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound25758 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env25759 : List Nat := [2,4,8,11,10,64,8,14,512,590,75,1,2,513,1,67,74,75,591,1,513,65,11,3,2,64,75,75,0,75,526,10,15,65,513,513]

theorem envBound25759 : H12AffineFastState.Bounded env25759 := by
  intro p hp
  have h : env25759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25758_25759 : H12AffineEnvironment.transform 4 10 env25758 = env25759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env25758 == env25759) = true)

def env25760 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5205,32768,32883,45405,9782,1025,32768,46425,41169,17,41003,8328,65,9919,45404,4097,43049,42073,260,257,341,46424,513]

theorem envBound25760 : H12AffineFastState.Bounded env25760 := by
  intro p hp
  have h : env25760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25742_25760 : H12AffineEnvironment.transform 20 46425 env25742 = env25760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 46425 env25742 == env25760) = true)

theorem identity25760 : scanCanonicalize (H12AffineFastState.compose env25760 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound25760 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env25761 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,8192,1028,32768,32883,41228,9782,1025,32768,42248,41169,17,41003,8328,65,9919,41229,80,43049,42073,260,257,341,42249,513]

theorem envBound25761 : H12AffineFastState.Bounded env25761 := by
  intro p hp
  have h : env25761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25760_25761 : H12AffineEnvironment.transform 11 81 env25760 = env25761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env25760 == env25761) = true)

theorem identity25761 : scanCanonicalize (H12AffineFastState.compose env25761 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(14+1) ^^^ 1992) := by decide +kernel

theorem selectedBound25761 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env25762 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,8192,1028,1992,1979,9924,9782,1025,1992,8896,10009,17,10211,8328,65,9919,9925,80,12257,9105,260,257,341,8897,513]

theorem envBound25762 : H12AffineFastState.Bounded env25762 := by
  intro p hp
  have h : env25762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25761_25762 : H12AffineEnvironment.transform 14 1992 env25761 = env25762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1992 env25761 == env25762) = true)

def env25763 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1,8192,1028,1944,1979,9876,9782,1025,1944,8848,10009,17,10163,8328,17,9919,9877,0,12209,9105,260,257,261,8849,513]

theorem envBound25763 : H12AffineFastState.Bounded env25763 := by
  intro p hp
  have h : env25763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25762_25763 : H12AffineEnvironment.transform 5 16 env25762 = env25763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env25762 == env25763) = true)

theorem identity25763 : scanCanonicalize (H12AffineFastState.compose env25763 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound25763 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env25764 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1,268,1028,1944,1979,1944,1850,1025,1944,924,1557,17,1727,388,17,1971,1945,0,3773,669,260,257,261,925,513]

theorem envBound25764 : H12AffineFastState.Bounded env25764 := by
  intro p hp
  have h : env25764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25763_25764 : H12AffineEnvironment.transform 12 268 env25763 = env25764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env25763 == env25764) = true)

theorem identity25764 : scanCanonicalize (H12AffineFastState.compose env25764 (packedSelected [2,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 319) := by decide +kernel

theorem selectedBound25764 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env25765 : List Nat := [2,4,8,16,32,16,128,256,512,1024,319,1,268,1028,1944,1979,1944,1850,1025,1944,924,1557,17,1727,388,17,1971,1945,0,1922,669,260,257,261,925,513]

theorem envBound25765 : H12AffineFastState.Bounded env25765 := by
  intro p hp
  have h : env25765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25764_25765 : H12AffineEnvironment.transform 10 319 env25764 = env25765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 319 env25764 == env25765) = true)

theorem identity25765 : scanCanonicalize (H12AffineFastState.compose env25765 (packedSelected [1,2,5,12] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound25765 : packedSelected [1,2,5,12] rootPS < 2^1333 := by decide +kernel

def env25766 : List Nat := [2,4,8,16,32,16,128,20,512,1024,43,1,24,1028,1676,1711,1676,1582,1025,1676,648,1557,17,1727,144,17,1703,1677,0,1686,669,16,21,17,649,513]

theorem envBound25766 : H12AffineFastState.Bounded env25766 := by
  intro p hp
  have h : env25766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25765_25766 : H12AffineEnvironment.transform 7 20 env25765 = env25766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env25765 == env25766) = true)

theorem identity25766 : scanCanonicalize (H12AffineFastState.compose env25766 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 564) := by decide +kernel

theorem selectedBound25766 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env25767 : List Nat := [2,4,8,16,32,16,128,20,512,564,43,1,24,560,184,155,184,26,565,184,648,33,17,139,144,17,147,185,0,162,669,16,21,17,649,513]

theorem envBound25767 : H12AffineFastState.Bounded env25767 := by
  intro p hp
  have h : env25767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25766_25767 : H12AffineEnvironment.transform 9 564 env25766 = env25767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 564 env25766 == env25767) = true)

theorem identity25767 : scanCanonicalize (H12AffineFastState.compose env25767 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound25767 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25768 : List Nat := [2,4,8,16,32,16,56,20,512,564,43,1,24,560,0,35,0,26,565,0,560,33,17,51,40,17,43,1,0,26,549,16,21,17,561,513]

theorem envBound25768 : H12AffineFastState.Bounded env25768 := by
  intro p hp
  have h : env25768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25767_25768 : H12AffineEnvironment.transform 6 56 env25767 = env25768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env25767 == env25768) = true)

theorem identity25768 : scanCanonicalize (H12AffineFastState.compose env25768 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 54) := by decide +kernel

theorem selectedBound25768 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25769 : List Nat := [2,4,8,16,32,16,56,20,54,2,43,1,24,6,0,35,0,26,3,0,6,33,17,51,40,17,43,1,0,26,19,16,21,17,7,55]

theorem envBound25769 : H12AffineFastState.Bounded env25769 := by
  intro p hp
  have h : env25769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25768_25769 : H12AffineEnvironment.transform 8 54 env25768 = env25769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 54 env25768 == env25769) = true)

theorem identity25769 : scanCanonicalize (H12AffineFastState.compose env25769 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound25769 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env25770 : List Nat := [2,4,8,16,11,16,19,20,29,2,0,1,24,6,0,8,0,26,3,0,6,10,17,24,3,17,0,1,0,26,19,16,21,17,7,28]

theorem envBound25770 : H12AffineFastState.Bounded env25770 := by
  intro p hp
  have h : env25770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25769_25770 : H12AffineEnvironment.transform 4 11 env25769 = env25770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env25769 == env25770) = true)

theorem identity25770 : scanCanonicalize (H12AffineFastState.compose env25770 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound25770 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25771 : List Nat := [2,4,8,11,11,11,8,15,6,2,0,1,3,6,0,8,0,1,3,0,6,10,10,3,3,10,0,1,0,1,8,11,14,10,7,7]

theorem envBound25771 : H12AffineFastState.Bounded env25771 := by
  intro p hp
  have h : env25771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25770_25771 : H12AffineEnvironment.transform 3 11 env25770 = env25771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env25770 == env25771) = true)

def env25772 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,0,8192,1028,1945,1979,9877,9782,1025,1945,8849,10009,17,10162,8328,16,9919,9876,1,12208,9105,260,257,260,8848,513]

theorem envBound25772 : H12AffineFastState.Bounded env25772 := by
  intro p hp
  have h : env25772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25762_25772 : H12AffineEnvironment.transform 5 17 env25762 = env25772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env25762 == env25772) = true)

theorem identity25772 : scanCanonicalize (H12AffineFastState.compose env25772 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 921) := by decide +kernel

theorem selectedBound25772 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env25773 : List Nat := [2,4,8,16,32,17,128,256,512,921,2048,0,8192,925,0,34,8460,8623,920,0,8849,8320,17,8235,8328,16,8486,8461,1,10281,9105,260,257,260,8848,513]

theorem envBound25773 : H12AffineFastState.Bounded env25773 := by
  intro p hp
  have h : env25773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25772_25773 : H12AffineEnvironment.transform 9 921 env25772 = env25773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 921 env25772 == env25773) = true)

theorem identity25773 : scanCanonicalize (H12AffineFastState.compose env25773 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound25773 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25774 : List Nat := [2,4,8,16,32,17,57,256,512,800,2048,0,8192,804,0,34,8460,8470,801,0,8744,8249,17,8235,8241,16,8486,8461,1,10281,9000,260,257,260,8745,513]

theorem envBound25774 : H12AffineFastState.Bounded env25774 := by
  intro p hp
  have h : env25774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25773_25774 : H12AffineEnvironment.transform 6 57 env25773 = env25774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env25773 == env25774) = true)

theorem identity25774 : scanCanonicalize (H12AffineFastState.compose env25774 (packedSelected [0,1,4,7,8,9,12] rootPS)) = affineNative (2^(12+1) ^^^ 2099) := by decide +kernel

theorem selectedBound25774 : packedSelected [0,1,4,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env25775 : List Nat := [2,4,8,16,32,17,57,256,512,800,2048,0,2099,804,0,34,2367,2341,801,0,2587,2058,17,2072,2050,16,2325,2366,1,26,2843,260,257,260,2586,513]

theorem envBound25775 : H12AffineFastState.Bounded env25775 := by
  intro p hp
  have h : env25775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25774_25775 : H12AffineEnvironment.transform 12 2099 env25774 = env25775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2099 env25774 == env25775) = true)

theorem identity25775 : scanCanonicalize (H12AffineFastState.compose env25775 (packedSelected [1,3,5,8,13] rootPS)) = affineNative (2^(10+1) ^^^ 318) := by decide +kernel

theorem selectedBound25775 : packedSelected [1,3,5,8,13] rootPS < 2^1333 := by decide +kernel

def env25776 : List Nat := [2,4,8,16,32,17,57,256,512,800,318,0,269,804,0,34,1,27,801,0,805,308,17,294,316,16,43,0,1,26,549,260,257,260,804,513]

theorem envBound25776 : H12AffineFastState.Bounded env25776 := by
  intro p hp
  have h : env25776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25775_25776 : H12AffineEnvironment.transform 10 318 env25775 = env25776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 318 env25775 == env25776) = true)

theorem identity25776 : scanCanonicalize (H12AffineFastState.compose env25776 (packedSelected [0,1,4] rootPS)) = affineNative (2^(8+1) ^^^ 259) := by decide +kernel

theorem selectedBound25776 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env25777 : List Nat := [2,4,8,16,32,17,57,256,259,35,318,0,269,39,0,34,1,27,34,0,38,308,17,294,316,16,43,0,1,26,294,260,257,260,39,258]

theorem envBound25777 : H12AffineFastState.Bounded env25777 := by
  intro p hp
  have h : env25777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25776_25777 : H12AffineEnvironment.transform 8 259 env25776 = env25777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 259 env25776 == env25777) = true)

theorem identity25777 : scanCanonicalize (H12AffineFastState.compose env25777 (packedSelected [3,5] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound25777 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env25778 : List Nat := [2,4,4,16,32,17,53,256,259,35,306,0,257,39,0,34,1,23,34,0,38,308,17,294,304,16,39,0,1,22,294,260,257,260,39,258]

theorem envBound25778 : H12AffineFastState.Bounded env25778 := by
  intro p hp
  have h : env25778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25777_25778 : H12AffineEnvironment.transform 2 4 env25777 = env25778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env25777 == env25778) = true)

def env25779 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,2248768,16777216,8328,2248720,21331969,4399266,4272290,4294795,16876545,4329609,257,16912418,151633,513]

theorem envBound25779 : H12AffineFastState.Bounded env25779 := by
  intro p hp
  have h : env25779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25735_25779 : H12AffineEnvironment.transform 26 21331969 env25735 = env25779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 21331969 env25735 == env25779) = true)

theorem identity25779 : scanCanonicalize (H12AffineFastState.compose env25779 (packedSelected [14] rootPS)) = affineNative (2^(21+1) ^^^ 2155652) := by decide +kernel

theorem selectedBound25779 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env25780 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,2155652,2248768,16777216,8328,2248720,19227781,2343974,2216998,2190351,16876545,2290701,257,16912418,151633,513]

theorem envBound25780 : H12AffineFastState.Bounded env25780 := by
  intro p hp
  have h : env25780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25779_25780 : H12AffineEnvironment.transform 21 2155652 env25779 = env25780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2155652 env25779 == env25780) = true)

theorem identity25780 : scanCanonicalize (H12AffineFastState.compose env25780 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(20+1) ^^^ 249970) := by decide +kernel

theorem selectedBound25780 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env25781 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,249970,210166,98354,16777216,8328,98402,17216759,5204,132180,179325,16876545,74879,257,16912418,151633,513]

theorem envBound25781 : H12AffineFastState.Bounded env25781 := by
  intro p hp
  have h : env25781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25780_25781 : H12AffineEnvironment.transform 20 249970 env25780 = env25781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 249970 env25780 == env25781) = true)

theorem identity25781 : scanCanonicalize (H12AffineFastState.compose env25781 (packedSelected [13,21] rootPS)) = affineNative (2^(23+1) ^^^ 42110) := by decide +kernel

theorem selectedBound25781 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env25782 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,249970,210166,98354,42110,8328,98402,397449,5204,132180,179325,73855,74879,257,177244,151633,513]

theorem envBound25782 : H12AffineFastState.Bounded env25782 := by
  intro p hp
  have h : env25782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25781_25782 : H12AffineEnvironment.transform 23 42110 env25781 = env25782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 42110 env25781 == env25782) = true)

def env25783 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,2248769,16777216,8328,2774032,134217728,151954594,151827618,4294795,17399808,151490696,525568,138907683,156226640,513]

theorem envBound25783 : H12AffineFastState.Bounded env25783 := by
  intro p hp
  have h : env25783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25676_25783 : H12AffineEnvironment.transform 22 2248769 env25676 = env25783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2248769 env25676 == env25783) = true)

def env25784 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,2248769,16777216,8328,2248720,134217728,151429282,151302306,4294795,16876544,151490696,256,138907683,155701328,513]

theorem envBound25784 : H12AffineFastState.Bounded env25784 := by
  intro p hp
  have h : env25784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25783_25784 : H12AffineEnvironment.transform 18 1024 env25783 = env25784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env25783 == env25784) = true)

def env25785 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,2248769,16777216,8328,2248720,21331968,4399266,4272290,4294795,16876544,4329608,256,16912419,151632,513]

theorem envBound25785 : H12AffineFastState.Bounded env25785 := by
  intro p hp
  have h : env25785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25784_25785 : H12AffineEnvironment.transform 26 21331968 env25784 = env25785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 21331968 env25784 == env25785) = true)

theorem identity25785 : scanCanonicalize (H12AffineFastState.compose env25785 (packedSelected [14] rootPS)) = affineNative (2^(21+1) ^^^ 172437) := by decide +kernel

theorem selectedBound25785 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env25786 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,172437,2248769,16777216,8328,2248720,17244565,98615,233783,207134,16876544,45341,256,16912419,151632,513]

theorem envBound25786 : H12AffineFastState.Bounded env25786 := by
  intro p hp
  have h : env25786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25785_25786 : H12AffineEnvironment.transform 21 172437 env25785 = env25786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 172437 env25785 == env25786) = true)

theorem identity25786 : scanCanonicalize (H12AffineFastState.compose env25786 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(23+1) ^^^ 2342929) := by decide +kernel

theorem selectedBound25786 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env25787 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,172437,2248769,2342929,8328,2248720,2417028,98615,233783,207134,2245649,45341,256,2215986,151632,513]

theorem envBound25787 : H12AffineFastState.Bounded env25787 := by
  intro p hp
  have h : env25787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25786_25787 : H12AffineEnvironment.transform 23 2342929 env25786 = env25787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2342929 env25786 == env25787) = true)

theorem identity25787 : scanCanonicalize (H12AffineFastState.compose env25787 (packedSelected [13,21] rootPS)) = affineNative (2^(16+1) ^^^ 45404) := by decide +kernel

theorem selectedBound25787 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env25788 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,45404,262144,1024,32768,2097152,4297,2154781,2191693,8328,2154828,2417028,98615,73835,104514,2159949,45341,256,2215986,57612,513]

theorem envBound25788 : H12AffineFastState.Bounded env25788 := by
  intro p hp
  have h : env25788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25787_25788 : H12AffineEnvironment.transform 16 45404 env25787 = env25788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45404 env25787 == env25788) = true)

def env25789 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,2248769,16777216,8328,2248720,21331969,4399267,4272291,4294795,16876544,4329609,256,16912418,151633,513]

theorem envBound25789 : H12AffineFastState.Bounded env25789 := by
  intro p hp
  have h : env25789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25784_25789 : H12AffineEnvironment.transform 26 21331969 env25784 = env25789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 21331969 env25784 == env25789) = true)

theorem identity25789 : scanCanonicalize (H12AffineFastState.compose env25789 (packedSelected [14] rootPS)) = affineNative (2^(21+1) ^^^ 2273685) := by decide +kernel

theorem selectedBound25789 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env25790 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,2273685,2248769,16777216,8328,2248720,19345812,2199862,2326838,2308382,16876544,2138396,256,16912418,151633,513]

theorem envBound25790 : H12AffineFastState.Bounded env25790 := by
  intro p hp
  have h : env25790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25789_25790 : H12AffineEnvironment.transform 21 2273685 env25789 = env25790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2273685 env25789 == env25790) = true)

theorem identity25790 : scanCanonicalize (H12AffineFastState.compose env25790 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(20+1) ^^^ 249970) := by decide +kernel

theorem selectedBound25790 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env25791 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,249970,90599,98355,16777216,8328,98402,17097190,147780,20804,59756,16876544,225646,256,16912418,151633,513]

theorem envBound25791 : H12AffineFastState.Bounded env25791 := by
  intro p hp
  have h : env25791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25790_25791 : H12AffineEnvironment.transform 20 249970 env25790 = env25791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 249970 env25790 == env25791) = true)

theorem identity25791 : scanCanonicalize (H12AffineFastState.compose env25791 (packedSelected [13,21] rootPS)) = affineNative (2^(23+1) ^^^ 192879) := by decide +kernel

theorem selectedBound25791 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env25792 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,249970,90599,98355,192879,8328,98402,397449,147780,20804,59756,226671,225646,256,57677,151633,513]

theorem envBound25792 : H12AffineFastState.Bounded env25792 := by
  intro p hp
  have h : env25792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25791_25792 : H12AffineEnvironment.transform 23 192879 env25791 = env25792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 192879 env25791 == env25792) = true)

theorem identity25792 : scanCanonicalize (H12AffineFastState.compose env25792 (packedSelected [0,3,5,10,27] rootPS)) = affineNative (2^(14+1) ^^^ 24648) := by decide +kernel

theorem selectedBound25792 : packedSelected [0,3,5,10,27] rootPS < 2^1333 := by decide +kernel

def env25793 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,24648,65536,131072,262144,1024,24648,208954,90599,90235,135463,8328,90154,397449,147780,20804,2340,226671,225646,256,261,151633,513]

theorem envBound25793 : H12AffineFastState.Bounded env25793 := by
  intro p hp
  have h : env25793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25792_25793 : H12AffineEnvironment.transform 14 24648 env25792 = env25793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 24648 env25792 == env25793) = true)

def env25794 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,24600,65536,131072,262144,1024,24600,208954,90551,90155,135463,8328,90154,397449,147732,20756,2340,226623,225598,256,261,151553,513]

theorem envBound25794 : H12AffineFastState.Bounded env25794 := by
  intro p hp
  have h : env25794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25793_25794 : H12AffineEnvironment.transform 5 16 env25793 = env25794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env25793 == env25794) = true)

theorem identity25794 : scanCanonicalize (H12AffineFastState.compose env25794 (packedSelected [6] rootPS)) = affineNative (2^(16+1) ^^^ 13340) := by decide +kernel

theorem selectedBound25794 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env25795 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,24600,65536,13340,262144,1024,24600,66598,90551,90155,9531,8328,90154,271509,29960,20756,2340,82211,83234,256,261,25629,513]

theorem envBound25795 : H12AffineFastState.Bounded env25795 := by
  intro p hp
  have h : env25795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25794_25795 : H12AffineEnvironment.transform 16 13340 env25794 = env25795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13340 env25794 == env25795) = true)

def env25796 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,1456,16384,17832,65536,4524,262144,1024,17832,66598,82951,83355,139,1336,83354,262437,20664,20756,2340,82211,83234,256,261,16813,513]

theorem envBound25796 : H12AffineFastState.Bounded env25796 := by
  intro p hp
  have h : env25796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25795_25796 : H12AffineEnvironment.transform 12 1456 env25795 = env25796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1456 env25795 == env25796) = true)

theorem identity25796 : scanCanonicalize (H12AffineFastState.compose env25796 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(13+1) ^^^ 277) := by decide +kernel

theorem selectedBound25796 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env25797 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,1456,277,1213,65536,4524,262144,1024,1213,66598,66834,66702,139,1336,66703,262437,4525,4097,2340,65590,66615,256,261,184,513]

theorem envBound25797 : H12AffineFastState.Bounded env25797 := by
  intro p hp
  have h : env25797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25796_25797 : H12AffineEnvironment.transform 13 277 env25796 = env25797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 277 env25796 == env25797) = true)

theorem identity25797 : scanCanonicalize (H12AffineFastState.compose env25797 (packedSelected [2,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound25797 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env25798 : List Nat := [2,4,8,16,32,16,128,256,512,1024,26,4096,1456,277,1213,65536,4524,262144,1024,1213,66598,66834,66702,139,1336,66703,262437,4525,4097,318,65590,66615,256,261,184,513]

theorem envBound25798 : H12AffineFastState.Bounded env25798 := by
  intro p hp
  have h : env25798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25797_25798 : H12AffineEnvironment.transform 10 26 env25797 = env25798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env25797 == env25798) = true)

theorem identity25798 : scanCanonicalize (H12AffineFastState.compose env25798 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 4130) := by decide +kernel

theorem selectedBound25798 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env25799 : List Nat := [2,4,8,16,32,16,128,256,512,1024,26,4096,1456,277,1213,4130,4524,262144,1024,1213,5124,5424,5292,139,1336,5293,262437,4525,4097,318,4116,5141,256,261,184,513]

theorem envBound25799 : H12AffineFastState.Bounded env25799 := by
  intro p hp
  have h : env25799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25798_25799 : H12AffineEnvironment.transform 15 4130 env25798 = env25799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4130 env25798 == env25799) = true)

theorem identity25799 : scanCanonicalize (H12AffineFastState.compose env25799 (packedSelected [1,2,3,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 1174) := by decide +kernel

theorem selectedBound25799 : packedSelected [1,2,3,12,15] rootPS < 2^1333 := by decide +kernel

def env25800 : List Nat := [2,4,8,16,32,16,128,256,512,1024,26,4096,1456,277,1213,4130,4524,1174,1024,1213,5124,5424,5292,139,1336,5293,1459,4525,4097,318,4116,5141,256,261,184,513]

theorem envBound25800 : H12AffineFastState.Bounded env25800 := by
  intro p hp
  have h : env25800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25799_25800 : H12AffineEnvironment.transform 17 1174 env25799 = env25800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1174 env25799 == env25800) = true)

def env25801 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,1457,16384,17833,65536,4525,262144,1024,17833,66598,82950,83354,138,1337,83355,262436,20665,20756,2340,82211,83234,256,261,16812,513]

theorem envBound25801 : H12AffineFastState.Bounded env25801 := by
  intro p hp
  have h : env25801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25795_25801 : H12AffineEnvironment.transform 12 1457 env25795 = env25801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1457 env25795 == env25801) = true)

theorem identity25801 : scanCanonicalize (H12AffineFastState.compose env25801 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(17+1) ^^^ 18480) := by decide +kernel

theorem selectedBound25801 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env25802 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,1457,16384,17833,65536,4525,18480,1024,17833,66598,82950,83354,138,1337,83355,18708,20665,20756,2340,82211,83234,256,261,16812,513]

theorem envBound25802 : H12AffineFastState.Bounded env25802 := by
  intro p hp
  have h : env25802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25801_25802 : H12AffineEnvironment.transform 17 18480 env25801 = env25802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 18480 env25801 == env25802) = true)

def env25803 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,1457,48,1433,65536,4525,2048,1024,1433,66598,66614,66986,138,1337,66987,2340,4233,4388,2340,65811,66834,256,261,412,513]

theorem envBound25803 : H12AffineFastState.Bounded env25803 := by
  intro p hp
  have h : env25803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25802_25803 : H12AffineEnvironment.transform 13 48 env25802 = env25803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 48 env25802 == env25803) = true)

theorem identity25803 : scanCanonicalize (H12AffineFastState.compose env25803 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 62) := by decide +kernel

theorem selectedBound25803 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env25804 : List Nat := [2,4,8,16,32,16,128,62,512,1024,2048,4096,1167,48,1191,65536,4243,2048,1024,1191,66598,66614,66708,138,1031,66709,2074,4233,4122,2074,65581,66604,62,59,162,513]

theorem envBound25804 : H12AffineFastState.Bounded env25804 := by
  intro p hp
  have h : env25804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25803_25804 : H12AffineEnvironment.transform 7 62 env25803 = env25804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 62 env25803 == env25804) = true)

theorem identity25804 : scanCanonicalize (H12AffineFastState.compose env25804 (packedSelected [4,9] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound25804 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env25805 : List Nat := [2,4,8,16,32,16,128,62,512,4,2048,4096,139,48,163,65536,4243,2048,4,163,65570,65586,65680,138,3,65681,2074,4233,4122,2074,65581,65576,62,59,162,513]

theorem envBound25805 : H12AffineFastState.Bounded env25805 := by
  intro p hp
  have h : env25805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25804_25805 : H12AffineEnvironment.transform 9 4 env25804 = env25805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env25804 == env25805) = true)

def env25806 : List Nat := [2,4,8,16,32,16,128,62,512,4,2048,4096,139,48,163,8,4243,2048,4,163,42,58,152,138,3,153,2074,4233,4122,2074,37,32,62,59,162,513]

theorem envBound25806 : H12AffineFastState.Bounded env25806 := by
  intro p hp
  have h : env25806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25805_25806 : H12AffineEnvironment.transform 15 8 env25805 = env25806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8 env25805 == env25806) = true)

theorem identity25806 : scanCanonicalize (H12AffineFastState.compose env25806 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound25806 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25807 : List Nat := [2,4,8,16,32,16,128,62,26,4,2048,4096,139,48,163,8,4243,2048,4,163,42,58,152,138,3,153,2074,4233,4122,2074,37,32,62,59,162,27]

theorem envBound25807 : H12AffineFastState.Bounded env25807 := by
  intro p hp
  have h : env25807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25806_25807 : H12AffineEnvironment.transform 8 26 env25806 = env25807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env25806 == env25807) = true)

theorem identity25807 : scanCanonicalize (H12AffineFastState.compose env25807 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2074) := by decide +kernel

theorem selectedBound25807 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env25808 : List Nat := [2,4,8,16,32,16,128,62,26,4,2048,2074,139,48,163,8,2185,2048,4,163,42,58,152,138,3,153,2074,2195,2048,2074,37,32,62,59,162,27]

theorem envBound25808 : H12AffineFastState.Bounded env25808 := by
  intro p hp
  have h : env25808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25807_25808 : H12AffineEnvironment.transform 11 2074 env25807 = env25808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2074 env25807 == env25808) = true)

theorem identity25808 : scanCanonicalize (H12AffineFastState.compose env25808 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound25808 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env25809 : List Nat := [2,4,8,16,32,16,19,62,26,4,2048,2074,24,48,48,8,2074,2048,4,48,42,58,11,25,3,10,2074,2048,2048,2074,37,32,62,59,49,27]

theorem envBound25809 : H12AffineFastState.Bounded env25809 := by
  intro p hp
  have h : env25809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25808_25809 : H12AffineEnvironment.transform 6 19 env25808 = env25809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env25808 == env25809) = true)

theorem identity25809 : scanCanonicalize (H12AffineFastState.compose env25809 (packedSelected [0,5] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound25809 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env25810 : List Nat := [2,4,8,10,32,10,9,36,0,4,2048,2048,2,42,42,8,2048,2048,4,42,42,32,11,3,3,10,2048,2048,2048,2048,37,32,36,33,43,1]

theorem envBound25810 : H12AffineFastState.Bounded env25810 := by
  intro p hp
  have h : env25810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25809_25810 : H12AffineEnvironment.transform 3 10 env25809 = env25810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env25809 == env25810) = true)

theorem identity25810 : scanCanonicalize (H12AffineFastState.compose env25810 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound25810 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25811 : List Nat := [2,4,5,7,32,7,4,36,0,4,2048,2048,2,39,39,5,2048,2048,4,39,39,32,6,3,3,7,2048,2048,2048,2048,37,32,36,33,38,1]

theorem envBound25811 : H12AffineFastState.Bounded env25811 := by
  intro p hp
  have h : env25811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25810_25811 : H12AffineEnvironment.transform 2 5 env25810 = env25811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env25810 == env25811) = true)

theorem identity25811 : scanCanonicalize (H12AffineFastState.compose env25811 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 38) := by decide +kernel

theorem selectedBound25811 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env25812 : List Nat := [2,4,5,7,32,7,4,36,0,4,38,38,2,39,39,5,38,38,4,39,39,32,6,3,3,7,38,38,38,38,37,32,36,33,38,1]

theorem envBound25812 : H12AffineFastState.Bounded env25812 := by
  intro p hp
  have h : env25812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25811_25812 : H12AffineEnvironment.transform 10 38 env25811 = env25812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 38 env25811 == env25812) = true)

def env25813 : List Nat := [2,4,8,16,32,16,128,62,512,4,2048,4096,139,48,163,9,4243,2048,4,163,43,59,153,138,3,152,2074,4233,4122,2074,36,33,62,59,162,513]

theorem envBound25813 : H12AffineFastState.Bounded env25813 := by
  intro p hp
  have h : env25813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25805_25813 : H12AffineEnvironment.transform 15 9 env25805 = env25813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9 env25805 == env25813) = true)

theorem identity25813 : scanCanonicalize (H12AffineFastState.compose env25813 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound25813 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25814 : List Nat := [2,4,8,16,32,16,128,62,137,4,2048,4096,139,48,163,9,4243,2048,4,163,43,59,153,138,3,152,2074,4233,4122,2074,36,33,62,59,162,136]

theorem envBound25814 : H12AffineFastState.Bounded env25814 := by
  intro p hp
  have h : env25814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25813_25814 : H12AffineEnvironment.transform 8 137 env25813 = env25814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env25813 == env25814) = true)

theorem identity25814 : scanCanonicalize (H12AffineFastState.compose env25814 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2049) := by decide +kernel

theorem selectedBound25814 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env25815 : List Nat := [2,4,8,16,32,16,128,62,137,4,2048,2049,139,48,163,9,2194,2048,4,163,43,59,153,138,3,152,2074,2184,2075,2074,36,33,62,59,162,136]

theorem envBound25815 : H12AffineFastState.Bounded env25815 := by
  intro p hp
  have h : env25815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25814_25815 : H12AffineEnvironment.transform 11 2049 env25814 = env25815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2049 env25814 == env25815) = true)

theorem identity25815 : scanCanonicalize (H12AffineFastState.compose env25815 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound25815 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env25816 : List Nat := [2,4,8,16,32,16,19,62,26,4,2048,2049,24,48,48,9,2049,2048,4,48,43,59,10,25,3,11,2074,2075,2075,2074,36,33,62,59,49,27]

theorem envBound25816 : H12AffineFastState.Bounded env25816 := by
  intro p hp
  have h : env25816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25815_25816 : H12AffineEnvironment.transform 6 19 env25815 = env25816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env25815 == env25816) = true)

theorem identity25816 : scanCanonicalize (H12AffineFastState.compose env25816 (packedSelected [0,5] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound25816 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env25817 : List Nat := [2,4,8,10,32,10,9,36,0,4,2048,2049,2,42,42,9,2049,2048,4,42,43,33,10,3,3,11,2048,2049,2049,2048,36,33,36,33,43,1]

theorem envBound25817 : H12AffineFastState.Bounded env25817 := by
  intro p hp
  have h : env25817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25816_25817 : H12AffineEnvironment.transform 3 10 env25816 = env25817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env25816 == env25817) = true)

theorem identity25817 : scanCanonicalize (H12AffineFastState.compose env25817 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound25817 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25818 : List Nat := [2,4,8,10,7,10,9,3,0,4,2048,2049,2,13,13,9,2049,2048,4,13,12,6,10,3,3,11,2048,2049,2049,2048,3,6,3,6,12,1]

theorem envBound25818 : H12AffineFastState.Bounded env25818 := by
  intro p hp
  have h : env25818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25817_25818 : H12AffineEnvironment.transform 4 7 env25817 = env25818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env25817 == env25818) = true)

theorem identity25818 : scanCanonicalize (H12AffineFastState.compose env25818 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 13) := by decide +kernel

theorem selectedBound25818 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env25819 : List Nat := [2,4,8,10,7,10,9,3,0,4,13,12,2,13,13,9,12,13,4,13,12,6,10,3,3,11,13,12,12,13,3,6,3,6,12,1]

theorem envBound25819 : H12AffineFastState.Bounded env25819 := by
  intro p hp
  have h : env25819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25818_25819 : H12AffineEnvironment.transform 10 13 env25818 = env25819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 13 env25818 == env25819) = true)

def env25820 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,1457,49,1432,65536,4525,2049,1024,1432,66598,66615,66987,138,1337,66986,2341,4232,4389,2340,65810,66835,256,261,413,513]

theorem envBound25820 : H12AffineFastState.Bounded env25820 := by
  intro p hp
  have h : env25820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25802_25820 : H12AffineEnvironment.transform 13 49 env25802 = env25820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 49 env25802 == env25820) = true)

theorem identity25820 : scanCanonicalize (H12AffineFastState.compose env25820 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 182) := by decide +kernel

theorem selectedBound25820 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env25821 : List Nat := [2,4,8,16,32,16,128,182,512,1024,2048,4096,1031,49,1070,65536,4123,2049,1024,1070,66598,66615,66589,138,1167,66588,2195,4232,4243,2194,65700,66725,182,179,43,513]

theorem envBound25821 : H12AffineFastState.Bounded env25821 := by
  intro p hp
  have h : env25821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25820_25821 : H12AffineEnvironment.transform 7 182 env25820 = env25821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 182 env25820 == env25821) = true)

theorem identity25821 : scanCanonicalize (H12AffineFastState.compose env25821 (packedSelected [4,9] rootPS)) = affineNative (2^(9+1) ^^^ 151) := by decide +kernel

theorem selectedBound25821 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env25822 : List Nat := [2,4,8,16,32,16,128,182,512,151,2048,4096,144,49,185,65536,4123,2049,151,185,65713,65696,65674,138,24,65675,2195,4232,4243,2194,65700,65586,182,179,43,513]

theorem envBound25822 : H12AffineFastState.Bounded env25822 := by
  intro p hp
  have h : env25822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25821_25822 : H12AffineEnvironment.transform 9 151 env25821 = env25822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 151 env25821 == env25822) = true)

def env25823 : List Nat := [2,4,8,16,32,16,128,182,512,151,2048,4096,144,49,185,8,4123,2049,151,185,185,168,130,138,24,131,2195,4232,4243,2194,172,58,182,179,43,513]

theorem envBound25823 : H12AffineFastState.Bounded env25823 := by
  intro p hp
  have h : env25823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25822_25823 : H12AffineEnvironment.transform 15 8 env25822 = env25823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8 env25822 == env25823) = true)

theorem identity25823 : scanCanonicalize (H12AffineFastState.compose env25823 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound25823 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25824 : List Nat := [2,4,8,16,32,16,128,182,137,151,2048,4096,144,49,185,8,4123,2049,151,185,185,168,130,138,24,131,2195,4232,4243,2194,172,58,182,179,43,136]

theorem envBound25824 : H12AffineFastState.Bounded env25824 := by
  intro p hp
  have h : env25824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25823_25824 : H12AffineEnvironment.transform 8 137 env25823 = env25824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env25823 == env25824) = true)

theorem identity25824 : scanCanonicalize (H12AffineFastState.compose env25824 (packedSelected [0,1] rootPS)) = affineNative (2^(11+1) ^^^ 49) := by decide +kernel

theorem selectedBound25824 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env25825 : List Nat := [2,4,8,16,32,16,128,182,137,151,2048,49,144,49,185,8,42,2049,151,185,185,168,130,138,24,131,2195,185,162,2194,172,58,182,179,43,136]

theorem envBound25825 : H12AffineFastState.Bounded env25825 := by
  intro p hp
  have h : env25825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25824_25825 : H12AffineEnvironment.transform 11 49 env25824 = env25825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env25824 == env25825) = true)

theorem identity25825 : scanCanonicalize (H12AffineFastState.compose env25825 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound25825 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env25826 : List Nat := [2,4,8,11,32,11,128,173,137,140,2048,42,139,42,162,8,42,2049,140,162,162,168,130,138,3,131,2184,162,162,2185,172,33,173,168,43,136]

theorem envBound25826 : H12AffineFastState.Bounded env25826 := by
  intro p hp
  have h : env25826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25825_25826 : H12AffineEnvironment.transform 3 11 env25825 = env25826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env25825 == env25826) = true)

theorem identity25826 : scanCanonicalize (H12AffineFastState.compose env25826 (packedSelected [0,5] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound25826 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env25827 : List Nat := [2,4,8,11,32,11,9,36,0,5,2048,42,2,42,43,8,42,2049,5,43,43,33,11,3,3,10,2049,43,43,2048,37,33,36,33,43,1]

theorem envBound25827 : H12AffineFastState.Bounded env25827 := by
  intro p hp
  have h : env25827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25826_25827 : H12AffineEnvironment.transform 6 9 env25826 = env25827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env25826 == env25827) = true)

theorem identity25827 : scanCanonicalize (H12AffineFastState.compose env25827 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 6) := by decide +kernel

theorem selectedBound25827 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25828 : List Nat := [2,4,8,11,32,11,9,36,0,5,6,42,2,42,43,8,42,7,5,43,43,33,11,3,3,10,7,43,43,6,37,33,36,33,43,1]

theorem envBound25828 : H12AffineFastState.Bounded env25828 := by
  intro p hp
  have h : env25828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25827_25828 : H12AffineEnvironment.transform 10 6 env25827 = env25828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 6 env25827 == env25828) = true)

def env25829 : List Nat := [2,4,8,16,32,16,128,182,512,151,2048,4096,144,49,185,9,4123,2049,151,185,184,169,131,138,24,130,2195,4232,4243,2194,173,59,182,179,43,513]

theorem envBound25829 : H12AffineFastState.Bounded env25829 := by
  intro p hp
  have h : env25829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25822_25829 : H12AffineEnvironment.transform 15 9 env25822 = env25829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9 env25822 == env25829) = true)

theorem identity25829 : scanCanonicalize (H12AffineFastState.compose env25829 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 146) := by decide +kernel

theorem selectedBound25829 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25830 : List Nat := [2,4,8,16,32,16,128,182,146,151,2048,4096,144,49,185,9,4123,2049,151,185,184,169,131,138,24,130,2195,4232,4243,2194,173,59,182,179,43,147]

theorem envBound25830 : H12AffineFastState.Bounded env25830 := by
  intro p hp
  have h : env25830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25829_25830 : H12AffineEnvironment.transform 8 146 env25829 = env25830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 146 env25829 == env25830) = true)

theorem identity25830 : scanCanonicalize (H12AffineFastState.compose env25830 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 185) := by decide +kernel

theorem selectedBound25830 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env25831 : List Nat := [2,4,8,16,32,16,128,182,146,151,2048,185,144,49,185,9,162,2049,151,185,184,169,131,138,24,130,2195,49,42,2194,173,59,182,179,43,147]

theorem envBound25831 : H12AffineFastState.Bounded env25831 := by
  intro p hp
  have h : env25831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25830_25831 : H12AffineEnvironment.transform 11 185 env25830 = env25831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 185 env25830 == env25831) = true)

theorem identity25831 : scanCanonicalize (H12AffineFastState.compose env25831 (packedSelected [0,1,5,8] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound25831 : packedSelected [0,1,5,8] rootPS < 2^1333 := by decide +kernel

def env25832 : List Nat := [2,4,8,11,32,11,128,173,137,140,2048,162,139,42,162,9,162,2049,140,162,163,169,131,138,3,130,2184,42,42,2185,173,32,173,168,43,136]

theorem envBound25832 : H12AffineFastState.Bounded env25832 := by
  intro p hp
  have h : env25832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25831_25832 : H12AffineEnvironment.transform 3 11 env25831 = env25832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env25831 == env25832) = true)

theorem identity25832 : scanCanonicalize (H12AffineFastState.compose env25832 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 163) := by decide +kernel

theorem selectedBound25832 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env25833 : List Nat := [2,4,8,11,32,11,128,173,137,140,163,162,139,42,162,9,162,162,140,162,163,169,131,138,3,130,43,42,42,42,173,32,173,168,43,136]

theorem envBound25833 : H12AffineFastState.Bounded env25833 := by
  intro p hp
  have h : env25833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25832_25833 : H12AffineEnvironment.transform 10 163 env25832 = env25833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 163 env25832 == env25833) = true)

def env25834 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,24601,65536,131072,262144,1024,24601,208954,90550,90154,135463,8328,90154,397449,147733,20757,2340,226622,225599,256,261,151552,513]

theorem envBound25834 : H12AffineFastState.Bounded env25834 := by
  intro p hp
  have h : env25834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25793_25834 : H12AffineEnvironment.transform 5 17 env25793 = env25834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env25793 == env25834) = true)

theorem identity25834 : scanCanonicalize (H12AffineFastState.compose env25834 (packedSelected [6] rootPS)) = affineNative (2^(16+1) ^^^ 87078) := by decide +kernel

theorem selectedBound25834 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env25835 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,24601,65536,87078,262144,1024,24601,25628,90550,90154,83201,8328,90154,345263,70963,20757,2340,8472,9497,256,261,66598,513]

theorem envBound25835 : H12AffineFastState.Bounded env25835 := by
  intro p hp
  have h : env25835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25834_25835 : H12AffineEnvironment.transform 16 87078 env25834 = env25835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 87078 env25834 == env25835) = true)

def env25836 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,24601,65536,87078,262144,1024,24601,25628,90138,90154,83117,8328,90154,345263,70815,20665,2184,8372,9397,172,169,66598,513]

theorem envBound25836 : H12AffineFastState.Bounded env25836 := by
  intro p hp
  have h : env25836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25835_25836 : H12AffineEnvironment.transform 7 172 env25835 = env25836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env25835 == env25836) = true)

theorem identity25836 : scanCanonicalize (H12AffineFastState.compose env25836 (packedSelected [13,17] rootPS)) = affineNative (2^(17+1) ^^^ 18481) := by decide +kernel

theorem selectedBound25836 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env25837 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,24601,65536,87078,18481,1024,24601,25628,90138,90154,83117,8328,90154,68766,70815,20665,2184,8372,9397,172,169,66598,513]

theorem envBound25837 : H12AffineFastState.Bounded env25837 := by
  intro p hp
  have h : env25837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25836_25837 : H12AffineEnvironment.transform 17 18481 env25836 = env25837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 18481 env25836 == env25837) = true)

theorem identity25837 : scanCanonicalize (H12AffineFastState.compose env25837 (packedSelected [10,15] rootPS)) = affineNative (2^(15+1) ^^^ 17447) := by decide +kernel

theorem selectedBound25837 : packedSelected [10,15] rootPS < 2^1333 := by decide +kernel

def env25838 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,24601,17447,4097,18481,1024,24601,25628,9277,9229,138,8328,9229,18617,20664,20665,2184,8372,9397,172,169,16385,513]

theorem envBound25838 : H12AffineFastState.Bounded env25838 := by
  intro p hp
  have h : env25838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25837_25838 : H12AffineEnvironment.transform 15 17447 env25837 = env25838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 17447 env25837 == env25838) = true)

theorem identity25838 : scanCanonicalize (H12AffineFastState.compose env25838 (packedSelected [1,3] rootPS)) = affineNative (2^(13+1) ^^^ 8890) := by decide +kernel

theorem selectedBound25838 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env25839 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,8890,675,9885,4097,10891,1024,675,1702,9277,9229,138,8328,9229,10755,12802,12803,2184,8372,9397,172,169,8891,513]

theorem envBound25839 : H12AffineFastState.Bounded env25839 := by
  intro p hp
  have h : env25839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25838_25839 : H12AffineEnvironment.transform 13 8890 env25838 = env25839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8890 env25838 == env25839) = true)

theorem identity25839 : scanCanonicalize (H12AffineFastState.compose env25839 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1213) := by decide +kernel

theorem selectedBound25839 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env25840 : List Nat := [2,4,8,16,32,17,128,172,512,1024,1213,4096,8192,8890,675,9885,4097,9782,1024,675,1702,9277,9229,138,8328,9229,9918,12802,12803,1077,8372,9397,172,169,8891,513]

theorem envBound25840 : H12AffineFastState.Bounded env25840 := by
  intro p hp
  have h : env25840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25839_25840 : H12AffineEnvironment.transform 10 1213 env25839 = env25840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1213 env25839 == env25840) = true)

theorem identity25840 : scanCanonicalize (H12AffineFastState.compose env25840 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 150) := by decide +kernel

theorem selectedBound25840 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env25841 : List Nat := [2,4,8,16,32,17,128,172,512,150,43,4096,8192,8890,675,8715,4097,8864,150,675,560,8363,8347,138,8328,8347,8744,12802,12803,163,8372,8227,172,169,8891,513]

theorem envBound25841 : H12AffineFastState.Bounded env25841 := by
  intro p hp
  have h : env25841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25840_25841 : H12AffineEnvironment.transform 9 150 env25840 = env25841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 150 env25840 == env25841) = true)

def env25842 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,24601,65536,87078,262144,1024,24601,25628,90139,90154,83116,8328,90154,345263,70814,20664,2185,8373,9396,173,168,66598,513]

theorem envBound25842 : H12AffineFastState.Bounded env25842 := by
  intro p hp
  have h : env25842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25835_25842 : H12AffineEnvironment.transform 7 173 env25835 = env25842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env25835 == env25842) = true)

theorem identity25842 : scanCanonicalize (H12AffineFastState.compose env25842 (packedSelected [13,17] rootPS)) = affineNative (2^(17+1) ^^^ 68631) := by decide +kernel

theorem selectedBound25842 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env25843 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,24601,65536,87078,68631,1024,24601,25628,90139,90154,83116,8328,90154,18616,70814,20664,2185,8373,9396,173,168,66598,513]

theorem envBound25843 : H12AffineFastState.Bounded env25843 := by
  intro p hp
  have h : env25843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25842_25843 : H12AffineEnvironment.transform 17 68631 env25842 = env25843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 68631 env25842 == env25843) = true)

theorem identity25843 : scanCanonicalize (H12AffineFastState.compose env25843 (packedSelected [1,3,5,8,10,12] rootPS)) = affineNative (2^(15+1) ^^^ 17446) := by decide +kernel

theorem selectedBound25843 : packedSelected [1,3,5,8,10,12] rootPS < 2^1333 := by decide +kernel

def env25844 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,24601,17446,4096,18481,1024,24601,25628,9277,9228,138,8328,9228,18616,20664,20664,2185,8373,9396,173,168,16384,513]

theorem envBound25844 : H12AffineFastState.Bounded env25844 := by
  intro p hp
  have h : env25844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25843_25844 : H12AffineEnvironment.transform 15 17446 env25843 = env25844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 17446 env25843 == env25844) = true)

theorem identity25844 : scanCanonicalize (H12AffineFastState.compose env25844 (packedSelected [1,3] rootPS)) = affineNative (2^(13+1) ^^^ 1583) := by decide +kernel

theorem selectedBound25844 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env25845 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1583,9782,521,4096,3614,1024,9782,8755,9277,9228,138,8328,9228,3735,5783,5783,2185,8373,9396,173,168,1583,513]

theorem envBound25845 : H12AffineFastState.Bounded env25845 := by
  intro p hp
  have h : env25845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25844_25845 : H12AffineEnvironment.transform 13 1583 env25844 = env25845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1583 env25844 == env25845) = true)

theorem identity25845 : scanCanonicalize (H12AffineFastState.compose env25845 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound25845 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env25846 : List Nat := [2,4,8,16,32,17,128,173,512,1024,1077,4096,8192,1583,9782,521,4096,555,1024,9782,8755,9277,9228,138,8328,9228,674,5783,5783,1212,8373,9396,173,168,1583,513]

theorem envBound25846 : H12AffineFastState.Bounded env25846 := by
  intro p hp
  have h : env25846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25845_25846 : H12AffineEnvironment.transform 10 1077 env25845 = env25846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env25845 == env25846) = true)

def env25847 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,2248769,16777216,8328,2248721,134217728,151429283,151302307,4294795,16876545,151490696,257,138907683,155701329,513]

theorem envBound25847 : H12AffineFastState.Bounded env25847 := by
  intro p hp
  have h : env25847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25783_25847 : H12AffineEnvironment.transform 18 1025 env25783 = env25847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env25783 == env25847) = true)

def env25848 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,2248769,16777216,8328,2248721,21331968,4399267,4272291,4294795,16876545,4329608,257,16912419,151633,513]

theorem envBound25848 : H12AffineFastState.Bounded env25848 := by
  intro p hp
  have h : env25848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25847_25848 : H12AffineEnvironment.transform 26 21331968 env25847 = env25848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 21331968 env25847 == env25848) = true)

theorem identity25848 : scanCanonicalize (H12AffineFastState.compose env25848 (packedSelected [14] rootPS)) = affineNative (2^(21+1) ^^^ 2143444) := by decide +kernel

theorem selectedBound25848 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env25849 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,2143444,2248769,16777216,8328,2248721,19215572,2331767,2196599,2178143,16876545,2270300,257,16912419,151633,513]

theorem envBound25849 : H12AffineFastState.Bounded env25849 := by
  intro p hp
  have h : env25849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25848_25849 : H12AffineEnvironment.transform 21 2143444 env25848 = env25849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2143444 env25848 == env25849) = true)

theorem identity25849 : scanCanonicalize (H12AffineFastState.compose env25849 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(23+1) ^^^ 120145) := by decide +kernel

theorem selectedBound25849 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env25850 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,2143444,2248769,120145,8328,2248721,2417029,2331767,2196599,2178143,20816,2270300,257,247154,151633,513]

theorem envBound25850 : H12AffineFastState.Bounded env25850 := by
  intro p hp
  have h : env25850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25849_25850 : H12AffineEnvironment.transform 23 120145 env25849 = env25850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 120145 env25849 == env25850) = true)

theorem identity25850 : scanCanonicalize (H12AffineFastState.compose env25850 (packedSelected [13,21] rootPS)) = affineNative (2^(16+1) ^^^ 45404) := by decide +kernel

theorem selectedBound25850 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env25851 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,45404,262144,1025,32768,2097152,2143444,2154781,120145,8328,2154829,2417029,2172203,2196599,2178143,20816,2102528,257,95278,57613,513]

theorem envBound25851 : H12AffineFastState.Bounded env25851 := by
  intro p hp
  have h : env25851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25850_25851 : H12AffineEnvironment.transform 16 45404 env25850 = env25851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45404 env25850 == env25851) = true)

theorem identity25851 : scanCanonicalize (H12AffineFastState.compose env25851 (packedSelected [0,3,5,10,27] rootPS)) = affineNative (2^(20+1) ^^^ 5125) := by decide +kernel

theorem selectedBound25851 : packedSelected [0,3,5,10,27] rootPS < 2^1333 := by decide +kernel

def env25852 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,45404,262144,1025,32768,5125,41169,62744,120145,8328,62792,324992,78126,102514,75866,20816,261,257,95278,57613,513]

theorem envBound25852 : H12AffineFastState.Bounded env25852 := by
  intro p hp
  have h : env25852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25851_25852 : H12AffineEnvironment.transform 20 5125 env25851 = env25852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5125 env25851 == env25852) = true)

theorem identity25852 : scanCanonicalize (H12AffineFastState.compose env25852 (packedSelected [1,5,8,12,15,17,24] rootPS)) = affineNative (2^(15+1) ^^^ 32883) := by decide +kernel

theorem selectedBound25852 : packedSelected [1,5,8,12,15,17,24] rootPS < 2^1333 := by decide +kernel

def env25853 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,32883,45404,262144,1025,32768,5125,41169,62744,21794,8328,62792,324992,45405,4097,43049,20816,261,257,62557,57613,513]

theorem envBound25853 : H12AffineFastState.Bounded env25853 := by
  intro p hp
  have h : env25853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25852_25853 : H12AffineEnvironment.transform 15 32883 env25852 = env25853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32883 env25852 == env25853) = true)

theorem identity25853 : scanCanonicalize (H12AffineFastState.compose env25853 (packedSelected [2,3,6,8,10,11,13,17,18] rootPS)) = affineNative (2^(17+1) ^^^ 54126) := by decide +kernel

theorem selectedBound25853 : packedSelected [2,3,6,8,10,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env25854 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,32883,45404,54126,1025,32768,5125,41169,62744,21794,8328,62792,9966,45405,4097,43049,20816,261,257,62557,57613,513]

theorem envBound25854 : H12AffineFastState.Bounded env25854 := by
  intro p hp
  have h : env25854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25853_25854 : H12AffineEnvironment.transform 17 54126 env25853 = env25854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 54126 env25853 == env25854) = true)

def env25855 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29960,30075,17492,9830,1025,29960,5125,21977,16,21794,8328,64,9966,17493,4097,23841,20816,261,257,341,5125,513]

theorem envBound25855 : H12AffineFastState.Bounded env25855 := by
  intro p hp
  have h : env25855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25854_25855 : H12AffineEnvironment.transform 14 29960 env25854 = env25855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29960 env25854 == env25855) = true)

theorem identity25855 : scanCanonicalize (H12AffineFastState.compose env25855 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound25855 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env25856 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,8192,16384,25945,25898,17492,9830,1025,25945,1108,17800,16,17779,8328,64,9966,17493,80,19824,16641,261,257,341,1108,513]

theorem envBound25856 : H12AffineFastState.Bounded env25856 := by
  intro p hp
  have h : env25856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25855_25856 : H12AffineEnvironment.transform 11 81 env25855 = env25856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env25855 == env25856) = true)

theorem identity25856 : scanCanonicalize (H12AffineFastState.compose env25856 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(12+1) ^^^ 1733) := by decide +kernel

theorem selectedBound25856 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env25857 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,1733,16384,17308,17391,17492,163,1025,17308,1108,17800,16,17779,1613,64,43,17493,80,19824,16641,261,257,341,1108,513]

theorem envBound25857 : H12AffineFastState.Bounded env25857 := by
  intro p hp
  have h : env25857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25856_25857 : H12AffineEnvironment.transform 12 1733 env25856 = env25857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1733 env25856 == env25857) = true)

def env25858 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1,1685,16384,17308,17343,17412,163,1025,17308,1028,17800,16,17699,1565,16,43,17413,0,19744,16641,261,257,261,1028,513]

theorem envBound25858 : H12AffineFastState.Bounded env25858 := by
  intro p hp
  have h : env25858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25857_25858 : H12AffineEnvironment.transform 5 16 env25857 = env25858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env25857 == env25858) = true)

theorem identity25858 : scanCanonicalize (H12AffineFastState.compose env25858 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 925) := by decide +kernel

theorem selectedBound25858 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env25859 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1,1685,925,1,34,1945,163,1025,1,1028,1557,16,1726,1565,16,43,1944,0,3773,668,261,257,261,1028,513]

theorem envBound25859 : H12AffineFastState.Bounded env25859 := by
  intro p hp
  have h : env25859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25858_25859 : H12AffineEnvironment.transform 13 925 env25858 = env25859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 925 env25858 == env25859) = true)

theorem identity25859 : scanCanonicalize (H12AffineFastState.compose env25859 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound25859 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25860 : List Nat := [2,4,8,16,32,16,128,20,512,1024,2048,1,1685,649,1,34,1677,163,1025,1,1028,1557,16,1726,1565,16,43,1676,0,3773,668,17,21,17,1028,513]

theorem envBound25860 : H12AffineFastState.Bounded env25860 := by
  intro p hp
  have h : env25860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25859_25860 : H12AffineEnvironment.transform 7 20 env25859 = env25860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env25859 == env25860) = true)

theorem identity25860 : scanCanonicalize (H12AffineFastState.compose env25860 (packedSelected [1,8,12] rootPS)) = affineNative (2^(9+1) ^^^ 652) := by decide +kernel

theorem selectedBound25860 : packedSelected [1,8,12] rootPS < 2^1333 := by decide +kernel

def env25861 : List Nat := [2,4,8,16,32,16,128,20,512,652,2048,1,25,649,1,34,1,163,653,1,648,153,16,50,145,16,43,0,0,2097,668,17,21,17,648,513]

theorem envBound25861 : H12AffineFastState.Bounded env25861 := by
  intro p hp
  have h : env25861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25860_25861 : H12AffineEnvironment.transform 9 652 env25860 = env25861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 652 env25860 == env25861) = true)

theorem identity25861 : scanCanonicalize (H12AffineFastState.compose env25861 (packedSelected [1,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 14) := by decide +kernel

theorem selectedBound25861 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env25862 : List Nat := [2,4,8,16,32,16,14,20,512,514,2048,1,25,519,1,34,1,45,515,1,518,23,16,50,31,16,43,0,0,2097,530,17,21,17,518,513]

theorem envBound25862 : H12AffineFastState.Bounded env25862 := by
  intro p hp
  have h : env25862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25861_25862 : H12AffineEnvironment.transform 6 14 env25861 = env25862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 14 env25861 == env25862) = true)

theorem identity25862 : scanCanonicalize (H12AffineFastState.compose env25862 (packedSelected [1,3,8] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound25862 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env25863 : List Nat := [2,4,8,16,32,16,14,20,512,514,43,1,25,519,1,34,1,45,515,1,518,23,16,50,31,16,43,0,0,26,530,17,21,17,518,513]

theorem envBound25863 : H12AffineFastState.Bounded env25863 := by
  intro p hp
  have h : env25863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25862_25863 : H12AffineEnvironment.transform 10 43 env25862 = env25863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env25862 == env25863) = true)

theorem identity25863 : scanCanonicalize (H12AffineFastState.compose env25863 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound25863 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env25864 : List Nat := [2,4,8,16,13,16,14,20,512,514,6,1,25,519,1,15,1,0,515,1,518,23,16,31,31,16,6,0,0,26,530,17,21,17,518,513]

theorem envBound25864 : H12AffineFastState.Bounded env25864 := by
  intro p hp
  have h : env25864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25863_25864 : H12AffineEnvironment.transform 4 13 env25863 = env25864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env25863 == env25864) = true)

theorem identity25864 : scanCanonicalize (H12AffineFastState.compose env25864 (packedSelected [7] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound25864 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env25865 : List Nat := [2,4,8,11,13,11,14,15,512,514,6,1,2,519,1,15,1,0,515,1,518,12,11,4,4,11,6,0,0,1,521,10,14,10,518,513]

theorem envBound25865 : H12AffineFastState.Bounded env25865 := by
  intro p hp
  have h : env25865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25864_25865 : H12AffineEnvironment.transform 3 11 env25864 = env25865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env25864 == env25865) = true)

theorem identity25865 : scanCanonicalize (H12AffineFastState.compose env25865 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound25865 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25866 : List Nat := [2,3,8,11,10,11,9,8,512,514,1,1,2,512,1,8,1,0,515,1,513,11,11,3,3,11,1,0,0,1,521,10,9,10,513,513]

theorem envBound25866 : H12AffineFastState.Bounded env25866 := by
  intro p hp
  have h : env25866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25865_25866 : H12AffineEnvironment.transform 1 3 env25865 = env25866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env25865 == env25866) = true)

theorem identity25866 : scanCanonicalize (H12AffineFastState.compose env25866 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound25866 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25867 : List Nat := [2,3,8,11,10,11,9,8,1,3,1,1,2,1,1,8,1,0,2,1,0,11,11,3,3,11,1,0,0,1,8,10,9,10,0,0]

theorem envBound25867 : H12AffineFastState.Bounded env25867 := by
  intro p hp
  have h : env25867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25866_25867 : H12AffineEnvironment.transform 8 1 env25866 = env25867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env25866 == env25867) = true)

def env25868 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,0,1684,16384,17308,17342,17413,163,1025,17308,1029,17800,16,17698,1564,17,43,17412,1,19745,16641,261,257,260,1029,513]

theorem envBound25868 : H12AffineFastState.Bounded env25868 := by
  intro p hp
  have h : env25868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25857_25868 : H12AffineEnvironment.transform 5 17 env25857 = env25868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env25857 == env25868) = true)

theorem identity25868 : scanCanonicalize (H12AffineFastState.compose env25868 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 921) := by decide +kernel

theorem selectedBound25868 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env25869 : List Nat := [2,4,8,16,32,17,128,256,512,921,2048,0,269,16384,17308,17342,17308,163,920,17308,924,16913,16,17083,389,17,43,17309,1,19128,16641,261,257,260,924,513]

theorem envBound25869 : H12AffineFastState.Bounded env25869 := by
  intro p hp
  have h : env25869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25868_25869 : H12AffineEnvironment.transform 9 921 env25868 = env25869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 921 env25868 == env25869) = true)

theorem identity25869 : scanCanonicalize (H12AffineFastState.compose env25869 (packedSelected [2,5,8] rootPS)) = affineNative (2^(13+1) ^^^ 2831) := by decide +kernel

theorem selectedBound25869 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env25870 : List Nat := [2,4,8,16,32,17,128,256,512,921,2048,0,269,2831,2195,2225,2195,163,920,2195,924,2334,16,2484,389,17,43,2194,1,439,2574,261,257,260,924,513]

theorem envBound25870 : H12AffineFastState.Bounded env25870 := by
  intro p hp
  have h : env25870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25869_25870 : H12AffineEnvironment.transform 13 2831 env25869 = env25870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2831 env25869 == env25870) = true)

theorem identity25870 : scanCanonicalize (H12AffineFastState.compose env25870 (packedSelected [0,1,2,4,5,7,9,12] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound25870 : packedSelected [0,1,2,4,5,7,9,12] rootPS < 2^1333 := by decide +kernel

def env25871 : List Nat := [2,4,8,16,32,17,128,173,512,564,2048,0,160,2722,2195,2225,2195,163,565,2195,561,2227,16,2073,40,17,43,2194,1,26,2574,168,172,169,561,513]

theorem envBound25871 : H12AffineFastState.Bounded env25871 := by
  intro p hp
  have h : env25871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25870_25871 : H12AffineEnvironment.transform 7 173 env25870 = env25871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env25870 == env25871) = true)

theorem identity25871 : scanCanonicalize (H12AffineFastState.compose env25871 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound25871 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25872 : List Nat := [2,4,8,16,32,17,57,20,512,564,2048,0,25,2587,2090,2056,2090,26,565,2090,561,2058,16,2073,40,17,43,2091,1,26,2574,17,21,16,561,513]

theorem envBound25872 : H12AffineFastState.Bounded env25872 := by
  intro p hp
  have h : env25872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25871_25872 : H12AffineEnvironment.transform 6 57 env25871 = env25872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env25871 == env25872) = true)

theorem identity25872 : scanCanonicalize (H12AffineFastState.compose env25872 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 27) := by decide +kernel

theorem selectedBound25872 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env25873 : List Nat := [2,4,8,16,32,17,57,20,512,564,27,0,25,512,49,19,49,26,565,49,561,17,16,2,40,17,43,48,1,26,533,17,21,16,561,513]

theorem envBound25873 : H12AffineFastState.Bounded env25873 := by
  intro p hp
  have h : env25873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25872_25873 : H12AffineEnvironment.transform 10 27 env25872 = env25873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 27 env25872 == env25873) = true)

theorem identity25873 : scanCanonicalize (H12AffineFastState.compose env25873 (packedSelected [0,1,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound25873 : packedSelected [0,1,3,5] rootPS < 2^1333 := by decide +kernel

def env25874 : List Nat := [2,4,8,16,16,17,9,20,512,516,27,0,25,512,1,19,1,26,517,1,513,17,16,2,24,17,27,0,1,26,533,17,21,16,513,513]

theorem envBound25874 : H12AffineFastState.Bounded env25874 := by
  intro p hp
  have h : env25874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25873_25874 : H12AffineEnvironment.transform 4 16 env25873 = env25874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env25873 == env25874) = true)

theorem identity25874 : scanCanonicalize (H12AffineFastState.compose env25874 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 7) := by decide +kernel

theorem selectedBound25874 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25875 : List Nat := [2,4,8,16,16,17,9,20,7,3,27,0,25,7,1,19,1,26,2,1,6,17,16,2,24,17,27,0,1,26,18,17,21,16,6,6]

theorem envBound25875 : H12AffineFastState.Bounded env25875 := by
  intro p hp
  have h : env25875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25874_25875 : H12AffineEnvironment.transform 8 7 env25874 = env25875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 7 env25874 == env25875) = true)

def env25876 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29961,30074,17493,9831,1025,29961,5125,21976,17,21794,8328,65,9966,17492,4097,23840,20816,261,257,340,5124,513]

theorem envBound25876 : H12AffineFastState.Bounded env25876 := by
  intro p hp
  have h : env25876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25854_25876 : H12AffineEnvironment.transform 14 29961 env25854 = env25876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29961 env25854 == env25876) = true)

theorem identity25876 : scanCanonicalize (H12AffineFastState.compose env25876 (packedSelected [6] rootPS)) = affineNative (2^(13+1) ^^^ 1028) := by decide +kernel

theorem selectedBound25876 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env25877 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1028,12557,12670,81,9831,1025,12557,5125,4572,17,4390,8328,65,9966,80,4097,6436,5460,261,257,340,5124,513]

theorem envBound25877 : H12AffineFastState.Bounded env25877 := by
  intro p hp
  have h : env25877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25876_25877 : H12AffineEnvironment.transform 13 1028 env25876 = env25877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1028 env25876 == env25877) = true)

theorem identity25877 : scanCanonicalize (H12AffineFastState.compose env25877 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(12+1) ^^^ 5828) := by decide +kernel

theorem selectedBound25877 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env25878 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5828,1028,1993,1978,81,4259,1025,1993,5125,4572,17,4390,5708,65,4138,80,4097,6436,5460,261,257,340,5124,513]

theorem envBound25878 : H12AffineFastState.Bounded env25878 := by
  intro p hp
  have h : env25878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25877_25878 : H12AffineEnvironment.transform 12 5828 env25877 = env25878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5828 env25877 == env25878) = true)

def env25879 : List Nat := [2,4,8,16,32,64,128,256,512,920,2048,4096,4444,924,81,34,81,4259,921,81,5021,4572,17,4390,4564,65,4138,80,4097,6436,4812,261,257,340,5020,513]

theorem envBound25879 : H12AffineFastState.Bounded env25879 := by
  intro p hp
  have h : env25879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25878_25879 : H12AffineEnvironment.transform 9 920 env25878 = env25879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 920 env25878 == env25879) = true)

theorem identity25879 : scanCanonicalize (H12AffineFastState.compose env25879 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 105) := by decide +kernel

theorem selectedBound25879 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env25880 : List Nat := [2,4,8,16,32,64,105,256,512,881,2048,4096,4444,885,81,34,81,4170,880,81,4980,4405,17,4390,4413,65,4138,80,4097,6436,4645,261,257,340,4981,513]

theorem envBound25880 : H12AffineFastState.Bounded env25880 := by
  intro p hp
  have h : env25880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25879_25880 : H12AffineEnvironment.transform 6 105 env25879 = env25880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 105 env25879 == env25880) = true)

theorem identity25880 : scanCanonicalize (H12AffineFastState.compose env25880 (packedSelected [0,1,2,4,7,8,9,12] rootPS)) = affineNative (2^(11+1) ^^^ 2415) := by decide +kernel

theorem selectedBound25880 : packedSelected [0,1,2,4,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env25881 : List Nat := [2,4,8,16,32,64,105,256,512,881,2048,2415,2099,885,81,34,81,2341,880,81,2587,2138,17,2121,2130,65,2373,80,2414,75,2890,261,257,340,2586,513]

theorem envBound25881 : H12AffineFastState.Bounded env25881 := by
  intro p hp
  have h : env25881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25880_25881 : H12AffineEnvironment.transform 11 2415 env25880 = env25881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2415 env25880 == env25881) = true)

theorem identity25881 : scanCanonicalize (H12AffineFastState.compose env25881 (packedSelected [1,3,5,8,13] rootPS)) = affineNative (2^(10+1) ^^^ 367) := by decide +kernel

theorem selectedBound25881 : packedSelected [1,3,5,8,13] rootPS < 2^1333 := by decide +kernel

def env25882 : List Nat := [2,4,8,16,32,64,105,256,512,881,367,0,348,885,81,34,81,74,880,81,884,309,17,294,317,65,42,80,1,75,549,261,257,340,885,513]

theorem envBound25882 : H12AffineFastState.Bounded env25882 := by
  intro p hp
  have h : env25882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25881_25882 : H12AffineEnvironment.transform 10 367 env25881 = env25882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 367 env25881 == env25882) = true)

theorem identity25882 : scanCanonicalize (H12AffineFastState.compose env25882 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound25882 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25883 : List Nat := [2,4,8,16,32,17,56,256,512,800,318,0,269,804,0,34,0,27,801,0,805,309,17,294,317,16,42,1,1,26,549,261,257,261,804,513]

theorem envBound25883 : H12AffineFastState.Bounded env25883 := by
  intro p hp
  have h : env25883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25882_25883 : H12AffineEnvironment.transform 5 17 env25882 = env25883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env25882 == env25883) = true)

theorem identity25883 : scanCanonicalize (H12AffineFastState.compose env25883 (packedSelected [0,1,4] rootPS)) = affineNative (2^(8+1) ^^^ 259) := by decide +kernel

theorem selectedBound25883 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env25884 : List Nat := [2,4,8,16,32,17,56,256,259,35,318,0,269,39,0,34,0,27,34,0,38,309,17,294,317,16,42,1,1,26,294,261,257,261,39,258]

theorem envBound25884 : H12AffineFastState.Bounded env25884 := by
  intro p hp
  have h : env25884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25883_25884 : H12AffineEnvironment.transform 8 259 env25883 = env25884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 259 env25883 == env25884) = true)

theorem identity25884 : scanCanonicalize (H12AffineFastState.compose env25884 (packedSelected [3,5] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound25884 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env25885 : List Nat := [2,4,4,16,32,17,52,256,259,35,306,0,257,39,0,34,0,23,34,0,38,309,17,294,305,16,38,1,1,22,294,261,257,261,39,258]

theorem envBound25885 : H12AffineFastState.Bounded env25885 := by
  intro p hp
  have h : env25885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25884_25885 : H12AffineEnvironment.transform 2 4 env25884 = env25885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env25884 == env25885) = true)

def env25886 : List Nat := [2,4,8,16,32,64,128,256,512,921,2048,4096,4445,925,80,35,81,4259,920,80,5020,4572,17,4390,4565,65,4138,80,4097,6436,4813,261,257,340,5021,513]

theorem envBound25886 : H12AffineFastState.Bounded env25886 := by
  intro p hp
  have h : env25886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25878_25886 : H12AffineEnvironment.transform 9 921 env25878 = env25886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 921 env25878 == env25886) = true)

theorem identity25886 : scanCanonicalize (H12AffineFastState.compose env25886 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 324) := by decide +kernel

theorem selectedBound25886 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env25887 : List Nat := [2,4,8,16,32,64,128,256,512,921,2048,324,25,925,80,35,81,487,920,80,728,152,17,98,145,65,366,80,325,2144,905,261,257,340,729,513]

theorem envBound25887 : H12AffineFastState.Bounded env25887 := by
  intro p hp
  have h : env25887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25886_25887 : H12AffineEnvironment.transform 11 324 env25886 = env25887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 324 env25886 == env25887) = true)

theorem identity25887 : scanCanonicalize (H12AffineFastState.compose env25887 (packedSelected [1,8,12] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound25887 : packedSelected [1,8,12] rootPS < 2^1333 := by decide +kernel

def env25888 : List Nat := [2,4,8,16,32,64,128,69,512,732,2048,1,25,728,80,35,81,162,733,80,728,152,17,98,145,65,43,80,0,2144,716,64,68,17,729,513]

theorem envBound25888 : H12AffineFastState.Bounded env25888 := by
  intro p hp
  have h : env25888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25887_25888 : H12AffineEnvironment.transform 7 69 env25887 = env25888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env25887 == env25888) = true)

def env25889 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,2248769,16777216,8328,2248721,21331969,4399266,4272290,4294795,16876545,4329609,257,16912418,151632,513]

theorem envBound25889 : H12AffineFastState.Bounded env25889 := by
  intro p hp
  have h : env25889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25847_25889 : H12AffineEnvironment.transform 26 21331969 env25847 = env25889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 21331969 env25847 == env25889) = true)

theorem identity25889 : scanCanonicalize (H12AffineFastState.compose env25889 (packedSelected [14] rootPS)) = affineNative (2^(21+1) ^^^ 42196) := by decide +kernel

theorem selectedBound25889 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env25890 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,42196,2248769,16777216,8328,2248721,17114325,230518,103542,76895,16876545,177245,257,16912418,151632,513]

theorem envBound25890 : H12AffineFastState.Bounded env25890 := by
  intro p hp
  have h : env25890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25889_25890 : H12AffineEnvironment.transform 21 42196 env25889 = env25890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 42196 env25889 == env25890) = true)

theorem identity25890 : scanCanonicalize (H12AffineFastState.compose env25890 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(20+1) ^^^ 249970) := by decide +kernel

theorem selectedBound25890 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env25891 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,249970,42196,98355,16777216,8328,98403,17114325,230518,103542,76895,16876545,177245,257,16912418,151632,513]

theorem envBound25891 : H12AffineFastState.Bounded env25891 := by
  intro p hp
  have h : env25891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25890_25891 : H12AffineEnvironment.transform 20 249970 env25890 = env25891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 249970 env25890 == env25891) = true)

theorem identity25891 : scanCanonicalize (H12AffineFastState.compose env25891 (packedSelected [13,21] rootPS)) = affineNative (2^(23+1) ^^^ 210012) := by decide +kernel

theorem selectedBound25891 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env25892 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,249970,42196,98355,210012,8328,98403,397449,230518,103542,76895,176221,177245,257,74878,151632,513]

theorem envBound25892 : H12AffineFastState.Bounded env25892 := by
  intro p hp
  have h : env25892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25891_25892 : H12AffineEnvironment.transform 23 210012 env25891 = env25892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 210012 env25891 == env25892) = true)

def env25893 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,8328,67108864,134217728,226926835,226799859,4294795,92374097,151490696,525568,138907683,224755777,513]

theorem envBound25893 : H12AffineFastState.Bounded env25893 := by
  intro p hp
  have h : env25893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25406_25893 : H12AffineEnvironment.transform 34 224755777 env25406 = env25893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 224755777 env25406 == env25893) = true)

def env25894 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,8328,8914000,134217728,151954595,151827619,4294795,17399809,151490696,525568,138907683,166560785,513]

theorem envBound25894 : H12AffineFastState.Bounded env25894 := by
  intro p hp
  have h : env25894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25893_25894 : H12AffineEnvironment.transform 25 8914000 env25893 = env25894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 8914000 env25893 == env25894) = true)

def env25895 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,2248768,16777216,8328,2774032,134217728,151954595,151827619,4294795,17399809,151490696,525568,138907683,156226641,513]

theorem envBound25895 : H12AffineFastState.Bounded env25895 := by
  intro p hp
  have h : env25895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25894_25895 : H12AffineEnvironment.transform 22 2248768 env25894 = env25895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2248768 env25894 == env25895) = true)

def env25896 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,2248768,16777216,8328,2248720,134217728,151429283,151302307,4294795,16876545,151490696,256,138907683,155701329,513]

theorem envBound25896 : H12AffineFastState.Bounded env25896 := by
  intro p hp
  have h : env25896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25895_25896 : H12AffineEnvironment.transform 18 1024 env25895 = env25896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env25895 == env25896) = true)

def env25897 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,2248768,16777216,8328,2248720,21331968,4399267,4272291,4294795,16876545,4329608,256,16912419,151633,513]

theorem envBound25897 : H12AffineFastState.Bounded env25897 := by
  intro p hp
  have h : env25897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25896_25897 : H12AffineEnvironment.transform 26 21331968 env25896 = env25897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 21331968 env25896 == env25897) = true)

theorem identity25897 : scanCanonicalize (H12AffineFastState.compose env25897 (packedSelected [14] rootPS)) = affineNative (2^(23+1) ^^^ 2229538) := by decide +kernel

theorem selectedBound25897 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env25898 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,2248768,2229538,8328,2248720,6784290,4399267,4272291,4294795,2326819,4329608,256,2102529,151633,513]

theorem envBound25898 : H12AffineFastState.Bounded env25898 := by
  intro p hp
  have h : env25898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25897_25898 : H12AffineEnvironment.transform 23 2229538 env25897 = env25898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2229538 env25897 == env25898) = true)

theorem identity25898 : scanCanonicalize (H12AffineFastState.compose env25898 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(21+1) ^^^ 222375) := by decide +kernel

theorem selectedBound25898 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env25899 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,222375,2248768,2229538,8328,2248720,2417029,17412,152580,191532,2326819,95279,256,2102529,151633,513]

theorem envBound25899 : H12AffineFastState.Bounded env25899 := by
  intro p hp
  have h : env25899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25898_25899 : H12AffineEnvironment.transform 21 222375 env25898 = env25899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 222375 env25898 == env25899) = true)

theorem identity25899 : scanCanonicalize (H12AffineFastState.compose env25899 (packedSelected [13,21] rootPS)) = affineNative (2^(16+1) ^^^ 45405) := by decide +kernel

theorem selectedBound25899 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env25900 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,45405,262144,1024,32768,2097152,120314,2154781,2143359,8328,2154829,2417029,17412,58713,23921,2175102,95279,256,2102529,57612,513]

theorem envBound25900 : H12AffineFastState.Bounded env25900 := by
  intro p hp
  have h : env25900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25899_25900 : H12AffineEnvironment.transform 16 45405 env25899 = env25900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45405 env25899 == env25900) = true)

theorem identity25900 : scanCanonicalize (H12AffineFastState.compose env25900 (packedSelected [0,3,5,10,27] rootPS)) = affineNative (2^(15+1) ^^^ 29995) := by decide +kernel

theorem selectedBound25900 : packedSelected [0,3,5,10,27] rootPS < 2^1333 := by decide +kernel

def env25901 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,29995,45405,262144,1024,32768,2097152,41169,2154781,2143359,8328,2154829,2417029,17412,58713,23921,2114901,260,256,2102529,57612,513]

theorem envBound25901 : H12AffineFastState.Bounded env25901 := by
  intro p hp
  have h : env25901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25900_25901 : H12AffineEnvironment.transform 15 29995 env25900 = env25901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29995 env25900 == env25901) = true)

theorem identity25901 : scanCanonicalize (H12AffineFastState.compose env25901 (packedSelected [1,5,8,12,15,17,24] rootPS)) = affineNative (2^(14+1) ^^^ 30040) := by decide +kernel

theorem selectedBound25901 : packedSelected [1,5,8,12,15,17,24] rootPS < 2^1333 := by decide +kernel

def env25902 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,30040,29995,17413,262144,1024,30040,2097152,21897,2102341,2113831,8328,2102293,2364637,17412,4097,23921,2114901,260,256,2102529,5204,513]

theorem envBound25902 : H12AffineFastState.Bounded env25902 := by
  intro p hp
  have h : env25902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25901_25902 : H12AffineEnvironment.transform 14 30040 env25901 = env25902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 30040 env25901 == env25902) = true)

theorem identity25902 : scanCanonicalize (H12AffineFastState.compose env25902 (packedSelected [2,3,6,8,10,11,13,17,18] rootPS)) = affineNative (2^(17+1) ^^^ 29282) := by decide +kernel

theorem selectedBound25902 : packedSelected [2,3,6,8,10,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env25903 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,30040,29995,17413,29282,1024,30040,2097152,21897,2102341,2113831,8328,2102293,2123455,17412,4097,23921,2114901,260,256,2102529,5204,513]

theorem envBound25903 : H12AffineFastState.Bounded env25903 := by
  intro p hp
  have h : env25903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25902_25903 : H12AffineEnvironment.transform 17 29282 env25902 = env25903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 29282 env25902 == env25903) = true)

def env25904 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,30040,29995,17413,29282,1024,30040,16464,21897,21525,375,8328,21573,9967,17412,4097,23921,1285,260,256,21841,5204,513]

theorem envBound25904 : H12AffineFastState.Bounded env25904 := by
  intro p hp
  have h : env25904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25903_25904 : H12AffineEnvironment.transform 20 16464 env25903 = env25904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 16464 env25903 == env25904) = true)

theorem identity25904 : scanCanonicalize (H12AffineFastState.compose env25904 (packedSelected [6] rootPS)) = affineNative (2^(13+1) ^^^ 1109) := by decide +kernel

theorem selectedBound25904 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env25905 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1109,12557,12670,80,13879,1024,12557,1029,4572,4160,375,8328,4112,9967,81,4097,6436,1285,260,256,4356,5204,513]

theorem envBound25905 : H12AffineFastState.Bounded env25905 := by
  intro p hp
  have h : env25905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25904_25905 : H12AffineEnvironment.transform 13 1109 env25904 = env25905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1109 env25904 == env25905) = true)

theorem identity25905 : scanCanonicalize (H12AffineFastState.compose env25905 (packedSelected [3,8,10,13,17] rootPS)) = affineNative (2^(9+1) ^^^ 921) := by decide +kernel

theorem selectedBound25905 : packedSelected [3,8,10,13,17] rootPS < 2^1333 := by decide +kernel

def env25906 : List Nat := [2,4,8,16,32,64,128,256,512,921,2048,4096,8192,972,12557,12670,80,12718,921,12557,924,4572,4160,375,8328,4112,8566,81,4097,6436,668,260,256,4356,5069,513]

theorem envBound25906 : H12AffineFastState.Bounded env25906 := by
  intro p hp
  have h : env25906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25905_25906 : H12AffineEnvironment.transform 9 921 env25905 = env25906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 921 env25905 == env25906) = true)

def env25907 : List Nat := [2,4,8,16,32,64,128,256,512,921,2048,4096,240,972,4605,4494,80,4446,921,4605,924,4572,4160,375,120,4112,390,81,4097,6436,668,260,256,4356,5069,513]

theorem envBound25907 : H12AffineFastState.Bounded env25907 := by
  intro p hp
  have h : env25907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25906_25907 : H12AffineEnvironment.transform 12 240 env25906 = env25907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 240 env25906 == env25907) = true)

theorem identity25907 : scanCanonicalize (H12AffineFastState.compose env25907 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 233) := by decide +kernel

theorem selectedBound25907 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25908 : List Nat := [2,4,8,16,32,64,128,256,512,921,2048,233,240,972,276,359,80,439,921,276,924,309,169,375,120,249,390,81,232,2509,668,260,256,493,804,513]

theorem envBound25908 : H12AffineFastState.Bounded env25908 := by
  intro p hp
  have h : env25908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25907_25908 : H12AffineEnvironment.transform 11 233 env25907 = env25908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 233 env25907 == env25908) = true)

theorem identity25908 : scanCanonicalize (H12AffineFastState.compose env25908 (packedSelected [4,5,8,9,11] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound25908 : packedSelected [4,5,8,9,11] rootPS < 2^1333 := by decide +kernel

def env25909 : List Nat := [2,4,8,16,32,64,128,252,512,613,2048,233,240,560,232,155,80,75,613,232,608,201,169,139,120,249,122,81,232,2097,668,248,252,17,728,513]

theorem envBound25909 : H12AffineFastState.Bounded env25909 := by
  intro p hp
  have h : env25909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25908_25909 : H12AffineEnvironment.transform 7 252 env25908 = env25909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env25908 == env25909) = true)

theorem identity25909 : scanCanonicalize (H12AffineFastState.compose env25909 (packedSelected [3,8,10] rootPS)) = affineNative (2^(10+1) ^^^ 122) := by decide +kernel

theorem selectedBound25909 : packedSelected [3,8,10] rootPS < 2^1333 := by decide +kernel

def env25910 : List Nat := [2,4,8,16,32,64,128,252,512,613,122,233,240,560,232,155,80,75,613,232,608,201,169,139,120,249,122,81,232,75,668,248,252,17,728,513]

theorem envBound25910 : H12AffineFastState.Bounded env25910 := by
  intro p hp
  have h : env25910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25909_25910 : H12AffineEnvironment.transform 10 122 env25909 = env25910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 122 env25909 == env25910) = true)

theorem identity25910 : scanCanonicalize (H12AffineFastState.compose env25910 (packedSelected [4,7] rootPS)) = affineNative (2^(6+1) ^^^ 104) := by decide +kernel

theorem selectedBound25910 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env25911 : List Nat := [2,4,8,16,32,64,104,20,512,613,122,1,24,560,0,115,80,75,613,0,608,33,65,99,120,17,122,81,0,75,628,16,20,17,560,513]

theorem envBound25911 : H12AffineFastState.Bounded env25911 := by
  intro p hp
  have h : env25911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25910_25911 : H12AffineEnvironment.transform 6 104 env25910 = env25911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 104 env25910 == env25911) = true)

theorem identity25911 : scanCanonicalize (H12AffineFastState.compose env25911 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 61) := by decide +kernel

theorem selectedBound25911 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25912 : List Nat := [2,4,8,16,32,64,104,20,61,88,122,1,24,13,0,115,80,75,88,0,93,33,65,99,120,17,122,81,0,75,73,16,20,17,13,60]

theorem envBound25912 : H12AffineFastState.Bounded env25912 := by
  intro p hp
  have h : env25912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25911_25912 : H12AffineEnvironment.transform 8 61 env25911 = env25912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 61 env25911 == env25912) = true)

theorem identity25912 : scanCanonicalize (H12AffineFastState.compose env25912 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound25912 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env25913 : List Nat := [2,4,8,16,32,11,35,20,61,19,49,1,24,13,0,56,27,0,19,0,22,33,10,40,51,17,49,26,0,0,2,16,20,17,13,60]

theorem envBound25913 : H12AffineFastState.Bounded env25913 := by
  intro p hp
  have h : env25913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25912_25913 : H12AffineEnvironment.transform 5 11 env25912 = env25913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env25912 == env25913) = true)

theorem identity25913 : scanCanonicalize (H12AffineFastState.compose env25913 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound25913 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25914 : List Nat := [2,4,8,16,11,11,8,20,22,19,26,1,24,13,0,19,27,0,19,0,22,10,10,3,24,17,26,26,0,0,2,16,20,17,13,23]

theorem envBound25914 : H12AffineFastState.Bounded env25914 := by
  intro p hp
  have h : env25914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25913_25914 : H12AffineEnvironment.transform 4 11 env25913 = env25914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env25913 == env25914) = true)

def env25915 : List Nat := [2,4,8,16,32,64,128,256,512,921,2048,4096,241,972,4604,4495,80,4447,921,4604,924,4572,4160,375,121,4112,391,81,4097,6436,668,260,256,4356,5069,513]

theorem envBound25915 : H12AffineFastState.Bounded env25915 := by
  intro p hp
  have h : env25915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25906_25915 : H12AffineEnvironment.transform 12 241 env25906 = env25915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 241 env25906 == env25915) = true)

theorem identity25915 : scanCanonicalize (H12AffineFastState.compose env25915 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound25915 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25916 : List Nat := [2,4,8,16,32,64,128,256,512,921,2048,277,241,972,233,154,80,74,921,233,924,201,341,375,121,261,391,81,276,2097,668,260,256,17,728,513]

theorem envBound25916 : H12AffineFastState.Bounded env25916 := by
  intro p hp
  have h : env25916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25915_25916 : H12AffineEnvironment.transform 11 277 env25915 = env25916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env25915 == env25916) = true)

theorem identity25916 : scanCanonicalize (H12AffineFastState.compose env25916 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound25916 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env25917 : List Nat := [2,4,8,16,32,64,128,252,512,613,2048,233,241,560,233,154,80,74,613,233,608,201,169,139,121,249,123,81,232,2097,668,248,252,17,728,513]

theorem envBound25917 : H12AffineFastState.Bounded env25917 := by
  intro p hp
  have h : env25917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25916_25917 : H12AffineEnvironment.transform 7 252 env25916 = env25917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env25916 == env25917) = true)

theorem identity25917 : scanCanonicalize (H12AffineFastState.compose env25917 (packedSelected [3,8,10] rootPS)) = affineNative (2^(10+1) ^^^ 123) := by decide +kernel

theorem selectedBound25917 : packedSelected [3,8,10] rootPS < 2^1333 := by decide +kernel

def env25918 : List Nat := [2,4,8,16,32,64,128,252,512,613,123,233,241,560,233,154,80,74,613,233,608,201,169,139,121,249,123,81,232,74,668,248,252,17,728,513]

theorem envBound25918 : H12AffineFastState.Bounded env25918 := by
  intro p hp
  have h : env25918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25917_25918 : H12AffineEnvironment.transform 10 123 env25917 = env25918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 123 env25917 == env25918) = true)

theorem identity25918 : scanCanonicalize (H12AffineFastState.compose env25918 (packedSelected [4,7] rootPS)) = affineNative (2^(6+1) ^^^ 104) := by decide +kernel

theorem selectedBound25918 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env25919 : List Nat := [2,4,8,16,32,64,104,20,512,613,123,1,25,560,1,114,80,74,613,1,608,33,65,99,121,17,123,81,0,74,628,16,20,17,560,513]

theorem envBound25919 : H12AffineFastState.Bounded env25919 := by
  intro p hp
  have h : env25919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25918_25919 : H12AffineEnvironment.transform 6 104 env25918 = env25919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 104 env25918 == env25919) = true)

theorem identity25919 : scanCanonicalize (H12AffineFastState.compose env25919 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 60) := by decide +kernel

theorem selectedBound25919 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25920 : List Nat := [2,4,8,16,32,64,104,20,60,89,123,1,25,12,1,114,80,74,89,1,92,33,65,99,121,17,123,81,0,74,72,16,20,17,12,61]

theorem envBound25920 : H12AffineFastState.Bounded env25920 := by
  intro p hp
  have h : env25920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25919_25920 : H12AffineEnvironment.transform 8 60 env25919 = env25920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 60 env25919 == env25920) = true)

theorem identity25920 : scanCanonicalize (H12AffineFastState.compose env25920 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound25920 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env25921 : List Nat := [2,4,8,16,32,10,34,20,60,19,49,1,25,12,1,56,26,0,19,1,22,33,11,41,51,17,49,27,0,0,2,16,20,17,12,61]

theorem envBound25921 : H12AffineFastState.Bounded env25921 := by
  intro p hp
  have h : env25921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25920_25921 : H12AffineEnvironment.transform 5 10 env25920 = env25921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env25920 == env25921) = true)

theorem identity25921 : scanCanonicalize (H12AffineFastState.compose env25921 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound25921 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25922 : List Nat := [2,4,8,11,32,10,34,15,39,8,42,1,2,12,1,35,1,0,8,1,13,33,11,41,40,10,42,0,0,0,2,11,15,10,12,38]

theorem envBound25922 : H12AffineFastState.Bounded env25922 := by
  intro p hp
  have h : env25922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25921_25922 : H12AffineEnvironment.transform 3 11 env25921 = env25922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env25921 == env25922) = true)

theorem identity25922 : scanCanonicalize (H12AffineFastState.compose env25922 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound25922 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env25923 : List Nat := [2,4,8,11,10,10,8,15,13,8,0,1,2,12,1,9,1,0,8,1,13,11,11,3,2,10,0,0,0,0,2,11,15,10,12,12]

theorem envBound25923 : H12AffineFastState.Bounded env25923 := by
  intro p hp
  have h : env25923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25922_25923 : H12AffineEnvironment.transform 4 10 env25922 = env25923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env25922 == env25923) = true)

def env25924 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,30040,29995,17413,29282,1024,30040,16465,21897,21524,374,8328,21572,9966,17412,4097,23921,1284,260,256,21840,5204,513]

theorem envBound25924 : H12AffineFastState.Bounded env25924 := by
  intro p hp
  have h : env25924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25903_25924 : H12AffineEnvironment.transform 20 16465 env25903 = env25924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 16465 env25903 == env25924) = true)

theorem identity25924 : scanCanonicalize (H12AffineFastState.compose env25924 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound25924 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env25925 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,8192,16384,25864,25979,17413,25138,1024,25864,16465,17881,17476,374,8328,17428,9966,17412,81,19745,1284,260,256,17664,1028,513]

theorem envBound25925 : H12AffineFastState.Bounded env25925 := by
  intro p hp
  have h : env25925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25924_25925 : H12AffineEnvironment.transform 11 80 env25924 = env25925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env25924 == env25925) = true)

theorem identity25925 : scanCanonicalize (H12AffineFastState.compose env25925 (packedSelected [3,8,10,13,17] rootPS)) = affineNative (2^(9+1) ^^^ 969) := by decide +kernel

theorem selectedBound25925 : packedSelected [3,8,10,13,17] rootPS < 2^1333 := by decide +kernel

def env25926 : List Nat := [2,4,8,16,32,64,128,256,512,969,2048,80,8192,16384,25281,25266,17356,25138,969,25281,16465,16912,17293,374,8328,17373,8487,17357,81,19176,717,260,256,17097,973,513]

theorem envBound25926 : H12AffineFastState.Bounded env25926 := by
  intro p hp
  have h : env25926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25925_25926 : H12AffineEnvironment.transform 9 969 env25925 = env25926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 969 env25925 == env25926) = true)

def env25927 : List Nat := [2,4,8,16,32,64,128,256,512,969,2048,80,240,16384,16945,16962,17356,17090,969,16945,16465,16912,17293,374,120,17373,471,17357,81,19176,717,260,256,17097,973,513]

theorem envBound25927 : H12AffineFastState.Bounded env25927 := by
  intro p hp
  have h : env25927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25926_25927 : H12AffineEnvironment.transform 12 240 env25926 = env25927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 240 env25926 == env25927) = true)

theorem identity25927 : scanCanonicalize (H12AffineFastState.compose env25927 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound25927 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25928 : List Nat := [2,4,8,16,32,64,56,256,512,881,2048,80,72,16384,16945,16962,17268,17018,881,16945,16465,16912,17205,374,120,17253,367,17269,81,19024,629,260,256,17009,885,513]

theorem envBound25928 : H12AffineFastState.Bounded env25928 := by
  intro p hp
  have h : env25928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25927_25928 : H12AffineEnvironment.transform 6 56 env25927 = env25928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env25927 == env25928) = true)

theorem identity25928 : scanCanonicalize (H12AffineFastState.compose env25928 (packedSelected [4,5,8,9,11] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound25928 : packedSelected [4,5,8,9,11] rootPS < 2^1333 := by decide +kernel

def env25929 : List Nat := [2,4,8,16,32,64,56,69,512,564,2048,80,72,16384,16945,16962,16945,17018,564,16945,16465,16912,17008,51,120,16928,42,16944,81,19024,629,65,69,17009,560,513]

theorem envBound25929 : H12AffineFastState.Bounded env25929 := by
  intro p hp
  have h : env25929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25928_25929 : H12AffineEnvironment.transform 7 69 env25928 = env25929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env25928 == env25929) = true)

theorem identity25929 : scanCanonicalize (H12AffineFastState.compose env25929 (packedSelected [3,8,10] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound25929 : packedSelected [3,8,10] rootPS < 2^1333 := by decide +kernel

def env25930 : List Nat := [2,4,8,16,32,64,56,69,512,564,42,80,72,16384,16945,16962,16945,17018,564,16945,16465,16912,17008,51,120,16928,42,16944,81,17018,629,65,69,17009,560,513]

theorem envBound25930 : H12AffineFastState.Bounded env25930 := by
  intro p hp
  have h : env25930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25929_25930 : H12AffineEnvironment.transform 10 42 env25929 = env25930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env25929 == env25930) = true)

theorem identity25930 : scanCanonicalize (H12AffineFastState.compose env25930 (packedSelected [4,7] rootPS)) = affineNative (2^(13+1) ^^^ 560) := by decide +kernel

theorem selectedBound25930 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env25931 : List Nat := [2,4,8,16,32,64,56,69,512,564,42,80,72,560,1,114,1,74,564,1,609,32,64,51,120,16,42,0,81,74,629,65,69,65,560,513]

theorem envBound25931 : H12AffineFastState.Bounded env25931 := by
  intro p hp
  have h : env25931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25930_25931 : H12AffineEnvironment.transform 13 560 env25930 = env25931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 560 env25930 == env25931) = true)

theorem identity25931 : scanCanonicalize (H12AffineFastState.compose env25931 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 29) := by decide +kernel

theorem selectedBound25931 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25932 : List Nat := [2,4,8,16,32,29,56,24,512,564,42,13,21,560,1,47,1,23,564,1,572,32,29,51,37,16,42,0,12,23,552,28,24,28,560,513]

theorem envBound25932 : H12AffineFastState.Bounded env25932 := by
  intro p hp
  have h : env25932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25931_25932 : H12AffineEnvironment.transform 5 29 env25931 = env25932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 29 env25931 == env25932) = true)

theorem identity25932 : scanCanonicalize (H12AffineFastState.compose env25932 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound25932 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env25933 : List Nat := [2,4,8,10,32,7,34,2,512,558,42,13,15,554,1,47,1,13,558,1,550,32,7,41,37,10,42,0,12,13,552,6,2,6,554,513]

theorem envBound25933 : H12AffineFastState.Bounded env25933 := by
  intro p hp
  have h : env25933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25932_25933 : H12AffineEnvironment.transform 3 10 env25932 = env25933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env25932 == env25933) = true)

theorem identity25933 : scanCanonicalize (H12AffineFastState.compose env25933 (packedSelected [0,4] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound25933 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env25934 : List Nat := [2,4,4,6,32,7,34,2,512,546,38,1,3,550,1,35,1,1,546,1,550,32,7,37,37,6,38,0,0,1,548,6,2,6,550,513]

theorem envBound25934 : H12AffineFastState.Bounded env25934 := by
  intro p hp
  have h : env25934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25933_25934 : H12AffineEnvironment.transform 2 4 env25933 = env25934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env25933 == env25934) = true)

def env25935 : List Nat := [2,4,8,16,32,64,128,256,512,969,2048,80,241,16384,16944,16963,17356,17091,969,16944,16465,16912,17293,374,121,17373,470,17357,81,19176,717,260,256,17097,973,513]

theorem envBound25935 : H12AffineFastState.Bounded env25935 := by
  intro p hp
  have h : env25935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25926_25935 : H12AffineEnvironment.transform 12 241 env25926 = env25935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 241 env25926 == env25935) = true)

theorem identity25935 : scanCanonicalize (H12AffineFastState.compose env25935 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound25935 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25936 : List Nat := [2,4,8,16,32,64,128,69,512,652,2048,80,241,16384,16944,16963,17033,17091,652,16944,16465,16912,17096,51,121,17048,147,17032,81,19176,717,65,69,17097,648,513]

theorem envBound25936 : H12AffineFastState.Bounded env25936 := by
  intro p hp
  have h : env25936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25935_25936 : H12AffineEnvironment.transform 7 69 env25935 = env25936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env25935 == env25936) = true)

theorem identity25936 : scanCanonicalize (H12AffineFastState.compose env25936 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound25936 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env25937 : List Nat := [2,4,8,16,32,64,56,69,512,564,2048,80,73,16384,16944,16963,16945,17019,564,16944,16465,16912,17008,51,121,16928,43,16944,81,19024,629,65,69,17009,560,513]

theorem envBound25937 : H12AffineFastState.Bounded env25937 := by
  intro p hp
  have h : env25937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25936_25937 : H12AffineEnvironment.transform 6 56 env25936 = env25937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env25936 == env25937) = true)

theorem identity25937 : scanCanonicalize (H12AffineFastState.compose env25937 (packedSelected [3,8,10] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound25937 : packedSelected [3,8,10] rootPS < 2^1333 := by decide +kernel

def env25938 : List Nat := [2,4,8,16,32,64,56,69,512,564,43,80,73,16384,16944,16963,16945,17019,564,16944,16465,16912,17008,51,121,16928,43,16944,81,17019,629,65,69,17009,560,513]

theorem envBound25938 : H12AffineFastState.Bounded env25938 := by
  intro p hp
  have h : env25938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25937_25938 : H12AffineEnvironment.transform 10 43 env25937 = env25938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env25937 == env25938) = true)

theorem identity25938 : scanCanonicalize (H12AffineFastState.compose env25938 (packedSelected [4,7] rootPS)) = affineNative (2^(13+1) ^^^ 560) := by decide +kernel

theorem selectedBound25938 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env25939 : List Nat := [2,4,8,16,32,64,56,69,512,564,43,80,73,560,0,115,1,75,564,0,609,32,64,51,121,16,43,0,81,75,629,65,69,65,560,513]

theorem envBound25939 : H12AffineFastState.Bounded env25939 := by
  intro p hp
  have h : env25939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25938_25939 : H12AffineEnvironment.transform 13 560 env25938 = env25939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 560 env25938 == env25939) = true)

theorem identity25939 : scanCanonicalize (H12AffineFastState.compose env25939 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 28) := by decide +kernel

theorem selectedBound25939 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25940 : List Nat := [2,4,8,16,32,28,56,25,512,564,43,12,21,560,0,47,1,23,564,0,573,32,28,51,37,16,43,0,13,23,553,29,25,29,560,513]

theorem envBound25940 : H12AffineFastState.Bounded env25940 := by
  intro p hp
  have h : env25940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25939_25940 : H12AffineEnvironment.transform 5 28 env25939 = env25940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 28 env25939 == env25940) = true)

theorem identity25940 : scanCanonicalize (H12AffineFastState.compose env25940 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound25940 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env25941 : List Nat := [2,4,8,11,32,7,35,2,512,559,43,12,14,555,0,47,1,12,559,0,550,32,7,40,37,11,43,0,13,12,553,6,2,6,555,513]

theorem envBound25941 : H12AffineFastState.Bounded env25941 := by
  intro p hp
  have h : env25941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25940_25941 : H12AffineEnvironment.transform 3 11 env25940 = env25941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env25940 == env25941) = true)

theorem identity25941 : scanCanonicalize (H12AffineFastState.compose env25941 (packedSelected [0,4] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound25941 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env25942 : List Nat := [2,4,4,7,32,7,35,2,512,547,39,0,2,551,0,35,1,0,547,0,550,32,7,36,37,7,39,0,1,0,549,6,2,6,551,513]

theorem envBound25942 : H12AffineFastState.Bounded env25942 := by
  intro p hp
  have h : env25942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25941_25942 : H12AffineEnvironment.transform 2 4 env25941 = env25942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env25941 == env25942) = true)

theorem identity25942 : scanCanonicalize (H12AffineFastState.compose env25942 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound25942 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env25943 : List Nat := [2,4,4,7,7,7,4,2,512,516,0,0,2,512,0,4,1,0,516,0,513,7,7,3,2,7,0,0,1,0,514,6,2,6,512,513]

theorem envBound25943 : H12AffineFastState.Bounded env25943 := by
  intro p hp
  have h : env25943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25942_25943 : H12AffineEnvironment.transform 4 7 env25942 = env25943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env25942 == env25943) = true)

def env25944 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,2248768,16777216,8328,2248720,21331969,4399266,4272290,4294795,16876545,4329609,256,16912418,151632,513]

theorem envBound25944 : H12AffineFastState.Bounded env25944 := by
  intro p hp
  have h : env25944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25896_25944 : H12AffineEnvironment.transform 26 21331969 env25896 = env25944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 21331969 env25896 == env25944) = true)

theorem identity25944 : scanCanonicalize (H12AffineFastState.compose env25944 (packedSelected [14] rootPS)) = affineNative (2^(23+1) ^^^ 136483) := by decide +kernel

theorem selectedBound25944 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env25945 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,2248768,136483,8328,2248720,4691234,4399266,4272290,4294795,233762,4329609,256,1281,151632,513]

theorem envBound25945 : H12AffineFastState.Bounded env25945 := by
  intro p hp
  have h : env25945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25944_25945 : H12AffineEnvironment.transform 23 136483 env25944 = env25945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 136483 env25944 == env25945) = true)

theorem identity25945 : scanCanonicalize (H12AffineFastState.compose env25945 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(20+1) ^^^ 249970) := by decide +kernel

theorem selectedBound25945 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env25946 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,249970,4194304,98354,136483,8328,98402,4691234,4399266,4272290,4294795,233762,4329609,256,1281,151632,513]

theorem envBound25946 : H12AffineFastState.Bounded env25946 := by
  intro p hp
  have h : env25946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25945_25946 : H12AffineEnvironment.transform 20 249970 env25945 = env25946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 249970 env25945 == env25946) = true)

theorem identity25946 : scanCanonicalize (H12AffineFastState.compose env25946 (packedSelected [13,21] rootPS)) = affineNative (2^(21+1) ^^^ 99754) := by decide +kernel

theorem selectedBound25946 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env25947 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,249970,99754,98354,136483,8328,98402,397448,173320,46344,3361,233762,234787,256,1281,151632,513]

theorem envBound25947 : H12AffineFastState.Bounded env25947 := by
  intro p hp
  have h : env25947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25946_25947 : H12AffineEnvironment.transform 21 99754 env25946 = env25947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 99754 env25946 == env25947) = true)

def env25948 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,2248768,16777216,8328,2248721,134217728,151429282,151302306,4294795,16876544,151490696,257,138907683,155701328,513]

theorem envBound25948 : H12AffineFastState.Bounded env25948 := by
  intro p hp
  have h : env25948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25895_25948 : H12AffineEnvironment.transform 18 1025 env25895 = env25948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env25895 == env25948) = true)

def env25949 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,2248768,16777216,8328,2248721,21331968,4399266,4272290,4294795,16876544,4329608,257,16912419,151632,513]

theorem envBound25949 : H12AffineFastState.Bounded env25949 := by
  intro p hp
  have h : env25949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25948_25949 : H12AffineEnvironment.transform 26 21331968 env25948 = env25949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 21331968 env25948 == env25949) = true)

theorem identity25949 : scanCanonicalize (H12AffineFastState.compose env25949 (packedSelected [14] rootPS)) = affineNative (2^(23+1) ^^^ 4195) := by decide +kernel

theorem selectedBound25949 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env25950 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,2248768,4195,8328,2248721,4558947,4399266,4272290,4294795,103523,4329608,257,131136,151632,513]

theorem envBound25950 : H12AffineFastState.Bounded env25950 := by
  intro p hp
  have h : env25950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25949_25950 : H12AffineEnvironment.transform 23 4195 env25949 = env25950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 4195 env25949 == env25950) = true)

theorem identity25950 : scanCanonicalize (H12AffineFastState.compose env25950 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(21+1) ^^^ 2191847) := by decide +kernel

theorem selectedBound25950 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env25951 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,2191847,2248768,4195,8328,2248721,2417028,2249029,2113861,2161004,103523,2318703,257,131136,151632,513]

theorem envBound25951 : H12AffineFastState.Bounded env25951 := by
  intro p hp
  have h : env25951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25950_25951 : H12AffineEnvironment.transform 21 2191847 env25950 = env25951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2191847 env25950 == env25951) = true)

theorem identity25951 : scanCanonicalize (H12AffineFastState.compose env25951 (packedSelected [13,21] rootPS)) = affineNative (2^(16+1) ^^^ 45405) := by decide +kernel

theorem selectedBound25951 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env25952 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,45405,262144,1025,32768,2097152,2191847,2154781,4195,8328,2154828,2417028,2154520,2113861,2161004,103523,2215986,257,45341,57613,513]

theorem envBound25952 : H12AffineFastState.Bounded env25952 := by
  intro p hp
  have h : env25952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25951_25952 : H12AffineEnvironment.transform 16 45405 env25951 = env25952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45405 env25951 == env25952) = true)

def env25953 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,2248768,16777216,8328,2248721,21331969,4399267,4272291,4294795,16876544,4329609,257,16912418,151633,513]

theorem envBound25953 : H12AffineFastState.Bounded env25953 := by
  intro p hp
  have h : env25953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25948_25953 : H12AffineEnvironment.transform 26 21331969 env25948 = env25953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 21331969 env25948 == env25953) = true)

theorem identity25953 : scanCanonicalize (H12AffineFastState.compose env25953 (packedSelected [14] rootPS)) = affineNative (2^(23+1) ^^^ 2097250) := by decide +kernel

theorem selectedBound25953 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env25954 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,2248768,2097250,8328,2248721,6652003,4399267,4272291,4294795,2196578,4329609,257,2232384,151633,513]

theorem envBound25954 : H12AffineFastState.Bounded env25954 := by
  intro p hp
  have h : env25954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25953_25954 : H12AffineEnvironment.transform 23 2097250 env25953 = env25954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2097250 env25953 == env25954) = true)

theorem identity25954 : scanCanonicalize (H12AffineFastState.compose env25954 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(20+1) ^^^ 249970) := by decide +kernel

theorem selectedBound25954 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env25955 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,249970,4194304,98354,249872,8328,98403,4608017,4399267,4272291,4294795,152592,4329609,257,114738,151633,513]

theorem envBound25955 : H12AffineFastState.Bounded env25955 := by
  intro p hp
  have h : env25955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25954_25955 : H12AffineEnvironment.transform 20 249970 env25954 = env25955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 249970 env25954 == env25955) = true)

theorem identity25955 : scanCanonicalize (H12AffineFastState.compose env25955 (packedSelected [13,21] rootPS)) = affineNative (2^(21+1) ^^^ 16537) := by decide +kernel

theorem selectedBound25955 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env25956 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,249970,16537,98354,249872,8328,98403,397448,221242,94266,116754,152592,151568,257,114738,151633,513]

theorem envBound25956 : H12AffineFastState.Bounded env25956 := by
  intro p hp
  have h : env25956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25955_25956 : H12AffineEnvironment.transform 21 16537 env25955 = env25956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 16537 env25955 == env25956) = true)

theorem identity25956 : scanCanonicalize (H12AffineFastState.compose env25956 (packedSelected [0,3,5,10,27] rootPS)) = affineNative (2^(15+1) ^^^ 49463) := by decide +kernel

theorem selectedBound25956 : packedSelected [0,3,5,10,27] rootPS < 2^1333 := by decide +kernel

def env25957 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,49463,131072,262144,1025,32768,135493,16537,16645,135463,8328,16724,397448,172301,45325,2341,152592,151568,257,261,151633,513]

theorem envBound25957 : H12AffineFastState.Bounded env25957 := by
  intro p hp
  have h : env25957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25956_25957 : H12AffineEnvironment.transform 15 49463 env25956 = env25957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 49463 env25956 == env25957) = true)

def env25958 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,49463,131072,262144,1025,32768,135445,16537,16645,135463,8328,16644,397448,172301,45325,2341,152592,151568,257,261,151553,513]

theorem envBound25958 : H12AffineFastState.Bounded env25958 := by
  intro p hp
  have h : env25958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25957_25958 : H12AffineEnvironment.transform 5 16 env25957 = env25958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env25957 == env25958) = true)

theorem identity25958 : scanCanonicalize (H12AffineFastState.compose env25958 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 1297) := by decide +kernel

theorem selectedBound25958 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env25959 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,1297,17446,131072,262144,1025,1297,135445,16537,16645,135463,8328,16644,397448,140316,13340,2341,152592,151568,257,261,151553,513]

theorem envBound25959 : H12AffineFastState.Bounded env25959 := by
  intro p hp
  have h : env25959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25958_25959 : H12AffineEnvironment.transform 14 1297 env25958 = env25959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1297 env25958 == env25959) = true)

def env25960 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,1297,17446,4096,262144,1025,1297,277,16537,16645,295,8328,16644,262280,13340,13340,2341,17424,16400,257,261,16385,513]

theorem envBound25960 : H12AffineFastState.Bounded env25960 := by
  intro p hp
  have h : env25960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25959_25960 : H12AffineEnvironment.transform 16 4096 env25959 = env25960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4096 env25959 == env25960) = true)

theorem identity25960 : scanCanonicalize (H12AffineFastState.compose env25960 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 675) := by decide +kernel

theorem selectedBound25960 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env25961 : List Nat := [2,4,8,16,32,16,128,256,512,1024,675,4096,8192,16384,1297,17446,4096,262144,1025,1297,277,16537,16645,295,8328,16644,262280,13340,13340,902,17424,16400,257,261,16385,513]

theorem envBound25961 : H12AffineFastState.Bounded env25961 := by
  intro p hp
  have h : env25961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25960_25961 : H12AffineEnvironment.transform 10 675 env25960 = env25961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 675 env25960 == env25961) = true)

theorem identity25961 : scanCanonicalize (H12AffineFastState.compose env25961 (packedSelected [3,5,10,12,13,15] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound25961 : packedSelected [3,5,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env25962 : List Nat := [2,4,8,16,32,16,128,173,512,1024,675,4096,8192,16384,1212,17446,4096,262144,1025,1212,184,16537,16552,138,8328,16553,262280,13340,13340,555,17424,16400,172,168,16385,513]

theorem envBound25962 : H12AffineFastState.Bounded env25962 := by
  intro p hp
  have h : env25962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25961_25962 : H12AffineEnvironment.transform 7 173 env25961 = env25962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env25961 == env25962) = true)

theorem identity25962 : scanCanonicalize (H12AffineFastState.compose env25962 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(17+1) ^^^ 9783) := by decide +kernel

theorem selectedBound25962 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env25963 : List Nat := [2,4,8,16,32,16,128,173,512,1024,675,4096,8192,16384,1212,17446,4096,9783,1025,1212,184,16537,16552,138,8328,16553,9919,13340,13340,555,17424,16400,172,168,16385,513]

theorem envBound25963 : H12AffineFastState.Bounded env25963 := by
  intro p hp
  have h : env25963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25962_25963 : H12AffineEnvironment.transform 17 9783 env25962 = env25963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 9783 env25962 == env25963) = true)

theorem identity25963 : scanCanonicalize (H12AffineFastState.compose env25963 (packedSelected [1,3] rootPS)) = affineNative (2^(13+1) ^^^ 8890) := by decide +kernel

theorem selectedBound25963 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env25964 : List Nat := [2,4,8,16,32,16,128,173,512,1024,675,4096,8192,8890,1212,9884,4096,9783,1025,1212,184,8739,8722,138,8328,8723,9919,13340,13340,555,9898,8874,172,168,8891,513]

theorem envBound25964 : H12AffineFastState.Bounded env25964 := by
  intro p hp
  have h : env25964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25963_25964 : H12AffineEnvironment.transform 13 8890 env25963 = env25964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8890 env25963 == env25964) = true)

theorem identity25964 : scanCanonicalize (H12AffineFastState.compose env25964 (packedSelected [0,4] rootPS)) = affineNative (2^(12+1) ^^^ 1684) := by decide +kernel

theorem selectedBound25964 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env25965 : List Nat := [2,4,8,16,32,16,128,173,512,1024,675,4096,1684,1070,1212,8,4096,163,1025,1212,184,1207,1158,138,1564,1159,43,4744,4744,555,62,1086,172,168,1071,513]

theorem envBound25965 : H12AffineFastState.Bounded env25965 := by
  intro p hp
  have h : env25965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25964_25965 : H12AffineEnvironment.transform 12 1684 env25964 = env25965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1684 env25964 == env25965) = true)

def env25966 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,1297,17446,4097,262144,1025,1297,276,16537,16645,294,8328,16644,262281,13341,13340,2341,17425,16401,257,261,16384,513]

theorem envBound25966 : H12AffineFastState.Bounded env25966 := by
  intro p hp
  have h : env25966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25959_25966 : H12AffineEnvironment.transform 16 4097 env25959 = env25966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4097 env25959 == env25966) = true)

theorem identity25966 : scanCanonicalize (H12AffineFastState.compose env25966 (packedSelected [5,8] rootPS)) = affineNative (2^(13+1) ^^^ 2587) := by decide +kernel

theorem selectedBound25966 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env25967 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,2587,1297,3645,4097,262144,1025,1297,276,2690,2846,294,8328,2847,262281,13341,13340,2341,3594,2570,257,261,2587,513]

theorem envBound25967 : H12AffineFastState.Bounded env25967 := by
  intro p hp
  have h : env25967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25966_25967 : H12AffineEnvironment.transform 13 2587 env25966 = env25967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2587 env25966 == env25967) = true)

theorem identity25967 : scanCanonicalize (H12AffineFastState.compose env25967 (packedSelected [3,5,10,12,13,15] rootPS)) = affineNative (2^(17+1) ^^^ 11413) := by decide +kernel

theorem selectedBound25967 : packedSelected [3,5,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env25968 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,2587,1297,3645,4097,11413,1025,1297,276,2690,2846,294,8328,2847,11292,13341,13340,2341,3594,2570,257,261,2587,513]

theorem envBound25968 : H12AffineFastState.Bounded env25968 := by
  intro p hp
  have h : env25968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25967_25968 : H12AffineEnvironment.transform 17 11413 env25967 = env25968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 11413 env25967 == env25968) = true)

theorem identity25968 : scanCanonicalize (H12AffineFastState.compose env25968 (packedSelected [1,3,10,12] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound25968 : packedSelected [1,3,10,12] rootPS < 2^1333 := by decide +kernel

def env25969 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,2587,1213,3645,4097,11413,1025,1213,184,2690,2738,138,8328,2739,11292,13341,13340,2185,3594,2570,173,169,2587,513]

theorem envBound25969 : H12AffineFastState.Bounded env25969 := by
  intro p hp
  have h : env25969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25968_25969 : H12AffineEnvironment.transform 7 172 env25968 = env25969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env25968 == env25969) = true)

theorem identity25969 : scanCanonicalize (H12AffineFastState.compose env25969 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 650) := by decide +kernel

theorem selectedBound25969 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env25970 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,650,2587,1213,3645,4097,3615,1025,1213,184,2690,2738,138,514,2739,3734,5783,5782,2185,3594,2570,173,169,2587,513]

theorem envBound25970 : H12AffineFastState.Bounded env25970 := by
  intro p hp
  have h : env25970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25969_25970 : H12AffineEnvironment.transform 12 650 env25969 = env25970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 650 env25969 == env25970) = true)

def env25971 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,49463,131072,262144,1025,32768,135444,16537,16645,135463,8328,16645,397448,172301,45325,2341,152592,151568,257,261,151552,513]

theorem envBound25971 : H12AffineFastState.Bounded env25971 := by
  intro p hp
  have h : env25971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25957_25971 : H12AffineEnvironment.transform 5 17 env25957 = env25971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env25957 == env25971) = true)

theorem identity25971 : scanCanonicalize (H12AffineFastState.compose env25971 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 17413) := by decide +kernel

theorem selectedBound25971 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env25972 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,17413,1330,131072,262144,1025,17413,135444,16537,16645,135463,8328,16645,397448,156936,29960,2341,152592,151568,257,261,151552,513]

theorem envBound25972 : H12AffineFastState.Bounded env25972 := by
  intro p hp
  have h : env25972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25971_25972 : H12AffineEnvironment.transform 14 17413 env25971 = env25972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 17413 env25971 == env25972) = true)

def env25973 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,17413,1330,4096,262144,1025,17413,276,16537,16645,295,8328,16645,262280,29960,29960,2341,17424,16400,257,261,16384,513]

theorem envBound25973 : H12AffineFastState.Bounded env25973 := by
  intro p hp
  have h : env25973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25972_25973 : H12AffineEnvironment.transform 16 4096 env25972 = env25973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4096 env25972 == env25973) = true)

theorem identity25973 : scanCanonicalize (H12AffineFastState.compose env25973 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 3858) := by decide +kernel

theorem selectedBound25973 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env25974 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,3858,16384,17413,1330,4096,262144,1025,17413,276,16537,16645,295,3994,16645,262280,23066,23066,2341,17424,16400,257,261,16384,513]

theorem envBound25974 : H12AffineFastState.Bounded env25974 := by
  intro p hp
  have h : env25974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25973_25974 : H12AffineEnvironment.transform 12 3858 env25973 = env25974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3858 env25973 == env25974) = true)

theorem identity25974 : scanCanonicalize (H12AffineFastState.compose env25974 (packedSelected [3,5,10,12,13,15] rootPS)) = affineNative (2^(17+1) ^^^ 17042) := by decide +kernel

theorem selectedBound25974 : packedSelected [3,5,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env25975 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,3858,16384,17413,1330,4096,17042,1025,17413,276,16537,16645,295,3994,16645,16922,23066,23066,2341,17424,16400,257,261,16384,513]

theorem envBound25975 : H12AffineFastState.Bounded env25975 := by
  intro p hp
  have h : env25975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25974_25975 : H12AffineEnvironment.transform 17 17042 env25974 = env25975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 17042 env25974 == env25975) = true)

theorem identity25975 : scanCanonicalize (H12AffineFastState.compose env25975 (packedSelected [1,3,10,12] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound25975 : packedSelected [1,3,10,12] rootPS < 2^1333 := by decide +kernel

def env25976 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,3775,16384,17413,1183,4096,17042,1025,17413,185,16537,16552,138,3639,16552,16922,23066,23066,2184,17424,16400,172,168,16384,513]

theorem envBound25976 : H12AffineFastState.Bounded env25976 := by
  intro p hp
  have h : env25976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25975_25976 : H12AffineEnvironment.transform 7 173 env25975 = env25976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env25975 == env25976) = true)

theorem identity25976 : scanCanonicalize (H12AffineFastState.compose env25976 (packedSelected [1,3] rootPS)) = affineNative (2^(13+1) ^^^ 1582) := by decide +kernel

theorem selectedBound25976 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env25977 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,3775,1582,555,1183,4096,1212,1025,555,185,1719,1670,138,3639,1670,1076,7220,7220,2184,574,1598,172,168,1582,513]

theorem envBound25977 : H12AffineFastState.Bounded env25977 := by
  intro p hp
  have h : env25977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25976_25977 : H12AffineEnvironment.transform 13 1582 env25976 = env25977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1582 env25976 == env25977) = true)

def env25978 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,17413,1330,4097,262144,1025,17413,277,16537,16645,294,8328,16645,262281,29961,29960,2341,17425,16401,257,261,16385,513]

theorem envBound25978 : H12AffineFastState.Bounded env25978 := by
  intro p hp
  have h : env25978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25972_25978 : H12AffineEnvironment.transform 16 4097 env25972 = env25978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4097 env25972 == env25978) = true)

theorem identity25978 : scanCanonicalize (H12AffineFastState.compose env25978 (packedSelected [5,8] rootPS)) = affineNative (2^(13+1) ^^^ 12203) := by decide +kernel

theorem selectedBound25978 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env25979 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,12203,11182,1330,4097,262144,1025,11182,277,12082,11950,294,8328,11950,262281,6818,6819,2341,11194,12218,257,261,12202,513]

theorem envBound25979 : H12AffineFastState.Bounded env25979 := by
  intro p hp
  have h : env25979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25978_25979 : H12AffineEnvironment.transform 13 12203 env25978 = env25979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12203 env25978 == env25979) = true)

theorem identity25979 : scanCanonicalize (H12AffineFastState.compose env25979 (packedSelected [3,5,10,12,13,15] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound25979 : packedSelected [3,5,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env25980 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,11783,10754,1182,4097,262144,1025,10754,185,11934,11950,138,8328,11950,262281,6818,6819,2185,10774,11798,173,169,11782,513]

theorem envBound25980 : H12AffineFastState.Bounded env25980 := by
  intro p hp
  have h : env25980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25979_25980 : H12AffineEnvironment.transform 7 172 env25979 = env25980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env25979 == env25980) = true)

theorem identity25980 : scanCanonicalize (H12AffineFastState.compose env25980 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(17+1) ^^^ 554) := by decide +kernel

theorem selectedBound25980 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env25981 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,11783,10754,1182,4097,554,1025,10754,185,11934,11950,138,8328,11950,675,6818,6819,2185,10774,11798,173,169,11782,513]

theorem envBound25981 : H12AffineFastState.Bounded env25981 := by
  intro p hp
  have h : env25981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25980_25981 : H12AffineEnvironment.transform 17 554 env25980 = env25981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 554 env25980 == env25981) = true)

theorem identity25981 : scanCanonicalize (H12AffineFastState.compose env25981 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 543) := by decide +kernel

theorem selectedBound25981 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env25982 : List Nat := [2,4,8,16,32,17,128,172,512,543,2048,4096,8192,10264,10754,641,4097,554,542,10754,185,10369,10417,138,8328,10417,675,6818,6819,2185,10774,10249,173,169,10265,513]

theorem envBound25982 : H12AffineFastState.Bounded env25982 := by
  intro p hp
  have h : env25982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25981_25982 : H12AffineEnvironment.transform 9 543 env25981 = env25982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 543 env25981 == env25982) = true)

theorem identity25982 : scanCanonicalize (H12AffineFastState.compose env25982 (packedSelected [0,4] rootPS)) = affineNative (2^(12+1) ^^^ 2601) := by decide +kernel

theorem selectedBound25982 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env25983 : List Nat := [2,4,8,16,32,17,128,172,512,543,2048,4096,2601,561,43,641,4097,554,542,43,185,680,664,138,2721,664,675,6818,6819,2185,63,544,173,169,560,513]

theorem envBound25983 : H12AffineFastState.Bounded env25983 := by
  intro p hp
  have h : env25983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25982_25983 : H12AffineEnvironment.transform 12 2601 env25982 = env25983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2601 env25982 == env25983) = true)

def env25984 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,2248769,16777216,8328,2774033,134217728,151954595,151827619,4294795,17399809,151490696,525568,138907683,156226640,513]

theorem envBound25984 : H12AffineFastState.Bounded env25984 := by
  intro p hp
  have h : env25984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25894_25984 : H12AffineEnvironment.transform 22 2248769 env25894 = env25984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2248769 env25894 == env25984) = true)

def env25985 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,2248769,16777216,8328,2248721,134217728,151429283,151302307,4294795,16876545,151490696,256,138907683,155701328,513]

theorem envBound25985 : H12AffineFastState.Bounded env25985 := by
  intro p hp
  have h : env25985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25984_25985 : H12AffineEnvironment.transform 18 1024 env25984 = env25985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env25984 == env25985) = true)

def env25986 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,2248769,16777216,8328,2248721,21331968,4399267,4272291,4294795,16876545,4329608,256,16912419,151632,513]

theorem envBound25986 : H12AffineFastState.Bounded env25986 := by
  intro p hp
  have h : env25986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25985_25986 : H12AffineEnvironment.transform 26 21331968 env25985 = env25986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 21331968 env25985 == env25986) = true)

theorem identity25986 : scanCanonicalize (H12AffineFastState.compose env25986 (packedSelected [14] rootPS)) = affineNative (2^(23+1) ^^^ 148850) := by decide +kernel

theorem selectedBound25986 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env25987 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,2248769,148850,8328,2248721,4703602,4399267,4272291,4294795,246131,4329608,256,21841,151632,513]

theorem envBound25987 : H12AffineFastState.Bounded env25987 := by
  intro p hp
  have h : env25987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25986_25987 : H12AffineEnvironment.transform 23 148850 env25986 = env25987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 148850 env25986 == env25987) = true)

theorem identity25987 : scanCanonicalize (H12AffineFastState.compose env25987 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(21+1) ^^^ 2303223) := by decide +kernel

theorem selectedBound25987 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env25988 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,2303223,2248769,148850,8328,2248721,2417029,2098260,2233428,2272380,246131,2176127,256,21841,151632,513]

theorem envBound25988 : H12AffineFastState.Bounded env25988 := by
  intro p hp
  have h : env25988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25987_25988 : H12AffineEnvironment.transform 21 2303223 env25987 = env25988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2303223 env25987 == env25988) = true)

theorem identity25988 : scanCanonicalize (H12AffineFastState.compose env25988 (packedSelected [13,21] rootPS)) = affineNative (2^(16+1) ^^^ 45404) := by decide +kernel

theorem selectedBound25988 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env25989 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,45404,262144,1024,32768,2097152,2201003,2154781,62510,8328,2154829,2417029,2098260,2139400,2104608,94255,2176127,256,21841,57612,513]

theorem envBound25989 : H12AffineFastState.Bounded env25989 := by
  intro p hp
  have h : env25989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25988_25989 : H12AffineEnvironment.transform 16 45404 env25988 = env25989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45404 env25988 == env25989) = true)

theorem identity25989 : scanCanonicalize (H12AffineFastState.compose env25989 (packedSelected [0,3,5,10,27] rootPS)) = affineNative (2^(20+1) ^^^ 79226) := by decide +kernel

theorem selectedBound25989 : packedSelected [0,3,5,10,27] rootPS < 2^1333 := by decide +kernel

def env25990 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,45404,262144,1024,32768,79226,41169,119911,62510,8328,119863,382207,78126,102514,75866,94255,261,256,21841,57612,513]

theorem envBound25990 : H12AffineFastState.Bounded env25990 := by
  intro p hp
  have h : env25990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25989_25990 : H12AffineEnvironment.transform 20 79226 env25989 = env25990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 79226 env25989 == env25990) = true)

theorem identity25990 : scanCanonicalize (H12AffineFastState.compose env25990 (packedSelected [1,5,8,12,15,17,24] rootPS)) = affineNative (2^(15+1) ^^^ 32883) := by decide +kernel

theorem selectedBound25990 : packedSelected [1,5,8,12,15,17,24] rootPS < 2^1333 := by decide +kernel

def env25991 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,32883,45404,262144,1024,32768,46345,41169,21524,62510,8328,21572,283788,45405,4097,43049,61532,261,256,21841,57612,513]

theorem envBound25991 : H12AffineFastState.Bounded env25991 := by
  intro p hp
  have h : env25991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25990_25991 : H12AffineEnvironment.transform 15 32883 env25990 = env25991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32883 env25990 == env25991) = true)

theorem identity25991 : scanCanonicalize (H12AffineFastState.compose env25991 (packedSelected [2,3,6,8,10,11,13,17,18] rootPS)) = affineNative (2^(17+1) ^^^ 54126) := by decide +kernel

theorem selectedBound25991 : packedSelected [2,3,6,8,10,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env25992 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,32883,45404,54126,1024,32768,46345,41169,21524,62510,8328,21572,34786,45405,4097,43049,61532,261,256,21841,57612,513]

theorem envBound25992 : H12AffineFastState.Bounded env25992 := by
  intro p hp
  have h : env25992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25991_25992 : H12AffineEnvironment.transform 17 54126 env25991 = env25992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 54126 env25991 == env25992) = true)

def env25993 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,30040,29995,17412,9782,1024,30040,16465,21897,21524,374,8328,21572,29370,17413,4097,23921,1284,261,256,21841,5204,513]

theorem envBound25993 : H12AffineFastState.Bounded env25993 := by
  intro p hp
  have h : env25993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25992_25993 : H12AffineEnvironment.transform 14 30040 env25992 = env25993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 30040 env25992 == env25993) = true)

theorem identity25993 : scanCanonicalize (H12AffineFastState.compose env25993 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound25993 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env25994 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,8192,16384,25864,25979,17412,9782,1024,25864,16465,17881,17476,374,8328,17428,25322,17413,81,19745,1284,261,256,17665,1028,513]

theorem envBound25994 : H12AffineFastState.Bounded env25994 := by
  intro p hp
  have h : env25994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25993_25994 : H12AffineEnvironment.transform 11 80 env25993 = env25994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env25993 == env25994) = true)

theorem identity25994 : scanCanonicalize (H12AffineFastState.compose env25994 (packedSelected [3,8,10,13,17] rootPS)) = affineNative (2^(13+1) ^^^ 972) := by decide +kernel

theorem selectedBound25994 : packedSelected [3,8,10,13,17] rootPS < 2^1333 := by decide +kernel

def env25995 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,8192,972,9924,9911,1992,9782,1024,9924,925,1557,1928,374,8328,2008,8486,1993,81,3821,1284,261,256,1741,1028,513]

theorem envBound25995 : H12AffineFastState.Bounded env25995 := by
  intro p hp
  have h : env25995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25994_25995 : H12AffineEnvironment.transform 13 972 env25994 = env25995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 972 env25994 == env25995) = true)

def env25996 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,240,972,1588,1607,1992,1734,1024,1588,925,1557,1928,374,120,2008,470,1993,81,3821,1284,261,256,1741,1028,513]

theorem envBound25996 : H12AffineFastState.Bounded env25996 := by
  intro p hp
  have h : env25996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25995_25996 : H12AffineEnvironment.transform 12 240 env25995 = env25996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 240 env25995 == env25996) = true)

theorem identity25996 : scanCanonicalize (H12AffineFastState.compose env25996 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound25996 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25997 : List Nat := [2,4,8,16,32,64,57,256,512,1024,2048,80,73,885,1588,1607,1905,1663,1024,1588,804,1557,1841,374,120,1889,367,1904,81,3668,1284,261,256,1652,1028,513]

theorem envBound25997 : H12AffineFastState.Bounded env25997 := by
  intro p hp
  have h : env25997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25996_25997 : H12AffineEnvironment.transform 6 57 env25996 = env25997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env25996 == env25997) = true)

theorem identity25997 : scanCanonicalize (H12AffineFastState.compose env25997 (packedSelected [4,5,8,9,11] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound25997 : packedSelected [4,5,8,9,11] rootPS < 2^1333 := by decide +kernel

def env25998 : List Nat := [2,4,8,16,32,64,57,68,512,1024,2048,80,73,561,1588,1607,1589,1663,1024,1588,608,1557,1653,50,120,1573,43,1588,81,3668,1088,65,68,1652,1028,513]

theorem envBound25998 : H12AffineFastState.Bounded env25998 := by
  intro p hp
  have h : env25998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25997_25998 : H12AffineEnvironment.transform 7 68 env25997 = env25998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env25997 == env25998) = true)

theorem identity25998 : scanCanonicalize (H12AffineFastState.compose env25998 (packedSelected [3,8,10] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound25998 : packedSelected [3,8,10] rootPS < 2^1333 := by decide +kernel

def env25999 : List Nat := [2,4,8,16,32,64,57,68,512,1024,43,80,73,561,1588,1607,1589,1663,1024,1588,608,1557,1653,50,120,1573,43,1588,81,1663,1088,65,68,1652,1028,513]

theorem envBound25999 : H12AffineFastState.Bounded env25999 := by
  intro p hp
  have h : env25999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25998_25999 : H12AffineEnvironment.transform 10 43 env25998 = env25999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env25998 == env25999) = true)

theorem identity25999 : scanCanonicalize (H12AffineFastState.compose env25999 (packedSelected [4,7] rootPS)) = affineNative (2^(9+1) ^^^ 565) := by decide +kernel

theorem selectedBound25999 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env26000 : List Nat := [2,4,8,16,32,64,57,68,512,565,43,80,73,561,1,114,0,74,565,1,608,32,64,50,120,16,43,1,81,74,629,65,68,65,561,513]

theorem envBound26000 : H12AffineFastState.Bounded env26000 := by
  intro p hp
  have h : env26000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25999_26000 : H12AffineEnvironment.transform 9 565 env25999 = env26000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 565 env25999 == env26000) = true)

theorem identity26000 : scanCanonicalize (H12AffineFastState.compose env26000 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound26000 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env26001 : List Nat := [2,4,4,16,32,64,53,68,512,565,39,80,69,561,1,114,0,70,565,1,608,32,64,50,116,16,39,1,81,70,629,65,68,65,561,513]

theorem envBound26001 : H12AffineFastState.Bounded env26001 := by
  intro p hp
  have h : env26001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26000_26001 : H12AffineEnvironment.transform 2 4 env26000 = env26001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env26000 == env26001) = true)

theorem identity26001 : scanCanonicalize (H12AffineFastState.compose env26001 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound26001 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env26002 : List Nat := [2,4,4,6,32,64,35,68,512,547,39,70,69,551,1,100,0,70,547,1,608,32,64,36,98,6,39,1,71,70,611,65,68,65,551,513]

theorem envBound26002 : H12AffineFastState.Bounded env26002 := by
  intro p hp
  have h : env26002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26001_26002 : H12AffineEnvironment.transform 3 6 env26001 = env26002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env26001 == env26002) = true)

theorem identity26002 : scanCanonicalize (H12AffineFastState.compose env26002 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 7) := by decide +kernel

theorem selectedBound26002 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env26003 : List Nat := [2,4,4,6,32,7,35,3,512,547,39,1,2,551,1,35,0,1,547,1,551,32,7,36,37,6,39,1,0,1,548,6,3,6,551,513]

theorem envBound26003 : H12AffineFastState.Bounded env26003 := by
  intro p hp
  have h : env26003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26002_26003 : H12AffineEnvironment.transform 5 7 env26002 = env26003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 7 env26002 == env26003) = true)

def env26004 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,241,972,1589,1606,1992,1735,1024,1589,925,1557,1928,374,121,2008,471,1993,81,3821,1284,261,256,1741,1028,513]

theorem envBound26004 : H12AffineFastState.Bounded env26004 := by
  intro p hp
  have h : env26004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25995_26004 : H12AffineEnvironment.transform 12 241 env25995 = env26004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 241 env25995 == env26004) = true)

theorem identity26004 : scanCanonicalize (H12AffineFastState.compose env26004 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound26004 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env26005 : List Nat := [2,4,8,16,32,64,128,68,512,1024,2048,80,241,648,1589,1606,1676,1735,1024,1589,729,1557,1740,50,121,1692,147,1677,81,3821,1088,65,68,1741,1028,513]

theorem envBound26005 : H12AffineFastState.Bounded env26005 := by
  intro p hp
  have h : env26005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26004_26005 : H12AffineEnvironment.transform 7 68 env26004 = env26005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env26004 == env26005) = true)

theorem identity26005 : scanCanonicalize (H12AffineFastState.compose env26005 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound26005 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env26006 : List Nat := [2,4,8,16,32,64,57,68,512,1024,2048,80,72,561,1589,1606,1589,1662,1024,1589,608,1557,1653,50,121,1573,42,1588,81,3668,1088,65,68,1652,1028,513]

theorem envBound26006 : H12AffineFastState.Bounded env26006 := by
  intro p hp
  have h : env26006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26005_26006 : H12AffineEnvironment.transform 6 57 env26005 = env26006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env26005 == env26006) = true)

theorem identity26006 : scanCanonicalize (H12AffineFastState.compose env26006 (packedSelected [3,8,10] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound26006 : packedSelected [3,8,10] rootPS < 2^1333 := by decide +kernel

def env26007 : List Nat := [2,4,8,16,32,64,57,68,512,1024,42,80,72,561,1589,1606,1589,1662,1024,1589,608,1557,1653,50,121,1573,42,1588,81,1662,1088,65,68,1652,1028,513]

theorem envBound26007 : H12AffineFastState.Bounded env26007 := by
  intro p hp
  have h : env26007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26006_26007 : H12AffineEnvironment.transform 10 42 env26006 = env26007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env26006 == env26007) = true)

end H12CloudChart2