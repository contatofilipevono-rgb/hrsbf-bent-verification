import H12CloudChart2Data059

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env14666 : List Nat := [2,4,8,16,10,16,128,15,136,1024,137,1054,138,1055,137,8,1054,136,1025,136,1054,11,16,139,2,17,137,1054,1055,136,1035,147,15,147,1055,136]

theorem envBound14666 : H12AffineFastState.Bounded env14666 := by
  intro p hp
  have h : env14666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14665_14666 : H12AffineEnvironment.transform 7 15 env14665 = env14666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env14665 == env14666) = true)

theorem identity14666 : scanCanonicalize (H12AffineFastState.compose env14666 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound14666 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env14667 : List Nat := [2,4,8,16,10,16,18,15,26,1024,27,1054,24,1055,27,8,1054,26,1025,26,1054,11,16,25,2,17,27,1054,1055,26,1035,1,15,1,1055,26]

theorem envBound14667 : H12AffineFastState.Bounded env14667 := by
  intro p hp
  have h : env14667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14666_14667 : H12AffineEnvironment.transform 6 18 env14666 = env14667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env14666 == env14667) = true)

def env14668 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1297,32768,65536,1296,512,1024,32769,1296,65804,17,98565,8328,16,134217728,1296,1296,1073741824,1284,4294967296,256,4295000227,134285081,512]

theorem envBound14668 : H12AffineFastState.Bounded env14668 := by
  intro p hp
  have h : env14668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14655_14668 : H12AffineEnvironment.transform 5 17 env14655 = env14668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env14655 == env14668) = true)

theorem identity14668 : scanCanonicalize (H12AffineFastState.compose env14668 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 431) := by decide +kernel

theorem selectedBound14668 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env14669 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,431,1297,32768,65536,1296,512,1024,32769,1296,65804,17,98565,295,16,134217728,1296,1296,1073741824,1284,4294967296,256,4295000227,134285081,512]

theorem envBound14669 : H12AffineFastState.Bounded env14669 := by
  intro p hp
  have h : env14669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14668_14669 : H12AffineEnvironment.transform 12 431 env14668 = env14669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 431 env14668 == env14669) = true)

theorem identity14669 : scanCanonicalize (H12AffineFastState.compose env14669 (packedSelected [3,5,8,28] rootPS)) = affineNative (2^(26+1) ^^^ 66056) := by decide +kernel

theorem selectedBound14669 : packedSelected [3,5,8,28] rootPS < 2^1333 := by decide +kernel

def env14670 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,431,1297,32768,65536,1296,512,1024,32769,1296,65804,17,98565,295,16,66056,1296,1296,1073741824,1284,4294967296,256,4295000227,1297,512]

theorem envBound14670 : H12AffineFastState.Bounded env14670 := by
  intro p hp
  have h : env14670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14669_14670 : H12AffineEnvironment.transform 26 66056 env14669 = env14670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 66056 env14669 == env14670) = true)

theorem identity14670 : scanCanonicalize (H12AffineFastState.compose env14670 (packedSelected [1,3,5] rootPS)) = affineNative (2^(14+1) ^^^ 162) := by decide +kernel

theorem selectedBound14670 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env14671 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,431,1297,162,65536,1296,512,1024,163,1296,65804,17,65959,295,16,66056,1296,1296,1073741824,1284,4294967296,256,4294967297,1297,512]

theorem envBound14671 : H12AffineFastState.Bounded env14671 := by
  intro p hp
  have h : env14671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14670_14671 : H12AffineEnvironment.transform 14 162 env14670 = env14671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 162 env14670 == env14671) = true)

theorem identity14671 : scanCanonicalize (H12AffineFastState.compose env14671 (packedSelected [1,12,13] rootPS)) = affineNative (2^(10+1) ^^^ 805) := by decide +kernel

theorem selectedBound14671 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env14672 : List Nat := [2,4,8,16,32,17,128,256,512,1024,805,1296,431,1297,162,65536,1296,512,1024,163,1296,65804,17,65959,295,16,66056,1296,1296,1073741824,1284,4294967296,256,4294967297,1297,512]

theorem envBound14672 : H12AffineFastState.Bounded env14672 := by
  intro p hp
  have h : env14672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14671_14672 : H12AffineEnvironment.transform 10 805 env14671 = env14672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 805 env14671 == env14672) = true)

theorem identity14672 : scanCanonicalize (H12AffineFastState.compose env14672 (packedSelected [1,3,12] rootPS)) = affineNative (2^(29+1) ^^^ 67132) := by decide +kernel

theorem selectedBound14672 : packedSelected [1,3,12] rootPS < 2^1333 := by decide +kernel

def env14673 : List Nat := [2,4,8,16,32,17,128,256,512,1024,805,1296,431,1297,162,65536,1296,512,1024,163,1296,65804,17,65959,295,16,66056,1296,1296,67132,1284,4294967296,256,4294967297,1297,512]

theorem envBound14673 : H12AffineFastState.Bounded env14673 := by
  intro p hp
  have h : env14673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14672_14673 : H12AffineEnvironment.transform 29 67132 env14672 = env14673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 67132 env14672 == env14673) = true)

theorem identity14673 : scanCanonicalize (H12AffineFastState.compose env14673 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound14673 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env14674 : List Nat := [2,4,8,16,32,17,128,256,512,273,805,1,431,0,162,65536,1,512,273,163,1,65804,17,65959,295,16,66056,1,1,66349,21,4294967296,256,4294967297,0,512]

theorem envBound14674 : H12AffineFastState.Bounded env14674 := by
  intro p hp
  have h : env14674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14673_14674 : H12AffineEnvironment.transform 9 273 env14673 = env14674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env14673 == env14674) = true)

theorem identity14674 : scanCanonicalize (H12AffineFastState.compose env14674 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 301) := by decide +kernel

theorem selectedBound14674 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14675 : List Nat := [2,4,8,16,32,17,128,256,512,273,805,1,431,0,162,301,1,512,273,163,1,33,17,138,295,16,805,1,1,512,21,4294967296,256,4294967297,0,512]

theorem envBound14675 : H12AffineFastState.Bounded env14675 := by
  intro p hp
  have h : env14675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14674_14675 : H12AffineEnvironment.transform 15 301 env14674 = env14675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 301 env14674 == env14675) = true)

theorem identity14675 : scanCanonicalize (H12AffineFastState.compose env14675 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound14675 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14676 : List Nat := [2,4,8,16,32,17,128,256,137,273,428,1,431,0,162,301,1,137,273,163,1,33,17,138,295,16,428,1,1,137,21,4294967296,256,4294967297,0,137]

theorem envBound14676 : H12AffineFastState.Bounded env14676 := by
  intro p hp
  have h : env14676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14675_14676 : H12AffineEnvironment.transform 8 137 env14675 = env14676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env14675 == env14676) = true)

theorem identity14676 : scanCanonicalize (H12AffineFastState.compose env14676 (packedSelected [0,4] rootPS)) = affineNative (2^(31+1) ^^^ 422) := by decide +kernel

theorem selectedBound14676 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env14677 : List Nat := [2,4,8,16,32,17,128,256,137,273,428,1,431,0,162,301,1,137,273,163,1,33,17,138,295,16,428,1,1,137,21,422,256,423,0,137]

theorem envBound14677 : H12AffineFastState.Bounded env14677 := by
  intro p hp
  have h : env14677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14676_14677 : H12AffineEnvironment.transform 31 422 env14676 = env14677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 422 env14676 == env14677) = true)

theorem identity14677 : scanCanonicalize (H12AffineFastState.compose env14677 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound14677 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env14678 : List Nat := [2,4,8,16,32,17,128,172,137,189,0,1,3,0,162,129,1,137,189,163,1,33,17,138,139,16,0,1,1,137,21,10,172,11,0,137]

theorem envBound14678 : H12AffineFastState.Bounded env14678 := by
  intro p hp
  have h : env14678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14677_14678 : H12AffineEnvironment.transform 7 172 env14677 = env14678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env14677 == env14678) = true)

theorem identity14678 : scanCanonicalize (H12AffineFastState.compose env14678 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound14678 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env14679 : List Nat := [2,4,8,16,32,17,8,36,1,53,0,1,3,0,42,9,1,1,53,43,1,33,17,2,3,16,0,1,1,1,21,10,36,11,0,1]

theorem envBound14679 : H12AffineFastState.Bounded env14679 := by
  intro p hp
  have h : env14679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14678_14679 : H12AffineEnvironment.transform 6 8 env14678 = env14679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14678 == env14679) = true)

theorem identity14679 : scanCanonicalize (H12AffineFastState.compose env14679 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound14679 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14680 : List Nat := [2,4,8,1,32,0,8,36,1,36,0,1,3,0,42,9,1,1,36,43,1,33,0,2,3,1,0,1,1,1,4,10,36,11,0,1]

theorem envBound14680 : H12AffineFastState.Bounded env14680 := by
  intro p hp
  have h : env14680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14679_14680 : H12AffineEnvironment.transform 3 1 env14679 = env14680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env14679 == env14680) = true)

def env14681 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,65536,1345,513,524288,32769,1345,4194304,64,98565,8328,525328,134217728,1345,524609,1073741824,1284,4294967296,256,4299260335,138936901,512]

theorem envBound14681 : H12AffineFastState.Bounded env14681 := by
  intro p hp
  have h : env14681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14564_14681 : H12AffineEnvironment.transform 17 513 env14564 = env14681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 513 env14564 == env14681) = true)

def env14682 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,65536,1345,513,1104,32769,1345,4194304,64,98565,8328,64,134217728,1345,1297,1073741824,1284,4294967296,256,4299260335,138413589,512]

theorem envBound14682 : H12AffineFastState.Bounded env14682 := by
  intro p hp
  have h : env14682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14681_14682 : H12AffineEnvironment.transform 18 1104 env14681 = env14682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1104 env14681 == env14682) = true)

theorem identity14682 : scanCanonicalize (H12AffineFastState.compose env14682 (packedSelected [3,5,24] rootPS)) = affineNative (2^(26+1) ^^^ 4203216) := by decide +kernel

theorem selectedBound14682 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env14683 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,65536,1345,513,1104,32769,1345,4194304,64,98565,8328,64,4203216,1345,1297,1073741824,1284,4294967296,256,4299260335,9413,512]

theorem envBound14683 : H12AffineFastState.Bounded env14683 := by
  intro p hp
  have h : env14683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14682_14683 : H12AffineEnvironment.transform 26 4203216 env14682 = env14683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 4203216 env14682 == env14683) = true)

def env14684 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1296,32768,65536,1297,513,1024,32769,1297,4194304,16,98565,8328,16,4203136,1297,1297,1073741824,1284,4294967296,256,4299260335,9365,512]

theorem envBound14684 : H12AffineFastState.Bounded env14684 := by
  intro p hp
  have h : env14684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14683_14684 : H12AffineEnvironment.transform 5 16 env14683 = env14684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env14683 == env14684) = true)

theorem identity14684 : scanCanonicalize (H12AffineFastState.compose env14684 (packedSelected [3,5,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound14684 : packedSelected [3,5,8,28] rootPS < 2^1333 := by decide +kernel

def env14685 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,389,1296,32768,65536,1297,513,1024,32769,1297,4194304,16,98565,269,16,4195077,1297,1297,1073741824,1284,4294967296,256,4299260335,1296,512]

theorem envBound14685 : H12AffineFastState.Bounded env14685 := by
  intro p hp
  have h : env14685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14684_14685 : H12AffineEnvironment.transform 12 389 env14684 = env14685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env14684 == env14685) = true)

theorem identity14685 : scanCanonicalize (H12AffineFastState.compose env14685 (packedSelected [1,12,13] rootPS)) = affineNative (2^(29+1) ^^^ 4227753) := by decide +kernel

theorem selectedBound14685 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env14686 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,389,1296,32768,65536,1297,513,1024,32769,1297,4194304,16,98565,269,16,4195077,1297,1297,4227753,1284,4294967296,256,4299260335,1296,512]

theorem envBound14686 : H12AffineFastState.Bounded env14686 := by
  intro p hp
  have h : env14686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14685_14686 : H12AffineEnvironment.transform 29 4227753 env14685 = env14686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4227753 env14685 == env14686) = true)

theorem identity14686 : scanCanonicalize (H12AffineFastState.compose env14686 (packedSelected [12] rootPS)) = affineNative (2^(21+1) ^^^ 32937) := by decide +kernel

theorem selectedBound14686 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env14687 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,389,1296,32768,65536,1297,513,1024,32769,1297,32937,16,98565,269,16,33708,1297,1297,512,1284,4294967296,256,4295033094,1296,512]

theorem envBound14687 : H12AffineFastState.Bounded env14687 := by
  intro p hp
  have h : env14687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14686_14687 : H12AffineEnvironment.transform 21 32937 env14686 = env14687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32937 env14686 == env14687) = true)

theorem identity14687 : scanCanonicalize (H12AffineFastState.compose env14687 (packedSelected [1,3,15] rootPS)) = affineNative (2^(14+1) ^^^ 2989) := by decide +kernel

theorem selectedBound14687 : packedSelected [1,3,15] rootPS < 2^1333 := by decide +kernel

def env14688 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,389,1296,2989,65536,1297,513,1024,2988,1297,2820,16,68264,269,16,2049,1297,1297,512,1284,4294967296,256,4295033094,1296,512]

theorem envBound14688 : H12AffineFastState.Bounded env14688 := by
  intro p hp
  have h : env14688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14687_14688 : H12AffineEnvironment.transform 14 2989 env14687 = env14688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2989 env14687 == env14688) = true)

def env14689 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,1,389,0,2989,65536,1,513,272,2988,1,2820,16,68264,269,16,2049,1,1,512,20,4294967296,256,4295033094,0,512]

theorem envBound14689 : H12AffineFastState.Bounded env14689 := by
  intro p hp
  have h : env14689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14688_14689 : H12AffineEnvironment.transform 9 272 env14688 = env14689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env14688 == env14689) = true)

theorem identity14689 : scanCanonicalize (H12AffineFastState.compose env14689 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 2595) := by decide +kernel

theorem selectedBound14689 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14690 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,1,389,0,2989,2595,1,513,272,2988,1,2820,16,139,269,16,2049,1,1,512,20,4294967296,256,4294970149,0,512]

theorem envBound14690 : H12AffineFastState.Bounded env14690 := by
  intro p hp
  have h : env14690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14689_14690 : H12AffineEnvironment.transform 15 2595 env14689 = env14690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2595 env14689 == env14690) = true)

def env14691 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,1,389,0,2989,2595,1,513,272,2988,1,2820,16,139,269,16,2049,1,1,512,20,2592,256,261,0,512]

theorem envBound14691 : H12AffineFastState.Bounded env14691 := by
  intro p hp
  have h : env14691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14690_14691 : H12AffineEnvironment.transform 31 2592 env14690 = env14691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 2592 env14690 == env14691) = true)

theorem identity14691 : scanCanonicalize (H12AffineFastState.compose env14691 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound14691 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14692 : List Nat := [2,4,8,16,32,16,128,256,32,272,2048,1,389,0,2445,2051,1,33,272,2444,1,2340,16,139,269,16,2049,1,1,32,20,2048,256,261,0,32]

theorem envBound14692 : H12AffineFastState.Bounded env14692 := by
  intro p hp
  have h : env14692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14691_14692 : H12AffineEnvironment.transform 8 32 env14691 = env14692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env14691 == env14692) = true)

def env14693 : List Nat := [2,4,8,16,0,16,128,256,0,272,2048,1,389,0,2445,2051,1,1,272,2444,1,2308,16,139,269,16,2049,1,1,0,20,2048,256,261,0,0]

theorem envBound14693 : H12AffineFastState.Bounded env14693 := by
  intro p hp
  have h : env14693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14692_14693 : H12AffineEnvironment.transform 4 0 env14692 = env14693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14692 == env14693) = true)

theorem identity14693 : scanCanonicalize (H12AffineFastState.compose env14693 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound14693 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env14694 : List Nat := [2,4,8,16,0,16,128,256,0,272,1,1,389,0,396,2,1,1,272,397,1,261,16,139,269,16,0,1,1,0,20,1,256,261,0,0]

theorem envBound14694 : H12AffineFastState.Bounded env14694 := by
  intro p hp
  have h : env14694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14693_14694 : H12AffineEnvironment.transform 10 1 env14693 = env14694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env14693 == env14694) = true)

def env14695 : List Nat := [2,4,8,16,0,16,8,256,0,272,1,1,269,0,260,2,1,1,272,261,1,261,16,3,269,16,0,1,1,0,20,1,256,261,0,0]

theorem envBound14695 : H12AffineFastState.Bounded env14695 := by
  intro p hp
  have h : env14695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14694_14695 : H12AffineEnvironment.transform 6 8 env14694 = env14695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14694 == env14695) = true)

def leafEnv14695 : List Nat := [2,4,8,16,0,16,8,256,0,272,1,1,269,0,260,2,1,1,272,261,1,261,16,3,20,269,1,16,0,1,1,0,20,1,256,261,4,3,0,0,0,1,1]

def active14695 : List Nat := [0,1,2,3,7]

def tree14695 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14695 : H12WitnessSearch.Good tree14695 := H12GlobalWitnessIndex.good

theorem leafIdentity14695 : H12AffineFastState.composeSystem env14695 rootObs = leafEnv14695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14695 rootObs == leafEnv14695) = true)

theorem terminalChecked14695 : H12PackedTerminal.terminalCheckFast leafEnv14695 active14695 tree14695 = true := by decide +kernel

def env14696 : List Nat := [2,4,8,16,0,16,9,256,0,272,1,1,268,0,261,2,1,1,272,260,1,261,16,2,269,16,0,1,1,0,20,1,256,261,0,0]

theorem envBound14696 : H12AffineFastState.Bounded env14696 := by
  intro p hp
  have h : env14696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14694_14696 : H12AffineEnvironment.transform 6 9 env14694 = env14696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14694 == env14696) = true)

theorem identity14696 : scanCanonicalize (H12AffineFastState.compose env14696 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound14696 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14697 : List Nat := [2,4,8,16,0,16,9,5,0,21,1,1,9,0,0,2,1,1,21,1,1,0,16,2,8,16,0,1,1,0,20,1,5,0,0,0]

theorem envBound14697 : H12AffineFastState.Bounded env14697 := by
  intro p hp
  have h : env14697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14696_14697 : H12AffineEnvironment.transform 7 5 env14696 = env14697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env14696 == env14697) = true)

def leafEnv14697 : List Nat := [2,4,8,16,0,16,9,5,0,21,1,1,9,0,0,2,1,1,21,1,1,0,16,2,20,8,1,16,0,1,1,0,20,1,5,0,4,2,0,0,0,1,1]

def active14697 : List Nat := [0,1,2,3]

def tree14697 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14697 : H12WitnessSearch.Good tree14697 := H12GlobalWitnessIndex.good

theorem leafIdentity14697 : H12AffineFastState.composeSystem env14697 rootObs = leafEnv14697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14697 rootObs == leafEnv14697) = true)

theorem terminalChecked14697 : H12PackedTerminal.terminalCheckFast leafEnv14697 active14697 tree14697 = true := by decide +kernel

def env14698 : List Nat := [2,4,8,16,1,16,128,256,1,272,2048,1,389,0,2445,2051,1,0,272,2444,1,2309,16,139,269,16,2049,1,1,1,20,2048,256,261,0,1]

theorem envBound14698 : H12AffineFastState.Bounded env14698 := by
  intro p hp
  have h : env14698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14692_14698 : H12AffineEnvironment.transform 4 1 env14692 = env14698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14692 == env14698) = true)

theorem identity14698 : scanCanonicalize (H12AffineFastState.compose env14698 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 137) := by decide +kernel

theorem selectedBound14698 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env14699 : List Nat := [2,4,8,16,1,16,128,256,1,272,137,1,389,0,260,138,1,0,272,261,1,396,16,139,269,16,136,1,1,1,20,137,256,261,0,1]

theorem envBound14699 : H12AffineFastState.Bounded env14699 := by
  intro p hp
  have h : env14699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14698_14699 : H12AffineEnvironment.transform 10 137 env14698 = env14699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 137 env14698 == env14699) = true)

theorem identity14699 : scanCanonicalize (H12AffineFastState.compose env14699 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound14699 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14700 : List Nat := [2,4,8,16,1,16,128,5,1,21,137,1,128,0,1,138,1,0,21,0,1,137,16,139,8,16,136,1,1,1,20,137,5,0,0,1]

theorem envBound14700 : H12AffineFastState.Bounded env14700 := by
  intro p hp
  have h : env14700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14699_14700 : H12AffineEnvironment.transform 7 5 env14699 = env14700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env14699 == env14700) = true)

def leafEnv14700 : List Nat := [2,4,8,16,1,16,128,5,1,21,137,1,128,0,1,138,1,0,21,0,1,137,16,139,20,8,1,16,136,1,1,1,20,137,5,0,4,3,0,1,0,1,1]

def active14700 : List Nat := [0,1,2,3,6]

def tree14700 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14700 : H12WitnessSearch.Good tree14700 := H12GlobalWitnessIndex.good

theorem leafIdentity14700 : H12AffineFastState.composeSystem env14700 rootObs = leafEnv14700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14700 rootObs == leafEnv14700) = true)

theorem terminalChecked14700 : H12PackedTerminal.terminalCheckFast leafEnv14700 active14700 tree14700 = true := by decide +kernel

def env14701 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,1,389,0,2989,2595,1,513,272,2988,1,2820,16,139,269,16,2049,1,1,512,20,2593,256,260,0,512]

theorem envBound14701 : H12AffineFastState.Bounded env14701 := by
  intro p hp
  have h : env14701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14690_14701 : H12AffineEnvironment.transform 31 2593 env14690 = env14701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 2593 env14690 == env14701) = true)

theorem identity14701 : scanCanonicalize (H12AffineFastState.compose env14701 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 260) := by decide +kernel

theorem selectedBound14701 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14702 : List Nat := [2,4,8,16,32,16,128,256,512,272,260,1,389,0,681,807,1,513,272,680,1,512,16,139,269,16,261,1,1,512,20,805,256,260,0,512]

theorem envBound14702 : H12AffineFastState.Bounded env14702 := by
  intro p hp
  have h : env14702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14701_14702 : H12AffineEnvironment.transform 10 260 env14701 = env14702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env14701 == env14702) = true)

def env14703 : List Nat := [2,4,8,16,32,16,128,256,0,272,260,1,389,0,169,295,1,1,272,168,1,0,16,139,269,16,261,1,1,0,20,293,256,260,0,0]

theorem envBound14703 : H12AffineFastState.Bounded env14703 := by
  intro p hp
  have h : env14703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14702_14703 : H12AffineEnvironment.transform 8 0 env14702 = env14703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env14702 == env14703) = true)

theorem identity14703 : scanCanonicalize (H12AffineFastState.compose env14703 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound14703 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env14704 : List Nat := [2,4,8,16,32,16,128,5,0,21,1,1,128,0,169,34,1,1,21,168,1,0,16,139,8,16,0,1,1,0,20,32,5,1,0,0]

theorem envBound14704 : H12AffineFastState.Bounded env14704 := by
  intro p hp
  have h : env14704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14703_14704 : H12AffineEnvironment.transform 7 5 env14703 = env14704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env14703 == env14704) = true)

def env14705 : List Nat := [2,4,8,16,0,16,128,5,0,21,1,1,128,0,137,2,1,1,21,136,1,0,16,139,8,16,0,1,1,0,20,0,5,1,0,0]

theorem envBound14705 : H12AffineFastState.Bounded env14705 := by
  intro p hp
  have h : env14705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14704_14705 : H12AffineEnvironment.transform 4 0 env14704 = env14705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14704 == env14705) = true)

def env14706 : List Nat := [2,4,8,16,1,16,128,5,0,21,1,1,128,0,136,3,1,1,21,137,1,0,16,139,8,16,0,1,1,0,20,1,5,1,0,0]

theorem envBound14706 : H12AffineFastState.Bounded env14706 := by
  intro p hp
  have h : env14706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14704_14706 : H12AffineEnvironment.transform 4 1 env14704 = env14706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14704 == env14706) = true)

theorem identity14706 : scanCanonicalize (H12AffineFastState.compose env14706 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound14706 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14707 : List Nat := [2,4,8,16,1,16,8,5,0,21,1,1,8,0,0,3,1,1,21,1,1,0,16,3,8,16,0,1,1,0,20,1,5,1,0,0]

theorem envBound14707 : H12AffineFastState.Bounded env14707 := by
  intro p hp
  have h : env14707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14706_14707 : H12AffineEnvironment.transform 6 8 env14706 = env14707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14706 == env14707) = true)

def leafEnv14707 : List Nat := [2,4,8,16,1,16,8,5,0,21,1,1,8,0,0,3,1,1,21,1,1,0,16,3,20,8,1,16,0,1,1,0,20,1,5,1,4,2,0,0,0,1,1]

def active14707 : List Nat := [0,1,2,3]

def tree14707 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14707 : H12WitnessSearch.Good tree14707 := H12GlobalWitnessIndex.good

theorem leafIdentity14707 : H12AffineFastState.composeSystem env14707 rootObs = leafEnv14707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14707 rootObs == leafEnv14707) = true)

theorem terminalChecked14707 : H12PackedTerminal.terminalCheckFast leafEnv14707 active14707 tree14707 = true := by decide +kernel

def env14708 : List Nat := [2,4,8,16,32,16,128,256,1,272,260,1,389,0,168,294,1,0,272,169,1,1,16,139,269,16,261,1,1,1,20,292,256,260,0,1]

theorem envBound14708 : H12AffineFastState.Bounded env14708 := by
  intro p hp
  have h : env14708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14702_14708 : H12AffineEnvironment.transform 8 1 env14702 = env14708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env14702 == env14708) = true)

theorem identity14708 : scanCanonicalize (H12AffineFastState.compose env14708 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 141) := by decide +kernel

theorem selectedBound14708 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env14709 : List Nat := [2,4,8,16,32,16,128,141,1,157,137,1,8,0,168,171,1,0,157,169,1,1,16,139,128,16,136,1,1,1,20,169,141,137,0,1]

theorem envBound14709 : H12AffineFastState.Bounded env14709 := by
  intro p hp
  have h : env14709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14708_14709 : H12AffineEnvironment.transform 7 141 env14708 = env14709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 141 env14708 == env14709) = true)

theorem identity14709 : scanCanonicalize (H12AffineFastState.compose env14709 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound14709 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14710 : List Nat := [2,4,8,16,32,16,9,4,1,20,0,1,8,0,33,34,1,0,20,32,1,1,16,2,9,16,1,1,1,1,20,32,4,0,0,1]

theorem envBound14710 : H12AffineFastState.Bounded env14710 := by
  intro p hp
  have h : env14710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14709_14710 : H12AffineEnvironment.transform 6 9 env14709 = env14710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14709 == env14710) = true)

def leafEnv14710 : List Nat := [2,4,8,16,32,16,9,4,1,20,0,1,8,0,33,34,1,0,20,32,1,1,16,2,20,9,1,16,1,1,1,1,20,32,4,0,4,34,0,1,0,1,1]

def active14710 : List Nat := [0,1,2,3,4]

def tree14710 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14710 : H12WitnessSearch.Good tree14710 := H12GlobalWitnessIndex.good

theorem leafIdentity14710 : H12AffineFastState.composeSystem env14710 rootObs = leafEnv14710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14710 rootObs == leafEnv14710) = true)

theorem terminalChecked14710 : H12PackedTerminal.terminalCheckFast leafEnv14710 active14710 tree14710 = true := by decide +kernel

def env14711 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,0,389,1,2989,65536,0,513,273,2988,0,2820,16,68264,269,16,2049,0,0,512,21,4294967296,256,4295033094,1,512]

theorem envBound14711 : H12AffineFastState.Bounded env14711 := by
  intro p hp
  have h : env14711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14688_14711 : H12AffineEnvironment.transform 9 273 env14688 = env14711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env14688 == env14711) = true)

def env14712 : List Nat := [2,4,8,16,32,16,128,256,512,273,940,0,389,1,1,65536,0,513,273,0,0,168,16,65796,269,16,941,0,0,512,21,4294967296,256,4295033094,1,512]

theorem envBound14712 : H12AffineFastState.Bounded env14712 := by
  intro p hp
  have h : env14712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14711_14712 : H12AffineEnvironment.transform 10 940 env14711 = env14712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 940 env14711 == env14712) = true)

def env14713 : List Nat := [2,4,8,16,32,16,8,256,512,273,804,0,269,1,1,65536,0,513,273,0,0,32,16,65796,269,16,805,0,0,512,21,4294967296,256,4295033094,1,512]

theorem envBound14713 : H12AffineFastState.Bounded env14713 := by
  intro p hp
  have h : env14713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14712_14713 : H12AffineEnvironment.transform 6 8 env14712 = env14713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14712 == env14713) = true)

theorem identity14713 : scanCanonicalize (H12AffineFastState.compose env14713 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 66083) := by decide +kernel

theorem selectedBound14713 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14714 : List Nat := [2,4,8,16,32,16,8,256,512,273,804,0,269,1,1,65536,0,513,273,0,0,32,16,65796,269,16,805,0,0,512,21,66083,256,805,1,512]

theorem envBound14714 : H12AffineFastState.Bounded env14714 := by
  intro p hp
  have h : env14714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14713_14714 : H12AffineEnvironment.transform 31 66083 env14713 = env14714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 66083 env14713 == env14714) = true)

theorem identity14714 : scanCanonicalize (H12AffineFastState.compose env14714 (packedSelected [4,6] rootPS)) = affineNative (2^(15+1) ^^^ 807) := by decide +kernel

theorem selectedBound14714 : packedSelected [4,6] rootPS < 2^1333 := by decide +kernel

def env14715 : List Nat := [2,4,8,16,32,16,8,256,512,273,804,0,269,1,1,807,0,513,273,0,0,32,16,547,269,16,805,0,0,512,21,260,256,805,1,512]

theorem envBound14715 : H12AffineFastState.Bounded env14715 := by
  intro p hp
  have h : env14715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14714_14715 : H12AffineEnvironment.transform 15 807 env14714 = env14715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 807 env14714 == env14715) = true)

def env14716 : List Nat := [2,4,8,16,32,16,8,256,0,273,292,0,269,1,1,295,0,1,273,0,0,32,16,35,269,16,293,0,0,0,21,260,256,293,1,0]

theorem envBound14716 : H12AffineFastState.Bounded env14716 := by
  intro p hp
  have h : env14716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14715_14716 : H12AffineEnvironment.transform 8 0 env14715 = env14716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env14715 == env14716) = true)

def env14717 : List Nat := [2,4,8,16,0,16,8,256,0,273,260,0,269,1,1,263,0,1,273,0,0,0,16,3,269,16,261,0,0,0,21,260,256,261,1,0]

theorem envBound14717 : H12AffineFastState.Bounded env14717 := by
  intro p hp
  have h : env14717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14716_14717 : H12AffineEnvironment.transform 4 0 env14716 = env14717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14716 == env14717) = true)

theorem identity14717 : scanCanonicalize (H12AffineFastState.compose env14717 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound14717 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env14718 : List Nat := [2,4,8,16,0,16,8,5,0,20,1,0,8,1,1,2,0,1,20,0,0,0,16,3,8,16,0,0,0,0,21,1,5,0,1,0]

theorem envBound14718 : H12AffineFastState.Bounded env14718 := by
  intro p hp
  have h : env14718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14717_14718 : H12AffineEnvironment.transform 7 5 env14717 = env14718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env14717 == env14718) = true)

def leafEnv14718 : List Nat := [2,4,8,16,0,16,8,5,0,20,1,0,8,1,1,2,0,1,20,0,0,0,16,3,21,8,1,16,0,0,0,0,21,1,5,0,4,3,1,0,0,0,1]

def active14718 : List Nat := [0,1,2,3]

def tree14718 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14718 : H12WitnessSearch.Good tree14718 := H12GlobalWitnessIndex.good

theorem leafIdentity14718 : H12AffineFastState.composeSystem env14718 rootObs = leafEnv14718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14718 rootObs == leafEnv14718) = true)

theorem terminalChecked14718 : H12PackedTerminal.terminalCheckFast leafEnv14718 active14718 tree14718 = true := by decide +kernel

def env14719 : List Nat := [2,4,8,16,1,16,8,256,0,273,261,0,269,1,1,262,0,1,273,0,0,1,16,2,269,16,260,0,0,0,21,260,256,260,1,0]

theorem envBound14719 : H12AffineFastState.Bounded env14719 := by
  intro p hp
  have h : env14719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14716_14719 : H12AffineEnvironment.transform 4 1 env14716 = env14719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14716 == env14719) = true)

def leafEnv14719 : List Nat := [2,4,8,16,1,16,8,256,0,273,261,0,269,1,1,262,0,1,273,0,0,1,16,2,21,269,1,16,260,0,0,0,21,260,256,260,4,262,1,0,0,0,1]

def active14719 : List Nat := [0,1,2,3,7]

def tree14719 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14719 : H12WitnessSearch.Good tree14719 := H12GlobalWitnessIndex.good

theorem leafIdentity14719 : H12AffineFastState.composeSystem env14719 rootObs = leafEnv14719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14719 rootObs == leafEnv14719) = true)

theorem terminalChecked14719 : H12PackedTerminal.terminalCheckFast leafEnv14719 active14719 tree14719 = true := by decide +kernel

def env14720 : List Nat := [2,4,8,16,32,16,8,256,1,273,293,0,269,1,1,294,0,0,273,0,0,32,16,34,269,16,292,0,0,1,21,260,256,292,1,1]

theorem envBound14720 : H12AffineFastState.Bounded env14720 := by
  intro p hp
  have h : env14720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14715_14720 : H12AffineEnvironment.transform 8 1 env14715 = env14720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env14715 == env14720) = true)

theorem identity14720 : scanCanonicalize (H12AffineFastState.compose env14720 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound14720 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14721 : List Nat := [2,4,8,16,1,16,8,256,1,273,260,0,269,1,1,263,0,0,273,0,0,1,16,3,269,16,261,0,0,1,21,260,256,261,1,1]

theorem envBound14721 : H12AffineFastState.Bounded env14721 := by
  intro p hp
  have h : env14721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14720_14721 : H12AffineEnvironment.transform 4 1 env14720 = env14721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14720 == env14721) = true)

theorem identity14721 : scanCanonicalize (H12AffineFastState.compose env14721 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound14721 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env14722 : List Nat := [2,4,8,16,1,16,8,5,1,20,1,0,8,1,1,2,0,0,20,0,0,1,16,3,8,16,0,0,0,1,21,1,5,0,1,1]

theorem envBound14722 : H12AffineFastState.Bounded env14722 := by
  intro p hp
  have h : env14722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14721_14722 : H12AffineEnvironment.transform 7 5 env14721 = env14722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env14721 == env14722) = true)

def leafEnv14722 : List Nat := [2,4,8,16,1,16,8,5,1,20,1,0,8,1,1,2,0,0,20,0,0,1,16,3,21,8,1,16,0,0,0,1,21,1,5,0,4,3,1,1,0,0,1]

def active14722 : List Nat := [0,1,2,3]

def tree14722 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14722 : H12WitnessSearch.Good tree14722 := H12GlobalWitnessIndex.good

theorem leafIdentity14722 : H12AffineFastState.composeSystem env14722 rootObs = leafEnv14722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14722 rootObs == leafEnv14722) = true)

theorem terminalChecked14722 : H12PackedTerminal.terminalCheckFast leafEnv14722 active14722 tree14722 = true := by decide +kernel

def env14723 : List Nat := [2,4,8,16,32,16,9,256,512,273,805,0,268,1,1,65536,0,513,273,0,0,33,16,65796,269,16,804,0,0,512,21,4294967296,256,4295033094,1,512]

theorem envBound14723 : H12AffineFastState.Bounded env14723 := by
  intro p hp
  have h : env14723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14712_14723 : H12AffineEnvironment.transform 6 9 env14712 = env14723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14712 == env14723) = true)

theorem identity14723 : scanCanonicalize (H12AffineFastState.compose env14723 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 65798) := by decide +kernel

theorem selectedBound14723 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14724 : List Nat := [2,4,8,16,32,16,9,256,512,273,805,0,268,1,1,65536,0,513,273,0,0,33,16,65796,269,16,804,0,0,512,21,65798,256,0,1,512]

theorem envBound14724 : H12AffineFastState.Bounded env14724 := by
  intro p hp
  have h : env14724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14723_14724 : H12AffineEnvironment.transform 31 65798 env14723 = env14724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 65798 env14723 == env14724) = true)

def env14725 : List Nat := [2,4,8,16,32,16,9,36,512,53,513,0,40,1,1,65536,0,513,53,0,0,33,16,65568,41,16,512,0,0,512,21,65570,36,0,1,512]

theorem envBound14725 : H12AffineFastState.Bounded env14725 := by
  intro p hp
  have h : env14725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14724_14725 : H12AffineEnvironment.transform 7 36 env14724 = env14725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env14724 == env14725) = true)

theorem identity14725 : scanCanonicalize (H12AffineFastState.compose env14725 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound14725 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14726 : List Nat := [2,4,8,16,32,16,9,36,1,53,0,0,40,1,1,65536,0,0,53,0,0,33,16,65568,41,16,1,0,0,1,21,65570,36,0,1,1]

theorem envBound14726 : H12AffineFastState.Bounded env14726 := by
  intro p hp
  have h : env14726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14725_14726 : H12AffineEnvironment.transform 8 1 env14725 = env14726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env14725 == env14726) = true)

def env14727 : List Nat := [2,4,8,16,0,16,9,4,1,21,0,0,8,1,1,65536,0,0,21,0,0,1,16,65536,9,16,1,0,0,1,21,65538,4,0,1,1]

theorem envBound14727 : H12AffineFastState.Bounded env14727 := by
  intro p hp
  have h : env14727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14726_14727 : H12AffineEnvironment.transform 4 0 env14726 = env14727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14726 == env14727) = true)

def leafEnv14727 : List Nat := [2,4,8,16,0,16,9,4,1,21,0,0,8,1,1,65536,0,0,21,0,0,1,16,65536,21,9,1,16,1,0,0,1,21,65538,4,0,4,2,1,1,0,0,1]

def active14727 : List Nat := [0,1,2,3,15]

def tree14727 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14727 : H12WitnessSearch.Good tree14727 := H12GlobalWitnessIndex.good

theorem leafIdentity14727 : H12AffineFastState.composeSystem env14727 rootObs = leafEnv14727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14727 rootObs == leafEnv14727) = true)

theorem terminalChecked14727 : H12PackedTerminal.terminalCheckFast leafEnv14727 active14727 tree14727 = true := by decide +kernel

def env14728 : List Nat := [2,4,8,16,1,16,9,5,1,20,0,0,9,1,1,65536,0,0,20,0,0,0,16,65537,8,16,1,0,0,1,21,65539,5,0,1,1]

theorem envBound14728 : H12AffineFastState.Bounded env14728 := by
  intro p hp
  have h : env14728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14726_14728 : H12AffineEnvironment.transform 4 1 env14726 = env14728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14726 == env14728) = true)

theorem identity14728 : scanCanonicalize (H12AffineFastState.compose env14728 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 3) := by decide +kernel

theorem selectedBound14728 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env14729 : List Nat := [2,4,8,16,1,16,9,5,1,20,0,0,9,1,1,3,0,0,20,0,0,0,16,2,8,16,1,0,0,1,21,0,5,0,1,1]

theorem envBound14729 : H12AffineFastState.Bounded env14729 := by
  intro p hp
  have h : env14729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14728_14729 : H12AffineEnvironment.transform 15 3 env14728 = env14729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3 env14728 == env14729) = true)

def leafEnv14729 : List Nat := [2,4,8,16,1,16,9,5,1,20,0,0,9,1,1,3,0,0,20,0,0,0,16,2,21,8,1,16,1,0,0,1,21,0,5,0,4,3,1,1,0,0,1]

def active14729 : List Nat := [0,1,2,3]

def tree14729 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14729 : H12WitnessSearch.Good tree14729 := H12GlobalWitnessIndex.good

theorem leafIdentity14729 : H12AffineFastState.composeSystem env14729 rootObs = leafEnv14729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14729 rootObs == leafEnv14729) = true)

theorem terminalChecked14729 : H12PackedTerminal.terminalCheckFast leafEnv14729 active14729 tree14729 = true := by decide +kernel

def env14730 : List Nat := [2,4,8,16,32,16,9,37,512,52,512,0,41,1,1,65536,0,513,52,0,0,33,16,65569,40,16,513,0,0,512,21,65571,37,0,1,512]

theorem envBound14730 : H12AffineFastState.Bounded env14730 := by
  intro p hp
  have h : env14730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14724_14730 : H12AffineEnvironment.transform 7 37 env14724 = env14730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env14724 == env14730) = true)

theorem identity14730 : scanCanonicalize (H12AffineFastState.compose env14730 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 547) := by decide +kernel

theorem selectedBound14730 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14731 : List Nat := [2,4,8,16,32,16,9,37,512,52,512,0,41,1,1,547,0,513,52,0,0,33,16,514,40,16,513,0,0,512,21,512,37,0,1,512]

theorem envBound14731 : H12AffineFastState.Bounded env14731 := by
  intro p hp
  have h : env14731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14730_14731 : H12AffineEnvironment.transform 15 547 env14730 = env14731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 547 env14730 == env14731) = true)

def env14732 : List Nat := [2,4,8,16,32,16,9,37,0,52,0,0,41,1,1,35,0,1,52,0,0,33,16,2,40,16,1,0,0,0,21,0,37,0,1,0]

theorem envBound14732 : H12AffineFastState.Bounded env14732 := by
  intro p hp
  have h : env14732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14731_14732 : H12AffineEnvironment.transform 8 0 env14731 = env14732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env14731 == env14732) = true)

def env14733 : List Nat := [2,4,8,16,32,16,9,37,1,52,1,0,41,1,1,34,0,0,52,0,0,33,16,3,40,16,0,0,0,1,21,1,37,0,1,1]

theorem envBound14733 : H12AffineFastState.Bounded env14733 := by
  intro p hp
  have h : env14733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14731_14733 : H12AffineEnvironment.transform 8 1 env14731 = env14733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env14731 == env14733) = true)

theorem identity14733 : scanCanonicalize (H12AffineFastState.compose env14733 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound14733 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env14734 : List Nat := [2,4,8,16,0,16,9,5,1,20,1,0,9,1,1,2,0,0,20,0,0,1,16,3,8,16,0,0,0,1,21,1,5,0,1,1]

theorem envBound14734 : H12AffineFastState.Bounded env14734 := by
  intro p hp
  have h : env14734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14733_14734 : H12AffineEnvironment.transform 4 0 env14733 = env14734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14733 == env14734) = true)

def leafEnv14734 : List Nat := [2,4,8,16,0,16,9,5,1,20,1,0,9,1,1,2,0,0,20,0,0,1,16,3,21,8,1,16,0,0,0,1,21,1,5,0,4,3,1,1,0,0,1]

def active14734 : List Nat := [0,1,2,3]

def tree14734 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14734 : H12WitnessSearch.Good tree14734 := H12GlobalWitnessIndex.good

theorem leafIdentity14734 : H12AffineFastState.composeSystem env14734 rootObs = leafEnv14734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14734 rootObs == leafEnv14734) = true)

theorem terminalChecked14734 : H12PackedTerminal.terminalCheckFast leafEnv14734 active14734 tree14734 = true := by decide +kernel

def env14735 : List Nat := [2,4,8,16,32,16,128,256,512,273,941,0,389,1,0,65536,0,513,273,1,0,169,16,65797,269,16,940,0,0,512,21,4294967296,256,4295033094,1,512]

theorem envBound14735 : H12AffineFastState.Bounded env14735 := by
  intro p hp
  have h : env14735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14711_14735 : H12AffineEnvironment.transform 10 941 env14711 = env14735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 941 env14711 == env14735) = true)

def env14736 : List Nat := [2,4,8,16,32,16,8,256,512,273,805,0,269,1,0,65536,0,513,273,1,0,33,16,65797,269,16,804,0,0,512,21,4294967296,256,4295033094,1,512]

theorem envBound14736 : H12AffineFastState.Bounded env14736 := by
  intro p hp
  have h : env14736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14735_14736 : H12AffineEnvironment.transform 6 8 env14735 = env14736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14735 == env14736) = true)

theorem identity14736 : scanCanonicalize (H12AffineFastState.compose env14736 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 513) := by decide +kernel

theorem selectedBound14736 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14737 : List Nat := [2,4,8,16,32,16,8,256,512,273,805,0,269,1,0,65536,0,513,273,1,0,33,16,65797,269,16,804,0,0,512,21,513,256,66311,1,512]

theorem envBound14737 : H12AffineFastState.Bounded env14737 := by
  intro p hp
  have h : env14737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14736_14737 : H12AffineEnvironment.transform 31 513 env14736 = env14737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 513 env14736 == env14737) = true)

def env14738 : List Nat := [2,4,8,16,32,16,8,256,292,273,1,0,269,1,0,65536,0,293,273,1,0,33,16,65797,269,16,0,0,0,292,21,293,256,65571,1,292]

theorem envBound14738 : H12AffineFastState.Bounded env14738 := by
  intro p hp
  have h : env14738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14737_14738 : H12AffineEnvironment.transform 8 292 env14737 = env14738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env14737 == env14738) = true)

theorem identity14738 : scanCanonicalize (H12AffineFastState.compose env14738 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound14738 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14739 : List Nat := [2,4,8,16,32,16,8,36,0,53,1,0,41,1,0,65536,0,1,53,1,0,33,16,65569,41,16,0,0,0,0,21,1,36,65571,1,0]

theorem envBound14739 : H12AffineFastState.Bounded env14739 := by
  intro p hp
  have h : env14739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14738_14739 : H12AffineEnvironment.transform 7 36 env14738 = env14739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env14738 == env14739) = true)

def env14740 : List Nat := [2,4,8,16,0,16,8,4,0,21,1,0,9,1,0,65536,0,1,21,1,0,1,16,65537,9,16,0,0,0,0,21,1,4,65539,1,0]

theorem envBound14740 : H12AffineFastState.Bounded env14740 := by
  intro p hp
  have h : env14740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14739_14740 : H12AffineEnvironment.transform 4 0 env14739 = env14740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14739 == env14740) = true)

def leafEnv14740 : List Nat := [2,4,8,16,0,16,8,4,0,21,1,0,9,1,0,65536,0,1,21,1,0,1,16,65537,21,9,1,16,0,0,0,0,21,1,4,65539,4,3,1,0,0,0,1]

def active14740 : List Nat := [0,1,2,3,15]

def tree14740 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14740 : H12WitnessSearch.Good tree14740 := H12GlobalWitnessIndex.good

theorem leafIdentity14740 : H12AffineFastState.composeSystem env14740 rootObs = leafEnv14740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14740 rootObs == leafEnv14740) = true)

theorem terminalChecked14740 : H12PackedTerminal.terminalCheckFast leafEnv14740 active14740 tree14740 = true := by decide +kernel

def env14741 : List Nat := [2,4,8,16,1,16,8,5,0,20,1,0,8,1,0,65536,0,1,20,1,0,0,16,65536,8,16,0,0,0,0,21,1,5,65538,1,0]

theorem envBound14741 : H12AffineFastState.Bounded env14741 := by
  intro p hp
  have h : env14741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14739_14741 : H12AffineEnvironment.transform 4 1 env14739 = env14741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14739 == env14741) = true)

theorem identity14741 : scanCanonicalize (H12AffineFastState.compose env14741 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 3) := by decide +kernel

theorem selectedBound14741 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env14742 : List Nat := [2,4,8,16,1,16,8,5,0,20,1,0,8,1,0,3,0,1,20,1,0,0,16,3,8,16,0,0,0,0,21,1,5,1,1,0]

theorem envBound14742 : H12AffineFastState.Bounded env14742 := by
  intro p hp
  have h : env14742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14741_14742 : H12AffineEnvironment.transform 15 3 env14741 = env14742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3 env14741 == env14742) = true)

def leafEnv14742 : List Nat := [2,4,8,16,1,16,8,5,0,20,1,0,8,1,0,3,0,1,20,1,0,0,16,3,21,8,1,16,0,0,0,0,21,1,5,1,4,2,1,0,0,0,1]

def active14742 : List Nat := [0,1,2,3]

def tree14742 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14742 : H12WitnessSearch.Good tree14742 := H12GlobalWitnessIndex.good

theorem leafIdentity14742 : H12AffineFastState.composeSystem env14742 rootObs = leafEnv14742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14742 rootObs == leafEnv14742) = true)

theorem terminalChecked14742 : H12PackedTerminal.terminalCheckFast leafEnv14742 active14742 tree14742 = true := by decide +kernel

def env14743 : List Nat := [2,4,8,16,32,16,8,256,293,273,0,0,269,1,0,65536,0,292,273,1,0,33,16,65797,269,16,1,0,0,293,21,292,256,65570,1,293]

theorem envBound14743 : H12AffineFastState.Bounded env14743 := by
  intro p hp
  have h : env14743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14737_14743 : H12AffineEnvironment.transform 8 293 env14737 = env14743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env14737 == env14743) = true)

theorem identity14743 : scanCanonicalize (H12AffineFastState.compose env14743 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound14743 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14744 : List Nat := [2,4,8,16,32,16,8,256,293,273,0,0,269,1,0,34,0,292,273,1,0,33,16,295,269,16,1,0,0,293,21,292,256,0,1,293]

theorem envBound14744 : H12AffineFastState.Bounded env14744 := by
  intro p hp
  have h : env14744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14743_14744 : H12AffineEnvironment.transform 15 34 env14743 = env14744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env14743 == env14744) = true)

def env14745 : List Nat := [2,4,8,16,0,16,8,256,261,273,0,0,269,1,0,2,0,260,273,1,0,1,16,263,269,16,1,0,0,261,21,260,256,0,1,261]

theorem envBound14745 : H12AffineFastState.Bounded env14745 := by
  intro p hp
  have h : env14745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14744_14745 : H12AffineEnvironment.transform 4 0 env14744 = env14745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14744 == env14745) = true)

theorem identity14745 : scanCanonicalize (H12AffineFastState.compose env14745 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound14745 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env14746 : List Nat := [2,4,8,16,0,16,8,5,0,20,0,0,8,1,0,2,0,1,20,1,0,1,16,2,8,16,1,0,0,0,21,1,5,0,1,0]

theorem envBound14746 : H12AffineFastState.Bounded env14746 := by
  intro p hp
  have h : env14746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14745_14746 : H12AffineEnvironment.transform 7 5 env14745 = env14746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env14745 == env14746) = true)

def leafEnv14746 : List Nat := [2,4,8,16,0,16,8,5,0,20,0,0,8,1,0,2,0,1,20,1,0,1,16,2,21,8,1,16,1,0,0,0,21,1,5,0,4,2,1,0,0,0,1]

def active14746 : List Nat := [0,1,2,3]

def tree14746 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14746 : H12WitnessSearch.Good tree14746 := H12GlobalWitnessIndex.good

theorem leafIdentity14746 : H12AffineFastState.composeSystem env14746 rootObs = leafEnv14746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14746 rootObs == leafEnv14746) = true)

theorem terminalChecked14746 : H12PackedTerminal.terminalCheckFast leafEnv14746 active14746 tree14746 = true := by decide +kernel

def env14747 : List Nat := [2,4,8,16,1,16,8,256,260,273,0,0,269,1,0,3,0,261,273,1,0,0,16,262,269,16,1,0,0,260,21,261,256,0,1,260]

theorem envBound14747 : H12AffineFastState.Bounded env14747 := by
  intro p hp
  have h : env14747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14744_14747 : H12AffineEnvironment.transform 4 1 env14744 = env14747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14744 == env14747) = true)

def env14748 : List Nat := [2,4,8,16,32,16,9,256,512,273,804,0,268,1,0,65536,0,513,273,1,0,32,16,65797,269,16,805,0,0,512,21,4294967296,256,4295033094,1,512]

theorem envBound14748 : H12AffineFastState.Bounded env14748 := by
  intro p hp
  have h : env14748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14735_14748 : H12AffineEnvironment.transform 6 9 env14735 = env14748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14735 == env14748) = true)

theorem identity14748 : scanCanonicalize (H12AffineFastState.compose env14748 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 292) := by decide +kernel

theorem selectedBound14748 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14749 : List Nat := [2,4,8,16,32,16,9,256,512,273,804,0,268,1,0,65536,0,513,273,1,0,32,16,65797,269,16,805,0,0,512,21,292,256,65570,1,512]

theorem envBound14749 : H12AffineFastState.Bounded env14749 := by
  intro p hp
  have h : env14749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14748_14749 : H12AffineEnvironment.transform 31 292 env14748 = env14749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 292 env14748 == env14749) = true)

theorem identity14749 : scanCanonicalize (H12AffineFastState.compose env14749 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 807) := by decide +kernel

theorem selectedBound14749 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14750 : List Nat := [2,4,8,16,32,16,9,256,512,273,804,0,268,1,0,807,0,513,273,1,0,32,16,546,269,16,805,0,0,512,21,292,256,773,1,512]

theorem envBound14750 : H12AffineFastState.Bounded env14750 := by
  intro p hp
  have h : env14750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14749_14750 : H12AffineEnvironment.transform 15 807 env14749 = env14750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 807 env14749 == env14750) = true)

def env14751 : List Nat := [2,4,8,16,32,16,9,256,32,273,260,0,268,1,0,263,0,33,273,1,0,32,16,2,269,16,261,0,0,32,21,292,256,293,1,32]

theorem envBound14751 : H12AffineFastState.Bounded env14751 := by
  intro p hp
  have h : env14751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14750_14751 : H12AffineEnvironment.transform 8 32 env14750 = env14751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env14750 == env14751) = true)

theorem identity14751 : scanCanonicalize (H12AffineFastState.compose env14751 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound14751 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env14752 : List Nat := [2,4,8,16,32,16,9,37,32,52,33,0,41,1,0,34,0,33,52,1,0,32,16,2,40,16,32,0,0,32,21,1,37,0,1,32]

theorem envBound14752 : H12AffineFastState.Bounded env14752 := by
  intro p hp
  have h : env14752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14751_14752 : H12AffineEnvironment.transform 7 37 env14751 = env14752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env14751 == env14752) = true)

def leafEnv14752 : List Nat := [2,4,8,16,32,16,9,37,32,52,33,0,41,1,0,34,0,33,52,1,0,32,16,2,21,40,1,16,32,0,0,32,21,1,37,0,4,34,1,32,0,0,1]

def active14752 : List Nat := [0,1,2,3,4]

def tree14752 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14752 : H12WitnessSearch.Good tree14752 := H12GlobalWitnessIndex.good

theorem leafIdentity14752 : H12AffineFastState.composeSystem env14752 rootObs = leafEnv14752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14752 rootObs == leafEnv14752) = true)

theorem terminalChecked14752 : H12PackedTerminal.terminalCheckFast leafEnv14752 active14752 tree14752 = true := by decide +kernel

def env14753 : List Nat := [2,4,8,16,32,16,9,256,33,273,261,0,268,1,0,262,0,32,273,1,0,32,16,3,269,16,260,0,0,33,21,292,256,292,1,33]

theorem envBound14753 : H12AffineFastState.Bounded env14753 := by
  intro p hp
  have h : env14753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14750_14753 : H12AffineEnvironment.transform 8 33 env14750 = env14753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env14750 == env14753) = true)

def env14754 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1297,32768,65536,1296,513,1025,32769,1296,4194304,17,98565,8328,17,4203137,1296,1297,1073741824,1284,4294967296,256,4299260335,9364,512]

theorem envBound14754 : H12AffineFastState.Bounded env14754 := by
  intro p hp
  have h : env14754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14683_14754 : H12AffineEnvironment.transform 5 17 env14683 = env14754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env14683 == env14754) = true)

theorem identity14754 : scanCanonicalize (H12AffineFastState.compose env14754 (packedSelected [3,5,10] rootPS)) = affineNative (2^(29+1) ^^^ 4270863) := by decide +kernel

theorem selectedBound14754 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env14755 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1297,32768,65536,1296,513,1025,32769,1296,4194304,17,98565,8328,17,4203137,1296,1297,4270863,1284,4294967296,256,4299260335,9364,512]

theorem envBound14755 : H12AffineFastState.Bounded env14755 := by
  intro p hp
  have h : env14755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14754_14755 : H12AffineEnvironment.transform 29 4270863 env14754 = env14755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4270863 env14754 == env14755) = true)

theorem identity14755 : scanCanonicalize (H12AffineFastState.compose env14755 (packedSelected [1,8,19] rootPS)) = affineNative (2^(14+1) ^^^ 513) := by decide +kernel

theorem selectedBound14755 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env14756 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1297,513,65536,1296,513,1025,512,1296,4194304,17,66308,8328,17,4203137,1296,1297,4270863,1284,4294967296,256,4299228078,9364,512]

theorem envBound14756 : H12AffineFastState.Bounded env14756 := by
  intro p hp
  have h : env14756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14755_14756 : H12AffineEnvironment.transform 14 513 env14755 = env14756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 513 env14755 == env14756) = true)

theorem identity14756 : scanCanonicalize (H12AffineFastState.compose env14756 (packedSelected [1,5,12] rootPS)) = affineNative (2^(21+1) ^^^ 10503) := by decide +kernel

theorem selectedBound14756 : packedSelected [1,5,12] rootPS < 2^1333 := by decide +kernel

def env14757 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1297,513,65536,1296,513,1025,512,1296,10503,17,66308,8328,17,2950,1296,1297,66056,1284,4294967296,256,4295043753,9364,512]

theorem envBound14757 : H12AffineFastState.Bounded env14757 := by
  intro p hp
  have h : env14757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14756_14757 : H12AffineEnvironment.transform 21 10503 env14756 = env14757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10503 env14756 == env14757) = true)

theorem identity14757 : scanCanonicalize (H12AffineFastState.compose env14757 (packedSelected [0,7,20] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound14757 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env14758 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,389,1297,513,65536,1296,513,1025,512,1296,2178,17,66308,269,17,2950,1296,1297,66056,1284,4294967296,256,4295035692,1297,512]

theorem envBound14758 : H12AffineFastState.Bounded env14758 := by
  intro p hp
  have h : env14758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14757_14758 : H12AffineEnvironment.transform 12 389 env14757 = env14758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env14757 == env14758) = true)

theorem identity14758 : scanCanonicalize (H12AffineFastState.compose env14758 (packedSelected [1,3,5] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound14758 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env14759 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,389,1297,513,262,1296,513,1025,512,1296,2178,17,514,269,17,2950,1296,1297,782,1284,4294967296,256,4294969898,1297,512]

theorem envBound14759 : H12AffineFastState.Bounded env14759 := by
  intro p hp
  have h : env14759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14758_14759 : H12AffineEnvironment.transform 15 262 env14758 = env14759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env14758 == env14759) = true)

theorem identity14759 : scanCanonicalize (H12AffineFastState.compose env14759 (packedSelected [1,3,8] rootPS)) = affineNative (2^(10+1) ^^^ 429) := by decide +kernel

theorem selectedBound14759 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env14760 : List Nat := [2,4,8,16,32,17,128,256,512,1024,429,1296,389,1297,513,262,1296,513,1025,512,1296,303,17,514,269,17,555,1296,1297,782,1284,4294967296,256,4294968199,1297,512]

theorem envBound14760 : H12AffineFastState.Bounded env14760 := by
  intro p hp
  have h : env14760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14759_14760 : H12AffineEnvironment.transform 10 429 env14759 = env14760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 429 env14759 == env14760) = true)

theorem identity14760 : scanCanonicalize (H12AffineFastState.compose env14760 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 163) := by decide +kernel

theorem selectedBound14760 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14761 : List Nat := [2,4,8,16,32,17,128,256,163,1024,429,1296,389,1297,162,262,1296,162,1025,163,1296,303,17,161,269,17,136,1296,1297,429,1284,4294967296,256,4294967588,1297,163]

theorem envBound14761 : H12AffineFastState.Bounded env14761 := by
  intro p hp
  have h : env14761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14760_14761 : H12AffineEnvironment.transform 8 163 env14760 = env14761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 163 env14760 == env14761) = true)

def env14762 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,65536,1345,513,1105,32769,1345,4194304,64,98565,8328,65,134217728,1345,1296,1073741824,1284,4294967296,256,4299260335,138413588,512]

theorem envBound14762 : H12AffineFastState.Bounded env14762 := by
  intro p hp
  have h : env14762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14681_14762 : H12AffineEnvironment.transform 18 1105 env14681 = env14762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1105 env14681 == env14762) = true)

theorem identity14762 : scanCanonicalize (H12AffineFastState.compose env14762 (packedSelected [3,5,24] rootPS)) = affineNative (2^(26+1) ^^^ 66137) := by decide +kernel

theorem selectedBound14762 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env14763 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,65536,1345,513,1105,32769,1345,4194304,64,98565,8328,65,66137,1345,1296,1073741824,1284,4294967296,256,4299260335,4260941,512]

theorem envBound14763 : H12AffineFastState.Bounded env14763 := by
  intro p hp
  have h : env14763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14762_14763 : H12AffineEnvironment.transform 26 66137 env14762 = env14763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 66137 env14762 == env14763) = true)

def env14764 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1296,32768,65536,1297,513,1025,32769,1297,4194304,16,98565,8328,17,66057,1297,1296,1073741824,1284,4294967296,256,4299260335,4260893,512]

theorem envBound14764 : H12AffineFastState.Bounded env14764 := by
  intro p hp
  have h : env14764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14763_14764 : H12AffineEnvironment.transform 5 16 env14763 = env14764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env14763 == env14764) = true)

theorem identity14764 : scanCanonicalize (H12AffineFastState.compose env14764 (packedSelected [3,5,10] rootPS)) = affineNative (2^(29+1) ^^^ 2988) := by decide +kernel

theorem selectedBound14764 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env14765 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1296,32768,65536,1297,513,1025,32769,1297,4194304,16,98565,8328,17,66057,1297,1296,2988,1284,4294967296,256,4299260335,4260893,512]

theorem envBound14765 : H12AffineFastState.Bounded env14765 := by
  intro p hp
  have h : env14765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14764_14765 : H12AffineEnvironment.transform 29 2988 env14764 = env14765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 2988 env14764 == env14765) = true)

theorem identity14765 : scanCanonicalize (H12AffineFastState.compose env14765 (packedSelected [1,8,19] rootPS)) = affineNative (2^(14+1) ^^^ 554) := by decide +kernel

theorem selectedBound14765 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env14766 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1296,554,65536,1297,513,1025,555,1297,4194304,16,66351,8328,17,66057,1297,1296,2988,1284,4294967296,256,4299228037,4260893,512]

theorem envBound14766 : H12AffineFastState.Bounded env14766 := by
  intro p hp
  have h : env14766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14765_14766 : H12AffineEnvironment.transform 14 554 env14765 = env14766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 554 env14765 == env14766) = true)

theorem identity14766 : scanCanonicalize (H12AffineFastState.compose env14766 (packedSelected [0,7,20] rootPS)) = affineNative (2^(21+1) ^^^ 65805) := by decide +kernel

theorem selectedBound14766 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env14767 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1296,554,65536,1297,513,1025,555,1297,65805,16,66351,8328,17,66057,1297,1296,2988,1284,4294967296,256,4294967944,1296,512]

theorem envBound14767 : H12AffineFastState.Bounded env14767 := by
  intro p hp
  have h : env14767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14766_14767 : H12AffineEnvironment.transform 21 65805 env14766 = env14767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 65805 env14766 == env14767) = true)

theorem identity14767 : scanCanonicalize (H12AffineFastState.compose env14767 (packedSelected [1,3,5] rootPS)) = affineNative (2^(15+1) ^^^ 8714) := by decide +kernel

theorem selectedBound14767 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env14768 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1296,554,8714,1297,513,1025,555,1297,8967,16,8485,8328,17,8195,1297,1296,2988,1284,4294967296,256,4294967944,1296,512]

theorem envBound14768 : H12AffineFastState.Bounded env14768 := by
  intro p hp
  have h : env14768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14767_14768 : H12AffineEnvironment.transform 15 8714 env14767 = env14768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8714 env14767 == env14768) = true)

theorem identity14768 : scanCanonicalize (H12AffineFastState.compose env14768 (packedSelected [1,3,8] rootPS)) = affineNative (2^(12+1) ^^^ 2051) := by decide +kernel

theorem selectedBound14768 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env14769 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,2051,1296,554,2569,1297,513,1025,555,1297,2820,16,2342,2187,17,2048,1297,1296,2988,1284,4294967296,256,4294967944,1296,512]

theorem envBound14769 : H12AffineFastState.Bounded env14769 := by
  intro p hp
  have h : env14769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14768_14769 : H12AffineEnvironment.transform 12 2051 env14768 = env14769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2051 env14768 == env14769) = true)

theorem identity14769 : scanCanonicalize (H12AffineFastState.compose env14769 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 783) := by decide +kernel

theorem selectedBound14769 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14770 : List Nat := [2,4,8,16,32,16,128,256,512,1024,783,1297,780,1296,554,262,1297,513,1025,555,1297,11,16,553,900,17,783,1297,1296,163,1284,4294967296,256,4294967944,1296,512]

theorem envBound14770 : H12AffineFastState.Bounded env14770 := by
  intro p hp
  have h : env14770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14769_14770 : H12AffineEnvironment.transform 10 783 env14769 = env14770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 783 env14769 == env14770) = true)

theorem identity14770 : scanCanonicalize (H12AffineFastState.compose env14770 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 162) := by decide +kernel

theorem selectedBound14770 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env14771 : List Nat := [2,4,8,16,32,16,128,256,162,1024,429,1297,430,1296,136,262,1297,163,1025,137,1297,11,16,139,294,17,429,1297,1296,163,1284,4294967296,256,4294967338,1296,162]

theorem envBound14771 : H12AffineFastState.Bounded env14771 := by
  intro p hp
  have h : env14771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14770_14771 : H12AffineEnvironment.transform 8 162 env14770 = env14771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 162 env14770 == env14771) = true)

theorem identity14771 : scanCanonicalize (H12AffineFastState.compose env14771 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 185) := by decide +kernel

theorem selectedBound14771 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14772 : List Nat := [2,4,8,16,32,16,128,256,162,1024,429,1297,430,1296,136,262,1297,163,1025,137,1297,11,16,139,294,17,429,1297,1296,163,1284,185,256,147,1296,162]

theorem envBound14772 : H12AffineFastState.Bounded env14772 := by
  intro p hp
  have h : env14772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14771_14772 : H12AffineEnvironment.transform 31 185 env14771 = env14772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 185 env14771 == env14772) = true)

theorem identity14772 : scanCanonicalize (H12AffineFastState.compose env14772 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound14772 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env14773 : List Nat := [2,4,8,16,10,16,128,256,136,1024,391,1297,388,1296,136,262,1297,137,1025,137,1297,11,16,139,268,17,391,1297,1296,137,1284,147,256,147,1296,136]

theorem envBound14773 : H12AffineFastState.Bounded env14773 := by
  intro p hp
  have h : env14773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14772_14773 : H12AffineEnvironment.transform 4 10 env14772 = env14773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env14772 == env14773) = true)

theorem identity14773 : scanCanonicalize (H12AffineFastState.compose env14773 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound14773 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14774 : List Nat := [2,4,8,16,10,16,128,15,136,1024,136,1054,139,1055,136,9,1054,137,1025,137,1054,11,16,139,3,17,136,1054,1055,137,1035,147,15,147,1055,136]

theorem envBound14774 : H12AffineFastState.Bounded env14774 := by
  intro p hp
  have h : env14774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14773_14774 : H12AffineEnvironment.transform 7 15 env14773 = env14774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env14773 == env14774) = true)

theorem identity14774 : scanCanonicalize (H12AffineFastState.compose env14774 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound14774 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env14775 : List Nat := [2,4,8,16,10,16,18,15,26,1024,26,1054,25,1055,26,9,1054,27,1025,27,1054,11,16,25,3,17,26,1054,1055,27,1035,1,15,1,1055,26]

theorem envBound14775 : H12AffineFastState.Bounded env14775 := by
  intro p hp
  have h : env14775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14774_14775 : H12AffineEnvironment.transform 6 18 env14774 = env14775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env14774 == env14775) = true)

def env14776 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1297,32768,65536,1296,513,1024,32769,1296,4194304,17,98565,8328,16,66056,1296,1296,1073741824,1284,4294967296,256,4299260335,4260892,512]

theorem envBound14776 : H12AffineFastState.Bounded env14776 := by
  intro p hp
  have h : env14776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14763_14776 : H12AffineEnvironment.transform 5 17 env14763 = env14776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env14763 == env14776) = true)

theorem identity14776 : scanCanonicalize (H12AffineFastState.compose env14776 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 73891) := by decide +kernel

theorem selectedBound14776 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env14777 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1297,32768,65536,1296,513,1024,32769,1296,73891,17,98565,8328,16,66056,1296,1296,1073741824,1284,4294967296,256,4295008524,9407,512]

theorem envBound14777 : H12AffineFastState.Bounded env14777 := by
  intro p hp
  have h : env14777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14776_14777 : H12AffineEnvironment.transform 21 73891 env14776 = env14777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73891 env14776 == env14777) = true)

theorem identity14777 : scanCanonicalize (H12AffineFastState.compose env14777 (packedSelected [3,5,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 430) := by decide +kernel

theorem selectedBound14777 : packedSelected [3,5,8,28] rootPS < 2^1333 := by decide +kernel

def env14778 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,430,1297,32768,65536,1296,513,1024,32769,1296,65805,17,98565,294,16,66056,1296,1296,1073741824,1284,4294967296,256,4295000226,1297,512]

theorem envBound14778 : H12AffineFastState.Bounded env14778 := by
  intro p hp
  have h : env14778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14777_14778 : H12AffineEnvironment.transform 12 430 env14777 = env14778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 430 env14777 == env14778) = true)

theorem identity14778 : scanCanonicalize (H12AffineFastState.compose env14778 (packedSelected [1,3,5] rootPS)) = affineNative (2^(14+1) ^^^ 163) := by decide +kernel

theorem selectedBound14778 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env14779 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,430,1297,163,65536,1296,513,1024,162,1296,65805,17,65958,294,16,66056,1296,1296,1073741824,1284,4294967296,256,4294967297,1297,512]

theorem envBound14779 : H12AffineFastState.Bounded env14779 := by
  intro p hp
  have h : env14779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14778_14779 : H12AffineEnvironment.transform 14 163 env14778 = env14779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 163 env14778 == env14779) = true)

theorem identity14779 : scanCanonicalize (H12AffineFastState.compose env14779 (packedSelected [1,12,13] rootPS)) = affineNative (2^(10+1) ^^^ 804) := by decide +kernel

theorem selectedBound14779 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env14780 : List Nat := [2,4,8,16,32,17,128,256,512,1024,804,1296,430,1297,163,65536,1296,513,1024,162,1296,65805,17,65958,294,16,66056,1296,1296,1073741824,1284,4294967296,256,4294967297,1297,512]

theorem envBound14780 : H12AffineFastState.Bounded env14780 := by
  intro p hp
  have h : env14780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14779_14780 : H12AffineEnvironment.transform 10 804 env14779 = env14780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 804 env14779 == env14780) = true)

theorem identity14780 : scanCanonicalize (H12AffineFastState.compose env14780 (packedSelected [1,3,12] rootPS)) = affineNative (2^(29+1) ^^^ 67132) := by decide +kernel

theorem selectedBound14780 : packedSelected [1,3,12] rootPS < 2^1333 := by decide +kernel

def env14781 : List Nat := [2,4,8,16,32,17,128,256,512,1024,804,1296,430,1297,163,65536,1296,513,1024,162,1296,65805,17,65958,294,16,66056,1296,1296,67132,1284,4294967296,256,4294967297,1297,512]

theorem envBound14781 : H12AffineFastState.Bounded env14781 := by
  intro p hp
  have h : env14781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14780_14781 : H12AffineEnvironment.transform 29 67132 env14780 = env14781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 67132 env14780 == env14781) = true)

theorem identity14781 : scanCanonicalize (H12AffineFastState.compose env14781 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound14781 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env14782 : List Nat := [2,4,8,16,32,17,128,256,512,273,804,1,430,0,163,65536,1,513,273,162,1,65805,17,65958,294,16,66056,1,1,66349,21,4294967296,256,4294967297,0,512]

theorem envBound14782 : H12AffineFastState.Bounded env14782 := by
  intro p hp
  have h : env14782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14781_14782 : H12AffineEnvironment.transform 9 273 env14781 = env14782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env14781 == env14782) = true)

theorem identity14782 : scanCanonicalize (H12AffineFastState.compose env14782 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 300) := by decide +kernel

theorem selectedBound14782 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14783 : List Nat := [2,4,8,16,32,17,128,256,512,273,804,1,430,0,163,300,1,513,273,162,1,33,17,138,294,16,804,1,1,513,21,4294967296,256,4294967297,0,512]

theorem envBound14783 : H12AffineFastState.Bounded env14783 := by
  intro p hp
  have h : env14783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14782_14783 : H12AffineEnvironment.transform 15 300 env14782 = env14783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 300 env14782 == env14783) = true)

theorem identity14783 : scanCanonicalize (H12AffineFastState.compose env14783 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound14783 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14784 : List Nat := [2,4,8,16,32,17,128,256,137,273,429,1,430,0,163,300,1,136,273,162,1,33,17,138,294,16,429,1,1,136,21,4294967296,256,4294967297,0,137]

theorem envBound14784 : H12AffineFastState.Bounded env14784 := by
  intro p hp
  have h : env14784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14783_14784 : H12AffineEnvironment.transform 8 137 env14783 = env14784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env14783 == env14784) = true)

theorem identity14784 : scanCanonicalize (H12AffineFastState.compose env14784 (packedSelected [0,4] rootPS)) = affineNative (2^(31+1) ^^^ 422) := by decide +kernel

theorem selectedBound14784 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env14785 : List Nat := [2,4,8,16,32,17,128,256,137,273,429,1,430,0,163,300,1,136,273,162,1,33,17,138,294,16,429,1,1,136,21,422,256,423,0,137]

theorem envBound14785 : H12AffineFastState.Bounded env14785 := by
  intro p hp
  have h : env14785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14784_14785 : H12AffineEnvironment.transform 31 422 env14784 = env14785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 422 env14784 == env14785) = true)

theorem identity14785 : scanCanonicalize (H12AffineFastState.compose env14785 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound14785 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env14786 : List Nat := [2,4,8,16,32,17,128,173,137,188,0,1,3,0,163,129,1,136,188,162,1,33,17,138,139,16,0,1,1,136,21,11,173,10,0,137]

theorem envBound14786 : H12AffineFastState.Bounded env14786 := by
  intro p hp
  have h : env14786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14785_14786 : H12AffineEnvironment.transform 7 173 env14785 = env14786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env14785 == env14786) = true)

theorem identity14786 : scanCanonicalize (H12AffineFastState.compose env14786 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound14786 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env14787 : List Nat := [2,4,8,16,32,17,9,36,0,53,0,1,3,0,42,8,1,1,53,43,1,33,17,3,2,16,0,1,1,1,21,11,36,10,0,0]

theorem envBound14787 : H12AffineFastState.Bounded env14787 := by
  intro p hp
  have h : env14787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14786_14787 : H12AffineEnvironment.transform 6 9 env14786 = env14787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14786 == env14787) = true)

theorem identity14787 : scanCanonicalize (H12AffineFastState.compose env14787 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound14787 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14788 : List Nat := [2,4,8,0,32,1,9,36,0,37,0,1,3,0,42,8,1,1,37,43,1,33,1,3,2,0,0,1,1,1,5,11,36,10,0,0]

theorem envBound14788 : H12AffineFastState.Bounded env14788 := by
  intro p hp
  have h : env14788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14787_14788 : H12AffineEnvironment.transform 3 0 env14787 = env14788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env14787 == env14788) = true)

def env14789 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,32768,65536,1345,262144,524288,32769,1345,4194304,65,98565,8328,525329,134217728,1344,524608,1073741824,1284,4294967296,256,4299260335,139198532,512]

theorem envBound14789 : H12AffineFastState.Bounded env14789 := by
  intro p hp
  have h : env14789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14563_14789 : H12AffineEnvironment.transform 13 1345 env14563 = env14789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env14563 == env14789) = true)

theorem identity14789 : scanCanonicalize (H12AffineFastState.compose env14789 (packedSelected [9,22] rootPS)) = affineNative (2^(18+1) ^^^ 1105) := by decide +kernel

theorem selectedBound14789 : packedSelected [9,22] rootPS < 2^1333 := by decide +kernel

def env14790 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,32768,65536,1345,262144,1105,32769,1345,4194304,65,98565,8328,64,134217728,1344,1297,1073741824,1284,4294967296,256,4299260335,138675221,512]

theorem envBound14790 : H12AffineFastState.Bounded env14790 := by
  intro p hp
  have h : env14790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14789_14790 : H12AffineEnvironment.transform 18 1105 env14789 = env14790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1105 env14789 == env14790) = true)

def env14791 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,32768,65536,1345,512,1105,32769,1345,4194304,65,98565,8328,64,134217728,1344,1297,1073741824,1284,4294967296,256,4299260335,138413589,512]

theorem envBound14791 : H12AffineFastState.Bounded env14791 := by
  intro p hp
  have h : env14791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14790_14791 : H12AffineEnvironment.transform 17 512 env14790 = env14791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 512 env14790 == env14791) = true)

theorem identity14791 : scanCanonicalize (H12AffineFastState.compose env14791 (packedSelected [3,5,24] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound14791 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env14792 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,388,1345,32768,65536,1345,512,1105,32769,1345,4194304,65,98565,268,64,134217728,1344,1297,1073741824,1284,4294967296,256,4299260335,138413589,512]

theorem envBound14792 : H12AffineFastState.Bounded env14792 := by
  intro p hp
  have h : env14792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14791_14792 : H12AffineEnvironment.transform 12 388 env14791 = env14792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env14791 == env14792) = true)

def env14793 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,388,1297,32768,65536,1297,512,1025,32769,1297,4194304,17,98565,268,16,134217728,1296,1297,1073741824,1284,4294967296,256,4299260335,138413589,512]

theorem envBound14793 : H12AffineFastState.Bounded env14793 := by
  intro p hp
  have h : env14793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14792_14793 : H12AffineEnvironment.transform 5 16 env14792 = env14793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env14792 == env14793) = true)

theorem identity14793 : scanCanonicalize (H12AffineFastState.compose env14793 (packedSelected [3,5,10] rootPS)) = affineNative (2^(29+1) ^^^ 4262539) := by decide +kernel

theorem selectedBound14793 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env14794 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,388,1297,32768,65536,1297,512,1025,32769,1297,4194304,17,98565,268,16,134217728,1296,1297,4262539,1284,4294967296,256,4299260335,138413589,512]

theorem envBound14794 : H12AffineFastState.Bounded env14794 := by
  intro p hp
  have h : env14794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14793_14794 : H12AffineEnvironment.transform 29 4262539 env14793 = env14794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4262539 env14793 == env14794) = true)

theorem identity14794 : scanCanonicalize (H12AffineFastState.compose env14794 (packedSelected [1,8,19] rootPS)) = affineNative (2^(26+1) ^^^ 4227333) := by decide +kernel

theorem selectedBound14794 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env14795 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,388,1297,32768,65536,1297,512,1025,32769,1297,4194304,17,98565,268,16,4227333,1296,1297,4262539,1284,4294967296,256,4299260335,34576,512]

theorem envBound14795 : H12AffineFastState.Bounded env14795 := by
  intro p hp
  have h : env14795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14794_14795 : H12AffineEnvironment.transform 26 4227333 env14794 = env14795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 4227333 env14794 == env14795) = true)

theorem identity14795 : scanCanonicalize (H12AffineFastState.compose env14795 (packedSelected [1,5,12] rootPS)) = affineNative (2^(15+1) ^^^ 2688) := by decide +kernel

theorem selectedBound14795 : packedSelected [1,5,12] rootPS < 2^1333 := by decide +kernel

def env14796 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,388,1297,32768,2688,1297,512,1025,32769,1297,4194304,17,35717,268,16,4227333,1296,1297,4194315,1284,4294967296,256,4299197231,34576,512]

theorem envBound14796 : H12AffineFastState.Bounded env14796 := by
  intro p hp
  have h : env14796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14795_14796 : H12AffineEnvironment.transform 15 2688 env14795 = env14796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2688 env14795 == env14796) = true)

theorem identity14796 : scanCanonicalize (H12AffineFastState.compose env14796 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 512) := by decide +kernel

theorem selectedBound14796 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env14797 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,388,1297,512,2688,1297,512,1025,513,1297,4194304,17,2437,268,16,4195077,1296,1297,4194315,1284,4294967296,256,4299163951,1296,512]

theorem envBound14797 : H12AffineFastState.Bounded env14797 := by
  intro p hp
  have h : env14797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14796_14797 : H12AffineEnvironment.transform 14 512 env14796 = env14797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 512 env14796 == env14797) = true)

theorem identity14797 : scanCanonicalize (H12AffineFastState.compose env14797 (packedSelected [1,3,5] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound14797 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env14798 : List Nat := [2,4,8,16,32,16,128,256,43,1024,2048,1297,388,1297,43,2219,1297,43,1025,42,1297,4194304,17,2437,268,16,4194606,1296,1297,4194315,1284,4294967296,256,4299163951,1296,43]

theorem envBound14798 : H12AffineFastState.Bounded env14798 := by
  intro p hp
  have h : env14798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14797_14798 : H12AffineEnvironment.transform 8 43 env14797 = env14798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env14797 == env14798) = true)

theorem identity14798 : scanCanonicalize (H12AffineFastState.compose env14798 (packedSelected [1,3,8] rootPS)) = affineNative (2^(10+1) ^^^ 270) := by decide +kernel

theorem selectedBound14798 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env14799 : List Nat := [2,4,8,16,32,16,128,256,43,1024,270,1297,388,1297,43,421,1297,43,1025,42,1297,4194304,17,139,268,16,4194606,1296,1297,4194315,1284,4294967296,256,4299161633,1296,43]

theorem envBound14799 : H12AffineFastState.Bounded env14799 := by
  intro p hp
  have h : env14799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14798_14799 : H12AffineEnvironment.transform 10 270 env14798 = env14799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 270 env14798 == env14799) = true)

theorem identity14799 : scanCanonicalize (H12AffineFastState.compose env14799 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 134) := by decide +kernel

theorem selectedBound14799 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env14800 : List Nat := [2,4,8,16,32,16,128,134,43,1024,136,1175,2,1175,43,35,1175,43,1025,42,1175,4194304,17,139,138,16,4194472,1174,1175,4194315,1154,4294967296,134,4299161633,1174,43]

theorem envBound14800 : H12AffineFastState.Bounded env14800 := by
  intro p hp
  have h : env14800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14799_14800 : H12AffineEnvironment.transform 7 134 env14799 = env14800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 134 env14799 == env14800) = true)

theorem identity14800 : scanCanonicalize (H12AffineFastState.compose env14800 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 42) := by decide +kernel

theorem selectedBound14800 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14801 : List Nat := [2,4,8,16,32,16,128,134,43,1024,136,1175,2,1175,43,35,1175,43,1025,42,1175,4194304,17,139,138,16,4194472,1174,1175,4194315,1154,42,134,4194315,1174,43]

theorem envBound14801 : H12AffineFastState.Bounded env14801 := by
  intro p hp
  have h : env14801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14800_14801 : H12AffineEnvironment.transform 31 42 env14800 = env14801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 42 env14800 == env14801) = true)

theorem identity14801 : scanCanonicalize (H12AffineFastState.compose env14801 (packedSelected [2,4,7] rootPS)) = affineNative (2^(21+1) ^^^ 131) := by decide +kernel

theorem selectedBound14801 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env14802 : List Nat := [2,4,8,16,32,16,128,134,43,1024,136,1175,2,1175,43,35,1175,43,1025,42,1175,131,17,139,138,16,43,1174,1175,136,1154,42,134,136,1174,43]

theorem envBound14802 : H12AffineFastState.Bounded env14802 := by
  intro p hp
  have h : env14802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14801_14802 : H12AffineEnvironment.transform 21 131 env14801 = env14802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 131 env14801 == env14802) = true)

theorem identity14802 : scanCanonicalize (H12AffineFastState.compose env14802 (packedSelected [2,4] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound14802 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env14803 : List Nat := [2,4,8,16,32,16,35,37,43,1024,43,1076,2,1076,43,35,1076,43,1025,42,1076,32,17,40,41,16,43,1077,1076,43,1057,42,37,43,1077,43]

theorem envBound14803 : H12AffineFastState.Bounded env14803 := by
  intro p hp
  have h : env14803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14802_14803 : H12AffineEnvironment.transform 6 35 env14802 = env14803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env14802 == env14803) = true)

theorem identity14803 : scanCanonicalize (H12AffineFastState.compose env14803 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound14803 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14804 : List Nat := [2,4,8,16,32,16,35,37,43,52,43,0,2,0,43,35,0,43,53,42,0,32,17,40,41,16,43,1,0,43,21,42,37,43,1,43]

theorem envBound14804 : H12AffineFastState.Bounded env14804 := by
  intro p hp
  have h : env14804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14803_14804 : H12AffineEnvironment.transform 9 52 env14803 = env14804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env14803 == env14804) = true)

theorem identity14804 : scanCanonicalize (H12AffineFastState.compose env14804 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound14804 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14805 : List Nat := [2,4,8,16,27,16,24,30,16,15,16,0,2,0,16,24,0,16,14,17,0,27,17,19,18,16,16,1,0,16,21,17,30,16,1,16]

theorem envBound14805 : H12AffineFastState.Bounded env14805 := by
  intro p hp
  have h : env14805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14804_14805 : H12AffineEnvironment.transform 4 27 env14804 = env14805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env14804 == env14805) = true)

theorem identity14805 : scanCanonicalize (H12AffineFastState.compose env14805 (packedSelected [6] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound14805 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env14806 : List Nat := [2,4,8,0,11,0,8,14,0,15,0,0,2,0,0,8,0,0,14,1,0,11,1,3,2,0,0,1,0,0,5,1,14,0,1,0]

theorem envBound14806 : H12AffineFastState.Bounded env14806 := by
  intro p hp
  have h : env14806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14805_14806 : H12AffineEnvironment.transform 3 0 env14805 = env14806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env14805 == env14806) = true)

def env14807 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,388,1296,32768,65536,1296,512,1024,32769,1296,4194304,16,98565,268,17,134217728,1297,1297,1073741824,1284,4294967296,256,4299260335,138413589,512]

theorem envBound14807 : H12AffineFastState.Bounded env14807 := by
  intro p hp
  have h : env14807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14792_14807 : H12AffineEnvironment.transform 5 17 env14792 = env14807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env14792 == env14807) = true)

theorem identity14807 : scanCanonicalize (H12AffineFastState.compose env14807 (packedSelected [3,5,8,28] rootPS)) = affineNative (2^(29+1) ^^^ 134283299) := by decide +kernel

theorem selectedBound14807 : packedSelected [3,5,8,28] rootPS < 2^1333 := by decide +kernel

def env14808 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,388,1296,32768,65536,1296,512,1024,32769,1296,4194304,16,98565,268,17,134217728,1297,1297,134283299,1284,4294967296,256,4299260335,138413589,512]

theorem envBound14808 : H12AffineFastState.Bounded env14808 := by
  intro p hp
  have h : env14808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14807_14808 : H12AffineEnvironment.transform 29 134283299 env14807 = env14808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 134283299 env14807 == env14808) = true)

theorem identity14808 : scanCanonicalize (H12AffineFastState.compose env14808 (packedSelected [1,3,8,15,17,21,38] rootPS)) = affineNative (2^(26+1) ^^^ 4195076) := by decide +kernel

theorem selectedBound14808 : packedSelected [1,3,8,15,17,21,38] rootPS < 2^1333 := by decide +kernel

def env14809 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,388,1296,32768,65536,1296,512,1024,32769,1296,4194304,16,98565,268,17,4195076,1297,1297,4260647,1284,4294967296,256,4299260335,1297,512]

theorem envBound14809 : H12AffineFastState.Bounded env14809 := by
  intro p hp
  have h : env14809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14808_14809 : H12AffineEnvironment.transform 26 4195076 env14808 = env14809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 4195076 env14808 == env14809) = true)

theorem identity14809 : scanCanonicalize (H12AffineFastState.compose env14809 (packedSelected [1] rootPS)) = affineNative (2^(14+1) ^^^ 940) := by decide +kernel

theorem selectedBound14809 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14810 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,388,1296,940,65536,1296,512,1024,941,1296,4194304,16,66217,268,17,4195076,1297,1297,4260647,1284,4294967296,256,4299227651,1297,512]

theorem envBound14810 : H12AffineFastState.Bounded env14810 := by
  intro p hp
  have h : env14810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14809_14810 : H12AffineEnvironment.transform 14 940 env14809 = env14810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 940 env14809 == env14810) = true)

theorem identity14810 : scanCanonicalize (H12AffineFastState.compose env14810 (packedSelected [3,8] rootPS)) = affineNative (2^(15+1) ^^^ 2595) := by decide +kernel

theorem selectedBound14810 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env14811 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,388,1296,940,2595,1296,512,1024,941,1296,4194304,16,2186,268,17,4195076,1297,1297,4196612,1284,4294967296,256,4299163680,1297,512]

theorem envBound14811 : H12AffineFastState.Bounded env14811 := by
  intro p hp
  have h : env14811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14810_14811 : H12AffineEnvironment.transform 15 2595 env14810 = env14811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2595 env14810 == env14811) = true)

theorem identity14811 : scanCanonicalize (H12AffineFastState.compose env14811 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound14811 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env14812 : List Nat := [2,4,8,16,32,17,128,256,512,1024,513,1296,388,1296,940,34,1296,512,1024,941,1296,4194304,16,651,268,17,4195076,1297,1297,4195077,1284,4294967296,256,4299162145,1297,512]

theorem envBound14812 : H12AffineFastState.Bounded env14812 := by
  intro p hp
  have h : env14812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14811_14812 : H12AffineEnvironment.transform 10 513 env14811 = env14812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env14811 == env14812) = true)

theorem identity14812 : scanCanonicalize (H12AffineFastState.compose env14812 (packedSelected [0,7] rootPS)) = affineNative (2^(21+1) ^^^ 773) := by decide +kernel

theorem selectedBound14812 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env14813 : List Nat := [2,4,8,16,32,17,128,256,512,1024,513,1296,388,1296,940,34,1296,512,1024,941,1296,773,16,651,268,17,1,1297,1297,0,1284,4294967296,256,4294967588,1297,512]

theorem envBound14813 : H12AffineFastState.Bounded env14813 := by
  intro p hp
  have h : env14813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14812_14813 : H12AffineEnvironment.transform 21 773 env14812 = env14813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 773 env14812 == env14813) = true)

theorem identity14813 : scanCanonicalize (H12AffineFastState.compose env14813 (packedSelected [4,9] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound14813 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env14814 : List Nat := [2,4,8,16,32,17,128,256,0,1024,1,1296,388,1296,428,34,1296,0,1024,429,1296,261,16,139,268,17,1,1297,1297,0,1284,4294967296,256,4294967588,1297,0]

theorem envBound14814 : H12AffineFastState.Bounded env14814 := by
  intro p hp
  have h : env14814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14813_14814 : H12AffineEnvironment.transform 8 0 env14813 = env14814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env14813 == env14814) = true)

theorem identity14814 : scanCanonicalize (H12AffineFastState.compose env14814 (packedSelected [2,4] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound14814 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env14815 : List Nat := [2,4,8,16,32,17,8,256,0,1024,1,1296,268,1296,292,34,1296,0,1024,293,1296,261,16,3,268,17,1,1297,1297,0,1284,4294967296,256,4294967588,1297,0]

theorem envBound14815 : H12AffineFastState.Bounded env14815 := by
  intro p hp
  have h : env14815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14814_14815 : H12AffineEnvironment.transform 6 8 env14814 = env14815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14814 == env14815) = true)

theorem identity14815 : scanCanonicalize (H12AffineFastState.compose env14815 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 0) := by decide +kernel

theorem selectedBound14815 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14816 : List Nat := [2,4,8,16,32,17,8,256,0,1024,1,1296,268,1296,292,34,1296,0,1024,293,1296,261,16,3,268,17,1,1297,1297,0,1284,0,256,292,1297,0]

theorem envBound14816 : H12AffineFastState.Bounded env14816 := by
  intro p hp
  have h : env14816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14815_14816 : H12AffineEnvironment.transform 31 0 env14815 = env14816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 0 env14815 == env14816) = true)

def env14817 : List Nat := [2,4,8,16,0,17,8,256,0,1024,1,1296,268,1296,260,2,1296,0,1024,261,1296,261,16,3,268,17,1,1297,1297,0,1284,0,256,260,1297,0]

theorem envBound14817 : H12AffineFastState.Bounded env14817 := by
  intro p hp
  have h : env14817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14816_14817 : H12AffineEnvironment.transform 4 0 env14816 = env14817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14816 == env14817) = true)

theorem identity14817 : scanCanonicalize (H12AffineFastState.compose env14817 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound14817 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14818 : List Nat := [2,4,8,16,0,17,8,4,0,1024,1,1044,8,1044,0,2,1044,0,1024,1,1044,1,16,3,8,17,1,1045,1045,0,1024,0,4,0,1045,0]

theorem envBound14818 : H12AffineFastState.Bounded env14818 := by
  intro p hp
  have h : env14818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14817_14818 : H12AffineEnvironment.transform 7 4 env14817 = env14818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env14817 == env14818) = true)

def leafEnv14818 : List Nat := [2,4,8,16,0,17,8,4,0,1024,1,1044,8,1044,0,2,1044,0,1024,1,1044,1,16,3,1024,8,1,17,1,1045,1045,0,1024,0,4,0,4,3,1045,0,0,1045,1]

def active14818 : List Nat := [0,1,2,3,9]

def tree14818 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14818 : H12WitnessSearch.Good tree14818 := H12GlobalWitnessIndex.good

theorem leafIdentity14818 : H12AffineFastState.composeSystem env14818 rootObs = leafEnv14818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14818 rootObs == leafEnv14818) = true)

theorem terminalChecked14818 : H12PackedTerminal.terminalCheckFast leafEnv14818 active14818 tree14818 = true := by decide +kernel

def env14819 : List Nat := [2,4,8,16,1,17,8,256,0,1024,1,1296,268,1296,261,3,1296,0,1024,260,1296,261,16,3,268,17,1,1297,1297,0,1284,0,256,261,1297,0]

theorem envBound14819 : H12AffineFastState.Bounded env14819 := by
  intro p hp
  have h : env14819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14816_14819 : H12AffineEnvironment.transform 4 1 env14816 = env14819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14816 == env14819) = true)

def leafEnv14819 : List Nat := [2,4,8,16,1,17,8,256,0,1024,1,1296,268,1296,261,3,1296,0,1024,260,1296,261,16,3,1284,268,1,17,1,1297,1297,0,1284,0,256,261,4,2,1297,0,0,1297,1]

def active14819 : List Nat := [0,1,2,3,7,9]

def tree14819 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14819 : H12WitnessSearch.Good tree14819 := H12GlobalWitnessIndex.good

theorem leafIdentity14819 : H12AffineFastState.composeSystem env14819 rootObs = leafEnv14819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14819 rootObs == leafEnv14819) = true)

theorem terminalChecked14819 : H12PackedTerminal.terminalCheckFast leafEnv14819 active14819 tree14819 = true := by decide +kernel

def env14820 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,32768,65536,1345,513,1105,32769,1345,4194304,65,98565,8328,64,134217728,1344,1297,1073741824,1284,4294967296,256,4299260335,138413588,512]

theorem envBound14820 : H12AffineFastState.Bounded env14820 := by
  intro p hp
  have h : env14820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14790_14820 : H12AffineEnvironment.transform 17 513 env14790 = env14820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 513 env14790 == env14820) = true)

theorem identity14820 : scanCanonicalize (H12AffineFastState.compose env14820 (packedSelected [3,5,24] rootPS)) = affineNative (2^(26+1) ^^^ 4203217) := by decide +kernel

theorem selectedBound14820 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env14821 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,32768,65536,1345,513,1105,32769,1345,4194304,65,98565,8328,64,4203217,1344,1297,1073741824,1284,4294967296,256,4299260335,9413,512]

theorem envBound14821 : H12AffineFastState.Bounded env14821 := by
  intro p hp
  have h : env14821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14820_14821 : H12AffineEnvironment.transform 26 4203217 env14820 = env14821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 4203217 env14820 == env14821) = true)

def env14822 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1297,32768,65536,1297,513,1025,32769,1297,4194304,17,98565,8328,16,4203137,1296,1297,1073741824,1284,4294967296,256,4299260335,9365,512]

theorem envBound14822 : H12AffineFastState.Bounded env14822 := by
  intro p hp
  have h : env14822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14821_14822 : H12AffineEnvironment.transform 5 16 env14821 = env14822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env14821 == env14822) = true)

theorem identity14822 : scanCanonicalize (H12AffineFastState.compose env14822 (packedSelected [3,5,10] rootPS)) = affineNative (2^(29+1) ^^^ 4270863) := by decide +kernel

theorem selectedBound14822 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env14823 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1297,32768,65536,1297,513,1025,32769,1297,4194304,17,98565,8328,16,4203137,1296,1297,4270863,1284,4294967296,256,4299260335,9365,512]

theorem envBound14823 : H12AffineFastState.Bounded env14823 := by
  intro p hp
  have h : env14823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14822_14823 : H12AffineEnvironment.transform 29 4270863 env14822 = env14823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4270863 env14822 == env14823) = true)

theorem identity14823 : scanCanonicalize (H12AffineFastState.compose env14823 (packedSelected [1,8,19] rootPS)) = affineNative (2^(14+1) ^^^ 513) := by decide +kernel

theorem selectedBound14823 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env14824 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1297,513,65536,1297,513,1025,512,1297,4194304,17,66308,8328,16,4203137,1296,1297,4270863,1284,4294967296,256,4299228078,9365,512]

theorem envBound14824 : H12AffineFastState.Bounded env14824 := by
  intro p hp
  have h : env14824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14823_14824 : H12AffineEnvironment.transform 14 513 env14823 = env14824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 513 env14823 == env14824) = true)

theorem identity14824 : scanCanonicalize (H12AffineFastState.compose env14824 (packedSelected [1,5,12] rootPS)) = affineNative (2^(15+1) ^^^ 2688) := by decide +kernel

theorem selectedBound14824 : packedSelected [1,5,12] rootPS < 2^1333 := by decide +kernel

def env14825 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1297,513,2688,1297,513,1025,512,1297,4194304,17,2436,8328,16,4203137,1296,1297,4202895,1284,4294967296,256,4299163950,9365,512]

theorem envBound14825 : H12AffineFastState.Bounded env14825 := by
  intro p hp
  have h : env14825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14824_14825 : H12AffineEnvironment.transform 15 2688 env14824 = env14825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2688 env14824 == env14825) = true)

theorem identity14825 : scanCanonicalize (H12AffineFastState.compose env14825 (packedSelected [0,7,20] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound14825 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env14826 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,389,1297,513,2688,1297,513,1025,512,1297,4194304,17,2436,269,16,4195076,1296,1297,4194314,1284,4294967296,256,4299163950,1296,512]

theorem envBound14826 : H12AffineFastState.Bounded env14826 := by
  intro p hp
  have h : env14826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14825_14826 : H12AffineEnvironment.transform 12 389 env14825 = env14826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env14825 == env14826) = true)

theorem identity14826 : scanCanonicalize (H12AffineFastState.compose env14826 (packedSelected [1,3,5] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound14826 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env14827 : List Nat := [2,4,8,16,32,16,128,256,43,1024,2048,1297,389,1297,42,2219,1297,42,1025,43,1297,4194304,17,2436,269,16,4194607,1296,1297,4194314,1284,4294967296,256,4299163950,1296,43]

theorem envBound14827 : H12AffineFastState.Bounded env14827 := by
  intro p hp
  have h : env14827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14826_14827 : H12AffineEnvironment.transform 8 43 env14826 = env14827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env14826 == env14827) = true)

theorem identity14827 : scanCanonicalize (H12AffineFastState.compose env14827 (packedSelected [1,3,8] rootPS)) = affineNative (2^(10+1) ^^^ 271) := by decide +kernel

theorem selectedBound14827 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env14828 : List Nat := [2,4,8,16,32,16,128,256,43,1024,271,1297,389,1297,42,420,1297,42,1025,43,1297,4194304,17,139,269,16,4194607,1296,1297,4194314,1284,4294967296,256,4299161633,1296,43]

theorem envBound14828 : H12AffineFastState.Bounded env14828 := by
  intro p hp
  have h : env14828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14827_14828 : H12AffineEnvironment.transform 10 271 env14827 = env14828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 271 env14827 == env14828) = true)

theorem identity14828 : scanCanonicalize (H12AffineFastState.compose env14828 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 134) := by decide +kernel

theorem selectedBound14828 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env14829 : List Nat := [2,4,8,16,32,16,128,134,43,1024,137,1175,3,1175,42,34,1175,42,1025,43,1175,4194304,17,139,139,16,4194473,1174,1175,4194314,1154,4294967296,134,4299161633,1174,43]

theorem envBound14829 : H12AffineFastState.Bounded env14829 := by
  intro p hp
  have h : env14829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14828_14829 : H12AffineEnvironment.transform 7 134 env14828 = env14829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 134 env14828 == env14829) = true)

theorem identity14829 : scanCanonicalize (H12AffineFastState.compose env14829 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 42) := by decide +kernel

theorem selectedBound14829 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14830 : List Nat := [2,4,8,16,32,16,128,134,43,1024,137,1175,3,1175,42,34,1175,42,1025,43,1175,4194304,17,139,139,16,4194473,1174,1175,4194314,1154,42,134,4194315,1174,43]

theorem envBound14830 : H12AffineFastState.Bounded env14830 := by
  intro p hp
  have h : env14830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14829_14830 : H12AffineEnvironment.transform 31 42 env14829 = env14830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 42 env14829 == env14830) = true)

theorem identity14830 : scanCanonicalize (H12AffineFastState.compose env14830 (packedSelected [2,4,7] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound14830 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env14831 : List Nat := [2,4,8,16,32,16,128,134,43,1024,137,1175,3,1175,42,34,1175,42,1025,43,1175,33,17,139,139,16,136,1174,1175,43,1154,42,134,42,1174,43]

theorem envBound14831 : H12AffineFastState.Bounded env14831 := by
  intro p hp
  have h : env14831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14830_14831 : H12AffineEnvironment.transform 21 33 env14830 = env14831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env14830 == env14831) = true)

theorem identity14831 : scanCanonicalize (H12AffineFastState.compose env14831 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound14831 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14832 : List Nat := [2,4,8,16,32,16,18,20,43,1024,27,1029,3,1029,42,34,1029,42,1025,43,1029,33,17,25,25,16,26,1028,1029,43,1040,42,20,42,1028,43]

theorem envBound14832 : H12AffineFastState.Bounded env14832 := by
  intro p hp
  have h : env14832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14831_14832 : H12AffineEnvironment.transform 6 18 env14831 = env14832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env14831 == env14832) = true)

theorem identity14832 : scanCanonicalize (H12AffineFastState.compose env14832 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound14832 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env14833 : List Nat := [2,4,8,16,17,16,18,20,26,1024,27,1029,3,1029,27,19,1029,27,1025,26,1029,16,17,25,25,16,26,1028,1029,26,1040,27,20,27,1028,26]

theorem envBound14833 : H12AffineFastState.Bounded env14833 := by
  intro p hp
  have h : env14833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14832_14833 : H12AffineEnvironment.transform 4 17 env14832 = env14833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env14832 == env14833) = true)

theorem identity14833 : scanCanonicalize (H12AffineFastState.compose env14833 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound14833 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14834 : List Nat := [2,4,8,16,17,16,18,20,26,4,27,1,3,1,27,19,1,27,5,26,1,16,17,25,25,16,26,0,1,26,20,27,20,27,0,26]

theorem envBound14834 : H12AffineFastState.Bounded env14834 := by
  intro p hp
  have h : env14834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14833_14834 : H12AffineEnvironment.transform 9 4 env14833 = env14834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env14833 == env14834) = true)

theorem identity14834 : scanCanonicalize (H12AffineFastState.compose env14834 (packedSelected [6] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound14834 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env14835 : List Nat := [2,4,8,11,10,11,9,15,1,4,0,1,3,1,0,8,1,0,5,1,1,11,10,2,2,11,1,0,1,1,15,0,15,0,0,1]

theorem envBound14835 : H12AffineFastState.Bounded env14835 := by
  intro p hp
  have h : env14835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14834_14835 : H12AffineEnvironment.transform 3 11 env14834 = env14835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env14834 == env14835) = true)

def env14836 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1296,32768,65536,1296,513,1024,32769,1296,4194304,16,98565,8328,17,4203136,1297,1297,1073741824,1284,4294967296,256,4299260335,9364,512]

theorem envBound14836 : H12AffineFastState.Bounded env14836 := by
  intro p hp
  have h : env14836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14821_14836 : H12AffineEnvironment.transform 5 17 env14821 = env14836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env14821 == env14836) = true)

theorem identity14836 : scanCanonicalize (H12AffineFastState.compose env14836 (packedSelected [3,5,8,28] rootPS)) = affineNative (2^(29+1) ^^^ 4260647) := by decide +kernel

theorem selectedBound14836 : packedSelected [3,5,8,28] rootPS < 2^1333 := by decide +kernel

def env14837 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1296,32768,65536,1296,513,1024,32769,1296,4194304,16,98565,8328,17,4203136,1297,1297,4260647,1284,4294967296,256,4299260335,9364,512]

theorem envBound14837 : H12AffineFastState.Bounded env14837 := by
  intro p hp
  have h : env14837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14836_14837 : H12AffineEnvironment.transform 29 4260647 env14836 = env14837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4260647 env14836 == env14837) = true)

theorem identity14837 : scanCanonicalize (H12AffineFastState.compose env14837 (packedSelected [1,3,8,15,17,21,38] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound14837 : packedSelected [1,3,8,15,17,21,38] rootPS < 2^1333 := by decide +kernel

def env14838 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,389,1296,32768,65536,1296,513,1024,32769,1296,4194304,16,98565,269,17,4195077,1297,1297,4260647,1284,4294967296,256,4299260335,1297,512]

theorem envBound14838 : H12AffineFastState.Bounded env14838 := by
  intro p hp
  have h : env14838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14837_14838 : H12AffineEnvironment.transform 12 389 env14837 = env14838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env14837 == env14838) = true)

theorem identity14838 : scanCanonicalize (H12AffineFastState.compose env14838 (packedSelected [1] rootPS)) = affineNative (2^(14+1) ^^^ 941) := by decide +kernel

theorem selectedBound14838 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14839 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,389,1296,941,65536,1296,513,1024,940,1296,4194304,16,66216,269,17,4195077,1297,1297,4260647,1284,4294967296,256,4299227650,1297,512]

theorem envBound14839 : H12AffineFastState.Bounded env14839 := by
  intro p hp
  have h : env14839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14838_14839 : H12AffineEnvironment.transform 14 941 env14838 = env14839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 941 env14838 == env14839) = true)

theorem identity14839 : scanCanonicalize (H12AffineFastState.compose env14839 (packedSelected [3,8] rootPS)) = affineNative (2^(15+1) ^^^ 2595) := by decide +kernel

theorem selectedBound14839 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env14840 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,389,1296,941,2595,1296,513,1024,940,1296,4194304,16,2187,269,17,4195077,1297,1297,4196612,1284,4294967296,256,4299163681,1297,512]

theorem envBound14840 : H12AffineFastState.Bounded env14840 := by
  intro p hp
  have h : env14840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14839_14840 : H12AffineEnvironment.transform 15 2595 env14839 = env14840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2595 env14839 == env14840) = true)

theorem identity14840 : scanCanonicalize (H12AffineFastState.compose env14840 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound14840 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env14841 : List Nat := [2,4,8,16,32,17,128,256,512,1024,512,1296,389,1296,941,35,1296,513,1024,940,1296,4194304,16,651,269,17,4195077,1297,1297,4195076,1284,4294967296,256,4299162145,1297,512]

theorem envBound14841 : H12AffineFastState.Bounded env14841 := by
  intro p hp
  have h : env14841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14840_14841 : H12AffineEnvironment.transform 10 512 env14840 = env14841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env14840 == env14841) = true)

theorem identity14841 : scanCanonicalize (H12AffineFastState.compose env14841 (packedSelected [0,7] rootPS)) = affineNative (2^(21+1) ^^^ 773) := by decide +kernel

theorem selectedBound14841 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env14842 : List Nat := [2,4,8,16,32,17,128,256,512,1024,512,1296,389,1296,941,35,1296,513,1024,940,1296,773,16,651,269,17,0,1297,1297,1,1284,4294967296,256,4294967588,1297,512]

theorem envBound14842 : H12AffineFastState.Bounded env14842 := by
  intro p hp
  have h : env14842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14841_14842 : H12AffineEnvironment.transform 21 773 env14841 = env14842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 773 env14841 == env14842) = true)

theorem identity14842 : scanCanonicalize (H12AffineFastState.compose env14842 (packedSelected [4,9] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound14842 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env14843 : List Nat := [2,4,8,16,32,17,128,256,0,1024,0,1296,389,1296,429,35,1296,1,1024,428,1296,261,16,139,269,17,0,1297,1297,1,1284,4294967296,256,4294967588,1297,0]

theorem envBound14843 : H12AffineFastState.Bounded env14843 := by
  intro p hp
  have h : env14843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14842_14843 : H12AffineEnvironment.transform 8 0 env14842 = env14843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env14842 == env14843) = true)

theorem identity14843 : scanCanonicalize (H12AffineFastState.compose env14843 (packedSelected [2,4] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound14843 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env14844 : List Nat := [2,4,8,16,32,17,8,256,0,1024,0,1296,269,1296,293,35,1296,1,1024,292,1296,261,16,3,269,17,0,1297,1297,1,1284,4294967296,256,4294967588,1297,0]

theorem envBound14844 : H12AffineFastState.Bounded env14844 := by
  intro p hp
  have h : env14844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14843_14844 : H12AffineEnvironment.transform 6 8 env14843 = env14844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14843 == env14844) = true)

theorem identity14844 : scanCanonicalize (H12AffineFastState.compose env14844 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 0) := by decide +kernel

theorem selectedBound14844 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14845 : List Nat := [2,4,8,16,32,17,8,256,0,1024,0,1296,269,1296,293,35,1296,1,1024,292,1296,261,16,3,269,17,0,1297,1297,1,1284,0,256,292,1297,0]

theorem envBound14845 : H12AffineFastState.Bounded env14845 := by
  intro p hp
  have h : env14845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14844_14845 : H12AffineEnvironment.transform 31 0 env14844 = env14845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 0 env14844 == env14845) = true)

def env14846 : List Nat := [2,4,8,16,0,17,8,256,0,1024,0,1296,269,1296,261,3,1296,1,1024,260,1296,261,16,3,269,17,0,1297,1297,1,1284,0,256,260,1297,0]

theorem envBound14846 : H12AffineFastState.Bounded env14846 := by
  intro p hp
  have h : env14846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14845_14846 : H12AffineEnvironment.transform 4 0 env14845 = env14846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14845 == env14846) = true)

theorem identity14846 : scanCanonicalize (H12AffineFastState.compose env14846 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound14846 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14847 : List Nat := [2,4,8,16,0,17,8,4,0,1024,0,1044,9,1044,1,3,1044,1,1024,0,1044,1,16,3,9,17,0,1045,1045,1,1024,0,4,0,1045,0]

theorem envBound14847 : H12AffineFastState.Bounded env14847 := by
  intro p hp
  have h : env14847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14846_14847 : H12AffineEnvironment.transform 7 4 env14846 = env14847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env14846 == env14847) = true)

def leafEnv14847 : List Nat := [2,4,8,16,0,17,8,4,0,1024,0,1044,9,1044,1,3,1044,1,1024,0,1044,1,16,3,1024,9,1,17,0,1045,1045,1,1024,0,4,0,4,2,1045,0,0,1045,1]

def active14847 : List Nat := [0,1,2,3,9]

def tree14847 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14847 : H12WitnessSearch.Good tree14847 := H12GlobalWitnessIndex.good

theorem leafIdentity14847 : H12AffineFastState.composeSystem env14847 rootObs = leafEnv14847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14847 rootObs == leafEnv14847) = true)

theorem terminalChecked14847 : H12PackedTerminal.terminalCheckFast leafEnv14847 active14847 tree14847 = true := by decide +kernel

def env14848 : List Nat := [2,4,8,16,1,17,8,256,0,1024,0,1296,269,1296,260,2,1296,1,1024,261,1296,261,16,3,269,17,0,1297,1297,1,1284,0,256,261,1297,0]

theorem envBound14848 : H12AffineFastState.Bounded env14848 := by
  intro p hp
  have h : env14848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14845_14848 : H12AffineEnvironment.transform 4 1 env14845 = env14848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14845 == env14848) = true)

def leafEnv14848 : List Nat := [2,4,8,16,1,17,8,256,0,1024,0,1296,269,1296,260,2,1296,1,1024,261,1296,261,16,3,1284,269,1,17,0,1297,1297,1,1284,0,256,261,4,3,1297,0,0,1297,1]

def active14848 : List Nat := [0,1,2,3,7,9]

def tree14848 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14848 : H12WitnessSearch.Good tree14848 := H12GlobalWitnessIndex.good

theorem leafIdentity14848 : H12AffineFastState.composeSystem env14848 rootObs = leafEnv14848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14848 rootObs == leafEnv14848) = true)

theorem terminalChecked14848 : H12PackedTerminal.terminalCheckFast leafEnv14848 active14848 tree14848 = true := by decide +kernel

def env14849 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,4194304,8388608,16777216,8328,8914000,134217728,8519744,676864,1073741824,25412673,4294967296,8536384,4315938986,164610304,512]

theorem envBound14849 : H12AffineFastState.Bounded env14849 := by
  intro p hp
  have h : env14849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14322_14849 : H12AffineEnvironment.transform 20 4097 env14322 = env14849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env14322 == env14849) = true)

theorem identity14849 : scanCanonicalize (H12AffineFastState.compose env14849 (packedSelected [14] rootPS)) = affineNative (2^(26+1) ^^^ 13385733) := by decide +kernel

theorem selectedBound14849 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env14850 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,4194304,8388608,16777216,8328,8914000,13385733,8519744,676864,1073741824,25412673,4294967296,8536384,4315938986,17006853,512]

theorem envBound14850 : H12AffineFastState.Bounded env14850 := by
  intro p hp
  have h : env14850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14849_14850 : H12AffineEnvironment.transform 26 13385733 env14849 = env14850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 13385733 env14849 == env14850) = true)

def env14851 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,4194304,17664,16777216,8328,541008,4982021,148800,676864,1073741824,17006913,4294967296,132160,4315938986,17006853,512]

theorem envBound14851 : H12AffineFastState.Bounded env14851 := by
  intro p hp
  have h : env14851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14850_14851 : H12AffineEnvironment.transform 22 17664 env14850 = env14851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17664 env14850 == env14851) = true)

theorem identity14851 : scanCanonicalize (H12AffineFastState.compose env14851 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(18+1) ^^^ 131392) := by decide +kernel

theorem selectedBound14851 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env14852 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,131392,32769,4097,4194304,17664,16777216,8328,147472,4588613,148800,21824,1073741824,17006913,4294967296,132160,4315938986,17006853,512]

theorem envBound14852 : H12AffineFastState.Bounded env14852 := by
  intro p hp
  have h : env14852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14851_14852 : H12AffineEnvironment.transform 18 131392 env14851 = env14852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 131392 env14851 == env14852) = true)

theorem identity14852 : scanCanonicalize (H12AffineFastState.compose env14852 (packedSelected [7,20,27] rootPS)) = affineNative (2^(16+1) ^^^ 1344) := by decide +kernel

theorem selectedBound14852 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env14853 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,1024,32769,4097,4194304,17664,16777216,8328,17744,4456709,16384,21824,1073741824,16876545,4294967296,256,4315938986,16876613,512]

theorem envBound14853 : H12AffineFastState.Bounded env14853 := by
  intro p hp
  have h : env14853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14852_14853 : H12AffineEnvironment.transform 16 1344 env14852 = env14853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env14852 == env14853) = true)

def env14854 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,65536,1344,262144,1024,32769,4097,4194304,64,16777216,8328,16,4456709,1344,4096,1073741824,16876545,4294967296,256,4315938986,16876613,512]

theorem envBound14854 : H12AffineFastState.Bounded env14854 := by
  intro p hp
  have h : env14854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14853_14854 : H12AffineEnvironment.transform 13 1344 env14853 = env14854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env14853 == env14854) = true)

theorem identity14854 : scanCanonicalize (H12AffineFastState.compose env14854 (packedSelected [0,7,20] rootPS)) = affineNative (2^(11+1) ^^^ 1344) := by decide +kernel

theorem selectedBound14854 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env14855 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,32768,65536,1344,262144,1024,32769,1345,4194304,64,16777216,8328,16,4456709,1344,1344,1073741824,16876545,4294967296,256,4315938986,16876613,512]

theorem envBound14855 : H12AffineFastState.Bounded env14855 := by
  intro p hp
  have h : env14855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14854_14855 : H12AffineEnvironment.transform 11 1344 env14854 = env14855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env14854 == env14855) = true)

theorem identity14855 : scanCanonicalize (H12AffineFastState.compose env14855 (packedSelected [17,21] rootPS)) = affineNative (2^(23+1) ^^^ 138) := by decide +kernel

theorem selectedBound14855 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env14856 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,32768,65536,1344,262144,1024,32769,1345,4194304,64,138,8328,16,4456709,1344,1344,1073741824,99467,4294967296,256,4299161632,99535,512]

theorem envBound14856 : H12AffineFastState.Bounded env14856 := by
  intro p hp
  have h : env14856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14855_14856 : H12AffineEnvironment.transform 23 138 env14855 = env14856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 138 env14855 == env14856) = true)

theorem identity14856 : scanCanonicalize (H12AffineFastState.compose env14856 (packedSelected [1,3,12,24,28,41] rootPS)) = affineNative (2^(17+1) ^^^ 76199) := by decide +kernel

theorem selectedBound14856 : packedSelected [1,3,12,24,28,41] rootPS < 2^1333 := by decide +kernel

def env14857 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,32768,65536,1344,76199,1024,32769,1345,4194304,64,138,8328,16,4270242,1344,1344,1073741824,99467,4294967296,256,4299161632,99535,512]

theorem envBound14857 : H12AffineFastState.Bounded env14857 := by
  intro p hp
  have h : env14857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14856_14857 : H12AffineEnvironment.transform 17 76199 env14856 = env14857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76199 env14856 == env14857) = true)

theorem identity14857 : scanCanonicalize (H12AffineFastState.compose env14857 (packedSelected [11,32] rootPS)) = affineNative (2^(29+1) ^^^ 4294795) := by decide +kernel

theorem selectedBound14857 : packedSelected [11,32] rootPS < 2^1333 := by decide +kernel

def env14858 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,32768,65536,1344,76199,1024,32769,1345,4194304,64,138,8328,16,4270242,1344,1344,4294795,99467,4294967296,256,4299161632,99535,512]

theorem envBound14858 : H12AffineFastState.Bounded env14858 := by
  intro p hp
  have h : env14858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14857_14858 : H12AffineEnvironment.transform 29 4294795 env14857 = env14858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4294795 env14857 == env14858) = true)

theorem identity14858 : scanCanonicalize (H12AffineFastState.compose env14858 (packedSelected [0,1,2,3,4,6,10,11,13,15] rootPS)) = affineNative (2^(14+1) ^^^ 9092) := by decide +kernel

theorem selectedBound14858 : packedSelected [0,1,2,3,4,6,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env14859 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,9092,65536,1344,76199,1024,9093,1345,4194304,64,138,8328,16,4270242,1344,1344,4270863,75535,4294967296,256,4299161632,75595,512]

theorem envBound14859 : H12AffineFastState.Bounded env14859 := by
  intro p hp
  have h : env14859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14858_14859 : H12AffineEnvironment.transform 14 9092 env14858 = env14859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9092 env14858 == env14859) = true)

theorem identity14859 : scanCanonicalize (H12AffineFastState.compose env14859 (packedSelected [0,2,5,6,8,9,10,12,17,18] rootPS)) = affineNative (2^(15+1) ^^^ 8795) := by decide +kernel

theorem selectedBound14859 : packedSelected [0,2,5,6,8,9,10,12,17,18] rootPS < 2^1333 := by decide +kernel

def env14860 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,9092,8795,1344,3068,1024,9093,1345,4194304,64,138,8328,16,4197113,1344,1344,4196692,1364,4294967296,256,4299161632,1296,512]

theorem envBound14860 : H12AffineFastState.Bounded env14860 := by
  intro p hp
  have h : env14860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14859_14860 : H12AffineEnvironment.transform 15 8795 env14859 = env14860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8795 env14859 == env14860) = true)

theorem identity14860 : scanCanonicalize (H12AffineFastState.compose env14860 (packedSelected [0,1,3,4,5,7,8,9,12] rootPS)) = affineNative (2^(31+1) ^^^ 4205176) := by decide +kernel

theorem selectedBound14860 : packedSelected [0,1,3,4,5,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env14861 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,9092,8795,1344,3068,1024,9093,1345,4194304,64,138,8328,16,4197113,1344,1344,4196692,1364,4205176,256,10840,1296,512]

theorem envBound14861 : H12AffineFastState.Bounded env14861 := by
  intro p hp
  have h : env14861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14860_14861 : H12AffineEnvironment.transform 31 4205176 env14860 = env14861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 4205176 env14860 == env14861) = true)

theorem identity14861 : scanCanonicalize (H12AffineFastState.compose env14861 (packedSelected [3,8,10] rootPS)) = affineNative (2^(12+1) ^^^ 2516) := by decide +kernel

theorem selectedBound14861 : packedSelected [3,8,10] rootPS < 2^1333 := by decide +kernel

def env14862 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,2516,1344,2640,2959,1344,3068,1024,2641,1345,4194304,64,138,2396,16,4197113,1344,1344,4196692,1364,4195244,256,908,1296,512]

theorem envBound14862 : H12AffineFastState.Bounded env14862 := by
  intro p hp
  have h : env14862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14861_14862 : H12AffineEnvironment.transform 12 2516 env14861 = env14862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2516 env14861 == env14862) = true)

theorem identity14862 : scanCanonicalize (H12AffineFastState.compose env14862 (packedSelected [1,2,5,6,7,9,11,17] rootPS)) = affineNative (2^(21+1) ^^^ 476) := by decide +kernel

theorem selectedBound14862 : packedSelected [1,2,5,6,7,9,11,17] rootPS < 2^1333 := by decide +kernel

def env14863 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,2516,1344,2640,2959,1344,3068,1024,2641,1345,476,64,138,2396,16,2853,1344,1344,2184,1364,624,256,908,1296,512]

theorem envBound14863 : H12AffineFastState.Bounded env14863 := by
  intro p hp
  have h : env14863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14862_14863 : H12AffineEnvironment.transform 21 476 env14862 = env14863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 476 env14862 == env14863) = true)

def env14864 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,65536,1344,262144,1024,32769,4097,4194304,65,16777216,8328,17,4456709,1345,4097,1073741824,16876545,4294967296,256,4315938986,16876613,512]

theorem envBound14864 : H12AffineFastState.Bounded env14864 := by
  intro p hp
  have h : env14864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14853_14864 : H12AffineEnvironment.transform 13 1345 env14853 = env14864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env14853 == env14864) = true)

theorem identity14864 : scanCanonicalize (H12AffineFastState.compose env14864 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound14864 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env14865 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,1296,32768,65536,1297,262144,1024,32769,4097,4194304,16,16777216,8328,17,4456709,1296,4097,1073741824,16876545,4294967296,256,4315938986,16876564,512]

theorem envBound14865 : H12AffineFastState.Bounded env14865 := by
  intro p hp
  have h : env14865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14864_14865 : H12AffineEnvironment.transform 5 17 env14864 = env14865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env14864 == env14865) = true)

def env14866 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,4194304,17665,16777216,8328,541009,4982020,148801,676864,1073741824,17006912,4294967296,132161,4315938986,17006853,512]

theorem envBound14866 : H12AffineFastState.Bounded env14866 := by
  intro p hp
  have h : env14866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14850_14866 : H12AffineEnvironment.transform 22 17665 env14850 = env14866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17665 env14850 == env14866) = true)

theorem identity14866 : scanCanonicalize (H12AffineFastState.compose env14866 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(23+1) ^^^ 98565) := by decide +kernel

theorem selectedBound14866 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env14867 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,4194304,17665,98565,8328,541009,4982020,148801,676864,1073741824,131141,4294967296,132161,4299260335,131072,512]

theorem envBound14867 : H12AffineFastState.Bounded env14867 := by
  intro p hp
  have h : env14867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14866_14867 : H12AffineEnvironment.transform 23 98565 env14866 = env14867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98565 env14866 == env14867) = true)

def env14868 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16384,262144,524288,32769,4097,4194304,17665,98565,8328,541009,4982020,1345,529408,1073741824,16453,4294967296,17473,4299260335,16384,512]

theorem envBound14868 : H12AffineFastState.Bounded env14868 := by
  intro p hp
  have h : env14868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14867_14868 : H12AffineEnvironment.transform 16 16384 env14867 = env14868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16384 env14867 == env14868) = true)

def env14869 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16384,262144,524288,32769,4097,10248,17665,98565,8328,541009,797964,1345,529408,1073741824,16453,4294967296,17473,4295076263,16384,512]

theorem envBound14869 : H12AffineFastState.Bounded env14869 := by
  intro p hp
  have h : env14869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14868_14869 : H12AffineEnvironment.transform 21 10248 env14868 = env14869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10248 env14868 == env14869) = true)

def env14870 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,16384,262144,524288,32769,4097,8200,17665,98565,8328,541009,795916,1345,529408,1073741824,16453,4294967296,17473,4295074215,16384,512]

theorem envBound14870 : H12AffineFastState.Bounded env14870 := by
  intro p hp
  have h : env14870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14869_14870 : H12AffineEnvironment.transform 10 0 env14869 = env14870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env14869 == env14870) = true)

def env14871 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,1344,32768,65536,1344,262144,524288,32769,4097,8200,65,98565,8328,525329,795916,1345,529408,1073741824,1285,4294967296,257,4295074215,1344,512]

theorem envBound14871 : H12AffineFastState.Bounded env14871 := by
  intro p hp
  have h : env14871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14870_14871 : H12AffineEnvironment.transform 13 1344 env14870 = env14871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env14870 == env14871) = true)

theorem identity14871 : scanCanonicalize (H12AffineFastState.compose env14871 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 823348) := by decide +kernel

theorem selectedBound14871 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env14872 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,1344,32768,65536,1344,262144,524288,32769,4097,8200,65,98565,8328,525329,795916,1345,529408,823348,1285,4294967296,257,4295074215,1344,512]

theorem envBound14872 : H12AffineFastState.Bounded env14872 := by
  intro p hp
  have h : env14872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14871_14872 : H12AffineEnvironment.transform 29 823348 env14871 = env14872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 823348 env14871 == env14872) = true)

theorem identity14872 : scanCanonicalize (H12AffineFastState.compose env14872 (packedSelected [4,9,16] rootPS)) = affineNative (2^(18+1) ^^^ 1025) := by decide +kernel

theorem selectedBound14872 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env14873 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,1344,32768,65536,1344,262144,1025,32769,4097,8200,65,98565,8328,16,270605,1345,4097,300085,1285,4294967296,257,4295074215,1344,512]

theorem envBound14873 : H12AffineFastState.Bounded env14873 := by
  intro p hp
  have h : env14873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14872_14873 : H12AffineEnvironment.transform 18 1025 env14872 = env14873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env14872 == env14873) = true)

theorem identity14873 : scanCanonicalize (H12AffineFastState.compose env14873 (packedSelected [17,21] rootPS)) = affineNative (2^(17+1) ^^^ 13340) := by decide +kernel

theorem selectedBound14873 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env14874 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,1344,32768,65536,1344,13340,1025,32769,4097,8200,65,98565,8328,16,5393,1345,4097,41001,1285,4294967296,257,4295074215,1344,512]

theorem envBound14874 : H12AffineFastState.Bounded env14874 := by
  intro p hp
  have h : env14874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14873_14874 : H12AffineEnvironment.transform 17 13340 env14873 = env14874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 13340 env14873 == env14874) = true)

theorem identity14874 : scanCanonicalize (H12AffineFastState.compose env14874 (packedSelected [0,1,3,4,7,9,10,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 1945) := by decide +kernel

theorem selectedBound14874 : packedSelected [0,1,3,4,7,9,10,13,15] rootPS < 2^1333 := by decide +kernel

def env14875 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1945,8192,1344,32768,65536,1344,9093,1025,32769,1944,8200,65,98565,8328,16,648,1345,1944,41001,1285,4294967296,257,4295074215,1344,512]

theorem envBound14875 : H12AffineFastState.Bounded env14875 := by
  intro p hp
  have h : env14875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14874_14875 : H12AffineEnvironment.transform 11 1945 env14874 = env14875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1945 env14874 == env14875) = true)

def env14876 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1945,8192,1344,8864,65536,1344,9093,1025,8865,1944,8200,65,74661,8328,16,648,1345,1944,649,1285,4294967296,257,4295033607,1344,512]

theorem envBound14876 : H12AffineFastState.Bounded env14876 := by
  intro p hp
  have h : env14876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14875_14876 : H12AffineEnvironment.transform 14 8864 env14875 = env14876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8864 env14875 == env14876) = true)

theorem identity14876 : scanCanonicalize (H12AffineFastState.compose env14876 (packedSelected [4,9] rootPS)) = affineNative (2^(12+1) ^^^ 900) := by decide +kernel

theorem selectedBound14876 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env14877 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1945,900,1344,292,65536,1344,1,1025,293,1944,908,65,65569,780,16,648,1345,1944,649,1285,4294967296,257,4295033607,1344,512]

theorem envBound14877 : H12AffineFastState.Bounded env14877 := by
  intro p hp
  have h : env14877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14876_14877 : H12AffineEnvironment.transform 12 900 env14876 = env14877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 900 env14876 == env14877) = true)

theorem identity14877 : scanCanonicalize (H12AffineFastState.compose env14877 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound14877 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env14878 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,1296,269,1344,292,65536,1344,1,1025,293,1297,261,65,65569,389,16,1,1345,1297,0,1285,4294967296,257,4295033230,1344,137]

theorem envBound14878 : H12AffineFastState.Bounded env14878 := by
  intro p hp
  have h : env14878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14877_14878 : H12AffineEnvironment.transform 8 137 env14877 = env14878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env14877 == env14878) = true)

theorem identity14878 : scanCanonicalize (H12AffineFastState.compose env14878 (packedSelected [1,3,5] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound14878 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env14879 : List Nat := [2,4,8,16,32,64,128,5,137,1024,0,1045,8,1093,33,65536,1093,1,1025,32,1044,0,65,65569,128,16,1,1092,1044,0,1024,4294967296,4,4295032971,1093,137]

theorem envBound14879 : H12AffineFastState.Bounded env14879 := by
  intro p hp
  have h : env14879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14878_14879 : H12AffineEnvironment.transform 7 5 env14878 = env14879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env14878 == env14879) = true)

theorem identity14879 : scanCanonicalize (H12AffineFastState.compose env14879 (packedSelected [2,4] rootPS)) = affineNative (2^(15+1) ^^^ 170) := by decide +kernel

theorem selectedBound14879 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env14880 : List Nat := [2,4,8,16,32,64,128,5,137,1024,0,1045,8,1093,33,170,1093,1,1025,32,1044,0,65,139,128,16,1,1092,1044,0,1024,4294967296,4,4294967329,1093,137]

theorem envBound14880 : H12AffineFastState.Bounded env14880 := by
  intro p hp
  have h : env14880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14879_14880 : H12AffineEnvironment.transform 15 170 env14879 = env14880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 170 env14879 == env14880) = true)

theorem identity14880 : scanCanonicalize (H12AffineFastState.compose env14880 (packedSelected [1,3] rootPS)) = affineNative (2^(31+1) ^^^ 136) := by decide +kernel

theorem selectedBound14880 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env14881 : List Nat := [2,4,8,16,32,64,128,5,137,1024,0,1045,8,1093,33,170,1093,1,1025,32,1044,0,65,139,128,16,1,1092,1044,0,1024,136,4,169,1093,137]

theorem envBound14881 : H12AffineFastState.Bounded env14881 := by
  intro p hp
  have h : env14881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14880_14881 : H12AffineEnvironment.transform 31 136 env14880 = env14881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 136 env14880 == env14881) = true)

theorem identity14881 : scanCanonicalize (H12AffineFastState.compose env14881 (packedSelected [0,2] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound14881 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env14882 : List Nat := [2,4,8,16,32,64,128,5,137,52,0,33,8,113,33,170,113,1,53,32,32,0,65,139,128,16,1,112,32,0,52,136,4,169,113,137]

theorem envBound14882 : H12AffineFastState.Bounded env14882 := by
  intro p hp
  have h : env14882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14881_14882 : H12AffineEnvironment.transform 9 52 env14881 = env14882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env14881 == env14882) = true)

def env14883 : List Nat := [2,4,8,16,0,64,128,5,137,20,0,1,8,81,1,138,81,1,21,0,0,0,65,139,128,16,1,80,0,0,20,136,4,137,81,137]

theorem envBound14883 : H12AffineFastState.Bounded env14883 := by
  intro p hp
  have h : env14883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14882_14883 : H12AffineEnvironment.transform 4 0 env14882 = env14883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14882 == env14883) = true)

theorem identity14883 : scanCanonicalize (H12AffineFastState.compose env14883 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound14883 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14884 : List Nat := [2,4,8,16,0,64,25,5,16,20,0,1,8,81,1,19,81,1,21,0,0,0,65,18,25,16,1,80,0,0,20,17,4,16,81,16]

theorem envBound14884 : H12AffineFastState.Bounded env14884 := by
  intro p hp
  have h : env14884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14883_14884 : H12AffineEnvironment.transform 6 25 env14883 = env14884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env14883 == env14884) = true)

theorem identity14884 : scanCanonicalize (H12AffineFastState.compose env14884 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound14884 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14885 : List Nat := [2,4,8,16,0,16,25,5,16,20,0,1,8,1,1,19,1,1,21,0,0,0,17,18,25,16,1,0,0,0,20,17,4,16,1,16]

theorem envBound14885 : H12AffineFastState.Bounded env14885 := by
  intro p hp
  have h : env14885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14884_14885 : H12AffineEnvironment.transform 5 16 env14884 = env14885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env14884 == env14885) = true)

def leafEnv14885 : List Nat := [2,4,8,16,0,16,25,5,16,20,0,1,8,1,1,19,1,1,21,0,0,0,17,18,20,25,1,16,1,0,0,0,20,17,4,16,4,3,1,16,0,0,1]

def active14885 : List Nat := [0,1,2,3]

def tree14885 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14885 : H12WitnessSearch.Good tree14885 := H12GlobalWitnessIndex.good

theorem leafIdentity14885 : H12AffineFastState.composeSystem env14885 rootObs = leafEnv14885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14885 rootObs == leafEnv14885) = true)

theorem terminalChecked14885 : H12PackedTerminal.terminalCheckFast leafEnv14885 active14885 tree14885 = true := by decide +kernel

def env14886 : List Nat := [2,4,8,16,1,64,128,5,137,21,0,0,8,80,0,139,80,1,20,1,1,0,65,139,128,16,1,81,1,0,21,136,4,136,80,137]

theorem envBound14886 : H12AffineFastState.Bounded env14886 := by
  intro p hp
  have h : env14886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14882_14886 : H12AffineEnvironment.transform 4 1 env14882 = env14886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14882 == env14886) = true)

theorem identity14886 : scanCanonicalize (H12AffineFastState.compose env14886 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound14886 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14887 : List Nat := [2,4,8,1,1,64,128,5,137,4,0,0,8,65,0,139,65,1,5,1,1,0,65,139,128,1,1,64,1,0,4,136,4,136,65,137]

theorem envBound14887 : H12AffineFastState.Bounded env14887 := by
  intro p hp
  have h : env14887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14886_14887 : H12AffineEnvironment.transform 3 1 env14886 = env14887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env14886 == env14887) = true)

def leafEnv14887 : List Nat := [2,4,8,1,1,64,128,5,137,4,0,0,8,65,0,139,65,1,5,1,1,0,65,139,4,128,1,1,1,64,1,0,4,136,4,136,4,2,65,137,0,1,1]

def active14887 : List Nat := [0,1,2,5,6]

def tree14887 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14887 : H12WitnessSearch.Good tree14887 := H12GlobalWitnessIndex.good

theorem leafIdentity14887 : H12AffineFastState.composeSystem env14887 rootObs = leafEnv14887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14887 rootObs == leafEnv14887) = true)

theorem terminalChecked14887 : H12PackedTerminal.terminalCheckFast leafEnv14887 active14887 tree14887 = true := by decide +kernel

def env14888 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1945,8192,1344,8865,65536,1344,9093,1025,8864,1944,8200,65,74660,8328,16,648,1345,1944,648,1285,4294967296,257,4295033606,1344,512]

theorem envBound14888 : H12AffineFastState.Bounded env14888 := by
  intro p hp
  have h : env14888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14875_14888 : H12AffineEnvironment.transform 14 8865 env14875 = env14888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8865 env14875 == env14888) = true)

theorem identity14888 : scanCanonicalize (H12AffineFastState.compose env14888 (packedSelected [4,9] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound14888 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env14889 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1945,268,1344,941,65536,1344,649,1025,940,1944,260,65,66216,388,16,648,1345,1944,648,1285,4294967296,257,4295033606,1344,512]

theorem envBound14889 : H12AffineFastState.Bounded env14889 := by
  intro p hp
  have h : env14889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14888_14889 : H12AffineEnvironment.transform 12 268 env14888 = env14889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env14888 == env14889) = true)

theorem identity14889 : scanCanonicalize (H12AffineFastState.compose env14889 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound14889 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env14890 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,1296,268,1344,292,65536,1344,0,1025,293,1297,260,65,65569,388,16,1,1345,1297,1,1285,4294967296,257,4295033231,1344,137]

theorem envBound14890 : H12AffineFastState.Bounded env14890 := by
  intro p hp
  have h : env14890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14889_14890 : H12AffineEnvironment.transform 8 137 env14889 = env14890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env14889 == env14890) = true)

theorem identity14890 : scanCanonicalize (H12AffineFastState.compose env14890 (packedSelected [1,3,5] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound14890 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env14891 : List Nat := [2,4,8,16,32,64,128,4,137,1024,0,1044,8,1092,32,65536,1092,0,1025,33,1045,0,65,65569,128,16,1,1093,1045,1,1025,4294967296,5,4295032971,1092,137]

theorem envBound14891 : H12AffineFastState.Bounded env14891 := by
  intro p hp
  have h : env14891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14890_14891 : H12AffineEnvironment.transform 7 4 env14890 = env14891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env14890 == env14891) = true)

def env14892 : List Nat := [2,4,8,16,0,64,128,4,137,1024,0,1044,8,1092,0,65536,1092,0,1025,1,1045,0,65,65537,128,16,1,1093,1045,1,1025,4294967296,5,4295032971,1092,137]

theorem envBound14892 : H12AffineFastState.Bounded env14892 := by
  intro p hp
  have h : env14892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14891_14892 : H12AffineEnvironment.transform 4 0 env14891 = env14892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14891 == env14892) = true)

theorem identity14892 : scanCanonicalize (H12AffineFastState.compose env14892 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 1028) := by decide +kernel

theorem selectedBound14892 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14893 : List Nat := [2,4,8,16,0,64,128,4,137,1024,0,1044,8,1092,0,65536,1092,0,1025,1,1045,0,65,65537,128,16,1,1093,1045,1,1025,1028,5,66703,1092,137]

theorem envBound14893 : H12AffineFastState.Bounded env14893 := by
  intro p hp
  have h : env14893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14892_14893 : H12AffineEnvironment.transform 31 1028 env14892 = env14893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1028 env14892 == env14893) = true)

def env14894 : List Nat := [2,4,8,16,0,64,128,4,137,68,0,80,8,0,0,65536,0,0,69,1,81,0,65,65537,128,16,1,1,81,1,69,64,5,65739,0,137]

theorem envBound14894 : H12AffineFastState.Bounded env14894 := by
  intro p hp
  have h : env14894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14893_14894 : H12AffineEnvironment.transform 9 68 env14893 = env14894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 68 env14893 == env14894) = true)

theorem identity14894 : scanCanonicalize (H12AffineFastState.compose env14894 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound14894 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14895 : List Nat := [2,4,8,16,0,17,128,4,137,21,0,1,8,0,0,65536,0,0,20,1,0,0,16,65537,128,16,1,1,0,1,20,17,5,65690,0,137]

theorem envBound14895 : H12AffineFastState.Bounded env14895 := by
  intro p hp
  have h : env14895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14894_14895 : H12AffineEnvironment.transform 5 17 env14894 = env14895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env14894 == env14895) = true)

theorem identity14895 : scanCanonicalize (H12AffineFastState.compose env14895 (packedSelected [3] rootPS)) = affineNative (2^(15+1) ^^^ 19) := by decide +kernel

theorem selectedBound14895 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env14896 : List Nat := [2,4,8,16,0,17,128,4,137,21,0,1,8,0,0,19,0,0,20,1,0,0,16,18,128,16,1,1,0,1,20,17,5,137,0,137]

theorem envBound14896 : H12AffineFastState.Bounded env14896 := by
  intro p hp
  have h : env14896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14895_14896 : H12AffineEnvironment.transform 15 19 env14895 = env14896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 19 env14895 == env14896) = true)

theorem identity14896 : scanCanonicalize (H12AffineFastState.compose env14896 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound14896 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14897 : List Nat := [2,4,8,16,0,17,25,4,16,21,0,1,8,0,0,19,0,0,20,1,0,0,16,18,25,16,1,1,0,1,20,17,5,16,0,16]

theorem envBound14897 : H12AffineFastState.Bounded env14897 := by
  intro p hp
  have h : env14897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14896_14897 : H12AffineEnvironment.transform 6 25 env14896 = env14897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env14896 == env14897) = true)

def leafEnv14897 : List Nat := [2,4,8,16,0,17,25,4,16,21,0,1,8,0,0,19,0,0,20,1,0,0,16,18,20,25,1,16,1,1,0,1,20,17,5,16,4,3,0,16,0,0,1]

def active14897 : List Nat := [0,1,2,3]

def tree14897 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14897 : H12WitnessSearch.Good tree14897 := H12GlobalWitnessIndex.good

theorem leafIdentity14897 : H12AffineFastState.composeSystem env14897 rootObs = leafEnv14897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14897 rootObs == leafEnv14897) = true)

theorem terminalChecked14897 : H12PackedTerminal.terminalCheckFast leafEnv14897 active14897 tree14897 = true := by decide +kernel

def env14898 : List Nat := [2,4,8,16,0,64,128,4,137,69,0,81,8,1,0,65536,1,0,68,1,80,0,65,65537,128,16,1,0,80,1,68,65,5,65738,1,137]

theorem envBound14898 : H12AffineFastState.Bounded env14898 := by
  intro p hp
  have h : env14898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14893_14898 : H12AffineEnvironment.transform 9 69 env14893 = env14898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env14893 == env14898) = true)

theorem identity14898 : scanCanonicalize (H12AffineFastState.compose env14898 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 219) := by decide +kernel

theorem selectedBound14898 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14899 : List Nat := [2,4,8,16,0,64,128,4,137,69,0,81,8,1,0,219,1,0,68,1,80,0,65,218,128,16,1,0,80,1,68,65,5,17,1,137]

theorem envBound14899 : H12AffineFastState.Bounded env14899 := by
  intro p hp
  have h : env14899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14898_14899 : H12AffineEnvironment.transform 15 219 env14898 = env14899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 219 env14898 == env14899) = true)

theorem identity14899 : scanCanonicalize (H12AffineFastState.compose env14899 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 73) := by decide +kernel

theorem selectedBound14899 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env14900 : List Nat := [2,4,8,16,0,64,73,4,64,69,0,81,8,1,0,18,1,0,68,1,80,0,65,19,73,16,1,0,80,1,68,65,5,17,1,64]

theorem envBound14900 : H12AffineFastState.Bounded env14900 := by
  intro p hp
  have h : env14900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14899_14900 : H12AffineEnvironment.transform 6 73 env14899 = env14900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 73 env14899 == env14900) = true)

def env14901 : List Nat := [2,4,8,16,1,64,128,4,137,1024,0,1044,8,1092,1,65536,1092,0,1025,0,1045,0,65,65536,128,16,1,1093,1045,1,1025,4294967296,5,4295032971,1092,137]

theorem envBound14901 : H12AffineFastState.Bounded env14901 := by
  intro p hp
  have h : env14901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14891_14901 : H12AffineEnvironment.transform 4 1 env14891 = env14901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14891 == env14901) = true)

theorem identity14901 : scanCanonicalize (H12AffineFastState.compose env14901 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 66567) := by decide +kernel

theorem selectedBound14901 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14902 : List Nat := [2,4,8,16,1,64,128,4,137,1024,0,1044,8,1092,1,65536,1092,0,1025,0,1045,0,65,65536,128,16,1,1093,1045,1,1025,66567,5,1164,1092,137]

theorem envBound14902 : H12AffineFastState.Bounded env14902 := by
  intro p hp
  have h : env14902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14901_14902 : H12AffineEnvironment.transform 31 66567 env14901 = env14902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 66567 env14901 == env14902) = true)

def env14903 : List Nat := [2,4,8,16,1,64,128,4,137,68,0,80,8,0,1,65536,0,0,69,0,81,0,65,65536,128,16,1,1,81,1,69,65603,5,200,0,137]

theorem envBound14903 : H12AffineFastState.Bounded env14903 := by
  intro p hp
  have h : env14903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14902_14903 : H12AffineEnvironment.transform 9 68 env14902 = env14903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 68 env14902 == env14903) = true)

def env14904 : List Nat := [2,4,8,16,1,64,128,4,137,69,0,81,8,1,1,65536,1,0,68,0,80,0,65,65536,128,16,1,0,80,1,68,65602,5,201,1,137]

theorem envBound14904 : H12AffineFastState.Bounded env14904 := by
  intro p hp
  have h : env14904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14902_14904 : H12AffineEnvironment.transform 9 69 env14902 = env14904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env14902 == env14904) = true)

theorem identity14904 : scanCanonicalize (H12AffineFastState.compose env14904 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 138) := by decide +kernel

theorem selectedBound14904 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14905 : List Nat := [2,4,8,16,1,64,128,4,137,69,0,81,8,1,1,138,1,0,68,0,80,0,65,138,128,16,1,0,80,1,68,200,5,201,1,137]

theorem envBound14905 : H12AffineFastState.Bounded env14905 := by
  intro p hp
  have h : env14905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14904_14905 : H12AffineEnvironment.transform 15 138 env14904 = env14905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 138 env14904 == env14905) = true)

theorem identity14905 : scanCanonicalize (H12AffineFastState.compose env14905 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound14905 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14906 : List Nat := [2,4,8,1,1,64,128,4,137,69,0,64,8,1,1,138,1,0,68,0,65,0,65,138,128,1,1,0,65,1,68,200,5,201,1,137]

theorem envBound14906 : H12AffineFastState.Bounded env14906 := by
  intro p hp
  have h : env14906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14905_14906 : H12AffineEnvironment.transform 3 1 env14905 = env14906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env14905 == env14906) = true)

def env14907 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,1345,32768,65536,1345,262144,524288,32769,4097,8200,64,98565,8328,525328,795916,1345,529408,1073741824,1284,4294967296,256,4295074215,1345,512]

theorem envBound14907 : H12AffineFastState.Bounded env14907 := by
  intro p hp
  have h : env14907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14870_14907 : H12AffineEnvironment.transform 13 1345 env14870 = env14907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env14870 == env14907) = true)

theorem identity14907 : scanCanonicalize (H12AffineFastState.compose env14907 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 295205) := by decide +kernel

theorem selectedBound14907 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env14908 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,1345,32768,65536,1345,262144,524288,32769,4097,8200,64,98565,8328,525328,795916,1345,529408,295205,1284,4294967296,256,4295074215,1345,512]

theorem envBound14908 : H12AffineFastState.Bounded env14908 := by
  intro p hp
  have h : env14908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14907_14908 : H12AffineEnvironment.transform 29 295205 env14907 = env14908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 295205 env14907 == env14908) = true)

theorem identity14908 : scanCanonicalize (H12AffineFastState.compose env14908 (packedSelected [18,23] rootPS)) = affineNative (2^(18+1) ^^^ 304169) := by decide +kernel

theorem selectedBound14908 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env14909 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,1345,32768,65536,1345,262144,304169,32769,4097,8200,64,98565,8328,303161,33061,1345,307241,295205,1284,4294967296,256,4295074215,1345,512]

theorem envBound14909 : H12AffineFastState.Bounded env14909 := by
  intro p hp
  have h : env14909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14908_14909 : H12AffineEnvironment.transform 18 304169 env14908 = env14909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 304169 env14908 == env14909) = true)

end H12CloudChart2