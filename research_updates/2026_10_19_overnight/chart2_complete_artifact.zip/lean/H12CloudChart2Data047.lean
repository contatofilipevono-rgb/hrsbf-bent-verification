import H12CloudChart2Data046

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans11465_11466 : H12AffineEnvironment.transform 2 1 env11465 = env11466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env11465 == env11466) = true)

theorem identity11466 : scanCanonicalize (H12AffineFastState.compose env11466 (packedSelected [10] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound11466 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env11467 : List Nat := [1,4,1,1,1,0,1,5,0,4,0,0,1,1,0,0,0,1,4,0,0,1,1,1,1,0,1,1,1,0,5,1,4,0,1,0]

theorem envBound11467 : H12AffineFastState.Bounded env11467 := by
  intro p hp
  have h : env11467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11466_11467 : H12AffineEnvironment.transform 0 1 env11466 = env11467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env11466 == env11467) = true)

def leafEnv11467 : List Nat := [1,4,1,1,1,0,1,5,0,4,0,0,1,1,0,0,0,1,4,0,0,1,1,1,5,1,1,0,1,1,1,0,5,1,4,0,5,0,1,0,0,0,1]

def active11467 : List Nat := [1]

def tree11467 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood11467 : H12WitnessSearch.Good tree11467 := H12GlobalWitnessIndex.good

theorem leafIdentity11467 : H12AffineFastState.composeSystem env11467 rootObs = leafEnv11467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env11467 rootObs == leafEnv11467) = true)

theorem terminalChecked11467 : H12PackedTerminal.terminalCheckFast leafEnv11467 active11467 tree11467 = true := by decide +kernel

def env11468 : List Nat := [2,4,8,16,32,33,128,36,145,1024,170,1166,176,1215,153,136,1215,171,1211,153,1166,19,154,138,56,171,35,1215,1166,34,1179,184,37,49,1214,145]

theorem envBound11468 : H12AffineFastState.Bounded env11468 := by
  intro p hp
  have h : env11468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11460_11468 : H12AffineEnvironment.transform 8 145 env11460 = env11468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 145 env11460 == env11468) = true)

theorem identity11468 : scanCanonicalize (H12AffineFastState.compose env11468 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 59) := by decide +kernel

theorem selectedBound11468 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env11469 : List Nat := [2,4,8,16,32,33,59,36,42,1024,17,1077,11,1028,34,51,1028,16,1024,34,1077,19,33,49,56,16,35,1028,1077,34,1056,3,37,49,1029,42]

theorem envBound11469 : H12AffineFastState.Bounded env11469 := by
  intro p hp
  have h : env11469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11468_11469 : H12AffineEnvironment.transform 6 59 env11468 = env11469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 59 env11468 == env11469) = true)

theorem identity11469 : scanCanonicalize (H12AffineFastState.compose env11469 (packedSelected [2,4] rootPS)) = affineNative (2^(4+1) ^^^ 19) := by decide +kernel

theorem selectedBound11469 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env11470 : List Nat := [2,4,8,16,19,18,8,23,25,1024,17,1030,11,1028,17,0,1028,16,1024,17,1030,19,18,2,11,16,16,1028,1030,17,1043,3,22,2,1029,25]

theorem envBound11470 : H12AffineFastState.Bounded env11470 := by
  intro p hp
  have h : env11470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11469_11470 : H12AffineEnvironment.transform 4 19 env11469 = env11470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 19 env11469 == env11470) = true)

theorem identity11470 : scanCanonicalize (H12AffineFastState.compose env11470 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound11470 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11471 : List Nat := [2,4,8,11,8,9,8,12,2,1024,10,1030,11,1028,10,0,1028,11,1024,10,1030,8,9,2,11,11,11,1028,1030,10,1032,3,13,2,1029,2]

theorem envBound11471 : H12AffineFastState.Bounded env11471 := by
  intro p hp
  have h : env11471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11470_11471 : H12AffineEnvironment.transform 3 11 env11470 = env11471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env11470 == env11471) = true)

theorem identity11471 : scanCanonicalize (H12AffineFastState.compose env11471 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 13) := by decide +kernel

theorem selectedBound11471 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11472 : List Nat := [2,4,8,11,8,9,8,12,2,13,10,11,11,9,10,0,9,11,13,10,11,8,9,2,11,11,11,9,11,10,5,3,13,2,8,2]

theorem envBound11472 : H12AffineFastState.Bounded env11472 := by
  intro p hp
  have h : env11472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11471_11472 : H12AffineEnvironment.transform 9 13 env11471 = env11472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 13 env11471 == env11472) = true)

theorem identity11472 : scanCanonicalize (H12AffineFastState.compose env11472 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound11472 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env11473 : List Nat := [2,4,3,0,3,2,3,7,2,6,1,0,0,2,1,0,2,0,6,1,0,3,2,2,0,0,0,2,0,1,5,3,6,2,3,2]

theorem envBound11473 : H12AffineFastState.Bounded env11473 := by
  intro p hp
  have h : env11473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11472_11473 : H12AffineEnvironment.transform 2 3 env11472 = env11473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env11472 == env11473) = true)

def leafEnv11473 : List Nat := [2,4,3,0,3,2,3,7,2,6,1,0,0,2,1,0,2,0,6,1,0,3,2,2,5,0,1,0,0,2,0,1,5,3,6,2,5,0,3,2,0,1,1]

def active11473 : List Nat := [0,1]

def tree11473 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood11473 : H12WitnessSearch.Good tree11473 := H12GlobalWitnessIndex.good

theorem leafIdentity11473 : H12AffineFastState.composeSystem env11473 rootObs = leafEnv11473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env11473 rootObs == leafEnv11473) = true)

theorem terminalChecked11473 : H12PackedTerminal.terminalCheckFast leafEnv11473 active11473 tree11473 = true := by decide +kernel

def env11474 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,4096,8192,4177,8233,2082,11460,2049,524288,8233,4097,10249,5236,138,8328,5156,2185,4176,11412,2184,11393,526066,37,10970,11461,512]

theorem envBound11474 : H12AffineFastState.Bounded env11474 := by
  intro p hp
  have h : env11474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11442_11474 : H12AffineEnvironment.transform 13 4177 env11442 = env11474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env11442 == env11474) = true)

theorem identity11474 : scanCanonicalize (H12AffineFastState.compose env11474 (packedSelected [2,4,6,7] rootPS)) = affineNative (2^(18+1) ^^^ 4638) := by decide +kernel

theorem selectedBound11474 : packedSelected [2,4,6,7] rootPS < 2^1333 := by decide +kernel

def env11475 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,4096,8192,4177,8233,2082,11460,2049,4638,8233,4097,10249,5236,138,8328,5156,2185,4176,11412,2184,11393,5356,37,10970,11461,512]

theorem envBound11475 : H12AffineFastState.Bounded env11475 := by
  intro p hp
  have h : env11475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11474_11475 : H12AffineEnvironment.transform 18 4638 env11474 = env11475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4638 env11474 == env11475) = true)

theorem identity11475 : scanCanonicalize (H12AffineFastState.compose env11475 (packedSelected [11] rootPS)) = affineNative (2^(12+1) ^^^ 5300) := by decide +kernel

theorem selectedBound11475 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env11476 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,4096,5300,4177,5277,2082,6256,2049,4638,5277,4097,7357,5236,138,5180,5156,2185,4176,6176,2184,6197,5356,37,7790,6257,512]

theorem envBound11476 : H12AffineFastState.Bounded env11476 := by
  intro p hp
  have h : env11476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11475_11476 : H12AffineEnvironment.transform 12 5300 env11475 = env11476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5300 env11475 == env11476) = true)

theorem identity11476 : scanCanonicalize (H12AffineFastState.compose env11476 (packedSelected [0,2,3,4,5,6,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 3766) := by decide +kernel

theorem selectedBound11476 : packedSelected [0,2,3,4,5,6,10,12] rootPS < 2^1333 := by decide +kernel

def env11477 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,3766,2562,3815,2603,2082,1734,2049,3240,2603,3767,523,2754,138,2698,2706,2185,3814,1686,2184,1667,2650,37,216,1735,512]

theorem envBound11477 : H12AffineFastState.Bounded env11477 := by
  intro p hp
  have h : env11477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11476_11477 : H12AffineEnvironment.transform 11 3766 env11476 = env11477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3766 env11476 == env11477) = true)

theorem identity11477 : scanCanonicalize (H12AffineFastState.compose env11477 (packedSelected [1,3,6] rootPS)) = affineNative (2^(10+1) ^^^ 168) := by decide +kernel

theorem selectedBound11477 : packedSelected [1,3,6] rootPS < 2^1333 := by decide +kernel

def env11478 : List Nat := [2,4,8,16,32,64,128,36,512,1024,168,1566,682,1615,643,138,1734,169,1024,643,1567,523,618,138,546,570,33,1614,1686,32,1667,754,37,216,1735,512]

theorem envBound11478 : H12AffineFastState.Bounded env11478 := by
  intro p hp
  have h : env11478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11477_11478 : H12AffineEnvironment.transform 10 168 env11477 = env11478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 168 env11477 == env11478) = true)

theorem identity11478 : scanCanonicalize (H12AffineFastState.compose env11478 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound11478 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env11479 : List Nat := [2,4,8,16,32,64,128,36,43,1024,168,1077,129,1124,168,138,1261,169,1024,168,1076,32,65,138,9,17,33,1125,1213,32,1192,217,37,216,1260,43]

theorem envBound11479 : H12AffineFastState.Bounded env11479 := by
  intro p hp
  have h : env11479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11478_11479 : H12AffineEnvironment.transform 8 43 env11478 = env11479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env11478 == env11479) = true)

theorem identity11479 : scanCanonicalize (H12AffineFastState.compose env11479 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 115) := by decide +kernel

theorem selectedBound11479 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11480 : List Nat := [2,4,8,16,32,64,115,36,43,1024,91,1077,114,1124,91,121,1054,90,1024,91,1076,32,65,121,9,17,33,1125,1102,32,1115,42,37,43,1055,43]

theorem envBound11480 : H12AffineFastState.Bounded env11480 := by
  intro p hp
  have h : env11480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11479_11480 : H12AffineEnvironment.transform 6 115 env11479 = env11480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 115 env11479 == env11480) = true)

theorem identity11480 : scanCanonicalize (H12AffineFastState.compose env11480 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound11480 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env11481 : List Nat := [2,4,8,16,32,59,8,36,43,1024,32,1077,9,1055,32,2,1054,33,1024,32,1076,32,58,2,9,17,33,1054,1077,32,1056,42,37,43,1055,43]

theorem envBound11481 : H12AffineFastState.Bounded env11481 := by
  intro p hp
  have h : env11481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11480_11481 : H12AffineEnvironment.transform 5 59 env11480 = env11481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env11480 == env11481) = true)

theorem identity11481 : scanCanonicalize (H12AffineFastState.compose env11481 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound11481 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11482 : List Nat := [2,4,0,16,32,51,0,36,35,1024,32,1077,1,1047,32,2,1046,33,1024,32,1076,32,50,2,1,17,33,1046,1077,32,1056,34,37,35,1047,35]

theorem envBound11482 : H12AffineFastState.Bounded env11482 := by
  intro p hp
  have h : env11482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11481_11482 : H12AffineEnvironment.transform 2 0 env11481 = env11482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env11481 == env11482) = true)

theorem identity11482 : scanCanonicalize (H12AffineFastState.compose env11482 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound11482 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11483 : List Nat := [2,4,0,16,32,51,0,36,35,37,32,16,1,50,32,2,51,33,37,32,17,32,50,2,1,17,33,51,16,32,5,34,37,35,50,35]

theorem envBound11483 : H12AffineFastState.Bounded env11483 := by
  intro p hp
  have h : env11483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11482_11483 : H12AffineEnvironment.transform 9 37 env11482 = env11483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env11482 == env11483) = true)

theorem identity11483 : scanCanonicalize (H12AffineFastState.compose env11483 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound11483 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env11484 : List Nat := [2,4,0,16,1,18,0,5,2,4,1,16,1,19,1,2,18,0,4,1,17,1,19,2,1,17,0,18,16,1,5,3,4,2,19,2]

theorem envBound11484 : H12AffineFastState.Bounded env11484 := by
  intro p hp
  have h : env11484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11483_11484 : H12AffineEnvironment.transform 4 1 env11483 = env11484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env11483 == env11484) = true)

def env11485 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,10249,17665,230469,8329,2098433,2518044,2117632,131152,1073741824,131141,4294967296,257,4297844918,131073,513]

theorem envBound11485 : H12AffineFastState.Bounded env11485 := by
  intro p hp
  have h : env11485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11415_11485 : H12AffineEnvironment.transform 24 8329 env11415 = env11485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8329 env11415 == env11485) = true)

def env11486 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,8201,17665,230469,8329,2098433,2515996,2117632,131152,1073741824,131141,4294967296,257,4297842870,131073,513]

theorem envBound11486 : H12AffineFastState.Bounded env11486 := by
  intro p hp
  have h : env11486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11485_11486 : H12AffineEnvironment.transform 10 0 env11485 = env11486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env11485 == env11486) = true)

def env11487 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,131072,262144,524288,32768,4096,8201,17665,230469,8329,5377,422940,16384,131152,1073741824,131141,4294967296,257,4295749814,131073,513]

theorem envBound11487 : H12AffineFastState.Bounded env11487 := by
  intro p hp
  have h : env11487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11486_11487 : H12AffineEnvironment.transform 20 4096 env11486 = env11487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env11486 == env11487) = true)

theorem identity11487 : scanCanonicalize (H12AffineFastState.compose env11487 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 33788) := by decide +kernel

theorem selectedBound11487 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env11488 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,131072,262144,524288,32768,4096,8201,17665,230469,8329,5377,422940,16384,131152,33788,131141,4294967296,257,4295749814,131073,513]

theorem envBound11488 : H12AffineFastState.Bounded env11488 := by
  intro p hp
  have h : env11488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11487_11488 : H12AffineEnvironment.transform 29 33788 env11487 = env11488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 33788 env11487 == env11488) = true)

theorem identity11488 : scanCanonicalize (H12AffineFastState.compose env11488 (packedSelected [0,4,6,7,16,20,22,25] rootPS)) = affineNative (2^(18+1) ^^^ 21585) := by decide +kernel

theorem selectedBound11488 : packedSelected [0,4,6,7,16,20,22,25] rootPS < 2^1333 := by decide +kernel

def env11489 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,131072,262144,21585,32768,4096,8201,17665,230469,8329,5377,422940,16384,131152,33788,131141,4294967296,257,4295206119,131073,513]

theorem envBound11489 : H12AffineFastState.Bounded env11489 := by
  intro p hp
  have h : env11489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11488_11489 : H12AffineEnvironment.transform 18 21585 env11488 = env11489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21585 env11488 == env11489) = true)

theorem identity11489 : scanCanonicalize (H12AffineFastState.compose env11489 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 9087) := by decide +kernel

theorem selectedBound11489 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env11490 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,9087,131072,262144,21585,32768,4096,8201,17665,173882,8329,5377,422940,16384,131152,33788,131141,4294967296,257,4295133080,131073,513]

theorem envBound11490 : H12AffineFastState.Bounded env11490 := by
  intro p hp
  have h : env11490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11489_11490 : H12AffineEnvironment.transform 15 9087 env11489 = env11490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9087 env11489 == env11490) = true)

theorem identity11490 : scanCanonicalize (H12AffineFastState.compose env11490 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 4177) := by decide +kernel

theorem selectedBound11490 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env11491 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,4177,32768,9087,131072,262144,1024,32768,4096,8201,5456,173882,8329,5377,402509,4177,131152,33788,131141,4294967296,257,4295133080,131073,513]

theorem envBound11491 : H12AffineFastState.Bounded env11491 := by
  intro p hp
  have h : env11491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11490_11491 : H12AffineEnvironment.transform 13 4177 env11490 = env11491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env11490 == env11491) = true)

theorem identity11491 : scanCanonicalize (H12AffineFastState.compose env11491 (packedSelected [13,21] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound11491 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env11492 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,4177,8540,9087,131072,262144,1024,8540,4096,8201,5456,132710,8329,5377,402509,4177,131152,8864,131141,4294967296,257,4295108292,131073,513]

theorem envBound11492 : H12AffineFastState.Bounded env11492 := by
  intro p hp
  have h : env11492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11491_11492 : H12AffineEnvironment.transform 14 8540 env11491 = env11492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env11491 == env11492) = true)

def env11493 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,131072,262144,524288,32768,4097,8201,17665,230469,8329,5376,422941,16385,131152,1073741824,131141,4294967296,257,4295749815,131073,513]

theorem envBound11493 : H12AffineFastState.Bounded env11493 := by
  intro p hp
  have h : env11493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11486_11493 : H12AffineEnvironment.transform 20 4097 env11486 = env11493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env11486 == env11493) = true)

theorem identity11493 : scanCanonicalize (H12AffineFastState.compose env11493 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 38589) := by decide +kernel

theorem selectedBound11493 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env11494 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,131072,262144,524288,32768,4097,8201,17665,230469,8329,5376,422941,16385,131152,38589,131141,4294967296,257,4295749815,131073,513]

theorem envBound11494 : H12AffineFastState.Bounded env11494 := by
  intro p hp
  have h : env11494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11493_11494 : H12AffineEnvironment.transform 29 38589 env11493 = env11494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 38589 env11493 == env11494) = true)

def env11495 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,4824,262144,524288,32768,4097,8201,17665,104093,8329,5376,288453,16385,4744,38589,4765,4294967296,257,4295615087,4825,513]

theorem envBound11495 : H12AffineFastState.Bounded env11495 := by
  intro p hp
  have h : env11495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11494_11495 : H12AffineEnvironment.transform 16 4824 env11494 = env11495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4824 env11494 == env11495) = true)

theorem identity11495 : scanCanonicalize (H12AffineFastState.compose env11495 (packedSelected [16,18,32] rootPS)) = affineNative (2^(14+1) ^^^ 28793) := by decide +kernel

theorem selectedBound11495 : packedSelected [16,18,32] rootPS < 2^1333 := by decide +kernel

def env11496 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,28793,65536,4824,262144,524288,28793,4097,8201,17665,91876,8329,5376,288453,16385,4744,26308,4765,4294967296,257,4295561750,4825,513]

theorem envBound11496 : H12AffineFastState.Bounded env11496 := by
  intro p hp
  have h : env11496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11495_11496 : H12AffineEnvironment.transform 14 28793 env11495 = env11496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 28793 env11495 == env11496) = true)

theorem identity11496 : scanCanonicalize (H12AffineFastState.compose env11496 (packedSelected [16,23] rootPS)) = affineNative (2^(17+1) ^^^ 0) := by decide +kernel

theorem selectedBound11496 : packedSelected [16,23] rootPS < 2^1333 := by decide +kernel

def env11497 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,28793,65536,4824,0,524288,28793,4097,8201,17665,91876,8329,5376,26309,16385,4744,26308,4765,4294967296,257,4295561750,4825,513]

theorem envBound11497 : H12AffineFastState.Bounded env11497 := by
  intro p hp
  have h : env11497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11496_11497 : H12AffineEnvironment.transform 17 0 env11496 = env11497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 0 env11496 == env11497) = true)

def env11498 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1296,8192,16384,25961,65536,1992,0,524288,25961,1297,8201,17665,91876,8329,16,26309,16385,1944,26308,1933,4294967296,257,4295558918,1993,513]

theorem envBound11498 : H12AffineFastState.Bounded env11498 := by
  intro p hp
  have h : env11498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11497_11498 : H12AffineEnvironment.transform 11 1296 env11497 = env11498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env11497 == env11498) = true)

theorem identity11498 : scanCanonicalize (H12AffineFastState.compose env11498 (packedSelected [0,1,2,3,4,5,6,8,12,13,15,16,17] rootPS)) = affineNative (2^(13+1) ^^^ 1344) := by decide +kernel

theorem selectedBound11498 : packedSelected [0,1,2,3,4,5,6,8,12,13,15,16,17] rootPS < 2^1333 := by decide +kernel

def env11499 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1296,8192,1344,8233,65536,1992,0,524288,8233,1297,8201,65,74660,8329,16,9093,1345,1944,9092,1933,4294967296,257,4295558918,1993,513]

theorem envBound11499 : H12AffineFastState.Bounded env11499 := by
  intro p hp
  have h : env11499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11498_11499 : H12AffineEnvironment.transform 13 1344 env11498 = env11499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env11498 == env11499) = true)

theorem identity11499 : scanCanonicalize (H12AffineFastState.compose env11499 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(18+1) ^^^ 75567) := by decide +kernel

theorem selectedBound11499 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env11500 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1296,8192,1344,8233,65536,1992,0,75567,8233,1297,8201,65,74660,8329,16,9093,1345,1944,9092,1933,4294967296,257,4294975529,1993,513]

theorem envBound11500 : H12AffineFastState.Bounded env11500 := by
  intro p hp
  have h : env11500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11499_11500 : H12AffineEnvironment.transform 18 75567 env11499 = env11500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 75567 env11499 == env11500) = true)

def env11501 : List Nat := [2,4,8,16,32,64,88,256,512,1024,0,1296,8192,1344,8233,65536,1808,0,75567,8233,1297,8201,65,74620,8273,16,9053,1345,1856,9052,1877,4294967296,257,4294975529,1809,513]

theorem envBound11501 : H12AffineFastState.Bounded env11501 := by
  intro p hp
  have h : env11501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11500_11501 : H12AffineEnvironment.transform 6 88 env11500 = env11501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env11500 == env11501) = true)

theorem identity11501 : scanCanonicalize (H12AffineFastState.compose env11501 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound11501 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env11502 : List Nat := [2,4,8,16,32,64,88,256,512,1024,0,1296,40,1344,1,65536,1808,0,67335,1,1297,33,65,66388,121,16,885,1345,1856,884,1877,4294967296,257,4294967297,1809,513]

theorem envBound11502 : H12AffineFastState.Bounded env11502 := by
  intro p hp
  have h : env11502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11501_11502 : H12AffineEnvironment.transform 12 40 env11501 = env11502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env11501 == env11502) = true)

theorem identity11502 : scanCanonicalize (H12AffineFastState.compose env11502 (packedSelected [0,1,5,7,10] rootPS)) = affineNative (2^(8+1) ^^^ 372) := by decide +kernel

theorem selectedBound11502 : packedSelected [0,1,5,7,10] rootPS < 2^1333 := by decide +kernel

def env11503 : List Nat := [2,4,8,16,32,64,88,256,372,1024,0,1296,40,1344,1,65536,1124,0,66675,1,1297,33,65,65568,121,16,1,1345,1076,0,1057,4294967296,257,4294967297,1125,373]

theorem envBound11503 : H12AffineFastState.Bounded env11503 := by
  intro p hp
  have h : env11503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11502_11503 : H12AffineEnvironment.transform 8 372 env11502 = env11503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 372 env11502 == env11503) = true)

theorem identity11503 : scanCanonicalize (H12AffineFastState.compose env11503 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(31+1) ^^^ 106) := by decide +kernel

theorem selectedBound11503 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env11504 : List Nat := [2,4,8,16,32,64,88,256,372,1024,0,1296,40,1344,1,65536,1124,0,66675,1,1297,33,65,65568,121,16,1,1345,1076,0,1057,106,257,107,1125,373]

theorem envBound11504 : H12AffineFastState.Bounded env11504 := by
  intro p hp
  have h : env11504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11503_11504 : H12AffineEnvironment.transform 31 106 env11503 = env11504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 106 env11503 == env11504) = true)

theorem identity11504 : scanCanonicalize (H12AffineFastState.compose env11504 (packedSelected [1,5,13] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound11504 : packedSelected [1,5,13] rootPS < 2^1333 := by decide +kernel

def env11505 : List Nat := [2,4,8,16,32,64,88,37,81,1024,0,1077,40,1125,1,65536,1124,0,66675,1,1076,33,65,65568,121,16,1,1124,1076,0,1057,106,36,107,1125,80]

theorem envBound11505 : H12AffineFastState.Bounded env11505 := by
  intro p hp
  have h : env11505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11504_11505 : H12AffineEnvironment.transform 7 37 env11504 = env11505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env11504 == env11505) = true)

theorem identity11505 : scanCanonicalize (H12AffineFastState.compose env11505 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound11505 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11506 : List Nat := [2,4,8,1,32,64,73,37,64,1024,0,1060,40,1125,1,65536,1124,0,66658,1,1061,33,65,65568,104,1,1,1124,1061,0,1057,106,36,107,1125,65]

theorem envBound11506 : H12AffineFastState.Bounded env11506 := by
  intro p hp
  have h : env11506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11505_11506 : H12AffineEnvironment.transform 3 1 env11505 = env11506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env11505 == env11506) = true)

def env11507 : List Nat := [2,4,8,1,32,64,73,37,64,1024,0,1060,40,1125,1,8,1124,0,1130,1,1061,33,65,40,104,1,1,1124,1061,0,1057,106,36,107,1125,65]

theorem envBound11507 : H12AffineFastState.Bounded env11507 := by
  intro p hp
  have h : env11507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11506_11507 : H12AffineEnvironment.transform 15 8 env11506 = env11507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8 env11506 == env11507) = true)

theorem identity11507 : scanCanonicalize (H12AffineFastState.compose env11507 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 43) := by decide +kernel

theorem selectedBound11507 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11508 : List Nat := [2,4,8,1,32,43,34,37,43,1024,0,1060,40,1038,1,8,1039,0,1025,1,1061,33,42,40,3,1,1,1039,1061,0,1057,1,36,0,1038,42]

theorem envBound11508 : H12AffineFastState.Bounded env11508 := by
  intro p hp
  have h : env11508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11507_11508 : H12AffineEnvironment.transform 5 43 env11507 = env11508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 43 env11507 == env11508) = true)

theorem identity11508 : scanCanonicalize (H12AffineFastState.compose env11508 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound11508 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11509 : List Nat := [2,4,8,1,0,11,2,5,11,1024,0,1028,8,1038,1,8,1039,0,1025,1,1029,1,10,8,3,1,1,1039,1029,0,1025,1,4,0,1038,10]

theorem envBound11509 : H12AffineFastState.Bounded env11509 := by
  intro p hp
  have h : env11509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11508_11509 : H12AffineEnvironment.transform 4 0 env11508 = env11509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env11508 == env11509) = true)

def leafEnv11509 : List Nat := [2,4,8,1,0,11,2,5,11,1024,0,1028,8,1038,1,8,1039,0,1025,1,1029,1,10,8,1024,3,1,1,1,1039,1029,0,1025,1,4,0,5,3,1038,10,0,1028,1]

def active11509 : List Nat := [0,1,2,9]

def tree11509 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood11509 : H12WitnessSearch.Good tree11509 := H12GlobalWitnessIndex.good

theorem leafIdentity11509 : H12AffineFastState.composeSystem env11509 rootObs = leafEnv11509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env11509 rootObs == leafEnv11509) = true)

theorem terminalChecked11509 : H12PackedTerminal.terminalCheckFast leafEnv11509 active11509 tree11509 = true := by decide +kernel

def env11510 : List Nat := [2,4,8,1,32,64,73,37,64,1024,0,1060,40,1125,1,9,1124,0,1131,1,1061,33,65,41,104,1,1,1124,1061,0,1057,106,36,107,1125,65]

theorem envBound11510 : H12AffineFastState.Bounded env11510 := by
  intro p hp
  have h : env11510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11506_11510 : H12AffineEnvironment.transform 15 9 env11506 = env11510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9 env11506 == env11510) = true)

def env11511 : List Nat := [2,4,8,16,32,64,89,256,512,1024,0,1296,8192,1344,8233,65536,1809,0,75567,8233,1297,8201,65,74621,8272,16,9052,1345,1857,9053,1876,4294967296,257,4294975529,1808,513]

theorem envBound11511 : H12AffineFastState.Bounded env11511 := by
  intro p hp
  have h : env11511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11500_11511 : H12AffineEnvironment.transform 6 89 env11500 = env11511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env11500 == env11511) = true)

theorem identity11511 : scanCanonicalize (H12AffineFastState.compose env11511 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(15+1) ^^^ 775) := by decide +kernel

theorem selectedBound11511 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env11512 : List Nat := [2,4,8,16,32,64,89,256,512,1024,0,1296,8192,1344,8233,775,1809,0,9256,8233,1297,8201,65,8314,8272,16,9052,1345,1857,9053,1876,4294967296,257,4294975529,1808,513]

theorem envBound11512 : H12AffineFastState.Bounded env11512 := by
  intro p hp
  have h : env11512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11511_11512 : H12AffineEnvironment.transform 15 775 env11511 = env11512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 775 env11511 == env11512) = true)

theorem identity11512 : scanCanonicalize (H12AffineFastState.compose env11512 (packedSelected [1,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 373) := by decide +kernel

theorem selectedBound11512 : packedSelected [1,5,10] rootPS < 2^1333 := by decide +kernel

def env11513 : List Nat := [2,4,8,16,32,64,89,256,373,1024,0,1296,8192,1344,8233,114,1124,0,9256,8233,1297,8201,65,8314,8272,16,8233,1345,1076,8232,1057,4294967296,257,4294975529,1125,372]

theorem envBound11513 : H12AffineFastState.Bounded env11513 := by
  intro p hp
  have h : env11513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11512_11513 : H12AffineEnvironment.transform 8 373 env11512 = env11513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 373 env11512 == env11513) = true)

theorem identity11513 : scanCanonicalize (H12AffineFastState.compose env11513 (packedSelected [1,5,13] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound11513 : packedSelected [1,5,13] rootPS < 2^1333 := by decide +kernel

def env11514 : List Nat := [2,4,8,16,32,64,89,37,80,1024,0,1077,8192,1125,8233,114,1124,0,9256,8233,1076,8201,65,8314,8272,16,8233,1124,1076,8232,1057,4294967296,36,4294975529,1125,81]

theorem envBound11514 : H12AffineFastState.Bounded env11514 := by
  intro p hp
  have h : env11514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11513_11514 : H12AffineEnvironment.transform 7 37 env11513 = env11514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env11513 == env11514) = true)

theorem identity11514 : scanCanonicalize (H12AffineFastState.compose env11514 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 8275) := by decide +kernel

theorem selectedBound11514 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11515 : List Nat := [2,4,8,16,32,64,89,37,80,1024,0,1077,8192,1125,8233,114,1124,0,9256,8233,1076,8201,65,8314,8272,16,8233,1124,1076,8232,1057,8275,36,122,1125,81]

theorem envBound11515 : H12AffineFastState.Bounded env11515 := by
  intro p hp
  have h : env11515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11514_11515 : H12AffineEnvironment.transform 31 8275 env11514 = env11515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 8275 env11514 == env11515) = true)

theorem identity11515 : scanCanonicalize (H12AffineFastState.compose env11515 (packedSelected [2,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound11515 : packedSelected [2,4,5] rootPS < 2^1333 := by decide +kernel

def env11516 : List Nat := [2,4,8,16,32,64,89,37,80,1024,0,1077,40,1125,1,114,1124,0,1024,1,1076,33,65,82,120,16,1,1124,1076,0,1057,123,36,122,1125,81]

theorem envBound11516 : H12AffineFastState.Bounded env11516 := by
  intro p hp
  have h : env11516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11515_11516 : H12AffineEnvironment.transform 12 40 env11515 = env11516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env11515 == env11516) = true)

theorem identity11516 : scanCanonicalize (H12AffineFastState.compose env11516 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound11516 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11517 : List Nat := [2,4,8,0,32,64,73,37,64,1024,0,1061,40,1125,1,98,1124,0,1024,1,1060,33,65,66,104,0,1,1124,1060,0,1057,107,36,106,1125,65]

theorem envBound11517 : H12AffineFastState.Bounded env11517 := by
  intro p hp
  have h : env11517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11516_11517 : H12AffineEnvironment.transform 3 0 env11516 = env11517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env11516 == env11517) = true)

def leafEnv11517 : List Nat := [2,4,8,0,32,64,73,37,64,1024,0,1061,40,1125,1,98,1124,0,1024,1,1060,33,65,66,1057,104,1,0,1,1124,1060,0,1057,107,36,106,5,35,1125,65,0,1061,1]

def active11517 : List Nat := [0,1,2,4,5,9]

def tree11517 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood11517 : H12WitnessSearch.Good tree11517 := H12GlobalWitnessIndex.good

theorem leafIdentity11517 : H12AffineFastState.composeSystem env11517 rootObs = leafEnv11517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env11517 rootObs == leafEnv11517) = true)

theorem terminalChecked11517 : H12PackedTerminal.terminalCheckFast leafEnv11517 active11517 tree11517 = true := by decide +kernel

def env11518 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1297,8192,16384,25960,65536,1993,0,524288,25960,1296,8201,17665,91876,8329,17,26309,16385,1945,26308,1932,4294967296,257,4295558919,1992,513]

theorem envBound11518 : H12AffineFastState.Bounded env11518 := by
  intro p hp
  have h : env11518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11497_11518 : H12AffineEnvironment.transform 11 1297 env11497 = env11518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env11497 == env11518) = true)

theorem identity11518 : scanCanonicalize (H12AffineFastState.compose env11518 (packedSelected [0,1,2,3,4,5,6,8,12,13,15,16,17] rootPS)) = affineNative (2^(15+1) ^^^ 8614) := by decide +kernel

theorem selectedBound11518 : packedSelected [0,1,2,3,4,5,6,8,12,13,15,16,17] rootPS < 2^1333 := by decide +kernel

def env11519 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1297,8192,16384,25960,8614,1993,0,524288,25960,1296,8201,17665,18242,8329,17,26309,16385,1945,26308,1932,4294967296,257,4295501473,1992,513]

theorem envBound11519 : H12AffineFastState.Bounded env11519 := by
  intro p hp
  have h : env11519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11518_11519 : H12AffineEnvironment.transform 15 8614 env11518 = env11519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8614 env11518 == env11519) = true)

def env11520 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,4825,262144,524288,32768,4097,8201,17665,104092,8329,5376,288452,16385,4745,38589,4764,4294967296,257,4295615086,4824,513]

theorem envBound11520 : H12AffineFastState.Bounded env11520 := by
  intro p hp
  have h : env11520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11494_11520 : H12AffineEnvironment.transform 16 4825 env11494 = env11520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4825 env11494 == env11520) = true)

theorem identity11520 : scanCanonicalize (H12AffineFastState.compose env11520 (packedSelected [16,18,32] rootPS)) = affineNative (2^(17+1) ^^^ 1) := by decide +kernel

theorem selectedBound11520 : packedSelected [16,18,32] rootPS < 2^1333 := by decide +kernel

def env11521 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,4825,1,524288,32768,4097,8201,17665,104092,8329,5376,26309,16385,4745,38589,4764,4294967296,257,4295615086,4824,513]

theorem envBound11521 : H12AffineFastState.Bounded env11521 := by
  intro p hp
  have h : env11521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11520_11521 : H12AffineEnvironment.transform 17 1 env11520 = env11521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1 env11520 == env11521) = true)

theorem identity11521 : scanCanonicalize (H12AffineFastState.compose env11521 (packedSelected [18,20] rootPS)) = affineNative (2^(14+1) ^^^ 28792) := by decide +kernel

theorem selectedBound11521 : packedSelected [18,20] rootPS < 2^1333 := by decide +kernel

def env11522 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,28792,65536,4825,1,524288,28792,4097,8201,17665,91876,8329,5376,26309,16385,4745,26309,4764,4294967296,257,4295561750,4824,513]

theorem envBound11522 : H12AffineFastState.Bounded env11522 := by
  intro p hp
  have h : env11522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11521_11522 : H12AffineEnvironment.transform 14 28792 env11521 = env11522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 28792 env11521 == env11522) = true)

def env11523 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1296,8192,16384,25960,65536,1993,1,524288,25960,1297,8201,17665,91876,8329,16,26309,16385,1945,26309,1932,4294967296,257,4295558918,1992,513]

theorem envBound11523 : H12AffineFastState.Bounded env11523 := by
  intro p hp
  have h : env11523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11522_11523 : H12AffineEnvironment.transform 11 1296 env11522 = env11523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env11522 == env11523) = true)

theorem identity11523 : scanCanonicalize (H12AffineFastState.compose env11523 (packedSelected [0,1,2,3,4,5,6,8,12,13,15,16,17] rootPS)) = affineNative (2^(15+1) ^^^ 17899) := by decide +kernel

theorem selectedBound11523 : packedSelected [0,1,2,3,4,5,6,8,12,13,15,16,17] rootPS < 2^1333 := by decide +kernel

def env11524 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1296,8192,16384,25960,17899,1993,1,524288,25960,1297,8201,17665,8975,8329,16,26309,16385,1945,26309,1932,4294967296,257,4295508717,1992,513]

theorem envBound11524 : H12AffineFastState.Bounded env11524 := by
  intro p hp
  have h : env11524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11523_11524 : H12AffineEnvironment.transform 15 17899 env11523 = env11524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 17899 env11523 == env11524) = true)

theorem identity11524 : scanCanonicalize (H12AffineFastState.compose env11524 (packedSelected [0,1,2,4,5,6,12,13,15] rootPS)) = affineNative (2^(18+1) ^^^ 17353) := by decide +kernel

theorem selectedBound11524 : packedSelected [0,1,2,4,5,6,12,13,15] rootPS < 2^1333 := by decide +kernel

def env11525 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1296,8192,16384,25960,17899,1993,1,17353,25960,1297,8201,17665,8975,8329,16,26309,16385,1945,26309,1932,4294967296,257,4294967588,1992,513]

theorem envBound11525 : H12AffineFastState.Bounded env11525 := by
  intro p hp
  have h : env11525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11524_11525 : H12AffineEnvironment.transform 18 17353 env11524 = env11525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 17353 env11524 == env11525) = true)

theorem identity11525 : scanCanonicalize (H12AffineFastState.compose env11525 (packedSelected [0,7] rootPS)) = affineNative (2^(13+1) ^^^ 1992) := by decide +kernel

theorem selectedBound11525 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env11526 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1296,8192,1992,8864,547,1993,1,1025,8864,1297,8201,713,8975,8329,16,8461,1993,1945,8461,1932,4294967296,257,4294967588,1992,513]

theorem envBound11526 : H12AffineFastState.Bounded env11526 := by
  intro p hp
  have h : env11526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11525_11526 : H12AffineEnvironment.transform 13 1992 env11525 = env11526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1992 env11525 == env11526) = true)

theorem identity11526 : scanCanonicalize (H12AffineFastState.compose env11526 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(12+1) ^^^ 900) := by decide +kernel

theorem selectedBound11526 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env11527 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1296,900,1992,292,547,1993,1,1025,292,1297,909,713,139,781,16,649,1993,1945,649,1932,4294967296,257,4294967588,1992,513]

theorem envBound11527 : H12AffineFastState.Bounded env11527 := by
  intro p hp
  have h : env11527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11526_11527 : H12AffineEnvironment.transform 12 900 env11526 = env11527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 900 env11526 == env11527) = true)

theorem identity11527 : scanCanonicalize (H12AffineFastState.compose env11527 (packedSelected [1,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 428) := by decide +kernel

theorem selectedBound11527 : packedSelected [1,5,10] rootPS < 2^1333 := by decide +kernel

def env11528 : List Nat := [2,4,8,16,32,64,128,256,428,1024,0,1296,40,1124,292,399,1125,1,1025,292,1297,33,357,139,161,16,293,1125,1077,293,1056,4294967296,257,4294967588,1124,429]

theorem envBound11528 : H12AffineFastState.Bounded env11528 := by
  intro p hp
  have h : env11528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11527_11528 : H12AffineEnvironment.transform 8 428 env11527 = env11528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 428 env11527 == env11528) = true)

theorem identity11528 : scanCanonicalize (H12AffineFastState.compose env11528 (packedSelected [5,8] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound11528 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env11529 : List Nat := [2,4,8,16,32,64,128,36,136,1024,0,1076,40,1124,0,171,1125,1,1025,0,1077,33,65,139,161,16,1,1125,1077,1,1056,4294967296,37,4294967296,1124,137]

theorem envBound11529 : H12AffineFastState.Bounded env11529 := by
  intro p hp
  have h : env11529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11528_11529 : H12AffineEnvironment.transform 7 36 env11528 = env11529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env11528 == env11529) = true)

theorem identity11529 : scanCanonicalize (H12AffineFastState.compose env11529 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 242) := by decide +kernel

theorem selectedBound11529 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11530 : List Nat := [2,4,8,16,32,64,128,36,136,1024,0,1076,40,1124,0,171,1125,1,1025,0,1077,33,65,139,161,16,1,1125,1077,1,1056,242,37,242,1124,137]

theorem envBound11530 : H12AffineFastState.Bounded env11530 := by
  intro p hp
  have h : env11530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11529_11530 : H12AffineEnvironment.transform 31 242 env11529 = env11530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 242 env11529 == env11530) = true)

theorem identity11530 : scanCanonicalize (H12AffineFastState.compose env11530 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 199) := by decide +kernel

theorem selectedBound11530 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11531 : List Nat := [2,4,8,16,32,64,128,36,136,199,0,243,40,163,0,171,162,1,198,0,242,33,65,139,161,16,1,162,242,1,231,242,37,242,163,137]

theorem envBound11531 : H12AffineFastState.Bounded env11531 := by
  intro p hp
  have h : env11531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11530_11531 : H12AffineEnvironment.transform 9 199 env11530 = env11531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 199 env11530 == env11531) = true)

theorem identity11531 : scanCanonicalize (H12AffineFastState.compose env11531 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound11531 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11532 : List Nat := [2,4,8,16,32,64,18,36,26,85,0,97,40,49,0,57,48,1,84,0,96,33,65,25,51,16,1,48,96,1,117,96,37,96,49,27]

theorem envBound11532 : H12AffineFastState.Bounded env11532 := by
  intro p hp
  have h : env11532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11531_11532 : H12AffineEnvironment.transform 6 18 env11531 = env11532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env11531 == env11532) = true)

theorem identity11532 : scanCanonicalize (H12AffineFastState.compose env11532 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound11532 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env11533 : List Nat := [2,4,8,11,32,64,9,36,1,78,0,97,40,42,0,34,43,1,79,0,96,33,65,2,40,11,1,43,96,1,110,96,37,96,42,0]

theorem envBound11533 : H12AffineFastState.Bounded env11533 := by
  intro p hp
  have h : env11533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11532_11533 : H12AffineEnvironment.transform 3 11 env11532 = env11533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env11532 == env11533) = true)

theorem identity11533 : scanCanonicalize (H12AffineFastState.compose env11533 (packedSelected [4] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound11533 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env11534 : List Nat := [2,4,8,11,32,11,9,36,1,5,0,42,40,42,0,34,43,1,4,0,43,33,10,2,40,11,1,43,43,1,37,43,37,43,42,0]

theorem envBound11534 : H12AffineFastState.Bounded env11534 := by
  intro p hp
  have h : env11534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11533_11534 : H12AffineEnvironment.transform 5 11 env11533 = env11534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env11533 == env11534) = true)

theorem identity11534 : scanCanonicalize (H12AffineFastState.compose env11534 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound11534 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env11535 : List Nat := [2,4,8,11,1,11,9,5,1,5,0,11,9,11,0,3,10,1,4,0,10,0,10,2,9,11,1,10,10,1,4,10,4,10,11,0]

theorem envBound11535 : H12AffineFastState.Bounded env11535 := by
  intro p hp
  have h : env11535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11534_11535 : H12AffineEnvironment.transform 4 1 env11534 = env11535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env11534 == env11535) = true)

def env11536 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1297,8192,16384,25961,65536,1992,1,524288,25961,1296,8201,17665,91876,8329,17,26309,16385,1944,26309,1933,4294967296,257,4295558919,1993,513]

theorem envBound11536 : H12AffineFastState.Bounded env11536 := by
  intro p hp
  have h : env11536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11522_11536 : H12AffineEnvironment.transform 11 1297 env11522 = env11536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env11522 == env11536) = true)

theorem identity11536 : scanCanonicalize (H12AffineFastState.compose env11536 (packedSelected [0,1,2,3,4,5,6,8,12,13,15,16,17] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound11536 : packedSelected [0,1,2,3,4,5,6,8,12,13,15,16,17] rootPS < 2^1333 := by decide +kernel

def env11537 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1297,268,16384,17509,65536,1992,1,524288,17509,1296,261,17665,83944,389,17,18377,16385,1944,18377,1933,4294967296,257,4295558919,1993,513]

theorem envBound11537 : H12AffineFastState.Bounded env11537 := by
  intro p hp
  have h : env11537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11536_11537 : H12AffineEnvironment.transform 12 268 env11536 = env11537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env11536 == env11537) = true)

theorem identity11537 : scanCanonicalize (H12AffineFastState.compose env11537 (packedSelected [2,3,5,6,7,9,10,12] rootPS)) = affineNative (2^(18+1) ^^^ 16704) := by decide +kernel

theorem selectedBound11537 : packedSelected [2,3,5,6,7,9,10,12] rootPS < 2^1333 := by decide +kernel

def env11538 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1297,268,16384,17509,65536,1992,1,16704,17509,1296,261,17665,83944,389,17,18377,16385,1944,18377,1933,4294967296,257,4295050823,1993,513]

theorem envBound11538 : H12AffineFastState.Bounded env11538 := by
  intro p hp
  have h : env11538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11537_11538 : H12AffineEnvironment.transform 18 16704 env11537 = env11538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 16704 env11537 == env11538) = true)

theorem identity11538 : scanCanonicalize (H12AffineFastState.compose env11538 (packedSelected [4,9] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound11538 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env11539 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,1297,268,16384,17509,65536,1345,1,16704,17509,1296,261,17665,83297,389,17,17728,16385,1297,17728,1284,4294967296,257,4295050446,1344,136]

theorem envBound11539 : H12AffineFastState.Bounded env11539 := by
  intro p hp
  have h : env11539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11538_11539 : H12AffineEnvironment.transform 8 137 env11538 = env11539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env11538 == env11539) = true)

theorem identity11539 : scanCanonicalize (H12AffineFastState.compose env11539 (packedSelected [0,7] rootPS)) = affineNative (2^(15+1) ^^^ 170) := by decide +kernel

theorem selectedBound11539 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env11540 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,1297,268,16384,17509,170,1345,1,16704,17509,1296,261,17665,17867,389,17,17728,16385,1297,17728,1284,4294967296,257,4294984804,1344,136]

theorem envBound11540 : H12AffineFastState.Bounded env11540 := by
  intro p hp
  have h : env11540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11539_11540 : H12AffineEnvironment.transform 15 170 env11539 = env11540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 170 env11539 == env11540) = true)

theorem identity11540 : scanCanonicalize (H12AffineFastState.compose env11540 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(13+1) ^^^ 1345) := by decide +kernel

theorem selectedBound11540 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env11541 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,1297,268,1345,292,170,1345,1,1025,292,1296,261,64,138,389,17,1,1344,1297,1,1284,4294967296,257,4294967589,1344,136]

theorem envBound11541 : H12AffineFastState.Bounded env11541 := by
  intro p hp
  have h : env11541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11540_11541 : H12AffineEnvironment.transform 13 1345 env11540 = env11541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env11540 == env11541) = true)

theorem identity11541 : scanCanonicalize (H12AffineFastState.compose env11541 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound11541 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env11542 : List Nat := [2,4,8,16,32,64,128,252,137,1024,0,1261,240,1213,216,170,1213,1,1025,216,1260,249,64,138,121,17,1,1212,1261,1,1272,4294967296,253,4294967513,1212,136]

theorem envBound11542 : H12AffineFastState.Bounded env11542 := by
  intro p hp
  have h : env11542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11541_11542 : H12AffineEnvironment.transform 7 252 env11541 = env11542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env11541 == env11542) = true)

theorem identity11542 : scanCanonicalize (H12AffineFastState.compose env11542 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 114) := by decide +kernel

theorem selectedBound11542 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env11543 : List Nat := [2,4,8,16,32,64,114,14,123,1024,0,1055,2,1103,42,88,1103,1,1025,42,1054,11,64,120,121,17,1,1102,1055,1,1034,4294967296,15,4294967339,1102,122]

theorem envBound11543 : H12AffineFastState.Bounded env11543 := by
  intro p hp
  have h : env11543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11542_11543 : H12AffineEnvironment.transform 6 114 env11542 = env11543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 114 env11542 == env11543) = true)

theorem identity11543 : scanCanonicalize (H12AffineFastState.compose env11543 (packedSelected [2,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound11543 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env11544 : List Nat := [2,4,8,16,0,64,82,14,91,1024,0,1055,2,1103,10,88,1103,1,1025,10,1054,11,64,88,89,17,1,1102,1055,1,1034,4294967296,15,4294967307,1102,90]

theorem envBound11544 : H12AffineFastState.Bounded env11544 := by
  intro p hp
  have h : env11544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11543_11544 : H12AffineEnvironment.transform 4 0 env11543 = env11544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env11543 == env11544) = true)

def env11545 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,8200,17665,230469,8329,2098433,2515997,2117632,131152,1073741824,131141,4294967296,257,4297842871,131073,513]

theorem envBound11545 : H12AffineFastState.Bounded env11545 := by
  intro p hp
  have h : env11545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11485_11545 : H12AffineEnvironment.transform 10 1 env11485 = env11545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env11485 == env11545) = true)

def env11546 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,131072,262144,524288,32768,4096,8200,17665,230469,8329,5377,422941,16384,131152,1073741824,131141,4294967296,257,4295749815,131073,513]

theorem envBound11546 : H12AffineFastState.Bounded env11546 := by
  intro p hp
  have h : env11546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11545_11546 : H12AffineEnvironment.transform 20 4096 env11545 = env11546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env11545 == env11546) = true)

theorem identity11546 : scanCanonicalize (H12AffineFastState.compose env11546 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 291717) := by decide +kernel

theorem selectedBound11546 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env11547 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,131072,262144,524288,32768,4096,8200,17665,230469,8329,5377,422941,16384,131152,291717,131141,4294967296,257,4295749815,131073,513]

theorem envBound11547 : H12AffineFastState.Bounded env11547 := by
  intro p hp
  have h : env11547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11546_11547 : H12AffineEnvironment.transform 29 291717 env11546 = env11547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 291717 env11546 == env11547) = true)

theorem identity11547 : scanCanonicalize (H12AffineFastState.compose env11547 (packedSelected [0,4,6,7,16,20,22,25] rootPS)) = affineNative (2^(18+1) ^^^ 21585) := by decide +kernel

theorem selectedBound11547 : packedSelected [0,4,6,7,16,20,22,25] rootPS < 2^1333 := by decide +kernel

def env11548 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,131072,262144,21585,32768,4096,8200,17665,230469,8329,5377,422941,16384,131152,291717,131141,4294967296,257,4295206118,131073,513]

theorem envBound11548 : H12AffineFastState.Bounded env11548 := by
  intro p hp
  have h : env11548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11547_11548 : H12AffineEnvironment.transform 18 21585 env11547 = env11548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21585 env11547 == env11548) = true)

theorem identity11548 : scanCanonicalize (H12AffineFastState.compose env11548 (packedSelected [4,9,16] rootPS)) = affineNative (2^(17+1) ^^^ 119558) := by decide +kernel

theorem selectedBound11548 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env11549 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,131072,119558,21585,32768,4096,8200,17665,230469,8329,5377,239387,16384,131152,106627,131141,4294967296,257,4295206118,131073,513]

theorem envBound11549 : H12AffineFastState.Bounded env11549 := by
  intro p hp
  have h : env11549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11548_11549 : H12AffineEnvironment.transform 17 119558 env11548 = env11549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 119558 env11548 == env11549) = true)

theorem identity11549 : scanCanonicalize (H12AffineFastState.compose env11549 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 4177) := by decide +kernel

theorem selectedBound11549 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env11550 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,4177,32768,65536,131072,99159,1024,32768,4096,8200,5456,230469,8329,5377,239387,4177,131152,106627,131141,4294967296,257,4295206118,131073,513]

theorem envBound11550 : H12AffineFastState.Bounded env11550 := by
  intro p hp
  have h : env11550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11549_11550 : H12AffineEnvironment.transform 13 4177 env11549 = env11550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env11549 == env11550) = true)

theorem identity11550 : scanCanonicalize (H12AffineFastState.compose env11550 (packedSelected [13,21] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound11550 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env11551 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,4177,8540,65536,131072,74251,1024,8540,4096,8200,5456,206105,8329,5377,198215,4177,131152,66015,131141,4294967296,257,4295165370,131073,513]

theorem envBound11551 : H12AffineFastState.Bounded env11551 := by
  intro p hp
  have h : env11551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11550_11551 : H12AffineEnvironment.transform 14 8540 env11550 = env11551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env11550 == env11551) = true)

def env11552 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,131072,262144,524288,32768,4097,8200,17665,230469,8329,5376,422940,16385,131152,1073741824,131141,4294967296,257,4295749814,131073,513]

theorem envBound11552 : H12AffineFastState.Bounded env11552 := by
  intro p hp
  have h : env11552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11545_11552 : H12AffineEnvironment.transform 20 4097 env11545 = env11552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env11545 == env11552) = true)

theorem identity11552 : scanCanonicalize (H12AffineFastState.compose env11552 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 288453) := by decide +kernel

theorem selectedBound11552 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env11553 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,131072,262144,524288,32768,4097,8200,17665,230469,8329,5376,422940,16385,131152,288453,131141,4294967296,257,4295749814,131073,513]

theorem envBound11553 : H12AffineFastState.Bounded env11553 := by
  intro p hp
  have h : env11553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11552_11553 : H12AffineEnvironment.transform 29 288453 env11552 = env11553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 288453 env11552 == env11553) = true)

def env11554 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,131072,189088,524288,32768,4097,8200,17665,230469,8329,5376,38588,16385,131152,164965,131141,4294967296,257,4295749814,131073,513]

theorem envBound11554 : H12AffineFastState.Bounded env11554 := by
  intro p hp
  have h : env11554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11553_11554 : H12AffineEnvironment.transform 17 189088 env11553 = env11554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 189088 env11553 == env11554) = true)

theorem identity11554 : scanCanonicalize (H12AffineFastState.compose env11554 (packedSelected [16,18,32] rootPS)) = affineNative (2^(14+1) ^^^ 28793) := by decide +kernel

theorem selectedBound11554 : packedSelected [16,18,32] rootPS < 2^1333 := by decide +kernel

def env11555 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,28793,65536,131072,135897,524288,28793,4097,8200,17665,226364,8329,5376,26309,16385,131152,160796,131141,4294967296,257,4295688399,131073,513]

theorem envBound11555 : H12AffineFastState.Bounded env11555 := by
  intro p hp
  have h : env11555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11554_11555 : H12AffineEnvironment.transform 14 28793 env11554 = env11555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 28793 env11554 == env11555) = true)

theorem identity11555 : scanCanonicalize (H12AffineFastState.compose env11555 (packedSelected [16,23] rootPS)) = affineNative (2^(16+1) ^^^ 4824) := by decide +kernel

theorem selectedBound11555 : packedSelected [16,23] rootPS < 2^1333 := by decide +kernel

def env11556 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,28793,65536,4824,1,524288,28793,4097,8200,17665,91876,8329,5376,26309,16385,4744,26308,4765,4294967296,257,4295561751,4825,513]

theorem envBound11556 : H12AffineFastState.Bounded env11556 := by
  intro p hp
  have h : env11556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11555_11556 : H12AffineEnvironment.transform 16 4824 env11555 = env11556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4824 env11555 == env11556) = true)

def env11557 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1296,8192,16384,25961,65536,1992,1,524288,25961,1297,8200,17665,91876,8329,16,26309,16385,1944,26308,1933,4294967296,257,4295558919,1993,513]

theorem envBound11557 : H12AffineFastState.Bounded env11557 := by
  intro p hp
  have h : env11557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11556_11557 : H12AffineEnvironment.transform 11 1296 env11556 = env11557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env11556 == env11557) = true)

theorem identity11557 : scanCanonicalize (H12AffineFastState.compose env11557 (packedSelected [0,1,2,3,4,5,6,8,12,13,15,16,17] rootPS)) = affineNative (2^(13+1) ^^^ 1344) := by decide +kernel

theorem selectedBound11557 : packedSelected [0,1,2,3,4,5,6,8,12,13,15,16,17] rootPS < 2^1333 := by decide +kernel

def env11558 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1296,8192,1344,8233,65536,1992,1,524288,8233,1297,8200,65,74660,8329,16,9093,1345,1944,9092,1933,4294967296,257,4295558919,1993,513]

theorem envBound11558 : H12AffineFastState.Bounded env11558 := by
  intro p hp
  have h : env11558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11557_11558 : H12AffineEnvironment.transform 13 1344 env11557 = env11558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env11557 == env11558) = true)

theorem identity11558 : scanCanonicalize (H12AffineFastState.compose env11558 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(18+1) ^^^ 75567) := by decide +kernel

theorem selectedBound11558 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env11559 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1296,8192,1344,8233,65536,1992,1,75567,8233,1297,8200,65,74660,8329,16,9093,1345,1944,9092,1933,4294967296,257,4294975528,1993,513]

theorem envBound11559 : H12AffineFastState.Bounded env11559 := by
  intro p hp
  have h : env11559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11558_11559 : H12AffineEnvironment.transform 18 75567 env11558 = env11559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 75567 env11558 == env11559) = true)

def env11560 : List Nat := [2,4,8,16,32,64,88,256,512,1024,1,1296,8192,1344,8233,65536,1808,1,75567,8233,1297,8200,65,74620,8273,16,9053,1345,1856,9052,1877,4294967296,257,4294975528,1809,513]

theorem envBound11560 : H12AffineFastState.Bounded env11560 := by
  intro p hp
  have h : env11560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11559_11560 : H12AffineEnvironment.transform 6 88 env11559 = env11560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env11559 == env11560) = true)

theorem identity11560 : scanCanonicalize (H12AffineFastState.compose env11560 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound11560 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env11561 : List Nat := [2,4,8,16,32,64,88,256,512,1024,1,1296,41,1344,0,65536,1808,1,67334,0,1297,33,65,66389,120,16,884,1345,1856,885,1877,4294967296,257,4294967297,1809,513]

theorem envBound11561 : H12AffineFastState.Bounded env11561 := by
  intro p hp
  have h : env11561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11560_11561 : H12AffineEnvironment.transform 12 41 env11560 = env11561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env11560 == env11561) = true)

theorem identity11561 : scanCanonicalize (H12AffineFastState.compose env11561 (packedSelected [0,1,5,7,10] rootPS)) = affineNative (2^(8+1) ^^^ 372) := by decide +kernel

theorem selectedBound11561 : packedSelected [0,1,5,7,10] rootPS < 2^1333 := by decide +kernel

def env11562 : List Nat := [2,4,8,16,32,64,88,256,372,1024,1,1296,41,1344,0,65536,1124,1,66674,0,1297,33,65,65569,120,16,0,1345,1076,1,1057,4294967296,257,4294967297,1125,373]

theorem envBound11562 : H12AffineFastState.Bounded env11562 := by
  intro p hp
  have h : env11562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11561_11562 : H12AffineEnvironment.transform 8 372 env11561 = env11562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 372 env11561 == env11562) = true)

theorem identity11562 : scanCanonicalize (H12AffineFastState.compose env11562 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(31+1) ^^^ 65560) := by decide +kernel

theorem selectedBound11562 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env11563 : List Nat := [2,4,8,16,32,64,88,256,372,1024,1,1296,41,1344,0,65536,1124,1,66674,0,1297,33,65,65569,120,16,0,1345,1076,1,1057,65560,257,65561,1125,373]

theorem envBound11563 : H12AffineFastState.Bounded env11563 := by
  intro p hp
  have h : env11563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11562_11563 : H12AffineEnvironment.transform 31 65560 env11562 = env11563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 65560 env11562 == env11563) = true)

theorem identity11563 : scanCanonicalize (H12AffineFastState.compose env11563 (packedSelected [1,5,13] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound11563 : packedSelected [1,5,13] rootPS < 2^1333 := by decide +kernel

def env11564 : List Nat := [2,4,8,16,32,64,88,37,81,1024,1,1077,41,1125,0,65536,1124,1,66674,0,1076,33,65,65569,120,16,0,1124,1076,1,1057,65560,36,65561,1125,80]

theorem envBound11564 : H12AffineFastState.Bounded env11564 := by
  intro p hp
  have h : env11564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11563_11564 : H12AffineEnvironment.transform 7 37 env11563 = env11564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env11563 == env11564) = true)

theorem identity11564 : scanCanonicalize (H12AffineFastState.compose env11564 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound11564 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11565 : List Nat := [2,4,8,1,32,64,73,37,64,1024,1,1060,41,1125,0,65536,1124,1,66659,0,1061,33,65,65569,105,1,0,1124,1061,1,1057,65545,36,65544,1125,65]

theorem envBound11565 : H12AffineFastState.Bounded env11565 := by
  intro p hp
  have h : env11565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11564_11565 : H12AffineEnvironment.transform 3 1 env11564 = env11565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env11564 == env11565) = true)

def env11566 : List Nat := [2,4,8,1,32,64,73,37,64,1024,1,1060,41,1125,0,8,1124,1,1131,0,1061,33,65,41,105,1,0,1124,1061,1,1057,1,36,0,1125,65]

theorem envBound11566 : H12AffineFastState.Bounded env11566 := by
  intro p hp
  have h : env11566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11565_11566 : H12AffineEnvironment.transform 15 8 env11565 = env11566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8 env11565 == env11566) = true)

def env11567 : List Nat := [2,4,8,1,32,64,73,37,64,1024,1,1060,41,1125,0,9,1124,1,1130,0,1061,33,65,40,105,1,0,1124,1061,1,1057,0,36,1,1125,65]

theorem envBound11567 : H12AffineFastState.Bounded env11567 := by
  intro p hp
  have h : env11567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11565_11567 : H12AffineEnvironment.transform 15 9 env11565 = env11567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9 env11565 == env11567) = true)

theorem identity11567 : scanCanonicalize (H12AffineFastState.compose env11567 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 43) := by decide +kernel

theorem selectedBound11567 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11568 : List Nat := [2,4,8,1,32,43,34,37,43,1024,1,1060,41,1038,0,9,1039,1,1025,0,1061,33,42,40,2,1,0,1039,1061,1,1057,0,36,1,1038,42]

theorem envBound11568 : H12AffineFastState.Bounded env11568 := by
  intro p hp
  have h : env11568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11567_11568 : H12AffineEnvironment.transform 5 43 env11567 = env11568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 43 env11567 == env11568) = true)

theorem identity11568 : scanCanonicalize (H12AffineFastState.compose env11568 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound11568 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11569 : List Nat := [2,4,8,1,0,11,2,5,11,1024,1,1028,9,1038,0,9,1039,1,1025,0,1029,1,10,8,2,1,0,1039,1029,1,1025,0,4,1,1038,10]

theorem envBound11569 : H12AffineFastState.Bounded env11569 := by
  intro p hp
  have h : env11569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11568_11569 : H12AffineEnvironment.transform 4 0 env11568 = env11569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env11568 == env11569) = true)

def leafEnv11569 : List Nat := [2,4,8,1,0,11,2,5,11,1024,1,1028,9,1038,0,9,1039,1,1025,0,1029,1,10,8,1024,2,1,1,0,1039,1029,1,1025,0,4,1,5,2,1038,10,0,1028,1]

def active11569 : List Nat := [0,1,2,9]

def tree11569 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood11569 : H12WitnessSearch.Good tree11569 := H12GlobalWitnessIndex.good

theorem leafIdentity11569 : H12AffineFastState.composeSystem env11569 rootObs = leafEnv11569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env11569 rootObs == leafEnv11569) = true)

theorem terminalChecked11569 : H12PackedTerminal.terminalCheckFast leafEnv11569 active11569 tree11569 = true := by decide +kernel

def env11570 : List Nat := [2,4,8,16,32,64,89,256,512,1024,1,1296,8192,1344,8233,65536,1809,1,75567,8233,1297,8200,65,74621,8272,16,9052,1345,1857,9053,1876,4294967296,257,4294975528,1808,513]

theorem envBound11570 : H12AffineFastState.Bounded env11570 := by
  intro p hp
  have h : env11570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11559_11570 : H12AffineEnvironment.transform 6 89 env11559 = env11570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env11559 == env11570) = true)

theorem identity11570 : scanCanonicalize (H12AffineFastState.compose env11570 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(15+1) ^^^ 774) := by decide +kernel

theorem selectedBound11570 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env11571 : List Nat := [2,4,8,16,32,64,89,256,512,1024,1,1296,8192,1344,8233,774,1809,1,9257,8233,1297,8200,65,8315,8272,16,9052,1345,1857,9053,1876,4294967296,257,4294975528,1808,513]

theorem envBound11571 : H12AffineFastState.Bounded env11571 := by
  intro p hp
  have h : env11571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11570_11571 : H12AffineEnvironment.transform 15 774 env11570 = env11571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 774 env11570 == env11571) = true)

theorem identity11571 : scanCanonicalize (H12AffineFastState.compose env11571 (packedSelected [1,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 373) := by decide +kernel

theorem selectedBound11571 : packedSelected [1,5,10] rootPS < 2^1333 := by decide +kernel

def env11572 : List Nat := [2,4,8,16,32,64,89,256,373,1024,1,1296,8192,1344,8233,115,1124,1,9257,8233,1297,8200,65,8315,8272,16,8233,1345,1076,8232,1057,4294967296,257,4294975528,1125,372]

theorem envBound11572 : H12AffineFastState.Bounded env11572 := by
  intro p hp
  have h : env11572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11571_11572 : H12AffineEnvironment.transform 8 373 env11571 = env11572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 373 env11571 == env11572) = true)

theorem identity11572 : scanCanonicalize (H12AffineFastState.compose env11572 (packedSelected [1,5,13] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound11572 : packedSelected [1,5,13] rootPS < 2^1333 := by decide +kernel

def env11573 : List Nat := [2,4,8,16,32,64,89,37,80,1024,1,1077,8192,1125,8233,115,1124,1,9257,8233,1076,8200,65,8315,8272,16,8233,1124,1076,8232,1057,4294967296,36,4294975528,1125,81]

theorem envBound11573 : H12AffineFastState.Bounded env11573 := by
  intro p hp
  have h : env11573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11572_11573 : H12AffineEnvironment.transform 7 37 env11572 = env11573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env11572 == env11573) = true)

theorem identity11573 : scanCanonicalize (H12AffineFastState.compose env11573 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 123) := by decide +kernel

theorem selectedBound11573 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11574 : List Nat := [2,4,8,16,32,64,89,37,80,1024,1,1077,8192,1125,8233,115,1124,1,9257,8233,1076,8200,65,8315,8272,16,8233,1124,1076,8232,1057,123,36,8275,1125,81]

theorem envBound11574 : H12AffineFastState.Bounded env11574 := by
  intro p hp
  have h : env11574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11573_11574 : H12AffineEnvironment.transform 31 123 env11573 = env11574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 123 env11573 == env11574) = true)

theorem identity11574 : scanCanonicalize (H12AffineFastState.compose env11574 (packedSelected [2,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound11574 : packedSelected [2,4,5] rootPS < 2^1333 := by decide +kernel

def env11575 : List Nat := [2,4,8,16,32,64,89,37,80,1024,1,1077,41,1125,0,115,1124,1,1024,0,1076,33,65,82,121,16,0,1124,1076,1,1057,123,36,122,1125,81]

theorem envBound11575 : H12AffineFastState.Bounded env11575 := by
  intro p hp
  have h : env11575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11574_11575 : H12AffineEnvironment.transform 12 41 env11574 = env11575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env11574 == env11575) = true)

theorem identity11575 : scanCanonicalize (H12AffineFastState.compose env11575 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound11575 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11576 : List Nat := [2,4,8,0,32,64,73,37,64,1024,1,1061,41,1125,0,99,1124,1,1024,0,1060,33,65,66,105,0,0,1124,1060,1,1057,107,36,106,1125,65]

theorem envBound11576 : H12AffineFastState.Bounded env11576 := by
  intro p hp
  have h : env11576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11575_11576 : H12AffineEnvironment.transform 3 0 env11575 = env11576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env11575 == env11576) = true)

def leafEnv11576 : List Nat := [2,4,8,0,32,64,73,37,64,1024,1,1061,41,1125,0,99,1124,1,1024,0,1060,33,65,66,1057,105,1,0,0,1124,1060,1,1057,107,36,106,5,34,1125,65,0,1061,1]

def active11576 : List Nat := [0,1,2,4,5,9]

def tree11576 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood11576 : H12WitnessSearch.Good tree11576 := H12GlobalWitnessIndex.good

theorem leafIdentity11576 : H12AffineFastState.composeSystem env11576 rootObs = leafEnv11576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env11576 rootObs == leafEnv11576) = true)

theorem terminalChecked11576 : H12PackedTerminal.terminalCheckFast leafEnv11576 active11576 tree11576 = true := by decide +kernel

def env11577 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1297,8192,16384,25960,65536,1993,1,524288,25960,1296,8200,17665,91876,8329,17,26309,16385,1945,26308,1932,4294967296,257,4295558918,1992,513]

theorem envBound11577 : H12AffineFastState.Bounded env11577 := by
  intro p hp
  have h : env11577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11556_11577 : H12AffineEnvironment.transform 11 1297 env11556 = env11577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env11556 == env11577) = true)

theorem identity11577 : scanCanonicalize (H12AffineFastState.compose env11577 (packedSelected [0,1,2,3,4,5,6,8,12,13,15,16,17] rootPS)) = affineNative (2^(15+1) ^^^ 8614) := by decide +kernel

theorem selectedBound11577 : packedSelected [0,1,2,3,4,5,6,8,12,13,15,16,17] rootPS < 2^1333 := by decide +kernel

def env11578 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1297,8192,16384,25960,8614,1993,1,524288,25960,1296,8200,17665,18242,8329,17,26309,16385,1945,26308,1932,4294967296,257,4295501472,1992,513]

theorem envBound11578 : H12AffineFastState.Bounded env11578 := by
  intro p hp
  have h : env11578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11577_11578 : H12AffineEnvironment.transform 15 8614 env11577 = env11578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8614 env11577 == env11578) = true)

def env11579 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,131072,189089,524288,32768,4097,8200,17665,230469,8329,5376,38589,16385,131152,164964,131141,4294967296,257,4295749814,131073,513]

theorem envBound11579 : H12AffineFastState.Bounded env11579 := by
  intro p hp
  have h : env11579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11553_11579 : H12AffineEnvironment.transform 17 189089 env11553 = env11579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 189089 env11553 == env11579) = true)

theorem identity11579 : scanCanonicalize (H12AffineFastState.compose env11579 (packedSelected [16,18,32] rootPS)) = affineNative (2^(16+1) ^^^ 58017) := by decide +kernel

theorem selectedBound11579 : packedSelected [16,18,32] rootPS < 2^1333 := by decide +kernel

def env11580 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,58017,0,524288,32768,4097,8200,17665,91876,8329,5376,38589,16385,58097,26309,58084,4294967296,257,4295561751,58016,513]

theorem envBound11580 : H12AffineFastState.Bounded env11580 := by
  intro p hp
  have h : env11580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11579_11580 : H12AffineEnvironment.transform 16 58017 env11579 = env11580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 58017 env11579 == env11580) = true)

theorem identity11580 : scanCanonicalize (H12AffineFastState.compose env11580 (packedSelected [18,20] rootPS)) = affineNative (2^(14+1) ^^^ 28792) := by decide +kernel

theorem selectedBound11580 : packedSelected [18,20] rootPS < 2^1333 := by decide +kernel

def env11581 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,28792,65536,4825,0,524288,28792,4097,8200,17665,91876,8329,5376,26309,16385,4745,26309,4764,4294967296,257,4295561751,4824,513]

theorem envBound11581 : H12AffineFastState.Bounded env11581 := by
  intro p hp
  have h : env11581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11580_11581 : H12AffineEnvironment.transform 14 28792 env11580 = env11581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 28792 env11580 == env11581) = true)

def env11582 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1296,8192,16384,25960,65536,1993,0,524288,25960,1297,8200,17665,91876,8329,16,26309,16385,1945,26309,1932,4294967296,257,4295558919,1992,513]

theorem envBound11582 : H12AffineFastState.Bounded env11582 := by
  intro p hp
  have h : env11582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11581_11582 : H12AffineEnvironment.transform 11 1296 env11581 = env11582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env11581 == env11582) = true)

theorem identity11582 : scanCanonicalize (H12AffineFastState.compose env11582 (packedSelected [0,1,2,3,4,5,6,8,12,13,15,16,17] rootPS)) = affineNative (2^(15+1) ^^^ 17898) := by decide +kernel

theorem selectedBound11582 : packedSelected [0,1,2,3,4,5,6,8,12,13,15,16,17] rootPS < 2^1333 := by decide +kernel

def env11583 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1296,8192,16384,25960,17898,1993,0,524288,25960,1297,8200,17665,8974,8329,16,26309,16385,1945,26309,1932,4294967296,257,4295508717,1992,513]

theorem envBound11583 : H12AffineFastState.Bounded env11583 := by
  intro p hp
  have h : env11583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11582_11583 : H12AffineEnvironment.transform 15 17898 env11582 = env11583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 17898 env11582 == env11583) = true)

theorem identity11583 : scanCanonicalize (H12AffineFastState.compose env11583 (packedSelected [0,1,2,4,5,6,12,13,15] rootPS)) = affineNative (2^(18+1) ^^^ 17353) := by decide +kernel

theorem selectedBound11583 : packedSelected [0,1,2,4,5,6,12,13,15] rootPS < 2^1333 := by decide +kernel

def env11584 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1296,8192,16384,25960,17898,1993,0,17353,25960,1297,8200,17665,8974,8329,16,26309,16385,1945,26309,1932,4294967296,257,4294967588,1992,513]

theorem envBound11584 : H12AffineFastState.Bounded env11584 := by
  intro p hp
  have h : env11584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11583_11584 : H12AffineEnvironment.transform 18 17353 env11583 = env11584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 17353 env11583 == env11584) = true)

theorem identity11584 : scanCanonicalize (H12AffineFastState.compose env11584 (packedSelected [0,7] rootPS)) = affineNative (2^(13+1) ^^^ 1992) := by decide +kernel

theorem selectedBound11584 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env11585 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1296,8192,1992,8864,546,1993,0,1025,8864,1297,8200,713,8974,8329,16,8461,1993,1945,8461,1932,4294967296,257,4294967588,1992,513]

theorem envBound11585 : H12AffineFastState.Bounded env11585 := by
  intro p hp
  have h : env11585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11584_11585 : H12AffineEnvironment.transform 13 1992 env11584 = env11585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1992 env11584 == env11585) = true)

theorem identity11585 : scanCanonicalize (H12AffineFastState.compose env11585 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(12+1) ^^^ 901) := by decide +kernel

theorem selectedBound11585 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env11586 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1296,901,1992,293,546,1993,0,1025,293,1297,909,713,139,780,16,648,1993,1945,648,1932,4294967296,257,4294967588,1992,513]

theorem envBound11586 : H12AffineFastState.Bounded env11586 := by
  intro p hp
  have h : env11586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11585_11586 : H12AffineEnvironment.transform 12 901 env11585 = env11586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 901 env11585 == env11586) = true)

theorem identity11586 : scanCanonicalize (H12AffineFastState.compose env11586 (packedSelected [1,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 428) := by decide +kernel

theorem selectedBound11586 : packedSelected [1,5,10] rootPS < 2^1333 := by decide +kernel

def env11587 : List Nat := [2,4,8,16,32,64,128,256,428,1024,1,1296,41,1124,293,398,1125,0,1025,293,1297,33,357,139,160,16,292,1125,1077,292,1056,4294967296,257,4294967588,1124,429]

theorem envBound11587 : H12AffineFastState.Bounded env11587 := by
  intro p hp
  have h : env11587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11586_11587 : H12AffineEnvironment.transform 8 428 env11586 = env11587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 428 env11586 == env11587) = true)

theorem identity11587 : scanCanonicalize (H12AffineFastState.compose env11587 (packedSelected [5,8] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound11587 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env11588 : List Nat := [2,4,8,16,32,64,128,36,136,1024,1,1076,41,1124,1,170,1125,0,1025,1,1077,33,65,139,160,16,0,1125,1077,0,1056,4294967296,37,4294967296,1124,137]

theorem envBound11588 : H12AffineFastState.Bounded env11588 := by
  intro p hp
  have h : env11588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11587_11588 : H12AffineEnvironment.transform 7 36 env11587 = env11588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env11587 == env11588) = true)

theorem identity11588 : scanCanonicalize (H12AffineFastState.compose env11588 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 242) := by decide +kernel

theorem selectedBound11588 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11589 : List Nat := [2,4,8,16,32,64,128,36,136,1024,1,1076,41,1124,1,170,1125,0,1025,1,1077,33,65,139,160,16,0,1125,1077,0,1056,242,37,242,1124,137]

theorem envBound11589 : H12AffineFastState.Bounded env11589 := by
  intro p hp
  have h : env11589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11588_11589 : H12AffineEnvironment.transform 31 242 env11588 = env11589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 242 env11588 == env11589) = true)

theorem identity11589 : scanCanonicalize (H12AffineFastState.compose env11589 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 198) := by decide +kernel

theorem selectedBound11589 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11590 : List Nat := [2,4,8,16,32,64,128,36,136,198,1,242,41,162,1,170,163,0,199,1,243,33,65,139,160,16,0,163,243,0,230,242,37,242,162,137]

theorem envBound11590 : H12AffineFastState.Bounded env11590 := by
  intro p hp
  have h : env11590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11589_11590 : H12AffineEnvironment.transform 9 198 env11589 = env11590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 198 env11589 == env11590) = true)

theorem identity11590 : scanCanonicalize (H12AffineFastState.compose env11590 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound11590 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11591 : List Nat := [2,4,8,16,32,64,18,36,26,84,1,96,41,48,1,56,49,0,85,1,97,33,65,25,50,16,0,49,97,0,116,96,37,96,48,27]

theorem envBound11591 : H12AffineFastState.Bounded env11591 := by
  intro p hp
  have h : env11591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11590_11591 : H12AffineEnvironment.transform 6 18 env11590 = env11591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env11590 == env11591) = true)

theorem identity11591 : scanCanonicalize (H12AffineFastState.compose env11591 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound11591 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env11592 : List Nat := [2,4,8,11,32,64,9,36,1,79,1,96,41,43,1,35,42,0,78,1,97,33,65,2,41,11,0,42,97,0,111,96,37,96,43,0]

theorem envBound11592 : H12AffineFastState.Bounded env11592 := by
  intro p hp
  have h : env11592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11591_11592 : H12AffineEnvironment.transform 3 11 env11591 = env11592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env11591 == env11592) = true)

theorem identity11592 : scanCanonicalize (H12AffineFastState.compose env11592 (packedSelected [4] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound11592 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env11593 : List Nat := [2,4,8,11,32,11,9,36,1,4,1,43,41,43,1,35,42,0,5,1,42,33,10,2,41,11,0,42,42,0,36,43,37,43,43,0]

theorem envBound11593 : H12AffineFastState.Bounded env11593 := by
  intro p hp
  have h : env11593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11592_11593 : H12AffineEnvironment.transform 5 11 env11592 = env11593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env11592 == env11593) = true)

theorem identity11593 : scanCanonicalize (H12AffineFastState.compose env11593 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound11593 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env11594 : List Nat := [2,4,8,11,1,11,9,5,1,4,1,10,8,10,1,2,11,0,5,1,11,0,10,2,8,11,0,11,11,0,5,10,4,10,10,0]

theorem envBound11594 : H12AffineFastState.Bounded env11594 := by
  intro p hp
  have h : env11594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11593_11594 : H12AffineEnvironment.transform 4 1 env11593 = env11594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env11593 == env11594) = true)

def env11595 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1297,8192,16384,25961,65536,1992,0,524288,25961,1296,8200,17665,91876,8329,17,26309,16385,1944,26309,1933,4294967296,257,4295558918,1993,513]

theorem envBound11595 : H12AffineFastState.Bounded env11595 := by
  intro p hp
  have h : env11595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11581_11595 : H12AffineEnvironment.transform 11 1297 env11581 = env11595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env11581 == env11595) = true)

theorem identity11595 : scanCanonicalize (H12AffineFastState.compose env11595 (packedSelected [0,1,2,3,4,5,6,8,12,13,15,16,17] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound11595 : packedSelected [0,1,2,3,4,5,6,8,12,13,15,16,17] rootPS < 2^1333 := by decide +kernel

def env11596 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1297,269,16384,17508,65536,1992,0,524288,17508,1296,261,17665,83945,388,17,18376,16385,1944,18376,1933,4294967296,257,4295558918,1993,513]

theorem envBound11596 : H12AffineFastState.Bounded env11596 := by
  intro p hp
  have h : env11596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11595_11596 : H12AffineEnvironment.transform 12 269 env11595 = env11596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env11595 == env11596) = true)

theorem identity11596 : scanCanonicalize (H12AffineFastState.compose env11596 (packedSelected [2,3,5,6,7,9,10,12] rootPS)) = affineNative (2^(18+1) ^^^ 16704) := by decide +kernel

theorem selectedBound11596 : packedSelected [2,3,5,6,7,9,10,12] rootPS < 2^1333 := by decide +kernel

def env11597 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1297,269,16384,17508,65536,1992,0,16704,17508,1296,261,17665,83945,388,17,18376,16385,1944,18376,1933,4294967296,257,4295050822,1993,513]

theorem envBound11597 : H12AffineFastState.Bounded env11597 := by
  intro p hp
  have h : env11597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11596_11597 : H12AffineEnvironment.transform 18 16704 env11596 = env11597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 16704 env11596 == env11597) = true)

theorem identity11597 : scanCanonicalize (H12AffineFastState.compose env11597 (packedSelected [4,9] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound11597 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env11598 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,1297,269,16384,17508,65536,1345,0,16704,17508,1296,261,17665,83296,388,17,17729,16385,1297,17729,1284,4294967296,257,4295050447,1344,136]

theorem envBound11598 : H12AffineFastState.Bounded env11598 := by
  intro p hp
  have h : env11598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11597_11598 : H12AffineEnvironment.transform 8 137 env11597 = env11598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env11597 == env11598) = true)

theorem identity11598 : scanCanonicalize (H12AffineFastState.compose env11598 (packedSelected [0,7] rootPS)) = affineNative (2^(15+1) ^^^ 171) := by decide +kernel

theorem selectedBound11598 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env11599 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,1297,269,16384,17508,171,1345,0,16704,17508,1296,261,17665,17867,388,17,17729,16385,1297,17729,1284,4294967296,257,4294984804,1344,136]

theorem envBound11599 : H12AffineFastState.Bounded env11599 := by
  intro p hp
  have h : env11599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11598_11599 : H12AffineEnvironment.transform 15 171 env11598 = env11599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 171 env11598 == env11599) = true)

theorem identity11599 : scanCanonicalize (H12AffineFastState.compose env11599 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(13+1) ^^^ 1345) := by decide +kernel

theorem selectedBound11599 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env11600 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,1297,269,1345,293,171,1345,0,1025,293,1296,261,64,138,388,17,0,1344,1297,0,1284,4294967296,257,4294967589,1344,136]

theorem envBound11600 : H12AffineFastState.Bounded env11600 := by
  intro p hp
  have h : env11600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11599_11600 : H12AffineEnvironment.transform 13 1345 env11599 = env11600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env11599 == env11600) = true)

theorem identity11600 : scanCanonicalize (H12AffineFastState.compose env11600 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound11600 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env11601 : List Nat := [2,4,8,16,32,64,128,252,137,1024,1,1261,241,1213,217,171,1213,0,1025,217,1260,249,64,138,120,17,0,1212,1261,0,1272,4294967296,253,4294967513,1212,136]

theorem envBound11601 : H12AffineFastState.Bounded env11601 := by
  intro p hp
  have h : env11601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11600_11601 : H12AffineEnvironment.transform 7 252 env11600 = env11601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env11600 == env11601) = true)

theorem identity11601 : scanCanonicalize (H12AffineFastState.compose env11601 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 114) := by decide +kernel

theorem selectedBound11601 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env11602 : List Nat := [2,4,8,16,32,64,114,14,123,1024,1,1055,3,1103,43,89,1103,0,1025,43,1054,11,64,120,120,17,0,1102,1055,0,1034,4294967296,15,4294967339,1102,122]

theorem envBound11602 : H12AffineFastState.Bounded env11602 := by
  intro p hp
  have h : env11602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11601_11602 : H12AffineEnvironment.transform 6 114 env11601 = env11602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 114 env11601 == env11602) = true)

theorem identity11602 : scanCanonicalize (H12AffineFastState.compose env11602 (packedSelected [2,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound11602 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env11603 : List Nat := [2,4,8,16,0,64,82,14,91,1024,1,1055,3,1103,11,89,1103,0,1025,11,1054,11,64,88,88,17,0,1102,1055,0,1034,4294967296,15,4294967307,1102,90]

theorem envBound11603 : H12AffineFastState.Bounded env11603 := by
  intro p hp
  have h : env11603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11602_11603 : H12AffineEnvironment.transform 4 0 env11602 = env11603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env11602 == env11603) = true)

def env11604 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,17665,16777216,33554432,2098433,23445585,2117632,131153,1073741824,16876545,4294967296,256,4352140403,131073,33563272]

theorem envBound11604 : H12AffineFastState.Bounded env11604 := by
  intro p hp
  have h : env11604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11249_11604 : H12AffineEnvironment.transform 26 23445585 env11249 = env11604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 23445585 env11249 == env11604) = true)

def env11605 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,17665,16777216,33554432,67108864,134217728,67130625,157794305,1073741824,140788817,4294967296,157663568,4417151346,131072,33563272]

theorem envBound11605 : H12AffineFastState.Bounded env11605 := by
  intro p hp
  have h : env11605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11247_11605 : H12AffineEnvironment.transform 28 157794305 env11247 = env11605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 28 157794305 env11247 == env11605) = true)

theorem identity11605 : scanCanonicalize (H12AffineFastState.compose env11605 (packedSelected [14] rootPS)) = affineNative (2^(25+1) ^^^ 5377) := by decide +kernel

theorem selectedBound11605 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env11606 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,17665,16777216,33554432,5377,134217728,16384,157794305,1073741824,140788817,4294967296,157663568,4350047347,131072,33563272]

theorem envBound11606 : H12AffineFastState.Bounded env11606 := by
  intro p hp
  have h : env11606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11605_11606 : H12AffineEnvironment.transform 25 5377 env11605 = env11606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 5377 env11605 == env11606) = true)

def env11607 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,17665,16777216,33554432,5377,23445584,16384,131153,1073741824,16876545,4294967296,256,4350047347,131072,33563272]

theorem envBound11607 : H12AffineFastState.Bounded env11607 := by
  intro p hp
  have h : env11607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11606_11607 : H12AffineEnvironment.transform 26 23445584 env11606 = env11607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 23445584 env11606 == env11607) = true)

def env11608 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,17665,16777216,33554432,5377,23445585,16384,131152,1073741824,16876544,4294967296,257,4350047347,131072,33563272]

theorem envBound11608 : H12AffineFastState.Bounded env11608 := by
  intro p hp
  have h : env11608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11606_11608 : H12AffineEnvironment.transform 26 23445585 env11606 = env11608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 23445585 env11606 == env11608) = true)

theorem identity11608 : scanCanonicalize (H12AffineFastState.compose env11608 (packedSelected [35] rootPS)) = affineNative (2^(23+1) ^^^ 230468) := by decide +kernel

theorem selectedBound11608 : packedSelected [35] rootPS < 2^1333 := by decide +kernel

def env11609 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,17665,230468,33554432,5377,6702101,16384,131152,1073741824,131140,4294967296,257,4333498423,131072,33563272]

theorem envBound11609 : H12AffineFastState.Bounded env11609 := by
  intro p hp
  have h : env11609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11608_11609 : H12AffineEnvironment.transform 23 230468 env11608 = env11609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 230468 env11608 == env11609) = true)

def env11610 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,10248,17665,230468,33554432,5377,2518045,16384,131152,1073741824,131140,4294967296,257,4329297983,131072,33563272]

theorem envBound11610 : H12AffineFastState.Bounded env11610 := by
  intro p hp
  have h : env11610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11609_11610 : H12AffineEnvironment.transform 21 10248 env11609 = env11610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10248 env11609 == env11610) = true)

def env11611 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8832,65536,131072,262144,524288,8832,2097152,10248,17665,206532,33554432,5377,2518045,16384,131152,1073741824,131140,4294967296,257,4329274047,131072,33563272]

theorem envBound11611 : H12AffineFastState.Bounded env11611 := by
  intro p hp
  have h : env11611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11610_11611 : H12AffineEnvironment.transform 14 8832 env11610 = env11611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8832 env11610 == env11611) = true)

def env11612 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8832,65536,131072,262144,524288,8832,2097152,8200,17665,206532,33554432,5377,2515997,16384,131152,1073741824,131140,4294967296,257,4329271999,131072,33563272]

theorem envBound11612 : H12AffineFastState.Bounded env11612 := by
  intro p hp
  have h : env11612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11611_11612 : H12AffineEnvironment.transform 10 0 env11611 = env11612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env11611 == env11612) = true)

theorem identity11612 : scanCanonicalize (H12AffineFastState.compose env11612 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 33960184) := by decide +kernel

theorem selectedBound11612 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env11613 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8832,65536,131072,262144,524288,8832,2097152,8200,17665,206532,33554432,5377,2515997,16384,131152,33960184,131140,4294967296,257,4329271999,131072,33563272]

theorem envBound11613 : H12AffineFastState.Bounded env11613 := by
  intro p hp
  have h : env11613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11612_11613 : H12AffineEnvironment.transform 29 33960184 env11612 = env11613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 33960184 env11612 == env11613) = true)

def env11614 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8832,65536,131072,0,524288,8832,2097152,8200,17665,206532,33554432,5377,2253853,16384,131152,33698040,131140,4294967296,257,4329271999,131072,33563272]

theorem envBound11614 : H12AffineFastState.Bounded env11614 := by
  intro p hp
  have h : env11614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11613_11614 : H12AffineEnvironment.transform 17 0 env11613 = env11614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 0 env11613 == env11614) = true)

def env11615 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8832,65536,1344,0,524288,8832,2097152,8200,17665,74628,33554432,5377,2122077,16384,1296,33568184,1284,4294967296,257,4329142271,1344,33563272]

theorem envBound11615 : H12AffineFastState.Bounded env11615 := by
  intro p hp
  have h : env11615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11614_11615 : H12AffineEnvironment.transform 16 1344 env11614 = env11615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env11614 == env11615) = true)

theorem identity11615 : scanCanonicalize (H12AffineFastState.compose env11615 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 4097) := by decide +kernel

theorem selectedBound11615 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env11616 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8832,65536,1344,0,524288,8832,4097,8200,17665,74628,33554432,5377,29020,16384,1296,33568184,1284,4294967296,257,4329142271,1344,33563272]

theorem envBound11616 : H12AffineFastState.Bounded env11616 := by
  intro p hp
  have h : env11616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11615_11616 : H12AffineEnvironment.transform 20 4097 env11615 = env11616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env11615 == env11616) = true)

theorem identity11616 : scanCanonicalize (H12AffineFastState.compose env11616 (packedSelected [20] rootPS)) = affineNative (2^(12+1) ^^^ 900) := by decide +kernel

theorem selectedBound11616 : packedSelected [20] rootPS < 2^1333 := by decide +kernel

def env11617 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,900,16384,260,65536,1344,0,524288,260,4097,908,17665,65536,33554432,5377,21208,16384,1296,33560124,1284,4294967296,257,4329133179,1344,33554700]

theorem envBound11617 : H12AffineFastState.Bounded env11617 := by
  intro p hp
  have h : env11617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11616_11617 : H12AffineEnvironment.transform 12 900 env11616 = env11617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 900 env11616 == env11617) = true)

theorem identity11617 : scanCanonicalize (H12AffineFastState.compose env11617 (packedSelected [5,8,12,13,15,17,24,28] rootPS)) = affineNative (2^(24+1) ^^^ 5661) := by decide +kernel

theorem selectedBound11617 : packedSelected [5,8,12,13,15,17,24,28] rootPS < 2^1333 := by decide +kernel

def env11618 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,900,16384,260,65536,1344,0,524288,260,4097,908,17665,65536,5661,5377,21208,16384,1296,33,1284,4294967296,257,4295574118,1344,5905]

theorem envBound11618 : H12AffineFastState.Bounded env11618 := by
  intro p hp
  have h : env11618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11617_11618 : H12AffineEnvironment.transform 24 5661 env11617 = env11618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 5661 env11617 == env11618) = true)

theorem identity11618 : scanCanonicalize (H12AffineFastState.compose env11618 (packedSelected [9,18,22,23] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound11618 : packedSelected [9,18,22,23] rootPS < 2^1333 := by decide +kernel

def env11619 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,4096,269,16384,260,65536,1344,0,524288,260,4097,261,17665,65536,5268,5377,20561,16384,1296,33,1284,4294967296,257,4295573743,1344,5528]

theorem envBound11619 : H12AffineFastState.Bounded env11619 := by
  intro p hp
  have h : env11619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11618_11619 : H12AffineEnvironment.transform 8 137 env11618 = env11619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env11618 == env11619) = true)

theorem identity11619 : scanCanonicalize (H12AffineFastState.compose env11619 (packedSelected [3,10,17,18,19,21,24] rootPS)) = affineNative (2^(13+1) ^^^ 1377) := by decide +kernel

theorem selectedBound11619 : packedSelected [3,10,17,18,19,21,24] rootPS < 2^1333 := by decide +kernel

def env11620 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,4096,269,1377,260,65536,1344,0,524288,260,4097,261,96,65536,5268,5377,5424,1377,1296,33,1284,4294967296,257,4295558542,1344,5528]

theorem envBound11620 : H12AffineFastState.Bounded env11620 := by
  intro p hp
  have h : env11620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11619_11620 : H12AffineEnvironment.transform 13 1377 env11619 = env11620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1377 env11619 == env11620) = true)

theorem identity11620 : scanCanonicalize (H12AffineFastState.compose env11620 (packedSelected [10,15,17] rootPS)) = affineNative (2^(18+1) ^^^ 70075) := by decide +kernel

theorem selectedBound11620 : packedSelected [10,15,17] rootPS < 2^1333 := by decide +kernel

def env11621 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,4096,269,1377,260,65536,1344,0,70075,260,4097,261,96,65536,5268,5377,5424,1377,1296,33,1284,4294967296,257,4294972469,1344,5528]

theorem envBound11621 : H12AffineFastState.Bounded env11621 := by
  intro p hp
  have h : env11621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11620_11621 : H12AffineEnvironment.transform 18 70075 env11620 = env11621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 70075 env11620 == env11621) = true)

theorem identity11621 : scanCanonicalize (H12AffineFastState.compose env11621 (packedSelected [1,3,5,8,10,12,13,16] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound11621 : packedSelected [1,3,5,8,10,12,13,16] rootPS < 2^1333 := by decide +kernel

def env11622 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,1296,269,1377,260,65536,1344,0,66731,260,1297,261,96,65536,388,17,32,1377,1296,33,1284,4294967296,257,4294967589,1344,136]

theorem envBound11622 : H12AffineFastState.Bounded env11622 := by
  intro p hp
  have h : env11622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11621_11622 : H12AffineEnvironment.transform 11 1296 env11621 = env11622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env11621 == env11622) = true)

theorem identity11622 : scanCanonicalize (H12AffineFastState.compose env11622 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound11622 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env11623 : List Nat := [2,4,8,16,0,64,128,256,137,1024,0,1296,269,1345,260,65536,1344,0,66699,260,1297,261,64,65536,388,17,0,1345,1296,1,1284,4294967296,257,4294967557,1344,136]

theorem envBound11623 : H12AffineFastState.Bounded env11623 := by
  intro p hp
  have h : env11623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11622_11623 : H12AffineEnvironment.transform 4 0 env11622 = env11623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env11622 == env11623) = true)

theorem identity11623 : scanCanonicalize (H12AffineFastState.compose env11623 (packedSelected [1,3,5] rootPS)) = affineNative (2^(7+1) ^^^ 221) := by decide +kernel

theorem selectedBound11623 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env11624 : List Nat := [2,4,8,16,0,64,128,221,137,1024,0,1229,208,1180,217,65536,1181,0,66699,217,1228,216,64,65536,89,17,0,1180,1229,1,1241,4294967296,220,4294967512,1181,136]

theorem envBound11624 : H12AffineFastState.Bounded env11624 := by
  intro p hp
  have h : env11624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11623_11624 : H12AffineEnvironment.transform 7 221 env11623 = env11624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 221 env11623 == env11624) = true)

theorem identity11624 : scanCanonicalize (H12AffineFastState.compose env11624 (packedSelected [1,2,3,4] rootPS)) = affineNative (2^(15+1) ^^^ 139) := by decide +kernel

theorem selectedBound11624 : packedSelected [1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env11625 : List Nat := [2,4,8,16,0,64,128,221,137,1024,0,1229,208,1180,217,139,1181,0,1024,217,1228,216,64,139,89,17,0,1180,1229,1,1241,4294967296,220,4294967512,1181,136]

theorem envBound11625 : H12AffineFastState.Bounded env11625 := by
  intro p hp
  have h : env11625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11624_11625 : H12AffineEnvironment.transform 15 139 env11624 = env11625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 139 env11624 == env11625) = true)

theorem identity11625 : scanCanonicalize (H12AffineFastState.compose env11625 (packedSelected [0,1] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound11625 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env11626 : List Nat := [2,4,8,16,0,0,128,157,137,1024,0,1165,144,1180,153,139,1181,0,1024,153,1164,152,0,139,25,17,0,1180,1165,1,1177,4294967296,156,4294967448,1181,136]

theorem envBound11626 : H12AffineFastState.Bounded env11626 := by
  intro p hp
  have h : env11626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11625_11626 : H12AffineEnvironment.transform 5 0 env11625 = env11626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env11625 == env11626) = true)

theorem identity11626 : scanCanonicalize (H12AffineFastState.compose env11626 (packedSelected [0,3] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound11626 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env11627 : List Nat := [2,4,8,16,0,0,25,4,16,1024,0,1044,9,1029,0,18,1028,0,1024,0,1045,1,0,18,25,17,0,1029,1044,1,1024,4294967296,5,4294967297,1028,17]

theorem envBound11627 : H12AffineFastState.Bounded env11627 := by
  intro p hp
  have h : env11627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11626_11627 : H12AffineEnvironment.transform 6 25 env11626 = env11627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env11626 == env11627) = true)

theorem identity11627 : scanCanonicalize (H12AffineFastState.compose env11627 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 11) := by decide +kernel

theorem selectedBound11627 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11628 : List Nat := [2,4,8,16,0,0,25,4,16,1024,0,1044,9,1029,0,18,1028,0,1024,0,1045,1,0,18,25,17,0,1029,1044,1,1024,11,5,10,1028,17]

theorem envBound11628 : H12AffineFastState.Bounded env11628 := by
  intro p hp
  have h : env11628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11627_11628 : H12AffineEnvironment.transform 31 11 env11627 = env11628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 11 env11627 == env11628) = true)

def leafEnv11628 : List Nat := [2,4,8,16,0,0,25,4,16,1024,0,1044,9,1029,0,18,1028,0,1024,0,1045,1,0,18,1024,25,1,17,0,1029,1044,1,1024,11,5,10,5,3,1028,17,0,1045,1]

def active11628 : List Nat := [0,1,2,3,9]

def tree11628 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood11628 : H12WitnessSearch.Good tree11628 := H12GlobalWitnessIndex.good

theorem leafIdentity11628 : H12AffineFastState.composeSystem env11628 rootObs = leafEnv11628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env11628 rootObs == leafEnv11628) = true)

theorem terminalChecked11628 : H12PackedTerminal.terminalCheckFast leafEnv11628 active11628 tree11628 = true := by decide +kernel

def env11629 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8832,65536,1345,0,524288,8832,2097152,8200,17665,74629,33554432,5377,2122076,16384,1297,33568185,1285,4294967296,257,4329142270,1345,33563272]

theorem envBound11629 : H12AffineFastState.Bounded env11629 := by
  intro p hp
  have h : env11629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11614_11629 : H12AffineEnvironment.transform 16 1345 env11614 = env11629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env11614 == env11629) = true)

theorem identity11629 : scanCanonicalize (H12AffineFastState.compose env11629 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(24+1) ^^^ 2647257) := by decide +kernel

theorem selectedBound11629 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env11630 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8832,65536,1345,0,524288,8832,2097152,8200,17665,74629,2647257,5377,2122076,16384,1297,2642272,1285,4294967296,257,4297134887,1345,2639441]

theorem envBound11630 : H12AffineFastState.Bounded env11630 := by
  intro p hp
  have h : env11630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11629_11630 : H12AffineEnvironment.transform 24 2647257 env11629 = env11630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 2647257 env11629 == env11630) = true)

theorem identity11630 : scanCanonicalize (H12AffineFastState.compose env11630 (packedSelected [1,3,4,5,6,7,8,9,10,13,16,17,19,20,21,25,27,33] rootPS)) = affineNative (2^(18+1) ^^^ 70451) := by decide +kernel

theorem selectedBound11630 : packedSelected [1,3,4,5,6,7,8,9,10,13,16,17,19,20,21,25,27,33] rootPS < 2^1333 := by decide +kernel

def env11631 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8832,65536,1345,0,70451,8832,2097152,8200,17665,74629,2193386,5377,2122076,16384,1297,2179667,1285,4294967296,257,4297134887,1345,2184546]

theorem envBound11631 : H12AffineFastState.Bounded env11631 := by
  intro p hp
  have h : env11631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11630_11631 : H12AffineEnvironment.transform 18 70451 env11630 = env11631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 70451 env11630 == env11631) = true)

theorem identity11631 : scanCanonicalize (H12AffineFastState.compose env11631 (packedSelected [1,5,6,8,19,24,25,26] rootPS)) = affineNative (2^(20+1) ^^^ 4097) := by decide +kernel

theorem selectedBound11631 : packedSelected [1,5,6,8,19,24,25,26] rootPS < 2^1333 := by decide +kernel

def env11632 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8832,65536,1345,0,70451,8832,4097,8200,17665,74629,92139,5377,29021,16384,1297,86610,1285,4294967296,257,4295033638,1345,83299]

theorem envBound11632 : H12AffineFastState.Bounded env11632 := by
  intro p hp
  have h : env11632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11631_11632 : H12AffineEnvironment.transform 20 4097 env11631 = env11632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env11631 == env11632) = true)

theorem identity11632 : scanCanonicalize (H12AffineFastState.compose env11632 (packedSelected [20] rootPS)) = affineNative (2^(12+1) ^^^ 5780) := by decide +kernel

theorem selectedBound11632 : packedSelected [20] rootPS < 2^1333 := by decide +kernel

def env11633 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,5780,16384,5140,65536,1345,0,70451,5140,4097,5788,17665,70929,86399,5377,18377,16384,1297,86610,1285,4294967296,257,4295033638,1345,83299]

theorem envBound11633 : H12AffineFastState.Bounded env11633 := by
  intro p hp
  have h : env11633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11632_11633 : H12AffineEnvironment.transform 12 5780 env11632 = env11633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5780 env11632 == env11633) = true)

theorem identity11633 : scanCanonicalize (H12AffineFastState.compose env11633 (packedSelected [18] rootPS)) = affineNative (2^(13+1) ^^^ 4856) := by decide +kernel

theorem selectedBound11633 : packedSelected [18] rootPS < 2^1333 := by decide +kernel

def env11634 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,5780,4856,5140,65536,1345,0,70451,5140,4097,5788,6137,70929,66439,5377,5425,4856,1297,65706,1285,4294967296,257,4295033638,1345,71579]

theorem envBound11634 : H12AffineFastState.Bounded env11634 := by
  intro p hp
  have h : env11634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11633_11634 : H12AffineEnvironment.transform 13 4856 env11633 = env11634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4856 env11633 == env11634) = true)

def env11635 : List Nat := [2,4,8,16,32,64,128,256,168,1024,0,4096,5180,4176,5140,65536,1345,0,70043,5140,4097,5172,5457,70929,65839,5377,5425,4176,1297,65706,1285,4294967296,257,4295033230,1345,70963]

theorem envBound11635 : H12AffineFastState.Bounded env11635 := by
  intro p hp
  have h : env11635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11634_11635 : H12AffineEnvironment.transform 8 168 env11634 = env11635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 168 env11634 == env11635) = true)

theorem identity11635 : scanCanonicalize (H12AffineFastState.compose env11635 (packedSelected [5,8] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound11635 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env11636 : List Nat := [2,4,8,16,32,64,128,37,168,1024,0,4096,5180,4176,5140,65536,1124,0,69822,5140,4097,5172,5236,70708,65546,5156,5140,4176,1076,65706,1056,4294967296,36,4295033003,1124,70678]

theorem envBound11636 : H12AffineFastState.Bounded env11636 := by
  intro p hp
  have h : env11636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11635_11636 : H12AffineEnvironment.transform 7 37 env11635 = env11636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env11635 == env11636) = true)

theorem identity11636 : scanCanonicalize (H12AffineFastState.compose env11636 (packedSelected [2,7,9] rootPS)) = affineNative (2^(31+1) ^^^ 70733) := by decide +kernel

theorem selectedBound11636 : packedSelected [2,7,9] rootPS < 2^1333 := by decide +kernel

def env11637 : List Nat := [2,4,8,16,32,64,128,37,168,1024,0,4096,5180,4176,5140,65536,1124,0,69822,5140,4097,5172,5236,70708,65546,5156,5140,4176,1076,65706,1056,70733,36,5350,1124,70678]

theorem envBound11637 : H12AffineFastState.Bounded env11637 := by
  intro p hp
  have h : env11637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11636_11637 : H12AffineEnvironment.transform 31 70733 env11636 = env11637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 70733 env11636 == env11637) = true)

def env11638 : List Nat := [2,4,8,16,32,64,128,37,168,1024,0,4096,5180,4176,5140,5300,1124,0,1034,5140,4097,5172,5236,128,5310,5156,5140,4176,1076,5150,1056,249,36,5350,1124,162]

theorem envBound11638 : H12AffineFastState.Bounded env11638 := by
  intro p hp
  have h : env11638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11637_11638 : H12AffineEnvironment.transform 15 5300 env11637 = env11638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5300 env11637 == env11638) = true)

theorem identity11638 : scanCanonicalize (H12AffineFastState.compose env11638 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 1054) := by decide +kernel

theorem selectedBound11638 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env11639 : List Nat := [2,4,8,16,32,64,128,37,168,1024,0,1054,34,1102,10,170,1124,0,1034,10,1055,42,106,128,160,58,10,1102,1076,0,1056,249,36,248,1124,162]

theorem envBound11639 : H12AffineFastState.Bounded env11639 := by
  intro p hp
  have h : env11639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11638_11639 : H12AffineEnvironment.transform 11 1054 env11638 = env11639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1054 env11638 == env11639) = true)

theorem identity11639 : scanCanonicalize (H12AffineFastState.compose env11639 (packedSelected [2,3,13] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound11639 : packedSelected [2,3,13] rootPS < 2^1333 := by decide +kernel

def env11640 : List Nat := [2,4,8,16,32,64,120,37,80,1024,0,1054,34,1102,10,82,1124,0,1034,10,1055,42,106,120,88,58,10,1102,1076,0,1056,1,36,0,1124,90]

theorem envBound11640 : H12AffineFastState.Bounded env11640 := by
  intro p hp
  have h : env11640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11639_11640 : H12AffineEnvironment.transform 6 120 env11639 = env11640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env11639 == env11640) = true)

theorem identity11640 : scanCanonicalize (H12AffineFastState.compose env11640 (packedSelected [2,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound11640 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env11641 : List Nat := [2,4,8,16,0,64,88,5,80,1024,0,1054,2,1102,10,82,1092,0,1034,10,1055,10,74,88,88,26,10,1102,1044,0,1024,1,4,0,1092,90]

theorem envBound11641 : H12AffineFastState.Bounded env11641 := by
  intro p hp
  have h : env11641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11640_11641 : H12AffineEnvironment.transform 4 0 env11640 = env11641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env11640 == env11641) = true)

theorem identity11641 : scanCanonicalize (H12AffineFastState.compose env11641 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound11641 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11642 : List Nat := [2,4,3,16,0,64,83,5,80,1024,0,1045,2,1093,1,82,1092,0,1025,1,1044,1,65,83,83,17,1,1093,1044,0,1024,1,4,0,1092,81]

theorem envBound11642 : H12AffineFastState.Bounded env11642 := by
  intro p hp
  have h : env11642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11641_11642 : H12AffineEnvironment.transform 2 3 env11641 = env11642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env11641 == env11642) = true)

theorem identity11642 : scanCanonicalize (H12AffineFastState.compose env11642 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound11642 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11643 : List Nat := [2,4,3,16,0,0,19,5,16,1024,0,1045,2,1029,1,18,1028,0,1025,1,1044,1,1,19,19,17,1,1029,1044,0,1024,1,4,0,1028,17]

theorem envBound11643 : H12AffineFastState.Bounded env11643 := by
  intro p hp
  have h : env11643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11642_11643 : H12AffineEnvironment.transform 5 0 env11642 = env11643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env11642 == env11643) = true)

def env11644 : List Nat := [2,4,8,16,32,64,128,37,168,1024,0,4096,5180,4176,5140,5301,1124,0,1035,5140,4097,5172,5236,129,5311,5156,5140,4176,1076,5151,1056,248,36,5350,1124,163]

theorem envBound11644 : H12AffineFastState.Bounded env11644 := by
  intro p hp
  have h : env11644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11637_11644 : H12AffineEnvironment.transform 15 5301 env11637 = env11644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5301 env11637 == env11644) = true)

theorem identity11644 : scanCanonicalize (H12AffineFastState.compose env11644 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 1045) := by decide +kernel

theorem selectedBound11644 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env11645 : List Nat := [2,4,8,16,32,64,128,37,168,1024,0,1045,41,1093,1,160,1124,0,1035,1,1044,33,97,129,170,49,1,1093,1076,10,1056,248,36,243,1124,163]

theorem envBound11645 : H12AffineFastState.Bounded env11645 := by
  intro p hp
  have h : env11645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11644_11645 : H12AffineEnvironment.transform 11 1045 env11644 = env11645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1045 env11644 == env11645) = true)

theorem identity11645 : scanCanonicalize (H12AffineFastState.compose env11645 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound11645 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env11646 : List Nat := [2,4,8,16,0,64,128,5,136,1024,0,1045,9,1093,1,128,1092,0,1035,1,1044,1,65,129,138,17,1,1093,1044,10,1024,216,4,211,1092,131]

theorem envBound11646 : H12AffineFastState.Bounded env11646 := by
  intro p hp
  have h : env11646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11645_11646 : H12AffineEnvironment.transform 4 0 env11645 = env11646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env11645 == env11646) = true)

theorem identity11646 : scanCanonicalize (H12AffineFastState.compose env11646 (packedSelected [1,2,13] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound11646 : packedSelected [1,2,13] rootPS < 2^1333 := by decide +kernel

def env11647 : List Nat := [2,4,8,16,0,64,89,5,81,1024,0,1045,9,1093,1,89,1092,0,1035,1,1044,1,65,88,83,17,1,1093,1044,10,1024,1,4,10,1092,90]

theorem envBound11647 : H12AffineFastState.Bounded env11647 := by
  intro p hp
  have h : env11647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11646_11647 : H12AffineEnvironment.transform 6 89 env11646 = env11647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env11646 == env11647) = true)

theorem identity11647 : scanCanonicalize (H12AffineFastState.compose env11647 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound11647 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env11648 : List Nat := [2,4,2,16,0,64,83,5,81,1024,0,1045,3,1093,1,83,1092,0,1025,1,1044,1,65,82,83,17,1,1093,1044,0,1024,1,4,0,1092,80]

theorem envBound11648 : H12AffineFastState.Bounded env11648 := by
  intro p hp
  have h : env11648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11647_11648 : H12AffineEnvironment.transform 2 2 env11647 = env11648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env11647 == env11648) = true)

theorem identity11648 : scanCanonicalize (H12AffineFastState.compose env11648 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound11648 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11649 : List Nat := [2,4,2,16,0,1,18,5,16,1024,0,1045,3,1028,1,18,1029,0,1025,1,1044,1,0,19,18,17,1,1028,1044,0,1024,1,4,0,1029,17]

theorem envBound11649 : H12AffineFastState.Bounded env11649 := by
  intro p hp
  have h : env11649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11648_11649 : H12AffineEnvironment.transform 5 1 env11648 = env11649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env11648 == env11649) = true)

def env11650 : List Nat := [2,4,8,16,32,64,128,256,169,1024,0,4096,5181,4177,5140,65536,1345,0,70042,5140,4097,5173,5456,70929,65838,5377,5425,4177,1297,65706,1285,4294967296,257,4295033231,1345,70962]

theorem envBound11650 : H12AffineFastState.Bounded env11650 := by
  intro p hp
  have h : env11650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11634_11650 : H12AffineEnvironment.transform 8 169 env11634 = env11650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 169 env11634 == env11650) = true)

theorem identity11650 : scanCanonicalize (H12AffineFastState.compose env11650 (packedSelected [5,8] rootPS)) = affineNative (2^(15+1) ^^^ 5279) := by decide +kernel

theorem selectedBound11650 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env11651 : List Nat := [2,4,8,16,32,64,128,256,169,1024,0,4096,5181,4177,5140,5279,1345,0,1285,5140,4097,5173,5456,398,5553,5377,5425,4177,1297,5173,1285,4294967296,257,4294972688,1345,429]

theorem envBound11651 : H12AffineFastState.Bounded env11651 := by
  intro p hp
  have h : env11651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11650_11651 : H12AffineEnvironment.transform 15 5279 env11650 = env11651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5279 env11650 == env11651) = true)

theorem identity11651 : scanCanonicalize (H12AffineFastState.compose env11651 (packedSelected [3,5,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 1328) := by decide +kernel

theorem selectedBound11651 : packedSelected [3,5,10,12] rootPS < 2^1333 := by decide +kernel

def env11652 : List Nat := [2,4,8,16,32,64,128,256,169,1024,0,1328,269,1377,292,431,1345,0,1285,292,1329,261,96,398,129,49,1,1377,1297,261,1285,4294967296,257,4294967328,1345,429]

theorem envBound11652 : H12AffineFastState.Bounded env11652 := by
  intro p hp
  have h : env11652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11651_11652 : H12AffineEnvironment.transform 11 1328 env11651 = env11652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1328 env11651 == env11652) = true)

def env11653 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8832,65536,131072,1,524288,8832,2097152,8200,17665,206532,33554432,5377,2253852,16384,131152,33698041,131140,4294967296,257,4329271999,131072,33563272]

theorem envBound11653 : H12AffineFastState.Bounded env11653 := by
  intro p hp
  have h : env11653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11613_11653 : H12AffineEnvironment.transform 17 1 env11613 = env11653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1 env11613 == env11653) = true)

def env11654 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8832,65536,1344,1,524288,8832,2097152,8200,17665,74628,33554432,5377,2122076,16384,1296,33568185,1284,4294967296,257,4329142271,1344,33563272]

theorem envBound11654 : H12AffineFastState.Bounded env11654 := by
  intro p hp
  have h : env11654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11653_11654 : H12AffineEnvironment.transform 16 1344 env11653 = env11654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env11653 == env11654) = true)

theorem identity11654 : scanCanonicalize (H12AffineFastState.compose env11654 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 4097) := by decide +kernel

theorem selectedBound11654 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env11655 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8832,65536,1344,1,524288,8832,4097,8200,17665,74628,33554432,5377,29021,16384,1296,33568185,1284,4294967296,257,4329142271,1344,33563272]

theorem envBound11655 : H12AffineFastState.Bounded env11655 := by
  intro p hp
  have h : env11655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11654_11655 : H12AffineEnvironment.transform 20 4097 env11654 = env11655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env11654 == env11655) = true)

theorem identity11655 : scanCanonicalize (H12AffineFastState.compose env11655 (packedSelected [20] rootPS)) = affineNative (2^(13+1) ^^^ 4824) := by decide +kernel

theorem selectedBound11655 : packedSelected [20] rootPS < 2^1333 := by decide +kernel

def env11656 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,4824,8832,65536,1344,1,524288,8832,4097,8200,6105,74628,33554432,5377,9093,4824,1296,33568185,1284,4294967296,257,4329121063,1344,33563272]

theorem envBound11656 : H12AffineFastState.Bounded env11656 := by
  intro p hp
  have h : env11656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11655_11656 : H12AffineEnvironment.transform 13 4824 env11655 = env11656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4824 env11655 == env11656) = true)

theorem identity11656 : scanCanonicalize (H12AffineFastState.compose env11656 (packedSelected [5,8,12,13,15,17,24,28] rootPS)) = affineNative (2^(24+1) ^^^ 5661) := by decide +kernel

theorem selectedBound11656 : packedSelected [5,8,12,13,15,17,24,28] rootPS < 2^1333 := by decide +kernel

def env11657 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,4824,8832,65536,1344,1,524288,8832,4097,8200,6105,74628,5661,5377,9093,4824,1296,9124,1284,4294967296,257,4295570234,1344,13461]

theorem envBound11657 : H12AffineFastState.Bounded env11657 := by
  intro p hp
  have h : env11657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11656_11657 : H12AffineEnvironment.transform 24 5661 env11656 = env11657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 5661 env11656 == env11657) = true)

theorem identity11657 : scanCanonicalize (H12AffineFastState.compose env11657 (packedSelected [9,18,22,23] rootPS)) = affineNative (2^(12+1) ^^^ 5149) := by decide +kernel

theorem selectedBound11657 : packedSelected [9,18,22,23] rootPS < 2^1333 := by decide +kernel

def env11658 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,5149,4824,5789,65536,1344,1,524288,5789,4097,5141,6105,71577,5661,5377,6040,4824,1296,6073,1284,4294967296,257,4295558951,1344,136]

theorem envBound11658 : H12AffineFastState.Bounded env11658 := by
  intro p hp
  have h : env11658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11657_11658 : H12AffineEnvironment.transform 12 5149 env11657 = env11658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5149 env11657 == env11658) = true)

theorem identity11658 : scanCanonicalize (H12AffineFastState.compose env11658 (packedSelected [5,8,16] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound11658 : packedSelected [5,8,16] rootPS < 2^1333 := by decide +kernel

def env11659 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,4096,5149,4177,5140,65536,1344,1,524288,5140,4097,5141,5456,70928,5268,5377,5393,4177,1296,5424,1284,4294967296,257,4295558574,1344,136]

theorem envBound11659 : H12AffineFastState.Bounded env11659 := by
  intro p hp
  have h : env11659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11658_11659 : H12AffineEnvironment.transform 8 137 env11658 = env11659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env11658 == env11659) = true)

theorem identity11659 : scanCanonicalize (H12AffineFastState.compose env11659 (packedSelected [0,7] rootPS)) = affineNative (2^(18+1) ^^^ 70074) := by decide +kernel

theorem selectedBound11659 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env11660 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,4096,5149,4177,5140,65536,1344,1,70074,5140,4097,5141,5456,70928,5268,5377,5393,4177,1296,5424,1284,4294967296,257,4294972436,1344,136]

theorem envBound11660 : H12AffineFastState.Bounded env11660 := by
  intro p hp
  have h : env11660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11659_11660 : H12AffineEnvironment.transform 18 70074 env11659 = env11660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 70074 env11659 == env11660) = true)

theorem identity11660 : scanCanonicalize (H12AffineFastState.compose env11660 (packedSelected [0,2,4,5,6,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound11660 : packedSelected [0,2,4,5,6,8] rootPS < 2^1333 := by decide +kernel

def env11661 : List Nat := [2,4,8,16,1,64,128,256,137,1024,0,4096,5149,4177,5140,65536,1344,1,70043,5140,4097,5141,5456,70928,5268,5377,5393,4177,1296,5393,1284,4294967296,257,4294972436,1344,136]

theorem envBound11661 : H12AffineFastState.Bounded env11661 := by
  intro p hp
  have h : env11661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11660_11661 : H12AffineEnvironment.transform 4 1 env11660 = env11661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env11660 == env11661) = true)

theorem identity11661 : scanCanonicalize (H12AffineFastState.compose env11661 (packedSelected [1,2,4,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound11661 : packedSelected [1,2,4,5,10] rootPS < 2^1333 := by decide +kernel

def env11662 : List Nat := [2,4,8,16,1,64,89,256,80,1024,0,4096,5149,4177,5140,65536,1344,1,69954,5140,4097,5141,5456,70928,5197,5377,5393,4177,1296,5393,1284,4294967296,257,4294972436,1344,81]

theorem envBound11662 : H12AffineFastState.Bounded env11662 := by
  intro p hp
  have h : env11662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11661_11662 : H12AffineEnvironment.transform 6 89 env11661 = env11662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env11661 == env11662) = true)

theorem identity11662 : scanCanonicalize (H12AffineFastState.compose env11662 (packedSelected [1,3] rootPS)) = affineNative (2^(15+1) ^^^ 5190) := by decide +kernel

theorem selectedBound11662 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env11663 : List Nat := [2,4,8,16,1,64,89,256,80,1024,0,4096,5149,4177,5140,5190,1344,1,1284,5140,4097,5141,5456,342,5197,5377,5393,4177,1296,5393,1284,4294967296,257,4294972436,1344,81]

theorem envBound11663 : H12AffineFastState.Bounded env11663 := by
  intro p hp
  have h : env11663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11662_11663 : H12AffineEnvironment.transform 15 5190 env11662 = env11663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5190 env11662 == env11663) = true)

theorem identity11663 : scanCanonicalize (H12AffineFastState.compose env11663 (packedSelected [2,4] rootPS)) = affineNative (2^(11+1) ^^^ 1044) := by decide +kernel

theorem selectedBound11663 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env11664 : List Nat := [2,4,8,16,1,64,89,256,80,1024,0,1044,9,1093,0,82,1344,1,1284,0,1045,1,324,342,89,277,261,1093,1296,261,1284,4294967296,257,4294967296,1344,81]

theorem envBound11664 : H12AffineFastState.Bounded env11664 := by
  intro p hp
  have h : env11664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11663_11664 : H12AffineEnvironment.transform 11 1044 env11663 = env11664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1044 env11663 == env11664) = true)

theorem identity11664 : scanCanonicalize (H12AffineFastState.compose env11664 (packedSelected [0,2] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound11664 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env11665 : List Nat := [2,4,8,16,1,10,19,256,26,1024,0,1044,9,1039,0,24,1290,1,1284,0,1045,1,270,284,19,277,261,1039,1296,261,1284,4294967296,257,4294967296,1290,27]

theorem envBound11665 : H12AffineFastState.Bounded env11665 := by
  intro p hp
  have h : env11665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11664_11665 : H12AffineEnvironment.transform 5 10 env11664 = env11665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env11664 == env11665) = true)

theorem identity11665 : scanCanonicalize (H12AffineFastState.compose env11665 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 0) := by decide +kernel

theorem selectedBound11665 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11666 : List Nat := [2,4,8,16,1,10,19,256,26,1024,0,1044,9,1039,0,24,1290,1,1284,0,1045,1,270,284,19,277,261,1039,1296,261,1284,0,257,0,1290,27]

theorem envBound11666 : H12AffineFastState.Bounded env11666 := by
  intro p hp
  have h : env11666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11665_11666 : H12AffineEnvironment.transform 31 0 env11665 = env11666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 0 env11665 == env11666) = true)

def env11667 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8832,65536,1345,1,524288,8832,2097152,8200,17665,74629,33554432,5377,2122077,16384,1297,33568184,1285,4294967296,257,4329142270,1345,33563272]

theorem envBound11667 : H12AffineFastState.Bounded env11667 := by
  intro p hp
  have h : env11667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11653_11667 : H12AffineEnvironment.transform 16 1345 env11653 = env11667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env11653 == env11667) = true)

theorem identity11667 : scanCanonicalize (H12AffineFastState.compose env11667 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(24+1) ^^^ 2647257) := by decide +kernel

theorem selectedBound11667 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env11668 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8832,65536,1345,1,524288,8832,2097152,8200,17665,74629,2647257,5377,2122077,16384,1297,2642273,1285,4294967296,257,4297134887,1345,2639441]

theorem envBound11668 : H12AffineFastState.Bounded env11668 := by
  intro p hp
  have h : env11668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11667_11668 : H12AffineEnvironment.transform 24 2647257 env11667 = env11668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 2647257 env11667 == env11668) = true)

theorem identity11668 : scanCanonicalize (H12AffineFastState.compose env11668 (packedSelected [1,3,4,5,6,7,8,9,10,13,16,17,19,20,21,25,27,33] rootPS)) = affineNative (2^(18+1) ^^^ 70450) := by decide +kernel

theorem selectedBound11668 : packedSelected [1,3,4,5,6,7,8,9,10,13,16,17,19,20,21,25,27,33] rootPS < 2^1333 := by decide +kernel

def env11669 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8832,65536,1345,1,70450,8832,2097152,8200,17665,74629,2193387,5377,2122077,16384,1297,2179667,1285,4294967296,257,4297134887,1345,2184547]

theorem envBound11669 : H12AffineFastState.Bounded env11669 := by
  intro p hp
  have h : env11669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11668_11669 : H12AffineEnvironment.transform 18 70450 env11668 = env11669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 70450 env11668 == env11669) = true)

theorem identity11669 : scanCanonicalize (H12AffineFastState.compose env11669 (packedSelected [1,5,6,8,19,24,25,26] rootPS)) = affineNative (2^(20+1) ^^^ 4097) := by decide +kernel

theorem selectedBound11669 : packedSelected [1,5,6,8,19,24,25,26] rootPS < 2^1333 := by decide +kernel

def env11670 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8832,65536,1345,1,70450,8832,4097,8200,17665,74629,92138,5377,29020,16384,1297,86610,1285,4294967296,257,4295033638,1345,83298]

theorem envBound11670 : H12AffineFastState.Bounded env11670 := by
  intro p hp
  have h : env11670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11669_11670 : H12AffineEnvironment.transform 20 4097 env11669 = env11670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env11669 == env11670) = true)

theorem identity11670 : scanCanonicalize (H12AffineFastState.compose env11670 (packedSelected [20] rootPS)) = affineNative (2^(13+1) ^^^ 1993) := by decide +kernel

theorem selectedBound11670 : packedSelected [20] rootPS < 2^1333 := by decide +kernel

def env11671 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,1993,8832,65536,1345,1,70450,8832,4097,8200,712,74629,73763,5377,13973,1993,1297,71067,1285,4294967296,257,4295033638,1345,66219]

theorem envBound11671 : H12AffineFastState.Bounded env11671 := by
  intro p hp
  have h : env11671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11670_11671 : H12AffineEnvironment.transform 13 1993 env11670 = env11671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1993 env11670 == env11671) = true)

theorem identity11671 : scanCanonicalize (H12AffineFastState.compose env11671 (packedSelected [1,3,5,8,10,16,18,19] rootPS)) = affineNative (2^(11+1) ^^^ 1328) := by decide +kernel

theorem selectedBound11671 : packedSelected [1,3,5,8,10,16,18,19] rootPS < 2^1333 := by decide +kernel

def env11672 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1328,8192,1993,8832,65536,1345,1,67074,8832,1329,8200,712,74629,73763,49,9125,1993,1297,65707,1285,4294967296,257,4295033638,1345,66219]

theorem envBound11672 : H12AffineFastState.Bounded env11672 := by
  intro p hp
  have h : env11672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11671_11672 : H12AffineEnvironment.transform 11 1328 env11671 = env11672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1328 env11671 == env11672) = true)

theorem identity11672 : scanCanonicalize (H12AffineFastState.compose env11672 (packedSelected [0,4,7,9,16,18] rootPS)) = affineNative (2^(15+1) ^^^ 171) := by decide +kernel

theorem selectedBound11672 : packedSelected [0,4,7,9,16,18] rootPS < 2^1333 := by decide +kernel

def env11673 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1328,8192,1993,8832,171,1345,1,1705,8832,1329,8200,712,9006,8328,49,9125,1993,1297,0,1285,4294967296,257,4294968205,1345,512]

theorem envBound11673 : H12AffineFastState.Bounded env11673 := by
  intro p hp
  have h : env11673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11672_11673 : H12AffineEnvironment.transform 15 171 env11672 = env11673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 171 env11672 == env11673) = true)

theorem identity11673 : scanCanonicalize (H12AffineFastState.compose env11673 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(12+1) ^^^ 651) := by decide +kernel

theorem selectedBound11673 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env11674 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1328,651,1993,11,171,1345,1,1705,11,1329,643,712,421,515,49,302,1993,1297,0,1285,4294967296,257,4294968205,1345,512]

theorem envBound11674 : H12AffineFastState.Bounded env11674 := by
  intro p hp
  have h : env11674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11673_11674 : H12AffineEnvironment.transform 12 651 env11673 = env11674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 651 env11673 == env11674) = true)

theorem identity11674 : scanCanonicalize (H12AffineFastState.compose env11674 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound11674 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env11675 : List Nat := [2,4,8,16,32,64,128,256,32,1024,0,1328,171,1513,11,171,1345,1,1161,11,1329,163,232,421,35,49,302,1513,1297,0,1285,4294967296,257,4294967725,1345,32]

theorem envBound11675 : H12AffineFastState.Bounded env11675 := by
  intro p hp
  have h : env11675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11674_11675 : H12AffineEnvironment.transform 8 32 env11674 = env11675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env11674 == env11675) = true)

theorem identity11675 : scanCanonicalize (H12AffineFastState.compose env11675 (packedSelected [2,4,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 16) := by decide +kernel

theorem selectedBound11675 : packedSelected [2,4,5,8] rootPS < 2^1333 := by decide +kernel

def env11676 : List Nat := [2,4,8,16,32,64,16,256,32,1024,0,1328,59,1401,11,59,1345,1,1049,11,1329,51,120,309,35,49,302,1401,1297,0,1285,4294967296,257,4294967613,1345,32]

theorem envBound11676 : H12AffineFastState.Bounded env11676 := by
  intro p hp
  have h : env11676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11675_11676 : H12AffineEnvironment.transform 6 16 env11675 = env11676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 16 env11675 == env11676) = true)

theorem identity11676 : scanCanonicalize (H12AffineFastState.compose env11676 (packedSelected [4,9] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound11676 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env11677 : List Nat := [2,4,8,9,32,64,9,256,32,1024,0,1321,34,1376,11,34,1345,1,1024,11,1320,42,97,300,35,40,302,1376,1288,0,1285,4294967296,257,4294967588,1345,32]

theorem envBound11677 : H12AffineFastState.Bounded env11677 := by
  intro p hp
  have h : env11677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11676_11677 : H12AffineEnvironment.transform 3 9 env11676 = env11677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env11676 == env11677) = true)

theorem identity11677 : scanCanonicalize (H12AffineFastState.compose env11677 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 323) := by decide +kernel

theorem selectedBound11677 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env11678 : List Nat := [2,4,8,9,32,64,9,256,32,323,0,106,34,35,11,34,2,1,323,11,107,42,97,300,35,40,302,35,75,0,70,4294967296,257,4294967588,2,32]

theorem envBound11678 : H12AffineFastState.Bounded env11678 := by
  intro p hp
  have h : env11678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11677_11678 : H12AffineEnvironment.transform 9 323 env11677 = env11678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 323 env11677 == env11678) = true)

theorem identity11678 : scanCanonicalize (H12AffineFastState.compose env11678 (packedSelected [3,5,12,13] rootPS)) = affineNative (2^(5+1) ^^^ 3) := by decide +kernel

theorem selectedBound11678 : packedSelected [3,5,12,13] rootPS < 2^1333 := by decide +kernel

def env11679 : List Nat := [2,4,8,9,32,3,9,256,32,256,0,41,34,35,11,34,2,1,256,11,40,42,34,300,35,40,302,35,8,0,5,4294967296,257,4294967588,2,32]

theorem envBound11679 : H12AffineFastState.Bounded env11679 := by
  intro p hp
  have h : env11679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11678_11679 : H12AffineEnvironment.transform 5 3 env11678 = env11679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 3 env11678 == env11679) = true)

theorem identity11679 : scanCanonicalize (H12AffineFastState.compose env11679 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound11679 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11680 : List Nat := [2,4,8,9,1,3,9,256,1,256,0,8,3,2,11,3,2,1,256,11,9,11,3,269,2,9,271,2,8,0,5,4294967296,257,4294967557,2,1]

theorem envBound11680 : H12AffineFastState.Bounded env11680 := by
  intro p hp
  have h : env11680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11679_11680 : H12AffineEnvironment.transform 4 1 env11679 = env11680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env11679 == env11680) = true)

theorem identity11680 : scanCanonicalize (H12AffineFastState.compose env11680 (packedSelected [2,4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound11680 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env11681 : List Nat := [2,4,8,9,1,3,9,5,1,5,0,8,3,2,11,3,2,1,5,11,9,11,3,8,2,9,10,2,8,0,5,4294967296,4,4294967296,2,1]

theorem envBound11681 : H12AffineFastState.Bounded env11681 := by
  intro p hp
  have h : env11681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11680_11681 : H12AffineEnvironment.transform 7 5 env11680 = env11681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env11680 == env11681) = true)

theorem identity11681 : scanCanonicalize (H12AffineFastState.compose env11681 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 11) := by decide +kernel

theorem selectedBound11681 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11682 : List Nat := [2,4,8,9,1,3,9,5,1,5,0,8,3,2,11,3,2,1,5,11,9,11,3,8,2,9,10,2,8,0,5,11,4,11,2,1]

theorem envBound11682 : H12AffineFastState.Bounded env11682 := by
  intro p hp
  have h : env11682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11681_11682 : H12AffineEnvironment.transform 31 11 env11681 = env11682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 11 env11681 == env11682) = true)

def env11683 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8832,65536,131072,262144,524288,8832,2097152,8201,17665,206532,33554432,5377,2515996,16384,131152,1073741824,131140,4294967296,257,4329271998,131072,33563272]

theorem envBound11683 : H12AffineFastState.Bounded env11683 := by
  intro p hp
  have h : env11683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11611_11683 : H12AffineEnvironment.transform 10 1 env11611 = env11683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env11611 == env11683) = true)

theorem identity11683 : scanCanonicalize (H12AffineFastState.compose env11683 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 2249353) := by decide +kernel

theorem selectedBound11683 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env11684 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8832,65536,131072,262144,524288,8832,2097152,8201,17665,206532,33554432,5377,2515996,16384,131152,2249353,131140,4294967296,257,4329271998,131072,33563272]

theorem envBound11684 : H12AffineFastState.Bounded env11684 := by
  intro p hp
  have h : env11684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11683_11684 : H12AffineEnvironment.transform 29 2249353 env11683 = env11684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 2249353 env11683 == env11684) = true)

def env11685 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8832,65536,131072,0,524288,8832,2097152,8201,17665,206532,33554432,5377,2253852,16384,131152,2249353,131140,4294967296,257,4329271998,131072,33563272]

theorem envBound11685 : H12AffineFastState.Bounded env11685 := by
  intro p hp
  have h : env11685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11684_11685 : H12AffineEnvironment.transform 17 0 env11684 = env11685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 0 env11684 == env11685) = true)

def env11686 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8832,65536,1344,0,524288,8832,2097152,8201,17665,74628,33554432,5377,2122076,16384,1296,2119625,1284,4294967296,257,4329142270,1344,33563272]

theorem envBound11686 : H12AffineFastState.Bounded env11686 := by
  intro p hp
  have h : env11686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11685_11686 : H12AffineEnvironment.transform 16 1344 env11685 = env11686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env11685 == env11686) = true)

theorem identity11686 : scanCanonicalize (H12AffineFastState.compose env11686 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 4097) := by decide +kernel

theorem selectedBound11686 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env11687 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8832,65536,1344,0,524288,8832,4097,8201,17665,74628,33554432,5377,29021,16384,1296,18376,1284,4294967296,257,4329142270,1344,33563272]

theorem envBound11687 : H12AffineFastState.Bounded env11687 := by
  intro p hp
  have h : env11687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11686_11687 : H12AffineEnvironment.transform 20 4097 env11686 = env11687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env11686 == env11687) = true)

theorem identity11687 : scanCanonicalize (H12AffineFastState.compose env11687 (packedSelected [20] rootPS)) = affineNative (2^(12+1) ^^^ 5812) := by decide +kernel

theorem selectedBound11687 : packedSelected [20] rootPS < 2^1333 := by decide +kernel

def env11688 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,5812,16384,5172,65536,1344,0,524288,5172,4097,5821,17665,70960,33554432,5377,18409,16384,1296,18376,1284,4294967296,257,4329128266,1344,33559612]

theorem envBound11688 : H12AffineFastState.Bounded env11688 := by
  intro p hp
  have h : env11688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11687_11688 : H12AffineEnvironment.transform 12 5812 env11687 = env11688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5812 env11687 == env11688) = true)

theorem identity11688 : scanCanonicalize (H12AffineFastState.compose env11688 (packedSelected [5,8,12,13,15,17,24,28] rootPS)) = affineNative (2^(13+1) ^^^ 4824) := by decide +kernel

theorem selectedBound11688 : packedSelected [5,8,12,13,15,17,24,28] rootPS < 2^1333 := by decide +kernel

def env11689 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,5812,4824,5172,65536,1344,0,524288,5172,4097,5821,6105,70960,33554432,5377,5425,4824,1296,5392,1284,4294967296,257,4329116562,1344,33559612]

theorem envBound11689 : H12AffineFastState.Bounded env11689 := by
  intro p hp
  have h : env11689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11688_11689 : H12AffineEnvironment.transform 13 4824 env11688 = env11689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4824 env11688 == env11689) = true)

theorem identity11689 : scanCanonicalize (H12AffineFastState.compose env11689 (packedSelected [9,18,22,23] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound11689 : packedSelected [9,18,22,23] rootPS < 2^1333 := by decide +kernel

def env11690 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,4096,5181,4177,5172,65536,1344,0,524288,5172,4097,5172,5456,70960,33554432,5377,5425,4177,1296,5392,1284,4294967296,257,4329115931,1344,33559612]

theorem envBound11690 : H12AffineFastState.Bounded env11690 := by
  intro p hp
  have h : env11690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11689_11690 : H12AffineEnvironment.transform 8 137 env11689 = env11690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env11689 == env11690) = true)

theorem identity11690 : scanCanonicalize (H12AffineFastState.compose env11690 (packedSelected [0,1,3,4,7,9,10,18,19] rootPS)) = affineNative (2^(18+1) ^^^ 70075) := by decide +kernel

theorem selectedBound11690 : packedSelected [0,1,3,4,7,9,10,18,19] rootPS < 2^1333 := by decide +kernel

def env11691 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,4096,5181,4177,5172,65536,1344,0,70075,5172,4097,5172,5456,70960,33554432,5377,5425,4177,1296,5392,1284,4294967296,257,4328521888,1344,33559612]

theorem envBound11691 : H12AffineFastState.Bounded env11691 := by
  intro p hp
  have h : env11691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11690_11691 : H12AffineEnvironment.transform 18 70075 env11690 = env11691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 70075 env11690 == env11691) = true)

theorem identity11691 : scanCanonicalize (H12AffineFastState.compose env11691 (packedSelected [5,8,16] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound11691 : packedSelected [5,8,16] rootPS < 2^1333 := by decide +kernel

def env11692 : List Nat := [2,4,8,16,1,64,128,256,137,1024,1,4096,5148,4177,5141,65536,1344,0,70042,5141,4097,5141,5456,70929,33554432,5377,5392,4177,1296,5392,1284,4294967296,257,4328521857,1344,33559581]

theorem envBound11692 : H12AffineFastState.Bounded env11692 := by
  intro p hp
  have h : env11692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11691_11692 : H12AffineEnvironment.transform 4 1 env11691 = env11692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env11691 == env11692) = true)

theorem identity11692 : scanCanonicalize (H12AffineFastState.compose env11692 (packedSelected [1,10,15,18] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound11692 : packedSelected [1,10,15,18] rootPS < 2^1333 := by decide +kernel

def env11693 : List Nat := [2,4,8,16,1,64,128,256,137,1024,1,4096,5148,4177,5141,343,1344,0,4301,5141,4097,5141,5456,5190,33554432,5377,5392,4177,1296,5392,1284,4294967296,257,4328521857,1344,33559581]

theorem envBound11693 : H12AffineFastState.Bounded env11693 := by
  intro p hp
  have h : env11693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11692_11693 : H12AffineEnvironment.transform 15 343 env11692 = env11693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env11692 == env11693) = true)

theorem identity11693 : scanCanonicalize (H12AffineFastState.compose env11693 (packedSelected [5,10,15,21] rootPS)) = affineNative (2^(24+1) ^^^ 349) := by decide +kernel

theorem selectedBound11693 : packedSelected [5,10,15,21] rootPS < 2^1333 := by decide +kernel

def env11694 : List Nat := [2,4,8,16,1,64,128,256,137,1024,1,4096,5148,4177,5141,343,1344,0,4301,5141,4097,5141,5456,5190,349,5377,5392,4177,1296,5392,1284,4294967296,257,4294967772,1344,5440]

theorem envBound11694 : H12AffineFastState.Bounded env11694 := by
  intro p hp
  have h : env11694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11693_11694 : H12AffineEnvironment.transform 24 349 env11693 = env11694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 349 env11693 == env11694) = true)

theorem identity11694 : scanCanonicalize (H12AffineFastState.compose env11694 (packedSelected [3,5,8,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 1044) := by decide +kernel

theorem selectedBound11694 : packedSelected [3,5,8,10,12] rootPS < 2^1333 := by decide +kernel

def env11695 : List Nat := [2,4,8,16,1,64,128,256,137,1024,1,1044,8,1093,1,343,1344,0,1241,1,1045,1,324,82,349,277,260,1093,1296,260,1284,4294967296,257,4294967772,1344,340]

theorem envBound11695 : H12AffineFastState.Bounded env11695 := by
  intro p hp
  have h : env11695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11694_11695 : H12AffineEnvironment.transform 11 1044 env11694 = env11695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1044 env11694 == env11695) = true)

theorem identity11695 : scanCanonicalize (H12AffineFastState.compose env11695 (packedSelected [0,1,3,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 220) := by decide +kernel

theorem selectedBound11695 : packedSelected [0,1,3,5,7] rootPS < 2^1333 := by decide +kernel

def env11696 : List Nat := [2,4,8,16,1,64,128,220,137,1024,1,1044,8,1093,1,139,1180,0,1241,1,1045,1,152,82,129,201,216,1093,1228,216,1240,4294967296,221,4294967296,1180,136]

theorem envBound11696 : H12AffineFastState.Bounded env11696 := by
  intro p hp
  have h : env11696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11695_11696 : H12AffineEnvironment.transform 7 220 env11695 = env11696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 220 env11695 == env11696) = true)

theorem identity11696 : scanCanonicalize (H12AffineFastState.compose env11696 (packedSelected [0,2] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound11696 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env11697 : List Nat := [2,4,8,16,1,64,19,79,26,1024,1,1044,8,1093,1,24,1039,0,1098,1,1045,1,11,82,18,90,75,1093,1119,75,1099,4294967296,78,4294967296,1039,27]

theorem envBound11697 : H12AffineFastState.Bounded env11697 := by
  intro p hp
  have h : env11697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11696_11697 : H12AffineEnvironment.transform 6 19 env11696 = env11697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env11696 == env11697) = true)

theorem identity11697 : scanCanonicalize (H12AffineFastState.compose env11697 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 74) := by decide +kernel

theorem selectedBound11697 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11698 : List Nat := [2,4,8,16,1,64,19,79,26,1024,1,1044,8,1093,1,24,1039,0,1098,1,1045,1,11,82,18,90,75,1093,1119,75,1099,74,78,74,1039,27]

theorem envBound11698 : H12AffineFastState.Bounded env11698 := by
  intro p hp
  have h : env11698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11697_11698 : H12AffineEnvironment.transform 31 74 env11697 = env11698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 74 env11697 == env11698) = true)

theorem identity11698 : scanCanonicalize (H12AffineFastState.compose env11698 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound11698 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env11699 : List Nat := [2,4,8,16,1,11,19,4,26,1024,1,1044,8,1038,1,24,1039,0,1025,1,1045,1,11,25,18,17,0,1038,1044,0,1024,1,5,1,1039,27]

theorem envBound11699 : H12AffineFastState.Bounded env11699 := by
  intro p hp
  have h : env11699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11698_11699 : H12AffineEnvironment.transform 5 11 env11698 = env11699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env11698 == env11699) = true)

theorem identity11699 : scanCanonicalize (H12AffineFastState.compose env11699 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound11699 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11700 : List Nat := [2,4,3,16,1,0,19,4,17,1024,1,1044,3,1029,1,19,1028,0,1025,1,1045,1,0,18,18,17,0,1029,1044,0,1024,1,5,1,1028,16]

theorem envBound11700 : H12AffineFastState.Bounded env11700 := by
  intro p hp
  have h : env11700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11699_11700 : H12AffineEnvironment.transform 2 3 env11699 = env11700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env11699 == env11700) = true)

def env11701 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8832,65536,1345,0,524288,8832,2097152,8201,17665,74629,33554432,5377,2122077,16384,1297,2119624,1285,4294967296,257,4329142271,1345,33563272]

theorem envBound11701 : H12AffineFastState.Bounded env11701 := by
  intro p hp
  have h : env11701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11685_11701 : H12AffineEnvironment.transform 16 1345 env11685 = env11701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env11685 == env11701) = true)

theorem identity11701 : scanCanonicalize (H12AffineFastState.compose env11701 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(24+1) ^^^ 2647257) := by decide +kernel

theorem selectedBound11701 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env11702 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8832,65536,1345,0,524288,8832,2097152,8201,17665,74629,2647257,5377,2122077,16384,1297,2119624,1285,4294967296,257,4297134886,1345,2639441]

theorem envBound11702 : H12AffineFastState.Bounded env11702 := by
  intro p hp
  have h : env11702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11701_11702 : H12AffineEnvironment.transform 24 2647257 env11701 = env11702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 2647257 env11701 == env11702) = true)

theorem identity11702 : scanCanonicalize (H12AffineFastState.compose env11702 (packedSelected [1,3,4,5,6,7,8,9,10,13,16,17,19,20,21,25,27,33] rootPS)) = affineNative (2^(15+1) ^^^ 5531) := by decide +kernel

theorem selectedBound11702 : packedSelected [1,3,4,5,6,7,8,9,10,13,16,17,19,20,21,25,27,33] rootPS < 2^1333 := by decide +kernel

def env11703 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8832,5531,1345,0,524288,8832,2097152,8201,17665,13854,2647257,5377,2122077,16384,1297,2119624,1285,4294967296,257,4297066173,1345,2639441]

theorem envBound11703 : H12AffineFastState.Bounded env11703 := by
  intro p hp
  have h : env11703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11702_11703 : H12AffineEnvironment.transform 15 5531 env11702 = env11703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5531 env11702 == env11703) = true)

theorem identity11703 : scanCanonicalize (H12AffineFastState.compose env11703 (packedSelected [1,5,6,8,19,24,25,26] rootPS)) = affineNative (2^(20+1) ^^^ 4097) := by decide +kernel

theorem selectedBound11703 : packedSelected [1,5,6,8,19,24,25,26] rootPS < 2^1333 := by decide +kernel

def env11704 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8832,5531,1345,0,524288,8832,4097,8201,17665,13854,554200,5377,29020,16384,1297,18377,1285,4294967296,257,4294973116,1345,546384]

theorem envBound11704 : H12AffineFastState.Bounded env11704 := by
  intro p hp
  have h : env11704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11703_11704 : H12AffineEnvironment.transform 20 4097 env11703 = env11704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env11703 == env11704) = true)

theorem identity11704 : scanCanonicalize (H12AffineFastState.compose env11704 (packedSelected [20] rootPS)) = affineNative (2^(12+1) ^^^ 933) := by decide +kernel

theorem selectedBound11704 : packedSelected [20] rootPS < 2^1333 := by decide +kernel

def env11705 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,933,16384,293,5531,1345,0,524288,293,4097,940,17665,5563,546685,5377,21241,16384,1297,18377,1285,4294967296,257,4294973116,1345,546384]

theorem envBound11705 : H12AffineFastState.Bounded env11705 := by
  intro p hp
  have h : env11705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11704_11705 : H12AffineEnvironment.transform 12 933 env11704 = env11705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 933 env11704 == env11705) = true)

theorem identity11705 : scanCanonicalize (H12AffineFastState.compose env11705 (packedSelected [0,1,3,4,5,7,8,9,12,13,15,16,18,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 1992) := by decide +kernel

theorem selectedBound11705 : packedSelected [0,1,3,4,5,7,8,9,12,13,15,16,18,21,23] rootPS < 2^1333 := by decide +kernel

def env11706 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,933,1992,293,5531,1345,0,524288,293,4097,940,713,5563,528565,5377,5425,1992,1297,1,1285,4294967296,257,4294973116,1345,528792]

theorem envBound11706 : H12AffineFastState.Bounded env11706 := by
  intro p hp
  have h : env11706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11705_11706 : H12AffineEnvironment.transform 13 1992 env11705 = env11706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1992 env11705 == env11706) = true)

theorem identity11706 : scanCanonicalize (H12AffineFastState.compose env11706 (packedSelected [18] rootPS)) = affineNative (2^(18+1) ^^^ 5016) := by decide +kernel

theorem selectedBound11706 : packedSelected [18] rootPS < 2^1333 := by decide +kernel

def env11707 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,933,1992,293,5531,1345,0,5016,293,4097,940,713,5563,813,5377,5425,1992,1297,1,1285,4294967296,257,4294973116,1345,512]

theorem envBound11707 : H12AffineFastState.Bounded env11707 := by
  intro p hp
  have h : env11707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11706_11707 : H12AffineEnvironment.transform 18 5016 env11706 = env11707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 5016 env11706 == env11707) = true)

theorem identity11707 : scanCanonicalize (H12AffineFastState.compose env11707 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(7+1) ^^^ 47) := by decide +kernel

theorem selectedBound11707 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env11708 : List Nat := [2,4,8,16,32,64,128,47,512,1024,1,4096,650,1767,10,5300,1134,0,4791,10,4097,643,713,5268,514,5166,5150,1767,1086,1,1066,4294967296,46,4294973116,1134,512]

theorem envBound11708 : H12AffineFastState.Bounded env11708 := by
  intro p hp
  have h : env11708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11707_11708 : H12AffineEnvironment.transform 7 47 env11707 = env11708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 47 env11707 == env11708) = true)

theorem identity11708 : scanCanonicalize (H12AffineFastState.compose env11708 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1598) := by decide +kernel

theorem selectedBound11708 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env11709 : List Nat := [2,4,8,16,32,64,128,47,512,1024,1,1598,650,1767,10,650,1134,0,1161,10,1599,643,713,682,514,528,544,1767,1086,1,1066,4294967296,46,4294967426,1134,512]

theorem envBound11709 : H12AffineFastState.Bounded env11709 := by
  intro p hp
  have h : env11709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11708_11709 : H12AffineEnvironment.transform 11 1598 env11708 = env11709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1598 env11708 == env11709) = true)

theorem identity11709 : scanCanonicalize (H12AffineFastState.compose env11709 (packedSelected [4,9] rootPS)) = affineNative (2^(8+1) ^^^ 169) := by decide +kernel

theorem selectedBound11709 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env11710 : List Nat := [2,4,8,16,32,64,128,47,169,1024,1,1175,35,1102,10,35,1134,0,1161,10,1174,42,96,3,171,185,137,1102,1086,1,1066,4294967296,46,4294967426,1134,169]

theorem envBound11710 : H12AffineFastState.Bounded env11710 := by
  intro p hp
  have h : env11710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11709_11710 : H12AffineEnvironment.transform 8 169 env11709 = env11710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 169 env11709 == env11710) = true)

theorem identity11710 : scanCanonicalize (H12AffineFastState.compose env11710 (packedSelected [2,4] rootPS)) = affineNative (2^(6+1) ^^^ 26) := by decide +kernel

theorem selectedBound11710 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env11711 : List Nat := [2,4,8,16,32,64,26,47,51,1024,1,1037,35,1102,10,35,1134,0,1043,10,1036,42,96,3,49,35,19,1102,1086,1,1066,4294967296,46,4294967320,1134,51]

theorem envBound11711 : H12AffineFastState.Bounded env11711 := by
  intro p hp
  have h : env11711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11710_11711 : H12AffineEnvironment.transform 6 26 env11710 = env11711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 26 env11710 == env11711) = true)

theorem identity11711 : scanCanonicalize (H12AffineFastState.compose env11711 (packedSelected [5,8] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound11711 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env11712 : List Nat := [2,4,3,16,32,64,17,36,51,1024,1,1030,35,1093,1,35,1125,0,1043,1,1031,33,96,3,49,35,19,1093,1077,1,1057,4294967296,37,4294967315,1125,51]

theorem envBound11712 : H12AffineFastState.Bounded env11712 := by
  intro p hp
  have h : env11712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11711_11712 : H12AffineEnvironment.transform 2 3 env11711 = env11712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env11711 == env11712) = true)

theorem identity11712 : scanCanonicalize (H12AffineFastState.compose env11712 (packedSelected [0,1,5] rootPS)) = affineNative (2^(31+1) ^^^ 1140) := by decide +kernel

theorem selectedBound11712 : packedSelected [0,1,5] rootPS < 2^1333 := by decide +kernel

def env11713 : List Nat := [2,4,3,16,32,64,17,36,51,1024,1,1030,35,1093,1,35,1125,0,1043,1,1031,33,96,3,49,35,19,1093,1077,1,1057,1140,37,1127,1125,51]

theorem envBound11713 : H12AffineFastState.Bounded env11713 := by
  intro p hp
  have h : env11713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11712_11713 : H12AffineEnvironment.transform 31 1140 env11712 = env11713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1140 env11712 == env11713) = true)

theorem identity11713 : scanCanonicalize (H12AffineFastState.compose env11713 (packedSelected [0,2,3,10] rootPS)) = affineNative (2^(9+1) ^^^ 102) := by decide +kernel

theorem selectedBound11713 : packedSelected [0,2,3,10] rootPS < 2^1333 := by decide +kernel

def env11714 : List Nat := [2,4,3,16,32,64,17,36,51,102,1,96,35,35,1,35,3,0,117,1,97,33,96,3,49,35,19,35,83,1,71,18,37,1,3,51]

theorem envBound11714 : H12AffineFastState.Bounded env11714 := by
  intro p hp
  have h : env11714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11713_11714 : H12AffineEnvironment.transform 9 102 env11713 = env11714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 102 env11713 == env11714) = true)

theorem identity11714 : scanCanonicalize (H12AffineFastState.compose env11714 (packedSelected [0,1,2,12] rootPS)) = affineNative (2^(5+1) ^^^ 2) := by decide +kernel

theorem selectedBound11714 : packedSelected [0,1,2,12] rootPS < 2^1333 := by decide +kernel

def env11715 : List Nat := [2,4,3,16,32,2,17,36,51,36,1,34,35,35,1,35,3,0,55,1,35,33,34,3,49,35,19,35,17,1,5,18,37,1,3,51]

theorem envBound11715 : H12AffineFastState.Bounded env11715 := by
  intro p hp
  have h : env11715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11714_11715 : H12AffineEnvironment.transform 5 2 env11714 = env11715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 2 env11714 == env11715) = true)

theorem identity11715 : scanCanonicalize (H12AffineFastState.compose env11715 (packedSelected [0,1,2] rootPS)) = affineNative (2^(4+1) ^^^ 19) := by decide +kernel

theorem selectedBound11715 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env11716 : List Nat := [2,4,3,16,19,2,17,23,0,23,1,17,16,16,1,16,3,0,4,1,16,18,17,3,2,16,19,16,17,1,5,18,22,1,3,0]

theorem envBound11716 : H12AffineFastState.Bounded env11716 := by
  intro p hp
  have h : env11716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11715_11716 : H12AffineEnvironment.transform 4 19 env11715 = env11716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 19 env11715 == env11716) = true)

def env11717 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8832,65536,131072,1,524288,8832,2097152,8201,17665,206532,33554432,5377,2253853,16384,131152,2249353,131140,4294967296,257,4329271998,131072,33563272]

theorem envBound11717 : H12AffineFastState.Bounded env11717 := by
  intro p hp
  have h : env11717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11684_11717 : H12AffineEnvironment.transform 17 1 env11684 = env11717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1 env11684 == env11717) = true)

def env11718 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,8832,65536,1344,1,524288,8832,2097152,8201,17665,74628,33554432,5377,2122077,16384,1296,2119625,1284,4294967296,257,4329142270,1344,33563272]

theorem envBound11718 : H12AffineFastState.Bounded env11718 := by
  intro p hp
  have h : env11718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11717_11718 : H12AffineEnvironment.transform 16 1344 env11717 = env11718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env11717 == env11718) = true)

theorem identity11718 : scanCanonicalize (H12AffineFastState.compose env11718 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 4097) := by decide +kernel

end H12CloudChart2