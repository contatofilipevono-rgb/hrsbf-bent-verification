import H12CloudChart2Data062

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound15407 : H12AffineFastState.Bounded env15407 := by
  intro p hp
  have h : env15407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15406_15407 : H12AffineEnvironment.transform 15 8323 env15406 = env15407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env15406 == env15407) = true)

theorem identity15407 : scanCanonicalize (H12AffineFastState.compose env15407 (packedSelected [1] rootPS)) = affineNative (2^(21+1) ^^^ 8706) := by decide +kernel

theorem selectedBound15407 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15408 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1297,9093,8323,1297,2179,1025,9092,1297,8706,16,514,8328,17,11141,1296,1296,10913,1284,168,257,8194,1297,512]

theorem envBound15408 : H12AffineFastState.Bounded env15408 := by
  intro p hp
  have h : env15408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15407_15408 : H12AffineEnvironment.transform 21 8706 env15407 = env15408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8706 env15407 == env15408) = true)

theorem identity15408 : scanCanonicalize (H12AffineFastState.compose env15408 (packedSelected [12,21] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound15408 : packedSelected [12,21] rootPS < 2^1333 := by decide +kernel

def env15409 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,269,1297,648,398,1297,2179,1025,649,1297,783,16,514,389,17,2696,1296,1296,2988,1284,168,257,271,1297,512]

theorem envBound15409 : H12AffineFastState.Bounded env15409 := by
  intro p hp
  have h : env15409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15408_15409 : H12AffineEnvironment.transform 12 269 env15408 = env15409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env15408 == env15409) = true)

theorem identity15409 : scanCanonicalize (H12AffineFastState.compose env15409 (packedSelected [2,6] rootPS)) = affineNative (2^(9+1) ^^^ 575) := by decide +kernel

theorem selectedBound15409 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env15410 : List Nat := [2,4,8,16,32,16,128,256,512,575,2048,814,269,814,648,398,814,2179,574,649,814,783,16,514,389,17,2696,815,815,2988,827,168,257,271,814,512]

theorem envBound15410 : H12AffineFastState.Bounded env15410 := by
  intro p hp
  have h : env15410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15409_15410 : H12AffineEnvironment.transform 9 575 env15409 = env15410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 575 env15409 == env15410) = true)

theorem identity15410 : scanCanonicalize (H12AffineFastState.compose env15410 (packedSelected [0,7,11] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound15410 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env15411 : List Nat := [2,4,8,16,32,16,128,256,137,182,2048,423,269,423,1,398,423,2179,183,0,423,390,16,139,389,17,2049,422,422,2341,434,168,257,271,423,137]

theorem envBound15411 : H12AffineFastState.Bounded env15411 := by
  intro p hp
  have h : env15411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15410_15411 : H12AffineEnvironment.transform 8 137 env15410 = env15411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env15410 == env15411) = true)

theorem identity15411 : scanCanonicalize (H12AffineFastState.compose env15411 (packedSelected [3] rootPS)) = affineNative (2^(7+1) ^^^ 167) := by decide +kernel

theorem selectedBound15411 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env15412 : List Nat := [2,4,8,16,32,16,128,167,137,182,2048,0,170,0,1,41,0,2179,183,0,0,33,16,139,34,17,2049,1,1,2178,21,168,166,168,0,137]

theorem envBound15412 : H12AffineFastState.Bounded env15412 := by
  intro p hp
  have h : env15412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15411_15412 : H12AffineEnvironment.transform 7 167 env15411 = env15412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 167 env15411 == env15412) = true)

theorem identity15412 : scanCanonicalize (H12AffineFastState.compose env15412 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 51) := by decide +kernel

theorem selectedBound15412 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15413 : List Nat := [2,4,8,16,32,16,51,20,58,5,2048,0,25,0,1,41,0,2096,4,0,0,33,16,56,34,17,2049,1,1,2097,21,27,21,27,0,58]

theorem envBound15413 : H12AffineFastState.Bounded env15413 := by
  intro p hp
  have h : env15413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15412_15413 : H12AffineEnvironment.transform 6 51 env15412 = env15413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 51 env15412 == env15413) = true)

def env15414 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1296,32768,65536,1296,262144,1025,32769,1296,4194304,17,98565,8328,17,4456709,1297,1297,1073741824,1285,73771,257,4235652,1296,512]

theorem envBound15414 : H12AffineFastState.Bounded env15414 := by
  intro p hp
  have h : env15414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15402_15414 : H12AffineEnvironment.transform 5 17 env15402 = env15414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env15402 == env15414) = true)

theorem identity15414 : scanCanonicalize (H12AffineFastState.compose env15414 (packedSelected [1,3,5] rootPS)) = affineNative (2^(29+1) ^^^ 4205065) := by decide +kernel

theorem selectedBound15414 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env15415 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1296,32768,65536,1296,262144,1025,32769,1296,4194304,17,98565,8328,17,4456709,1297,1297,4205065,1285,73771,257,4235652,1296,512]

theorem envBound15415 : H12AffineFastState.Bounded env15415 := by
  intro p hp
  have h : env15415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15414_15415 : H12AffineEnvironment.transform 29 4205065 env15414 = env15415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4205065 env15414 == env15415) = true)

theorem identity15415 : scanCanonicalize (H12AffineFastState.compose env15415 (packedSelected [1,3,8] rootPS)) = affineNative (2^(14+1) ^^^ 8972) := by decide +kernel

theorem selectedBound15415 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env15416 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1296,8972,65536,1296,262144,1025,8973,1296,4194304,17,74249,8328,17,4456709,1297,1297,4205065,1285,73771,257,4194952,1296,512]

theorem envBound15416 : H12AffineFastState.Bounded env15416 := by
  intro p hp
  have h : env15416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15415_15416 : H12AffineEnvironment.transform 14 8972 env15415 = env15416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8972 env15415 == env15416) = true)

theorem identity15416 : scanCanonicalize (H12AffineFastState.compose env15416 (packedSelected [1,12,13] rootPS)) = affineNative (2^(17+1) ^^^ 74542) := by decide +kernel

theorem selectedBound15416 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env15417 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1296,8972,65536,1296,74542,1025,8973,1296,4194304,17,74249,8328,17,4268587,1297,1297,4205065,1285,73771,257,4194952,1296,512]

theorem envBound15417 : H12AffineFastState.Bounded env15417 := by
  intro p hp
  have h : env15417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15416_15417 : H12AffineEnvironment.transform 17 74542 env15416 = env15417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 74542 env15416 == env15417) = true)

theorem identity15417 : scanCanonicalize (H12AffineFastState.compose env15417 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(21+1) ^^^ 10369) := by decide +kernel

theorem selectedBound15417 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env15418 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1296,8972,65536,1296,74542,1025,8973,1296,10369,17,74249,8328,17,68266,1297,1297,648,1285,73771,257,10761,1296,512]

theorem envBound15418 : H12AffineFastState.Bounded env15418 := by
  intro p hp
  have h : env15418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15417_15418 : H12AffineEnvironment.transform 21 10369 env15417 = env15418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10369 env15417 == env15418) = true)

theorem identity15418 : scanCanonicalize (H12AffineFastState.compose env15418 (packedSelected [1,12,17] rootPS)) = affineNative (2^(12+1) ^^^ 780) := by decide +kernel

theorem selectedBound15418 : packedSelected [1,12,17] rootPS < 2^1333 := by decide +kernel

def env15419 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,780,1296,0,65536,1296,65570,1025,1,1296,2957,17,65797,900,17,68266,1297,1297,648,1285,66343,257,2309,1296,512]

theorem envBound15419 : H12AffineFastState.Bounded env15419 := by
  intro p hp
  have h : env15419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15418_15419 : H12AffineEnvironment.transform 12 780 env15418 = env15419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 780 env15418 == env15419) = true)

theorem identity15419 : scanCanonicalize (H12AffineFastState.compose env15419 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 1215) := by decide +kernel

theorem selectedBound15419 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15420 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,780,1296,0,1215,1296,1181,1025,1,1296,2957,17,1466,900,17,3605,1297,1297,648,1285,1944,257,2309,1296,512]

theorem envBound15420 : H12AffineFastState.Bounded env15420 := by
  intro p hp
  have h : env15420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15419_15420 : H12AffineEnvironment.transform 15 1215 env15419 = env15420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1215 env15419 == env15420) = true)

theorem identity15420 : scanCanonicalize (H12AffineFastState.compose env15420 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1180) := by decide +kernel

theorem selectedBound15420 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env15421 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1180,1296,780,1296,0,1215,1296,1181,1025,1,1296,1809,17,1466,900,17,649,1297,1297,648,1285,1944,257,1433,1296,512]

theorem envBound15421 : H12AffineFastState.Bounded env15421 := by
  intro p hp
  have h : env15421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15420_15421 : H12AffineEnvironment.transform 10 1180 env15420 = env15421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1180 env15420 == env15421) = true)

theorem identity15421 : scanCanonicalize (H12AffineFastState.compose env15421 (packedSelected [7] rootPS)) = affineNative (2^(9+1) ^^^ 305) := by decide +kernel

theorem selectedBound15421 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env15422 : List Nat := [2,4,8,16,32,17,128,256,512,305,429,33,780,33,0,398,33,428,304,1,33,544,17,139,900,17,649,32,32,648,52,681,257,168,33,512]

theorem envBound15422 : H12AffineFastState.Bounded env15422 := by
  intro p hp
  have h : env15422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15421_15422 : H12AffineEnvironment.transform 9 305 env15421 = env15422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env15421 == env15422) = true)

theorem identity15422 : scanCanonicalize (H12AffineFastState.compose env15422 (packedSelected [2,6] rootPS)) = affineNative (2^(8+1) ^^^ 169) := by decide +kernel

theorem selectedBound15422 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env15423 : List Nat := [2,4,8,16,32,17,128,256,169,305,429,33,421,33,0,398,33,428,304,1,33,137,17,139,301,17,32,32,32,33,52,0,257,168,33,169]

theorem envBound15423 : H12AffineFastState.Bounded env15423 := by
  intro p hp
  have h : env15423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15422_15423 : H12AffineEnvironment.transform 8 169 env15422 = env15423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 169 env15422 == env15423) = true)

theorem identity15423 : scanCanonicalize (H12AffineFastState.compose env15423 (packedSelected [1,4] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound15423 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env15424 : List Nat := [2,4,8,16,32,17,128,173,169,156,0,33,8,33,0,35,33,1,157,1,33,137,17,139,128,17,32,32,32,33,52,0,172,168,33,169]

theorem envBound15424 : H12AffineFastState.Bounded env15424 := by
  intro p hp
  have h : env15424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15423_15424 : H12AffineEnvironment.transform 7 173 env15423 = env15424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env15423 == env15424) = true)

def env15425 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4097,32768,65536,1345,262144,1025,32769,4096,4194304,5376,98645,8328,5457,4456789,4096,1345,1073741824,1365,4294967296,257,4299260415,1345,512]

theorem envBound15425 : H12AffineFastState.Bounded env15425 := by
  intro p hp
  have h : env15425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15399_15425 : H12AffineEnvironment.transform 13 4097 env15399 = env15425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4097 env15399 == env15425) = true)

theorem identity15425 : scanCanonicalize (H12AffineFastState.compose env15425 (packedSelected [0,7,20] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound15425 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env15426 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1297,8192,1296,32768,65536,1345,262144,1025,32769,1297,4194304,17,98645,8328,64,4456789,1297,1345,1073741824,1365,4294967296,257,4299260415,1345,512]

theorem envBound15426 : H12AffineFastState.Bounded env15426 := by
  intro p hp
  have h : env15426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15425_15426 : H12AffineEnvironment.transform 11 1297 env15425 = env15426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env15425 == env15426) = true)

theorem identity15426 : scanCanonicalize (H12AffineFastState.compose env15426 (packedSelected [13,17] rootPS)) = affineNative (2^(31+1) ^^^ 1077979296) := by decide +kernel

theorem selectedBound15426 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env15427 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1297,8192,1296,32768,65536,1345,262144,1025,32769,1297,4194304,17,98645,8328,64,4456789,1297,1345,1073741824,1365,1077979296,257,1073817951,1345,512]

theorem envBound15427 : H12AffineFastState.Bounded env15427 := by
  intro p hp
  have h : env15427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15426_15427 : H12AffineEnvironment.transform 31 1077979296 env15426 = env15427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1077979296 env15426 == env15427) = true)

theorem identity15427 : scanCanonicalize (H12AffineFastState.compose env15427 (packedSelected [13,21] rootPS)) = affineNative (2^(29+1) ^^^ 43128) := by decide +kernel

theorem selectedBound15427 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env15428 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1297,8192,1296,32768,65536,1345,262144,1025,32769,1297,4194304,17,98645,8328,64,4456789,1297,1345,43128,1365,4194520,257,98599,1345,512]

theorem envBound15428 : H12AffineFastState.Bounded env15428 := by
  intro p hp
  have h : env15428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15427_15428 : H12AffineEnvironment.transform 29 43128 env15427 = env15428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 43128 env15427 == env15428) = true)

theorem identity15428 : scanCanonicalize (H12AffineFastState.compose env15428 (packedSelected [1,3,15,24,28,38] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound15428 : packedSelected [1,3,15,24,28,38] rootPS < 2^1333 := by decide +kernel

def env15429 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1296,32768,65536,1296,262144,1025,32769,1297,4194304,17,98564,8328,17,4456708,1297,1296,43049,1284,4194441,257,98599,1296,512]

theorem envBound15429 : H12AffineFastState.Bounded env15429 := by
  intro p hp
  have h : env15429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15428_15429 : H12AffineEnvironment.transform 5 17 env15428 = env15429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env15428 == env15429) = true)

theorem identity15429 : scanCanonicalize (H12AffineFastState.compose env15429 (packedSelected [1,3,5] rootPS)) = affineNative (2^(21+1) ^^^ 73989) := by decide +kernel

theorem selectedBound15429 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env15430 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1296,32768,65536,1296,262144,1025,32769,1297,73989,17,98564,8328,17,335873,1297,1296,43049,1284,74124,257,98599,1296,512]

theorem envBound15430 : H12AffineFastState.Bounded env15430 := by
  intro p hp
  have h : env15430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15429_15430 : H12AffineEnvironment.transform 21 73989 env15429 = env15430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73989 env15429 == env15430) = true)

theorem identity15430 : scanCanonicalize (H12AffineFastState.compose env15430 (packedSelected [1,3,8] rootPS)) = affineNative (2^(14+1) ^^^ 9093) := by decide +kernel

theorem selectedBound15430 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env15431 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1296,9093,65536,1296,262144,1025,9092,1297,73989,17,74369,8328,17,335873,1297,1296,2988,1284,74124,257,74402,1296,512]

theorem envBound15431 : H12AffineFastState.Bounded env15431 := by
  intro p hp
  have h : env15431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15430_15431 : H12AffineEnvironment.transform 14 9093 env15430 = env15431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9093 env15430 == env15431) = true)

theorem identity15431 : scanCanonicalize (H12AffineFastState.compose env15431 (packedSelected [1,12,13] rootPS)) = affineNative (2^(17+1) ^^^ 76425) := by decide +kernel

theorem selectedBound15431 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env15432 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1296,9093,65536,1296,76425,1025,9092,1297,73989,17,74369,8328,17,2696,1297,1296,2988,1284,74124,257,74402,1296,512]

theorem envBound15432 : H12AffineFastState.Bounded env15432 := by
  intro p hp
  have h : env15432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15431_15432 : H12AffineEnvironment.transform 17 76425 env15431 = env15432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76425 env15431 == env15432) = true)

theorem identity15432 : scanCanonicalize (H12AffineFastState.compose env15432 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound15432 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env15433 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1296,9093,8323,1296,2570,1025,9092,1297,390,17,514,8328,17,2696,1297,1296,2988,1284,271,257,545,1296,512]

theorem envBound15433 : H12AffineFastState.Bounded env15433 := by
  intro p hp
  have h : env15433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15432_15433 : H12AffineEnvironment.transform 15 8323 env15432 = env15433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env15432 == env15433) = true)

theorem identity15433 : scanCanonicalize (H12AffineFastState.compose env15433 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound15433 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15434 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,269,1296,648,398,1296,2570,1025,649,1297,390,17,514,389,17,2696,1297,1296,2988,1284,271,257,545,1296,512]

theorem envBound15434 : H12AffineFastState.Bounded env15434 := by
  intro p hp
  have h : env15434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15433_15434 : H12AffineEnvironment.transform 12 269 env15433 = env15434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env15433 == env15434) = true)

theorem identity15434 : scanCanonicalize (H12AffineFastState.compose env15434 (packedSelected [0,2,4,6,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 574) := by decide +kernel

theorem selectedBound15434 : packedSelected [0,2,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env15435 : List Nat := [2,4,8,16,32,17,128,256,512,574,2048,815,269,814,648,398,814,2570,575,649,815,390,17,514,389,17,2696,815,814,2988,826,271,257,545,814,512]

theorem envBound15435 : H12AffineFastState.Bounded env15435 := by
  intro p hp
  have h : env15435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15434_15435 : H12AffineEnvironment.transform 9 574 env15434 = env15435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 574 env15434 == env15435) = true)

theorem identity15435 : scanCanonicalize (H12AffineFastState.compose env15435 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 302) := by decide +kernel

theorem selectedBound15435 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env15436 : List Nat := [2,4,8,16,32,17,128,256,302,272,2048,1,269,0,422,398,0,2340,273,423,1,390,17,300,389,17,2470,1,0,2178,20,271,257,271,0,302]

theorem envBound15436 : H12AffineFastState.Bounded env15436 := by
  intro p hp
  have h : env15436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15435_15436 : H12AffineEnvironment.transform 8 302 env15435 = env15436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 302 env15435 == env15436) = true)

theorem identity15436 : scanCanonicalize (H12AffineFastState.compose env15436 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 167) := by decide +kernel

theorem selectedBound15436 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env15437 : List Nat := [2,4,8,16,32,17,128,167,137,183,2048,1,170,0,1,41,0,2179,182,0,1,33,17,139,34,17,2049,1,0,2178,20,168,166,168,0,137]

theorem envBound15437 : H12AffineFastState.Bounded env15437 := by
  intro p hp
  have h : env15437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15436_15437 : H12AffineEnvironment.transform 7 167 env15436 = env15437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 167 env15436 == env15437) = true)

theorem identity15437 : scanCanonicalize (H12AffineFastState.compose env15437 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 50) := by decide +kernel

theorem selectedBound15437 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15438 : List Nat := [2,4,8,16,32,17,50,21,59,5,2048,1,24,0,1,41,0,2097,4,0,1,33,17,57,34,17,2049,1,0,2096,20,26,20,26,0,59]

theorem envBound15438 : H12AffineFastState.Bounded env15438 := by
  intro p hp
  have h : env15438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15437_15438 : H12AffineEnvironment.transform 6 50 env15437 = env15438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 50 env15437 == env15438) = true)

def env15439 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,4194304,8388608,16777216,8328,8914000,134217728,8519745,676865,1073741824,25412673,4294967296,8536384,4315938986,164610304,512]

theorem envBound15439 : H12AffineFastState.Bounded env15439 := by
  intro p hp
  have h : env15439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15273_15439 : H12AffineEnvironment.transform 20 4097 env15273 = env15439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env15273 == env15439) = true)

theorem identity15439 : scanCanonicalize (H12AffineFastState.compose env15439 (packedSelected [14] rootPS)) = affineNative (2^(26+1) ^^^ 4477269) := by decide +kernel

theorem selectedBound15439 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env15440 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,4194304,8388608,16777216,8328,8914000,4477269,8519745,676865,1073741824,25412673,4294967296,8536384,4315938986,25923669,512]

theorem envBound15440 : H12AffineFastState.Bounded env15440 := by
  intro p hp
  have h : env15440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15439_15440 : H12AffineEnvironment.transform 26 4477269 env15439 = env15440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 4477269 env15439 == env15440) = true)

def env15441 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,4194304,17664,16777216,8328,541008,4477269,148801,676865,1073741824,17006913,4294967296,132160,4315938986,17552725,512]

theorem envBound15441 : H12AffineFastState.Bounded env15441 := by
  intro p hp
  have h : env15441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15440_15441 : H12AffineEnvironment.transform 22 17664 env15440 = env15441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17664 env15440 == env15441) = true)

def env15442 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,524288,32769,4097,4194304,17664,16777216,8328,541008,4477269,16385,545089,1073741824,16876545,4294967296,256,4315938986,17420309,512]

theorem envBound15442 : H12AffineFastState.Bounded env15442 := by
  intro p hp
  have h : env15442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15441_15442 : H12AffineEnvironment.transform 16 1344 env15441 = env15442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env15441 == env15442) = true)

theorem identity15442 : scanCanonicalize (H12AffineFastState.compose env15442 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(23+1) ^^^ 98564) := by decide +kernel

theorem selectedBound15442 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env15443 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,524288,32769,4097,4194304,17664,98564,8328,541008,4477269,16385,545089,1073741824,1285,4294967296,256,4299260334,545041,512]

theorem envBound15443 : H12AffineFastState.Bounded env15443 := by
  intro p hp
  have h : env15443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15442_15443 : H12AffineEnvironment.transform 23 98564 env15442 = env15443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98564 env15442 == env15443) = true)

def env15444 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,21504,32769,4097,4194304,17664,98564,8328,5456,4477269,16385,1345,1073741824,1285,4294967296,256,4299260334,1297,512]

theorem envBound15444 : H12AffineFastState.Bounded env15444 := by
  intro p hp
  have h : env15444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15443_15444 : H12AffineEnvironment.transform 18 21504 env15443 = env15444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21504 env15443 == env15444) = true)

theorem identity15444 : scanCanonicalize (H12AffineFastState.compose env15444 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 4176) := by decide +kernel

theorem selectedBound15444 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env15445 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,1344,262144,1104,32769,4097,4194304,5456,98564,8328,5456,4456709,4177,1345,1073741824,1285,4294967296,256,4299260334,1297,512]

theorem envBound15445 : H12AffineFastState.Bounded env15445 := by
  intro p hp
  have h : env15445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15444_15445 : H12AffineEnvironment.transform 13 4176 env15444 = env15445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env15444 == env15445) = true)

theorem identity15445 : scanCanonicalize (H12AffineFastState.compose env15445 (packedSelected [9,22] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound15445 : packedSelected [9,22] rootPS < 2^1333 := by decide +kernel

def env15446 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,65536,1296,262144,1024,32769,4097,4194304,5376,98564,8328,5376,4456709,4097,1297,1073741824,1285,4294967296,256,4299260334,1297,512]

theorem envBound15446 : H12AffineFastState.Bounded env15446 := by
  intro p hp
  have h : env15446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15445_15446 : H12AffineEnvironment.transform 5 16 env15445 = env15446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env15445 == env15446) = true)

theorem identity15446 : scanCanonicalize (H12AffineFastState.compose env15446 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(29+1) ^^^ 4294794) := by decide +kernel

theorem selectedBound15446 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env15447 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,65536,1296,262144,1024,32769,4097,4194304,5376,98564,8328,5376,4456709,4097,1297,4294794,1285,4294967296,256,4299260334,1297,512]

theorem envBound15447 : H12AffineFastState.Bounded env15447 := by
  intro p hp
  have h : env15447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15446_15447 : H12AffineEnvironment.transform 29 4294794 env15446 = env15447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4294794 env15446 == env15447) = true)

def env15448 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,65536,1296,262144,1024,32769,4097,41088,5376,98564,8328,5376,303493,4097,1297,75786,1285,4294967296,256,4295041326,1297,512]

theorem envBound15448 : H12AffineFastState.Bounded env15448 := by
  intro p hp
  have h : env15448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15447_15448 : H12AffineEnvironment.transform 21 41088 env15447 = env15448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env15447 == env15448) = true)

theorem identity15448 : scanCanonicalize (H12AffineFastState.compose env15448 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 103731) := by decide +kernel

theorem selectedBound15448 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env15449 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,65536,1296,262144,1024,32769,4097,41088,5376,98564,8328,5376,303493,4097,1297,75786,1285,103731,256,46109,1297,512]

theorem envBound15449 : H12AffineFastState.Bounded env15449 := by
  intro p hp
  have h : env15449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15448_15449 : H12AffineEnvironment.transform 31 103731 env15448 = env15449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 103731 env15448 == env15449) = true)

theorem identity15449 : scanCanonicalize (H12AffineFastState.compose env15449 (packedSelected [1,8,12] rootPS)) = affineNative (2^(15+1) ^^^ 33063) := by decide +kernel

theorem selectedBound15449 : packedSelected [1,8,12] rootPS < 2^1333 := by decide +kernel

def env15450 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,33063,1296,262144,1024,32769,4097,41088,5376,35,8328,5376,303493,4097,1297,43309,1285,5140,256,46109,1297,512]

theorem envBound15450 : H12AffineFastState.Bounded env15450 := by
  intro p hp
  have h : env15450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15449_15450 : H12AffineEnvironment.transform 15 33063 env15449 = env15450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33063 env15449 == env15450) = true)

def env15451 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1296,32768,33063,1296,262144,1024,32769,1297,41088,16,35,8328,16,303493,1297,1297,43309,1285,260,256,41229,1297,512]

theorem envBound15451 : H12AffineFastState.Bounded env15451 := by
  intro p hp
  have h : env15451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15450_15451 : H12AffineEnvironment.transform 11 1296 env15450 = env15451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env15450 == env15451) = true)

theorem identity15451 : scanCanonicalize (H12AffineFastState.compose env15451 (packedSelected [1,3,5] rootPS)) = affineNative (2^(17+1) ^^^ 43048) := by decide +kernel

theorem selectedBound15451 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env15452 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1296,32768,33063,1296,43048,1024,32769,1297,41088,16,35,8328,16,2477,1297,1297,43309,1285,260,256,41229,1297,512]

theorem envBound15452 : H12AffineFastState.Bounded env15452 := by
  intro p hp
  have h : env15452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15451_15452 : H12AffineEnvironment.transform 17 43048 env15451 = env15452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43048 env15451 == env15452) = true)

theorem identity15452 : scanCanonicalize (H12AffineFastState.compose env15452 (packedSelected [1] rootPS)) = affineNative (2^(14+1) ^^^ 3125) := by decide +kernel

theorem selectedBound15452 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15453 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1296,3125,3346,1296,9245,1024,3124,1297,11445,16,35,8328,16,2477,1297,1297,9496,1285,260,256,11576,1297,512]

theorem envBound15453 : H12AffineFastState.Bounded env15453 := by
  intro p hp
  have h : env15453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15452_15453 : H12AffineEnvironment.transform 14 3125 env15452 = env15453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 3125 env15452 == env15453) = true)

theorem identity15453 : scanCanonicalize (H12AffineFastState.compose env15453 (packedSelected [3,8] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound15453 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env15454 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,1296,8192,1296,3125,3346,1296,9245,1024,3124,1297,11293,16,35,8224,16,2309,1297,1297,9496,1285,260,256,11576,1297,512]

theorem envBound15454 : H12AffineFastState.Bounded env15454 := by
  intro p hp
  have h : env15454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15453_15454 : H12AffineEnvironment.transform 6 40 env15453 = env15454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env15453 == env15454) = true)

theorem identity15454 : scanCanonicalize (H12AffineFastState.compose env15454 (packedSelected [3] rootPS)) = affineNative (2^(12+1) ^^^ 3353) := by decide +kernel

theorem selectedBound15454 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env15455 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,1296,3353,1296,3125,3346,1296,2308,1024,3124,1297,260,16,35,3385,16,2309,1297,1297,2049,1285,260,256,33,1297,512]

theorem envBound15455 : H12AffineFastState.Bounded env15455 := by
  intro p hp
  have h : env15455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15454_15455 : H12AffineEnvironment.transform 12 3353 env15454 = env15455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3353 env15454 == env15455) = true)

theorem identity15455 : scanCanonicalize (H12AffineFastState.compose env15455 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound15455 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15456 : List Nat := [2,4,8,16,32,16,40,256,292,1024,2048,1296,3353,1296,3125,3346,1296,2308,1024,3124,1297,260,16,35,3385,16,2309,1297,1297,2049,1285,260,256,33,1297,292]

theorem envBound15456 : H12AffineFastState.Bounded env15456 := by
  intro p hp
  have h : env15456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15455_15456 : H12AffineEnvironment.transform 8 292 env15455 = env15456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env15455 == env15456) = true)

theorem identity15456 : scanCanonicalize (H12AffineFastState.compose env15456 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound15456 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env15457 : List Nat := [2,4,8,16,32,16,40,5,33,1024,2048,1045,3100,1045,3125,3095,1045,2049,1024,3124,1044,1,16,35,3132,16,2048,1044,1044,2049,1024,1,5,33,1044,33]

theorem envBound15457 : H12AffineFastState.Bounded env15457 := by
  intro p hp
  have h : env15457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15456_15457 : H12AffineEnvironment.transform 7 5 env15456 = env15457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env15456 == env15457) = true)

theorem identity15457 : scanCanonicalize (H12AffineFastState.compose env15457 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound15457 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15458 : List Nat := [2,4,8,16,0,16,8,5,1,1024,2048,1045,3100,1045,3093,3095,1045,2049,1024,3092,1044,1,16,3,3100,16,2048,1044,1044,2049,1024,1,5,1,1044,1]

theorem envBound15458 : H12AffineFastState.Bounded env15458 := by
  intro p hp
  have h : env15458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15457_15458 : H12AffineEnvironment.transform 4 0 env15457 = env15458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15457 == env15458) = true)

theorem identity15458 : scanCanonicalize (H12AffineFastState.compose env15458 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound15458 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env15459 : List Nat := [2,4,8,16,0,16,8,5,1,1024,1,1045,1053,1045,1044,1046,1045,0,1024,1045,1044,1,16,3,1053,16,1,1044,1044,0,1024,1,5,1,1044,1]

theorem envBound15459 : H12AffineFastState.Bounded env15459 := by
  intro p hp
  have h : env15459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15458_15459 : H12AffineEnvironment.transform 10 1 env15458 = env15459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env15458 == env15459) = true)

def env15460 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1297,32768,33063,1296,262144,1024,32769,1296,41088,17,35,8328,17,303493,1296,1297,43309,1285,261,256,41228,1297,512]

theorem envBound15460 : H12AffineFastState.Bounded env15460 := by
  intro p hp
  have h : env15460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15450_15460 : H12AffineEnvironment.transform 11 1297 env15450 = env15460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env15450 == env15460) = true)

theorem identity15460 : scanCanonicalize (H12AffineFastState.compose env15460 (packedSelected [1,3,5] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound15460 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env15461 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1297,8192,1297,32768,33063,1296,262144,1024,32769,1296,41088,17,35,8328,17,303493,1296,1297,43309,1285,261,256,41228,1297,137]

theorem envBound15461 : H12AffineFastState.Bounded env15461 := by
  intro p hp
  have h : env15461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15460_15461 : H12AffineEnvironment.transform 8 137 env15460 = env15461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env15460 == env15461) = true)

theorem identity15461 : scanCanonicalize (H12AffineFastState.compose env15461 (packedSelected [2,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 8200) := by decide +kernel

theorem selectedBound15461 : packedSelected [2,23,32] rootPS < 2^1333 := by decide +kernel

def env15462 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1297,8192,1297,8200,8495,1296,262144,1024,8201,1296,136,17,35,8328,17,262541,1296,1297,2341,1285,261,256,260,1297,137]

theorem envBound15462 : H12AffineFastState.Bounded env15462 := by
  intro p hp
  have h : env15462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15461_15462 : H12AffineEnvironment.transform 14 8200 env15461 = env15462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8200 env15461 == env15462) = true)

def env15463 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1297,8192,1297,8200,8495,1296,2080,1024,8201,1296,136,17,35,8328,17,2477,1296,1297,2341,1285,261,256,260,1297,137]

theorem envBound15463 : H12AffineFastState.Bounded env15463 := by
  intro p hp
  have h : env15463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15462_15463 : H12AffineEnvironment.transform 17 2080 env15462 = env15463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2080 env15462 == env15463) = true)

theorem identity15463 : scanCanonicalize (H12AffineFastState.compose env15463 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 441) := by decide +kernel

theorem selectedBound15463 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15464 : List Nat := [2,4,8,16,32,16,128,256,137,441,2048,168,8192,168,8200,8495,169,2080,441,8201,169,136,17,35,8328,17,2477,169,168,2341,188,261,256,260,168,137]

theorem envBound15464 : H12AffineFastState.Bounded env15464 := by
  intro p hp
  have h : env15464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15463_15464 : H12AffineEnvironment.transform 9 441 env15463 = env15464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 441 env15463 == env15464) = true)

def env15465 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1297,8192,1297,8200,8495,1296,2081,1024,8201,1296,136,17,35,8328,17,2476,1296,1297,2341,1285,261,256,260,1297,137]

theorem envBound15465 : H12AffineFastState.Bounded env15465 := by
  intro p hp
  have h : env15465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15462_15465 : H12AffineEnvironment.transform 17 2081 env15462 = env15465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2081 env15462 == env15465) = true)

theorem identity15465 : scanCanonicalize (H12AffineFastState.compose env15465 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound15465 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15466 : List Nat := [2,4,8,16,32,16,40,256,33,1024,2048,1297,8192,1297,8200,8495,1296,2081,1024,8201,1296,32,17,35,8224,17,2308,1296,1297,2341,1285,261,256,260,1297,33]

theorem envBound15466 : H12AffineFastState.Bounded env15466 := by
  intro p hp
  have h : env15466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15465_15466 : H12AffineEnvironment.transform 6 40 env15465 = env15466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env15465 == env15466) = true)

def env15467 : List Nat := [2,4,8,16,32,16,40,256,33,1024,2048,1297,2088,1297,2080,2311,1296,2081,1024,2081,1296,32,17,35,2056,17,2308,1296,1297,2341,1285,261,256,260,1297,33]

theorem envBound15467 : H12AffineFastState.Bounded env15467 := by
  intro p hp
  have h : env15467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15466_15467 : H12AffineEnvironment.transform 12 2088 env15466 = env15467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2088 env15466 == env15467) = true)

def env15468 : List Nat := [2,4,8,16,32,16,40,256,33,1024,2048,1297,2089,1297,2081,2310,1296,2081,1024,2080,1296,32,17,35,2057,17,2308,1296,1297,2341,1285,261,256,260,1297,33]

theorem envBound15468 : H12AffineFastState.Bounded env15468 := by
  intro p hp
  have h : env15468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15466_15468 : H12AffineEnvironment.transform 12 2089 env15466 = env15468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2089 env15466 == env15468) = true)

theorem identity15468 : scanCanonicalize (H12AffineFastState.compose env15468 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound15468 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15469 : List Nat := [2,4,8,16,32,16,40,37,33,1024,2048,1076,2089,1076,2081,2083,1077,2081,1024,2080,1077,32,17,35,2057,17,2081,1077,1076,2048,1056,32,37,33,1076,33]

theorem envBound15469 : H12AffineFastState.Bounded env15469 := by
  intro p hp
  have h : env15469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15468_15469 : H12AffineEnvironment.transform 7 37 env15468 = env15469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env15468 == env15469) = true)

theorem identity15469 : scanCanonicalize (H12AffineFastState.compose env15469 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound15469 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env15470 : List Nat := [2,4,8,16,0,16,8,5,1,1024,2048,1044,2057,1044,2049,2051,1045,2049,1024,2048,1045,0,17,3,2057,17,2049,1045,1044,2048,1024,0,5,1,1044,1]

theorem envBound15470 : H12AffineFastState.Bounded env15470 := by
  intro p hp
  have h : env15470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15469_15470 : H12AffineEnvironment.transform 4 0 env15469 = env15470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15469 == env15470) = true)

def leafEnv15470 : List Nat := [2,4,8,16,0,16,8,5,1,1024,2048,1044,2057,1044,2049,2051,1045,2049,1024,2048,1045,0,17,3,1024,2057,1,17,2049,1045,1044,2048,1024,0,5,1,4,2050,1044,1,0,1045,1]

def active15470 : List Nat := [0,1,2,3,9,10]

def tree15470 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15470 : H12WitnessSearch.Good tree15470 := H12GlobalWitnessIndex.good

theorem leafIdentity15470 : H12AffineFastState.composeSystem env15470 rootObs = leafEnv15470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15470 rootObs == leafEnv15470) = true)

theorem terminalChecked15470 : H12PackedTerminal.terminalCheckFast leafEnv15470 active15470 tree15470 = true := by decide +kernel

def env15471 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,65536,1296,262144,1024,32769,4097,41089,5376,98564,8328,5376,303492,4097,1297,75787,1285,4294967296,256,4295041327,1297,512]

theorem envBound15471 : H12AffineFastState.Bounded env15471 := by
  intro p hp
  have h : env15471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15447_15471 : H12AffineEnvironment.transform 21 41089 env15447 = env15471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env15447 == env15471) = true)

theorem identity15471 : scanCanonicalize (H12AffineFastState.compose env15471 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 78911) := by decide +kernel

theorem selectedBound15471 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env15472 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,65536,1296,262144,1024,32769,4097,41089,5376,98564,8328,5376,303492,4097,1297,75787,1285,78911,256,5392,1297,512]

theorem envBound15472 : H12AffineFastState.Bounded env15472 := by
  intro p hp
  have h : env15472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15471_15472 : H12AffineEnvironment.transform 31 78911 env15471 = env15472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 78911 env15471 == env15472) = true)

theorem identity15472 : scanCanonicalize (H12AffineFastState.compose env15472 (packedSelected [1,8,12] rootPS)) = affineNative (2^(15+1) ^^^ 13627) := by decide +kernel

theorem selectedBound15472 : packedSelected [1,8,12] rootPS < 2^1333 := by decide +kernel

def env15473 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,13627,1296,262144,1024,32769,4097,41089,5376,46143,8328,5376,303492,4097,1297,7472,1285,260,256,5392,1297,512]

theorem envBound15473 : H12AffineFastState.Bounded env15473 := by
  intro p hp
  have h : env15473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15472_15473 : H12AffineEnvironment.transform 15 13627 env15472 = env15473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13627 env15472 == env15473) = true)

theorem identity15473 : scanCanonicalize (H12AffineFastState.compose env15473 (packedSelected [2,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 13973) := by decide +kernel

theorem selectedBound15473 : packedSelected [2,23,32] rootPS < 2^1333 := by decide +kernel

def env15474 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,13973,13627,1296,262144,1024,13972,4097,5652,5376,682,8328,5376,268049,4097,1297,7472,1285,260,256,5392,1297,512]

theorem envBound15474 : H12AffineFastState.Bounded env15474 := by
  intro p hp
  have h : env15474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15473_15474 : H12AffineEnvironment.transform 14 13973 env15473 = env15474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13973 env15473 == env15474) = true)

def env15475 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1296,9093,8235,1296,262144,1024,9092,1297,772,16,682,8328,16,262657,1297,1297,2080,1285,260,256,0,1297,512]

theorem envBound15475 : H12AffineFastState.Bounded env15475 := by
  intro p hp
  have h : env15475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15474_15475 : H12AffineEnvironment.transform 11 1296 env15474 = env15475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env15474 == env15475) = true)

theorem identity15475 : scanCanonicalize (H12AffineFastState.compose env15475 (packedSelected [1,3,5] rootPS)) = affineNative (2^(17+1) ^^^ 2988) := by decide +kernel

theorem selectedBound15475 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env15476 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1296,9093,8235,1296,2988,1024,9092,1297,772,16,682,8328,16,2477,1297,1297,2080,1285,260,256,0,1297,512]

theorem envBound15476 : H12AffineFastState.Bounded env15476 := by
  intro p hp
  have h : env15476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15475_15476 : H12AffineEnvironment.transform 17 2988 env15475 = env15476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2988 env15475 == env15476) = true)

theorem identity15476 : scanCanonicalize (H12AffineFastState.compose env15476 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 2721) := by decide +kernel

theorem selectedBound15476 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15477 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,2721,1296,2340,2698,1296,2988,1024,2341,1297,772,16,682,2601,16,2477,1297,1297,2080,1285,260,256,0,1297,512]

theorem envBound15477 : H12AffineFastState.Bounded env15477 := by
  intro p hp
  have h : env15477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15476_15477 : H12AffineEnvironment.transform 12 2721 env15476 = env15477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2721 env15476 == env15477) = true)

theorem identity15477 : scanCanonicalize (H12AffineFastState.compose env15477 (packedSelected [7] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound15477 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env15478 : List Nat := [2,4,8,16,32,16,128,256,1,1024,2048,1296,2208,1296,2340,2187,1296,2477,1024,2341,1297,261,16,171,2088,16,2477,1297,1297,2080,1285,260,256,0,1297,1]

theorem envBound15478 : H12AffineFastState.Bounded env15478 := by
  intro p hp
  have h : env15478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15477_15478 : H12AffineEnvironment.transform 8 1 env15477 = env15478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env15477 == env15478) = true)

theorem identity15478 : scanCanonicalize (H12AffineFastState.compose env15478 (packedSelected [3,8] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound15478 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env15479 : List Nat := [2,4,8,16,0,16,128,256,1,1024,2048,1296,2176,1296,2308,2187,1296,2445,1024,2309,1297,261,16,139,2056,16,2445,1297,1297,2048,1285,260,256,0,1297,1]

theorem envBound15479 : H12AffineFastState.Bounded env15479 := by
  intro p hp
  have h : env15479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15478_15479 : H12AffineEnvironment.transform 4 0 env15478 = env15479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15478 == env15479) = true)

def leafEnv15479 : List Nat := [2,4,8,16,0,16,128,256,1,1024,2048,1296,2176,1296,2308,2187,1296,2445,1024,2309,1297,261,16,139,1285,2056,1,16,2445,1297,1297,2048,1285,260,256,0,4,2050,1297,1,0,1296,1]

def active15479 : List Nat := [0,1,2,3,6,7,9,10]

def tree15479 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15479 : H12WitnessSearch.Good tree15479 := H12GlobalWitnessIndex.good

theorem leafIdentity15479 : H12AffineFastState.composeSystem env15479 rootObs = leafEnv15479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15479 rootObs == leafEnv15479) = true)

theorem terminalChecked15479 : H12PackedTerminal.terminalCheckFast leafEnv15479 active15479 tree15479 = true := by decide +kernel

def env15480 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1297,9092,8234,1296,262144,1024,9093,1296,773,17,682,8328,17,262656,1296,1297,2081,1285,260,256,1,1297,512]

theorem envBound15480 : H12AffineFastState.Bounded env15480 := by
  intro p hp
  have h : env15480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15474_15480 : H12AffineEnvironment.transform 11 1297 env15474 = env15480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env15474 == env15480) = true)

theorem identity15480 : scanCanonicalize (H12AffineFastState.compose env15480 (packedSelected [1,3,5] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound15480 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env15481 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,1297,8192,1297,8460,8234,1296,262144,1024,8461,1296,397,17,34,8328,17,262280,1296,1297,2081,1285,260,256,1,1297,136]

theorem envBound15481 : H12AffineFastState.Bounded env15481 := by
  intro p hp
  have h : env15481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15480_15481 : H12AffineEnvironment.transform 8 136 env15480 = env15481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env15480 == env15481) = true)

def env15482 : List Nat := [2,4,8,16,32,16,128,256,136,272,2048,1,8192,1,8460,8234,0,262144,272,8461,0,397,17,34,8328,17,262280,0,1,2081,21,260,256,1,1,136]

theorem envBound15482 : H12AffineFastState.Bounded env15482 := by
  intro p hp
  have h : env15482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15481_15482 : H12AffineEnvironment.transform 9 272 env15481 = env15482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env15481 == env15482) = true)

theorem identity15482 : scanCanonicalize (H12AffineFastState.compose env15482 (packedSelected [1] rootPS)) = affineNative (2^(17+1) ^^^ 2444) := by decide +kernel

theorem selectedBound15482 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15483 : List Nat := [2,4,8,16,32,16,128,256,136,272,2048,1,8192,1,8460,8234,0,2444,272,8461,0,397,17,34,8328,17,2308,0,1,2081,21,260,256,1,1,136]

theorem envBound15483 : H12AffineFastState.Bounded env15483 := by
  intro p hp
  have h : env15483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15482_15483 : H12AffineEnvironment.transform 17 2444 env15482 = env15483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2444 env15482 == env15483) = true)

theorem identity15483 : scanCanonicalize (H12AffineFastState.compose env15483 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound15483 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env15484 : List Nat := [2,4,8,16,32,16,41,256,33,272,2048,1,8192,1,8460,8234,0,2341,272,8461,0,292,17,34,8225,17,2308,0,1,2081,21,260,256,1,1,33]

theorem envBound15484 : H12AffineFastState.Bounded env15484 := by
  intro p hp
  have h : env15484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15483_15484 : H12AffineEnvironment.transform 6 41 env15483 = env15484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env15483 == env15484) = true)

def env15485 : List Nat := [2,4,8,16,0,16,9,256,1,272,2048,1,8192,1,8460,8202,0,2309,272,8461,0,260,17,2,8193,17,2308,0,1,2049,21,260,256,1,1,1]

theorem envBound15485 : H12AffineFastState.Bounded env15485 := by
  intro p hp
  have h : env15485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15484_15485 : H12AffineEnvironment.transform 4 0 env15484 = env15485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15484 == env15485) = true)

theorem identity15485 : scanCanonicalize (H12AffineFastState.compose env15485 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound15485 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15486 : List Nat := [2,4,8,16,0,16,9,4,1,20,2048,1,8192,1,8200,8202,0,2049,20,8201,0,0,17,2,8193,17,2048,0,1,2049,21,0,4,1,1,1]

theorem envBound15486 : H12AffineFastState.Bounded env15486 := by
  intro p hp
  have h : env15486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15485_15486 : H12AffineEnvironment.transform 7 4 env15485 = env15486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env15485 == env15486) = true)

def env15487 : List Nat := [2,4,8,16,1,16,8,256,0,272,2048,1,8192,1,8460,8203,0,2308,272,8461,0,261,17,3,8192,17,2308,0,1,2048,21,260,256,1,1,0]

theorem envBound15487 : H12AffineFastState.Bounded env15487 := by
  intro p hp
  have h : env15487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15484_15487 : H12AffineEnvironment.transform 4 1 env15484 = env15487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env15484 == env15487) = true)

theorem identity15487 : scanCanonicalize (H12AffineFastState.compose env15487 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 2057) := by decide +kernel

theorem selectedBound15487 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15488 : List Nat := [2,4,8,16,1,16,8,256,0,272,2048,1,2057,1,2309,2050,0,2308,272,2308,0,261,17,3,2057,17,2308,0,1,2048,21,260,256,1,1,0]

theorem envBound15488 : H12AffineFastState.Bounded env15488 := by
  intro p hp
  have h : env15488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15487_15488 : H12AffineEnvironment.transform 12 2057 env15487 = env15488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2057 env15487 == env15488) = true)

def leafEnv15488 : List Nat := [2,4,8,16,1,16,8,256,0,272,2048,1,2057,1,2309,2050,0,2308,272,2308,0,261,17,3,21,2057,1,17,2308,0,1,2048,21,260,256,1,4,2051,1,0,0,0,1]

def active15488 : List Nat := [0,1,2,3,7,10]

def tree15488 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15488 : H12WitnessSearch.Good tree15488 := H12GlobalWitnessIndex.good

theorem leafIdentity15488 : H12AffineFastState.composeSystem env15488 rootObs = leafEnv15488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15488 rootObs == leafEnv15488) = true)

theorem terminalChecked15488 : H12PackedTerminal.terminalCheckFast leafEnv15488 active15488 tree15488 = true := by decide +kernel

def env15489 : List Nat := [2,4,8,16,32,16,128,256,136,273,2048,0,8192,0,8460,8234,1,262144,273,8461,1,397,17,34,8328,17,262280,1,0,2081,20,260,256,1,0,136]

theorem envBound15489 : H12AffineFastState.Bounded env15489 := by
  intro p hp
  have h : env15489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15481_15489 : H12AffineEnvironment.transform 9 273 env15481 = env15489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env15481 == env15489) = true)

theorem identity15489 : scanCanonicalize (H12AffineFastState.compose env15489 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound15489 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15490 : List Nat := [2,4,8,16,32,16,41,256,33,273,2048,0,8192,0,8460,8234,1,262144,273,8461,1,292,17,34,8225,17,262177,1,0,2081,20,260,256,1,0,33]

theorem envBound15490 : H12AffineFastState.Bounded env15490 := by
  intro p hp
  have h : env15490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15489_15490 : H12AffineEnvironment.transform 6 41 env15489 = env15490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env15489 == env15490) = true)

theorem identity15490 : scanCanonicalize (H12AffineFastState.compose env15490 (packedSelected [3] rootPS)) = affineNative (2^(17+1) ^^^ 2341) := by decide +kernel

theorem selectedBound15490 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env15491 : List Nat := [2,4,8,16,32,16,41,256,33,273,2048,0,8192,0,8460,8234,1,2341,273,8461,1,292,17,34,8225,17,2308,1,0,2081,20,260,256,1,0,33]

theorem envBound15491 : H12AffineFastState.Bounded env15491 := by
  intro p hp
  have h : env15491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15490_15491 : H12AffineEnvironment.transform 17 2341 env15490 = env15491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2341 env15490 == env15491) = true)

def env15492 : List Nat := [2,4,8,16,0,16,9,256,1,273,2048,0,8192,0,8460,8202,1,2309,273,8461,1,260,17,2,8193,17,2308,1,0,2049,20,260,256,1,0,1]

theorem envBound15492 : H12AffineFastState.Bounded env15492 := by
  intro p hp
  have h : env15492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15491_15492 : H12AffineEnvironment.transform 4 0 env15491 = env15492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15491 == env15492) = true)

theorem identity15492 : scanCanonicalize (H12AffineFastState.compose env15492 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound15492 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15493 : List Nat := [2,4,8,16,0,16,9,4,1,21,2048,0,8192,0,8200,8202,1,2049,21,8201,1,0,17,2,8193,17,2048,1,0,2049,20,0,4,1,0,1]

theorem envBound15493 : H12AffineFastState.Bounded env15493 := by
  intro p hp
  have h : env15493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15492_15493 : H12AffineEnvironment.transform 7 4 env15492 = env15493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env15492 == env15493) = true)

def env15494 : List Nat := [2,4,8,16,1,16,8,256,0,273,2048,0,8192,0,8460,8203,1,2308,273,8461,1,261,17,3,8192,17,2308,1,0,2048,20,260,256,1,0,0]

theorem envBound15494 : H12AffineFastState.Bounded env15494 := by
  intro p hp
  have h : env15494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15491_15494 : H12AffineEnvironment.transform 4 1 env15491 = env15494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env15491 == env15494) = true)

theorem identity15494 : scanCanonicalize (H12AffineFastState.compose env15494 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 2057) := by decide +kernel

theorem selectedBound15494 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15495 : List Nat := [2,4,8,16,1,16,8,256,0,273,2048,0,2057,0,2309,2050,1,2308,273,2308,1,261,17,3,2057,17,2308,1,0,2048,20,260,256,1,0,0]

theorem envBound15495 : H12AffineFastState.Bounded env15495 := by
  intro p hp
  have h : env15495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15494_15495 : H12AffineEnvironment.transform 12 2057 env15494 = env15495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2057 env15494 == env15495) = true)

def leafEnv15495 : List Nat := [2,4,8,16,1,16,8,256,0,273,2048,0,2057,0,2309,2050,1,2308,273,2308,1,261,17,3,20,2057,1,17,2308,1,0,2048,20,260,256,1,4,2051,0,0,0,1,1]

def active15495 : List Nat := [0,1,2,3,7,10]

def tree15495 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15495 : H12WitnessSearch.Good tree15495 := H12GlobalWitnessIndex.good

theorem leafIdentity15495 : H12AffineFastState.composeSystem env15495 rootObs = leafEnv15495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15495 rootObs == leafEnv15495) = true)

theorem terminalChecked15495 : H12PackedTerminal.terminalCheckFast leafEnv15495 active15495 tree15495 = true := by decide +kernel

def env15496 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,21505,32769,4097,4194304,17664,98564,8328,5457,4477269,16385,1344,1073741824,1285,4294967296,256,4299260334,1296,512]

theorem envBound15496 : H12AffineFastState.Bounded env15496 := by
  intro p hp
  have h : env15496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15443_15496 : H12AffineEnvironment.transform 18 21505 env15443 = env15496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21505 env15443 == env15496) = true)

theorem identity15496 : scanCanonicalize (H12AffineFastState.compose env15496 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 4097) := by decide +kernel

theorem selectedBound15496 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env15497 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4097,32768,65536,1344,262144,1024,32769,4097,4194304,5377,98564,8328,5457,4456788,4096,1344,1073741824,1285,4294967296,256,4299260334,1296,512]

theorem envBound15497 : H12AffineFastState.Bounded env15497 := by
  intro p hp
  have h : env15497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15496_15497 : H12AffineEnvironment.transform 13 4097 env15496 = env15497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4097 env15496 == env15497) = true)

def env15498 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,32768,65536,1296,262144,1024,32769,4097,4194304,5377,98564,8328,5377,4456708,4096,1296,1073741824,1285,4294967296,256,4299260334,1296,512]

theorem envBound15498 : H12AffineFastState.Bounded env15498 := by
  intro p hp
  have h : env15498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15497_15498 : H12AffineEnvironment.transform 5 16 env15497 = env15498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env15497 == env15498) = true)

theorem identity15498 : scanCanonicalize (H12AffineFastState.compose env15498 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(31+1) ^^^ 4489645) := by decide +kernel

theorem selectedBound15498 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env15499 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,32768,65536,1296,262144,1024,32769,4097,4194304,5377,98564,8328,5377,4456708,4096,1296,1073741824,1285,4489645,256,327683,1296,512]

theorem envBound15499 : H12AffineFastState.Bounded env15499 := by
  intro p hp
  have h : env15499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15498_15499 : H12AffineEnvironment.transform 31 4489645 env15498 = env15499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 4489645 env15498 == env15499) = true)

theorem identity15499 : scanCanonicalize (H12AffineFastState.compose env15499 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(21+1) ^^^ 305965) := by decide +kernel

theorem selectedBound15499 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env15500 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,32768,65536,1296,262144,1024,32769,4097,305965,5377,98564,8328,5377,43561,4096,1296,1073741824,1285,10880,256,327683,1296,512]

theorem envBound15500 : H12AffineFastState.Bounded env15500 := by
  intro p hp
  have h : env15500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15499_15500 : H12AffineEnvironment.transform 21 305965 env15499 = env15500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 305965 env15499 == env15500) = true)

theorem identity15500 : scanCanonicalize (H12AffineFastState.compose env15500 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(29+1) ^^^ 272652) := by decide +kernel

theorem selectedBound15500 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env15501 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,32768,65536,1296,262144,1024,32769,4097,305965,5377,98564,8328,5377,43561,4096,1296,272652,1285,10880,256,327683,1296,512]

theorem envBound15501 : H12AffineFastState.Bounded env15501 := by
  intro p hp
  have h : env15501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15500_15501 : H12AffineEnvironment.transform 29 272652 env15500 = env15501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 272652 env15500 == env15501) = true)

theorem identity15501 : scanCanonicalize (H12AffineFastState.compose env15501 (packedSelected [1,3,5,12,13,24] rootPS)) = affineNative (2^(17+1) ^^^ 100387) := by decide +kernel

theorem selectedBound15501 : packedSelected [1,3,5,12,13,24] rootPS < 2^1333 := by decide +kernel

def env15502 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,32768,65536,1296,100387,1024,32769,4097,74510,5377,98564,8328,5377,43561,4096,1296,106799,1285,10880,256,34848,1296,512]

theorem envBound15502 : H12AffineFastState.Bounded env15502 := by
  intro p hp
  have h : env15502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15501_15502 : H12AffineEnvironment.transform 17 100387 env15501 = env15502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 100387 env15501 == env15502) = true)

theorem identity15502 : scanCanonicalize (H12AffineFastState.compose env15502 (packedSelected [8,12,13,28] rootPS)) = affineNative (2^(15+1) ^^^ 43822) := by decide +kernel

theorem selectedBound15502 : packedSelected [8,12,13,28] rootPS < 2^1333 := by decide +kernel

def env15503 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,32768,43822,1296,8973,1024,32769,4097,34848,5377,10794,8328,5377,43561,4096,1296,2561,1285,10880,256,34848,1296,512]

theorem envBound15503 : H12AffineFastState.Bounded env15503 := by
  intro p hp
  have h : env15503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15502_15503 : H12AffineEnvironment.transform 15 43822 env15502 = env15503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 43822 env15502 == env15503) = true)

theorem identity15503 : scanCanonicalize (H12AffineFastState.compose env15503 (packedSelected [4,9,11] rootPS)) = affineNative (2^(14+1) ^^^ 2852) := by decide +kernel

theorem selectedBound15503 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env15504 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,2852,8202,1296,8973,1024,2853,4097,772,5377,10794,8328,5377,8461,4096,1296,2561,1285,10880,256,772,1296,512]

theorem envBound15504 : H12AffineFastState.Bounded env15504 := by
  intro p hp
  have h : env15504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15503_15504 : H12AffineEnvironment.transform 14 2852 env15503 = env15504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2852 env15503 == env15504) = true)

theorem identity15504 : scanCanonicalize (H12AffineFastState.compose env15504 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 7197) := by decide +kernel

theorem selectedBound15504 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env15505 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,7197,4097,2852,7191,1296,7952,1024,2853,4097,772,5377,5687,7317,5377,7440,4096,1296,2561,1285,5789,256,772,1296,512]

theorem envBound15505 : H12AffineFastState.Bounded env15505 := by
  intro p hp
  have h : env15505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15504_15505 : H12AffineEnvironment.transform 12 7197 env15504 = env15505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7197 env15504 == env15505) = true)

theorem identity15505 : scanCanonicalize (H12AffineFastState.compose env15505 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound15505 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env15506 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,2317,1297,2852,2311,1296,2560,1024,2853,1297,772,17,807,2437,17,2048,1296,1296,2561,1285,909,256,772,1296,512]

theorem envBound15506 : H12AffineFastState.Bounded env15506 := by
  intro p hp
  have h : env15506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15505_15506 : H12AffineEnvironment.transform 11 1296 env15505 = env15506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env15505 == env15506) = true)

theorem identity15506 : scanCanonicalize (H12AffineFastState.compose env15506 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1809) := by decide +kernel

theorem selectedBound15506 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env15507 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1809,1296,1564,1297,1077,1558,1296,1297,1024,1076,1297,772,17,807,1684,17,1809,1296,1296,1296,1285,909,256,772,1296,512]

theorem envBound15507 : H12AffineFastState.Bounded env15507 := by
  intro p hp
  have h : env15507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15506_15507 : H12AffineEnvironment.transform 10 1809 env15506 = env15507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1809 env15506 == env15507) = true)

theorem identity15507 : scanCanonicalize (H12AffineFastState.compose env15507 (packedSelected [0,1,4] rootPS)) = affineNative (2^(9+1) ^^^ 150) := by decide +kernel

theorem selectedBound15507 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env15508 : List Nat := [2,4,8,16,32,16,128,256,512,150,903,390,650,391,163,640,390,391,150,162,391,772,17,807,514,17,903,390,390,390,403,909,256,772,390,512]

theorem envBound15508 : H12AffineFastState.Bounded env15508 := by
  intro p hp
  have h : env15508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15507_15508 : H12AffineEnvironment.transform 9 150 env15507 = env15508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 150 env15507 == env15508) = true)

theorem identity15508 : scanCanonicalize (H12AffineFastState.compose env15508 (packedSelected [5] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound15508 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env15509 : List Nat := [2,4,8,16,32,16,128,173,512,150,554,43,650,42,163,640,43,42,150,162,42,681,17,650,514,17,554,43,43,43,62,544,173,681,43,512]

theorem envBound15509 : H12AffineFastState.Bounded env15509 := by
  intro p hp
  have h : env15509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15508_15509 : H12AffineEnvironment.transform 7 173 env15508 = env15509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env15508 == env15509) = true)

theorem identity15509 : scanCanonicalize (H12AffineFastState.compose env15509 (packedSelected [0,2,6] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound15509 : packedSelected [0,2,6] rootPS < 2^1333 := by decide +kernel

def env15510 : List Nat := [2,4,8,0,32,0,128,173,512,134,554,43,650,42,163,640,43,42,134,162,42,681,1,650,514,1,554,43,43,43,46,544,173,681,43,512]

theorem envBound15510 : H12AffineFastState.Bounded env15510 := by
  intro p hp
  have h : env15510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15509_15510 : H12AffineEnvironment.transform 3 0 env15509 = env15510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env15509 == env15510) = true)

theorem identity15510 : scanCanonicalize (H12AffineFastState.compose env15510 (packedSelected [1,10] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound15510 : packedSelected [1,10] rootPS < 2^1333 := by decide +kernel

def env15511 : List Nat := [2,4,8,0,32,0,128,173,0,134,42,43,138,42,163,128,43,42,134,162,42,169,1,138,2,1,42,43,43,43,46,32,173,169,43,0]

theorem envBound15511 : H12AffineFastState.Bounded env15511 := by
  intro p hp
  have h : env15511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15510_15511 : H12AffineEnvironment.transform 8 0 env15510 = env15511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env15510 == env15511) = true)

theorem identity15511 : scanCanonicalize (H12AffineFastState.compose env15511 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound15511 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15512 : List Nat := [2,4,8,0,11,0,128,134,0,134,1,0,138,1,136,128,0,1,134,137,1,130,1,138,2,1,1,0,0,0,5,11,134,130,0,0]

theorem envBound15512 : H12AffineFastState.Bounded env15512 := by
  intro p hp
  have h : env15512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15511_15512 : H12AffineEnvironment.transform 4 11 env15511 = env15512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env15511 == env15512) = true)

def env15513 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,32768,65536,1297,262144,1024,32769,4097,4194304,5377,98564,8328,5376,4456709,4096,1297,1073741824,1285,4294967296,256,4299260334,1296,512]

theorem envBound15513 : H12AffineFastState.Bounded env15513 := by
  intro p hp
  have h : env15513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15497_15513 : H12AffineEnvironment.transform 5 17 env15497 = env15513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env15497 == env15513) = true)

theorem identity15513 : scanCanonicalize (H12AffineFastState.compose env15513 (packedSelected [1,3,5,12,13,24] rootPS)) = affineNative (2^(29+1) ^^^ 4294794) := by decide +kernel

theorem selectedBound15513 : packedSelected [1,3,5,12,13,24] rootPS < 2^1333 := by decide +kernel

def env15514 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,32768,65536,1297,262144,1024,32769,4097,4194304,5377,98564,8328,5376,4456709,4096,1297,4294794,1285,4294967296,256,4299260334,1296,512]

theorem envBound15514 : H12AffineFastState.Bounded env15514 := by
  intro p hp
  have h : env15514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15513_15514 : H12AffineEnvironment.transform 29 4294794 env15513 = env15514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4294794 env15513 == env15514) = true)

def env15515 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,32768,65536,1297,262144,1024,32769,4097,41088,5377,98564,8328,5376,303493,4096,1297,75786,1285,4294967296,256,4295041326,1296,512]

theorem envBound15515 : H12AffineFastState.Bounded env15515 := by
  intro p hp
  have h : env15515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15514_15515 : H12AffineEnvironment.transform 21 41088 env15514 = env15515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env15514 == env15515) = true)

theorem identity15515 : scanCanonicalize (H12AffineFastState.compose env15515 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 103730) := by decide +kernel

theorem selectedBound15515 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env15516 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,32768,65536,1297,262144,1024,32769,4097,41088,5377,98564,8328,5376,303493,4096,1297,75786,1285,103730,256,46108,1296,512]

theorem envBound15516 : H12AffineFastState.Bounded env15516 := by
  intro p hp
  have h : env15516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15515_15516 : H12AffineEnvironment.transform 31 103730 env15515 = env15516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 103730 env15515 == env15516) = true)

theorem identity15516 : scanCanonicalize (H12AffineFastState.compose env15516 (packedSelected [1,8,12] rootPS)) = affineNative (2^(15+1) ^^^ 8234) := by decide +kernel

theorem selectedBound15516 : packedSelected [1,8,12] rootPS < 2^1333 := by decide +kernel

def env15517 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,32768,8234,1297,262144,1024,32769,4097,41088,5377,41262,8328,5376,303493,4096,1297,2080,1285,46360,256,46108,1296,512]

theorem envBound15517 : H12AffineFastState.Bounded env15517 := by
  intro p hp
  have h : env15517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15516_15517 : H12AffineEnvironment.transform 15 8234 env15516 = env15517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8234 env15516 == env15517) = true)

def env15518 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1297,32768,8234,1297,262144,1024,32769,1297,41088,17,41262,8328,16,303493,1296,1297,2080,1285,40968,256,41228,1296,512]

theorem envBound15518 : H12AffineFastState.Bounded env15518 := by
  intro p hp
  have h : env15518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15517_15518 : H12AffineEnvironment.transform 11 1296 env15517 = env15518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env15517 == env15518) = true)

theorem identity15518 : scanCanonicalize (H12AffineFastState.compose env15518 (packedSelected [1,3,5] rootPS)) = affineNative (2^(17+1) ^^^ 43680) := by decide +kernel

theorem selectedBound15518 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env15519 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1297,32768,8234,1297,43680,1024,32769,1297,41088,17,41262,8328,16,2853,1296,1297,2080,1285,40968,256,41228,1296,512]

theorem envBound15519 : H12AffineFastState.Bounded env15519 := by
  intro p hp
  have h : env15519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15518_15519 : H12AffineEnvironment.transform 17 43680 env15518 = env15519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43680 env15518 == env15519) = true)

theorem identity15519 : scanCanonicalize (H12AffineFastState.compose env15519 (packedSelected [1,3,8] rootPS)) = affineNative (2^(14+1) ^^^ 8613) := by decide +kernel

theorem selectedBound15519 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env15520 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1297,8613,8234,1297,2821,1024,8612,1297,293,17,139,8328,16,2853,1296,1297,2080,1285,429,256,169,1296,512]

theorem envBound15520 : H12AffineFastState.Bounded env15520 := by
  intro p hp
  have h : env15520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15519_15520 : H12AffineEnvironment.transform 14 8613 env15519 = env15520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8613 env15519 == env15520) = true)

theorem identity15520 : scanCanonicalize (H12AffineFastState.compose env15520 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound15520 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env15521 : List Nat := [2,4,8,16,0,17,128,256,512,1024,2048,1296,8192,1297,8581,8202,1297,2821,1024,8580,1297,261,17,139,8328,16,2821,1296,1297,2048,1285,397,256,137,1296,512]

theorem envBound15521 : H12AffineFastState.Bounded env15521 := by
  intro p hp
  have h : env15521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15520_15521 : H12AffineEnvironment.transform 4 0 env15520 = env15521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15520 == env15521) = true)

theorem identity15521 : scanCanonicalize (H12AffineFastState.compose env15521 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound15521 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env15522 : List Nat := [2,4,8,16,0,17,128,256,137,1024,2048,1296,8192,1297,8581,8202,1297,2444,1024,8580,1297,261,17,139,8328,16,2444,1296,1297,2048,1285,397,256,137,1296,137]

theorem envBound15522 : H12AffineFastState.Bounded env15522 := by
  intro p hp
  have h : env15522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15521_15522 : H12AffineEnvironment.transform 8 137 env15521 = env15522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env15521 == env15522) = true)

theorem identity15522 : scanCanonicalize (H12AffineFastState.compose env15522 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 2056) := by decide +kernel

theorem selectedBound15522 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15523 : List Nat := [2,4,8,16,0,17,128,256,137,1024,2048,1296,2056,1297,2445,2050,1297,2444,1024,2444,1297,261,17,139,2176,16,2444,1296,1297,2048,1285,397,256,137,1296,137]

theorem envBound15523 : H12AffineFastState.Bounded env15523 := by
  intro p hp
  have h : env15523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15522_15523 : H12AffineEnvironment.transform 12 2056 env15522 = env15523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2056 env15522 == env15523) = true)

theorem identity15523 : scanCanonicalize (H12AffineFastState.compose env15523 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound15523 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15524 : List Nat := [2,4,8,16,0,17,9,256,0,1024,2048,1296,2056,1297,2308,2050,1297,2309,1024,2309,1297,261,17,2,2057,16,2309,1296,1297,2048,1285,260,256,0,1296,0]

theorem envBound15524 : H12AffineFastState.Bounded env15524 := by
  intro p hp
  have h : env15524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15523_15524 : H12AffineEnvironment.transform 6 9 env15523 = env15524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env15523 == env15524) = true)

def leafEnv15524 : List Nat := [2,4,8,16,0,17,9,256,0,1024,2048,1296,2056,1297,2308,2050,1297,2309,1024,2309,1297,261,17,2,1285,2057,1,16,2309,1296,1297,2048,1285,260,256,0,4,2050,1296,0,0,1296,1]

def active15524 : List Nat := [0,1,2,3,7,9,10]

def tree15524 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15524 : H12WitnessSearch.Good tree15524 := H12GlobalWitnessIndex.good

theorem leafIdentity15524 : H12AffineFastState.composeSystem env15524 rootObs = leafEnv15524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15524 rootObs == leafEnv15524) = true)

theorem terminalChecked15524 : H12PackedTerminal.terminalCheckFast leafEnv15524 active15524 tree15524 = true := by decide +kernel

def env15525 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1296,32768,8234,1297,262144,1024,32769,1296,41088,16,41262,8328,17,303493,1297,1297,2080,1285,40969,256,41229,1296,512]

theorem envBound15525 : H12AffineFastState.Bounded env15525 := by
  intro p hp
  have h : env15525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15517_15525 : H12AffineEnvironment.transform 11 1297 env15517 = env15525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env15517 == env15525) = true)

def env15526 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,32768,65536,1297,262144,1024,32769,4097,41089,5377,98564,8328,5376,303492,4096,1297,75787,1285,4294967296,256,4295041327,1296,512]

theorem envBound15526 : H12AffineFastState.Bounded env15526 := by
  intro p hp
  have h : env15526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15514_15526 : H12AffineEnvironment.transform 21 41089 env15514 = env15526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env15514 == env15526) = true)

theorem identity15526 : scanCanonicalize (H12AffineFastState.compose env15526 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 78910) := by decide +kernel

theorem selectedBound15526 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env15527 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,32768,65536,1297,262144,1024,32769,4097,41089,5377,98564,8328,5376,303492,4096,1297,75787,1285,78910,256,5393,1296,512]

theorem envBound15527 : H12AffineFastState.Bounded env15527 := by
  intro p hp
  have h : env15527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15526_15527 : H12AffineEnvironment.transform 31 78910 env15526 = env15527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 78910 env15526 == env15527) = true)

theorem identity15527 : scanCanonicalize (H12AffineFastState.compose env15527 (packedSelected [1,8,12] rootPS)) = affineNative (2^(15+1) ^^^ 37942) := by decide +kernel

theorem selectedBound15527 : packedSelected [1,8,12] rootPS < 2^1333 := by decide +kernel

def env15528 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,32768,37942,1297,262144,1024,32769,4097,41089,5377,5426,8328,5376,303492,4096,1297,48189,1285,40968,256,5393,1296,512]

theorem envBound15528 : H12AffineFastState.Bounded env15528 := by
  intro p hp
  have h : env15528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15527_15528 : H12AffineEnvironment.transform 15 37942 env15527 = env15528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 37942 env15527 == env15528) = true)

def env15529 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1297,32768,33062,1297,262144,1024,32769,1297,41089,17,34,8328,16,303492,1296,1297,43309,1285,40968,256,1,1296,512]

theorem envBound15529 : H12AffineFastState.Bounded env15529 := by
  intro p hp
  have h : env15529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15528_15529 : H12AffineEnvironment.transform 11 1296 env15528 = env15529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env15528 == env15529) = true)

theorem identity15529 : scanCanonicalize (H12AffineFastState.compose env15529 (packedSelected [1,3,5] rootPS)) = affineNative (2^(17+1) ^^^ 43681) := by decide +kernel

theorem selectedBound15529 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env15530 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1297,32768,33062,1297,43681,1024,32769,1297,41089,17,34,8328,16,2853,1296,1297,43309,1285,40968,256,1,1296,512]

theorem envBound15530 : H12AffineFastState.Bounded env15530 := by
  intro p hp
  have h : env15530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15529_15530 : H12AffineEnvironment.transform 17 43681 env15529 = env15530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43681 env15529 == env15530) = true)

theorem identity15530 : scanCanonicalize (H12AffineFastState.compose env15530 (packedSelected [1,3,8] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound15530 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env15531 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,1296,8192,1297,32768,33062,1297,43528,1024,32769,1297,41000,17,34,8225,16,2853,1296,1297,43309,1285,40968,256,1,1296,512]

theorem envBound15531 : H12AffineFastState.Bounded env15531 := by
  intro p hp
  have h : env15531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15530_15531 : H12AffineEnvironment.transform 6 41 env15530 = env15531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env15530 == env15531) = true)

theorem identity15531 : scanCanonicalize (H12AffineFastState.compose env15531 (packedSelected [1,3] rootPS)) = affineNative (2^(14+1) ^^^ 8493) := by decide +kernel

theorem selectedBound15531 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env15532 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,1296,8192,1297,8493,8203,1297,2853,1024,8492,1297,261,17,34,8225,16,2853,1296,1297,2048,1285,293,256,1,1296,512]

theorem envBound15532 : H12AffineFastState.Bounded env15532 := by
  intro p hp
  have h : env15532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15531_15532 : H12AffineEnvironment.transform 14 8493 env15531 = env15532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8493 env15531 == env15532) = true)

theorem identity15532 : scanCanonicalize (H12AffineFastState.compose env15532 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound15532 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env15533 : List Nat := [2,4,8,16,32,17,41,256,33,1024,2048,1296,8192,1297,8493,8203,1297,2308,1024,8492,1297,261,17,34,8225,16,2308,1296,1297,2048,1285,293,256,1,1296,33]

theorem envBound15533 : H12AffineFastState.Bounded env15533 := by
  intro p hp
  have h : env15533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15532_15533 : H12AffineEnvironment.transform 8 33 env15532 = env15533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env15532 == env15533) = true)

theorem identity15533 : scanCanonicalize (H12AffineFastState.compose env15533 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 2056) := by decide +kernel

theorem selectedBound15533 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15534 : List Nat := [2,4,8,16,32,17,41,256,33,1024,2048,1296,2056,1297,2341,2051,1297,2308,1024,2340,1297,261,17,34,2089,16,2308,1296,1297,2048,1285,293,256,1,1296,33]

theorem envBound15534 : H12AffineFastState.Bounded env15534 := by
  intro p hp
  have h : env15534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15533_15534 : H12AffineEnvironment.transform 12 2056 env15533 = env15534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2056 env15533 == env15534) = true)

def env15535 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1296,32768,33063,1297,262144,1024,32769,1296,41089,16,35,8328,17,303492,1297,1297,43308,1285,40968,256,0,1296,512]

theorem envBound15535 : H12AffineFastState.Bounded env15535 := by
  intro p hp
  have h : env15535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15528_15535 : H12AffineEnvironment.transform 11 1297 env15528 = env15535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env15528 == env15535) = true)

def env15536 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,1,8192,0,32768,33063,1,262144,272,32769,0,41089,16,35,8328,17,303492,1,1,43308,21,40968,256,0,0,512]

theorem envBound15536 : H12AffineFastState.Bounded env15536 := by
  intro p hp
  have h : env15536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15535_15536 : H12AffineEnvironment.transform 9 272 env15535 = env15536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env15535 == env15536) = true)

def env15537 : List Nat := [2,4,8,16,32,17,40,256,512,272,2048,1,8192,0,32768,33063,1,262144,272,32769,0,41001,16,35,8224,17,303404,1,1,43308,21,40968,256,0,0,512]

theorem envBound15537 : H12AffineFastState.Bounded env15537 := by
  intro p hp
  have h : env15537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15536_15537 : H12AffineEnvironment.transform 6 40 env15536 = env15537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env15536 == env15537) = true)

theorem identity15537 : scanCanonicalize (H12AffineFastState.compose env15537 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound15537 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env15538 : List Nat := [2,4,8,16,32,17,40,256,512,272,2048,1,8192,0,32768,33063,1,43049,272,32769,0,41001,16,35,8224,17,2309,1,1,43308,21,40968,256,0,0,512]

theorem envBound15538 : H12AffineFastState.Bounded env15538 := by
  intro p hp
  have h : env15538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15537_15538 : H12AffineEnvironment.transform 17 43049 env15537 = env15538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env15537 == env15538) = true)

def env15539 : List Nat := [2,4,8,16,0,17,8,256,512,272,2048,1,8192,0,32768,33031,1,43017,272,32769,0,40969,16,3,8192,17,2309,1,1,43276,21,40968,256,0,0,512]

theorem envBound15539 : H12AffineFastState.Bounded env15539 := by
  intro p hp
  have h : env15539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15538_15539 : H12AffineEnvironment.transform 4 0 env15538 = env15539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15538 == env15539) = true)

theorem identity15539 : scanCanonicalize (H12AffineFastState.compose env15539 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound15539 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15540 : List Nat := [2,4,8,16,0,17,8,256,1,272,2048,1,8192,0,32768,33031,1,43017,272,32769,0,40969,16,3,8192,17,2309,1,1,43276,21,40968,256,0,0,1]

theorem envBound15540 : H12AffineFastState.Bounded env15540 := by
  intro p hp
  have h : env15540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15539_15540 : H12AffineEnvironment.transform 8 1 env15539 = env15540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env15539 == env15540) = true)

def env15541 : List Nat := [2,4,8,16,0,17,8,256,1,272,2048,1,8192,0,2048,2311,1,8201,272,2049,0,10249,16,3,8192,17,2309,1,1,8460,21,10248,256,0,0,1]

theorem envBound15541 : H12AffineFastState.Bounded env15541 := by
  intro p hp
  have h : env15541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15540_15541 : H12AffineEnvironment.transform 14 2048 env15540 = env15541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2048 env15540 == env15541) = true)

theorem identity15541 : scanCanonicalize (H12AffineFastState.compose env15541 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound15541 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15542 : List Nat := [2,4,8,16,0,17,8,5,1,21,2048,1,8192,0,2048,2050,1,8201,21,2049,0,10249,16,3,8192,17,2048,1,1,8201,21,10248,5,0,0,1]

theorem envBound15542 : H12AffineFastState.Bounded env15542 := by
  intro p hp
  have h : env15542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15541_15542 : H12AffineEnvironment.transform 7 5 env15541 = env15542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env15541 == env15542) = true)

def env15543 : List Nat := [2,4,8,16,0,17,8,256,1,272,2048,1,8192,0,2049,2310,1,8200,272,2048,0,10248,16,3,8192,17,2309,1,1,8461,21,10249,256,0,0,1]

theorem envBound15543 : H12AffineFastState.Bounded env15543 := by
  intro p hp
  have h : env15543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15540_15543 : H12AffineEnvironment.transform 14 2049 env15540 = env15543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2049 env15540 == env15543) = true)

theorem identity15543 : scanCanonicalize (H12AffineFastState.compose env15543 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 2057) := by decide +kernel

theorem selectedBound15543 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15544 : List Nat := [2,4,8,16,0,17,8,256,1,272,2048,1,2057,0,2049,2310,1,2049,272,2048,0,1,16,3,2057,17,2309,1,1,2308,21,0,256,0,0,1]

theorem envBound15544 : H12AffineFastState.Bounded env15544 := by
  intro p hp
  have h : env15544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15543_15544 : H12AffineEnvironment.transform 12 2057 env15543 = env15544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2057 env15543 == env15544) = true)

theorem identity15544 : scanCanonicalize (H12AffineFastState.compose env15544 (packedSelected [7] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound15544 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env15545 : List Nat := [2,4,8,16,0,17,8,4,1,20,2048,1,2057,0,2049,2050,1,2049,20,2048,0,1,16,3,2057,17,2049,1,1,2048,21,0,4,0,0,1]

theorem envBound15545 : H12AffineFastState.Bounded env15545 := by
  intro p hp
  have h : env15545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15544_15545 : H12AffineEnvironment.transform 7 4 env15544 = env15545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env15544 == env15545) = true)

def leafEnv15545 : List Nat := [2,4,8,16,0,17,8,4,1,20,2048,1,2057,0,2049,2050,1,2049,20,2048,0,1,16,3,21,2057,1,17,2049,1,1,2048,21,0,4,0,4,2051,0,1,0,0,1]

def active15545 : List Nat := [0,1,2,3,10]

def tree15545 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15545 : H12WitnessSearch.Good tree15545 := H12GlobalWitnessIndex.good

theorem leafIdentity15545 : H12AffineFastState.composeSystem env15545 rootObs = leafEnv15545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15545 rootObs == leafEnv15545) = true)

theorem terminalChecked15545 : H12PackedTerminal.terminalCheckFast leafEnv15545 active15545 tree15545 = true := by decide +kernel

def env15546 : List Nat := [2,4,8,16,1,17,9,256,512,272,2048,1,8192,0,32768,33030,1,43016,272,32769,0,40968,16,2,8193,17,2309,1,1,43277,21,40968,256,0,0,512]

theorem envBound15546 : H12AffineFastState.Bounded env15546 := by
  intro p hp
  have h : env15546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15538_15546 : H12AffineEnvironment.transform 4 1 env15538 = env15546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env15538 == env15546) = true)

theorem identity15546 : scanCanonicalize (H12AffineFastState.compose env15546 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound15546 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15547 : List Nat := [2,4,8,16,1,17,9,256,260,272,2048,1,8192,0,32768,33030,1,43016,272,32769,0,40968,16,2,8193,17,2309,1,1,43277,21,40968,256,0,0,260]

theorem envBound15547 : H12AffineFastState.Bounded env15547 := by
  intro p hp
  have h : env15547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15546_15547 : H12AffineEnvironment.transform 8 260 env15546 = env15547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env15546 == env15547) = true)

def env15548 : List Nat := [2,4,8,16,1,17,9,256,260,272,2048,1,2056,0,32768,33030,1,32768,272,32769,0,34816,16,2,2057,17,2309,1,1,33029,21,34816,256,0,0,260]

theorem envBound15548 : H12AffineFastState.Bounded env15548 := by
  intro p hp
  have h : env15548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15547_15548 : H12AffineEnvironment.transform 12 2056 env15547 = env15548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2056 env15547 == env15548) = true)

theorem identity15548 : scanCanonicalize (H12AffineFastState.compose env15548 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound15548 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15549 : List Nat := [2,4,8,16,1,17,9,4,0,20,2048,1,2056,0,32768,32770,1,32768,20,32769,0,34816,16,2,2057,17,2049,1,1,32769,21,34816,4,0,0,0]

theorem envBound15549 : H12AffineFastState.Bounded env15549 := by
  intro p hp
  have h : env15549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15548_15549 : H12AffineEnvironment.transform 7 4 env15548 = env15549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env15548 == env15549) = true)

def leafEnv15549 : List Nat := [2,4,8,16,1,17,9,4,0,20,2048,1,2056,0,32768,32770,1,32768,20,32769,0,34816,16,2,21,2057,1,17,2049,1,1,32769,21,34816,4,0,4,32770,0,0,0,0,1]

def active15549 : List Nat := [0,1,2,3,10,14]

def tree15549 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15549 : H12WitnessSearch.Good tree15549 := H12GlobalWitnessIndex.good

theorem leafIdentity15549 : H12AffineFastState.composeSystem env15549 rootObs = leafEnv15549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15549 rootObs == leafEnv15549) = true)

theorem terminalChecked15549 : H12PackedTerminal.terminalCheckFast leafEnv15549 active15549 tree15549 = true := by decide +kernel

def env15550 : List Nat := [2,4,8,16,1,17,9,256,260,272,2048,1,2057,0,32768,33030,1,32769,272,32769,0,34817,16,2,2056,17,2309,1,1,33028,21,34817,256,0,0,260]

theorem envBound15550 : H12AffineFastState.Bounded env15550 := by
  intro p hp
  have h : env15550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15547_15550 : H12AffineEnvironment.transform 12 2057 env15547 = env15550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2057 env15547 == env15550) = true)

theorem identity15550 : scanCanonicalize (H12AffineFastState.compose env15550 (packedSelected [0] rootPS)) = affineNative (2^(14+1) ^^^ 2049) := by decide +kernel

theorem selectedBound15550 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15551 : List Nat := [2,4,8,16,1,17,9,256,260,272,2048,1,2057,0,2049,2311,1,2048,272,2048,0,0,16,2,2056,17,2309,1,1,2309,21,0,256,0,0,260]

theorem envBound15551 : H12AffineFastState.Bounded env15551 := by
  intro p hp
  have h : env15551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15550_15551 : H12AffineEnvironment.transform 14 2049 env15550 = env15551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2049 env15550 == env15551) = true)

theorem identity15551 : scanCanonicalize (H12AffineFastState.compose env15551 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound15551 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env15552 : List Nat := [2,4,8,16,1,17,9,4,0,20,2048,1,2057,0,2049,2051,1,2048,20,2048,0,0,16,2,2056,17,2049,1,1,2049,21,0,4,0,0,0]

theorem envBound15552 : H12AffineFastState.Bounded env15552 := by
  intro p hp
  have h : env15552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15551_15552 : H12AffineEnvironment.transform 7 4 env15551 = env15552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env15551 == env15552) = true)

def leafEnv15552 : List Nat := [2,4,8,16,1,17,9,4,0,20,2048,1,2057,0,2049,2051,1,2048,20,2048,0,0,16,2,21,2056,1,17,2049,1,1,2049,21,0,4,0,4,2051,0,0,0,0,1]

def active15552 : List Nat := [0,1,2,3,10]

def tree15552 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15552 : H12WitnessSearch.Good tree15552 := H12GlobalWitnessIndex.good

theorem leafIdentity15552 : H12AffineFastState.composeSystem env15552 rootObs = leafEnv15552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15552 rootObs == leafEnv15552) = true)

theorem terminalChecked15552 : H12PackedTerminal.terminalCheckFast leafEnv15552 active15552 tree15552 = true := by decide +kernel

def env15553 : List Nat := [2,4,8,16,32,17,41,256,512,272,2048,1,8192,0,32768,33063,1,262144,272,32769,0,41000,16,35,8225,17,303405,1,1,43308,21,40968,256,0,0,512]

theorem envBound15553 : H12AffineFastState.Bounded env15553 := by
  intro p hp
  have h : env15553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15536_15553 : H12AffineEnvironment.transform 6 41 env15536 = env15553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env15536 == env15553) = true)

theorem identity15553 : scanCanonicalize (H12AffineFastState.compose env15553 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound15553 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env15554 : List Nat := [2,4,8,16,32,17,41,5,512,21,2048,1,8192,0,32768,32802,1,262144,21,32769,0,41000,16,35,8225,17,303144,1,1,43049,21,40968,5,0,0,512]

theorem envBound15554 : H12AffineFastState.Bounded env15554 := by
  intro p hp
  have h : env15554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15553_15554 : H12AffineEnvironment.transform 7 5 env15553 = env15554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env15553 == env15554) = true)

theorem identity15554 : scanCanonicalize (H12AffineFastState.compose env15554 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 521) := by decide +kernel

theorem selectedBound15554 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15555 : List Nat := [2,4,8,16,32,17,41,5,512,21,2048,1,521,0,32768,32802,1,262144,21,32769,0,33313,16,35,552,17,295457,1,1,35360,21,33281,5,0,0,512]

theorem envBound15555 : H12AffineFastState.Bounded env15555 := by
  intro p hp
  have h : env15555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15554_15555 : H12AffineEnvironment.transform 12 521 env15554 = env15555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 521 env15554 == env15555) = true)

theorem identity15555 : scanCanonicalize (H12AffineFastState.compose env15555 (packedSelected [11,18] rootPS)) = affineNative (2^(14+1) ^^^ 33) := by decide +kernel

theorem selectedBound15555 : packedSelected [11,18] rootPS < 2^1333 := by decide +kernel

def env15556 : List Nat := [2,4,8,16,32,17,41,5,512,21,2048,1,521,0,33,3,1,262144,21,32,0,512,16,35,552,17,262656,1,1,2561,21,544,5,0,0,512]

theorem envBound15556 : H12AffineFastState.Bounded env15556 := by
  intro p hp
  have h : env15556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15555_15556 : H12AffineEnvironment.transform 14 33 env15555 = env15556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 33 env15555 == env15556) = true)

def env15557 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,0,8192,1,32768,33063,0,262144,273,32769,1,41089,16,35,8328,17,303492,0,0,43308,20,40968,256,0,1,512]

theorem envBound15557 : H12AffineFastState.Bounded env15557 := by
  intro p hp
  have h : env15557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15535_15557 : H12AffineEnvironment.transform 9 273 env15535 = env15557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env15535 == env15557) = true)

theorem identity15557 : scanCanonicalize (H12AffineFastState.compose env15557 (packedSelected [1] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound15557 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15558 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,0,8192,1,32768,33063,0,43049,273,32769,1,41089,16,35,8328,17,2477,0,0,43308,20,40968,256,0,1,512]

theorem envBound15558 : H12AffineFastState.Bounded env15558 := by
  intro p hp
  have h : env15558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15557_15558 : H12AffineEnvironment.transform 17 43049 env15557 = env15558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env15557 == env15558) = true)

theorem identity15558 : scanCanonicalize (H12AffineFastState.compose env15558 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound15558 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env15559 : List Nat := [2,4,8,16,32,17,40,256,512,273,2048,0,8192,1,32768,33063,0,43049,273,32769,1,41001,16,35,8224,17,2309,0,0,43308,20,40968,256,0,1,512]

theorem envBound15559 : H12AffineFastState.Bounded env15559 := by
  intro p hp
  have h : env15559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15558_15559 : H12AffineEnvironment.transform 6 40 env15558 = env15559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env15558 == env15559) = true)

def env15560 : List Nat := [2,4,8,16,0,17,8,256,512,273,2048,0,8192,1,32768,33031,0,43017,273,32769,1,40969,16,3,8192,17,2309,0,0,43276,20,40968,256,0,1,512]

theorem envBound15560 : H12AffineFastState.Bounded env15560 := by
  intro p hp
  have h : env15560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15559_15560 : H12AffineEnvironment.transform 4 0 env15559 = env15560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15559 == env15560) = true)

theorem identity15560 : scanCanonicalize (H12AffineFastState.compose env15560 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound15560 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15561 : List Nat := [2,4,8,16,0,17,8,256,1,273,2048,0,8192,1,32768,33031,0,43017,273,32769,1,40969,16,3,8192,17,2309,0,0,43276,20,40968,256,0,1,1]

theorem envBound15561 : H12AffineFastState.Bounded env15561 := by
  intro p hp
  have h : env15561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15560_15561 : H12AffineEnvironment.transform 8 1 env15560 = env15561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env15560 == env15561) = true)

def env15562 : List Nat := [2,4,8,16,0,17,8,256,1,273,2048,0,8192,1,2048,2311,0,8201,273,2049,1,10249,16,3,8192,17,2309,0,0,8460,20,10248,256,0,1,1]

theorem envBound15562 : H12AffineFastState.Bounded env15562 := by
  intro p hp
  have h : env15562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15561_15562 : H12AffineEnvironment.transform 14 2048 env15561 = env15562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2048 env15561 == env15562) = true)

theorem identity15562 : scanCanonicalize (H12AffineFastState.compose env15562 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound15562 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15563 : List Nat := [2,4,8,16,0,17,8,5,1,20,2048,0,8192,1,2048,2050,0,8201,20,2049,1,10249,16,3,8192,17,2048,0,0,8201,20,10248,5,0,1,1]

theorem envBound15563 : H12AffineFastState.Bounded env15563 := by
  intro p hp
  have h : env15563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15562_15563 : H12AffineEnvironment.transform 7 5 env15562 = env15563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env15562 == env15563) = true)

def env15564 : List Nat := [2,4,8,16,0,17,8,256,1,273,2048,0,8192,1,2049,2310,0,8200,273,2048,1,10248,16,3,8192,17,2309,0,0,8461,20,10249,256,0,1,1]

theorem envBound15564 : H12AffineFastState.Bounded env15564 := by
  intro p hp
  have h : env15564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15561_15564 : H12AffineEnvironment.transform 14 2049 env15561 = env15564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2049 env15561 == env15564) = true)

theorem identity15564 : scanCanonicalize (H12AffineFastState.compose env15564 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 2057) := by decide +kernel

theorem selectedBound15564 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15565 : List Nat := [2,4,8,16,0,17,8,256,1,273,2048,0,2057,1,2049,2310,0,2049,273,2048,1,1,16,3,2057,17,2309,0,0,2308,20,0,256,0,1,1]

theorem envBound15565 : H12AffineFastState.Bounded env15565 := by
  intro p hp
  have h : env15565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15564_15565 : H12AffineEnvironment.transform 12 2057 env15564 = env15565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2057 env15564 == env15565) = true)

theorem identity15565 : scanCanonicalize (H12AffineFastState.compose env15565 (packedSelected [7] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound15565 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env15566 : List Nat := [2,4,8,16,0,17,8,4,1,21,2048,0,2057,1,2049,2050,0,2049,21,2048,1,1,16,3,2057,17,2049,0,0,2048,20,0,4,0,1,1]

theorem envBound15566 : H12AffineFastState.Bounded env15566 := by
  intro p hp
  have h : env15566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15565_15566 : H12AffineEnvironment.transform 7 4 env15565 = env15566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env15565 == env15566) = true)

def leafEnv15566 : List Nat := [2,4,8,16,0,17,8,4,1,21,2048,0,2057,1,2049,2050,0,2049,21,2048,1,1,16,3,20,2057,1,17,2049,0,0,2048,20,0,4,0,4,2051,1,1,0,1,1]

def active15566 : List Nat := [0,1,2,3,10]

def tree15566 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15566 : H12WitnessSearch.Good tree15566 := H12GlobalWitnessIndex.good

theorem leafIdentity15566 : H12AffineFastState.composeSystem env15566 rootObs = leafEnv15566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15566 rootObs == leafEnv15566) = true)

theorem terminalChecked15566 : H12PackedTerminal.terminalCheckFast leafEnv15566 active15566 tree15566 = true := by decide +kernel

def env15567 : List Nat := [2,4,8,16,1,17,9,256,512,273,2048,0,8192,1,32768,33030,0,43016,273,32769,1,40968,16,2,8193,17,2309,0,0,43277,20,40968,256,0,1,512]

theorem envBound15567 : H12AffineFastState.Bounded env15567 := by
  intro p hp
  have h : env15567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15559_15567 : H12AffineEnvironment.transform 4 1 env15559 = env15567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env15559 == env15567) = true)

theorem identity15567 : scanCanonicalize (H12AffineFastState.compose env15567 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound15567 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15568 : List Nat := [2,4,8,16,1,17,9,256,260,273,2048,0,8192,1,32768,33030,0,43016,273,32769,1,40968,16,2,8193,17,2309,0,0,43277,20,40968,256,0,1,260]

theorem envBound15568 : H12AffineFastState.Bounded env15568 := by
  intro p hp
  have h : env15568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15567_15568 : H12AffineEnvironment.transform 8 260 env15567 = env15568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env15567 == env15568) = true)

def env15569 : List Nat := [2,4,8,16,1,17,9,256,260,273,2048,0,2056,1,32768,33030,0,32768,273,32769,1,34816,16,2,2057,17,2309,0,0,33029,20,34816,256,0,1,260]

theorem envBound15569 : H12AffineFastState.Bounded env15569 := by
  intro p hp
  have h : env15569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15568_15569 : H12AffineEnvironment.transform 12 2056 env15568 = env15569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2056 env15568 == env15569) = true)

theorem identity15569 : scanCanonicalize (H12AffineFastState.compose env15569 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound15569 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15570 : List Nat := [2,4,8,16,1,17,9,4,0,21,2048,0,2056,1,32768,32770,0,32768,21,32769,1,34816,16,2,2057,17,2049,0,0,32769,20,34816,4,0,1,0]

theorem envBound15570 : H12AffineFastState.Bounded env15570 := by
  intro p hp
  have h : env15570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15569_15570 : H12AffineEnvironment.transform 7 4 env15569 = env15570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env15569 == env15570) = true)

def leafEnv15570 : List Nat := [2,4,8,16,1,17,9,4,0,21,2048,0,2056,1,32768,32770,0,32768,21,32769,1,34816,16,2,20,2057,1,17,2049,0,0,32769,20,34816,4,0,4,32770,1,0,0,1,1]

def active15570 : List Nat := [0,1,2,3,10,14]

def tree15570 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15570 : H12WitnessSearch.Good tree15570 := H12GlobalWitnessIndex.good

theorem leafIdentity15570 : H12AffineFastState.composeSystem env15570 rootObs = leafEnv15570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15570 rootObs == leafEnv15570) = true)

theorem terminalChecked15570 : H12PackedTerminal.terminalCheckFast leafEnv15570 active15570 tree15570 = true := by decide +kernel

def env15571 : List Nat := [2,4,8,16,1,17,9,256,260,273,2048,0,2057,1,32768,33030,0,32769,273,32769,1,34817,16,2,2056,17,2309,0,0,33028,20,34817,256,0,1,260]

theorem envBound15571 : H12AffineFastState.Bounded env15571 := by
  intro p hp
  have h : env15571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15568_15571 : H12AffineEnvironment.transform 12 2057 env15568 = env15571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2057 env15568 == env15571) = true)

theorem identity15571 : scanCanonicalize (H12AffineFastState.compose env15571 (packedSelected [0] rootPS)) = affineNative (2^(14+1) ^^^ 2049) := by decide +kernel

theorem selectedBound15571 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15572 : List Nat := [2,4,8,16,1,17,9,256,260,273,2048,0,2057,1,2049,2311,0,2048,273,2048,1,0,16,2,2056,17,2309,0,0,2309,20,0,256,0,1,260]

theorem envBound15572 : H12AffineFastState.Bounded env15572 := by
  intro p hp
  have h : env15572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15571_15572 : H12AffineEnvironment.transform 14 2049 env15571 = env15572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2049 env15571 == env15572) = true)

theorem identity15572 : scanCanonicalize (H12AffineFastState.compose env15572 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound15572 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env15573 : List Nat := [2,4,8,16,1,17,9,4,0,21,2048,0,2057,1,2049,2051,0,2048,21,2048,1,0,16,2,2056,17,2049,0,0,2049,20,0,4,0,1,0]

theorem envBound15573 : H12AffineFastState.Bounded env15573 := by
  intro p hp
  have h : env15573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15572_15573 : H12AffineEnvironment.transform 7 4 env15572 = env15573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env15572 == env15573) = true)

def leafEnv15573 : List Nat := [2,4,8,16,1,17,9,4,0,21,2048,0,2057,1,2049,2051,0,2048,21,2048,1,0,16,2,20,2056,1,17,2049,0,0,2049,20,0,4,0,4,2051,1,0,0,1,1]

def active15573 : List Nat := [0,1,2,3,10]

def tree15573 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15573 : H12WitnessSearch.Good tree15573 := H12GlobalWitnessIndex.good

theorem leafIdentity15573 : H12AffineFastState.composeSystem env15573 rootObs = leafEnv15573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15573 rootObs == leafEnv15573) = true)

theorem terminalChecked15573 : H12PackedTerminal.terminalCheckFast leafEnv15573 active15573 tree15573 = true := by decide +kernel

def env15574 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32769,4097,4194304,17664,16777216,8328,541008,4477269,16384,545088,1073741824,16876544,4294967296,257,4315938986,17420308,512]

theorem envBound15574 : H12AffineFastState.Bounded env15574 := by
  intro p hp
  have h : env15574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15441_15574 : H12AffineEnvironment.transform 16 1345 env15441 = env15574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env15441 == env15574) = true)

theorem identity15574 : scanCanonicalize (H12AffineFastState.compose env15574 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(23+1) ^^^ 644436) := by decide +kernel

theorem selectedBound15574 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env15575 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32769,4097,4194304,17664,644436,8328,541008,4477269,16384,545088,1073741824,545108,4294967296,257,4299806206,1344,512]

theorem envBound15575 : H12AffineFastState.Bounded env15575 := by
  intro p hp
  have h : env15575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15574_15575 : H12AffineEnvironment.transform 23 644436 env15574 = env15575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 644436 env15574 == env15575) = true)

theorem identity15575 : scanCanonicalize (H12AffineFastState.compose env15575 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(18+1) ^^^ 1025) := by decide +kernel

theorem selectedBound15575 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env15576 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,1025,32769,4097,4194304,17664,119125,8328,17745,4477269,16384,21825,1073741824,21845,4294967296,257,4299280895,1344,512]

theorem envBound15576 : H12AffineFastState.Bounded env15576 := by
  intro p hp
  have h : env15576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15575_15576 : H12AffineEnvironment.transform 18 1025 env15575 = env15576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env15575 == env15576) = true)

def env15577 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4096,32768,65536,1345,262144,1025,32769,4097,4194304,5376,98645,8328,5457,4456789,4096,1345,1073741824,1365,4294967296,257,4299260415,1344,512]

theorem envBound15577 : H12AffineFastState.Bounded env15577 := by
  intro p hp
  have h : env15577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15576_15577 : H12AffineEnvironment.transform 13 4096 env15576 = env15577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4096 env15576 == env15577) = true)

theorem identity15577 : scanCanonicalize (H12AffineFastState.compose env15577 (packedSelected [0,7,20] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound15577 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env15578 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1297,8192,1297,32768,65536,1345,262144,1025,32769,1296,4194304,17,98645,8328,64,4456789,1297,1345,1073741824,1365,4294967296,257,4299260415,1344,512]

theorem envBound15578 : H12AffineFastState.Bounded env15578 := by
  intro p hp
  have h : env15578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15577_15578 : H12AffineEnvironment.transform 11 1297 env15577 = env15578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env15577 == env15578) = true)

theorem identity15578 : scanCanonicalize (H12AffineFastState.compose env15578 (packedSelected [13,17] rootPS)) = affineNative (2^(31+1) ^^^ 1077979296) := by decide +kernel

theorem selectedBound15578 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env15579 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1297,8192,1297,32768,65536,1345,262144,1025,32769,1296,4194304,17,98645,8328,64,4456789,1297,1345,1073741824,1365,1077979296,257,1073817951,1344,512]

theorem envBound15579 : H12AffineFastState.Bounded env15579 := by
  intro p hp
  have h : env15579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15578_15579 : H12AffineEnvironment.transform 31 1077979296 env15578 = env15579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1077979296 env15578 == env15579) = true)

theorem identity15579 : scanCanonicalize (H12AffineFastState.compose env15579 (packedSelected [13,21] rootPS)) = affineNative (2^(29+1) ^^^ 43128) := by decide +kernel

theorem selectedBound15579 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env15580 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1297,8192,1297,32768,65536,1345,262144,1025,32769,1296,4194304,17,98645,8328,64,4456789,1297,1345,43128,1365,4194520,257,98599,1344,512]

theorem envBound15580 : H12AffineFastState.Bounded env15580 := by
  intro p hp
  have h : env15580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15579_15580 : H12AffineEnvironment.transform 29 43128 env15579 = env15580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 43128 env15579 == env15580) = true)

theorem identity15580 : scanCanonicalize (H12AffineFastState.compose env15580 (packedSelected [1,3,15,24,28,38] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound15580 : packedSelected [1,3,15,24,28,38] rootPS < 2^1333 := by decide +kernel

def env15581 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1297,32768,65536,1296,262144,1025,32769,1296,4194304,17,98564,8328,17,4456708,1297,1296,43049,1284,4194441,257,98599,1297,512]

theorem envBound15581 : H12AffineFastState.Bounded env15581 := by
  intro p hp
  have h : env15581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15580_15581 : H12AffineEnvironment.transform 5 17 env15580 = env15581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env15580 == env15581) = true)

theorem identity15581 : scanCanonicalize (H12AffineFastState.compose env15581 (packedSelected [1,3,5] rootPS)) = affineNative (2^(15+1) ^^^ 8193) := by decide +kernel

theorem selectedBound15581 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env15582 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1297,32768,8193,1296,262144,1025,32769,1296,4194304,17,41221,8328,17,4456708,1297,1296,43049,1284,4194441,257,41254,1297,512]

theorem envBound15582 : H12AffineFastState.Bounded env15582 := by
  intro p hp
  have h : env15582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15581_15582 : H12AffineEnvironment.transform 15 8193 env15581 = env15582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8193 env15581 == env15582) = true)

theorem identity15582 : scanCanonicalize (H12AffineFastState.compose env15582 (packedSelected [1,3,8] rootPS)) = affineNative (2^(14+1) ^^^ 9093) := by decide +kernel

theorem selectedBound15582 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env15583 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1297,9093,8193,1296,262144,1025,9092,1296,4194304,17,640,8328,17,4456708,1297,1296,2988,1284,4194441,257,675,1297,512]

theorem envBound15583 : H12AffineFastState.Bounded env15583 := by
  intro p hp
  have h : env15583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15582_15583 : H12AffineEnvironment.transform 14 9093 env15582 = env15583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9093 env15582 == env15583) = true)

theorem identity15583 : scanCanonicalize (H12AffineFastState.compose env15583 (packedSelected [1,12,13] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound15583 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env15584 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1297,9093,8193,1296,262144,1025,9092,1296,33,17,640,8328,17,262437,1297,1296,2988,1284,168,257,675,1297,512]

theorem envBound15584 : H12AffineFastState.Bounded env15584 := by
  intro p hp
  have h : env15584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15583_15584 : H12AffineEnvironment.transform 21 33 env15583 = env15584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env15583 == env15584) = true)

theorem identity15584 : scanCanonicalize (H12AffineFastState.compose env15584 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 2470) := by decide +kernel

theorem selectedBound15584 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env15585 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1297,9093,8193,1296,2470,1025,9092,1296,33,17,640,8328,17,2179,1297,1296,2988,1284,168,257,675,1297,512]

theorem envBound15585 : H12AffineFastState.Bounded env15585 := by
  intro p hp
  have h : env15585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15584_15585 : H12AffineEnvironment.transform 17 2470 env15584 = env15585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2470 env15584 == env15585) = true)

theorem identity15585 : scanCanonicalize (H12AffineFastState.compose env15585 (packedSelected [3] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound15585 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env15586 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,269,1297,648,268,1296,2470,1025,649,1296,33,17,640,389,17,2179,1297,1296,2988,1284,168,257,675,1297,512]

theorem envBound15586 : H12AffineFastState.Bounded env15586 := by
  intro p hp
  have h : env15586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15585_15586 : H12AffineEnvironment.transform 12 269 env15585 = env15586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env15585 == env15586) = true)

theorem identity15586 : scanCanonicalize (H12AffineFastState.compose env15586 (packedSelected [0,2,4,6,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 921) := by decide +kernel

theorem selectedBound15586 : packedSelected [0,2,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env15587 : List Nat := [2,4,8,16,32,17,128,256,512,921,2048,648,269,648,648,268,649,2470,920,649,649,33,17,640,389,17,2179,648,649,2988,669,168,257,675,648,512]

theorem envBound15587 : H12AffineFastState.Bounded env15587 := by
  intro p hp
  have h : env15587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15586_15587 : H12AffineEnvironment.transform 9 921 env15586 = env15587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 921 env15586 == env15587) = true)

theorem identity15587 : scanCanonicalize (H12AffineFastState.compose env15587 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound15587 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15588 : List Nat := [2,4,8,16,32,17,128,256,137,272,2048,1,269,1,1,268,0,2470,273,0,0,33,17,9,389,17,2179,1,0,2341,20,168,257,42,1,137]

theorem envBound15588 : H12AffineFastState.Bounded env15588 := by
  intro p hp
  have h : env15588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15587_15588 : H12AffineEnvironment.transform 8 137 env15587 = env15588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env15587 == env15588) = true)

theorem identity15588 : scanCanonicalize (H12AffineFastState.compose env15588 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound15588 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env15589 : List Nat := [2,4,8,16,32,17,2,256,11,272,2048,1,269,1,1,268,0,2340,273,0,0,33,17,9,263,17,2049,1,0,2341,20,42,257,42,1,11]

theorem envBound15589 : H12AffineFastState.Bounded env15589 := by
  intro p hp
  have h : env15589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15588_15589 : H12AffineEnvironment.transform 6 2 env15588 = env15589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env15588 == env15589) = true)

theorem identity15589 : scanCanonicalize (H12AffineFastState.compose env15589 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound15589 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15590 : List Nat := [2,4,8,16,32,17,2,20,11,4,2048,1,25,1,1,24,0,2096,5,0,0,33,17,9,19,17,2049,1,0,2097,20,42,21,42,1,11]

theorem envBound15590 : H12AffineFastState.Bounded env15590 := by
  intro p hp
  have h : env15590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15589_15590 : H12AffineEnvironment.transform 7 20 env15589 = env15590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env15589 == env15590) = true)

def env15591 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4097,32768,65536,1345,262144,1025,32769,4097,4194304,5377,98644,8328,5456,4456788,4097,1344,1073741824,1364,4294967296,257,4299260414,1344,512]

theorem envBound15591 : H12AffineFastState.Bounded env15591 := by
  intro p hp
  have h : env15591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15576_15591 : H12AffineEnvironment.transform 13 4097 env15576 = env15591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4097 env15576 == env15591) = true)

theorem identity15591 : scanCanonicalize (H12AffineFastState.compose env15591 (packedSelected [0,7,20] rootPS)) = affineNative (2^(11+1) ^^^ 1345) := by decide +kernel

theorem selectedBound15591 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env15592 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,65536,1345,262144,1025,32769,1344,4194304,64,98644,8328,17,4456788,1344,1344,1073741824,1364,4294967296,257,4299260414,1344,512]

theorem envBound15592 : H12AffineFastState.Bounded env15592 := by
  intro p hp
  have h : env15592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15591_15592 : H12AffineEnvironment.transform 11 1345 env15591 = env15592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env15591 == env15592) = true)

theorem identity15592 : scanCanonicalize (H12AffineFastState.compose env15592 (packedSelected [12,13,15,17,38,41] rootPS)) = affineNative (2^(31+1) ^^^ 73771) := by decide +kernel

theorem selectedBound15592 : packedSelected [12,13,15,17,38,41] rootPS < 2^1333 := by decide +kernel

def env15593 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,65536,1345,262144,1025,32769,1344,4194304,64,98644,8328,17,4456788,1344,1344,1073741824,1364,73771,257,4235733,1344,512]

theorem envBound15593 : H12AffineFastState.Bounded env15593 := by
  intro p hp
  have h : env15593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15592_15593 : H12AffineEnvironment.transform 31 73771 env15592 = env15593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 73771 env15592 == env15593) = true)

def env15594 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1296,32768,65536,1297,262144,1025,32769,1296,4194304,16,98564,8328,17,4456708,1296,1296,1073741824,1284,73771,257,4235653,1296,512]

theorem envBound15594 : H12AffineFastState.Bounded env15594 := by
  intro p hp
  have h : env15594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15593_15594 : H12AffineEnvironment.transform 5 16 env15593 = env15594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env15593 == env15594) = true)

theorem identity15594 : scanCanonicalize (H12AffineFastState.compose env15594 (packedSelected [1,3,5] rootPS)) = affineNative (2^(29+1) ^^^ 101025) := by decide +kernel

theorem selectedBound15594 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env15595 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1296,32768,65536,1297,262144,1025,32769,1296,4194304,16,98564,8328,17,4456708,1296,1296,101025,1284,73771,257,4235653,1296,512]

theorem envBound15595 : H12AffineFastState.Bounded env15595 := by
  intro p hp
  have h : env15595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15594_15595 : H12AffineEnvironment.transform 29 101025 env15594 = env15595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 101025 env15594 == env15595) = true)

theorem identity15595 : scanCanonicalize (H12AffineFastState.compose env15595 (packedSelected [1,3,8] rootPS)) = affineNative (2^(14+1) ^^^ 9093) := by decide +kernel

theorem selectedBound15595 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env15596 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1296,9093,65536,1297,262144,1025,9092,1296,4194304,16,74369,8328,17,4456708,1296,1296,76068,1284,73771,257,4194816,1296,512]

theorem envBound15596 : H12AffineFastState.Bounded env15596 := by
  intro p hp
  have h : env15596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15595_15596 : H12AffineEnvironment.transform 14 9093 env15595 = env15596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9093 env15595 == env15596) = true)

theorem identity15596 : scanCanonicalize (H12AffineFastState.compose env15596 (packedSelected [1,12,13] rootPS)) = affineNative (2^(21+1) ^^^ 74409) := by decide +kernel

theorem selectedBound15596 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env15597 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1296,9093,65536,1297,262144,1025,9092,1296,74409,16,74369,8328,17,336813,1296,1296,76068,1284,73771,257,73897,1296,512]

theorem envBound15597 : H12AffineFastState.Bounded env15597 := by
  intro p hp
  have h : env15597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15596_15597 : H12AffineEnvironment.transform 21 74409 env15596 = env15597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 74409 env15596 == env15597) = true)

theorem identity15597 : scanCanonicalize (H12AffineFastState.compose env15597 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 76199) := by decide +kernel

theorem selectedBound15597 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env15598 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1296,9093,65536,1297,76199,1025,9092,1296,74409,16,74369,8328,17,2570,1296,1296,76068,1284,73771,257,73897,1296,512]

theorem envBound15598 : H12AffineFastState.Bounded env15598 := by
  intro p hp
  have h : env15598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15597_15598 : H12AffineEnvironment.transform 17 76199 env15597 = env15598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76199 env15597 == env15598) = true)

theorem identity15598 : scanCanonicalize (H12AffineFastState.compose env15598 (packedSelected [3] rootPS)) = affineNative (2^(15+1) ^^^ 901) := by decide +kernel

theorem selectedBound15598 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env15599 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1296,9093,901,1297,10786,1025,9092,1296,8492,16,8452,8328,17,2570,1296,1296,10913,1284,9134,257,9004,1296,512]

theorem envBound15599 : H12AffineFastState.Bounded env15599 := by
  intro p hp
  have h : env15599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15598_15599 : H12AffineEnvironment.transform 15 901 env15598 = env15599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 901 env15598 == env15599) = true)

theorem identity15599 : scanCanonicalize (H12AffineFastState.compose env15599 (packedSelected [1,12,21] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound15599 : packedSelected [1,12,21] rootPS < 2^1333 := by decide +kernel

def env15600 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,269,1296,648,901,1297,2863,1025,649,1296,33,16,9,389,17,2570,1296,1296,2988,1284,675,257,545,1296,512]

theorem envBound15600 : H12AffineFastState.Bounded env15600 := by
  intro p hp
  have h : env15600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15599_15600 : H12AffineEnvironment.transform 12 269 env15599 = env15600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env15599 == env15600) = true)

theorem identity15600 : scanCanonicalize (H12AffineFastState.compose env15600 (packedSelected [2,6] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound15600 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env15601 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,0,269,1,648,901,0,2863,272,649,1,33,16,9,389,17,2570,1,1,2988,21,675,257,545,1,512]

theorem envBound15601 : H12AffineFastState.Bounded env15601 := by
  intro p hp
  have h : env15601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15600_15601 : H12AffineEnvironment.transform 9 273 env15600 = env15601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env15600 == env15601) = true)

theorem identity15601 : scanCanonicalize (H12AffineFastState.compose env15601 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound15601 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15602 : List Nat := [2,4,8,16,32,16,128,256,11,273,2048,0,269,1,131,398,0,2340,272,130,1,33,16,9,389,17,2049,1,1,2471,21,168,257,42,1,11]

theorem envBound15602 : H12AffineFastState.Bounded env15602 := by
  intro p hp
  have h : env15602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15601_15602 : H12AffineEnvironment.transform 8 11 env15601 = env15602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env15601 == env15602) = true)

theorem identity15602 : scanCanonicalize (H12AffineFastState.compose env15602 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound15602 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env15603 : List Nat := [2,4,8,16,32,16,2,256,11,273,2048,0,269,1,1,268,0,2340,272,0,1,33,16,9,263,17,2049,1,1,2341,21,42,257,42,1,11]

theorem envBound15603 : H12AffineFastState.Bounded env15603 := by
  intro p hp
  have h : env15603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15602_15603 : H12AffineEnvironment.transform 6 2 env15602 = env15603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env15602 == env15603) = true)

theorem identity15603 : scanCanonicalize (H12AffineFastState.compose env15603 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound15603 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15604 : List Nat := [2,4,8,16,32,16,2,21,11,4,2048,0,24,1,1,25,0,2097,5,0,1,33,16,9,18,17,2049,1,1,2096,21,42,20,42,1,11]

theorem envBound15604 : H12AffineFastState.Bounded env15604 := by
  intro p hp
  have h : env15604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15603_15604 : H12AffineEnvironment.transform 7 21 env15603 = env15604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env15603 == env15604) = true)

def env15605 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1297,32768,65536,1296,262144,1025,32769,1297,4194304,17,98565,8328,17,4456709,1297,1297,1073741824,1285,73771,257,4235652,1297,512]

theorem envBound15605 : H12AffineFastState.Bounded env15605 := by
  intro p hp
  have h : env15605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15593_15605 : H12AffineEnvironment.transform 5 17 env15593 = env15605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env15593 == env15605) = true)

theorem identity15605 : scanCanonicalize (H12AffineFastState.compose env15605 (packedSelected [1,3,5] rootPS)) = affineNative (2^(29+1) ^^^ 11020) := by decide +kernel

theorem selectedBound15605 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env15606 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1297,32768,65536,1296,262144,1025,32769,1297,4194304,17,98565,8328,17,4456709,1297,1297,11020,1285,73771,257,4235652,1297,512]

theorem envBound15606 : H12AffineFastState.Bounded env15606 := by
  intro p hp
  have h : env15606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15605_15606 : H12AffineEnvironment.transform 29 11020 env15605 = env15606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 11020 env15605 == env15606) = true)

theorem identity15606 : scanCanonicalize (H12AffineFastState.compose env15606 (packedSelected [1,3,8] rootPS)) = affineNative (2^(14+1) ^^^ 8972) := by decide +kernel

theorem selectedBound15606 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env15607 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1297,8972,65536,1296,262144,1025,8973,1297,4194304,17,74249,8328,17,4456709,1297,1297,11020,1285,73771,257,4194952,1297,512]

theorem envBound15607 : H12AffineFastState.Bounded env15607 := by
  intro p hp
  have h : env15607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15606_15607 : H12AffineEnvironment.transform 14 8972 env15606 = env15607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8972 env15606 == env15607) = true)

theorem identity15607 : scanCanonicalize (H12AffineFastState.compose env15607 (packedSelected [1,12,13] rootPS)) = affineNative (2^(21+1) ^^^ 76047) := by decide +kernel

theorem selectedBound15607 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env15608 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1297,8972,65536,1296,262144,1025,8973,1297,76047,17,74249,8328,17,337930,1297,1297,11020,1285,73771,257,76679,1297,512]

theorem envBound15608 : H12AffineFastState.Bounded env15608 := by
  intro p hp
  have h : env15608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15607_15608 : H12AffineEnvironment.transform 21 76047 env15607 = env15608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 76047 env15607 == env15608) = true)

theorem identity15608 : scanCanonicalize (H12AffineFastState.compose env15608 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 428) := by decide +kernel

theorem selectedBound15608 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env15609 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1297,8972,65536,1296,428,1025,8973,1297,76047,17,74249,8328,17,76198,1297,1297,11020,1285,73771,257,76679,1297,512]

theorem envBound15609 : H12AffineFastState.Bounded env15609 := by
  intro p hp
  have h : env15609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15608_15609 : H12AffineEnvironment.transform 17 428 env15608 = env15609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 428 env15608 == env15609) = true)

theorem identity15609 : scanCanonicalize (H12AffineFastState.compose env15609 (packedSelected [1,12,17] rootPS)) = affineNative (2^(15+1) ^^^ 2822) := by decide +kernel

theorem selectedBound15609 : packedSelected [1,12,17] rootPS < 2^1333 := by decide +kernel

def env15610 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1297,8972,2822,1296,428,1025,8973,1297,8713,17,10511,8328,17,8864,1297,1297,11020,1285,11053,257,8321,1297,512]

theorem envBound15610 : H12AffineFastState.Bounded env15610 := by
  intro p hp
  have h : env15610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15609_15610 : H12AffineEnvironment.transform 15 2822 env15609 = env15610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2822 env15609 == env15610) = true)

theorem identity15610 : scanCanonicalize (H12AffineFastState.compose env15610 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 305) := by decide +kernel

theorem selectedBound15610 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15611 : List Nat := [2,4,8,16,32,17,128,256,512,305,2048,33,8192,32,8972,2822,33,428,304,8973,32,8713,17,10511,8328,17,8864,32,32,11020,52,11053,257,8321,32,512]

theorem envBound15611 : H12AffineFastState.Bounded env15611 := by
  intro p hp
  have h : env15611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15610_15611 : H12AffineEnvironment.transform 9 305 env15610 = env15611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env15610 == env15611) = true)

theorem identity15611 : scanCanonicalize (H12AffineFastState.compose env15611 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 429) := by decide +kernel

theorem selectedBound15611 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env15612 : List Nat := [2,4,8,16,32,17,128,256,512,305,429,33,8192,32,8972,683,33,428,304,8973,32,8713,17,8354,8328,17,8864,32,32,8865,52,8832,257,8321,32,512]

theorem envBound15612 : H12AffineFastState.Bounded env15612 := by
  intro p hp
  have h : env15612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15611_15612 : H12AffineEnvironment.transform 10 429 env15611 = env15612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 429 env15611 == env15612) = true)

theorem identity15612 : scanCanonicalize (H12AffineFastState.compose env15612 (packedSelected [7] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound15612 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env15613 : List Nat := [2,4,8,16,32,17,128,256,512,305,429,33,41,32,805,683,33,428,304,804,32,544,17,139,161,17,649,32,32,648,52,681,257,168,32,512]

theorem envBound15613 : H12AffineFastState.Bounded env15613 := by
  intro p hp
  have h : env15613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15612_15613 : H12AffineEnvironment.transform 12 41 env15612 = env15613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env15612 == env15613) = true)

theorem identity15613 : scanCanonicalize (H12AffineFastState.compose env15613 (packedSelected [2,6] rootPS)) = affineNative (2^(8+1) ^^^ 169) := by decide +kernel

theorem selectedBound15613 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env15614 : List Nat := [2,4,8,16,32,17,128,256,169,305,429,33,41,32,396,2,33,428,304,397,32,137,17,139,161,17,32,32,32,33,52,0,257,168,32,169]

theorem envBound15614 : H12AffineFastState.Bounded env15614 := by
  intro p hp
  have h : env15614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15613_15614 : H12AffineEnvironment.transform 8 169 env15613 = env15614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 169 env15613 == env15614) = true)

theorem identity15614 : scanCanonicalize (H12AffineFastState.compose env15614 (packedSelected [1,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound15614 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env15615 : List Nat := [2,4,8,16,1,17,128,256,136,272,396,0,8,1,396,2,0,397,273,397,1,137,17,139,128,17,1,1,1,0,21,0,257,137,1,136]

theorem envBound15615 : H12AffineFastState.Bounded env15615 := by
  intro p hp
  have h : env15615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15614_15615 : H12AffineEnvironment.transform 4 1 env15614 = env15615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env15614 == env15615) = true)

def env15616 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,4194304,17665,16777216,8328,541009,4477269,148800,676865,1073741824,17006912,4294967296,132161,4315938986,17552724,512]

theorem envBound15616 : H12AffineFastState.Bounded env15616 := by
  intro p hp
  have h : env15616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15440_15616 : H12AffineEnvironment.transform 22 17665 env15440 = env15616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17665 env15440 == env15616) = true)

def env15617 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,524288,32769,4097,4194304,17665,16777216,8328,541009,4477269,16384,545089,1073741824,16876544,4294967296,257,4315938986,17420308,512]

theorem envBound15617 : H12AffineFastState.Bounded env15617 := by
  intro p hp
  have h : env15617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15616_15617 : H12AffineEnvironment.transform 16 1344 env15616 = env15617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env15616 == env15617) = true)

def env15618 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32769,4097,4194304,17665,16777216,8328,541009,4477269,16385,545088,1073741824,16876545,4294967296,256,4315938986,17420309,512]

theorem envBound15618 : H12AffineFastState.Bounded env15618 := by
  intro p hp
  have h : env15618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15616_15618 : H12AffineEnvironment.transform 16 1345 env15616 = env15618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env15616 == env15618) = true)

theorem identity15618 : scanCanonicalize (H12AffineFastState.compose env15618 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(18+1) ^^^ 21585) := by decide +kernel

theorem selectedBound15618 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env15619 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,21585,32769,4097,4194304,17665,16777216,8328,5376,4477269,16385,1297,1073741824,16876545,4294967296,256,4315938986,16876612,512]

theorem envBound15619 : H12AffineFastState.Bounded env15619 := by
  intro p hp
  have h : env15619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15618_15619 : H12AffineEnvironment.transform 18 21585 env15618 = env15619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21585 env15618 == env15619) = true)

theorem identity15619 : scanCanonicalize (H12AffineFastState.compose env15619 (packedSelected [0,4,7,9,16,20] rootPS)) = affineNative (2^(13+1) ^^^ 4097) := by decide +kernel

theorem selectedBound15619 : packedSelected [0,4,7,9,16,20] rootPS < 2^1333 := by decide +kernel

def env15620 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4097,32768,65536,1345,262144,1104,32769,4097,4194304,5376,16777216,8328,5376,4456788,4096,1297,1073741824,16876545,4294967296,256,4315938986,16876612,512]

theorem envBound15620 : H12AffineFastState.Bounded env15620 := by
  intro p hp
  have h : env15620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15619_15620 : H12AffineEnvironment.transform 13 4097 env15619 = env15620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4097 env15619 == env15620) = true)

theorem identity15620 : scanCanonicalize (H12AffineFastState.compose env15620 (packedSelected [4,16,22] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound15620 : packedSelected [4,16,22] rootPS < 2^1333 := by decide +kernel

def env15621 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,32768,65536,1297,262144,1024,32769,4097,4194304,5376,16777216,8328,5376,4456708,4096,1297,1073741824,16876545,4294967296,256,4315938986,16876564,512]

theorem envBound15621 : H12AffineFastState.Bounded env15621 := by
  intro p hp
  have h : env15621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15620_15621 : H12AffineEnvironment.transform 5 16 env15620 = env15621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env15620 == env15621) = true)

theorem identity15621 : scanCanonicalize (H12AffineFastState.compose env15621 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(31+1) ^^^ 1094789541) := by decide +kernel

theorem selectedBound15621 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env15622 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,32768,65536,1297,262144,1024,32769,4097,4194304,5376,16777216,8328,5376,4456708,4096,1297,1073741824,16876545,1094789541,256,1073817871,16876564,512]

theorem envBound15622 : H12AffineFastState.Bounded env15622 := by
  intro p hp
  have h : env15622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15621_15622 : H12AffineEnvironment.transform 31 1094789541 env15621 = env15622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1094789541 env15621 == env15622) = true)

def env15623 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,8192,4097,32768,65536,1297,262144,1024,32769,4097,4194304,5376,16777216,8328,5376,4456708,4096,1297,1073741824,16876545,1094789541,256,1073817871,16876564,136]

theorem envBound15623 : H12AffineFastState.Bounded env15623 := by
  intro p hp
  have h : env15623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15622_15623 : H12AffineEnvironment.transform 8 136 env15622 = env15623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env15622 == env15623) = true)

theorem identity15623 : scanCanonicalize (H12AffineFastState.compose env15623 (packedSelected [1,3,8,10,12,13,17,28,38] rootPS)) = affineNative (2^(29+1) ^^^ 100614) := by decide +kernel

theorem selectedBound15623 : packedSelected [1,3,8,10,12,13,17,28,38] rootPS < 2^1333 := by decide +kernel

def env15624 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,8192,4097,32768,65536,1297,262144,1024,32769,4097,4194304,5376,16777216,8328,5376,4456708,4096,1297,100614,16876545,21012643,256,40969,16876564,136]

theorem envBound15624 : H12AffineFastState.Bounded env15624 := by
  intro p hp
  have h : env15624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15623_15624 : H12AffineEnvironment.transform 29 100614 env15623 = env15624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 100614 env15623 == env15624) = true)

def env15625 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,8192,4097,32768,65536,1297,13592,1024,32769,4097,4194304,5376,16777216,8328,5376,4207644,4096,1297,100614,16876545,21012643,256,40969,16876564,136]

theorem envBound15625 : H12AffineFastState.Bounded env15625 := by
  intro p hp
  have h : env15625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15624_15625 : H12AffineEnvironment.transform 17 13592 env15624 = env15625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 13592 env15624 == env15625) = true)

theorem identity15625 : scanCanonicalize (H12AffineFastState.compose env15625 (packedSelected [3,5,24] rootPS)) = affineNative (2^(23+1) ^^^ 13720) := by decide +kernel

theorem selectedBound15625 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env15626 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,8192,4097,32768,65536,1297,13592,1024,32769,4097,4194304,5376,13720,8328,5376,4207644,4096,1297,100614,111001,4232507,256,40969,110988,136]

theorem envBound15626 : H12AffineFastState.Bounded env15626 := by
  intro p hp
  have h : env15626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15625_15626 : H12AffineEnvironment.transform 23 13720 env15625 = env15626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 13720 env15625 == env15626) = true)

def env15627 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,8192,4097,32768,41096,1297,13592,1024,32769,4097,4194304,5376,13720,8328,5376,4207644,4096,1297,10638,4369,4232507,256,40969,4356,136]

theorem envBound15627 : H12AffineFastState.Bounded env15627 := by
  intro p hp
  have h : env15627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15626_15627 : H12AffineEnvironment.transform 15 41096 env15626 = env15627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41096 env15626 == env15627) = true)

theorem identity15627 : scanCanonicalize (H12AffineFastState.compose env15627 (packedSelected [1,8,28] rootPS)) = affineNative (2^(21+1) ^^^ 5529) := by decide +kernel

theorem selectedBound15627 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env15628 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,8192,4097,32768,41096,1297,13592,1024,32769,4097,5529,5376,13720,8328,5376,8581,4096,1297,10638,4369,32930,256,40969,4356,136]

theorem envBound15628 : H12AffineFastState.Bounded env15628 := by
  intro p hp
  have h : env15628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15627_15628 : H12AffineEnvironment.transform 21 5529 env15627 = env15628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 5529 env15627 == env15628) = true)

theorem identity15628 : scanCanonicalize (H12AffineFastState.compose env15628 (packedSelected [3,6,7,15,17] rootPS)) = affineNative (2^(14+1) ^^^ 8200) := by decide +kernel

theorem selectedBound15628 : packedSelected [3,6,7,15,17] rootPS < 2^1333 := by decide +kernel

def env15629 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,8192,4097,8200,128,1297,13592,1024,8201,4097,5529,5376,13720,8328,5376,8581,4096,1297,10638,4369,8362,256,1,4356,136]

theorem envBound15629 : H12AffineFastState.Bounded env15629 := by
  intro p hp
  have h : env15629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15628_15629 : H12AffineEnvironment.transform 14 8200 env15628 = env15629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8200 env15628 == env15629) = true)

def env15630 : List Nat := [2,4,8,16,32,16,128,256,136,256,2048,4096,8192,4097,8200,128,17,12312,256,8201,4097,4249,4096,12440,8328,4096,8581,4096,17,10638,4369,8362,256,1,4356,136]

theorem envBound15630 : H12AffineFastState.Bounded env15630 := by
  intro p hp
  have h : env15630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15629_15630 : H12AffineEnvironment.transform 9 256 env15629 = env15630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env15629 == env15630) = true)

theorem identity15630 : scanCanonicalize (H12AffineFastState.compose env15630 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound15630 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env15631 : List Nat := [2,4,8,16,32,16,128,256,136,256,2048,16,8192,17,8200,128,17,8200,256,8201,17,137,16,8328,8328,16,8581,16,17,10638,257,8362,256,1,276,136]

theorem envBound15631 : H12AffineFastState.Bounded env15631 := by
  intro p hp
  have h : env15631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15630_15631 : H12AffineEnvironment.transform 11 16 env15630 = env15631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env15630 == env15631) = true)

def env15632 : List Nat := [2,4,8,16,32,16,128,256,136,257,2048,4096,8192,4097,8200,128,16,12313,257,8201,4097,4248,4097,12441,8328,4097,8581,4096,16,10638,4369,8362,256,1,4356,136]

theorem envBound15632 : H12AffineFastState.Bounded env15632 := by
  intro p hp
  have h : env15632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15629_15632 : H12AffineEnvironment.transform 9 257 env15629 = env15632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 257 env15629 == env15632) = true)

theorem identity15632 : scanCanonicalize (H12AffineFastState.compose env15632 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound15632 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env15633 : List Nat := [2,4,8,16,32,16,128,5,136,4,2048,4096,8192,4097,8200,128,16,12313,4,8201,4097,4248,4097,12441,8328,4097,8320,4096,16,10379,4116,8362,5,1,4097,136]

theorem envBound15633 : H12AffineFastState.Bounded env15633 := by
  intro p hp
  have h : env15633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15632_15633 : H12AffineEnvironment.transform 7 5 env15632 = env15633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env15632 == env15633) = true)

def env15634 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,8192,4097,32768,41097,1297,13592,1024,32769,4097,4194304,5376,13720,8328,5376,4207644,4096,1297,10639,4368,4232507,256,40969,4357,136]

theorem envBound15634 : H12AffineFastState.Bounded env15634 := by
  intro p hp
  have h : env15634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15626_15634 : H12AffineEnvironment.transform 15 41097 env15626 = env15634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41097 env15626 == env15634) = true)

theorem identity15634 : scanCanonicalize (H12AffineFastState.compose env15634 (packedSelected [1,8,28] rootPS)) = affineNative (2^(21+1) ^^^ 396) := by decide +kernel

theorem selectedBound15634 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env15635 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,8192,4097,32768,41097,1297,13592,1024,32769,4097,396,5376,13720,8328,5376,13712,4096,1297,10639,4368,38071,256,40969,4357,136]

theorem envBound15635 : H12AffineFastState.Bounded env15635 := by
  intro p hp
  have h : env15635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15634_15635 : H12AffineEnvironment.transform 21 396 env15634 = env15635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 396 env15634 == env15635) = true)

def env15636 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,8192,4097,1280,9609,1297,13592,1024,1281,4097,396,5376,13720,8328,5376,13712,4096,1297,10639,4368,4535,256,9481,4357,136]

theorem envBound15636 : H12AffineFastState.Bounded env15636 := by
  intro p hp
  have h : env15636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15635_15636 : H12AffineEnvironment.transform 14 1280 env15635 = env15636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1280 env15635 == env15636) = true)

theorem identity15636 : scanCanonicalize (H12AffineFastState.compose env15636 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 4120) := by decide +kernel

theorem selectedBound15636 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env15637 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,4120,4097,1280,5521,1297,1280,1024,1281,4097,396,5376,1408,4240,5376,1416,4096,1297,6551,4368,4535,256,5393,4357,136]

theorem envBound15637 : H12AffineFastState.Bounded env15637 := by
  intro p hp
  have h : env15637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15636_15637 : H12AffineEnvironment.transform 12 4120 env15636 = env15637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4120 env15636 == env15637) = true)

theorem identity15637 : scanCanonicalize (H12AffineFastState.compose env15637 (packedSelected [2,7,10,15,23,32] rootPS)) = affineNative (2^(11+1) ^^^ 318) := by decide +kernel

theorem selectedBound15637 : packedSelected [2,7,10,15,23,32] rootPS < 2^1333 := by decide +kernel

def env15638 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,318,294,319,1280,1199,1297,1280,1024,1281,319,396,1086,1408,430,1086,1416,318,1297,2217,46,137,256,1071,59,136]

theorem envBound15638 : H12AffineFastState.Bounded env15638 := by
  intro p hp
  have h : env15638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15637_15638 : H12AffineEnvironment.transform 11 318 env15637 = env15638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 318 env15637 == env15638) = true)

theorem identity15638 : scanCanonicalize (H12AffineFastState.compose env15638 (packedSelected [0,1,3,7,9,11,13] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound15638 : packedSelected [0,1,3,7,9,11,13] rootPS < 2^1333 := by decide +kernel

def env15639 : List Nat := [2,4,8,16,32,16,128,256,136,1024,42,318,294,319,1280,1199,1297,1280,1024,1281,319,396,1086,1408,430,1086,1416,318,1297,131,46,137,256,1071,59,136]

theorem envBound15639 : H12AffineFastState.Bounded env15639 := by
  intro p hp
  have h : env15639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15638_15639 : H12AffineEnvironment.transform 10 42 env15638 = env15639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env15638 == env15639) = true)

theorem identity15639 : scanCanonicalize (H12AffineFastState.compose env15639 (packedSelected [1,3,8] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound15639 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env15640 : List Nat := [2,4,8,16,32,16,128,5,136,1024,42,59,35,58,1029,1199,1044,1029,1024,1028,58,137,1086,1157,171,1086,1165,59,1044,131,46,137,5,1071,59,136]

theorem envBound15640 : H12AffineFastState.Bounded env15640 := by
  intro p hp
  have h : env15640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15639_15640 : H12AffineEnvironment.transform 7 5 env15639 = env15640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env15639 == env15640) = true)

theorem identity15640 : scanCanonicalize (H12AffineFastState.compose env15640 (packedSelected [1,3,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 135) := by decide +kernel

theorem selectedBound15640 : packedSelected [1,3,5,7] rootPS < 2^1333 := by decide +kernel

def env15641 : List Nat := [2,4,8,16,32,16,128,5,136,135,42,59,35,58,130,40,147,130,135,131,58,137,185,2,171,185,10,59,147,131,46,137,5,168,59,136]

theorem envBound15641 : H12AffineFastState.Bounded env15641 := by
  intro p hp
  have h : env15641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15640_15641 : H12AffineEnvironment.transform 9 135 env15640 = env15641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 135 env15640 == env15641) = true)

theorem identity15641 : scanCanonicalize (H12AffineFastState.compose env15641 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound15641 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env15642 : List Nat := [2,4,8,16,26,16,128,5,136,135,16,1,25,0,130,18,147,130,135,131,0,137,131,2,145,131,10,1,147,131,20,137,5,146,1,136]

theorem envBound15642 : H12AffineFastState.Bounded env15642 := by
  intro p hp
  have h : env15642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15641_15642 : H12AffineEnvironment.transform 4 26 env15641 = env15642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env15641 == env15642) = true)

theorem identity15642 : scanCanonicalize (H12AffineFastState.compose env15642 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound15642 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env15643 : List Nat := [2,4,8,16,26,16,24,5,16,31,16,1,25,0,26,18,11,26,31,27,0,17,27,2,9,27,10,1,11,27,20,17,5,10,1,16]

theorem envBound15643 : H12AffineFastState.Bounded env15643 := by
  intro p hp
  have h : env15643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15642_15643 : H12AffineEnvironment.transform 6 24 env15642 = env15643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env15642 == env15643) = true)

theorem identity15643 : scanCanonicalize (H12AffineFastState.compose env15643 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound15643 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env15644 : List Nat := [2,4,2,16,16,16,18,5,16,21,16,1,19,0,16,18,1,16,21,17,0,17,17,2,3,17,0,1,1,17,20,17,5,0,1,16]

theorem envBound15644 : H12AffineFastState.Bounded env15644 := by
  intro p hp
  have h : env15644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15643_15644 : H12AffineEnvironment.transform 2 2 env15643 = env15644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env15643 == env15644) = true)

theorem identity15644 : scanCanonicalize (H12AffineFastState.compose env15644 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound15644 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15645 : List Nat := [2,4,2,0,0,0,2,5,0,5,0,1,3,0,0,2,1,0,5,1,0,1,1,2,3,1,0,1,1,1,4,1,5,0,1,0]

theorem envBound15645 : H12AffineFastState.Bounded env15645 := by
  intro p hp
  have h : env15645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15644_15645 : H12AffineEnvironment.transform 3 0 env15644 = env15645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env15644 == env15645) = true)

def env15646 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,8192,4097,1281,9608,1297,13592,1024,1280,4097,396,5376,13720,8328,5376,13712,4096,1297,10639,4368,4534,256,9480,4357,136]

theorem envBound15646 : H12AffineFastState.Bounded env15646 := by
  intro p hp
  have h : env15646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15635_15646 : H12AffineEnvironment.transform 14 1281 env15635 = env15646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1281 env15635 == env15646) = true)

theorem identity15646 : scanCanonicalize (H12AffineFastState.compose env15646 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 1037) := by decide +kernel

theorem selectedBound15646 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env15647 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,1037,4097,1281,389,1297,4373,1024,1280,4097,396,5376,4501,1157,5376,4509,4096,1297,3458,4368,4534,256,261,4357,136]

theorem envBound15647 : H12AffineFastState.Bounded env15647 := by
  intro p hp
  have h : env15647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15646_15647 : H12AffineEnvironment.transform 12 1037 env15646 = env15647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1037 env15646 == env15647) = true)

theorem identity15647 : scanCanonicalize (H12AffineFastState.compose env15647 (packedSelected [2,3,5,7,15,23,32] rootPS)) = affineNative (2^(9+1) ^^^ 298) := by decide +kernel

theorem selectedBound15647 : packedSelected [2,3,5,7,15,23,32] rootPS < 2^1333 := by decide +kernel

def env15648 : List Nat := [2,4,8,16,32,16,128,256,136,298,2048,4096,295,4097,43,389,59,4373,298,42,4097,396,4138,4501,431,4138,4509,4096,59,2216,4368,4534,256,261,4357,136]

theorem envBound15648 : H12AffineFastState.Bounded env15648 := by
  intro p hp
  have h : env15648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15647_15648 : H12AffineEnvironment.transform 9 298 env15647 = env15648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 298 env15647 == env15648) = true)

theorem identity15648 : scanCanonicalize (H12AffineFastState.compose env15648 (packedSelected [0,3,7,9,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 58) := by decide +kernel

theorem selectedBound15648 : packedSelected [0,3,7,9,11,12] rootPS < 2^1333 := by decide +kernel

def env15649 : List Nat := [2,4,8,16,32,16,128,256,136,298,2048,58,295,59,43,389,59,303,298,42,59,396,16,431,431,16,423,58,59,2216,298,396,256,261,319,136]

theorem envBound15649 : H12AffineFastState.Bounded env15649 := by
  intro p hp
  have h : env15649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15648_15649 : H12AffineEnvironment.transform 11 58 env15648 = env15649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 58 env15648 == env15649) = true)

theorem identity15649 : scanCanonicalize (H12AffineFastState.compose env15649 (packedSelected [3,5,7,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound15649 : packedSelected [3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env15650 : List Nat := [2,4,8,16,32,16,9,256,1,298,2048,58,295,59,43,268,59,303,298,42,59,261,16,294,294,16,302,58,59,2081,298,261,256,261,319,1]

theorem envBound15650 : H12AffineFastState.Bounded env15650 := by
  intro p hp
  have h : env15650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15649_15650 : H12AffineEnvironment.transform 6 9 env15649 = env15650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env15649 == env15650) = true)

theorem identity15650 : scanCanonicalize (H12AffineFastState.compose env15650 (packedSelected [7] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound15650 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env15651 : List Nat := [2,4,8,16,32,16,9,5,1,47,2048,58,34,59,43,9,59,42,47,42,59,0,16,35,35,16,43,58,59,2081,47,0,5,0,58,1]

theorem envBound15651 : H12AffineFastState.Bounded env15651 := by
  intro p hp
  have h : env15651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15650_15651 : H12AffineEnvironment.transform 7 5 env15650 = env15651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env15650 == env15651) = true)

theorem identity15651 : scanCanonicalize (H12AffineFastState.compose env15651 (packedSelected [1,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound15651 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env15652 : List Nat := [2,4,8,16,1,16,9,5,1,14,2048,27,3,26,10,9,26,11,14,11,26,0,16,2,2,16,10,27,26,2048,14,0,5,0,27,1]

theorem envBound15652 : H12AffineFastState.Bounded env15652 := by
  intro p hp
  have h : env15652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15651_15652 : H12AffineEnvironment.transform 4 1 env15651 = env15652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env15651 == env15652) = true)

theorem identity15652 : scanCanonicalize (H12AffineFastState.compose env15652 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 27) := by decide +kernel

theorem selectedBound15652 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15653 : List Nat := [2,4,8,16,1,16,9,5,1,14,27,27,3,26,10,9,26,11,14,11,26,0,16,2,2,16,10,27,26,27,14,0,5,0,27,1]

theorem envBound15653 : H12AffineFastState.Bounded env15653 := by
  intro p hp
  have h : env15653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15652_15653 : H12AffineEnvironment.transform 10 27 env15652 = env15653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 27 env15652 == env15653) = true)

theorem identity15653 : scanCanonicalize (H12AffineFastState.compose env15653 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound15653 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env15654 : List Nat := [2,4,8,0,1,0,9,5,1,14,11,11,3,10,10,9,10,11,14,11,10,0,0,2,2,0,10,11,10,11,14,0,5,0,11,1]

theorem envBound15654 : H12AffineFastState.Bounded env15654 := by
  intro p hp
  have h : env15654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15653_15654 : H12AffineEnvironment.transform 3 0 env15653 = env15654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env15653 == env15654) = true)

def env15655 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,8192,4097,32768,65536,1297,13593,1024,32769,4097,4194304,5376,16777216,8328,5376,4207645,4096,1297,100614,16876545,21012643,256,40969,16876564,136]

theorem envBound15655 : H12AffineFastState.Bounded env15655 := by
  intro p hp
  have h : env15655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15624_15655 : H12AffineEnvironment.transform 17 13593 env15624 = env15655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 13593 env15624 == env15655) = true)

theorem identity15655 : scanCanonicalize (H12AffineFastState.compose env15655 (packedSelected [3,5,24] rootPS)) = affineNative (2^(15+1) ^^^ 46236) := by decide +kernel

theorem selectedBound15655 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env15656 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,8192,4097,32768,46236,1297,13593,1024,32769,4097,4194304,5376,16777216,8328,5376,4207645,4096,1297,15770,16789661,21012643,256,40969,16789640,136]

theorem envBound15656 : H12AffineFastState.Bounded env15656 := by
  intro p hp
  have h : env15656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15655_15656 : H12AffineEnvironment.transform 15 46236 env15655 = env15656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 46236 env15655 == env15656) = true)

def env15657 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,8192,4097,32768,46236,1297,13593,1024,32769,4097,4194304,5376,13720,8328,5376,4207645,4096,1297,15770,1285,4232507,256,40969,1296,136]

theorem envBound15657 : H12AffineFastState.Bounded env15657 := by
  intro p hp
  have h : env15657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15656_15657 : H12AffineEnvironment.transform 23 13720 env15656 = env15657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 13720 env15656 == env15657) = true)

theorem identity15657 : scanCanonicalize (H12AffineFastState.compose env15657 (packedSelected [1,12,13] rootPS)) = affineNative (2^(21+1) ^^^ 2091) := by decide +kernel

theorem selectedBound15657 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env15658 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,8192,4097,32768,46236,1297,13593,1024,32769,4097,2091,5376,13720,8328,5376,15414,4096,1297,15770,1285,40208,256,40969,1296,136]

theorem envBound15658 : H12AffineFastState.Bounded env15658 := by
  intro p hp
  have h : env15658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15657_15658 : H12AffineEnvironment.transform 21 2091 env15657 = env15658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2091 env15657 == env15658) = true)

theorem identity15658 : scanCanonicalize (H12AffineFastState.compose env15658 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 2208) := by decide +kernel

theorem selectedBound15658 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env15659 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,2208,4097,32768,39996,1297,7609,1024,32769,4097,2091,5376,7480,2088,5376,5270,4096,1297,5434,1285,40208,256,34985,1296,136]

theorem envBound15659 : H12AffineFastState.Bounded env15659 := by
  intro p hp
  have h : env15659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15658_15659 : H12AffineEnvironment.transform 12 2208 env15658 = env15659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2208 env15658 == env15659) = true)

theorem identity15659 : scanCanonicalize (H12AffineFastState.compose env15659 (packedSelected [1,5,8,12,17] rootPS)) = affineNative (2^(14+1) ^^^ 130) := by decide +kernel

theorem selectedBound15659 : packedSelected [1,5,8,12,17] rootPS < 2^1333 := by decide +kernel

end H12CloudChart2