import H12CloudChart2Data067

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity16657 : scanCanonicalize (H12AffineFastState.compose env16657 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound16657 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env16658 : List Nat := [2,4,8,16,32,17,41,36,32,52,33,0,8,0,33,35,0,33,52,32,0,33,16,34,41,17,33,0,0,33,21,0,36,0,0,32]

theorem envBound16658 : H12AffineFastState.Bounded env16658 := by
  intro p hp
  have h : env16658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16657_16658 : H12AffineEnvironment.transform 15 35 env16657 = env16658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env16657 == env16658) = true)

theorem identity16658 : scanCanonicalize (H12AffineFastState.compose env16658 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound16658 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16659 : List Nat := [2,4,8,16,1,17,8,5,1,21,0,0,8,0,0,2,0,0,21,1,0,0,16,3,8,17,0,0,0,0,21,0,5,0,0,1]

theorem envBound16659 : H12AffineFastState.Bounded env16659 := by
  intro p hp
  have h : env16659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16658_16659 : H12AffineEnvironment.transform 4 1 env16658 = env16659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env16658 == env16659) = true)

def leafEnv16659 : List Nat := [2,4,8,16,1,17,8,5,1,21,0,0,8,0,0,2,0,0,21,1,0,0,16,3,21,8,1,17,0,0,0,0,21,0,5,0,4,3,0,1,0,0,1]

def active16659 : List Nat := [0,1,2,3]

def tree16659 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16659 : H12WitnessSearch.Good tree16659 := H12GlobalWitnessIndex.good

theorem leafIdentity16659 : H12AffineFastState.composeSystem env16659 rootObs = leafEnv16659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16659 rootObs == leafEnv16659) = true)

theorem terminalChecked16659 : H12PackedTerminal.terminalCheckFast leafEnv16659 active16659 tree16659 = true := by decide +kernel

def env16660 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,9,0,261,65536,0,513,272,260,0,4194304,16,65537,129,17,4195076,0,0,1073741824,21,4194440,256,65571,0,512]

theorem envBound16660 : H12AffineFastState.Bounded env16660 := by
  intro p hp
  have h : env16660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16637_16660 : H12AffineEnvironment.transform 12 9 env16637 = env16660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env16637 == env16660) = true)

theorem identity16660 : scanCanonicalize (H12AffineFastState.compose env16660 (packedSelected [6] rootPS)) = affineNative (2^(29+1) ^^^ 2081) := by decide +kernel

theorem selectedBound16660 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env16661 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,9,0,261,65536,0,513,272,260,0,4194304,16,65537,129,17,4195076,0,0,2081,21,4194440,256,65571,0,512]

theorem envBound16661 : H12AffineFastState.Bounded env16661 := by
  intro p hp
  have h : env16661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16660_16661 : H12AffineEnvironment.transform 29 2081 env16660 = env16661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 2081 env16660 == env16661) = true)

def env16662 : List Nat := [2,4,8,16,32,17,128,4,512,20,2048,0,9,0,1,65536,0,513,20,0,0,4194304,16,65537,129,17,4194816,0,0,2081,21,4194440,4,65571,0,512]

theorem envBound16662 : H12AffineFastState.Bounded env16662 := by
  intro p hp
  have h : env16662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16661_16662 : H12AffineEnvironment.transform 7 4 env16661 = env16662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env16661 == env16662) = true)

theorem identity16662 : scanCanonicalize (H12AffineFastState.compose env16662 (packedSelected [2] rootPS)) = affineNative (2^(21+1) ^^^ 66218) := by decide +kernel

theorem selectedBound16662 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16663 : List Nat := [2,4,8,16,32,17,128,4,512,20,2048,0,9,0,1,65536,0,513,20,0,0,66218,16,65537,129,17,65706,0,0,2081,21,66082,4,65571,0,512]

theorem envBound16663 : H12AffineFastState.Bounded env16663 := by
  intro p hp
  have h : env16663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16662_16663 : H12AffineEnvironment.transform 21 66218 env16662 = env16663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 66218 env16662 == env16663) = true)

theorem identity16663 : scanCanonicalize (H12AffineFastState.compose env16663 (packedSelected [0,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound16663 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env16664 : List Nat := [2,4,8,16,32,17,128,4,512,20,0,0,9,0,1,65536,0,513,20,0,0,66218,16,65537,129,17,65706,0,0,33,21,66082,4,65571,0,512]

theorem envBound16664 : H12AffineFastState.Bounded env16664 := by
  intro p hp
  have h : env16664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16663_16664 : H12AffineEnvironment.transform 10 0 env16663 = env16664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env16663 == env16664) = true)

theorem identity16664 : scanCanonicalize (H12AffineFastState.compose env16664 (packedSelected [0,7,18] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound16664 : packedSelected [0,7,18] rootPS < 2^1333 := by decide +kernel

def env16665 : List Nat := [2,4,8,16,1,17,128,4,512,20,0,0,9,0,1,65536,0,513,20,0,0,66187,16,65537,129,17,65675,0,0,0,21,66051,4,65538,0,512]

theorem envBound16665 : H12AffineFastState.Bounded env16665 := by
  intro p hp
  have h : env16665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16664_16665 : H12AffineEnvironment.transform 4 1 env16664 = env16665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env16664 == env16665) = true)

theorem identity16665 : scanCanonicalize (H12AffineFastState.compose env16665 (packedSelected [4,9] rootPS)) = affineNative (2^(15+1) ^^^ 650) := by decide +kernel

theorem selectedBound16665 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env16666 : List Nat := [2,4,8,16,1,17,128,4,512,20,0,0,9,0,1,650,0,513,20,0,0,1,16,651,129,17,513,0,0,0,21,137,4,648,0,512]

theorem envBound16666 : H12AffineFastState.Bounded env16666 := by
  intro p hp
  have h : env16666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16665_16666 : H12AffineEnvironment.transform 15 650 env16665 = env16666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 650 env16665 == env16666) = true)

theorem identity16666 : scanCanonicalize (H12AffineFastState.compose env16666 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound16666 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env16667 : List Nat := [2,4,8,16,1,17,128,4,137,20,0,0,9,0,1,3,0,136,20,0,0,1,16,2,129,17,136,0,0,0,21,137,4,1,0,137]

theorem envBound16667 : H12AffineFastState.Bounded env16667 := by
  intro p hp
  have h : env16667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16666_16667 : H12AffineEnvironment.transform 8 137 env16666 = env16667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env16666 == env16667) = true)

def env16668 : List Nat := [2,4,8,16,32,17,128,5,512,21,2048,0,9,0,0,65536,0,513,21,1,0,4194304,16,65537,129,17,4194817,0,0,2081,21,4194440,5,65571,0,512]

theorem envBound16668 : H12AffineFastState.Bounded env16668 := by
  intro p hp
  have h : env16668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16661_16668 : H12AffineEnvironment.transform 7 5 env16661 = env16668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env16661 == env16668) = true)

theorem identity16668 : scanCanonicalize (H12AffineFastState.compose env16668 (packedSelected [2] rootPS)) = affineNative (2^(21+1) ^^^ 680) := by decide +kernel

theorem selectedBound16668 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16669 : List Nat := [2,4,8,16,32,17,128,5,512,21,2048,0,9,0,0,65536,0,513,21,1,0,680,16,65537,129,17,169,0,0,2081,21,544,5,65571,0,512]

theorem envBound16669 : H12AffineFastState.Bounded env16669 := by
  intro p hp
  have h : env16669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16668_16669 : H12AffineEnvironment.transform 21 680 env16668 = env16669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 680 env16668 == env16669) = true)

theorem identity16669 : scanCanonicalize (H12AffineFastState.compose env16669 (packedSelected [0,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 168) := by decide +kernel

theorem selectedBound16669 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env16670 : List Nat := [2,4,8,16,32,17,128,5,512,21,168,0,9,0,0,65536,0,513,21,1,0,680,16,65537,129,17,169,0,0,137,21,544,5,65571,0,512]

theorem envBound16670 : H12AffineFastState.Bounded env16670 := by
  intro p hp
  have h : env16670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16669_16670 : H12AffineEnvironment.transform 10 168 env16669 = env16670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 168 env16669 == env16670) = true)

theorem identity16670 : scanCanonicalize (H12AffineFastState.compose env16670 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound16670 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env16671 : List Nat := [2,4,8,16,32,17,128,5,137,21,168,0,9,0,0,65536,0,136,21,1,0,33,16,65537,129,17,169,0,0,137,21,169,5,65571,0,137]

theorem envBound16671 : H12AffineFastState.Bounded env16671 := by
  intro p hp
  have h : env16671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16670_16671 : H12AffineEnvironment.transform 8 137 env16670 = env16671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env16670 == env16671) = true)

theorem identity16671 : scanCanonicalize (H12AffineFastState.compose env16671 (packedSelected [0,4] rootPS)) = affineNative (2^(15+1) ^^^ 138) := by decide +kernel

theorem selectedBound16671 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env16672 : List Nat := [2,4,8,16,32,17,128,5,137,21,168,0,9,0,0,138,0,136,21,1,0,33,16,139,129,17,169,0,0,137,21,169,5,169,0,137]

theorem envBound16672 : H12AffineFastState.Bounded env16672 := by
  intro p hp
  have h : env16672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16671_16672 : H12AffineEnvironment.transform 15 138 env16671 = env16672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 138 env16671 == env16672) = true)

def env16673 : List Nat := [2,4,8,16,0,17,128,5,137,21,136,0,9,0,0,138,0,136,21,1,0,1,16,139,129,17,137,0,0,137,21,137,5,137,0,137]

theorem envBound16673 : H12AffineFastState.Bounded env16673 := by
  intro p hp
  have h : env16673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16672_16673 : H12AffineEnvironment.transform 4 0 env16672 = env16673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env16672 == env16673) = true)

theorem identity16673 : scanCanonicalize (H12AffineFastState.compose env16673 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound16673 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16674 : List Nat := [2,4,8,16,0,17,8,5,1,21,0,0,9,0,0,2,0,0,21,1,0,1,16,3,9,17,1,0,0,1,21,1,5,1,0,1]

theorem envBound16674 : H12AffineFastState.Bounded env16674 := by
  intro p hp
  have h : env16674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16673_16674 : H12AffineEnvironment.transform 6 8 env16673 = env16674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env16673 == env16674) = true)

def leafEnv16674 : List Nat := [2,4,8,16,0,17,8,5,1,21,0,0,9,0,0,2,0,0,21,1,0,1,16,3,21,9,1,17,1,0,0,1,21,1,5,1,4,3,0,1,0,0,1]

def active16674 : List Nat := [0,1,2,3]

def tree16674 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16674 : H12WitnessSearch.Good tree16674 := H12GlobalWitnessIndex.good

theorem leafIdentity16674 : H12AffineFastState.composeSystem env16674 rootObs = leafEnv16674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16674 rootObs == leafEnv16674) = true)

theorem terminalChecked16674 : H12PackedTerminal.terminalCheckFast leafEnv16674 active16674 tree16674 = true := by decide +kernel

def env16675 : List Nat := [2,4,8,16,1,17,128,5,137,21,137,0,9,0,0,138,0,136,21,1,0,0,16,139,129,17,136,0,0,137,21,136,5,136,0,137]

theorem envBound16675 : H12AffineFastState.Bounded env16675 := by
  intro p hp
  have h : env16675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16672_16675 : H12AffineEnvironment.transform 4 1 env16672 = env16675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env16672 == env16675) = true)

def env16676 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,8192,1,32768,65536,1,513,273,32769,1,4194304,16,98564,8328,17,4195076,1,1,1073741824,20,4294967296,256,4299260334,1,512]

theorem envBound16676 : H12AffineFastState.Bounded env16676 := by
  intro p hp
  have h : env16676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16580_16676 : H12AffineEnvironment.transform 9 273 env16580 = env16676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env16580 == env16676) = true)

theorem identity16676 : scanCanonicalize (H12AffineFastState.compose env16676 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 1073816106) := by decide +kernel

theorem selectedBound16676 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16677 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,8192,1,32768,65536,1,513,273,32769,1,4194304,16,98564,8328,17,4195076,1,1,1073741824,20,1073816106,256,1077977988,1,512]

theorem envBound16677 : H12AffineFastState.Bounded env16677 := by
  intro p hp
  have h : env16677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16676_16677 : H12AffineEnvironment.transform 31 1073816106 env16676 = env16677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1073816106 env16676 == env16677) = true)

theorem identity16677 : scanCanonicalize (H12AffineFastState.compose env16677 (packedSelected [3] rootPS)) = affineNative (2^(29+1) ^^^ 4196613) := by decide +kernel

theorem selectedBound16677 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env16678 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,8192,1,32768,65536,1,513,273,32769,1,4194304,16,98564,8328,17,4195076,1,1,4196613,20,4270895,256,43649,1,512]

theorem envBound16678 : H12AffineFastState.Bounded env16678 := by
  intro p hp
  have h : env16678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16677_16678 : H12AffineEnvironment.transform 29 4196613 env16677 = env16678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4196613 env16677 == env16678) = true)

theorem identity16678 : scanCanonicalize (H12AffineFastState.compose env16678 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 10792) := by decide +kernel

theorem selectedBound16678 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env16679 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,8192,1,10792,65536,1,513,273,10793,1,4194304,16,76588,8328,17,4195076,1,1,4196613,20,4270895,256,169,1,512]

theorem envBound16679 : H12AffineFastState.Bounded env16679 := by
  intro p hp
  have h : env16679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16678_16679 : H12AffineEnvironment.transform 14 10792 env16678 = env16679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 10792 env16678 == env16679) = true)

def env16680 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,8192,1,10792,65536,1,513,273,10793,1,10248,16,76588,8328,17,11020,1,1,8461,20,66343,256,169,1,512]

theorem envBound16680 : H12AffineFastState.Bounded env16680 := by
  intro p hp
  have h : env16680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16679_16680 : H12AffineEnvironment.transform 21 10248 env16679 = env16680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10248 env16679 == env16680) = true)

def env16681 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,2720,1,136,65536,1,513,273,137,1,680,16,65932,2600,17,428,1,1,2989,20,66343,256,169,1,512]

theorem envBound16681 : H12AffineFastState.Bounded env16681 := by
  intro p hp
  have h : env16681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16680_16681 : H12AffineEnvironment.transform 12 2720 env16680 = env16681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2720 env16680 == env16681) = true)

theorem identity16681 : scanCanonicalize (H12AffineFastState.compose env16681 (packedSelected [0,4,7] rootPS)) = affineNative (2^(15+1) ^^^ 2050) := by decide +kernel

theorem selectedBound16681 : packedSelected [0,4,7] rootPS < 2^1333 := by decide +kernel

def env16682 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,2720,1,136,2050,1,513,273,137,1,680,16,2446,2600,17,428,1,1,2989,20,2853,256,169,1,512]

theorem envBound16682 : H12AffineFastState.Bounded env16682 := by
  intro p hp
  have h : env16682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16681_16682 : H12AffineEnvironment.transform 15 2050 env16681 = env16682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2050 env16681 == env16682) = true)

def env16683 : List Nat := [2,4,8,16,32,17,128,256,512,273,512,1,160,1,136,514,1,513,273,137,1,680,16,910,40,17,428,1,1,429,20,293,256,169,1,512]

theorem envBound16683 : H12AffineFastState.Bounded env16683 := by
  intro p hp
  have h : env16683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16682_16683 : H12AffineEnvironment.transform 10 512 env16682 = env16683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env16682 == env16683) = true)

theorem identity16683 : scanCanonicalize (H12AffineFastState.compose env16683 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 429) := by decide +kernel

theorem selectedBound16683 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env16684 : List Nat := [2,4,8,16,32,17,128,256,429,273,429,1,160,1,136,431,1,428,273,137,1,261,16,35,40,17,428,1,1,429,20,293,256,169,1,429]

theorem envBound16684 : H12AffineFastState.Bounded env16684 := by
  intro p hp
  have h : env16684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16683_16684 : H12AffineEnvironment.transform 8 429 env16683 = env16684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 429 env16683 == env16684) = true)

def env16685 : List Nat := [2,4,8,16,0,17,128,256,397,273,397,1,128,1,136,399,1,396,273,137,1,261,16,3,8,17,396,1,1,397,20,261,256,137,1,397]

theorem envBound16685 : H12AffineFastState.Bounded env16685 := by
  intro p hp
  have h : env16685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16684_16685 : H12AffineEnvironment.transform 4 0 env16684 = env16685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env16684 == env16685) = true)

theorem identity16685 : scanCanonicalize (H12AffineFastState.compose env16685 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound16685 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16686 : List Nat := [2,4,8,16,0,17,8,256,261,273,261,1,8,1,0,263,1,260,273,1,1,261,16,3,8,17,260,1,1,261,20,261,256,1,1,261]

theorem envBound16686 : H12AffineFastState.Bounded env16686 := by
  intro p hp
  have h : env16686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16685_16686 : H12AffineEnvironment.transform 6 8 env16685 = env16686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env16685 == env16686) = true)

def env16687 : List Nat := [2,4,8,16,1,17,128,256,396,273,396,1,129,1,136,398,1,397,273,137,1,261,16,2,9,17,397,1,1,396,20,260,256,136,1,396]

theorem envBound16687 : H12AffineFastState.Bounded env16687 := by
  intro p hp
  have h : env16687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16684_16687 : H12AffineEnvironment.transform 4 1 env16684 = env16687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env16684 == env16687) = true)

theorem identity16687 : scanCanonicalize (H12AffineFastState.compose env16687 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 140) := by decide +kernel

theorem selectedBound16687 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env16688 : List Nat := [2,4,8,16,1,17,128,140,0,157,0,1,129,1,136,2,1,1,157,137,1,137,16,2,9,17,1,1,1,0,20,136,140,136,1,0]

theorem envBound16688 : H12AffineFastState.Bounded env16688 := by
  intro p hp
  have h : env16688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16687_16688 : H12AffineEnvironment.transform 7 140 env16687 = env16688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 140 env16687 == env16688) = true)

def leafEnv16688 : List Nat := [2,4,8,16,1,17,128,140,0,157,0,1,129,1,136,2,1,1,157,137,1,137,16,2,20,9,1,17,1,1,1,0,20,136,140,136,4,2,1,0,0,1,1]

def active16688 : List Nat := [0,1,2,3,6]

def tree16688 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16688 : H12WitnessSearch.Good tree16688 := H12GlobalWitnessIndex.good

theorem leafIdentity16688 : H12AffineFastState.composeSystem env16688 rootObs = leafEnv16688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16688 rootObs == leafEnv16688) = true)

theorem terminalChecked16688 : H12PackedTerminal.terminalCheckFast leafEnv16688 active16688 tree16688 = true := by decide +kernel

def env16689 : List Nat := [2,4,8,16,32,17,128,256,512,273,513,1,161,1,136,515,1,513,273,137,1,680,16,911,41,17,428,1,1,428,20,292,256,169,1,512]

theorem envBound16689 : H12AffineFastState.Bounded env16689 := by
  intro p hp
  have h : env16689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16682_16689 : H12AffineEnvironment.transform 10 513 env16682 = env16689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env16682 == env16689) = true)

def env16690 : List Nat := [2,4,8,16,0,17,128,256,512,273,513,1,129,1,136,515,1,513,273,137,1,648,16,911,9,17,396,1,1,396,20,260,256,137,1,512]

theorem envBound16690 : H12AffineFastState.Bounded env16690 := by
  intro p hp
  have h : env16690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16689_16690 : H12AffineEnvironment.transform 4 0 env16689 = env16690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env16689 == env16690) = true)

theorem identity16690 : scanCanonicalize (H12AffineFastState.compose env16690 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound16690 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16691 : List Nat := [2,4,8,16,0,17,8,256,512,273,513,1,9,1,0,515,1,513,273,1,1,512,16,775,9,17,260,1,1,260,20,260,256,1,1,512]

theorem envBound16691 : H12AffineFastState.Bounded env16691 := by
  intro p hp
  have h : env16691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16690_16691 : H12AffineEnvironment.transform 6 8 env16690 = env16691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env16690 == env16691) = true)

theorem identity16691 : scanCanonicalize (H12AffineFastState.compose env16691 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound16691 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env16692 : List Nat := [2,4,8,16,0,17,8,5,512,20,513,1,9,1,0,515,1,513,20,1,1,512,16,514,9,17,1,1,1,1,20,1,5,1,1,512]

theorem envBound16692 : H12AffineFastState.Bounded env16692 := by
  intro p hp
  have h : env16692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16691_16692 : H12AffineEnvironment.transform 7 5 env16691 = env16692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env16691 == env16692) = true)

def leafEnv16692 : List Nat := [2,4,8,16,0,17,8,5,512,20,513,1,9,1,0,515,1,513,20,1,1,512,16,514,20,9,1,17,1,1,1,1,20,1,5,1,4,3,1,512,0,1,1]

def active16692 : List Nat := [0,1,2,3,8]

def tree16692 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16692 : H12WitnessSearch.Good tree16692 := H12GlobalWitnessIndex.good

theorem leafIdentity16692 : H12AffineFastState.composeSystem env16692 rootObs = leafEnv16692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16692 rootObs == leafEnv16692) = true)

theorem terminalChecked16692 : H12PackedTerminal.terminalCheckFast leafEnv16692 active16692 tree16692 = true := by decide +kernel

def env16693 : List Nat := [2,4,8,16,1,17,128,256,512,273,513,1,128,1,136,515,1,513,273,137,1,649,16,911,8,17,397,1,1,397,20,261,256,136,1,512]

theorem envBound16693 : H12AffineFastState.Bounded env16693 := by
  intro p hp
  have h : env16693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16689_16693 : H12AffineEnvironment.transform 4 1 env16689 = env16693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env16689 == env16693) = true)

def env16694 : List Nat := [2,4,8,16,1,17,128,256,0,273,1,1,128,1,136,3,1,1,273,137,1,137,16,399,8,17,397,1,1,397,20,261,256,136,1,0]

theorem envBound16694 : H12AffineFastState.Bounded env16694 := by
  intro p hp
  have h : env16694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16693_16694 : H12AffineEnvironment.transform 8 0 env16693 = env16694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env16693 == env16694) = true)

theorem identity16694 : scanCanonicalize (H12AffineFastState.compose env16694 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 140) := by decide +kernel

theorem selectedBound16694 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16695 : List Nat := [2,4,8,16,1,17,128,140,0,157,1,1,128,1,136,3,1,1,157,137,1,137,16,3,8,17,1,1,1,1,20,137,140,136,1,0]

theorem envBound16695 : H12AffineFastState.Bounded env16695 := by
  intro p hp
  have h : env16695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16694_16695 : H12AffineEnvironment.transform 7 140 env16694 = env16695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 140 env16694 == env16695) = true)

theorem identity16695 : scanCanonicalize (H12AffineFastState.compose env16695 (packedSelected [6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound16695 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env16696 : List Nat := [2,4,8,16,1,17,8,4,0,21,1,1,8,1,0,3,1,1,21,1,1,1,16,3,8,17,1,1,1,1,20,1,4,0,1,0]

theorem envBound16696 : H12AffineFastState.Bounded env16696 := by
  intro p hp
  have h : env16696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16695_16696 : H12AffineEnvironment.transform 6 8 env16695 = env16696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env16695 == env16696) = true)

def leafEnv16696 : List Nat := [2,4,8,16,1,17,8,4,0,21,1,1,8,1,0,3,1,1,21,1,1,1,16,3,20,8,1,17,1,1,1,1,20,1,4,0,4,2,1,0,0,1,1]

def active16696 : List Nat := [0,1,2,3]

def tree16696 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16696 : H12WitnessSearch.Good tree16696 := H12GlobalWitnessIndex.good

theorem leafIdentity16696 : H12AffineFastState.composeSystem env16696 rootObs = leafEnv16696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16696 rootObs == leafEnv16696) = true)

theorem terminalChecked16696 : H12PackedTerminal.terminalCheckFast leafEnv16696 active16696 tree16696 = true := by decide +kernel

def env16697 : List Nat := [2,4,8,16,1,17,128,256,1,273,0,1,128,1,136,2,1,0,273,137,1,136,16,398,8,17,397,1,1,397,20,261,256,136,1,1]

theorem envBound16697 : H12AffineFastState.Bounded env16697 := by
  intro p hp
  have h : env16697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16693_16697 : H12AffineEnvironment.transform 8 1 env16693 = env16697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env16693 == env16697) = true)

theorem identity16697 : scanCanonicalize (H12AffineFastState.compose env16697 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound16697 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16698 : List Nat := [2,4,8,16,1,17,8,256,1,273,0,1,8,1,0,2,1,0,273,1,1,0,16,262,8,17,261,1,1,261,20,261,256,0,1,1]

theorem envBound16698 : H12AffineFastState.Bounded env16698 := by
  intro p hp
  have h : env16698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16697_16698 : H12AffineEnvironment.transform 6 8 env16697 = env16698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env16697 == env16698) = true)

theorem identity16698 : scanCanonicalize (H12AffineFastState.compose env16698 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound16698 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env16699 : List Nat := [2,4,8,16,1,17,8,5,1,20,0,1,8,1,0,2,1,0,20,1,1,0,16,3,8,17,0,1,1,0,20,0,5,0,1,1]

theorem envBound16699 : H12AffineFastState.Bounded env16699 := by
  intro p hp
  have h : env16699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16698_16699 : H12AffineEnvironment.transform 7 5 env16698 = env16699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env16698 == env16699) = true)

def leafEnv16699 : List Nat := [2,4,8,16,1,17,8,5,1,20,0,1,8,1,0,2,1,0,20,1,1,0,16,3,20,8,1,17,0,1,1,0,20,0,5,0,4,3,1,1,0,1,1]

def active16699 : List Nat := [0,1,2,3]

def tree16699 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16699 : H12WitnessSearch.Good tree16699 := H12GlobalWitnessIndex.good

theorem leafIdentity16699 : H12AffineFastState.composeSystem env16699 rootObs = leafEnv16699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16699 rootObs == leafEnv16699) = true)

theorem terminalChecked16699 : H12PackedTerminal.terminalCheckFast leafEnv16699 active16699 tree16699 = true := by decide +kernel

def env16700 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,2721,1,137,65536,1,513,273,136,1,681,16,65933,2601,17,429,1,1,2988,20,66343,256,169,1,512]

theorem envBound16700 : H12AffineFastState.Bounded env16700 := by
  intro p hp
  have h : env16700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16680_16700 : H12AffineEnvironment.transform 12 2721 env16680 = env16700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2721 env16680 == env16700) = true)

theorem identity16700 : scanCanonicalize (H12AffineFastState.compose env16700 (packedSelected [0,4,7] rootPS)) = affineNative (2^(10+1) ^^^ 545) := by decide +kernel

theorem selectedBound16700 : packedSelected [0,4,7] rootPS < 2^1333 := by decide +kernel

def env16701 : List Nat := [2,4,8,16,32,17,128,256,512,273,545,1,128,1,137,65536,1,513,273,136,1,681,16,65933,8,17,429,1,1,397,20,66343,256,169,1,512]

theorem envBound16701 : H12AffineFastState.Bounded env16701 := by
  intro p hp
  have h : env16701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16700_16701 : H12AffineEnvironment.transform 10 545 env16700 = env16701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 545 env16700 == env16701) = true)

def env16702 : List Nat := [2,4,8,16,0,17,128,256,512,273,513,1,128,1,137,65536,1,513,273,136,1,649,16,65933,8,17,397,1,1,397,20,66311,256,137,1,512]

theorem envBound16702 : H12AffineFastState.Bounded env16702 := by
  intro p hp
  have h : env16702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16701_16702 : H12AffineEnvironment.transform 4 0 env16701 = env16702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env16701 == env16702) = true)

def env16703 : List Nat := [2,4,8,16,0,17,8,256,512,273,513,1,8,1,1,65536,1,513,273,0,1,513,16,65797,8,17,261,1,1,261,20,66311,256,1,1,512]

theorem envBound16703 : H12AffineFastState.Bounded env16703 := by
  intro p hp
  have h : env16703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16702_16703 : H12AffineEnvironment.transform 6 8 env16702 = env16703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env16702 == env16703) = true)

def env16704 : List Nat := [2,4,8,16,0,17,9,256,512,273,513,1,9,1,0,65536,1,513,273,1,1,512,16,65796,8,17,260,1,1,260,20,66311,256,0,1,512]

theorem envBound16704 : H12AffineFastState.Bounded env16704 := by
  intro p hp
  have h : env16704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16702_16704 : H12AffineEnvironment.transform 6 9 env16702 = env16704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env16702 == env16704) = true)

theorem identity16704 : scanCanonicalize (H12AffineFastState.compose env16704 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 515) := by decide +kernel

theorem selectedBound16704 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16705 : List Nat := [2,4,8,16,0,17,9,256,512,273,513,1,9,1,0,515,1,513,273,1,1,512,16,775,8,17,260,1,1,260,20,260,256,0,1,512]

theorem envBound16705 : H12AffineFastState.Bounded env16705 := by
  intro p hp
  have h : env16705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16704_16705 : H12AffineEnvironment.transform 15 515 env16704 = env16705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 515 env16704 == env16705) = true)

theorem identity16705 : scanCanonicalize (H12AffineFastState.compose env16705 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound16705 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env16706 : List Nat := [2,4,8,16,0,17,9,4,512,21,513,1,9,1,0,515,1,513,21,1,1,512,16,515,8,17,0,1,1,0,20,0,4,0,1,512]

theorem envBound16706 : H12AffineFastState.Bounded env16706 := by
  intro p hp
  have h : env16706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16705_16706 : H12AffineEnvironment.transform 7 4 env16705 = env16706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env16705 == env16706) = true)

theorem identity16706 : scanCanonicalize (H12AffineFastState.compose env16706 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound16706 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16707 : List Nat := [2,4,8,16,0,17,9,4,1,21,0,1,9,1,0,2,1,0,21,1,1,1,16,2,8,17,0,1,1,0,20,0,4,0,1,1]

theorem envBound16707 : H12AffineFastState.Bounded env16707 := by
  intro p hp
  have h : env16707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16706_16707 : H12AffineEnvironment.transform 8 1 env16706 = env16707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env16706 == env16707) = true)

def leafEnv16707 : List Nat := [2,4,8,16,0,17,9,4,1,21,0,1,9,1,0,2,1,0,21,1,1,1,16,2,20,8,1,17,0,1,1,0,20,0,4,0,4,2,1,1,0,1,1]

def active16707 : List Nat := [0,1,2,3]

def tree16707 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16707 : H12WitnessSearch.Good tree16707 := H12GlobalWitnessIndex.good

theorem leafIdentity16707 : H12AffineFastState.composeSystem env16707 rootObs = leafEnv16707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16707 rootObs == leafEnv16707) = true)

theorem terminalChecked16707 : H12PackedTerminal.terminalCheckFast leafEnv16707 active16707 tree16707 = true := by decide +kernel

def env16708 : List Nat := [2,4,8,16,1,17,128,256,512,273,512,1,128,1,137,65536,1,513,273,136,1,648,16,65933,8,17,396,1,1,397,20,66310,256,136,1,512]

theorem envBound16708 : H12AffineFastState.Bounded env16708 := by
  intro p hp
  have h : env16708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16701_16708 : H12AffineEnvironment.transform 4 1 env16701 = env16708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env16701 == env16708) = true)

theorem identity16708 : scanCanonicalize (H12AffineFastState.compose env16708 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 397) := by decide +kernel

theorem selectedBound16708 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env16709 : List Nat := [2,4,8,16,1,17,128,256,397,273,397,1,128,1,137,65536,1,396,273,136,1,261,16,65933,8,17,396,1,1,397,20,65675,256,136,1,397]

theorem envBound16709 : H12AffineFastState.Bounded env16709 := by
  intro p hp
  have h : env16709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16708_16709 : H12AffineEnvironment.transform 8 397 env16708 = env16709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 397 env16708 == env16709) = true)

def env16710 : List Nat := [2,4,8,16,1,17,8,256,261,273,261,1,8,1,1,65536,1,260,273,0,1,261,16,65797,8,17,260,1,1,261,20,65539,256,0,1,261]

theorem envBound16710 : H12AffineFastState.Bounded env16710 := by
  intro p hp
  have h : env16710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16709_16710 : H12AffineEnvironment.transform 6 8 env16709 = env16710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env16709 == env16710) = true)

def env16711 : List Nat := [2,4,8,16,1,17,9,256,260,273,260,1,9,1,0,65536,1,261,273,1,1,261,16,65796,8,17,261,1,1,260,20,65538,256,1,1,260]

theorem envBound16711 : H12AffineFastState.Bounded env16711 := by
  intro p hp
  have h : env16711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16709_16711 : H12AffineEnvironment.transform 6 9 env16709 = env16711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env16709 == env16711) = true)

theorem identity16711 : scanCanonicalize (H12AffineFastState.compose env16711 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound16711 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16712 : List Nat := [2,4,8,16,1,17,9,256,260,273,260,1,9,1,0,263,1,261,273,1,1,261,16,3,8,17,261,1,1,260,20,261,256,1,1,260]

theorem envBound16712 : H12AffineFastState.Bounded env16712 := by
  intro p hp
  have h : env16712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16711_16712 : H12AffineEnvironment.transform 15 263 env16711 = env16712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env16711 == env16712) = true)

theorem identity16712 : scanCanonicalize (H12AffineFastState.compose env16712 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound16712 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16713 : List Nat := [2,4,8,16,1,17,9,4,0,21,0,1,9,1,0,3,1,1,21,1,1,1,16,3,8,17,1,1,1,0,20,1,4,1,1,0]

theorem envBound16713 : H12AffineFastState.Bounded env16713 := by
  intro p hp
  have h : env16713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16712_16713 : H12AffineEnvironment.transform 7 4 env16712 = env16713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env16712 == env16713) = true)

def env16714 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,8192,1,10792,65536,1,513,273,10793,1,10249,16,76588,8328,17,11021,1,1,8460,20,66342,256,169,1,512]

theorem envBound16714 : H12AffineFastState.Bounded env16714 := by
  intro p hp
  have h : env16714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16679_16714 : H12AffineEnvironment.transform 21 10249 env16679 = env16714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10249 env16679 == env16714) = true)

theorem identity16714 : scanCanonicalize (H12AffineFastState.compose env16714 (packedSelected [11] rootPS)) = affineNative (2^(12+1) ^^^ 780) := by decide +kernel

theorem selectedBound16714 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env16715 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,780,1,2340,65536,1,513,273,2341,1,2821,16,67616,900,17,2049,1,1,512,20,66342,256,169,1,512]

theorem envBound16715 : H12AffineFastState.Bounded env16715 := by
  intro p hp
  have h : env16715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16714_16715 : H12AffineEnvironment.transform 12 780 env16714 = env16715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 780 env16714 == env16715) = true)

def env16716 : List Nat := [2,4,8,16,32,17,128,256,512,273,428,1,780,1,136,65536,1,513,273,137,1,681,16,65932,900,17,429,1,1,512,20,66342,256,169,1,512]

theorem envBound16716 : H12AffineFastState.Bounded env16716 := by
  intro p hp
  have h : env16716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16715_16716 : H12AffineEnvironment.transform 10 428 env16715 = env16716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 428 env16715 == env16716) = true)

theorem identity16716 : scanCanonicalize (H12AffineFastState.compose env16716 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound16716 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env16717 : List Nat := [2,4,8,16,0,17,128,256,512,273,396,1,780,1,136,65536,1,513,273,137,1,649,16,65932,900,17,397,1,1,512,20,66310,256,137,1,512]

theorem envBound16717 : H12AffineFastState.Bounded env16717 := by
  intro p hp
  have h : env16717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16716_16717 : H12AffineEnvironment.transform 4 0 env16716 = env16717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env16716 == env16717) = true)

def env16718 : List Nat := [2,4,8,16,0,17,8,256,512,273,260,1,780,1,0,65536,1,513,273,1,1,513,16,65796,780,17,261,1,1,512,20,66310,256,1,1,512]

theorem envBound16718 : H12AffineFastState.Bounded env16718 := by
  intro p hp
  have h : env16718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16717_16718 : H12AffineEnvironment.transform 6 8 env16717 = env16718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env16717 == env16718) = true)

theorem identity16718 : scanCanonicalize (H12AffineFastState.compose env16718 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound16718 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16719 : List Nat := [2,4,8,16,0,17,8,256,512,273,260,1,780,1,0,262,1,513,273,1,1,513,16,2,780,17,261,1,1,512,20,512,256,1,1,512]

theorem envBound16719 : H12AffineFastState.Bounded env16719 := by
  intro p hp
  have h : env16719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16718_16719 : H12AffineEnvironment.transform 15 262 env16718 = env16719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env16718 == env16719) = true)

theorem identity16719 : scanCanonicalize (H12AffineFastState.compose env16719 (packedSelected [2,6] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound16719 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env16720 : List Nat := [2,4,8,16,0,17,8,256,0,273,260,1,268,1,0,262,1,1,273,1,1,1,16,2,268,17,261,1,1,0,20,0,256,1,1,0]

theorem envBound16720 : H12AffineFastState.Bounded env16720 := by
  intro p hp
  have h : env16720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16719_16720 : H12AffineEnvironment.transform 8 0 env16719 = env16720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env16719 == env16720) = true)

def env16721 : List Nat := [2,4,8,16,0,17,9,256,512,273,261,1,780,1,1,65536,1,513,273,0,1,512,16,65797,781,17,260,1,1,512,20,66310,256,0,1,512]

theorem envBound16721 : H12AffineFastState.Bounded env16721 := by
  intro p hp
  have h : env16721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16717_16721 : H12AffineEnvironment.transform 6 9 env16717 = env16721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env16717 == env16721) = true)

def env16722 : List Nat := [2,4,8,16,32,17,128,256,512,273,429,1,780,1,137,65536,1,513,273,136,1,680,16,65933,900,17,428,1,1,512,20,66342,256,169,1,512]

theorem envBound16722 : H12AffineFastState.Bounded env16722 := by
  intro p hp
  have h : env16722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16715_16722 : H12AffineEnvironment.transform 10 429 env16715 = env16722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 429 env16715 == env16722) = true)

theorem identity16722 : scanCanonicalize (H12AffineFastState.compose env16722 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 514) := by decide +kernel

theorem selectedBound16722 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env16723 : List Nat := [2,4,8,16,32,17,128,256,512,273,429,1,780,1,137,514,1,513,273,136,1,680,16,911,900,17,428,1,1,512,20,292,256,169,1,512]

theorem envBound16723 : H12AffineFastState.Bounded env16723 := by
  intro p hp
  have h : env16723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16722_16723 : H12AffineEnvironment.transform 15 514 env16722 = env16723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 514 env16722 == env16723) = true)

def env16724 : List Nat := [2,4,8,16,32,17,8,256,512,273,293,1,780,1,1,514,1,513,273,0,1,544,16,775,780,17,292,1,1,512,20,292,256,33,1,512]

theorem envBound16724 : H12AffineFastState.Bounded env16724 := by
  intro p hp
  have h : env16724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16723_16724 : H12AffineEnvironment.transform 6 8 env16723 = env16724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env16723 == env16724) = true)

theorem identity16724 : scanCanonicalize (H12AffineFastState.compose env16724 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound16724 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16725 : List Nat := [2,4,8,16,32,17,8,256,260,273,293,1,8,1,1,262,1,261,273,0,1,292,16,3,8,17,292,1,1,260,20,292,256,33,1,260]

theorem envBound16725 : H12AffineFastState.Bounded env16725 := by
  intro p hp
  have h : env16725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16724_16725 : H12AffineEnvironment.transform 8 260 env16724 = env16725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env16724 == env16725) = true)

def env16726 : List Nat := [2,4,8,16,0,17,8,256,260,273,261,1,8,1,1,262,1,261,273,0,1,260,16,3,8,17,260,1,1,260,20,260,256,1,1,260]

theorem envBound16726 : H12AffineFastState.Bounded env16726 := by
  intro p hp
  have h : env16726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16725_16726 : H12AffineEnvironment.transform 4 0 env16725 = env16726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env16725 == env16726) = true)

theorem identity16726 : scanCanonicalize (H12AffineFastState.compose env16726 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound16726 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16727 : List Nat := [2,4,8,16,0,17,8,5,1,20,0,1,8,1,1,3,1,0,20,0,1,1,16,3,8,17,1,1,1,1,20,1,5,1,1,1]

theorem envBound16727 : H12AffineFastState.Bounded env16727 := by
  intro p hp
  have h : env16727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16726_16727 : H12AffineEnvironment.transform 7 5 env16726 = env16727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env16726 == env16727) = true)

def leafEnv16727 : List Nat := [2,4,8,16,0,17,8,5,1,20,0,1,8,1,1,3,1,0,20,0,1,1,16,3,20,8,1,17,1,1,1,1,20,1,5,1,4,2,1,1,0,1,1]

def active16727 : List Nat := [0,1,2,3]

def tree16727 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16727 : H12WitnessSearch.Good tree16727 := H12GlobalWitnessIndex.good

theorem leafIdentity16727 : H12AffineFastState.composeSystem env16727 rootObs = leafEnv16727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16727 rootObs == leafEnv16727) = true)

theorem terminalChecked16727 : H12PackedTerminal.terminalCheckFast leafEnv16727 active16727 tree16727 = true := by decide +kernel

def env16728 : List Nat := [2,4,8,16,1,17,8,256,260,273,260,1,8,1,1,262,1,261,273,0,1,261,16,3,8,17,261,1,1,260,20,261,256,0,1,260]

theorem envBound16728 : H12AffineFastState.Bounded env16728 := by
  intro p hp
  have h : env16728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16725_16728 : H12AffineEnvironment.transform 4 1 env16725 = env16728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env16725 == env16728) = true)

def leafEnv16728 : List Nat := [2,4,8,16,1,17,8,256,260,273,260,1,8,1,1,262,1,261,273,0,1,261,16,3,20,8,1,17,261,1,1,260,20,261,256,0,4,263,1,260,0,1,1]

def active16728 : List Nat := [0,1,2,3,7]

def tree16728 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16728 : H12WitnessSearch.Good tree16728 := H12GlobalWitnessIndex.good

theorem leafIdentity16728 : H12AffineFastState.composeSystem env16728 rootObs = leafEnv16728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16728 rootObs == leafEnv16728) = true)

theorem terminalChecked16728 : H12PackedTerminal.terminalCheckFast leafEnv16728 active16728 tree16728 = true := by decide +kernel

def env16729 : List Nat := [2,4,8,16,32,17,9,256,512,273,292,1,780,1,0,514,1,513,273,1,1,545,16,774,781,17,293,1,1,512,20,292,256,32,1,512]

theorem envBound16729 : H12AffineFastState.Bounded env16729 := by
  intro p hp
  have h : env16729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16723_16729 : H12AffineEnvironment.transform 6 9 env16723 = env16729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env16723 == env16729) = true)

def env16730 : List Nat := [2,4,8,16,32,17,9,256,0,273,292,1,268,1,0,2,1,1,273,1,1,33,16,262,269,17,293,1,1,0,20,292,256,32,1,0]

theorem envBound16730 : H12AffineFastState.Bounded env16730 := by
  intro p hp
  have h : env16730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16729_16730 : H12AffineEnvironment.transform 8 0 env16729 = env16730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env16729 == env16730) = true)

theorem identity16730 : scanCanonicalize (H12AffineFastState.compose env16730 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound16730 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16731 : List Nat := [2,4,8,16,32,17,9,5,0,20,33,1,9,1,0,2,1,1,20,1,1,33,16,3,8,17,32,1,1,0,20,33,5,32,1,0]

theorem envBound16731 : H12AffineFastState.Bounded env16731 := by
  intro p hp
  have h : env16731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16730_16731 : H12AffineEnvironment.transform 7 5 env16730 = env16731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env16730 == env16731) = true)

def env16732 : List Nat := [2,4,8,16,32,17,9,256,1,273,292,1,269,1,0,3,1,0,273,1,1,32,16,263,268,17,293,1,1,1,20,292,256,32,1,1]

theorem envBound16732 : H12AffineFastState.Bounded env16732 := by
  intro p hp
  have h : env16732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16729_16732 : H12AffineEnvironment.transform 8 1 env16729 = env16732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env16729 == env16732) = true)

theorem identity16732 : scanCanonicalize (H12AffineFastState.compose env16732 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound16732 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16733 : List Nat := [2,4,8,16,0,17,9,256,1,273,260,1,269,1,0,3,1,0,273,1,1,0,16,263,268,17,261,1,1,1,20,260,256,0,1,1]

theorem envBound16733 : H12AffineFastState.Bounded env16733 := by
  intro p hp
  have h : env16733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16732_16733 : H12AffineEnvironment.transform 4 0 env16732 = env16733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env16732 == env16733) = true)

def leafEnv16733 : List Nat := [2,4,8,16,0,17,9,256,1,273,260,1,269,1,0,3,1,0,273,1,1,0,16,263,20,268,1,17,261,1,1,1,20,260,256,0,4,262,1,1,0,1,1]

def active16733 : List Nat := [0,1,2,3,7]

def tree16733 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16733 : H12WitnessSearch.Good tree16733 := H12GlobalWitnessIndex.good

theorem leafIdentity16733 : H12AffineFastState.composeSystem env16733 rootObs = leafEnv16733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16733 rootObs == leafEnv16733) = true)

theorem terminalChecked16733 : H12PackedTerminal.terminalCheckFast leafEnv16733 active16733 tree16733 = true := by decide +kernel

def env16734 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,65536,1345,513,1025,32769,1345,4194304,17,98564,8328,64,4195077,1297,1296,1073741824,1285,4294967296,256,4299260334,1345,512]

theorem envBound16734 : H12AffineFastState.Bounded env16734 := by
  intro p hp
  have h : env16734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16565_16734 : H12AffineEnvironment.transform 13 1297 env16565 = env16734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env16565 == env16734) = true)

theorem identity16734 : scanCanonicalize (H12AffineFastState.compose env16734 (packedSelected [3,5,10] rootPS)) = affineNative (2^(29+1) ^^^ 4270862) := by decide +kernel

theorem selectedBound16734 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env16735 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,65536,1345,513,1025,32769,1345,4194304,17,98564,8328,64,4195077,1297,1296,4270862,1285,4294967296,256,4299260334,1345,512]

theorem envBound16735 : H12AffineFastState.Bounded env16735 := by
  intro p hp
  have h : env16735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16734_16735 : H12AffineEnvironment.transform 29 4270862 env16734 = env16735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4270862 env16734 == env16735) = true)

theorem identity16735 : scanCanonicalize (H12AffineFastState.compose env16735 (packedSelected [1,12,13] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound16735 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env16736 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,8192,1297,32768,65536,1345,136,1025,32769,1345,4194304,17,98564,8328,64,4194700,1297,1296,4270471,1285,4294967296,256,4299260334,1345,137]

theorem envBound16736 : H12AffineFastState.Bounded env16736 := by
  intro p hp
  have h : env16736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16735_16736 : H12AffineEnvironment.transform 8 137 env16735 = env16736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env16735 == env16736) = true)

theorem identity16736 : scanCanonicalize (H12AffineFastState.compose env16736 (packedSelected [1,8,19] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound16736 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env16737 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,8192,1297,8460,65536,1345,136,1025,8461,1345,4194304,17,73736,8328,64,4194700,1297,1296,4270471,1285,4294967296,256,4299235490,1345,137]

theorem envBound16737 : H12AffineFastState.Bounded env16737 := by
  intro p hp
  have h : env16737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16736_16737 : H12AffineEnvironment.transform 14 8460 env16736 = env16737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env16736 == env16737) = true)

theorem identity16737 : scanCanonicalize (H12AffineFastState.compose env16737 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 74031) := by decide +kernel

theorem selectedBound16737 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env16738 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,8192,1297,8460,65536,1345,136,1025,8461,1345,4194304,17,73736,8328,64,4194700,1297,1296,4270471,1285,74031,256,4194701,1345,137]

theorem envBound16738 : H12AffineFastState.Bounded env16738 := by
  intro p hp
  have h : env16738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16737_16738 : H12AffineEnvironment.transform 31 74031 env16737 = env16738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 74031 env16737 == env16738) = true)

def env16739 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,8192,1297,8460,65536,1345,136,1025,8461,1345,8320,17,73736,8328,64,8460,1297,1296,67847,1285,74031,256,8461,1345,137]

theorem envBound16739 : H12AffineFastState.Bounded env16739 := by
  intro p hp
  have h : env16739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16738_16739 : H12AffineEnvironment.transform 21 8320 env16738 = env16739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8320 env16738 == env16739) = true)

theorem identity16739 : scanCanonicalize (H12AffineFastState.compose env16739 (packedSelected [7] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound16739 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env16740 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,388,1297,136,65536,1345,136,1025,137,1345,260,17,65932,268,64,136,1297,1296,67847,1285,65707,256,137,1345,137]

theorem envBound16740 : H12AffineFastState.Bounded env16740 := by
  intro p hp
  have h : env16740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16739_16740 : H12AffineEnvironment.transform 12 388 env16739 = env16740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env16739 == env16740) = true)

def env16741 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,1345,388,1297,136,65536,1345,136,1025,137,1345,260,17,65932,268,64,136,1297,1296,65799,1285,65707,256,137,1345,137]

theorem envBound16741 : H12AffineFastState.Bounded env16741 := by
  intro p hp
  have h : env16741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16740_16741 : H12AffineEnvironment.transform 10 0 env16740 = env16741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env16740 == env16741) = true)

theorem identity16741 : scanCanonicalize (H12AffineFastState.compose env16741 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 171) := by decide +kernel

theorem selectedBound16741 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16742 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,1345,388,1297,136,171,1345,136,1025,137,1345,260,17,295,268,64,136,1297,1296,428,1285,0,256,137,1345,137]

theorem envBound16742 : H12AffineFastState.Bounded env16742 := by
  intro p hp
  have h : env16742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16741_16742 : H12AffineEnvironment.transform 15 171 env16741 = env16742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 171 env16741 == env16742) = true)

theorem identity16742 : scanCanonicalize (H12AffineFastState.compose env16742 (packedSelected [1,3,8] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound16742 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env16743 : List Nat := [2,4,8,16,32,64,128,172,137,1024,0,1261,40,1213,136,171,1261,136,1025,137,1261,168,17,139,160,64,136,1213,1212,0,1193,0,172,137,1261,137]

theorem envBound16743 : H12AffineFastState.Bounded env16743 := by
  intro p hp
  have h : env16743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16742_16743 : H12AffineEnvironment.transform 7 172 env16742 = env16743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env16742 == env16743) = true)

def env16744 : List Nat := [2,4,8,16,32,16,128,172,137,1024,0,1213,40,1213,136,171,1213,136,1025,137,1213,168,17,139,160,16,136,1213,1212,0,1193,0,172,137,1213,137]

theorem envBound16744 : H12AffineFastState.Bounded env16744 := by
  intro p hp
  have h : env16744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16743_16744 : H12AffineEnvironment.transform 5 16 env16743 = env16744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env16743 == env16744) = true)

theorem identity16744 : scanCanonicalize (H12AffineFastState.compose env16744 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound16744 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16745 : List Nat := [2,4,8,16,32,16,3,47,10,1024,0,1086,40,1086,11,40,1086,11,1025,10,1086,43,17,8,35,16,11,1086,1087,0,1066,0,47,10,1086,10]

theorem envBound16745 : H12AffineFastState.Bounded env16745 := by
  intro p hp
  have h : env16745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16744_16745 : H12AffineEnvironment.transform 6 3 env16744 = env16745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env16744 == env16745) = true)

def env16746 : List Nat := [2,4,8,16,0,16,3,15,10,1024,0,1054,8,1054,11,8,1054,11,1025,10,1054,11,17,8,3,16,11,1054,1055,0,1034,0,15,10,1054,10]

theorem envBound16746 : H12AffineFastState.Bounded env16746 := by
  intro p hp
  have h : env16746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16745_16746 : H12AffineEnvironment.transform 4 0 env16745 = env16746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env16745 == env16746) = true)

theorem identity16746 : scanCanonicalize (H12AffineFastState.compose env16746 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound16746 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16747 : List Nat := [2,4,8,0,0,0,3,15,10,1024,0,1038,8,1038,11,8,1038,11,1025,10,1038,11,1,8,3,0,11,1038,1039,0,1034,0,15,10,1038,10]

theorem envBound16747 : H12AffineFastState.Bounded env16747 := by
  intro p hp
  have h : env16747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16746_16747 : H12AffineEnvironment.transform 3 0 env16746 = env16747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env16746 == env16747) = true)

def leafEnv16747 : List Nat := [2,4,8,0,0,0,3,15,10,1024,0,1038,8,1038,11,8,1038,11,1025,10,1038,11,1,8,1035,3,1,0,11,1038,1039,0,1034,0,15,10,4,2,1038,10,0,1039,1]

def active16747 : List Nat := [0,1,2,9]

def tree16747 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16747 : H12WitnessSearch.Good tree16747 := H12GlobalWitnessIndex.good

theorem leafIdentity16747 : H12AffineFastState.composeSystem env16747 rootObs = leafEnv16747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16747 rootObs == leafEnv16747) = true)

theorem terminalChecked16747 : H12PackedTerminal.terminalCheckFast leafEnv16747 active16747 tree16747 = true := by decide +kernel

def env16748 : List Nat := [2,4,8,16,1,16,3,14,10,1024,0,1055,9,1055,11,9,1055,11,1025,10,1055,10,17,8,2,16,11,1055,1054,0,1035,0,14,10,1055,10]

theorem envBound16748 : H12AffineFastState.Bounded env16748 := by
  intro p hp
  have h : env16748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16745_16748 : H12AffineEnvironment.transform 4 1 env16745 = env16748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env16745 == env16748) = true)

theorem identity16748 : scanCanonicalize (H12AffineFastState.compose env16748 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound16748 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16749 : List Nat := [2,4,8,11,1,11,3,14,10,1024,0,1028,9,1028,11,9,1028,11,1025,10,1028,10,10,8,2,11,11,1028,1029,0,1035,0,14,10,1028,10]

theorem envBound16749 : H12AffineFastState.Bounded env16749 := by
  intro p hp
  have h : env16749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16748_16749 : H12AffineEnvironment.transform 3 11 env16748 = env16749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env16748 == env16749) = true)

def leafEnv16749 : List Nat := [2,4,8,11,1,11,3,14,10,1024,0,1028,9,1028,11,9,1028,11,1025,10,1028,10,10,8,1034,2,1,11,11,1028,1029,0,1035,0,14,10,4,3,1028,10,0,1029,1]

def active16749 : List Nat := [0,1,2,9]

def tree16749 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16749 : H12WitnessSearch.Good tree16749 := H12GlobalWitnessIndex.good

theorem leafIdentity16749 : H12AffineFastState.composeSystem env16749 rootObs = leafEnv16749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16749 rootObs == leafEnv16749) = true)

theorem terminalChecked16749 : H12PackedTerminal.terminalCheckFast leafEnv16749 active16749 tree16749 = true := by decide +kernel

def env16750 : List Nat := [2,4,8,16,32,17,128,172,137,1024,0,1212,40,1213,136,171,1212,136,1025,137,1212,168,17,139,160,17,136,1213,1212,0,1193,0,172,137,1212,137]

theorem envBound16750 : H12AffineFastState.Bounded env16750 := by
  intro p hp
  have h : env16750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16743_16750 : H12AffineEnvironment.transform 5 17 env16743 = env16750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env16743 == env16750) = true)

theorem identity16750 : scanCanonicalize (H12AffineFastState.compose env16750 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound16750 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16751 : List Nat := [2,4,3,16,32,17,128,167,130,1024,0,1207,35,1206,131,160,1207,131,1025,130,1207,163,17,128,160,17,131,1206,1207,0,1186,0,167,130,1207,130]

theorem envBound16751 : H12AffineFastState.Bounded env16751 := by
  intro p hp
  have h : env16751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16750_16751 : H12AffineEnvironment.transform 2 3 env16750 = env16751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env16750 == env16751) = true)

def env16752 : List Nat := [2,4,3,16,0,17,128,135,130,1024,0,1175,3,1174,131,128,1175,131,1025,130,1175,131,17,128,128,17,131,1174,1175,0,1154,0,135,130,1175,130]

theorem envBound16752 : H12AffineFastState.Bounded env16752 := by
  intro p hp
  have h : env16752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16751_16752 : H12AffineEnvironment.transform 4 0 env16751 = env16752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env16751 == env16752) = true)

theorem identity16752 : scanCanonicalize (H12AffineFastState.compose env16752 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound16752 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16753 : List Nat := [2,4,3,1,0,0,128,135,130,1024,0,1158,3,1159,131,128,1158,131,1025,130,1158,131,0,128,128,0,131,1159,1158,0,1154,0,135,130,1158,130]

theorem envBound16753 : H12AffineFastState.Bounded env16753 := by
  intro p hp
  have h : env16753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16752_16753 : H12AffineEnvironment.transform 3 1 env16752 = env16753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env16752 == env16753) = true)

def leafEnv16753 : List Nat := [2,4,3,1,0,0,128,135,130,1024,0,1158,3,1159,131,128,1158,131,1025,130,1158,131,0,128,1155,128,1,0,131,1159,1158,0,1154,0,135,130,4,2,1158,130,0,1158,1]

def active16753 : List Nat := [0,1,6,9]

def tree16753 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16753 : H12WitnessSearch.Good tree16753 := H12GlobalWitnessIndex.good

theorem leafIdentity16753 : H12AffineFastState.composeSystem env16753 rootObs = leafEnv16753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16753 rootObs == leafEnv16753) = true)

theorem terminalChecked16753 : H12PackedTerminal.terminalCheckFast leafEnv16753 active16753 tree16753 = true := by decide +kernel

def env16754 : List Nat := [2,4,3,16,1,17,128,134,130,1024,0,1174,2,1175,131,129,1174,131,1025,130,1174,130,17,128,129,17,131,1175,1174,0,1155,0,134,130,1174,130]

theorem envBound16754 : H12AffineFastState.Bounded env16754 := by
  intro p hp
  have h : env16754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16751_16754 : H12AffineEnvironment.transform 4 1 env16751 = env16754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env16751 == env16754) = true)

theorem identity16754 : scanCanonicalize (H12AffineFastState.compose env16754 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound16754 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16755 : List Nat := [2,4,3,16,1,17,18,20,16,1024,0,1028,2,1029,17,19,1028,17,1025,16,1028,16,17,18,19,17,17,1029,1028,0,1041,0,20,16,1028,16]

theorem envBound16755 : H12AffineFastState.Bounded env16755 := by
  intro p hp
  have h : env16755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16754_16755 : H12AffineEnvironment.transform 6 18 env16754 = env16755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env16754 == env16755) = true)

def leafEnv16755 : List Nat := [2,4,3,16,1,17,18,20,16,1024,0,1028,2,1029,17,19,1028,17,1025,16,1028,16,17,18,1040,19,1,17,17,1029,1028,0,1041,0,20,16,4,3,1028,16,0,1028,1]

def active16755 : List Nat := [0,1,3,9]

def tree16755 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16755 : H12WitnessSearch.Good tree16755 := H12GlobalWitnessIndex.good

theorem leafIdentity16755 : H12AffineFastState.composeSystem env16755 rootObs = leafEnv16755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16755 rootObs == leafEnv16755) = true)

theorem terminalChecked16755 : H12PackedTerminal.terminalCheckFast leafEnv16755 active16755 tree16755 = true := by decide +kernel

def env16756 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,1345,388,1297,136,65536,1345,136,1025,137,1345,260,17,65932,268,64,136,1297,1296,65798,1285,65707,256,137,1345,137]

theorem envBound16756 : H12AffineFastState.Bounded env16756 := by
  intro p hp
  have h : env16756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16740_16756 : H12AffineEnvironment.transform 10 1 env16740 = env16756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env16740 == env16756) = true)

theorem identity16756 : scanCanonicalize (H12AffineFastState.compose env16756 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound16756 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16757 : List Nat := [2,4,8,16,32,64,128,173,137,1024,1,1260,41,1212,136,65536,1260,136,1025,137,1260,169,17,65569,161,64,136,1212,1213,65707,1192,65707,173,137,1260,137]

theorem envBound16757 : H12AffineFastState.Bounded env16757 := by
  intro p hp
  have h : env16757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16756_16757 : H12AffineEnvironment.transform 7 173 env16756 = env16757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env16756 == env16757) = true)

theorem identity16757 : scanCanonicalize (H12AffineFastState.compose env16757 (packedSelected [1,3,5] rootPS)) = affineNative (2^(15+1) ^^^ 170) := by decide +kernel

theorem selectedBound16757 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env16758 : List Nat := [2,4,8,16,32,64,128,173,137,1024,1,1260,41,1212,136,170,1260,136,1025,137,1260,169,17,139,161,64,136,1212,1213,1,1192,1,173,137,1260,137]

theorem envBound16758 : H12AffineFastState.Bounded env16758 := by
  intro p hp
  have h : env16758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16757_16758 : H12AffineEnvironment.transform 15 170 env16757 = env16758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 170 env16757 == env16758) = true)

def env16759 : List Nat := [2,4,8,16,32,16,128,173,137,1024,1,1212,41,1212,136,170,1212,136,1025,137,1212,169,17,139,161,16,136,1212,1213,1,1192,1,173,137,1212,137]

theorem envBound16759 : H12AffineFastState.Bounded env16759 := by
  intro p hp
  have h : env16759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16758_16759 : H12AffineEnvironment.transform 5 16 env16758 = env16759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env16758 == env16759) = true)

theorem identity16759 : scanCanonicalize (H12AffineFastState.compose env16759 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound16759 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16760 : List Nat := [2,4,8,16,32,16,2,47,11,1024,1,1086,41,1086,10,40,1086,10,1025,11,1086,43,17,9,35,16,10,1086,1087,1,1066,1,47,11,1086,11]

theorem envBound16760 : H12AffineFastState.Bounded env16760 := by
  intro p hp
  have h : env16760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16759_16760 : H12AffineEnvironment.transform 6 2 env16759 = env16760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env16759 == env16760) = true)

def env16761 : List Nat := [2,4,8,16,0,16,2,15,11,1024,1,1054,9,1054,10,8,1054,10,1025,11,1054,11,17,9,3,16,10,1054,1055,1,1034,1,15,11,1054,11]

theorem envBound16761 : H12AffineFastState.Bounded env16761 := by
  intro p hp
  have h : env16761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16760_16761 : H12AffineEnvironment.transform 4 0 env16760 = env16761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env16760 == env16761) = true)

theorem identity16761 : scanCanonicalize (H12AffineFastState.compose env16761 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound16761 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16762 : List Nat := [2,4,8,10,0,10,2,15,11,1024,1,1028,9,1028,10,8,1028,10,1025,11,1028,11,11,9,3,10,10,1028,1029,1,1034,1,15,11,1028,11]

theorem envBound16762 : H12AffineFastState.Bounded env16762 := by
  intro p hp
  have h : env16762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16761_16762 : H12AffineEnvironment.transform 3 10 env16761 = env16762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env16761 == env16762) = true)

def leafEnv16762 : List Nat := [2,4,8,10,0,10,2,15,11,1024,1,1028,9,1028,10,8,1028,10,1025,11,1028,11,11,9,1035,3,1,10,10,1028,1029,1,1034,1,15,11,4,3,1028,11,0,1029,1]

def active16762 : List Nat := [0,1,2,9]

def tree16762 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16762 : H12WitnessSearch.Good tree16762 := H12GlobalWitnessIndex.good

theorem leafIdentity16762 : H12AffineFastState.composeSystem env16762 rootObs = leafEnv16762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16762 rootObs == leafEnv16762) = true)

theorem terminalChecked16762 : H12PackedTerminal.terminalCheckFast leafEnv16762 active16762 tree16762 = true := by decide +kernel

def env16763 : List Nat := [2,4,8,16,1,16,2,14,11,1024,1,1055,8,1055,10,9,1055,10,1025,11,1055,10,17,9,2,16,10,1055,1054,1,1035,1,14,11,1055,11]

theorem envBound16763 : H12AffineFastState.Bounded env16763 := by
  intro p hp
  have h : env16763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16760_16763 : H12AffineEnvironment.transform 4 1 env16760 = env16763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env16760 == env16763) = true)

theorem identity16763 : scanCanonicalize (H12AffineFastState.compose env16763 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound16763 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16764 : List Nat := [2,4,8,1,1,1,2,14,11,1024,1,1038,8,1038,10,9,1038,10,1025,11,1038,10,0,9,2,1,10,1038,1039,1,1035,1,14,11,1038,11]

theorem envBound16764 : H12AffineFastState.Bounded env16764 := by
  intro p hp
  have h : env16764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16763_16764 : H12AffineEnvironment.transform 3 1 env16763 = env16764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env16763 == env16764) = true)

def leafEnv16764 : List Nat := [2,4,8,1,1,1,2,14,11,1024,1,1038,8,1038,10,9,1038,10,1025,11,1038,10,0,9,1034,2,1,1,10,1038,1039,1,1035,1,14,11,4,2,1038,11,0,1039,1]

def active16764 : List Nat := [0,1,2,9]

def tree16764 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16764 : H12WitnessSearch.Good tree16764 := H12GlobalWitnessIndex.good

theorem leafIdentity16764 : H12AffineFastState.composeSystem env16764 rootObs = leafEnv16764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16764 rootObs == leafEnv16764) = true)

theorem terminalChecked16764 : H12PackedTerminal.terminalCheckFast leafEnv16764 active16764 tree16764 = true := by decide +kernel

def env16765 : List Nat := [2,4,8,16,32,17,128,173,137,1024,1,1213,41,1212,136,170,1213,136,1025,137,1213,169,17,139,161,17,136,1212,1213,1,1192,1,173,137,1213,137]

theorem envBound16765 : H12AffineFastState.Bounded env16765 := by
  intro p hp
  have h : env16765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16758_16765 : H12AffineEnvironment.transform 5 17 env16758 = env16765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env16758 == env16765) = true)

theorem identity16765 : scanCanonicalize (H12AffineFastState.compose env16765 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound16765 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16766 : List Nat := [2,4,2,16,32,17,128,167,131,1024,1,1207,35,1206,130,160,1207,130,1025,131,1207,163,17,129,161,17,130,1206,1207,1,1186,1,167,131,1207,131]

theorem envBound16766 : H12AffineFastState.Bounded env16766 := by
  intro p hp
  have h : env16766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16765_16766 : H12AffineEnvironment.transform 2 2 env16765 = env16766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env16765 == env16766) = true)

def env16767 : List Nat := [2,4,2,16,0,17,128,135,131,1024,1,1175,3,1174,130,128,1175,130,1025,131,1175,131,17,129,129,17,130,1174,1175,1,1154,1,135,131,1175,131]

theorem envBound16767 : H12AffineFastState.Bounded env16767 := by
  intro p hp
  have h : env16767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16766_16767 : H12AffineEnvironment.transform 4 0 env16766 = env16767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env16766 == env16767) = true)

theorem identity16767 : scanCanonicalize (H12AffineFastState.compose env16767 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound16767 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16768 : List Nat := [2,4,2,16,0,17,19,20,16,1024,1,1028,3,1029,17,19,1028,17,1025,16,1028,16,17,18,18,17,17,1029,1028,1,1041,1,20,16,1028,16]

theorem envBound16768 : H12AffineFastState.Bounded env16768 := by
  intro p hp
  have h : env16768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16767_16768 : H12AffineEnvironment.transform 6 19 env16767 = env16768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env16767 == env16768) = true)

def leafEnv16768 : List Nat := [2,4,2,16,0,17,19,20,16,1024,1,1028,3,1029,17,19,1028,17,1025,16,1028,16,17,18,1040,18,1,17,17,1029,1028,1,1041,1,20,16,4,3,1028,16,0,1028,1]

def active16768 : List Nat := [0,1,3,9]

def tree16768 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16768 : H12WitnessSearch.Good tree16768 := H12GlobalWitnessIndex.good

theorem leafIdentity16768 : H12AffineFastState.composeSystem env16768 rootObs = leafEnv16768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16768 rootObs == leafEnv16768) = true)

theorem terminalChecked16768 : H12PackedTerminal.terminalCheckFast leafEnv16768 active16768 tree16768 = true := by decide +kernel

def env16769 : List Nat := [2,4,2,16,1,17,128,134,131,1024,1,1174,2,1175,130,129,1174,130,1025,131,1174,130,17,129,128,17,130,1175,1174,1,1155,1,134,131,1174,131]

theorem envBound16769 : H12AffineFastState.Bounded env16769 := by
  intro p hp
  have h : env16769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16766_16769 : H12AffineEnvironment.transform 4 1 env16766 = env16769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env16766 == env16769) = true)

theorem identity16769 : scanCanonicalize (H12AffineFastState.compose env16769 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound16769 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16770 : List Nat := [2,4,2,0,1,1,128,134,131,1024,1,1158,2,1159,130,129,1158,130,1025,131,1158,130,1,129,128,1,130,1159,1158,1,1155,1,134,131,1158,131]

theorem envBound16770 : H12AffineFastState.Bounded env16770 := by
  intro p hp
  have h : env16770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16769_16770 : H12AffineEnvironment.transform 3 0 env16769 = env16770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env16769 == env16770) = true)

def leafEnv16770 : List Nat := [2,4,2,0,1,1,128,134,131,1024,1,1158,2,1159,130,129,1158,130,1025,131,1158,130,1,129,1154,128,1,1,130,1159,1158,1,1155,1,134,131,4,2,1158,131,0,1158,1]

def active16770 : List Nat := [0,1,6,9]

def tree16770 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16770 : H12WitnessSearch.Good tree16770 := H12GlobalWitnessIndex.good

theorem leafIdentity16770 : H12AffineFastState.composeSystem env16770 rootObs = leafEnv16770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16770 rootObs == leafEnv16770) = true)

theorem terminalChecked16770 : H12PackedTerminal.terminalCheckFast leafEnv16770 active16770 tree16770 = true := by decide +kernel

def env16771 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,8192,1297,8460,65536,1345,136,1025,8461,1345,8321,17,73736,8328,64,8461,1297,1296,67846,1285,74031,256,8460,1345,137]

theorem envBound16771 : H12AffineFastState.Bounded env16771 := by
  intro p hp
  have h : env16771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16738_16771 : H12AffineEnvironment.transform 21 8321 env16738 = env16771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8321 env16738 == env16771) = true)

def env16772 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32769,4096,4194304,17665,644436,8328,541009,134217728,16385,545089,1073741824,545108,4294967296,257,4299806206,138695701,512]

theorem envBound16772 : H12AffineFastState.Bounded env16772 := by
  intro p hp
  have h : env16772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16258_16772 : H12AffineEnvironment.transform 22 17665 env16258 = env16772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17665 env16258 == env16772) = true)

def env16773 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,4194304,8388608,16777216,8328,8914000,134217728,8519745,676865,1073741824,25412673,4294967296,8536384,4315938986,164610305,512]

theorem envBound16773 : H12AffineFastState.Bounded env16773 := by
  intro p hp
  have h : env16773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16117_16773 : H12AffineEnvironment.transform 20 4097 env16117 = env16773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env16117 == env16773) = true)

theorem identity16773 : scanCanonicalize (H12AffineFastState.compose env16773 (packedSelected [14] rootPS)) = affineNative (2^(26+1) ^^^ 12980501) := by decide +kernel

theorem selectedBound16773 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env16774 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,4194304,8388608,16777216,8328,8914000,12980501,8519745,676865,1073741824,25412673,4294967296,8536384,4315938986,17420308,512]

theorem envBound16774 : H12AffineFastState.Bounded env16774 := by
  intro p hp
  have h : env16774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16773_16774 : H12AffineEnvironment.transform 26 12980501 env16773 = env16774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 12980501 env16773 == env16774) = true)

def env16775 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,4194304,660544,16777216,8328,135184,4982101,529409,676865,1073741824,17420289,4294967296,546048,4315938986,17420308,512]

theorem envBound16775 : H12AffineFastState.Bounded env16775 := by
  intro p hp
  have h : env16775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16774_16775 : H12AffineEnvironment.transform 22 660544 env16774 = env16775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 660544 env16774 == env16775) = true)

theorem identity16775 : scanCanonicalize (H12AffineFastState.compose env16775 (packedSelected [0,4,7,9,16,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound16775 : packedSelected [0,4,7,9,16,20] rootPS < 2^1333 := by decide +kernel

def env16776 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,4194304,660496,16777216,8328,135184,4982021,529409,676865,1073741824,17420289,4294967296,546048,4315938986,17420308,512]

theorem envBound16776 : H12AffineFastState.Bounded env16776 := by
  intro p hp
  have h : env16776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16775_16776 : H12AffineEnvironment.transform 5 16 env16775 = env16776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env16775 == env16776) = true)

def env16777 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,151824,32769,4097,4194304,17664,16777216,8328,135184,4609045,148753,1297,1073741824,17006865,4294967296,132112,4315938986,17006852,512]

theorem envBound16777 : H12AffineFastState.Bounded env16777 := by
  intro p hp
  have h : env16777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16776_16777 : H12AffineEnvironment.transform 18 151824 env16776 = env16777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 151824 env16776 == env16777) = true)

def env16778 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,151825,32769,4097,4194304,17665,16777216,8328,135184,4609044,148752,1296,1073741824,17006864,4294967296,132113,4315938986,17006853,512]

theorem envBound16778 : H12AffineFastState.Bounded env16778 := by
  intro p hp
  have h : env16778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16776_16778 : H12AffineEnvironment.transform 18 151825 env16776 = env16778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 151825 env16776 == env16778) = true)

theorem identity16778 : scanCanonicalize (H12AffineFastState.compose env16778 (packedSelected [0,27] rootPS)) = affineNative (2^(23+1) ^^^ 98564) := by decide +kernel

theorem selectedBound16778 : packedSelected [0,27] rootPS < 2^1333 := by decide +kernel

def env16779 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,151825,32769,4097,4194304,17665,98564,8328,135184,4609044,148752,1296,1073741824,131092,4294967296,132113,4299260334,131073,512]

theorem envBound16779 : H12AffineFastState.Bounded env16779 := by
  intro p hp
  have h : env16779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16778_16779 : H12AffineEnvironment.transform 23 98564 env16778 = env16779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98564 env16778 == env16779) = true)

theorem identity16779 : scanCanonicalize (H12AffineFastState.compose env16779 (packedSelected [5,15,17,24] rootPS)) = affineNative (2^(29+1) ^^^ 4497708) := by decide +kernel

theorem selectedBound16779 : packedSelected [5,15,17,24] rootPS < 2^1333 := by decide +kernel

def env16780 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,151825,32769,4097,4194304,17665,98564,8328,135184,4609044,148752,1296,4497708,131092,4294967296,132113,4299260334,131073,512]

theorem envBound16780 : H12AffineFastState.Bounded env16780 := by
  intro p hp
  have h : env16780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16779_16780 : H12AffineEnvironment.transform 29 4497708 env16779 = env16780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4497708 env16779 == env16780) = true)

theorem identity16780 : scanCanonicalize (H12AffineFastState.compose env16780 (packedSelected [4,9,16,18,23] rootPS)) = affineNative (2^(17+1) ^^^ 195896) := by decide +kernel

theorem selectedBound16780 : packedSelected [4,9,16,18,23] rootPS < 2^1333 := by decide +kernel

def env16781 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,195896,151825,32769,4097,4194304,17665,98564,8328,135184,4237612,148752,1296,4348948,131092,4294967296,132113,4299260334,131073,512]

theorem envBound16781 : H12AffineFastState.Bounded env16781 := by
  intro p hp
  have h : env16781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16780_16781 : H12AffineEnvironment.transform 17 195896 env16780 = env16781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 195896 env16780 == env16781) = true)

def env16782 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,195896,151825,32769,4097,10248,17665,98564,8328,135184,33060,148752,1296,160796,131092,4294967296,132113,4295076262,131073,512]

theorem envBound16782 : H12AffineFastState.Bounded env16782 := by
  intro p hp
  have h : env16782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16781_16782 : H12AffineEnvironment.transform 21 10248 env16781 = env16782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10248 env16781 == env16782) = true)

theorem identity16782 : scanCanonicalize (H12AffineFastState.compose env16782 (packedSelected [11] rootPS)) = affineNative (2^(16+1) ^^^ 4097) := by decide +kernel

theorem selectedBound16782 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env16783 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4097,60729,16656,32769,4097,10248,17665,98564,8328,17,33060,21777,1296,25629,4117,4294967296,5136,4295076262,4096,512]

theorem envBound16783 : H12AffineFastState.Bounded env16783 := by
  intro p hp
  have h : env16783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16782_16783 : H12AffineEnvironment.transform 16 4097 env16782 = env16783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4097 env16782 == env16783) = true)

def env16784 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,25912,65536,4097,2049,16656,25913,4097,10248,17665,91196,8328,17,25628,21777,1296,25629,4117,4294967296,5136,4295052446,4096,512]

theorem envBound16784 : H12AffineFastState.Bounded env16784 := by
  intro p hp
  have h : env16784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16783_16784 : H12AffineEnvironment.transform 14 25912 env16783 = env16784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25912 env16783 == env16784) = true)

theorem identity16784 : scanCanonicalize (H12AffineFastState.compose env16784 (packedSelected [4,9] rootPS)) = affineNative (2^(12+1) ^^^ 7197) := by decide +kernel

theorem selectedBound16784 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env16785 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,7197,16384,22821,65536,4097,2049,16656,22820,4097,5141,17665,88097,7317,17,22529,21777,1296,22528,4117,4294967296,5136,4295052446,4096,512]

theorem envBound16785 : H12AffineFastState.Bounded env16785 := by
  intro p hp
  have h : env16785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16784_16785 : H12AffineEnvironment.transform 12 7197 env16784 = env16785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7197 env16784 == env16785) = true)

theorem identity16785 : scanCanonicalize (H12AffineFastState.compose env16785 (packedSelected [0,7,10,13] rootPS)) = affineNative (2^(13+1) ^^^ 4096) := by decide +kernel

theorem selectedBound16785 : packedSelected [0,7,10,13] rootPS < 2^1333 := by decide +kernel

def env16786 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,7197,4096,2341,65536,4097,2049,4368,2340,4097,5141,5377,67617,7317,17,2049,1297,1296,2048,4117,4294967296,5136,4295040158,4096,512]

theorem envBound16786 : H12AffineFastState.Bounded env16786 := by
  intro p hp
  have h : env16786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16785_16786 : H12AffineEnvironment.transform 13 4096 env16785 = env16786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4096 env16785 == env16786) = true)

def env16787 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,2317,1296,2341,65536,1297,2049,1024,2340,1297,261,17,67617,2437,17,2049,1297,1296,2048,1285,4294967296,256,4295035278,1296,512]

theorem envBound16787 : H12AffineFastState.Bounded env16787 := by
  intro p hp
  have h : env16787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16786_16787 : H12AffineEnvironment.transform 11 1296 env16786 = env16787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env16786 == env16787) = true)

theorem identity16787 : scanCanonicalize (H12AffineFastState.compose env16787 (packedSelected [1,3] rootPS)) = affineNative (2^(15+1) ^^^ 2218) := by decide +kernel

theorem selectedBound16787 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env16788 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,2317,1296,2341,2218,1297,2049,1024,2340,1297,261,17,139,2437,17,2049,1297,1296,2048,1285,4294967296,256,4294967588,1296,512]

theorem envBound16788 : H12AffineFastState.Bounded env16788 := by
  intro p hp
  have h : env16788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16787_16788 : H12AffineEnvironment.transform 15 2218 env16787 = env16788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2218 env16787 == env16788) = true)

theorem identity16788 : scanCanonicalize (H12AffineFastState.compose env16788 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 545) := by decide +kernel

theorem selectedBound16788 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16789 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,2317,1296,2341,2218,1297,2049,1024,2340,1297,261,17,139,2437,17,2049,1297,1296,2048,1285,545,256,773,1296,512]

theorem envBound16789 : H12AffineFastState.Bounded env16789 := by
  intro p hp
  have h : env16789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16788_16789 : H12AffineEnvironment.transform 31 545 env16788 = env16789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 545 env16788 == env16789) = true)

theorem identity16789 : scanCanonicalize (H12AffineFastState.compose env16789 (packedSelected [5] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound16789 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env16790 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,1296,2317,1296,2341,2218,1297,2049,1024,2340,1297,261,17,139,2437,17,2049,1297,1296,2048,1285,169,256,397,1296,136]

theorem envBound16790 : H12AffineFastState.Bounded env16790 := by
  intro p hp
  have h : env16790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16789_16790 : H12AffineEnvironment.transform 8 136 env16789 = env16790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env16789 == env16790) = true)

def env16791 : List Nat := [2,4,8,16,32,16,8,256,0,1024,2048,1296,2317,1296,2341,2082,1297,2049,1024,2340,1297,261,17,3,2317,17,2049,1297,1296,2048,1285,33,256,261,1296,0]

theorem envBound16791 : H12AffineFastState.Bounded env16791 := by
  intro p hp
  have h : env16791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16790_16791 : H12AffineEnvironment.transform 6 8 env16790 = env16791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env16790 == env16791) = true)

theorem identity16791 : scanCanonicalize (H12AffineFastState.compose env16791 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound16791 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16792 : List Nat := [2,4,8,16,32,16,8,4,0,1024,2048,1044,2057,1044,2081,2082,1045,2049,1024,2080,1045,1,17,3,2057,17,2049,1045,1044,2048,1025,33,4,1,1044,0]

theorem envBound16792 : H12AffineFastState.Bounded env16792 := by
  intro p hp
  have h : env16792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16791_16792 : H12AffineEnvironment.transform 7 4 env16791 = env16792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env16791 == env16792) = true)

def leafEnv16792 : List Nat := [2,4,8,16,32,16,8,4,0,1024,2048,1044,2057,1044,2081,2082,1045,2049,1024,2080,1045,1,17,3,1025,2057,1,17,2049,1045,1044,2048,1025,33,4,1,4,2083,1044,0,0,1045,1]

def active16792 : List Nat := [0,1,2,3,4,9,10]

def tree16792 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16792 : H12WitnessSearch.Good tree16792 := H12GlobalWitnessIndex.good

theorem leafIdentity16792 : H12AffineFastState.composeSystem env16792 rootObs = leafEnv16792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16792 rootObs == leafEnv16792) = true)

theorem terminalChecked16792 : H12PackedTerminal.terminalCheckFast leafEnv16792 active16792 tree16792 = true := by decide +kernel

def env16793 : List Nat := [2,4,8,16,32,16,9,256,1,1024,2048,1296,2317,1296,2341,2083,1297,2049,1024,2340,1297,261,17,2,2316,17,2049,1297,1296,2048,1285,32,256,260,1296,1]

theorem envBound16793 : H12AffineFastState.Bounded env16793 := by
  intro p hp
  have h : env16793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16790_16793 : H12AffineEnvironment.transform 6 9 env16790 = env16793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env16790 == env16793) = true)

theorem identity16793 : scanCanonicalize (H12AffineFastState.compose env16793 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound16793 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16794 : List Nat := [2,4,8,16,0,16,9,256,1,1024,2048,1296,2317,1296,2309,2051,1297,2049,1024,2308,1297,261,17,2,2316,17,2049,1297,1296,2048,1285,0,256,260,1296,1]

theorem envBound16794 : H12AffineFastState.Bounded env16794 := by
  intro p hp
  have h : env16794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16793_16794 : H12AffineEnvironment.transform 4 0 env16793 = env16794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env16793 == env16794) = true)

def leafEnv16794 : List Nat := [2,4,8,16,0,16,9,256,1,1024,2048,1296,2317,1296,2309,2051,1297,2049,1024,2308,1297,261,17,2,1285,2316,1,17,2049,1297,1296,2048,1285,0,256,260,4,2051,1296,1,0,1297,1]

def active16794 : List Nat := [0,1,2,3,7,9,10]

def tree16794 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16794 : H12WitnessSearch.Good tree16794 := H12GlobalWitnessIndex.good

theorem leafIdentity16794 : H12AffineFastState.composeSystem env16794 rootObs = leafEnv16794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16794 rootObs == leafEnv16794) = true)

theorem terminalChecked16794 : H12PackedTerminal.terminalCheckFast leafEnv16794 active16794 tree16794 = true := by decide +kernel

def env16795 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,2316,1297,2341,65536,1296,2049,1025,2340,1296,260,16,67617,2436,17,2049,1297,1296,2048,1284,4294967296,257,4295035279,1297,512]

theorem envBound16795 : H12AffineFastState.Bounded env16795 := by
  intro p hp
  have h : env16795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16786_16795 : H12AffineEnvironment.transform 11 1297 env16786 = env16795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env16786 == env16795) = true)

theorem identity16795 : scanCanonicalize (H12AffineFastState.compose env16795 (packedSelected [1,3] rootPS)) = affineNative (2^(31+1) ^^^ 68527) := by decide +kernel

theorem selectedBound16795 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env16796 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,2316,1297,2341,65536,1296,2049,1025,2340,1296,260,16,67617,2436,17,2049,1297,1296,2048,1284,68527,257,544,1297,512]

theorem envBound16796 : H12AffineFastState.Bounded env16796 := by
  intro p hp
  have h : env16796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16795_16796 : H12AffineEnvironment.transform 31 68527 env16795 = env16796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 68527 env16795 == env16796) = true)

theorem identity16796 : scanCanonicalize (H12AffineFastState.compose env16796 (packedSelected [5] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound16796 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env16797 : List Nat := [2,4,8,16,32,16,128,5,512,1024,2048,1044,2057,1044,2080,65536,1045,2049,1025,2081,1045,1,16,67617,2177,17,2049,1044,1045,2048,1025,68266,4,544,1044,512]

theorem envBound16797 : H12AffineFastState.Bounded env16797 := by
  intro p hp
  have h : env16797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16796_16797 : H12AffineEnvironment.transform 7 5 env16796 = env16797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env16796 == env16797) = true)

theorem identity16797 : scanCanonicalize (H12AffineFastState.compose env16797 (packedSelected [8] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound16797 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env16798 : List Nat := [2,4,8,16,32,16,128,5,137,1024,2048,1044,2057,1044,2080,65536,1045,2049,1025,2081,1045,1,16,67617,2177,17,2049,1044,1045,2048,1025,67619,4,169,1044,137]

theorem envBound16798 : H12AffineFastState.Bounded env16798 := by
  intro p hp
  have h : env16798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16797_16798 : H12AffineEnvironment.transform 8 137 env16797 = env16798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env16797 == env16798) = true)

def env16799 : List Nat := [2,4,8,16,32,16,128,5,137,20,2048,0,2057,0,2080,65536,1,2049,21,2081,1,1,16,67617,2177,17,2049,0,1,2048,21,67619,4,169,0,137]

theorem envBound16799 : H12AffineFastState.Bounded env16799 := by
  intro p hp
  have h : env16799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16798_16799 : H12AffineEnvironment.transform 9 20 env16798 = env16799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env16798 == env16799) = true)

theorem identity16799 : scanCanonicalize (H12AffineFastState.compose env16799 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound16799 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16800 : List Nat := [2,4,8,16,32,16,128,5,137,20,32,0,41,0,0,65536,1,33,21,1,1,1,16,65537,161,17,33,0,1,32,21,65539,4,169,0,137]

theorem envBound16800 : H12AffineFastState.Bounded env16800 := by
  intro p hp
  have h : env16800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16799_16800 : H12AffineEnvironment.transform 10 32 env16799 = env16800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env16799 == env16800) = true)

def env16801 : List Nat := [2,4,8,16,0,16,128,5,137,20,0,0,9,0,0,65536,1,1,21,1,1,1,16,65537,129,17,1,0,1,0,21,65539,4,137,0,137]

theorem envBound16801 : H12AffineFastState.Bounded env16801 := by
  intro p hp
  have h : env16801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16800_16801 : H12AffineEnvironment.transform 4 0 env16800 = env16801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env16800 == env16801) = true)

theorem identity16801 : scanCanonicalize (H12AffineFastState.compose env16801 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 154) := by decide +kernel

theorem selectedBound16801 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16802 : List Nat := [2,4,8,16,0,16,128,5,137,20,0,0,9,0,0,154,1,1,21,1,1,1,16,155,129,17,1,0,1,0,21,153,4,137,0,137]

theorem envBound16802 : H12AffineFastState.Bounded env16802 := by
  intro p hp
  have h : env16802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16801_16802 : H12AffineEnvironment.transform 15 154 env16801 = env16802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 154 env16801 == env16802) = true)

def env16803 : List Nat := [2,4,8,16,1,16,128,5,137,20,1,0,8,0,0,65536,1,0,21,1,1,1,16,65537,128,17,0,0,1,1,21,65539,4,136,0,137]

theorem envBound16803 : H12AffineFastState.Bounded env16803 := by
  intro p hp
  have h : env16803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16800_16803 : H12AffineEnvironment.transform 4 1 env16800 = env16803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env16800 == env16803) = true)

theorem identity16803 : scanCanonicalize (H12AffineFastState.compose env16803 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 19) := by decide +kernel

theorem selectedBound16803 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16804 : List Nat := [2,4,8,16,1,16,128,5,137,20,1,0,8,0,0,19,1,0,21,1,1,1,16,18,128,17,0,0,1,1,21,16,4,136,0,137]

theorem envBound16804 : H12AffineFastState.Bounded env16804 := by
  intro p hp
  have h : env16804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16803_16804 : H12AffineEnvironment.transform 15 19 env16803 = env16804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 19 env16803 == env16804) = true)

theorem identity16804 : scanCanonicalize (H12AffineFastState.compose env16804 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound16804 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16805 : List Nat := [2,4,8,16,1,16,25,5,16,20,1,0,8,0,0,19,1,0,21,1,1,1,16,18,25,17,0,0,1,1,21,16,4,17,0,16]

theorem envBound16805 : H12AffineFastState.Bounded env16805 := by
  intro p hp
  have h : env16805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16804_16805 : H12AffineEnvironment.transform 6 25 env16804 = env16805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env16804 == env16805) = true)

def leafEnv16805 : List Nat := [2,4,8,16,1,16,25,5,16,20,1,0,8,0,0,19,1,0,21,1,1,1,16,18,21,25,1,17,0,0,1,1,21,16,4,17,4,3,0,16,0,1,1]

def active16805 : List Nat := [0,1,2,3]

def tree16805 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16805 : H12WitnessSearch.Good tree16805 := H12GlobalWitnessIndex.good

theorem leafIdentity16805 : H12AffineFastState.composeSystem env16805 rootObs = leafEnv16805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16805 rootObs == leafEnv16805) = true)

theorem terminalChecked16805 : H12PackedTerminal.terminalCheckFast leafEnv16805 active16805 tree16805 = true := by decide +kernel

def env16806 : List Nat := [2,4,8,16,32,16,128,5,137,21,2048,1,2057,1,2080,65536,0,2049,20,2081,0,1,16,67617,2177,17,2049,1,0,2048,20,67619,4,169,1,137]

theorem envBound16806 : H12AffineFastState.Bounded env16806 := by
  intro p hp
  have h : env16806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16798_16806 : H12AffineEnvironment.transform 9 21 env16798 = env16806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env16798 == env16806) = true)

theorem identity16806 : scanCanonicalize (H12AffineFastState.compose env16806 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 138) := by decide +kernel

theorem selectedBound16806 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16807 : List Nat := [2,4,8,16,32,16,128,5,137,21,2048,1,2057,1,2080,138,0,2049,20,2081,0,1,16,2219,2177,17,2049,1,0,2048,20,2217,4,169,1,137]

theorem envBound16807 : H12AffineFastState.Bounded env16807 := by
  intro p hp
  have h : env16807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16806_16807 : H12AffineEnvironment.transform 15 138 env16806 = env16807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 138 env16806 == env16807) = true)

def env16808 : List Nat := [2,4,8,16,0,16,128,5,137,21,2048,1,2057,1,2048,138,0,2049,20,2049,0,1,16,2187,2177,17,2049,1,0,2048,20,2185,4,137,1,137]

theorem envBound16808 : H12AffineFastState.Bounded env16808 := by
  intro p hp
  have h : env16808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16807_16808 : H12AffineEnvironment.transform 4 0 env16807 = env16808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env16807 == env16808) = true)

theorem identity16808 : scanCanonicalize (H12AffineFastState.compose env16808 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound16808 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16809 : List Nat := [2,4,8,1,0,1,128,5,137,4,2048,1,2057,1,2048,138,0,2049,5,2049,0,1,1,2187,2177,0,2049,1,0,2048,5,2185,4,137,1,137]

theorem envBound16809 : H12AffineFastState.Bounded env16809 := by
  intro p hp
  have h : env16809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16808_16809 : H12AffineEnvironment.transform 3 1 env16808 = env16809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env16808 == env16809) = true)

theorem identity16809 : scanCanonicalize (H12AffineFastState.compose env16809 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound16809 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16810 : List Nat := [2,4,8,1,0,1,128,5,137,4,0,1,9,1,0,138,0,1,5,1,0,1,1,139,129,0,1,1,0,0,5,137,4,137,1,137]

theorem envBound16810 : H12AffineFastState.Bounded env16810 := by
  intro p hp
  have h : env16810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16809_16810 : H12AffineEnvironment.transform 10 0 env16809 = env16810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env16809 == env16810) = true)

def leafEnv16810 : List Nat := [2,4,8,1,0,1,128,5,137,4,0,1,9,1,0,138,0,1,5,1,0,1,1,139,5,129,1,0,1,1,0,0,5,137,4,137,4,3,1,137,0,0,1]

def active16810 : List Nat := [0,1,2,6]

def tree16810 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16810 : H12WitnessSearch.Good tree16810 := H12GlobalWitnessIndex.good

theorem leafIdentity16810 : H12AffineFastState.composeSystem env16810 rootObs = leafEnv16810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16810 rootObs == leafEnv16810) = true)

theorem terminalChecked16810 : H12PackedTerminal.terminalCheckFast leafEnv16810 active16810 tree16810 = true := by decide +kernel

def env16811 : List Nat := [2,4,8,16,1,16,128,5,137,21,2048,1,2057,1,2049,138,0,2049,20,2048,0,1,16,2186,2177,17,2049,1,0,2048,20,2184,4,136,1,137]

theorem envBound16811 : H12AffineFastState.Bounded env16811 := by
  intro p hp
  have h : env16811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16807_16811 : H12AffineEnvironment.transform 4 1 env16807 = env16811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env16807 == env16811) = true)

theorem identity16811 : scanCanonicalize (H12AffineFastState.compose env16811 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound16811 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16812 : List Nat := [2,4,8,16,1,16,24,5,17,21,2048,1,2057,1,2049,18,0,2049,20,2048,0,1,16,2066,2073,17,2049,1,0,2048,20,2064,4,16,1,17]

theorem envBound16812 : H12AffineFastState.Bounded env16812 := by
  intro p hp
  have h : env16812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16811_16812 : H12AffineEnvironment.transform 6 24 env16811 = env16812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env16811 == env16812) = true)

def env16813 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,25913,65536,4097,2048,16656,25912,4097,10248,17665,91197,8328,17,25629,21777,1296,25629,4117,4294967296,5136,4295052447,4096,512]

theorem envBound16813 : H12AffineFastState.Bounded env16813 := by
  intro p hp
  have h : env16813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16783_16813 : H12AffineEnvironment.transform 14 25913 env16783 = env16813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25913 env16783 == env16813) = true)

theorem identity16813 : scanCanonicalize (H12AffineFastState.compose env16813 (packedSelected [4,9] rootPS)) = affineNative (2^(13+1) ^^^ 4096) := by decide +kernel

theorem selectedBound16813 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env16814 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,13625,65536,4097,2048,4368,13624,4097,10248,5377,78909,8328,17,13341,1297,1296,13341,4117,4294967296,5136,4295040159,4096,512]

theorem envBound16814 : H12AffineFastState.Bounded env16814 := by
  intro p hp
  have h : env16814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16813_16814 : H12AffineEnvironment.transform 13 4096 env16813 = env16814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4096 env16813 == env16814) = true)

theorem identity16814 : scanCanonicalize (H12AffineFastState.compose env16814 (packedSelected [3,5,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 7196) := by decide +kernel

theorem selectedBound16814 : packedSelected [3,5,10,12] rootPS < 2^1333 := by decide +kernel

def env16815 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,7196,4096,2341,65536,4097,2048,4368,2340,4097,5140,5377,67617,7316,17,2049,1297,1296,2049,4117,4294967296,5136,4295040159,4096,512]

theorem envBound16815 : H12AffineFastState.Bounded env16815 := by
  intro p hp
  have h : env16815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16814_16815 : H12AffineEnvironment.transform 12 7196 env16814 = env16815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7196 env16814 == env16815) = true)

def env16816 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,2316,1296,2341,65536,1297,2048,1024,2340,1297,260,17,67617,2436,17,2049,1297,1296,2049,1285,4294967296,256,4295035279,1296,512]

theorem envBound16816 : H12AffineFastState.Bounded env16816 := by
  intro p hp
  have h : env16816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16815_16816 : H12AffineEnvironment.transform 11 1296 env16815 = env16816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env16815 == env16816) = true)

theorem identity16816 : scanCanonicalize (H12AffineFastState.compose env16816 (packedSelected [1,3] rootPS)) = affineNative (2^(15+1) ^^^ 2218) := by decide +kernel

theorem selectedBound16816 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env16817 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,2316,1296,2341,2218,1297,2048,1024,2340,1297,260,17,139,2436,17,2049,1297,1296,2049,1285,4294967296,256,4294967589,1296,512]

theorem envBound16817 : H12AffineFastState.Bounded env16817 := by
  intro p hp
  have h : env16817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16816_16817 : H12AffineEnvironment.transform 15 2218 env16816 = env16817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2218 env16816 == env16817) = true)

theorem identity16817 : scanCanonicalize (H12AffineFastState.compose env16817 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 544) := by decide +kernel

theorem selectedBound16817 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16818 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,2316,1296,2341,2218,1297,2048,1024,2340,1297,260,17,139,2436,17,2049,1297,1296,2049,1285,544,256,773,1296,512]

theorem envBound16818 : H12AffineFastState.Bounded env16818 := by
  intro p hp
  have h : env16818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16817_16818 : H12AffineEnvironment.transform 31 544 env16817 = env16818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 544 env16817 == env16818) = true)

theorem identity16818 : scanCanonicalize (H12AffineFastState.compose env16818 (packedSelected [5] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound16818 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env16819 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,2316,1296,2341,2218,1297,2048,1024,2340,1297,260,17,139,2436,17,2049,1297,1296,2049,1285,169,256,396,1296,137]

theorem envBound16819 : H12AffineFastState.Bounded env16819 := by
  intro p hp
  have h : env16819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16818_16819 : H12AffineEnvironment.transform 8 137 env16818 = env16819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env16818 == env16819) = true)

theorem identity16819 : scanCanonicalize (H12AffineFastState.compose env16819 (packedSelected [0,2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound16819 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env16820 : List Nat := [2,4,8,16,32,16,8,256,1,1024,2048,1296,2316,1296,2341,2082,1297,2048,1024,2340,1297,260,17,3,2316,17,2049,1297,1296,2049,1285,33,256,260,1296,1]

theorem envBound16820 : H12AffineFastState.Bounded env16820 := by
  intro p hp
  have h : env16820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16819_16820 : H12AffineEnvironment.transform 6 8 env16819 = env16820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env16819 == env16820) = true)

theorem identity16820 : scanCanonicalize (H12AffineFastState.compose env16820 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound16820 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16821 : List Nat := [2,4,8,16,0,16,8,256,1,1024,2048,1296,2316,1296,2309,2050,1297,2048,1024,2308,1297,260,17,3,2316,17,2049,1297,1296,2049,1285,1,256,260,1296,1]

theorem envBound16821 : H12AffineFastState.Bounded env16821 := by
  intro p hp
  have h : env16821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16820_16821 : H12AffineEnvironment.transform 4 0 env16820 = env16821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env16820 == env16821) = true)

def env16822 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,2317,1297,2341,65536,1296,2048,1025,2340,1296,261,16,67617,2437,17,2049,1297,1296,2049,1284,4294967296,257,4295035278,1297,512]

theorem envBound16822 : H12AffineFastState.Bounded env16822 := by
  intro p hp
  have h : env16822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16815_16822 : H12AffineEnvironment.transform 11 1297 env16815 = env16822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env16815 == env16822) = true)

theorem identity16822 : scanCanonicalize (H12AffineFastState.compose env16822 (packedSelected [1,3] rootPS)) = affineNative (2^(31+1) ^^^ 68526) := by decide +kernel

theorem selectedBound16822 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env16823 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,2317,1297,2341,65536,1296,2048,1025,2340,1296,261,16,67617,2437,17,2049,1297,1296,2049,1284,68526,257,544,1297,512]

theorem envBound16823 : H12AffineFastState.Bounded env16823 := by
  intro p hp
  have h : env16823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16822_16823 : H12AffineEnvironment.transform 31 68526 env16822 = env16823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 68526 env16822 == env16823) = true)

theorem identity16823 : scanCanonicalize (H12AffineFastState.compose env16823 (packedSelected [5] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound16823 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env16824 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,1045,2057,1045,2081,65536,1044,2048,1025,2080,1044,1,16,67617,2177,17,2049,1045,1044,2049,1024,68266,5,544,1045,512]

theorem envBound16824 : H12AffineFastState.Bounded env16824 := by
  intro p hp
  have h : env16824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16823_16824 : H12AffineEnvironment.transform 7 4 env16823 = env16824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env16823 == env16824) = true)

theorem identity16824 : scanCanonicalize (H12AffineFastState.compose env16824 (packedSelected [8] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound16824 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env16825 : List Nat := [2,4,8,16,32,16,128,4,137,1024,2048,1045,2057,1045,2081,65536,1044,2048,1025,2080,1044,1,16,67617,2177,17,2049,1045,1044,2049,1024,67619,5,169,1045,137]

theorem envBound16825 : H12AffineFastState.Bounded env16825 := by
  intro p hp
  have h : env16825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16824_16825 : H12AffineEnvironment.transform 8 137 env16824 = env16825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env16824 == env16825) = true)

theorem identity16825 : scanCanonicalize (H12AffineFastState.compose env16825 (packedSelected [2,4] rootPS)) = affineNative (2^(15+1) ^^^ 2218) := by decide +kernel

theorem selectedBound16825 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env16826 : List Nat := [2,4,8,16,32,16,128,4,137,1024,2048,1045,2057,1045,2081,2218,1044,2048,1025,2080,1044,1,16,139,2177,17,2049,1045,1044,2049,1024,137,5,169,1045,137]

theorem envBound16826 : H12AffineFastState.Bounded env16826 := by
  intro p hp
  have h : env16826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16825_16826 : H12AffineEnvironment.transform 15 2218 env16825 = env16826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2218 env16825 == env16826) = true)

theorem identity16826 : scanCanonicalize (H12AffineFastState.compose env16826 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound16826 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16827 : List Nat := [2,4,8,16,32,16,128,4,137,1024,33,1045,40,1045,0,139,1044,33,1025,1,1044,1,16,139,160,17,32,1045,1044,32,1024,137,5,169,1045,137]

theorem envBound16827 : H12AffineFastState.Bounded env16827 := by
  intro p hp
  have h : env16827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16826_16827 : H12AffineEnvironment.transform 10 33 env16826 = env16827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env16826 == env16827) = true)

theorem identity16827 : scanCanonicalize (H12AffineFastState.compose env16827 (packedSelected [0,2] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound16827 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env16828 : List Nat := [2,4,8,16,32,16,128,4,137,52,33,33,40,33,0,139,32,33,53,1,32,1,16,139,160,17,32,33,32,32,52,137,5,169,33,137]

theorem envBound16828 : H12AffineFastState.Bounded env16828 := by
  intro p hp
  have h : env16828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16827_16828 : H12AffineEnvironment.transform 9 52 env16827 = env16828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env16827 == env16828) = true)

def env16829 : List Nat := [2,4,8,16,0,16,128,4,137,20,1,1,8,1,0,139,0,1,21,1,0,1,16,139,128,17,0,1,0,0,20,137,5,137,1,137]

theorem envBound16829 : H12AffineFastState.Bounded env16829 := by
  intro p hp
  have h : env16829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16828_16829 : H12AffineEnvironment.transform 4 0 env16828 = env16829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env16828 == env16829) = true)

theorem identity16829 : scanCanonicalize (H12AffineFastState.compose env16829 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound16829 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16830 : List Nat := [2,4,8,0,0,0,128,4,137,4,1,1,8,1,0,139,0,1,5,1,0,1,0,139,128,1,0,1,0,0,4,137,5,137,1,137]

theorem envBound16830 : H12AffineFastState.Bounded env16830 := by
  intro p hp
  have h : env16830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16829_16830 : H12AffineEnvironment.transform 3 0 env16829 = env16830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env16829 == env16830) = true)

def leafEnv16830 : List Nat := [2,4,8,0,0,0,128,4,137,4,1,1,8,1,0,139,0,1,5,1,0,1,0,139,4,128,1,1,0,1,0,0,4,137,5,137,4,2,1,137,0,0,1]

def active16830 : List Nat := [0,1,2,6]

def tree16830 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16830 : H12WitnessSearch.Good tree16830 := H12GlobalWitnessIndex.good

theorem leafIdentity16830 : H12AffineFastState.composeSystem env16830 rootObs = leafEnv16830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16830 rootObs == leafEnv16830) = true)

theorem terminalChecked16830 : H12PackedTerminal.terminalCheckFast leafEnv16830 active16830 tree16830 = true := by decide +kernel

def env16831 : List Nat := [2,4,8,16,1,16,128,4,137,21,0,0,9,0,0,139,1,0,20,1,1,1,16,139,129,17,1,0,1,1,21,137,5,136,0,137]

theorem envBound16831 : H12AffineFastState.Bounded env16831 := by
  intro p hp
  have h : env16831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16828_16831 : H12AffineEnvironment.transform 4 1 env16828 = env16831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env16828 == env16831) = true)

theorem identity16831 : scanCanonicalize (H12AffineFastState.compose env16831 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound16831 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16832 : List Nat := [2,4,8,16,1,16,25,4,16,21,0,0,9,0,0,18,1,0,20,1,1,1,16,18,24,17,1,0,1,1,21,16,5,17,0,16]

theorem envBound16832 : H12AffineFastState.Bounded env16832 := by
  intro p hp
  have h : env16832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16831_16832 : H12AffineEnvironment.transform 6 25 env16831 = env16832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env16831 == env16832) = true)

def leafEnv16832 : List Nat := [2,4,8,16,1,16,25,4,16,21,0,0,9,0,0,18,1,0,20,1,1,1,16,18,21,24,1,17,1,0,1,1,21,16,5,17,4,2,0,16,0,1,1]

def active16832 : List Nat := [0,1,2,3]

def tree16832 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16832 : H12WitnessSearch.Good tree16832 := H12GlobalWitnessIndex.good

theorem leafIdentity16832 : H12AffineFastState.composeSystem env16832 rootObs = leafEnv16832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16832 rootObs == leafEnv16832) = true)

theorem terminalChecked16832 : H12PackedTerminal.terminalCheckFast leafEnv16832 active16832 tree16832 = true := by decide +kernel

def env16833 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,195896,151825,32769,4097,10249,17665,98564,8328,135184,33061,148752,1296,160797,131092,4294967296,132113,4295076263,131073,512]

theorem envBound16833 : H12AffineFastState.Bounded env16833 := by
  intro p hp
  have h : env16833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16781_16833 : H12AffineEnvironment.transform 21 10249 env16781 = env16833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10249 env16781 == env16833) = true)

theorem identity16833 : scanCanonicalize (H12AffineFastState.compose env16833 (packedSelected [11] rootPS)) = affineNative (2^(16+1) ^^^ 39205) := by decide +kernel

theorem selectedBound16833 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env16834 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,39205,25629,51252,32769,4097,10249,17665,98564,8328,35125,33061,56373,1296,60728,39217,4294967296,40244,4295076263,39204,512]

theorem envBound16834 : H12AffineFastState.Bounded env16834 := by
  intro p hp
  have h : env16834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16833_16834 : H12AffineEnvironment.transform 16 39205 env16833 = env16834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 39205 env16833 == env16834) = true)

def env16835 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,25912,65536,31773,25629,11532,25913,4097,10249,17665,91196,8328,27661,25629,14605,1296,2048,31753,4294967296,30732,4295052447,31772,512]

theorem envBound16835 : H12AffineFastState.Bounded env16835 := by
  intro p hp
  have h : env16835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16834_16835 : H12AffineEnvironment.transform 14 25912 env16834 = env16835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25912 env16834 == env16835) = true)

theorem identity16835 : scanCanonicalize (H12AffineFastState.compose env16835 (packedSelected [4,9] rootPS)) = affineNative (2^(13+1) ^^^ 4096) := by decide +kernel

theorem selectedBound16835 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env16836 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,13624,65536,11293,13341,11532,13625,4097,10249,5377,78908,8328,15373,13341,14605,1296,2048,11273,4294967296,10252,4295040159,11292,512]

theorem envBound16836 : H12AffineFastState.Bounded env16836 := by
  intro p hp
  have h : env16836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16835_16836 : H12AffineEnvironment.transform 13 4096 env16835 = env16836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4096 env16835 == env16836) = true)

def env16837 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,8192,4096,13624,65536,11293,13341,11532,13625,4097,10249,5377,78908,8328,15373,13341,14605,1296,2048,11273,4294967296,10252,4295040159,11292,136]

theorem envBound16837 : H12AffineFastState.Bounded env16837 := by
  intro p hp
  have h : env16837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16836_16837 : H12AffineEnvironment.transform 8 136 env16836 = env16837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env16836 == env16837) = true)

theorem identity16837 : scanCanonicalize (H12AffineFastState.compose env16837 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 2316) := by decide +kernel

theorem selectedBound16837 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env16838 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,2316,4096,7220,65536,1297,7441,1024,7221,4097,261,5377,73008,2436,5377,7441,4097,1296,2048,1285,4294967296,256,4295040159,1296,136]

theorem envBound16838 : H12AffineFastState.Bounded env16838 := by
  intro p hp
  have h : env16838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16837_16838 : H12AffineEnvironment.transform 12 2316 env16837 = env16838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2316 env16837 == env16838) = true)

theorem identity16838 : scanCanonicalize (H12AffineFastState.compose env16838 (packedSelected [1,3] rootPS)) = affineNative (2^(15+1) ^^^ 7611) := by decide +kernel

theorem selectedBound16838 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env16839 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,2316,4096,7220,7611,1297,7441,1024,7221,4097,261,5377,139,2436,5377,7441,4097,1296,2048,1285,4294967296,256,4294967588,1296,136]

theorem envBound16839 : H12AffineFastState.Bounded env16839 := by
  intro p hp
  have h : env16839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16838_16839 : H12AffineEnvironment.transform 15 7611 env16838 = env16839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 7611 env16838 == env16839) = true)

theorem identity16839 : scanCanonicalize (H12AffineFastState.compose env16839 (packedSelected [2,4] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound16839 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env16840 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,1297,2316,1297,2341,2218,1297,2048,1024,2340,1296,261,16,139,2436,16,2048,1296,1296,2048,1285,4294967296,256,4294967588,1296,136]

theorem envBound16840 : H12AffineFastState.Bounded env16840 := by
  intro p hp
  have h : env16840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16839_16840 : H12AffineEnvironment.transform 11 1297 env16839 = env16840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env16839 == env16840) = true)

theorem identity16840 : scanCanonicalize (H12AffineFastState.compose env16840 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 261) := by decide +kernel

theorem selectedBound16840 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16841 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,1297,2316,1297,2341,2218,1297,2048,1024,2340,1296,261,16,139,2436,16,2048,1296,1296,2048,1285,261,256,33,1296,136]

theorem envBound16841 : H12AffineFastState.Bounded env16841 := by
  intro p hp
  have h : env16841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16840_16841 : H12AffineEnvironment.transform 31 261 env16840 = env16841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 261 env16840 == env16841) = true)

theorem identity16841 : scanCanonicalize (H12AffineFastState.compose env16841 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 140) := by decide +kernel

theorem selectedBound16841 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16842 : List Nat := [2,4,8,16,32,16,128,140,136,1024,2048,1181,2176,1181,2217,2218,1181,2048,1024,2216,1180,137,16,139,2056,16,2048,1180,1180,2048,1161,137,140,33,1180,136]

theorem envBound16842 : H12AffineFastState.Bounded env16842 := by
  intro p hp
  have h : env16842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16841_16842 : H12AffineEnvironment.transform 7 140 env16841 = env16842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 140 env16841 == env16842) = true)

def env16843 : List Nat := [2,4,8,16,0,16,128,140,136,1024,2048,1181,2176,1181,2185,2186,1181,2048,1024,2184,1180,137,16,139,2056,16,2048,1180,1180,2048,1161,137,140,1,1180,136]

theorem envBound16843 : H12AffineFastState.Bounded env16843 := by
  intro p hp
  have h : env16843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16842_16843 : H12AffineEnvironment.transform 4 0 env16842 = env16843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env16842 == env16843) = true)

theorem identity16843 : scanCanonicalize (H12AffineFastState.compose env16843 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound16843 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16844 : List Nat := [2,4,8,16,0,16,9,5,1,1024,2048,1044,2057,1044,2048,2051,1044,2048,1024,2049,1045,0,16,2,2056,16,2048,1045,1045,2048,1024,0,5,1,1045,1]

theorem envBound16844 : H12AffineFastState.Bounded env16844 := by
  intro p hp
  have h : env16844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16843_16844 : H12AffineEnvironment.transform 6 9 env16843 = env16844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env16843 == env16844) = true)

def leafEnv16844 : List Nat := [2,4,8,16,0,16,9,5,1,1024,2048,1044,2057,1044,2048,2051,1044,2048,1024,2049,1045,0,16,2,1024,2056,1,16,2048,1045,1045,2048,1024,0,5,1,4,2051,1045,1,0,1044,1]

def active16844 : List Nat := [0,1,2,3,9,10]

def tree16844 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16844 : H12WitnessSearch.Good tree16844 := H12GlobalWitnessIndex.good

theorem leafIdentity16844 : H12AffineFastState.composeSystem env16844 rootObs = leafEnv16844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16844 rootObs == leafEnv16844) = true)

theorem terminalChecked16844 : H12PackedTerminal.terminalCheckFast leafEnv16844 active16844 tree16844 = true := by decide +kernel

def env16845 : List Nat := [2,4,8,16,1,16,128,140,136,1024,2048,1181,2176,1181,2184,2187,1181,2048,1024,2185,1180,137,16,139,2056,16,2048,1180,1180,2048,1161,137,140,0,1180,136]

theorem envBound16845 : H12AffineFastState.Bounded env16845 := by
  intro p hp
  have h : env16845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16842_16845 : H12AffineEnvironment.transform 4 1 env16842 = env16845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env16842 == env16845) = true)

def leafEnv16845 : List Nat := [2,4,8,16,1,16,128,140,136,1024,2048,1181,2176,1181,2184,2187,1181,2048,1024,2185,1180,137,16,139,1161,2056,1,16,2048,1180,1180,2048,1161,137,140,0,4,2050,1180,136,0,1181,1]

def active16845 : List Nat := [0,1,2,3,6,9,10]

def tree16845 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16845 : H12WitnessSearch.Good tree16845 := H12GlobalWitnessIndex.good

theorem leafIdentity16845 : H12AffineFastState.composeSystem env16845 rootObs = leafEnv16845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16845 rootObs == leafEnv16845) = true)

theorem terminalChecked16845 : H12PackedTerminal.terminalCheckFast leafEnv16845 active16845 tree16845 = true := by decide +kernel

def env16846 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,4096,8192,4096,13624,65536,11293,13341,11532,13625,4097,10249,5377,78908,8328,15373,13341,14605,1296,2048,11273,4294967296,10252,4295040159,11292,137]

theorem envBound16846 : H12AffineFastState.Bounded env16846 := by
  intro p hp
  have h : env16846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16836_16846 : H12AffineEnvironment.transform 8 137 env16836 = env16846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env16836 == env16846) = true)

def env16847 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,4096,7448,4096,2080,65536,4357,2309,4116,2081,4097,5393,5377,67876,7568,277,2309,1045,1296,2048,4369,4294967296,5396,4295040159,4356,137]

theorem envBound16847 : H12AffineFastState.Bounded env16847 := by
  intro p hp
  have h : env16847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16846_16847 : H12AffineEnvironment.transform 12 7448 env16846 = env16847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7448 env16846 == env16847) = true)

theorem identity16847 : scanCanonicalize (H12AffineFastState.compose env16847 (packedSelected [3,10] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound16847 : packedSelected [3,10] rootPS < 2^1333 := by decide +kernel

def env16848 : List Nat := [2,4,8,16,32,16,128,5,137,1024,2048,4096,7197,4096,2080,65536,4096,2048,4116,2081,4097,5140,5124,67617,7317,16,2048,1045,1045,2048,4116,4294967296,5137,4295040159,4097,137]

theorem envBound16848 : H12AffineFastState.Bounded env16848 := by
  intro p hp
  have h : env16848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16847_16848 : H12AffineEnvironment.transform 7 5 env16847 = env16848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env16847 == env16848) = true)

theorem identity16848 : scanCanonicalize (H12AffineFastState.compose env16848 (packedSelected [1,3,5] rootPS)) = affineNative (2^(15+1) ^^^ 7358) := by decide +kernel

theorem selectedBound16848 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env16849 : List Nat := [2,4,8,16,32,16,128,5,137,1024,2048,4096,7197,4096,2080,7358,4096,2048,4116,2081,4097,5140,5124,5279,7317,16,2048,1045,1045,2048,4116,4294967296,5137,4294967329,4097,137]

theorem envBound16849 : H12AffineFastState.Bounded env16849 := by
  intro p hp
  have h : env16849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16848_16849 : H12AffineEnvironment.transform 15 7358 env16848 = env16849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 7358 env16848 == env16849) = true)

def env16850 : List Nat := [2,4,8,16,32,16,128,5,137,1024,2048,2048,1053,2048,2080,1214,2048,2048,2068,2081,2049,3092,3076,3231,1173,16,2048,1045,1045,2048,2068,4294967296,3089,4294967329,2049,137]

theorem envBound16850 : H12AffineFastState.Bounded env16850 := by
  intro p hp
  have h : env16850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16849_16850 : H12AffineEnvironment.transform 11 2048 env16849 = env16850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2048 env16849 == env16850) = true)

theorem identity16850 : scanCanonicalize (H12AffineFastState.compose env16850 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 0) := by decide +kernel

theorem selectedBound16850 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16851 : List Nat := [2,4,8,16,32,16,128,5,137,1024,2048,2048,1053,2048,2080,1214,2048,2048,2068,2081,2049,3092,3076,3231,1173,16,2048,1045,1045,2048,2068,0,3089,33,2049,137]

theorem envBound16851 : H12AffineFastState.Bounded env16851 := by
  intro p hp
  have h : env16851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16850_16851 : H12AffineEnvironment.transform 31 0 env16850 = env16851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 0 env16850 == env16851) = true)

theorem identity16851 : scanCanonicalize (H12AffineFastState.compose env16851 (packedSelected [2,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 1180) := by decide +kernel

theorem selectedBound16851 : packedSelected [2,3,4] rootPS < 2^1333 := by decide +kernel

def env16852 : List Nat := [2,4,8,16,32,16,128,5,137,1024,1180,1180,1053,1180,1212,1214,1180,1180,1160,1213,1181,136,152,3,1173,16,1180,1045,1045,1180,1160,0,141,33,1181,137]

theorem envBound16852 : H12AffineFastState.Bounded env16852 := by
  intro p hp
  have h : env16852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16851_16852 : H12AffineEnvironment.transform 10 1180 env16851 = env16852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1180 env16851 == env16852) = true)

def env16853 : List Nat := [2,4,8,0,32,0,128,5,137,1024,1164,1164,1037,1164,1196,1198,1164,1164,1160,1197,1165,136,136,3,1157,0,1164,1029,1029,1164,1160,0,141,33,1165,137]

theorem envBound16853 : H12AffineFastState.Bounded env16853 := by
  intro p hp
  have h : env16853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16852_16853 : H12AffineEnvironment.transform 3 0 env16852 = env16853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env16852 == env16853) = true)

theorem identity16853 : scanCanonicalize (H12AffineFastState.compose env16853 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound16853 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16854 : List Nat := [2,4,8,0,32,0,41,5,32,1024,1061,1061,1037,1061,1029,1031,1061,1061,1057,1028,1060,33,33,3,1068,0,1061,1029,1029,1061,1057,0,36,33,1060,32]

theorem envBound16854 : H12AffineFastState.Bounded env16854 := by
  intro p hp
  have h : env16854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16853_16854 : H12AffineEnvironment.transform 6 41 env16853 = env16854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env16853 == env16854) = true)

theorem identity16854 : scanCanonicalize (H12AffineFastState.compose env16854 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound16854 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16855 : List Nat := [2,4,8,0,1,0,8,5,1,1024,1028,1028,1037,1028,1029,1031,1028,1028,1024,1028,1029,0,0,3,1037,0,1028,1029,1029,1028,1024,0,5,0,1029,1]

theorem envBound16855 : H12AffineFastState.Bounded env16855 := by
  intro p hp
  have h : env16855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16854_16855 : H12AffineEnvironment.transform 4 1 env16854 = env16855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env16854 == env16855) = true)

def leafEnv16855 : List Nat := [2,4,8,0,1,0,8,5,1,1024,1028,1028,1037,1028,1029,1031,1028,1028,1024,1028,1029,0,0,3,1024,1037,1,0,1028,1029,1029,1028,1024,0,5,0,4,1030,1029,1,0,1028,1]

def active16855 : List Nat := [0,1,2,9]

def tree16855 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16855 : H12WitnessSearch.Good tree16855 := H12GlobalWitnessIndex.good

theorem leafIdentity16855 : H12AffineFastState.composeSystem env16855 rootObs = leafEnv16855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16855 rootObs == leafEnv16855) = true)

theorem terminalChecked16855 : H12PackedTerminal.terminalCheckFast leafEnv16855 active16855 tree16855 = true := by decide +kernel

def env16856 : List Nat := [2,4,8,1,32,1,128,5,137,1024,1165,1165,1036,1165,1197,1199,1165,1165,1160,1196,1164,136,137,3,1156,1,1165,1028,1028,1165,1160,0,141,33,1164,137]

theorem envBound16856 : H12AffineFastState.Bounded env16856 := by
  intro p hp
  have h : env16856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16852_16856 : H12AffineEnvironment.transform 3 1 env16852 = env16856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env16852 == env16856) = true)

theorem identity16856 : scanCanonicalize (H12AffineFastState.compose env16856 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound16856 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16857 : List Nat := [2,4,8,1,1,1,128,5,137,1024,1165,1165,1036,1165,1164,1166,1165,1165,1160,1165,1164,136,137,3,1156,1,1165,1028,1028,1165,1160,0,141,0,1164,137]

theorem envBound16857 : H12AffineFastState.Bounded env16857 := by
  intro p hp
  have h : env16857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16856_16857 : H12AffineEnvironment.transform 4 1 env16856 = env16857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env16856 == env16857) = true)

theorem identity16857 : scanCanonicalize (H12AffineFastState.compose env16857 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound16857 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16858 : List Nat := [2,4,8,1,1,1,8,5,1,1024,1029,1029,1036,1029,1028,1030,1029,1029,1024,1029,1028,0,1,3,1036,1,1029,1028,1028,1029,1024,0,5,0,1028,1]

theorem envBound16858 : H12AffineFastState.Bounded env16858 := by
  intro p hp
  have h : env16858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16857_16858 : H12AffineEnvironment.transform 6 8 env16857 = env16858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env16857 == env16858) = true)

def leafEnv16858 : List Nat := [2,4,8,1,1,1,8,5,1,1024,1029,1029,1036,1029,1028,1030,1029,1029,1024,1029,1028,0,1,3,1024,1036,1,1,1029,1028,1028,1029,1024,0,5,0,4,1031,1028,1,0,1029,1]

def active16858 : List Nat := [0,1,2,9]

def tree16858 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16858 : H12WitnessSearch.Good tree16858 := H12GlobalWitnessIndex.good

theorem leafIdentity16858 : H12AffineFastState.composeSystem env16858 rootObs = leafEnv16858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16858 rootObs == leafEnv16858) = true)

theorem terminalChecked16858 : H12PackedTerminal.terminalCheckFast leafEnv16858 active16858 tree16858 = true := by decide +kernel

def env16859 : List Nat := [2,4,8,16,32,16,128,5,137,1024,2048,2049,1052,2049,2080,1215,2049,2048,2069,2081,2048,3093,3077,3230,1172,16,2048,1045,1045,2048,2069,4294967296,3088,4294967329,2048,137]

theorem envBound16859 : H12AffineFastState.Bounded env16859 := by
  intro p hp
  have h : env16859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16849_16859 : H12AffineEnvironment.transform 11 2049 env16849 = env16859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2049 env16849 == env16859) = true)

theorem identity16859 : scanCanonicalize (H12AffineFastState.compose env16859 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 3093) := by decide +kernel

theorem selectedBound16859 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16860 : List Nat := [2,4,8,16,32,16,128,5,137,1024,2048,2049,1052,2049,2080,1215,2049,2048,2069,2081,2048,3093,3077,3230,1172,16,2048,1045,1045,2048,2069,3093,3088,3124,2048,137]

theorem envBound16860 : H12AffineFastState.Bounded env16860 := by
  intro p hp
  have h : env16860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16859_16860 : H12AffineEnvironment.transform 31 3093 env16859 = env16860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 3093 env16859 == env16860) = true)

theorem identity16860 : scanCanonicalize (H12AffineFastState.compose env16860 (packedSelected [2,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound16860 : packedSelected [2,3,4] rootPS < 2^1333 := by decide +kernel

def env16861 : List Nat := [2,4,8,16,32,16,8,5,1,1024,2048,2049,1052,2049,2080,1079,2049,2048,2069,2081,2048,3093,3077,3094,1052,16,2048,1045,1045,2048,2069,3093,3088,3124,2048,1]

theorem envBound16861 : H12AffineFastState.Bounded env16861 := by
  intro p hp
  have h : env16861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16860_16861 : H12AffineEnvironment.transform 6 8 env16860 = env16861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env16860 == env16861) = true)

def env16862 : List Nat := [2,4,8,16,16,16,8,5,1,1024,2048,2049,1052,2049,2064,1031,2049,2048,2069,2065,2048,3093,3077,3094,1052,16,2048,1045,1045,2048,2069,3093,3088,3076,2048,1]

theorem envBound16862 : H12AffineFastState.Bounded env16862 := by
  intro p hp
  have h : env16862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16861_16862 : H12AffineEnvironment.transform 4 16 env16861 = env16862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env16861 == env16862) = true)

theorem identity16862 : scanCanonicalize (H12AffineFastState.compose env16862 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1028) := by decide +kernel

theorem selectedBound16862 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16863 : List Nat := [2,4,8,16,16,16,8,5,1,1024,1028,1029,1052,1029,1044,1031,1029,1028,1041,1045,1028,17,1,18,1052,16,1028,1045,1045,1028,1041,17,20,0,1028,1]

theorem envBound16863 : H12AffineFastState.Bounded env16863 := by
  intro p hp
  have h : env16863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16862_16863 : H12AffineEnvironment.transform 10 1028 env16862 = env16863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1028 env16862 == env16863) = true)

theorem identity16863 : scanCanonicalize (H12AffineFastState.compose env16863 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound16863 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16864 : List Nat := [2,4,8,1,1,1,8,5,1,1024,1028,1029,1037,1029,1029,1031,1029,1028,1024,1028,1028,0,1,3,1037,1,1028,1028,1028,1028,1024,0,5,0,1028,1]

theorem envBound16864 : H12AffineFastState.Bounded env16864 := by
  intro p hp
  have h : env16864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16863_16864 : H12AffineEnvironment.transform 3 1 env16863 = env16864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env16863 == env16864) = true)

def leafEnv16864 : List Nat := [2,4,8,1,1,1,8,5,1,1024,1028,1029,1037,1029,1029,1031,1029,1028,1024,1028,1028,0,1,3,1024,1037,1,1,1028,1028,1028,1028,1024,0,5,0,4,1030,1028,1,0,1029,1]

def active16864 : List Nat := [0,1,2,9]

def tree16864 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16864 : H12WitnessSearch.Good tree16864 := H12GlobalWitnessIndex.good

theorem leafIdentity16864 : H12AffineFastState.composeSystem env16864 rootObs = leafEnv16864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16864 rootObs == leafEnv16864) = true)

theorem terminalChecked16864 : H12PackedTerminal.terminalCheckFast leafEnv16864 active16864 tree16864 = true := by decide +kernel

def env16865 : List Nat := [2,4,8,16,17,16,8,5,1,1024,2048,2049,1052,2049,2065,1030,2049,2048,2069,2064,2048,3093,3077,3094,1052,16,2048,1045,1045,2048,2069,3093,3088,3077,2048,1]

theorem envBound16865 : H12AffineFastState.Bounded env16865 := by
  intro p hp
  have h : env16865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16861_16865 : H12AffineEnvironment.transform 4 17 env16861 = env16865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env16861 == env16865) = true)

theorem identity16865 : scanCanonicalize (H12AffineFastState.compose env16865 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound16865 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16866 : List Nat := [2,4,8,0,1,0,8,5,1,1024,2048,2049,1036,2049,2049,1030,2049,2048,2053,2048,2048,3077,3077,3078,1036,0,2048,1029,1029,2048,2053,3077,3072,3077,2048,1]

theorem envBound16866 : H12AffineFastState.Bounded env16866 := by
  intro p hp
  have h : env16866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16865_16866 : H12AffineEnvironment.transform 3 0 env16865 = env16866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env16865 == env16866) = true)

theorem identity16866 : scanCanonicalize (H12AffineFastState.compose env16866 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1029) := by decide +kernel

theorem selectedBound16866 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16867 : List Nat := [2,4,8,0,1,0,8,5,1,1024,1029,1028,1036,1028,1028,1030,1028,1029,1024,1029,1029,0,0,3,1036,0,1029,1029,1029,1029,1024,0,5,0,1029,1]

theorem envBound16867 : H12AffineFastState.Bounded env16867 := by
  intro p hp
  have h : env16867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16866_16867 : H12AffineEnvironment.transform 10 1029 env16866 = env16867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1029 env16866 == env16867) = true)

def leafEnv16867 : List Nat := [2,4,8,0,1,0,8,5,1,1024,1029,1028,1036,1028,1028,1030,1028,1029,1024,1029,1029,0,0,3,1024,1036,1,0,1029,1029,1029,1029,1024,0,5,0,4,1031,1029,1,0,1028,1]

def active16867 : List Nat := [0,1,2,9]

def tree16867 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16867 : H12WitnessSearch.Good tree16867 := H12GlobalWitnessIndex.good

theorem leafIdentity16867 : H12AffineFastState.composeSystem env16867 rootObs = leafEnv16867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16867 rootObs == leafEnv16867) = true)

theorem terminalChecked16867 : H12PackedTerminal.terminalCheckFast leafEnv16867 active16867 tree16867 = true := by decide +kernel

def env16868 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,4096,7449,4096,2081,65536,4356,2308,4117,2080,4097,5392,5377,67877,7569,276,2308,1044,1296,2048,4368,4294967296,5397,4295040159,4357,137]

theorem envBound16868 : H12AffineFastState.Bounded env16868 := by
  intro p hp
  have h : env16868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16846_16868 : H12AffineEnvironment.transform 12 7449 env16846 = env16868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7449 env16846 == env16868) = true)

theorem identity16868 : scanCanonicalize (H12AffineFastState.compose env16868 (packedSelected [3,10] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound16868 : packedSelected [3,10] rootPS < 2^1333 := by decide +kernel

def env16869 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1297,2056,1297,2081,65536,1045,2308,1284,2080,1296,1,16,67877,2176,276,2308,1044,1296,2048,1025,4294967296,4,4295035278,1044,137]

theorem envBound16869 : H12AffineFastState.Bounded env16869 := by
  intro p hp
  have h : env16869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16868_16869 : H12AffineEnvironment.transform 11 1297 env16868 = env16869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env16868 == env16869) = true)

def env16870 : List Nat := [2,4,8,16,32,16,128,4,137,1024,2048,1045,2056,1045,2081,65536,1045,2048,1024,2080,1044,1,16,67617,2176,16,2048,1044,1044,2048,1025,4294967296,4,4295035018,1044,137]

theorem envBound16870 : H12AffineFastState.Bounded env16870 := by
  intro p hp
  have h : env16870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16869_16870 : H12AffineEnvironment.transform 7 4 env16869 = env16870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env16869 == env16870) = true)

theorem identity16870 : scanCanonicalize (H12AffineFastState.compose env16870 (packedSelected [1,3] rootPS)) = affineNative (2^(15+1) ^^^ 2218) := by decide +kernel

theorem selectedBound16870 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env16871 : List Nat := [2,4,8,16,32,16,128,4,137,1024,2048,1045,2056,1045,2081,2218,1045,2048,1024,2080,1044,1,16,139,2176,16,2048,1044,1044,2048,1025,4294967296,4,4294967328,1044,137]

theorem envBound16871 : H12AffineFastState.Bounded env16871 := by
  intro p hp
  have h : env16871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16870_16871 : H12AffineEnvironment.transform 15 2218 env16870 = env16871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2218 env16870 == env16871) = true)

theorem identity16871 : scanCanonicalize (H12AffineFastState.compose env16871 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 1) := by decide +kernel

theorem selectedBound16871 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16872 : List Nat := [2,4,8,16,32,16,128,4,137,1024,2048,1045,2056,1045,2081,2218,1045,2048,1024,2080,1044,1,16,139,2176,16,2048,1044,1044,2048,1025,1,4,33,1044,137]

theorem envBound16872 : H12AffineFastState.Bounded env16872 := by
  intro p hp
  have h : env16872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16871_16872 : H12AffineEnvironment.transform 31 1 env16871 = env16872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1 env16871 == env16872) = true)

theorem identity16872 : scanCanonicalize (H12AffineFastState.compose env16872 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound16872 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16873 : List Nat := [2,4,8,16,32,16,9,4,0,1024,2048,1045,2056,1045,2081,2083,1045,2048,1024,2080,1044,1,16,2,2057,16,2048,1044,1044,2048,1025,1,4,33,1044,0]

theorem envBound16873 : H12AffineFastState.Bounded env16873 := by
  intro p hp
  have h : env16873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16872_16873 : H12AffineEnvironment.transform 6 9 env16872 = env16873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env16872 == env16873) = true)

def env16874 : List Nat := [2,4,8,16,32,16,128,5,137,1024,2048,1044,2056,1044,2081,65536,1045,2049,1025,2080,1045,1,16,67616,2176,17,2049,1044,1045,2048,1025,4294967296,4,4295035019,1044,137]

theorem envBound16874 : H12AffineFastState.Bounded env16874 := by
  intro p hp
  have h : env16874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16869_16874 : H12AffineEnvironment.transform 7 5 env16869 = env16874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env16869 == env16874) = true)

theorem identity16874 : scanCanonicalize (H12AffineFastState.compose env16874 (packedSelected [1,3] rootPS)) = affineNative (2^(31+1) ^^^ 67618) := by decide +kernel

theorem selectedBound16874 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env16875 : List Nat := [2,4,8,16,32,16,128,5,137,1024,2048,1044,2056,1044,2081,65536,1045,2049,1025,2080,1045,1,16,67616,2176,17,2049,1044,1045,2048,1025,67618,4,169,1044,137]

theorem envBound16875 : H12AffineFastState.Bounded env16875 := by
  intro p hp
  have h : env16875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16874_16875 : H12AffineEnvironment.transform 31 67618 env16874 = env16875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 67618 env16874 == env16875) = true)

def env16876 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,25913,65536,31772,25629,11533,25912,4097,10249,17665,91197,8328,27660,25628,14604,1296,2049,31752,4294967296,30733,4295052446,31773,512]

theorem envBound16876 : H12AffineFastState.Bounded env16876 := by
  intro p hp
  have h : env16876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16834_16876 : H12AffineEnvironment.transform 14 25913 env16834 = env16876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25913 env16834 == env16876) = true)

theorem identity16876 : scanCanonicalize (H12AffineFastState.compose env16876 (packedSelected [4,9] rootPS)) = affineNative (2^(12+1) ^^^ 7197) := by decide +kernel

theorem selectedBound16876 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env16877 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,7197,16384,22820,65536,16385,22528,4368,22821,4097,5140,17665,88096,7317,20497,22529,1297,1296,2049,16405,4294967296,17424,4295052446,16384,512]

theorem envBound16877 : H12AffineFastState.Bounded env16877 := by
  intro p hp
  have h : env16877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16876_16877 : H12AffineEnvironment.transform 12 7197 env16876 = env16877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7197 env16876 == env16877) = true)

theorem identity16877 : scanCanonicalize (H12AffineFastState.compose env16877 (packedSelected [3,5,10,15] rootPS)) = affineNative (2^(13+1) ^^^ 4096) := by decide +kernel

theorem selectedBound16877 : packedSelected [3,5,10,15] rootPS < 2^1333 := by decide +kernel

def env16878 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,7197,4096,2340,65536,4097,2048,4368,2341,4097,5140,5377,67616,7317,17,2049,1297,1296,2049,4117,4294967296,5136,4295040158,4096,512]

theorem envBound16878 : H12AffineFastState.Bounded env16878 := by
  intro p hp
  have h : env16878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16877_16878 : H12AffineEnvironment.transform 13 4096 env16877 = env16878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4096 env16877 == env16878) = true)

def env16879 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,2317,1296,2340,65536,1297,2048,1024,2341,1297,260,17,67616,2437,17,2049,1297,1296,2049,1285,4294967296,256,4295035278,1296,512]

theorem envBound16879 : H12AffineFastState.Bounded env16879 := by
  intro p hp
  have h : env16879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16878_16879 : H12AffineEnvironment.transform 11 1296 env16878 = env16879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env16878 == env16879) = true)

theorem identity16879 : scanCanonicalize (H12AffineFastState.compose env16879 (packedSelected [1,3] rootPS)) = affineNative (2^(15+1) ^^^ 2219) := by decide +kernel

theorem selectedBound16879 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env16880 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,2317,1296,2340,2219,1297,2048,1024,2341,1297,260,17,139,2437,17,2049,1297,1296,2049,1285,4294967296,256,4294967589,1296,512]

theorem envBound16880 : H12AffineFastState.Bounded env16880 := by
  intro p hp
  have h : env16880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16879_16880 : H12AffineEnvironment.transform 15 2219 env16879 = env16880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2219 env16879 == env16880) = true)

theorem identity16880 : scanCanonicalize (H12AffineFastState.compose env16880 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 544) := by decide +kernel

theorem selectedBound16880 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16881 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,2317,1296,2340,2219,1297,2048,1024,2341,1297,260,17,139,2437,17,2049,1297,1296,2049,1285,544,256,773,1296,512]

theorem envBound16881 : H12AffineFastState.Bounded env16881 := by
  intro p hp
  have h : env16881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16880_16881 : H12AffineEnvironment.transform 31 544 env16880 = env16881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 544 env16880 == env16881) = true)

theorem identity16881 : scanCanonicalize (H12AffineFastState.compose env16881 (packedSelected [5] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound16881 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env16882 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,2317,1296,2340,2219,1297,2048,1024,2341,1297,260,17,139,2437,17,2049,1297,1296,2049,1285,169,256,396,1296,137]

theorem envBound16882 : H12AffineFastState.Bounded env16882 := by
  intro p hp
  have h : env16882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16881_16882 : H12AffineEnvironment.transform 8 137 env16881 = env16882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env16881 == env16882) = true)

theorem identity16882 : scanCanonicalize (H12AffineFastState.compose env16882 (packedSelected [0,2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound16882 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env16883 : List Nat := [2,4,8,16,32,16,8,256,1,1024,2048,1296,2317,1296,2340,2083,1297,2048,1024,2341,1297,260,17,3,2317,17,2049,1297,1296,2049,1285,33,256,260,1296,1]

theorem envBound16883 : H12AffineFastState.Bounded env16883 := by
  intro p hp
  have h : env16883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16882_16883 : H12AffineEnvironment.transform 6 8 env16882 = env16883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env16882 == env16883) = true)

theorem identity16883 : scanCanonicalize (H12AffineFastState.compose env16883 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound16883 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16884 : List Nat := [2,4,8,16,0,16,8,256,1,1024,2048,1296,2317,1296,2308,2051,1297,2048,1024,2309,1297,260,17,3,2317,17,2049,1297,1296,2049,1285,1,256,260,1296,1]

theorem envBound16884 : H12AffineFastState.Bounded env16884 := by
  intro p hp
  have h : env16884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16883_16884 : H12AffineEnvironment.transform 4 0 env16883 = env16884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env16883 == env16884) = true)

def env16885 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,2316,1297,2340,65536,1296,2048,1025,2341,1296,261,16,67616,2436,17,2049,1297,1296,2049,1284,4294967296,257,4295035279,1297,512]

theorem envBound16885 : H12AffineFastState.Bounded env16885 := by
  intro p hp
  have h : env16885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16878_16885 : H12AffineEnvironment.transform 11 1297 env16878 = env16885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env16878 == env16885) = true)

theorem identity16885 : scanCanonicalize (H12AffineFastState.compose env16885 (packedSelected [1,3] rootPS)) = affineNative (2^(31+1) ^^^ 68527) := by decide +kernel

theorem selectedBound16885 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env16886 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,2316,1297,2340,65536,1296,2048,1025,2341,1296,261,16,67616,2436,17,2049,1297,1296,2049,1284,68527,257,544,1297,512]

theorem envBound16886 : H12AffineFastState.Bounded env16886 := by
  intro p hp
  have h : env16886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16885_16886 : H12AffineEnvironment.transform 31 68527 env16885 = env16886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 68527 env16885 == env16886) = true)

theorem identity16886 : scanCanonicalize (H12AffineFastState.compose env16886 (packedSelected [5] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound16886 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env16887 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,1045,2056,1045,2080,65536,1044,2048,1025,2081,1044,1,16,67616,2176,17,2049,1045,1044,2049,1024,68267,5,544,1045,512]

theorem envBound16887 : H12AffineFastState.Bounded env16887 := by
  intro p hp
  have h : env16887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16886_16887 : H12AffineEnvironment.transform 7 4 env16886 = env16887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env16886 == env16887) = true)

theorem identity16887 : scanCanonicalize (H12AffineFastState.compose env16887 (packedSelected [8] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound16887 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env16888 : List Nat := [2,4,8,16,32,16,128,4,137,1024,2048,1045,2056,1045,2080,65536,1044,2048,1025,2081,1044,1,16,67616,2176,17,2049,1045,1044,2049,1024,67618,5,169,1045,137]

theorem envBound16888 : H12AffineFastState.Bounded env16888 := by
  intro p hp
  have h : env16888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16887_16888 : H12AffineEnvironment.transform 8 137 env16887 = env16888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env16887 == env16888) = true)

theorem identity16888 : scanCanonicalize (H12AffineFastState.compose env16888 (packedSelected [2,4] rootPS)) = affineNative (2^(15+1) ^^^ 2219) := by decide +kernel

theorem selectedBound16888 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env16889 : List Nat := [2,4,8,16,32,16,128,4,137,1024,2048,1045,2056,1045,2080,2219,1044,2048,1025,2081,1044,1,16,139,2176,17,2049,1045,1044,2049,1024,137,5,169,1045,137]

theorem envBound16889 : H12AffineFastState.Bounded env16889 := by
  intro p hp
  have h : env16889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16888_16889 : H12AffineEnvironment.transform 15 2219 env16888 = env16889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2219 env16888 == env16889) = true)

theorem identity16889 : scanCanonicalize (H12AffineFastState.compose env16889 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound16889 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16890 : List Nat := [2,4,8,16,32,16,128,4,137,1024,32,1045,40,1045,0,139,1044,32,1025,1,1044,1,16,139,160,17,33,1045,1044,33,1024,137,5,169,1045,137]

theorem envBound16890 : H12AffineFastState.Bounded env16890 := by
  intro p hp
  have h : env16890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16889_16890 : H12AffineEnvironment.transform 10 32 env16889 = env16890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env16889 == env16890) = true)

theorem identity16890 : scanCanonicalize (H12AffineFastState.compose env16890 (packedSelected [0,2] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound16890 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env16891 : List Nat := [2,4,8,16,32,16,128,4,137,52,32,33,40,33,0,139,32,32,53,1,32,1,16,139,160,17,33,33,32,33,52,137,5,169,33,137]

theorem envBound16891 : H12AffineFastState.Bounded env16891 := by
  intro p hp
  have h : env16891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16890_16891 : H12AffineEnvironment.transform 9 52 env16890 = env16891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env16890 == env16891) = true)

def env16892 : List Nat := [2,4,8,16,0,16,128,4,137,20,0,1,8,1,0,139,0,0,21,1,0,1,16,139,128,17,1,1,0,1,20,137,5,137,1,137]

theorem envBound16892 : H12AffineFastState.Bounded env16892 := by
  intro p hp
  have h : env16892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16891_16892 : H12AffineEnvironment.transform 4 0 env16891 = env16892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env16891 == env16892) = true)

theorem identity16892 : scanCanonicalize (H12AffineFastState.compose env16892 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound16892 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16893 : List Nat := [2,4,8,0,0,0,128,4,137,4,0,1,8,1,0,139,0,0,5,1,0,1,0,139,128,1,1,1,0,1,4,137,5,137,1,137]

theorem envBound16893 : H12AffineFastState.Bounded env16893 := by
  intro p hp
  have h : env16893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16892_16893 : H12AffineEnvironment.transform 3 0 env16892 = env16893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env16892 == env16893) = true)

def leafEnv16893 : List Nat := [2,4,8,0,0,0,128,4,137,4,0,1,8,1,0,139,0,0,5,1,0,1,0,139,4,128,1,1,1,1,0,1,4,137,5,137,4,2,1,137,0,0,1]

def active16893 : List Nat := [0,1,2,6]

def tree16893 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16893 : H12WitnessSearch.Good tree16893 := H12GlobalWitnessIndex.good

theorem leafIdentity16893 : H12AffineFastState.composeSystem env16893 rootObs = leafEnv16893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16893 rootObs == leafEnv16893) = true)

theorem terminalChecked16893 : H12PackedTerminal.terminalCheckFast leafEnv16893 active16893 tree16893 = true := by decide +kernel

def env16894 : List Nat := [2,4,8,16,1,16,128,4,137,21,1,0,9,0,0,139,1,1,20,1,1,1,16,139,129,17,0,0,1,0,21,137,5,136,0,137]

theorem envBound16894 : H12AffineFastState.Bounded env16894 := by
  intro p hp
  have h : env16894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16891_16894 : H12AffineEnvironment.transform 4 1 env16891 = env16894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env16891 == env16894) = true)

theorem identity16894 : scanCanonicalize (H12AffineFastState.compose env16894 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound16894 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16895 : List Nat := [2,4,8,16,1,16,25,4,16,21,1,0,9,0,0,18,1,1,20,1,1,1,16,18,24,17,0,0,1,0,21,16,5,17,0,16]

theorem envBound16895 : H12AffineFastState.Bounded env16895 := by
  intro p hp
  have h : env16895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16894_16895 : H12AffineEnvironment.transform 6 25 env16894 = env16895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env16894 == env16895) = true)

def leafEnv16895 : List Nat := [2,4,8,16,1,16,25,4,16,21,1,0,9,0,0,18,1,1,20,1,1,1,16,18,21,24,1,17,0,0,1,0,21,16,5,17,4,2,0,16,0,1,1]

def active16895 : List Nat := [0,1,2,3]

def tree16895 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16895 : H12WitnessSearch.Good tree16895 := H12GlobalWitnessIndex.good

theorem leafIdentity16895 : H12AffineFastState.composeSystem env16895 rootObs = leafEnv16895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16895 rootObs == leafEnv16895) = true)

theorem terminalChecked16895 : H12PackedTerminal.terminalCheckFast leafEnv16895 active16895 tree16895 = true := by decide +kernel

def env16896 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,4194304,660545,16777216,8328,135185,4982100,529408,676865,1073741824,17420288,4294967296,546049,4315938986,17420308,512]

theorem envBound16896 : H12AffineFastState.Bounded env16896 := by
  intro p hp
  have h : env16896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16774_16896 : H12AffineEnvironment.transform 22 660545 env16774 = env16896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 660545 env16774 == env16896) = true)

def env16897 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4096,32768,65536,131072,262144,524288,32769,4097,4194304,660545,16777216,8328,135185,4982100,529408,656385,1073741824,17399808,4294967296,525569,4315938986,17399828,512]

theorem envBound16897 : H12AffineFastState.Bounded env16897 := by
  intro p hp
  have h : env16897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16896_16897 : H12AffineEnvironment.transform 13 4096 env16896 = env16897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4096 env16896 == env16897) = true)

end H12CloudChart2