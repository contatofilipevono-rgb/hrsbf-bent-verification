import H12CloudChart2Data054

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans13455_13456 : H12AffineEnvironment.transform 8 0 env13455 = env13456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env13455 == env13456) = true)

def leafEnv13456 : List Nat := [2,4,8,16,32,16,8,4,0,20,32,0,9,0,1,65536,0,1,20,0,0,0,16,65536,20,9,1,16,1,0,0,32,20,65570,4,0,4,2,0,0,0,0,1]

def active13456 : List Nat := [0,1,2,3,4,15]

def tree13456 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13456 : H12WitnessSearch.Good tree13456 := H12GlobalWitnessIndex.good

theorem leafIdentity13456 : H12AffineFastState.composeSystem env13456 rootObs = leafEnv13456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13456 rootObs == leafEnv13456) = true)

theorem terminalChecked13456 : H12PackedTerminal.terminalCheckFast leafEnv13456 active13456 tree13456 = true := by decide +kernel

def env13457 : List Nat := [2,4,8,16,32,16,8,4,1,20,33,0,9,0,1,65536,0,0,20,0,0,1,16,65536,9,16,1,0,0,32,20,65571,4,0,0,1]

theorem envBound13457 : H12AffineFastState.Bounded env13457 := by
  intro p hp
  have h : env13457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13455_13457 : H12AffineEnvironment.transform 8 1 env13455 = env13457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env13455 == env13457) = true)

theorem identity13457 : scanCanonicalize (H12AffineFastState.compose env13457 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound13457 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13458 : List Nat := [2,4,8,16,1,16,8,4,1,20,0,0,9,0,1,65536,0,0,20,0,0,1,16,65536,9,16,1,0,0,1,20,65538,4,0,0,1]

theorem envBound13458 : H12AffineFastState.Bounded env13458 := by
  intro p hp
  have h : env13458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13457_13458 : H12AffineEnvironment.transform 4 1 env13457 = env13458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13457 == env13458) = true)

theorem identity13458 : scanCanonicalize (H12AffineFastState.compose env13458 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 3) := by decide +kernel

theorem selectedBound13458 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13459 : List Nat := [2,4,8,16,1,16,8,4,1,20,0,0,9,0,1,3,0,0,20,0,0,1,16,3,9,16,1,0,0,1,20,1,4,0,0,1]

theorem envBound13459 : H12AffineFastState.Bounded env13459 := by
  intro p hp
  have h : env13459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13458_13459 : H12AffineEnvironment.transform 15 3 env13458 = env13459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3 env13458 == env13459) = true)

def leafEnv13459 : List Nat := [2,4,8,16,1,16,8,4,1,20,0,0,9,0,1,3,0,0,20,0,0,1,16,3,20,9,1,16,1,0,0,1,20,1,4,0,4,2,0,1,0,0,1]

def active13459 : List Nat := [0,1,2,3]

def tree13459 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13459 : H12WitnessSearch.Good tree13459 := H12GlobalWitnessIndex.good

theorem leafIdentity13459 : H12AffineFastState.composeSystem env13459 rootObs = leafEnv13459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13459 rootObs == leafEnv13459) = true)

theorem terminalChecked13459 : H12PackedTerminal.terminalCheckFast leafEnv13459 active13459 tree13459 = true := by decide +kernel

def env13460 : List Nat := [2,4,8,16,32,16,128,4,512,20,2048,0,9,0,1,65536,0,513,20,0,0,513,16,65536,129,16,0,0,0,1073741824,20,66219,4,0,0,512]

theorem envBound13460 : H12AffineFastState.Bounded env13460 := by
  intro p hp
  have h : env13460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13451_13460 : H12AffineEnvironment.transform 21 513 env13451 = env13460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 513 env13451 == env13460) = true)

def env13461 : List Nat := [2,4,8,16,32,16,128,5,512,21,2048,0,9,0,0,65536,0,513,21,1,0,4194304,16,65536,129,16,4194816,0,0,1073741824,20,4260010,5,0,0,512]

theorem envBound13461 : H12AffineFastState.Bounded env13461 := by
  intro p hp
  have h : env13461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13450_13461 : H12AffineEnvironment.transform 7 5 env13450 = env13461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env13450 == env13461) = true)

def env13462 : List Nat := [2,4,8,16,32,16,128,5,512,21,2048,0,9,0,0,65536,0,513,21,1,0,512,16,65536,129,16,0,0,0,1073741824,20,66218,5,0,0,512]

theorem envBound13462 : H12AffineFastState.Bounded env13462 := by
  intro p hp
  have h : env13462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13461_13462 : H12AffineEnvironment.transform 21 512 env13461 = env13462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 512 env13461 == env13462) = true)

theorem identity13462 : scanCanonicalize (H12AffineFastState.compose env13462 (packedSelected [7] rootPS)) = affineNative (2^(29+1) ^^^ 67723) := by decide +kernel

theorem selectedBound13462 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env13463 : List Nat := [2,4,8,16,32,16,128,5,512,21,2048,0,9,0,0,65536,0,513,21,1,0,512,16,65536,129,16,0,0,0,67723,20,66218,5,0,0,512]

theorem envBound13463 : H12AffineFastState.Bounded env13463 := by
  intro p hp
  have h : env13463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13462_13463 : H12AffineEnvironment.transform 29 67723 env13462 = env13463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 67723 env13462 == env13463) = true)

def env13464 : List Nat := [2,4,8,16,32,16,128,5,512,21,0,0,9,0,0,65536,0,513,21,1,0,512,16,65536,129,16,0,0,0,65675,20,66218,5,0,0,512]

theorem envBound13464 : H12AffineFastState.Bounded env13464 := by
  intro p hp
  have h : env13464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13463_13464 : H12AffineEnvironment.transform 10 0 env13463 = env13464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env13463 == env13464) = true)

theorem identity13464 : scanCanonicalize (H12AffineFastState.compose env13464 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 682) := by decide +kernel

theorem selectedBound13464 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13465 : List Nat := [2,4,8,16,32,16,128,5,512,21,0,0,9,0,0,682,0,513,21,1,0,512,16,682,129,16,0,0,0,545,20,0,5,0,0,512]

theorem envBound13465 : H12AffineFastState.Bounded env13465 := by
  intro p hp
  have h : env13465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13464_13465 : H12AffineEnvironment.transform 15 682 env13464 = env13465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 682 env13464 == env13465) = true)

theorem identity13465 : scanCanonicalize (H12AffineFastState.compose env13465 (packedSelected [4,9] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound13465 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env13466 : List Nat := [2,4,8,16,32,16,128,5,1,21,0,0,9,0,0,171,0,0,21,1,0,1,16,171,129,16,0,0,0,32,20,0,5,0,0,1]

theorem envBound13466 : H12AffineFastState.Bounded env13466 := by
  intro p hp
  have h : env13466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13465_13466 : H12AffineEnvironment.transform 8 1 env13465 = env13466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env13465 == env13466) = true)

def env13467 : List Nat := [2,4,8,16,32,16,128,5,512,21,1,0,9,0,0,65536,0,513,21,1,0,512,16,65536,129,16,0,0,0,65674,20,66218,5,0,0,512]

theorem envBound13467 : H12AffineFastState.Bounded env13467 := by
  intro p hp
  have h : env13467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13463_13467 : H12AffineEnvironment.transform 10 1 env13463 = env13467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env13463 == env13467) = true)

theorem identity13467 : scanCanonicalize (H12AffineFastState.compose env13467 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound13467 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13468 : List Nat := [2,4,8,16,32,16,128,5,32,21,1,0,9,0,0,65536,0,33,21,1,0,32,16,65536,129,16,0,0,0,65674,20,65674,5,0,0,32]

theorem envBound13468 : H12AffineFastState.Bounded env13468 := by
  intro p hp
  have h : env13468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13467_13468 : H12AffineEnvironment.transform 8 32 env13467 = env13468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env13467 == env13468) = true)

theorem identity13468 : scanCanonicalize (H12AffineFastState.compose env13468 (packedSelected [11] rootPS)) = affineNative (2^(15+1) ^^^ 170) := by decide +kernel

theorem selectedBound13468 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env13469 : List Nat := [2,4,8,16,32,16,128,5,32,21,1,0,9,0,0,170,0,33,21,1,0,32,16,170,129,16,0,0,0,32,20,32,5,0,0,32]

theorem envBound13469 : H12AffineFastState.Bounded env13469 := by
  intro p hp
  have h : env13469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13468_13469 : H12AffineEnvironment.transform 15 170 env13468 = env13469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 170 env13468 == env13469) = true)

theorem identity13469 : scanCanonicalize (H12AffineFastState.compose env13469 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound13469 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env13470 : List Nat := [2,4,8,16,1,16,128,5,1,21,1,0,9,0,0,139,0,0,21,1,0,1,16,139,129,16,0,0,0,1,20,1,5,0,0,1]

theorem envBound13470 : H12AffineFastState.Bounded env13470 := by
  intro p hp
  have h : env13470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13469_13470 : H12AffineEnvironment.transform 4 1 env13469 = env13470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13469 == env13470) = true)

def leafEnv13470 : List Nat := [2,4,8,16,1,16,128,5,1,21,1,0,9,0,0,139,0,0,21,1,0,1,16,139,20,129,1,16,0,0,0,1,20,1,5,0,4,2,0,1,0,0,1]

def active13470 : List Nat := [0,1,2,3,6]

def tree13470 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13470 : H12WitnessSearch.Good tree13470 := H12GlobalWitnessIndex.good

theorem leafIdentity13470 : H12AffineFastState.composeSystem env13470 rootObs = leafEnv13470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13470 rootObs == leafEnv13470) = true)

theorem terminalChecked13470 : H12PackedTerminal.terminalCheckFast leafEnv13470 active13470 tree13470 = true := by decide +kernel

def env13471 : List Nat := [2,4,8,16,32,16,128,5,512,21,2048,0,9,0,0,65536,0,513,21,1,0,513,16,65536,129,16,1,0,0,1073741824,20,66219,5,0,0,512]

theorem envBound13471 : H12AffineFastState.Bounded env13471 := by
  intro p hp
  have h : env13471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13461_13471 : H12AffineEnvironment.transform 21 513 env13461 = env13471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 513 env13461 == env13471) = true)

theorem identity13471 : scanCanonicalize (H12AffineFastState.compose env13471 (packedSelected [7] rootPS)) = affineNative (2^(29+1) ^^^ 67586) := by decide +kernel

theorem selectedBound13471 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env13472 : List Nat := [2,4,8,16,32,16,128,5,512,21,2048,0,9,0,0,65536,0,513,21,1,0,513,16,65536,129,16,1,0,0,67586,20,66219,5,0,0,512]

theorem envBound13472 : H12AffineFastState.Bounded env13472 := by
  intro p hp
  have h : env13472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13471_13472 : H12AffineEnvironment.transform 29 67586 env13471 = env13472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 67586 env13471 == env13472) = true)

def env13473 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,8192,1,32768,65536,1,513,273,32769,1,4194304,16,98565,8328,16,4195077,1,1,1073741824,21,4294967296,256,4299260335,1,512]

theorem envBound13473 : H12AffineFastState.Bounded env13473 := by
  intro p hp
  have h : env13473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13348_13473 : H12AffineEnvironment.transform 9 273 env13348 = env13473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env13348 == env13473) = true)

theorem identity13473 : scanCanonicalize (H12AffineFastState.compose env13473 (packedSelected [1] rootPS)) = affineNative (2^(29+1) ^^^ 4268706) := by decide +kernel

theorem selectedBound13473 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13474 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,8192,1,32768,65536,1,513,273,32769,1,4194304,16,98565,8328,16,4195077,1,1,4268706,21,4294967296,256,4299260335,1,512]

theorem envBound13474 : H12AffineFastState.Bounded env13474 := by
  intro p hp
  have h : env13474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13473_13474 : H12AffineEnvironment.transform 29 4268706 env13473 = env13474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4268706 env13473 == env13474) = true)

theorem identity13474 : scanCanonicalize (H12AffineFastState.compose env13474 (packedSelected [3] rootPS)) = affineNative (2^(15+1) ^^^ 11174) := by decide +kernel

theorem selectedBound13474 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env13475 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,8192,1,32768,11174,1,513,273,32769,1,4194304,16,43683,8328,16,4195077,1,1,4196612,21,4294967296,256,4299205129,1,512]

theorem envBound13475 : H12AffineFastState.Bounded env13475 := by
  intro p hp
  have h : env13475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13474_13475 : H12AffineEnvironment.transform 15 11174 env13474 = env13475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 11174 env13474 == env13475) = true)

theorem identity13475 : scanCanonicalize (H12AffineFastState.compose env13475 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 10792) := by decide +kernel

theorem selectedBound13475 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env13476 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,8192,1,10792,11174,1,513,273,10793,1,4194304,16,139,8328,16,4195077,1,1,4196612,21,4294967296,256,4299161633,1,512]

theorem envBound13476 : H12AffineFastState.Bounded env13476 := by
  intro p hp
  have h : env13476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13475_13476 : H12AffineEnvironment.transform 14 10792 env13475 = env13476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 10792 env13475 == env13476) = true)

def env13477 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,8192,1,10792,11174,1,513,273,10793,1,2728,16,139,8328,16,2477,1,1,940,21,4294967296,256,4294969993,1,512]

theorem envBound13477 : H12AffineFastState.Bounded env13477 := by
  intro p hp
  have h : env13477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13476_13477 : H12AffineEnvironment.transform 21 2728 env13476 = env13477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2728 env13476 == env13477) = true)

theorem identity13477 : scanCanonicalize (H12AffineFastState.compose env13477 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 429) := by decide +kernel

theorem selectedBound13477 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env13478 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,8192,1,10792,11174,1,513,273,10793,1,2728,16,139,8328,16,2477,1,1,940,21,429,256,2852,1,512]

theorem envBound13478 : H12AffineFastState.Bounded env13478 := by
  intro p hp
  have h : env13478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13477_13478 : H12AffineEnvironment.transform 31 429 env13477 = env13478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 429 env13477 == env13478) = true)

def env13479 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,672,1,2184,2310,1,513,273,2185,1,2728,16,139,552,16,2477,1,1,940,21,429,256,2852,1,512]

theorem envBound13479 : H12AffineFastState.Bounded env13479 := by
  intro p hp
  have h : env13479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13478_13479 : H12AffineEnvironment.transform 12 672 env13478 = env13479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 672 env13478 == env13479) = true)

def env13480 : List Nat := [2,4,8,16,32,16,128,256,136,273,2048,1,40,1,2184,2310,1,137,273,2185,1,2080,16,139,160,16,2477,1,1,292,21,429,256,2476,1,136]

theorem envBound13480 : H12AffineFastState.Bounded env13480 := by
  intro p hp
  have h : env13480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13479_13480 : H12AffineEnvironment.transform 8 136 env13479 = env13480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env13479 == env13480) = true)

theorem identity13480 : scanCanonicalize (H12AffineFastState.compose env13480 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound13480 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13481 : List Nat := [2,4,8,16,32,16,128,173,136,188,2048,1,40,1,2184,2219,1,137,188,2185,1,2080,16,139,160,16,2048,1,1,137,21,0,173,2049,1,136]

theorem envBound13481 : H12AffineFastState.Bounded env13481 := by
  intro p hp
  have h : env13481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13480_13481 : H12AffineEnvironment.transform 7 173 env13480 = env13481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env13480 == env13481) = true)

theorem identity13481 : scanCanonicalize (H12AffineFastState.compose env13481 (packedSelected [7] rootPS)) = affineNative (2^(10+1) ^^^ 137) := by decide +kernel

theorem selectedBound13481 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env13482 : List Nat := [2,4,8,16,32,16,128,173,136,188,137,1,40,1,1,34,1,137,188,0,1,169,16,139,160,16,137,1,1,137,21,0,173,136,1,136]

theorem envBound13482 : H12AffineFastState.Bounded env13482 := by
  intro p hp
  have h : env13482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13481_13482 : H12AffineEnvironment.transform 10 137 env13481 = env13482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 137 env13481 == env13482) = true)

def env13483 : List Nat := [2,4,8,16,0,16,128,141,136,156,137,1,8,1,1,2,1,137,156,0,1,137,16,139,128,16,137,1,1,137,21,0,141,136,1,136]

theorem envBound13483 : H12AffineFastState.Bounded env13483 := by
  intro p hp
  have h : env13483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13482_13483 : H12AffineEnvironment.transform 4 0 env13482 = env13483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13482 == env13483) = true)

theorem identity13483 : scanCanonicalize (H12AffineFastState.compose env13483 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound13483 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13484 : List Nat := [2,4,8,16,0,16,8,5,0,20,1,1,8,1,1,2,1,1,20,0,1,1,16,3,8,16,1,1,1,1,21,0,5,0,1,0]

theorem envBound13484 : H12AffineFastState.Bounded env13484 := by
  intro p hp
  have h : env13484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13483_13484 : H12AffineEnvironment.transform 6 8 env13483 = env13484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13483 == env13484) = true)

def leafEnv13484 : List Nat := [2,4,8,16,0,16,8,5,0,20,1,1,8,1,1,2,1,1,20,0,1,1,16,3,21,8,1,16,1,1,1,1,21,0,5,0,4,3,1,0,0,1,1]

def active13484 : List Nat := [0,1,2,3]

def tree13484 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13484 : H12WitnessSearch.Good tree13484 := H12GlobalWitnessIndex.good

theorem leafIdentity13484 : H12AffineFastState.composeSystem env13484 rootObs = leafEnv13484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13484 rootObs == leafEnv13484) = true)

theorem terminalChecked13484 : H12PackedTerminal.terminalCheckFast leafEnv13484 active13484 tree13484 = true := by decide +kernel

def env13485 : List Nat := [2,4,8,16,1,16,128,140,136,157,137,1,9,1,1,3,1,137,157,0,1,136,16,139,129,16,137,1,1,137,21,0,140,136,1,136]

theorem envBound13485 : H12AffineFastState.Bounded env13485 := by
  intro p hp
  have h : env13485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13482_13485 : H12AffineEnvironment.transform 4 1 env13482 = env13485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13482 == env13485) = true)

def leafEnv13485 : List Nat := [2,4,8,16,1,16,128,140,136,157,137,1,9,1,1,3,1,137,157,0,1,136,16,139,21,129,1,16,137,1,1,137,21,0,140,136,4,138,1,136,0,1,1]

def active13485 : List Nat := [0,1,2,3,6]

def tree13485 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13485 : H12WitnessSearch.Good tree13485 := H12GlobalWitnessIndex.good

theorem leafIdentity13485 : H12AffineFastState.composeSystem env13485 rootObs = leafEnv13485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13485 rootObs == leafEnv13485) = true)

theorem terminalChecked13485 : H12PackedTerminal.terminalCheckFast leafEnv13485 active13485 tree13485 = true := by decide +kernel

def env13486 : List Nat := [2,4,8,16,32,16,128,256,137,273,2048,1,41,1,2184,2310,1,136,273,2185,1,2081,16,139,161,16,2477,1,1,293,21,429,256,2477,1,137]

theorem envBound13486 : H12AffineFastState.Bounded env13486 := by
  intro p hp
  have h : env13486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13479_13486 : H12AffineEnvironment.transform 8 137 env13479 = env13486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env13479 == env13486) = true)

theorem identity13486 : scanCanonicalize (H12AffineFastState.compose env13486 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound13486 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13487 : List Nat := [2,4,8,16,32,16,128,256,137,273,0,1,41,1,136,262,1,136,273,137,1,33,16,139,161,16,429,1,1,293,21,429,256,429,1,137]

theorem envBound13487 : H12AffineFastState.Bounded env13487 := by
  intro p hp
  have h : env13487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13486_13487 : H12AffineEnvironment.transform 10 0 env13486 = env13487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env13486 == env13487) = true)

def env13488 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,673,1,2185,2311,1,513,273,2184,1,2728,16,139,553,16,2477,1,1,940,21,429,256,2852,1,512]

theorem envBound13488 : H12AffineFastState.Bounded env13488 := by
  intro p hp
  have h : env13488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13478_13488 : H12AffineEnvironment.transform 12 673 env13478 = env13488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 673 env13478 == env13488) = true)

theorem identity13488 : scanCanonicalize (H12AffineFastState.compose env13488 (packedSelected [0,2,4] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound13488 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env13489 : List Nat := [2,4,8,16,32,16,128,172,512,189,2048,1,673,1,2185,2219,1,513,189,2184,1,2728,16,139,553,16,2049,1,1,512,21,1,172,2696,1,512]

theorem envBound13489 : H12AffineFastState.Bounded env13489 := by
  intro p hp
  have h : env13489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13488_13489 : H12AffineEnvironment.transform 7 172 env13488 = env13489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env13488 == env13489) = true)

def env13490 : List Nat := [2,4,8,16,32,16,128,172,512,189,0,1,673,1,137,171,1,513,189,136,1,680,16,139,553,16,1,1,1,512,21,1,172,648,1,512]

theorem envBound13490 : H12AffineFastState.Bounded env13490 := by
  intro p hp
  have h : env13490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13489_13490 : H12AffineEnvironment.transform 10 0 env13489 = env13490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env13489 == env13490) = true)

theorem identity13490 : scanCanonicalize (H12AffineFastState.compose env13490 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound13490 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13491 : List Nat := [2,4,8,16,32,16,8,36,512,53,0,1,553,1,1,35,1,513,53,0,1,544,16,3,553,16,1,1,1,512,21,1,36,512,1,512]

theorem envBound13491 : H12AffineFastState.Bounded env13491 := by
  intro p hp
  have h : env13491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13490_13491 : H12AffineEnvironment.transform 6 8 env13490 = env13491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13490 == env13491) = true)

def env13492 : List Nat := [2,4,8,16,32,16,8,36,0,53,0,1,41,1,1,35,1,1,53,0,1,32,16,3,41,16,1,1,1,0,21,1,36,0,1,0]

theorem envBound13492 : H12AffineFastState.Bounded env13492 := by
  intro p hp
  have h : env13492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13491_13492 : H12AffineEnvironment.transform 8 0 env13491 = env13492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env13491 == env13492) = true)

theorem identity13492 : scanCanonicalize (H12AffineFastState.compose env13492 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound13492 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13493 : List Nat := [2,4,8,16,0,16,8,4,0,21,0,1,9,1,1,3,1,1,21,0,1,0,16,3,9,16,1,1,1,0,21,1,4,0,1,0]

theorem envBound13493 : H12AffineFastState.Bounded env13493 := by
  intro p hp
  have h : env13493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13492_13493 : H12AffineEnvironment.transform 4 0 env13492 = env13493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13492 == env13493) = true)

def leafEnv13493 : List Nat := [2,4,8,16,0,16,8,4,0,21,0,1,9,1,1,3,1,1,21,0,1,0,16,3,21,9,1,16,1,1,1,0,21,1,4,0,4,2,1,0,0,1,1]

def active13493 : List Nat := [0,1,2,3]

def tree13493 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13493 : H12WitnessSearch.Good tree13493 := H12GlobalWitnessIndex.good

theorem leafIdentity13493 : H12AffineFastState.composeSystem env13493 rootObs = leafEnv13493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13493 rootObs == leafEnv13493) = true)

theorem terminalChecked13493 : H12PackedTerminal.terminalCheckFast leafEnv13493 active13493 tree13493 = true := by decide +kernel

def env13494 : List Nat := [2,4,8,16,32,16,8,36,1,53,0,1,40,1,1,35,1,0,53,0,1,33,16,3,40,16,1,1,1,1,21,1,36,1,1,1]

theorem envBound13494 : H12AffineFastState.Bounded env13494 := by
  intro p hp
  have h : env13494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13491_13494 : H12AffineEnvironment.transform 8 1 env13491 = env13494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env13491 == env13494) = true)

def env13495 : List Nat := [2,4,8,16,32,16,128,172,512,189,1,1,673,1,136,170,1,513,189,137,1,681,16,139,553,16,0,1,1,512,21,1,172,649,1,512]

theorem envBound13495 : H12AffineFastState.Bounded env13495 := by
  intro p hp
  have h : env13495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13489_13495 : H12AffineEnvironment.transform 10 1 env13489 = env13495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env13489 == env13495) = true)

theorem identity13495 : scanCanonicalize (H12AffineFastState.compose env13495 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound13495 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13496 : List Nat := [2,4,8,16,32,16,128,172,1,189,1,1,160,1,136,170,1,0,189,137,1,168,16,139,40,16,0,1,1,1,21,1,172,136,1,1]

theorem envBound13496 : H12AffineFastState.Bounded env13496 := by
  intro p hp
  have h : env13496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13495_13496 : H12AffineEnvironment.transform 8 1 env13495 = env13496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env13495 == env13496) = true)

def env13497 : List Nat := [2,4,8,16,0,16,128,140,1,157,1,1,128,1,136,138,1,0,157,137,1,136,16,139,8,16,0,1,1,1,21,1,140,136,1,1]

theorem envBound13497 : H12AffineFastState.Bounded env13497 := by
  intro p hp
  have h : env13497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13496_13497 : H12AffineEnvironment.transform 4 0 env13496 = env13497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13496 == env13497) = true)

theorem identity13497 : scanCanonicalize (H12AffineFastState.compose env13497 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound13497 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13498 : List Nat := [2,4,8,16,0,16,9,5,1,20,1,1,9,1,1,3,1,0,20,0,1,1,16,2,8,16,0,1,1,1,21,1,5,1,1,1]

theorem envBound13498 : H12AffineFastState.Bounded env13498 := by
  intro p hp
  have h : env13498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13497_13498 : H12AffineEnvironment.transform 6 9 env13497 = env13498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env13497 == env13498) = true)

def leafEnv13498 : List Nat := [2,4,8,16,0,16,9,5,1,20,1,1,9,1,1,3,1,0,20,0,1,1,16,2,21,8,1,16,0,1,1,1,21,1,5,1,4,3,1,1,0,1,1]

def active13498 : List Nat := [0,1,2,3]

def tree13498 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13498 : H12WitnessSearch.Good tree13498 := H12GlobalWitnessIndex.good

theorem leafIdentity13498 : H12AffineFastState.composeSystem env13498 rootObs = leafEnv13498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13498 rootObs == leafEnv13498) = true)

theorem terminalChecked13498 : H12PackedTerminal.terminalCheckFast leafEnv13498 active13498 tree13498 = true := by decide +kernel

def env13499 : List Nat := [2,4,8,16,1,16,128,141,1,156,1,1,129,1,136,139,1,0,156,137,1,137,16,139,9,16,0,1,1,1,21,1,141,136,1,1]

theorem envBound13499 : H12AffineFastState.Bounded env13499 := by
  intro p hp
  have h : env13499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13496_13499 : H12AffineEnvironment.transform 4 1 env13496 = env13499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13496 == env13499) = true)

def leafEnv13499 : List Nat := [2,4,8,16,1,16,128,141,1,156,1,1,129,1,136,139,1,0,156,137,1,137,16,139,21,9,1,16,0,1,1,1,21,1,141,136,4,2,1,1,0,1,1]

def active13499 : List Nat := [0,1,2,3,6]

def tree13499 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13499 : H12WitnessSearch.Good tree13499 := H12GlobalWitnessIndex.good

theorem leafIdentity13499 : H12AffineFastState.composeSystem env13499 rootObs = leafEnv13499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13499 rootObs == leafEnv13499) = true)

theorem terminalChecked13499 : H12PackedTerminal.terminalCheckFast leafEnv13499 active13499 tree13499 = true := by decide +kernel

def env13500 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,8192,1,10792,11174,1,513,273,10793,1,2729,16,139,8328,16,2476,1,1,941,21,4294967296,256,4294969992,1,512]

theorem envBound13500 : H12AffineFastState.Bounded env13500 := by
  intro p hp
  have h : env13500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13476_13500 : H12AffineEnvironment.transform 21 2729 env13476 = env13500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2729 env13476 == env13500) = true)

theorem identity13500 : scanCanonicalize (H12AffineFastState.compose env13500 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 2696) := by decide +kernel

theorem selectedBound13500 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env13501 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,8192,1,10792,11174,1,513,273,10793,1,2729,16,139,8328,16,2476,1,1,941,21,2696,256,0,1,512]

theorem envBound13501 : H12AffineFastState.Bounded env13501 := by
  intro p hp
  have h : env13501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13500_13501 : H12AffineEnvironment.transform 31 2696 env13500 = env13501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 2696 env13500 == env13501) = true)

def env13502 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,672,1,2184,2310,1,513,273,2185,1,2729,16,139,552,16,2476,1,1,941,21,2696,256,0,1,512]

theorem envBound13502 : H12AffineFastState.Bounded env13502 := by
  intro p hp
  have h : env13502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13501_13502 : H12AffineEnvironment.transform 12 672 env13501 = env13502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 672 env13501 == env13502) = true)

theorem identity13502 : scanCanonicalize (H12AffineFastState.compose env13502 (packedSelected [0,2,4] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound13502 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env13503 : List Nat := [2,4,8,16,32,16,128,173,512,188,2048,1,672,1,2184,2219,1,513,188,2185,1,2729,16,139,552,16,2049,1,1,512,21,2696,173,0,1,512]

theorem envBound13503 : H12AffineFastState.Bounded env13503 := by
  intro p hp
  have h : env13503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13502_13503 : H12AffineEnvironment.transform 7 173 env13502 = env13503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env13502 == env13503) = true)

def env13504 : List Nat := [2,4,8,16,32,16,128,173,512,188,0,1,672,1,136,171,1,513,188,137,1,681,16,139,552,16,1,1,1,512,21,648,173,0,1,512]

theorem envBound13504 : H12AffineFastState.Bounded env13504 := by
  intro p hp
  have h : env13504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13503_13504 : H12AffineEnvironment.transform 10 0 env13503 = env13504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env13503 == env13504) = true)

theorem identity13504 : scanCanonicalize (H12AffineFastState.compose env13504 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound13504 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13505 : List Nat := [2,4,8,16,32,16,8,37,512,52,0,1,552,1,0,35,1,513,52,1,1,545,16,3,552,16,1,1,1,512,21,512,37,0,1,512]

theorem envBound13505 : H12AffineFastState.Bounded env13505 := by
  intro p hp
  have h : env13505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13504_13505 : H12AffineEnvironment.transform 6 8 env13504 = env13505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13504 == env13505) = true)

def env13506 : List Nat := [2,4,8,16,32,16,8,37,0,52,0,1,40,1,0,35,1,1,52,1,1,33,16,3,40,16,1,1,1,0,21,0,37,0,1,0]

theorem envBound13506 : H12AffineFastState.Bounded env13506 := by
  intro p hp
  have h : env13506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13505_13506 : H12AffineEnvironment.transform 8 0 env13505 = env13506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env13505 == env13506) = true)

def leafEnv13506 : List Nat := [2,4,8,16,32,16,8,37,0,52,0,1,40,1,0,35,1,1,52,1,1,33,16,3,21,40,1,16,1,1,1,0,21,0,37,0,4,34,1,0,0,1,1]

def active13506 : List Nat := [0,1,2,3,4]

def tree13506 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13506 : H12WitnessSearch.Good tree13506 := H12GlobalWitnessIndex.good

theorem leafIdentity13506 : H12AffineFastState.composeSystem env13506 rootObs = leafEnv13506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13506 rootObs == leafEnv13506) = true)

theorem terminalChecked13506 : H12PackedTerminal.terminalCheckFast leafEnv13506 active13506 tree13506 = true := by decide +kernel

def env13507 : List Nat := [2,4,8,16,32,16,8,37,1,52,0,1,41,1,0,35,1,0,52,1,1,32,16,3,41,16,1,1,1,1,21,1,37,0,1,1]

theorem envBound13507 : H12AffineFastState.Bounded env13507 := by
  intro p hp
  have h : env13507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13505_13507 : H12AffineEnvironment.transform 8 1 env13505 = env13507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env13505 == env13507) = true)

theorem identity13507 : scanCanonicalize (H12AffineFastState.compose env13507 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound13507 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13508 : List Nat := [2,4,8,16,1,16,8,4,1,21,0,1,8,1,0,2,1,0,21,1,1,1,16,3,8,16,1,1,1,1,21,1,4,0,1,1]

theorem envBound13508 : H12AffineFastState.Bounded env13508 := by
  intro p hp
  have h : env13508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13507_13508 : H12AffineEnvironment.transform 4 1 env13507 = env13508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13507 == env13508) = true)

def leafEnv13508 : List Nat := [2,4,8,16,1,16,8,4,1,21,0,1,8,1,0,2,1,0,21,1,1,1,16,3,21,8,1,16,1,1,1,1,21,1,4,0,4,3,1,1,0,1,1]

def active13508 : List Nat := [0,1,2,3]

def tree13508 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13508 : H12WitnessSearch.Good tree13508 := H12GlobalWitnessIndex.good

theorem leafIdentity13508 : H12AffineFastState.composeSystem env13508 rootObs = leafEnv13508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13508 rootObs == leafEnv13508) = true)

theorem terminalChecked13508 : H12PackedTerminal.terminalCheckFast leafEnv13508 active13508 tree13508 = true := by decide +kernel

def env13509 : List Nat := [2,4,8,16,32,16,128,173,512,188,1,1,672,1,137,170,1,513,188,136,1,680,16,139,552,16,0,1,1,512,21,649,173,0,1,512]

theorem envBound13509 : H12AffineFastState.Bounded env13509 := by
  intro p hp
  have h : env13509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13503_13509 : H12AffineEnvironment.transform 10 1 env13503 = env13509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env13503 == env13509) = true)

theorem identity13509 : scanCanonicalize (H12AffineFastState.compose env13509 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound13509 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13510 : List Nat := [2,4,8,16,32,16,128,173,1,188,1,1,161,1,137,170,1,0,188,136,1,169,16,139,41,16,0,1,1,1,21,136,173,0,1,1]

theorem envBound13510 : H12AffineFastState.Bounded env13510 := by
  intro p hp
  have h : env13510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13509_13510 : H12AffineEnvironment.transform 8 1 env13509 = env13510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env13509 == env13510) = true)

def env13511 : List Nat := [2,4,8,16,0,16,128,141,1,156,1,1,129,1,137,138,1,0,156,136,1,137,16,139,9,16,0,1,1,1,21,136,141,0,1,1]

theorem envBound13511 : H12AffineFastState.Bounded env13511 := by
  intro p hp
  have h : env13511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13510_13511 : H12AffineEnvironment.transform 4 0 env13510 = env13511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13510 == env13511) = true)

def env13512 : List Nat := [2,4,8,16,1,16,128,140,1,157,1,1,128,1,137,139,1,0,157,136,1,136,16,139,8,16,0,1,1,1,21,136,140,0,1,1]

theorem envBound13512 : H12AffineFastState.Bounded env13512 := by
  intro p hp
  have h : env13512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13510_13512 : H12AffineEnvironment.transform 4 1 env13510 = env13512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13510 == env13512) = true)

theorem identity13512 : scanCanonicalize (H12AffineFastState.compose env13512 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound13512 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13513 : List Nat := [2,4,8,16,1,16,9,5,1,20,1,1,9,1,0,2,1,0,20,1,1,1,16,2,8,16,0,1,1,1,21,1,5,0,1,1]

theorem envBound13513 : H12AffineFastState.Bounded env13513 := by
  intro p hp
  have h : env13513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13512_13513 : H12AffineEnvironment.transform 6 9 env13512 = env13513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env13512 == env13513) = true)

def leafEnv13513 : List Nat := [2,4,8,16,1,16,9,5,1,20,1,1,9,1,0,2,1,0,20,1,1,1,16,2,21,8,1,16,0,1,1,1,21,1,5,0,4,2,1,1,0,1,1]

def active13513 : List Nat := [0,1,2,3]

def tree13513 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13513 : H12WitnessSearch.Good tree13513 := H12GlobalWitnessIndex.good

theorem leafIdentity13513 : H12AffineFastState.composeSystem env13513 rootObs = leafEnv13513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13513 rootObs == leafEnv13513) = true)

theorem terminalChecked13513 : H12PackedTerminal.terminalCheckFast leafEnv13513 active13513 tree13513 = true := by decide +kernel

def env13514 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,673,1,2185,2311,1,513,273,2184,1,2729,16,139,553,16,2476,1,1,941,21,2696,256,0,1,512]

theorem envBound13514 : H12AffineFastState.Bounded env13514 := by
  intro p hp
  have h : env13514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13501_13514 : H12AffineEnvironment.transform 12 673 env13501 = env13514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 673 env13501 == env13514) = true)

def env13515 : List Nat := [2,4,8,16,32,16,128,256,136,273,2048,1,41,1,2185,2311,1,137,273,2184,1,2081,16,139,161,16,2476,1,1,293,21,2048,256,0,1,136]

theorem envBound13515 : H12AffineFastState.Bounded env13515 := by
  intro p hp
  have h : env13515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13514_13515 : H12AffineEnvironment.transform 8 136 env13514 = env13515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env13514 == env13515) = true)

theorem identity13515 : scanCanonicalize (H12AffineFastState.compose env13515 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound13515 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13516 : List Nat := [2,4,8,16,32,16,128,172,136,189,2048,1,41,1,2185,2219,1,137,189,2184,1,2081,16,139,161,16,2048,1,1,137,21,2048,172,0,1,136]

theorem envBound13516 : H12AffineFastState.Bounded env13516 := by
  intro p hp
  have h : env13516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13515_13516 : H12AffineEnvironment.transform 7 172 env13515 = env13516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env13515 == env13516) = true)

theorem identity13516 : scanCanonicalize (H12AffineFastState.compose env13516 (packedSelected [7] rootPS)) = affineNative (2^(10+1) ^^^ 137) := by decide +kernel

theorem selectedBound13516 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env13517 : List Nat := [2,4,8,16,32,16,128,172,136,189,137,1,41,1,0,34,1,137,189,1,1,168,16,139,161,16,137,1,1,137,21,137,172,0,1,136]

theorem envBound13517 : H12AffineFastState.Bounded env13517 := by
  intro p hp
  have h : env13517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13516_13517 : H12AffineEnvironment.transform 10 137 env13516 = env13517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 137 env13516 == env13517) = true)

def env13518 : List Nat := [2,4,8,16,0,16,128,140,136,157,137,1,9,1,0,2,1,137,157,1,1,136,16,139,129,16,137,1,1,137,21,137,140,0,1,136]

theorem envBound13518 : H12AffineFastState.Bounded env13518 := by
  intro p hp
  have h : env13518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13517_13518 : H12AffineEnvironment.transform 4 0 env13517 = env13518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13517 == env13518) = true)

theorem identity13518 : scanCanonicalize (H12AffineFastState.compose env13518 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound13518 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13519 : List Nat := [2,4,8,16,0,16,8,4,0,21,1,1,9,1,0,2,1,1,21,1,1,0,16,3,9,16,1,1,1,1,21,1,4,0,1,0]

theorem envBound13519 : H12AffineFastState.Bounded env13519 := by
  intro p hp
  have h : env13519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13518_13519 : H12AffineEnvironment.transform 6 8 env13518 = env13519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13518 == env13519) = true)

def leafEnv13519 : List Nat := [2,4,8,16,0,16,8,4,0,21,1,1,9,1,0,2,1,1,21,1,1,0,16,3,21,9,1,16,1,1,1,1,21,1,4,0,4,3,1,0,0,1,1]

def active13519 : List Nat := [0,1,2,3]

def tree13519 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13519 : H12WitnessSearch.Good tree13519 := H12GlobalWitnessIndex.good

theorem leafIdentity13519 : H12AffineFastState.composeSystem env13519 rootObs = leafEnv13519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13519 rootObs == leafEnv13519) = true)

theorem terminalChecked13519 : H12PackedTerminal.terminalCheckFast leafEnv13519 active13519 tree13519 = true := by decide +kernel

def env13520 : List Nat := [2,4,8,16,1,16,128,141,136,156,137,1,8,1,0,3,1,137,156,1,1,137,16,139,128,16,137,1,1,137,21,137,141,0,1,136]

theorem envBound13520 : H12AffineFastState.Bounded env13520 := by
  intro p hp
  have h : env13520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13517_13520 : H12AffineEnvironment.transform 4 1 env13517 = env13520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13517 == env13520) = true)

def env13521 : List Nat := [2,4,8,16,32,16,128,256,137,273,2048,1,40,1,2185,2311,1,136,273,2184,1,2080,16,139,160,16,2476,1,1,292,21,2049,256,0,1,137]

theorem envBound13521 : H12AffineFastState.Bounded env13521 := by
  intro p hp
  have h : env13521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13514_13521 : H12AffineEnvironment.transform 8 137 env13514 = env13521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env13514 == env13521) = true)

theorem identity13521 : scanCanonicalize (H12AffineFastState.compose env13521 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound13521 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13522 : List Nat := [2,4,8,16,32,16,128,256,137,273,0,1,40,1,137,263,1,136,273,136,1,32,16,139,160,16,428,1,1,292,21,1,256,0,1,137]

theorem envBound13522 : H12AffineFastState.Bounded env13522 := by
  intro p hp
  have h : env13522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13521_13522 : H12AffineEnvironment.transform 10 0 env13521 = env13522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env13521 == env13522) = true)

theorem identity13522 : scanCanonicalize (H12AffineFastState.compose env13522 (packedSelected [2,7] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound13522 : packedSelected [2,7] rootPS < 2^1333 := by decide +kernel

def env13523 : List Nat := [2,4,8,16,32,16,41,256,32,273,0,1,40,1,32,263,1,33,273,33,1,32,16,34,9,16,261,1,1,292,21,1,256,0,1,32]

theorem envBound13523 : H12AffineFastState.Bounded env13523 := by
  intro p hp
  have h : env13523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13522_13523 : H12AffineEnvironment.transform 6 41 env13522 = env13523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env13522 == env13523) = true)

def env13524 : List Nat := [2,4,8,16,0,16,9,256,0,273,0,1,8,1,0,263,1,1,273,1,1,0,16,2,9,16,261,1,1,260,21,1,256,0,1,0]

theorem envBound13524 : H12AffineFastState.Bounded env13524 := by
  intro p hp
  have h : env13524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13523_13524 : H12AffineEnvironment.transform 4 0 env13523 = env13524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13523 == env13524) = true)

theorem identity13524 : scanCanonicalize (H12AffineFastState.compose env13524 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound13524 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13525 : List Nat := [2,4,8,16,0,16,9,4,0,21,0,1,8,1,0,3,1,1,21,1,1,0,16,2,9,16,1,1,1,0,21,1,4,0,1,0]

theorem envBound13525 : H12AffineFastState.Bounded env13525 := by
  intro p hp
  have h : env13525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13524_13525 : H12AffineEnvironment.transform 7 4 env13524 = env13525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env13524 == env13525) = true)

def leafEnv13525 : List Nat := [2,4,8,16,0,16,9,4,0,21,0,1,8,1,0,3,1,1,21,1,1,0,16,2,21,9,1,16,1,1,1,0,21,1,4,0,4,3,1,0,0,1,1]

def active13525 : List Nat := [0,1,2,3]

def tree13525 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13525 : H12WitnessSearch.Good tree13525 := H12GlobalWitnessIndex.good

theorem leafIdentity13525 : H12AffineFastState.composeSystem env13525 rootObs = leafEnv13525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13525 rootObs == leafEnv13525) = true)

theorem terminalChecked13525 : H12PackedTerminal.terminalCheckFast leafEnv13525 active13525 tree13525 = true := by decide +kernel

def env13526 : List Nat := [2,4,8,16,1,16,8,256,1,273,0,1,9,1,1,263,1,0,273,0,1,1,16,3,9,16,261,1,1,261,21,1,256,0,1,1]

theorem envBound13526 : H12AffineFastState.Bounded env13526 := by
  intro p hp
  have h : env13526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13523_13526 : H12AffineEnvironment.transform 4 1 env13523 = env13526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13523 == env13526) = true)

def leafEnv13526 : List Nat := [2,4,8,16,1,16,8,256,1,273,0,1,9,1,1,263,1,0,273,0,1,1,16,3,21,9,1,16,261,1,1,261,21,1,256,0,4,262,1,1,0,1,1]

def active13526 : List Nat := [0,1,2,3,7]

def tree13526 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13526 : H12WitnessSearch.Good tree13526 := H12GlobalWitnessIndex.good

theorem leafIdentity13526 : H12AffineFastState.composeSystem env13526 rootObs = leafEnv13526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13526 rootObs == leafEnv13526) = true)

theorem terminalChecked13526 : H12PackedTerminal.terminalCheckFast leafEnv13526 active13526 tree13526 = true := by decide +kernel

def env13527 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1297,32768,65536,1297,513,1025,32769,1297,4194304,17,98565,8328,17,4195076,1297,1296,1073741824,1284,4294967296,256,4299260335,1297,512]

theorem envBound13527 : H12AffineFastState.Bounded env13527 := by
  intro p hp
  have h : env13527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13347_13527 : H12AffineEnvironment.transform 5 17 env13347 = env13527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env13347 == env13527) = true)

theorem identity13527 : scanCanonicalize (H12AffineFastState.compose env13527 (packedSelected [1,3,5] rootPS)) = affineNative (2^(29+1) ^^^ 4197260) := by decide +kernel

theorem selectedBound13527 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env13528 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1297,32768,65536,1297,513,1025,32769,1297,4194304,17,98565,8328,17,4195076,1297,1296,4197260,1284,4294967296,256,4299260335,1297,512]

theorem envBound13528 : H12AffineFastState.Bounded env13528 := by
  intro p hp
  have h : env13528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13527_13528 : H12AffineEnvironment.transform 29 4197260 env13527 = env13528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4197260 env13527 == env13528) = true)

theorem identity13528 : scanCanonicalize (H12AffineFastState.compose env13528 (packedSelected [1,3,8] rootPS)) = affineNative (2^(15+1) ^^^ 10542) := by decide +kernel

theorem selectedBound13528 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env13529 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1297,32768,10542,1297,513,1025,32769,1297,4194304,17,43051,8328,17,4195076,1297,1296,4197260,1284,4294967296,256,4299204737,1297,512]

theorem envBound13529 : H12AffineFastState.Bounded env13529 := by
  intro p hp
  have h : env13529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13528_13529 : H12AffineEnvironment.transform 15 10542 env13528 = env13529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 10542 env13528 == env13529) = true)

theorem identity13529 : scanCanonicalize (H12AffineFastState.compose env13529 (packedSelected [1] rootPS)) = affineNative (2^(21+1) ^^^ 2470) := by decide +kernel

theorem selectedBound13529 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13530 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1297,32768,10542,1297,513,1025,32769,1297,2470,17,43051,8328,17,2722,1297,1296,554,1284,4294967296,256,4295008551,1297,512]

theorem envBound13530 : H12AffineFastState.Bounded env13530 := by
  intro p hp
  have h : env13530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13529_13530 : H12AffineEnvironment.transform 21 2470 env13529 = env13530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2470 env13529 == env13530) = true)

theorem identity13530 : scanCanonicalize (H12AffineFastState.compose env13530 (packedSelected [10] rootPS)) = affineNative (2^(10+1) ^^^ 429) := by decide +kernel

theorem selectedBound13530 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env13531 : List Nat := [2,4,8,16,32,17,128,256,512,1024,429,1297,8192,1297,32768,8323,1297,513,1025,32769,1297,11,17,41350,8328,17,783,1297,1296,554,1284,4294967296,256,4295008551,1297,512]

theorem envBound13531 : H12AffineFastState.Bounded env13531 := by
  intro p hp
  have h : env13531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13530_13531 : H12AffineEnvironment.transform 10 429 env13530 = env13531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 429 env13530 == env13531) = true)

theorem identity13531 : scanCanonicalize (H12AffineFastState.compose env13531 (packedSelected [12,13] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound13531 : packedSelected [12,13] rootPS < 2^1333 := by decide +kernel

def env13532 : List Nat := [2,4,8,16,32,17,128,256,137,1024,429,1297,8192,1297,32768,8323,1297,136,1025,32769,1297,11,17,41350,8328,17,390,1297,1296,163,1284,4294967296,256,4295008551,1297,137]

theorem envBound13532 : H12AffineFastState.Bounded env13532 := by
  intro p hp
  have h : env13532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13531_13532 : H12AffineEnvironment.transform 8 137 env13531 = env13532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env13531 == env13532) = true)

theorem identity13532 : scanCanonicalize (H12AffineFastState.compose env13532 (packedSelected [3] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound13532 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env13533 : List Nat := [2,4,8,16,32,17,128,256,137,1024,429,1297,8192,1297,136,8323,1297,136,1025,137,1297,11,17,8462,8328,17,390,1297,1296,163,1284,4294967296,256,4294975919,1297,137]

theorem envBound13533 : H12AffineFastState.Bounded env13533 := by
  intro p hp
  have h : env13533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13532_13533 : H12AffineEnvironment.transform 14 136 env13532 = env13533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env13532 == env13533) = true)

theorem identity13533 : scanCanonicalize (H12AffineFastState.compose env13533 (packedSelected [7] rootPS)) = affineNative (2^(31+1) ^^^ 8486) := by decide +kernel

theorem selectedBound13533 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env13534 : List Nat := [2,4,8,16,32,17,128,256,137,1024,429,1297,8192,1297,136,8323,1297,136,1025,137,1297,11,17,8462,8328,17,390,1297,1296,163,1284,8486,256,137,1297,137]

theorem envBound13534 : H12AffineFastState.Bounded env13534 := by
  intro p hp
  have h : env13534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13533_13534 : H12AffineEnvironment.transform 31 8486 env13533 = env13534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 8486 env13533 == env13534) = true)

theorem identity13534 : scanCanonicalize (H12AffineFastState.compose env13534 (packedSelected [0,4,9] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound13534 : packedSelected [0,4,9] rootPS < 2^1333 := by decide +kernel

def env13535 : List Nat := [2,4,8,16,32,17,128,256,137,1024,429,1297,389,1297,136,262,1297,136,1025,137,1297,11,17,139,269,17,390,1297,1296,163,1284,163,256,137,1297,137]

theorem envBound13535 : H12AffineFastState.Bounded env13535 := by
  intro p hp
  have h : env13535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13534_13535 : H12AffineEnvironment.transform 12 389 env13534 = env13535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env13534 == env13535) = true)

theorem identity13535 : scanCanonicalize (H12AffineFastState.compose env13535 (packedSelected [0,2,4] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound13535 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env13536 : List Nat := [2,4,8,16,32,17,128,14,137,1024,163,1055,139,1055,136,8,1055,136,1025,137,1055,11,17,139,3,17,136,1055,1054,163,1034,163,14,137,1055,137]

theorem envBound13536 : H12AffineFastState.Bounded env13536 := by
  intro p hp
  have h : env13536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13535_13536 : H12AffineEnvironment.transform 7 14 env13535 = env13536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env13535 == env13536) = true)

def env13537 : List Nat := [2,4,8,16,32,17,40,14,33,1024,11,1055,35,1055,32,8,1055,32,1025,33,1055,11,17,35,3,17,32,1055,1054,11,1034,11,14,33,1055,33]

theorem envBound13537 : H12AffineFastState.Bounded env13537 := by
  intro p hp
  have h : env13537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13536_13537 : H12AffineEnvironment.transform 6 40 env13536 = env13537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env13536 == env13537) = true)

theorem identity13537 : scanCanonicalize (H12AffineFastState.compose env13537 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound13537 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13538 : List Nat := [2,4,8,16,16,17,24,14,17,1024,11,1055,19,1055,16,8,1055,16,1025,17,1055,11,17,19,3,17,16,1055,1054,11,1034,11,14,17,1055,17]

theorem envBound13538 : H12AffineFastState.Bounded env13538 := by
  intro p hp
  have h : env13538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13537_13538 : H12AffineEnvironment.transform 4 16 env13537 = env13538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env13537 == env13538) = true)

def leafEnv13538 : List Nat := [2,4,8,16,16,17,24,14,17,1024,11,1055,19,1055,16,8,1055,16,1025,17,1055,11,17,19,1035,3,1,17,16,1055,1054,11,1034,11,14,17,4,25,1055,17,0,1054,1]

def active13538 : List Nat := [0,1,2,3,9]

def tree13538 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13538 : H12WitnessSearch.Good tree13538 := H12GlobalWitnessIndex.good

theorem leafIdentity13538 : H12AffineFastState.composeSystem env13538 rootObs = leafEnv13538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13538 rootObs == leafEnv13538) = true)

theorem terminalChecked13538 : H12PackedTerminal.terminalCheckFast leafEnv13538 active13538 tree13538 = true := by decide +kernel

def env13539 : List Nat := [2,4,8,16,32,17,41,14,32,1024,10,1055,34,1055,33,8,1055,33,1025,32,1055,11,17,34,3,17,33,1055,1054,10,1034,10,14,32,1055,32]

theorem envBound13539 : H12AffineFastState.Bounded env13539 := by
  intro p hp
  have h : env13539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13536_13539 : H12AffineEnvironment.transform 6 41 env13536 = env13539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env13536 == env13539) = true)

theorem identity13539 : scanCanonicalize (H12AffineFastState.compose env13539 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound13539 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13540 : List Nat := [2,4,8,10,32,11,41,14,32,1024,10,1029,34,1029,33,8,1029,33,1025,32,1029,11,11,34,3,11,33,1029,1028,10,1034,10,14,32,1029,32]

theorem envBound13540 : H12AffineFastState.Bounded env13540 := by
  intro p hp
  have h : env13540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13539_13540 : H12AffineEnvironment.transform 3 10 env13539 = env13540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env13539 == env13540) = true)

def leafEnv13540 : List Nat := [2,4,8,10,32,11,41,14,32,1024,10,1029,34,1029,33,8,1029,33,1025,32,1029,11,11,34,1035,3,1,11,33,1029,1028,10,1034,10,14,32,4,40,1029,32,0,1028,1]

def active13540 : List Nat := [0,1,2,4,9]

def tree13540 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13540 : H12WitnessSearch.Good tree13540 := H12GlobalWitnessIndex.good

theorem leafIdentity13540 : H12AffineFastState.composeSystem env13540 rootObs = leafEnv13540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13540 rootObs == leafEnv13540) = true)

theorem terminalChecked13540 : H12PackedTerminal.terminalCheckFast leafEnv13540 active13540 tree13540 = true := by decide +kernel

def env13541 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,32768,65536,1344,513,1105,32769,1344,4194304,64,98565,8328,65,134217728,1344,1297,1073741824,1284,4294967296,256,4299260335,138413588,512]

theorem envBound13541 : H12AffineFastState.Bounded env13541 := by
  intro p hp
  have h : env13541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13345_13541 : H12AffineEnvironment.transform 18 1105 env13345 = env13541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1105 env13345 == env13541) = true)

theorem identity13541 : scanCanonicalize (H12AffineFastState.compose env13541 (packedSelected [3,5,24] rootPS)) = affineNative (2^(26+1) ^^^ 74716) := by decide +kernel

theorem selectedBound13541 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env13542 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,32768,65536,1344,513,1105,32769,1344,4194304,64,98565,8328,65,74716,1344,1297,1073741824,1284,4294967296,256,4299260335,4269512,512]

theorem envBound13542 : H12AffineFastState.Bounded env13542 := by
  intro p hp
  have h : env13542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13541_13542 : H12AffineEnvironment.transform 26 74716 env13541 = env13542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 74716 env13541 == env13542) = true)

def env13543 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1296,32768,65536,1296,513,1025,32769,1296,4194304,16,98565,8328,17,74636,1296,1297,1073741824,1284,4294967296,256,4299260335,4269464,512]

theorem envBound13543 : H12AffineFastState.Bounded env13543 := by
  intro p hp
  have h : env13543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13542_13543 : H12AffineEnvironment.transform 5 16 env13542 = env13543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13542 == env13543) = true)

theorem identity13543 : scanCanonicalize (H12AffineFastState.compose env13543 (packedSelected [3,5,10] rootPS)) = affineNative (2^(29+1) ^^^ 2988) := by decide +kernel

theorem selectedBound13543 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env13544 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1296,32768,65536,1296,513,1025,32769,1296,4194304,16,98565,8328,17,74636,1296,1297,2988,1284,4294967296,256,4299260335,4269464,512]

theorem envBound13544 : H12AffineFastState.Bounded env13544 := by
  intro p hp
  have h : env13544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13543_13544 : H12AffineEnvironment.transform 29 2988 env13543 = env13544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 2988 env13543 == env13544) = true)

theorem identity13544 : scanCanonicalize (H12AffineFastState.compose env13544 (packedSelected [1,8,19] rootPS)) = affineNative (2^(14+1) ^^^ 9135) := by decide +kernel

theorem selectedBound13544 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env13545 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1296,9135,65536,1296,513,1025,9134,1296,4194304,16,74410,8328,17,74636,1296,1297,2988,1284,4294967296,256,4299235840,4269464,512]

theorem envBound13545 : H12AffineFastState.Bounded env13545 := by
  intro p hp
  have h : env13545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13544_13545 : H12AffineEnvironment.transform 14 9135 env13544 = env13545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9135 env13544 == env13545) = true)

theorem identity13545 : scanCanonicalize (H12AffineFastState.compose env13545 (packedSelected [0,7,20] rootPS)) = affineNative (2^(21+1) ^^^ 73864) := by decide +kernel

theorem selectedBound13545 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env13546 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1296,9135,65536,1296,513,1025,9134,1296,73864,16,74410,8328,17,74636,1296,1297,2988,1284,4294967296,256,4294967944,1296,512]

theorem envBound13546 : H12AffineFastState.Bounded env13546 := by
  intro p hp
  have h : env13546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13545_13546 : H12AffineEnvironment.transform 21 73864 env13545 = env13546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73864 env13545 == env13546) = true)

theorem identity13546 : scanCanonicalize (H12AffineFastState.compose env13546 (packedSelected [1,3,5] rootPS)) = affineNative (2^(15+1) ^^^ 8714) := by decide +kernel

theorem selectedBound13546 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env13547 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1296,9135,8714,1296,513,1025,9134,1296,642,16,160,8328,17,390,1296,1297,2988,1284,4294967296,256,4294967944,1296,512]

theorem envBound13547 : H12AffineFastState.Bounded env13547 := by
  intro p hp
  have h : env13547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13546_13547 : H12AffineEnvironment.transform 15 8714 env13546 = env13547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8714 env13546 == env13547) = true)

theorem identity13547 : scanCanonicalize (H12AffineFastState.compose env13547 (packedSelected [1,3,8] rootPS)) = affineNative (2^(10+1) ^^^ 390) := by decide +kernel

theorem selectedBound13547 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env13548 : List Nat := [2,4,8,16,32,16,128,256,512,1024,390,1296,8192,1296,9135,8714,1296,513,1025,9134,1296,642,16,160,8328,17,390,1296,1297,554,1284,4294967296,256,4294967944,1296,512]

theorem envBound13548 : H12AffineFastState.Bounded env13548 := by
  intro p hp
  have h : env13548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13547_13548 : H12AffineEnvironment.transform 10 390 env13547 = env13548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 390 env13547 == env13548) = true)

theorem identity13548 : scanCanonicalize (H12AffineFastState.compose env13548 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound13548 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13549 : List Nat := [2,4,8,16,32,16,128,256,136,1024,390,1296,8192,1296,8487,8322,1296,137,1025,8486,1296,10,16,160,8328,17,390,1296,1297,162,1284,4294967296,256,4294967296,1296,136]

theorem envBound13549 : H12AffineFastState.Bounded env13549 := by
  intro p hp
  have h : env13549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13548_13549 : H12AffineEnvironment.transform 8 136 env13548 = env13549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env13548 == env13549) = true)

theorem identity13549 : scanCanonicalize (H12AffineFastState.compose env13549 (packedSelected [0,6,7] rootPS)) = affineNative (2^(31+1) ^^^ 271) := by decide +kernel

theorem selectedBound13549 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env13550 : List Nat := [2,4,8,16,32,16,128,256,136,1024,390,1296,8192,1296,8487,8322,1296,137,1025,8486,1296,10,16,160,8328,17,390,1296,1297,162,1284,271,256,271,1296,136]

theorem envBound13550 : H12AffineFastState.Bounded env13550 := by
  intro p hp
  have h : env13550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13549_13550 : H12AffineEnvironment.transform 31 271 env13549 = env13550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 271 env13549 == env13550) = true)

theorem identity13550 : scanCanonicalize (H12AffineFastState.compose env13550 (packedSelected [4,6,9] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound13550 : packedSelected [4,6,9] rootPS < 2^1333 := by decide +kernel

def env13551 : List Nat := [2,4,8,16,11,16,128,256,136,1024,390,1296,8192,1296,8460,8322,1296,137,1025,8461,1296,10,16,139,8328,17,390,1296,1297,137,1284,271,256,271,1296,136]

theorem envBound13551 : H12AffineFastState.Bounded env13551 := by
  intro p hp
  have h : env13551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13550_13551 : H12AffineEnvironment.transform 4 11 env13550 = env13551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env13550 == env13551) = true)

theorem identity13551 : scanCanonicalize (H12AffineFastState.compose env13551 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound13551 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13552 : List Nat := [2,4,8,16,11,16,19,256,27,1024,277,1296,8192,1296,8460,8209,1296,26,1025,8461,1296,10,16,24,8219,17,277,1296,1297,26,1284,271,256,271,1296,27]

theorem envBound13552 : H12AffineFastState.Bounded env13552 := by
  intro p hp
  have h : env13552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13551_13552 : H12AffineEnvironment.transform 6 19 env13551 = env13552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env13551 == env13552) = true)

theorem identity13552 : scanCanonicalize (H12AffineFastState.compose env13552 (packedSelected [3] rootPS)) = affineNative (2^(12+1) ^^^ 278) := by decide +kernel

theorem selectedBound13552 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env13553 : List Nat := [2,4,8,16,11,16,19,256,27,1024,277,1296,278,1296,26,263,1296,26,1025,27,1296,10,16,24,269,17,277,1296,1297,26,1284,271,256,271,1296,27]

theorem envBound13553 : H12AffineFastState.Bounded env13553 := by
  intro p hp
  have h : env13553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13552_13553 : H12AffineEnvironment.transform 12 278 env13552 = env13553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 278 env13552 == env13553) = true)

theorem identity13553 : scanCanonicalize (H12AffineFastState.compose env13553 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound13553 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env13554 : List Nat := [2,4,8,16,11,16,19,15,27,1024,26,1055,25,1055,26,8,1055,26,1025,27,1055,10,16,24,2,17,26,1055,1054,26,1035,0,15,0,1055,27]

theorem envBound13554 : H12AffineFastState.Bounded env13554 := by
  intro p hp
  have h : env13554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13553_13554 : H12AffineEnvironment.transform 7 15 env13553 = env13554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env13553 == env13554) = true)

def env13555 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1297,32768,65536,1297,513,1024,32769,1297,4194304,17,98565,8328,16,74637,1297,1297,1073741824,1284,4294967296,256,4299260335,4269465,512]

theorem envBound13555 : H12AffineFastState.Bounded env13555 := by
  intro p hp
  have h : env13555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13542_13555 : H12AffineEnvironment.transform 5 17 env13542 = env13555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env13542 == env13555) = true)

theorem identity13555 : scanCanonicalize (H12AffineFastState.compose env13555 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 73891) := by decide +kernel

theorem selectedBound13555 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env13556 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1297,32768,65536,1297,513,1024,32769,1297,73891,17,98565,8328,16,74637,1297,1297,1073741824,1284,4294967296,256,4295008524,1338,512]

theorem envBound13556 : H12AffineFastState.Bounded env13556 := by
  intro p hp
  have h : env13556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13555_13556 : H12AffineEnvironment.transform 21 73891 env13555 = env13556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73891 env13555 == env13556) = true)

theorem identity13556 : scanCanonicalize (H12AffineFastState.compose env13556 (packedSelected [3,5,8,28] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound13556 : packedSelected [3,5,8,28] rootPS < 2^1333 := by decide +kernel

def env13557 : List Nat := [2,4,8,16,11,17,128,256,512,1024,2048,1297,8192,1297,32768,65536,1297,513,1024,32769,1297,73864,17,98565,8328,16,74637,1297,1297,1073741824,1284,4294967296,256,4295008524,1297,512]

theorem envBound13557 : H12AffineFastState.Bounded env13557 := by
  intro p hp
  have h : env13557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13556_13557 : H12AffineEnvironment.transform 4 11 env13556 = env13557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env13556 == env13557) = true)

theorem identity13557 : scanCanonicalize (H12AffineFastState.compose env13557 (packedSelected [1,3,5] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound13557 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env13558 : List Nat := [2,4,8,16,11,17,128,256,512,1024,2048,1297,8192,1297,8461,65536,1297,513,1024,8460,1297,73864,17,73736,8328,16,74637,1297,1297,1073741824,1284,4294967296,256,4294967297,1297,512]

theorem envBound13558 : H12AffineFastState.Bounded env13558 := by
  intro p hp
  have h : env13558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13557_13558 : H12AffineEnvironment.transform 14 8461 env13557 = env13558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env13557 == env13558) = true)

theorem identity13558 : scanCanonicalize (H12AffineFastState.compose env13558 (packedSelected [1,12,13] rootPS)) = affineNative (2^(29+1) ^^^ 76173) := by decide +kernel

theorem selectedBound13558 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env13559 : List Nat := [2,4,8,16,11,17,128,256,512,1024,2048,1297,8192,1297,8461,65536,1297,513,1024,8460,1297,73864,17,73736,8328,16,74637,1297,1297,76173,1284,4294967296,256,4294967297,1297,512]

theorem envBound13559 : H12AffineFastState.Bounded env13559 := by
  intro p hp
  have h : env13559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13558_13559 : H12AffineEnvironment.transform 29 76173 env13558 = env13559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 76173 env13558 == env13559) = true)

theorem identity13559 : scanCanonicalize (H12AffineFastState.compose env13559 (packedSelected [1,3] rootPS)) = affineNative (2^(15+1) ^^^ 9618) := by decide +kernel

theorem selectedBound13559 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env13560 : List Nat := [2,4,8,16,11,17,128,256,512,1024,2048,1297,8192,1297,8461,9618,1297,513,1024,8460,1297,1306,17,1434,8328,16,1567,1297,1297,3103,1284,4294967296,256,4294967297,1297,512]

theorem envBound13560 : H12AffineFastState.Bounded env13560 := by
  intro p hp
  have h : env13560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13559_13560 : H12AffineEnvironment.transform 15 9618 env13559 = env13560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9618 env13559 == env13560) = true)

theorem identity13560 : scanCanonicalize (H12AffineFastState.compose env13560 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound13560 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env13561 : List Nat := [2,4,8,16,11,17,128,256,512,272,2048,1,8192,1,8461,8322,1,513,272,8460,1,10,17,138,8328,16,783,1,1,2319,20,4294967296,256,4294967297,1,512]

theorem envBound13561 : H12AffineFastState.Bounded env13561 := by
  intro p hp
  have h : env13561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13560_13561 : H12AffineEnvironment.transform 9 272 env13560 = env13561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env13560 == env13561) = true)

theorem identity13561 : scanCanonicalize (H12AffineFastState.compose env13561 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 782) := by decide +kernel

theorem selectedBound13561 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13562 : List Nat := [2,4,8,16,11,17,128,256,512,272,782,1,8192,1,8461,8322,1,513,272,8460,1,10,17,138,8328,16,783,1,1,513,20,4294967296,256,4294967297,1,512]

theorem envBound13562 : H12AffineFastState.Bounded env13562 := by
  intro p hp
  have h : env13562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13561_13562 : H12AffineEnvironment.transform 10 782 env13561 = env13562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 782 env13561 == env13562) = true)

theorem identity13562 : scanCanonicalize (H12AffineFastState.compose env13562 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 521) := by decide +kernel

theorem selectedBound13562 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13563 : List Nat := [2,4,8,16,11,17,128,256,512,272,782,1,521,1,772,651,1,513,272,773,1,10,17,138,641,16,783,1,1,513,20,4294967296,256,4294967297,1,512]

theorem envBound13563 : H12AffineFastState.Bounded env13563 := by
  intro p hp
  have h : env13563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13562_13563 : H12AffineEnvironment.transform 12 521 env13562 = env13563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 521 env13562 == env13563) = true)

theorem identity13563 : scanCanonicalize (H12AffineFastState.compose env13563 (packedSelected [0,4] rootPS)) = affineNative (2^(31+1) ^^^ 396) := by decide +kernel

theorem selectedBound13563 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env13564 : List Nat := [2,4,8,16,11,17,128,256,512,272,782,1,521,1,772,651,1,513,272,773,1,10,17,138,641,16,783,1,1,513,20,396,256,397,1,512]

theorem envBound13564 : H12AffineFastState.Bounded env13564 := by
  intro p hp
  have h : env13564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13563_13564 : H12AffineEnvironment.transform 31 396 env13563 = env13564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 396 env13563 == env13564) = true)

theorem identity13564 : scanCanonicalize (H12AffineFastState.compose env13564 (packedSelected [6] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound13564 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env13565 : List Nat := [2,4,2,16,1,17,128,256,512,272,772,1,515,1,772,641,1,513,272,773,1,0,17,128,641,16,773,1,1,513,20,390,256,391,1,512]

theorem envBound13565 : H12AffineFastState.Bounded env13565 := by
  intro p hp
  have h : env13565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13564_13565 : H12AffineEnvironment.transform 2 2 env13564 = env13565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env13564 == env13565) = true)

theorem identity13565 : scanCanonicalize (H12AffineFastState.compose env13565 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound13565 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env13566 : List Nat := [2,4,2,16,1,17,128,256,261,272,1,1,262,1,1,388,1,260,272,0,1,0,17,128,388,16,0,1,1,260,20,390,256,391,1,261]

theorem envBound13566 : H12AffineFastState.Bounded env13566 := by
  intro p hp
  have h : env13566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13565_13566 : H12AffineEnvironment.transform 8 261 env13565 = env13566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env13565 == env13566) = true)

theorem identity13566 : scanCanonicalize (H12AffineFastState.compose env13566 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound13566 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13567 : List Nat := [2,4,2,0,1,1,128,256,261,256,1,1,262,1,1,388,1,260,256,0,1,0,1,128,388,0,0,1,1,260,4,390,256,391,1,261]

theorem envBound13567 : H12AffineFastState.Bounded env13567 := by
  intro p hp
  have h : env13567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13566_13567 : H12AffineEnvironment.transform 3 0 env13566 = env13567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env13566 == env13567) = true)

def env13568 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,32768,65536,1344,262144,524288,32769,1344,4194304,65,98565,8328,525329,134217728,1345,524609,1073741824,1284,4294967296,256,4299260335,139198532,512]

theorem envBound13568 : H12AffineFastState.Bounded env13568 := by
  intro p hp
  have h : env13568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13112_13568 : H12AffineEnvironment.transform 13 1345 env13112 = env13568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env13112 == env13568) = true)

theorem identity13568 : scanCanonicalize (H12AffineFastState.compose env13568 (packedSelected [9,22] rootPS)) = affineNative (2^(18+1) ^^^ 1105) := by decide +kernel

theorem selectedBound13568 : packedSelected [9,22] rootPS < 2^1333 := by decide +kernel

def env13569 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,32768,65536,1344,262144,1105,32769,1344,4194304,65,98565,8328,64,134217728,1345,1296,1073741824,1284,4294967296,256,4299260335,138675221,512]

theorem envBound13569 : H12AffineFastState.Bounded env13569 := by
  intro p hp
  have h : env13569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13568_13569 : H12AffineEnvironment.transform 18 1105 env13568 = env13569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1105 env13568 == env13569) = true)

def env13570 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,32768,65536,1344,512,1105,32769,1344,4194304,65,98565,8328,64,134217728,1345,1296,1073741824,1284,4294967296,256,4299260335,138413589,512]

theorem envBound13570 : H12AffineFastState.Bounded env13570 := by
  intro p hp
  have h : env13570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13569_13570 : H12AffineEnvironment.transform 17 512 env13569 = env13570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 512 env13569 == env13570) = true)

def env13571 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1297,32768,65536,1296,512,1025,32769,1296,4194304,17,98565,8328,16,134217728,1297,1296,1073741824,1284,4294967296,256,4299260335,138413589,512]

theorem envBound13571 : H12AffineFastState.Bounded env13571 := by
  intro p hp
  have h : env13571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13570_13571 : H12AffineEnvironment.transform 5 16 env13570 = env13571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13570 == env13571) = true)

theorem identity13571 : scanCanonicalize (H12AffineFastState.compose env13571 (packedSelected [3,5,10] rootPS)) = affineNative (2^(29+1) ^^^ 4270863) := by decide +kernel

theorem selectedBound13571 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env13572 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1297,32768,65536,1296,512,1025,32769,1296,4194304,17,98565,8328,16,134217728,1297,1296,4270863,1284,4294967296,256,4299260335,138413589,512]

theorem envBound13572 : H12AffineFastState.Bounded env13572 := by
  intro p hp
  have h : env13572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13571_13572 : H12AffineEnvironment.transform 29 4270863 env13571 = env13572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4270863 env13571 == env13572) = true)

theorem identity13572 : scanCanonicalize (H12AffineFastState.compose env13572 (packedSelected [1,8,19] rootPS)) = affineNative (2^(26+1) ^^^ 4235393) := by decide +kernel

theorem selectedBound13572 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env13573 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1297,32768,65536,1296,512,1025,32769,1296,4194304,17,98565,8328,16,4235393,1297,1296,4270863,1284,4294967296,256,4299260335,42644,512]

theorem envBound13573 : H12AffineFastState.Bounded env13573 := by
  intro p hp
  have h : env13573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13572_13573 : H12AffineEnvironment.transform 26 4235393 env13572 = env13573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 4235393 env13572 == env13573) = true)

theorem identity13573 : scanCanonicalize (H12AffineFastState.compose env13573 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 9092) := by decide +kernel

theorem selectedBound13573 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env13574 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1297,9092,65536,1296,512,1025,9093,1296,4194304,17,74369,8328,16,4195077,1297,1296,4270863,1284,4294967296,256,4299235883,1296,512]

theorem envBound13574 : H12AffineFastState.Bounded env13574 := by
  intro p hp
  have h : env13574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13573_13574 : H12AffineEnvironment.transform 14 9092 env13573 = env13574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9092 env13573 == env13574) = true)

theorem identity13574 : scanCanonicalize (H12AffineFastState.compose env13574 (packedSelected [1,3,5] rootPS)) = affineNative (2^(15+1) ^^^ 10543) := by decide +kernel

theorem selectedBound13574 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env13575 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1297,9092,10543,1296,512,1025,9093,1296,4194304,17,2990,8328,16,4195077,1297,1296,4194848,1284,4294967296,256,4299164420,1296,512]

theorem envBound13575 : H12AffineFastState.Bounded env13575 := by
  intro p hp
  have h : env13575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13574_13575 : H12AffineEnvironment.transform 15 10543 env13574 = env13575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 10543 env13574 == env13575) = true)

theorem identity13575 : scanCanonicalize (H12AffineFastState.compose env13575 (packedSelected [1,3,8] rootPS)) = affineNative (2^(10+1) ^^^ 805) := by decide +kernel

theorem selectedBound13575 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env13576 : List Nat := [2,4,8,16,32,16,128,256,512,1024,805,1296,8192,1297,9092,8714,1296,512,1025,9093,1296,4194304,17,139,8328,16,4195077,1297,1296,4194848,1284,4294967296,256,4299161633,1296,512]

theorem envBound13576 : H12AffineFastState.Bounded env13576 := by
  intro p hp
  have h : env13576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13575_13576 : H12AffineEnvironment.transform 10 805 env13575 = env13576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 805 env13575 == env13576) = true)

theorem identity13576 : scanCanonicalize (H12AffineFastState.compose env13576 (packedSelected [1,3] rootPS)) = affineNative (2^(21+1) ^^^ 8712) := by decide +kernel

theorem selectedBound13576 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env13577 : List Nat := [2,4,8,16,32,16,128,256,512,1024,805,1296,8192,1297,9092,8714,1296,512,1025,9093,1296,8712,17,139,8328,16,8461,1297,1296,8232,1284,4294967296,256,4294976041,1296,512]

theorem envBound13577 : H12AffineFastState.Bounded env13577 := by
  intro p hp
  have h : env13577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13576_13577 : H12AffineEnvironment.transform 21 8712 env13576 = env13577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8712 env13576 == env13577) = true)

theorem identity13577 : scanCanonicalize (H12AffineFastState.compose env13577 (packedSelected [7] rootPS)) = affineNative (2^(31+1) ^^^ 8864) := by decide +kernel

theorem selectedBound13577 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env13578 : List Nat := [2,4,8,16,32,16,128,256,512,1024,805,1296,8192,1297,9092,8714,1296,512,1025,9093,1296,8712,17,139,8328,16,8461,1297,1296,8232,1284,8864,256,137,1296,512]

theorem envBound13578 : H12AffineFastState.Bounded env13578 := by
  intro p hp
  have h : env13578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13577_13578 : H12AffineEnvironment.transform 31 8864 env13577 = env13578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 8864 env13577 == env13578) = true)

theorem identity13578 : scanCanonicalize (H12AffineFastState.compose env13578 (packedSelected [0,4,9] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound13578 : packedSelected [0,4,9] rootPS < 2^1333 := by decide +kernel

def env13579 : List Nat := [2,4,8,16,32,16,128,256,137,1024,428,1296,8192,1297,8461,8323,1296,137,1025,8460,1296,8321,17,139,8328,16,8461,1297,1296,8232,1284,8233,256,137,1296,137]

theorem envBound13579 : H12AffineFastState.Bounded env13579 := by
  intro p hp
  have h : env13579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13578_13579 : H12AffineEnvironment.transform 8 137 env13578 = env13579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env13578 == env13579) = true)

theorem identity13579 : scanCanonicalize (H12AffineFastState.compose env13579 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 2) := by decide +kernel

theorem selectedBound13579 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13580 : List Nat := [2,4,8,16,32,16,128,256,137,1024,428,1296,2,1297,271,129,1296,137,1025,270,1296,131,17,139,138,16,271,1297,1296,42,1284,43,256,137,1296,137]

theorem envBound13580 : H12AffineFastState.Bounded env13580 := by
  intro p hp
  have h : env13580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13579_13580 : H12AffineEnvironment.transform 12 2 env13579 = env13580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2 env13579 == env13580) = true)

theorem identity13580 : scanCanonicalize (H12AffineFastState.compose env13580 (packedSelected [2,4] rootPS)) = affineNative (2^(7+1) ^^^ 134) := by decide +kernel

theorem selectedBound13580 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env13581 : List Nat := [2,4,8,16,32,16,128,134,137,1024,42,1174,2,1175,137,129,1174,137,1025,136,1174,131,17,139,138,16,137,1175,1174,42,1154,43,134,137,1174,137]

theorem envBound13581 : H12AffineFastState.Bounded env13581 := by
  intro p hp
  have h : env13581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13580_13581 : H12AffineEnvironment.transform 7 134 env13580 = env13581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 134 env13580 == env13581) = true)

def env13582 : List Nat := [2,4,8,16,32,16,40,46,33,1024,42,1086,2,1087,33,41,1086,33,1025,32,1086,43,17,35,34,16,33,1087,1086,42,1066,43,46,33,1086,33]

theorem envBound13582 : H12AffineFastState.Bounded env13582 := by
  intro p hp
  have h : env13582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13581_13582 : H12AffineEnvironment.transform 6 40 env13581 = env13582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env13581 == env13582) = true)

theorem identity13582 : scanCanonicalize (H12AffineFastState.compose env13582 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound13582 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13583 : List Nat := [2,4,8,16,17,16,25,31,16,1024,27,1039,2,1038,16,24,1039,16,1025,17,1039,26,17,18,19,16,16,1038,1039,27,1051,26,31,16,1039,16]

theorem envBound13583 : H12AffineFastState.Bounded env13583 := by
  intro p hp
  have h : env13583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13582_13583 : H12AffineEnvironment.transform 4 17 env13582 = env13583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env13582 == env13583) = true)

def leafEnv13583 : List Nat := [2,4,8,16,17,16,25,31,16,1024,27,1039,2,1038,16,24,1039,16,1025,17,1039,26,17,18,1050,19,1,16,16,1038,1039,27,1051,26,31,16,4,8,1039,16,0,1039,1]

def active13583 : List Nat := [0,1,2,3,9]

def tree13583 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13583 : H12WitnessSearch.Good tree13583 := H12GlobalWitnessIndex.good

theorem leafIdentity13583 : H12AffineFastState.composeSystem env13583 rootObs = leafEnv13583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13583 rootObs == leafEnv13583) = true)

theorem terminalChecked13583 : H12PackedTerminal.terminalCheckFast leafEnv13583 active13583 tree13583 = true := by decide +kernel

def env13584 : List Nat := [2,4,8,16,32,16,41,47,32,1024,42,1087,2,1086,32,40,1087,32,1025,33,1087,42,17,34,35,16,32,1086,1087,42,1067,43,47,32,1087,32]

theorem envBound13584 : H12AffineFastState.Bounded env13584 := by
  intro p hp
  have h : env13584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13581_13584 : H12AffineEnvironment.transform 6 41 env13581 = env13584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env13581 == env13584) = true)

theorem identity13584 : scanCanonicalize (H12AffineFastState.compose env13584 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound13584 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13585 : List Nat := [2,4,8,16,26,16,19,21,26,1024,16,1029,2,1028,26,18,1029,26,1025,27,1029,16,17,24,25,16,26,1028,1029,16,1041,17,21,26,1029,26]

theorem envBound13585 : H12AffineFastState.Bounded env13585 := by
  intro p hp
  have h : env13585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13584_13585 : H12AffineEnvironment.transform 4 26 env13584 = env13585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env13584 == env13585) = true)

def leafEnv13585 : List Nat := [2,4,8,16,26,16,19,21,26,1024,16,1029,2,1028,26,18,1029,26,1025,27,1029,16,17,24,1040,25,1,16,26,1028,1029,16,1041,17,21,26,4,8,1029,26,0,1029,1]

def active13585 : List Nat := [0,1,2,3,9]

def tree13585 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13585 : H12WitnessSearch.Good tree13585 := H12GlobalWitnessIndex.good

theorem leafIdentity13585 : H12AffineFastState.composeSystem env13585 rootObs = leafEnv13585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13585 rootObs == leafEnv13585) = true)

theorem terminalChecked13585 : H12PackedTerminal.terminalCheckFast leafEnv13585 active13585 tree13585 = true := by decide +kernel

def env13586 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1296,32768,65536,1297,512,1024,32769,1297,4194304,16,98565,8328,17,134217728,1296,1296,1073741824,1284,4294967296,256,4299260335,138413589,512]

theorem envBound13586 : H12AffineFastState.Bounded env13586 := by
  intro p hp
  have h : env13586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13570_13586 : H12AffineEnvironment.transform 5 17 env13570 = env13586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env13570 == env13586) = true)

theorem identity13586 : scanCanonicalize (H12AffineFastState.compose env13586 (packedSelected [3,5,8,28] rootPS)) = affineNative (2^(29+1) ^^^ 134291879) := by decide +kernel

theorem selectedBound13586 : packedSelected [3,5,8,28] rootPS < 2^1333 := by decide +kernel

def env13587 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1296,32768,65536,1297,512,1024,32769,1297,4194304,16,98565,8328,17,134217728,1296,1296,134291879,1284,4294967296,256,4299260335,138413589,512]

theorem envBound13587 : H12AffineFastState.Bounded env13587 := by
  intro p hp
  have h : env13587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13586_13587 : H12AffineEnvironment.transform 29 134291879 env13586 = env13587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 134291879 env13586 == env13587) = true)

theorem identity13587 : scanCanonicalize (H12AffineFastState.compose env13587 (packedSelected [1,3,8,15,17,21,38] rootPS)) = affineNative (2^(26+1) ^^^ 4195076) := by decide +kernel

theorem selectedBound13587 : packedSelected [1,3,8,15,17,21,38] rootPS < 2^1333 := by decide +kernel

def env13588 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1296,32768,65536,1297,512,1024,32769,1297,4194304,16,98565,8328,17,4195076,1296,1296,4268707,1284,4294967296,256,4299260335,1297,512]

theorem envBound13588 : H12AffineFastState.Bounded env13588 := by
  intro p hp
  have h : env13588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13587_13588 : H12AffineEnvironment.transform 26 4195076 env13587 = env13588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 4195076 env13587 == env13588) = true)

theorem identity13588 : scanCanonicalize (H12AffineFastState.compose env13588 (packedSelected [1] rootPS)) = affineNative (2^(21+1) ^^^ 8832) := by decide +kernel

theorem selectedBound13588 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13589 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1296,32768,65536,1297,512,1024,32769,1297,8832,16,98565,8328,17,8580,1296,1296,65571,1284,4294967296,256,4295074607,1297,512]

theorem envBound13589 : H12AffineFastState.Bounded env13589 := by
  intro p hp
  have h : env13589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13588_13589 : H12AffineEnvironment.transform 21 8832 env13588 = env13589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8832 env13588 == env13589) = true)

theorem identity13589 : scanCanonicalize (H12AffineFastState.compose env13589 (packedSelected [3,8] rootPS)) = affineNative (2^(15+1) ^^^ 11175) := by decide +kernel

theorem selectedBound13589 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env13590 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1296,32768,11175,1297,512,1024,32769,1297,8832,16,43682,8328,17,8580,1296,1296,11140,1284,4294967296,256,4295002248,1297,512]

theorem envBound13590 : H12AffineFastState.Bounded env13590 := by
  intro p hp
  have h : env13590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13589_13590 : H12AffineEnvironment.transform 15 11175 env13589 = env13590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 11175 env13589 == env13590) = true)

theorem identity13590 : scanCanonicalize (H12AffineFastState.compose env13590 (packedSelected [3] rootPS)) = affineNative (2^(12+1) ^^^ 900) := by decide +kernel

theorem selectedBound13590 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env13591 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,900,1296,32768,2083,1297,512,1024,32769,1297,260,16,35110,780,17,512,1296,1296,2048,1284,4294967296,256,4295002248,1297,512]

theorem envBound13591 : H12AffineFastState.Bounded env13591 := by
  intro p hp
  have h : env13591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13590_13591 : H12AffineEnvironment.transform 12 900 env13590 = env13591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 900 env13590 == env13591) = true)

theorem identity13591 : scanCanonicalize (H12AffineFastState.compose env13591 (packedSelected [0,7] rootPS)) = affineNative (2^(14+1) ^^^ 2477) := by decide +kernel

theorem selectedBound13591 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env13592 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,900,1296,2477,2083,1297,512,1024,2476,1297,260,16,139,780,17,512,1296,1296,2048,1284,4294967296,256,4294967589,1297,512]

theorem envBound13592 : H12AffineFastState.Bounded env13592 := by
  intro p hp
  have h : env13592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13591_13592 : H12AffineEnvironment.transform 14 2477 env13591 = env13592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2477 env13591 == env13592) = true)

theorem identity13592 : scanCanonicalize (H12AffineFastState.compose env13592 (packedSelected [12] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound13592 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env13593 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,1297,780,1296,2341,2083,1297,512,1024,2340,1297,260,16,3,780,17,512,1296,1296,2048,1284,4294967296,256,4294967589,1297,512]

theorem envBound13593 : H12AffineFastState.Bounded env13593 := by
  intro p hp
  have h : env13593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13592_13593 : H12AffineEnvironment.transform 6 8 env13592 = env13593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13592 == env13593) = true)

theorem identity13593 : scanCanonicalize (H12AffineFastState.compose env13593 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 293) := by decide +kernel

theorem selectedBound13593 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13594 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,1297,780,1296,2341,2083,1297,512,1024,2340,1297,260,16,3,780,17,512,1296,1296,2048,1284,293,256,0,1297,512]

theorem envBound13594 : H12AffineFastState.Bounded env13594 := by
  intro p hp
  have h : env13594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13593_13594 : H12AffineEnvironment.transform 31 293 env13593 = env13594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 293 env13593 == env13594) = true)

def env13595 : List Nat := [2,4,8,16,0,17,8,256,512,1024,2048,1297,780,1296,2309,2051,1297,512,1024,2308,1297,260,16,3,780,17,512,1296,1296,2048,1284,261,256,0,1297,512]

theorem envBound13595 : H12AffineFastState.Bounded env13595 := by
  intro p hp
  have h : env13595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13594_13595 : H12AffineEnvironment.transform 4 0 env13594 = env13595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13594 == env13595) = true)

theorem identity13595 : scanCanonicalize (H12AffineFastState.compose env13595 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound13595 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13596 : List Nat := [2,4,8,16,0,17,8,256,0,1024,2048,1297,268,1296,2309,2051,1297,0,1024,2308,1297,260,16,3,268,17,0,1296,1296,2048,1284,261,256,0,1297,0]

theorem envBound13596 : H12AffineFastState.Bounded env13596 := by
  intro p hp
  have h : env13596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13595_13596 : H12AffineEnvironment.transform 8 0 env13595 = env13596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env13595 == env13596) = true)

def leafEnv13596 : List Nat := [2,4,8,16,0,17,8,256,0,1024,2048,1297,268,1296,2309,2051,1297,0,1024,2308,1297,260,16,3,1284,268,1,17,0,1296,1296,2048,1284,261,256,0,4,2050,1297,0,0,1296,1]

def active13596 : List Nat := [0,1,2,3,7,9,10]

def tree13596 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13596 : H12WitnessSearch.Good tree13596 := H12GlobalWitnessIndex.good

theorem leafIdentity13596 : H12AffineFastState.composeSystem env13596 rootObs = leafEnv13596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13596 rootObs == leafEnv13596) = true)

theorem terminalChecked13596 : H12PackedTerminal.terminalCheckFast leafEnv13596 active13596 tree13596 = true := by decide +kernel

def env13597 : List Nat := [2,4,8,16,1,17,8,256,512,1024,2048,1297,780,1296,2308,2050,1297,512,1024,2309,1297,260,16,3,780,17,512,1296,1296,2048,1284,260,256,0,1297,512]

theorem envBound13597 : H12AffineFastState.Bounded env13597 := by
  intro p hp
  have h : env13597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13594_13597 : H12AffineEnvironment.transform 4 1 env13594 = env13597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13594 == env13597) = true)

theorem identity13597 : scanCanonicalize (H12AffineFastState.compose env13597 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound13597 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13598 : List Nat := [2,4,8,16,1,17,8,256,260,1024,2048,1297,8,1296,2308,2050,1297,260,1024,2309,1297,260,16,3,8,17,260,1296,1296,2048,1284,260,256,0,1297,260]

theorem envBound13598 : H12AffineFastState.Bounded env13598 := by
  intro p hp
  have h : env13598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13597_13598 : H12AffineEnvironment.transform 8 260 env13597 = env13598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env13597 == env13598) = true)

def leafEnv13598 : List Nat := [2,4,8,16,1,17,8,256,260,1024,2048,1297,8,1296,2308,2050,1297,260,1024,2309,1297,260,16,3,1284,8,1,17,260,1296,1296,2048,1284,260,256,0,4,2051,1297,260,0,1296,1]

def active13598 : List Nat := [0,1,2,3,7,9,10]

def tree13598 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13598 : H12WitnessSearch.Good tree13598 := H12GlobalWitnessIndex.good

theorem leafIdentity13598 : H12AffineFastState.composeSystem env13598 rootObs = leafEnv13598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13598 rootObs == leafEnv13598) = true)

theorem terminalChecked13598 : H12PackedTerminal.terminalCheckFast leafEnv13598 active13598 tree13598 = true := by decide +kernel

def env13599 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,32768,65536,1344,513,1105,32769,1344,4194304,65,98565,8328,64,134217728,1345,1296,1073741824,1284,4294967296,256,4299260335,138413588,512]

theorem envBound13599 : H12AffineFastState.Bounded env13599 := by
  intro p hp
  have h : env13599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13569_13599 : H12AffineEnvironment.transform 17 513 env13569 = env13599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 513 env13569 == env13599) = true)

theorem identity13599 : scanCanonicalize (H12AffineFastState.compose env13599 (packedSelected [3,5,24] rootPS)) = affineNative (2^(26+1) ^^^ 4195156) := by decide +kernel

theorem selectedBound13599 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env13600 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,32768,65536,1344,513,1105,32769,1344,4194304,65,98565,8328,64,4195156,1345,1296,1073741824,1284,4294967296,256,4299260335,1344,512]

theorem envBound13600 : H12AffineFastState.Bounded env13600 := by
  intro p hp
  have h : env13600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13599_13600 : H12AffineEnvironment.transform 26 4195156 env13599 = env13600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 4195156 env13599 == env13600) = true)

theorem identity13600 : scanCanonicalize (H12AffineFastState.compose env13600 (packedSelected [8,10,13,15] rootPS)) = affineNative (2^(29+1) ^^^ 4294875) := by decide +kernel

theorem selectedBound13600 : packedSelected [8,10,13,15] rootPS < 2^1333 := by decide +kernel

def env13601 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,32768,65536,1344,513,1105,32769,1344,4194304,65,98565,8328,64,4195156,1345,1296,4294875,1284,4294967296,256,4299260335,1344,512]

theorem envBound13601 : H12AffineFastState.Bounded env13601 := by
  intro p hp
  have h : env13601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13600_13601 : H12AffineEnvironment.transform 29 4294875 env13600 = env13601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4294875 env13600 == env13601) = true)

def env13602 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,32768,65536,1344,513,1105,32769,1344,41168,65,98565,8328,64,41860,1345,1296,75787,1284,4294967296,256,4295041407,1344,512]

theorem envBound13602 : H12AffineFastState.Bounded env13602 := by
  intro p hp
  have h : env13602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13601_13602 : H12AffineEnvironment.transform 21 41168 env13601 = env13602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41168 env13601 == env13602) = true)

theorem identity13602 : scanCanonicalize (H12AffineFastState.compose env13602 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 74030) := by decide +kernel

theorem selectedBound13602 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env13603 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,32768,65536,1344,513,1105,32769,1344,41168,65,98565,8328,64,41860,1345,1296,75787,1284,74030,256,81,1344,512]

theorem envBound13603 : H12AffineFastState.Bounded env13603 := by
  intro p hp
  have h : env13603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13602_13603 : H12AffineEnvironment.transform 31 74030 env13602 = env13603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 74030 env13602 == env13603) = true)

def env13604 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1297,32768,65536,1296,513,1025,32769,1296,41088,17,98565,8328,16,41860,1297,1296,75787,1284,74030,256,1,1296,512]

theorem envBound13604 : H12AffineFastState.Bounded env13604 := by
  intro p hp
  have h : env13604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13603_13604 : H12AffineEnvironment.transform 5 16 env13603 = env13604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13603 == env13604) = true)

theorem identity13604 : scanCanonicalize (H12AffineFastState.compose env13604 (packedSelected [1,3,5] rootPS)) = affineNative (2^(15+1) ^^^ 10542) := by decide +kernel

theorem selectedBound13604 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env13605 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1297,32768,10542,1296,513,1025,32769,1296,41088,17,43051,8328,16,41860,1297,1296,293,1284,2048,256,1,1296,512]

theorem envBound13605 : H12AffineFastState.Bounded env13605 := by
  intro p hp
  have h : env13605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13604_13605 : H12AffineEnvironment.transform 15 10542 env13604 = env13605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 10542 env13604 == env13605) = true)

theorem identity13605 : scanCanonicalize (H12AffineFastState.compose env13605 (packedSelected [1,3,8] rootPS)) = affineNative (2^(14+1) ^^^ 10400) := by decide +kernel

theorem selectedBound13605 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env13606 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1297,10400,10542,1296,513,1025,10401,1296,2080,17,139,8328,16,2852,1297,1296,293,1284,2048,256,1,1296,512]

theorem envBound13606 : H12AffineFastState.Bounded env13606 := by
  intro p hp
  have h : env13606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13605_13606 : H12AffineEnvironment.transform 14 10400 env13605 = env13606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 10400 env13605 == env13606) = true)

theorem identity13606 : scanCanonicalize (H12AffineFastState.compose env13606 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound13606 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env13607 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,269,1297,2477,2083,1296,513,1025,2476,1296,2080,17,139,389,16,2852,1297,1296,293,1284,2048,256,1,1296,512]

theorem envBound13607 : H12AffineFastState.Bounded env13607 := by
  intro p hp
  have h : env13607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13606_13607 : H12AffineEnvironment.transform 12 269 env13606 = env13607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env13606 == env13607) = true)

theorem identity13607 : scanCanonicalize (H12AffineFastState.compose env13607 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound13607 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env13608 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,269,1297,2477,2083,1296,136,1025,2476,1296,2080,17,139,389,16,2477,1297,1296,293,1284,2048,256,1,1296,137]

theorem envBound13608 : H12AffineFastState.Bounded env13608 := by
  intro p hp
  have h : env13608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13607_13608 : H12AffineEnvironment.transform 8 137 env13607 = env13608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env13607 == env13608) = true)

theorem identity13608 : scanCanonicalize (H12AffineFastState.compose env13608 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 163) := by decide +kernel

theorem selectedBound13608 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13609 : List Nat := [2,4,8,16,32,16,128,256,137,1024,163,1296,269,1297,270,128,1296,136,1025,271,1296,131,17,139,389,16,270,1297,1296,293,1284,163,256,1,1296,137]

theorem envBound13609 : H12AffineFastState.Bounded env13609 := by
  intro p hp
  have h : env13609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13608_13609 : H12AffineEnvironment.transform 10 163 env13608 = env13609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 163 env13608 == env13609) = true)

theorem identity13609 : scanCanonicalize (H12AffineFastState.compose env13609 (packedSelected [10] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound13609 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env13610 : List Nat := [2,4,8,16,32,16,128,14,137,1024,163,1054,3,1055,0,128,1054,136,1025,1,1054,131,17,139,139,16,0,1055,1054,43,1034,163,14,1,1054,137]

theorem envBound13610 : H12AffineFastState.Bounded env13610 := by
  intro p hp
  have h : env13610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13609_13610 : H12AffineEnvironment.transform 7 14 env13609 = env13610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env13609 == env13610) = true)

theorem identity13610 : scanCanonicalize (H12AffineFastState.compose env13610 (packedSelected [2,4] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound13610 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env13611 : List Nat := [2,4,8,16,32,16,8,14,1,1024,43,1054,3,1055,0,8,1054,0,1025,1,1054,11,17,3,3,16,0,1055,1054,43,1034,43,14,1,1054,1]

theorem envBound13611 : H12AffineFastState.Bounded env13611 := by
  intro p hp
  have h : env13611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13610_13611 : H12AffineEnvironment.transform 6 8 env13610 = env13611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13610 == env13611) = true)

def env13612 : List Nat := [2,4,8,16,0,16,8,14,1,1024,11,1054,3,1055,0,8,1054,0,1025,1,1054,11,17,3,3,16,0,1055,1054,11,1034,11,14,1,1054,1]

theorem envBound13612 : H12AffineFastState.Bounded env13612 := by
  intro p hp
  have h : env13612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13611_13612 : H12AffineEnvironment.transform 4 0 env13611 = env13612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13611 == env13612) = true)

theorem identity13612 : scanCanonicalize (H12AffineFastState.compose env13612 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound13612 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13613 : List Nat := [2,4,8,1,0,1,8,14,1,1024,11,1039,3,1038,0,8,1039,0,1025,1,1039,11,0,3,3,1,0,1038,1039,11,1034,11,14,1,1039,1]

theorem envBound13613 : H12AffineFastState.Bounded env13613 := by
  intro p hp
  have h : env13613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13612_13613 : H12AffineEnvironment.transform 3 1 env13612 = env13613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env13612 == env13613) = true)

def leafEnv13613 : List Nat := [2,4,8,1,0,1,8,14,1,1024,11,1039,3,1038,0,8,1039,0,1025,1,1039,11,0,3,1035,3,1,1,0,1038,1039,11,1034,11,14,1,4,9,1039,1,0,1039,1]

def active13613 : List Nat := [0,1,2,9]

def tree13613 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13613 : H12WitnessSearch.Good tree13613 := H12GlobalWitnessIndex.good

theorem leafIdentity13613 : H12AffineFastState.composeSystem env13613 rootObs = leafEnv13613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13613 rootObs == leafEnv13613) = true)

theorem terminalChecked13613 : H12PackedTerminal.terminalCheckFast leafEnv13613 active13613 tree13613 = true := by decide +kernel

def env13614 : List Nat := [2,4,8,16,1,16,8,14,1,1024,10,1054,3,1055,0,8,1054,0,1025,1,1054,11,17,3,3,16,0,1055,1054,10,1034,10,14,1,1054,1]

theorem envBound13614 : H12AffineFastState.Bounded env13614 := by
  intro p hp
  have h : env13614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13611_13614 : H12AffineEnvironment.transform 4 1 env13611 = env13614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13611 == env13614) = true)

theorem identity13614 : scanCanonicalize (H12AffineFastState.compose env13614 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound13614 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13615 : List Nat := [2,4,8,11,1,11,8,14,1,1024,10,1029,3,1028,0,8,1029,0,1025,1,1029,11,10,3,3,11,0,1028,1029,10,1034,10,14,1,1029,1]

theorem envBound13615 : H12AffineFastState.Bounded env13615 := by
  intro p hp
  have h : env13615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13614_13615 : H12AffineEnvironment.transform 3 11 env13614 = env13615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env13614 == env13615) = true)

def leafEnv13615 : List Nat := [2,4,8,11,1,11,8,14,1,1024,10,1029,3,1028,0,8,1029,0,1025,1,1029,11,10,3,1035,3,1,11,0,1028,1029,10,1034,10,14,1,4,9,1029,1,0,1029,1]

def active13615 : List Nat := [0,1,2,9]

def tree13615 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13615 : H12WitnessSearch.Good tree13615 := H12GlobalWitnessIndex.good

theorem leafIdentity13615 : H12AffineFastState.composeSystem env13615 rootObs = leafEnv13615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13615 rootObs == leafEnv13615) = true)

theorem terminalChecked13615 : H12PackedTerminal.terminalCheckFast leafEnv13615 active13615 tree13615 = true := by decide +kernel

def env13616 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1296,32768,65536,1297,513,1024,32769,1297,41089,16,98565,8328,17,41860,1296,1296,75787,1284,74030,256,0,1297,512]

theorem envBound13616 : H12AffineFastState.Bounded env13616 := by
  intro p hp
  have h : env13616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13603_13616 : H12AffineEnvironment.transform 5 17 env13603 = env13616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env13603 == env13616) = true)

theorem identity13616 : scanCanonicalize (H12AffineFastState.compose env13616 (packedSelected [1,3,5] rootPS)) = affineNative (2^(14+1) ^^^ 10792) := by decide +kernel

theorem selectedBound13616 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env13617 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1296,10792,65536,1297,513,1024,10793,1297,2729,16,76589,8328,17,2476,1296,1296,75787,1284,74030,256,0,1297,512]

theorem envBound13617 : H12AffineFastState.Bounded env13617 := by
  intro p hp
  have h : env13617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13616_13617 : H12AffineEnvironment.transform 14 10792 env13616 = env13617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 10792 env13616 == env13617) = true)

theorem identity13617 : scanCanonicalize (H12AffineFastState.compose env13617 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 2088) := by decide +kernel

theorem selectedBound13617 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13618 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,2088,1296,512,65536,1297,513,1024,513,1297,2729,16,66309,2208,17,2476,1296,1296,65571,1284,67846,256,0,1297,512]

theorem envBound13618 : H12AffineFastState.Bounded env13618 := by
  intro p hp
  have h : env13618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13617_13618 : H12AffineEnvironment.transform 12 2088 env13617 = env13618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2088 env13617 == env13618) = true)

theorem identity13618 : scanCanonicalize (H12AffineFastState.compose env13618 (packedSelected [3,8] rootPS)) = affineNative (2^(15+1) ^^^ 910) := by decide +kernel

theorem selectedBound13618 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env13619 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,2088,1296,512,910,1297,513,1024,513,1297,2729,16,139,2208,17,2476,1296,1296,941,1284,2696,256,0,1297,512]

theorem envBound13619 : H12AffineFastState.Bounded env13619 := by
  intro p hp
  have h : env13619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13618_13619 : H12AffineEnvironment.transform 15 910 env13618 = env13619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 910 env13618 == env13619) = true)

theorem identity13619 : scanCanonicalize (H12AffineFastState.compose env13619 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 941) := by decide +kernel

theorem selectedBound13619 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env13620 : List Nat := [2,4,8,16,32,17,128,256,512,1024,941,1297,901,1296,512,910,1297,513,1024,513,1297,260,16,139,781,17,513,1296,1296,941,1284,293,256,0,1297,512]

theorem envBound13620 : H12AffineFastState.Bounded env13620 := by
  intro p hp
  have h : env13620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13619_13620 : H12AffineEnvironment.transform 10 941 env13619 = env13620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 941 env13619 == env13620) = true)

theorem identity13620 : scanCanonicalize (H12AffineFastState.compose env13620 (packedSelected [12] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound13620 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env13621 : List Nat := [2,4,8,16,32,17,8,256,512,1024,805,1297,781,1296,512,774,1297,513,1024,513,1297,260,16,3,781,17,513,1296,1296,805,1284,293,256,0,1297,512]

theorem envBound13621 : H12AffineFastState.Bounded env13621 := by
  intro p hp
  have h : env13621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13620_13621 : H12AffineEnvironment.transform 6 8 env13620 = env13621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13620 == env13621) = true)

def env13622 : List Nat := [2,4,8,16,0,17,8,256,512,1024,773,1297,781,1296,512,774,1297,513,1024,513,1297,260,16,3,781,17,513,1296,1296,773,1284,261,256,0,1297,512]

theorem envBound13622 : H12AffineFastState.Bounded env13622 := by
  intro p hp
  have h : env13622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13621_13622 : H12AffineEnvironment.transform 4 0 env13621 = env13622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13621 == env13622) = true)

theorem identity13622 : scanCanonicalize (H12AffineFastState.compose env13622 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound13622 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13623 : List Nat := [2,4,8,16,0,17,8,256,0,1024,261,1297,269,1296,0,262,1297,1,1024,1,1297,260,16,3,269,17,1,1296,1296,261,1284,261,256,0,1297,0]

theorem envBound13623 : H12AffineFastState.Bounded env13623 := by
  intro p hp
  have h : env13623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13622_13623 : H12AffineEnvironment.transform 8 0 env13622 = env13623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env13622 == env13623) = true)

def leafEnv13623 : List Nat := [2,4,8,16,0,17,8,256,0,1024,261,1297,269,1296,0,262,1297,1,1024,1,1297,260,16,3,1284,269,1,17,1,1296,1296,261,1284,261,256,0,4,263,1297,0,0,1296,1]

def active13623 : List Nat := [0,1,2,3,7,9]

def tree13623 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13623 : H12WitnessSearch.Good tree13623 := H12GlobalWitnessIndex.good

theorem leafIdentity13623 : H12AffineFastState.composeSystem env13623 rootObs = leafEnv13623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13623 rootObs == leafEnv13623) = true)

theorem terminalChecked13623 : H12PackedTerminal.terminalCheckFast leafEnv13623 active13623 tree13623 = true := by decide +kernel

def env13624 : List Nat := [2,4,8,16,1,17,8,256,512,1024,772,1297,781,1296,512,774,1297,513,1024,513,1297,260,16,3,781,17,513,1296,1296,772,1284,260,256,0,1297,512]

theorem envBound13624 : H12AffineFastState.Bounded env13624 := by
  intro p hp
  have h : env13624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13621_13624 : H12AffineEnvironment.transform 4 1 env13621 = env13624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13621 == env13624) = true)

theorem identity13624 : scanCanonicalize (H12AffineFastState.compose env13624 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound13624 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13625 : List Nat := [2,4,8,16,1,17,8,256,260,1024,0,1297,9,1296,260,2,1297,261,1024,261,1297,260,16,3,9,17,261,1296,1296,0,1284,260,256,0,1297,260]

theorem envBound13625 : H12AffineFastState.Bounded env13625 := by
  intro p hp
  have h : env13625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13624_13625 : H12AffineEnvironment.transform 8 260 env13624 = env13625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env13624 == env13625) = true)

def leafEnv13625 : List Nat := [2,4,8,16,1,17,8,256,260,1024,0,1297,9,1296,260,2,1297,261,1024,261,1297,260,16,3,1284,9,1,17,261,1296,1296,0,1284,260,256,0,4,3,1297,260,0,1296,1]

def active13625 : List Nat := [0,1,2,3,7,9]

def tree13625 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13625 : H12WitnessSearch.Good tree13625 := H12GlobalWitnessIndex.good

theorem leafIdentity13625 : H12AffineFastState.composeSystem env13625 rootObs = leafEnv13625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13625 rootObs == leafEnv13625) = true)

theorem terminalChecked13625 : H12PackedTerminal.terminalCheckFast leafEnv13625 active13625 tree13625 = true := by decide +kernel

def env13626 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,32768,65536,1344,513,1105,32769,1344,41169,65,98565,8328,64,41861,1345,1296,75786,1284,4294967296,256,4295041406,1344,512]

theorem envBound13626 : H12AffineFastState.Bounded env13626 := by
  intro p hp
  have h : env13626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13601_13626 : H12AffineEnvironment.transform 21 41169 env13601 = env13626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41169 env13601 == env13626) = true)

theorem identity13626 : scanCanonicalize (H12AffineFastState.compose env13626 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 98339) := by decide +kernel

theorem selectedBound13626 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env13627 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,32768,65536,1344,513,1105,32769,1344,41169,65,98565,8328,64,41861,1345,1296,75786,1284,98339,256,41309,1344,512]

theorem envBound13627 : H12AffineFastState.Bounded env13627 := by
  intro p hp
  have h : env13627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13626_13627 : H12AffineEnvironment.transform 31 98339 env13626 = env13627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 98339 env13626 == env13627) = true)

def env13628 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1297,32768,65536,1296,513,1025,32769,1296,41089,17,98565,8328,16,41861,1297,1296,75786,1284,98339,256,41229,1296,512]

theorem envBound13628 : H12AffineFastState.Bounded env13628 := by
  intro p hp
  have h : env13628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13627_13628 : H12AffineEnvironment.transform 5 16 env13627 = env13628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13627 == env13628) = true)

theorem identity13628 : scanCanonicalize (H12AffineFastState.compose env13628 (packedSelected [1,3,5] rootPS)) = affineNative (2^(15+1) ^^^ 10542) := by decide +kernel

theorem selectedBound13628 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env13629 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1297,32768,10542,1296,513,1025,32769,1296,41089,17,43051,8328,16,41861,1297,1296,292,1284,43277,256,41229,1296,512]

theorem envBound13629 : H12AffineFastState.Bounded env13629 := by
  intro p hp
  have h : env13629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13628_13629 : H12AffineEnvironment.transform 15 10542 env13628 = env13629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 10542 env13628 == env13629) = true)

theorem identity13629 : scanCanonicalize (H12AffineFastState.compose env13629 (packedSelected [1,3,8] rootPS)) = affineNative (2^(14+1) ^^^ 10400) := by decide +kernel

theorem selectedBound13629 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env13630 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1297,10400,10542,1296,513,1025,10401,1296,2081,17,139,8328,16,2853,1297,1296,292,1284,429,256,2477,1296,512]

theorem envBound13630 : H12AffineFastState.Bounded env13630 := by
  intro p hp
  have h : env13630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13629_13630 : H12AffineEnvironment.transform 14 10400 env13629 = env13630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 10400 env13629 == env13630) = true)

theorem identity13630 : scanCanonicalize (H12AffineFastState.compose env13630 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound13630 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env13631 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,268,1297,2476,2082,1296,513,1025,2477,1296,2081,17,139,388,16,2853,1297,1296,292,1284,429,256,2477,1296,512]

theorem envBound13631 : H12AffineFastState.Bounded env13631 := by
  intro p hp
  have h : env13631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13630_13631 : H12AffineEnvironment.transform 12 268 env13630 = env13631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env13630 == env13631) = true)

theorem identity13631 : scanCanonicalize (H12AffineFastState.compose env13631 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound13631 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env13632 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,268,1297,2476,2082,1296,136,1025,2477,1296,2081,17,139,388,16,2476,1297,1296,292,1284,429,256,2477,1296,137]

theorem envBound13632 : H12AffineFastState.Bounded env13632 := by
  intro p hp
  have h : env13632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13631_13632 : H12AffineEnvironment.transform 8 137 env13631 = env13632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env13631 == env13632) = true)

theorem identity13632 : scanCanonicalize (H12AffineFastState.compose env13632 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 162) := by decide +kernel

theorem selectedBound13632 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13633 : List Nat := [2,4,8,16,32,16,128,256,137,1024,162,1296,268,1297,270,128,1296,136,1025,271,1296,131,17,139,388,16,270,1297,1296,292,1284,429,256,271,1296,137]

theorem envBound13633 : H12AffineFastState.Bounded env13633 := by
  intro p hp
  have h : env13633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13632_13633 : H12AffineEnvironment.transform 10 162 env13632 = env13633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 162 env13632 == env13633) = true)

theorem identity13633 : scanCanonicalize (H12AffineFastState.compose env13633 (packedSelected [10] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound13633 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env13634 : List Nat := [2,4,8,16,32,16,128,15,137,1024,162,1055,3,1054,1,128,1055,136,1025,0,1055,131,17,139,139,16,1,1054,1055,43,1035,162,15,0,1055,137]

theorem envBound13634 : H12AffineFastState.Bounded env13634 := by
  intro p hp
  have h : env13634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13633_13634 : H12AffineEnvironment.transform 7 15 env13633 = env13634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env13633 == env13634) = true)

theorem identity13634 : scanCanonicalize (H12AffineFastState.compose env13634 (packedSelected [2,4] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound13634 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env13635 : List Nat := [2,4,8,16,32,16,9,15,0,1024,43,1055,3,1054,1,9,1055,1,1025,0,1055,10,17,2,2,16,1,1054,1055,43,1035,43,15,0,1055,0]

theorem envBound13635 : H12AffineFastState.Bounded env13635 := by
  intro p hp
  have h : env13635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13634_13635 : H12AffineEnvironment.transform 6 9 env13634 = env13635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env13634 == env13635) = true)

def env13636 : List Nat := [2,4,8,16,0,16,9,15,0,1024,11,1055,3,1054,1,9,1055,1,1025,0,1055,10,17,2,2,16,1,1054,1055,11,1035,11,15,0,1055,0]

theorem envBound13636 : H12AffineFastState.Bounded env13636 := by
  intro p hp
  have h : env13636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13635_13636 : H12AffineEnvironment.transform 4 0 env13635 = env13636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13635 == env13636) = true)

theorem identity13636 : scanCanonicalize (H12AffineFastState.compose env13636 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound13636 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13637 : List Nat := [2,4,8,10,0,10,9,15,0,1024,11,1029,3,1028,1,9,1029,1,1025,0,1029,10,11,2,2,10,1,1028,1029,11,1035,11,15,0,1029,0]

theorem envBound13637 : H12AffineFastState.Bounded env13637 := by
  intro p hp
  have h : env13637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13636_13637 : H12AffineEnvironment.transform 3 10 env13636 = env13637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env13636 == env13637) = true)

def leafEnv13637 : List Nat := [2,4,8,10,0,10,9,15,0,1024,11,1029,3,1028,1,9,1029,1,1025,0,1029,10,11,2,1034,2,1,10,1,1028,1029,11,1035,11,15,0,4,9,1029,0,0,1029,1]

def active13637 : List Nat := [0,1,2,9]

def tree13637 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13637 : H12WitnessSearch.Good tree13637 := H12GlobalWitnessIndex.good

theorem leafIdentity13637 : H12AffineFastState.composeSystem env13637 rootObs = leafEnv13637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13637 rootObs == leafEnv13637) = true)

theorem terminalChecked13637 : H12PackedTerminal.terminalCheckFast leafEnv13637 active13637 tree13637 = true := by decide +kernel

def env13638 : List Nat := [2,4,8,16,1,16,9,15,0,1024,10,1055,3,1054,1,9,1055,1,1025,0,1055,10,17,2,2,16,1,1054,1055,10,1035,10,15,0,1055,0]

theorem envBound13638 : H12AffineFastState.Bounded env13638 := by
  intro p hp
  have h : env13638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13635_13638 : H12AffineEnvironment.transform 4 1 env13635 = env13638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13635 == env13638) = true)

theorem identity13638 : scanCanonicalize (H12AffineFastState.compose env13638 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound13638 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13639 : List Nat := [2,4,8,0,1,0,9,15,0,1024,10,1039,3,1038,1,9,1039,1,1025,0,1039,10,1,2,2,0,1,1038,1039,10,1035,10,15,0,1039,0]

theorem envBound13639 : H12AffineFastState.Bounded env13639 := by
  intro p hp
  have h : env13639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13638_13639 : H12AffineEnvironment.transform 3 0 env13638 = env13639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env13638 == env13639) = true)

def leafEnv13639 : List Nat := [2,4,8,0,1,0,9,15,0,1024,10,1039,3,1038,1,9,1039,1,1025,0,1039,10,1,2,1034,2,1,0,1,1038,1039,10,1035,10,15,0,4,9,1039,0,0,1039,1]

def active13639 : List Nat := [0,1,2,9]

def tree13639 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13639 : H12WitnessSearch.Good tree13639 := H12GlobalWitnessIndex.good

theorem leafIdentity13639 : H12AffineFastState.composeSystem env13639 rootObs = leafEnv13639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13639 rootObs == leafEnv13639) = true)

theorem terminalChecked13639 : H12PackedTerminal.terminalCheckFast leafEnv13639 active13639 tree13639 = true := by decide +kernel

def env13640 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1296,32768,65536,1297,513,1024,32769,1297,41088,16,98565,8328,17,41861,1296,1296,75786,1284,98339,256,41228,1297,512]

theorem envBound13640 : H12AffineFastState.Bounded env13640 := by
  intro p hp
  have h : env13640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13627_13640 : H12AffineEnvironment.transform 5 17 env13627 = env13640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env13627 == env13640) = true)

theorem identity13640 : scanCanonicalize (H12AffineFastState.compose env13640 (packedSelected [1,3,5] rootPS)) = affineNative (2^(14+1) ^^^ 10792) := by decide +kernel

theorem selectedBound13640 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env13641 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1296,10792,65536,1297,513,1024,10793,1297,2728,16,76589,8328,17,2477,1296,1296,75786,1284,76299,256,2852,1297,512]

theorem envBound13641 : H12AffineFastState.Bounded env13641 := by
  intro p hp
  have h : env13641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13640_13641 : H12AffineEnvironment.transform 14 10792 env13640 = env13641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 10792 env13640 == env13641) = true)

theorem identity13641 : scanCanonicalize (H12AffineFastState.compose env13641 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 2089) := by decide +kernel

theorem selectedBound13641 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13642 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,2089,1296,513,65536,1297,513,1024,512,1297,2728,16,66308,2209,17,2477,1296,1296,65571,1284,66082,256,2852,1297,512]

theorem envBound13642 : H12AffineFastState.Bounded env13642 := by
  intro p hp
  have h : env13642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13641_13642 : H12AffineEnvironment.transform 12 2089 env13641 = env13642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2089 env13641 == env13642) = true)

theorem identity13642 : scanCanonicalize (H12AffineFastState.compose env13642 (packedSelected [3,8] rootPS)) = affineNative (2^(15+1) ^^^ 911) := by decide +kernel

theorem selectedBound13642 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env13643 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,2089,1296,513,911,1297,513,1024,512,1297,2728,16,139,2209,17,2477,1296,1296,940,1284,429,256,2852,1297,512]

theorem envBound13643 : H12AffineFastState.Bounded env13643 := by
  intro p hp
  have h : env13643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13642_13643 : H12AffineEnvironment.transform 15 911 env13642 = env13643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 911 env13642 == env13643) = true)

theorem identity13643 : scanCanonicalize (H12AffineFastState.compose env13643 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 940) := by decide +kernel

theorem selectedBound13643 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env13644 : List Nat := [2,4,8,16,32,17,128,256,512,1024,940,1297,901,1296,513,911,1297,513,1024,512,1297,260,16,139,781,17,513,1296,1296,940,1284,429,256,136,1297,512]

theorem envBound13644 : H12AffineFastState.Bounded env13644 := by
  intro p hp
  have h : env13644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13643_13644 : H12AffineEnvironment.transform 10 940 env13643 = env13644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 940 env13643 == env13644) = true)

theorem identity13644 : scanCanonicalize (H12AffineFastState.compose env13644 (packedSelected [12] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound13644 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env13645 : List Nat := [2,4,8,16,32,17,8,256,512,1024,804,1297,781,1296,513,775,1297,513,1024,512,1297,260,16,3,781,17,513,1296,1296,804,1284,293,256,0,1297,512]

theorem envBound13645 : H12AffineFastState.Bounded env13645 := by
  intro p hp
  have h : env13645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13644_13645 : H12AffineEnvironment.transform 6 8 env13644 = env13645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env13644 == env13645) = true)

def env13646 : List Nat := [2,4,8,16,0,17,8,256,512,1024,772,1297,781,1296,513,775,1297,513,1024,512,1297,260,16,3,781,17,513,1296,1296,772,1284,261,256,0,1297,512]

theorem envBound13646 : H12AffineFastState.Bounded env13646 := by
  intro p hp
  have h : env13646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13645_13646 : H12AffineEnvironment.transform 4 0 env13645 = env13646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env13645 == env13646) = true)

theorem identity13646 : scanCanonicalize (H12AffineFastState.compose env13646 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound13646 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13647 : List Nat := [2,4,8,16,0,17,8,256,0,1024,260,1297,269,1296,1,263,1297,1,1024,0,1297,260,16,3,269,17,1,1296,1296,260,1284,261,256,0,1297,0]

theorem envBound13647 : H12AffineFastState.Bounded env13647 := by
  intro p hp
  have h : env13647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13646_13647 : H12AffineEnvironment.transform 8 0 env13646 = env13647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env13646 == env13647) = true)

def leafEnv13647 : List Nat := [2,4,8,16,0,17,8,256,0,1024,260,1297,269,1296,1,263,1297,1,1024,0,1297,260,16,3,1284,269,1,17,1,1296,1296,260,1284,261,256,0,4,262,1297,0,0,1296,1]

def active13647 : List Nat := [0,1,2,3,7,9]

def tree13647 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13647 : H12WitnessSearch.Good tree13647 := H12GlobalWitnessIndex.good

theorem leafIdentity13647 : H12AffineFastState.composeSystem env13647 rootObs = leafEnv13647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13647 rootObs == leafEnv13647) = true)

theorem terminalChecked13647 : H12PackedTerminal.terminalCheckFast leafEnv13647 active13647 tree13647 = true := by decide +kernel

def env13648 : List Nat := [2,4,8,16,1,17,8,256,512,1024,773,1297,781,1296,513,775,1297,513,1024,512,1297,260,16,3,781,17,513,1296,1296,773,1284,260,256,0,1297,512]

theorem envBound13648 : H12AffineFastState.Bounded env13648 := by
  intro p hp
  have h : env13648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13645_13648 : H12AffineEnvironment.transform 4 1 env13645 = env13648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env13645 == env13648) = true)

theorem identity13648 : scanCanonicalize (H12AffineFastState.compose env13648 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound13648 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13649 : List Nat := [2,4,8,16,1,17,8,256,260,1024,1,1297,9,1296,261,3,1297,261,1024,260,1297,260,16,3,9,17,261,1296,1296,1,1284,260,256,0,1297,260]

theorem envBound13649 : H12AffineFastState.Bounded env13649 := by
  intro p hp
  have h : env13649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13648_13649 : H12AffineEnvironment.transform 8 260 env13648 = env13649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env13648 == env13649) = true)

def leafEnv13649 : List Nat := [2,4,8,16,1,17,8,256,260,1024,1,1297,9,1296,261,3,1297,261,1024,260,1297,260,16,3,1284,9,1,17,261,1296,1296,1,1284,260,256,0,4,2,1297,260,0,1296,1]

def active13649 : List Nat := [0,1,2,3,7,9]

def tree13649 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13649 : H12WitnessSearch.Good tree13649 := H12GlobalWitnessIndex.good

theorem leafIdentity13649 : H12AffineFastState.composeSystem env13649 rootObs = leafEnv13649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13649 rootObs == leafEnv13649) = true)

theorem terminalChecked13649 : H12PackedTerminal.terminalCheckFast leafEnv13649 active13649 tree13649 = true := by decide +kernel

def env13650 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,16384,32768,65536,1344,262144,524288,32769,1345,4194304,17664,98565,8328,541008,134217728,16384,541697,1073741824,1284,4294967296,256,4299260335,139198532,512]

theorem envBound13650 : H12AffineFastState.Bounded env13650 := by
  intro p hp
  have h : env13650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13111_13650 : H12AffineEnvironment.transform 11 1345 env13111 = env13650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env13111 == env13650) = true)

def env13651 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,65536,1344,262144,524288,32769,1345,4194304,64,98565,8328,525328,134217728,1344,524609,1073741824,1284,4294967296,256,4299260335,139198532,512]

theorem envBound13651 : H12AffineFastState.Bounded env13651 := by
  intro p hp
  have h : env13651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13650_13651 : H12AffineEnvironment.transform 13 1344 env13650 = env13651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env13650 == env13651) = true)

theorem identity13651 : scanCanonicalize (H12AffineFastState.compose env13651 (packedSelected [9,22] rootPS)) = affineNative (2^(26+1) ^^^ 4982020) := by decide +kernel

theorem selectedBound13651 : packedSelected [9,22] rootPS < 2^1333 := by decide +kernel

def env13652 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,65536,1344,262144,524288,32769,1345,4194304,64,98565,8328,525328,4982020,1344,524609,1073741824,1284,4294967296,256,4299260335,1344,512]

theorem envBound13652 : H12AffineFastState.Bounded env13652 := by
  intro p hp
  have h : env13652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13651_13652 : H12AffineEnvironment.transform 26 4982020 env13651 = env13652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 4982020 env13651 == env13652) = true)

def env13653 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,65536,1344,262144,1104,32769,1345,4194304,64,98565,8328,64,4456788,1344,1297,1073741824,1284,4294967296,256,4299260335,1344,512]

theorem envBound13653 : H12AffineFastState.Bounded env13653 := by
  intro p hp
  have h : env13653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13652_13653 : H12AffineEnvironment.transform 18 1104 env13652 = env13653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1104 env13652 == env13653) = true)

theorem identity13653 : scanCanonicalize (H12AffineFastState.compose env13653 (packedSelected [8,10,13,15] rootPS)) = affineNative (2^(21+1) ^^^ 363049) := by decide +kernel

theorem selectedBound13653 : packedSelected [8,10,13,15] rootPS < 2^1333 := by decide +kernel

def env13654 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,65536,1344,262144,1104,32769,1345,363049,64,98565,8328,64,101245,1344,1297,1073741824,1284,4294967296,256,4295232390,1344,512]

theorem envBound13654 : H12AffineFastState.Bounded env13654 := by
  intro p hp
  have h : env13654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13653_13654 : H12AffineEnvironment.transform 21 363049 env13653 = env13654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 363049 env13653 == env13654) = true)

theorem identity13654 : scanCanonicalize (H12AffineFastState.compose env13654 (packedSelected [3,8,10,13,17] rootPS)) = affineNative (2^(29+1) ^^^ 2421) := by decide +kernel

theorem selectedBound13654 : packedSelected [3,8,10,13,17] rootPS < 2^1333 := by decide +kernel

def env13655 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,65536,1344,262144,1104,32769,1345,363049,64,98565,8328,64,101245,1344,1297,2421,1284,4294967296,256,4295232390,1344,512]

theorem envBound13655 : H12AffineFastState.Bounded env13655 := by
  intro p hp
  have h : env13655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13654_13655 : H12AffineEnvironment.transform 29 2421 env13654 = env13655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 2421 env13654 == env13655) = true)

theorem identity13655 : scanCanonicalize (H12AffineFastState.compose env13655 (packedSelected [8,12,19,21] rootPS)) = affineNative (2^(17+1) ^^^ 76279) := by decide +kernel

theorem selectedBound13655 : packedSelected [8,12,19,21] rootPS < 2^1333 := by decide +kernel

def env13656 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,65536,1344,76279,1104,32769,1345,41950,64,98565,8328,64,101245,1344,1297,2421,1284,4294967296,256,4295041649,1344,512]

theorem envBound13656 : H12AffineFastState.Bounded env13656 := by
  intro p hp
  have h : env13656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13655_13656 : H12AffineEnvironment.transform 17 76279 env13655 = env13656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76279 env13655 == env13656) = true)

theorem identity13656 : scanCanonicalize (H12AffineFastState.compose env13656 (packedSelected [3,5,24] rootPS)) = affineNative (2^(15+1) ^^^ 33166) := by decide +kernel

theorem selectedBound13656 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env13657 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,33166,1344,43129,1104,32769,1345,41950,64,139,8328,64,2803,1344,1297,2421,1284,4294967296,256,4295009279,1344,512]

theorem envBound13657 : H12AffineFastState.Bounded env13657 := by
  intro p hp
  have h : env13657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13656_13657 : H12AffineEnvironment.transform 15 33166 env13656 = env13657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33166 env13656 == env13657) = true)

theorem identity13657 : scanCanonicalize (H12AffineFastState.compose env13657 (packedSelected [11,32] rootPS)) = affineNative (2^(14+1) ^^^ 9215) := by decide +kernel

theorem selectedBound13657 : packedSelected [11,32] rootPS < 2^1333 := by decide +kernel

def env13658 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,9215,8817,1344,2950,1104,9214,1345,33,64,139,8328,64,2803,1344,1297,2421,1284,4294967296,256,4294967296,1344,512]

theorem envBound13658 : H12AffineFastState.Bounded env13658 := by
  intro p hp
  have h : env13658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13657_13658 : H12AffineEnvironment.transform 14 9215 env13657 = env13658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9215 env13657 == env13658) = true)

theorem identity13658 : scanCanonicalize (H12AffineFastState.compose env13658 (packedSelected [3,5] rootPS)) = affineNative (2^(8+1) ^^^ 243) := by decide +kernel

theorem selectedBound13658 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env13659 : List Nat := [2,4,8,16,32,64,128,256,243,1024,2048,1345,8192,1344,8460,8322,1344,2421,1104,8461,1345,33,64,139,8328,64,2048,1344,1297,2421,1284,4294967296,256,4294967296,1344,243]

theorem envBound13659 : H12AffineFastState.Bounded env13659 := by
  intro p hp
  have h : env13659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13658_13659 : H12AffineEnvironment.transform 8 243 env13658 = env13659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 243 env13658 == env13659) = true)

theorem identity13659 : scanCanonicalize (H12AffineFastState.compose env13659 (packedSelected [0,2,4] rootPS)) = affineNative (2^(31+1) ^^^ 10361) := by decide +kernel

theorem selectedBound13659 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env13660 : List Nat := [2,4,8,16,32,64,128,256,243,1024,2048,1345,8192,1344,8460,8322,1344,2421,1104,8461,1345,33,64,139,8328,64,2048,1344,1297,2421,1284,10361,256,10361,1344,243]

theorem envBound13660 : H12AffineFastState.Bounded env13660 := by
  intro p hp
  have h : env13660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13659_13660 : H12AffineEnvironment.transform 31 10361 env13659 = env13660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 10361 env13659 == env13660) = true)

theorem identity13660 : scanCanonicalize (H12AffineFastState.compose env13660 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 2089) := by decide +kernel

theorem selectedBound13660 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env13661 : List Nat := [2,4,8,16,32,64,128,256,243,1024,2048,1345,2089,1344,2341,2219,1344,2421,1104,2340,1345,33,64,139,2209,64,2048,1344,1297,2421,1284,80,256,80,1344,243]

theorem envBound13661 : H12AffineFastState.Bounded env13661 := by
  intro p hp
  have h : env13661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13660_13661 : H12AffineEnvironment.transform 12 2089 env13660 = env13661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2089 env13660 == env13661) = true)

theorem identity13661 : scanCanonicalize (H12AffineFastState.compose env13661 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound13661 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env13662 : List Nat := [2,4,8,16,32,16,128,256,163,1024,2048,1297,2089,1296,2341,2219,1296,2341,1024,2340,1297,33,16,139,2209,16,2048,1296,1297,2341,1284,0,256,0,1296,163]

theorem envBound13662 : H12AffineFastState.Bounded env13662 := by
  intro p hp
  have h : env13662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13661_13662 : H12AffineEnvironment.transform 5 16 env13661 = env13662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13661 == env13662) = true)

def env13663 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,65536,1344,262144,1105,32769,1345,4194304,64,98565,8328,65,4456789,1344,1296,1073741824,1284,4294967296,256,4299260335,1344,512]

theorem envBound13663 : H12AffineFastState.Bounded env13663 := by
  intro p hp
  have h : env13663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13652_13663 : H12AffineEnvironment.transform 18 1105 env13652 = env13663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1105 env13652 == env13663) = true)

theorem identity13663 : scanCanonicalize (H12AffineFastState.compose env13663 (packedSelected [8,10,13,15] rootPS)) = affineNative (2^(8+1) ^^^ 217) := by decide +kernel

theorem selectedBound13663 : packedSelected [8,10,13,15] rootPS < 2^1333 := by decide +kernel

def env13664 : List Nat := [2,4,8,16,32,64,128,256,217,1024,2048,1345,8192,1344,32768,65536,1344,262144,1105,32769,1345,4194304,64,98565,8328,65,4456789,1344,1296,1073741824,1284,4294967296,256,4299260335,1344,217]

theorem envBound13664 : H12AffineFastState.Bounded env13664 := by
  intro p hp
  have h : env13664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13663_13664 : H12AffineEnvironment.transform 8 217 env13663 = env13664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env13663 == env13664) = true)

def env13665 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1297,8192,1296,32768,65536,1296,262144,1025,32769,1297,4194304,16,98565,8328,17,4456709,1296,1296,1073741824,1284,4294967296,256,4299260335,1296,137]

theorem envBound13665 : H12AffineFastState.Bounded env13665 := by
  intro p hp
  have h : env13665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13664_13665 : H12AffineEnvironment.transform 5 16 env13664 = env13665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env13664 == env13665) = true)

theorem identity13665 : scanCanonicalize (H12AffineFastState.compose env13665 (packedSelected [1,3,5] rootPS)) = affineNative (2^(29+1) ^^^ 4196613) := by decide +kernel

theorem selectedBound13665 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env13666 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1297,8192,1296,32768,65536,1296,262144,1025,32769,1297,4194304,16,98565,8328,17,4456709,1296,1296,4196613,1284,4294967296,256,4299260335,1296,137]

theorem envBound13666 : H12AffineFastState.Bounded env13666 := by
  intro p hp
  have h : env13666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13665_13666 : H12AffineEnvironment.transform 29 4196613 env13665 = env13666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4196613 env13665 == env13666) = true)

theorem identity13666 : scanCanonicalize (H12AffineFastState.compose env13666 (packedSelected [1,3] rootPS)) = affineNative (2^(17+1) ^^^ 32768) := by decide +kernel

theorem selectedBound13666 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env13667 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1297,8192,1296,32768,65536,1296,32768,1025,32769,1297,4194304,16,98565,8328,17,4227333,1296,1296,4196613,1284,4294967296,256,4299260335,1296,137]

theorem envBound13667 : H12AffineFastState.Bounded env13667 := by
  intro p hp
  have h : env13667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13666_13667 : H12AffineEnvironment.transform 17 32768 env13666 = env13667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32768 env13666 == env13667) = true)

theorem identity13667 : scanCanonicalize (H12AffineFastState.compose env13667 (packedSelected [8] rootPS)) = affineNative (2^(15+1) ^^^ 43430) := by decide +kernel

theorem selectedBound13667 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env13668 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1297,8192,1296,32768,43430,1296,32768,1025,32769,1297,4194304,16,10403,8328,17,4227333,1296,1296,4196613,1284,4294967296,256,4299171849,1296,137]

theorem envBound13668 : H12AffineFastState.Bounded env13668 := by
  intro p hp
  have h : env13668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13667_13668 : H12AffineEnvironment.transform 15 43430 env13667 = env13668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 43430 env13667 == env13668) = true)

theorem identity13668 : scanCanonicalize (H12AffineFastState.compose env13668 (packedSelected [1] rootPS)) = affineNative (2^(21+1) ^^^ 10275) := by decide +kernel

theorem selectedBound13668 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13669 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1297,8192,1296,32768,43430,1296,32768,1025,32769,1297,10275,16,10403,8328,17,43302,1296,1296,8486,1284,4294967296,256,4294967338,1296,137]

theorem envBound13669 : H12AffineFastState.Bounded env13669 := by
  intro p hp
  have h : env13669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13668_13669 : H12AffineEnvironment.transform 21 10275 env13668 = env13669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10275 env13668 == env13669) = true)

theorem identity13669 : scanCanonicalize (H12AffineFastState.compose env13669 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 2088) := by decide +kernel

theorem selectedBound13669 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env13670 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1297,2088,1296,32768,33166,1296,32768,1025,32769,1297,11,16,139,2208,17,33038,1296,1296,2318,1284,4294967296,256,4294967338,1296,137]

theorem envBound13670 : H12AffineFastState.Bounded env13670 := by
  intro p hp
  have h : env13670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13669_13670 : H12AffineEnvironment.transform 12 2088 env13669 = env13670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2088 env13669 == env13670) = true)

theorem identity13670 : scanCanonicalize (H12AffineFastState.compose env13670 (packedSelected [10] rootPS)) = affineNative (2^(14+1) ^^^ 2341) := by decide +kernel

theorem selectedBound13670 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env13671 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1297,2088,1296,2341,2219,1296,2341,1025,2340,1297,11,16,139,2208,17,2091,1296,1296,2318,1284,4294967296,256,4294967338,1296,137]

theorem envBound13671 : H12AffineFastState.Bounded env13671 := by
  intro p hp
  have h : env13671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13670_13671 : H12AffineEnvironment.transform 14 2341 env13670 = env13671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2341 env13670 == env13671) = true)

theorem identity13671 : scanCanonicalize (H12AffineFastState.compose env13671 (packedSelected [0,2,4] rootPS)) = affineNative (2^(31+1) ^^^ 429) := by decide +kernel

theorem selectedBound13671 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env13672 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1297,2088,1296,2341,2219,1296,2341,1025,2340,1297,11,16,139,2208,17,2091,1296,1296,2318,1284,429,256,391,1296,137]

theorem envBound13672 : H12AffineFastState.Bounded env13672 := by
  intro p hp
  have h : env13672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13671_13672 : H12AffineEnvironment.transform 31 429 env13671 = env13672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 429 env13671 == env13672) = true)

theorem identity13672 : scanCanonicalize (H12AffineFastState.compose env13672 (packedSelected [7] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound13672 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env13673 : List Nat := [2,4,8,16,32,16,128,14,137,1024,2048,1055,2088,1054,2091,2219,1054,2091,1025,2090,1055,11,16,139,2208,17,2091,1054,1054,2048,1034,163,14,137,1054,137]

theorem envBound13673 : H12AffineFastState.Bounded env13673 := by
  intro p hp
  have h : env13673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13672_13673 : H12AffineEnvironment.transform 7 14 env13672 = env13673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env13672 == env13673) = true)

def env13674 : List Nat := [2,4,8,16,32,16,40,14,33,1024,2048,1055,2088,1054,2091,2051,1054,2091,1025,2090,1055,11,16,35,2056,17,2091,1054,1054,2048,1034,11,14,33,1054,33]

theorem envBound13674 : H12AffineFastState.Bounded env13674 := by
  intro p hp
  have h : env13674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13673_13674 : H12AffineEnvironment.transform 6 40 env13673 = env13674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env13673 == env13674) = true)

theorem identity13674 : scanCanonicalize (H12AffineFastState.compose env13674 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound13674 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13675 : List Nat := [2,4,8,16,17,16,25,14,16,1024,2048,1055,2073,1054,2074,2051,1054,2074,1025,2075,1055,11,16,18,2056,17,2074,1054,1054,2048,1034,11,14,16,1054,16]

theorem envBound13675 : H12AffineFastState.Bounded env13675 := by
  intro p hp
  have h : env13675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13674_13675 : H12AffineEnvironment.transform 4 17 env13674 = env13675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env13674 == env13675) = true)

def leafEnv13675 : List Nat := [2,4,8,16,17,16,25,14,16,1024,2048,1055,2073,1054,2074,2051,1054,2074,1025,2075,1055,11,16,18,1035,2056,1,17,2074,1054,1054,2048,1034,11,14,16,4,2067,1054,16,0,1054,1]

def active13675 : List Nat := [0,1,2,3,9,10]

def tree13675 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13675 : H12WitnessSearch.Good tree13675 := H12GlobalWitnessIndex.good

theorem leafIdentity13675 : H12AffineFastState.composeSystem env13675 rootObs = leafEnv13675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13675 rootObs == leafEnv13675) = true)

theorem terminalChecked13675 : H12PackedTerminal.terminalCheckFast leafEnv13675 active13675 tree13675 = true := by decide +kernel

def env13676 : List Nat := [2,4,8,16,32,16,41,14,32,1024,2048,1055,2088,1054,2091,2050,1054,2091,1025,2090,1055,11,16,34,2057,17,2091,1054,1054,2048,1034,10,14,32,1054,32]

theorem envBound13676 : H12AffineFastState.Bounded env13676 := by
  intro p hp
  have h : env13676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13673_13676 : H12AffineEnvironment.transform 6 41 env13673 = env13676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env13673 == env13676) = true)

theorem identity13676 : scanCanonicalize (H12AffineFastState.compose env13676 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound13676 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13677 : List Nat := [2,4,8,11,32,11,41,14,32,1024,2048,1028,2088,1029,2091,2050,1029,2091,1025,2090,1028,11,11,34,2057,10,2091,1029,1029,2048,1034,10,14,32,1029,32]

theorem envBound13677 : H12AffineFastState.Bounded env13677 := by
  intro p hp
  have h : env13677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13676_13677 : H12AffineEnvironment.transform 3 11 env13676 = env13677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env13676 == env13677) = true)

def leafEnv13677 : List Nat := [2,4,8,11,32,11,41,14,32,1024,2048,1028,2088,1029,2091,2050,1029,2091,1025,2090,1028,11,11,34,1035,2057,1,10,2091,1029,1029,2048,1034,10,14,32,4,2082,1029,32,0,1029,1]

def active13677 : List Nat := [0,1,2,4,9,10]

def tree13677 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13677 : H12WitnessSearch.Good tree13677 := H12GlobalWitnessIndex.good

theorem leafIdentity13677 : H12AffineFastState.composeSystem env13677 rootObs = leafEnv13677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13677 rootObs == leafEnv13677) = true)

theorem terminalChecked13677 : H12PackedTerminal.terminalCheckFast leafEnv13677 active13677 tree13677 = true := by decide +kernel

def env13678 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,1296,8192,1297,32768,65536,1297,262144,1024,32769,1296,4194304,17,98565,8328,16,4456708,1297,1296,1073741824,1284,4294967296,256,4299260335,1297,136]

theorem envBound13678 : H12AffineFastState.Bounded env13678 := by
  intro p hp
  have h : env13678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13664_13678 : H12AffineEnvironment.transform 5 17 env13664 = env13678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env13664 == env13678) = true)

theorem identity13678 : scanCanonicalize (H12AffineFastState.compose env13678 (packedSelected [1,10] rootPS)) = affineNative (2^(29+1) ^^^ 4294794) := by decide +kernel

theorem selectedBound13678 : packedSelected [1,10] rootPS < 2^1333 := by decide +kernel

def env13679 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,1296,8192,1297,32768,65536,1297,262144,1024,32769,1296,4194304,17,98565,8328,16,4456708,1297,1296,4294794,1284,4294967296,256,4299260335,1297,136]

theorem envBound13679 : H12AffineFastState.Bounded env13679 := by
  intro p hp
  have h : env13679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13678_13679 : H12AffineEnvironment.transform 29 4294794 env13678 = env13679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4294794 env13678 == env13679) = true)

theorem identity13679 : scanCanonicalize (H12AffineFastState.compose env13679 (packedSelected [3,12] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound13679 : packedSelected [3,12] rootPS < 2^1333 := by decide +kernel

def env13680 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,1296,8192,1297,8461,65536,1297,262144,1024,8460,1296,4194304,17,73736,8328,16,4456708,1297,1296,4270471,1284,4294967296,256,4299235490,1297,136]

theorem envBound13680 : H12AffineFastState.Bounded env13680 := by
  intro p hp
  have h : env13680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13679_13680 : H12AffineEnvironment.transform 14 8461 env13679 = env13680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env13679 == env13680) = true)

theorem identity13680 : scanCanonicalize (H12AffineFastState.compose env13680 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 74031) := by decide +kernel

theorem selectedBound13680 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env13681 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,1296,8192,1297,8461,65536,1297,262144,1024,8460,1296,4194304,17,73736,8328,16,4456708,1297,1296,4270471,1284,74031,256,4194701,1297,136]

theorem envBound13681 : H12AffineFastState.Bounded env13681 := by
  intro p hp
  have h : env13681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13680_13681 : H12AffineEnvironment.transform 31 74031 env13680 = env13681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 74031 env13680 == env13681) = true)

def env13682 : List Nat := [2,4,8,16,32,17,128,256,136,272,2048,0,8192,1,8461,65536,1,262144,272,8460,0,4194304,17,73736,8328,16,4456708,1,0,4270471,20,74031,256,4194701,1,136]

theorem envBound13682 : H12AffineFastState.Bounded env13682 := by
  intro p hp
  have h : env13682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13681_13682 : H12AffineEnvironment.transform 9 272 env13681 = env13682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env13681 == env13682) = true)

theorem identity13682 : scanCanonicalize (H12AffineFastState.compose env13682 (packedSelected [1] rootPS)) = affineNative (2^(17+1) ^^^ 76199) := by decide +kernel

theorem selectedBound13682 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env13683 : List Nat := [2,4,8,16,32,17,128,256,136,272,2048,0,8192,1,8461,65536,1,76199,272,8460,0,4194304,17,73736,8328,16,4270243,1,0,4270471,20,74031,256,4194701,1,136]

theorem envBound13683 : H12AffineFastState.Bounded env13683 := by
  intro p hp
  have h : env13683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13682_13683 : H12AffineEnvironment.transform 17 76199 env13682 = env13683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76199 env13682 == env13683) = true)

theorem identity13683 : scanCanonicalize (H12AffineFastState.compose env13683 (packedSelected [3] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound13683 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env13684 : List Nat := [2,4,8,16,32,17,128,256,136,272,2048,0,8192,1,8461,8323,1,2340,272,8460,0,4194304,17,139,8328,16,4196384,1,0,4196612,20,428,256,4194701,1,136]

theorem envBound13684 : H12AffineFastState.Bounded env13684 := by
  intro p hp
  have h : env13684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13683_13684 : H12AffineEnvironment.transform 15 8323 env13683 = env13684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env13683 == env13684) = true)

def env13685 : List Nat := [2,4,8,16,32,17,128,256,136,272,2048,0,8192,1,8461,8323,1,2340,272,8460,0,10248,17,139,8328,16,8232,1,0,8460,20,428,256,10629,1,136]

theorem envBound13685 : H12AffineFastState.Bounded env13685 := by
  intro p hp
  have h : env13685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13684_13685 : H12AffineEnvironment.transform 21 10248 env13684 = env13685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10248 env13684 == env13685) = true)

theorem identity13685 : scanCanonicalize (H12AffineFastState.compose env13685 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 2088) := by decide +kernel

theorem selectedBound13685 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env13686 : List Nat := [2,4,8,16,32,17,128,256,136,272,2048,0,2088,1,2341,2219,1,2340,272,2340,0,32,17,139,2208,16,2048,1,0,2340,20,428,256,429,1,136]

theorem envBound13686 : H12AffineFastState.Bounded env13686 := by
  intro p hp
  have h : env13686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13685_13686 : H12AffineEnvironment.transform 12 2088 env13685 = env13686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2088 env13685 == env13686) = true)

theorem identity13686 : scanCanonicalize (H12AffineFastState.compose env13686 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 141) := by decide +kernel

theorem selectedBound13686 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env13687 : List Nat := [2,4,8,16,32,17,128,141,136,157,2048,0,2088,1,2216,2219,1,2217,157,2217,0,32,17,139,2208,16,2048,1,0,2217,20,33,141,32,1,136]

theorem envBound13687 : H12AffineFastState.Bounded env13687 := by
  intro p hp
  have h : env13687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13686_13687 : H12AffineEnvironment.transform 7 141 env13686 = env13687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 141 env13686 == env13687) = true)

theorem identity13687 : scanCanonicalize (H12AffineFastState.compose env13687 (packedSelected [7] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound13687 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env13688 : List Nat := [2,4,8,16,32,17,41,36,33,52,2048,0,2088,1,2049,2050,1,2048,52,2048,0,32,17,34,2057,16,2048,1,0,2048,20,33,36,32,1,33]

theorem envBound13688 : H12AffineFastState.Bounded env13688 := by
  intro p hp
  have h : env13688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13687_13688 : H12AffineEnvironment.transform 6 41 env13687 = env13688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env13687 == env13688) = true)

def leafEnv13688 : List Nat := [2,4,8,16,32,17,41,36,33,52,2048,0,2088,1,2049,2050,1,2048,52,2048,0,32,17,34,20,2057,1,16,2048,1,0,2048,20,33,36,32,4,2082,1,33,0,0,1]

def active13688 : List Nat := [0,1,2,3,4,10]

def tree13688 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood13688 : H12WitnessSearch.Good tree13688 := H12GlobalWitnessIndex.good

theorem leafIdentity13688 : H12AffineFastState.composeSystem env13688 rootObs = leafEnv13688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env13688 rootObs == leafEnv13688) = true)

theorem terminalChecked13688 : H12PackedTerminal.terminalCheckFast leafEnv13688 active13688 tree13688 = true := by decide +kernel

def env13689 : List Nat := [2,4,8,16,32,17,128,256,136,272,2048,0,8192,1,8461,8323,1,2340,272,8460,0,10249,17,139,8328,16,8233,1,0,8461,20,428,256,10628,1,136]

theorem envBound13689 : H12AffineFastState.Bounded env13689 := by
  intro p hp
  have h : env13689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans13684_13689 : H12AffineEnvironment.transform 21 10249 env13684 = env13689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10249 env13684 == env13689) = true)

end H12CloudChart2