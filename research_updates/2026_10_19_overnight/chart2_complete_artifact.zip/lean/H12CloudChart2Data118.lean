import H12CloudChart2Data117

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env29100 : List Nat := [2,4,8,16,32,33,19,37,43,4,1,1,50,48,42,57,1,43,4,43,1,10,16,40,40,33,26,49,48,1,62,58,36,33,1,43]

theorem envBound29100 : H12AffineFastState.Bounded env29100 := by
  intro p hp
  have h : env29100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29099_29100 : H12AffineEnvironment.transform 6 19 env29099 = env29100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env29099 == env29100) = true)

theorem identity29100 : scanCanonicalize (H12AffineFastState.compose env29100 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound29100 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env29101 : List Nat := [2,4,8,16,10,11,19,15,1,4,1,1,24,26,0,19,1,1,4,1,1,10,16,2,2,11,26,27,26,1,20,16,14,11,1,1]

theorem envBound29101 : H12AffineFastState.Bounded env29101 := by
  intro p hp
  have h : env29101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29100_29101 : H12AffineEnvironment.transform 4 10 env29100 = env29101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env29100 == env29101) = true)

theorem identity29101 : scanCanonicalize (H12AffineFastState.compose env29101 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound29101 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env29102 : List Nat := [2,4,8,11,10,11,8,15,1,4,1,1,3,1,0,8,1,1,4,1,1,10,11,2,2,11,1,0,1,1,15,11,14,11,1,1]

theorem envBound29102 : H12AffineFastState.Bounded env29102 := by
  intro p hp
  have h : env29102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29101_29102 : H12AffineEnvironment.transform 3 11 env29101 = env29102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env29101 == env29102) = true)

theorem identity29102 : scanCanonicalize (H12AffineFastState.compose env29102 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound29102 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29103 : List Nat := [2,4,4,7,6,7,4,3,1,4,1,1,3,1,0,4,1,1,4,1,1,6,7,2,2,7,1,0,1,1,3,7,2,7,1,1]

theorem envBound29103 : H12AffineFastState.Bounded env29103 := by
  intro p hp
  have h : env29103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29102_29103 : H12AffineEnvironment.transform 2 4 env29102 = env29103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env29102 == env29103) = true)

def env29104 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,80,8540,8495,1,8622,4417,8541,4096,4573,17,8511,12425,4161,318,80,80,6436,8204,8201,257,65,0,4608]

theorem envBound29104 : H12AffineFastState.Bounded env29104 := by
  intro p hp
  have h : env29104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29092_29104 : H12AffineEnvironment.transform 9 321 env29092 = env29104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env29092 == env29104) = true)

theorem identity29104 : scanCanonicalize (H12AffineFastState.compose env29104 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound29104 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env29105 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,25,80,325,310,1,439,4417,324,4096,4573,17,294,4240,4161,318,80,80,6436,21,16,257,65,0,4608]

theorem envBound29105 : H12AffineFastState.Bounded env29105 := by
  intro p hp
  have h : env29105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29104_29105 : H12AffineEnvironment.transform 12 25 env29104 = env29105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env29104 == env29105) = true)

theorem identity29105 : scanCanonicalize (H12AffineFastState.compose env29105 (packedSelected [0,2,3,4,5,7,9,10,11,12,15,16,17,18,20] rootPS)) = affineNative (2^(11+1) ^^^ 2999) := by decide +kernel

theorem selectedBound29105 : packedSelected [0,2,3,4,5,7,9,10,11,12,15,16,17,18,20] rootPS < 2^1333 := by decide +kernel

def env29106 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,2999,25,80,325,310,1,439,2806,324,2999,2666,17,294,2855,3062,318,80,80,659,21,16,257,65,0,2487]

theorem envBound29106 : H12AffineFastState.Bounded env29106 := by
  intro p hp
  have h : env29106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29105_29106 : H12AffineEnvironment.transform 11 2999 env29105 = env29106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2999 env29105 == env29106) = true)

theorem identity29106 : scanCanonicalize (H12AffineFastState.compose env29106 (packedSelected [0,1,2,4,5,7,9,10,11,13,23] rootPS)) = affineNative (2^(10+1) ^^^ 538) := by decide +kernel

theorem selectedBound29106 : packedSelected [0,1,2,4,5,7,9,10,11,13,23] rootPS < 2^1333 := by decide +kernel

def env29107 : List Nat := [2,4,8,16,32,64,128,256,512,321,538,429,25,80,325,310,1,439,236,324,429,112,17,294,317,492,318,80,80,659,21,16,257,65,0,941]

theorem envBound29107 : H12AffineFastState.Bounded env29107 := by
  intro p hp
  have h : env29107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29106_29107 : H12AffineEnvironment.transform 10 538 env29106 = env29107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 538 env29106 == env29107) = true)

theorem identity29107 : scanCanonicalize (H12AffineFastState.compose env29107 (packedSelected [0,1,2,3,7,12,13,16,17] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound29107 : packedSelected [0,1,2,3,7,12,13,16,17] rootPS < 2^1333 := by decide +kernel

def env29108 : List Nat := [2,4,8,16,32,64,57,256,512,321,538,276,25,80,325,310,1,270,85,324,276,112,17,294,317,341,318,80,80,554,21,16,257,65,0,788]

theorem envBound29108 : H12AffineFastState.Bounded env29108 := by
  intro p hp
  have h : env29108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29107_29108 : H12AffineEnvironment.transform 6 57 env29107 = env29108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env29107 == env29108) = true)

theorem identity29108 : scanCanonicalize (H12AffineFastState.compose env29108 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(8+1) ^^^ 97) := by decide +kernel

theorem selectedBound29108 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env29109 : List Nat := [2,4,8,16,32,64,57,256,97,321,123,276,25,80,325,310,1,270,85,324,276,112,17,294,317,341,318,80,80,75,21,16,257,65,0,373]

theorem envBound29109 : H12AffineFastState.Bounded env29109 := by
  intro p hp
  have h : env29109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29108_29109 : H12AffineEnvironment.transform 8 97 env29108 = env29109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 97 env29108 == env29109) = true)

theorem identity29109 : scanCanonicalize (H12AffineFastState.compose env29109 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound29109 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env29110 : List Nat := [2,4,8,16,32,11,57,256,42,266,48,276,25,27,270,310,1,270,30,271,276,59,17,294,317,286,318,27,27,0,21,16,257,10,0,318]

theorem envBound29110 : H12AffineFastState.Bounded env29110 := by
  intro p hp
  have h : env29110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29109_29110 : H12AffineEnvironment.transform 5 11 env29109 = env29110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env29109 == env29110) = true)

theorem identity29110 : scanCanonicalize (H12AffineFastState.compose env29110 (packedSelected [1,2,5] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound29110 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env29111 : List Nat := [2,4,8,16,11,11,18,256,1,266,27,276,25,27,270,285,1,270,30,271,276,16,17,269,278,286,277,27,27,0,21,16,257,10,0,277]

theorem envBound29111 : H12AffineFastState.Bounded env29111 := by
  intro p hp
  have h : env29111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29110_29111 : H12AffineEnvironment.transform 4 11 env29110 = env29111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env29110 == env29111) = true)

def env29112 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,21585,32769,4096,61649,91183,123164,28888,78894,385203,90415,1296,96347,25885,82998,257,1280,1345,21073]

theorem envBound29112 : H12AffineFastState.Bounded env29112 := by
  intro p hp
  have h : env29112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29021_29112 : H12AffineEnvironment.transform 18 21585 env29021 = env29112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21585 env29021 == env29112) = true)

theorem identity29112 : scanCanonicalize (H12AffineFastState.compose env29112 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound29112 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env29113 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,13340,65536,74863,262144,21585,13341,4096,17613,91183,87296,28888,78894,349359,90415,1296,96347,25885,82998,257,1280,1345,21073]

theorem envBound29113 : H12AffineFastState.Bounded env29113 := by
  intro p hp
  have h : env29113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29112_29113 : H12AffineEnvironment.transform 14 13340 env29112 = env29113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env29112 == env29113) = true)

def env29114 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74863,262144,4417,13341,4096,477,74047,69648,13768,78894,332223,74815,1296,81227,8205,65830,257,1280,1345,5953]

theorem envBound29114 : H12AffineFastState.Bounded env29114 := by
  intro p hp
  have h : env29114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29113_29114 : H12AffineEnvironment.transform 13 1296 env29113 = env29114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env29113 == env29114) = true)

def env29115 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74863,65664,4417,13341,4096,477,74047,69648,13768,78894,4415,74815,1296,81227,8205,65830,257,1280,1345,5953]

theorem envBound29115 : H12AffineFastState.Bounded env29115 := by
  intro p hp
  have h : env29115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29114_29115 : H12AffineEnvironment.transform 17 65664 env29114 = env29115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env29114 == env29115) = true)

theorem identity29115 : scanCanonicalize (H12AffineFastState.compose env29115 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5158) := by decide +kernel

theorem selectedBound29115 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env29116 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,5158,12361,5286,4417,13341,4096,477,13593,1078,13768,8200,4415,12313,1296,10605,8205,5376,257,1280,1345,5953]

theorem envBound29116 : H12AffineFastState.Bounded env29116 := by
  intro p hp
  have h : env29116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29115_29116 : H12AffineEnvironment.transform 15 5158 env29115 = env29116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5158 env29115 == env29116) = true)

def env29117 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5384,1296,276,5158,1345,5286,4417,277,4096,477,17,1078,192,5376,4415,1297,1296,7269,5381,5376,257,1280,1345,5953]

theorem envBound29117 : H12AffineFastState.Bounded env29117 := by
  intro p hp
  have h : env29117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29116_29117 : H12AffineEnvironment.transform 12 5384 env29116 = env29117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5384 env29116 == env29117) = true)

theorem identity29117 : scanCanonicalize (H12AffineFastState.compose env29117 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound29117 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env29118 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,1368,1296,276,1142,1345,1270,273,277,80,477,17,1078,192,1360,367,1297,1296,3125,1365,1360,257,1280,1345,1809]

theorem envBound29118 : H12AffineFastState.Bounded env29118 := by
  intro p hp
  have h : env29118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29117_29118 : H12AffineEnvironment.transform 11 80 env29117 = env29118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env29117 == env29118) = true)

theorem identity29118 : scanCanonicalize (H12AffineFastState.compose env29118 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(9+1) ^^^ 188) := by decide +kernel

theorem selectedBound29118 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env29119 : List Nat := [2,4,8,16,32,64,128,256,512,188,2048,80,484,428,276,202,509,74,273,277,80,477,17,138,192,492,367,429,428,2185,489,492,257,444,509,941]

theorem envBound29119 : H12AffineFastState.Bounded env29119 := by
  intro p hp
  have h : env29119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29118_29119 : H12AffineEnvironment.transform 9 188 env29118 = env29119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 188 env29118 == env29119) = true)

theorem identity29119 : scanCanonicalize (H12AffineFastState.compose env29119 (packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 217) := by decide +kernel

theorem selectedBound29119 : packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env29120 : List Nat := [2,4,8,16,32,64,128,256,217,188,2048,80,484,428,276,202,509,74,273,277,80,477,17,138,192,492,367,429,428,2185,489,492,257,444,509,372]

theorem envBound29120 : H12AffineFastState.Bounded env29120 := by
  intro p hp
  have h : env29120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29119_29120 : H12AffineEnvironment.transform 8 217 env29119 = env29120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env29119 == env29120) = true)

theorem identity29120 : scanCanonicalize (H12AffineFastState.compose env29120 (packedSelected [0,2,3,7,8,10,13,16] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound29120 : packedSelected [0,2,3,7,8,10,13,16] rootPS < 2^1333 := by decide +kernel

def env29121 : List Nat := [2,4,8,16,32,64,128,256,217,188,80,80,484,428,276,202,509,74,273,277,80,477,17,138,192,492,367,429,428,217,489,492,257,444,509,372]

theorem envBound29121 : H12AffineFastState.Bounded env29121 := by
  intro p hp
  have h : env29121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29120_29121 : H12AffineEnvironment.transform 10 80 env29120 = env29121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env29120 == env29121) = true)

theorem identity29121 : scanCanonicalize (H12AffineFastState.compose env29121 (packedSelected [1,3,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound29121 : packedSelected [1,3,7,9] rootPS < 2^1333 := by decide +kernel

def env29122 : List Nat := [2,4,8,16,32,64,34,256,123,30,80,80,326,270,276,104,351,74,273,277,80,383,17,40,98,334,367,271,270,123,331,334,257,286,351,372]

theorem envBound29122 : H12AffineFastState.Bounded env29122 := by
  intro p hp
  have h : env29122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29121_29122 : H12AffineEnvironment.transform 6 34 env29121 = env29122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env29121 == env29122) = true)

theorem identity29122 : scanCanonicalize (H12AffineFastState.compose env29122 (packedSelected [0,3,4,8,10] rootPS)) = affineNative (2^(7+1) ^^^ 110) := by decide +kernel

theorem selectedBound29122 : packedSelected [0,3,4,8,10] rootPS < 2^1333 := by decide +kernel

def env29123 : List Nat := [2,4,8,16,32,64,34,110,123,30,80,80,40,96,122,104,49,74,127,123,80,17,17,40,98,32,1,97,96,123,37,32,111,112,49,26]

theorem envBound29123 : H12AffineFastState.Bounded env29123 := by
  intro p hp
  have h : env29123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29122_29123 : H12AffineEnvironment.transform 7 110 env29122 = env29123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 110 env29122 == env29123) = true)

theorem identity29123 : scanCanonicalize (H12AffineFastState.compose env29123 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 58) := by decide +kernel

theorem selectedBound29123 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env29124 : List Nat := [2,4,8,16,32,58,34,20,1,30,42,42,40,26,0,18,49,48,5,1,42,17,17,40,24,32,1,27,26,1,37,32,21,10,49,26]

theorem envBound29124 : H12AffineFastState.Bounded env29124 := by
  intro p hp
  have h : env29124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29123_29124 : H12AffineEnvironment.transform 5 58 env29123 = env29124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 58 env29123 == env29124) = true)

def env29125 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5385,1296,277,5158,1344,5286,4417,276,4096,477,16,1078,193,5377,4415,1296,1296,7268,5380,5376,257,1280,1345,5953]

theorem envBound29125 : H12AffineFastState.Bounded env29125 := by
  intro p hp
  have h : env29125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29116_29125 : H12AffineEnvironment.transform 12 5385 env29116 = env29125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5385 env29116 == env29125) = true)

theorem identity29125 : scanCanonicalize (H12AffineFastState.compose env29125 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 324) := by decide +kernel

theorem selectedBound29125 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env29126 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,324,1101,1296,277,1378,1344,1506,5,276,324,477,16,1078,193,1093,123,1296,1296,3360,1088,1092,257,1280,1345,1541]

theorem envBound29126 : H12AffineFastState.Bounded env29126 := by
  intro p hp
  have h : env29126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29125_29126 : H12AffineEnvironment.transform 11 324 env29125 = env29126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 324 env29125 == env29126) = true)

theorem identity29126 : scanCanonicalize (H12AffineFastState.compose env29126 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound29126 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env29127 : List Nat := [2,4,8,16,32,64,128,256,512,5,2048,324,72,277,277,359,325,487,5,276,324,477,16,51,193,64,123,277,277,2341,69,65,257,261,324,512]

theorem envBound29127 : H12AffineFastState.Bounded env29127 := by
  intro p hp
  have h : env29127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29126_29127 : H12AffineEnvironment.transform 9 5 env29126 = env29127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env29126 == env29127) = true)

theorem identity29127 : scanCanonicalize (H12AffineFastState.compose env29127 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound29127 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env29128 : List Nat := [2,4,8,16,32,16,128,256,512,5,2048,276,24,277,277,311,277,439,5,276,276,397,16,51,145,16,43,277,277,2341,21,17,257,261,276,512]

theorem envBound29128 : H12AffineFastState.Bounded env29128 := by
  intro p hp
  have h : env29128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29127_29128 : H12AffineEnvironment.transform 5 16 env29127 = env29128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env29127 == env29128) = true)

theorem identity29128 : scanCanonicalize (H12AffineFastState.compose env29128 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 941) := by decide +kernel

theorem selectedBound29128 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29129 : List Nat := [2,4,8,16,32,16,128,256,512,5,941,276,24,277,277,311,277,439,5,276,276,397,16,51,145,16,43,277,277,648,21,17,257,261,276,512]

theorem envBound29129 : H12AffineFastState.Bounded env29129 := by
  intro p hp
  have h : env29129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29128_29129 : H12AffineEnvironment.transform 10 941 env29128 = env29129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 941 env29128 == env29129) = true)

theorem identity29129 : scanCanonicalize (H12AffineFastState.compose env29129 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(8+1) ^^^ 413) := by decide +kernel

theorem selectedBound29129 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env29130 : List Nat := [2,4,8,16,32,16,128,256,413,5,48,276,24,277,277,311,277,439,5,276,276,397,16,51,145,16,43,277,277,277,21,17,257,261,276,413]

theorem envBound29130 : H12AffineFastState.Bounded env29130 := by
  intro p hp
  have h : env29130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29129_29130 : H12AffineEnvironment.transform 8 413 env29129 = env29130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 413 env29129 == env29130) = true)

def env29131 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74863,65665,4417,13341,4096,477,74047,69648,13768,78894,4414,74815,1296,81227,8205,65830,257,1280,1345,5953]

theorem envBound29131 : H12AffineFastState.Bounded env29131 := by
  intro p hp
  have h : env29131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29114_29131 : H12AffineEnvironment.transform 17 65665 env29114 = env29131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env29114 == env29131) = true)

theorem identity29131 : scanCanonicalize (H12AffineFastState.compose env29131 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 358) := by decide +kernel

theorem selectedBound29131 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env29132 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,358,9481,487,4417,13341,4096,477,8281,4470,13768,13640,4414,9561,1296,15405,8205,64,257,1280,1345,5953]

theorem envBound29132 : H12AffineFastState.Bounded env29132 := by
  intro p hp
  have h : env29132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29131_29132 : H12AffineEnvironment.transform 15 358 env29131 = env29132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 358 env29131 == env29132) = true)

def env29133 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,72,1296,5204,358,1345,487,4417,5205,4096,477,17,4470,5504,5376,4414,1297,1296,7269,69,64,257,1280,1345,5953]

theorem envBound29133 : H12AffineFastState.Bounded env29133 := by
  intro p hp
  have h : env29133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29132_29133 : H12AffineEnvironment.transform 12 72 env29132 = env29133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env29132 == env29133) = true)

theorem identity29133 : scanCanonicalize (H12AffineFastState.compose env29133 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound29133 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env29134 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,72,0,4420,358,81,487,4417,4421,4096,477,17,4470,4240,4112,4414,1,0,6517,69,64,257,16,81,4689]

theorem envBound29134 : H12AffineFastState.Bounded env29134 := by
  intro p hp
  have h : env29134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29133_29134 : H12AffineEnvironment.transform 9 272 env29133 = env29134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env29133 == env29134) = true)

theorem identity29134 : scanCanonicalize (H12AffineFastState.compose env29134 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(11+1) ^^^ 508) := by decide +kernel

theorem selectedBound29134 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env29135 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,508,72,0,184,358,81,487,189,185,508,477,17,138,364,492,194,1,0,2185,69,64,257,16,81,941]

theorem envBound29135 : H12AffineFastState.Bounded env29135 := by
  intro p hp
  have h : env29135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29134_29135 : H12AffineEnvironment.transform 11 508 env29134 = env29135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 508 env29134 == env29135) = true)

theorem identity29135 : scanCanonicalize (H12AffineFastState.compose env29135 (packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 217) := by decide +kernel

theorem selectedBound29135 : packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env29136 : List Nat := [2,4,8,16,32,64,128,256,217,272,2048,508,72,0,184,358,81,487,189,185,508,477,17,138,364,492,194,1,0,2185,69,64,257,16,81,372]

theorem envBound29136 : H12AffineFastState.Bounded env29136 := by
  intro p hp
  have h : env29136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29135_29136 : H12AffineEnvironment.transform 8 217 env29135 = env29136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env29135 == env29136) = true)

theorem identity29136 : scanCanonicalize (H12AffineFastState.compose env29136 (packedSelected [0,2,3,7,8,10,13,16] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound29136 : packedSelected [0,2,3,7,8,10,13,16] rootPS < 2^1333 := by decide +kernel

def env29137 : List Nat := [2,4,8,16,32,64,128,256,217,272,81,508,72,0,184,358,81,487,189,185,508,477,17,138,364,492,194,1,0,216,69,64,257,16,81,372]

theorem envBound29137 : H12AffineFastState.Bounded env29137 := by
  intro p hp
  have h : env29137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29136_29137 : H12AffineEnvironment.transform 10 81 env29136 = env29137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env29136 == env29137) = true)

theorem identity29137 : scanCanonicalize (H12AffineFastState.compose env29137 (packedSelected [0,2,4,7,9,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound29137 : packedSelected [0,2,4,7,9,12] rootPS < 2^1333 := by decide +kernel

def env29138 : List Nat := [2,4,8,16,32,17,128,256,136,272,0,429,25,0,184,311,0,438,189,185,429,396,17,138,317,445,147,1,0,137,20,17,257,16,0,293]

theorem envBound29138 : H12AffineFastState.Bounded env29138 := by
  intro p hp
  have h : env29138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29137_29138 : H12AffineEnvironment.transform 5 17 env29137 = env29138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env29137 == env29138) = true)

theorem identity29138 : scanCanonicalize (H12AffineFastState.compose env29138 (packedSelected [1,3,5] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound29138 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env29139 : List Nat := [2,4,4,16,32,17,128,256,132,272,0,417,21,0,180,311,0,438,177,181,417,384,17,134,305,433,147,1,0,133,20,17,257,16,0,293]

theorem envBound29139 : H12AffineFastState.Bounded env29139 := by
  intro p hp
  have h : env29139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29138_29139 : H12AffineEnvironment.transform 2 4 env29138 = env29139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env29138 == env29139) = true)

theorem identity29139 : scanCanonicalize (H12AffineFastState.compose env29139 (packedSelected [3,8] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound29139 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env29140 : List Nat := [2,4,4,16,7,17,128,256,132,272,0,390,21,0,147,272,0,401,150,146,390,384,17,134,278,406,147,1,0,133,20,17,257,16,0,258]

theorem envBound29140 : H12AffineFastState.Bounded env29140 := by
  intro p hp
  have h : env29140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29139_29140 : H12AffineEnvironment.transform 4 7 env29139 = env29140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env29139 == env29140) = true)

theorem identity29140 : scanCanonicalize (H12AffineFastState.compose env29140 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound29140 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env29141 : List Nat := [2,4,4,16,7,17,128,21,132,5,0,147,21,0,147,5,0,132,150,146,147,149,17,134,3,131,147,1,0,133,20,17,20,16,0,23]

theorem envBound29141 : H12AffineFastState.Bounded env29141 := by
  intro p hp
  have h : env29141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29140_29141 : H12AffineEnvironment.transform 7 21 env29140 = env29141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env29140 == env29141) = true)

theorem identity29141 : scanCanonicalize (H12AffineFastState.compose env29141 (packedSelected [2,4,7] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound29141 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env29142 : List Nat := [2,4,4,16,7,17,19,21,23,5,0,0,21,0,0,5,0,23,5,1,0,6,17,21,3,16,0,1,0,22,20,17,20,16,0,23]

theorem envBound29142 : H12AffineFastState.Bounded env29142 := by
  intro p hp
  have h : env29142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29141_29142 : H12AffineEnvironment.transform 6 19 env29141 = env29142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env29141 == env29142) = true)

theorem identity29142 : scanCanonicalize (H12AffineFastState.compose env29142 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound29142 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29143 : List Nat := [2,4,4,6,7,7,5,3,1,5,0,0,3,0,0,5,0,1,5,1,0,6,7,3,3,6,0,1,0,0,2,7,2,6,0,1]

theorem envBound29143 : H12AffineFastState.Bounded env29143 := by
  intro p hp
  have h : env29143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29142_29143 : H12AffineEnvironment.transform 3 6 env29142 = env29143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env29142 == env29143) = true)

def env29144 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,73,1296,5205,358,1344,487,4417,5204,4096,477,16,4470,5505,5377,4414,1296,1296,7268,68,64,257,1280,1345,5953]

theorem envBound29144 : H12AffineFastState.Bounded env29144 := by
  intro p hp
  have h : env29144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29132_29144 : H12AffineEnvironment.transform 12 73 env29132 = env29144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env29132 == env29144) = true)

theorem identity29144 : scanCanonicalize (H12AffineFastState.compose env29144 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 324) := by decide +kernel

theorem selectedBound29144 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env29145 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,324,73,1296,1297,358,1344,487,5,1296,324,477,16,50,1221,1093,122,1296,1296,3360,68,64,257,1280,1345,1541]

theorem envBound29145 : H12AffineFastState.Bounded env29145 := by
  intro p hp
  have h : env29145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29144_29145 : H12AffineEnvironment.transform 11 324 env29144 = env29145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 324 env29144 == env29145) = true)

theorem identity29145 : scanCanonicalize (H12AffineFastState.compose env29145 (packedSelected [2,5,8,12,15,17,18,19,20] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound29145 : packedSelected [2,5,8,12,15,17,18,19,20] rootPS < 2^1333 := by decide +kernel

def env29146 : List Nat := [2,4,8,16,32,64,128,256,292,1024,2048,324,73,1296,1297,358,1344,487,5,1296,324,477,16,50,1221,1093,122,1296,1296,3360,68,64,257,1280,1345,1313]

theorem envBound29146 : H12AffineFastState.Bounded env29146 := by
  intro p hp
  have h : env29146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29145_29146 : H12AffineEnvironment.transform 8 292 env29145 = env29146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env29145 == env29146) = true)

theorem identity29146 : scanCanonicalize (H12AffineFastState.compose env29146 (packedSelected [1,3,12,15,16,17,19,23] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound29146 : packedSelected [1,3,12,15,16,17,19,23] rootPS < 2^1333 := by decide +kernel

def env29147 : List Nat := [2,4,8,16,32,64,128,253,217,1024,2048,185,73,1261,1260,155,1213,26,5,1261,185,32,16,50,1221,1093,122,1261,1261,3293,68,64,252,1277,1212,1244]

theorem envBound29147 : H12AffineFastState.Bounded env29147 := by
  intro p hp
  have h : env29147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29146_29147 : H12AffineEnvironment.transform 7 253 env29146 = env29147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env29146 == env29147) = true)

theorem identity29147 : scanCanonicalize (H12AffineFastState.compose env29147 (packedSelected [2,5,8,17] rootPS)) = affineNative (2^(10+1) ^^^ 1223) := by decide +kernel

theorem selectedBound29147 : packedSelected [2,5,8,17] rootPS < 2^1333 := by decide +kernel

def env29148 : List Nat := [2,4,8,16,32,64,128,253,217,1024,1223,185,73,1261,1260,155,1213,26,5,1261,185,32,16,50,1221,1093,122,1261,1261,26,68,64,252,1277,1212,1244]

theorem envBound29148 : H12AffineFastState.Bounded env29148 := by
  intro p hp
  have h : env29148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29147_29148 : H12AffineEnvironment.transform 10 1223 env29147 = env29148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1223 env29147 == env29148) = true)

theorem identity29148 : scanCanonicalize (H12AffineFastState.compose env29148 (packedSelected [0,2,3,4,7,8,9,10,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound29148 : packedSelected [0,2,3,4,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env29149 : List Nat := [2,4,8,16,32,64,56,69,97,1024,1151,1,73,1109,1108,35,1029,26,5,1109,1,32,16,50,1149,1093,122,1109,1109,26,68,64,68,1093,1028,1124]

theorem envBound29149 : H12AffineFastState.Bounded env29149 := by
  intro p hp
  have h : env29149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29148_29149 : H12AffineEnvironment.transform 6 56 env29148 = env29149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env29148 == env29149) = true)

theorem identity29149 : scanCanonicalize (H12AffineFastState.compose env29149 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound29149 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env29150 : List Nat := [2,4,8,16,32,33,56,36,0,1024,1054,1,40,1076,1077,35,1029,26,5,1076,1,32,16,50,1052,1060,27,1076,1076,26,37,33,37,1060,1028,1029]

theorem envBound29150 : H12AffineFastState.Bounded env29150 := by
  intro p hp
  have h : env29150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29149_29150 : H12AffineEnvironment.transform 5 33 env29149 = env29150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env29149 == env29150) = true)

theorem identity29150 : scanCanonicalize (H12AffineFastState.compose env29150 (packedSelected [0,1,2,3,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 3) := by decide +kernel

theorem selectedBound29150 : packedSelected [0,1,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env29151 : List Nat := [2,4,8,16,32,33,56,36,0,3,29,1,40,55,54,35,6,26,5,55,1,32,16,50,31,39,27,55,55,26,37,33,37,39,7,6]

theorem envBound29151 : H12AffineFastState.Bounded env29151 := by
  intro p hp
  have h : env29151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29150_29151 : H12AffineEnvironment.transform 9 3 env29150 = env29151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 3 env29150 == env29151) = true)

theorem identity29151 : scanCanonicalize (H12AffineFastState.compose env29151 (packedSelected [0,1,2,3,4,8] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound29151 : packedSelected [0,1,2,3,4,8] rootPS < 2^1333 := by decide +kernel

def env29152 : List Nat := [2,4,8,16,10,11,18,14,0,3,29,1,2,29,28,9,6,26,5,29,1,10,16,24,31,13,27,29,29,26,15,11,15,13,7,6]

theorem envBound29152 : H12AffineFastState.Bounded env29152 := by
  intro p hp
  have h : env29152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29151_29152 : H12AffineEnvironment.transform 4 10 env29151 = env29152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env29151 == env29152) = true)

def env29153 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74863,262144,4416,13341,4096,476,74046,69649,13769,78894,332222,74814,1296,81226,8204,65831,257,1280,1345,5952]

theorem envBound29153 : H12AffineFastState.Bounded env29153 := by
  intro p hp
  have h : env29153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29113_29153 : H12AffineEnvironment.transform 13 1297 env29113 = env29153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env29113 == env29153) = true)

def env29154 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74863,65664,4416,13341,4096,476,74046,69649,13769,78894,4414,74814,1296,81226,8204,65831,257,1280,1345,5952]

theorem envBound29154 : H12AffineFastState.Bounded env29154 := by
  intro p hp
  have h : env29154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29153_29154 : H12AffineEnvironment.transform 17 65664 env29153 = env29154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env29153 == env29154) = true)

theorem identity29154 : scanCanonicalize (H12AffineFastState.compose env29154 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9326) := by decide +kernel

theorem selectedBound29154 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env29155 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,9326,1,9454,4416,13341,4096,476,1360,13439,13769,4160,4414,80,1296,6436,8204,9545,257,1280,1345,5952]

theorem envBound29155 : H12AffineFastState.Bounded env29155 := by
  intro p hp
  have h : env29155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29154_29155 : H12AffineEnvironment.transform 15 9326 env29154 = env29155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9326 env29154 == env29155) = true)

def env29156 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,81,12636,8494,1,8622,4416,12637,4096,476,16,12607,12425,4160,4414,80,80,6436,8204,8201,257,64,1,4608]

theorem envBound29156 : H12AffineFastState.Bounded env29156 := by
  intro p hp
  have h : env29156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29155_29156 : H12AffineEnvironment.transform 9 320 env29155 = env29156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env29155 == env29156) = true)

theorem identity29156 : scanCanonicalize (H12AffineFastState.compose env29156 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 4121) := by decide +kernel

theorem selectedBound29156 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env29157 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,4121,81,325,4407,1,4535,4416,324,4096,476,16,294,144,4160,4414,80,80,6436,4117,4112,257,64,1,4608]

theorem envBound29157 : H12AffineFastState.Bounded env29157 := by
  intro p hp
  have h : env29157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29156_29157 : H12AffineEnvironment.transform 12 4121 env29156 = env29157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4121 env29156 == env29157) = true)

theorem identity29157 : scanCanonicalize (H12AffineFastState.compose env29157 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound29157 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env29158 : List Nat := [2,4,8,16,32,64,128,172,512,236,2048,4096,4121,81,233,4251,1,4123,4332,232,4096,112,16,138,144,4160,4242,80,80,6280,4117,4112,173,64,1,4608]

theorem envBound29158 : H12AffineFastState.Bounded env29158 := by
  intro p hp
  have h : env29158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29157_29158 : H12AffineEnvironment.transform 7 172 env29157 = env29158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env29157 == env29158) = true)

theorem identity29158 : scanCanonicalize (H12AffineFastState.compose env29158 (packedSelected [0,2,3,5,7,10,11,12,15,16,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 755) := by decide +kernel

theorem selectedBound29158 : packedSelected [0,2,3,5,7,10,11,12,15,16,17,18] rootPS < 2^1333 := by decide +kernel

def env29159 : List Nat := [2,4,8,16,32,64,128,172,512,236,755,4096,4121,81,233,4251,1,4123,4332,232,4096,112,16,138,144,4160,4242,80,80,4731,4117,4112,173,64,1,4608]

theorem envBound29159 : H12AffineFastState.Bounded env29159 := by
  intro p hp
  have h : env29159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29158_29159 : H12AffineEnvironment.transform 10 755 env29158 = env29159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 755 env29158 == env29159) = true)

theorem identity29159 : scanCanonicalize (H12AffineFastState.compose env29159 (packedSelected [0,2,3,7,8,10,12,15,16] rootPS)) = affineNative (2^(8+1) ^^^ 75) := by decide +kernel

theorem selectedBound29159 : packedSelected [0,2,3,7,8,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env29160 : List Nat := [2,4,8,16,32,64,128,172,75,236,184,4096,4121,81,233,4251,1,4123,4332,232,4096,112,16,138,144,4160,4242,80,80,4144,4117,4112,173,64,1,4171]

theorem envBound29160 : H12AffineFastState.Bounded env29160 := by
  intro p hp
  have h : env29160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29159_29160 : H12AffineEnvironment.transform 8 75 env29159 = env29160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 75 env29159 == env29160) = true)

theorem identity29160 : scanCanonicalize (H12AffineFastState.compose env29160 (packedSelected [0,1,2,3,5,8,9,11] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound29160 : packedSelected [0,1,2,3,5,8,9,11] rootPS < 2^1333 := by decide +kernel

def env29161 : List Nat := [2,4,8,16,32,64,56,20,75,84,0,4096,4121,81,81,4131,1,4123,4180,80,4096,112,16,50,40,4160,4138,80,80,4144,4117,4112,21,64,1,4171]

theorem envBound29161 : H12AffineFastState.Bounded env29161 := by
  intro p hp
  have h : env29161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29160_29161 : H12AffineEnvironment.transform 6 56 env29160 = env29161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env29160 == env29161) = true)

theorem identity29161 : scanCanonicalize (H12AffineFastState.compose env29161 (packedSelected [2,5,8] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound29161 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env29162 : List Nat := [2,4,8,11,32,64,35,15,75,79,0,4096,4098,74,74,4131,1,4096,4175,75,4096,107,11,41,40,4160,4138,75,75,4139,4110,4107,14,64,1,4171]

theorem envBound29162 : H12AffineFastState.Bounded env29162 := by
  intro p hp
  have h : env29162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29161_29162 : H12AffineEnvironment.transform 3 11 env29161 = env29162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env29161 == env29162) = true)

theorem identity29162 : scanCanonicalize (H12AffineFastState.compose env29162 (packedSelected [1,2,3,4,9] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound29162 : packedSelected [1,2,3,4,9] rootPS < 2^1333 := by decide +kernel

def env29163 : List Nat := [2,4,8,11,10,64,9,15,75,79,0,4096,4098,74,74,4105,1,4096,4175,75,4096,65,11,3,2,4160,4096,75,75,4097,4110,4107,14,64,1,4171]

theorem envBound29163 : H12AffineFastState.Bounded env29163 := by
  intro p hp
  have h : env29163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29162_29163 : H12AffineEnvironment.transform 4 10 env29162 = env29163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env29162 == env29163) = true)

theorem identity29163 : scanCanonicalize (H12AffineFastState.compose env29163 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound29163 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29164 : List Nat := [2,4,8,11,10,64,9,15,75,79,0,0,2,74,74,9,1,0,79,75,0,65,11,3,2,64,0,75,75,1,14,11,14,64,1,75]

theorem envBound29164 : H12AffineFastState.Bounded env29164 := by
  intro p hp
  have h : env29164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29163_29164 : H12AffineEnvironment.transform 11 0 env29163 = env29164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env29163 == env29164) = true)

theorem identity29164 : scanCanonicalize (H12AffineFastState.compose env29164 (packedSelected [0,1] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound29164 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env29165 : List Nat := [2,4,8,11,10,11,9,15,0,4,0,0,2,1,1,9,1,0,4,0,0,10,11,3,2,11,0,0,0,1,14,11,14,11,1,0]

theorem envBound29165 : H12AffineFastState.Bounded env29165 := by
  intro p hp
  have h : env29165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29164_29165 : H12AffineEnvironment.transform 5 11 env29164 = env29165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env29164 == env29165) = true)

theorem identity29165 : scanCanonicalize (H12AffineFastState.compose env29165 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound29165 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29166 : List Nat := [2,2,8,11,10,11,9,9,0,2,0,0,2,1,1,9,1,0,2,0,0,10,11,3,2,11,0,0,0,1,8,11,8,11,1,0]

theorem envBound29166 : H12AffineFastState.Bounded env29166 := by
  intro p hp
  have h : env29166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29165_29166 : H12AffineEnvironment.transform 1 2 env29165 = env29166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env29165 == env29166) = true)

def env29167 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,80,12637,8495,1,8623,4416,12636,4096,476,17,12606,12424,4160,4414,80,81,6436,8204,8200,257,65,0,4609]

theorem envBound29167 : H12AffineFastState.Bounded env29167 := by
  intro p hp
  have h : env29167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29155_29167 : H12AffineEnvironment.transform 9 321 env29155 = env29167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env29155 == env29167) = true)

theorem identity29167 : scanCanonicalize (H12AffineFastState.compose env29167 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound29167 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env29168 : List Nat := [2,4,8,16,32,64,128,68,512,5,2048,4096,8192,80,12313,8299,1,8427,4100,12312,4096,152,17,12410,12424,4160,4218,80,81,6240,8204,8200,69,65,0,4609]

theorem envBound29168 : H12AffineFastState.Bounded env29168 := by
  intro p hp
  have h : env29168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29167_29168 : H12AffineEnvironment.transform 7 68 env29167 = env29168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env29167 == env29168) = true)

theorem identity29168 : scanCanonicalize (H12AffineFastState.compose env29168 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound29168 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env29169 : List Nat := [2,4,8,16,32,64,128,68,512,5,2048,1,8192,80,8216,8299,1,8427,5,8217,1,152,17,8315,8329,65,123,80,81,2145,8204,8200,69,65,0,512]

theorem envBound29169 : H12AffineFastState.Bounded env29169 := by
  intro p hp
  have h : env29169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29168_29169 : H12AffineEnvironment.transform 11 1 env29168 = env29169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env29168 == env29169) = true)

theorem identity29169 : scanCanonicalize (H12AffineFastState.compose env29169 (packedSelected [0,2,5,7,8,10,11] rootPS)) = affineNative (2^(6+1) ^^^ 104) := by decide +kernel

theorem selectedBound29169 : packedSelected [0,2,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env29170 : List Nat := [2,4,8,16,32,64,104,68,512,5,2048,1,8192,80,8216,8299,1,8195,5,8217,1,112,17,8315,8289,65,123,80,81,2145,8204,8200,69,65,0,512]

theorem envBound29170 : H12AffineFastState.Bounded env29170 := by
  intro p hp
  have h : env29170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29169_29170 : H12AffineEnvironment.transform 6 104 env29169 = env29170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 104 env29169 == env29170) = true)

theorem identity29170 : scanCanonicalize (H12AffineFastState.compose env29170 (packedSelected [2,5,8,13] rootPS)) = affineNative (2^(12+1) ^^^ 72) := by decide +kernel

theorem selectedBound29170 : packedSelected [2,5,8,13] rootPS < 2^1333 := by decide +kernel

def env29171 : List Nat := [2,4,8,16,32,64,104,68,512,5,2048,1,72,80,80,35,1,75,5,81,1,112,17,51,41,65,123,80,81,2145,68,64,69,65,0,512]

theorem envBound29171 : H12AffineFastState.Bounded env29171 := by
  intro p hp
  have h : env29171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29170_29171 : H12AffineEnvironment.transform 12 72 env29170 = env29171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env29170 == env29171) = true)

theorem identity29171 : scanCanonicalize (H12AffineFastState.compose env29171 (packedSelected [2,5] rootPS)) = affineNative (2^(10+1) ^^^ 582) := by decide +kernel

theorem selectedBound29171 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env29172 : List Nat := [2,4,8,16,32,64,104,68,512,5,582,1,72,80,80,35,1,75,5,81,1,112,17,51,41,65,123,80,81,551,68,64,69,65,0,512]

theorem envBound29172 : H12AffineFastState.Bounded env29172 := by
  intro p hp
  have h : env29172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29171_29172 : H12AffineEnvironment.transform 10 582 env29171 = env29172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 582 env29171 == env29172) = true)

theorem identity29172 : scanCanonicalize (H12AffineFastState.compose env29172 (packedSelected [2,8] rootPS)) = affineNative (2^(5+1) ^^^ 7) := by decide +kernel

theorem selectedBound29172 : packedSelected [2,8] rootPS < 2^1333 := by decide +kernel

def env29173 : List Nat := [2,4,8,16,32,7,47,3,512,5,513,1,15,23,23,35,1,12,5,22,1,55,17,51,41,6,60,23,22,551,3,7,2,6,0,512]

theorem envBound29173 : H12AffineFastState.Bounded env29173 := by
  intro p hp
  have h : env29173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29172_29173 : H12AffineEnvironment.transform 5 7 env29172 = env29173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 7 env29172 == env29173) = true)

def env29174 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74863,65665,4416,13341,4096,476,74046,69649,13769,78894,4415,74814,1296,81226,8204,65831,257,1280,1345,5952]

theorem envBound29174 : H12AffineFastState.Bounded env29174 := by
  intro p hp
  have h : env29174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29153_29174 : H12AffineEnvironment.transform 17 65665 env29153 = env29174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env29153 == env29174) = true)

theorem identity29174 : scanCanonicalize (H12AffineFastState.compose env29174 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12591) := by decide +kernel

theorem selectedBound29174 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env29175 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,12591,5440,12718,4416,13341,4096,476,4113,8510,13769,1281,4415,5393,1296,3173,8204,12296,257,1280,1345,5952]

theorem envBound29175 : H12AffineFastState.Bounded env29175 := by
  intro p hp
  have h : env29175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29174_29175 : H12AffineEnvironment.transform 15 12591 env29174 = env29175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12591 env29174 == env29175) = true)

def env29176 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1297,9244,8495,1344,8622,320,9245,0,476,17,8510,9673,1281,319,1297,1296,3173,8204,8200,257,1280,1345,1856]

theorem envBound29176 : H12AffineFastState.Bounded env29176 := by
  intro p hp
  have h : env29176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29175_29176 : H12AffineEnvironment.transform 11 0 env29175 = env29176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env29175 == env29176) = true)

theorem identity29176 : scanCanonicalize (H12AffineFastState.compose env29176 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound29176 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env29177 : List Nat := [2,4,8,16,32,64,128,256,512,5,2048,0,8192,276,8217,8495,325,8622,320,8216,0,476,17,8510,8652,260,319,276,277,2144,8204,8200,257,261,324,837]

theorem envBound29177 : H12AffineFastState.Bounded env29177 := by
  intro p hp
  have h : env29177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29176_29177 : H12AffineEnvironment.transform 9 5 env29176 = env29177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env29176 == env29177) = true)

theorem identity29177 : scanCanonicalize (H12AffineFastState.compose env29177 (packedSelected [1,2,3,11,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 2746) := by decide +kernel

theorem selectedBound29177 : packedSelected [1,2,3,11,19,20] rootPS < 2^1333 := by decide +kernel

def env29178 : List Nat := [2,4,8,16,32,64,128,256,512,5,2048,0,2746,276,2723,2965,325,2836,320,2722,0,476,17,2948,2934,260,319,276,277,2144,2742,2738,257,261,324,837]

theorem envBound29178 : H12AffineFastState.Bounded env29178 := by
  intro p hp
  have h : env29178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29177_29178 : H12AffineEnvironment.transform 12 2746 env29177 = env29178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2746 env29177 == env29178) = true)

theorem identity29178 : scanCanonicalize (H12AffineFastState.compose env29178 (packedSelected [2,4,5,8,9,13,17,19,23] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound29178 : packedSelected [2,4,5,8,9,13,17,19,23] rootPS < 2^1333 := by decide +kernel

def env29179 : List Nat := [2,4,8,16,32,64,128,252,512,5,2048,0,2746,232,2723,2665,185,2792,188,2722,0,32,17,2680,2698,248,195,232,233,2144,2742,2738,253,249,184,697]

theorem envBound29179 : H12AffineFastState.Bounded env29179 := by
  intro p hp
  have h : env29179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29178_29179 : H12AffineEnvironment.transform 7 252 env29178 = env29179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env29178 == env29179) = true)

theorem identity29179 : scanCanonicalize (H12AffineFastState.compose env29179 (packedSelected [0,3,5,7,11,13] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound29179 : packedSelected [0,3,5,7,11,13] rootPS < 2^1333 := by decide +kernel

def env29180 : List Nat := [2,4,8,16,32,16,128,172,512,5,2048,0,2746,184,2723,2617,185,2744,188,2722,0,32,17,2600,2698,168,147,184,185,2096,2742,2738,173,169,184,697]

theorem envBound29180 : H12AffineFastState.Bounded env29180 := by
  intro p hp
  have h : env29180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29179_29180 : H12AffineEnvironment.transform 5 16 env29179 = env29180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env29179 == env29180) = true)

theorem identity29180 : scanCanonicalize (H12AffineFastState.compose env29180 (packedSelected [0,2,3,7,8,11] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound29180 : packedSelected [0,2,3,7,8,11] rootPS < 2^1333 := by decide +kernel

def env29181 : List Nat := [2,4,8,16,32,16,57,21,512,5,2048,0,2563,1,2586,2617,0,2561,5,2587,0,32,17,2600,2611,17,42,1,0,2096,2575,2571,20,16,1,512]

theorem envBound29181 : H12AffineFastState.Bounded env29181 := by
  intro p hp
  have h : env29181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29180_29181 : H12AffineEnvironment.transform 6 57 env29180 = env29181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env29180 == env29181) = true)

theorem identity29181 : scanCanonicalize (H12AffineFastState.compose env29181 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 560) := by decide +kernel

theorem selectedBound29181 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29182 : List Nat := [2,4,8,16,32,16,57,21,512,5,560,0,51,1,42,9,0,49,5,43,0,32,17,24,3,17,42,1,0,512,63,59,20,16,1,512]

theorem envBound29182 : H12AffineFastState.Bounded env29182 := by
  intro p hp
  have h : env29182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29181_29182 : H12AffineEnvironment.transform 10 560 env29181 = env29182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 560 env29181 == env29182) = true)

theorem identity29182 : scanCanonicalize (H12AffineFastState.compose env29182 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound29182 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env29183 : List Nat := [2,4,8,16,32,16,57,21,26,5,42,0,51,1,42,9,0,49,5,43,0,32,17,24,3,17,42,1,0,26,63,59,20,16,1,26]

theorem envBound29183 : H12AffineFastState.Bounded env29183 := by
  intro p hp
  have h : env29183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29182_29183 : H12AffineEnvironment.transform 8 26 env29182 = env29183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env29182 == env29183) = true)

theorem identity29183 : scanCanonicalize (H12AffineFastState.compose env29183 (packedSelected [0,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound29183 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env29184 : List Nat := [2,4,8,16,16,16,9,21,26,5,26,0,3,1,26,9,0,1,5,27,0,16,17,24,3,17,26,1,0,26,15,11,20,16,1,26]

theorem envBound29184 : H12AffineFastState.Bounded env29184 := by
  intro p hp
  have h : env29184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29183_29184 : H12AffineEnvironment.transform 4 16 env29183 = env29184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env29183 == env29184) = true)

theorem identity29184 : scanCanonicalize (H12AffineFastState.compose env29184 (packedSelected [0,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound29184 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env29185 : List Nat := [2,4,8,11,11,11,9,14,1,5,1,0,3,1,1,9,0,1,5,0,0,11,10,3,3,10,1,1,0,1,15,11,15,11,1,1]

theorem envBound29185 : H12AffineFastState.Bounded env29185 := by
  intro p hp
  have h : env29185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29184_29185 : H12AffineEnvironment.transform 3 11 env29184 = env29185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env29184 == env29185) = true)

theorem identity29185 : scanCanonicalize (H12AffineFastState.compose env29185 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound29185 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29186 : List Nat := [2,3,8,11,11,11,9,9,1,2,1,0,3,1,1,9,0,1,2,0,0,11,10,3,3,10,1,1,0,1,8,11,8,11,1,1]

theorem envBound29186 : H12AffineFastState.Bounded env29186 := by
  intro p hp
  have h : env29186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29185_29186 : H12AffineEnvironment.transform 1 3 env29185 = env29186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env29185 == env29186) = true)

def env29187 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1297,9245,8494,1345,8623,321,9244,1,476,16,8510,9672,1281,318,1296,1296,3173,8204,8201,257,1280,1345,1857]

theorem envBound29187 : H12AffineFastState.Bounded env29187 := by
  intro p hp
  have h : env29187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29175_29187 : H12AffineEnvironment.transform 11 1 env29175 = env29187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env29175 == env29187) = true)

theorem identity29187 : scanCanonicalize (H12AffineFastState.compose env29187 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound29187 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env29188 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,24,1297,1029,310,1345,439,321,1028,1,476,16,294,1488,1281,318,1296,1296,3173,20,17,257,1280,1345,1857]

theorem envBound29188 : H12AffineFastState.Bounded env29188 := by
  intro p hp
  have h : env29188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29187_29188 : H12AffineEnvironment.transform 12 24 env29187 = env29188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env29187 == env29188) = true)

theorem identity29188 : scanCanonicalize (H12AffineFastState.compose env29188 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound29188 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env29189 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,1,24,1213,1029,154,1261,27,237,1028,1,112,16,138,1148,1197,146,1212,1212,3173,20,17,173,1196,1261,1773]

theorem envBound29189 : H12AffineFastState.Bounded env29189 := by
  intro p hp
  have h : env29189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29188_29189 : H12AffineEnvironment.transform 7 172 env29188 = env29189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env29188 == env29189) = true)

theorem identity29189 : scanCanonicalize (H12AffineFastState.compose env29189 (packedSelected [0,2,3,5,7,10,11,12,15,16,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 754) := by decide +kernel

theorem selectedBound29189 : packedSelected [0,2,3,5,7,10,11,12,15,16,17,18] rootPS < 2^1333 := by decide +kernel

def env29190 : List Nat := [2,4,8,16,32,64,128,172,512,1024,754,1,24,1213,1029,154,1261,27,237,1028,1,112,16,138,1148,1197,146,1212,1212,1687,20,17,173,1196,1261,1773]

theorem envBound29190 : H12AffineFastState.Bounded env29190 := by
  intro p hp
  have h : env29190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29189_29190 : H12AffineEnvironment.transform 10 754 env29189 = env29190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 754 env29189 == env29190) = true)

theorem identity29190 : scanCanonicalize (H12AffineFastState.compose env29190 (packedSelected [0,2,3,7,8,10,12,15,16] rootPS)) = affineNative (2^(8+1) ^^^ 75) := by decide +kernel

theorem selectedBound29190 : packedSelected [0,2,3,7,8,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env29191 : List Nat := [2,4,8,16,32,64,128,172,75,1024,185,1,24,1213,1029,154,1261,27,237,1028,1,112,16,138,1148,1197,146,1212,1212,1244,20,17,173,1196,1261,1190]

theorem envBound29191 : H12AffineFastState.Bounded env29191 := by
  intro p hp
  have h : env29191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29190_29191 : H12AffineEnvironment.transform 8 75 env29190 = env29191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 75 env29190 == env29191) = true)

theorem identity29191 : scanCanonicalize (H12AffineFastState.compose env29191 (packedSelected [0,2,9,10,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound29191 : packedSelected [0,2,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env29192 : List Nat := [2,4,8,16,32,64,18,62,75,1024,43,1,24,1071,1029,8,1151,27,127,1028,1,112,16,24,1148,1087,0,1070,1070,1102,20,17,63,1086,1151,1076]

theorem envBound29192 : H12AffineFastState.Bounded env29192 := by
  intro p hp
  have h : env29192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29191_29192 : H12AffineEnvironment.transform 6 18 env29191 = env29192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env29191 == env29192) = true)

theorem identity29192 : scanCanonicalize (H12AffineFastState.compose env29192 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound29192 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env29193 : List Nat := [2,4,8,16,32,64,18,62,75,5,43,1,24,42,0,8,122,27,127,1,1,112,16,24,121,58,0,43,43,75,20,17,63,59,122,49]

theorem envBound29193 : H12AffineFastState.Bounded env29193 := by
  intro p hp
  have h : env29193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29192_29193 : H12AffineEnvironment.transform 9 5 env29192 = env29193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env29192 == env29193) = true)

theorem identity29193 : scanCanonicalize (H12AffineFastState.compose env29193 (packedSelected [2,4,7] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound29193 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env29194 : List Nat := [2,4,8,16,32,32,18,62,43,5,43,1,24,42,0,8,26,27,31,1,1,16,16,24,25,58,0,43,43,43,20,17,63,59,26,49]

theorem envBound29194 : H12AffineFastState.Bounded env29194 := by
  intro p hp
  have h : env29194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29193_29194 : H12AffineEnvironment.transform 5 32 env29193 = env29194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env29193 == env29194) = true)

theorem identity29194 : scanCanonicalize (H12AffineFastState.compose env29194 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound29194 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env29195 : List Nat := [2,4,8,11,32,32,9,37,43,5,43,1,3,42,0,8,1,0,4,1,1,11,11,3,2,33,0,43,43,43,15,10,36,32,1,42]

theorem envBound29195 : H12AffineFastState.Bounded env29195 := by
  intro p hp
  have h : env29195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29194_29195 : H12AffineEnvironment.transform 3 11 env29194 = env29195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env29194 == env29195) = true)

theorem identity29195 : scanCanonicalize (H12AffineFastState.compose env29195 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound29195 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env29196 : List Nat := [2,4,1,2,32,32,0,37,34,5,34,1,3,35,0,1,1,0,4,1,1,2,2,3,2,33,0,34,34,34,6,3,36,32,1,35]

theorem envBound29196 : H12AffineFastState.Bounded env29196 := by
  intro p hp
  have h : env29196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29195_29196 : H12AffineEnvironment.transform 2 1 env29195 = env29196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env29195 == env29196) = true)

theorem identity29196 : scanCanonicalize (H12AffineFastState.compose env29196 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound29196 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29197 : List Nat := [2,4,1,2,2,2,0,7,0,5,0,1,3,1,0,1,1,0,4,1,1,2,2,3,2,3,0,0,0,0,6,3,6,2,1,1]

theorem envBound29197 : H12AffineFastState.Bounded env29197 := by
  intro p hp
  have h : env29197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29196_29197 : H12AffineEnvironment.transform 4 2 env29196 = env29197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env29196 == env29197) = true)

theorem identity29197 : scanCanonicalize (H12AffineFastState.compose env29197 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound29197 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29198 : List Nat := [2,0,1,2,2,2,0,3,0,1,0,1,3,1,0,1,1,0,0,1,1,2,2,3,2,3,0,0,0,0,2,3,2,2,1,1]

theorem envBound29198 : H12AffineFastState.Bounded env29198 := by
  intro p hp
  have h : env29198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29197_29198 : H12AffineEnvironment.transform 1 0 env29197 = env29198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env29197 == env29198) = true)

theorem identity29198 : scanCanonicalize (H12AffineFastState.compose env29198 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound29198 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env29199 : List Nat := [0,0,1,0,0,0,0,1,0,1,0,1,1,1,0,1,1,0,0,1,1,0,0,1,0,1,0,0,0,0,0,1,0,0,1,1]

theorem envBound29199 : H12AffineFastState.Bounded env29199 := by
  intro p hp
  have h : env29199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29198_29199 : H12AffineEnvironment.transform 0 0 env29198 = env29199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env29198 == env29199) = true)

def env29200 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,524288,32769,4096,61649,91183,123165,533641,614527,385202,90415,545089,96347,25884,594022,257,1280,1345,525824]

theorem envBound29200 : H12AffineFastState.Bounded env29200 := by
  intro p hp
  have h : env29200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29020_29200 : H12AffineEnvironment.transform 23 123165 env29020 = env29200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 123165 env29020 == env29200) = true)

def env29201 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,21584,32769,4096,61649,91183,123165,28889,78895,385202,90415,1297,96347,25884,82998,257,1280,1345,21072]

theorem envBound29201 : H12AffineFastState.Bounded env29201 := by
  intro p hp
  have h : env29201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29200_29201 : H12AffineEnvironment.transform 18 21584 env29200 = env29201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21584 env29200 == env29201) = true)

theorem identity29201 : scanCanonicalize (H12AffineFastState.compose env29201 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 25677) := by decide +kernel

theorem selectedBound29201 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env29202 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,25677,65536,74863,262144,21584,25676,4096,5276,91183,66896,28889,78895,328959,90415,1297,96347,25884,82998,257,1280,1345,21072]

theorem envBound29202 : H12AffineFastState.Bounded env29202 := by
  intro p hp
  have h : env29202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29201_29202 : H12AffineEnvironment.transform 14 25677 env29201 = env29202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25677 env29201 == env29202) = true)

def env29203 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74863,262144,4416,8540,4096,5276,74047,66896,13769,78895,328959,74815,1297,81227,8204,65830,257,1280,1345,5952]

theorem envBound29203 : H12AffineFastState.Bounded env29203 := by
  intro p hp
  have h : env29203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29202_29203 : H12AffineEnvironment.transform 13 1296 env29202 = env29203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env29202 == env29203) = true)

def env29204 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74863,65664,4416,8540,4096,5276,74047,66896,13769,78895,1151,74815,1297,81227,8204,65830,257,1280,1345,5952]

theorem envBound29204 : H12AffineFastState.Bounded env29204 := by
  intro p hp
  have h : env29204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29203_29204 : H12AffineEnvironment.transform 17 65664 env29203 = env29204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env29203 == env29204) = true)

theorem identity29204 : scanCanonicalize (H12AffineFastState.compose env29204 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 72) := by decide +kernel

theorem selectedBound29204 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env29205 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,72,1296,277,65536,66599,65664,4416,276,4096,5276,65911,66896,5505,70759,1151,66679,1297,72963,68,65830,257,1280,1345,5952]

theorem envBound29205 : H12AffineFastState.Bounded env29205 := by
  intro p hp
  have h : env29205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29204_29205 : H12AffineEnvironment.transform 12 72 env29204 = env29205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env29204 == env29205) = true)

def env29206 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1556,72,1296,277,65536,66599,65664,1876,276,1556,648,65911,66896,917,66163,1151,66679,1297,68375,68,65830,257,1280,1345,340]

theorem envBound29206 : H12AffineFastState.Bounded env29206 := by
  intro p hp
  have h : env29206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29205_29206 : H12AffineEnvironment.transform 11 1556 env29205 = env29206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1556 env29205 == env29206) = true)

def env29207 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,852,72,80,277,65536,65895,65664,532,276,852,648,65911,65552,917,66163,319,65847,81,68375,68,65830,257,64,1,340]

theorem envBound29207 : H12AffineFastState.Bounded env29207 := by
  intro p hp
  have h : env29207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29206_29207 : H12AffineEnvironment.transform 9 320 env29206 = env29207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env29206 == env29207) = true)

theorem identity29207 : scanCanonicalize (H12AffineFastState.compose env29207 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 807) := by decide +kernel

theorem selectedBound29207 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env29208 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,852,72,80,277,807,576,935,532,276,852,648,592,823,917,340,319,528,81,2096,68,513,257,64,1,340]

theorem envBound29208 : H12AffineFastState.Bounded env29208 := by
  intro p hp
  have h : env29208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29207_29208 : H12AffineEnvironment.transform 15 807 env29207 = env29208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 807 env29207 == env29208) = true)

theorem identity29208 : scanCanonicalize (H12AffineFastState.compose env29208 (packedSelected [0,3,4,5,9,10,16,27] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound29208 : packedSelected [0,3,4,5,9,10,16,27] rootPS < 2^1333 := by decide +kernel

def env29209 : List Nat := [2,4,8,16,32,64,128,68,512,4,2048,528,72,80,81,611,576,739,532,80,528,648,592,627,721,16,123,528,81,2096,68,513,69,64,1,16]

theorem envBound29209 : H12AffineFastState.Bounded env29209 := by
  intro p hp
  have h : env29209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29208_29209 : H12AffineEnvironment.transform 7 68 env29208 = env29209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env29208 == env29209) = true)

theorem identity29209 : scanCanonicalize (H12AffineFastState.compose env29209 (packedSelected [0,7,8,12,15,17,18] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound29209 : packedSelected [0,7,8,12,15,17,18] rootPS < 2^1333 := by decide +kernel

def env29210 : List Nat := [2,4,8,16,13,64,128,68,512,4,2048,528,72,80,81,590,576,718,532,80,528,648,592,606,721,16,86,528,81,2077,68,513,69,64,1,16]

theorem envBound29210 : H12AffineFastState.Bounded env29210 := by
  intro p hp
  have h : env29210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29209_29210 : H12AffineEnvironment.transform 4 13 env29209 = env29210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env29209 == env29210) = true)

theorem identity29210 : scanCanonicalize (H12AffineFastState.compose env29210 (packedSelected [2,3,5,8,10,11,13,17,20] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound29210 : packedSelected [2,3,5,8,10,11,13,17,20] rootPS < 2^1333 := by decide +kernel

def env29211 : List Nat := [2,4,8,16,13,64,128,68,137,4,2048,153,72,80,81,199,201,71,157,80,153,1,217,215,88,16,86,153,81,2077,68,136,69,64,1,16]

theorem envBound29211 : H12AffineFastState.Bounded env29211 := by
  intro p hp
  have h : env29211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29210_29211 : H12AffineEnvironment.transform 8 137 env29210 = env29211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env29210 == env29211) = true)

theorem identity29211 : scanCanonicalize (H12AffineFastState.compose env29211 (packedSelected [0,1,2,3,7,8,11,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 194) := by decide +kernel

theorem selectedBound29211 : packedSelected [0,1,2,3,7,8,11,12,15] rootPS < 2^1333 := by decide +kernel

def env29212 : List Nat := [2,4,8,16,13,64,128,68,137,4,194,153,72,80,81,199,201,71,157,80,153,1,217,215,88,16,86,153,81,223,68,136,69,64,1,16]

theorem envBound29212 : H12AffineFastState.Bounded env29212 := by
  intro p hp
  have h : env29212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29211_29212 : H12AffineEnvironment.transform 10 194 env29211 = env29212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 194 env29211 == env29212) = true)

theorem identity29212 : scanCanonicalize (H12AffineFastState.compose env29212 (packedSelected [10] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound29212 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env29213 : List Nat := [2,4,3,16,6,64,128,68,130,4,194,146,67,80,81,199,194,71,150,80,146,1,210,215,83,16,86,146,81,212,68,131,69,64,1,16]

theorem envBound29213 : H12AffineFastState.Bounded env29213 := by
  intro p hp
  have h : env29213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29212_29213 : H12AffineEnvironment.transform 2 3 env29212 = env29213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env29212 == env29213) = true)

theorem identity29213 : scanCanonicalize (H12AffineFastState.compose env29213 (packedSelected [1,3,4,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 6) := by decide +kernel

theorem selectedBound29213 : packedSelected [1,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env29214 : List Nat := [2,4,3,16,6,6,128,2,130,4,132,146,5,22,23,129,132,1,150,22,146,1,148,145,21,16,16,146,23,146,2,131,3,6,1,16]

theorem envBound29214 : H12AffineFastState.Bounded env29214 := by
  intro p hp
  have h : env29214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29213_29214 : H12AffineEnvironment.transform 5 6 env29213 = env29214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 6 env29213 == env29214) = true)

theorem identity29214 : scanCanonicalize (H12AffineFastState.compose env29214 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound29214 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env29215 : List Nat := [2,4,3,16,6,6,4,2,6,4,0,22,5,22,23,5,0,1,18,22,22,1,16,21,21,16,16,22,23,22,2,7,3,6,1,16]

theorem envBound29215 : H12AffineFastState.Bounded env29215 := by
  intro p hp
  have h : env29215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29214_29215 : H12AffineEnvironment.transform 6 4 env29214 = env29215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env29214 == env29215) = true)

theorem identity29215 : scanCanonicalize (H12AffineFastState.compose env29215 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound29215 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29216 : List Nat := [2,2,3,16,0,0,2,2,0,2,0,16,3,16,17,3,0,1,18,16,16,1,16,19,19,16,16,16,17,16,2,1,3,0,1,16]

theorem envBound29216 : H12AffineFastState.Bounded env29216 := by
  intro p hp
  have h : env29216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29215_29216 : H12AffineEnvironment.transform 1 2 env29215 = env29216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env29215 == env29216) = true)

theorem identity29216 : scanCanonicalize (H12AffineFastState.compose env29216 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound29216 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env29217 : List Nat := [2,2,3,0,0,0,2,2,0,2,0,0,3,0,1,3,0,1,2,0,0,1,0,3,3,0,0,0,1,0,2,1,3,0,1,0]

theorem envBound29217 : H12AffineFastState.Bounded env29217 := by
  intro p hp
  have h : env29217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29216_29217 : H12AffineEnvironment.transform 3 0 env29216 = env29217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env29216 == env29217) = true)

def env29218 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,853,72,81,277,65536,65894,65664,533,276,853,648,65911,65553,917,66163,318,65846,80,68375,68,65830,257,65,0,340]

theorem envBound29218 : H12AffineFastState.Bounded env29218 := by
  intro p hp
  have h : env29218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29206_29218 : H12AffineEnvironment.transform 9 321 env29206 = env29218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env29206 == env29218) = true)

theorem identity29218 : scanCanonicalize (H12AffineFastState.compose env29218 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound29218 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env29219 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,853,72,81,277,114,276,242,533,276,853,648,261,99,917,513,318,324,80,2917,68,340,257,65,0,340]

theorem envBound29219 : H12AffineFastState.Bounded env29219 := by
  intro p hp
  have h : env29219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29218_29219 : H12AffineEnvironment.transform 15 114 env29218 = env29219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env29218 == env29219) = true)

theorem identity29219 : scanCanonicalize (H12AffineFastState.compose env29219 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound29219 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env29220 : List Nat := [2,4,8,16,32,64,128,256,17,321,2048,324,72,81,277,114,276,242,4,276,324,153,261,99,388,16,318,324,80,2420,68,340,257,65,0,340]

theorem envBound29220 : H12AffineFastState.Bounded env29220 := by
  intro p hp
  have h : env29220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29219_29220 : H12AffineEnvironment.transform 8 17 env29219 = env29220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env29219 == env29220) = true)

theorem identity29220 : scanCanonicalize (H12AffineFastState.compose env29220 (packedSelected [0,1,2,3,5,7,8,11,12,13,15] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound29220 : packedSelected [0,1,2,3,5,7,8,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env29221 : List Nat := [2,4,8,16,32,64,2,256,17,321,2048,324,72,81,277,114,276,112,4,276,324,27,261,99,262,16,318,324,80,2420,68,340,257,65,0,340]

theorem envBound29221 : H12AffineFastState.Bounded env29221 := by
  intro p hp
  have h : env29221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29220_29221 : H12AffineEnvironment.transform 6 2 env29220 = env29221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env29220 == env29221) = true)

theorem identity29221 : scanCanonicalize (H12AffineFastState.compose env29221 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound29221 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env29222 : List Nat := [2,4,8,16,32,64,2,69,17,4,2048,1,72,81,80,114,81,112,4,81,1,27,64,99,67,16,123,1,80,2097,68,17,68,65,0,17]

theorem envBound29222 : H12AffineFastState.Bounded env29222 := by
  intro p hp
  have h : env29222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29221_29222 : H12AffineEnvironment.transform 7 69 env29221 = env29222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env29221 == env29222) = true)

theorem identity29222 : scanCanonicalize (H12AffineFastState.compose env29222 (packedSelected [1,3,5] rootPS)) = affineNative (2^(5+1) ^^^ 55) := by decide +kernel

theorem selectedBound29222 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env29223 : List Nat := [2,4,8,16,32,55,2,50,17,4,2048,1,63,38,39,5,38,7,4,38,1,27,55,20,52,16,12,1,39,2097,51,17,51,54,0,17]

theorem envBound29223 : H12AffineFastState.Bounded env29223 := by
  intro p hp
  have h : env29223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29222_29223 : H12AffineEnvironment.transform 5 55 env29222 = env29223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 55 env29222 == env29223) = true)

theorem identity29223 : scanCanonicalize (H12AffineFastState.compose env29223 (packedSelected [2,3,8] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound29223 : packedSelected [2,3,8] rootPS < 2^1333 := by decide +kernel

def env29224 : List Nat := [2,4,8,16,7,16,2,21,17,4,2048,1,24,1,0,5,1,7,4,1,1,27,16,20,19,16,12,1,0,2070,20,17,20,17,0,17]

theorem envBound29224 : H12AffineFastState.Bounded env29224 := by
  intro p hp
  have h : env29224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29223_29224 : H12AffineEnvironment.transform 4 7 env29223 = env29224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env29223 == env29224) = true)

theorem identity29224 : scanCanonicalize (H12AffineFastState.compose env29224 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound29224 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29225 : List Nat := [2,4,8,16,7,16,2,21,17,4,16,1,24,1,0,5,1,7,4,1,1,27,16,20,19,16,12,1,0,6,20,17,20,17,0,17]

theorem envBound29225 : H12AffineFastState.Bounded env29225 := by
  intro p hp
  have h : env29225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29224_29225 : H12AffineEnvironment.transform 10 16 env29224 = env29225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env29224 == env29225) = true)

theorem identity29225 : scanCanonicalize (H12AffineFastState.compose env29225 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound29225 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env29226 : List Nat := [2,4,2,16,7,16,2,21,17,4,16,1,18,1,0,5,1,7,4,1,1,17,16,20,19,16,6,1,0,6,20,17,20,17,0,17]

theorem envBound29226 : H12AffineFastState.Bounded env29226 := by
  intro p hp
  have h : env29226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29225_29226 : H12AffineEnvironment.transform 2 2 env29225 = env29226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env29225 == env29226) = true)

theorem identity29226 : scanCanonicalize (H12AffineFastState.compose env29226 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound29226 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env29227 : List Nat := [2,4,2,1,7,1,2,4,0,4,1,1,3,1,0,5,1,7,4,1,1,0,1,5,2,1,6,1,0,6,5,0,5,0,0,0]

theorem envBound29227 : H12AffineFastState.Bounded env29227 := by
  intro p hp
  have h : env29227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29226_29227 : H12AffineEnvironment.transform 3 1 env29226 = env29227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env29226 == env29227) = true)

theorem identity29227 : scanCanonicalize (H12AffineFastState.compose env29227 (packedSelected [7] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound29227 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env29228 : List Nat := [2,2,2,1,1,1,2,2,0,2,1,1,3,1,0,3,1,1,2,1,1,0,1,3,2,1,0,1,0,0,3,0,3,0,0,0]

theorem envBound29228 : H12AffineFastState.Bounded env29228 := by
  intro p hp
  have h : env29228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29227_29228 : H12AffineEnvironment.transform 1 2 env29227 = env29228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env29227 == env29228) = true)

def env29229 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1557,72,1296,277,65536,66599,65664,1877,276,1557,649,65911,66896,916,66162,1151,66679,1297,68374,68,65830,257,1280,1345,341]

theorem envBound29229 : H12AffineFastState.Bounded env29229 := by
  intro p hp
  have h : env29229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29205_29229 : H12AffineEnvironment.transform 11 1557 env29205 = env29229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1557 env29205 == env29229) = true)

def env29230 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,853,72,80,277,65536,65895,65664,533,276,853,649,65911,65552,916,66162,319,65847,81,68374,68,65830,257,64,1,341]

theorem envBound29230 : H12AffineFastState.Bounded env29230 := by
  intro p hp
  have h : env29230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29229_29230 : H12AffineEnvironment.transform 9 320 env29229 = env29230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env29229 == env29230) = true)

theorem identity29230 : scanCanonicalize (H12AffineFastState.compose env29230 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 806) := by decide +kernel

theorem selectedBound29230 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env29231 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,853,72,80,277,806,577,934,533,276,853,649,593,822,916,340,319,529,81,2096,68,512,257,64,1,341]

theorem envBound29231 : H12AffineFastState.Bounded env29231 := by
  intro p hp
  have h : env29231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29230_29231 : H12AffineEnvironment.transform 15 806 env29230 = env29231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 806 env29230 == env29231) = true)

theorem identity29231 : scanCanonicalize (H12AffineFastState.compose env29231 (packedSelected [0,3,4,5,9,10,16,27] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound29231 : packedSelected [0,3,4,5,9,10,16,27] rootPS < 2^1333 := by decide +kernel

def env29232 : List Nat := [2,4,8,16,32,64,128,68,512,4,2048,529,72,80,81,610,577,738,533,80,529,649,593,626,720,16,123,529,81,2096,68,512,69,64,1,17]

theorem envBound29232 : H12AffineFastState.Bounded env29232 := by
  intro p hp
  have h : env29232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29231_29232 : H12AffineEnvironment.transform 7 68 env29231 = env29232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env29231 == env29232) = true)

theorem identity29232 : scanCanonicalize (H12AffineFastState.compose env29232 (packedSelected [0,7,8,12,15,17,18] rootPS)) = affineNative (2^(8+1) ^^^ 108) := by decide +kernel

theorem selectedBound29232 : packedSelected [0,7,8,12,15,17,18] rootPS < 2^1333 := by decide +kernel

def env29233 : List Nat := [2,4,8,16,32,64,128,68,108,4,2048,125,72,80,81,14,45,142,121,80,125,229,61,30,188,16,123,125,81,2096,68,108,69,64,1,17]

theorem envBound29233 : H12AffineFastState.Bounded env29233 := by
  intro p hp
  have h : env29233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29232_29233 : H12AffineEnvironment.transform 8 108 env29232 = env29233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 108 env29232 == env29233) = true)

theorem identity29233 : scanCanonicalize (H12AffineFastState.compose env29233 (packedSelected [2,3,5,8,10,11,13,17,20] rootPS)) = affineNative (2^(6+1) ^^^ 101) := by decide +kernel

theorem selectedBound29233 : packedSelected [2,3,5,8,10,11,13,17,20] rootPS < 2^1333 := by decide +kernel

def env29234 : List Nat := [2,4,8,16,32,64,101,68,108,4,2048,125,72,80,81,14,45,107,121,80,125,0,61,30,89,16,123,125,81,2096,68,108,69,64,1,17]

theorem envBound29234 : H12AffineFastState.Bounded env29234 := by
  intro p hp
  have h : env29234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29233_29234 : H12AffineEnvironment.transform 6 101 env29233 = env29234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 101 env29233 == env29234) = true)

theorem identity29234 : scanCanonicalize (H12AffineFastState.compose env29234 (packedSelected [0,1,2,3,7,8,11,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 39) := by decide +kernel

theorem selectedBound29234 : packedSelected [0,1,2,3,7,8,11,12,15] rootPS < 2^1333 := by decide +kernel

def env29235 : List Nat := [2,4,8,16,32,64,101,68,108,4,39,125,72,80,81,14,45,107,121,80,125,0,61,30,89,16,123,125,81,23,68,108,69,64,1,17]

theorem envBound29235 : H12AffineFastState.Bounded env29235 := by
  intro p hp
  have h : env29235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29234_29235 : H12AffineEnvironment.transform 10 39 env29234 = env29235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 39 env29234 == env29235) = true)

theorem identity29235 : scanCanonicalize (H12AffineFastState.compose env29235 (packedSelected [10] rootPS)) = affineNative (2^(5+1) ^^^ 55) := by decide +kernel

theorem selectedBound29235 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env29236 : List Nat := [2,4,8,16,32,55,18,51,27,4,39,10,63,39,38,14,45,28,14,39,10,0,61,30,46,16,12,10,38,23,51,27,50,55,1,17]

theorem envBound29236 : H12AffineFastState.Bounded env29236 := by
  intro p hp
  have h : env29236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29235_29236 : H12AffineEnvironment.transform 5 55 env29235 = env29236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 55 env29235 == env29236) = true)

theorem identity29236 : scanCanonicalize (H12AffineFastState.compose env29236 (packedSelected [4,7] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound29236 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env29237 : List Nat := [2,4,8,16,12,27,18,31,27,4,11,10,19,11,10,14,1,28,14,11,10,0,17,30,2,16,12,10,10,23,31,27,30,27,1,17]

theorem envBound29237 : H12AffineFastState.Bounded env29237 := by
  intro p hp
  have h : env29237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29236_29237 : H12AffineEnvironment.transform 4 12 env29236 = env29237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env29236 == env29237) = true)

theorem identity29237 : scanCanonicalize (H12AffineFastState.compose env29237 (packedSelected [1,2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound29237 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env29238 : List Nat := [2,4,8,1,12,10,3,14,10,4,11,10,2,11,10,14,1,13,14,11,10,0,0,15,2,1,12,10,10,6,14,10,15,10,1,0]

theorem envBound29238 : H12AffineFastState.Bounded env29238 := by
  intro p hp
  have h : env29238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29237_29238 : H12AffineEnvironment.transform 3 1 env29237 = env29238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env29237 == env29238) = true)

theorem identity29238 : scanCanonicalize (H12AffineFastState.compose env29238 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound29238 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env29239 : List Nat := [2,4,5,1,1,7,3,3,7,4,6,7,2,6,7,3,1,0,3,6,7,0,0,2,2,1,1,7,7,6,3,7,2,7,1,0]

theorem envBound29239 : H12AffineFastState.Bounded env29239 := by
  intro p hp
  have h : env29239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29238_29239 : H12AffineEnvironment.transform 2 5 env29238 = env29239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env29238 == env29239) = true)

theorem identity29239 : scanCanonicalize (H12AffineFastState.compose env29239 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound29239 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29240 : List Nat := [2,2,3,1,1,1,3,3,1,2,0,1,2,0,1,3,1,0,3,0,1,0,0,2,2,1,1,1,1,0,3,1,2,1,1,0]

theorem envBound29240 : H12AffineFastState.Bounded env29240 := by
  intro p hp
  have h : env29240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29239_29240 : H12AffineEnvironment.transform 1 2 env29239 = env29240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env29239 == env29240) = true)

theorem identity29240 : scanCanonicalize (H12AffineFastState.compose env29240 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound29240 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29241 : List Nat := [0,0,1,1,1,1,1,1,1,0,0,1,0,0,1,1,1,0,1,0,1,0,0,0,0,1,1,1,1,0,1,1,0,1,1,0]

theorem envBound29241 : H12AffineFastState.Bounded env29241 := by
  intro p hp
  have h : env29241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29240_29241 : H12AffineEnvironment.transform 0 0 env29240 = env29241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env29240 == env29241) = true)

def env29242 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,852,72,81,277,65536,65894,65664,532,276,852,649,65911,65553,916,66162,318,65846,80,68374,68,65830,257,65,0,341]

theorem envBound29242 : H12AffineFastState.Bounded env29242 := by
  intro p hp
  have h : env29242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29229_29242 : H12AffineEnvironment.transform 9 321 env29229 = env29242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env29229 == env29242) = true)

theorem identity29242 : scanCanonicalize (H12AffineFastState.compose env29242 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound29242 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env29243 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,852,72,81,277,114,276,242,532,276,852,649,261,99,916,512,318,324,80,2916,68,340,257,65,0,341]

theorem envBound29243 : H12AffineFastState.Bounded env29243 := by
  intro p hp
  have h : env29243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29242_29243 : H12AffineEnvironment.transform 15 114 env29242 = env29243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env29242 == env29243) = true)

theorem identity29243 : scanCanonicalize (H12AffineFastState.compose env29243 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound29243 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env29244 : List Nat := [2,4,8,16,32,64,128,256,16,321,2048,324,72,81,277,114,276,242,4,276,324,153,261,99,388,16,318,324,80,2420,68,340,257,65,0,341]

theorem envBound29244 : H12AffineFastState.Bounded env29244 := by
  intro p hp
  have h : env29244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29243_29244 : H12AffineEnvironment.transform 8 16 env29243 = env29244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env29243 == env29244) = true)

theorem identity29244 : scanCanonicalize (H12AffineFastState.compose env29244 (packedSelected [0,1,2,3,5,7,8,11,12,13,15] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound29244 : packedSelected [0,1,2,3,5,7,8,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env29245 : List Nat := [2,4,8,16,32,64,3,256,16,321,2048,324,72,81,277,114,276,113,4,276,324,26,261,99,263,16,318,324,80,2420,68,340,257,65,0,341]

theorem envBound29245 : H12AffineFastState.Bounded env29245 := by
  intro p hp
  have h : env29245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29244_29245 : H12AffineEnvironment.transform 6 3 env29244 = env29245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env29244 == env29245) = true)

theorem identity29245 : scanCanonicalize (H12AffineFastState.compose env29245 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound29245 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env29246 : List Nat := [2,4,8,16,32,64,3,69,16,4,2048,1,72,81,80,114,81,113,4,81,1,26,64,99,66,16,123,1,80,2097,68,17,68,65,0,16]

theorem envBound29246 : H12AffineFastState.Bounded env29246 := by
  intro p hp
  have h : env29246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29245_29246 : H12AffineEnvironment.transform 7 69 env29245 = env29246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env29245 == env29246) = true)

theorem identity29246 : scanCanonicalize (H12AffineFastState.compose env29246 (packedSelected [1,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound29246 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env29247 : List Nat := [2,4,8,16,7,64,3,69,16,4,2048,1,72,81,80,85,81,86,4,81,1,26,64,68,66,16,92,1,80,2070,68,17,68,65,0,16]

theorem envBound29247 : H12AffineFastState.Bounded env29247 := by
  intro p hp
  have h : env29247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29246_29247 : H12AffineEnvironment.transform 4 7 env29246 = env29247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env29246 == env29247) = true)

theorem identity29247 : scanCanonicalize (H12AffineFastState.compose env29247 (packedSelected [2,3,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound29247 : packedSelected [2,3,8] rootPS < 2^1333 := by decide +kernel

def env29248 : List Nat := [2,4,8,16,7,16,3,21,16,4,2048,1,24,1,0,5,1,6,4,1,1,26,16,20,18,16,12,1,0,2070,20,17,20,17,0,16]

theorem envBound29248 : H12AffineFastState.Bounded env29248 := by
  intro p hp
  have h : env29248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29247_29248 : H12AffineEnvironment.transform 5 16 env29247 = env29248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env29247 == env29248) = true)

theorem identity29248 : scanCanonicalize (H12AffineFastState.compose env29248 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound29248 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29249 : List Nat := [2,4,8,16,7,16,3,21,16,4,17,1,24,1,0,5,1,6,4,1,1,26,16,20,18,16,12,1,0,7,20,17,20,17,0,16]

theorem envBound29249 : H12AffineFastState.Bounded env29249 := by
  intro p hp
  have h : env29249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29248_29249 : H12AffineEnvironment.transform 10 17 env29248 = env29249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env29248 == env29249) = true)

theorem identity29249 : scanCanonicalize (H12AffineFastState.compose env29249 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound29249 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env29250 : List Nat := [2,4,3,16,7,16,3,21,16,4,17,1,19,1,0,5,1,6,4,1,1,17,16,20,18,16,7,1,0,7,20,17,20,17,0,16]

theorem envBound29250 : H12AffineFastState.Bounded env29250 := by
  intro p hp
  have h : env29250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29249_29250 : H12AffineEnvironment.transform 2 3 env29249 = env29250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env29249 == env29250) = true)

theorem identity29250 : scanCanonicalize (H12AffineFastState.compose env29250 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound29250 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env29251 : List Nat := [2,4,3,0,7,0,3,5,0,4,1,1,3,1,0,5,1,6,4,1,1,1,0,4,2,0,7,1,0,7,4,1,4,1,0,0]

theorem envBound29251 : H12AffineFastState.Bounded env29251 := by
  intro p hp
  have h : env29251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29250_29251 : H12AffineEnvironment.transform 3 0 env29250 = env29251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env29250 == env29251) = true)

theorem identity29251 : scanCanonicalize (H12AffineFastState.compose env29251 (packedSelected [7] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound29251 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env29252 : List Nat := [2,3,3,0,0,0,3,2,0,3,1,1,3,1,0,2,1,1,3,1,1,1,0,3,2,0,0,1,0,0,3,1,3,1,0,0]

theorem envBound29252 : H12AffineFastState.Bounded env29252 := by
  intro p hp
  have h : env29252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29251_29252 : H12AffineEnvironment.transform 1 3 env29251 = env29252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env29251 == env29252) = true)

def env29253 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74863,65665,4416,8540,4096,5276,74047,66896,13769,78895,1150,74815,1297,81227,8204,65830,257,1280,1345,5952]

theorem envBound29253 : H12AffineFastState.Bounded env29253 := by
  intro p hp
  have h : env29253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29203_29253 : H12AffineEnvironment.transform 17 65665 env29203 = env29253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env29203 == env29253) = true)

theorem identity29253 : scanCanonicalize (H12AffineFastState.compose env29253 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5385) := by decide +kernel

theorem selectedBound29253 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env29254 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5385,1296,5204,65536,69990,65665,4416,5205,4096,5276,70710,66896,192,65830,1150,69942,1297,67650,5381,65830,257,1280,1345,5952]

theorem envBound29254 : H12AffineFastState.Bounded env29254 := by
  intro p hp
  have h : env29254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29253_29254 : H12AffineEnvironment.transform 12 5385 env29253 = env29254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5385 env29253 == env29254) = true)

def env29255 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1556,797,1296,576,65536,67442,65665,1876,577,1556,648,66082,66896,192,65830,1150,67362,1297,67650,785,65830,257,1280,1345,340]

theorem envBound29255 : H12AffineFastState.Bounded env29255 := by
  intro p hp
  have h : env29255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29254_29255 : H12AffineEnvironment.transform 11 1556 env29254 = env29255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1556 env29254 == env29255) = true)

def env29256 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,836,797,64,576,65536,66082,65665,516,577,836,648,66082,65536,192,65830,302,66162,65,67650,785,65830,257,80,17,340]

theorem envBound29256 : H12AffineFastState.Bounded env29256 := by
  intro p hp
  have h : env29256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29255_29256 : H12AffineEnvironment.transform 9 336 env29255 = env29256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 336 env29255 == env29256) = true)

theorem identity29256 : scanCanonicalize (H12AffineFastState.compose env29256 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 84) := by decide +kernel

theorem selectedBound29256 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env29257 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,836,797,64,576,84,630,213,516,577,836,648,630,84,192,370,302,550,65,2070,785,370,257,80,17,340]

theorem envBound29257 : H12AffineFastState.Bounded env29257 := by
  intro p hp
  have h : env29257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29256_29257 : H12AffineEnvironment.transform 15 84 env29256 = env29257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 84 env29256 == env29257) = true)

def env29258 : List Nat := [2,4,8,16,32,64,128,256,96,336,2048,292,381,64,32,84,22,213,100,33,292,232,22,84,192,370,302,70,65,2070,369,370,257,80,17,340]

theorem envBound29258 : H12AffineFastState.Bounded env29258 := by
  intro p hp
  have h : env29258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29257_29258 : H12AffineEnvironment.transform 8 96 env29257 = env29258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 96 env29257 == env29258) = true)

theorem identity29258 : scanCanonicalize (H12AffineFastState.compose env29258 (packedSelected [0,5,7,12,17,20,21,38] rootPS)) = affineNative (2^(7+1) ^^^ 234) := by decide +kernel

theorem selectedBound29258 : packedSelected [0,5,7,12,17,20,21,38] rootPS < 2^1333 := by decide +kernel

def env29259 : List Nat := [2,4,8,16,32,64,128,234,96,186,2048,206,151,64,32,84,22,213,100,33,206,232,22,84,192,152,196,70,65,2070,155,152,235,80,17,190]

theorem envBound29259 : H12AffineFastState.Bounded env29259 := by
  intro p hp
  have h : env29259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29258_29259 : H12AffineEnvironment.transform 7 234 env29258 = env29259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 234 env29258 == env29259) = true)

theorem identity29259 : scanCanonicalize (H12AffineFastState.compose env29259 (packedSelected [1,3,4,8,9,10,16,17,19] rootPS)) = affineNative (2^(5+1) ^^^ 39) := by decide +kernel

theorem selectedBound29259 : packedSelected [1,3,4,8,9,10,16,17,19] rootPS < 2^1333 := by decide +kernel

def env29260 : List Nat := [2,4,8,16,32,39,128,141,7,186,2048,169,151,39,32,51,22,178,3,33,169,143,22,51,167,152,163,33,38,2070,155,152,140,55,17,190]

theorem envBound29260 : H12AffineFastState.Bounded env29260 := by
  intro p hp
  have h : env29260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29259_29260 : H12AffineEnvironment.transform 5 39 env29259 = env29260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 39 env29259 == env29260) = true)

theorem identity29260 : scanCanonicalize (H12AffineFastState.compose env29260 (packedSelected [0,1,2,5,7,8,10,11,12,15,17,18] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound29260 : packedSelected [0,1,2,5,7,8,10,11,12,15,17,18] rootPS < 2^1333 := by decide +kernel

def env29261 : List Nat := [2,4,5,16,32,39,128,128,7,183,2048,164,151,39,32,51,22,178,3,33,164,130,22,51,167,149,163,33,38,2070,150,149,129,55,17,179]

theorem envBound29261 : H12AffineFastState.Bounded env29261 := by
  intro p hp
  have h : env29261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29260_29261 : H12AffineEnvironment.transform 2 5 env29260 = env29261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env29260 == env29261) = true)

theorem identity29261 : scanCanonicalize (H12AffineFastState.compose env29261 (packedSelected [0,5,9,12] rootPS)) = affineNative (2^(6+1) ^^^ 36) := by decide +kernel

theorem selectedBound29261 : packedSelected [0,5,9,12] rootPS < 2^1333 := by decide +kernel

def env29262 : List Nat := [2,4,5,16,32,39,36,36,7,19,2048,0,51,39,32,51,22,22,3,33,0,38,22,51,3,49,7,33,38,2070,50,49,37,55,17,23]

theorem envBound29262 : H12AffineFastState.Bounded env29262 := by
  intro p hp
  have h : env29262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29261_29262 : H12AffineEnvironment.transform 6 36 env29261 = env29262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 36 env29261 == env29262) = true)

theorem identity29262 : scanCanonicalize (H12AffineFastState.compose env29262 (packedSelected [1,4,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 38) := by decide +kernel

theorem selectedBound29262 : packedSelected [1,4,7,8] rootPS < 2^1333 := by decide +kernel

def env29263 : List Nat := [2,4,5,16,32,39,36,36,7,19,38,0,51,39,32,51,22,22,3,33,0,38,22,51,3,49,7,33,38,48,50,49,37,55,17,23]

theorem envBound29263 : H12AffineFastState.Bounded env29263 := by
  intro p hp
  have h : env29263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29262_29263 : H12AffineEnvironment.transform 10 38 env29262 = env29263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 38 env29262 == env29263) = true)

def env29264 : List Nat := [2,4,8,16,32,64,128,256,97,336,2048,293,380,64,33,84,23,213,101,32,293,233,23,84,192,370,302,71,65,2070,368,370,257,80,17,340]

theorem envBound29264 : H12AffineFastState.Bounded env29264 := by
  intro p hp
  have h : env29264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29257_29264 : H12AffineEnvironment.transform 8 97 env29257 = env29264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 97 env29257 == env29264) = true)

theorem identity29264 : scanCanonicalize (H12AffineFastState.compose env29264 (packedSelected [0,5,7,12,17,20,21,38] rootPS)) = affineNative (2^(7+1) ^^^ 237) := by decide +kernel

theorem selectedBound29264 : packedSelected [0,5,7,12,17,20,21,38] rootPS < 2^1333 := by decide +kernel

def env29265 : List Nat := [2,4,8,16,32,64,128,237,97,189,2048,200,145,64,33,84,23,213,101,32,200,233,23,84,192,159,195,71,65,2070,157,159,236,80,17,185]

theorem envBound29265 : H12AffineFastState.Bounded env29265 := by
  intro p hp
  have h : env29265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29264_29265 : H12AffineEnvironment.transform 7 237 env29264 = env29265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 237 env29264 == env29265) = true)

theorem identity29265 : scanCanonicalize (H12AffineFastState.compose env29265 (packedSelected [1,2,4,9,10,12,13,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 239) := by decide +kernel

theorem selectedBound29265 : packedSelected [1,2,4,9,10,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env29266 : List Nat := [2,4,8,16,32,64,128,237,97,189,239,200,145,64,33,84,23,213,101,32,200,233,23,84,192,159,195,71,65,249,157,159,236,80,17,185]

theorem envBound29266 : H12AffineFastState.Bounded env29266 := by
  intro p hp
  have h : env29266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29265_29266 : H12AffineEnvironment.transform 10 239 env29265 = env29266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 239 env29265 == env29266) = true)

theorem identity29266 : scanCanonicalize (H12AffineFastState.compose env29266 (packedSelected [0,2,3,7,8,15] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound29266 : packedSelected [0,2,3,7,8,15] rootPS < 2^1333 := by decide +kernel

def env29267 : List Nat := [2,4,8,16,32,64,120,21,97,69,23,48,105,64,33,84,23,45,101,32,48,17,23,84,56,103,59,71,65,1,101,103,20,80,17,65]

theorem envBound29267 : H12AffineFastState.Bounded env29267 := by
  intro p hp
  have h : env29267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29266_29267 : H12AffineEnvironment.transform 6 120 env29266 = env29267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env29266 == env29267) = true)

theorem identity29267 : scanCanonicalize (H12AffineFastState.compose env29267 (packedSelected [2,4,5,8,9,10] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound29267 : packedSelected [2,4,5,8,9,10] rootPS < 2^1333 := by decide +kernel

def env29268 : List Nat := [2,2,8,16,32,64,120,19,97,67,17,48,105,64,33,82,17,43,99,32,48,17,17,82,56,97,59,65,65,1,99,97,18,80,17,65]

theorem envBound29268 : H12AffineFastState.Bounded env29268 := by
  intro p hp
  have h : env29268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29267_29268 : H12AffineEnvironment.transform 1 2 env29267 = env29268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env29267 == env29268) = true)

theorem identity29268 : scanCanonicalize (H12AffineFastState.compose env29268 (packedSelected [0,3,4] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound29268 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env29269 : List Nat := [2,2,8,16,32,49,9,19,16,50,17,48,24,49,33,35,17,43,18,32,48,17,17,35,56,16,59,48,48,1,18,16,18,33,17,48]

theorem envBound29269 : H12AffineFastState.Bounded env29269 := by
  intro p hp
  have h : env29269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29268_29269 : H12AffineEnvironment.transform 5 49 env29268 = env29269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env29268 == env29269) = true)

theorem identity29269 : scanCanonicalize (H12AffineFastState.compose env29269 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound29269 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env29270 : List Nat := [2,2,8,1,32,32,9,2,1,35,0,33,9,32,33,35,0,43,3,32,33,0,0,35,41,1,42,33,33,1,3,1,3,33,0,33]

theorem envBound29270 : H12AffineFastState.Bounded env29270 := by
  intro p hp
  have h : env29270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29269_29270 : H12AffineEnvironment.transform 3 1 env29269 = env29270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env29269 == env29270) = true)

theorem identity29270 : scanCanonicalize (H12AffineFastState.compose env29270 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound29270 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29271 : List Nat := [2,2,3,1,32,32,2,2,1,35,0,33,2,32,33,35,0,32,3,32,33,0,0,35,34,1,33,33,33,1,3,1,3,33,0,33]

theorem envBound29271 : H12AffineFastState.Bounded env29271 := by
  intro p hp
  have h : env29271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29270_29271 : H12AffineEnvironment.transform 2 3 env29270 = env29271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env29270 == env29271) = true)

def env29272 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,837,797,65,576,65536,66083,65665,517,577,837,648,66082,65537,192,65830,303,66163,64,67650,785,65830,257,81,16,340]

theorem envBound29272 : H12AffineFastState.Bounded env29272 := by
  intro p hp
  have h : env29272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29255_29272 : H12AffineEnvironment.transform 9 337 env29255 = env29272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 337 env29255 == env29272) = true)

theorem identity29272 : scanCanonicalize (H12AffineFastState.compose env29272 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 785) := by decide +kernel

theorem selectedBound29272 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env29273 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,837,797,65,576,785,306,912,517,577,837,648,307,784,192,567,303,354,64,2899,785,567,257,81,16,340]

theorem envBound29273 : H12AffineFastState.Bounded env29273 := by
  intro p hp
  have h : env29273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29272_29273 : H12AffineEnvironment.transform 15 785 env29272 = env29273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 785 env29272 == env29273) = true)

def env29274 : List Nat := [2,4,8,0,32,64,128,256,512,321,2048,837,781,65,576,769,290,896,517,577,837,648,291,768,192,551,303,354,64,2883,769,551,257,65,0,324]

theorem envBound29274 : H12AffineFastState.Bounded env29274 := by
  intro p hp
  have h : env29274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29273_29274 : H12AffineEnvironment.transform 3 0 env29273 = env29274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env29273 == env29274) = true)

theorem identity29274 : scanCanonicalize (H12AffineFastState.compose env29274 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound29274 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env29275 : List Nat := [2,4,8,0,6,64,128,256,512,321,2048,837,781,65,576,769,260,896,517,577,837,648,261,768,192,513,265,324,64,2883,769,513,257,65,0,324]

theorem envBound29275 : H12AffineFastState.Bounded env29275 := by
  intro p hp
  have h : env29275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29274_29275 : H12AffineEnvironment.transform 4 6 env29274 = env29275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env29274 == env29275) = true)

theorem identity29275 : scanCanonicalize (H12AffineFastState.compose env29275 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound29275 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env29276 : List Nat := [2,4,8,0,6,64,128,256,1,321,2048,324,268,65,65,256,260,385,4,64,324,137,261,257,192,0,265,324,64,2370,256,0,257,65,0,324]

theorem envBound29276 : H12AffineFastState.Bounded env29276 := by
  intro p hp
  have h : env29276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29275_29276 : H12AffineEnvironment.transform 8 1 env29275 = env29276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env29275 == env29276) = true)

theorem identity29276 : scanCanonicalize (H12AffineFastState.compose env29276 (packedSelected [0,1,2,7,8,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 140) := by decide +kernel

theorem selectedBound29276 : packedSelected [0,1,2,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env29277 : List Nat := [2,4,8,0,6,64,128,140,1,205,2048,200,128,65,65,140,136,13,4,64,200,137,137,141,192,0,133,200,64,2254,140,0,141,65,0,200]

theorem envBound29277 : H12AffineFastState.Bounded env29277 := by
  intro p hp
  have h : env29277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29276_29277 : H12AffineEnvironment.transform 7 140 env29276 = env29277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 140 env29276 == env29277) = true)

def env29278 : List Nat := [2,4,8,1,32,64,128,256,512,320,2048,837,780,65,576,768,291,897,517,577,837,648,290,769,192,550,303,354,64,2882,768,550,257,64,1,325]

theorem envBound29278 : H12AffineFastState.Bounded env29278 := by
  intro p hp
  have h : env29278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29273_29278 : H12AffineEnvironment.transform 3 1 env29273 = env29278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env29273 == env29278) = true)

theorem identity29278 : scanCanonicalize (H12AffineFastState.compose env29278 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 355) := by decide +kernel

theorem selectedBound29278 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env29279 : List Nat := [2,4,8,1,32,64,128,256,355,320,2048,38,111,65,291,99,291,226,358,290,38,491,290,98,192,325,303,354,64,2081,99,325,257,64,1,325]

theorem envBound29279 : H12AffineFastState.Bounded env29279 := by
  intro p hp
  have h : env29279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29278_29279 : H12AffineEnvironment.transform 8 355 env29278 = env29279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 355 env29278 == env29279) = true)

theorem identity29279 : scanCanonicalize (H12AffineFastState.compose env29279 (packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS)) = affineNative (2^(10+1) ^^^ 70) := by decide +kernel

theorem selectedBound29279 : packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env29280 : List Nat := [2,4,8,1,32,64,128,256,355,320,70,38,111,65,291,99,291,226,358,290,38,491,290,98,192,325,303,354,64,103,99,325,257,64,1,325]

theorem envBound29280 : H12AffineFastState.Bounded env29280 := by
  intro p hp
  have h : env29280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29279_29280 : H12AffineEnvironment.transform 10 70 env29279 = env29280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 70 env29279 == env29280) = true)

theorem identity29280 : scanCanonicalize (H12AffineFastState.compose env29280 (packedSelected [0,1,2,7,8,10,13,15,17,18] rootPS)) = affineNative (2^(6+1) ^^^ 101) := by decide +kernel

theorem selectedBound29280 : packedSelected [0,1,2,7,8,10,13,15,17,18] rootPS < 2^1333 := by decide +kernel

def env29281 : List Nat := [2,4,8,1,32,64,101,256,355,320,70,38,111,65,291,99,291,7,358,290,38,270,290,98,37,325,303,354,64,103,99,325,257,64,1,325]

theorem envBound29281 : H12AffineFastState.Bounded env29281 := by
  intro p hp
  have h : env29281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29280_29281 : H12AffineEnvironment.transform 6 101 env29280 = env29281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 101 env29280 == env29281) = true)

theorem identity29281 : scanCanonicalize (H12AffineFastState.compose env29281 (packedSelected [1,2,3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 111) := by decide +kernel

theorem selectedBound29281 : packedSelected [1,2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env29282 : List Nat := [2,4,8,1,32,64,101,111,12,47,70,38,111,65,76,99,76,7,9,77,38,97,77,98,37,42,64,13,64,103,99,42,110,64,1,42]

theorem envBound29282 : H12AffineFastState.Bounded env29282 := by
  intro p hp
  have h : env29282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29281_29282 : H12AffineEnvironment.transform 7 111 env29281 = env29282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 111 env29281 == env29282) = true)

theorem identity29282 : scanCanonicalize (H12AffineFastState.compose env29282 (packedSelected [0,1,3,4,5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound29282 : packedSelected [0,1,3,4,5] rootPS < 2^1333 := by decide +kernel

def env29283 : List Nat := [2,4,2,1,32,64,101,101,6,37,70,38,101,65,70,99,70,7,3,71,38,97,71,98,37,32,64,7,64,103,99,32,100,64,1,32]

theorem envBound29283 : H12AffineFastState.Bounded env29283 := by
  intro p hp
  have h : env29283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29282_29283 : H12AffineEnvironment.transform 2 2 env29282 = env29283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env29282 == env29283) = true)

def env29284 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1557,796,1296,577,65536,67443,65665,1877,576,1557,649,66083,66896,192,65830,1150,67363,1297,67650,784,65830,257,1280,1345,341]

theorem envBound29284 : H12AffineFastState.Bounded env29284 := by
  intro p hp
  have h : env29284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29254_29284 : H12AffineEnvironment.transform 11 1557 env29254 = env29284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1557 env29254 == env29284) = true)

def env29285 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,837,796,64,577,65536,66083,65665,517,576,837,649,66083,65536,192,65830,302,66163,65,67650,784,65830,257,80,17,341]

theorem envBound29285 : H12AffineFastState.Bounded env29285 := by
  intro p hp
  have h : env29285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29284_29285 : H12AffineEnvironment.transform 9 336 env29284 = env29285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 336 env29284 == env29285) = true)

theorem identity29285 : scanCanonicalize (H12AffineFastState.compose env29285 (packedSelected [1,8,28] rootPS)) = affineNative (2^(8+1) ^^^ 103) := by decide +kernel

theorem selectedBound29285 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env29286 : List Nat := [2,4,8,16,32,64,128,256,103,336,2048,290,379,64,38,65536,65604,65665,98,39,290,238,65604,65536,192,65830,302,65556,65,67650,375,65830,257,80,17,341]

theorem envBound29286 : H12AffineFastState.Bounded env29286 := by
  intro p hp
  have h : env29286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29285_29286 : H12AffineEnvironment.transform 8 103 env29285 = env29286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 103 env29285 == env29286) = true)

def env29287 : List Nat := [2,4,8,0,32,64,128,256,103,320,2048,290,363,64,38,65536,65604,65665,98,39,290,238,65604,65536,192,65830,302,65540,65,67650,359,65830,257,64,1,325]

theorem envBound29287 : H12AffineFastState.Bounded env29287 := by
  intro p hp
  have h : env29287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29286_29287 : H12AffineEnvironment.transform 3 0 env29286 = env29287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env29286 == env29287) = true)

theorem identity29287 : scanCanonicalize (H12AffineFastState.compose env29287 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 98) := by decide +kernel

theorem selectedBound29287 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env29288 : List Nat := [2,4,8,0,32,64,128,256,103,320,2048,290,363,64,38,98,38,227,98,39,290,238,38,98,192,324,302,102,65,2080,359,324,257,64,1,325]

theorem envBound29288 : H12AffineFastState.Bounded env29288 := by
  intro p hp
  have h : env29288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29287_29288 : H12AffineEnvironment.transform 15 98 env29287 = env29288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 98 env29287 == env29288) = true)

theorem identity29288 : scanCanonicalize (H12AffineFastState.compose env29288 (packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS)) = affineNative (2^(10+1) ^^^ 322) := by decide +kernel

theorem selectedBound29288 : packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env29289 : List Nat := [2,4,8,0,32,64,128,256,103,320,322,290,363,64,38,98,38,227,98,39,290,238,38,98,192,324,302,102,65,354,359,324,257,64,1,325]

theorem envBound29289 : H12AffineFastState.Bounded env29289 := by
  intro p hp
  have h : env29289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29288_29289 : H12AffineEnvironment.transform 10 322 env29288 = env29289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 322 env29288 == env29289) = true)

theorem identity29289 : scanCanonicalize (H12AffineFastState.compose env29289 (packedSelected [0,1,2,7,8,10,13,15,17,18] rootPS)) = affineNative (2^(7+1) ^^^ 225) := by decide +kernel

theorem selectedBound29289 : packedSelected [0,1,2,7,8,10,13,15,17,18] rootPS < 2^1333 := by decide +kernel

def env29290 : List Nat := [2,4,8,0,32,64,128,225,103,161,163,195,138,64,38,98,38,227,98,39,195,238,38,98,192,165,207,102,65,131,134,165,224,64,1,164]

theorem envBound29290 : H12AffineFastState.Bounded env29290 := by
  intro p hp
  have h : env29290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29289_29290 : H12AffineEnvironment.transform 7 225 env29289 = env29290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 225 env29289 == env29290) = true)

theorem identity29290 : scanCanonicalize (H12AffineFastState.compose env29290 (packedSelected [1,2,3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 13) := by decide +kernel

theorem selectedBound29290 : packedSelected [1,2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env29291 : List Nat := [2,4,8,0,32,13,128,172,42,161,163,142,138,13,38,47,38,174,47,39,142,163,38,47,141,165,130,43,12,131,134,165,173,13,1,164]

theorem envBound29291 : H12AffineFastState.Bounded env29291 := by
  intro p hp
  have h : env29291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29290_29291 : H12AffineEnvironment.transform 5 13 env29290 = env29291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 13 env29290 == env29291) = true)

theorem identity29291 : scanCanonicalize (H12AffineFastState.compose env29291 (packedSelected [3,4,7] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound29291 : packedSelected [3,4,7] rootPS < 2^1333 := by decide +kernel

def env29292 : List Nat := [2,4,8,0,7,13,128,139,13,134,132,142,138,13,1,8,1,137,8,0,142,132,1,8,141,130,130,12,12,131,134,130,138,13,1,131]

theorem envBound29292 : H12AffineFastState.Bounded env29292 := by
  intro p hp
  have h : env29292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29291_29292 : H12AffineEnvironment.transform 4 7 env29291 = env29292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env29291 == env29292) = true)

theorem identity29292 : scanCanonicalize (H12AffineFastState.compose env29292 (packedSelected [0,2,4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound29292 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env29293 : List Nat := [2,4,2,0,7,7,128,129,7,134,132,132,128,7,1,2,1,131,2,0,132,132,1,2,135,130,130,6,6,131,134,130,128,7,1,131]

theorem envBound29293 : H12AffineFastState.Bounded env29293 := by
  intro p hp
  have h : env29293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29292_29293 : H12AffineEnvironment.transform 2 2 env29292 = env29293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env29292 == env29293) = true)

theorem identity29293 : scanCanonicalize (H12AffineFastState.compose env29293 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound29293 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29294 : List Nat := [2,4,2,0,7,7,4,5,7,2,0,0,4,7,1,2,1,7,2,0,0,0,1,2,3,6,6,6,6,7,2,6,4,7,1,7]

theorem envBound29294 : H12AffineFastState.Bounded env29294 := by
  intro p hp
  have h : env29294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29293_29294 : H12AffineEnvironment.transform 6 4 env29293 = env29294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env29293 == env29294) = true)

def env29295 : List Nat := [2,4,8,1,32,64,128,256,103,321,2048,290,362,64,38,65536,65604,65665,98,39,290,238,65604,65536,192,65830,302,65541,65,67650,358,65830,257,65,0,324]

theorem envBound29295 : H12AffineFastState.Bounded env29295 := by
  intro p hp
  have h : env29295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29286_29295 : H12AffineEnvironment.transform 3 1 env29286 = env29295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env29286 == env29295) = true)

theorem identity29295 : scanCanonicalize (H12AffineFastState.compose env29295 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 321) := by decide +kernel

theorem selectedBound29295 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env29296 : List Nat := [2,4,8,1,32,64,128,256,103,321,2048,290,362,64,38,321,261,448,98,39,290,238,261,321,192,103,302,324,65,2307,358,103,257,65,0,324]

theorem envBound29296 : H12AffineFastState.Bounded env29296 := by
  intro p hp
  have h : env29296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29295_29296 : H12AffineEnvironment.transform 15 321 env29295 = env29296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 321 env29295 == env29296) = true)

theorem identity29296 : scanCanonicalize (H12AffineFastState.compose env29296 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 38) := by decide +kernel

theorem selectedBound29296 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env29297 : List Nat := [2,4,8,1,32,38,128,256,1,295,2048,290,268,38,38,295,261,422,4,39,290,136,261,295,166,1,302,290,39,2307,256,1,257,39,0,290]

theorem envBound29297 : H12AffineFastState.Bounded env29297 := by
  intro p hp
  have h : env29297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29296_29297 : H12AffineEnvironment.transform 5 38 env29296 = env29297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 38 env29296 == env29297) = true)

theorem identity29297 : scanCanonicalize (H12AffineFastState.compose env29297 (packedSelected [0,1,2,7,8,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 46) := by decide +kernel

theorem selectedBound29297 : packedSelected [0,1,2,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env29298 : List Nat := [2,4,8,1,32,38,46,256,1,295,2048,290,268,38,38,295,261,264,4,39,290,38,261,295,8,1,302,290,39,2307,256,1,257,39,0,290]

theorem envBound29298 : H12AffineFastState.Bounded env29298 := by
  intro p hp
  have h : env29298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29297_29298 : H12AffineEnvironment.transform 6 46 env29297 = env29298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 46 env29297 == env29298) = true)

theorem identity29298 : scanCanonicalize (H12AffineFastState.compose env29298 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 34) := by decide +kernel

theorem selectedBound29298 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env29299 : List Nat := [2,4,8,1,32,38,46,34,1,5,2048,0,46,38,38,5,39,42,4,39,0,38,39,5,8,1,12,0,39,2081,34,1,35,39,0,0]

theorem envBound29299 : H12AffineFastState.Bounded env29299 := by
  intro p hp
  have h : env29299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29298_29299 : H12AffineEnvironment.transform 7 34 env29298 = env29299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 34 env29298 == env29299) = true)

theorem identity29299 : scanCanonicalize (H12AffineFastState.compose env29299 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound29299 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env29300 : List Nat := [2,4,8,1,32,38,46,34,1,5,11,0,46,38,38,5,39,42,4,39,0,38,39,5,8,1,12,0,39,42,34,1,35,39,0,0]

theorem envBound29300 : H12AffineFastState.Bounded env29300 := by
  intro p hp
  have h : env29300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29299_29300 : H12AffineEnvironment.transform 10 11 env29299 = env29300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env29299 == env29300) = true)

theorem identity29300 : scanCanonicalize (H12AffineFastState.compose env29300 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound29300 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29301 : List Nat := [2,4,8,1,10,12,4,8,1,5,11,0,4,12,12,5,13,0,4,13,0,12,13,5,8,1,12,0,13,0,8,1,9,13,0,0]

theorem envBound29301 : H12AffineFastState.Bounded env29301 := by
  intro p hp
  have h : env29301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29300_29301 : H12AffineEnvironment.transform 4 10 env29300 = env29301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env29300 == env29301) = true)

theorem identity29301 : scanCanonicalize (H12AffineFastState.compose env29301 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound29301 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29302 : List Nat := [2,4,1,1,3,5,4,1,1,5,2,0,4,5,5,5,4,0,4,4,0,5,4,5,1,1,5,0,4,0,1,1,0,4,0,0]

theorem envBound29302 : H12AffineFastState.Bounded env29302 := by
  intro p hp
  have h : env29302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29301_29302 : H12AffineEnvironment.transform 2 1 env29301 = env29302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env29301 == env29302) = true)

theorem identity29302 : scanCanonicalize (H12AffineFastState.compose env29302 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound29302 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env29303 : List Nat := [2,3,1,1,3,2,3,1,1,2,2,0,3,2,2,2,3,0,3,3,0,2,3,2,1,1,2,0,3,0,1,1,0,3,0,0]

theorem envBound29303 : H12AffineFastState.Bounded env29303 := by
  intro p hp
  have h : env29303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29302_29303 : H12AffineEnvironment.transform 1 3 env29302 = env29303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env29302 == env29303) = true)

def env29304 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,836,796,65,577,65536,66082,65665,516,576,836,649,66083,65537,192,65830,303,66162,64,67650,784,65830,257,81,16,341]

theorem envBound29304 : H12AffineFastState.Bounded env29304 := by
  intro p hp
  have h : env29304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29284_29304 : H12AffineEnvironment.transform 9 337 env29284 = env29304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 337 env29284 == env29304) = true)

theorem identity29304 : scanCanonicalize (H12AffineFastState.compose env29304 (packedSelected [1,8,28] rootPS)) = affineNative (2^(7+1) ^^^ 35) := by decide +kernel

theorem selectedBound29304 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env29305 : List Nat := [2,4,8,16,32,64,128,35,512,114,2048,615,575,65,577,65536,66082,65665,516,576,615,649,66083,65537,192,65541,12,66162,64,67650,563,65541,34,81,16,118]

theorem envBound29305 : H12AffineFastState.Bounded env29305 := by
  intro p hp
  have h : env29305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29304_29305 : H12AffineEnvironment.transform 7 35 env29304 = env29305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 35 env29304 == env29305) = true)

def env29306 : List Nat := [2,4,8,0,32,64,128,35,512,98,2048,615,559,65,577,65536,66082,65665,516,576,615,649,66083,65537,192,65541,12,66146,64,67650,547,65541,34,65,0,102]

theorem envBound29306 : H12AffineFastState.Bounded env29306 := by
  intro p hp
  have h : env29306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29305_29306 : H12AffineEnvironment.transform 3 0 env29305 = env29306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env29305 == env29306) = true)

theorem identity29306 : scanCanonicalize (H12AffineFastState.compose env29306 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 517) := by decide +kernel

theorem selectedBound29306 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env29307 : List Nat := [2,4,8,0,32,64,128,35,512,98,2048,615,559,65,577,517,39,644,516,576,615,649,38,516,192,512,12,103,64,2631,547,512,34,65,0,102]

theorem envBound29307 : H12AffineFastState.Bounded env29307 := by
  intro p hp
  have h : env29307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29306_29307 : H12AffineEnvironment.transform 15 517 env29306 = env29307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 517 env29306 == env29307) = true)

theorem identity29307 : scanCanonicalize (H12AffineFastState.compose env29307 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound29307 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env29308 : List Nat := [2,4,8,0,32,64,128,35,0,98,2048,103,47,65,65,5,39,132,4,64,103,137,38,4,192,0,12,103,64,2119,35,0,34,65,0,102]

theorem envBound29308 : H12AffineFastState.Bounded env29308 := by
  intro p hp
  have h : env29308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29307_29308 : H12AffineEnvironment.transform 8 0 env29307 = env29308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env29307 == env29308) = true)

theorem identity29308 : scanCanonicalize (H12AffineFastState.compose env29308 (packedSelected [0,1,2,7,8,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 46) := by decide +kernel

theorem selectedBound29308 : packedSelected [0,1,2,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env29309 : List Nat := [2,4,8,0,32,64,46,35,0,98,2048,103,47,65,65,5,39,42,4,64,103,39,38,4,110,0,12,103,64,2119,35,0,34,65,0,102]

theorem envBound29309 : H12AffineFastState.Bounded env29309 := by
  intro p hp
  have h : env29309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29308_29309 : H12AffineEnvironment.transform 6 46 env29308 = env29309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 46 env29308 == env29309) = true)

def env29310 : List Nat := [2,4,8,1,32,64,128,35,512,99,2048,615,558,65,577,65536,66082,65665,516,576,615,649,66083,65537,192,65541,12,66147,64,67650,546,65541,34,64,1,103]

theorem envBound29310 : H12AffineFastState.Bounded env29310 := by
  intro p hp
  have h : env29310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29305_29310 : H12AffineEnvironment.transform 3 1 env29305 = env29310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env29305 == env29310) = true)

theorem identity29310 : scanCanonicalize (H12AffineFastState.compose env29310 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 99) := by decide +kernel

theorem selectedBound29310 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env29311 : List Nat := [2,4,8,1,32,64,128,35,512,99,2048,615,558,65,577,99,577,226,516,576,615,649,576,98,192,102,12,512,64,2081,546,102,34,64,1,103]

theorem envBound29311 : H12AffineFastState.Bounded env29311 := by
  intro p hp
  have h : env29311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29310_29311 : H12AffineEnvironment.transform 15 99 env29310 = env29311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 99 env29310 == env29311) = true)

theorem identity29311 : scanCanonicalize (H12AffineFastState.compose env29311 (packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS)) = affineNative (2^(10+1) ^^^ 519) := by decide +kernel

theorem selectedBound29311 : packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env29312 : List Nat := [2,4,8,1,32,64,128,35,512,99,519,615,558,65,577,99,577,226,516,576,615,649,576,98,192,102,12,512,64,550,546,102,34,64,1,103]

theorem envBound29312 : H12AffineFastState.Bounded env29312 := by
  intro p hp
  have h : env29312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29311_29312 : H12AffineEnvironment.transform 10 519 env29311 = env29312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 519 env29311 == env29312) = true)

theorem identity29312 : scanCanonicalize (H12AffineFastState.compose env29312 (packedSelected [0,1,2,7,8,10,13,15,17,18] rootPS)) = affineNative (2^(8+1) ^^^ 165) := by decide +kernel

theorem selectedBound29312 : packedSelected [0,1,2,7,8,10,13,15,17,18] rootPS < 2^1333 := by decide +kernel

def env29313 : List Nat := [2,4,8,1,32,64,128,35,165,99,162,194,139,65,228,99,228,226,161,229,194,44,229,98,192,102,12,165,64,131,135,102,34,64,1,103]

theorem envBound29313 : H12AffineFastState.Bounded env29313 := by
  intro p hp
  have h : env29313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29312_29313 : H12AffineEnvironment.transform 8 165 env29312 = env29313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 165 env29312 == env29313) = true)

theorem identity29313 : scanCanonicalize (H12AffineFastState.compose env29313 (packedSelected [1,2,3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 78) := by decide +kernel

theorem selectedBound29313 : packedSelected [1,2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env29314 : List Nat := [2,4,8,1,32,64,78,35,107,99,108,12,69,65,42,99,42,44,111,43,12,44,43,98,14,102,12,107,64,77,73,102,34,64,1,103]

theorem envBound29314 : H12AffineFastState.Bounded env29314 := by
  intro p hp
  have h : env29314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29313_29314 : H12AffineEnvironment.transform 6 78 env29313 = env29314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 78 env29313 == env29314) = true)

theorem identity29314 : scanCanonicalize (H12AffineFastState.compose env29314 (packedSelected [1,2,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound29314 : packedSelected [1,2,5,8] rootPS < 2^1333 := by decide +kernel

def env29315 : List Nat := [2,4,8,1,32,32,46,35,11,3,12,12,37,33,42,3,42,44,15,43,12,44,43,2,14,6,12,11,32,45,41,6,34,32,1,7]

theorem envBound29315 : H12AffineFastState.Bounded env29315 := by
  intro p hp
  have h : env29315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29314_29315 : H12AffineEnvironment.transform 5 32 env29314 = env29315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env29314 == env29315) = true)

theorem identity29315 : scanCanonicalize (H12AffineFastState.compose env29315 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound29315 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29316 : List Nat := [2,4,8,1,6,6,8,5,11,3,12,12,3,7,12,3,12,10,15,13,12,10,13,2,14,6,12,11,6,11,15,6,4,6,1,7]

theorem envBound29316 : H12AffineFastState.Bounded env29316 := by
  intro p hp
  have h : env29316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29315_29316 : H12AffineEnvironment.transform 4 6 env29315 = env29316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env29315 == env29316) = true)

theorem identity29316 : scanCanonicalize (H12AffineFastState.compose env29316 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound29316 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29317 : List Nat := [2,4,2,1,6,6,2,5,1,3,6,6,3,7,6,3,6,0,5,7,6,0,7,2,4,6,6,1,6,1,5,6,4,6,1,7]

theorem envBound29317 : H12AffineFastState.Bounded env29317 := by
  intro p hp
  have h : env29317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29316_29317 : H12AffineEnvironment.transform 2 2 env29316 = env29317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env29316 == env29317) = true)

def env29318 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74863,262144,4417,8541,4096,5276,74046,66896,13768,78895,328959,74814,1297,81226,8205,65831,257,1280,1345,5953]

theorem envBound29318 : H12AffineFastState.Bounded env29318 := by
  intro p hp
  have h : env29318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29202_29318 : H12AffineEnvironment.transform 13 1297 env29202 = env29318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env29202 == env29318) = true)

def env29319 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74863,65664,4417,8541,4096,5276,74046,66896,13768,78895,1151,74814,1297,81226,8205,65831,257,1280,1345,5953]

theorem envBound29319 : H12AffineFastState.Bounded env29319 := by
  intro p hp
  have h : env29319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29318_29319 : H12AffineEnvironment.transform 17 65664 env29318 = env29319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env29318 == env29319) = true)

theorem identity29319 : scanCanonicalize (H12AffineFastState.compose env29319 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound29319 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env29320 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1297,8540,65536,74863,65664,321,8541,0,1180,74046,66896,9672,74799,1151,74814,1297,77130,8205,65831,257,1280,1345,1857]

theorem envBound29320 : H12AffineFastState.Bounded env29320 := by
  intro p hp
  have h : env29320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29319_29320 : H12AffineEnvironment.transform 11 0 env29319 = env29320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env29319 == env29320) = true)

def env29321 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,0,8192,81,8540,65536,74031,65664,321,8541,0,476,74046,65552,8328,74095,319,74110,81,75786,8205,65831,257,64,1,513]

theorem envBound29321 : H12AffineFastState.Bounded env29321 := by
  intro p hp
  have h : env29321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29320_29321 : H12AffineEnvironment.transform 9 320 env29320 = env29321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env29320 == env29321) = true)

theorem identity29321 : scanCanonicalize (H12AffineFastState.compose env29321 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound29321 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env29322 : List Nat := [2,4,8,16,32,64,128,69,512,5,2048,0,8192,81,8217,65536,73834,65664,4,8216,0,153,73851,65552,8328,73770,122,73787,81,75786,8205,65634,68,64,1,513]

theorem envBound29322 : H12AffineFastState.Bounded env29322 := by
  intro p hp
  have h : env29322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29321_29322 : H12AffineEnvironment.transform 7 69 env29321 = env29322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env29321 == env29322) = true)

theorem identity29322 : scanCanonicalize (H12AffineFastState.compose env29322 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound29322 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env29323 : List Nat := [2,4,8,16,32,64,128,69,512,5,2048,0,8192,81,8217,115,8217,243,4,8216,0,153,8200,99,8328,8281,122,8264,81,10361,8205,17,68,64,1,513]

theorem envBound29323 : H12AffineFastState.Bounded env29323 := by
  intro p hp
  have h : env29323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29322_29323 : H12AffineEnvironment.transform 15 115 env29322 = env29323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env29322 == env29323) = true)

theorem identity29323 : scanCanonicalize (H12AffineFastState.compose env29323 (packedSelected [3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound29323 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env29324 : List Nat := [2,4,8,0,32,64,128,69,512,5,2048,0,8192,65,8201,99,8201,227,4,8200,0,137,8200,99,8328,8265,106,8264,65,10345,8205,1,68,64,1,513]

theorem envBound29324 : H12AffineFastState.Bounded env29324 := by
  intro p hp
  have h : env29324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29323_29324 : H12AffineEnvironment.transform 3 0 env29323 = env29324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env29323 == env29324) = true)

theorem identity29324 : scanCanonicalize (H12AffineFastState.compose env29324 (packedSelected [2,11,12,13,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 640) := by decide +kernel

theorem selectedBound29324 : packedSelected [2,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env29325 : List Nat := [2,4,8,0,32,64,128,69,512,5,2048,0,640,65,649,99,649,227,4,648,0,137,648,99,520,713,106,712,65,2793,653,1,68,64,1,513]

theorem envBound29325 : H12AffineFastState.Bounded env29325 := by
  intro p hp
  have h : env29325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29324_29325 : H12AffineEnvironment.transform 12 640 env29324 = env29325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 640 env29324 == env29325) = true)

theorem identity29325 : scanCanonicalize (H12AffineFastState.compose env29325 (packedSelected [1,2,3,12] rootPS)) = affineNative (2^(10+1) ^^^ 131) := by decide +kernel

theorem selectedBound29325 : packedSelected [1,2,3,12] rootPS < 2^1333 := by decide +kernel

def env29326 : List Nat := [2,4,8,0,32,64,128,69,512,5,131,0,640,65,649,99,649,227,4,648,0,137,648,99,520,713,106,712,65,618,653,1,68,64,1,513]

theorem envBound29326 : H12AffineFastState.Bounded env29326 := by
  intro p hp
  have h : env29326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29325_29326 : H12AffineEnvironment.transform 10 131 env29325 = env29326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 131 env29325 == env29326) = true)

theorem identity29326 : scanCanonicalize (H12AffineFastState.compose env29326 (packedSelected [1,3,5,13] rootPS)) = affineNative (2^(8+1) ^^^ 133) := by decide +kernel

theorem selectedBound29326 : packedSelected [1,3,5,13] rootPS < 2^1333 := by decide +kernel

def env29327 : List Nat := [2,4,8,0,32,64,128,69,133,5,131,0,5,65,12,99,12,227,4,13,0,137,13,99,141,76,106,77,65,239,8,1,68,64,1,132]

theorem envBound29327 : H12AffineFastState.Bounded env29327 := by
  intro p hp
  have h : env29327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29326_29327 : H12AffineEnvironment.transform 8 133 env29326 = env29327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 133 env29326 == env29327) = true)

theorem identity29327 : scanCanonicalize (H12AffineFastState.compose env29327 (packedSelected [0,2,4,7,9,15] rootPS)) = affineNative (2^(5+1) ^^^ 13) := by decide +kernel

theorem selectedBound29327 : packedSelected [0,2,4,7,9,15] rootPS < 2^1333 := by decide +kernel

def env29328 : List Nat := [2,4,8,0,32,13,128,8,133,5,131,0,5,12,12,46,12,174,4,13,0,137,13,46,141,1,39,0,12,162,8,1,9,13,1,132]

theorem envBound29328 : H12AffineFastState.Bounded env29328 := by
  intro p hp
  have h : env29328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29327_29328 : H12AffineEnvironment.transform 5 13 env29327 = env29328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 13 env29327 == env29328) = true)

theorem identity29328 : scanCanonicalize (H12AffineFastState.compose env29328 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound29328 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env29329 : List Nat := [2,4,8,0,32,13,9,8,12,5,10,0,5,12,12,46,12,39,4,13,0,0,13,46,4,1,39,0,12,43,8,1,9,13,1,13]

theorem envBound29329 : H12AffineFastState.Bounded env29329 := by
  intro p hp
  have h : env29329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29328_29329 : H12AffineEnvironment.transform 6 9 env29328 = env29329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env29328 == env29329) = true)

theorem identity29329 : scanCanonicalize (H12AffineFastState.compose env29329 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound29329 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29330 : List Nat := [2,2,8,0,32,11,9,8,10,3,10,0,3,10,10,40,10,33,2,11,0,0,11,40,2,1,33,0,10,43,8,1,9,11,1,11]

theorem envBound29330 : H12AffineFastState.Bounded env29330 := by
  intro p hp
  have h : env29330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29329_29330 : H12AffineEnvironment.transform 1 2 env29329 = env29330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env29329 == env29330) = true)

theorem identity29330 : scanCanonicalize (H12AffineFastState.compose env29330 (packedSelected [0,2] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound29330 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env29331 : List Nat := [2,2,8,0,3,11,9,8,10,3,10,0,3,10,10,11,10,2,2,11,0,0,11,11,2,1,2,0,10,8,8,1,9,11,1,11]

theorem envBound29331 : H12AffineFastState.Bounded env29331 := by
  intro p hp
  have h : env29331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29330_29331 : H12AffineEnvironment.transform 4 3 env29330 = env29331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env29330 == env29331) = true)

theorem identity29331 : scanCanonicalize (H12AffineFastState.compose env29331 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound29331 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env29332 : List Nat := [0,0,8,0,1,9,9,8,8,1,8,0,1,8,8,9,8,0,0,9,0,0,9,9,0,1,0,0,8,8,8,1,9,9,1,9]

theorem envBound29332 : H12AffineFastState.Bounded env29332 := by
  intro p hp
  have h : env29332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29331_29332 : H12AffineEnvironment.transform 0 0 env29331 = env29332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env29331 == env29332) = true)

theorem identity29332 : scanCanonicalize (H12AffineFastState.compose env29332 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound29332 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env29333 : List Nat := [0,0,0,0,1,1,1,0,0,1,0,0,1,0,0,1,0,0,0,1,0,0,1,1,0,1,0,0,0,0,0,1,1,1,1,1]

theorem envBound29333 : H12AffineFastState.Bounded env29333 := by
  intro p hp
  have h : env29333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29332_29333 : H12AffineEnvironment.transform 2 0 env29332 = env29333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env29332 == env29333) = true)

def env29334 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,0,8192,80,8540,65536,74030,65664,321,8541,0,477,74046,65553,8329,74094,318,74111,80,75787,8205,65831,257,65,0,512]

theorem envBound29334 : H12AffineFastState.Bounded env29334 := by
  intro p hp
  have h : env29334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29320_29334 : H12AffineEnvironment.transform 9 321 env29320 = env29334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env29320 == env29334) = true)

theorem identity29334 : scanCanonicalize (H12AffineFastState.compose env29334 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 8250) := by decide +kernel

theorem selectedBound29334 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env29335 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,0,8192,80,8540,8250,276,8378,321,8541,0,477,260,8235,8329,340,318,325,80,2097,8205,8477,257,65,0,512]

theorem envBound29335 : H12AffineFastState.Bounded env29335 := by
  intro p hp
  have h : env29335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29334_29335 : H12AffineEnvironment.transform 15 8250 env29334 = env29335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8250 env29334 == env29335) = true)

theorem identity29335 : scanCanonicalize (H12AffineFastState.compose env29335 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound29335 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env29336 : List Nat := [2,4,8,16,32,64,128,69,512,4,2048,0,8192,80,8217,8250,81,8378,4,8216,0,152,65,8235,8329,17,123,0,80,2097,8205,8280,68,65,0,512]

theorem envBound29336 : H12AffineFastState.Bounded env29336 := by
  intro p hp
  have h : env29336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29335_29336 : H12AffineEnvironment.transform 7 69 env29335 = env29336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env29335 == env29336) = true)

theorem identity29336 : scanCanonicalize (H12AffineFastState.compose env29336 (packedSelected [0,1,3,5,7,8,10,11,13] rootPS)) = affineNative (2^(12+1) ^^^ 2169) := by decide +kernel

theorem selectedBound29336 : packedSelected [0,1,3,5,7,8,10,11,13] rootPS < 2^1333 := by decide +kernel

def env29337 : List Nat := [2,4,8,16,32,64,128,69,512,4,2048,0,2169,80,2144,2115,81,2243,4,2145,0,152,65,2130,2288,17,123,0,80,2097,2164,2081,68,65,0,512]

theorem envBound29337 : H12AffineFastState.Bounded env29337 := by
  intro p hp
  have h : env29337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29336_29337 : H12AffineEnvironment.transform 12 2169 env29336 = env29337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2169 env29336 == env29337) = true)

theorem identity29337 : scanCanonicalize (H12AffineFastState.compose env29337 (packedSelected [0,2,3,5,7,10,11,12] rootPS)) = affineNative (2^(8+1) ^^^ 185) := by decide +kernel

theorem selectedBound29337 : packedSelected [0,2,3,5,7,10,11,12] rootPS < 2^1333 := by decide +kernel

def env29338 : List Nat := [2,4,8,16,32,64,128,69,185,4,2048,0,2169,80,2144,2115,81,2243,4,2145,0,152,65,2130,2288,17,123,0,80,2097,2164,2081,68,65,0,185]

theorem envBound29338 : H12AffineFastState.Bounded env29338 := by
  intro p hp
  have h : env29338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29337_29338 : H12AffineEnvironment.transform 8 185 env29337 = env29338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 185 env29337 == env29338) = true)

theorem identity29338 : scanCanonicalize (H12AffineFastState.compose env29338 (packedSelected [0,2,5,7,8,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 194) := by decide +kernel

theorem selectedBound29338 : packedSelected [0,2,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env29339 : List Nat := [2,4,8,16,32,64,128,69,185,4,194,0,187,80,162,129,81,1,4,163,0,152,65,144,50,17,123,0,80,243,182,227,68,65,0,185]

theorem envBound29339 : H12AffineFastState.Bounded env29339 := by
  intro p hp
  have h : env29339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29338_29339 : H12AffineEnvironment.transform 10 194 env29338 = env29339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 194 env29338 == env29339) = true)

theorem identity29339 : scanCanonicalize (H12AffineFastState.compose env29339 (packedSelected [0,2,8] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound29339 : packedSelected [0,2,8] rootPS < 2^1333 := by decide +kernel

def env29340 : List Nat := [2,4,8,16,32,64,89,69,96,4,27,0,98,80,123,88,81,1,4,122,0,65,65,73,50,17,123,0,80,42,111,58,68,65,0,96]

theorem envBound29340 : H12AffineFastState.Bounded env29340 := by
  intro p hp
  have h : env29340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29339_29340 : H12AffineEnvironment.transform 6 89 env29339 = env29340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env29339 == env29340) = true)

theorem identity29340 : scanCanonicalize (H12AffineFastState.compose env29340 (packedSelected [2,3,4] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound29340 : packedSelected [2,3,4] rootPS < 2^1333 := by decide +kernel

def env29341 : List Nat := [2,4,8,11,32,64,66,69,96,4,0,0,98,75,96,67,74,1,4,97,0,65,65,73,41,10,96,0,75,42,111,33,68,65,0,96]

theorem envBound29341 : H12AffineFastState.Bounded env29341 := by
  intro p hp
  have h : env29341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29340_29341 : H12AffineEnvironment.transform 3 11 env29340 = env29341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env29340 == env29341) = true)

theorem identity29341 : scanCanonicalize (H12AffineFastState.compose env29341 (packedSelected [0,1] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound29341 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env29342 : List Nat := [2,4,8,11,32,32,34,37,0,4,0,0,2,43,0,35,42,1,4,1,0,33,33,41,41,10,0,0,43,42,15,33,36,33,0,0]

theorem envBound29342 : H12AffineFastState.Bounded env29342 := by
  intro p hp
  have h : env29342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29341_29342 : H12AffineEnvironment.transform 5 32 env29341 = env29342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env29341 == env29342) = true)

theorem identity29342 : scanCanonicalize (H12AffineFastState.compose env29342 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound29342 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29343 : List Nat := [2,4,4,7,32,32,34,37,0,4,0,0,2,39,0,35,38,1,4,1,0,33,33,37,37,6,0,0,39,38,3,33,36,33,0,0]

theorem envBound29343 : H12AffineFastState.Bounded env29343 := by
  intro p hp
  have h : env29343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29342_29343 : H12AffineEnvironment.transform 2 4 env29342 = env29343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env29342 == env29343) = true)

theorem identity29343 : scanCanonicalize (H12AffineFastState.compose env29343 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound29343 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29344 : List Nat := [2,4,4,7,7,7,5,2,0,4,0,0,2,0,0,4,1,1,4,1,0,6,6,2,2,6,0,0,0,1,3,6,3,6,0,0]

theorem envBound29344 : H12AffineFastState.Bounded env29344 := by
  intro p hp
  have h : env29344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29343_29344 : H12AffineEnvironment.transform 4 7 env29343 = env29344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env29343 == env29344) = true)

def env29345 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74863,65665,4417,8541,4096,5276,74046,66896,13768,78895,1150,74814,1297,81226,8205,65831,257,1280,1345,5953]

theorem envBound29345 : H12AffineFastState.Bounded env29345 := by
  intro p hp
  have h : env29345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29318_29345 : H12AffineEnvironment.transform 17 65665 env29318 = env29345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env29318 == env29345) = true)

theorem identity29345 : scanCanonicalize (H12AffineFastState.compose env29345 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound29345 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env29346 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,81,8540,65536,74031,65665,4417,8541,4096,4572,74046,65552,12424,78191,318,74110,81,79882,8205,65831,257,64,1,4609]

theorem envBound29346 : H12AffineFastState.Bounded env29346 := by
  intro p hp
  have h : env29346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29345_29346 : H12AffineEnvironment.transform 9 320 env29345 = env29346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env29345 == env29346) = true)

def env29347 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,852,8192,81,8540,65536,74031,65665,533,8541,852,648,74046,65552,9180,74299,318,74110,81,76638,8205,65831,257,64,1,341]

theorem envBound29347 : H12AffineFastState.Bounded env29347 := by
  intro p hp
  have h : env29347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29346_29347 : H12AffineEnvironment.transform 11 852 env29346 = env29347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 852 env29346 == env29347) = true)

def env29348 : List Nat := [2,4,8,0,32,64,128,256,512,320,2048,836,8192,65,8524,65536,74031,65665,517,8525,836,648,74030,65536,9164,74283,302,74094,65,76622,8205,65831,257,64,1,325]

theorem envBound29348 : H12AffineFastState.Bounded env29348 := by
  intro p hp
  have h : env29348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29347_29348 : H12AffineEnvironment.transform 3 0 env29347 = env29348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env29347 == env29348) = true)

theorem identity29348 : scanCanonicalize (H12AffineFastState.compose env29348 (packedSelected [1,8,28] rootPS)) = affineNative (2^(6+1) ^^^ 111) := by decide +kernel

theorem selectedBound29348 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env29349 : List Nat := [2,4,8,0,32,64,111,256,512,320,2048,836,8192,65,8524,65536,74031,65646,517,8525,836,615,74030,65536,8995,74283,302,74094,65,76622,8205,65831,257,64,1,325]

theorem envBound29349 : H12AffineFastState.Bounded env29349 := by
  intro p hp
  have h : env29349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29348_29349 : H12AffineEnvironment.transform 6 111 env29348 = env29349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 111 env29348 == env29349) = true)

def env29350 : List Nat := [2,4,8,0,32,64,111,256,512,320,2048,836,780,65,576,65536,66083,65646,517,577,836,615,66082,65536,47,65831,302,66146,65,67650,769,65831,257,64,1,325]

theorem envBound29350 : H12AffineFastState.Bounded env29350 := by
  intro p hp
  have h : env29350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29349_29350 : H12AffineEnvironment.transform 12 780 env29349 = env29350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 780 env29349 == env29350) = true)

theorem identity29350 : scanCanonicalize (H12AffineFastState.compose env29350 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 807) := by decide +kernel

theorem selectedBound29350 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env29351 : List Nat := [2,4,8,0,32,64,111,256,512,320,2048,836,780,65,576,807,260,841,517,577,836,615,261,807,47,512,302,325,65,2917,769,512,257,64,1,325]

theorem envBound29351 : H12AffineFastState.Bounded env29351 := by
  intro p hp
  have h : env29351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29350_29351 : H12AffineEnvironment.transform 15 807 env29350 = env29351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 807 env29350 == env29351) = true)

theorem identity29351 : scanCanonicalize (H12AffineFastState.compose env29351 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound29351 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env29352 : List Nat := [2,4,8,0,32,64,111,68,512,4,2048,512,584,65,576,611,64,525,517,577,512,615,65,611,47,512,106,1,65,2593,581,512,69,64,1,1]

theorem envBound29352 : H12AffineFastState.Bounded env29352 := by
  intro p hp
  have h : env29352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29351_29352 : H12AffineEnvironment.transform 7 68 env29351 = env29352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env29351 == env29352) = true)

theorem identity29352 : scanCanonicalize (H12AffineFastState.compose env29352 (packedSelected [5,10] rootPS)) = affineNative (2^(10+1) ^^^ 618) := by decide +kernel

theorem selectedBound29352 : packedSelected [5,10] rootPS < 2^1333 := by decide +kernel

def env29353 : List Nat := [2,4,8,0,32,64,111,68,512,4,618,512,584,65,576,611,64,525,517,577,512,615,65,611,47,512,106,1,65,75,581,512,69,64,1,1]

theorem envBound29353 : H12AffineFastState.Bounded env29353 := by
  intro p hp
  have h : env29353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29352_29353 : H12AffineEnvironment.transform 10 618 env29352 = env29353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 618 env29352 == env29353) = true)

theorem identity29353 : scanCanonicalize (H12AffineFastState.compose env29353 (packedSelected [1,2,3,5,13] rootPS)) = affineNative (2^(5+1) ^^^ 42) := by decide +kernel

theorem selectedBound29353 : packedSelected [1,2,3,5,13] rootPS < 2^1333 := by decide +kernel

def env29354 : List Nat := [2,4,8,0,32,42,5,46,512,4,512,512,546,43,554,521,42,525,517,555,512,525,43,521,47,512,0,1,43,33,559,512,47,42,1,1]

theorem envBound29354 : H12AffineFastState.Bounded env29354 := by
  intro p hp
  have h : env29354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29353_29354 : H12AffineEnvironment.transform 5 42 env29353 = env29354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 42 env29353 == env29354) = true)

theorem identity29354 : scanCanonicalize (H12AffineFastState.compose env29354 (packedSelected [0,2,3,5,7,8] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound29354 : packedSelected [0,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env29355 : List Nat := [2,3,8,0,32,42,2,41,512,3,512,512,546,43,554,521,42,522,514,555,512,522,43,521,40,512,0,1,43,33,552,512,40,42,1,1]

theorem envBound29355 : H12AffineFastState.Bounded env29355 := by
  intro p hp
  have h : env29355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29354_29355 : H12AffineEnvironment.transform 1 3 env29354 = env29355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env29354 == env29355) = true)

theorem identity29355 : scanCanonicalize (H12AffineFastState.compose env29355 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound29355 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29356 : List Nat := [2,3,8,0,11,1,2,2,512,3,512,512,521,0,513,521,1,522,514,512,512,522,0,521,3,512,0,1,0,10,515,512,3,1,1,1]

theorem envBound29356 : H12AffineFastState.Bounded env29356 := by
  intro p hp
  have h : env29356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29355_29356 : H12AffineEnvironment.transform 4 11 env29355 = env29356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env29355 == env29356) = true)

theorem identity29356 : scanCanonicalize (H12AffineFastState.compose env29356 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound29356 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29357 : List Nat := [2,3,8,0,11,1,2,2,1,3,1,1,8,0,0,8,1,11,3,1,1,11,0,8,3,1,0,1,0,10,2,1,3,1,1,1]

theorem envBound29357 : H12AffineFastState.Bounded env29357 := by
  intro p hp
  have h : env29357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29356_29357 : H12AffineEnvironment.transform 8 1 env29356 = env29357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env29356 == env29357) = true)

theorem identity29357 : scanCanonicalize (H12AffineFastState.compose env29357 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound29357 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env29358 : List Nat := [2,3,2,0,1,1,2,2,1,3,1,1,2,0,0,2,1,1,3,1,1,1,0,2,3,1,0,1,0,0,2,1,3,1,1,1]

theorem envBound29358 : H12AffineFastState.Bounded env29358 := by
  intro p hp
  have h : env29358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29357_29358 : H12AffineEnvironment.transform 2 2 env29357 = env29358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env29357 == env29358) = true)

def env29359 : List Nat := [2,4,8,0,32,64,111,256,512,320,2048,836,781,65,577,65536,66082,65646,517,576,836,615,66083,65536,46,65830,302,66147,65,67651,768,65831,257,64,1,325]

theorem envBound29359 : H12AffineFastState.Bounded env29359 := by
  intro p hp
  have h : env29359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29349_29359 : H12AffineEnvironment.transform 12 781 env29349 = env29359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 781 env29349 == env29359) = true)

theorem identity29359 : scanCanonicalize (H12AffineFastState.compose env29359 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 99) := by decide +kernel

theorem selectedBound29359 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

end H12CloudChart2