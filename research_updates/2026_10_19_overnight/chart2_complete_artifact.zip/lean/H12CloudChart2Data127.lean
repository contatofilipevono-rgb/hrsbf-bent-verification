import H12CloudChart2Data126

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity31425 : scanCanonicalize (H12AffineFastState.compose env31425 (packedSelected [0,5,6,8,9,10,13] rootPS)) = affineNative (2^(10+1) ^^^ 1070) := by decide +kernel

theorem selectedBound31425 : packedSelected [0,5,6,8,9,10,13] rootPS < 2^1333 := by decide +kernel

def env31426 : List Nat := [2,4,8,16,32,16,128,173,512,1024,1070,1687,1580,162,1212,1156,1191,1191,1585,1213,1687,1060,1044,1701,1173,1573,49,185,184,184,669,179,173,168,1212,48]

theorem envBound31426 : H12AffineFastState.Bounded env31426 := by
  intro p hp
  have h : env31426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31425_31426 : H12AffineEnvironment.transform 10 1070 env31425 = env31426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1070 env31425 == env31426) = true)

theorem identity31426 : scanCanonicalize (H12AffineFastState.compose env31426 (packedSelected [1,4,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 167) := by decide +kernel

theorem selectedBound31426 : packedSelected [1,4,7,8] rootPS < 2^1333 := by decide +kernel

def env31427 : List Nat := [2,4,8,16,32,16,128,173,512,167,137,560,651,162,27,35,0,0,662,26,560,131,179,514,50,642,49,185,184,184,669,179,173,168,27,48]

theorem envBound31427 : H12AffineFastState.Bounded env31427 := by
  intro p hp
  have h : env31427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31426_31427 : H12AffineEnvironment.transform 9 167 env31426 = env31427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 167 env31426 == env31427) = true)

theorem identity31427 : scanCanonicalize (H12AffineFastState.compose env31427 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound31427 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env31428 : List Nat := [2,4,8,16,32,16,34,15,512,5,43,560,553,0,27,35,0,0,564,26,560,33,17,514,50,544,49,27,26,26,575,17,15,10,27,48]

theorem envBound31428 : H12AffineFastState.Bounded env31428 := by
  intro p hp
  have h : env31428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31427_31428 : H12AffineEnvironment.transform 6 34 env31427 = env31428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env31427 == env31428) = true)

theorem identity31428 : scanCanonicalize (H12AffineFastState.compose env31428 (packedSelected [6] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound31428 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env31429 : List Nat := [2,4,8,16,32,16,34,15,48,5,43,0,25,0,27,35,0,0,4,26,0,33,17,50,50,16,49,27,26,26,15,17,15,10,27,48]

theorem envBound31429 : H12AffineFastState.Bounded env31429 := by
  intro p hp
  have h : env31429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31428_31429 : H12AffineEnvironment.transform 8 48 env31428 = env31429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env31428 == env31429) = true)

theorem identity31429 : scanCanonicalize (H12AffineFastState.compose env31429 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound31429 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env31430 : List Nat := [2,4,8,16,17,16,19,15,1,5,26,0,25,0,27,18,0,0,4,26,0,16,17,3,3,16,0,27,26,26,15,17,15,10,27,1]

theorem envBound31430 : H12AffineFastState.Bounded env31430 := by
  intro p hp
  have h : env31430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31429_31430 : H12AffineEnvironment.transform 4 17 env31429 = env31430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env31429 == env31430) = true)

theorem identity31430 : scanCanonicalize (H12AffineFastState.compose env31430 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound31430 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31431 : List Nat := [2,4,8,11,10,11,8,15,1,5,1,0,2,0,0,9,0,0,4,1,0,11,10,3,3,11,0,0,1,1,15,10,15,10,0,1]

theorem envBound31431 : H12AffineFastState.Bounded env31431 := by
  intro p hp
  have h : env31431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31430_31431 : H12AffineEnvironment.transform 3 11 env31430 = env31431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env31430 == env31431) = true)

theorem identity31431 : scanCanonicalize (H12AffineFastState.compose env31431 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound31431 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31432 : List Nat := [2,2,8,11,10,11,8,9,1,3,1,0,2,0,0,9,0,0,2,1,0,11,10,3,3,11,0,0,1,1,9,10,9,10,0,1]

theorem envBound31432 : H12AffineFastState.Bounded env31432 := by
  intro p hp
  have h : env31432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31431_31432 : H12AffineEnvironment.transform 1 2 env31431 = env31432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env31431 == env31432) = true)

def env31433 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61568,147472,58519,143497,20496,508074,148669,148668,96266,90263,16401,173,148652,1213,135680]

theorem envBound31433 : H12AffineFastState.Bounded env31433 := by
  intro p hp
  have h : env31433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31417_31433 : H12AffineEnvironment.transform 5 17 env31417 = env31433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env31417 == env31433) = true)

theorem identity31433 : scanCanonicalize (H12AffineFastState.compose env31433 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 137352) := by decide +kernel

theorem selectedBound31433 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env31434 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,137352,136193,32769,4096,61568,147472,58519,143497,20496,120866,148669,148668,96266,90263,16401,173,148652,1213,135680]

theorem envBound31434 : H12AffineFastState.Bounded env31434 := by
  intro p hp
  have h : env31434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31433_31434 : H12AffineEnvironment.transform 17 137352 env31433 = env31434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137352 env31433 == env31434) = true)

theorem identity31434 : scanCanonicalize (H12AffineFastState.compose env31434 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(16+1) ^^^ 62492) := by decide +kernel

theorem selectedBound31434 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env31435 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,62492,60564,57373,32769,4096,61568,46092,58519,50325,20496,120866,45217,45216,96266,90263,16401,173,45232,1213,58908]

theorem envBound31435 : H12AffineFastState.Bounded env31435 := by
  intro p hp
  have h : env31435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31434_31435 : H12AffineEnvironment.transform 16 62492 env31434 = env31435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 62492 env31434 == env31435) = true)

theorem identity31435 : scanCanonicalize (H12AffineFastState.compose env31435 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 9350) := by decide +kernel

theorem selectedBound31435 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env31436 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,9350,62492,60564,57373,32769,4096,61568,46092,58519,50325,20496,64676,45217,45216,23692,17425,16401,173,45232,1213,58908]

theorem envBound31436 : H12AffineFastState.Bounded env31436 := by
  intro p hp
  have h : env31436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31435_31436 : H12AffineEnvironment.transform 15 9350 env31435 = env31436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9350 env31435 == env31436) = true)

theorem identity31436 : scanCanonicalize (H12AffineFastState.compose env31436 (packedSelected [0,1,2,4,6,7,8,9,13,18,19,23] rootPS)) = affineNative (2^(14+1) ^^^ 23176) := by decide +kernel

theorem selectedBound31436 : packedSelected [0,1,2,4,6,7,8,9,13,18,19,23] rootPS < 2^1333 := by decide +kernel

def env31437 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,23176,9350,11924,13852,14997,23177,4096,10760,28292,15903,7709,20496,9772,27177,27176,23692,17425,16401,173,27192,1213,15508]

theorem envBound31437 : H12AffineFastState.Bounded env31437 := by
  intro p hp
  have h : env31437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31436_31437 : H12AffineEnvironment.transform 14 23176 env31436 = env31437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 23176 env31436 == env31437) = true)

theorem identity31437 : scanCanonicalize (H12AffineFastState.compose env31437 (packedSelected [0,1,2,4,6,7,8,9,13,17,21,26] rootPS)) = affineNative (2^(12+1) ^^^ 3629) := by decide +kernel

theorem selectedBound31437 : packedSelected [0,1,2,4,6,7,8,9,13,17,21,26] rootPS < 2^1333 := by decide +kernel

def env31438 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,3629,16384,23176,2731,185,6193,5304,23177,4096,1061,16553,4146,7709,20496,2049,17412,17413,23692,17425,16401,173,17429,1213,4793]

theorem envBound31438 : H12AffineFastState.Bounded env31438 := by
  intro p hp
  have h : env31438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31437_31438 : H12AffineEnvironment.transform 12 3629 env31437 = env31438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3629 env31437 == env31438) = true)

theorem identity31438 : scanCanonicalize (H12AffineFastState.compose env31438 (packedSelected [1,2,4,6,7,8,10,11,17] rootPS)) = affineNative (2^(11+1) ^^^ 560) := by decide +kernel

theorem selectedBound31438 : packedSelected [1,2,4,6,7,8,10,11,17] rootPS < 2^1333 := by decide +kernel

def env31439 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,560,3629,16384,18616,2731,185,2561,1672,18617,560,1061,16553,514,3117,16928,2049,17412,17413,20156,17425,16401,173,17429,1213,137]

theorem envBound31439 : H12AffineFastState.Bounded env31439 := by
  intro p hp
  have h : env31439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31438_31439 : H12AffineEnvironment.transform 11 560 env31438 = env31439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 560 env31438 == env31439) = true)

theorem identity31439 : scanCanonicalize (H12AffineFastState.compose env31439 (packedSelected [2,4,5,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 163) := by decide +kernel

theorem selectedBound31439 : packedSelected [2,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env31440 : List Nat := [2,4,8,16,32,17,128,173,512,1024,163,560,1678,16384,16411,520,185,674,1672,16410,560,1061,16553,514,1166,16928,162,17412,17413,17951,17425,16401,173,17429,1213,137]

theorem envBound31440 : H12AffineFastState.Bounded env31440 := by
  intro p hp
  have h : env31440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31439_31440 : H12AffineEnvironment.transform 10 163 env31439 = env31440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 163 env31439 == env31440) = true)

theorem identity31440 : scanCanonicalize (H12AffineFastState.compose env31440 (packedSelected [1,3,4,9,13] rootPS)) = affineNative (2^(9+1) ^^^ 31) := by decide +kernel

theorem selectedBound31440 : packedSelected [1,3,4,9,13] rootPS < 2^1333 := by decide +kernel

def env31441 : List Nat := [2,4,8,16,32,17,128,173,512,31,163,560,657,16384,16411,520,185,674,663,16410,560,58,16553,514,145,16928,162,16411,16410,16896,16398,16401,173,16394,162,137]

theorem envBound31441 : H12AffineFastState.Bounded env31441 := by
  intro p hp
  have h : env31441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31440_31441 : H12AffineEnvironment.transform 9 31 env31440 = env31441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 31 env31440 == env31441) = true)

theorem identity31441 : scanCanonicalize (H12AffineFastState.compose env31441 (packedSelected [0,4,6,7,9,10] rootPS)) = affineNative (2^(13+1) ^^^ 163) := by decide +kernel

theorem selectedBound31441 : packedSelected [0,4,6,7,9,10] rootPS < 2^1333 := by decide +kernel

def env31442 : List Nat := [2,4,8,16,32,17,128,173,512,31,163,560,657,163,184,520,185,674,663,185,560,58,10,514,145,643,162,184,185,675,173,178,173,169,162,137]

theorem envBound31442 : H12AffineFastState.Bounded env31442 := by
  intro p hp
  have h : env31442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31441_31442 : H12AffineEnvironment.transform 13 163 env31441 = env31442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 163 env31441 == env31442) = true)

theorem identity31442 : scanCanonicalize (H12AffineFastState.compose env31442 (packedSelected [1,2,5,6] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound31442 : packedSelected [1,2,5,6] rootPS < 2^1333 := by decide +kernel

def env31443 : List Nat := [2,4,8,16,17,17,128,156,512,31,146,513,657,146,137,520,136,659,663,136,513,11,10,514,145,643,147,137,136,658,156,131,156,152,147,137]

theorem envBound31443 : H12AffineFastState.Bounded env31443 := by
  intro p hp
  have h : env31443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31442_31443 : H12AffineEnvironment.transform 4 17 env31442 = env31443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env31442 == env31443) = true)

theorem identity31443 : scanCanonicalize (H12AffineFastState.compose env31443 (packedSelected [1,2] rootPS)) = affineNative (2^(8+1) ^^^ 132) := by decide +kernel

theorem selectedBound31443 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env31444 : List Nat := [2,4,8,16,17,17,128,156,132,31,146,133,21,146,137,140,136,23,19,136,133,11,10,134,145,7,147,137,136,22,156,131,156,152,147,137]

theorem envBound31444 : H12AffineFastState.Bounded env31444 := by
  intro p hp
  have h : env31444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31443_31444 : H12AffineEnvironment.transform 8 132 env31443 = env31444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 132 env31443 == env31444) = true)

theorem identity31444 : scanCanonicalize (H12AffineFastState.compose env31444 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound31444 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env31445 : List Nat := [2,4,4,16,17,17,128,144,132,19,146,133,21,146,133,128,132,23,19,132,133,7,6,134,145,7,147,133,132,22,144,131,144,148,147,133]

theorem envBound31445 : H12AffineFastState.Bounded env31445 := by
  intro p hp
  have h : env31445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31444_31445 : H12AffineEnvironment.transform 2 4 env31444 = env31445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env31444 == env31445) = true)

theorem identity31445 : scanCanonicalize (H12AffineFastState.compose env31445 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound31445 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31446 : List Nat := [2,4,4,16,17,17,19,3,23,19,1,22,21,1,22,19,23,23,19,23,22,7,6,21,2,7,0,22,23,22,3,16,3,7,0,22]

theorem envBound31446 : H12AffineFastState.Bounded env31446 := by
  intro p hp
  have h : env31446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31445_31446 : H12AffineEnvironment.transform 6 19 env31445 = env31446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env31445 == env31446) = true)

theorem identity31446 : scanCanonicalize (H12AffineFastState.compose env31446 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound31446 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31447 : List Nat := [2,4,4,3,2,2,0,3,4,0,1,5,6,1,5,0,4,4,0,4,5,7,6,6,2,7,0,5,4,5,3,3,3,7,0,5]

theorem envBound31447 : H12AffineFastState.Bounded env31447 := by
  intro p hp
  have h : env31447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31446_31447 : H12AffineEnvironment.transform 3 3 env31446 = env31447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env31446 == env31447) = true)

theorem identity31447 : scanCanonicalize (H12AffineFastState.compose env31447 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound31447 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env31448 : List Nat := [0,4,4,1,0,0,0,1,4,0,1,5,4,1,5,0,4,4,0,4,5,5,4,4,0,5,0,5,4,5,1,1,1,5,0,5]

theorem envBound31448 : H12AffineFastState.Bounded env31448 := by
  intro p hp
  have h : env31448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31447_31448 : H12AffineEnvironment.transform 0 0 env31447 = env31448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env31447 == env31448) = true)

theorem identity31448 : scanCanonicalize (H12AffineFastState.compose env31448 (packedSelected [5] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound31448 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env31449 : List Nat := [0,0,0,1,0,0,0,1,0,0,1,1,0,1,1,0,0,0,0,0,1,1,0,0,0,1,0,1,0,1,1,1,1,1,0,1]

theorem envBound31449 : H12AffineFastState.Bounded env31449 := by
  intro p hp
  have h : env31449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31448_31449 : H12AffineEnvironment.transform 1 0 env31448 = env31449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env31448 == env31449) = true)

def env31450 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147521,16777216,533641,672785,134217728,148801,545088,96347,16876545,16819499,257,545104,151462016,525824]

theorem envBound31450 : H12AffineFastState.Bounded env31450 := by
  intro p hp
  have h : env31450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31206_31450 : H12AffineEnvironment.transform 24 533641 env31206 = env31450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 533641 env31206 == env31450) = true)

def env31451 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147521,16777216,533641,672785,17245632,148801,545088,96347,16876545,16819499,257,545104,1344,525824]

theorem envBound31451 : H12AffineFastState.Bounded env31451 := by
  intro p hp
  have h : env31451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31450_31451 : H12AffineEnvironment.transform 26 17245632 env31450 = env31451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245632 env31450 == env31451) = true)

theorem identity31451 : scanCanonicalize (H12AffineFastState.compose env31451 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 74863) := by decide +kernel

theorem selectedBound31451 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env31452 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,524288,32769,4096,61649,91182,16777216,533641,614526,17039791,90414,545088,96347,16876545,16819499,257,545104,1344,525824]

theorem envBound31452 : H12AffineFastState.Bounded env31452 := by
  intro p hp
  have h : env31452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31451_31452 : H12AffineEnvironment.transform 16 74863 env31451 = env31452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 74863 env31451 == env31452) = true)

def env31453 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,524288,32769,4096,61649,91182,123164,533641,614526,385203,90414,545088,96347,25885,82999,257,545104,1344,525824]

theorem envBound31453 : H12AffineFastState.Bounded env31453 := by
  intro p hp
  have h : env31453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31452_31453 : H12AffineEnvironment.transform 23 123164 env31452 = env31453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 123164 env31452 == env31453) = true)

def env31454 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,21584,32769,4096,61649,91182,123164,28889,78894,385203,90414,1296,96347,25885,82999,257,1280,1344,21072]

theorem envBound31454 : H12AffineFastState.Bounded env31454 := by
  intro p hp
  have h : env31454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31453_31454 : H12AffineEnvironment.transform 18 21584 env31453 = env31454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21584 env31453 == env31454) = true)

theorem identity31454 : scanCanonicalize (H12AffineFastState.compose env31454 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 25676) := by decide +kernel

theorem selectedBound31454 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env31455 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,25676,65536,74863,262144,21584,25677,4096,5277,91182,66896,28889,78894,328959,90414,1296,96347,25885,82999,257,1280,1344,21072]

theorem envBound31455 : H12AffineFastState.Bounded env31455 := by
  intro p hp
  have h : env31455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31454_31455 : H12AffineEnvironment.transform 14 25676 env31454 = env31455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25676 env31454 == env31455) = true)

def env31456 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74863,262144,4416,8541,4096,5277,74046,66896,13769,78894,328959,74814,1296,81227,8205,65831,257,1280,1344,5952]

theorem envBound31456 : H12AffineFastState.Bounded env31456 := by
  intro p hp
  have h : env31456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31455_31456 : H12AffineEnvironment.transform 13 1296 env31455 = env31456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env31455 == env31456) = true)

def env31457 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74863,65664,4416,8541,4096,5277,74046,66896,13769,78894,1151,74814,1296,81227,8205,65831,257,1280,1344,5952]

theorem envBound31457 : H12AffineFastState.Bounded env31457 := by
  intro p hp
  have h : env31457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31456_31457 : H12AffineEnvironment.transform 17 65664 env31456 = env31457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env31456 == env31457) = true)

theorem identity31457 : scanCanonicalize (H12AffineFastState.compose env31457 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound31457 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env31458 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,8192,1296,8540,65536,74863,65664,272,8541,80,1229,74046,66896,9625,74878,1151,74814,1296,77083,8205,65831,257,1280,1344,1808]

theorem envBound31458 : H12AffineFastState.Bounded env31458 := by
  intro p hp
  have h : env31458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31457_31458 : H12AffineEnvironment.transform 11 80 env31457 = env31458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env31457 == env31458) = true)

def env31459 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,80,8192,80,8540,65536,74031,65664,272,8541,80,397,74046,65552,8409,74046,319,74110,80,75867,8205,65831,257,64,0,592]

theorem envBound31459 : H12AffineFastState.Bounded env31459 := by
  intro p hp
  have h : env31459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31458_31459 : H12AffineEnvironment.transform 9 320 env31458 = env31459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env31458 == env31459) = true)

theorem identity31459 : scanCanonicalize (H12AffineFastState.compose env31459 (packedSelected [7,20,27] rootPS)) = affineNative (2^(15+1) ^^^ 8250) := by decide +kernel

theorem selectedBound31459 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env31460 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,80,8192,80,8540,8250,277,8378,272,8541,80,397,260,8234,8409,260,319,324,80,2145,8205,8477,257,64,0,592]

theorem envBound31460 : H12AffineFastState.Bounded env31460 := by
  intro p hp
  have h : env31460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31459_31460 : H12AffineEnvironment.transform 15 8250 env31459 = env31460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8250 env31459 == env31460) = true)

theorem identity31460 : scanCanonicalize (H12AffineFastState.compose env31460 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound31460 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env31461 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,8192,1,8461,8250,277,8378,272,8460,1,397,260,8234,8328,260,319,277,1,2096,8205,8477,257,17,0,513]

theorem envBound31461 : H12AffineFastState.Bounded env31461 := by
  intro p hp
  have h : env31461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31460_31461 : H12AffineEnvironment.transform 5 17 env31460 = env31461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env31460 == env31461) = true)

theorem identity31461 : scanCanonicalize (H12AffineFastState.compose env31461 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 796) := by decide +kernel

theorem selectedBound31461 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env31462 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,796,1,529,806,277,934,272,528,1,397,260,822,916,260,319,277,1,2096,785,513,257,17,0,513]

theorem envBound31462 : H12AffineFastState.Bounded env31462 := by
  intro p hp
  have h : env31462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31461_31462 : H12AffineEnvironment.transform 12 796 env31461 = env31462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 796 env31461 == env31462) = true)

theorem identity31462 : scanCanonicalize (H12AffineFastState.compose env31462 (packedSelected [0,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 277) := by decide +kernel

theorem selectedBound31462 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env31463 : List Nat := [2,4,8,16,32,17,128,256,512,273,277,1,796,1,529,806,277,934,272,528,1,397,260,822,916,260,319,277,1,293,785,513,257,17,0,513]

theorem envBound31463 : H12AffineFastState.Bounded env31463 := by
  intro p hp
  have h : env31463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31462_31463 : H12AffineEnvironment.transform 10 277 env31462 = env31463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 277 env31462 == env31463) = true)

theorem identity31463 : scanCanonicalize (H12AffineFastState.compose env31463 (packedSelected [0,1,2,3,5,8,12] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound31463 : packedSelected [0,1,2,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env31464 : List Nat := [2,4,8,5,32,4,128,256,512,260,256,1,777,1,516,806,256,934,261,517,1,397,260,803,897,260,298,256,1,293,772,513,257,4,0,513]

theorem envBound31464 : H12AffineFastState.Bounded env31464 := by
  intro p hp
  have h : env31464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31463_31464 : H12AffineEnvironment.transform 3 5 env31463 = env31464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env31463 == env31464) = true)

theorem identity31464 : scanCanonicalize (H12AffineFastState.compose env31464 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 0) := by decide +kernel

theorem selectedBound31464 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env31465 : List Nat := [2,4,8,5,32,4,128,0,512,4,0,1,521,1,516,550,0,678,5,517,1,141,4,547,641,4,42,0,1,37,516,513,1,4,0,513]

theorem envBound31465 : H12AffineFastState.Bounded env31465 := by
  intro p hp
  have h : env31465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31464_31465 : H12AffineEnvironment.transform 7 0 env31464 = env31465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 0 env31464 == env31465) = true)

theorem identity31465 : scanCanonicalize (H12AffineFastState.compose env31465 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound31465 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31466 : List Nat := [2,4,8,5,32,4,128,0,0,4,0,1,9,1,4,38,0,166,5,5,1,141,4,35,129,4,42,0,1,37,4,1,1,4,0,1]

theorem envBound31466 : H12AffineFastState.Bounded env31466 := by
  intro p hp
  have h : env31466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31465_31466 : H12AffineEnvironment.transform 8 0 env31465 = env31466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env31465 == env31466) = true)

theorem identity31466 : scanCanonicalize (H12AffineFastState.compose env31466 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 0) := by decide +kernel

theorem selectedBound31466 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env31467 : List Nat := [2,4,8,5,32,4,0,0,0,4,0,1,9,1,4,38,0,38,5,5,1,13,4,35,1,4,42,0,1,37,4,1,1,4,0,1]

theorem envBound31467 : H12AffineFastState.Bounded env31467 := by
  intro p hp
  have h : env31467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31466_31467 : H12AffineEnvironment.transform 6 0 env31466 = env31467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 0 env31466 == env31467) = true)

theorem identity31467 : scanCanonicalize (H12AffineFastState.compose env31467 (packedSelected [0,5] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound31467 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env31468 : List Nat := [2,1,8,0,32,1,0,0,0,1,0,1,9,1,1,35,0,35,0,0,1,8,1,35,1,1,42,0,1,32,1,1,1,1,0,1]

theorem envBound31468 : H12AffineFastState.Bounded env31468 := by
  intro p hp
  have h : env31468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31467_31468 : H12AffineEnvironment.transform 1 1 env31467 = env31468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env31467 == env31468) = true)

theorem identity31468 : scanCanonicalize (H12AffineFastState.compose env31468 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound31468 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31469 : List Nat := [2,1,0,0,32,1,0,0,0,1,0,1,1,1,1,35,0,35,0,0,1,0,1,35,1,1,34,0,1,32,1,1,1,1,0,1]

theorem envBound31469 : H12AffineFastState.Bounded env31469 := by
  intro p hp
  have h : env31469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31468_31469 : H12AffineEnvironment.transform 2 0 env31468 = env31469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env31468 == env31469) = true)

theorem identity31469 : scanCanonicalize (H12AffineFastState.compose env31469 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound31469 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31470 : List Nat := [1,1,0,0,32,1,0,0,0,1,0,1,1,1,1,32,0,32,0,0,1,0,1,32,1,1,33,0,1,32,1,1,1,1,0,1]

theorem envBound31470 : H12AffineFastState.Bounded env31470 := by
  intro p hp
  have h : env31470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31469_31470 : H12AffineEnvironment.transform 0 1 env31469 = env31470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env31469 == env31470) = true)

def env31471 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,80,8192,81,8540,65536,74030,65664,272,8541,80,396,74046,65553,8408,74047,318,74111,81,75866,8205,65831,257,65,1,593]

theorem envBound31471 : H12AffineFastState.Bounded env31471 := by
  intro p hp
  have h : env31471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31458_31471 : H12AffineEnvironment.transform 9 321 env31458 = env31471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env31458 == env31471) = true)

theorem identity31471 : scanCanonicalize (H12AffineFastState.compose env31471 (packedSelected [7,20,27] rootPS)) = affineNative (2^(15+1) ^^^ 8298) := by decide +kernel

theorem selectedBound31471 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env31472 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,80,8192,81,8540,8298,324,8426,272,8541,80,396,340,8315,8408,341,318,277,81,2096,8205,8525,257,65,1,593]

theorem envBound31472 : H12AffineFastState.Bounded env31472 := by
  intro p hp
  have h : env31472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31471_31472 : H12AffineEnvironment.transform 15 8298 env31471 = env31472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8298 env31471 == env31472) = true)

theorem identity31472 : scanCanonicalize (H12AffineFastState.compose env31472 (packedSelected [0,1,4,7,8,9,16,19,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound31472 : packedSelected [0,1,4,7,8,9,16,19,20] rootPS < 2^1333 := by decide +kernel

def env31473 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,1,8192,0,8461,8251,277,8379,272,8460,1,396,261,8234,8329,260,318,277,0,2096,8205,8476,257,16,1,512]

theorem envBound31473 : H12AffineFastState.Bounded env31473 := by
  intro p hp
  have h : env31473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31472_31473 : H12AffineEnvironment.transform 5 17 env31472 = env31473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env31472 == env31473) = true)

theorem identity31473 : scanCanonicalize (H12AffineFastState.compose env31473 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 2088) := by decide +kernel

theorem selectedBound31473 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env31474 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,1,2088,0,2341,2067,277,2195,272,2340,1,396,261,2050,2209,260,318,277,0,2096,2085,2356,257,16,1,512]

theorem envBound31474 : H12AffineFastState.Bounded env31474 := by
  intro p hp
  have h : env31474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31473_31474 : H12AffineEnvironment.transform 12 2088 env31473 = env31474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2088 env31473 == env31474) = true)

theorem identity31474 : scanCanonicalize (H12AffineFastState.compose env31474 (packedSelected [0,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 438) := by decide +kernel

theorem selectedBound31474 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env31475 : List Nat := [2,4,8,16,32,17,128,256,512,272,438,1,414,0,147,421,277,293,272,146,1,396,261,436,279,260,318,277,0,390,403,130,257,16,1,512]

theorem envBound31475 : H12AffineFastState.Bounded env31475 := by
  intro p hp
  have h : env31475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31474_31475 : H12AffineEnvironment.transform 10 438 env31474 = env31475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 438 env31474 == env31475) = true)

theorem identity31475 : scanCanonicalize (H12AffineFastState.compose env31475 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(7+1) ^^^ 157) := by decide +kernel

theorem selectedBound31475 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env31476 : List Nat := [2,4,8,16,32,17,128,157,512,141,43,1,3,0,147,56,136,184,141,146,1,17,152,41,138,153,163,136,0,27,14,130,156,16,1,512]

theorem envBound31476 : H12AffineFastState.Bounded env31476 := by
  intro p hp
  have h : env31476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31475_31476 : H12AffineEnvironment.transform 7 157 env31475 = env31476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 157 env31475 == env31476) = true)

theorem identity31476 : scanCanonicalize (H12AffineFastState.compose env31476 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound31476 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env31477 : List Nat := [2,4,8,16,32,17,35,62,512,46,43,1,3,0,48,56,43,27,46,49,1,17,59,41,41,58,0,43,0,27,14,33,63,16,1,512]

theorem envBound31477 : H12AffineFastState.Bounded env31477 := by
  intro p hp
  have h : env31477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31476_31477 : H12AffineEnvironment.transform 6 35 env31476 = env31477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env31476 == env31477) = true)

theorem identity31477 : scanCanonicalize (H12AffineFastState.compose env31477 (packedSelected [3,5] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound31477 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env31478 : List Nat := [2,4,8,16,32,17,35,62,0,46,43,1,3,0,48,56,43,27,46,49,1,17,59,41,41,58,0,43,0,27,14,33,63,16,1,0]

theorem envBound31478 : H12AffineFastState.Bounded env31478 := by
  intro p hp
  have h : env31478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31477_31478 : H12AffineEnvironment.transform 8 0 env31477 = env31478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env31477 == env31478) = true)

theorem identity31478 : scanCanonicalize (H12AffineFastState.compose env31478 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound31478 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env31479 : List Nat := [2,4,8,16,11,17,8,21,0,5,0,1,3,0,27,19,0,27,5,26,1,17,16,2,2,17,0,0,0,27,14,10,20,16,1,0]

theorem envBound31479 : H12AffineFastState.Bounded env31479 := by
  intro p hp
  have h : env31479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31478_31479 : H12AffineEnvironment.transform 4 11 env31478 = env31479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env31478 == env31479) = true)

def env31480 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74863,65665,4416,8541,4096,5277,74046,66896,13769,78894,1150,74814,1296,81227,8205,65831,257,1280,1344,5952]

theorem envBound31480 : H12AffineFastState.Bounded env31480 := by
  intro p hp
  have h : env31480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31456_31480 : H12AffineEnvironment.transform 17 65665 env31456 = env31480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env31456 == env31480) = true)

theorem identity31480 : scanCanonicalize (H12AffineFastState.compose env31480 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound31480 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env31481 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,8192,1,8540,65536,74110,65665,4416,8541,4096,4492,74046,65601,12504,78143,367,74031,1,79962,8205,65831,257,17,81,4689]

theorem envBound31481 : H12AffineFastState.Bounded env31481 := by
  intro p hp
  have h : env31481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31480_31481 : H12AffineEnvironment.transform 9 273 env31480 = env31481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env31480 == env31481) = true)

def env31482 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,772,8192,1,8540,65536,74110,65665,580,8541,772,648,74046,65601,9180,74299,367,74031,1,76638,8205,65831,257,17,81,341]

theorem envBound31482 : H12AffineFastState.Bounded env31482 := by
  intro p hp
  have h : env31482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31481_31482 : H12AffineEnvironment.transform 11 772 env31481 = env31482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 772 env31481 == env31482) = true)

def env31483 : List Nat := [2,4,8,16,32,0,128,256,512,273,2048,772,8192,1,8476,65536,74046,65665,516,8477,772,648,74046,65537,9116,74299,303,74031,1,76574,8205,65831,257,17,17,277]

theorem envBound31483 : H12AffineFastState.Bounded env31483 := by
  intro p hp
  have h : env31483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31482_31483 : H12AffineEnvironment.transform 5 0 env31482 = env31483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env31482 == env31483) = true)

theorem identity31483 : scanCanonicalize (H12AffineFastState.compose env31483 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 8836) := by decide +kernel

theorem selectedBound31483 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env31484 : List Nat := [2,4,8,16,32,0,128,256,512,273,2048,772,8192,1,8476,8836,954,8709,516,8477,772,648,954,8837,9116,191,303,939,1,2458,8205,9123,257,17,17,277]

theorem envBound31484 : H12AffineFastState.Bounded env31484 := by
  intro p hp
  have h : env31484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31483_31484 : H12AffineEnvironment.transform 15 8836 env31483 = env31484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8836 env31483 == env31484) = true)

def env31485 : List Nat := [2,4,8,16,32,0,128,256,512,273,132,772,8192,1,8476,8836,954,8709,516,8477,772,648,954,8837,9116,191,303,939,1,286,8205,9123,257,17,17,277]

theorem envBound31485 : H12AffineFastState.Bounded env31485 := by
  intro p hp
  have h : env31485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31484_31485 : H12AffineEnvironment.transform 10 132 env31484 = env31485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 132 env31484 == env31485) = true)

def env31486 : List Nat := [2,4,8,16,32,0,128,256,260,273,132,0,8192,1,8476,8576,190,8449,256,8477,0,396,190,8577,8344,191,303,175,1,286,8205,8359,257,17,17,277]

theorem envBound31486 : H12AffineFastState.Bounded env31486 := by
  intro p hp
  have h : env31486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31485_31486 : H12AffineEnvironment.transform 8 260 env31485 = env31486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env31485 == env31486) = true)

theorem identity31486 : scanCanonicalize (H12AffineFastState.compose env31486 (packedSelected [0,3,4,5,7,9,10,12,15,16,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 187) := by decide +kernel

theorem selectedBound31486 : packedSelected [0,3,4,5,7,9,10,12,15,16,20,21] rootPS < 2^1333 := by decide +kernel

def env31487 : List Nat := [2,4,8,16,32,0,128,187,191,170,132,0,8192,1,8359,8251,190,8378,187,8358,0,55,190,8250,8344,191,148,175,1,165,8205,8359,186,17,17,174]

theorem envBound31487 : H12AffineFastState.Bounded env31487 := by
  intro p hp
  have h : env31487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31486_31487 : H12AffineEnvironment.transform 7 187 env31486 = env31487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 187 env31486 == env31487) = true)

theorem identity31487 : scanCanonicalize (H12AffineFastState.compose env31487 (packedSelected [5,8,10,11,12,13,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 20) := by decide +kernel

theorem selectedBound31487 : packedSelected [5,8,10,11,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env31488 : List Nat := [2,4,8,16,32,0,128,187,191,170,132,0,20,1,179,47,190,174,187,178,0,55,190,46,140,191,148,175,1,165,25,179,186,17,17,174]

theorem envBound31488 : H12AffineFastState.Bounded env31488 := by
  intro p hp
  have h : env31488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31487_31488 : H12AffineEnvironment.transform 12 20 env31487 = env31488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 20 env31487 == env31488) = true)

theorem identity31488 : scanCanonicalize (H12AffineFastState.compose env31488 (packedSelected [1,4,5,7,8,11,12] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound31488 : packedSelected [1,4,5,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env31489 : List Nat := [2,4,8,16,11,0,128,144,148,129,132,0,20,1,152,4,149,133,144,153,0,28,149,5,140,148,148,132,1,142,25,152,145,17,17,133]

theorem envBound31489 : H12AffineFastState.Bounded env31489 := by
  intro p hp
  have h : env31489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31488_31489 : H12AffineEnvironment.transform 4 11 env31488 = env31489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env31488 == env31489) = true)

theorem identity31489 : scanCanonicalize (H12AffineFastState.compose env31489 (packedSelected [2,3,8] rootPS)) = affineNative (2^(6+1) ^^^ 21) := by decide +kernel

theorem selectedBound31489 : packedSelected [2,3,8] rootPS < 2^1333 := by decide +kernel

def env31490 : List Nat := [2,4,8,16,11,0,21,5,1,20,17,0,20,1,13,4,0,16,5,12,0,28,0,5,25,1,1,17,1,27,25,13,4,17,17,16]

theorem envBound31490 : H12AffineFastState.Bounded env31490 := by
  intro p hp
  have h : env31490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31489_31490 : H12AffineEnvironment.transform 6 21 env31489 = env31490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 21 env31489 == env31490) = true)

theorem identity31490 : scanCanonicalize (H12AffineFastState.compose env31490 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound31490 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env31491 : List Nat := [2,4,8,0,11,0,5,5,1,4,1,0,4,1,13,4,0,0,5,12,0,12,0,5,9,1,1,1,1,11,9,13,4,1,1,0]

theorem envBound31491 : H12AffineFastState.Bounded env31491 := by
  intro p hp
  have h : env31491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31490_31491 : H12AffineEnvironment.transform 3 0 env31490 = env31491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env31490 == env31491) = true)

theorem identity31491 : scanCanonicalize (H12AffineFastState.compose env31491 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound31491 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31492 : List Nat := [0,4,8,0,9,0,5,5,1,4,1,0,4,1,13,4,0,0,5,12,0,12,0,5,9,1,1,1,1,9,9,13,4,1,1,0]

theorem envBound31492 : H12AffineFastState.Bounded env31492 := by
  intro p hp
  have h : env31492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31491_31492 : H12AffineEnvironment.transform 0 0 env31491 = env31492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env31491 == env31492) = true)

theorem identity31492 : scanCanonicalize (H12AffineFastState.compose env31492 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound31492 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31493 : List Nat := [0,4,1,0,0,0,5,5,1,4,1,0,4,1,4,4,0,0,5,5,0,5,0,5,0,1,1,1,1,0,0,4,4,1,1,0]

theorem envBound31493 : H12AffineFastState.Bounded env31493 := by
  intro p hp
  have h : env31493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31492_31493 : H12AffineEnvironment.transform 2 1 env31492 = env31493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env31492 == env31493) = true)

theorem identity31493 : scanCanonicalize (H12AffineFastState.compose env31493 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound31493 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env31494 : List Nat := [0,1,1,0,0,0,0,0,1,1,1,0,1,1,1,1,0,0,0,0,0,0,0,0,0,1,1,1,1,0,0,1,1,1,1,0]

theorem envBound31494 : H12AffineFastState.Bounded env31494 := by
  intro p hp
  have h : env31494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31493_31494 : H12AffineEnvironment.transform 1 1 env31493 = env31494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env31493 == env31494) = true)

def env31495 : List Nat := [2,4,8,16,32,0,128,256,261,273,132,1,8192,1,8476,8577,191,8448,257,8477,1,397,191,8576,8345,191,303,174,1,286,8205,8358,257,17,17,277]

theorem envBound31495 : H12AffineFastState.Bounded env31495 := by
  intro p hp
  have h : env31495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31485_31495 : H12AffineEnvironment.transform 8 261 env31485 = env31495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env31485 == env31495) = true)

theorem identity31495 : scanCanonicalize (H12AffineFastState.compose env31495 (packedSelected [0,3,4,5,7,9,10,12,15,16,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 188) := by decide +kernel

theorem selectedBound31495 : packedSelected [0,3,4,5,7,9,10,12,15,16,20,21] rootPS < 2^1333 := by decide +kernel

def env31496 : List Nat := [2,4,8,16,32,0,128,188,185,173,132,1,8192,1,8352,8253,191,8380,189,8353,1,49,191,8252,8345,191,147,174,1,162,8205,8358,189,17,17,169]

theorem envBound31496 : H12AffineFastState.Bounded env31496 := by
  intro p hp
  have h : env31496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31495_31496 : H12AffineEnvironment.transform 7 188 env31495 = env31496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 188 env31495 == env31496) = true)

theorem identity31496 : scanCanonicalize (H12AffineFastState.compose env31496 (packedSelected [11,12,13,15,16] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound31496 : packedSelected [11,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env31497 : List Nat := [2,4,8,16,11,0,128,151,146,134,132,1,8192,1,8331,8214,148,8343,150,8330,1,26,148,8215,8345,148,147,133,1,137,8205,8333,150,17,17,130]

theorem envBound31497 : H12AffineFastState.Bounded env31497 := by
  intro p hp
  have h : env31497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31496_31497 : H12AffineEnvironment.transform 4 11 env31496 = env31497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env31496 == env31497) = true)

theorem identity31497 : scanCanonicalize (H12AffineFastState.compose env31497 (packedSelected [2,3,8] rootPS)) = affineNative (2^(12+1) ^^^ 15) := by decide +kernel

theorem selectedBound31497 : packedSelected [2,3,8] rootPS < 2^1333 := by decide +kernel

def env31498 : List Nat := [2,4,8,16,11,0,128,151,146,134,132,1,15,1,132,25,148,152,150,133,1,26,148,24,150,148,147,133,1,137,2,130,150,17,17,130]

theorem envBound31498 : H12AffineFastState.Bounded env31498 := by
  intro p hp
  have h : env31498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31497_31498 : H12AffineEnvironment.transform 12 15 env31497 = env31498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 15 env31497 == env31498) = true)

theorem identity31498 : scanCanonicalize (H12AffineFastState.compose env31498 (packedSelected [0,2,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound31498 : packedSelected [0,2,4,5] rootPS < 2^1333 := by decide +kernel

def env31499 : List Nat := [2,4,8,16,11,0,2,21,16,4,6,1,15,1,6,25,22,26,20,7,1,26,22,24,20,22,17,7,1,11,2,0,20,17,17,0]

theorem envBound31499 : H12AffineFastState.Bounded env31499 := by
  intro p hp
  have h : env31499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31498_31499 : H12AffineEnvironment.transform 6 2 env31498 = env31499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env31498 == env31499) = true)

theorem identity31499 : scanCanonicalize (H12AffineFastState.compose env31499 (packedSelected [1,2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound31499 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env31500 : List Nat := [2,4,8,10,11,0,2,15,10,4,6,1,15,1,6,3,12,0,14,7,1,0,12,2,14,12,11,7,1,11,2,0,14,11,11,0]

theorem envBound31500 : H12AffineFastState.Bounded env31500 := by
  intro p hp
  have h : env31500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31499_31500 : H12AffineEnvironment.transform 3 10 env31499 = env31500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env31499 == env31500) = true)

theorem identity31500 : scanCanonicalize (H12AffineFastState.compose env31500 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound31500 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env31501 : List Nat := [2,4,2,0,1,0,2,5,0,4,6,1,5,1,6,3,6,0,4,7,1,0,6,2,4,6,1,7,1,1,2,0,4,1,1,0]

theorem envBound31501 : H12AffineFastState.Bounded env31501 := by
  intro p hp
  have h : env31501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31500_31501 : H12AffineEnvironment.transform 2 2 env31500 = env31501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env31500 == env31501) = true)

def env31502 : List Nat := [2,4,8,16,32,0,128,256,512,273,133,772,8192,1,8476,8836,954,8709,516,8477,772,648,954,8837,9116,191,303,939,1,287,8205,9123,257,17,17,277]

theorem envBound31502 : H12AffineFastState.Bounded env31502 := by
  intro p hp
  have h : env31502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31484_31502 : H12AffineEnvironment.transform 10 133 env31484 = env31502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 133 env31484 == env31502) = true)

def env31503 : List Nat := [2,4,8,16,32,0,128,256,260,273,133,0,8192,1,8476,8576,190,8449,256,8477,0,396,190,8577,8344,191,303,175,1,287,8205,8359,257,17,17,277]

theorem envBound31503 : H12AffineFastState.Bounded env31503 := by
  intro p hp
  have h : env31503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31502_31503 : H12AffineEnvironment.transform 8 260 env31502 = env31503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env31502 == env31503) = true)

theorem identity31503 : scanCanonicalize (H12AffineFastState.compose env31503 (packedSelected [0,3,4,5,7,9,10,12,15,16,20,21] rootPS)) = affineNative (2^(12+1) ^^^ 284) := by decide +kernel

theorem selectedBound31503 : packedSelected [0,3,4,5,7,9,10,12,15,16,20,21] rootPS < 2^1333 := by decide +kernel

def env31504 : List Nat := [2,4,8,16,32,0,128,256,260,273,133,0,284,1,0,156,190,29,256,1,0,396,190,157,388,191,303,175,1,287,273,443,257,17,17,277]

theorem envBound31504 : H12AffineFastState.Bounded env31504 := by
  intro p hp
  have h : env31504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31503_31504 : H12AffineEnvironment.transform 12 284 env31503 = env31504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 284 env31503 == env31504) = true)

theorem identity31504 : scanCanonicalize (H12AffineFastState.compose env31504 (packedSelected [4,9,12,13,15,16] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound31504 : packedSelected [4,9,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env31505 : List Nat := [2,4,8,1,32,0,128,256,260,256,133,0,269,1,0,141,175,12,256,1,0,396,175,140,388,174,303,175,1,270,256,426,257,0,0,260]

theorem envBound31505 : H12AffineFastState.Bounded env31505 := by
  intro p hp
  have h : env31505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31504_31505 : H12AffineEnvironment.transform 3 1 env31504 = env31505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env31504 == env31505) = true)

theorem identity31505 : scanCanonicalize (H12AffineFastState.compose env31505 (packedSelected [1,2,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 46) := by decide +kernel

theorem selectedBound31505 : packedSelected [1,2,5,8] rootPS < 2^1333 := by decide +kernel

def env31506 : List Nat := [2,4,8,1,32,0,46,256,260,256,43,0,269,1,0,35,1,12,256,1,0,290,1,34,298,0,303,1,1,270,256,260,257,0,0,260]

theorem envBound31506 : H12AffineFastState.Bounded env31506 := by
  intro p hp
  have h : env31506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31505_31506 : H12AffineEnvironment.transform 6 46 env31505 = env31506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 46 env31505 == env31506) = true)

theorem identity31506 : scanCanonicalize (H12AffineFastState.compose env31506 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound31506 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env31507 : List Nat := [2,4,8,1,6,0,8,256,260,256,13,0,269,1,0,5,1,12,256,1,0,260,1,4,268,0,265,1,1,270,256,260,257,0,0,260]

theorem envBound31507 : H12AffineFastState.Bounded env31507 := by
  intro p hp
  have h : env31507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31506_31507 : H12AffineEnvironment.transform 4 6 env31506 = env31507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env31506 == env31507) = true)

theorem identity31507 : scanCanonicalize (H12AffineFastState.compose env31507 (packedSelected [1,2] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound31507 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env31508 : List Nat := [2,4,5,1,6,0,5,256,260,256,0,0,256,1,0,5,1,1,256,1,0,260,1,4,257,0,260,1,1,259,256,260,257,0,0,260]

theorem envBound31508 : H12AffineFastState.Bounded env31508 := by
  intro p hp
  have h : env31508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31507_31508 : H12AffineEnvironment.transform 2 5 env31507 = env31508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env31507 == env31508) = true)

theorem identity31508 : scanCanonicalize (H12AffineFastState.compose env31508 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound31508 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31509 : List Nat := [2,4,5,1,6,0,5,4,0,4,0,0,4,1,0,5,1,1,4,1,0,0,1,4,5,0,0,1,1,7,4,0,5,0,0,0]

theorem envBound31509 : H12AffineFastState.Bounded env31509 := by
  intro p hp
  have h : env31509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31508_31509 : H12AffineEnvironment.transform 7 4 env31508 = env31509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env31508 == env31509) = true)

theorem identity31509 : scanCanonicalize (H12AffineFastState.compose env31509 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound31509 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env31510 : List Nat := [2,3,2,1,1,0,2,3,0,3,0,0,3,1,0,2,1,1,3,1,0,0,1,3,2,0,0,1,1,0,3,0,2,0,0,0]

theorem envBound31510 : H12AffineFastState.Bounded env31510 := by
  intro p hp
  have h : env31510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31509_31510 : H12AffineEnvironment.transform 1 3 env31509 = env31510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env31509 == env31510) = true)

def env31511 : List Nat := [2,4,8,16,32,0,128,256,261,273,133,1,8192,1,8476,8577,191,8448,257,8477,1,397,191,8576,8345,191,303,174,1,287,8205,8358,257,17,17,277]

theorem envBound31511 : H12AffineFastState.Bounded env31511 := by
  intro p hp
  have h : env31511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31502_31511 : H12AffineEnvironment.transform 8 261 env31502 = env31511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env31502 == env31511) = true)

theorem identity31511 : scanCanonicalize (H12AffineFastState.compose env31511 (packedSelected [0,3,4,5,7,9,10,12,15,16,20,21] rootPS)) = affineNative (2^(12+1) ^^^ 282) := by decide +kernel

theorem selectedBound31511 : packedSelected [0,3,4,5,7,9,10,12,15,16,20,21] rootPS < 2^1333 := by decide +kernel

def env31512 : List Nat := [2,4,8,16,32,0,128,256,261,273,133,1,282,1,6,155,191,26,257,7,1,397,191,154,387,191,303,174,1,287,279,444,257,17,17,277]

theorem envBound31512 : H12AffineFastState.Bounded env31512 := by
  intro p hp
  have h : env31512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31511_31512 : H12AffineEnvironment.transform 12 282 env31511 = env31512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 282 env31511 == env31512) = true)

theorem identity31512 : scanCanonicalize (H12AffineFastState.compose env31512 (packedSelected [5,8,10,11,12,13,15,16] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound31512 : packedSelected [5,8,10,11,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env31513 : List Nat := [2,4,8,16,26,0,128,256,261,273,133,1,282,1,6,155,133,26,257,7,1,397,133,154,387,133,277,148,1,287,279,390,257,17,17,277]

theorem envBound31513 : H12AffineFastState.Bounded env31513 := by
  intro p hp
  have h : env31513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31512_31513 : H12AffineEnvironment.transform 4 26 env31512 = env31513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env31512 == env31513) = true)

theorem identity31513 : scanCanonicalize (H12AffineFastState.compose env31513 (packedSelected [1,2,4,9,10,11] rootPS)) = affineNative (2^(7+1) ^^^ 150) := by decide +kernel

theorem selectedBound31513 : packedSelected [1,2,4,9,10,11] rootPS < 2^1333 := by decide +kernel

def env31514 : List Nat := [2,4,8,16,26,0,128,150,147,135,133,1,140,1,6,155,133,26,151,7,1,27,133,154,21,133,131,148,1,137,129,16,151,17,17,131]

theorem envBound31514 : H12AffineFastState.Bounded env31514 := by
  intro p hp
  have h : env31514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31513_31514 : H12AffineEnvironment.transform 7 150 env31513 = env31514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 150 env31513 == env31514) = true)

theorem identity31514 : scanCanonicalize (H12AffineFastState.compose env31514 (packedSelected [3,5] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound31514 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env31515 : List Nat := [2,4,8,16,26,0,5,19,22,2,0,1,9,1,6,30,0,26,18,7,1,27,0,31,21,0,6,17,1,12,4,16,18,17,17,6]

theorem envBound31515 : H12AffineFastState.Bounded env31515 := by
  intro p hp
  have h : env31515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31514_31515 : H12AffineEnvironment.transform 6 5 env31514 = env31515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env31514 == env31515) = true)

def env31516 : List Nat := [2,4,8,16,32,1,128,256,512,273,2048,772,8192,1,8477,65536,74047,65665,517,8476,772,648,74046,65536,9117,74299,302,74031,1,76575,8205,65831,257,17,16,276]

theorem envBound31516 : H12AffineFastState.Bounded env31516 := by
  intro p hp
  have h : env31516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31482_31516 : H12AffineEnvironment.transform 5 1 env31482 = env31516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env31482 == env31516) = true)

theorem identity31516 : scanCanonicalize (H12AffineFastState.compose env31516 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 668) := by decide +kernel

theorem selectedBound31516 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env31517 : List Nat := [2,4,8,16,32,1,128,256,512,273,2048,772,8192,1,8477,668,9123,541,517,8476,772,648,9122,668,9117,8359,302,9139,1,10627,8205,955,257,17,16,276]

theorem envBound31517 : H12AffineFastState.Bounded env31517 := by
  intro p hp
  have h : env31517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31516_31517 : H12AffineEnvironment.transform 15 668 env31516 = env31517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 668 env31516 == env31517) = true)

def env31518 : List Nat := [2,4,8,16,32,1,128,256,512,273,2048,772,24,1,261,668,955,541,517,260,772,648,954,668,901,191,302,939,1,2459,21,955,257,17,16,276]

theorem envBound31518 : H12AffineFastState.Bounded env31518 := by
  intro p hp
  have h : env31518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31517_31518 : H12AffineEnvironment.transform 12 24 env31517 = env31518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env31517 == env31518) = true)

theorem identity31518 : scanCanonicalize (H12AffineFastState.compose env31518 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 186) := by decide +kernel

theorem selectedBound31518 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env31519 : List Nat := [2,4,8,16,32,1,128,186,512,171,2048,702,24,1,191,668,513,541,517,190,702,648,512,668,575,191,148,529,1,2081,21,513,187,17,16,174]

theorem envBound31519 : H12AffineFastState.Bounded env31519 := by
  intro p hp
  have h : env31519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31518_31519 : H12AffineEnvironment.transform 7 186 env31518 = env31519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 186 env31518 == env31519) = true)

theorem identity31519 : scanCanonicalize (H12AffineFastState.compose env31519 (packedSelected [0,1,2,3,7,10,12,17,20] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound31519 : packedSelected [0,1,2,3,7,10,12,17,20] rootPS < 2^1333 := by decide +kernel

def env31520 : List Nat := [2,4,8,16,32,1,128,186,33,171,2048,159,24,1,191,189,32,60,36,190,159,169,33,189,30,191,148,48,1,2081,21,32,187,17,16,174]

theorem envBound31520 : H12AffineFastState.Bounded env31520 := by
  intro p hp
  have h : env31520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31519_31520 : H12AffineEnvironment.transform 8 33 env31519 = env31520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env31519 == env31520) = true)

theorem identity31520 : scanCanonicalize (H12AffineFastState.compose env31520 (packedSelected [1,2,3,5,10,12] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound31520 : packedSelected [1,2,3,5,10,12] rootPS < 2^1333 := by decide +kernel

def env31521 : List Nat := [2,4,8,16,32,1,24,34,33,51,2048,7,24,1,39,37,32,60,36,38,7,49,33,37,30,39,12,48,1,2081,21,32,35,17,16,54]

theorem envBound31521 : H12AffineFastState.Bounded env31521 := by
  intro p hp
  have h : env31521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31520_31521 : H12AffineEnvironment.transform 6 24 env31520 = env31521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env31520 == env31521) = true)

theorem identity31521 : scanCanonicalize (H12AffineFastState.compose env31521 (packedSelected [2,3,4,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound31521 : packedSelected [2,3,4,8,9] rootPS < 2^1333 := by decide +kernel

def env31522 : List Nat := [2,4,8,16,32,1,24,34,33,51,48,7,24,1,39,37,32,60,36,38,7,49,33,37,30,39,12,48,1,17,21,32,35,17,16,54]

theorem envBound31522 : H12AffineFastState.Bounded env31522 := by
  intro p hp
  have h : env31522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31521_31522 : H12AffineEnvironment.transform 10 48 env31521 = env31522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env31521 == env31522) = true)

theorem identity31522 : scanCanonicalize (H12AffineFastState.compose env31522 (packedSelected [0,2,7,8] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound31522 : packedSelected [0,2,7,8] rootPS < 2^1333 := by decide +kernel

def env31523 : List Nat := [2,4,5,16,32,1,21,34,33,51,48,7,21,1,39,37,32,49,36,38,7,49,33,37,19,39,1,48,1,17,21,32,35,17,16,54]

theorem envBound31523 : H12AffineFastState.Bounded env31523 := by
  intro p hp
  have h : env31523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31522_31523 : H12AffineEnvironment.transform 2 5 env31522 = env31523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env31522 == env31523) = true)

theorem identity31523 : scanCanonicalize (H12AffineFastState.compose env31523 (packedSelected [0,2,3,4] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound31523 : packedSelected [0,2,3,4] rootPS < 2^1333 := by decide +kernel

def env31524 : List Nat := [2,4,5,7,32,1,2,34,33,36,39,7,2,1,39,37,32,38,36,38,7,38,33,37,4,39,1,39,1,6,2,32,35,6,7,33]

theorem envBound31524 : H12AffineFastState.Bounded env31524 := by
  intro p hp
  have h : env31524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31523_31524 : H12AffineEnvironment.transform 3 7 env31523 = env31524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env31523 == env31524) = true)

theorem identity31524 : scanCanonicalize (H12AffineFastState.compose env31524 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound31524 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31525 : List Nat := [2,2,3,1,32,1,2,34,33,34,33,1,2,1,33,35,32,32,34,32,1,32,33,35,2,33,1,33,1,0,2,32,35,0,1,33]

theorem envBound31525 : H12AffineFastState.Bounded env31525 := by
  intro p hp
  have h : env31525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31524_31525 : H12AffineEnvironment.transform 1 2 env31524 = env31525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env31524 == env31525) = true)

theorem identity31525 : scanCanonicalize (H12AffineFastState.compose env31525 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound31525 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31526 : List Nat := [2,2,3,1,1,1,2,3,0,3,0,1,2,1,0,2,1,1,3,1,1,1,0,2,2,0,1,0,1,0,2,1,2,0,1,0]

theorem envBound31526 : H12AffineFastState.Bounded env31526 := by
  intro p hp
  have h : env31526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31525_31526 : H12AffineEnvironment.transform 4 1 env31525 = env31526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env31525 == env31526) = true)

def env31527 : List Nat := [2,4,8,16,32,1,128,256,512,273,2048,772,25,1,260,668,954,541,517,261,772,648,955,668,900,190,302,938,1,2458,20,955,257,17,16,276]

theorem envBound31527 : H12AffineFastState.Bounded env31527 := by
  intro p hp
  have h : env31527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31517_31527 : H12AffineEnvironment.transform 12 25 env31517 = env31527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env31517 == env31527) = true)

theorem identity31527 : scanCanonicalize (H12AffineFastState.compose env31527 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 175) := by decide +kernel

theorem selectedBound31527 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env31528 : List Nat := [2,4,8,16,32,1,128,256,175,273,2048,427,25,1,260,51,277,178,170,261,427,39,276,51,299,190,302,261,1,2458,20,276,257,17,16,276]

theorem envBound31528 : H12AffineFastState.Bounded env31528 := by
  intro p hp
  have h : env31528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31527_31528 : H12AffineEnvironment.transform 8 175 env31527 = env31528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 175 env31527 == env31528) = true)

theorem identity31528 : scanCanonicalize (H12AffineFastState.compose env31528 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound31528 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env31529 : List Nat := [2,4,8,0,32,1,128,256,175,257,2048,427,9,1,260,35,261,162,170,261,427,39,260,35,299,174,302,261,1,2442,4,260,257,1,0,260]

theorem envBound31529 : H12AffineFastState.Bounded env31529 := by
  intro p hp
  have h : env31529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31528_31529 : H12AffineEnvironment.transform 3 0 env31528 = env31529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env31528 == env31529) = true)

theorem identity31529 : scanCanonicalize (H12AffineFastState.compose env31529 (packedSelected [0,2,3,7,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 160) := by decide +kernel

theorem selectedBound31529 : packedSelected [0,2,3,7,11,12] rootPS < 2^1333 := by decide +kernel

def env31530 : List Nat := [2,4,8,0,32,1,128,160,175,161,2048,11,9,1,164,35,165,162,170,165,11,39,164,35,139,174,142,165,1,2090,4,164,161,1,0,164]

theorem envBound31530 : H12AffineFastState.Bounded env31530 := by
  intro p hp
  have h : env31530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31529_31530 : H12AffineEnvironment.transform 7 160 env31529 = env31530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 160 env31529 == env31530) = true)

theorem identity31530 : scanCanonicalize (H12AffineFastState.compose env31530 (packedSelected [0,1,2,3,7,8,11] rootPS)) = affineNative (2^(6+1) ^^^ 47) := by decide +kernel

theorem selectedBound31530 : packedSelected [0,1,2,3,7,8,11] rootPS < 2^1333 := by decide +kernel

def env31531 : List Nat := [2,4,8,0,32,1,47,15,0,14,2048,11,9,1,11,35,10,13,5,10,11,39,11,35,36,1,33,10,1,2090,4,11,14,1,0,11]

theorem envBound31531 : H12AffineFastState.Bounded env31531 := by
  intro p hp
  have h : env31531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31530_31531 : H12AffineEnvironment.transform 6 47 env31530 = env31531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 47 env31530 == env31531) = true)

theorem identity31531 : scanCanonicalize (H12AffineFastState.compose env31531 (packedSelected [3,5] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound31531 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env31532 : List Nat := [2,4,8,0,7,1,8,15,0,14,2048,11,9,1,11,4,10,13,5,10,11,0,11,4,3,1,6,10,1,2061,4,11,14,1,0,11]

theorem envBound31532 : H12AffineFastState.Bounded env31532 := by
  intro p hp
  have h : env31532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31531_31532 : H12AffineEnvironment.transform 4 7 env31531 = env31532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env31531 == env31532) = true)

theorem identity31532 : scanCanonicalize (H12AffineFastState.compose env31532 (packedSelected [1,2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound31532 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env31533 : List Nat := [2,3,8,0,0,1,8,8,0,9,2048,11,9,1,11,3,10,10,2,10,11,0,11,3,3,1,1,10,1,2058,3,11,9,1,0,11]

theorem envBound31533 : H12AffineFastState.Bounded env31533 := by
  intro p hp
  have h : env31533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31532_31533 : H12AffineEnvironment.transform 1 3 env31532 = env31533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env31532 == env31533) = true)

def env31534 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,773,8192,1,8540,65536,74110,65665,581,8541,773,649,74046,65601,9181,74298,367,74031,1,76639,8205,65831,257,17,81,340]

theorem envBound31534 : H12AffineFastState.Bounded env31534 := by
  intro p hp
  have h : env31534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31481_31534 : H12AffineEnvironment.transform 11 773 env31481 = env31534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 773 env31481 == env31534) = true)

def env31535 : List Nat := [2,4,8,16,32,0,128,256,512,273,2048,773,8192,1,8476,65536,74046,65665,517,8477,773,649,74046,65537,9117,74298,303,74031,1,76575,8205,65831,257,17,17,276]

theorem envBound31535 : H12AffineFastState.Bounded env31535 := by
  intro p hp
  have h : env31535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31534_31535 : H12AffineEnvironment.transform 5 0 env31534 = env31535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env31534 == env31535) = true)

theorem identity31535 : scanCanonicalize (H12AffineFastState.compose env31535 (packedSelected [1,8,28] rootPS)) = affineNative (2^(8+1) ^^^ 427) := by decide +kernel

theorem selectedBound31535 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env31536 : List Nat := [2,4,8,16,32,0,128,256,427,273,2048,174,8192,1,8476,65536,74046,65665,430,8477,174,290,74046,65537,8246,74129,303,74031,1,75956,8205,65831,257,17,17,276]

theorem envBound31536 : H12AffineFastState.Bounded env31536 := by
  intro p hp
  have h : env31536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31535_31536 : H12AffineEnvironment.transform 8 427 env31535 = env31536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 427 env31535 == env31536) = true)

def env31537 : List Nat := [2,4,8,16,32,0,36,256,271,273,2048,10,8192,1,8476,65536,74046,65573,266,8477,10,290,74046,65537,8246,74037,303,74031,1,75792,8205,65831,257,17,17,276]

theorem envBound31537 : H12AffineFastState.Bounded env31537 := by
  intro p hp
  have h : env31537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31536_31537 : H12AffineEnvironment.transform 6 36 env31536 = env31537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 36 env31536 == env31537) = true)

theorem identity31537 : scanCanonicalize (H12AffineFastState.compose env31537 (packedSelected [2,3,4,5,7,8,9,10,16,17,20,21,23,24,27,32,41] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound31537 : packedSelected [2,3,4,5,7,8,9,10,16,17,20,21,23,24,27,32,41] rootPS < 2^1333 := by decide +kernel

def env31538 : List Nat := [2,4,8,0,32,0,36,256,271,257,2048,10,8192,1,8460,65536,74030,65573,266,8461,10,290,74030,65537,8230,74021,303,74031,1,75776,8205,65831,257,1,1,260]

theorem envBound31538 : H12AffineFastState.Bounded env31538 := by
  intro p hp
  have h : env31538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31537_31538 : H12AffineEnvironment.transform 3 0 env31537 = env31538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env31537 == env31538) = true)

theorem identity31538 : scanCanonicalize (H12AffineFastState.compose env31538 (packedSelected [0,2,3,5,7,8,10,11,13,15,16,23] rootPS)) = affineNative (2^(15+1) ^^^ 8236) := by decide +kernel

theorem selectedBound31538 : packedSelected [0,2,3,5,7,8,10,11,13,15,16,23] rootPS < 2^1333 := by decide +kernel

def env31539 : List Nat := [2,4,8,0,32,0,36,256,271,257,2048,10,8192,1,8460,8236,258,8201,266,8461,10,290,258,8237,8230,265,303,259,1,2092,8205,8459,257,1,1,260]

theorem envBound31539 : H12AffineFastState.Bounded env31539 := by
  intro p hp
  have h : env31539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31538_31539 : H12AffineEnvironment.transform 15 8236 env31538 = env31539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8236 env31538 == env31539) = true)

theorem identity31539 : scanCanonicalize (H12AffineFastState.compose env31539 (packedSelected [2,4,5,7,12,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound31539 : packedSelected [2,4,5,7,12,13,17] rootPS < 2^1333 := by decide +kernel

def env31540 : List Nat := [2,4,8,0,32,0,36,37,42,36,2048,10,8192,1,8233,8236,39,8201,47,8232,10,7,39,8237,8230,44,10,38,1,2092,8205,8238,36,1,1,33]

theorem envBound31540 : H12AffineFastState.Bounded env31540 := by
  intro p hp
  have h : env31540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31539_31540 : H12AffineEnvironment.transform 7 37 env31539 = env31540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env31539 == env31540) = true)

theorem identity31540 : scanCanonicalize (H12AffineFastState.compose env31540 (packedSelected [0,1,3,5,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound31540 : packedSelected [0,1,3,5,8,9] rootPS < 2^1333 := by decide +kernel

def env31541 : List Nat := [2,4,8,0,32,0,36,37,42,36,2048,10,9,1,32,37,39,0,47,33,10,7,39,36,47,44,10,38,1,2092,4,39,36,1,1,33]

theorem envBound31541 : H12AffineFastState.Bounded env31541 := by
  intro p hp
  have h : env31541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31540_31541 : H12AffineEnvironment.transform 12 9 env31540 = env31541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env31540 == env31541) = true)

theorem identity31541 : scanCanonicalize (H12AffineFastState.compose env31541 (packedSelected [0,1,3,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 6) := by decide +kernel

theorem selectedBound31541 : packedSelected [0,1,3,4,5] rootPS < 2^1333 := by decide +kernel

def env31542 : List Nat := [2,4,8,0,32,0,36,37,42,36,6,10,9,1,32,37,39,0,47,33,10,7,39,36,47,44,10,38,1,42,4,39,36,1,1,33]

theorem envBound31542 : H12AffineFastState.Bounded env31542 := by
  intro p hp
  have h : env31542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31541_31542 : H12AffineEnvironment.transform 10 6 env31541 = env31542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 6 env31541 == env31542) = true)

theorem identity31542 : scanCanonicalize (H12AffineFastState.compose env31542 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound31542 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env31543 : List Nat := [2,4,2,0,32,0,36,37,32,36,6,0,3,1,32,37,39,0,37,33,0,7,39,36,37,38,0,38,1,32,4,39,36,1,1,33]

theorem envBound31543 : H12AffineFastState.Bounded env31543 := by
  intro p hp
  have h : env31543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31542_31543 : H12AffineEnvironment.transform 2 2 env31542 = env31543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env31542 == env31543) = true)

theorem identity31543 : scanCanonicalize (H12AffineFastState.compose env31543 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound31543 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31544 : List Nat := [2,4,2,0,7,0,3,2,7,3,6,0,3,1,7,2,0,0,2,6,0,7,0,3,2,1,0,1,1,7,4,0,3,1,1,6]

theorem envBound31544 : H12AffineFastState.Bounded env31544 := by
  intro p hp
  have h : env31544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31543_31544 : H12AffineEnvironment.transform 4 7 env31543 = env31544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env31543 == env31544) = true)

theorem identity31544 : scanCanonicalize (H12AffineFastState.compose env31544 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound31544 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31545 : List Nat := [2,1,2,0,2,0,3,2,2,3,3,0,3,1,2,2,0,0,2,3,0,2,0,3,2,1,0,1,1,2,1,0,3,1,1,3]

theorem envBound31545 : H12AffineFastState.Bounded env31545 := by
  intro p hp
  have h : env31545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31544_31545 : H12AffineEnvironment.transform 1 1 env31544 = env31545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env31544 == env31545) = true)

def env31546 : List Nat := [2,4,8,16,32,0,37,256,270,273,2048,11,8192,1,8476,65536,74046,65572,267,8477,11,290,74046,65537,8246,74036,303,74031,1,75793,8205,65831,257,17,17,276]

theorem envBound31546 : H12AffineFastState.Bounded env31546 := by
  intro p hp
  have h : env31546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31536_31546 : H12AffineEnvironment.transform 6 37 env31536 = env31546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 37 env31536 == env31546) = true)

theorem identity31546 : scanCanonicalize (H12AffineFastState.compose env31546 (packedSelected [2,3,4,5,7,8,9,10,16,17,20,21,23,24,27,32,41] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound31546 : packedSelected [2,3,4,5,7,8,9,10,16,17,20,21,23,24,27,32,41] rootPS < 2^1333 := by decide +kernel

def env31547 : List Nat := [2,4,8,16,32,0,37,256,270,273,2048,11,9,1,277,65536,65847,65572,267,276,11,290,65847,65537,63,65853,303,65830,1,67608,4,65831,257,17,17,276]

theorem envBound31547 : H12AffineFastState.Bounded env31547 := by
  intro p hp
  have h : env31547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31546_31547 : H12AffineEnvironment.transform 12 9 env31546 = env31547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env31546 == env31547) = true)

theorem identity31547 : scanCanonicalize (H12AffineFastState.compose env31547 (packedSelected [2,4,8,9,11,15,16,17,18] rootPS)) = affineNative (2^(15+1) ^^^ 2072) := by decide +kernel

theorem selectedBound31547 : packedSelected [2,4,8,9,11,15,16,17,18] rootPS < 2^1333 := by decide +kernel

def env31548 : List Nat := [2,4,8,16,32,0,37,256,270,273,2048,11,9,1,277,2072,2351,2108,267,276,11,290,2351,2073,63,2341,303,2366,1,0,4,2367,257,17,17,276]

theorem envBound31548 : H12AffineFastState.Bounded env31548 := by
  intro p hp
  have h : env31548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31547_31548 : H12AffineEnvironment.transform 15 2072 env31547 = env31548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2072 env31547 == env31548) = true)

theorem identity31548 : scanCanonicalize (H12AffineFastState.compose env31548 (packedSelected [1,2,3,5,7,8,9,12,13] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound31548 : packedSelected [1,2,3,5,7,8,9,12,13] rootPS < 2^1333 := by decide +kernel

def env31549 : List Nat := [2,4,8,16,32,0,37,256,270,273,26,11,9,1,277,2,309,38,267,276,11,290,309,3,63,319,303,292,1,0,4,293,257,17,17,276]

theorem envBound31549 : H12AffineFastState.Bounded env31549 := by
  intro p hp
  have h : env31549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31548_31549 : H12AffineEnvironment.transform 10 26 env31548 = env31549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env31548 == env31549) = true)

theorem identity31549 : scanCanonicalize (H12AffineFastState.compose env31549 (packedSelected [0,3,4,7,9,11] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound31549 : packedSelected [0,3,4,7,9,11] rootPS < 2^1333 := by decide +kernel

def env31550 : List Nat := [2,4,8,10,32,0,37,256,270,267,0,11,9,1,271,2,303,38,267,270,11,290,303,3,37,293,303,292,1,0,4,293,257,11,11,270]

theorem envBound31550 : H12AffineFastState.Bounded env31550 := by
  intro p hp
  have h : env31550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31549_31550 : H12AffineEnvironment.transform 3 10 env31549 = env31550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env31549 == env31550) = true)

theorem identity31550 : scanCanonicalize (H12AffineFastState.compose env31550 (packedSelected [1,2,4,7] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound31550 : packedSelected [1,2,4,7] rootPS < 2^1333 := by decide +kernel

def env31551 : List Nat := [2,4,8,10,32,0,37,14,0,5,0,11,9,1,1,2,33,38,5,0,11,44,33,3,37,43,33,42,1,0,4,43,15,11,11,0]

theorem envBound31551 : H12AffineFastState.Bounded env31551 := by
  intro p hp
  have h : env31551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31550_31551 : H12AffineEnvironment.transform 7 14 env31550 = env31551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env31550 == env31551) = true)

theorem identity31551 : scanCanonicalize (H12AffineFastState.compose env31551 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound31551 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env31552 : List Nat := [2,4,8,10,11,0,14,14,0,5,0,11,9,1,1,2,10,13,5,0,11,7,10,3,14,0,10,1,1,0,4,0,15,11,11,0]

theorem envBound31552 : H12AffineFastState.Bounded env31552 := by
  intro p hp
  have h : env31552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31551_31552 : H12AffineEnvironment.transform 4 11 env31551 = env31552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env31551 == env31552) = true)

theorem identity31552 : scanCanonicalize (H12AffineFastState.compose env31552 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound31552 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31553 : List Nat := [2,4,3,1,0,0,5,5,0,5,0,0,2,1,1,2,1,6,5,0,0,7,1,3,5,0,1,1,1,0,4,0,4,0,0,0]

theorem envBound31553 : H12AffineFastState.Bounded env31553 := by
  intro p hp
  have h : env31553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31552_31553 : H12AffineEnvironment.transform 2 3 env31552 = env31553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env31552 == env31553) = true)

theorem identity31553 : scanCanonicalize (H12AffineFastState.compose env31553 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound31553 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31554 : List Nat := [2,3,3,1,0,0,2,2,0,2,0,0,2,1,1,2,1,1,2,0,0,0,1,3,2,0,1,1,1,0,3,0,3,0,0,0]

theorem envBound31554 : H12AffineFastState.Bounded env31554 := by
  intro p hp
  have h : env31554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31553_31554 : H12AffineEnvironment.transform 1 3 env31553 = env31554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env31553 == env31554) = true)

def env31555 : List Nat := [2,4,8,16,32,1,128,256,512,273,2048,773,8192,1,8477,65536,74047,65665,516,8476,773,649,74046,65536,9116,74298,302,74031,1,76574,8205,65831,257,17,16,277]

theorem envBound31555 : H12AffineFastState.Bounded env31555 := by
  intro p hp
  have h : env31555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31534_31555 : H12AffineEnvironment.transform 5 1 env31534 = env31555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env31534 == env31555) = true)

theorem identity31555 : scanCanonicalize (H12AffineFastState.compose env31555 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 947) := by decide +kernel

theorem selectedBound31555 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env31556 : List Nat := [2,4,8,16,32,1,128,256,512,273,2048,773,947,1,686,65536,66188,65665,516,687,773,649,66189,65536,47,65929,302,66204,1,67757,958,65831,257,17,16,277]

theorem envBound31556 : H12AffineFastState.Bounded env31556 := by
  intro p hp
  have h : env31556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31555_31556 : H12AffineEnvironment.transform 12 947 env31555 = env31556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 947 env31555 == env31556) = true)

def env31557 : List Nat := [2,4,8,16,32,1,128,256,512,273,788,773,947,1,686,65536,66188,65665,516,687,773,649,66189,65536,47,65929,302,66204,1,66489,958,65831,257,17,16,277]

theorem envBound31557 : H12AffineFastState.Bounded env31557 := by
  intro p hp
  have h : env31557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31556_31557 : H12AffineEnvironment.transform 10 788 env31556 = env31557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 788 env31556 == env31557) = true)

def env31558 : List Nat := [2,4,8,16,12,1,128,256,512,273,788,773,927,1,642,65536,66188,65665,516,643,773,649,66189,65536,3,65929,258,66204,1,66453,914,65803,257,17,16,277]

theorem envBound31558 : H12AffineFastState.Bounded env31558 := by
  intro p hp
  have h : env31558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31557_31558 : H12AffineEnvironment.transform 4 12 env31557 = env31558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env31557 == env31558) = true)

theorem identity31558 : scanCanonicalize (H12AffineFastState.compose env31558 (packedSelected [0,2,3,5,8,9,17] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound31558 : packedSelected [0,2,3,5,8,9,17] rootPS < 2^1333 := by decide +kernel

def env31559 : List Nat := [2,4,8,11,12,1,128,256,512,266,783,773,900,1,642,65536,66188,65665,516,643,773,649,66189,65536,3,65929,258,66183,1,66446,905,65803,257,10,11,270]

theorem envBound31559 : H12AffineFastState.Bounded env31559 := by
  intro p hp
  have h : env31559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31558_31559 : H12AffineEnvironment.transform 3 11 env31558 = env31559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env31558 == env31559) = true)

theorem identity31559 : scanCanonicalize (H12AffineFastState.compose env31559 (packedSelected [0,3,4,5,7,9,13,15,16,18] rootPS)) = affineNative (2^(8+1) ^^^ 133) := by decide +kernel

theorem selectedBound31559 : packedSelected [0,3,4,5,7,9,13,15,16,18] rootPS < 2^1333 := by decide +kernel

def env31560 : List Nat := [2,4,8,11,12,1,128,256,133,266,394,384,257,1,7,65536,65545,65665,129,6,384,12,65544,65536,3,65929,258,65538,1,65803,268,65803,257,10,11,270]

theorem envBound31560 : H12AffineFastState.Bounded env31560 := by
  intro p hp
  have h : env31560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31559_31560 : H12AffineEnvironment.transform 8 133 env31559 = env31560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 133 env31559 == env31560) = true)

theorem identity31560 : scanCanonicalize (H12AffineFastState.compose env31560 (packedSelected [2,3,5,7,8,9] rootPS)) = affineNative (2^(15+1) ^^^ 129) := by decide +kernel

theorem selectedBound31560 : packedSelected [2,3,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env31561 : List Nat := [2,4,8,11,12,1,128,256,133,266,394,384,257,1,7,129,136,0,129,6,384,12,137,129,3,264,258,131,1,394,268,394,257,10,11,270]

theorem envBound31561 : H12AffineFastState.Bounded env31561 := by
  intro p hp
  have h : env31561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31560_31561 : H12AffineEnvironment.transform 15 129 env31560 = env31561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 129 env31560 == env31561) = true)

theorem identity31561 : scanCanonicalize (H12AffineFastState.compose env31561 (packedSelected [1,2,4,5,7] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound31561 : packedSelected [1,2,4,5,7] rootPS < 2^1333 := by decide +kernel

def env31562 : List Nat := [2,4,3,0,7,1,128,256,133,257,385,384,257,1,7,129,131,0,129,6,384,7,130,129,3,259,258,131,1,385,263,385,257,1,0,261]

theorem envBound31562 : H12AffineFastState.Bounded env31562 := by
  intro p hp
  have h : env31562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31561_31562 : H12AffineEnvironment.transform 2 3 env31561 = env31562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env31561 == env31562) = true)

theorem identity31562 : scanCanonicalize (H12AffineFastState.compose env31562 (packedSelected [1,3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound31562 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env31563 : List Nat := [2,2,3,0,1,1,128,256,131,257,385,384,257,1,1,129,131,0,129,0,384,1,130,129,3,259,258,131,1,385,257,385,257,1,0,259]

theorem envBound31563 : H12AffineFastState.Bounded env31563 := by
  intro p hp
  have h : env31563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31562_31563 : H12AffineEnvironment.transform 1 2 env31562 = env31563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env31562 == env31563) = true)

theorem identity31563 : scanCanonicalize (H12AffineFastState.compose env31563 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 3) := by decide +kernel

theorem selectedBound31563 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31564 : List Nat := [2,2,3,0,1,1,128,3,131,2,130,131,2,1,1,129,131,0,129,0,131,1,130,129,3,0,1,131,1,130,2,130,2,1,0,0]

theorem envBound31564 : H12AffineFastState.Bounded env31564 := by
  intro p hp
  have h : env31564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31563_31564 : H12AffineEnvironment.transform 7 3 env31563 = env31564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 3 env31563 == env31564) = true)

theorem identity31564 : scanCanonicalize (H12AffineFastState.compose env31564 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound31564 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31565 : List Nat := [2,2,3,0,1,1,3,3,0,2,1,0,2,1,1,2,0,0,2,0,0,1,1,2,3,0,1,0,1,1,2,1,2,1,0,0]

theorem envBound31565 : H12AffineFastState.Bounded env31565 := by
  intro p hp
  have h : env31565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31564_31565 : H12AffineEnvironment.transform 6 3 env31564 = env31565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env31564 == env31565) = true)

def env31566 : List Nat := [2,4,8,16,13,1,128,256,512,273,788,773,926,1,643,65536,66188,65665,516,642,773,649,66189,65536,2,65929,259,66204,1,66452,915,65802,257,17,16,277]

theorem envBound31566 : H12AffineFastState.Bounded env31566 := by
  intro p hp
  have h : env31566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31557_31566 : H12AffineEnvironment.transform 4 13 env31557 = env31566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env31557 == env31566) = true)

theorem identity31566 : scanCanonicalize (H12AffineFastState.compose env31566 (packedSelected [0,2,3,5,8,9,17] rootPS)) = affineNative (2^(7+1) ^^^ 2) := by decide +kernel

theorem selectedBound31566 : packedSelected [0,2,3,5,8,9,17] rootPS < 2^1333 := by decide +kernel

def env31567 : List Nat := [2,4,8,16,13,1,128,2,512,19,534,519,668,1,643,65536,66188,65665,516,642,519,649,66189,65536,2,65675,1,66204,1,66198,657,65544,3,17,16,23]

theorem envBound31567 : H12AffineFastState.Bounded env31567 := by
  intro p hp
  have h : env31567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31566_31567 : H12AffineEnvironment.transform 7 2 env31566 = env31567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 2 env31566 == env31567) = true)

theorem identity31567 : scanCanonicalize (H12AffineFastState.compose env31567 (packedSelected [1,4,5,7,8,10,12,16] rootPS)) = affineNative (2^(15+1) ^^^ 667) := by decide +kernel

theorem selectedBound31567 : packedSelected [1,4,5,7,8,10,12,16] rootPS < 2^1333 := by decide +kernel

def env31568 : List Nat := [2,4,8,16,13,1,128,2,512,19,534,519,668,1,643,667,23,538,516,642,519,649,22,667,2,528,1,7,1,13,657,659,3,17,16,23]

theorem envBound31568 : H12AffineFastState.Bounded env31568 := by
  intro p hp
  have h : env31568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31567_31568 : H12AffineEnvironment.transform 15 667 env31567 = env31568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 667 env31567 == env31568) = true)

theorem identity31568 : scanCanonicalize (H12AffineFastState.compose env31568 (packedSelected [0,3,4,7,9,11] rootPS)) = affineNative (2^(8+1) ^^^ 152) := by decide +kernel

theorem selectedBound31568 : packedSelected [0,3,4,7,9,11] rootPS < 2^1333 := by decide +kernel

def env31569 : List Nat := [2,4,8,16,13,1,128,2,152,19,142,159,4,1,27,3,23,130,156,26,159,17,22,3,2,136,1,7,1,13,9,11,3,17,16,23]

theorem envBound31569 : H12AffineFastState.Bounded env31569 := by
  intro p hp
  have h : env31569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31568_31569 : H12AffineEnvironment.transform 8 152 env31568 = env31569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 152 env31568 == env31569) = true)

theorem identity31569 : scanCanonicalize (H12AffineFastState.compose env31569 (packedSelected [2,4,5,7,8] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound31569 : packedSelected [2,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env31570 : List Nat := [2,4,4,16,1,1,128,2,148,19,130,147,4,1,23,3,23,130,144,22,147,17,22,3,2,132,1,7,1,1,5,7,3,17,16,23]

theorem envBound31570 : H12AffineFastState.Bounded env31570 := by
  intro p hp
  have h : env31570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31569_31570 : H12AffineEnvironment.transform 2 4 env31569 = env31570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env31569 == env31570) = true)

theorem identity31570 : scanCanonicalize (H12AffineFastState.compose env31570 (packedSelected [0,2,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound31570 : packedSelected [0,2,3,4] rootPS < 2^1333 := by decide +kernel

def env31571 : List Nat := [2,4,4,16,1,1,19,2,7,19,17,0,4,1,23,3,23,17,3,22,0,17,22,3,2,23,1,7,1,1,5,7,3,17,16,23]

theorem envBound31571 : H12AffineFastState.Bounded env31571 := by
  intro p hp
  have h : env31571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31570_31571 : H12AffineEnvironment.transform 6 19 env31570 = env31571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env31570 == env31571) = true)

theorem identity31571 : scanCanonicalize (H12AffineFastState.compose env31571 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound31571 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env31572 : List Nat := [2,4,4,0,1,1,3,2,7,3,1,0,4,1,7,3,7,1,3,6,0,1,6,3,2,7,1,7,1,1,5,7,3,1,0,7]

theorem envBound31572 : H12AffineFastState.Bounded env31572 := by
  intro p hp
  have h : env31572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31571_31572 : H12AffineEnvironment.transform 3 0 env31571 = env31572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env31571 == env31572) = true)

theorem identity31572 : scanCanonicalize (H12AffineFastState.compose env31572 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound31572 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31573 : List Nat := [2,2,2,0,1,1,3,2,1,3,1,0,2,1,1,3,1,1,3,0,0,1,0,3,2,1,1,1,1,1,3,1,3,1,0,1]

theorem envBound31573 : H12AffineFastState.Bounded env31573 := by
  intro p hp
  have h : env31573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31572_31573 : H12AffineEnvironment.transform 1 2 env31572 = env31573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env31572 == env31573) = true)

def env31574 : List Nat := [2,4,8,16,32,1,128,256,512,273,789,773,947,1,686,65536,66188,65665,516,687,773,649,66189,65536,47,65929,302,66204,1,66488,958,65831,257,17,16,277]

theorem envBound31574 : H12AffineFastState.Bounded env31574 := by
  intro p hp
  have h : env31574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31556_31574 : H12AffineEnvironment.transform 10 789 env31556 = env31574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 789 env31556 == env31574) = true)

def env31575 : List Nat := [2,4,8,16,12,1,128,256,512,273,789,773,927,1,642,65536,66188,65665,516,643,773,649,66189,65536,3,65929,258,66204,1,66452,914,65803,257,17,16,277]

theorem envBound31575 : H12AffineFastState.Bounded env31575 := by
  intro p hp
  have h : env31575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31574_31575 : H12AffineEnvironment.transform 4 12 env31574 = env31575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env31574 == env31575) = true)

theorem identity31575 : scanCanonicalize (H12AffineFastState.compose env31575 (packedSelected [0,2,3,5,8,9,17] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound31575 : packedSelected [0,2,3,5,8,9,17] rootPS < 2^1333 := by decide +kernel

def env31576 : List Nat := [2,4,8,1,12,1,128,256,512,256,772,773,910,1,642,65536,66188,65665,516,643,773,649,66189,65536,3,65929,258,66189,1,66437,899,65803,257,0,1,260]

theorem envBound31576 : H12AffineFastState.Bounded env31576 := by
  intro p hp
  have h : env31576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31575_31576 : H12AffineEnvironment.transform 3 1 env31575 = env31576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env31575 == env31576) = true)

theorem identity31576 : scanCanonicalize (H12AffineFastState.compose env31576 (packedSelected [3,4,7,10,11,12,15,16] rootPS)) = affineNative (2^(7+1) ^^^ 134) := by decide +kernel

theorem selectedBound31576 : packedSelected [3,4,7,10,11,12,15,16] rootPS < 2^1333 := by decide +kernel

def env31577 : List Nat := [2,4,8,1,12,1,128,134,512,134,642,643,520,1,642,65536,66188,65665,516,643,643,649,66189,65536,3,65551,132,66189,1,66051,517,65677,135,0,1,130]

theorem envBound31577 : H12AffineFastState.Bounded env31577 := by
  intro p hp
  have h : env31577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31576_31577 : H12AffineEnvironment.transform 7 134 env31576 = env31577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 134 env31576 == env31577) = true)

theorem identity31577 : scanCanonicalize (H12AffineFastState.compose env31577 (packedSelected [1,4,8,9,10,11] rootPS)) = affineNative (2^(8+1) ^^^ 143) := by decide +kernel

theorem selectedBound31577 : packedSelected [1,4,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env31578 : List Nat := [2,4,8,1,12,1,128,134,143,134,13,12,135,1,13,65536,65539,65665,139,12,12,6,65538,65536,3,65551,132,65538,1,65676,138,65677,135,0,1,130]

theorem envBound31578 : H12AffineFastState.Bounded env31578 := by
  intro p hp
  have h : env31578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31577_31578 : H12AffineEnvironment.transform 8 143 env31577 = env31578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 143 env31577 == env31578) = true)

theorem identity31578 : scanCanonicalize (H12AffineFastState.compose env31578 (packedSelected [1,3] rootPS)) = affineNative (2^(15+1) ^^^ 129) := by decide +kernel

theorem selectedBound31578 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env31579 : List Nat := [2,4,8,1,12,1,128,134,143,134,13,12,135,1,13,129,130,0,139,12,12,6,131,129,3,142,132,131,1,13,138,12,135,0,1,130]

theorem envBound31579 : H12AffineFastState.Bounded env31579 := by
  intro p hp
  have h : env31579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31578_31579 : H12AffineEnvironment.transform 15 129 env31578 = env31579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 129 env31578 == env31579) = true)

def env31580 : List Nat := [2,4,8,16,13,1,128,256,512,273,789,773,926,1,643,65536,66188,65665,516,642,773,649,66189,65536,2,65929,259,66204,1,66453,915,65802,257,17,16,277]

theorem envBound31580 : H12AffineFastState.Bounded env31580 := by
  intro p hp
  have h : env31580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31574_31580 : H12AffineEnvironment.transform 4 13 env31574 = env31580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env31574 == env31580) = true)

theorem identity31580 : scanCanonicalize (H12AffineFastState.compose env31580 (packedSelected [0,2,3,5,8,9,17] rootPS)) = affineNative (2^(7+1) ^^^ 8) := by decide +kernel

theorem selectedBound31580 : packedSelected [0,2,3,5,8,9,17] rootPS < 2^1333 := by decide +kernel

def env31581 : List Nat := [2,4,8,16,13,1,128,8,512,25,541,525,662,1,643,65536,66188,65665,516,642,525,649,66189,65536,2,65665,11,66204,1,66205,667,65538,9,17,16,29]

theorem envBound31581 : H12AffineFastState.Bounded env31581 := by
  intro p hp
  have h : env31581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31580_31581 : H12AffineEnvironment.transform 7 8 env31580 = env31581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 8 env31580 == env31581) = true)

theorem identity31581 : scanCanonicalize (H12AffineFastState.compose env31581 (packedSelected [0,2,3,4,8,18] rootPS)) = affineNative (2^(15+1) ^^^ 527) := by decide +kernel

theorem selectedBound31581 : packedSelected [0,2,3,4,8,18] rootPS < 2^1333 := by decide +kernel

def env31582 : List Nat := [2,4,8,16,13,1,128,8,512,25,541,525,662,1,643,527,131,654,516,642,525,649,130,527,2,654,11,147,1,146,667,525,9,17,16,29]

theorem envBound31582 : H12AffineFastState.Bounded env31582 := by
  intro p hp
  have h : env31582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31581_31582 : H12AffineEnvironment.transform 15 527 env31581 = env31582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 527 env31581 == env31582) = true)

theorem identity31582 : scanCanonicalize (H12AffineFastState.compose env31582 (packedSelected [0,2,4,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound31582 : packedSelected [0,2,4,5,10] rootPS < 2^1333 := by decide +kernel

def env31583 : List Nat := [2,4,8,16,13,1,9,8,512,25,541,525,543,1,522,527,10,519,516,523,525,512,11,527,2,519,11,26,1,27,530,525,9,17,16,29]

theorem envBound31583 : H12AffineFastState.Bounded env31583 := by
  intro p hp
  have h : env31583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31582_31583 : H12AffineEnvironment.transform 6 9 env31582 = env31583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env31582 == env31583) = true)

theorem identity31583 : scanCanonicalize (H12AffineFastState.compose env31583 (packedSelected [0,5,7] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound31583 : packedSelected [0,5,7] rootPS < 2^1333 := by decide +kernel

def env31584 : List Nat := [2,3,8,16,10,1,9,8,512,25,538,522,536,1,522,520,10,512,515,523,522,512,11,520,2,512,11,26,1,27,530,522,9,17,16,26]

theorem envBound31584 : H12AffineFastState.Bounded env31584 := by
  intro p hp
  have h : env31584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31583_31584 : H12AffineEnvironment.transform 1 3 env31583 = env31584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env31583 == env31584) = true)

theorem identity31584 : scanCanonicalize (H12AffineFastState.compose env31584 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound31584 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env31585 : List Nat := [2,3,8,0,10,1,9,8,512,9,522,522,520,1,522,520,10,512,515,523,522,512,11,520,2,512,11,10,1,11,514,522,9,1,0,10]

theorem envBound31585 : H12AffineFastState.Bounded env31585 := by
  intro p hp
  have h : env31585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31584_31585 : H12AffineEnvironment.transform 3 0 env31584 = env31585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env31584 == env31585) = true)

theorem identity31585 : scanCanonicalize (H12AffineFastState.compose env31585 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound31585 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31586 : List Nat := [2,3,3,0,1,1,2,3,512,2,513,513,515,1,513,515,1,512,515,512,513,512,0,515,2,512,0,1,1,0,514,513,2,1,0,1]

theorem envBound31586 : H12AffineFastState.Bounded env31586 := by
  intro p hp
  have h : env31586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31585_31586 : H12AffineEnvironment.transform 2 3 env31585 = env31586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env31585 == env31586) = true)

theorem identity31586 : scanCanonicalize (H12AffineFastState.compose env31586 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound31586 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31587 : List Nat := [2,3,3,0,1,1,2,3,1,2,0,0,2,1,0,2,1,1,2,1,0,1,0,2,2,1,0,1,1,0,3,0,2,1,0,1]

theorem envBound31587 : H12AffineFastState.Bounded env31587 := by
  intro p hp
  have h : env31587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31586_31587 : H12AffineEnvironment.transform 8 1 env31586 = env31587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env31586 == env31587) = true)

def env31588 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74863,262144,4417,8540,4096,5277,74047,66896,13768,78894,328959,74815,1296,81226,8204,65830,257,1280,1344,5953]

theorem envBound31588 : H12AffineFastState.Bounded env31588 := by
  intro p hp
  have h : env31588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31455_31588 : H12AffineEnvironment.transform 13 1297 env31455 = env31588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env31455 == env31588) = true)

def env31589 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74863,65664,4417,8540,4096,5277,74047,66896,13768,78894,1151,74815,1296,81226,8204,65830,257,1280,1344,5953]

theorem envBound31589 : H12AffineFastState.Bounded env31589 := by
  intro p hp
  have h : env31589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31588_31589 : H12AffineEnvironment.transform 17 65664 env31588 = env31589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env31588 == env31589) = true)

theorem identity31589 : scanCanonicalize (H12AffineFastState.compose env31589 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound31589 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env31590 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,24,1297,325,65536,66679,65664,4417,324,4096,5277,65831,66896,5584,70710,1151,66599,1296,73042,20,65830,257,1280,1344,5953]

theorem envBound31590 : H12AffineFastState.Bounded env31590 := by
  intro p hp
  have h : env31590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31589_31590 : H12AffineEnvironment.transform 12 24 env31589 = env31590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env31589 == env31590) = true)

def env31591 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1556,24,1297,325,65536,66679,65664,1877,324,1556,649,65831,66896,964,66082,1151,66599,1296,68422,20,65830,257,1280,1344,341]

theorem envBound31591 : H12AffineFastState.Bounded env31591 := by
  intro p hp
  have h : env31591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31590_31591 : H12AffineEnvironment.transform 11 1556 env31590 = env31591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1556 env31590 == env31591) = true)

def env31592 : List Nat := [2,4,8,16,32,0,128,256,512,1024,2048,1556,24,1297,261,65536,66615,65664,1813,260,1556,649,65831,66832,900,66082,1087,66599,1296,68358,20,65830,257,1280,1280,277]

theorem envBound31592 : H12AffineFastState.Bounded env31592 := by
  intro p hp
  have h : env31592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31591_31592 : H12AffineEnvironment.transform 5 0 env31591 = env31592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env31591 == env31592) = true)

theorem identity31592 : scanCanonicalize (H12AffineFastState.compose env31592 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 1285) := by decide +kernel

theorem selectedBound31592 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env31593 : List Nat := [2,4,8,16,32,0,128,256,512,1024,2048,1556,24,1297,261,1285,306,1413,1813,260,1556,649,1058,21,900,1831,1087,290,1296,3587,20,1059,257,1280,1280,277]

theorem envBound31593 : H12AffineFastState.Bounded env31593 := by
  intro p hp
  have h : env31593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31592_31593 : H12AffineEnvironment.transform 15 1285 env31592 = env31593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1285 env31592 == env31593) = true)

def env31594 : List Nat := [2,4,8,16,32,0,128,256,512,272,2048,772,24,1,261,21,306,149,517,260,772,649,306,21,900,567,303,290,0,2835,20,307,257,16,16,277]

theorem envBound31594 : H12AffineFastState.Bounded env31594 := by
  intro p hp
  have h : env31594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31593_31594 : H12AffineEnvironment.transform 9 272 env31593 = env31594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env31593 == env31594) = true)

theorem identity31594 : scanCanonicalize (H12AffineFastState.compose env31594 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 306) := by decide +kernel

theorem selectedBound31594 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env31595 : List Nat := [2,4,8,16,32,0,128,256,306,272,2048,54,24,1,261,21,306,149,311,260,54,443,306,21,182,261,303,290,0,2081,20,307,257,16,16,277]

theorem envBound31595 : H12AffineFastState.Bounded env31595 := by
  intro p hp
  have h : env31595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31594_31595 : H12AffineEnvironment.transform 8 306 env31594 = env31595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 306 env31594 == env31595) = true)

theorem identity31595 : scanCanonicalize (H12AffineFastState.compose env31595 (packedSelected [0,1,2,3,7,10,12,17,20] rootPS)) = affineNative (2^(10+1) ^^^ 61) := by decide +kernel

theorem selectedBound31595 : packedSelected [0,1,2,3,7,10,12,17,20] rootPS < 2^1333 := by decide +kernel

def env31596 : List Nat := [2,4,8,16,32,0,128,256,306,272,61,54,24,1,261,21,306,149,311,260,54,443,306,21,182,261,303,290,0,28,20,307,257,16,16,277]

theorem envBound31596 : H12AffineFastState.Bounded env31596 := by
  intro p hp
  have h : env31596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31595_31596 : H12AffineEnvironment.transform 10 61 env31595 = env31596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 61 env31595 == env31596) = true)

theorem identity31596 : scanCanonicalize (H12AffineFastState.compose env31596 (packedSelected [0,5,7,8,11,12,17] rootPS)) = affineNative (2^(7+1) ^^^ 34) := by decide +kernel

theorem selectedBound31596 : packedSelected [0,5,7,8,11,12,17] rootPS < 2^1333 := by decide +kernel

def env31597 : List Nat := [2,4,8,16,32,0,128,34,16,50,61,54,24,1,39,21,16,149,21,38,54,153,16,21,182,39,13,0,0,28,20,17,35,16,16,55]

theorem envBound31597 : H12AffineFastState.Bounded env31597 := by
  intro p hp
  have h : env31597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31596_31597 : H12AffineEnvironment.transform 7 34 env31596 = env31597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 34 env31596 == env31597) = true)

theorem identity31597 : scanCanonicalize (H12AffineFastState.compose env31597 (packedSelected [0,1,2,7,8,11] rootPS)) = affineNative (2^(4+1) ^^^ 22) := by decide +kernel

theorem selectedBound31597 : packedSelected [0,1,2,7,8,11] rootPS < 2^1333 := by decide +kernel

def env31598 : List Nat := [2,4,8,16,22,0,128,20,16,4,11,0,24,1,17,21,16,149,21,16,0,153,16,21,128,17,13,0,0,28,20,17,21,16,16,1]

theorem envBound31598 : H12AffineFastState.Bounded env31598 := by
  intro p hp
  have h : env31598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31597_31598 : H12AffineEnvironment.transform 4 22 env31597 = env31598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 22 env31597 == env31598) = true)

theorem identity31598 : scanCanonicalize (H12AffineFastState.compose env31598 (packedSelected [3,5] rootPS)) = affineNative (2^(6+1) ^^^ 15) := by decide +kernel

theorem selectedBound31598 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env31599 : List Nat := [2,4,8,16,22,0,15,20,16,4,11,0,24,1,17,21,16,26,21,16,0,22,16,21,15,17,13,0,0,28,20,17,21,16,16,1]

theorem envBound31599 : H12AffineFastState.Bounded env31599 := by
  intro p hp
  have h : env31599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31598_31599 : H12AffineEnvironment.transform 6 15 env31598 = env31599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 15 env31598 == env31599) = true)

theorem identity31599 : scanCanonicalize (H12AffineFastState.compose env31599 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound31599 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env31600 : List Nat := [2,4,8,11,13,0,15,15,11,4,11,0,3,1,10,14,11,1,14,11,0,13,11,14,15,10,13,0,0,7,15,10,14,11,11,1]

theorem envBound31600 : H12AffineFastState.Bounded env31600 := by
  intro p hp
  have h : env31600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31599_31600 : H12AffineEnvironment.transform 3 11 env31599 = env31600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env31599 == env31600) = true)

theorem identity31600 : scanCanonicalize (H12AffineFastState.compose env31600 (packedSelected [1,2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound31600 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env31601 : List Nat := [2,4,2,1,7,0,5,5,1,4,1,0,3,1,0,4,1,1,4,1,0,7,1,4,5,0,7,0,0,7,5,0,4,1,1,1]

theorem envBound31601 : H12AffineFastState.Bounded env31601 := by
  intro p hp
  have h : env31601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31600_31601 : H12AffineEnvironment.transform 2 2 env31600 = env31601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env31600 == env31601) = true)

def env31602 : List Nat := [2,4,8,16,32,0,128,256,512,273,2048,773,24,0,261,20,306,148,516,260,773,649,307,21,900,566,302,290,1,2834,20,306,257,17,17,277]

theorem envBound31602 : H12AffineFastState.Bounded env31602 := by
  intro p hp
  have h : env31602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31593_31602 : H12AffineEnvironment.transform 9 273 env31593 = env31602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env31593 == env31602) = true)

theorem identity31602 : scanCanonicalize (H12AffineFastState.compose env31602 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound31602 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env31603 : List Nat := [2,4,8,16,7,0,128,256,512,273,2048,773,24,0,261,20,277,148,516,260,773,649,276,21,900,529,265,261,1,2834,20,277,257,17,17,277]

theorem envBound31603 : H12AffineFastState.Bounded env31603 := by
  intro p hp
  have h : env31603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31602_31603 : H12AffineEnvironment.transform 4 7 env31602 = env31603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env31602 == env31603) = true)

theorem identity31603 : scanCanonicalize (H12AffineFastState.compose env31603 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound31603 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env31604 : List Nat := [2,4,8,16,7,0,128,256,260,273,2048,1,24,0,261,20,277,148,256,260,1,397,276,21,128,277,265,261,1,2070,20,277,257,17,17,277]

theorem envBound31604 : H12AffineFastState.Bounded env31604 := by
  intro p hp
  have h : env31604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31603_31604 : H12AffineEnvironment.transform 8 260 env31603 = env31604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env31603 == env31604) = true)

theorem identity31604 : scanCanonicalize (H12AffineFastState.compose env31604 (packedSelected [0,3,5,7,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound31604 : packedSelected [0,3,5,7,10,11] rootPS < 2^1333 := by decide +kernel

def env31605 : List Nat := [2,4,8,16,7,0,128,256,260,273,0,1,24,0,261,20,277,148,256,260,1,397,276,21,128,277,265,261,1,22,20,277,257,17,17,277]

theorem envBound31605 : H12AffineFastState.Bounded env31605 := by
  intro p hp
  have h : env31605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31604_31605 : H12AffineEnvironment.transform 10 0 env31604 = env31605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env31604 == env31605) = true)

def env31606 : List Nat := [2,4,8,16,32,1,128,256,512,1024,2048,1556,24,1297,260,65536,66614,65664,1812,261,1556,649,65831,66833,901,66082,1086,66599,1296,68359,20,65830,257,1280,1281,276]

theorem envBound31606 : H12AffineFastState.Bounded env31606 := by
  intro p hp
  have h : env31606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31591_31606 : H12AffineEnvironment.transform 5 1 env31591 = env31606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env31591 == env31606) = true)

theorem identity31606 : scanCanonicalize (H12AffineFastState.compose env31606 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 21) := by decide +kernel

theorem selectedBound31606 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env31607 : List Nat := [2,4,8,16,32,1,128,256,512,1024,2048,1556,24,1297,260,21,1059,149,1812,261,1556,649,306,1284,901,567,1086,1074,1296,2834,20,307,257,1280,1281,276]

theorem envBound31607 : H12AffineFastState.Bounded env31607 := by
  intro p hp
  have h : env31607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31606_31607 : H12AffineEnvironment.transform 15 21 env31606 = env31607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21 env31606 == env31607) = true)

def env31608 : List Nat := [2,4,8,16,32,1,128,256,512,272,2048,772,24,1,260,21,307,149,516,261,772,649,306,20,901,567,302,290,0,2834,20,307,257,16,17,276]

theorem envBound31608 : H12AffineFastState.Bounded env31608 := by
  intro p hp
  have h : env31608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31607_31608 : H12AffineEnvironment.transform 9 272 env31607 = env31608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env31607 == env31608) = true)

theorem identity31608 : scanCanonicalize (H12AffineFastState.compose env31608 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 306) := by decide +kernel

theorem selectedBound31608 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env31609 : List Nat := [2,4,8,16,32,1,128,256,306,272,2048,54,24,1,260,21,307,149,310,261,54,443,306,20,183,261,302,290,0,2080,20,307,257,16,17,276]

theorem envBound31609 : H12AffineFastState.Bounded env31609 := by
  intro p hp
  have h : env31609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31608_31609 : H12AffineEnvironment.transform 8 306 env31608 = env31609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 306 env31608 == env31609) = true)

theorem identity31609 : scanCanonicalize (H12AffineFastState.compose env31609 (packedSelected [0,1,2,3,7,10,12,17,20] rootPS)) = affineNative (2^(10+1) ^^^ 287) := by decide +kernel

theorem selectedBound31609 : packedSelected [0,1,2,3,7,10,12,17,20] rootPS < 2^1333 := by decide +kernel

def env31610 : List Nat := [2,4,8,16,32,1,128,256,306,272,287,54,24,1,260,21,307,149,310,261,54,443,306,20,183,261,302,290,0,319,20,307,257,16,17,276]

theorem envBound31610 : H12AffineFastState.Bounded env31610 := by
  intro p hp
  have h : env31610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31609_31610 : H12AffineEnvironment.transform 10 287 env31609 = env31610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 287 env31609 == env31610) = true)

theorem identity31610 : scanCanonicalize (H12AffineFastState.compose env31610 (packedSelected [0,3,7,8,11,12,15,17] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound31610 : packedSelected [0,3,7,8,11,12,15,17] rootPS < 2^1333 := by decide +kernel

def env31611 : List Nat := [2,4,8,16,32,1,5,256,306,272,287,54,24,1,260,21,307,16,310,261,54,318,306,20,50,261,302,290,0,319,20,307,257,16,17,276]

theorem envBound31611 : H12AffineFastState.Bounded env31611 := by
  intro p hp
  have h : env31611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31610_31611 : H12AffineEnvironment.transform 6 5 env31610 = env31611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env31610 == env31611) = true)

theorem identity31611 : scanCanonicalize (H12AffineFastState.compose env31611 (packedSelected [0,1,2,3,5,7,8,11] rootPS)) = affineNative (2^(7+1) ^^^ 41) := by decide +kernel

theorem selectedBound31611 : packedSelected [0,1,2,3,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env31612 : List Nat := [2,4,8,16,32,1,5,41,27,57,54,54,24,1,45,21,26,16,31,44,54,23,27,20,50,44,7,11,0,22,20,26,40,16,17,61]

theorem envBound31612 : H12AffineFastState.Bounded env31612 := by
  intro p hp
  have h : env31612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31611_31612 : H12AffineEnvironment.transform 7 41 env31611 = env31612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 41 env31611 == env31612) = true)

theorem identity31612 : scanCanonicalize (H12AffineFastState.compose env31612 (packedSelected [0,2,3,4,5,8] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound31612 : packedSelected [0,2,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env31613 : List Nat := [2,4,4,16,32,1,5,37,23,53,54,54,20,1,33,21,22,16,19,32,54,23,23,20,50,32,7,7,0,22,20,22,36,16,17,49]

theorem envBound31613 : H12AffineFastState.Bounded env31613 := by
  intro p hp
  have h : env31613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31612_31613 : H12AffineEnvironment.transform 2 4 env31612 = env31613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env31612 == env31613) = true)

theorem identity31613 : scanCanonicalize (H12AffineFastState.compose env31613 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound31613 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env31614 : List Nat := [2,4,4,0,32,1,5,37,7,37,38,38,4,1,33,5,6,0,3,32,38,7,7,4,34,32,7,7,0,6,4,6,36,0,1,33]

theorem envBound31614 : H12AffineFastState.Bounded env31614 := by
  intro p hp
  have h : env31614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31613_31614 : H12AffineEnvironment.transform 3 0 env31613 = env31614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env31613 == env31614) = true)

theorem identity31614 : scanCanonicalize (H12AffineFastState.compose env31614 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound31614 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env31615 : List Nat := [2,4,4,0,1,1,5,4,7,4,7,7,4,1,0,5,6,0,3,1,7,7,7,4,3,1,7,7,0,6,4,6,5,0,1,0]

theorem envBound31615 : H12AffineFastState.Bounded env31615 := by
  intro p hp
  have h : env31615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31614_31615 : H12AffineEnvironment.transform 4 1 env31614 = env31615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env31614 == env31615) = true)

def env31616 : List Nat := [2,4,8,16,32,1,128,256,512,273,2048,773,24,0,260,21,306,149,517,261,773,649,306,21,901,567,303,291,1,2834,20,307,257,17,16,276]

theorem envBound31616 : H12AffineFastState.Bounded env31616 := by
  intro p hp
  have h : env31616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31607_31616 : H12AffineEnvironment.transform 9 273 env31607 = env31616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env31607 == env31616) = true)

theorem identity31616 : scanCanonicalize (H12AffineFastState.compose env31616 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound31616 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env31617 : List Nat := [2,4,8,16,7,1,128,256,512,273,2048,773,24,0,260,21,277,149,517,261,773,649,277,21,901,528,264,260,1,2834,20,276,257,17,16,276]

theorem envBound31617 : H12AffineFastState.Bounded env31617 := by
  intro p hp
  have h : env31617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31616_31617 : H12AffineEnvironment.transform 4 7 env31616 = env31617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env31616 == env31617) = true)

theorem identity31617 : scanCanonicalize (H12AffineFastState.compose env31617 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound31617 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env31618 : List Nat := [2,4,8,16,7,1,128,256,260,273,2048,1,24,0,260,21,277,149,257,261,1,397,277,21,129,276,264,260,1,2070,20,276,257,17,16,276]

theorem envBound31618 : H12AffineFastState.Bounded env31618 := by
  intro p hp
  have h : env31618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31617_31618 : H12AffineEnvironment.transform 8 260 env31617 = env31618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env31617 == env31618) = true)

theorem identity31618 : scanCanonicalize (H12AffineFastState.compose env31618 (packedSelected [0,3,5,7,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound31618 : packedSelected [0,3,5,7,10,11] rootPS < 2^1333 := by decide +kernel

def env31619 : List Nat := [2,4,8,16,7,1,128,256,260,273,1,1,24,0,260,21,277,149,257,261,1,397,277,21,129,276,264,260,1,23,20,276,257,17,16,276]

theorem envBound31619 : H12AffineFastState.Bounded env31619 := by
  intro p hp
  have h : env31619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31618_31619 : H12AffineEnvironment.transform 10 1 env31618 = env31619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env31618 == env31619) = true)

theorem identity31619 : scanCanonicalize (H12AffineFastState.compose env31619 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound31619 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env31620 : List Nat := [2,4,8,0,7,1,128,256,260,257,1,1,8,0,260,5,261,133,257,261,1,397,261,5,129,260,264,260,1,7,4,260,257,1,0,260]

theorem envBound31620 : H12AffineFastState.Bounded env31620 := by
  intro p hp
  have h : env31620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31619_31620 : H12AffineEnvironment.transform 3 0 env31619 = env31620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env31619 == env31620) = true)

theorem identity31620 : scanCanonicalize (H12AffineFastState.compose env31620 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound31620 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31621 : List Nat := [2,4,8,0,7,1,8,256,260,257,1,1,8,0,260,5,261,13,257,261,1,261,261,5,9,260,264,260,1,7,4,260,257,1,0,260]

theorem envBound31621 : H12AffineFastState.Bounded env31621 := by
  intro p hp
  have h : env31621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31620_31621 : H12AffineEnvironment.transform 6 8 env31620 = env31621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env31620 == env31621) = true)

theorem identity31621 : scanCanonicalize (H12AffineFastState.compose env31621 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound31621 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31622 : List Nat := [2,4,2,0,7,1,2,256,260,257,1,1,2,0,260,5,261,7,257,261,1,261,261,5,3,260,258,260,1,7,4,260,257,1,0,260]

theorem envBound31622 : H12AffineFastState.Bounded env31622 := by
  intro p hp
  have h : env31622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31621_31622 : H12AffineEnvironment.transform 2 2 env31621 = env31622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env31621 == env31622) = true)

theorem identity31622 : scanCanonicalize (H12AffineFastState.compose env31622 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound31622 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env31623 : List Nat := [2,2,2,0,1,1,2,256,258,257,1,1,2,0,258,3,259,1,257,259,1,259,259,3,3,258,258,258,1,1,2,258,257,1,0,258]

theorem envBound31623 : H12AffineFastState.Bounded env31623 := by
  intro p hp
  have h : env31623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31622_31623 : H12AffineEnvironment.transform 1 2 env31622 = env31623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env31622 == env31623) = true)

theorem identity31623 : scanCanonicalize (H12AffineFastState.compose env31623 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 3) := by decide +kernel

theorem selectedBound31623 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31624 : List Nat := [2,2,2,0,1,1,2,3,1,2,1,1,2,0,1,3,0,1,2,0,1,0,0,3,3,1,1,1,1,1,2,1,2,1,0,1]

theorem envBound31624 : H12AffineFastState.Bounded env31624 := by
  intro p hp
  have h : env31624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31623_31624 : H12AffineEnvironment.transform 7 3 env31623 = env31624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 3 env31623 == env31624) = true)

def env31625 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1557,24,1297,325,65536,66679,65664,1876,324,1557,648,65831,66896,965,66083,1151,66599,1296,68423,20,65830,257,1280,1344,340]

theorem envBound31625 : H12AffineFastState.Bounded env31625 := by
  intro p hp
  have h : env31625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31590_31625 : H12AffineEnvironment.transform 11 1557 env31590 = env31625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1557 env31590 == env31625) = true)

def env31626 : List Nat := [2,4,8,16,32,0,128,256,512,1024,2048,1557,24,1297,261,65536,66615,65664,1812,260,1557,648,65831,66832,901,66083,1087,66599,1296,68359,20,65830,257,1280,1280,276]

theorem envBound31626 : H12AffineFastState.Bounded env31626 := by
  intro p hp
  have h : env31626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31625_31626 : H12AffineEnvironment.transform 5 0 env31625 = env31626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env31625 == env31626) = true)

theorem identity31626 : scanCanonicalize (H12AffineFastState.compose env31626 (packedSelected [1,8,28] rootPS)) = affineNative (2^(9+1) ^^^ 50) := by decide +kernel

theorem selectedBound31626 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env31627 : List Nat := [2,4,8,16,32,0,128,256,512,50,2048,551,24,291,261,65536,65541,65664,806,260,551,648,65831,65826,901,66083,13,65557,290,68359,20,65830,257,306,306,276]

theorem envBound31627 : H12AffineFastState.Bounded env31627 := by
  intro p hp
  have h : env31627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31626_31627 : H12AffineEnvironment.transform 9 50 env31626 = env31627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 50 env31626 == env31627) = true)

def env31628 : List Nat := [2,4,8,16,32,0,128,256,512,50,2048,551,24,291,261,304,309,432,806,260,551,648,23,18,901,787,13,293,290,2615,20,22,257,306,306,276]

theorem envBound31628 : H12AffineFastState.Bounded env31628 := by
  intro p hp
  have h : env31628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31627_31628 : H12AffineEnvironment.transform 15 304 env31627 = env31628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 304 env31627 == env31628) = true)

theorem identity31628 : scanCanonicalize (H12AffineFastState.compose env31628 (packedSelected [0,1,3,4,7,8,9,10,15,16,19,20,41] rootPS)) = affineNative (2^(8+1) ^^^ 411) := by decide +kernel

theorem selectedBound31628 : packedSelected [0,1,3,4,7,8,9,10,15,16,19,20,41] rootPS < 2^1333 := by decide +kernel

def env31629 : List Nat := [2,4,8,16,32,0,128,256,411,50,2048,444,24,291,261,304,309,432,189,260,444,275,23,18,30,136,13,293,290,2476,20,22,257,306,306,276]

theorem envBound31629 : H12AffineFastState.Bounded env31629 := by
  intro p hp
  have h : env31629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31628_31629 : H12AffineEnvironment.transform 8 411 env31628 = env31629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 411 env31628 == env31629) = true)

theorem identity31629 : scanCanonicalize (H12AffineFastState.compose env31629 (packedSelected [0,3,4,5,7,9,10,11,13,17,18,19,20,21] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound31629 : packedSelected [0,3,4,5,7,9,10,11,13,17,18,19,20,21] rootPS < 2^1333 := by decide +kernel

def env31630 : List Nat := [2,4,4,16,32,0,128,256,407,50,2048,432,20,291,261,304,309,432,177,260,432,275,23,18,18,132,1,293,290,2464,20,22,257,306,306,276]

theorem envBound31630 : H12AffineFastState.Bounded env31630 := by
  intro p hp
  have h : env31630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31629_31630 : H12AffineEnvironment.transform 2 4 env31629 = env31630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env31629 == env31630) = true)

theorem identity31630 : scanCanonicalize (H12AffineFastState.compose env31630 (packedSelected [0,1,3,4,10,12,13,16] rootPS)) = affineNative (2^(10+1) ^^^ 385) := by decide +kernel

theorem selectedBound31630 : packedSelected [0,1,3,4,10,12,13,16] rootPS < 2^1333 := by decide +kernel

def env31631 : List Nat := [2,4,4,16,32,0,128,256,407,50,385,432,20,291,261,304,309,432,177,260,432,275,23,18,18,132,1,293,290,33,20,22,257,306,306,276]

theorem envBound31631 : H12AffineFastState.Bounded env31631 := by
  intro p hp
  have h : env31631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31630_31631 : H12AffineEnvironment.transform 10 385 env31630 = env31631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 385 env31630 == env31631) = true)

def env31632 : List Nat := [2,4,8,16,32,0,128,256,512,50,2048,551,24,291,261,305,308,433,806,260,551,648,22,19,901,786,13,292,290,2614,20,23,257,306,306,276]

theorem envBound31632 : H12AffineFastState.Bounded env31632 := by
  intro p hp
  have h : env31632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31627_31632 : H12AffineEnvironment.transform 15 305 env31627 = env31632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 305 env31627 == env31632) = true)

theorem identity31632 : scanCanonicalize (H12AffineFastState.compose env31632 (packedSelected [0,1,3,4,7,8,9,10,15,16,19,20,41] rootPS)) = affineNative (2^(8+1) ^^^ 412) := by decide +kernel

theorem selectedBound31632 : packedSelected [0,1,3,4,7,8,9,10,15,16,19,20,41] rootPS < 2^1333 := by decide +kernel

def env31633 : List Nat := [2,4,8,16,32,0,128,256,412,50,2048,443,24,291,261,305,308,433,186,260,443,276,22,19,25,142,13,292,290,2474,20,23,257,306,306,276]

theorem envBound31633 : H12AffineFastState.Bounded env31633 := by
  intro p hp
  have h : env31633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31632_31633 : H12AffineEnvironment.transform 8 412 env31632 = env31633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 412 env31632 == env31633) = true)

theorem identity31633 : scanCanonicalize (H12AffineFastState.compose env31633 (packedSelected [2,3,10,11,13,18] rootPS)) = affineNative (2^(10+1) ^^^ 29) := by decide +kernel

theorem selectedBound31633 : packedSelected [2,3,10,11,13,18] rootPS < 2^1333 := by decide +kernel

def env31634 : List Nat := [2,4,8,16,32,0,128,256,412,50,29,443,24,291,261,305,308,433,186,260,443,276,22,19,25,142,13,292,290,439,20,23,257,306,306,276]

theorem envBound31634 : H12AffineFastState.Bounded env31634 := by
  intro p hp
  have h : env31634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31633_31634 : H12AffineEnvironment.transform 10 29 env31633 = env31634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 29 env31633 == env31634) = true)

theorem identity31634 : scanCanonicalize (H12AffineFastState.compose env31634 (packedSelected [0,9,10,11,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 140) := by decide +kernel

theorem selectedBound31634 : packedSelected [0,9,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env31635 : List Nat := [2,4,8,16,32,0,128,140,16,50,29,55,24,175,137,189,184,61,186,136,55,152,22,19,25,142,13,168,174,59,20,23,141,190,190,152]

theorem envBound31635 : H12AffineFastState.Bounded env31635 := by
  intro p hp
  have h : env31635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31634_31635 : H12AffineEnvironment.transform 7 140 env31634 = env31635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 140 env31634 == env31635) = true)

theorem identity31635 : scanCanonicalize (H12AffineFastState.compose env31635 (packedSelected [0,1,5,8,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound31635 : packedSelected [0,1,5,8,9] rootPS < 2^1333 := by decide +kernel

def env31636 : List Nat := [2,4,8,16,1,0,128,140,16,19,29,22,24,142,137,156,153,28,155,136,22,152,22,19,25,142,13,137,143,26,20,23,141,159,159,152]

theorem envBound31636 : H12AffineFastState.Bounded env31636 := by
  intro p hp
  have h : env31636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31635_31636 : H12AffineEnvironment.transform 4 1 env31635 = env31636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env31635 == env31636) = true)

theorem identity31636 : scanCanonicalize (H12AffineFastState.compose env31636 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 15) := by decide +kernel

theorem selectedBound31636 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env31637 : List Nat := [2,4,8,16,1,0,15,3,16,19,29,22,24,1,6,19,22,28,20,7,22,23,22,19,25,1,13,6,0,26,20,23,2,16,16,23]

theorem envBound31637 : H12AffineFastState.Bounded env31637 := by
  intro p hp
  have h : env31637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31636_31637 : H12AffineEnvironment.transform 6 15 env31636 = env31637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 15 env31636 == env31637) = true)

theorem identity31637 : scanCanonicalize (H12AffineFastState.compose env31637 (packedSelected [1,2,3] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound31637 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env31638 : List Nat := [2,4,4,16,1,0,3,3,16,19,17,22,20,1,6,19,22,16,20,7,22,23,22,19,21,1,1,6,0,22,20,23,2,16,16,23]

theorem envBound31638 : H12AffineFastState.Bounded env31638 := by
  intro p hp
  have h : env31638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31637_31638 : H12AffineEnvironment.transform 2 4 env31637 = env31638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env31637 == env31638) = true)

theorem identity31638 : scanCanonicalize (H12AffineFastState.compose env31638 (packedSelected [1,2] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound31638 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env31639 : List Nat := [2,4,4,6,1,0,3,3,6,5,7,0,2,1,6,5,0,6,2,7,0,1,0,5,3,1,1,6,0,0,2,1,2,6,6,1]

theorem envBound31639 : H12AffineFastState.Bounded env31639 := by
  intro p hp
  have h : env31639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31638_31639 : H12AffineEnvironment.transform 3 6 env31638 = env31639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env31638 == env31639) = true)

def env31640 : List Nat := [2,4,8,16,32,1,128,256,512,1024,2048,1557,24,1297,260,65536,66614,65664,1813,261,1557,648,65831,66833,900,66083,1086,66599,1296,68358,20,65830,257,1280,1281,277]

theorem envBound31640 : H12AffineFastState.Bounded env31640 := by
  intro p hp
  have h : env31640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31625_31640 : H12AffineEnvironment.transform 5 1 env31625 = env31640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env31625 == env31640) = true)

theorem identity31640 : scanCanonicalize (H12AffineFastState.compose env31640 (packedSelected [1,8,28] rootPS)) = affineNative (2^(7+1) ^^^ 34) := by decide +kernel

theorem selectedBound31640 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env31641 : List Nat := [2,4,8,16,32,1,128,34,512,1024,2048,1557,24,1075,38,65536,66614,65664,1591,39,1557,648,65541,66611,678,66083,1086,66599,1074,68132,20,65540,35,1058,1059,55]

theorem envBound31641 : H12AffineFastState.Bounded env31641 := by
  intro p hp
  have h : env31641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31640_31641 : H12AffineEnvironment.transform 7 34 env31640 = env31641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 34 env31640 == env31641) = true)

def env31642 : List Nat := [2,4,8,16,32,1,128,34,512,56,2048,557,24,11,38,65536,65550,65664,527,39,557,648,65541,65547,678,66083,6,65567,10,68132,20,65540,35,26,27,55]

theorem envBound31642 : H12AffineFastState.Bounded env31642 := by
  intro p hp
  have h : env31642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31641_31642 : H12AffineEnvironment.transform 9 56 env31641 = env31642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 56 env31641 == env31642) = true)

theorem identity31642 : scanCanonicalize (H12AffineFastState.compose env31642 (packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS)) = affineNative (2^(6+1) ^^^ 52) := by decide +kernel

theorem selectedBound31642 : packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS < 2^1333 := by decide +kernel

def env31643 : List Nat := [2,4,8,16,32,1,52,34,512,56,2048,557,24,11,38,65536,65550,65588,527,39,557,572,65541,65547,530,66083,6,65567,10,68132,20,65540,35,26,27,55]

theorem envBound31643 : H12AffineFastState.Bounded env31643 := by
  intro p hp
  have h : env31643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31642_31643 : H12AffineEnvironment.transform 6 52 env31642 = env31643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 52 env31642 == env31643) = true)

theorem identity31643 : scanCanonicalize (H12AffineFastState.compose env31643 (packedSelected [0,2,5,7,8,11,12,13,16,21,23] rootPS)) = affineNative (2^(15+1) ^^^ 2105) := by decide +kernel

theorem selectedBound31643 : packedSelected [0,2,5,7,8,11,12,13,16,21,23] rootPS < 2^1333 := by decide +kernel

def env31644 : List Nat := [2,4,8,16,32,1,52,34,512,56,2048,557,24,11,38,2105,2103,2061,527,39,557,572,2108,2098,530,2586,6,2086,10,541,20,2109,35,26,27,55]

theorem envBound31644 : H12AffineFastState.Bounded env31644 := by
  intro p hp
  have h : env31644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31643_31644 : H12AffineEnvironment.transform 15 2105 env31643 = env31644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2105 env31643 == env31644) = true)

theorem identity31644 : scanCanonicalize (H12AffineFastState.compose env31644 (packedSelected [0,2,3,4,10,11,12,13,16,17] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound31644 : packedSelected [0,2,3,4,10,11,12,13,16,17] rootPS < 2^1333 := by decide +kernel

def env31645 : List Nat := [2,4,8,16,32,1,52,34,512,56,42,557,24,11,38,19,29,39,527,39,557,572,22,24,530,560,6,12,10,541,20,23,35,26,27,55]

theorem envBound31645 : H12AffineFastState.Bounded env31645 := by
  intro p hp
  have h : env31645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31644_31645 : H12AffineEnvironment.transform 10 42 env31644 = env31645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env31644 == env31645) = true)

theorem identity31645 : scanCanonicalize (H12AffineFastState.compose env31645 (packedSelected [3,5,7,8,9,11] rootPS)) = affineNative (2^(4+1) ^^^ 28) := by decide +kernel

theorem selectedBound31645 : packedSelected [3,5,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env31646 : List Nat := [2,4,8,16,28,1,8,30,512,4,22,529,24,11,26,19,29,27,527,27,529,512,22,24,530,524,6,12,10,541,20,23,31,26,27,11]

theorem envBound31646 : H12AffineFastState.Bounded env31646 := by
  intro p hp
  have h : env31646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31645_31646 : H12AffineEnvironment.transform 4 28 env31645 = env31646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 28 env31645 == env31646) = true)

theorem identity31646 : scanCanonicalize (H12AffineFastState.compose env31646 (packedSelected [0,2,3,4,5,8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound31646 : packedSelected [0,2,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env31647 : List Nat := [2,4,8,0,12,1,8,14,512,4,6,513,8,11,10,3,13,11,527,11,513,512,6,8,514,524,6,12,10,525,4,7,15,10,11,11]

theorem envBound31647 : H12AffineFastState.Bounded env31647 := by
  intro p hp
  have h : env31647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31646_31647 : H12AffineEnvironment.transform 3 0 env31646 = env31647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env31646 == env31647) = true)

def env31648 : List Nat := [2,4,8,16,32,1,128,34,512,57,2048,556,24,10,38,65536,65551,65664,526,39,556,648,65541,65546,678,66083,7,65566,11,68132,20,65540,35,27,26,55]

theorem envBound31648 : H12AffineFastState.Bounded env31648 := by
  intro p hp
  have h : env31648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31641_31648 : H12AffineEnvironment.transform 9 57 env31641 = env31648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 57 env31641 == env31648) = true)

theorem identity31648 : scanCanonicalize (H12AffineFastState.compose env31648 (packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS)) = affineNative (2^(6+1) ^^^ 63) := by decide +kernel

theorem selectedBound31648 : packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS < 2^1333 := by decide +kernel

def env31649 : List Nat := [2,4,8,16,32,1,63,34,512,57,2048,556,24,10,38,65536,65551,65599,526,39,556,567,65541,65546,537,66083,7,65566,11,68132,20,65540,35,27,26,55]

theorem envBound31649 : H12AffineFastState.Bounded env31649 := by
  intro p hp
  have h : env31649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31648_31649 : H12AffineEnvironment.transform 6 63 env31648 = env31649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 63 env31648 == env31649) = true)

theorem identity31649 : scanCanonicalize (H12AffineFastState.compose env31649 (packedSelected [0,2,3,4,5,7,10,11,12,15,16,17,18,19,20,21,27] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound31649 : packedSelected [0,2,3,4,5,7,10,11,12,15,16,17,18,19,20,21,27] rootPS < 2^1333 := by decide +kernel

def env31650 : List Nat := [2,4,8,16,32,1,63,34,512,57,2048,556,24,10,38,34,45,29,526,39,556,567,39,40,537,513,7,60,11,2566,20,38,35,27,26,55]

theorem envBound31650 : H12AffineFastState.Bounded env31650 := by
  intro p hp
  have h : env31650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31649_31650 : H12AffineEnvironment.transform 15 34 env31649 = env31650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env31649 == env31650) = true)

theorem identity31650 : scanCanonicalize (H12AffineFastState.compose env31650 (packedSelected [0,1,3,5,7,8,10,13,18] rootPS)) = affineNative (2^(10+1) ^^^ 560) := by decide +kernel

theorem selectedBound31650 : packedSelected [0,1,3,5,7,8,10,13,18] rootPS < 2^1333 := by decide +kernel

def env31651 : List Nat := [2,4,8,16,32,1,63,34,512,57,560,556,24,10,38,34,45,29,526,39,556,567,39,40,537,513,7,60,11,54,20,38,35,27,26,55]

theorem envBound31651 : H12AffineFastState.Bounded env31651 := by
  intro p hp
  have h : env31651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31650_31651 : H12AffineEnvironment.transform 10 560 env31650 = env31651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 560 env31650 == env31651) = true)

theorem identity31651 : scanCanonicalize (H12AffineFastState.compose env31651 (packedSelected [1,3,4,5,8,9,10] rootPS)) = affineNative (2^(8+1) ^^^ 45) := by decide +kernel

theorem selectedBound31651 : packedSelected [1,3,4,5,8,9,10] rootPS < 2^1333 := by decide +kernel

def env31652 : List Nat := [2,4,8,16,32,1,63,34,45,57,29,1,24,10,38,34,45,29,35,39,1,26,39,40,52,44,7,60,11,54,20,38,35,27,26,55]

theorem envBound31652 : H12AffineFastState.Bounded env31652 := by
  intro p hp
  have h : env31652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31651_31652 : H12AffineEnvironment.transform 8 45 env31651 = env31652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 45 env31651 == env31652) = true)

theorem identity31652 : scanCanonicalize (H12AffineFastState.compose env31652 (packedSelected [0,4,5,8] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound31652 : packedSelected [0,4,5,8] rootPS < 2^1333 := by decide +kernel

def env31653 : List Nat := [2,4,8,10,32,1,37,34,45,35,7,1,2,10,38,34,45,7,35,39,1,0,39,40,46,44,7,38,11,44,14,38,35,1,0,45]

theorem envBound31653 : H12AffineFastState.Bounded env31653 := by
  intro p hp
  have h : env31653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31652_31653 : H12AffineEnvironment.transform 3 10 env31652 = env31653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env31652 == env31653) = true)

theorem identity31653 : scanCanonicalize (H12AffineFastState.compose env31653 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound31653 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env31654 : List Nat := [2,4,5,7,32,1,37,34,32,35,7,1,2,7,38,34,32,7,35,39,1,0,39,37,35,33,7,38,6,33,3,38,35,1,0,32]

theorem envBound31654 : H12AffineFastState.Bounded env31654 := by
  intro p hp
  have h : env31654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31653_31654 : H12AffineEnvironment.transform 2 5 env31653 = env31654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env31653 == env31654) = true)

theorem identity31654 : scanCanonicalize (H12AffineFastState.compose env31654 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound31654 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31655 : List Nat := [2,4,5,7,7,1,2,5,7,4,7,1,2,7,1,5,7,7,4,0,1,0,0,2,4,6,7,1,6,6,3,1,4,1,0,7]

theorem envBound31655 : H12AffineFastState.Bounded env31655 := by
  intro p hp
  have h : env31655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31654_31655 : H12AffineEnvironment.transform 4 7 env31654 = env31655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env31654 == env31655) = true)

theorem identity31655 : scanCanonicalize (H12AffineFastState.compose env31655 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound31655 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31656 : List Nat := [2,3,2,0,0,1,2,2,0,3,0,1,2,0,1,2,0,0,3,0,1,0,0,2,3,1,0,1,1,1,3,1,3,1,0,0]

theorem envBound31656 : H12AffineFastState.Bounded env31656 := by
  intro p hp
  have h : env31656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31655_31656 : H12AffineEnvironment.transform 1 3 env31655 = env31656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env31655 == env31656) = true)

def env31657 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74863,65665,4417,8540,4096,5277,74047,66896,13768,78894,1150,74815,1296,81226,8204,65830,257,1280,1344,5953]

theorem envBound31657 : H12AffineFastState.Bounded env31657 := by
  intro p hp
  have h : env31657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31588_31657 : H12AffineEnvironment.transform 17 65665 env31588 = env31657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env31588 == env31657) = true)

theorem identity31657 : scanCanonicalize (H12AffineFastState.compose env31657 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5464) := by decide +kernel

theorem selectedBound31657 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env31658 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5464,1297,5125,65536,69943,65665,4417,5124,4096,5277,70759,66896,144,65910,1150,69991,1296,67602,5460,65830,257,1280,1344,5953]

theorem envBound31658 : H12AffineFastState.Bounded env31658 := by
  intro p hp
  have h : env31658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31657_31658 : H12AffineEnvironment.transform 12 5464 env31657 = env31658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5464 env31657 == env31658) = true)

def env31659 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1556,844,1297,529,65536,67363,65665,1877,528,1556,649,66163,66896,144,65910,1150,67443,1296,67602,832,65830,257,1280,1344,341]

theorem envBound31659 : H12AffineFastState.Bounded env31659 := by
  intro p hp
  have h : env31659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31658_31659 : H12AffineEnvironment.transform 11 1556 env31658 = env31659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1556 env31658 == env31659) = true)

def env31660 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,836,844,65,529,65536,66163,65665,517,528,836,649,66163,65536,144,65910,302,66083,64,67602,832,65830,257,80,16,341]

theorem envBound31660 : H12AffineFastState.Bounded env31660 := by
  intro p hp
  have h : env31660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31659_31660 : H12AffineEnvironment.transform 9 336 env31659 = env31660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 336 env31659 == env31660) = true)

theorem identity31660 : scanCanonicalize (H12AffineFastState.compose env31660 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 20) := by decide +kernel

theorem selectedBound31660 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env31661 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,836,844,65,529,20,615,149,517,528,836,649,615,20,144,354,302,567,64,2054,832,306,257,80,16,341]

theorem envBound31661 : H12AffineFastState.Bounded env31661 := by
  intro p hp
  have h : env31661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31660_31661 : H12AffineEnvironment.transform 15 20 env31660 = env31661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 20 env31660 == env31661) = true)

def env31662 : List Nat := [2,4,8,16,32,64,128,256,112,336,2048,308,316,65,97,20,23,149,117,96,308,249,23,20,144,354,302,71,64,2054,304,306,257,80,16,341]

theorem envBound31662 : H12AffineFastState.Bounded env31662 := by
  intro p hp
  have h : env31662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31661_31662 : H12AffineEnvironment.transform 8 112 env31661 = env31662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 112 env31661 == env31662) = true)

theorem identity31662 : scanCanonicalize (H12AffineFastState.compose env31662 (packedSelected [0,5,15,27,41] rootPS)) = affineNative (2^(7+1) ^^^ 205) := by decide +kernel

theorem selectedBound31662 : packedSelected [0,5,15,27,41] rootPS < 2^1333 := by decide +kernel

def env31663 : List Nat := [2,4,8,16,32,64,128,205,112,157,2048,249,241,65,97,20,23,149,117,96,249,249,23,20,144,175,227,71,64,2054,253,255,204,80,16,152]

theorem envBound31663 : H12AffineFastState.Bounded env31663 := by
  intro p hp
  have h : env31663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31662_31663 : H12AffineEnvironment.transform 7 205 env31662 = env31663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 205 env31662 == env31663) = true)

theorem identity31663 : scanCanonicalize (H12AffineFastState.compose env31663 (packedSelected [0,1,3,4,5,7,9,11,13,23] rootPS)) = affineNative (2^(10+1) ^^^ 223) := by decide +kernel

theorem selectedBound31663 : packedSelected [0,1,3,4,5,7,9,11,13,23] rootPS < 2^1333 := by decide +kernel

def env31664 : List Nat := [2,4,8,16,32,64,128,205,112,157,223,249,241,65,97,20,23,149,117,96,249,249,23,20,144,175,227,71,64,217,253,255,204,80,16,152]

theorem envBound31664 : H12AffineFastState.Bounded env31664 := by
  intro p hp
  have h : env31664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31663_31664 : H12AffineEnvironment.transform 10 223 env31663 = env31664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 223 env31663 == env31664) = true)

theorem identity31664 : scanCanonicalize (H12AffineFastState.compose env31664 (packedSelected [1,2,8,11,12,13] rootPS)) = affineNative (2^(5+1) ^^^ 55) := by decide +kernel

theorem selectedBound31664 : packedSelected [1,2,8,11,12,13] rootPS < 2^1333 := by decide +kernel

def env31665 : List Nat := [2,4,8,16,32,55,128,186,7,157,168,142,134,54,22,20,23,149,2,23,142,142,23,20,144,175,148,48,55,174,138,136,187,39,16,152]

theorem envBound31665 : H12AffineFastState.Bounded env31665 := by
  intro p hp
  have h : env31665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31664_31665 : H12AffineEnvironment.transform 5 55 env31664 = env31665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 55 env31664 == env31665) = true)

theorem identity31665 : scanCanonicalize (H12AffineFastState.compose env31665 (packedSelected [0,1,2,8,9,11] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound31665 : packedSelected [0,1,2,8,9,11] rootPS < 2^1333 := by decide +kernel

def env31666 : List Nat := [2,4,8,13,32,42,128,167,7,128,168,142,134,43,11,9,10,136,2,10,142,142,10,9,141,175,137,45,42,174,138,136,166,39,13,133]

theorem envBound31666 : H12AffineFastState.Bounded env31666 := by
  intro p hp
  have h : env31666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31665_31666 : H12AffineEnvironment.transform 3 13 env31665 = env31666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env31665 == env31666) = true)

theorem identity31666 : scanCanonicalize (H12AffineFastState.compose env31666 (packedSelected [0,2,3,4,5,8] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound31666 : packedSelected [0,2,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env31667 : List Nat := [2,4,8,13,7,13,128,128,7,128,143,142,134,12,11,9,10,136,2,10,142,142,10,9,141,136,137,10,13,137,138,136,129,0,13,133]

theorem envBound31667 : H12AffineFastState.Bounded env31667 := by
  intro p hp
  have h : env31667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31666_31667 : H12AffineEnvironment.transform 4 7 env31666 = env31667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env31666 == env31667) = true)

theorem identity31667 : scanCanonicalize (H12AffineFastState.compose env31667 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound31667 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env31668 : List Nat := [2,4,3,6,7,6,128,128,7,128,132,133,134,7,0,2,1,131,2,1,133,133,1,2,134,131,130,1,6,130,129,131,129,0,6,133]

theorem envBound31668 : H12AffineFastState.Bounded env31668 := by
  intro p hp
  have h : env31668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31667_31668 : H12AffineEnvironment.transform 2 3 env31667 = env31668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env31667 == env31668) = true)

theorem identity31668 : scanCanonicalize (H12AffineFastState.compose env31668 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound31668 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31669 : List Nat := [2,4,3,6,7,6,5,5,7,5,1,0,3,7,0,2,1,6,2,1,0,0,1,2,3,6,7,1,6,7,4,6,4,0,6,0]

theorem envBound31669 : H12AffineFastState.Bounded env31669 := by
  intro p hp
  have h : env31669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31668_31669 : H12AffineEnvironment.transform 6 5 env31668 = env31669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env31668 == env31669) = true)

theorem identity31669 : scanCanonicalize (H12AffineFastState.compose env31669 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound31669 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31670 : List Nat := [2,2,3,0,1,0,3,3,1,3,1,0,3,1,0,2,1,0,2,1,0,0,1,2,3,0,1,1,0,1,2,0,2,0,0,0]

theorem envBound31670 : H12AffineFastState.Bounded env31670 := by
  intro p hp
  have h : env31670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31669_31670 : H12AffineEnvironment.transform 1 2 env31669 = env31670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env31669 == env31670) = true)

theorem identity31670 : scanCanonicalize (H12AffineFastState.compose env31670 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound31670 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31671 : List Nat := [1,1,0,0,1,0,0,0,1,0,1,0,0,1,0,1,1,0,1,1,0,0,1,1,0,0,1,1,0,1,1,0,1,0,0,0]

theorem envBound31671 : H12AffineFastState.Bounded env31671 := by
  intro p hp
  have h : env31671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31670_31671 : H12AffineEnvironment.transform 0 1 env31670 = env31671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env31670 == env31671) = true)

def env31672 : List Nat := [2,4,8,16,32,64,128,256,113,336,2048,309,317,65,96,20,22,149,116,97,309,248,22,20,144,354,302,70,64,2054,305,306,257,80,16,341]

theorem envBound31672 : H12AffineFastState.Bounded env31672 := by
  intro p hp
  have h : env31672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31661_31672 : H12AffineEnvironment.transform 8 113 env31661 = env31672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 113 env31661 == env31672) = true)

theorem identity31672 : scanCanonicalize (H12AffineFastState.compose env31672 (packedSelected [0,5,15,27,41] rootPS)) = affineNative (2^(7+1) ^^^ 203) := by decide +kernel

theorem selectedBound31672 : packedSelected [0,5,15,27,41] rootPS < 2^1333 := by decide +kernel

def env31673 : List Nat := [2,4,8,16,32,64,128,203,113,155,2048,254,246,65,96,20,22,149,116,97,254,248,22,20,144,169,229,70,64,2054,250,249,202,80,16,158]

theorem envBound31673 : H12AffineFastState.Bounded env31673 := by
  intro p hp
  have h : env31673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31672_31673 : H12AffineEnvironment.transform 7 203 env31672 = env31673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 203 env31672 == env31673) = true)

theorem identity31673 : scanCanonicalize (H12AffineFastState.compose env31673 (packedSelected [0,1,2,5,7,10,12,13,15,17,23,24] rootPS)) = affineNative (2^(6+1) ^^^ 36) := by decide +kernel

theorem selectedBound31673 : packedSelected [0,1,2,5,7,10,12,13,15,17,23,24] rootPS < 2^1333 := by decide +kernel

def env31674 : List Nat := [2,4,8,16,32,64,36,111,113,63,2048,90,82,65,96,20,22,49,116,97,90,92,22,20,52,13,65,70,64,2054,94,93,110,80,16,58]

theorem envBound31674 : H12AffineFastState.Bounded env31674 := by
  intro p hp
  have h : env31674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31673_31674 : H12AffineEnvironment.transform 6 36 env31673 = env31674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 36 env31673 == env31674) = true)

theorem identity31674 : scanCanonicalize (H12AffineFastState.compose env31674 (packedSelected [0,3,8,9] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound31674 : packedSelected [0,3,8,9] rootPS < 2^1333 := by decide +kernel

def env31675 : List Nat := [2,4,8,16,17,64,21,94,64,14,2048,90,82,65,81,20,22,0,69,80,90,92,22,20,5,13,65,70,64,2054,94,93,95,80,16,11]

theorem envBound31675 : H12AffineFastState.Bounded env31675 := by
  intro p hp
  have h : env31675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31674_31675 : H12AffineEnvironment.transform 4 17 env31674 = env31675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env31674 == env31675) = true)

theorem identity31675 : scanCanonicalize (H12AffineFastState.compose env31675 (packedSelected [1,5,8,11] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound31675 : packedSelected [1,5,8,11] rootPS < 2^1333 := by decide +kernel

def env31676 : List Nat := [2,4,2,16,17,64,21,84,64,4,2048,80,82,65,81,20,22,0,69,80,80,86,22,20,5,7,65,70,64,2054,84,87,85,80,16,1]

theorem envBound31676 : H12AffineFastState.Bounded env31676 := by
  intro p hp
  have h : env31676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31675_31676 : H12AffineEnvironment.transform 2 2 env31675 = env31676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env31675 == env31676) = true)

theorem identity31676 : scanCanonicalize (H12AffineFastState.compose env31676 (packedSelected [2,3,5] rootPS)) = affineNative (2^(5+1) ^^^ 22) := by decide +kernel

theorem selectedBound31676 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env31677 : List Nat := [2,4,2,16,17,22,21,2,22,4,2048,6,4,23,7,20,22,0,19,6,6,0,22,20,5,7,23,16,22,2054,2,1,3,6,16,1]

theorem envBound31677 : H12AffineFastState.Bounded env31677 := by
  intro p hp
  have h : env31677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31676_31677 : H12AffineEnvironment.transform 5 22 env31676 = env31677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 22 env31676 == env31677) = true)

theorem identity31677 : scanCanonicalize (H12AffineFastState.compose env31677 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound31677 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env31678 : List Nat := [2,4,2,16,17,22,21,2,22,4,1,6,4,23,7,20,22,0,19,6,6,0,22,20,5,7,23,16,22,7,2,1,3,6,16,1]

theorem envBound31678 : H12AffineFastState.Bounded env31678 := by
  intro p hp
  have h : env31678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31677_31678 : H12AffineEnvironment.transform 10 1 env31677 = env31678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env31677 == env31678) = true)

theorem identity31678 : scanCanonicalize (H12AffineFastState.compose env31678 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound31678 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31679 : List Nat := [2,3,2,16,17,17,18,2,17,3,1,1,3,16,0,19,17,0,19,1,1,0,17,19,2,0,16,16,17,0,2,1,3,1,16,1]

theorem envBound31679 : H12AffineFastState.Bounded env31679 := by
  intro p hp
  have h : env31679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31678_31679 : H12AffineEnvironment.transform 1 3 env31678 = env31679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env31678 == env31679) = true)

def env31680 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,837,844,64,529,65536,66162,65665,516,528,837,649,66163,65537,144,65910,303,66082,65,67602,832,65830,257,81,17,341]

theorem envBound31680 : H12AffineFastState.Bounded env31680 := by
  intro p hp
  have h : env31680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31659_31680 : H12AffineEnvironment.transform 9 337 env31659 = env31680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 337 env31659 == env31680) = true)

theorem identity31680 : scanCanonicalize (H12AffineFastState.compose env31680 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 769) := by decide +kernel

theorem selectedBound31680 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env31681 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,837,844,64,529,769,371,896,516,528,837,649,370,768,144,631,303,291,65,2835,832,551,257,81,17,341]

theorem envBound31681 : H12AffineFastState.Bounded env31681 := by
  intro p hp
  have h : env31681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31680_31681 : H12AffineEnvironment.transform 15 769 env31680 = env31681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 769 env31680 == env31681) = true)

def env31682 : List Nat := [2,4,8,16,32,64,128,100,512,53,2048,545,552,64,529,613,23,740,516,528,545,649,22,612,144,631,75,71,65,2679,548,551,101,81,17,49]

theorem envBound31682 : H12AffineFastState.Bounded env31682 := by
  intro p hp
  have h : env31682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31681_31682 : H12AffineEnvironment.transform 7 100 env31681 = env31682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 100 env31681 == env31682) = true)

theorem identity31682 : scanCanonicalize (H12AffineFastState.compose env31682 (packedSelected [0,4,5,9,12,16,17,21,27,38] rootPS)) = affineNative (2^(8+1) ^^^ 190) := by decide +kernel

theorem selectedBound31682 : packedSelected [0,4,5,9,12,16,17,21,27,38] rootPS < 2^1333 := by decide +kernel

def env31683 : List Nat := [2,4,8,16,32,64,128,100,190,53,2048,159,150,64,175,219,23,90,186,174,159,55,22,218,144,201,75,71,65,2249,154,153,101,81,17,49]

theorem envBound31683 : H12AffineFastState.Bounded env31683 := by
  intro p hp
  have h : env31683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31682_31683 : H12AffineEnvironment.transform 8 190 env31682 = env31683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 190 env31682 == env31683) = true)

theorem identity31683 : scanCanonicalize (H12AffineFastState.compose env31683 (packedSelected [2,4,8,9,10,11,13,16,17,21,23,24] rootPS)) = affineNative (2^(10+1) ^^^ 60) := by decide +kernel

theorem selectedBound31683 : packedSelected [2,4,8,9,10,11,13,16,17,21,23,24] rootPS < 2^1333 := by decide +kernel

def env31684 : List Nat := [2,4,8,16,32,64,128,100,190,53,60,159,150,64,175,219,23,90,186,174,159,55,22,218,144,201,75,71,65,245,154,153,101,81,17,49]

theorem envBound31684 : H12AffineFastState.Bounded env31684 := by
  intro p hp
  have h : env31684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31683_31684 : H12AffineEnvironment.transform 10 60 env31683 = env31684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 60 env31683 == env31684) = true)

theorem identity31684 : scanCanonicalize (H12AffineFastState.compose env31684 (packedSelected [2,3,8,10,11,13] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound31684 : packedSelected [2,3,8,10,11,13] rootPS < 2^1333 := by decide +kernel

def env31685 : List Nat := [2,4,8,16,32,64,25,100,39,53,60,6,15,64,54,66,23,90,35,55,6,55,22,67,9,80,75,71,65,108,3,0,101,81,17,49]

theorem envBound31685 : H12AffineFastState.Bounded env31685 := by
  intro p hp
  have h : env31685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31684_31685 : H12AffineEnvironment.transform 6 25 env31684 = env31685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env31684 == env31685) = true)

theorem identity31685 : scanCanonicalize (H12AffineFastState.compose env31685 (packedSelected [2,3,5,8,10,11,12] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound31685 : packedSelected [2,3,5,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env31686 : List Nat := [2,4,8,16,16,64,25,84,23,5,12,6,15,64,6,66,23,90,19,7,6,7,22,67,9,80,75,71,65,92,3,0,85,81,17,1]

theorem envBound31686 : H12AffineFastState.Bounded env31686 := by
  intro p hp
  have h : env31686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31685_31686 : H12AffineEnvironment.transform 4 16 env31685 = env31686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env31685 == env31686) = true)

theorem identity31686 : scanCanonicalize (H12AffineFastState.compose env31686 (packedSelected [0,2,3,7] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound31686 : packedSelected [0,2,3,7] rootPS < 2^1333 := by decide +kernel

def env31687 : List Nat := [2,4,3,16,16,64,18,84,23,5,7,6,4,64,6,66,23,81,19,7,6,7,22,67,2,80,64,71,65,87,3,0,85,81,17,1]

theorem envBound31687 : H12AffineFastState.Bounded env31687 := by
  intro p hp
  have h : env31687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31686_31687 : H12AffineEnvironment.transform 2 3 env31686 = env31687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env31686 == env31687) = true)

end H12CloudChart2