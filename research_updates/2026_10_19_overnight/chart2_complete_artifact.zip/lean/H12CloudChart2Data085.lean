import H12CloudChart2Data084

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound20851 : H12AffineFastState.Bounded env20851 := by
  intro p hp
  have h : env20851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20850_20851 : H12AffineEnvironment.transform 21 10248 env20850 = env20851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10248 env20850 == env20851) = true)

def env20852 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,8200,147521,230468,8328,672784,925772,16385,676864,1073741824,131141,4294967296,257,4295206118,1345,512]

theorem envBound20852 : H12AffineFastState.Bounded env20852 := by
  intro p hp
  have h : env20852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20851_20852 : H12AffineEnvironment.transform 10 0 env20851 = env20852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env20851 == env20852) = true)

def env20853 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1344,262144,524288,32769,4097,8200,17665,98564,8328,541008,795916,16385,545088,1073741824,1285,4294967296,257,4295074214,1345,512]

theorem envBound20853 : H12AffineFastState.Bounded env20853 := by
  intro p hp
  have h : env20853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20852_20853 : H12AffineEnvironment.transform 16 1344 env20852 = env20853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env20852 == env20853) = true)

theorem identity20853 : scanCanonicalize (H12AffineFastState.compose env20853 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 312421) := by decide +kernel

theorem selectedBound20853 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env20854 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1344,262144,524288,32769,4097,8200,17665,98564,8328,541008,795916,16385,545088,312421,1285,4294967296,257,4295074214,1345,512]

theorem envBound20854 : H12AffineFastState.Bounded env20854 := by
  intro p hp
  have h : env20854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20853_20854 : H12AffineEnvironment.transform 29 312421 env20853 = env20854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 312421 env20853 == env20854) = true)

def env20855 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1344,262144,304168,32769,4097,8200,17665,98564,8328,320888,33060,16385,324968,312421,1285,4294967296,257,4295074214,1345,512]

theorem envBound20855 : H12AffineFastState.Bounded env20855 := by
  intro p hp
  have h : env20855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20854_20855 : H12AffineEnvironment.transform 18 304168 env20854 = env20855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 304168 env20854 == env20855) = true)

theorem identity20855 : scanCanonicalize (H12AffineFastState.compose env20855 (packedSelected [5,8,13,15,19] rootPS)) = affineNative (2^(15+1) ^^^ 50382) := by decide +kernel

theorem selectedBound20855 : packedSelected [5,8,13,15,19] rootPS < 2^1333 := by decide +kernel

def env20856 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,50382,1344,262144,304168,32769,4097,8200,17665,17866,8328,320888,33060,16385,324968,312421,1285,4294967296,257,4294993256,1345,512]

theorem envBound20856 : H12AffineFastState.Bounded env20856 := by
  intro p hp
  have h : env20856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20855_20856 : H12AffineEnvironment.transform 15 50382 env20855 = env20856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 50382 env20855 == env20856) = true)

theorem identity20856 : scanCanonicalize (H12AffineFastState.compose env20856 (packedSelected [0,5,7,8,10,12,20,21] rootPS)) = affineNative (2^(17+1) ^^^ 58728) := by decide +kernel

theorem selectedBound20856 : packedSelected [0,5,7,8,10,12,20,21] rootPS < 2^1333 := by decide +kernel

def env20857 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,50382,1344,58728,16704,32769,4097,8200,17665,17866,8328,16,33060,16385,4096,8461,1285,4294967296,257,4294993256,1345,512]

theorem envBound20857 : H12AffineFastState.Bounded env20857 := by
  intro p hp
  have h : env20857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20856_20857 : H12AffineEnvironment.transform 17 58728 env20856 = env20857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 58728 env20856 == env20857) = true)

theorem identity20857 : scanCanonicalize (H12AffineFastState.compose env20857 (packedSelected [1,5,8,24] rootPS)) = affineNative (2^(13+1) ^^^ 1345) := by decide +kernel

theorem selectedBound20857 : packedSelected [1,5,8,24] rootPS < 2^1333 := by decide +kernel

def env20858 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,1345,32768,33167,1344,41001,1025,32769,4097,8200,64,139,8328,16,33060,1344,4096,8461,1285,4294967296,257,4294975529,1345,512]

theorem envBound20858 : H12AffineFastState.Bounded env20858 := by
  intro p hp
  have h : env20858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20857_20858 : H12AffineEnvironment.transform 13 1345 env20857 = env20858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env20857 == env20858) = true)

theorem identity20858 : scanCanonicalize (H12AffineFastState.compose env20858 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(14+1) ^^^ 293) := by decide +kernel

theorem selectedBound20858 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env20859 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,1345,293,170,1344,8460,1025,292,4097,8200,64,139,8328,16,1,1344,4096,8461,1285,4294967296,257,4294975529,1345,512]

theorem envBound20859 : H12AffineFastState.Bounded env20859 := by
  intro p hp
  have h : env20859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20858_20859 : H12AffineEnvironment.transform 14 293 env20858 = env20859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 293 env20858 == env20859) = true)

theorem identity20859 : scanCanonicalize (H12AffineFastState.compose env20859 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound20859 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env20860 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1297,8192,1345,293,170,1344,8460,1025,292,1296,8200,64,139,8328,16,1,1344,1297,8461,1285,4294967296,257,4294975529,1345,512]

theorem envBound20860 : H12AffineFastState.Bounded env20860 := by
  intro p hp
  have h : env20860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20859_20860 : H12AffineEnvironment.transform 11 1297 env20859 = env20860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env20859 == env20860) = true)

def env20861 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1297,672,1345,293,170,1344,940,1025,292,1296,680,64,139,552,16,1,1344,1297,941,1285,4294967296,257,4294967945,1345,512]

theorem envBound20861 : H12AffineFastState.Bounded env20861 := by
  intro p hp
  have h : env20861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20860_20861 : H12AffineEnvironment.transform 12 672 env20860 = env20861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 672 env20860 == env20861) = true)

theorem identity20861 : scanCanonicalize (H12AffineFastState.compose env20861 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 648) := by decide +kernel

theorem selectedBound20861 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20862 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1297,672,1345,293,170,1344,940,1025,292,1296,680,64,139,552,16,1,1344,1297,941,1285,648,257,1,1345,512]

theorem envBound20862 : H12AffineFastState.Bounded env20862 := by
  intro p hp
  have h : env20862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20861_20862 : H12AffineEnvironment.transform 31 648 env20861 = env20862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 648 env20861 == env20862) = true)

theorem identity20862 : scanCanonicalize (H12AffineFastState.compose env20862 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound20862 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20863 : List Nat := [2,4,8,16,32,64,89,256,512,1024,0,1297,633,1345,293,115,1344,885,1025,292,1296,625,64,82,552,16,1,1344,1297,884,1285,593,257,1,1345,512]

theorem envBound20863 : H12AffineFastState.Bounded env20863 := by
  intro p hp
  have h : env20863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20862_20863 : H12AffineEnvironment.transform 6 89 env20862 = env20863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env20862 == env20863) = true)

def env20864 : List Nat := [2,4,8,16,32,64,89,256,80,1024,0,1297,41,1345,293,115,1344,293,1025,292,1296,33,64,82,120,16,1,1344,1297,292,1285,1,257,1,1345,80]

theorem envBound20864 : H12AffineFastState.Bounded env20864 := by
  intro p hp
  have h : env20864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20863_20864 : H12AffineEnvironment.transform 8 80 env20863 = env20864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 80 env20863 == env20864) = true)

theorem identity20864 : scanCanonicalize (H12AffineFastState.compose env20864 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound20864 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20865 : List Nat := [2,4,8,16,32,64,89,36,80,1024,0,1077,41,1125,1,115,1124,1,1025,0,1076,33,64,82,120,16,1,1124,1077,0,1057,1,37,1,1125,80]

theorem envBound20865 : H12AffineFastState.Bounded env20865 := by
  intro p hp
  have h : env20865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20864_20865 : H12AffineEnvironment.transform 7 36 env20864 = env20865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env20864 == env20865) = true)

def env20866 : List Nat := [2,4,8,16,32,64,89,256,81,1024,0,1297,40,1345,293,115,1344,292,1025,292,1296,32,64,82,121,16,1,1344,1297,293,1285,0,257,1,1345,81]

theorem envBound20866 : H12AffineFastState.Bounded env20866 := by
  intro p hp
  have h : env20866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20863_20866 : H12AffineEnvironment.transform 8 81 env20863 = env20866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env20863 == env20866) = true)

theorem identity20866 : scanCanonicalize (H12AffineFastState.compose env20866 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound20866 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20867 : List Nat := [2,4,8,16,0,64,89,256,81,1024,0,1297,8,1345,261,83,1344,260,1025,260,1296,0,64,82,89,16,1,1344,1297,261,1285,0,257,1,1345,81]

theorem envBound20867 : H12AffineFastState.Bounded env20867 := by
  intro p hp
  have h : env20867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20866_20867 : H12AffineEnvironment.transform 4 0 env20866 = env20867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env20866 == env20867) = true)

theorem identity20867 : scanCanonicalize (H12AffineFastState.compose env20867 (packedSelected [4] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound20867 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env20868 : List Nat := [2,4,8,16,0,16,9,256,1,1024,0,1297,8,1297,261,3,1296,260,1025,260,1296,0,16,2,9,16,1,1296,1297,261,1285,0,257,1,1297,1]

theorem envBound20868 : H12AffineFastState.Bounded env20868 := by
  intro p hp
  have h : env20868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20867_20868 : H12AffineEnvironment.transform 5 16 env20867 = env20868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20867 == env20868) = true)

def leafEnv20868 : List Nat := [2,4,8,16,0,16,9,256,1,1024,0,1297,8,1297,261,3,1296,260,1025,260,1296,0,16,2,1284,9,1,16,1,1296,1297,261,1285,0,257,1,5,3,1297,1,0,1296,1]

def active20868 : List Nat := [0,1,2,3,7,9]

def tree20868 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20868 : H12WitnessSearch.Good tree20868 := H12GlobalWitnessIndex.good

theorem leafIdentity20868 : H12AffineFastState.composeSystem env20868 rootObs = leafEnv20868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20868 rootObs == leafEnv20868) = true)

theorem terminalChecked20868 : H12PackedTerminal.terminalCheckFast leafEnv20868 active20868 tree20868 = true := by decide +kernel

def env20869 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1297,673,1345,293,170,1344,941,1025,292,1296,681,64,139,553,16,1,1344,1297,940,1285,4294967296,257,4294967944,1345,512]

theorem envBound20869 : H12AffineFastState.Bounded env20869 := by
  intro p hp
  have h : env20869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20860_20869 : H12AffineEnvironment.transform 12 673 env20860 = env20869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 673 env20860 == env20869) = true)

theorem identity20869 : scanCanonicalize (H12AffineFastState.compose env20869 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 429) := by decide +kernel

theorem selectedBound20869 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20870 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1297,673,1345,293,170,1344,941,1025,292,1296,681,64,139,553,16,1,1344,1297,940,1285,429,257,805,1345,512]

theorem envBound20870 : H12AffineFastState.Bounded env20870 := by
  intro p hp
  have h : env20870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20869_20870 : H12AffineEnvironment.transform 31 429 env20869 = env20870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 429 env20869 == env20870) = true)

theorem identity20870 : scanCanonicalize (H12AffineFastState.compose env20870 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound20870 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20871 : List Nat := [2,4,8,16,32,64,9,256,512,1024,0,1297,552,1345,293,35,1344,804,1025,292,1296,544,64,2,553,16,1,1344,1297,805,1285,292,257,805,1345,512]

theorem envBound20871 : H12AffineFastState.Bounded env20871 := by
  intro p hp
  have h : env20871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20870_20871 : H12AffineEnvironment.transform 6 9 env20870 = env20871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20870 == env20871) = true)

def env20872 : List Nat := [2,4,8,16,32,64,9,256,0,1024,0,1297,40,1345,293,35,1344,292,1025,292,1296,32,64,2,41,16,1,1344,1297,293,1285,292,257,293,1345,0]

theorem envBound20872 : H12AffineFastState.Bounded env20872 := by
  intro p hp
  have h : env20872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20871_20872 : H12AffineEnvironment.transform 8 0 env20871 = env20872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env20871 == env20872) = true)

theorem identity20872 : scanCanonicalize (H12AffineFastState.compose env20872 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound20872 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20873 : List Nat := [2,4,8,16,32,49,9,256,0,1024,0,1297,40,1328,293,35,1329,292,1025,292,1296,32,49,2,41,16,1,1329,1297,293,1285,292,257,293,1328,0]

theorem envBound20873 : H12AffineFastState.Bounded env20873 := by
  intro p hp
  have h : env20873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20872_20873 : H12AffineEnvironment.transform 5 49 env20872 = env20873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env20872 == env20873) = true)

theorem identity20873 : scanCanonicalize (H12AffineFastState.compose env20873 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound20873 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env20874 : List Nat := [2,4,8,16,32,49,9,5,0,1024,0,1044,40,1077,32,35,1076,33,1025,33,1045,32,49,2,41,16,1,1076,1044,32,1024,33,4,32,1077,0]

theorem envBound20874 : H12AffineFastState.Bounded env20874 := by
  intro p hp
  have h : env20874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20873_20874 : H12AffineEnvironment.transform 7 5 env20873 = env20874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env20873 == env20874) = true)

theorem identity20874 : scanCanonicalize (H12AffineFastState.compose env20874 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound20874 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env20875 : List Nat := [2,4,8,16,1,16,9,5,0,1024,0,1044,9,1044,1,2,1045,0,1025,0,1045,1,16,2,8,16,1,1045,1044,1,1024,0,4,1,1044,0]

theorem envBound20875 : H12AffineFastState.Bounded env20875 := by
  intro p hp
  have h : env20875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20874_20875 : H12AffineEnvironment.transform 4 1 env20874 = env20875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env20874 == env20875) = true)

def leafEnv20875 : List Nat := [2,4,8,16,1,16,9,5,0,1024,0,1044,9,1044,1,2,1045,0,1025,0,1045,1,16,2,1025,8,1,16,1,1045,1044,1,1024,0,4,1,5,2,1044,0,0,1045,1]

def active20875 : List Nat := [0,1,2,3,9]

def tree20875 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20875 : H12WitnessSearch.Good tree20875 := H12GlobalWitnessIndex.good

theorem leafIdentity20875 : H12AffineFastState.composeSystem env20875 rootObs = leafEnv20875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20875 rootObs == leafEnv20875) = true)

theorem terminalChecked20875 : H12PackedTerminal.terminalCheckFast leafEnv20875 active20875 tree20875 = true := by decide +kernel

def env20876 : List Nat := [2,4,8,16,32,64,9,256,1,1024,0,1297,41,1345,293,35,1344,293,1025,292,1296,33,64,2,40,16,1,1344,1297,292,1285,292,257,292,1345,1]

theorem envBound20876 : H12AffineFastState.Bounded env20876 := by
  intro p hp
  have h : env20876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20871_20876 : H12AffineEnvironment.transform 8 1 env20871 = env20876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env20871 == env20876) = true)

theorem identity20876 : scanCanonicalize (H12AffineFastState.compose env20876 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound20876 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20877 : List Nat := [2,4,8,16,32,16,9,256,1,1024,0,1297,41,1297,293,35,1296,293,1025,292,1296,33,16,2,40,16,1,1296,1297,292,1285,292,257,292,1297,1]

theorem envBound20877 : H12AffineFastState.Bounded env20877 := by
  intro p hp
  have h : env20877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20876_20877 : H12AffineEnvironment.transform 5 16 env20876 = env20877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20876 == env20877) = true)

def env20878 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1344,262144,304169,32769,4097,8200,17665,98564,8328,320889,33061,16385,324969,312421,1285,4294967296,257,4295074214,1345,512]

theorem envBound20878 : H12AffineFastState.Bounded env20878 := by
  intro p hp
  have h : env20878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20854_20878 : H12AffineEnvironment.transform 18 304169 env20854 = env20878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 304169 env20854 == env20878) = true)

theorem identity20878 : scanCanonicalize (H12AffineFastState.compose env20878 (packedSelected [4,9,18] rootPS)) = affineNative (2^(17+1) ^^^ 50277) := by decide +kernel

theorem selectedBound20878 : packedSelected [4,9,18] rootPS < 2^1333 := by decide +kernel

def env20879 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1344,50277,24652,32769,4097,8200,17665,98564,8328,8476,33061,16385,12556,0,1285,4294967296,257,4295074214,1345,512]

theorem envBound20879 : H12AffineFastState.Bounded env20879 := by
  intro p hp
  have h : env20879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20878_20879 : H12AffineEnvironment.transform 17 50277 env20878 = env20879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 50277 env20878 == env20879) = true)

theorem identity20879 : scanCanonicalize (H12AffineFastState.compose env20879 (packedSelected [5,8,13,15,19] rootPS)) = affineNative (2^(15+1) ^^^ 38047) := by decide +kernel

theorem selectedBound20879 : packedSelected [5,8,13,15,19] rootPS < 2^1333 := by decide +kernel

def env20880 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,38047,1344,50277,24652,32769,4097,8200,17665,5531,8328,8476,33061,16385,12556,0,1285,4294967296,257,4294980921,1345,512]

theorem envBound20880 : H12AffineFastState.Bounded env20880 := by
  intro p hp
  have h : env20880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20879_20880 : H12AffineEnvironment.transform 15 38047 env20879 = env20880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38047 env20879 == env20880) = true)

theorem identity20880 : scanCanonicalize (H12AffineFastState.compose env20880 (packedSelected [0,1,3,4,7,9,10,13,15,20] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound20880 : packedSelected [0,1,3,4,7,9,10,13,15,20] rootPS < 2^1333 := by decide +kernel

def env20881 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,269,16384,32768,38047,1344,50277,16705,32769,4097,261,17665,5531,389,17,33061,16385,4097,0,1285,4294967296,257,4294972468,1345,512]

theorem envBound20881 : H12AffineFastState.Bounded env20881 := by
  intro p hp
  have h : env20881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20880_20881 : H12AffineEnvironment.transform 12 269 env20880 = env20881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env20880 == env20881) = true)

theorem identity20881 : scanCanonicalize (H12AffineFastState.compose env20881 (packedSelected [4,9] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound20881 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env20882 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1296,269,16384,32768,33167,1344,50277,16705,32769,1297,261,17665,139,389,17,33061,16385,1297,0,1285,4294967296,257,4294967588,1345,512]

theorem envBound20882 : H12AffineFastState.Bounded env20882 := by
  intro p hp
  have h : env20882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20881_20882 : H12AffineEnvironment.transform 11 1296 env20881 = env20882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env20881 == env20882) = true)

theorem identity20882 : scanCanonicalize (H12AffineFastState.compose env20882 (packedSelected [3,5,12,13] rootPS)) = affineNative (2^(13+1) ^^^ 1344) := by decide +kernel

theorem selectedBound20882 : packedSelected [3,5,12,13] rootPS < 2^1333 := by decide +kernel

def env20883 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1296,269,1344,32768,33167,1344,33061,1025,32769,1297,261,65,139,389,17,33061,1345,1297,0,1285,4294967296,257,4294967588,1345,512]

theorem envBound20883 : H12AffineFastState.Bounded env20883 := by
  intro p hp
  have h : env20883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20882_20883 : H12AffineEnvironment.transform 13 1344 env20882 = env20883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env20882 == env20883) = true)

theorem identity20883 : scanCanonicalize (H12AffineFastState.compose env20883 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound20883 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env20884 : List Nat := [2,4,8,16,32,17,128,256,512,1024,0,1296,269,1297,32768,33167,1297,33061,1025,32769,1297,261,16,139,389,17,33061,1296,1297,0,1285,4294967296,257,4294967588,1296,512]

theorem envBound20884 : H12AffineFastState.Bounded env20884 := by
  intro p hp
  have h : env20884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20883_20884 : H12AffineEnvironment.transform 5 17 env20883 = env20884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env20883 == env20884) = true)

theorem identity20884 : scanCanonicalize (H12AffineFastState.compose env20884 (packedSelected [1] rootPS)) = affineNative (2^(14+1) ^^^ 1076) := by decide +kernel

theorem selectedBound20884 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20885 : List Nat := [2,4,8,16,32,17,128,256,512,1024,0,1296,269,1297,1076,1467,1297,1297,1025,1077,1297,261,16,139,389,17,1297,1296,1297,0,1285,4294967296,257,4294967588,1296,512]

theorem envBound20885 : H12AffineFastState.Bounded env20885 := by
  intro p hp
  have h : env20885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20884_20885 : H12AffineEnvironment.transform 14 1076 env20884 = env20885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1076 env20884 == env20885) = true)

theorem identity20885 : scanCanonicalize (H12AffineFastState.compose env20885 (packedSelected [5] rootPS)) = affineNative (2^(9+1) ^^^ 188) := by decide +kernel

theorem selectedBound20885 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env20886 : List Nat := [2,4,8,16,32,17,128,256,512,188,0,428,269,429,136,263,429,429,189,137,429,261,16,139,389,17,429,428,429,0,441,4294967296,257,4294967588,428,512]

theorem envBound20886 : H12AffineFastState.Bounded env20886 := by
  intro p hp
  have h : env20886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20885_20886 : H12AffineEnvironment.transform 9 188 env20885 = env20886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 188 env20885 == env20886) = true)

theorem identity20886 : scanCanonicalize (H12AffineFastState.compose env20886 (packedSelected [0,2,4] rootPS)) = affineNative (2^(31+1) ^^^ 429) := by decide +kernel

theorem selectedBound20886 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env20887 : List Nat := [2,4,8,16,32,17,128,256,512,188,0,428,269,429,136,263,429,429,189,137,429,261,16,139,389,17,429,428,429,0,441,429,257,137,428,512]

theorem envBound20887 : H12AffineFastState.Bounded env20887 := by
  intro p hp
  have h : env20887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20886_20887 : H12AffineEnvironment.transform 31 429 env20886 = env20887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 429 env20886 == env20887) = true)

def env20888 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1345,262144,524288,32769,4097,8200,17664,98565,8328,541009,795917,16385,545089,1073741824,1284,4294967296,257,4295074215,1345,512]

theorem envBound20888 : H12AffineFastState.Bounded env20888 := by
  intro p hp
  have h : env20888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20852_20888 : H12AffineEnvironment.transform 16 1345 env20852 = env20888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env20852 == env20888) = true)

theorem identity20888 : scanCanonicalize (H12AffineFastState.compose env20888 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 312372) := by decide +kernel

theorem selectedBound20888 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env20889 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1345,262144,524288,32769,4097,8200,17664,98565,8328,541009,795917,16385,545089,312372,1284,4294967296,257,4295074215,1345,512]

theorem envBound20889 : H12AffineFastState.Bounded env20889 := by
  intro p hp
  have h : env20889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20888_20889 : H12AffineEnvironment.transform 29 312372 env20888 = env20889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 312372 env20888 == env20889) = true)

theorem identity20889 : scanCanonicalize (H12AffineFastState.compose env20889 (packedSelected [4,9,16] rootPS)) = affineNative (2^(18+1) ^^^ 1025) := by decide +kernel

theorem selectedBound20889 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env20890 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1345,262144,1025,32769,4097,8200,17664,98565,8328,17744,270604,16385,21824,312372,1284,4294967296,257,4295074215,1345,512]

theorem envBound20890 : H12AffineFastState.Bounded env20890 := by
  intro p hp
  have h : env20890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20889_20890 : H12AffineEnvironment.transform 18 1025 env20889 = env20890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env20889 == env20890) = true)

theorem identity20890 : scanCanonicalize (H12AffineFastState.compose env20890 (packedSelected [1,5,8,15,17,21,24,38] rootPS)) = affineNative (2^(17+1) ^^^ 91318) := by decide +kernel

theorem selectedBound20890 : packedSelected [1,5,8,15,17,21,24,38] rootPS < 2^1333 := by decide +kernel

def env20891 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1345,91318,1025,32769,4097,8200,17664,98565,8328,17744,83386,16385,21824,106626,1284,4294967296,257,4295074215,1345,512]

theorem envBound20891 : H12AffineFastState.Bounded env20891 := by
  intro p hp
  have h : env20891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20890_20891 : H12AffineEnvironment.transform 17 91318 env20890 = env20891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 91318 env20890 == env20891) = true)

theorem identity20891 : scanCanonicalize (H12AffineFastState.compose env20891 (packedSelected [13,21] rootPS)) = affineNative (2^(13+1) ^^^ 4176) := by decide +kernel

theorem selectedBound20891 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env20892 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,4176,32768,65536,1345,79078,1025,32769,4097,8200,5456,98565,8328,5376,71146,4177,1296,106626,1284,4294967296,257,4295074215,1345,512]

theorem envBound20892 : H12AffineFastState.Bounded env20892 := by
  intro p hp
  have h : env20892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20891_20892 : H12AffineEnvironment.transform 13 4176 env20891 = env20892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env20891 == env20892) = true)

theorem identity20892 : scanCanonicalize (H12AffineFastState.compose env20892 (packedSelected [3,5,10] rootPS)) = affineNative (2^(31+1) ^^^ 8320) := by decide +kernel

theorem selectedBound20892 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env20893 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,4176,32768,65536,1345,79078,1025,32769,4097,8200,5456,98565,8328,5376,71146,4177,1296,106626,1284,8320,257,98599,1345,512]

theorem envBound20893 : H12AffineFastState.Bounded env20893 := by
  intro p hp
  have h : env20893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20892_20893 : H12AffineEnvironment.transform 31 8320 env20892 = env20893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 8320 env20892 == env20893) = true)

theorem identity20893 : scanCanonicalize (H12AffineFastState.compose env20893 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 38094) := by decide +kernel

theorem selectedBound20893 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env20894 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,4176,32768,38094,1345,41000,1025,32769,4097,8200,5456,5579,8328,5376,33060,4177,1296,13388,1284,8320,257,5609,1345,512]

theorem envBound20894 : H12AffineFastState.Bounded env20894 := by
  intro p hp
  have h : env20894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20893_20894 : H12AffineEnvironment.transform 15 38094 env20893 = env20894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38094 env20893 == env20894) = true)

theorem identity20894 : scanCanonicalize (H12AffineFastState.compose env20894 (packedSelected [3,5,12,13] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound20894 : packedSelected [3,5,12,13] rootPS < 2^1333 := by decide +kernel

def env20895 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,469,4176,32768,38094,1345,33277,1025,32769,4097,477,5456,5579,349,5376,33060,4177,1296,5529,1284,341,257,5609,1345,512]

theorem envBound20895 : H12AffineFastState.Bounded env20895 := by
  intro p hp
  have h : env20895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20894_20895 : H12AffineEnvironment.transform 12 469 env20894 = env20895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env20894 == env20895) = true)

theorem identity20895 : scanCanonicalize (H12AffineFastState.compose env20895 (packedSelected [1,2,3,4,5,6,8,9,12] rootPS)) = affineNative (2^(11+1) ^^^ 941) := by decide +kernel

theorem selectedBound20895 : packedSelected [1,2,3,4,5,6,8,9,12] rootPS < 2^1333 := by decide +kernel

def env20896 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,941,469,1021,32768,34659,1345,33277,1025,32769,940,477,1789,1638,349,1709,33060,1020,1296,1588,1284,341,257,1604,1345,512]

theorem envBound20896 : H12AffineFastState.Bounded env20896 := by
  intro p hp
  have h : env20896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20895_20896 : H12AffineEnvironment.transform 11 941 env20895 = env20896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 941 env20895 == env20896) = true)

theorem identity20896 : scanCanonicalize (H12AffineFastState.compose env20896 (packedSelected [1,2,4,5,6,9,17] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound20896 : packedSelected [1,2,4,5,6,9,17] rootPS < 2^1333 := by decide +kernel

def env20897 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,941,469,1021,136,2027,1345,373,1025,137,940,477,1789,1638,349,1709,428,1020,1296,1588,1284,341,257,1604,1345,512]

theorem envBound20897 : H12AffineFastState.Bounded env20897 := by
  intro p hp
  have h : env20897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20896_20897 : H12AffineEnvironment.transform 14 136 env20896 = env20897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env20896 == env20897) = true)

theorem identity20897 : scanCanonicalize (H12AffineFastState.compose env20897 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 533) := by decide +kernel

theorem selectedBound20897 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env20898 : List Nat := [2,4,8,16,32,64,128,256,512,533,0,941,469,1021,136,510,852,373,532,137,940,477,232,115,349,184,428,1020,773,33,785,341,257,81,852,512]

theorem envBound20898 : H12AffineFastState.Bounded env20898 := by
  intro p hp
  have h : env20898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20897_20898 : H12AffineEnvironment.transform 9 533 env20897 = env20898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 533 env20897 == env20898) = true)

theorem identity20898 : scanCanonicalize (H12AffineFastState.compose env20898 (packedSelected [2,3,4,5,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound20898 : packedSelected [2,3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env20899 : List Nat := [2,4,8,16,32,16,128,256,512,533,0,941,389,941,136,430,772,293,532,137,940,397,184,35,269,184,428,940,773,33,785,261,257,1,772,512]

theorem envBound20899 : H12AffineFastState.Bounded env20899 := by
  intro p hp
  have h : env20899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20898_20899 : H12AffineEnvironment.transform 5 16 env20898 = env20899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20898 == env20899) = true)

theorem identity20899 : scanCanonicalize (H12AffineFastState.compose env20899 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 309) := by decide +kernel

theorem selectedBound20899 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20900 : List Nat := [2,4,8,16,32,16,128,256,309,288,0,152,389,152,136,430,49,293,289,137,153,397,184,35,269,184,428,153,48,33,36,261,257,1,49,309]

theorem envBound20900 : H12AffineFastState.Bounded env20900 := by
  intro p hp
  have h : env20900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20899_20900 : H12AffineEnvironment.transform 8 309 env20899 = env20900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 309 env20899 == env20900) = true)

theorem identity20900 : scanCanonicalize (H12AffineFastState.compose env20900 (packedSelected [3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound20900 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env20901 : List Nat := [2,4,8,16,32,16,128,37,16,5,0,152,160,152,136,139,49,0,4,137,153,168,184,35,40,184,137,153,48,33,36,32,36,1,49,16]

theorem envBound20901 : H12AffineFastState.Bounded env20901 := by
  intro p hp
  have h : env20901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20900_20901 : H12AffineEnvironment.transform 7 37 env20900 = env20901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env20900 == env20901) = true)

theorem identity20901 : scanCanonicalize (H12AffineFastState.compose env20901 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound20901 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20902 : List Nat := [2,4,8,16,32,16,56,37,16,5,0,32,24,32,48,51,49,0,4,49,33,16,0,35,40,0,49,33,48,33,36,32,36,1,49,16]

theorem envBound20902 : H12AffineFastState.Bounded env20902 := by
  intro p hp
  have h : env20902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20901_20902 : H12AffineEnvironment.transform 6 56 env20901 = env20902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env20901 == env20902) = true)

def env20903 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,8201,147521,230468,8328,672784,925773,16385,676864,1073741824,131141,4294967296,257,4295206119,1345,512]

theorem envBound20903 : H12AffineFastState.Bounded env20903 := by
  intro p hp
  have h : env20903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20851_20903 : H12AffineEnvironment.transform 10 1 env20851 = env20903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env20851 == env20903) = true)

def env20904 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1344,262144,524288,32769,4097,8201,17665,98564,8328,541008,795917,16385,545088,1073741824,1285,4294967296,257,4295074215,1345,512]

theorem envBound20904 : H12AffineFastState.Bounded env20904 := by
  intro p hp
  have h : env20904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20903_20904 : H12AffineEnvironment.transform 16 1344 env20903 = env20904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env20903 == env20904) = true)

theorem identity20904 : scanCanonicalize (H12AffineFastState.compose env20904 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 548941) := by decide +kernel

theorem selectedBound20904 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env20905 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1344,262144,524288,32769,4097,8201,17665,98564,8328,541008,795917,16385,545088,548941,1285,4294967296,257,4295074215,1345,512]

theorem envBound20905 : H12AffineFastState.Bounded env20905 := by
  intro p hp
  have h : env20905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20904_20905 : H12AffineEnvironment.transform 29 548941 env20904 = env20905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 548941 env20904 == env20905) = true)

def env20906 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1344,262144,304168,32769,4097,8201,17665,98564,8328,320888,33061,16385,324968,312421,1285,4294967296,257,4295074215,1345,512]

theorem envBound20906 : H12AffineFastState.Bounded env20906 := by
  intro p hp
  have h : env20906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20905_20906 : H12AffineEnvironment.transform 18 304168 env20905 = env20906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 304168 env20905 == env20906) = true)

theorem identity20906 : scanCanonicalize (H12AffineFastState.compose env20906 (packedSelected [4,9,18] rootPS)) = affineNative (2^(17+1) ^^^ 50276) := by decide +kernel

theorem selectedBound20906 : packedSelected [4,9,18] rootPS < 2^1333 := by decide +kernel

def env20907 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1344,50276,24652,32769,4097,8201,17665,98564,8328,8476,33061,16385,12556,1,1285,4294967296,257,4295074215,1345,512]

theorem envBound20907 : H12AffineFastState.Bounded env20907 := by
  intro p hp
  have h : env20907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20906_20907 : H12AffineEnvironment.transform 17 50276 env20906 = env20907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 50276 env20906 == env20907) = true)

theorem identity20907 : scanCanonicalize (H12AffineFastState.compose env20907 (packedSelected [5,8,13,15,19] rootPS)) = affineNative (2^(15+1) ^^^ 53726) := by decide +kernel

theorem selectedBound20907 : packedSelected [5,8,13,15,19] rootPS < 2^1333 := by decide +kernel

def env20908 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,53726,1344,50276,24652,32769,4097,8201,17665,20698,8328,8476,33061,16385,12556,1,1285,4294967296,257,4294996089,1345,512]

theorem envBound20908 : H12AffineFastState.Bounded env20908 := by
  intro p hp
  have h : env20908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20907_20908 : H12AffineEnvironment.transform 15 53726 env20907 = env20908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53726 env20907 == env20908) = true)

theorem identity20908 : scanCanonicalize (H12AffineFastState.compose env20908 (packedSelected [1,3,5,8,12,13,15,17] rootPS)) = affineNative (2^(13+1) ^^^ 4176) := by decide +kernel

theorem selectedBound20908 : packedSelected [1,3,5,8,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env20909 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,4176,32768,33166,1344,37940,12316,32769,4097,8201,5457,138,8328,8476,33061,4177,12556,1,1285,4294967296,257,4294975529,1345,512]

theorem envBound20909 : H12AffineFastState.Bounded env20909 := by
  intro p hp
  have h : env20909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20908_20909 : H12AffineEnvironment.transform 13 4176 env20908 = env20909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env20908 == env20909) = true)

theorem identity20909 : scanCanonicalize (H12AffineFastState.compose env20909 (packedSelected [1,3,4,9,10,13,15] rootPS)) = affineNative (2^(12+1) ^^^ 5149) := by decide +kernel

theorem selectedBound20909 : packedSelected [1,3,4,9,10,13,15] rootPS < 2^1333 := by decide +kernel

def env20910 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,5149,4176,32768,33166,1344,37940,1025,32769,4097,5140,5457,138,5269,5377,33061,4177,1297,1,1285,4294967296,257,4294972468,1345,512]

theorem envBound20910 : H12AffineFastState.Bounded env20910 := by
  intro p hp
  have h : env20910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20909_20910 : H12AffineEnvironment.transform 12 5149 env20909 = env20910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5149 env20909 == env20910) = true)

theorem identity20910 : scanCanonicalize (H12AffineFastState.compose env20910 (packedSelected [5,8] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound20910 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env20911 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1297,268,1345,32768,33166,1344,33061,1025,32769,1296,261,64,138,388,16,33061,1344,1297,1,1285,4294967296,257,4294967589,1345,512]

theorem envBound20911 : H12AffineFastState.Bounded env20911 := by
  intro p hp
  have h : env20911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20910_20911 : H12AffineEnvironment.transform 11 1297 env20910 = env20911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env20910 == env20911) = true)

theorem identity20911 : scanCanonicalize (H12AffineFastState.compose env20911 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound20911 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env20912 : List Nat := [2,4,8,16,32,64,128,256,136,1024,1,1297,268,1345,32768,33166,1344,33061,1025,32769,1296,261,64,138,388,16,33061,1344,1297,1,1285,4294967296,257,4294967589,1345,136]

theorem envBound20912 : H12AffineFastState.Bounded env20912 := by
  intro p hp
  have h : env20912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20911_20912 : H12AffineEnvironment.transform 8 136 env20911 = env20912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env20911 == env20912) = true)

theorem identity20912 : scanCanonicalize (H12AffineFastState.compose env20912 (packedSelected [2,4] rootPS)) = affineNative (2^(14+1) ^^^ 113) := by decide +kernel

theorem selectedBound20912 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env20913 : List Nat := [2,4,8,16,32,64,128,256,136,1024,1,1297,268,1345,113,511,1344,340,1025,112,1296,261,64,138,388,16,340,1344,1297,1,1285,4294967296,257,4294967589,1345,136]

theorem envBound20913 : H12AffineFastState.Bounded env20913 := by
  intro p hp
  have h : env20913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20912_20913 : H12AffineEnvironment.transform 14 113 env20912 = env20913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 113 env20912 == env20913) = true)

theorem identity20913 : scanCanonicalize (H12AffineFastState.compose env20913 (packedSelected [5] rootPS)) = affineNative (2^(6+1) ^^^ 121) := by decide +kernel

theorem selectedBound20913 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env20914 : List Nat := [2,4,8,16,32,64,121,256,113,1024,1,1297,268,1345,113,262,1344,340,1025,112,1296,261,64,115,381,16,340,1344,1297,1,1285,4294967296,257,4294967589,1345,113]

theorem envBound20914 : H12AffineFastState.Bounded env20914 := by
  intro p hp
  have h : env20914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20913_20914 : H12AffineEnvironment.transform 6 121 env20913 = env20914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env20913 == env20914) = true)

theorem identity20914 : scanCanonicalize (H12AffineFastState.compose env20914 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 1) := by decide +kernel

theorem selectedBound20914 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20915 : List Nat := [2,4,8,16,32,64,121,256,113,1024,1,1297,268,1345,113,262,1344,340,1025,112,1296,261,64,115,381,16,340,1344,1297,1,1285,1,257,292,1345,113]

theorem envBound20915 : H12AffineFastState.Bounded env20915 := by
  intro p hp
  have h : env20915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20914_20915 : H12AffineEnvironment.transform 31 1 env20914 = env20915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1 env20914 == env20915) = true)

def env20916 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1344,262144,304169,32769,4097,8201,17665,98564,8328,320889,33060,16385,324969,312420,1285,4294967296,257,4295074215,1345,512]

theorem envBound20916 : H12AffineFastState.Bounded env20916 := by
  intro p hp
  have h : env20916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20905_20916 : H12AffineEnvironment.transform 18 304169 env20905 = env20916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 304169 env20905 == env20916) = true)

theorem identity20916 : scanCanonicalize (H12AffineFastState.compose env20916 (packedSelected [5,8,13,15,19] rootPS)) = affineNative (2^(15+1) ^^^ 50382) := by decide +kernel

theorem selectedBound20916 : packedSelected [5,8,13,15,19] rootPS < 2^1333 := by decide +kernel

def env20917 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,50382,1344,262144,304169,32769,4097,8201,17665,17866,8328,320889,33060,16385,324969,312420,1285,4294967296,257,4294993257,1345,512]

theorem envBound20917 : H12AffineFastState.Bounded env20917 := by
  intro p hp
  have h : env20917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20916_20917 : H12AffineEnvironment.transform 15 50382 env20916 = env20917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 50382 env20916 == env20917) = true)

theorem identity20917 : scanCanonicalize (H12AffineFastState.compose env20917 (packedSelected [0,5,7,8,10,12,20,21] rootPS)) = affineNative (2^(17+1) ^^^ 58729) := by decide +kernel

theorem selectedBound20917 : packedSelected [0,5,7,8,10,12,20,21] rootPS < 2^1333 := by decide +kernel

def env20918 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,50382,1344,58729,16704,32769,4097,8201,17665,17866,8328,16,33060,16385,4096,8461,1285,4294967296,257,4294993257,1345,512]

theorem envBound20918 : H12AffineFastState.Bounded env20918 := by
  intro p hp
  have h : env20918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20917_20918 : H12AffineEnvironment.transform 17 58729 env20917 = env20918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 58729 env20917 == env20918) = true)

theorem identity20918 : scanCanonicalize (H12AffineFastState.compose env20918 (packedSelected [1,5,8,24] rootPS)) = affineNative (2^(13+1) ^^^ 1345) := by decide +kernel

theorem selectedBound20918 : packedSelected [1,5,8,24] rootPS < 2^1333 := by decide +kernel

def env20919 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,1345,32768,33167,1344,41000,1025,32769,4097,8201,64,139,8328,16,33060,1344,4096,8461,1285,4294967296,257,4294975528,1345,512]

theorem envBound20919 : H12AffineFastState.Bounded env20919 := by
  intro p hp
  have h : env20919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20918_20919 : H12AffineEnvironment.transform 13 1345 env20918 = env20919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env20918 == env20919) = true)

theorem identity20919 : scanCanonicalize (H12AffineFastState.compose env20919 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(14+1) ^^^ 292) := by decide +kernel

theorem selectedBound20919 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env20920 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,1345,292,171,1344,8460,1025,293,4097,8201,64,139,8328,16,0,1344,4096,8461,1285,4294967296,257,4294975528,1345,512]

theorem envBound20920 : H12AffineFastState.Bounded env20920 := by
  intro p hp
  have h : env20920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20919_20920 : H12AffineEnvironment.transform 14 292 env20919 = env20920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 292 env20919 == env20920) = true)

theorem identity20920 : scanCanonicalize (H12AffineFastState.compose env20920 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound20920 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env20921 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1297,8192,1345,292,171,1344,8460,1025,293,1296,8201,64,139,8328,16,0,1344,1297,8461,1285,4294967296,257,4294975528,1345,512]

theorem envBound20921 : H12AffineFastState.Bounded env20921 := by
  intro p hp
  have h : env20921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20920_20921 : H12AffineEnvironment.transform 11 1297 env20920 = env20921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env20920 == env20921) = true)

def env20922 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1297,672,1345,292,171,1344,940,1025,293,1296,681,64,139,552,16,0,1344,1297,941,1285,4294967296,257,4294967944,1345,512]

theorem envBound20922 : H12AffineFastState.Bounded env20922 := by
  intro p hp
  have h : env20922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20921_20922 : H12AffineEnvironment.transform 12 672 env20921 = env20922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 672 env20921 == env20922) = true)

theorem identity20922 : scanCanonicalize (H12AffineFastState.compose env20922 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 429) := by decide +kernel

theorem selectedBound20922 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20923 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1297,672,1345,292,171,1344,940,1025,293,1296,681,64,139,552,16,0,1344,1297,941,1285,429,257,805,1345,512]

theorem envBound20923 : H12AffineFastState.Bounded env20923 := by
  intro p hp
  have h : env20923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20922_20923 : H12AffineEnvironment.transform 31 429 env20922 = env20923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 429 env20922 == env20923) = true)

theorem identity20923 : scanCanonicalize (H12AffineFastState.compose env20923 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound20923 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20924 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1,1297,553,1345,292,34,1344,805,1025,293,1296,544,64,2,552,16,0,1344,1297,804,1285,292,257,805,1345,512]

theorem envBound20924 : H12AffineFastState.Bounded env20924 := by
  intro p hp
  have h : env20924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20923_20924 : H12AffineEnvironment.transform 6 9 env20923 = env20924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20923 == env20924) = true)

def env20925 : List Nat := [2,4,8,16,32,64,9,256,0,1024,1,1297,41,1345,292,34,1344,293,1025,293,1296,32,64,2,40,16,0,1344,1297,292,1285,292,257,293,1345,0]

theorem envBound20925 : H12AffineFastState.Bounded env20925 := by
  intro p hp
  have h : env20925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20924_20925 : H12AffineEnvironment.transform 8 0 env20924 = env20925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env20924 == env20925) = true)

theorem identity20925 : scanCanonicalize (H12AffineFastState.compose env20925 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound20925 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20926 : List Nat := [2,4,8,16,32,49,9,256,0,1024,1,1297,41,1328,292,34,1329,293,1025,293,1296,32,49,2,40,16,0,1329,1297,292,1285,292,257,293,1328,0]

theorem envBound20926 : H12AffineFastState.Bounded env20926 := by
  intro p hp
  have h : env20926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20925_20926 : H12AffineEnvironment.transform 5 49 env20925 = env20926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env20925 == env20926) = true)

theorem identity20926 : scanCanonicalize (H12AffineFastState.compose env20926 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound20926 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env20927 : List Nat := [2,4,8,16,32,49,9,5,0,1024,1,1044,41,1077,33,34,1076,32,1025,32,1045,32,49,2,40,16,0,1076,1044,33,1024,33,4,32,1077,0]

theorem envBound20927 : H12AffineFastState.Bounded env20927 := by
  intro p hp
  have h : env20927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20926_20927 : H12AffineEnvironment.transform 7 5 env20926 = env20927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env20926 == env20927) = true)

theorem identity20927 : scanCanonicalize (H12AffineFastState.compose env20927 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound20927 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env20928 : List Nat := [2,4,8,16,1,16,9,5,0,1024,1,1044,8,1044,0,3,1045,1,1025,1,1045,1,16,2,9,16,0,1045,1044,0,1024,0,4,1,1044,0]

theorem envBound20928 : H12AffineFastState.Bounded env20928 := by
  intro p hp
  have h : env20928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20927_20928 : H12AffineEnvironment.transform 4 1 env20927 = env20928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env20927 == env20928) = true)

def leafEnv20928 : List Nat := [2,4,8,16,1,16,9,5,0,1024,1,1044,8,1044,0,3,1045,1,1025,1,1045,1,16,2,1025,9,1,16,0,1045,1044,0,1024,0,4,1,5,3,1044,0,0,1045,1]

def active20928 : List Nat := [0,1,2,3,9]

def tree20928 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20928 : H12WitnessSearch.Good tree20928 := H12GlobalWitnessIndex.good

theorem leafIdentity20928 : H12AffineFastState.composeSystem env20928 rootObs = leafEnv20928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20928 rootObs == leafEnv20928) = true)

theorem terminalChecked20928 : H12PackedTerminal.terminalCheckFast leafEnv20928 active20928 tree20928 = true := by decide +kernel

def env20929 : List Nat := [2,4,8,16,32,64,9,256,1,1024,1,1297,40,1345,292,34,1344,292,1025,293,1296,33,64,2,41,16,0,1344,1297,293,1285,292,257,292,1345,1]

theorem envBound20929 : H12AffineFastState.Bounded env20929 := by
  intro p hp
  have h : env20929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20924_20929 : H12AffineEnvironment.transform 8 1 env20924 = env20929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env20924 == env20929) = true)

theorem identity20929 : scanCanonicalize (H12AffineFastState.compose env20929 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound20929 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20930 : List Nat := [2,4,8,16,32,16,9,256,1,1024,1,1297,40,1297,292,34,1296,292,1025,293,1296,33,16,2,41,16,0,1296,1297,293,1285,292,257,292,1297,1]

theorem envBound20930 : H12AffineFastState.Bounded env20930 := by
  intro p hp
  have h : env20930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20929_20930 : H12AffineEnvironment.transform 5 16 env20929 = env20930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20929 == env20930) = true)

def env20931 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1297,673,1345,292,171,1344,941,1025,293,1296,680,64,139,553,16,0,1344,1297,940,1285,4294967296,257,4294967945,1345,512]

theorem envBound20931 : H12AffineFastState.Bounded env20931 := by
  intro p hp
  have h : env20931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20921_20931 : H12AffineEnvironment.transform 12 673 env20921 = env20931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 673 env20921 == env20931) = true)

theorem identity20931 : scanCanonicalize (H12AffineFastState.compose env20931 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 648) := by decide +kernel

theorem selectedBound20931 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20932 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1297,673,1345,292,171,1344,941,1025,293,1296,680,64,139,553,16,0,1344,1297,940,1285,648,257,1,1345,512]

theorem envBound20932 : H12AffineFastState.Bounded env20932 := by
  intro p hp
  have h : env20932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20931_20932 : H12AffineEnvironment.transform 31 648 env20931 = env20932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 648 env20931 == env20932) = true)

theorem identity20932 : scanCanonicalize (H12AffineFastState.compose env20932 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound20932 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20933 : List Nat := [2,4,8,16,32,64,89,256,512,1024,1,1297,632,1345,292,114,1344,884,1025,293,1296,625,64,82,553,16,0,1344,1297,885,1285,593,257,1,1345,512]

theorem envBound20933 : H12AffineFastState.Bounded env20933 := by
  intro p hp
  have h : env20933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20932_20933 : H12AffineEnvironment.transform 6 89 env20932 = env20933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env20932 == env20933) = true)

def env20934 : List Nat := [2,4,8,16,32,64,89,256,80,1024,1,1297,40,1345,292,114,1344,292,1025,293,1296,33,64,82,121,16,0,1344,1297,293,1285,1,257,1,1345,80]

theorem envBound20934 : H12AffineFastState.Bounded env20934 := by
  intro p hp
  have h : env20934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20933_20934 : H12AffineEnvironment.transform 8 80 env20933 = env20934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 80 env20933 == env20934) = true)

theorem identity20934 : scanCanonicalize (H12AffineFastState.compose env20934 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound20934 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20935 : List Nat := [2,4,8,16,32,64,89,36,80,1024,1,1077,40,1125,0,114,1124,0,1025,1,1076,33,64,82,121,16,0,1124,1077,1,1057,1,37,1,1125,80]

theorem envBound20935 : H12AffineFastState.Bounded env20935 := by
  intro p hp
  have h : env20935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20934_20935 : H12AffineEnvironment.transform 7 36 env20934 = env20935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env20934 == env20935) = true)

def env20936 : List Nat := [2,4,8,16,32,64,89,256,81,1024,1,1297,41,1345,292,114,1344,293,1025,293,1296,32,64,82,120,16,0,1344,1297,292,1285,0,257,1,1345,81]

theorem envBound20936 : H12AffineFastState.Bounded env20936 := by
  intro p hp
  have h : env20936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20933_20936 : H12AffineEnvironment.transform 8 81 env20933 = env20936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env20933 == env20936) = true)

theorem identity20936 : scanCanonicalize (H12AffineFastState.compose env20936 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound20936 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20937 : List Nat := [2,4,8,16,0,64,89,256,81,1024,1,1297,9,1345,260,82,1344,261,1025,261,1296,0,64,82,88,16,0,1344,1297,260,1285,0,257,1,1345,81]

theorem envBound20937 : H12AffineFastState.Bounded env20937 := by
  intro p hp
  have h : env20937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20936_20937 : H12AffineEnvironment.transform 4 0 env20936 = env20937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env20936 == env20937) = true)

theorem identity20937 : scanCanonicalize (H12AffineFastState.compose env20937 (packedSelected [4] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound20937 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env20938 : List Nat := [2,4,8,16,0,16,9,256,1,1024,1,1297,9,1297,260,2,1296,261,1025,261,1296,0,16,2,8,16,0,1296,1297,260,1285,0,257,1,1297,1]

theorem envBound20938 : H12AffineFastState.Bounded env20938 := by
  intro p hp
  have h : env20938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20937_20938 : H12AffineEnvironment.transform 5 16 env20937 = env20938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20937 == env20938) = true)

def leafEnv20938 : List Nat := [2,4,8,16,0,16,9,256,1,1024,1,1297,9,1297,260,2,1296,261,1025,261,1296,0,16,2,1284,8,1,16,0,1296,1297,260,1285,0,257,1,5,2,1297,1,0,1296,1]

def active20938 : List Nat := [0,1,2,3,7,9]

def tree20938 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20938 : H12WitnessSearch.Good tree20938 := H12GlobalWitnessIndex.good

theorem leafIdentity20938 : H12AffineFastState.composeSystem env20938 rootObs = leafEnv20938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20938 rootObs == leafEnv20938) = true)

theorem terminalChecked20938 : H12PackedTerminal.terminalCheckFast leafEnv20938 active20938 tree20938 = true := by decide +kernel

def env20939 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1345,262144,524288,32769,4097,8201,17664,98565,8328,541009,795916,16385,545089,1073741824,1284,4294967296,257,4295074214,1345,512]

theorem envBound20939 : H12AffineFastState.Bounded env20939 := by
  intro p hp
  have h : env20939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20903_20939 : H12AffineEnvironment.transform 16 1345 env20903 = env20939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env20903 == env20939) = true)

theorem identity20939 : scanCanonicalize (H12AffineFastState.compose env20939 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 548892) := by decide +kernel

theorem selectedBound20939 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env20940 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1345,262144,524288,32769,4097,8201,17664,98565,8328,541009,795916,16385,545089,548892,1284,4294967296,257,4295074214,1345,512]

theorem envBound20940 : H12AffineFastState.Bounded env20940 := by
  intro p hp
  have h : env20940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20939_20940 : H12AffineEnvironment.transform 29 548892 env20939 = env20940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 548892 env20939 == env20940) = true)

theorem identity20940 : scanCanonicalize (H12AffineFastState.compose env20940 (packedSelected [4,9,16] rootPS)) = affineNative (2^(18+1) ^^^ 1025) := by decide +kernel

theorem selectedBound20940 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env20941 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1345,262144,1025,32769,4097,8201,17664,98565,8328,17744,270605,16385,21824,25629,1284,4294967296,257,4295074214,1345,512]

theorem envBound20941 : H12AffineFastState.Bounded env20941 := by
  intro p hp
  have h : env20941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20940_20941 : H12AffineEnvironment.transform 18 1025 env20940 = env20941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env20940 == env20941) = true)

theorem identity20941 : scanCanonicalize (H12AffineFastState.compose env20941 (packedSelected [1,5,8,15,17,21,24,38] rootPS)) = affineNative (2^(15+1) ^^^ 50335) := by decide +kernel

theorem selectedBound20941 : packedSelected [1,5,8,15,17,21,24,38] rootPS < 2^1333 := by decide +kernel

def env20942 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,50335,1345,262144,1025,32769,4097,8201,17664,17818,8328,17744,270605,16385,21824,25629,1284,4294967296,257,4294993209,1345,512]

theorem envBound20942 : H12AffineFastState.Bounded env20942 := by
  intro p hp
  have h : env20942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20941_20942 : H12AffineEnvironment.transform 15 50335 env20941 = env20942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 50335 env20941 == env20942) = true)

theorem identity20942 : scanCanonicalize (H12AffineFastState.compose env20942 (packedSelected [13,21] rootPS)) = affineNative (2^(13+1) ^^^ 4176) := by decide +kernel

theorem selectedBound20942 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env20943 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,4176,32768,38095,1345,262144,1025,32769,4097,8201,5456,5578,8328,5376,270605,4177,1296,13389,1284,4294967296,257,4294980969,1345,512]

theorem envBound20943 : H12AffineFastState.Bounded env20943 := by
  intro p hp
  have h : env20943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20942_20943 : H12AffineEnvironment.transform 13 4176 env20942 = env20943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env20942 == env20943) = true)

theorem identity20943 : scanCanonicalize (H12AffineFastState.compose env20943 (packedSelected [3,5,10] rootPS)) = affineNative (2^(31+1) ^^^ 8321) := by decide +kernel

theorem selectedBound20943 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env20944 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,4176,32768,38095,1345,262144,1025,32769,4097,8201,5456,5578,8328,5376,270605,4177,1296,13389,1284,8321,257,5608,1345,512]

theorem envBound20944 : H12AffineFastState.Bounded env20944 := by
  intro p hp
  have h : env20944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20943_20944 : H12AffineEnvironment.transform 31 8321 env20943 = env20944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 8321 env20943 == env20944) = true)

theorem identity20944 : scanCanonicalize (H12AffineFastState.compose env20944 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 41001) := by decide +kernel

theorem selectedBound20944 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env20945 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,4176,32768,38095,1345,41001,1025,32769,4097,8201,5456,5578,8328,5376,33060,4177,1296,13389,1284,8321,257,5608,1345,512]

theorem envBound20945 : H12AffineFastState.Bounded env20945 := by
  intro p hp
  have h : env20945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20944_20945 : H12AffineEnvironment.transform 17 41001 env20944 = env20945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 41001 env20944 == env20945) = true)

theorem identity20945 : scanCanonicalize (H12AffineFastState.compose env20945 (packedSelected [3,5,12,13] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound20945 : packedSelected [3,5,12,13] rootPS < 2^1333 := by decide +kernel

def env20946 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,469,4176,32768,38095,1345,33276,1025,32769,4097,476,5456,5578,349,5376,33060,4177,1296,5528,1284,340,257,5608,1345,512]

theorem envBound20946 : H12AffineFastState.Bounded env20946 := by
  intro p hp
  have h : env20946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20945_20946 : H12AffineEnvironment.transform 12 469 env20945 = env20946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env20945 == env20946) = true)

theorem identity20946 : scanCanonicalize (H12AffineFastState.compose env20946 (packedSelected [1,2,3,4,5,6,8,9,12] rootPS)) = affineNative (2^(11+1) ^^^ 1021) := by decide +kernel

theorem selectedBound20946 : packedSelected [1,2,3,4,5,6,8,9,12] rootPS < 2^1333 := by decide +kernel

def env20947 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1021,469,941,32768,34610,1345,33276,1025,32769,1020,476,1709,1591,349,1789,33060,940,1296,1637,1284,340,257,1557,1345,512]

theorem envBound20947 : H12AffineFastState.Bounded env20947 := by
  intro p hp
  have h : env20947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20946_20947 : H12AffineEnvironment.transform 11 1021 env20946 = env20947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1021 env20946 == env20947) = true)

theorem identity20947 : scanCanonicalize (H12AffineFastState.compose env20947 (packedSelected [1,2,4,5,6,9,17] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound20947 : packedSelected [1,2,4,5,6,9,17] rootPS < 2^1333 := by decide +kernel

def env20948 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1021,469,941,137,1979,1345,373,1025,136,1020,476,1709,1591,349,1789,429,940,1296,1637,1284,340,257,1557,1345,512]

theorem envBound20948 : H12AffineFastState.Bounded env20948 := by
  intro p hp
  have h : env20948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20947_20948 : H12AffineEnvironment.transform 14 137 env20947 = env20948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env20947 == env20948) = true)

theorem identity20948 : scanCanonicalize (H12AffineFastState.compose env20948 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 581) := by decide +kernel

theorem selectedBound20948 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env20949 : List Nat := [2,4,8,16,32,64,128,256,512,581,1,1021,469,941,137,510,772,373,580,136,1020,476,232,114,349,184,429,940,853,32,833,340,257,80,772,512]

theorem envBound20949 : H12AffineFastState.Bounded env20949 := by
  intro p hp
  have h : env20949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20948_20949 : H12AffineEnvironment.transform 9 581 env20948 = env20949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 581 env20948 == env20949) = true)

theorem identity20949 : scanCanonicalize (H12AffineFastState.compose env20949 (packedSelected [2,3,5,18] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound20949 : packedSelected [2,3,5,18] rootPS < 2^1333 := by decide +kernel

def env20950 : List Nat := [2,4,8,16,1,64,128,256,512,581,1,988,469,908,137,479,772,340,580,136,989,476,201,83,349,153,396,909,853,1,833,340,257,80,772,512]

theorem envBound20950 : H12AffineFastState.Bounded env20950 := by
  intro p hp
  have h : env20950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20949_20950 : H12AffineEnvironment.transform 4 1 env20949 = env20950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env20949 == env20950) = true)

theorem identity20950 : scanCanonicalize (H12AffineFastState.compose env20950 (packedSelected [0,2,4] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound20950 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env20951 : List Nat := [2,4,8,16,1,16,128,256,512,533,1,908,389,908,137,399,772,260,532,136,909,396,153,3,269,153,396,909,773,1,785,260,257,0,772,512]

theorem envBound20951 : H12AffineFastState.Bounded env20951 := by
  intro p hp
  have h : env20951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20950_20951 : H12AffineEnvironment.transform 5 16 env20950 = env20951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20950 == env20951) = true)

theorem identity20951 : scanCanonicalize (H12AffineFastState.compose env20951 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound20951 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20952 : List Nat := [2,4,8,16,1,16,128,21,512,533,1,665,144,665,137,154,529,17,532,136,664,153,153,3,24,153,153,664,528,1,516,17,20,0,529,512]

theorem envBound20952 : H12AffineFastState.Bounded env20952 := by
  intro p hp
  have h : env20952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20951_20952 : H12AffineEnvironment.transform 7 21 env20951 = env20952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env20951 == env20952) = true)

theorem identity20952 : scanCanonicalize (H12AffineFastState.compose env20952 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound20952 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env20953 : List Nat := [2,4,8,16,1,16,128,21,1,20,1,152,144,152,137,154,16,17,21,136,153,153,153,3,24,153,153,153,17,1,5,17,20,0,16,1]

theorem envBound20953 : H12AffineFastState.Bounded env20953 := by
  intro p hp
  have h : env20953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20952_20953 : H12AffineEnvironment.transform 8 1 env20952 = env20953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env20952 == env20953) = true)

def env20954 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,10249,147521,230468,8328,672784,927821,16385,676864,1073741824,131141,4294967296,257,4295208167,1345,512]

theorem envBound20954 : H12AffineFastState.Bounded env20954 := by
  intro p hp
  have h : env20954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20850_20954 : H12AffineEnvironment.transform 21 10249 env20850 = env20954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10249 env20850 == env20954) = true)

def env20955 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,8201,147521,230468,8328,672784,925773,16385,676864,1073741824,131141,4294967296,257,4295206119,1345,512]

theorem envBound20955 : H12AffineFastState.Bounded env20955 := by
  intro p hp
  have h : env20955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20954_20955 : H12AffineEnvironment.transform 10 0 env20954 = env20955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env20954 == env20955) = true)

def env20956 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1344,262144,524288,32769,4097,8201,17665,98564,8328,541008,795917,16385,545088,1073741824,1285,4294967296,257,4295074215,1345,512]

theorem envBound20956 : H12AffineFastState.Bounded env20956 := by
  intro p hp
  have h : env20956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20955_20956 : H12AffineEnvironment.transform 16 1344 env20955 = env20956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env20955 == env20956) = true)

theorem identity20956 : scanCanonicalize (H12AffineFastState.compose env20956 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 581992) := by decide +kernel

theorem selectedBound20956 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env20957 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1344,262144,524288,32769,4097,8201,17665,98564,8328,541008,795917,16385,545088,581992,1285,4294967296,257,4295074215,1345,512]

theorem envBound20957 : H12AffineFastState.Bounded env20957 := by
  intro p hp
  have h : env20957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20956_20957 : H12AffineEnvironment.transform 29 581992 env20956 = env20957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 581992 env20956 == env20957) = true)

def env20958 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1344,262144,304168,32769,4097,8201,17665,98564,8328,320888,33061,16385,324968,279872,1285,4294967296,257,4295074215,1345,512]

theorem envBound20958 : H12AffineFastState.Bounded env20958 := by
  intro p hp
  have h : env20958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20957_20958 : H12AffineEnvironment.transform 18 304168 env20957 = env20958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 304168 env20957 == env20958) = true)

theorem identity20958 : scanCanonicalize (H12AffineFastState.compose env20958 (packedSelected [4,9,18] rootPS)) = affineNative (2^(14+1) ^^^ 17509) := by decide +kernel

theorem selectedBound20958 : packedSelected [4,9,18] rootPS < 2^1333 := by decide +kernel

def env20959 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,17509,65536,1344,262144,286797,17508,4097,8201,17665,83297,8328,270621,17728,16385,274701,279872,1285,4294967296,257,4295058882,1345,512]

theorem envBound20959 : H12AffineFastState.Bounded env20959 := by
  intro p hp
  have h : env20959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20958_20959 : H12AffineEnvironment.transform 14 17509 env20958 = env20959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 17509 env20958 == env20959) = true)

theorem identity20959 : scanCanonicalize (H12AffineFastState.compose env20959 (packedSelected [5,8,13,15,19] rootPS)) = affineNative (2^(15+1) ^^^ 17898) := by decide +kernel

theorem selectedBound20959 : packedSelected [5,8,13,15,19] rootPS < 2^1333 := by decide +kernel

def env20960 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,17509,17898,1344,262144,286797,17508,4097,8201,17665,139,8328,270621,17728,16385,274701,279872,1285,4294967296,257,4294975528,1345,512]

theorem envBound20960 : H12AffineFastState.Bounded env20960 := by
  intro p hp
  have h : env20960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20959_20960 : H12AffineEnvironment.transform 15 17898 env20959 = env20960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 17898 env20959 == env20960) = true)

def env20961 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,17509,17898,1344,26592,1965,17508,4097,8201,17665,139,8328,18173,17728,16385,22253,8864,1285,4294967296,257,4294975528,1345,512]

theorem envBound20961 : H12AffineFastState.Bounded env20961 := by
  intro p hp
  have h : env20961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20960_20961 : H12AffineEnvironment.transform 17 26592 env20960 = env20961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 26592 env20960 == env20961) = true)

theorem identity20961 : scanCanonicalize (H12AffineFastState.compose env20961 (packedSelected [1,3,10,13] rootPS)) = affineNative (2^(13+1) ^^^ 4176) := by decide +kernel

theorem selectedBound20961 : packedSelected [1,3,10,13] rootPS < 2^1333 := by decide +kernel

def env20962 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,4176,5173,5562,1344,14256,1965,5172,4097,8201,5457,139,8328,5805,5392,4177,1725,8864,1285,4294967296,257,4294975528,1345,512]

theorem envBound20962 : H12AffineFastState.Bounded env20962 := by
  intro p hp
  have h : env20962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20961_20962 : H12AffineEnvironment.transform 13 4176 env20961 = env20962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env20961 == env20962) = true)

theorem identity20962 : scanCanonicalize (H12AffineFastState.compose env20962 (packedSelected [0,7,12] rootPS)) = affineNative (2^(8+1) ^^^ 428) := by decide +kernel

theorem selectedBound20962 : packedSelected [0,7,12] rootPS < 2^1333 := by decide +kernel

def env20963 : List Nat := [2,4,8,16,32,64,128,256,428,1024,0,4096,8192,4176,5173,5562,1344,13340,1025,5172,4097,8201,5457,139,8328,5377,5392,4177,1297,8460,1285,4294967296,257,4294975528,1345,428]

theorem envBound20963 : H12AffineFastState.Bounded env20963 := by
  intro p hp
  have h : env20963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20962_20963 : H12AffineEnvironment.transform 8 428 env20962 = env20963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 428 env20962 == env20963) = true)

def env20964 : List Nat := [2,4,8,16,32,64,128,256,428,1024,0,1432,8192,1480,429,34,1344,8580,1025,428,1433,8201,201,139,8328,153,136,1481,1297,8460,1285,4294967296,257,4294975528,1345,428]

theorem envBound20964 : H12AffineFastState.Bounded env20964 := by
  intro p hp
  have h : env20964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20963_20964 : H12AffineEnvironment.transform 11 1432 env20963 = env20964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1432 env20963 == env20964) = true)

theorem identity20964 : scanCanonicalize (H12AffineFastState.compose env20964 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 8352) := by decide +kernel

theorem selectedBound20964 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20965 : List Nat := [2,4,8,16,32,64,128,256,428,1024,0,1432,8192,1480,429,34,1344,8580,1025,428,1433,8201,201,139,8328,153,136,1481,1297,8460,1285,8352,257,136,1345,428]

theorem envBound20965 : H12AffineFastState.Bounded env20965 := by
  intro p hp
  have h : env20965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20964_20965 : H12AffineEnvironment.transform 31 8352 env20964 = env20965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 8352 env20964 == env20965) = true)

def env20966 : List Nat := [2,4,8,16,32,16,128,256,428,1024,0,1432,8192,1432,429,34,1296,8580,1025,428,1433,8201,153,139,8328,153,136,1433,1297,8460,1285,8352,257,136,1297,428]

theorem envBound20966 : H12AffineFastState.Bounded env20966 := by
  intro p hp
  have h : env20966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20965_20966 : H12AffineEnvironment.transform 5 16 env20965 = env20966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20965 == env20966) = true)

theorem identity20966 : scanCanonicalize (H12AffineFastState.compose env20966 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound20966 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20967 : List Nat := [2,4,8,16,32,16,9,256,293,1024,0,1297,8192,1297,292,34,1296,8461,1025,293,1296,8201,16,2,8193,16,1,1296,1297,8460,1285,8233,257,1,1297,293]

theorem envBound20967 : H12AffineFastState.Bounded env20967 := by
  intro p hp
  have h : env20967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20966_20967 : H12AffineEnvironment.transform 6 9 env20966 = env20967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20966 == env20967) = true)

theorem identity20967 : scanCanonicalize (H12AffineFastState.compose env20967 (packedSelected [5] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound20967 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env20968 : List Nat := [2,4,8,16,32,16,9,256,293,1024,0,1297,41,1297,292,34,1296,292,1025,293,1296,32,16,2,40,16,1,1296,1297,293,1285,0,257,1,1297,293]

theorem envBound20968 : H12AffineFastState.Bounded env20968 := by
  intro p hp
  have h : env20968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20967_20968 : H12AffineEnvironment.transform 12 41 env20967 = env20968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env20967 == env20968) = true)

theorem identity20968 : scanCanonicalize (H12AffineFastState.compose env20968 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound20968 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20969 : List Nat := [2,4,8,16,32,16,9,4,33,1024,0,1045,41,1045,32,34,1044,32,1025,33,1044,32,16,2,40,16,1,1044,1045,33,1025,0,5,1,1045,33]

theorem envBound20969 : H12AffineFastState.Bounded env20969 := by
  intro p hp
  have h : env20969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20968_20969 : H12AffineEnvironment.transform 7 4 env20968 = env20969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env20968 == env20969) = true)

def leafEnv20969 : List Nat := [2,4,8,16,32,16,9,4,33,1024,0,1045,41,1045,32,34,1044,32,1025,33,1044,32,16,2,1024,40,1,16,1,1044,1045,33,1025,0,5,1,5,34,1045,33,0,1044,1]

def active20969 : List Nat := [0,1,2,3,4,9]

def tree20969 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20969 : H12WitnessSearch.Good tree20969 := H12GlobalWitnessIndex.good

theorem leafIdentity20969 : H12AffineFastState.composeSystem env20969 rootObs = leafEnv20969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20969 rootObs == leafEnv20969) = true)

theorem terminalChecked20969 : H12PackedTerminal.terminalCheckFast leafEnv20969 active20969 tree20969 = true := by decide +kernel

def env20970 : List Nat := [2,4,8,16,32,17,128,256,428,1024,0,1432,8192,1433,429,34,1297,8580,1025,428,1433,8201,152,139,8328,153,136,1432,1297,8460,1285,8352,257,136,1296,428]

theorem envBound20970 : H12AffineFastState.Bounded env20970 := by
  intro p hp
  have h : env20970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20965_20970 : H12AffineEnvironment.transform 5 17 env20965 = env20970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env20965 == env20970) = true)

theorem identity20970 : scanCanonicalize (H12AffineFastState.compose env20970 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound20970 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20971 : List Nat := [2,4,8,16,32,17,128,256,428,1024,0,1432,268,1433,429,34,1297,136,1025,428,1433,261,152,139,388,153,136,1432,1297,0,1285,428,257,136,1296,428]

theorem envBound20971 : H12AffineFastState.Bounded env20971 := by
  intro p hp
  have h : env20971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20970_20971 : H12AffineEnvironment.transform 12 268 env20970 = env20971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env20970 == env20971) = true)

theorem identity20971 : scanCanonicalize (H12AffineFastState.compose env20971 (packedSelected [2,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound20971 : packedSelected [2,4,5] rootPS < 2^1333 := by decide +kernel

def env20972 : List Nat := [2,4,8,16,32,17,128,172,0,1024,0,1076,160,1077,1,34,1213,136,1025,0,1077,169,152,139,40,153,136,1076,1213,0,1193,0,173,136,1212,0]

theorem envBound20972 : H12AffineFastState.Bounded env20972 := by
  intro p hp
  have h : env20972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20971_20972 : H12AffineEnvironment.transform 7 172 env20971 = env20972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env20971 == env20972) = true)

def env20973 : List Nat := [2,4,8,16,32,64,128,256,428,1024,0,1433,8192,1481,428,35,1344,8581,1025,429,1432,8201,200,139,8328,152,137,1480,1297,8460,1285,4294967296,257,4294975528,1345,428]

theorem envBound20973 : H12AffineFastState.Bounded env20973 := by
  intro p hp
  have h : env20973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20963_20973 : H12AffineEnvironment.transform 11 1433 env20963 = env20973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1433 env20963 == env20973) = true)

theorem identity20973 : scanCanonicalize (H12AffineFastState.compose env20973 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 292) := by decide +kernel

theorem selectedBound20973 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20974 : List Nat := [2,4,8,16,32,64,128,256,428,1024,0,1433,8192,1481,428,35,1344,8581,1025,429,1432,8201,200,139,8328,152,137,1480,1297,8460,1285,292,257,8460,1345,428]

theorem envBound20974 : H12AffineFastState.Bounded env20974 := by
  intro p hp
  have h : env20974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20973_20974 : H12AffineEnvironment.transform 31 292 env20973 = env20974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 292 env20973 == env20974) = true)

def env20975 : List Nat := [2,4,8,16,32,16,128,256,428,1024,0,1433,8192,1433,428,35,1296,8581,1025,429,1432,8201,152,139,8328,152,137,1432,1297,8460,1285,292,257,8460,1297,428]

theorem envBound20975 : H12AffineFastState.Bounded env20975 := by
  intro p hp
  have h : env20975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20974_20975 : H12AffineEnvironment.transform 5 16 env20974 = env20975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20974 == env20975) = true)

def env20976 : List Nat := [2,4,8,16,32,17,128,256,428,1024,0,1433,8192,1432,428,35,1297,8581,1025,429,1432,8201,153,139,8328,152,137,1433,1297,8460,1285,292,257,8460,1296,428]

theorem envBound20976 : H12AffineFastState.Bounded env20976 := by
  intro p hp
  have h : env20976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20974_20976 : H12AffineEnvironment.transform 5 17 env20974 = env20976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env20974 == env20976) = true)

theorem identity20976 : scanCanonicalize (H12AffineFastState.compose env20976 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound20976 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20977 : List Nat := [2,4,8,16,32,17,128,256,428,1024,0,1433,389,1432,428,35,1297,0,1025,429,1432,396,153,139,269,152,137,1433,1297,137,1285,292,257,137,1296,428]

theorem envBound20977 : H12AffineFastState.Bounded env20977 := by
  intro p hp
  have h : env20977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20976_20977 : H12AffineEnvironment.transform 12 389 env20976 = env20977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env20976 == env20977) = true)

theorem identity20977 : scanCanonicalize (H12AffineFastState.compose env20977 (packedSelected [2,4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound20977 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env20978 : List Nat := [2,4,8,16,32,17,128,37,137,1024,0,1212,160,1213,137,35,1076,0,1025,136,1213,169,153,139,40,152,137,1212,1076,137,1056,1,36,137,1077,137]

theorem envBound20978 : H12AffineFastState.Bounded env20978 := by
  intro p hp
  have h : env20978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20977_20978 : H12AffineEnvironment.transform 7 37 env20977 = env20978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env20977 == env20978) = true)

def env20979 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,17509,17898,1344,26593,1964,17508,4097,8201,17665,139,8328,18172,17728,16385,22252,8865,1285,4294967296,257,4294975528,1345,512]

theorem envBound20979 : H12AffineFastState.Bounded env20979 := by
  intro p hp
  have h : env20979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20960_20979 : H12AffineEnvironment.transform 17 26593 env20960 = env20979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 26593 env20960 == env20979) = true)

theorem identity20979 : scanCanonicalize (H12AffineFastState.compose env20979 (packedSelected [1,3,10,13] rootPS)) = affineNative (2^(13+1) ^^^ 5117) := by decide +kernel

theorem selectedBound20979 : packedSelected [1,3,10,13] rootPS < 2^1333 := by decide +kernel

def env20980 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,5117,6040,5655,1344,13340,1964,6041,4097,8201,5884,139,8328,5377,5821,5116,1297,8865,1285,4294967296,257,4294975528,1345,512]

theorem envBound20980 : H12AffineFastState.Bounded env20980 := by
  intro p hp
  have h : env20980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20979_20980 : H12AffineEnvironment.transform 13 5117 env20979 = env20980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5117 env20979 == env20980) = true)

theorem identity20980 : scanCanonicalize (H12AffineFastState.compose env20980 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 429) := by decide +kernel

theorem selectedBound20980 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env20981 : List Nat := [2,4,8,16,32,64,128,256,429,1024,0,4096,8192,4176,5173,5562,1344,13340,1025,5172,4097,8201,5457,139,8328,5377,5392,4177,1297,8460,1285,4294967296,257,4294975528,1345,429]

theorem envBound20981 : H12AffineFastState.Bounded env20981 := by
  intro p hp
  have h : env20981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20980_20981 : H12AffineEnvironment.transform 8 429 env20980 = env20981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 429 env20980 == env20981) = true)

def env20982 : List Nat := [2,4,8,16,32,64,128,256,429,1024,0,1432,8192,1480,429,34,1344,8580,1025,428,1433,8201,201,139,8328,153,136,1481,1297,8460,1285,4294967296,257,4294975528,1345,429]

theorem envBound20982 : H12AffineFastState.Bounded env20982 := by
  intro p hp
  have h : env20982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20981_20982 : H12AffineEnvironment.transform 11 1432 env20981 = env20982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1432 env20981 == env20982) = true)

theorem identity20982 : scanCanonicalize (H12AffineFastState.compose env20982 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 292) := by decide +kernel

theorem selectedBound20982 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20983 : List Nat := [2,4,8,16,32,64,128,256,429,1024,0,1432,8192,1480,429,34,1344,8580,1025,428,1433,8201,201,139,8328,153,136,1481,1297,8460,1285,292,257,8460,1345,429]

theorem envBound20983 : H12AffineFastState.Bounded env20983 := by
  intro p hp
  have h : env20983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20982_20983 : H12AffineEnvironment.transform 31 292 env20982 = env20983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 292 env20982 == env20983) = true)

def env20984 : List Nat := [2,4,8,16,32,16,128,256,429,1024,0,1432,8192,1432,429,34,1296,8580,1025,428,1433,8201,153,139,8328,153,136,1433,1297,8460,1285,292,257,8460,1297,429]

theorem envBound20984 : H12AffineFastState.Bounded env20984 := by
  intro p hp
  have h : env20984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20983_20984 : H12AffineEnvironment.transform 5 16 env20983 = env20984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20983 == env20984) = true)

def env20985 : List Nat := [2,4,8,16,32,16,8,256,293,1024,0,1296,8192,1296,293,34,1296,8460,1025,292,1297,8201,17,3,8192,17,0,1297,1297,8460,1285,292,257,8460,1297,293]

theorem envBound20985 : H12AffineFastState.Bounded env20985 := by
  intro p hp
  have h : env20985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20984_20985 : H12AffineEnvironment.transform 6 8 env20984 = env20985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20984 == env20985) = true)

theorem identity20985 : scanCanonicalize (H12AffineFastState.compose env20985 (packedSelected [3] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound20985 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env20986 : List Nat := [2,4,8,16,32,16,8,256,293,1024,0,1296,268,1296,293,34,1296,0,1025,292,1297,261,17,3,268,17,0,1297,1297,0,1285,292,257,0,1297,293]

theorem envBound20986 : H12AffineFastState.Bounded env20986 := by
  intro p hp
  have h : env20986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20985_20986 : H12AffineEnvironment.transform 12 268 env20985 = env20986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env20985 == env20986) = true)

def env20987 : List Nat := [2,4,8,16,0,16,8,256,261,1024,0,1296,268,1296,261,2,1296,0,1025,260,1297,261,17,3,268,17,0,1297,1297,0,1285,260,257,0,1297,261]

theorem envBound20987 : H12AffineFastState.Bounded env20987 := by
  intro p hp
  have h : env20987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20986_20987 : H12AffineEnvironment.transform 4 0 env20986 = env20987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env20986 == env20987) = true)

theorem identity20987 : scanCanonicalize (H12AffineFastState.compose env20987 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound20987 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20988 : List Nat := [2,4,8,16,0,16,8,4,1,1024,0,1044,8,1044,1,2,1044,0,1025,0,1045,1,17,3,8,17,0,1045,1045,0,1025,0,5,0,1045,1]

theorem envBound20988 : H12AffineFastState.Bounded env20988 := by
  intro p hp
  have h : env20988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20987_20988 : H12AffineEnvironment.transform 7 4 env20987 = env20988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env20987 == env20988) = true)

def leafEnv20988 : List Nat := [2,4,8,16,0,16,8,4,1,1024,0,1044,8,1044,1,2,1044,0,1025,0,1045,1,17,3,1024,8,1,17,0,1045,1045,0,1025,0,5,0,5,3,1045,1,0,1044,1]

def active20988 : List Nat := [0,1,2,3,9]

def tree20988 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20988 : H12WitnessSearch.Good tree20988 := H12GlobalWitnessIndex.good

theorem leafIdentity20988 : H12AffineFastState.composeSystem env20988 rootObs = leafEnv20988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20988 rootObs == leafEnv20988) = true)

theorem terminalChecked20988 : H12PackedTerminal.terminalCheckFast leafEnv20988 active20988 tree20988 = true := by decide +kernel

def env20989 : List Nat := [2,4,8,16,1,16,8,256,260,1024,0,1296,268,1296,260,3,1296,0,1025,261,1297,261,17,3,268,17,0,1297,1297,0,1285,261,257,0,1297,260]

theorem envBound20989 : H12AffineFastState.Bounded env20989 := by
  intro p hp
  have h : env20989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20986_20989 : H12AffineEnvironment.transform 4 1 env20986 = env20989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env20986 == env20989) = true)

def leafEnv20989 : List Nat := [2,4,8,16,1,16,8,256,260,1024,0,1296,268,1296,260,3,1296,0,1025,261,1297,261,17,3,1284,268,1,17,0,1297,1297,0,1285,261,257,0,5,2,1297,260,0,1296,1]

def active20989 : List Nat := [0,1,2,3,7,9]

def tree20989 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20989 : H12WitnessSearch.Good tree20989 := H12GlobalWitnessIndex.good

theorem leafIdentity20989 : H12AffineFastState.composeSystem env20989 rootObs = leafEnv20989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20989 rootObs == leafEnv20989) = true)

theorem terminalChecked20989 : H12PackedTerminal.terminalCheckFast leafEnv20989 active20989 tree20989 = true := by decide +kernel

def env20990 : List Nat := [2,4,8,16,32,16,9,256,292,1024,0,1297,8192,1297,292,34,1296,8461,1025,293,1296,8201,16,2,8193,16,1,1296,1297,8460,1285,292,257,8460,1297,292]

theorem envBound20990 : H12AffineFastState.Bounded env20990 := by
  intro p hp
  have h : env20990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20984_20990 : H12AffineEnvironment.transform 6 9 env20984 = env20990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20984 == env20990) = true)

theorem identity20990 : scanCanonicalize (H12AffineFastState.compose env20990 (packedSelected [5] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound20990 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env20991 : List Nat := [2,4,8,16,32,16,9,256,292,1024,0,1297,41,1297,292,34,1296,292,1025,293,1296,32,16,2,40,16,1,1296,1297,293,1285,292,257,293,1297,292]

theorem envBound20991 : H12AffineFastState.Bounded env20991 := by
  intro p hp
  have h : env20991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20990_20991 : H12AffineEnvironment.transform 12 41 env20990 = env20991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env20990 == env20991) = true)

theorem identity20991 : scanCanonicalize (H12AffineFastState.compose env20991 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound20991 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20992 : List Nat := [2,4,8,16,32,16,9,5,33,1024,0,1044,41,1044,33,34,1045,33,1025,32,1045,32,16,2,40,16,1,1045,1044,32,1024,33,4,32,1044,33]

theorem envBound20992 : H12AffineFastState.Bounded env20992 := by
  intro p hp
  have h : env20992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20991_20992 : H12AffineEnvironment.transform 7 5 env20991 = env20992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env20991 == env20992) = true)

theorem identity20992 : scanCanonicalize (H12AffineFastState.compose env20992 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound20992 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env20993 : List Nat := [2,4,8,16,1,16,9,5,0,1024,0,1044,8,1044,0,3,1045,0,1025,1,1045,1,16,2,9,16,1,1045,1044,1,1024,0,4,1,1044,0]

theorem envBound20993 : H12AffineFastState.Bounded env20993 := by
  intro p hp
  have h : env20993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20992_20993 : H12AffineEnvironment.transform 4 1 env20992 = env20993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env20992 == env20993) = true)

def leafEnv20993 : List Nat := [2,4,8,16,1,16,9,5,0,1024,0,1044,8,1044,0,3,1045,0,1025,1,1045,1,16,2,1025,9,1,16,1,1045,1044,1,1024,0,4,1,5,3,1044,0,0,1045,1]

def active20993 : List Nat := [0,1,2,3,9]

def tree20993 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20993 : H12WitnessSearch.Good tree20993 := H12GlobalWitnessIndex.good

theorem leafIdentity20993 : H12AffineFastState.composeSystem env20993 rootObs = leafEnv20993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20993 rootObs == leafEnv20993) = true)

theorem terminalChecked20993 : H12PackedTerminal.terminalCheckFast leafEnv20993 active20993 tree20993 = true := by decide +kernel

def env20994 : List Nat := [2,4,8,16,32,17,128,256,429,1024,0,1432,8192,1433,429,34,1297,8580,1025,428,1433,8201,152,139,8328,153,136,1432,1297,8460,1285,292,257,8460,1296,429]

theorem envBound20994 : H12AffineFastState.Bounded env20994 := by
  intro p hp
  have h : env20994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20983_20994 : H12AffineEnvironment.transform 5 17 env20983 = env20994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env20983 == env20994) = true)

theorem identity20994 : scanCanonicalize (H12AffineFastState.compose env20994 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound20994 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20995 : List Nat := [2,4,8,16,32,17,128,256,429,1024,0,1432,388,1433,429,34,1297,0,1025,428,1433,397,152,139,268,153,136,1432,1297,136,1285,292,257,136,1296,429]

theorem envBound20995 : H12AffineFastState.Bounded env20995 := by
  intro p hp
  have h : env20995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20994_20995 : H12AffineEnvironment.transform 12 388 env20994 = env20995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env20994 == env20995) = true)

def env20996 : List Nat := [2,4,8,16,32,64,128,256,429,1024,0,1433,8192,1481,428,35,1344,8581,1025,429,1432,8201,200,139,8328,152,137,1480,1297,8460,1285,4294967296,257,4294975528,1345,429]

theorem envBound20996 : H12AffineFastState.Bounded env20996 := by
  intro p hp
  have h : env20996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20981_20996 : H12AffineEnvironment.transform 11 1433 env20981 = env20996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1433 env20981 == env20996) = true)

theorem identity20996 : scanCanonicalize (H12AffineFastState.compose env20996 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 8352) := by decide +kernel

theorem selectedBound20996 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20997 : List Nat := [2,4,8,16,32,64,128,256,429,1024,0,1433,8192,1481,428,35,1344,8581,1025,429,1432,8201,200,139,8328,152,137,1480,1297,8460,1285,8352,257,136,1345,429]

theorem envBound20997 : H12AffineFastState.Bounded env20997 := by
  intro p hp
  have h : env20997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20996_20997 : H12AffineEnvironment.transform 31 8352 env20996 = env20997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 8352 env20996 == env20997) = true)

def env20998 : List Nat := [2,4,8,16,32,16,128,256,429,1024,0,1433,8192,1433,428,35,1296,8581,1025,429,1432,8201,152,139,8328,152,137,1432,1297,8460,1285,8352,257,136,1297,429]

theorem envBound20998 : H12AffineFastState.Bounded env20998 := by
  intro p hp
  have h : env20998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20997_20998 : H12AffineEnvironment.transform 5 16 env20997 = env20998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20997 == env20998) = true)

theorem identity20998 : scanCanonicalize (H12AffineFastState.compose env20998 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound20998 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20999 : List Nat := [2,4,8,16,32,16,9,256,292,1024,0,1296,8192,1296,293,35,1296,8460,1025,292,1297,8201,17,2,8193,17,0,1297,1297,8460,1285,8233,257,1,1297,292]

theorem envBound20999 : H12AffineFastState.Bounded env20999 := by
  intro p hp
  have h : env20999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20998_20999 : H12AffineEnvironment.transform 6 9 env20998 = env20999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20998 == env20999) = true)

theorem identity20999 : scanCanonicalize (H12AffineFastState.compose env20999 (packedSelected [3] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound20999 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env21000 : List Nat := [2,4,8,16,32,16,9,256,292,1024,0,1296,268,1296,293,35,1296,0,1025,292,1297,261,17,2,269,17,0,1297,1297,0,1285,293,257,1,1297,292]

theorem envBound21000 : H12AffineFastState.Bounded env21000 := by
  intro p hp
  have h : env21000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20999_21000 : H12AffineEnvironment.transform 12 268 env20999 = env21000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env20999 == env21000) = true)

theorem identity21000 : scanCanonicalize (H12AffineFastState.compose env21000 (packedSelected [2,4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound21000 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env21001 : List Nat := [2,4,8,16,32,16,9,37,1,1024,0,1077,41,1077,0,35,1077,0,1025,1,1076,32,17,2,40,17,0,1076,1076,0,1056,0,36,1,1076,1]

theorem envBound21001 : H12AffineFastState.Bounded env21001 := by
  intro p hp
  have h : env21001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21000_21001 : H12AffineEnvironment.transform 7 37 env21000 = env21001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env21000 == env21001) = true)

theorem identity21001 : scanCanonicalize (H12AffineFastState.compose env21001 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound21001 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21002 : List Nat := [2,4,8,16,0,16,9,5,1,1024,0,1045,9,1045,0,3,1045,0,1025,1,1044,0,17,2,8,17,0,1044,1044,0,1024,0,4,1,1044,1]

theorem envBound21002 : H12AffineFastState.Bounded env21002 := by
  intro p hp
  have h : env21002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21001_21002 : H12AffineEnvironment.transform 4 0 env21001 = env21002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env21001 == env21002) = true)

def env21003 : List Nat := [2,4,8,16,32,17,128,256,429,1024,0,1433,8192,1432,428,35,1297,8581,1025,429,1432,8201,153,139,8328,152,137,1433,1297,8460,1285,8352,257,136,1296,429]

theorem envBound21003 : H12AffineFastState.Bounded env21003 := by
  intro p hp
  have h : env21003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20997_21003 : H12AffineEnvironment.transform 5 17 env20997 = env21003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env20997 == env21003) = true)

theorem identity21003 : scanCanonicalize (H12AffineFastState.compose env21003 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound21003 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21004 : List Nat := [2,4,8,16,32,17,128,256,429,1024,0,1433,268,1432,428,35,1297,137,1025,429,1432,261,153,139,388,152,137,1433,1297,0,1285,428,257,136,1296,429]

theorem envBound21004 : H12AffineFastState.Bounded env21004 := by
  intro p hp
  have h : env21004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21003_21004 : H12AffineEnvironment.transform 12 268 env21003 = env21004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env21003 == env21004) = true)

theorem identity21004 : scanCanonicalize (H12AffineFastState.compose env21004 (packedSelected [2,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound21004 : packedSelected [2,4,5] rootPS < 2^1333 := by decide +kernel

def env21005 : List Nat := [2,4,8,16,32,17,9,256,292,1024,0,1296,268,1297,293,35,1297,0,1025,292,1297,261,16,2,269,17,0,1296,1297,0,1285,293,257,1,1296,292]

theorem envBound21005 : H12AffineFastState.Bounded env21005 := by
  intro p hp
  have h : env21005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21004_21005 : H12AffineEnvironment.transform 6 9 env21004 = env21005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21004 == env21005) = true)

theorem identity21005 : scanCanonicalize (H12AffineFastState.compose env21005 (packedSelected [2,4] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound21005 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env21006 : List Nat := [2,4,8,16,32,17,9,36,0,1024,0,1076,40,1077,1,35,1077,0,1025,0,1077,33,16,2,41,17,0,1076,1077,0,1057,1,37,1,1076,0]

theorem envBound21006 : H12AffineFastState.Bounded env21006 := by
  intro p hp
  have h : env21006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21005_21006 : H12AffineEnvironment.transform 7 36 env21005 = env21006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env21005 == env21006) = true)

def leafEnv21006 : List Nat := [2,4,8,16,32,17,9,36,0,1024,0,1076,40,1077,1,35,1077,0,1025,0,1077,33,16,2,1056,41,1,17,0,1076,1077,0,1057,1,37,1,5,35,1076,0,0,1076,1]

def active21006 : List Nat := [0,1,2,3,4,9]

def tree21006 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21006 : H12WitnessSearch.Good tree21006 := H12GlobalWitnessIndex.good

theorem leafIdentity21006 : H12AffineFastState.composeSystem env21006 rootObs = leafEnv21006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21006 rootObs == leafEnv21006) = true)

theorem terminalChecked21006 : H12PackedTerminal.terminalCheckFast leafEnv21006 active21006 tree21006 = true := by decide +kernel

def env21007 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1344,262144,304169,32769,4097,8201,17665,98564,8328,320889,33060,16385,324969,279873,1285,4294967296,257,4295074215,1345,512]

theorem envBound21007 : H12AffineFastState.Bounded env21007 := by
  intro p hp
  have h : env21007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20957_21007 : H12AffineEnvironment.transform 18 304169 env20957 = env21007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 304169 env20957 == env21007) = true)

theorem identity21007 : scanCanonicalize (H12AffineFastState.compose env21007 (packedSelected [4,9,18] rootPS)) = affineNative (2^(17+1) ^^^ 33060) := by decide +kernel

theorem selectedBound21007 : packedSelected [4,9,18] rootPS < 2^1333 := by decide +kernel

def env21008 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1344,33060,9485,32769,4097,8201,17665,98564,8328,25693,33060,16385,29773,50277,1285,4294967296,257,4295074215,1345,512]

theorem envBound21008 : H12AffineFastState.Bounded env21008 := by
  intro p hp
  have h : env21008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21007_21008 : H12AffineEnvironment.transform 17 33060 env21007 = env21008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 33060 env21007 == env21008) = true)

theorem identity21008 : scanCanonicalize (H12AffineFastState.compose env21008 (packedSelected [4,5,8,9,13,15,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 38046) := by decide +kernel

theorem selectedBound21008 : packedSelected [4,5,8,9,13,15,19,20] rootPS < 2^1333 := by decide +kernel

def env21009 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,38046,1344,33060,9485,32769,4097,8201,17665,5530,8328,25693,33060,16385,29773,50277,1285,4294967296,257,4294980921,1345,512]

theorem envBound21009 : H12AffineFastState.Bounded env21009 := by
  intro p hp
  have h : env21009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21008_21009 : H12AffineEnvironment.transform 15 38046 env21008 = env21009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38046 env21008 == env21009) = true)

theorem identity21009 : scanCanonicalize (H12AffineFastState.compose env21009 (packedSelected [1,3,4,9,10,13,15,17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8233) := by decide +kernel

theorem selectedBound21009 : packedSelected [1,3,4,9,10,13,15,17,21] rootPS < 2^1333 := by decide +kernel

def env21010 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,8233,13495,1344,8461,9485,8232,4097,8201,17665,5530,8328,25693,8461,16385,29773,25676,1285,4294967296,257,4294980921,1345,512]

theorem envBound21010 : H12AffineFastState.Bounded env21010 := by
  intro p hp
  have h : env21010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21009_21010 : H12AffineEnvironment.transform 14 8233 env21009 = env21010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env21009 == env21010) = true)

def env21011 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1345,262144,524288,32769,4097,8201,17664,98565,8328,541009,795916,16385,545089,1073741824,1284,4294967296,257,4295074214,1345,512]

theorem envBound21011 : H12AffineFastState.Bounded env21011 := by
  intro p hp
  have h : env21011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20955_21011 : H12AffineEnvironment.transform 16 1345 env20955 = env21011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env20955 == env21011) = true)

theorem identity21011 : scanCanonicalize (H12AffineFastState.compose env21011 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 581944) := by decide +kernel

theorem selectedBound21011 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env21012 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1345,262144,524288,32769,4097,8201,17664,98565,8328,541009,795916,16385,545089,581944,1284,4294967296,257,4295074214,1345,512]

theorem envBound21012 : H12AffineFastState.Bounded env21012 := by
  intro p hp
  have h : env21012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21011_21012 : H12AffineEnvironment.transform 29 581944 env21011 = env21012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 581944 env21011 == env21012) = true)

theorem identity21012 : scanCanonicalize (H12AffineFastState.compose env21012 (packedSelected [4,9,16] rootPS)) = affineNative (2^(18+1) ^^^ 1025) := by decide +kernel

theorem selectedBound21012 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env21013 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1345,262144,1025,32769,4097,8201,17664,98565,8328,17744,270605,16385,21824,58681,1284,4294967296,257,4295074214,1345,512]

theorem envBound21013 : H12AffineFastState.Bounded env21013 := by
  intro p hp
  have h : env21013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21012_21013 : H12AffineEnvironment.transform 18 1025 env21012 = env21013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env21012 == env21013) = true)

theorem identity21013 : scanCanonicalize (H12AffineFastState.compose env21013 (packedSelected [1,5,8,15,17,21,24,38] rootPS)) = affineNative (2^(15+1) ^^^ 17850) := by decide +kernel

theorem selectedBound21013 : packedSelected [1,5,8,15,17,21,24,38] rootPS < 2^1333 := by decide +kernel

def env21014 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,17850,1345,262144,1025,32769,4097,8201,17664,50367,8328,17744,270605,16385,21824,58681,1284,4294967296,257,4295025692,1345,512]

theorem envBound21014 : H12AffineFastState.Bounded env21014 := by
  intro p hp
  have h : env21014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21013_21014 : H12AffineEnvironment.transform 15 17850 env21013 = env21014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 17850 env21013 == env21014) = true)

theorem identity21014 : scanCanonicalize (H12AffineFastState.compose env21014 (packedSelected [13,21] rootPS)) = affineNative (2^(13+1) ^^^ 4176) := by decide +kernel

theorem selectedBound21014 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env21015 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,4176,32768,5610,1345,262144,1025,32769,4097,8201,5456,38127,8328,5376,270605,4177,1296,46441,1284,4294967296,257,4295013452,1345,512]

theorem envBound21015 : H12AffineFastState.Bounded env21015 := by
  intro p hp
  have h : env21015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21014_21015 : H12AffineEnvironment.transform 13 4176 env21014 = env21015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env21014 == env21015) = true)

theorem identity21015 : scanCanonicalize (H12AffineFastState.compose env21015 (packedSelected [3,5,10] rootPS)) = affineNative (2^(31+1) ^^^ 8321) := by decide +kernel

theorem selectedBound21015 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env21016 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,4176,32768,5610,1345,262144,1025,32769,4097,8201,5456,38127,8328,5376,270605,4177,1296,46441,1284,8321,257,38093,1345,512]

theorem envBound21016 : H12AffineFastState.Bounded env21016 := by
  intro p hp
  have h : env21016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21015_21016 : H12AffineEnvironment.transform 31 8321 env21015 = env21016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 8321 env21015 == env21016) = true)

theorem identity21016 : scanCanonicalize (H12AffineFastState.compose env21016 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 41000) := by decide +kernel

theorem selectedBound21016 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env21017 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,4176,32768,5610,1345,41000,1025,32769,4097,8201,5456,38127,8328,5376,33061,4177,1296,46441,1284,8321,257,38093,1345,512]

theorem envBound21017 : H12AffineFastState.Bounded env21017 := by
  intro p hp
  have h : env21017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21016_21017 : H12AffineEnvironment.transform 17 41000 env21016 = env21017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 41000 env21016 == env21017) = true)

theorem identity21017 : scanCanonicalize (H12AffineFastState.compose env21017 (packedSelected [3,5,12,13] rootPS)) = affineNative (2^(14+1) ^^^ 8432) := by decide +kernel

theorem selectedBound21017 : packedSelected [3,5,12,13] rootPS < 2^1333 := by decide +kernel

def env21018 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,4176,8432,5610,1345,216,1025,8433,4097,8201,5456,13343,8328,5376,8661,4177,1296,5529,1284,8321,257,13373,1345,512]

theorem envBound21018 : H12AffineFastState.Bounded env21018 := by
  intro p hp
  have h : env21018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21017_21018 : H12AffineEnvironment.transform 14 8432 env21017 = env21018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8432 env21017 == env21018) = true)

theorem identity21018 : scanCanonicalize (H12AffineFastState.compose env21018 (packedSelected [2,4,6,9] rootPS)) = affineNative (2^(12+1) ^^^ 632) := by decide +kernel

theorem selectedBound21018 : packedSelected [2,4,6,9] rootPS < 2^1333 := by decide +kernel

def env21019 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,632,4176,648,5610,1345,216,1025,649,4097,625,5456,5735,752,5376,941,4177,1296,5529,1284,761,257,5701,1345,512]

theorem envBound21019 : H12AffineFastState.Bounded env21019 := by
  intro p hp
  have h : env21019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21018_21019 : H12AffineEnvironment.transform 12 632 env21018 = env21019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 632 env21018 == env21019) = true)

theorem identity21019 : scanCanonicalize (H12AffineFastState.compose env21019 (packedSelected [2,3,4,6,7,12] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound21019 : packedSelected [2,3,4,6,7,12] rootPS < 2^1333 := by decide +kernel

def env21020 : List Nat := [2,4,8,16,32,64,128,256,261,1024,0,4096,381,4176,397,5610,1345,216,1025,396,4097,372,5456,5474,501,5376,168,4177,1296,5529,1284,508,257,5440,1345,261]

theorem envBound21020 : H12AffineFastState.Bounded env21020 := by
  intro p hp
  have h : env21020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21019_21020 : H12AffineEnvironment.transform 8 261 env21019 = env21020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env21019 == env21020) = true)

theorem identity21020 : scanCanonicalize (H12AffineFastState.compose env21020 (packedSelected [2,4,6,7,8,17] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound21020 : packedSelected [2,4,6,7,8,17] rootPS < 2^1333 := by decide +kernel

def env21021 : List Nat := [2,4,8,16,32,64,128,4,1,1024,0,4096,121,4176,137,5358,1093,216,1025,136,4097,112,5204,5222,241,5124,168,4177,1044,5277,1024,248,5,5188,1093,1]

theorem envBound21021 : H12AffineFastState.Bounded env21021 := by
  intro p hp
  have h : env21021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21020_21021 : H12AffineEnvironment.transform 7 4 env21020 = env21021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env21020 == env21021) = true)

theorem identity21021 : scanCanonicalize (H12AffineFastState.compose env21021 (packedSelected [3,5] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound21021 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env21022 : List Nat := [2,4,8,16,32,64,128,4,1,1024,0,0,121,80,137,1262,1093,216,1025,136,1,112,1108,1126,241,1028,168,81,1044,1181,1024,248,5,1092,1093,1]

theorem envBound21022 : H12AffineFastState.Bounded env21022 := by
  intro p hp
  have h : env21022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21021_21022 : H12AffineEnvironment.transform 11 0 env21021 = env21022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env21021 == env21022) = true)

theorem identity21022 : scanCanonicalize (H12AffineFastState.compose env21022 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 188) := by decide +kernel

theorem selectedBound21022 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env21023 : List Nat := [2,4,8,16,32,64,128,4,1,188,0,0,121,80,137,82,249,216,189,136,1,112,232,218,241,184,168,81,168,33,188,248,5,248,249,1]

theorem envBound21023 : H12AffineFastState.Bounded env21023 := by
  intro p hp
  have h : env21023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21022_21023 : H12AffineEnvironment.transform 9 188 env21022 = env21023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 188 env21022 == env21023) = true)

theorem identity21023 : scanCanonicalize (H12AffineFastState.compose env21023 (packedSelected [0,1] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound21023 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env21024 : List Nat := [2,4,8,16,32,32,128,4,1,188,0,0,25,48,137,50,153,184,189,136,1,16,136,186,145,184,168,49,168,33,188,152,5,152,153,1]

theorem envBound21024 : H12AffineFastState.Bounded env21024 := by
  intro p hp
  have h : env21024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21023_21024 : H12AffineEnvironment.transform 5 32 env21023 = env21024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env21023 == env21024) = true)

def env21025 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,8200,147521,230468,8328,672784,925772,16385,676864,1073741824,131141,4294967296,257,4295206118,1345,512]

theorem envBound21025 : H12AffineFastState.Bounded env21025 := by
  intro p hp
  have h : env21025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20954_21025 : H12AffineEnvironment.transform 10 1 env20954 = env21025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env20954 == env21025) = true)

def env21026 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1344,262144,524288,32769,4097,8200,17665,98564,8328,541008,795916,16385,545088,1073741824,1285,4294967296,257,4295074214,1345,512]

theorem envBound21026 : H12AffineFastState.Bounded env21026 := by
  intro p hp
  have h : env21026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21025_21026 : H12AffineEnvironment.transform 16 1344 env21025 = env21026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env21025 == env21026) = true)

theorem identity21026 : scanCanonicalize (H12AffineFastState.compose env21026 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 279872) := by decide +kernel

theorem selectedBound21026 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env21027 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1344,262144,524288,32769,4097,8200,17665,98564,8328,541008,795916,16385,545088,279872,1285,4294967296,257,4295074214,1345,512]

theorem envBound21027 : H12AffineFastState.Bounded env21027 := by
  intro p hp
  have h : env21027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21026_21027 : H12AffineEnvironment.transform 29 279872 env21026 = env21027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 279872 env21026 == env21027) = true)

def env21028 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1344,262144,304168,32769,4097,8200,17665,98564,8328,320888,33060,16385,324968,279872,1285,4294967296,257,4295074214,1345,512]

theorem envBound21028 : H12AffineFastState.Bounded env21028 := by
  intro p hp
  have h : env21028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21027_21028 : H12AffineEnvironment.transform 18 304168 env21027 = env21028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 304168 env21027 == env21028) = true)

theorem identity21028 : scanCanonicalize (H12AffineFastState.compose env21028 (packedSelected [4,9,18] rootPS)) = affineNative (2^(17+1) ^^^ 33060) := by decide +kernel

theorem selectedBound21028 : packedSelected [4,9,18] rootPS < 2^1333 := by decide +kernel

def env21029 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1344,33060,9484,32769,4097,8200,17665,98564,8328,25692,33060,16385,29772,50276,1285,4294967296,257,4295074214,1345,512]

theorem envBound21029 : H12AffineFastState.Bounded env21029 := by
  intro p hp
  have h : env21029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21028_21029 : H12AffineEnvironment.transform 17 33060 env21028 = env21029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 33060 env21028 == env21029) = true)

theorem identity21029 : scanCanonicalize (H12AffineFastState.compose env21029 (packedSelected [4,5,8,9,13,15,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 20731) := by decide +kernel

theorem selectedBound21029 : packedSelected [4,5,8,9,13,15,19,20] rootPS < 2^1333 := by decide +kernel

def env21030 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,20731,1344,33060,9484,32769,4097,8200,17665,53759,8328,25692,33060,16385,29772,50276,1285,4294967296,257,4295029085,1345,512]

theorem envBound21030 : H12AffineFastState.Bounded env21030 := by
  intro p hp
  have h : env21030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21029_21030 : H12AffineEnvironment.transform 15 20731 env21029 = env21030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 20731 env21029 == env21030) = true)

theorem identity21030 : scanCanonicalize (H12AffineFastState.compose env21030 (packedSelected [4,5,8,9,13,15,19,23] rootPS)) = affineNative (2^(13+1) ^^^ 1344) := by decide +kernel

theorem selectedBound21030 : packedSelected [4,5,8,9,13,15,19,23] rootPS < 2^1333 := by decide +kernel

def env21031 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,1344,32768,5563,1344,33060,9484,32769,4097,8200,65,38079,8328,8476,33060,1345,12556,33060,1285,4294967296,257,4295013405,1345,512]

theorem envBound21031 : H12AffineFastState.Bounded env21031 := by
  intro p hp
  have h : env21031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21030_21031 : H12AffineEnvironment.transform 13 1344 env21030 = env21031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env21030 == env21031) = true)

theorem identity21031 : scanCanonicalize (H12AffineFastState.compose env21031 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound21031 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env21032 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1297,8192,1344,32768,170,1344,33060,9484,32769,1296,8200,65,33198,8328,8476,33060,1345,9245,33060,1285,4294967296,257,4295008524,1345,512]

theorem envBound21032 : H12AffineFastState.Bounded env21032 := by
  intro p hp
  have h : env21032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21031_21032 : H12AffineEnvironment.transform 11 1297 env21031 = env21032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env21031 == env21032) = true)

theorem identity21032 : scanCanonicalize (H12AffineFastState.compose env21032 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(14+1) ^^^ 292) := by decide +kernel

theorem selectedBound21032 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env21033 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1297,8192,1344,292,170,1344,0,9484,293,1296,8200,65,138,8328,8476,0,1345,9245,0,1285,4294967296,257,4294975528,1345,512]

theorem envBound21033 : H12AffineFastState.Bounded env21033 := by
  intro p hp
  have h : env21033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21032_21033 : H12AffineEnvironment.transform 14 292 env21032 = env21033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 292 env21032 == env21033) = true)

def env21034 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1344,262144,304169,32769,4097,8200,17665,98564,8328,320889,33061,16385,324969,279872,1285,4294967296,257,4295074214,1345,512]

theorem envBound21034 : H12AffineFastState.Bounded env21034 := by
  intro p hp
  have h : env21034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21027_21034 : H12AffineEnvironment.transform 18 304169 env21027 = env21034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 304169 env21027 == env21034) = true)

theorem identity21034 : scanCanonicalize (H12AffineFastState.compose env21034 (packedSelected [4,9,18] rootPS)) = affineNative (2^(14+1) ^^^ 17508) := by decide +kernel

theorem selectedBound21034 : packedSelected [4,9,18] rootPS < 2^1333 := by decide +kernel

def env21035 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,17508,65536,1344,262144,286797,17509,4097,8200,17665,83296,8328,270621,17729,16385,274701,279872,1285,4294967296,257,4295058882,1345,512]

theorem envBound21035 : H12AffineFastState.Bounded env21035 := by
  intro p hp
  have h : env21035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21034_21035 : H12AffineEnvironment.transform 14 17508 env21034 = env21035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 17508 env21034 == env21035) = true)

theorem identity21035 : scanCanonicalize (H12AffineFastState.compose env21035 (packedSelected [5,8,13,15,19] rootPS)) = affineNative (2^(15+1) ^^^ 17899) := by decide +kernel

theorem selectedBound21035 : packedSelected [5,8,13,15,19] rootPS < 2^1333 := by decide +kernel

def env21036 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,17508,17899,1344,262144,286797,17509,4097,8200,17665,139,8328,270621,17729,16385,274701,279872,1285,4294967296,257,4294975529,1345,512]

theorem envBound21036 : H12AffineFastState.Bounded env21036 := by
  intro p hp
  have h : env21036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21035_21036 : H12AffineEnvironment.transform 15 17899 env21035 = env21036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 17899 env21035 == env21036) = true)

def env21037 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,17508,17899,1344,26592,1965,17509,4097,8200,17665,139,8328,18173,17729,16385,22253,8864,1285,4294967296,257,4294975529,1345,512]

theorem envBound21037 : H12AffineFastState.Bounded env21037 := by
  intro p hp
  have h : env21037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21036_21037 : H12AffineEnvironment.transform 17 26592 env21036 = env21037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 26592 env21036 == env21037) = true)

theorem identity21037 : scanCanonicalize (H12AffineFastState.compose env21037 (packedSelected [1,3,10,13] rootPS)) = affineNative (2^(13+1) ^^^ 4176) := by decide +kernel

theorem selectedBound21037 : packedSelected [1,3,10,13] rootPS < 2^1333 := by decide +kernel

def env21038 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,4176,5172,5563,1344,14256,1965,5173,4097,8200,5457,139,8328,5805,5393,4177,1725,8864,1285,4294967296,257,4294975529,1345,512]

theorem envBound21038 : H12AffineFastState.Bounded env21038 := by
  intro p hp
  have h : env21038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21037_21038 : H12AffineEnvironment.transform 13 4176 env21037 = env21038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env21037 == env21038) = true)

theorem identity21038 : scanCanonicalize (H12AffineFastState.compose env21038 (packedSelected [0,7,12] rootPS)) = affineNative (2^(8+1) ^^^ 428) := by decide +kernel

theorem selectedBound21038 : packedSelected [0,7,12] rootPS < 2^1333 := by decide +kernel

def env21039 : List Nat := [2,4,8,16,32,64,128,256,428,1024,1,4096,8192,4176,5172,5563,1344,13340,1025,5173,4097,8200,5457,139,8328,5377,5393,4177,1297,8460,1285,4294967296,257,4294975529,1345,428]

theorem envBound21039 : H12AffineFastState.Bounded env21039 := by
  intro p hp
  have h : env21039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21038_21039 : H12AffineEnvironment.transform 8 428 env21038 = env21039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 428 env21038 == env21039) = true)

def env21040 : List Nat := [2,4,8,16,32,64,128,256,428,1024,1,1432,8192,1480,428,35,1344,8580,1025,429,1433,8200,201,139,8328,153,137,1481,1297,8460,1285,4294967296,257,4294975529,1345,428]

theorem envBound21040 : H12AffineFastState.Bounded env21040 := by
  intro p hp
  have h : env21040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21039_21040 : H12AffineEnvironment.transform 11 1432 env21039 = env21040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1432 env21039 == env21040) = true)

theorem identity21040 : scanCanonicalize (H12AffineFastState.compose env21040 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 8353) := by decide +kernel

theorem selectedBound21040 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21041 : List Nat := [2,4,8,16,32,64,128,256,428,1024,1,1432,8192,1480,428,35,1344,8580,1025,429,1433,8200,201,139,8328,153,137,1481,1297,8460,1285,8353,257,136,1345,428]

theorem envBound21041 : H12AffineFastState.Bounded env21041 := by
  intro p hp
  have h : env21041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21040_21041 : H12AffineEnvironment.transform 31 8353 env21040 = env21041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 8353 env21040 == env21041) = true)

def env21042 : List Nat := [2,4,8,16,32,16,128,256,428,1024,1,1432,8192,1432,428,35,1296,8580,1025,429,1433,8200,153,139,8328,153,137,1433,1297,8460,1285,8353,257,136,1297,428]

theorem envBound21042 : H12AffineFastState.Bounded env21042 := by
  intro p hp
  have h : env21042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21041_21042 : H12AffineEnvironment.transform 5 16 env21041 = env21042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env21041 == env21042) = true)

theorem identity21042 : scanCanonicalize (H12AffineFastState.compose env21042 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound21042 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21043 : List Nat := [2,4,8,16,32,16,9,256,293,1024,1,1297,8192,1297,293,35,1296,8461,1025,292,1296,8200,16,2,8193,16,0,1296,1297,8460,1285,8232,257,1,1297,293]

theorem envBound21043 : H12AffineFastState.Bounded env21043 := by
  intro p hp
  have h : env21043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21042_21043 : H12AffineEnvironment.transform 6 9 env21042 = env21043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21042 == env21043) = true)

theorem identity21043 : scanCanonicalize (H12AffineFastState.compose env21043 (packedSelected [5] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound21043 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env21044 : List Nat := [2,4,8,16,32,16,9,256,293,1024,1,1297,40,1297,293,35,1296,293,1025,292,1296,32,16,2,41,16,0,1296,1297,292,1285,0,257,1,1297,293]

theorem envBound21044 : H12AffineFastState.Bounded env21044 := by
  intro p hp
  have h : env21044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21043_21044 : H12AffineEnvironment.transform 12 40 env21043 = env21044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env21043 == env21044) = true)

theorem identity21044 : scanCanonicalize (H12AffineFastState.compose env21044 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound21044 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21045 : List Nat := [2,4,8,16,32,16,9,4,33,1024,1,1045,40,1045,33,35,1044,33,1025,32,1044,32,16,2,41,16,0,1044,1045,32,1025,0,5,1,1045,33]

theorem envBound21045 : H12AffineFastState.Bounded env21045 := by
  intro p hp
  have h : env21045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21044_21045 : H12AffineEnvironment.transform 7 4 env21044 = env21045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env21044 == env21045) = true)

def leafEnv21045 : List Nat := [2,4,8,16,32,16,9,4,33,1024,1,1045,40,1045,33,35,1044,33,1025,32,1044,32,16,2,1024,41,1,16,0,1044,1045,32,1025,0,5,1,5,35,1045,33,0,1044,1]

def active21045 : List Nat := [0,1,2,3,4,9]

def tree21045 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21045 : H12WitnessSearch.Good tree21045 := H12GlobalWitnessIndex.good

theorem leafIdentity21045 : H12AffineFastState.composeSystem env21045 rootObs = leafEnv21045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21045 rootObs == leafEnv21045) = true)

theorem terminalChecked21045 : H12PackedTerminal.terminalCheckFast leafEnv21045 active21045 tree21045 = true := by decide +kernel

def env21046 : List Nat := [2,4,8,16,32,17,128,256,428,1024,1,1432,8192,1433,428,35,1297,8580,1025,429,1433,8200,152,139,8328,153,137,1432,1297,8460,1285,8353,257,136,1296,428]

theorem envBound21046 : H12AffineFastState.Bounded env21046 := by
  intro p hp
  have h : env21046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21041_21046 : H12AffineEnvironment.transform 5 17 env21041 = env21046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env21041 == env21046) = true)

theorem identity21046 : scanCanonicalize (H12AffineFastState.compose env21046 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound21046 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21047 : List Nat := [2,4,8,16,32,17,128,256,428,1024,1,1432,269,1433,428,35,1297,137,1025,429,1433,261,152,139,389,153,137,1432,1297,1,1285,428,257,136,1296,428]

theorem envBound21047 : H12AffineFastState.Bounded env21047 := by
  intro p hp
  have h : env21047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21046_21047 : H12AffineEnvironment.transform 12 269 env21046 = env21047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env21046 == env21047) = true)

theorem identity21047 : scanCanonicalize (H12AffineFastState.compose env21047 (packedSelected [2,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound21047 : packedSelected [2,4,5] rootPS < 2^1333 := by decide +kernel

def env21048 : List Nat := [2,4,8,16,32,17,128,172,0,1024,1,1076,161,1077,0,35,1213,137,1025,1,1077,169,152,139,41,153,137,1076,1213,1,1193,0,173,136,1212,0]

theorem envBound21048 : H12AffineFastState.Bounded env21048 := by
  intro p hp
  have h : env21048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21047_21048 : H12AffineEnvironment.transform 7 172 env21047 = env21048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env21047 == env21048) = true)

def env21049 : List Nat := [2,4,8,16,32,64,128,256,428,1024,1,1433,8192,1481,429,34,1344,8581,1025,428,1432,8200,200,139,8328,152,136,1480,1297,8460,1285,4294967296,257,4294975529,1345,428]

theorem envBound21049 : H12AffineFastState.Bounded env21049 := by
  intro p hp
  have h : env21049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21039_21049 : H12AffineEnvironment.transform 11 1433 env21039 = env21049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1433 env21039 == env21049) = true)

theorem identity21049 : scanCanonicalize (H12AffineFastState.compose env21049 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 292) := by decide +kernel

theorem selectedBound21049 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21050 : List Nat := [2,4,8,16,32,64,128,256,428,1024,1,1433,8192,1481,429,34,1344,8581,1025,428,1432,8200,200,139,8328,152,136,1480,1297,8460,1285,292,257,8461,1345,428]

theorem envBound21050 : H12AffineFastState.Bounded env21050 := by
  intro p hp
  have h : env21050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21049_21050 : H12AffineEnvironment.transform 31 292 env21049 = env21050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 292 env21049 == env21050) = true)

def env21051 : List Nat := [2,4,8,16,32,16,128,256,428,1024,1,1433,8192,1433,429,34,1296,8581,1025,428,1432,8200,152,139,8328,152,136,1432,1297,8460,1285,292,257,8461,1297,428]

theorem envBound21051 : H12AffineFastState.Bounded env21051 := by
  intro p hp
  have h : env21051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21050_21051 : H12AffineEnvironment.transform 5 16 env21050 = env21051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env21050 == env21051) = true)

def env21052 : List Nat := [2,4,8,16,32,17,128,256,428,1024,1,1433,8192,1432,429,34,1297,8581,1025,428,1432,8200,153,139,8328,152,136,1433,1297,8460,1285,292,257,8461,1296,428]

theorem envBound21052 : H12AffineFastState.Bounded env21052 := by
  intro p hp
  have h : env21052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21050_21052 : H12AffineEnvironment.transform 5 17 env21050 = env21052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env21050 == env21052) = true)

theorem identity21052 : scanCanonicalize (H12AffineFastState.compose env21052 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound21052 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21053 : List Nat := [2,4,8,16,32,17,128,256,428,1024,1,1433,388,1432,429,34,1297,1,1025,428,1432,396,153,139,268,152,136,1433,1297,136,1285,292,257,137,1296,428]

theorem envBound21053 : H12AffineFastState.Bounded env21053 := by
  intro p hp
  have h : env21053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21052_21053 : H12AffineEnvironment.transform 12 388 env21052 = env21053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env21052 == env21053) = true)

theorem identity21053 : scanCanonicalize (H12AffineFastState.compose env21053 (packedSelected [2,4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound21053 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env21054 : List Nat := [2,4,8,16,32,17,128,37,137,1024,1,1212,161,1213,136,34,1076,1,1025,137,1213,169,153,139,41,152,136,1212,1076,136,1056,1,36,137,1077,137]

theorem envBound21054 : H12AffineFastState.Bounded env21054 := by
  intro p hp
  have h : env21054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21053_21054 : H12AffineEnvironment.transform 7 37 env21053 = env21054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env21053 == env21054) = true)

def env21055 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,17508,17899,1344,26593,1964,17509,4097,8200,17665,139,8328,18172,17729,16385,22252,8865,1285,4294967296,257,4294975529,1345,512]

theorem envBound21055 : H12AffineFastState.Bounded env21055 := by
  intro p hp
  have h : env21055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21036_21055 : H12AffineEnvironment.transform 17 26593 env21036 = env21055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 26593 env21036 == env21055) = true)

theorem identity21055 : scanCanonicalize (H12AffineFastState.compose env21055 (packedSelected [1,3,10,13] rootPS)) = affineNative (2^(13+1) ^^^ 5117) := by decide +kernel

theorem selectedBound21055 : packedSelected [1,3,10,13] rootPS < 2^1333 := by decide +kernel

def env21056 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,5117,6041,5654,1344,13340,1964,6040,4097,8200,5884,139,8328,5377,5820,5116,1297,8865,1285,4294967296,257,4294975529,1345,512]

theorem envBound21056 : H12AffineFastState.Bounded env21056 := by
  intro p hp
  have h : env21056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21055_21056 : H12AffineEnvironment.transform 13 5117 env21055 = env21056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5117 env21055 == env21056) = true)

theorem identity21056 : scanCanonicalize (H12AffineFastState.compose env21056 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 429) := by decide +kernel

theorem selectedBound21056 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env21057 : List Nat := [2,4,8,16,32,64,128,256,429,1024,1,4096,8192,4176,5172,5563,1344,13340,1025,5173,4097,8200,5457,139,8328,5377,5393,4177,1297,8460,1285,4294967296,257,4294975529,1345,429]

theorem envBound21057 : H12AffineFastState.Bounded env21057 := by
  intro p hp
  have h : env21057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21056_21057 : H12AffineEnvironment.transform 8 429 env21056 = env21057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 429 env21056 == env21057) = true)

def env21058 : List Nat := [2,4,8,16,32,64,128,256,429,1024,1,1432,8192,1480,428,35,1344,8580,1025,429,1433,8200,201,139,8328,153,137,1481,1297,8460,1285,4294967296,257,4294975529,1345,429]

theorem envBound21058 : H12AffineFastState.Bounded env21058 := by
  intro p hp
  have h : env21058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21057_21058 : H12AffineEnvironment.transform 11 1432 env21057 = env21058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1432 env21057 == env21058) = true)

theorem identity21058 : scanCanonicalize (H12AffineFastState.compose env21058 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 292) := by decide +kernel

theorem selectedBound21058 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21059 : List Nat := [2,4,8,16,32,64,128,256,429,1024,1,1432,8192,1480,428,35,1344,8580,1025,429,1433,8200,201,139,8328,153,137,1481,1297,8460,1285,292,257,8461,1345,429]

theorem envBound21059 : H12AffineFastState.Bounded env21059 := by
  intro p hp
  have h : env21059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21058_21059 : H12AffineEnvironment.transform 31 292 env21058 = env21059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 292 env21058 == env21059) = true)

def env21060 : List Nat := [2,4,8,16,32,16,128,256,429,1024,1,1432,8192,1432,428,35,1296,8580,1025,429,1433,8200,153,139,8328,153,137,1433,1297,8460,1285,292,257,8461,1297,429]

theorem envBound21060 : H12AffineFastState.Bounded env21060 := by
  intro p hp
  have h : env21060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21059_21060 : H12AffineEnvironment.transform 5 16 env21059 = env21060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env21059 == env21060) = true)

def env21061 : List Nat := [2,4,8,16,32,16,8,256,293,1024,1,1296,8192,1296,292,35,1296,8460,1025,293,1297,8200,17,3,8192,17,1,1297,1297,8460,1285,292,257,8461,1297,293]

theorem envBound21061 : H12AffineFastState.Bounded env21061 := by
  intro p hp
  have h : env21061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21060_21061 : H12AffineEnvironment.transform 6 8 env21060 = env21061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21060 == env21061) = true)

theorem identity21061 : scanCanonicalize (H12AffineFastState.compose env21061 (packedSelected [3] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound21061 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env21062 : List Nat := [2,4,8,16,32,16,8,256,293,1024,1,1296,269,1296,292,35,1296,1,1025,293,1297,261,17,3,269,17,1,1297,1297,1,1285,292,257,0,1297,293]

theorem envBound21062 : H12AffineFastState.Bounded env21062 := by
  intro p hp
  have h : env21062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21061_21062 : H12AffineEnvironment.transform 12 269 env21061 = env21062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env21061 == env21062) = true)

def env21063 : List Nat := [2,4,8,16,0,16,8,256,261,1024,1,1296,269,1296,260,3,1296,1,1025,261,1297,261,17,3,269,17,1,1297,1297,1,1285,260,257,0,1297,261]

theorem envBound21063 : H12AffineFastState.Bounded env21063 := by
  intro p hp
  have h : env21063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21062_21063 : H12AffineEnvironment.transform 4 0 env21062 = env21063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env21062 == env21063) = true)

theorem identity21063 : scanCanonicalize (H12AffineFastState.compose env21063 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound21063 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21064 : List Nat := [2,4,8,16,0,16,8,4,1,1024,1,1044,9,1044,0,3,1044,1,1025,1,1045,1,17,3,9,17,1,1045,1045,1,1025,0,5,0,1045,1]

theorem envBound21064 : H12AffineFastState.Bounded env21064 := by
  intro p hp
  have h : env21064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21063_21064 : H12AffineEnvironment.transform 7 4 env21063 = env21064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env21063 == env21064) = true)

def leafEnv21064 : List Nat := [2,4,8,16,0,16,8,4,1,1024,1,1044,9,1044,0,3,1044,1,1025,1,1045,1,17,3,1024,9,1,17,1,1045,1045,1,1025,0,5,0,5,2,1045,1,0,1044,1]

def active21064 : List Nat := [0,1,2,3,9]

def tree21064 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21064 : H12WitnessSearch.Good tree21064 := H12GlobalWitnessIndex.good

theorem leafIdentity21064 : H12AffineFastState.composeSystem env21064 rootObs = leafEnv21064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21064 rootObs == leafEnv21064) = true)

theorem terminalChecked21064 : H12PackedTerminal.terminalCheckFast leafEnv21064 active21064 tree21064 = true := by decide +kernel

def env21065 : List Nat := [2,4,8,16,1,16,8,256,260,1024,1,1296,269,1296,261,2,1296,1,1025,260,1297,261,17,3,269,17,1,1297,1297,1,1285,261,257,0,1297,260]

theorem envBound21065 : H12AffineFastState.Bounded env21065 := by
  intro p hp
  have h : env21065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21062_21065 : H12AffineEnvironment.transform 4 1 env21062 = env21065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env21062 == env21065) = true)

def leafEnv21065 : List Nat := [2,4,8,16,1,16,8,256,260,1024,1,1296,269,1296,261,2,1296,1,1025,260,1297,261,17,3,1284,269,1,17,1,1297,1297,1,1285,261,257,0,5,3,1297,260,0,1296,1]

def active21065 : List Nat := [0,1,2,3,7,9]

def tree21065 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21065 : H12WitnessSearch.Good tree21065 := H12GlobalWitnessIndex.good

theorem leafIdentity21065 : H12AffineFastState.composeSystem env21065 rootObs = leafEnv21065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21065 rootObs == leafEnv21065) = true)

theorem terminalChecked21065 : H12PackedTerminal.terminalCheckFast leafEnv21065 active21065 tree21065 = true := by decide +kernel

def env21066 : List Nat := [2,4,8,16,32,16,9,256,292,1024,1,1297,8192,1297,293,35,1296,8461,1025,292,1296,8200,16,2,8193,16,0,1296,1297,8460,1285,292,257,8461,1297,292]

theorem envBound21066 : H12AffineFastState.Bounded env21066 := by
  intro p hp
  have h : env21066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21060_21066 : H12AffineEnvironment.transform 6 9 env21060 = env21066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21060 == env21066) = true)

theorem identity21066 : scanCanonicalize (H12AffineFastState.compose env21066 (packedSelected [5] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound21066 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env21067 : List Nat := [2,4,8,16,32,16,9,256,292,1024,1,1297,40,1297,293,35,1296,293,1025,292,1296,32,16,2,41,16,0,1296,1297,292,1285,292,257,293,1297,292]

theorem envBound21067 : H12AffineFastState.Bounded env21067 := by
  intro p hp
  have h : env21067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21066_21067 : H12AffineEnvironment.transform 12 40 env21066 = env21067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env21066 == env21067) = true)

theorem identity21067 : scanCanonicalize (H12AffineFastState.compose env21067 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound21067 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21068 : List Nat := [2,4,8,16,32,16,9,5,33,1024,1,1044,40,1044,32,35,1045,32,1025,33,1045,32,16,2,41,16,0,1045,1044,33,1024,33,4,32,1044,33]

theorem envBound21068 : H12AffineFastState.Bounded env21068 := by
  intro p hp
  have h : env21068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21067_21068 : H12AffineEnvironment.transform 7 5 env21067 = env21068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env21067 == env21068) = true)

theorem identity21068 : scanCanonicalize (H12AffineFastState.compose env21068 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound21068 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env21069 : List Nat := [2,4,8,16,1,16,9,5,0,1024,1,1044,9,1044,1,2,1045,1,1025,0,1045,1,16,2,8,16,0,1045,1044,0,1024,0,4,1,1044,0]

theorem envBound21069 : H12AffineFastState.Bounded env21069 := by
  intro p hp
  have h : env21069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21068_21069 : H12AffineEnvironment.transform 4 1 env21068 = env21069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env21068 == env21069) = true)

def leafEnv21069 : List Nat := [2,4,8,16,1,16,9,5,0,1024,1,1044,9,1044,1,2,1045,1,1025,0,1045,1,16,2,1025,8,1,16,0,1045,1044,0,1024,0,4,1,5,2,1044,0,0,1045,1]

def active21069 : List Nat := [0,1,2,3,9]

def tree21069 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21069 : H12WitnessSearch.Good tree21069 := H12GlobalWitnessIndex.good

theorem leafIdentity21069 : H12AffineFastState.composeSystem env21069 rootObs = leafEnv21069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21069 rootObs == leafEnv21069) = true)

theorem terminalChecked21069 : H12PackedTerminal.terminalCheckFast leafEnv21069 active21069 tree21069 = true := by decide +kernel

def env21070 : List Nat := [2,4,8,16,32,17,128,256,429,1024,1,1432,8192,1433,428,35,1297,8580,1025,429,1433,8200,152,139,8328,153,137,1432,1297,8460,1285,292,257,8461,1296,429]

theorem envBound21070 : H12AffineFastState.Bounded env21070 := by
  intro p hp
  have h : env21070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21059_21070 : H12AffineEnvironment.transform 5 17 env21059 = env21070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env21059 == env21070) = true)

theorem identity21070 : scanCanonicalize (H12AffineFastState.compose env21070 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound21070 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21071 : List Nat := [2,4,8,16,32,17,128,256,429,1024,1,1432,389,1433,428,35,1297,1,1025,429,1433,397,152,139,269,153,137,1432,1297,137,1285,292,257,136,1296,429]

theorem envBound21071 : H12AffineFastState.Bounded env21071 := by
  intro p hp
  have h : env21071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21070_21071 : H12AffineEnvironment.transform 12 389 env21070 = env21071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env21070 == env21071) = true)

def env21072 : List Nat := [2,4,8,16,32,64,128,256,429,1024,1,1433,8192,1481,429,34,1344,8581,1025,428,1432,8200,200,139,8328,152,136,1480,1297,8460,1285,4294967296,257,4294975529,1345,429]

theorem envBound21072 : H12AffineFastState.Bounded env21072 := by
  intro p hp
  have h : env21072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21057_21072 : H12AffineEnvironment.transform 11 1433 env21057 = env21072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1433 env21057 == env21072) = true)

theorem identity21072 : scanCanonicalize (H12AffineFastState.compose env21072 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 8353) := by decide +kernel

theorem selectedBound21072 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21073 : List Nat := [2,4,8,16,32,64,128,256,429,1024,1,1433,8192,1481,429,34,1344,8581,1025,428,1432,8200,200,139,8328,152,136,1480,1297,8460,1285,8353,257,136,1345,429]

theorem envBound21073 : H12AffineFastState.Bounded env21073 := by
  intro p hp
  have h : env21073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21072_21073 : H12AffineEnvironment.transform 31 8353 env21072 = env21073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 8353 env21072 == env21073) = true)

def env21074 : List Nat := [2,4,8,16,32,16,128,256,429,1024,1,1433,8192,1433,429,34,1296,8581,1025,428,1432,8200,152,139,8328,152,136,1432,1297,8460,1285,8353,257,136,1297,429]

theorem envBound21074 : H12AffineFastState.Bounded env21074 := by
  intro p hp
  have h : env21074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21073_21074 : H12AffineEnvironment.transform 5 16 env21073 = env21074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env21073 == env21074) = true)

theorem identity21074 : scanCanonicalize (H12AffineFastState.compose env21074 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound21074 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21075 : List Nat := [2,4,8,16,32,16,9,256,292,1024,1,1296,8192,1296,292,34,1296,8460,1025,293,1297,8200,17,2,8193,17,1,1297,1297,8460,1285,8232,257,1,1297,292]

theorem envBound21075 : H12AffineFastState.Bounded env21075 := by
  intro p hp
  have h : env21075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21074_21075 : H12AffineEnvironment.transform 6 9 env21074 = env21075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21074 == env21075) = true)

theorem identity21075 : scanCanonicalize (H12AffineFastState.compose env21075 (packedSelected [3] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound21075 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env21076 : List Nat := [2,4,8,16,32,16,9,256,292,1024,1,1296,269,1296,292,34,1296,1,1025,293,1297,261,17,2,268,17,1,1297,1297,1,1285,293,257,1,1297,292]

theorem envBound21076 : H12AffineFastState.Bounded env21076 := by
  intro p hp
  have h : env21076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21075_21076 : H12AffineEnvironment.transform 12 269 env21075 = env21076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env21075 == env21076) = true)

theorem identity21076 : scanCanonicalize (H12AffineFastState.compose env21076 (packedSelected [2,4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound21076 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env21077 : List Nat := [2,4,8,16,32,16,9,37,1,1024,1,1077,40,1077,1,34,1077,1,1025,0,1076,32,17,2,41,17,1,1076,1076,1,1056,0,36,1,1076,1]

theorem envBound21077 : H12AffineFastState.Bounded env21077 := by
  intro p hp
  have h : env21077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21076_21077 : H12AffineEnvironment.transform 7 37 env21076 = env21077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env21076 == env21077) = true)

theorem identity21077 : scanCanonicalize (H12AffineFastState.compose env21077 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound21077 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21078 : List Nat := [2,4,8,16,0,16,9,5,1,1024,1,1045,8,1045,1,2,1045,1,1025,0,1044,0,17,2,9,17,1,1044,1044,1,1024,0,4,1,1044,1]

theorem envBound21078 : H12AffineFastState.Bounded env21078 := by
  intro p hp
  have h : env21078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21077_21078 : H12AffineEnvironment.transform 4 0 env21077 = env21078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env21077 == env21078) = true)

def env21079 : List Nat := [2,4,8,16,32,17,128,256,429,1024,1,1433,8192,1432,429,34,1297,8581,1025,428,1432,8200,153,139,8328,152,136,1433,1297,8460,1285,8353,257,136,1296,429]

theorem envBound21079 : H12AffineFastState.Bounded env21079 := by
  intro p hp
  have h : env21079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21073_21079 : H12AffineEnvironment.transform 5 17 env21073 = env21079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env21073 == env21079) = true)

theorem identity21079 : scanCanonicalize (H12AffineFastState.compose env21079 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound21079 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21080 : List Nat := [2,4,8,16,32,17,128,256,429,1024,1,1433,269,1432,429,34,1297,136,1025,428,1432,261,153,139,389,152,136,1433,1297,1,1285,428,257,136,1296,429]

theorem envBound21080 : H12AffineFastState.Bounded env21080 := by
  intro p hp
  have h : env21080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21079_21080 : H12AffineEnvironment.transform 12 269 env21079 = env21080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env21079 == env21080) = true)

theorem identity21080 : scanCanonicalize (H12AffineFastState.compose env21080 (packedSelected [2,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound21080 : packedSelected [2,4,5] rootPS < 2^1333 := by decide +kernel

def env21081 : List Nat := [2,4,8,16,32,17,9,256,292,1024,1,1296,269,1297,292,34,1297,1,1025,293,1297,261,16,2,268,17,1,1296,1297,1,1285,293,257,1,1296,292]

theorem envBound21081 : H12AffineFastState.Bounded env21081 := by
  intro p hp
  have h : env21081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21080_21081 : H12AffineEnvironment.transform 6 9 env21080 = env21081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21080 == env21081) = true)

theorem identity21081 : scanCanonicalize (H12AffineFastState.compose env21081 (packedSelected [2,4] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound21081 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env21082 : List Nat := [2,4,8,16,32,17,9,36,0,1024,1,1076,41,1077,0,34,1077,1,1025,1,1077,33,16,2,40,17,1,1076,1077,1,1057,1,37,1,1076,0]

theorem envBound21082 : H12AffineFastState.Bounded env21082 := by
  intro p hp
  have h : env21082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21081_21082 : H12AffineEnvironment.transform 7 36 env21081 = env21082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env21081 == env21082) = true)

def leafEnv21082 : List Nat := [2,4,8,16,32,17,9,36,0,1024,1,1076,41,1077,0,34,1077,1,1025,1,1077,33,16,2,1056,40,1,17,1,1076,1077,1,1057,1,37,1,5,34,1076,0,0,1076,1]

def active21082 : List Nat := [0,1,2,3,4,9]

def tree21082 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21082 : H12WitnessSearch.Good tree21082 := H12GlobalWitnessIndex.good

theorem leafIdentity21082 : H12AffineFastState.composeSystem env21082 rootObs = leafEnv21082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21082 rootObs == leafEnv21082) = true)

theorem terminalChecked21082 : H12PackedTerminal.terminalCheckFast leafEnv21082 active21082 tree21082 = true := by decide +kernel

def env21083 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1345,262144,524288,32769,4097,8200,17664,98565,8328,541009,795917,16385,545089,1073741824,1284,4294967296,257,4295074215,1345,512]

theorem envBound21083 : H12AffineFastState.Bounded env21083 := by
  intro p hp
  have h : env21083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21025_21083 : H12AffineEnvironment.transform 16 1345 env21025 = env21083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env21025 == env21083) = true)

theorem identity21083 : scanCanonicalize (H12AffineFastState.compose env21083 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 279824) := by decide +kernel

theorem selectedBound21083 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env21084 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1345,262144,524288,32769,4097,8200,17664,98565,8328,541009,795917,16385,545089,279824,1284,4294967296,257,4295074215,1345,512]

theorem envBound21084 : H12AffineFastState.Bounded env21084 := by
  intro p hp
  have h : env21084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21083_21084 : H12AffineEnvironment.transform 29 279824 env21083 = env21084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 279824 env21083 == env21084) = true)

theorem identity21084 : scanCanonicalize (H12AffineFastState.compose env21084 (packedSelected [4,9,16] rootPS)) = affineNative (2^(18+1) ^^^ 1025) := by decide +kernel

theorem selectedBound21084 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env21085 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1345,262144,1025,32769,4097,8200,17664,98565,8328,17744,270604,16385,21824,279824,1284,4294967296,257,4295074215,1345,512]

theorem envBound21085 : H12AffineFastState.Bounded env21085 := by
  intro p hp
  have h : env21085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21084_21085 : H12AffineEnvironment.transform 18 1025 env21084 = env21085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env21084 == env21085) = true)

theorem identity21085 : scanCanonicalize (H12AffineFastState.compose env21085 (packedSelected [1,5,8,15,17,21,24,38] rootPS)) = affineNative (2^(17+1) ^^^ 124307) := by decide +kernel

theorem selectedBound21085 : packedSelected [1,5,8,15,17,21,24,38] rootPS < 2^1333 := by decide +kernel

def env21086 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1345,124307,1025,32769,4097,8200,17664,98565,8328,17744,115871,16385,21824,106627,1284,4294967296,257,4295074215,1345,512]

theorem envBound21086 : H12AffineFastState.Bounded env21086 := by
  intro p hp
  have h : env21086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21085_21086 : H12AffineEnvironment.transform 17 124307 env21085 = env21086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 124307 env21085 == env21086) = true)

theorem identity21086 : scanCanonicalize (H12AffineFastState.compose env21086 (packedSelected [13,21] rootPS)) = affineNative (2^(13+1) ^^^ 4176) := by decide +kernel

theorem selectedBound21086 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env21087 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,4176,32768,65536,1345,112067,1025,32769,4097,8200,5456,98565,8328,5376,103631,4177,1296,106627,1284,4294967296,257,4295074215,1345,512]

theorem envBound21087 : H12AffineFastState.Bounded env21087 := by
  intro p hp
  have h : env21087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21086_21087 : H12AffineEnvironment.transform 13 4176 env21086 = env21087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env21086 == env21087) = true)

theorem identity21087 : scanCanonicalize (H12AffineFastState.compose env21087 (packedSelected [3,5,10] rootPS)) = affineNative (2^(31+1) ^^^ 8320) := by decide +kernel

theorem selectedBound21087 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env21088 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,4176,32768,65536,1345,112067,1025,32769,4097,8200,5456,98565,8328,5376,103631,4177,1296,106627,1284,8320,257,98599,1345,512]

theorem envBound21088 : H12AffineFastState.Bounded env21088 := by
  intro p hp
  have h : env21088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21087_21088 : H12AffineEnvironment.transform 31 8320 env21087 = env21088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 8320 env21087 == env21088) = true)

theorem identity21088 : scanCanonicalize (H12AffineFastState.compose env21088 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 5610) := by decide +kernel

theorem selectedBound21088 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env21089 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,4176,32768,5610,1345,41001,1025,32769,4097,8200,5456,38127,8328,5376,33061,4177,1296,46441,1284,8320,257,38093,1345,512]

theorem envBound21089 : H12AffineFastState.Bounded env21089 := by
  intro p hp
  have h : env21089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21088_21089 : H12AffineEnvironment.transform 15 5610 env21088 = env21089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5610 env21088 == env21089) = true)

theorem identity21089 : scanCanonicalize (H12AffineFastState.compose env21089 (packedSelected [3,5,12,13] rootPS)) = affineNative (2^(14+1) ^^^ 8433) := by decide +kernel

theorem selectedBound21089 : packedSelected [3,5,12,13] rootPS < 2^1333 := by decide +kernel

def env21090 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,4176,8433,5610,1345,216,1025,8432,4097,8200,5456,13342,8328,5376,8660,4177,1296,5528,1284,8320,257,13372,1345,512]

theorem envBound21090 : H12AffineFastState.Bounded env21090 := by
  intro p hp
  have h : env21090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21089_21090 : H12AffineEnvironment.transform 14 8433 env21089 = env21090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8433 env21089 == env21090) = true)

theorem identity21090 : scanCanonicalize (H12AffineFastState.compose env21090 (packedSelected [2,4,6,9] rootPS)) = affineNative (2^(12+1) ^^^ 5992) := by decide +kernel

theorem selectedBound21090 : packedSelected [2,4,6,9] rootPS < 2^1333 := by decide +kernel

def env21091 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,5992,4176,6041,5610,1345,216,1025,6040,4097,5984,5456,886,6112,5376,5820,4177,1296,5528,1284,6120,257,852,1345,512]

theorem envBound21091 : H12AffineFastState.Bounded env21091 := by
  intro p hp
  have h : env21091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21090_21091 : H12AffineEnvironment.transform 12 5992 env21090 = env21091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5992 env21090 == env21091) = true)

theorem identity21091 : scanCanonicalize (H12AffineFastState.compose env21091 (packedSelected [0,1,4] rootPS)) = affineNative (2^(9+1) ^^^ 816) := by decide +kernel

theorem selectedBound21091 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env21092 : List Nat := [2,4,8,16,32,64,128,256,512,816,1,4096,4184,4176,4265,4826,625,216,817,4264,4097,4176,4704,886,4304,4656,4492,4177,544,4776,564,4312,257,852,625,512]

theorem envBound21092 : H12AffineFastState.Bounded env21092 := by
  intro p hp
  have h : env21092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21091_21092 : H12AffineEnvironment.transform 9 816 env21091 = env21092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 816 env21091 == env21092) = true)

theorem identity21092 : scanCanonicalize (H12AffineFastState.compose env21092 (packedSelected [3,8,12,17] rootPS)) = affineNative (2^(11+1) ^^^ 33) := by decide +kernel

theorem selectedBound21092 : packedSelected [3,8,12,17] rootPS < 2^1333 := by decide +kernel

def env21093 : List Nat := [2,4,8,16,32,64,128,256,512,816,1,33,121,113,136,763,625,216,817,137,32,113,577,886,241,529,429,112,544,649,564,249,257,852,625,512]

theorem envBound21093 : H12AffineFastState.Bounded env21093 := by
  intro p hp
  have h : env21093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21092_21093 : H12AffineEnvironment.transform 11 33 env21092 = env21093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 33 env21092 == env21093) = true)

theorem identity21093 : scanCanonicalize (H12AffineFastState.compose env21093 (packedSelected [3,5] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound21093 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env21094 : List Nat := [2,4,8,16,32,64,128,256,33,273,1,33,121,113,136,218,80,216,272,137,32,113,96,343,241,48,429,112,1,168,21,249,257,373,80,33]

theorem envBound21094 : H12AffineFastState.Bounded env21094 := by
  intro p hp
  have h : env21094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21093_21094 : H12AffineEnvironment.transform 8 33 env21093 = env21094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env21093 == env21094) = true)

theorem identity21094 : scanCanonicalize (H12AffineFastState.compose env21094 (packedSelected [6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound21094 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env21095 : List Nat := [2,4,8,16,32,64,8,256,33,273,1,33,121,113,0,82,80,80,272,1,32,113,96,343,121,48,293,112,1,32,21,113,257,373,80,33]

theorem envBound21095 : H12AffineFastState.Bounded env21095 := by
  intro p hp
  have h : env21095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21094_21095 : H12AffineEnvironment.transform 6 8 env21094 = env21095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21094 == env21095) = true)

theorem identity21095 : scanCanonicalize (H12AffineFastState.compose env21095 (packedSelected [0,1,2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound21095 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env21096 : List Nat := [2,4,8,16,16,64,8,256,17,273,1,17,73,65,0,82,80,80,272,1,16,65,80,343,73,0,277,64,1,16,21,65,257,325,80,17]

theorem envBound21096 : H12AffineFastState.Bounded env21096 := by
  intro p hp
  have h : env21096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21095_21096 : H12AffineEnvironment.transform 4 16 env21095 = env21096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env21095 == env21096) = true)

theorem identity21096 : scanCanonicalize (H12AffineFastState.compose env21096 (packedSelected [0,1,3] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound21096 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env21097 : List Nat := [2,4,8,16,16,64,8,68,17,85,1,17,73,65,0,82,80,80,84,1,16,65,80,19,73,0,81,64,1,16,21,65,69,1,80,17]

theorem envBound21097 : H12AffineFastState.Bounded env21097 := by
  intro p hp
  have h : env21097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21096_21097 : H12AffineEnvironment.transform 7 68 env21096 = env21097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env21096 == env21097) = true)

theorem identity21097 : scanCanonicalize (H12AffineFastState.compose env21097 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound21097 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21098 : List Nat := [2,4,8,0,0,64,8,68,1,69,1,1,73,65,0,66,64,64,68,1,0,65,64,3,73,0,65,64,1,0,5,65,69,1,64,1]

theorem envBound21098 : H12AffineFastState.Bounded env21098 := by
  intro p hp
  have h : env21098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21097_21098 : H12AffineEnvironment.transform 3 0 env21097 = env21098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env21097 == env21098) = true)

theorem identity21098 : scanCanonicalize (H12AffineFastState.compose env21098 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound21098 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21099 : List Nat := [2,4,8,0,0,0,8,4,1,5,1,1,9,1,0,2,0,0,4,1,0,1,0,3,9,0,1,0,1,0,5,1,5,1,0,1]

theorem envBound21099 : H12AffineFastState.Bounded env21099 := by
  intro p hp
  have h : env21099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21098_21099 : H12AffineEnvironment.transform 5 0 env21098 = env21099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env21098 == env21099) = true)

def env21100 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,8914001,134217728,8519745,536870912,1073741824,562663489,4294967296,545789249,4315938986,34359738368,512]

theorem envBound21100 : H12AffineFastState.Bounded env21100 := by
  intro p hp
  have h : env21100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17940_21100 : H12AffineEnvironment.transform 27 8519745 env17940 = env21100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 8519745 env17940 == env21100) = true)

def env21101 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,8914001,134217728,8519745,536870912,1073741824,562663489,4294967296,545789249,4315938986,702907648,512]

theorem envBound21101 : H12AffineFastState.Bounded env21101 := by
  intro p hp
  have h : env21101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21100_21101 : H12AffineEnvironment.transform 34 702907648 env21100 = env21101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 702907648 env21100 == env21101) = true)

def env21102 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,8914001,134217728,8519745,2769920,1073741824,27513921,4294967296,10637633,4315938986,164610304,512]

theorem envBound21102 : H12AffineFastState.Bounded env21102 := by
  intro p hp
  have h : env21102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21101_21102 : H12AffineEnvironment.transform 28 2769920 env21101 = env21102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 28 2769920 env21101 == env21102) = true)

def env21103 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,4194304,8388608,16777216,8328,8914001,134217728,8519745,676864,1073741824,25412673,4294967296,8536385,4315938986,164610304,512]

theorem envBound21103 : H12AffineFastState.Bounded env21103 := by
  intro p hp
  have h : env21103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21102_21103 : H12AffineEnvironment.transform 20 4096 env21102 = env21103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env21102 == env21103) = true)

end H12CloudChart2