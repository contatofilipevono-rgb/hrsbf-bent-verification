import H12CloudChart2Data194

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env49012 : List Nat := [2,4,8,16,7,17,128,138,1,4,13,12,139,158,158,155,132,13,141,159,12,7,11,25,139,130,159,133,133,133,24,7,139,29,158,136]

theorem envBound49012 : H12AffineFastState.Bounded env49012 := by
  intro p hp
  have h : env49012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49011_49012 : H12AffineEnvironment.transform 4 7 env49011 = env49012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env49011 == env49012) = true)

theorem identity49012 : scanCanonicalize (H12AffineFastState.compose env49012 (packedSelected [0,1,2,7] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound49012 : packedSelected [0,1,2,7] rootPS < 2^1333 := by decide +kernel

def env49013 : List Nat := [2,4,8,16,7,17,19,25,1,4,13,12,24,13,13,8,23,13,30,12,12,7,11,25,24,17,12,22,22,22,24,7,24,29,13,27]

theorem envBound49013 : H12AffineFastState.Bounded env49013 := by
  intro p hp
  have h : env49013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49012_49013 : H12AffineEnvironment.transform 6 19 env49012 = env49013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env49012 == env49013) = true)

theorem identity49013 : scanCanonicalize (H12AffineFastState.compose env49013 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound49013 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env49014 : List Nat := [2,4,8,6,7,7,5,15,1,4,13,12,14,13,13,8,1,13,8,12,12,7,11,15,14,7,12,0,0,0,14,7,14,11,13,13]

theorem envBound49014 : H12AffineFastState.Bounded env49014 := by
  intro p hp
  have h : env49014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49013_49014 : H12AffineEnvironment.transform 3 6 env49013 = env49014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env49013 == env49014) = true)

theorem identity49014 : scanCanonicalize (H12AffineFastState.compose env49014 (packedSelected [0,1,4] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound49014 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env49015 : List Nat := [2,4,5,6,7,7,5,2,1,4,0,1,3,0,0,5,1,0,5,1,1,7,6,2,3,7,1,0,0,0,3,7,3,6,0,0]

theorem envBound49015 : H12AffineFastState.Bounded env49015 := by
  intro p hp
  have h : env49015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49014_49015 : H12AffineEnvironment.transform 2 5 env49014 = env49015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env49014 == env49015) = true)

theorem identity49015 : scanCanonicalize (H12AffineFastState.compose env49015 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound49015 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49016 : List Nat := [1,4,5,5,4,4,5,1,1,4,0,1,0,0,0,5,1,0,5,1,1,4,5,1,0,4,1,0,0,0,0,4,0,5,0,0]

theorem envBound49016 : H12AffineFastState.Bounded env49016 := by
  intro p hp
  have h : env49016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49015_49016 : H12AffineEnvironment.transform 0 1 env49015 = env49016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env49015 == env49016) = true)

theorem identity49016 : scanCanonicalize (H12AffineFastState.compose env49016 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound49016 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49017 : List Nat := [1,1,0,0,1,1,0,1,1,1,0,1,0,0,0,0,1,0,0,1,1,1,0,1,0,1,1,0,0,0,0,1,0,0,0,0]

theorem envBound49017 : H12AffineFastState.Bounded env49017 := by
  intro p hp
  have h : env49017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49016_49017 : H12AffineEnvironment.transform 1 1 env49016 = env49017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env49016 == env49017) = true)

def env49018 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,16777216,533641,672785,17245633,148800,545089,96347,16876544,618622,257,16876549,1344,525824]

theorem envBound49018 : H12AffineFastState.Bounded env49018 := by
  intro p hp
  have h : env49018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48889_49018 : H12AffineEnvironment.transform 26 17245633 env48889 = env49018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245633 env48889 == env49018) = true)

theorem identity49018 : scanCanonicalize (H12AffineFastState.compose env49018 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 717114) := by decide +kernel

theorem selectedBound49018 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env49019 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,717114,533641,672785,906491,148800,545089,96347,750906,618622,257,750911,1344,525824]

theorem envBound49019 : H12AffineFastState.Bounded env49019 := by
  intro p hp
  have h : env49019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49018_49019 : H12AffineEnvironment.transform 23 717114 env49018 = env49019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 717114 env49018 == env49019) = true)

def env49020 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147520,58682,143497,20497,508155,148800,148801,96347,90426,222334,257,90431,1344,135680]

theorem envBound49020 : H12AffineFastState.Bounded env49020 := by
  intro p hp
  have h : env49020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49019_49020 : H12AffineEnvironment.transform 18 136192 env49019 = env49020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136192 env49019 == env49020) = true)

def env49021 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147520,58518,143497,20497,508155,148716,148717,96347,90262,222334,173,90259,1260,135680]

theorem envBound49021 : H12AffineFastState.Bounded env49021 := by
  intro p hp
  have h : env49021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49020_49021 : H12AffineEnvironment.transform 7 172 env49020 = env49021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env49020 == env49021) = true)

def env49022 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61569,147472,58518,143497,20497,508075,148668,148669,96267,90262,222254,173,90259,1212,135680]

theorem envBound49022 : H12AffineFastState.Bounded env49022 := by
  intro p hp
  have h : env49022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49021_49022 : H12AffineEnvironment.transform 5 16 env49021 = env49022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env49021 == env49022) = true)

theorem identity49022 : scanCanonicalize (H12AffineFastState.compose env49022 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 137352) := by decide +kernel

theorem selectedBound49022 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env49023 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,137352,136192,32769,4096,61569,147472,58518,143497,20497,120867,148668,148669,96267,90262,222254,173,90259,1212,135680]

theorem envBound49023 : H12AffineFastState.Bounded env49023 := by
  intro p hp
  have h : env49023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49022_49023 : H12AffineEnvironment.transform 17 137352 env49022 = env49023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137352 env49022 == env49023) = true)

theorem identity49023 : scanCanonicalize (H12AffineFastState.compose env49023 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(16+1) ^^^ 62493) := by decide +kernel

theorem selectedBound49023 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env49024 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,62493,60565,57373,32769,4096,61569,46093,58518,50324,20497,120867,45217,45216,96267,90262,102451,173,90259,1212,58909]

theorem envBound49024 : H12AffineFastState.Bounded env49024 := by
  intro p hp
  have h : env49024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49023_49024 : H12AffineEnvironment.transform 16 62493 env49023 = env49024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 62493 env49023 == env49024) = true)

theorem identity49024 : scanCanonicalize (H12AffineFastState.compose env49024 (packedSelected [4,9,16] rootPS)) = affineNative (2^(14+1) ^^^ 29861) := by decide +kernel

theorem selectedBound49024 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env49025 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,29861,65536,184,6192,5304,29860,4096,1060,16552,4147,12337,20497,76934,17412,17413,96267,90262,91286,173,90259,1212,4792]

theorem envBound49025 : H12AffineFastState.Bounded env49025 := by
  intro p hp
  have h : env49025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49024_49025 : H12AffineEnvironment.transform 14 29861 env49024 = env49025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29861 env49024 == env49025) = true)

theorem identity49025 : scanCanonicalize (H12AffineFastState.compose env49025 (packedSelected [0,2,3,5,6,7,10,13,20] rootPS)) = affineNative (2^(15+1) ^^^ 6675) := by decide +kernel

theorem selectedBound49025 : packedSelected [0,2,3,5,6,7,10,13,20] rootPS < 2^1333 := by decide +kernel

def env49026 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,29861,6675,184,6192,5304,29860,4096,1060,16552,4147,12337,20497,13973,17412,17413,25112,31365,32389,173,31360,1212,4792]

theorem envBound49026 : H12AffineFastState.Bounded env49026 := by
  intro p hp
  have h : env49026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49025_49026 : H12AffineEnvironment.transform 15 6675 env49025 = env49026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 6675 env49025 == env49026) = true)

theorem identity49026 : scanCanonicalize (H12AffineFastState.compose env49026 (packedSelected [17,18,19,21,23,26] rootPS)) = affineNative (2^(12+1) ^^^ 7828) := by decide +kernel

theorem selectedBound49026 : packedSelected [17,18,19,21,23,26] rootPS < 2^1333 := by decide +kernel

def env49027 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,7828,16384,18993,6675,184,6192,5304,18992,4096,1060,16552,4147,3749,20497,2049,17412,17413,23692,17425,16401,173,17428,1212,4792]

theorem envBound49027 : H12AffineFastState.Bounded env49027 := by
  intro p hp
  have h : env49027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49026_49027 : H12AffineEnvironment.transform 12 7828 env49026 = env49027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7828 env49026 == env49027) = true)

theorem identity49027 : scanCanonicalize (H12AffineFastState.compose env49027 (packedSelected [0,1,3,5,8,9,11,13,17] rootPS)) = affineNative (2^(13+1) ^^^ 5772) := by decide +kernel

theorem selectedBound49027 : packedSelected [0,1,3,5,8,9,11,13,17] rootPS < 2^1333 := by decide +kernel

def env49028 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,7828,5772,7357,6675,184,6192,5304,7356,4096,1060,5668,4147,3749,1693,2049,4744,4745,2560,4765,5789,173,4760,1212,4792]

theorem envBound49028 : H12AffineFastState.Bounded env49028 := by
  intro p hp
  have h : env49028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49027_49028 : H12AffineEnvironment.transform 13 5772 env49027 = env49028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5772 env49027 == env49028) = true)

theorem identity49028 : scanCanonicalize (H12AffineFastState.compose env49028 (packedSelected [2,4,5,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 555) := by decide +kernel

theorem selectedBound49028 : packedSelected [2,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env49029 : List Nat := [2,4,8,16,32,16,128,172,512,1024,555,4096,5311,5772,5782,4152,184,4635,5304,5783,4096,1060,5668,4147,1166,1693,554,4744,4745,43,4765,5789,173,4760,1212,4792]

theorem envBound49029 : H12AffineFastState.Bounded env49029 := by
  intro p hp
  have h : env49029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49028_49029 : H12AffineEnvironment.transform 10 555 env49028 = env49029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 555 env49028 == env49029) = true)

theorem identity49029 : scanCanonicalize (H12AffineFastState.compose env49029 (packedSelected [0,1,2,5,6,7,10] rootPS)) = affineNative (2^(9+1) ^^^ 30) := by decide +kernel

theorem selectedBound49029 : packedSelected [0,1,2,5,6,7,10] rootPS < 2^1333 := by decide +kernel

def env49030 : List Nat := [2,4,8,16,32,16,128,172,512,30,555,4096,4257,4754,4744,4152,184,4635,4262,4745,4096,58,4666,4147,144,643,554,4744,4745,43,4765,4739,173,4760,162,4792]

theorem envBound49030 : H12AffineFastState.Bounded env49030 := by
  intro p hp
  have h : env49030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49029_49030 : H12AffineEnvironment.transform 9 30 env49029 = env49030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 30 env49029 == env49030) = true)

def env49031 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61568,147473,58518,143497,20497,508074,148669,148668,96266,90262,222255,173,90259,1213,135680]

theorem envBound49031 : H12AffineFastState.Bounded env49031 := by
  intro p hp
  have h : env49031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49021_49031 : H12AffineEnvironment.transform 5 17 env49021 = env49031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env49021 == env49031) = true)

theorem identity49031 : scanCanonicalize (H12AffineFastState.compose env49031 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 45216) := by decide +kernel

theorem selectedBound49031 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env49032 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,45216,262144,42144,32769,4096,61568,61617,58518,32809,20497,356362,62493,62492,96266,90262,119951,173,90259,1213,41632]

theorem envBound49032 : H12AffineFastState.Bounded env49032 := by
  intro p hp
  have h : env49032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49031_49032 : H12AffineEnvironment.transform 16 45216 env49031 = env49032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45216 env49031 == env49032) = true)

theorem identity49032 : scanCanonicalize (H12AffineFastState.compose env49032 (packedSelected [16,20] rootPS)) = affineNative (2^(17+1) ^^^ 2185) := by decide +kernel

theorem selectedBound49032 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env49033 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,45216,2185,42144,32769,4096,61568,61617,58518,32809,20497,96387,62493,62492,96266,90262,119951,173,90259,1213,41632]

theorem envBound49033 : H12AffineFastState.Bounded env49033 := by
  intro p hp
  have h : env49033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49032_49033 : H12AffineEnvironment.transform 17 2185 env49032 = env49033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2185 env49032 == env49033) = true)

theorem identity49033 : scanCanonicalize (H12AffineFastState.compose env49033 (packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS)) = affineNative (2^(15+1) ^^^ 24635) := by decide +kernel

theorem selectedBound49033 : packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env49034 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,24635,45216,2185,42144,32769,4096,61568,61617,58518,32809,20497,6328,62493,62492,6193,173,46260,173,168,1213,41632]

theorem envBound49034 : H12AffineFastState.Bounded env49034 := by
  intro p hp
  have h : env49034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49033_49034 : H12AffineEnvironment.transform 15 24635 env49033 = env49034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 24635 env49033 == env49034) = true)

theorem identity49034 : scanCanonicalize (H12AffineFastState.compose env49034 (packedSelected [1,4,5,8,9,16,17,21,24] rootPS)) = affineNative (2^(13+1) ^^^ 5124) := by decide +kernel

theorem selectedBound49034 : packedSelected [1,4,5,8,9,16,17,21,24] rootPS < 2^1333 := by decide +kernel

def env49035 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,5124,32768,13375,45216,2185,42144,32769,4096,42116,42165,45202,32809,1045,6328,40985,40984,6193,173,46260,173,168,1213,41632]

theorem envBound49035 : H12AffineFastState.Bounded env49035 := by
  intro p hp
  have h : env49035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49034_49035 : H12AffineEnvironment.transform 13 5124 env49034 = env49035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5124 env49034 == env49035) = true)

theorem identity49035 : scanCanonicalize (H12AffineFastState.compose env49035 (packedSelected [2,3,5,6,10,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 7845) := by decide +kernel

theorem selectedBound49035 : packedSelected [2,3,5,6,10,15,17] rootPS < 2^1333 := by decide +kernel

def env49036 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,7845,5124,32768,2714,36357,2185,39429,32769,4096,39457,39440,36407,32809,1045,6328,40636,40637,6193,173,35345,173,168,1213,39941]

theorem envBound49036 : H12AffineFastState.Bounded env49036 := by
  intro p hp
  have h : env49036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49035_49036 : H12AffineEnvironment.transform 12 7845 env49035 = env49036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7845 env49035 == env49036) = true)

theorem identity49036 : scanCanonicalize (H12AffineFastState.compose env49036 (packedSelected [3,5,6,7,9,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 2745) := by decide +kernel

theorem selectedBound49036 : packedSelected [3,5,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env49037 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,2745,1052,3773,32768,2714,36357,2185,32956,32769,2745,32920,32937,36407,32809,1045,513,33797,33796,648,173,35345,173,168,1213,34492]

theorem envBound49037 : H12AffineFastState.Bounded env49037 := by
  intro p hp
  have h : env49037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49036_49037 : H12AffineEnvironment.transform 11 2745 env49036 = env49037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2745 env49036 == env49037) = true)

theorem identity49037 : scanCanonicalize (H12AffineFastState.compose env49037 (packedSelected [0,4,11] rootPS)) = affineNative (2^(14+1) ^^^ 2184) := by decide +kernel

theorem selectedBound49037 : packedSelected [0,4,11] rootPS < 2^1333 := by decide +kernel

def env49038 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,2745,1052,3773,2184,2714,1677,2185,2100,2185,2745,2064,2081,1727,2209,1045,513,3213,3212,648,173,665,173,168,1213,3636]

theorem envBound49038 : H12AffineFastState.Bounded env49038 := by
  intro p hp
  have h : env49038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49037_49038 : H12AffineEnvironment.transform 14 2184 env49037 = env49038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2184 env49037 == env49038) = true)

theorem identity49038 : scanCanonicalize (H12AffineFastState.compose env49038 (packedSelected [0,1,2,6,8,9,12] rootPS)) = affineNative (2^(10+1) ^^^ 697) := by decide +kernel

theorem selectedBound49038 : packedSelected [0,1,2,6,8,9,12] rootPS < 2^1333 := by decide +kernel

def env49039 : List Nat := [2,4,8,16,32,17,128,172,512,1024,697,0,1052,1028,561,35,1677,560,653,560,0,681,664,1727,536,1045,513,1588,1589,648,173,665,173,168,1213,1165]

theorem envBound49039 : H12AffineFastState.Bounded env49039 := by
  intro p hp
  have h : env49039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49038_49039 : H12AffineEnvironment.transform 10 697 env49038 = env49039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 697 env49038 == env49039) = true)

theorem identity49039 : scanCanonicalize (H12AffineFastState.compose env49039 (packedSelected [1,3,4,9] rootPS)) = affineNative (2^(9+1) ^^^ 151) := by decide +kernel

theorem selectedBound49039 : packedSelected [1,3,4,9] rootPS < 2^1333 := by decide +kernel

def env49040 : List Nat := [2,4,8,16,32,17,128,172,512,151,697,0,139,147,561,35,538,560,653,560,0,681,664,552,536,130,513,675,674,648,173,665,173,168,42,26]

theorem envBound49040 : H12AffineFastState.Bounded env49040 := by
  intro p hp
  have h : env49040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49039_49040 : H12AffineEnvironment.transform 9 151 env49039 = env49040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 151 env49039 == env49040) = true)

theorem identity49040 : scanCanonicalize (H12AffineFastState.compose env49040 (packedSelected [2,4,6,7] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound49040 : packedSelected [2,4,6,7] rootPS < 2^1333 := by decide +kernel

def env49041 : List Nat := [2,4,8,16,32,17,128,172,48,151,137,0,139,147,1,35,42,0,189,0,0,153,168,24,40,130,49,147,146,184,173,169,173,168,42,26]

theorem envBound49041 : H12AffineFastState.Bounded env49041 := by
  intro p hp
  have h : env49041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49040_49041 : H12AffineEnvironment.transform 8 48 env49040 = env49041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env49040 == env49041) = true)

theorem identity49041 : scanCanonicalize (H12AffineFastState.compose env49041 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound49041 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env49042 : List Nat := [2,4,8,16,32,17,8,36,48,31,1,0,3,27,1,35,42,0,53,0,0,17,32,24,40,10,49,27,26,48,37,33,37,32,42,26]

theorem envBound49042 : H12AffineFastState.Bounded env49042 := by
  intro p hp
  have h : env49042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49041_49042 : H12AffineEnvironment.transform 6 8 env49041 = env49042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env49041 == env49042) = true)

theorem identity49042 : scanCanonicalize (H12AffineFastState.compose env49042 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound49042 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env49043 : List Nat := [2,4,8,16,17,17,8,21,1,31,1,0,3,27,1,18,27,0,4,0,0,17,17,24,25,10,0,27,26,1,20,16,20,17,27,26]

theorem envBound49043 : H12AffineFastState.Bounded env49043 := by
  intro p hp
  have h : env49043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49042_49043 : H12AffineEnvironment.transform 4 17 env49042 = env49043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env49042 == env49043) = true)

theorem identity49043 : scanCanonicalize (H12AffineFastState.compose env49043 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound49043 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49044 : List Nat := [2,4,8,10,11,11,8,15,1,5,1,0,3,1,1,8,1,0,4,0,0,11,11,2,3,10,0,1,0,1,14,10,14,11,1,0]

theorem envBound49044 : H12AffineFastState.Bounded env49044 := by
  intro p hp
  have h : env49044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49043_49044 : H12AffineEnvironment.transform 3 10 env49043 = env49044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env49043 == env49044) = true)

theorem identity49044 : scanCanonicalize (H12AffineFastState.compose env49044 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound49044 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49045 : List Nat := [2,0,8,10,11,11,8,11,1,1,1,0,3,1,1,8,1,0,0,0,0,11,11,2,3,10,0,1,0,1,10,10,10,11,1,0]

theorem envBound49045 : H12AffineFastState.Bounded env49045 := by
  intro p hp
  have h : env49045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49044_49045 : H12AffineEnvironment.transform 1 0 env49044 = env49045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env49044 == env49045) = true)

theorem identity49045 : scanCanonicalize (H12AffineFastState.compose env49045 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound49045 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49046 : List Nat := [2,0,0,2,3,3,0,3,1,1,1,0,3,1,1,0,1,0,0,0,0,3,3,2,3,2,0,1,0,1,2,2,2,3,1,0]

theorem envBound49046 : H12AffineFastState.Bounded env49046 := by
  intro p hp
  have h : env49046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49045_49046 : H12AffineEnvironment.transform 2 0 env49045 = env49046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env49045 == env49046) = true)

theorem identity49046 : scanCanonicalize (H12AffineFastState.compose env49046 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound49046 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env49047 : List Nat := [0,0,0,0,1,1,0,1,1,1,1,0,1,1,1,0,1,0,0,0,0,1,1,0,1,0,0,1,0,1,0,0,0,1,1,0]

theorem envBound49047 : H12AffineFastState.Bounded env49047 := by
  intro p hp
  have h : env49047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49046_49047 : H12AffineEnvironment.transform 0 0 env49046 = env49047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env49046 == env49047) = true)

def env49048 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147520,58519,143497,20497,508155,148717,148716,96347,90263,222334,172,90258,1261,135680]

theorem envBound49048 : H12AffineFastState.Bounded env49048 := by
  intro p hp
  have h : env49048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49020_49048 : H12AffineEnvironment.transform 7 173 env49020 = env49048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env49020 == env49048) = true)

def env49049 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61569,147472,58519,143497,20497,508075,148669,148668,96267,90263,222254,172,90258,1213,135680]

theorem envBound49049 : H12AffineFastState.Bounded env49049 := by
  intro p hp
  have h : env49049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49048_49049 : H12AffineEnvironment.transform 5 16 env49048 = env49049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env49048 == env49049) = true)

theorem identity49049 : scanCanonicalize (H12AffineFastState.compose env49049 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 208054) := by decide +kernel

theorem selectedBound49049 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env49050 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,208054,136192,32769,4096,61569,147472,58519,143497,20497,60445,148669,148668,96267,90263,222254,172,90258,1213,135680]

theorem envBound49050 : H12AffineFastState.Bounded env49050 := by
  intro p hp
  have h : env49050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49049_49050 : H12AffineEnvironment.transform 17 208054 env49049 = env49050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 208054 env49049 == env49050) = true)

theorem identity49050 : scanCanonicalize (H12AffineFastState.compose env49050 (packedSelected [1,3,5,7,8,10,20,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53283) := by decide +kernel

theorem selectedBound49050 : packedSelected [1,3,5,7,8,10,20,26,27] rootPS < 2^1333 := by decide +kernel

def env49051 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,53283,131072,195733,136192,32769,4096,61569,147472,58519,143497,20497,60445,148669,148668,43048,45236,177165,172,45233,1213,135680]

theorem envBound49051 : H12AffineFastState.Bounded env49051 := by
  intro p hp
  have h : env49051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49050_49051 : H12AffineEnvironment.transform 15 53283 env49050 = env49051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53283 env49050 == env49051) = true)

theorem identity49051 : scanCanonicalize (H12AffineFastState.compose env49051 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(16+1) ^^^ 21693) := by decide +kernel

theorem selectedBound49051 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env49052 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,53283,21693,43048,16573,32769,4096,61569,5293,58519,25652,20497,60445,4096,4097,43048,45236,57520,172,45233,1213,18109]

theorem envBound49052 : H12AffineFastState.Bounded env49052 := by
  intro p hp
  have h : env49052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49051_49052 : H12AffineEnvironment.transform 16 21693 env49051 = env49052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 21693 env49051 == env49052) = true)

theorem identity49052 : scanCanonicalize (H12AffineFastState.compose env49052 (packedSelected [4,9,20] rootPS)) = affineNative (2^(14+1) ^^^ 29860) := by decide +kernel

theorem selectedBound49052 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env49053 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,29860,9351,21693,23692,16573,29861,4096,1061,5293,4147,25652,20497,6329,4096,4097,23692,17424,5140,172,17429,1213,18109]

theorem envBound49053 : H12AffineFastState.Bounded env49053 := by
  intro p hp
  have h : env49053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49052_49053 : H12AffineEnvironment.transform 14 29860 env49052 = env49053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29860 env49052 == env49053) = true)

theorem identity49053 : scanCanonicalize (H12AffineFastState.compose env49053 (packedSelected [0,2,3,4,5,6,11,16] rootPS)) = affineNative (2^(13+1) ^^^ 12960) := by decide +kernel

theorem selectedBound49053 : packedSelected [0,2,3,4,5,6,11,16] rootPS < 2^1333 := by decide +kernel

def env49054 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,12960,1540,9351,9757,11820,12829,1541,4096,1061,5293,4147,5780,8881,6329,4096,4097,11820,14000,5140,172,14005,1213,13341]

theorem envBound49054 : H12AffineFastState.Bounded env49054 := by
  intro p hp
  have h : env49054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49053_49054 : H12AffineEnvironment.transform 13 12960 env49053 = env49054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12960 env49053 == env49054) = true)

theorem identity49054 : scanCanonicalize (H12AffineFastState.compose env49054 (packedSelected [1,3,6,7,9,11,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 147) := by decide +kernel

theorem selectedBound49054 : packedSelected [1,3,6,7,9,11,15,17] rootPS < 2^1333 := by decide +kernel

def env49055 : List Nat := [2,4,8,16,32,16,128,173,512,1024,147,4096,8192,12960,1540,9351,9757,9919,12829,1541,4096,1061,5293,4147,5780,8881,4138,4096,4097,9919,14000,5140,172,14005,1213,13341]

theorem envBound49055 : H12AffineFastState.Bounded env49055 := by
  intro p hp
  have h : env49055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49054_49055 : H12AffineEnvironment.transform 10 147 env49054 = env49055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 147 env49054 == env49055) = true)

theorem identity49055 : scanCanonicalize (H12AffineFastState.compose env49055 (packedSelected [0,1,2,5,6,9,11,13] rootPS)) = affineNative (2^(12+1) ^^^ 5676) := by decide +kernel

theorem selectedBound49055 : packedSelected [0,1,2,5,6,9,11,13] rootPS < 2^1333 := by decide +kernel

def env49056 : List Nat := [2,4,8,16,32,16,128,173,512,1024,147,4096,5676,1164,1540,4779,4145,4243,1073,1541,4096,1061,5293,4147,5780,5277,4138,4096,4097,4243,156,5140,172,153,1213,561]

theorem envBound49056 : H12AffineFastState.Bounded env49056 := by
  intro p hp
  have h : env49056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49055_49056 : H12AffineEnvironment.transform 12 5676 env49055 = env49056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5676 env49055 == env49056) = true)

theorem identity49056 : scanCanonicalize (H12AffineFastState.compose env49056 (packedSelected [0,4,5,7,8,9,10,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 162) := by decide +kernel

theorem selectedBound49056 : packedSelected [0,4,5,7,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env49057 : List Nat := [2,4,8,16,32,16,128,173,512,1024,147,162,1678,1164,1540,521,147,49,1073,1541,162,1061,1039,145,1590,1087,136,162,163,49,156,1206,172,153,1213,561]

theorem envBound49057 : H12AffineFastState.Bounded env49057 := by
  intro p hp
  have h : env49057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49056_49057 : H12AffineEnvironment.transform 11 162 env49056 = env49057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 162 env49056 == env49057) = true)

theorem identity49057 : scanCanonicalize (H12AffineFastState.compose env49057 (packedSelected [0,2,4,5,6,7,8,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 542) := by decide +kernel

theorem selectedBound49057 : packedSelected [0,2,4,5,6,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env49058 : List Nat := [2,4,8,16,32,16,128,173,512,542,147,162,144,658,26,521,147,49,559,27,162,571,529,145,40,545,136,162,163,49,156,680,172,153,675,561]

theorem envBound49058 : H12AffineFastState.Bounded env49058 := by
  intro p hp
  have h : env49058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49057_49058 : H12AffineEnvironment.transform 9 542 env49057 = env49058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 542 env49057 == env49058) = true)

theorem identity49058 : scanCanonicalize (H12AffineFastState.compose env49058 (packedSelected [2,3,6,8] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound49058 : packedSelected [2,3,6,8] rootPS < 2^1333 := by decide +kernel

def env49059 : List Nat := [2,4,8,16,10,16,128,135,512,542,147,136,144,658,26,521,147,27,517,27,136,529,529,145,2,523,136,136,137,27,156,642,134,153,649,539]

theorem envBound49059 : H12AffineFastState.Bounded env49059 := by
  intro p hp
  have h : env49059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49058_49059 : H12AffineEnvironment.transform 4 10 env49058 = env49059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env49058 == env49059) = true)

theorem identity49059 : scanCanonicalize (H12AffineFastState.compose env49059 (packedSelected [0,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound49059 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env49060 : List Nat := [2,4,8,16,10,16,4,3,512,542,23,12,20,534,26,521,23,27,517,27,12,529,529,21,2,523,12,12,13,27,24,518,2,29,525,539]

theorem envBound49060 : H12AffineFastState.Bounded env49060 := by
  intro p hp
  have h : env49060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49059_49060 : H12AffineEnvironment.transform 6 4 env49059 = env49060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env49059 == env49060) = true)

theorem identity49060 : scanCanonicalize (H12AffineFastState.compose env49060 (packedSelected [2,3,5] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound49060 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env49061 : List Nat := [2,4,8,6,10,6,4,3,512,520,1,12,2,512,12,521,1,13,517,13,12,519,519,3,2,523,12,12,13,13,14,518,2,11,525,525]

theorem envBound49061 : H12AffineFastState.Bounded env49061 := by
  intro p hp
  have h : env49061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49060_49061 : H12AffineEnvironment.transform 3 6 env49060 = env49061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env49060 == env49061) = true)

theorem identity49061 : scanCanonicalize (H12AffineFastState.compose env49061 (packedSelected [1,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 12) := by decide +kernel

theorem selectedBound49061 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env49062 : List Nat := [2,4,8,6,10,6,4,3,12,4,1,12,2,12,12,5,1,13,9,13,12,11,11,3,2,7,12,12,13,13,14,10,2,11,1,1]

theorem envBound49062 : H12AffineFastState.Bounded env49062 := by
  intro p hp
  have h : env49062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49061_49062 : H12AffineEnvironment.transform 8 12 env49061 = env49062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 12 env49061 == env49062) = true)

theorem identity49062 : scanCanonicalize (H12AffineFastState.compose env49062 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound49062 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49063 : List Nat := [2,4,5,6,7,6,4,3,1,4,1,1,2,1,1,5,1,0,4,0,1,6,6,3,2,7,1,1,0,0,3,7,2,6,1,1]

theorem envBound49063 : H12AffineFastState.Bounded env49063 := by
  intro p hp
  have h : env49063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49062_49063 : H12AffineEnvironment.transform 2 5 env49062 = env49063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env49062 == env49063) = true)

def env49064 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61568,147473,58519,143497,20497,508074,148668,148669,96266,90263,222255,172,90258,1212,135680]

theorem envBound49064 : H12AffineFastState.Bounded env49064 := by
  intro p hp
  have h : env49064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49048_49064 : H12AffineEnvironment.transform 5 17 env49048 = env49064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env49048 == env49064) = true)

theorem identity49064 : scanCanonicalize (H12AffineFastState.compose env49064 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 99487) := by decide +kernel

theorem selectedBound49064 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env49065 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,99487,262144,102559,32769,4096,61568,115854,58519,111638,20497,279605,114723,114722,96266,90263,57520,172,90258,1212,104095]

theorem envBound49065 : H12AffineFastState.Bounded env49065 := by
  intro p hp
  have h : env49065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49064_49065 : H12AffineEnvironment.transform 16 99487 env49064 = env49065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 99487 env49064 == env49065) = true)

theorem identity49065 : scanCanonicalize (H12AffineFastState.compose env49065 (packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS)) = affineNative (2^(14+1) ^^^ 12312) := by decide +kernel

theorem selectedBound49065 : packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS < 2^1333 := by decide +kernel

def env49066 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,12312,65536,78983,262144,73863,12313,4096,16536,95382,21647,66574,20497,279605,94267,94266,96266,90263,20648,172,90258,1212,75399]

theorem envBound49066 : H12AffineFastState.Bounded env49066 := by
  intro p hp
  have h : env49066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49065_49066 : H12AffineEnvironment.transform 14 12312 env49065 = env49066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12312 env49065 == env49066) = true)

theorem identity49066 : scanCanonicalize (H12AffineFastState.compose env49066 (packedSelected [3,7,10,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 9351) := by decide +kernel

theorem selectedBound49066 : packedSelected [3,7,10,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env49067 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,12312,9351,4096,262144,1024,12313,4096,16536,20497,21647,8329,20497,279605,21692,21693,23693,17424,20648,172,17429,1212,512]

theorem envBound49067 : H12AffineFastState.Bounded env49067 := by
  intro p hp
  have h : env49067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49066_49067 : H12AffineEnvironment.transform 15 9351 env49066 = env49067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9351 env49066 == env49067) = true)

theorem identity49067 : scanCanonicalize (H12AffineFastState.compose env49067 (packedSelected [4,9,16] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound49067 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env49068 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1213,12312,9351,4096,262144,1024,12313,4096,1061,5292,4146,8329,5292,262280,4097,4096,6192,173,5141,172,168,1212,512]

theorem envBound49068 : H12AffineFastState.Bounded env49068 := by
  intro p hp
  have h : env49068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49067_49068 : H12AffineEnvironment.transform 13 1213 env49067 = env49068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env49067 == env49068) = true)

theorem identity49068 : scanCanonicalize (H12AffineFastState.compose env49068 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 4648) := by decide +kernel

theorem selectedBound49068 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env49069 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,4648,1213,560,5807,4096,262144,1024,561,4096,1061,5292,4146,4769,5292,262280,4097,4096,6192,173,5141,172,168,1212,512]

theorem envBound49069 : H12AffineFastState.Bounded env49069 := by
  intro p hp
  have h : env49069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49068_49069 : H12AffineEnvironment.transform 12 4648 env49068 = env49069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4648 env49068 == env49069) = true)

theorem identity49069 : scanCanonicalize (H12AffineFastState.compose env49069 (packedSelected [1,3,13] rootPS)) = affineNative (2^(17+1) ^^^ 3213) := by decide +kernel

theorem selectedBound49069 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env49070 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,4648,1213,560,5807,4096,3213,1024,561,4096,1061,5292,4146,4769,5292,3077,4097,4096,6192,173,5141,172,168,1212,512]

theorem envBound49070 : H12AffineFastState.Bounded env49070 := by
  intro p hp
  have h : env49070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49069_49070 : H12AffineEnvironment.transform 17 3213 env49069 = env49070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3213 env49069 == env49070) = true)

theorem identity49070 : scanCanonicalize (H12AffineFastState.compose env49070 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 2586) := by decide +kernel

theorem selectedBound49070 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env49071 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,2586,2098,1213,560,3253,2586,3213,1024,561,2586,1061,3766,2600,2235,3766,3077,2587,2586,554,173,3599,172,168,1212,512]

theorem envBound49071 : H12AffineFastState.Bounded env49071 := by
  intro p hp
  have h : env49071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49070_49071 : H12AffineEnvironment.transform 11 2586 env49070 = env49071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2586 env49070 == env49071) = true)

theorem identity49071 : scanCanonicalize (H12AffineFastState.compose env49071 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 674) := by decide +kernel

theorem selectedBound49071 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env49072 : List Nat := [2,4,8,16,32,17,128,173,512,1024,674,184,656,1213,560,1559,184,1583,1024,561,184,1061,1044,138,537,1044,1703,185,184,554,173,1197,172,168,1212,512]

theorem envBound49072 : H12AffineFastState.Bounded env49072 := by
  intro p hp
  have h : env49072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49071_49072 : H12AffineEnvironment.transform 10 674 env49071 = env49072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 674 env49071 == env49072) = true)

theorem identity49072 : scanCanonicalize (H12AffineFastState.compose env49072 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound49072 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49073 : List Nat := [2,4,8,16,32,17,35,14,512,1024,513,27,563,1054,560,1559,27,1583,1024,561,27,1061,1044,41,537,1044,1540,26,27,554,14,1038,15,11,1055,512]

theorem envBound49073 : H12AffineFastState.Bounded env49073 := by
  intro p hp
  have h : env49073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49072_49073 : H12AffineEnvironment.transform 6 35 env49072 = env49073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env49072 == env49073) = true)

theorem identity49073 : scanCanonicalize (H12AffineFastState.compose env49073 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound49073 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env49074 : List Nat := [2,4,8,11,32,10,35,14,512,1024,513,0,552,1029,555,1548,0,1583,1024,554,0,1061,1039,41,514,1039,1540,1,0,554,14,1038,15,11,1028,512]

theorem envBound49074 : H12AffineFastState.Bounded env49074 := by
  intro p hp
  have h : env49074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49073_49074 : H12AffineEnvironment.transform 3 11 env49073 = env49074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env49073 == env49074) = true)

theorem identity49074 : scanCanonicalize (H12AffineFastState.compose env49074 (packedSelected [1,4] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound49074 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env49075 : List Nat := [2,4,8,11,11,10,8,14,512,1024,513,0,515,1029,512,1548,0,1540,1024,513,0,1038,1039,2,514,1039,1540,1,0,513,14,1038,15,11,1028,512]

theorem envBound49075 : H12AffineFastState.Bounded env49075 := by
  intro p hp
  have h : env49075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49074_49075 : H12AffineEnvironment.transform 4 11 env49074 = env49075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env49074 == env49075) = true)

theorem identity49075 : scanCanonicalize (H12AffineFastState.compose env49075 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 9) := by decide +kernel

theorem selectedBound49075 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49076 : List Nat := [2,4,8,11,11,10,8,14,512,9,513,0,515,12,512,517,0,525,9,513,0,7,6,2,514,6,525,1,0,513,14,7,15,11,13,512]

theorem envBound49076 : H12AffineFastState.Bounded env49076 := by
  intro p hp
  have h : env49076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49075_49076 : H12AffineEnvironment.transform 9 9 env49075 = env49076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 9 env49075 == env49076) = true)

theorem identity49076 : scanCanonicalize (H12AffineFastState.compose env49076 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 13) := by decide +kernel

theorem selectedBound49076 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env49077 : List Nat := [2,4,8,11,11,10,8,14,13,9,12,0,14,12,13,8,0,0,9,12,0,7,6,2,15,6,0,1,0,12,14,7,15,11,13,13]

theorem envBound49077 : H12AffineFastState.Bounded env49077 := by
  intro p hp
  have h : env49077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49076_49077 : H12AffineEnvironment.transform 8 13 env49076 = env49077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 13 env49076 == env49077) = true)

def env49078 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147520,58683,143496,20496,508154,148800,148800,96347,90427,222335,257,90430,1344,135681]

theorem envBound49078 : H12AffineFastState.Bounded env49078 := by
  intro p hp
  have h : env49078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49019_49078 : H12AffineEnvironment.transform 18 136193 env49019 = env49078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136193 env49019 == env49078) = true)

def env49079 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147520,58519,143496,20496,508154,148716,148716,96347,90263,222335,173,90258,1260,135681]

theorem envBound49079 : H12AffineFastState.Bounded env49079 := by
  intro p hp
  have h : env49079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49078_49079 : H12AffineEnvironment.transform 7 172 env49078 = env49079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env49078 == env49079) = true)

def env49080 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61569,147472,58519,143496,20496,508074,148668,148668,96267,90263,222255,173,90258,1212,135681]

theorem envBound49080 : H12AffineFastState.Bounded env49080 := by
  intro p hp
  have h : env49080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49079_49080 : H12AffineEnvironment.transform 5 16 env49079 = env49080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env49079 == env49080) = true)

theorem identity49080 : scanCanonicalize (H12AffineFastState.compose env49080 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 45217) := by decide +kernel

theorem selectedBound49080 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env49081 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,45217,262144,42144,32769,4096,61569,61617,58519,32809,20496,356363,62493,62493,96267,90263,119950,173,90258,1212,41632]

theorem envBound49081 : H12AffineFastState.Bounded env49081 := by
  intro p hp
  have h : env49081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49080_49081 : H12AffineEnvironment.transform 16 45217 env49080 = env49081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45217 env49080 == env49081) = true)

theorem identity49081 : scanCanonicalize (H12AffineFastState.compose env49081 (packedSelected [16,20] rootPS)) = affineNative (2^(17+1) ^^^ 2185) := by decide +kernel

theorem selectedBound49081 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env49082 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,45217,2185,42144,32769,4096,61569,61617,58519,32809,20496,96386,62493,62493,96267,90263,119950,173,90258,1212,41632]

theorem envBound49082 : H12AffineFastState.Bounded env49082 := by
  intro p hp
  have h : env49082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49081_49082 : H12AffineEnvironment.transform 17 2185 env49081 = env49082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2185 env49081 == env49082) = true)

theorem identity49082 : scanCanonicalize (H12AffineFastState.compose env49082 (packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS)) = affineNative (2^(15+1) ^^^ 24635) := by decide +kernel

theorem selectedBound49082 : packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env49083 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,24635,45217,2185,42144,32769,4096,61569,61617,58519,32809,20496,6329,62493,62493,6192,172,46261,173,169,1212,41632]

theorem envBound49083 : H12AffineFastState.Bounded env49083 := by
  intro p hp
  have h : env49083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49082_49083 : H12AffineEnvironment.transform 15 24635 env49082 = env49083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 24635 env49082 == env49083) = true)

theorem identity49083 : scanCanonicalize (H12AffineFastState.compose env49083 (packedSelected [1,4,5,8,9,16,17,21,24] rootPS)) = affineNative (2^(13+1) ^^^ 5124) := by decide +kernel

theorem selectedBound49083 : packedSelected [1,4,5,8,9,16,17,21,24] rootPS < 2^1333 := by decide +kernel

def env49084 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,5124,32768,13375,45217,2185,42144,32769,4096,42117,42165,45203,32809,1044,6329,40985,40985,6192,172,46261,173,169,1212,41632]

theorem envBound49084 : H12AffineFastState.Bounded env49084 := by
  intro p hp
  have h : env49084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49083_49084 : H12AffineEnvironment.transform 13 5124 env49083 = env49084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5124 env49083 == env49084) = true)

theorem identity49084 : scanCanonicalize (H12AffineFastState.compose env49084 (packedSelected [2,3,5,6,10,15,17] rootPS)) = affineNative (2^(14+1) ^^^ 3772) := by decide +kernel

theorem selectedBound49084 : packedSelected [2,3,5,6,10,15,17] rootPS < 2^1333 := by decide +kernel

def env49085 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,5124,3772,13375,15901,2185,10780,3773,4096,10809,10761,15919,3733,1044,6329,11941,11941,6192,172,14857,173,169,1212,11292]

theorem envBound49085 : H12AffineFastState.Bounded env49085 := by
  intro p hp
  have h : env49085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49084_49085 : H12AffineEnvironment.transform 14 3772 env49084 = env49085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 3772 env49084 == env49085) = true)

theorem identity49085 : scanCanonicalize (H12AffineFastState.compose env49085 (packedSelected [3,5,6,7,9,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound49085 : packedSelected [3,5,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env49086 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,1052,5124,3772,4131,6657,2185,3584,3773,4096,3621,3605,6707,3733,1044,6329,2745,2745,6192,172,7701,173,169,1212,2048]

theorem envBound49086 : H12AffineFastState.Bounded env49086 := by
  intro p hp
  have h : env49086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49085_49086 : H12AffineEnvironment.transform 12 1052 env49085 = env49086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env49085 == env49086) = true)

theorem identity49086 : scanCanonicalize (H12AffineFastState.compose env49086 (packedSelected [2,3,7,8,9,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 1190) := by decide +kernel

theorem selectedBound49086 : packedSelected [2,3,7,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env49087 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,1190,1052,162,3772,1157,3751,2185,3584,3773,1190,3621,3605,3733,3733,1044,3103,2745,2745,3222,172,2739,173,169,1212,2048]

theorem envBound49087 : H12AffineFastState.Bounded env49087 := by
  intro p hp
  have h : env49087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49086_49087 : H12AffineEnvironment.transform 11 1190 env49086 = env49087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1190 env49086 == env49087) = true)

theorem identity49087 : scanCanonicalize (H12AffineFastState.compose env49087 (packedSelected [0,5,6,8,9,10,13] rootPS)) = affineNative (2^(10+1) ^^^ 1070) := by decide +kernel

theorem selectedBound49087 : packedSelected [0,5,6,8,9,10,13] rootPS < 2^1333 := by decide +kernel

def env49088 : List Nat := [2,4,8,16,32,16,128,172,512,1024,1070,1190,1052,162,658,1157,649,1191,558,659,1190,523,571,699,699,1044,49,1687,1687,184,172,1693,173,169,1212,1070]

theorem envBound49088 : H12AffineFastState.Bounded env49088 := by
  intro p hp
  have h : env49088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49087_49088 : H12AffineEnvironment.transform 10 1070 env49087 = env49088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1070 env49087 == env49088) = true)

theorem identity49088 : scanCanonicalize (H12AffineFastState.compose env49088 (packedSelected [4,5,8,9] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound49088 : packedSelected [4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env49089 : List Nat := [2,4,8,11,32,11,128,172,512,1024,1070,1190,1031,162,649,1157,649,1191,558,648,1190,523,544,672,672,1039,42,1676,1676,163,172,1670,173,169,1191,1070]

theorem envBound49089 : H12AffineFastState.Bounded env49089 := by
  intro p hp
  have h : env49089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49088_49089 : H12AffineEnvironment.transform 3 11 env49088 = env49089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env49088 == env49089) = true)

theorem identity49089 : scanCanonicalize (H12AffineFastState.compose env49089 (packedSelected [3,4,5,6,7] rootPS)) = affineNative (2^(8+1) ^^^ 163) := by decide +kernel

theorem selectedBound49089 : packedSelected [3,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env49090 : List Nat := [2,4,8,11,32,11,128,172,163,1024,1070,1190,1031,162,42,1157,42,1191,141,43,1190,168,131,3,3,1039,42,1071,1071,163,172,1061,173,169,1191,1070]

theorem envBound49090 : H12AffineFastState.Bounded env49090 := by
  intro p hp
  have h : env49090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49089_49090 : H12AffineEnvironment.transform 8 163 env49089 = env49090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 163 env49089 == env49090) = true)

theorem identity49090 : scanCanonicalize (H12AffineFastState.compose env49090 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 141) := by decide +kernel

theorem selectedBound49090 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env49091 : List Nat := [2,4,8,11,32,11,128,172,163,141,163,43,138,162,42,8,42,42,141,43,43,168,131,3,3,130,42,162,162,163,172,168,173,169,42,163]

theorem envBound49091 : H12AffineFastState.Bounded env49091 := by
  intro p hp
  have h : env49091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49090_49091 : H12AffineEnvironment.transform 9 141 env49090 = env49091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 141 env49090 == env49091) = true)

theorem identity49091 : scanCanonicalize (H12AffineFastState.compose env49091 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound49091 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env49092 : List Nat := [2,4,8,11,32,11,9,37,42,4,42,43,3,43,42,8,42,42,4,43,43,33,10,3,3,11,42,43,43,42,37,33,36,32,42,42]

theorem envBound49092 : H12AffineFastState.Bounded env49092 := by
  intro p hp
  have h : env49092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49091_49092 : H12AffineEnvironment.transform 6 9 env49091 = env49092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env49091 == env49092) = true)

theorem identity49092 : scanCanonicalize (H12AffineFastState.compose env49092 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound49092 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49093 : List Nat := [2,4,4,7,32,7,5,37,38,4,38,39,3,39,38,4,38,38,4,39,39,33,6,3,3,7,38,39,39,38,37,33,36,32,38,38]

theorem envBound49093 : H12AffineFastState.Bounded env49093 := by
  intro p hp
  have h : env49093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49092_49093 : H12AffineEnvironment.transform 2 4 env49092 = env49093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env49092 == env49093) = true)

def env49094 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61568,147473,58519,143496,20496,508075,148669,148669,96266,90263,222254,173,90258,1213,135681]

theorem envBound49094 : H12AffineFastState.Bounded env49094 := by
  intro p hp
  have h : env49094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49079_49094 : H12AffineEnvironment.transform 5 17 env49079 = env49094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env49079 == env49094) = true)

theorem identity49094 : scanCanonicalize (H12AffineFastState.compose env49094 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 137353) := by decide +kernel

theorem selectedBound49094 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env49095 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,137353,136193,32769,4096,61568,147473,58519,143496,20496,120866,148669,148669,96266,90263,222254,173,90258,1213,135681]

theorem envBound49095 : H12AffineFastState.Bounded env49095 := by
  intro p hp
  have h : env49095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49094_49095 : H12AffineEnvironment.transform 17 137353 env49094 = env49095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137353 env49094 == env49095) = true)

theorem identity49095 : scanCanonicalize (H12AffineFastState.compose env49095 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(16+1) ^^^ 62493) := by decide +kernel

theorem selectedBound49095 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env49096 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,62493,60564,57372,32769,4096,61568,46092,58519,50325,20496,120866,45216,45216,96266,90263,102451,173,90258,1213,58908]

theorem envBound49096 : H12AffineFastState.Bounded env49096 := by
  intro p hp
  have h : env49096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49095_49096 : H12AffineEnvironment.transform 16 62493 env49095 = env49096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 62493 env49095 == env49096) = true)

theorem identity49096 : scanCanonicalize (H12AffineFastState.compose env49096 (packedSelected [4,9,16] rootPS)) = affineNative (2^(14+1) ^^^ 29861) := by decide +kernel

theorem selectedBound49096 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env49097 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,29861,65536,184,6193,5305,29860,4096,1061,16553,4146,12336,20496,76935,17413,17413,96266,90263,91286,173,90258,1213,4793]

theorem envBound49097 : H12AffineFastState.Bounded env49097 := by
  intro p hp
  have h : env49097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49096_49097 : H12AffineEnvironment.transform 14 29861 env49096 = env49097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29861 env49096 == env49097) = true)

theorem identity49097 : scanCanonicalize (H12AffineFastState.compose env49097 (packedSelected [0,2,3,5,6,7,10,13,20] rootPS)) = affineNative (2^(13+1) ^^^ 10897) := by decide +kernel

theorem selectedBound49097 : packedSelected [0,2,3,5,6,7,10,13,20] rootPS < 2^1333 := by decide +kernel

def env49098 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,10897,7732,65536,184,6193,5305,7733,4096,1061,10808,4146,12336,14977,76935,11924,11924,70299,68102,69127,173,68099,1213,4793]

theorem envBound49098 : H12AffineFastState.Bounded env49098 := by
  intro p hp
  have h : env49098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49097_49098 : H12AffineEnvironment.transform 13 10897 env49097 = env49098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 10897 env49097 == env49098) = true)

theorem identity49098 : scanCanonicalize (H12AffineFastState.compose env49098 (packedSelected [17,18,19,21,23,26] rootPS)) = affineNative (2^(15+1) ^^^ 9350) := by decide +kernel

theorem selectedBound49098 : packedSelected [17,18,19,21,23,26] rootPS < 2^1333 := by decide +kernel

def env49099 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,10897,7732,9350,184,6193,5305,7733,4096,1061,10808,4146,12336,14977,2049,11924,11924,13853,11904,10881,173,11909,1213,4793]

theorem envBound49099 : H12AffineFastState.Bounded env49099 := by
  intro p hp
  have h : env49099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49098_49099 : H12AffineEnvironment.transform 15 9350 env49098 = env49099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9350 env49098 == env49099) = true)

theorem identity49099 : scanCanonicalize (H12AffineFastState.compose env49099 (packedSelected [1,2,4,6,7,8,10,11,17] rootPS)) = affineNative (2^(12+1) ^^^ 3237) := by decide +kernel

theorem selectedBound49099 : packedSelected [1,2,4,6,7,8,10,11,17] rootPS < 2^1333 := by decide +kernel

def env49100 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,3237,1588,7732,2083,184,6193,5305,7733,4096,1061,1693,4146,7317,5668,2049,561,561,6840,549,1572,173,544,1213,4793]

theorem envBound49100 : H12AffineFastState.Bounded env49100 := by
  intro p hp
  have h : env49100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49099_49100 : H12AffineEnvironment.transform 12 3237 env49099 = env49100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3237 env49099 == env49100) = true)

theorem identity49100 : scanCanonicalize (H12AffineFastState.compose env49100 (packedSelected [2,4,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2075) := by decide +kernel

theorem selectedBound49100 : packedSelected [2,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env49101 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,2075,3237,1588,1583,2083,184,42,3234,1582,2075,1061,1693,2089,1166,3647,2049,561,561,675,549,1572,173,544,1213,2722]

theorem envBound49101 : H12AffineFastState.Bounded env49101 := by
  intro p hp
  have h : env49101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49100_49101 : H12AffineEnvironment.transform 11 2075 env49100 = env49101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2075 env49100 == env49101) = true)

theorem identity49101 : scanCanonicalize (H12AffineFastState.compose env49101 (packedSelected [0,1,2,5,6,7,10] rootPS)) = affineNative (2^(9+1) ^^^ 31) := by decide +kernel

theorem selectedBound49101 : packedSelected [0,1,2,5,6,7,10] rootPS < 2^1333 := by decide +kernel

def env49102 : List Nat := [2,4,8,16,32,17,128,172,512,31,2048,2075,2234,555,560,2083,184,42,2237,561,2075,58,642,2089,145,2592,2049,561,561,675,549,571,173,544,162,2722]

theorem envBound49102 : H12AffineFastState.Bounded env49102 := by
  intro p hp
  have h : env49102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49101_49102 : H12AffineEnvironment.transform 9 31 env49101 = env49102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 31 env49101 == env49102) = true)

theorem identity49102 : scanCanonicalize (H12AffineFastState.compose env49102 (packedSelected [2,3,5,13] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound49102 : packedSelected [2,3,5,13] rootPS < 2^1333 := by decide +kernel

def env49103 : List Nat := [2,4,8,16,32,17,128,172,136,31,2048,2075,2234,163,184,2083,184,42,2237,185,2075,58,10,2089,145,2216,2049,185,185,43,173,179,173,168,162,2090]

theorem envBound49103 : H12AffineFastState.Bounded env49103 := by
  intro p hp
  have h : env49103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49102_49103 : H12AffineEnvironment.transform 8 136 env49102 = env49103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env49102 == env49103) = true)

theorem identity49103 : scanCanonicalize (H12AffineFastState.compose env49103 (packedSelected [1,2,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 146) := by decide +kernel

theorem selectedBound49103 : packedSelected [1,2,5,6] rootPS < 2^1333 := by decide +kernel

def env49104 : List Nat := [2,4,8,16,32,17,128,172,136,31,146,137,40,163,184,177,184,42,47,185,137,58,10,187,145,58,147,185,185,43,173,179,173,168,162,184]

theorem envBound49104 : H12AffineFastState.Bounded env49104 := by
  intro p hp
  have h : env49104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49103_49104 : H12AffineEnvironment.transform 10 146 env49103 = env49104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 146 env49103 == env49104) = true)

theorem identity49104 : scanCanonicalize (H12AffineFastState.compose env49104 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound49104 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env49105 : List Nat := [2,4,8,16,16,17,128,156,136,31,146,137,24,147,136,129,136,26,31,137,137,10,10,139,145,10,147,137,137,27,157,131,157,152,146,136]

theorem envBound49105 : H12AffineFastState.Bounded env49105 := by
  intro p hp
  have h : env49105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49104_49105 : H12AffineEnvironment.transform 4 16 env49104 = env49105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env49104 == env49105) = true)

theorem identity49105 : scanCanonicalize (H12AffineFastState.compose env49105 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound49105 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49106 : List Nat := [2,4,8,6,6,7,128,138,136,9,132,137,14,133,136,129,136,12,9,137,137,10,10,139,135,10,133,137,137,13,139,131,139,142,132,136]

theorem envBound49106 : H12AffineFastState.Bounded env49106 := by
  intro p hp
  have h : env49106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49105_49106 : H12AffineEnvironment.transform 3 6 env49105 = env49106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env49105 == env49106) = true)

theorem identity49106 : scanCanonicalize (H12AffineFastState.compose env49106 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound49106 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env49107 : List Nat := [2,4,8,6,6,7,5,15,13,9,1,12,14,0,13,4,13,12,9,12,12,10,10,14,2,10,0,12,12,13,14,6,14,11,1,13]

theorem envBound49107 : H12AffineFastState.Bounded env49107 := by
  intro p hp
  have h : env49107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49106_49107 : H12AffineEnvironment.transform 6 5 env49106 = env49107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env49106 == env49107) = true)

theorem identity49107 : scanCanonicalize (H12AffineFastState.compose env49107 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound49107 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49108 : List Nat := [2,4,5,6,6,7,5,2,0,4,1,1,3,0,0,4,0,1,4,1,1,7,7,3,2,7,0,1,1,0,3,6,3,6,1,0]

theorem envBound49108 : H12AffineFastState.Bounded env49108 := by
  intro p hp
  have h : env49108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49107_49108 : H12AffineEnvironment.transform 2 5 env49107 = env49108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env49107 == env49108) = true)

def env49109 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147520,58518,143496,20496,508154,148717,148717,96347,90262,222335,172,90259,1261,135681]

theorem envBound49109 : H12AffineFastState.Bounded env49109 := by
  intro p hp
  have h : env49109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49078_49109 : H12AffineEnvironment.transform 7 173 env49078 = env49109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env49078 == env49109) = true)

def env49110 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61569,147472,58518,143496,20496,508074,148669,148669,96267,90262,222255,172,90259,1213,135681]

theorem envBound49110 : H12AffineFastState.Bounded env49110 := by
  intro p hp
  have h : env49110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49109_49110 : H12AffineEnvironment.transform 5 16 env49109 = env49110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env49109 == env49110) = true)

theorem identity49110 : scanCanonicalize (H12AffineFastState.compose env49110 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 99486) := by decide +kernel

theorem selectedBound49110 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env49111 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,99486,262144,102559,32769,4096,61569,115854,58518,111638,20496,279604,114723,114723,96267,90262,57521,172,90259,1213,104095]

theorem envBound49111 : H12AffineFastState.Bounded env49111 := by
  intro p hp
  have h : env49111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49110_49111 : H12AffineEnvironment.transform 16 99486 env49110 = env49111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 99486 env49110 == env49111) = true)

theorem identity49111 : scanCanonicalize (H12AffineFastState.compose env49111 (packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS)) = affineNative (2^(14+1) ^^^ 12313) := by decide +kernel

theorem selectedBound49111 : packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS < 2^1333 := by decide +kernel

def env49112 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,12313,65536,78983,262144,73862,12312,4096,16536,95383,21647,66575,20496,279604,94266,94266,96267,90262,20648,172,90259,1213,75398]

theorem envBound49112 : H12AffineFastState.Bounded env49112 := by
  intro p hp
  have h : env49112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49111_49112 : H12AffineEnvironment.transform 14 12313 env49111 = env49112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12313 env49111 == env49112) = true)

theorem identity49112 : scanCanonicalize (H12AffineFastState.compose env49112 (packedSelected [3,7,10,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 9350) := by decide +kernel

theorem selectedBound49112 : packedSelected [3,7,10,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env49113 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,12313,9350,4097,262144,1024,12312,4096,16536,20497,21647,8329,20496,279604,21692,21692,23693,17424,20648,172,17429,1213,512]

theorem envBound49113 : H12AffineFastState.Bounded env49113 := by
  intro p hp
  have h : env49113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49112_49113 : H12AffineEnvironment.transform 15 9350 env49112 = env49113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9350 env49112 == env49113) = true)

theorem identity49113 : scanCanonicalize (H12AffineFastState.compose env49113 (packedSelected [4,9,16] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound49113 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env49114 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1212,12313,9350,4097,262144,1024,12312,4096,1060,5293,4147,8329,5292,262280,4096,4096,6193,172,5140,172,169,1213,512]

theorem envBound49114 : H12AffineFastState.Bounded env49114 := by
  intro p hp
  have h : env49114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49113_49114 : H12AffineEnvironment.transform 13 1212 env49113 = env49114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env49113 == env49114) = true)

theorem identity49114 : scanCanonicalize (H12AffineFastState.compose env49114 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 656) := by decide +kernel

theorem selectedBound49114 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env49115 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,656,1212,4745,1558,4097,262144,1024,4744,4096,1060,5293,4147,537,5292,262280,4096,4096,6193,172,5140,172,169,1213,512]

theorem envBound49115 : H12AffineFastState.Bounded env49115 := by
  intro p hp
  have h : env49115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49114_49115 : H12AffineEnvironment.transform 12 656 env49114 = env49115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 656 env49114 == env49115) = true)

theorem identity49115 : scanCanonicalize (H12AffineFastState.compose env49115 (packedSelected [1,3,13] rootPS)) = affineNative (2^(17+1) ^^^ 7221) := by decide +kernel

theorem selectedBound49115 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env49116 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,656,1212,4745,1558,4097,7221,1024,4744,4096,1060,5293,4147,537,5292,7357,4096,4096,6193,172,5140,172,169,1213,512]

theorem envBound49116 : H12AffineFastState.Bounded env49116 := by
  intro p hp
  have h : env49116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49115_49116 : H12AffineEnvironment.transform 17 7221 env49115 = env49116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7221 env49115 == env49116) = true)

theorem identity49116 : scanCanonicalize (H12AffineFastState.compose env49116 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 674) := by decide +kernel

theorem selectedBound49116 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env49117 : List Nat := [2,4,8,16,32,16,128,173,512,1024,674,4096,656,1212,4745,1558,4097,5783,1024,4744,4096,1060,5293,4147,537,5292,5663,4096,4096,4755,172,5140,172,169,1213,512]

theorem envBound49117 : H12AffineFastState.Bounded env49117 := by
  intro p hp
  have h : env49117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49116_49117 : H12AffineEnvironment.transform 10 674 env49116 = env49117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 674 env49116 == env49117) = true)

def env49118 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61568,147473,58518,143496,20496,508075,148668,148668,96266,90262,222254,172,90259,1212,135681]

theorem envBound49118 : H12AffineFastState.Bounded env49118 := by
  intro p hp
  have h : env49118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49109_49118 : H12AffineEnvironment.transform 5 17 env49109 = env49118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env49109 == env49118) = true)

theorem identity49118 : scanCanonicalize (H12AffineFastState.compose env49118 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 208055) := by decide +kernel

theorem selectedBound49118 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env49119 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,208055,136193,32769,4096,61568,147473,58518,143496,20496,60444,148668,148668,96266,90262,222254,172,90259,1212,135681]

theorem envBound49119 : H12AffineFastState.Bounded env49119 := by
  intro p hp
  have h : env49119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49118_49119 : H12AffineEnvironment.transform 17 208055 env49118 = env49119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 208055 env49118 == env49119) = true)

theorem identity49119 : scanCanonicalize (H12AffineFastState.compose env49119 (packedSelected [1,3,5,7,8,10,20,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53282) := by decide +kernel

theorem selectedBound49119 : packedSelected [1,3,5,7,8,10,20,26,27] rootPS < 2^1333 := by decide +kernel

def env49120 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,53282,131072,195733,136193,32769,4096,61568,147473,58518,143496,20496,60444,148668,148668,43048,45236,177164,172,45233,1212,135681]

theorem envBound49120 : H12AffineFastState.Bounded env49120 := by
  intro p hp
  have h : env49120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49119_49120 : H12AffineEnvironment.transform 15 53282 env49119 = env49120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53282 env49119 == env49120) = true)

theorem identity49120 : scanCanonicalize (H12AffineFastState.compose env49120 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(16+1) ^^^ 21693) := by decide +kernel

theorem selectedBound49120 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env49121 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,53282,21693,43048,16572,32769,4096,61568,5292,58518,25653,20496,60444,4097,4097,43048,45236,57521,172,45233,1212,18108]

theorem envBound49121 : H12AffineFastState.Bounded env49121 := by
  intro p hp
  have h : env49121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49120_49121 : H12AffineEnvironment.transform 16 21693 env49120 = env49121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 21693 env49120 == env49121) = true)

theorem identity49121 : scanCanonicalize (H12AffineFastState.compose env49121 (packedSelected [4,9,20] rootPS)) = affineNative (2^(14+1) ^^^ 29860) := by decide +kernel

theorem selectedBound49121 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env49122 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,29860,9350,21693,23692,16572,29861,4096,1060,5292,4146,25653,20496,6328,4097,4097,23692,17424,5141,172,17429,1212,18108]

theorem envBound49122 : H12AffineFastState.Bounded env49122 := by
  intro p hp
  have h : env49122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49121_49122 : H12AffineEnvironment.transform 14 29860 env49121 = env49122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29860 env49121 == env49122) = true)

theorem identity49122 : scanCanonicalize (H12AffineFastState.compose env49122 (packedSelected [0,2,3,4,5,6,11,16] rootPS)) = affineNative (2^(13+1) ^^^ 8728) := by decide +kernel

theorem selectedBound49122 : packedSelected [0,2,3,4,5,6,11,16] rootPS < 2^1333 := by decide +kernel

def env49123 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,8728,5820,9350,13989,16020,8868,5821,4096,1060,5292,4146,1581,12808,6328,4097,4097,16020,9736,5141,172,9741,1212,9380]

theorem envBound49123 : H12AffineFastState.Bounded env49123 := by
  intro p hp
  have h : env49123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49122_49123 : H12AffineEnvironment.transform 13 8728 env49122 = env49123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8728 env49122 == env49123) = true)

theorem identity49123 : scanCanonicalize (H12AffineFastState.compose env49123 (packedSelected [0,1,2,5,7,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 7822) := by decide +kernel

theorem selectedBound49123 : packedSelected [0,1,2,5,7,15,17] rootPS < 2^1333 := by decide +kernel

def env49124 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,7822,7318,5820,6664,2091,26,7210,5821,4096,1060,5292,4146,1581,3206,6328,4097,4097,26,6278,5141,172,6275,1212,6698]

theorem envBound49124 : H12AffineFastState.Bounded env49124 := by
  intro p hp
  have h : env49124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49123_49124 : H12AffineEnvironment.transform 12 7822 env49123 = env49124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7822 env49123 == env49124) = true)

theorem identity49124 : scanCanonicalize (H12AffineFastState.compose env49124 (packedSelected [1,3,13] rootPS)) = affineNative (2^(11+1) ^^^ 136) := by decide +kernel

theorem selectedBound49124 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env49125 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,136,3590,3102,1588,2688,2091,26,3234,1589,136,1060,1060,186,1581,3206,2096,137,137,26,2062,1181,172,2059,1212,2722]

theorem envBound49125 : H12AffineFastState.Bounded env49125 := by
  intro p hp
  have h : env49125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49124_49125 : H12AffineEnvironment.transform 11 136 env49124 = env49125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 136 env49124 == env49125) = true)

theorem identity49125 : scanCanonicalize (H12AffineFastState.compose env49125 (packedSelected [2,3,4,6,7,8,10,12] rootPS)) = affineNative (2^(10+1) ^^^ 184) := by decide +kernel

theorem selectedBound49125 : packedSelected [2,3,4,6,7,8,10,12] rootPS < 2^1333 := by decide +kernel

def env49126 : List Nat := [2,4,8,16,32,17,128,173,512,1024,184,136,1726,1190,1588,568,147,26,1050,1589,136,1060,1060,186,1581,1086,136,137,137,26,182,1181,172,179,1212,538]

theorem envBound49126 : H12AffineFastState.Bounded env49126 := by
  intro p hp
  have h : env49126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49125_49126 : H12AffineEnvironment.transform 10 184 env49125 = env49126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 184 env49125 == env49126) = true)

theorem identity49126 : scanCanonicalize (H12AffineFastState.compose env49126 (packedSelected [0,1,2,5,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 701) := by decide +kernel

theorem selectedBound49126 : packedSelected [0,1,2,5,9,10] rootPS < 2^1333 := by decide +kernel

def env49127 : List Nat := [2,4,8,16,32,17,128,173,512,701,184,136,3,539,137,568,147,26,679,136,136,665,665,186,144,643,136,137,137,26,182,544,172,179,513,538]

theorem envBound49127 : H12AffineFastState.Bounded env49127 := by
  intro p hp
  have h : env49127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49126_49127 : H12AffineEnvironment.transform 9 701 env49126 = env49127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 701 env49126 == env49127) = true)

theorem identity49127 : scanCanonicalize (H12AffineFastState.compose env49127 (packedSelected [3,5,6] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound49127 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env49128 : List Nat := [2,4,8,16,32,17,128,173,26,167,184,136,3,1,137,34,147,26,189,136,136,131,131,186,144,153,136,137,137,26,182,58,172,179,27,0]

theorem envBound49128 : H12AffineFastState.Bounded env49128 := by
  intro p hp
  have h : env49128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49127_49128 : H12AffineEnvironment.transform 8 26 env49127 = env49128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env49127 == env49128) = true)

theorem identity49128 : scanCanonicalize (H12AffineFastState.compose env49128 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound49128 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49129 : List Nat := [2,4,8,16,32,17,57,20,26,30,1,49,3,1,48,34,42,26,4,49,49,58,58,3,41,32,49,48,48,26,15,58,21,10,27,0]

theorem envBound49129 : H12AffineFastState.Bounded env49129 := by
  intro p hp
  have h : env49129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49128_49129 : H12AffineEnvironment.transform 6 57 env49128 = env49129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env49128 == env49129) = true)

theorem identity49129 : scanCanonicalize (H12AffineFastState.compose env49129 (packedSelected [4,7] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound49129 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env49130 : List Nat := [2,4,8,16,11,17,18,20,26,30,1,26,3,1,27,9,1,26,4,26,26,17,17,3,2,11,26,27,27,26,15,17,21,10,27,0]

theorem envBound49130 : H12AffineFastState.Bounded env49130 := by
  intro p hp
  have h : env49130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49129_49130 : H12AffineEnvironment.transform 4 11 env49129 = env49130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env49129 == env49130) = true)

theorem identity49130 : scanCanonicalize (H12AffineFastState.compose env49130 (packedSelected [0,1,4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound49130 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env49131 : List Nat := [2,3,8,16,11,17,18,19,26,25,1,26,3,1,27,9,1,26,3,26,26,17,17,3,2,11,26,27,27,26,8,17,18,10,27,0]

theorem envBound49131 : H12AffineFastState.Bounded env49131 := by
  intro p hp
  have h : env49131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49130_49131 : H12AffineEnvironment.transform 1 3 env49130 = env49131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env49130 == env49131) = true)

def env49132 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,16777216,33554432,672785,134217728,148800,33584584,96346,50962569,4294967296,34088328,4345352435,151462017,33563273]

theorem envBound49132 : H12AffineFastState.Bounded env49132 := by
  intro p hp
  have h : env49132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47782_49132 : H12AffineEnvironment.transform 20 4097 env47782 = env49132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env47782 == env49132) = true)

theorem identity49132 : scanCanonicalize (H12AffineFastState.compose env49132 (packedSelected [14] rootPS)) = affineNative (2^(31+1) ^^^ 184841335) := by decide +kernel

theorem selectedBound49132 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env49133 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,16777216,33554432,672785,134217728,148800,33584584,96346,50962569,184841335,34088328,134521988,151462017,33563273]

theorem envBound49133 : H12AffineFastState.Bounded env49133 := by
  intro p hp
  have h : env49133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49132_49133 : H12AffineEnvironment.transform 31 184841335 env49132 = env49133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 184841335 env49132 == env49133) = true)

def env49134 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,16777216,533640,672785,134217728,148800,545088,96346,16876545,151802111,256,134521988,151462017,525825]

theorem envBound49134 : H12AffineFastState.Bounded env49134 := by
  intro p hp
  have h : env49134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49133_49134 : H12AffineEnvironment.transform 24 533640 env49133 = env49134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 533640 env49133 == env49134) = true)

def env49135 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,16777216,533640,672785,17245632,148800,545088,96346,16876545,750911,256,17006916,1345,525825]

theorem envBound49135 : H12AffineFastState.Bounded env49135 := by
  intro p hp
  have h : env49135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49134_49135 : H12AffineEnvironment.transform 26 17245632 env49134 = env49135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245632 env49134 == env49135) = true)

theorem identity49135 : scanCanonicalize (H12AffineFastState.compose env49135 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 74862) := by decide +kernel

theorem selectedBound49135 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env49136 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,524288,32769,4097,61648,91182,16777216,533640,614527,17039790,90414,545088,96346,16876545,545105,256,16819498,1345,525825]

theorem envBound49136 : H12AffineFastState.Bounded env49136 := by
  intro p hp
  have h : env49136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49135_49136 : H12AffineEnvironment.transform 16 74862 env49135 = env49136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 74862 env49135 == env49136) = true)

def env49137 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,524288,32769,4097,61648,91182,123164,533640,614527,385202,90414,545088,96346,25885,545105,256,82998,1345,525825]

theorem envBound49137 : H12AffineFastState.Bounded env49137 := by
  intro p hp
  have h : env49137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49136_49137 : H12AffineEnvironment.transform 23 123164 env49136 = env49137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 123164 env49136 == env49137) = true)

def env49138 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,21584,32769,4097,61648,91182,123164,28888,78895,385202,90414,1296,96346,25885,1281,256,82998,1345,21073]

theorem envBound49138 : H12AffineFastState.Bounded env49138 := by
  intro p hp
  have h : env49138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49137_49138 : H12AffineEnvironment.transform 18 21584 env49137 = env49138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21584 env49137 == env49138) = true)

theorem identity49138 : scanCanonicalize (H12AffineFastState.compose env49138 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 25676) := by decide +kernel

theorem selectedBound49138 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env49139 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,25676,65536,74862,262144,21584,25677,4097,5276,91182,66896,28888,78895,328958,90414,1296,96346,25885,1281,256,82998,1345,21073]

theorem envBound49139 : H12AffineFastState.Bounded env49139 := by
  intro p hp
  have h : env49139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49138_49139 : H12AffineEnvironment.transform 14 25676 env49138 = env49139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25676 env49138 == env49139) = true)

def env49140 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74862,262144,4416,8541,4097,5276,74046,66896,13768,78895,328958,74814,1296,81226,8205,1281,256,65830,1345,5953]

theorem envBound49140 : H12AffineFastState.Bounded env49140 := by
  intro p hp
  have h : env49140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49139_49140 : H12AffineEnvironment.transform 13 1296 env49139 = env49140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env49139 == env49140) = true)

def env49141 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74862,65664,4416,8541,4097,5276,74046,66896,13768,78895,1150,74814,1296,81226,8205,1281,256,65830,1345,5953]

theorem envBound49141 : H12AffineFastState.Bounded env49141 := by
  intro p hp
  have h : env49141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49140_49141 : H12AffineEnvironment.transform 17 65664 env49140 = env49141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env49140 == env49141) = true)

theorem identity49141 : scanCanonicalize (H12AffineFastState.compose env49141 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound49141 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env49142 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1296,8540,65536,74862,65664,321,8541,0,1181,74046,66896,9673,74798,1150,74814,1296,77131,8205,1281,256,65830,1345,1856]

theorem envBound49142 : H12AffineFastState.Bounded env49142 := by
  intro p hp
  have h : env49142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49141_49142 : H12AffineEnvironment.transform 11 1 env49141 = env49142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env49141 == env49142) = true)

def env49143 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,1,8192,80,8540,65536,74030,65664,321,8541,0,477,74046,65552,8329,74094,318,74110,80,75787,8205,65,256,65830,1,512]

theorem envBound49143 : H12AffineFastState.Bounded env49143 := by
  intro p hp
  have h : env49143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49142_49143 : H12AffineEnvironment.transform 9 320 env49142 = env49143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env49142 == env49143) = true)

theorem identity49143 : scanCanonicalize (H12AffineFastState.compose env49143 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound49143 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env49144 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,1,348,80,0,65536,65650,65664,321,1,0,477,65634,65552,469,65586,318,65570,80,67927,337,65,256,65830,1,512]

theorem envBound49144 : H12AffineFastState.Bounded env49144 := by
  intro p hp
  have h : env49144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49143_49144 : H12AffineEnvironment.transform 12 348 env49143 = env49144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env49143 == env49144) = true)

theorem identity49144 : scanCanonicalize (H12AffineFastState.compose env49144 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound49144 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env49145 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,1,348,80,0,35,81,163,321,1,0,477,65,51,469,17,318,1,80,2420,337,65,256,261,1,512]

theorem envBound49145 : H12AffineFastState.Bounded env49145 := by
  intro p hp
  have h : env49145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49144_49145 : H12AffineEnvironment.transform 15 35 env49144 = env49145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env49144 == env49145) = true)

theorem identity49145 : scanCanonicalize (H12AffineFastState.compose env49145 (packedSelected [2,10,13] rootPS)) = affineNative (2^(10+1) ^^^ 561) := by decide +kernel

theorem selectedBound49145 : packedSelected [2,10,13] rootPS < 2^1333 := by decide +kernel

def env49146 : List Nat := [2,4,8,16,32,64,128,256,512,320,561,1,348,80,0,35,81,163,321,1,0,477,65,51,469,17,318,1,80,837,337,65,256,261,1,512]

theorem envBound49146 : H12AffineFastState.Bounded env49146 := by
  intro p hp
  have h : env49146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49145_49146 : H12AffineEnvironment.transform 10 561 env49145 = env49146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 561 env49145 == env49146) = true)

theorem identity49146 : scanCanonicalize (H12AffineFastState.compose env49146 (packedSelected [0,1,3,7,11,12,15] rootPS)) = affineNative (2^(8+1) ^^^ 184) := by decide +kernel

theorem selectedBound49146 : packedSelected [0,1,3,7,11,12,15] rootPS < 2^1333 := by decide +kernel

def env49147 : List Nat := [2,4,8,16,32,64,128,256,184,320,137,1,348,80,0,35,81,163,321,1,0,477,65,51,469,17,318,1,80,509,337,65,256,261,1,184]

theorem envBound49147 : H12AffineFastState.Bounded env49147 := by
  intro p hp
  have h : env49147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49146_49147 : H12AffineEnvironment.transform 8 184 env49146 = env49147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 184 env49146 == env49147) = true)

theorem identity49147 : scanCanonicalize (H12AffineFastState.compose env49147 (packedSelected [1,3,4,8,11] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound49147 : packedSelected [1,3,4,8,11] rootPS < 2^1333 := by decide +kernel

def env49148 : List Nat := [2,4,8,16,32,64,18,256,42,320,27,1,348,80,0,35,81,49,321,1,0,335,65,51,327,17,318,1,80,367,337,65,256,261,1,42]

theorem envBound49148 : H12AffineFastState.Bounded env49148 := by
  intro p hp
  have h : env49148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49147_49148 : H12AffineEnvironment.transform 6 18 env49147 = env49148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env49147 == env49148) = true)

theorem identity49148 : scanCanonicalize (H12AffineFastState.compose env49148 (packedSelected [0,1,2,3,4,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound49148 : packedSelected [0,1,2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env49149 : List Nat := [2,4,8,16,32,10,18,256,42,266,27,1,278,26,0,35,27,49,267,1,0,261,11,51,269,17,318,1,26,293,283,11,256,261,1,42]

theorem envBound49149 : H12AffineFastState.Bounded env49149 := by
  intro p hp
  have h : env49149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49148_49149 : H12AffineEnvironment.transform 5 10 env49148 = env49149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env49148 == env49149) = true)

theorem identity49149 : scanCanonicalize (H12AffineFastState.compose env49149 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound49149 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env49150 : List Nat := [2,4,8,16,11,10,18,256,1,266,27,1,278,26,0,8,27,26,267,1,0,261,11,24,269,17,277,1,26,270,283,11,256,261,1,1]

theorem envBound49150 : H12AffineFastState.Bounded env49150 := by
  intro p hp
  have h : env49150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49149_49150 : H12AffineEnvironment.transform 4 11 env49149 = env49150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env49149 == env49150) = true)

theorem identity49150 : scanCanonicalize (H12AffineFastState.compose env49150 (packedSelected [0,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound49150 : packedSelected [0,2,3] rootPS < 2^1333 := by decide +kernel

def env49151 : List Nat := [2,4,8,10,11,10,8,256,1,266,1,1,268,0,0,8,1,0,267,1,0,261,11,2,269,11,271,1,0,270,257,11,256,261,1,1]

theorem envBound49151 : H12AffineFastState.Bounded env49151 := by
  intro p hp
  have h : env49151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49150_49151 : H12AffineEnvironment.transform 3 10 env49150 = env49151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env49150 == env49151) = true)

theorem identity49151 : scanCanonicalize (H12AffineFastState.compose env49151 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound49151 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env49152 : List Nat := [2,4,8,10,11,10,8,15,1,5,1,1,3,0,0,8,1,0,4,1,0,10,11,2,2,11,0,1,0,1,14,11,15,10,1,1]

theorem envBound49152 : H12AffineFastState.Bounded env49152 := by
  intro p hp
  have h : env49152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49151_49152 : H12AffineEnvironment.transform 7 15 env49151 = env49152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env49151 == env49152) = true)

theorem identity49152 : scanCanonicalize (H12AffineFastState.compose env49152 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound49152 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49153 : List Nat := [2,3,8,10,11,10,8,8,1,2,1,1,3,0,0,8,1,0,3,1,0,10,11,2,2,11,0,1,0,1,9,11,8,10,1,1]

theorem envBound49153 : H12AffineFastState.Bounded env49153 := by
  intro p hp
  have h : env49153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49152_49153 : H12AffineEnvironment.transform 1 3 env49152 = env49153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env49152 == env49153) = true)

def env49154 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,1,8192,81,8540,65536,74031,65664,321,8541,0,476,74046,65553,8328,74095,319,74111,81,75786,8205,64,256,65830,0,513]

theorem envBound49154 : H12AffineFastState.Bounded env49154 := by
  intro p hp
  have h : env49154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49142_49154 : H12AffineEnvironment.transform 9 321 env49142 = env49154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env49142 == env49154) = true)

theorem identity49154 : scanCanonicalize (H12AffineFastState.compose env49154 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound49154 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env49155 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,1,8192,81,8540,34,8461,162,321,8541,0,476,8476,51,8328,8525,319,8541,81,10280,8205,64,256,260,0,513]

theorem envBound49155 : H12AffineFastState.Bounded env49155 := by
  intro p hp
  have h : env49155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49154_49155 : H12AffineEnvironment.transform 15 34 env49154 = env49155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env49154 == env49155) = true)

theorem identity49155 : scanCanonicalize (H12AffineFastState.compose env49155 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound49155 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env49156 : List Nat := [2,4,8,16,32,64,128,20,512,85,2048,1,8192,81,8264,34,8217,162,85,8265,0,200,8200,51,8328,8281,43,8265,81,10280,8205,64,20,16,0,513]

theorem envBound49156 : H12AffineFastState.Bounded env49156 := by
  intro p hp
  have h : env49156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49155_49156 : H12AffineEnvironment.transform 7 20 env49155 = env49156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env49155 == env49156) = true)

theorem identity49156 : scanCanonicalize (H12AffineFastState.compose env49156 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound49156 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env49157 : List Nat := [2,4,8,16,32,1,128,20,512,20,2048,1,8192,16,8201,34,8217,162,20,8200,0,137,8200,51,8328,8216,43,8200,16,10280,8205,1,20,16,0,513]

theorem envBound49157 : H12AffineFastState.Bounded env49157 := by
  intro p hp
  have h : env49157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49156_49157 : H12AffineEnvironment.transform 5 1 env49156 = env49157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env49156 == env49157) = true)

theorem identity49157 : scanCanonicalize (H12AffineFastState.compose env49157 (packedSelected [2,11,12,13,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 657) := by decide +kernel

theorem selectedBound49157 : packedSelected [2,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env49158 : List Nat := [2,4,8,16,32,1,128,20,512,20,2048,1,657,16,664,34,648,162,20,665,0,137,665,51,537,649,43,665,16,2745,668,1,20,16,0,513]

theorem envBound49158 : H12AffineFastState.Bounded env49158 := by
  intro p hp
  have h : env49158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49157_49158 : H12AffineEnvironment.transform 12 657 env49157 = env49158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 657 env49157 == env49158) = true)

theorem identity49158 : scanCanonicalize (H12AffineFastState.compose env49158 (packedSelected [1,2,3,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 691) := by decide +kernel

theorem selectedBound49158 : packedSelected [1,2,3,13,15] rootPS < 2^1333 := by decide +kernel

def env49159 : List Nat := [2,4,8,16,32,1,128,20,512,20,691,1,657,16,664,34,648,162,20,665,0,137,665,51,537,649,43,665,16,10,668,1,20,16,0,513]

theorem envBound49159 : H12AffineFastState.Bounded env49159 := by
  intro p hp
  have h : env49159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49158_49159 : H12AffineEnvironment.transform 10 691 env49158 = env49159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 691 env49158 == env49159) = true)

theorem identity49159 : scanCanonicalize (H12AffineFastState.compose env49159 (packedSelected [1,2,4,5,8,9,11] rootPS)) = affineNative (2^(6+1) ^^^ 62) := by decide +kernel

theorem selectedBound49159 : packedSelected [1,2,4,5,8,9,11] rootPS < 2^1333 := by decide +kernel

def env49160 : List Nat := [2,4,8,16,32,1,62,20,512,20,525,1,559,16,550,34,566,28,20,551,0,55,551,51,537,567,43,551,16,10,546,1,20,16,0,513]

theorem envBound49160 : H12AffineFastState.Bounded env49160 := by
  intro p hp
  have h : env49160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49159_49160 : H12AffineEnvironment.transform 6 62 env49159 = env49160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 62 env49159 == env49160) = true)

theorem identity49160 : scanCanonicalize (H12AffineFastState.compose env49160 (packedSelected [1,2,3,5,12] rootPS)) = affineNative (2^(8+1) ^^^ 38) := by decide +kernel

theorem selectedBound49160 : packedSelected [1,2,3,5,12] rootPS < 2^1333 := by decide +kernel

def env49161 : List Nat := [2,4,8,16,32,1,62,20,38,20,43,1,9,16,0,34,16,28,20,1,0,55,1,51,63,17,43,1,16,10,4,1,20,16,0,39]

theorem envBound49161 : H12AffineFastState.Bounded env49161 := by
  intro p hp
  have h : env49161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49160_49161 : H12AffineEnvironment.transform 8 38 env49160 = env49161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 38 env49160 == env49161) = true)

theorem identity49161 : scanCanonicalize (H12AffineFastState.compose env49161 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound49161 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env49162 : List Nat := [2,4,8,16,6,1,24,20,0,20,13,1,9,16,0,4,16,28,20,1,0,17,1,21,25,17,13,1,16,10,4,1,20,16,0,1]

theorem envBound49162 : H12AffineFastState.Bounded env49162 := by
  intro p hp
  have h : env49162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49161_49162 : H12AffineEnvironment.transform 4 6 env49161 = env49162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env49161 == env49162) = true)

theorem identity49162 : scanCanonicalize (H12AffineFastState.compose env49162 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound49162 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49163 : List Nat := [2,4,8,6,6,1,14,2,0,2,13,1,9,6,0,4,6,10,2,1,0,7,1,3,15,7,13,1,6,10,4,1,2,6,0,1]

theorem envBound49163 : H12AffineFastState.Bounded env49163 := by
  intro p hp
  have h : env49163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49162_49163 : H12AffineEnvironment.transform 3 6 env49162 = env49163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env49162 == env49163) = true)

theorem identity49163 : scanCanonicalize (H12AffineFastState.compose env49163 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound49163 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49164 : List Nat := [2,4,2,6,6,1,4,2,0,2,7,1,3,6,0,4,6,0,2,1,0,7,1,3,5,7,7,1,6,0,4,1,2,6,0,1]

theorem envBound49164 : H12AffineFastState.Bounded env49164 := by
  intro p hp
  have h : env49164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49163_49164 : H12AffineEnvironment.transform 2 2 env49163 = env49164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env49163 == env49164) = true)

theorem identity49164 : scanCanonicalize (H12AffineFastState.compose env49164 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound49164 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49165 : List Nat := [1,4,1,5,5,1,4,1,0,1,4,1,0,5,0,4,5,0,1,1,0,4,1,0,5,4,4,1,5,0,4,1,1,5,0,1]

theorem envBound49165 : H12AffineFastState.Bounded env49165 := by
  intro p hp
  have h : env49165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49164_49165 : H12AffineEnvironment.transform 0 1 env49164 = env49165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env49164 == env49165) = true)

theorem identity49165 : scanCanonicalize (H12AffineFastState.compose env49165 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound49165 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env49166 : List Nat := [1,1,1,0,0,1,1,1,0,1,1,1,0,0,0,1,0,0,1,1,0,1,1,0,0,1,1,1,0,0,1,1,1,0,0,1]

theorem envBound49166 : H12AffineFastState.Bounded env49166 := by
  intro p hp
  have h : env49166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49165_49166 : H12AffineEnvironment.transform 1 1 env49165 = env49166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env49165 == env49166) = true)

def env49167 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74862,65665,4416,8541,4097,5276,74046,66896,13768,78895,1151,74814,1296,81226,8205,1281,256,65830,1345,5953]

theorem envBound49167 : H12AffineFastState.Bounded env49167 := by
  intro p hp
  have h : env49167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49140_49167 : H12AffineEnvironment.transform 17 65665 env49140 = env49167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env49140 == env49167) = true)

theorem identity49167 : scanCanonicalize (H12AffineFastState.compose env49167 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound49167 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env49168 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,81,8540,65536,74031,65665,4416,8541,4097,4573,74046,65553,12425,78190,318,74111,81,79883,8205,64,256,65830,0,4608]

theorem envBound49168 : H12AffineFastState.Bounded env49168 := by
  intro p hp
  have h : env49168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49167_49168 : H12AffineEnvironment.transform 9 321 env49167 = env49168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env49167 == env49168) = true)

def env49169 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,852,8192,81,8540,65536,74031,65665,532,8541,853,649,74046,65553,9181,74298,318,74111,81,76639,8205,64,256,65830,0,340]

theorem envBound49169 : H12AffineFastState.Bounded env49169 := by
  intro p hp
  have h : env49169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49168_49169 : H12AffineEnvironment.transform 11 852 env49168 = env49169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 852 env49168 == env49169) = true)

def env49170 : List Nat := [2,4,8,0,32,64,128,256,512,321,2048,836,8192,65,8524,65536,74031,65665,516,8525,837,649,74030,65537,9165,74282,302,74095,65,76623,8205,64,256,65830,0,324]

theorem envBound49170 : H12AffineFastState.Bounded env49170 := by
  intro p hp
  have h : env49170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49169_49170 : H12AffineEnvironment.transform 3 0 env49169 = env49170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env49169 == env49170) = true)

theorem identity49170 : scanCanonicalize (H12AffineFastState.compose env49170 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 8546) := by decide +kernel

theorem selectedBound49170 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env49171 : List Nat := [2,4,8,0,32,64,128,256,512,321,2048,836,8192,65,8524,8546,77,8675,516,8525,837,649,76,8547,9165,840,302,13,65,2605,8205,64,256,8260,0,324]

theorem envBound49171 : H12AffineFastState.Bounded env49171 := by
  intro p hp
  have h : env49171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49170_49171 : H12AffineEnvironment.transform 15 8546 env49170 = env49171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8546 env49170 == env49171) = true)

def env49172 : List Nat := [2,4,8,0,32,64,128,256,328,321,2048,12,8192,65,8524,8546,77,8675,332,8525,13,449,76,8547,8325,0,302,13,65,2405,8205,64,256,8260,0,324]

theorem envBound49172 : H12AffineFastState.Bounded env49172 := by
  intro p hp
  have h : env49172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49171_49172 : H12AffineEnvironment.transform 8 328 env49171 = env49172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 328 env49171 == env49172) = true)

theorem identity49172 : scanCanonicalize (H12AffineFastState.compose env49172 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 320) := by decide +kernel

theorem selectedBound49172 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env49173 : List Nat := [2,4,8,0,32,64,128,256,328,321,2048,12,320,65,12,34,77,163,332,13,13,449,76,35,453,0,302,13,65,2405,333,64,256,260,0,324]

theorem envBound49173 : H12AffineFastState.Bounded env49173 := by
  intro p hp
  have h : env49173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49172_49173 : H12AffineEnvironment.transform 12 320 env49172 = env49173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 320 env49172 == env49173) = true)

theorem identity49173 : scanCanonicalize (H12AffineFastState.compose env49173 (packedSelected [0,1,3,4,5,7,8,9,10,11,12,13,15,18,20,21,23] rootPS)) = affineNative (2^(10+1) ^^^ 493) := by decide +kernel

theorem selectedBound49173 : packedSelected [0,1,3,4,5,7,8,9,10,11,12,13,15,18,20,21,23] rootPS < 2^1333 := by decide +kernel

def env49174 : List Nat := [2,4,8,0,32,64,128,256,328,321,493,12,320,65,12,34,77,163,332,13,13,449,76,35,453,0,302,13,65,136,333,64,256,260,0,324]

theorem envBound49174 : H12AffineFastState.Bounded env49174 := by
  intro p hp
  have h : env49174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49173_49174 : H12AffineEnvironment.transform 10 493 env49173 = env49174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 493 env49173 == env49174) = true)

theorem identity49174 : scanCanonicalize (H12AffineFastState.compose env49174 (packedSelected [1,3,11,17,18] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound49174 : packedSelected [1,3,11,17,18] rootPS < 2^1333 := by decide +kernel

def env49175 : List Nat := [2,4,8,0,32,64,5,256,328,321,360,12,320,65,12,34,77,38,332,13,13,324,76,35,320,0,302,13,65,13,333,64,256,260,0,324]

theorem envBound49175 : H12AffineFastState.Bounded env49175 := by
  intro p hp
  have h : env49175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49174_49175 : H12AffineEnvironment.transform 6 5 env49174 = env49175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env49174 == env49175) = true)

theorem identity49175 : scanCanonicalize (H12AffineFastState.compose env49175 (packedSelected [0,3,5,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 41) := by decide +kernel

theorem selectedBound49175 : packedSelected [0,3,5,8,9] rootPS < 2^1333 := by decide +kernel

def env49176 : List Nat := [2,4,8,0,32,64,5,41,97,104,65,12,105,65,12,34,77,38,101,13,13,109,76,35,105,0,7,13,65,13,100,64,41,45,0,109]

theorem envBound49176 : H12AffineFastState.Bounded env49176 := by
  intro p hp
  have h : env49176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49175_49176 : H12AffineEnvironment.transform 7 41 env49175 = env49176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 41 env49175 == env49176) = true)

def env49177 : List Nat := [2,4,8,0,32,64,128,256,329,321,2048,13,8192,65,8524,8546,77,8675,333,8525,12,448,76,8547,8324,1,302,13,65,2404,8205,64,256,8260,0,324]

theorem envBound49177 : H12AffineFastState.Bounded env49177 := by
  intro p hp
  have h : env49177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49171_49177 : H12AffineEnvironment.transform 8 329 env49171 = env49177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 329 env49171 == env49177) = true)

theorem identity49177 : scanCanonicalize (H12AffineFastState.compose env49177 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 332) := by decide +kernel

theorem selectedBound49177 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env49178 : List Nat := [2,4,8,0,32,64,128,256,329,321,2048,13,332,65,0,46,77,175,333,1,12,448,76,47,456,1,302,13,65,2404,321,64,256,264,0,324]

theorem envBound49178 : H12AffineFastState.Bounded env49178 := by
  intro p hp
  have h : env49178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49177_49178 : H12AffineEnvironment.transform 12 332 env49177 = env49178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 332 env49177 == env49178) = true)

theorem identity49178 : scanCanonicalize (H12AffineFastState.compose env49178 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound49178 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env49179 : List Nat := [2,4,5,0,32,64,128,256,324,321,2048,0,321,65,0,35,64,162,320,1,1,448,65,34,453,1,291,0,65,2404,321,64,256,261,0,324]

theorem envBound49179 : H12AffineFastState.Bounded env49179 := by
  intro p hp
  have h : env49179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49178_49179 : H12AffineEnvironment.transform 2 5 env49178 = env49179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env49178 == env49179) = true)

theorem identity49179 : scanCanonicalize (H12AffineFastState.compose env49179 (packedSelected [3] rootPS)) = affineNative (2^(7+1) ^^^ 193) := by decide +kernel

theorem selectedBound49179 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env49180 : List Nat := [2,4,5,0,32,64,128,193,133,128,2048,0,128,65,0,35,64,162,129,1,1,1,65,34,4,1,226,0,65,2213,128,64,193,196,0,133]

theorem envBound49180 : H12AffineFastState.Bounded env49180 := by
  intro p hp
  have h : env49180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49179_49180 : H12AffineEnvironment.transform 7 193 env49179 = env49180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 193 env49179 == env49180) = true)

theorem identity49180 : scanCanonicalize (H12AffineFastState.compose env49180 (packedSelected [1,2,5] rootPS)) = affineNative (2^(5+1) ^^^ 39) := by decide +kernel

theorem selectedBound49180 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env49181 : List Nat := [2,4,5,0,32,39,128,166,133,128,2048,0,128,38,0,35,39,162,129,1,1,1,38,34,4,1,133,0,38,2213,128,39,166,163,0,133]

theorem envBound49181 : H12AffineFastState.Bounded env49181 := by
  intro p hp
  have h : env49181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49180_49181 : H12AffineEnvironment.transform 5 39 env49180 = env49181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 39 env49180 == env49181) = true)

theorem identity49181 : scanCanonicalize (H12AffineFastState.compose env49181 (packedSelected [7] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound49181 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env49182 : List Nat := [2,4,5,0,32,39,5,35,0,5,2048,0,5,38,0,35,39,39,4,1,1,1,38,34,4,1,0,0,38,2080,5,39,35,38,0,0]

theorem envBound49182 : H12AffineFastState.Bounded env49182 := by
  intro p hp
  have h : env49182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49181_49182 : H12AffineEnvironment.transform 6 5 env49181 = env49182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env49181 == env49182) = true)

theorem identity49182 : scanCanonicalize (H12AffineFastState.compose env49182 (packedSelected [1,4] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound49182 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env49183 : List Nat := [2,4,5,0,32,39,5,35,0,5,33,0,5,38,0,35,39,39,4,1,1,1,38,34,4,1,0,0,38,1,5,39,35,38,0,0]

theorem envBound49183 : H12AffineFastState.Bounded env49183 := by
  intro p hp
  have h : env49183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49182_49183 : H12AffineEnvironment.transform 10 33 env49182 = env49183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env49182 == env49183) = true)

theorem identity49183 : scanCanonicalize (H12AffineFastState.compose env49183 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound49183 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49184 : List Nat := [2,4,5,0,0,7,5,3,0,5,1,0,5,6,0,3,7,7,4,1,1,1,6,2,4,1,0,0,6,1,5,7,3,6,0,0]

theorem envBound49184 : H12AffineFastState.Bounded env49184 := by
  intro p hp
  have h : env49184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49183_49184 : H12AffineEnvironment.transform 4 0 env49183 = env49184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env49183 == env49184) = true)

def env49185 : List Nat := [2,4,8,1,32,64,128,256,512,321,2048,837,8192,64,8525,65536,74031,65665,517,8524,836,649,74031,65536,9164,74283,303,74094,64,76622,8205,64,256,65830,0,325]

theorem envBound49185 : H12AffineFastState.Bounded env49185 := by
  intro p hp
  have h : env49185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49169_49185 : H12AffineEnvironment.transform 3 1 env49169 = env49185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env49169 == env49185) = true)

theorem identity49185 : scanCanonicalize (H12AffineFastState.compose env49185 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 298) := by decide +kernel

theorem selectedBound49185 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env49186 : List Nat := [2,4,8,1,32,64,128,256,512,321,2048,837,8192,64,8525,298,8197,427,517,8524,836,649,8197,298,9164,8961,303,8260,64,10852,8205,64,256,12,0,325]

theorem envBound49186 : H12AffineFastState.Bounded env49186 := by
  intro p hp
  have h : env49186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49185_49186 : H12AffineEnvironment.transform 15 298 env49185 = env49186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 298 env49185 == env49186) = true)

def env49187 : List Nat := [2,4,8,1,32,64,128,256,328,321,2048,13,8192,64,8525,298,8197,427,333,8524,12,449,8197,298,8324,8265,303,8260,64,10540,8205,64,256,12,0,325]

theorem envBound49187 : H12AffineFastState.Bounded env49187 := by
  intro p hp
  have h : env49187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49186_49187 : H12AffineEnvironment.transform 8 328 env49186 = env49187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 328 env49186 == env49187) = true)

theorem identity49187 : scanCanonicalize (H12AffineFastState.compose env49187 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound49187 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env49188 : List Nat := [2,4,5,1,32,64,128,256,325,321,2048,0,8192,64,8512,295,8197,422,320,8513,1,449,8197,295,8324,8260,290,8260,64,10529,8192,64,256,1,0,325]

theorem envBound49188 : H12AffineFastState.Bounded env49188 := by
  intro p hp
  have h : env49188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49187_49188 : H12AffineEnvironment.transform 2 5 env49187 = env49188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env49187 == env49188) = true)

theorem identity49188 : scanCanonicalize (H12AffineFastState.compose env49188 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 320) := by decide +kernel

theorem selectedBound49188 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env49189 : List Nat := [2,4,5,1,32,64,128,256,325,321,2048,0,320,64,0,295,325,422,320,1,1,449,325,295,452,260,290,260,64,2145,320,64,256,1,0,325]

theorem envBound49189 : H12AffineFastState.Bounded env49189 := by
  intro p hp
  have h : env49189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49188_49189 : H12AffineEnvironment.transform 12 320 env49188 = env49189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 320 env49188 == env49189) = true)

theorem identity49189 : scanCanonicalize (H12AffineFastState.compose env49189 (packedSelected [1,2,10,12,17] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound49189 : packedSelected [1,2,10,12,17] rootPS < 2^1333 := by decide +kernel

def env49190 : List Nat := [2,4,5,1,32,33,128,256,292,288,2048,0,289,33,0,295,292,422,289,1,1,416,292,295,421,260,290,260,33,2048,289,33,256,1,0,292]

theorem envBound49190 : H12AffineFastState.Bounded env49190 := by
  intro p hp
  have h : env49190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49189_49190 : H12AffineEnvironment.transform 5 33 env49189 = env49190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env49189 == env49190) = true)

theorem identity49190 : scanCanonicalize (H12AffineFastState.compose env49190 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound49190 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49191 : List Nat := [2,4,5,1,32,33,128,256,292,288,32,0,289,33,0,295,292,422,289,1,1,416,292,295,421,260,290,260,33,32,289,33,256,1,0,292]

theorem envBound49191 : H12AffineFastState.Bounded env49191 := by
  intro p hp
  have h : env49191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49190_49191 : H12AffineEnvironment.transform 10 32 env49190 = env49191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env49190 == env49191) = true)

theorem identity49191 : scanCanonicalize (H12AffineFastState.compose env49191 (packedSelected [5,8] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound49191 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env49192 : List Nat := [2,4,5,1,0,1,128,256,260,256,0,0,257,1,0,263,260,390,257,1,1,384,260,263,389,260,258,260,1,0,257,1,256,1,0,260]

theorem envBound49192 : H12AffineFastState.Bounded env49192 := by
  intro p hp
  have h : env49192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49191_49192 : H12AffineEnvironment.transform 4 0 env49191 = env49192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env49191 == env49192) = true)

theorem identity49192 : scanCanonicalize (H12AffineFastState.compose env49192 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 134) := by decide +kernel

theorem selectedBound49192 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49193 : List Nat := [2,4,5,1,0,1,128,134,130,134,0,0,135,1,0,129,130,0,135,1,1,6,130,129,3,130,132,130,1,0,135,1,134,1,0,130]

theorem envBound49193 : H12AffineFastState.Bounded env49193 := by
  intro p hp
  have h : env49193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49192_49193 : H12AffineEnvironment.transform 7 134 env49192 = env49193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 134 env49192 == env49193) = true)

theorem identity49193 : scanCanonicalize (H12AffineFastState.compose env49193 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound49193 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49194 : List Nat := [2,4,5,1,0,1,3,5,1,5,0,0,4,1,0,2,1,0,4,1,1,6,1,2,3,1,7,1,1,0,4,1,5,1,0,1]

theorem envBound49194 : H12AffineFastState.Bounded env49194 := by
  intro p hp
  have h : env49194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49193_49194 : H12AffineEnvironment.transform 6 3 env49193 = env49194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env49193 == env49194) = true)

theorem identity49194 : scanCanonicalize (H12AffineFastState.compose env49194 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound49194 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env49195 : List Nat := [2,2,3,1,0,1,3,3,1,3,0,0,2,1,0,2,1,0,2,1,1,0,1,2,3,1,1,1,1,0,2,1,3,1,0,1]

theorem envBound49195 : H12AffineFastState.Bounded env49195 := by
  intro p hp
  have h : env49195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49194_49195 : H12AffineEnvironment.transform 1 2 env49194 = env49195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env49194 == env49195) = true)

def env49196 : List Nat := [2,4,8,1,32,64,128,256,329,321,2048,12,8192,64,8525,298,8197,427,332,8524,13,448,8197,298,8325,8264,303,8260,64,10541,8205,64,256,12,0,325]

theorem envBound49196 : H12AffineFastState.Bounded env49196 := by
  intro p hp
  have h : env49196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49186_49196 : H12AffineEnvironment.transform 8 329 env49186 = env49196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 329 env49186 == env49196) = true)

theorem identity49196 : scanCanonicalize (H12AffineFastState.compose env49196 (packedSelected [1,5,7,8,16,18,23,24,27] rootPS)) = affineNative (2^(12+1) ^^^ 333) := by decide +kernel

theorem selectedBound49196 : packedSelected [1,5,7,8,16,18,23,24,27] rootPS < 2^1333 := by decide +kernel

def env49197 : List Nat := [2,4,8,1,32,64,128,256,329,321,2048,12,333,64,0,298,328,427,332,1,13,448,328,298,456,261,303,265,64,2144,320,64,256,12,0,325]

theorem envBound49197 : H12AffineFastState.Bounded env49197 := by
  intro p hp
  have h : env49197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49196_49197 : H12AffineEnvironment.transform 12 333 env49196 = env49197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 333 env49196 == env49197) = true)

theorem identity49197 : scanCanonicalize (H12AffineFastState.compose env49197 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 9) := by decide +kernel

theorem selectedBound49197 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env49198 : List Nat := [2,4,8,1,32,64,128,9,64,72,2048,12,68,64,0,35,65,162,69,1,13,201,65,35,193,12,38,0,64,2144,73,64,9,12,0,76]

theorem envBound49198 : H12AffineFastState.Bounded env49198 := by
  intro p hp
  have h : env49198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49197_49198 : H12AffineEnvironment.transform 7 9 env49197 = env49198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 9 env49197 == env49198) = true)

theorem identity49198 : scanCanonicalize (H12AffineFastState.compose env49198 (packedSelected [1,3,10] rootPS)) = affineNative (2^(10+1) ^^^ 142) := by decide +kernel

theorem selectedBound49198 : packedSelected [1,3,10] rootPS < 2^1333 := by decide +kernel

def env49199 : List Nat := [2,4,8,1,32,64,128,9,64,72,142,12,68,64,0,35,65,162,69,1,13,201,65,35,193,12,38,0,64,238,73,64,9,12,0,76]

theorem envBound49199 : H12AffineFastState.Bounded env49199 := by
  intro p hp
  have h : env49199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49198_49199 : H12AffineEnvironment.transform 10 142 env49198 = env49199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 142 env49198 == env49199) = true)

theorem identity49199 : scanCanonicalize (H12AffineFastState.compose env49199 (packedSelected [1,2,3,4,8,9,11] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound49199 : packedSelected [1,2,3,4,8,9,11] rootPS < 2^1333 := by decide +kernel

def env49200 : List Nat := [2,4,8,1,32,64,4,9,64,72,10,12,68,64,0,35,65,38,69,1,13,77,65,35,69,12,38,0,64,106,73,64,9,12,0,76]

theorem envBound49200 : H12AffineFastState.Bounded env49200 := by
  intro p hp
  have h : env49200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49199_49200 : H12AffineEnvironment.transform 6 4 env49199 = env49200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env49199 == env49200) = true)

theorem identity49200 : scanCanonicalize (H12AffineFastState.compose env49200 (packedSelected [1,7,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 7) := by decide +kernel

theorem selectedBound49200 : packedSelected [1,7,8,9] rootPS < 2^1333 := by decide +kernel

def env49201 : List Nat := [2,4,8,1,32,7,4,9,7,15,10,12,3,7,0,35,6,38,2,1,13,10,6,35,2,12,38,0,7,45,14,7,9,12,0,11]

theorem envBound49201 : H12AffineFastState.Bounded env49201 := by
  intro p hp
  have h : env49201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49200_49201 : H12AffineEnvironment.transform 5 7 env49200 = env49201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 7 env49200 == env49201) = true)

theorem identity49201 : scanCanonicalize (H12AffineFastState.compose env49201 (packedSelected [2,3] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound49201 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env49202 : List Nat := [2,4,8,1,7,7,4,9,7,15,10,12,3,7,0,4,6,1,2,1,13,10,6,4,2,12,1,0,7,10,14,7,9,12,0,11]

theorem envBound49202 : H12AffineFastState.Bounded env49202 := by
  intro p hp
  have h : env49202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49201_49202 : H12AffineEnvironment.transform 4 7 env49201 = env49202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env49201 == env49202) = true)

theorem identity49202 : scanCanonicalize (H12AffineFastState.compose env49202 (packedSelected [0,4] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound49202 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env49203 : List Nat := [2,4,5,1,7,7,4,4,7,2,7,1,3,7,0,4,6,1,2,1,0,7,6,4,2,1,1,0,7,7,3,7,4,1,0,6]

theorem envBound49203 : H12AffineFastState.Bounded env49203 := by
  intro p hp
  have h : env49203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49202_49203 : H12AffineEnvironment.transform 2 5 env49202 = env49203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env49202 == env49203) = true)

theorem identity49203 : scanCanonicalize (H12AffineFastState.compose env49203 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound49203 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49204 : List Nat := [2,1,0,1,2,2,1,1,2,2,2,1,3,2,0,1,3,1,2,1,0,2,3,1,2,1,1,0,2,2,3,2,1,1,0,3]

theorem envBound49204 : H12AffineFastState.Bounded env49204 := by
  intro p hp
  have h : env49204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49203_49204 : H12AffineEnvironment.transform 1 1 env49203 = env49204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env49203 == env49204) = true)

theorem identity49204 : scanCanonicalize (H12AffineFastState.compose env49204 (packedSelected [2] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound49204 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49205 : List Nat := [0,1,0,1,0,0,1,1,0,0,0,1,1,0,0,1,1,1,0,1,0,0,1,1,0,1,1,0,0,0,1,0,1,1,0,1]

theorem envBound49205 : H12AffineFastState.Bounded env49205 := by
  intro p hp
  have h : env49205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49204_49205 : H12AffineEnvironment.transform 0 0 env49204 = env49205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env49204 == env49205) = true)

def env49206 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,853,8192,81,8540,65536,74031,65665,533,8541,852,648,74046,65553,9180,74299,318,74111,81,76638,8205,64,256,65830,0,341]

theorem envBound49206 : H12AffineFastState.Bounded env49206 := by
  intro p hp
  have h : env49206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49168_49206 : H12AffineEnvironment.transform 11 853 env49168 = env49206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 853 env49168 == env49206) = true)

def env49207 : List Nat := [2,4,8,0,32,64,128,256,512,321,2048,837,8192,65,8524,65536,74031,65665,517,8525,836,648,74030,65537,9164,74283,302,74095,65,76622,8205,64,256,65830,0,325]

theorem envBound49207 : H12AffineFastState.Bounded env49207 := by
  intro p hp
  have h : env49207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49206_49207 : H12AffineEnvironment.transform 3 0 env49206 = env49207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env49206 == env49207) = true)

theorem identity49207 : scanCanonicalize (H12AffineFastState.compose env49207 (packedSelected [1,8,28] rootPS)) = affineNative (2^(5+1) ^^^ 13) := by decide +kernel

theorem selectedBound49207 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env49208 : List Nat := [2,4,8,0,32,13,128,256,512,268,2048,776,8192,12,8449,65536,74031,65665,517,8448,777,648,74030,65537,9089,74283,302,74018,12,76547,8205,13,256,65830,0,264]

theorem envBound49208 : H12AffineFastState.Bounded env49208 := by
  intro p hp
  have h : env49208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49207_49208 : H12AffineEnvironment.transform 5 13 env49207 = env49208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 13 env49207 == env49208) = true)

def env49209 : List Nat := [2,4,8,0,32,13,128,256,512,268,2048,776,4,12,261,65536,65835,65665,517,260,777,648,65834,65537,901,66095,302,65830,12,68359,9,13,256,65830,0,264]

theorem envBound49209 : H12AffineFastState.Bounded env49209 := by
  intro p hp
  have h : env49209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49208_49209 : H12AffineEnvironment.transform 12 4 env49208 = env49209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4 env49208 == env49209) = true)

theorem identity49209 : scanCanonicalize (H12AffineFastState.compose env49209 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 13) := by decide +kernel

theorem selectedBound49209 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env49210 : List Nat := [2,4,8,0,32,13,128,256,13,268,2048,261,4,12,261,65536,65835,65665,8,260,260,133,65834,65537,392,65570,302,65830,12,67850,9,13,256,65830,0,264]

theorem envBound49210 : H12AffineFastState.Bounded env49210 := by
  intro p hp
  have h : env49210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49209_49210 : H12AffineEnvironment.transform 8 13 env49209 = env49210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 13 env49209 == env49210) = true)

theorem identity49210 : scanCanonicalize (H12AffineFastState.compose env49210 (packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS)) = affineNative (2^(15+1) ^^^ 269) := by decide +kernel

theorem selectedBound49210 : packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS < 2^1333 := by decide +kernel

def env49211 : List Nat := [2,4,8,0,32,13,128,256,13,268,2048,261,4,12,261,269,38,396,8,260,260,133,39,268,392,303,302,43,12,2055,9,13,256,43,0,264]

theorem envBound49211 : H12AffineFastState.Bounded env49211 := by
  intro p hp
  have h : env49211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49210_49211 : H12AffineEnvironment.transform 15 269 env49210 = env49211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 269 env49210 == env49211) = true)

theorem identity49211 : scanCanonicalize (H12AffineFastState.compose env49211 (packedSelected [0,1,2,3,4,7,8,9,10,11,12,16] rootPS)) = affineNative (2^(6+1) ^^^ 14) := by decide +kernel

theorem selectedBound49211 : packedSelected [0,1,2,3,4,7,8,9,10,11,12,16] rootPS < 2^1333 := by decide +kernel

def env49212 : List Nat := [2,4,8,0,32,13,14,256,13,268,2048,261,4,12,261,269,38,258,8,260,260,11,39,268,262,303,302,43,12,2055,9,13,256,43,0,264]

theorem envBound49212 : H12AffineFastState.Bounded env49212 := by
  intro p hp
  have h : env49212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49211_49212 : H12AffineEnvironment.transform 6 14 env49211 = env49212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 14 env49211 == env49212) = true)

theorem identity49212 : scanCanonicalize (H12AffineFastState.compose env49212 (packedSelected [0,1,5,7,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound49212 : packedSelected [0,1,5,7,11,12] rootPS < 2^1333 := by decide +kernel

def env49213 : List Nat := [2,4,8,0,32,13,14,5,13,9,2048,0,4,12,0,8,38,7,8,1,1,11,39,9,3,42,43,43,12,2055,9,13,5,43,0,13]

theorem envBound49213 : H12AffineFastState.Bounded env49213 := by
  intro p hp
  have h : env49213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49212_49213 : H12AffineEnvironment.transform 7 5 env49212 = env49213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env49212 == env49213) = true)

theorem identity49213 : scanCanonicalize (H12AffineFastState.compose env49213 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 45) := by decide +kernel

theorem selectedBound49213 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env49214 : List Nat := [2,4,8,0,32,13,14,5,13,9,45,0,4,12,0,8,38,7,8,1,1,11,39,9,3,42,43,43,12,42,9,13,5,43,0,13]

theorem envBound49214 : H12AffineFastState.Bounded env49214 := by
  intro p hp
  have h : env49214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49213_49214 : H12AffineEnvironment.transform 10 45 env49213 = env49214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 45 env49213 == env49214) = true)

theorem identity49214 : scanCanonicalize (H12AffineFastState.compose env49214 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound49214 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env49215 : List Nat := [2,4,8,0,7,13,14,5,13,9,10,0,4,12,0,8,1,7,8,1,1,11,0,9,3,13,12,12,12,13,9,13,5,12,0,13]

theorem envBound49215 : H12AffineFastState.Bounded env49215 := by
  intro p hp
  have h : env49215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49214_49215 : H12AffineEnvironment.transform 4 7 env49214 = env49215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env49214 == env49215) = true)

theorem identity49215 : scanCanonicalize (H12AffineFastState.compose env49215 (packedSelected [0,1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound49215 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env49216 : List Nat := [2,3,8,0,0,10,9,2,10,9,10,0,3,11,0,8,1,0,8,1,1,11,0,9,3,10,11,11,11,10,9,10,2,11,0,10]

theorem envBound49216 : H12AffineFastState.Bounded env49216 := by
  intro p hp
  have h : env49216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49215_49216 : H12AffineEnvironment.transform 1 3 env49215 = env49216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env49215 == env49216) = true)

theorem identity49216 : scanCanonicalize (H12AffineFastState.compose env49216 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound49216 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env49217 : List Nat := [2,3,3,0,0,1,2,2,1,2,1,0,3,0,0,3,1,0,3,1,1,0,0,2,3,1,0,0,0,1,2,1,2,0,0,1]

theorem envBound49217 : H12AffineFastState.Bounded env49217 := by
  intro p hp
  have h : env49217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49216_49217 : H12AffineEnvironment.transform 2 3 env49216 = env49217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env49216 == env49217) = true)

def env49218 : List Nat := [2,4,8,0,32,13,128,256,512,268,2048,776,5,12,260,65536,65834,65665,517,261,777,648,65835,65537,900,66094,302,65831,12,68358,8,13,256,65830,0,264]

theorem envBound49218 : H12AffineFastState.Bounded env49218 := by
  intro p hp
  have h : env49218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49208_49218 : H12AffineEnvironment.transform 12 5 env49208 = env49218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5 env49208 == env49218) = true)

theorem identity49218 : scanCanonicalize (H12AffineFastState.compose env49218 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound49218 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env49219 : List Nat := [2,4,8,0,32,13,128,4,512,8,2048,524,5,12,0,65536,65582,65665,517,1,525,648,65583,65537,640,66094,42,65571,12,68098,8,13,4,65570,0,12]

theorem envBound49219 : H12AffineFastState.Bounded env49219 := by
  intro p hp
  have h : env49219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49218_49219 : H12AffineEnvironment.transform 7 4 env49218 = env49219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env49218 == env49219) = true)

theorem identity49219 : scanCanonicalize (H12AffineFastState.compose env49219 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound49219 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env49220 : List Nat := [2,4,8,0,32,13,128,4,512,8,2048,524,5,12,0,35,13,162,517,1,525,648,12,34,640,525,42,0,12,2593,8,13,4,1,0,12]

theorem envBound49220 : H12AffineFastState.Bounded env49220 := by
  intro p hp
  have h : env49220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49219_49220 : H12AffineEnvironment.transform 15 35 env49219 = env49220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env49219 == env49220) = true)

theorem identity49220 : scanCanonicalize (H12AffineFastState.compose env49220 (packedSelected [0,2,5,7,8,11,12,13,15] rootPS)) = affineNative (2^(8+1) ^^^ 168) := by decide +kernel

theorem selectedBound49220 : packedSelected [0,2,5,7,8,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env49221 : List Nat := [2,4,8,0,32,13,128,4,168,8,2048,164,5,12,0,35,13,162,173,1,165,32,12,34,40,165,42,0,12,2185,8,13,4,1,0,12]

theorem envBound49221 : H12AffineFastState.Bounded env49221 := by
  intro p hp
  have h : env49221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49220_49221 : H12AffineEnvironment.transform 8 168 env49220 = env49221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 168 env49220 == env49221) = true)

theorem identity49221 : scanCanonicalize (H12AffineFastState.compose env49221 (packedSelected [1,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 131) := by decide +kernel

theorem selectedBound49221 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env49222 : List Nat := [2,4,8,0,32,13,128,4,168,8,131,164,5,12,0,35,13,162,173,1,165,32,12,34,40,165,42,0,12,10,8,13,4,1,0,12]

theorem envBound49222 : H12AffineFastState.Bounded env49222 := by
  intro p hp
  have h : env49222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49221_49222 : H12AffineEnvironment.transform 10 131 env49221 = env49222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 131 env49221 == env49222) = true)

theorem identity49222 : scanCanonicalize (H12AffineFastState.compose env49222 (packedSelected [2,3,4,7,8] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound49222 : packedSelected [2,3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env49223 : List Nat := [2,2,8,0,32,11,128,2,168,8,131,162,3,10,0,35,11,162,171,1,163,32,10,34,40,163,42,0,10,10,8,11,2,1,0,10]

theorem envBound49223 : H12AffineFastState.Bounded env49223 := by
  intro p hp
  have h : env49223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49222_49223 : H12AffineEnvironment.transform 1 2 env49222 = env49223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env49222 == env49223) = true)

theorem identity49223 : scanCanonicalize (H12AffineFastState.compose env49223 (packedSelected [0,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound49223 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env49224 : List Nat := [2,2,8,0,32,11,35,2,11,8,32,1,3,10,0,35,11,1,8,1,0,32,10,34,40,0,42,0,10,10,8,11,2,1,0,10]

theorem envBound49224 : H12AffineFastState.Bounded env49224 := by
  intro p hp
  have h : env49224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49223_49224 : H12AffineEnvironment.transform 6 35 env49223 = env49224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env49223 == env49224) = true)

theorem identity49224 : scanCanonicalize (H12AffineFastState.compose env49224 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound49224 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49225 : List Nat := [2,2,8,0,0,11,3,2,11,8,0,1,3,10,0,3,11,1,8,1,0,0,10,2,8,0,10,0,10,10,8,11,2,1,0,10]

theorem envBound49225 : H12AffineFastState.Bounded env49225 := by
  intro p hp
  have h : env49225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49224_49225 : H12AffineEnvironment.transform 4 0 env49224 = env49225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env49224 == env49225) = true)

theorem identity49225 : scanCanonicalize (H12AffineFastState.compose env49225 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound49225 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49226 : List Nat := [2,2,1,0,0,2,3,2,2,1,0,1,3,3,0,3,2,1,1,1,0,0,3,2,1,0,3,0,3,3,1,2,2,1,0,3]

theorem envBound49226 : H12AffineFastState.Bounded env49226 := by
  intro p hp
  have h : env49226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49225_49226 : H12AffineEnvironment.transform 2 1 env49225 = env49226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env49225 == env49226) = true)

theorem identity49226 : scanCanonicalize (H12AffineFastState.compose env49226 (packedSelected [2] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound49226 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49227 : List Nat := [0,0,1,0,0,0,1,0,0,1,0,1,1,1,0,1,0,1,1,1,0,0,1,0,1,0,1,0,1,1,1,0,0,1,0,1]

theorem envBound49227 : H12AffineFastState.Bounded env49227 := by
  intro p hp
  have h : env49227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49226_49227 : H12AffineEnvironment.transform 0 0 env49226 = env49227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env49226 == env49227) = true)

def env49228 : List Nat := [2,4,8,1,32,64,128,256,512,321,2048,836,8192,64,8525,65536,74031,65665,516,8524,837,648,74031,65536,9165,74282,303,74094,64,76623,8205,64,256,65830,0,324]

theorem envBound49228 : H12AffineFastState.Bounded env49228 := by
  intro p hp
  have h : env49228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49206_49228 : H12AffineEnvironment.transform 3 1 env49206 = env49228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env49206 == env49228) = true)

theorem identity49228 : scanCanonicalize (H12AffineFastState.compose env49228 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 5) := by decide +kernel

theorem selectedBound49228 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env49229 : List Nat := [2,4,8,1,32,64,128,256,512,321,2048,836,5,64,328,65536,65834,65665,516,329,837,648,65834,65536,968,66095,303,65899,64,68426,8,64,256,65830,0,324]

theorem envBound49229 : H12AffineFastState.Bounded env49229 := by
  intro p hp
  have h : env49229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49228_49229 : H12AffineEnvironment.transform 12 5 env49228 = env49229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5 env49228 == env49229) = true)

def env49230 : List Nat := [2,4,8,1,32,64,128,256,512,321,2048,836,5,64,328,160,394,33,516,329,837,648,394,160,968,655,303,459,64,3050,8,64,256,390,0,324]

theorem envBound49230 : H12AffineFastState.Bounded env49230 := by
  intro p hp
  have h : env49230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49229_49230 : H12AffineEnvironment.transform 15 160 env49229 = env49230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 160 env49229 == env49230) = true)

theorem identity49230 : scanCanonicalize (H12AffineFastState.compose env49230 (packedSelected [2,10,11,15,18,19] rootPS)) = affineNative (2^(10+1) ^^^ 194) := by decide +kernel

theorem selectedBound49230 : packedSelected [2,10,11,15,18,19] rootPS < 2^1333 := by decide +kernel

def env49231 : List Nat := [2,4,8,1,32,64,128,256,512,321,194,836,5,64,328,160,394,33,516,329,837,648,394,160,968,655,303,459,64,808,8,64,256,390,0,324]

theorem envBound49231 : H12AffineFastState.Bounded env49231 := by
  intro p hp
  have h : env49231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49230_49231 : H12AffineEnvironment.transform 10 194 env49230 = env49231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 194 env49230 == env49231) = true)

theorem identity49231 : scanCanonicalize (H12AffineFastState.compose env49231 (packedSelected [0,1,2,5,8,9,10,11,12,16,17,18,23] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound49231 : packedSelected [0,1,2,5,8,9,10,11,12,16,17,18,23] rootPS < 2^1333 := by decide +kernel

def env49232 : List Nat := [2,4,8,1,32,64,128,256,11,321,194,335,5,64,328,160,394,33,15,329,334,131,394,160,451,132,303,459,64,291,8,64,256,390,0,324]

theorem envBound49232 : H12AffineFastState.Bounded env49232 := by
  intro p hp
  have h : env49232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49231_49232 : H12AffineEnvironment.transform 8 11 env49231 = env49232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env49231 == env49232) = true)

theorem identity49232 : scanCanonicalize (H12AffineFastState.compose env49232 (packedSelected [0,1,3,4,7,8,9,10,13,15,17] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound49232 : packedSelected [0,1,3,4,7,8,9,10,13,15,17] rootPS < 2^1333 := by decide +kernel

def env49233 : List Nat := [2,4,8,1,32,1,128,256,11,256,131,270,5,1,265,160,394,33,15,264,271,131,394,160,386,132,303,394,1,291,8,1,256,390,0,261]

theorem envBound49233 : H12AffineFastState.Bounded env49233 := by
  intro p hp
  have h : env49233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49232_49233 : H12AffineEnvironment.transform 5 1 env49232 = env49233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env49232 == env49233) = true)

theorem identity49233 : scanCanonicalize (H12AffineFastState.compose env49233 (packedSelected [1,4,5,7,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound49233 : packedSelected [1,4,5,7,11,12] rootPS < 2^1333 := by decide +kernel

def env49234 : List Nat := [2,4,8,1,32,1,128,5,11,5,131,11,5,1,12,160,143,33,15,13,10,131,143,160,135,132,42,143,1,38,8,1,5,131,0,0]

theorem envBound49234 : H12AffineFastState.Bounded env49234 := by
  intro p hp
  have h : env49234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49233_49234 : H12AffineEnvironment.transform 7 5 env49233 = env49234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env49233 == env49234) = true)

theorem identity49234 : scanCanonicalize (H12AffineFastState.compose env49234 (packedSelected [0,2,4,5,8] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound49234 : packedSelected [0,2,4,5,8] rootPS < 2^1333 := by decide +kernel

def env49235 : List Nat := [2,4,8,1,7,1,128,5,11,5,131,11,5,1,12,135,143,6,15,13,10,131,143,135,135,132,13,143,1,1,8,1,5,131,0,0]

theorem envBound49235 : H12AffineFastState.Bounded env49235 := by
  intro p hp
  have h : env49235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49234_49235 : H12AffineEnvironment.transform 4 7 env49234 = env49235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env49234 == env49235) = true)

theorem identity49235 : scanCanonicalize (H12AffineFastState.compose env49235 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound49235 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env49236 : List Nat := [2,2,8,1,1,1,128,3,11,3,131,11,3,1,10,129,137,0,9,11,10,131,137,129,129,130,11,137,1,1,8,1,3,131,0,0]

theorem envBound49236 : H12AffineFastState.Bounded env49236 := by
  intro p hp
  have h : env49236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49235_49236 : H12AffineEnvironment.transform 1 2 env49235 = env49236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env49235 == env49236) = true)

theorem identity49236 : scanCanonicalize (H12AffineFastState.compose env49236 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound49236 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49237 : List Nat := [2,2,8,1,1,1,2,3,11,3,1,11,3,1,10,3,11,0,9,11,10,1,11,3,3,0,11,11,1,1,8,1,3,1,0,0]

theorem envBound49237 : H12AffineFastState.Bounded env49237 := by
  intro p hp
  have h : env49237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49236_49237 : H12AffineEnvironment.transform 6 2 env49236 = env49237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env49236 == env49237) = true)

theorem identity49237 : scanCanonicalize (H12AffineFastState.compose env49237 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound49237 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env49238 : List Nat := [2,2,2,1,1,1,2,3,1,3,1,1,3,1,0,3,1,0,3,1,0,1,1,3,3,0,1,1,1,1,2,1,3,1,0,0]

theorem envBound49238 : H12AffineFastState.Bounded env49238 := by
  intro p hp
  have h : env49238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49237_49238 : H12AffineEnvironment.transform 2 2 env49237 = env49238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env49237 == env49238) = true)

theorem identity49238 : scanCanonicalize (H12AffineFastState.compose env49238 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound49238 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49239 : List Nat := [0,0,0,1,1,1,0,1,1,1,1,1,1,1,0,1,1,0,1,1,0,1,1,1,1,0,1,1,1,1,0,1,1,1,0,0]

theorem envBound49239 : H12AffineFastState.Bounded env49239 := by
  intro p hp
  have h : env49239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49238_49239 : H12AffineEnvironment.transform 0 0 env49238 = env49239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env49238 == env49239) = true)

def env49240 : List Nat := [2,4,8,1,32,64,128,256,512,321,2048,836,5,64,328,161,395,32,516,329,837,648,395,161,968,654,303,458,64,3051,8,64,256,391,0,324]

theorem envBound49240 : H12AffineFastState.Bounded env49240 := by
  intro p hp
  have h : env49240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49229_49240 : H12AffineEnvironment.transform 15 161 env49229 = env49240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 161 env49229 == env49240) = true)

theorem identity49240 : scanCanonicalize (H12AffineFastState.compose env49240 (packedSelected [2,10,11,15,18,19] rootPS)) = affineNative (2^(10+1) ^^^ 207) := by decide +kernel

theorem selectedBound49240 : packedSelected [2,10,11,15,18,19] rootPS < 2^1333 := by decide +kernel

def env49241 : List Nat := [2,4,8,1,32,64,128,256,512,321,207,836,5,64,328,161,395,32,516,329,837,648,395,161,968,654,303,458,64,804,8,64,256,391,0,324]

theorem envBound49241 : H12AffineFastState.Bounded env49241 := by
  intro p hp
  have h : env49241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49240_49241 : H12AffineEnvironment.transform 10 207 env49240 = env49241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 207 env49240 == env49241) = true)

theorem identity49241 : scanCanonicalize (H12AffineFastState.compose env49241 (packedSelected [1,3,4,5,9,16,17,18,21,23] rootPS)) = affineNative (2^(8+1) ^^^ 39) := by decide +kernel

theorem selectedBound49241 : packedSelected [1,3,4,5,9,16,17,18,21,23] rootPS < 2^1333 := by decide +kernel

def env49242 : List Nat := [2,4,8,1,32,64,128,256,39,321,207,355,5,64,328,161,395,32,35,329,354,175,395,161,495,169,303,458,64,259,8,64,256,391,0,324]

theorem envBound49242 : H12AffineFastState.Bounded env49242 := by
  intro p hp
  have h : env49242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49241_49242 : H12AffineEnvironment.transform 8 39 env49241 = env49242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 39 env49241 == env49242) = true)

theorem identity49242 : scanCanonicalize (H12AffineFastState.compose env49242 (packedSelected [0,1,2,5,7,12,13,15,18] rootPS)) = affineNative (2^(6+1) ^^^ 47) := by decide +kernel

theorem selectedBound49242 : packedSelected [0,1,2,5,7,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env49243 : List Nat := [2,4,8,1,32,64,47,256,39,321,96,355,5,64,328,14,292,32,35,329,354,0,292,14,320,6,303,357,64,259,8,64,256,296,0,324]

theorem envBound49243 : H12AffineFastState.Bounded env49243 := by
  intro p hp
  have h : env49243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49242_49243 : H12AffineEnvironment.transform 6 47 env49242 = env49243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 47 env49242 == env49243) = true)

theorem identity49243 : scanCanonicalize (H12AffineFastState.compose env49243 (packedSelected [1,3,7,8,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 39) := by decide +kernel

theorem selectedBound49243 : packedSelected [1,3,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env49244 : List Nat := [2,4,8,1,32,39,47,256,39,294,7,260,5,39,303,14,292,32,35,302,261,0,292,14,295,6,303,258,39,259,8,39,256,296,0,291]

theorem envBound49244 : H12AffineFastState.Bounded env49244 := by
  intro p hp
  have h : env49244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49243_49244 : H12AffineEnvironment.transform 5 39 env49243 = env49244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 39 env49243 == env49244) = true)

theorem identity49244 : scanCanonicalize (H12AffineFastState.compose env49244 (packedSelected [2,4,7] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound49244 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env49245 : List Nat := [2,4,8,1,6,1,9,256,1,256,7,260,5,1,265,14,258,6,5,264,261,0,258,14,257,6,265,258,1,259,8,1,256,270,0,261]

theorem envBound49245 : H12AffineFastState.Bounded env49245 := by
  intro p hp
  have h : env49245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49244_49245 : H12AffineEnvironment.transform 4 6 env49244 = env49245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env49244 == env49245) = true)

theorem identity49245 : scanCanonicalize (H12AffineFastState.compose env49245 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound49245 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49246 : List Nat := [2,4,5,1,6,1,4,256,1,256,7,260,5,1,260,3,258,6,5,261,261,0,258,3,257,6,260,258,1,259,5,1,256,259,0,261]

theorem envBound49246 : H12AffineFastState.Bounded env49246 := by
  intro p hp
  have h : env49246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49245_49246 : H12AffineEnvironment.transform 2 5 env49245 = env49246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env49245 == env49246) = true)

theorem identity49246 : scanCanonicalize (H12AffineFastState.compose env49246 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound49246 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49247 : List Nat := [2,4,5,1,6,1,4,5,1,5,7,1,5,1,1,3,7,6,5,0,0,0,7,3,4,6,1,7,1,6,5,1,5,6,0,0]

theorem envBound49247 : H12AffineFastState.Bounded env49247 := by
  intro p hp
  have h : env49247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49246_49247 : H12AffineEnvironment.transform 7 5 env49246 = env49247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env49246 == env49247) = true)

theorem identity49247 : scanCanonicalize (H12AffineFastState.compose env49247 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound49247 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49248 : List Nat := [2,0,1,1,2,1,0,1,1,1,3,1,1,1,1,3,3,2,1,0,0,0,3,3,0,2,1,3,1,2,1,1,1,2,0,0]

theorem envBound49248 : H12AffineFastState.Bounded env49248 := by
  intro p hp
  have h : env49248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49247_49248 : H12AffineEnvironment.transform 1 0 env49247 = env49248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env49247 == env49248) = true)

theorem identity49248 : scanCanonicalize (H12AffineFastState.compose env49248 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound49248 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env49249 : List Nat := [0,0,1,1,0,1,0,1,1,1,1,1,1,1,1,1,1,0,1,0,0,0,1,1,0,0,1,1,1,0,1,1,1,0,0,0]

theorem envBound49249 : H12AffineFastState.Bounded env49249 := by
  intro p hp
  have h : env49249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49248_49249 : H12AffineEnvironment.transform 0 0 env49248 = env49249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env49248 == env49249) = true)

def env49250 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74862,262144,4417,8540,4097,5276,74047,66896,13769,78895,328958,74815,1296,81227,8204,1281,256,65831,1345,5952]

theorem envBound49250 : H12AffineFastState.Bounded env49250 := by
  intro p hp
  have h : env49250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49139_49250 : H12AffineEnvironment.transform 13 1297 env49139 = env49250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env49139 == env49250) = true)

def env49251 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74862,65664,4417,8540,4097,5276,74047,66896,13769,78895,1150,74815,1296,81227,8204,1281,256,65831,1345,5952]

theorem envBound49251 : H12AffineFastState.Bounded env49251 := by
  intro p hp
  have h : env49251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49250_49251 : H12AffineEnvironment.transform 17 65664 env49250 = env49251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env49250 == env49251) = true)

theorem identity49251 : scanCanonicalize (H12AffineFastState.compose env49251 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 72) := by decide +kernel

theorem selectedBound49251 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env49252 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,72,1297,277,65536,66598,65664,4417,276,4097,5276,65911,66896,5505,70759,1150,66679,1296,72963,68,1281,256,65831,1345,5952]

theorem envBound49252 : H12AffineFastState.Bounded env49252 := by
  intro p hp
  have h : env49252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49251_49252 : H12AffineEnvironment.transform 12 72 env49251 = env49252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env49251 == env49252) = true)

def env49253 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1556,72,1297,277,65536,66598,65664,1877,276,1557,648,65911,66896,917,66163,1150,66679,1296,68375,68,1281,256,65831,1345,340]

theorem envBound49253 : H12AffineFastState.Bounded env49253 := by
  intro p hp
  have h : env49253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49252_49253 : H12AffineEnvironment.transform 11 1556 env49252 = env49253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1556 env49252 == env49253) = true)

def env49254 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,852,72,81,277,65536,65894,65664,533,276,853,648,65911,65552,917,66163,318,65847,80,68375,68,65,256,65831,1,340]

theorem envBound49254 : H12AffineFastState.Bounded env49254 := by
  intro p hp
  have h : env49254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49253_49254 : H12AffineEnvironment.transform 9 320 env49253 = env49254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env49253 == env49254) = true)

theorem identity49254 : scanCanonicalize (H12AffineFastState.compose env49254 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound49254 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env49255 : List Nat := [2,4,8,16,32,64,128,21,512,85,2048,577,72,81,0,65536,65651,65664,533,1,576,648,65634,65552,640,66163,43,65570,80,68098,68,65,21,65586,1,65]

theorem envBound49255 : H12AffineFastState.Bounded env49255 := by
  intro p hp
  have h : env49255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49254_49255 : H12AffineEnvironment.transform 7 21 env49254 = env49255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env49254 == env49255) = true)

theorem identity49255 : scanCanonicalize (H12AffineFastState.compose env49255 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 611) := by decide +kernel

theorem selectedBound49255 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env49256 : List Nat := [2,4,8,16,32,64,128,21,512,85,2048,577,72,81,0,611,528,739,533,1,576,648,513,627,640,16,43,577,80,2145,68,65,21,593,1,65]

theorem envBound49256 : H12AffineFastState.Bounded env49256 := by
  intro p hp
  have h : env49256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49255_49256 : H12AffineEnvironment.transform 15 611 env49255 = env49256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 611 env49255 == env49256) = true)

theorem identity49256 : scanCanonicalize (H12AffineFastState.compose env49256 (packedSelected [0,1,7,8,10,11,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 210) := by decide +kernel

theorem selectedBound49256 : packedSelected [0,1,7,8,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env49257 : List Nat := [2,4,8,16,32,64,128,21,512,85,210,577,72,81,0,611,528,739,533,1,576,648,513,627,640,16,43,577,80,179,68,65,21,593,1,65]

theorem envBound49257 : H12AffineFastState.Bounded env49257 := by
  intro p hp
  have h : env49257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49256_49257 : H12AffineEnvironment.transform 10 210 env49256 = env49257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 210 env49256 == env49257) = true)

theorem identity49257 : scanCanonicalize (H12AffineFastState.compose env49257 (packedSelected [4,9,16] rootPS)) = affineNative (2^(8+1) ^^^ 65) := by decide +kernel

theorem selectedBound49257 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env49258 : List Nat := [2,4,8,16,32,64,128,21,65,85,210,0,72,81,0,34,81,162,84,1,1,201,64,50,193,16,43,0,80,179,68,65,21,16,1,65]

theorem envBound49258 : H12AffineFastState.Bounded env49258 := by
  intro p hp
  have h : env49258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49257_49258 : H12AffineEnvironment.transform 8 65 env49257 = env49258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 65 env49257 == env49258) = true)

theorem identity49258 : scanCanonicalize (H12AffineFastState.compose env49258 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound49258 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env49259 : List Nat := [2,4,8,16,32,64,88,21,65,85,10,0,72,81,0,34,81,122,84,1,1,17,64,50,25,16,43,0,80,107,68,65,21,16,1,65]

theorem envBound49259 : H12AffineFastState.Bounded env49259 := by
  intro p hp
  have h : env49259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49258_49259 : H12AffineEnvironment.transform 6 88 env49258 = env49259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env49258 == env49259) = true)

theorem identity49259 : scanCanonicalize (H12AffineFastState.compose env49259 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound49259 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49260 : List Nat := [2,4,8,16,32,10,18,21,11,31,10,0,2,27,0,34,27,48,30,1,1,17,10,50,25,16,43,0,26,33,14,11,21,16,1,11]

theorem envBound49260 : H12AffineFastState.Bounded env49260 := by
  intro p hp
  have h : env49260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49259_49260 : H12AffineEnvironment.transform 5 10 env49259 = env49260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env49259 == env49260) = true)

theorem identity49260 : scanCanonicalize (H12AffineFastState.compose env49260 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound49260 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env49261 : List Nat := [2,4,8,6,32,10,4,3,11,9,10,0,2,13,0,34,13,38,8,1,1,7,10,36,15,6,43,0,12,33,14,11,3,6,1,11]

theorem envBound49261 : H12AffineFastState.Bounded env49261 := by
  intro p hp
  have h : env49261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49260_49261 : H12AffineEnvironment.transform 3 6 env49260 = env49261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env49260 == env49261) = true)

theorem identity49261 : scanCanonicalize (H12AffineFastState.compose env49261 (packedSelected [0,1,4,7] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound49261 : packedSelected [0,1,4,7] rootPS < 2^1333 := by decide +kernel

def env49262 : List Nat := [2,4,8,6,6,10,4,3,11,9,10,0,2,13,0,4,13,0,8,1,1,7,10,2,15,6,13,0,12,7,14,11,3,6,1,11]

theorem envBound49262 : H12AffineFastState.Bounded env49262 := by
  intro p hp
  have h : env49262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49261_49262 : H12AffineEnvironment.transform 4 6 env49261 = env49262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env49261 == env49262) = true)

theorem identity49262 : scanCanonicalize (H12AffineFastState.compose env49262 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound49262 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49263 : List Nat := [2,4,5,6,6,7,4,3,6,4,7,0,2,0,0,4,0,0,5,1,1,7,7,2,2,6,0,0,1,7,3,6,3,6,1,6]

theorem envBound49263 : H12AffineFastState.Bounded env49263 := by
  intro p hp
  have h : env49263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49262_49263 : H12AffineEnvironment.transform 2 5 env49262 = env49263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env49262 == env49263) = true)

def env49264 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,853,72,80,277,65536,65895,65664,532,276,852,648,65911,65553,917,66163,319,65846,81,68375,68,64,256,65831,0,340]

theorem envBound49264 : H12AffineFastState.Bounded env49264 := by
  intro p hp
  have h : env49264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49253_49264 : H12AffineEnvironment.transform 9 321 env49253 = env49264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env49253 == env49264) = true)

theorem identity49264 : scanCanonicalize (H12AffineFastState.compose env49264 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 65) := by decide +kernel

theorem selectedBound49264 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env49265 : List Nat := [2,4,8,16,32,64,128,256,65,321,2048,276,72,80,277,65536,65895,65664,85,276,277,201,65911,65553,468,65586,319,65846,81,67926,68,64,256,65831,0,340]

theorem envBound49265 : H12AffineFastState.Bounded env49265 := by
  intro p hp
  have h : env49265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49264_49265 : H12AffineEnvironment.transform 8 65 env49264 = env49265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 65 env49264 == env49265) = true)

theorem identity49265 : scanCanonicalize (H12AffineFastState.compose env49265 (packedSelected [0,3,4,5,9,10,16,27] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound49265 : packedSelected [0,3,4,5,9,10,16,27] rootPS < 2^1333 := by decide +kernel

def env49266 : List Nat := [2,4,8,16,32,64,128,256,65,321,2048,276,72,80,277,34,325,162,85,276,277,201,341,51,468,16,319,276,81,2420,68,64,256,261,0,340]

theorem envBound49266 : H12AffineFastState.Bounded env49266 := by
  intro p hp
  have h : env49266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49265_49266 : H12AffineEnvironment.transform 15 34 env49265 = env49266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env49265 == env49266) = true)

theorem identity49266 : scanCanonicalize (H12AffineFastState.compose env49266 (packedSelected [0,2,3,5,7,8,10,13,18] rootPS)) = affineNative (2^(10+1) ^^^ 238) := by decide +kernel

theorem selectedBound49266 : packedSelected [0,2,3,5,7,8,10,13,18] rootPS < 2^1333 := by decide +kernel

def env49267 : List Nat := [2,4,8,16,32,64,128,256,65,321,238,276,72,80,277,34,325,162,85,276,277,201,341,51,468,16,319,276,81,410,68,64,256,261,0,340]

theorem envBound49267 : H12AffineFastState.Bounded env49267 := by
  intro p hp
  have h : env49267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49266_49267 : H12AffineEnvironment.transform 10 238 env49266 = env49267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 238 env49266 == env49267) = true)

theorem identity49267 : scanCanonicalize (H12AffineFastState.compose env49267 (packedSelected [8,11,12,15,20] rootPS)) = affineNative (2^(6+1) ^^^ 72) := by decide +kernel

theorem selectedBound49267 : packedSelected [8,11,12,15,20] rootPS < 2^1333 := by decide +kernel

def env49268 : List Nat := [2,4,8,16,32,64,72,256,65,321,38,276,72,80,277,34,325,106,85,276,277,1,341,51,284,16,319,276,81,338,68,64,256,261,0,340]

theorem envBound49268 : H12AffineFastState.Bounded env49268 := by
  intro p hp
  have h : env49268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49267_49268 : H12AffineEnvironment.transform 6 72 env49267 = env49268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 72 env49267 == env49268) = true)

theorem identity49268 : scanCanonicalize (H12AffineFastState.compose env49268 (packedSelected [1,2,13] rootPS)) = affineNative (2^(4+1) ^^^ 28) := by decide +kernel

theorem selectedBound49268 : packedSelected [1,2,13] rootPS < 2^1333 := by decide +kernel

def env49269 : List Nat := [2,4,8,16,28,64,72,256,65,321,26,276,72,80,277,30,325,86,85,276,277,1,341,15,284,16,259,276,81,338,68,64,256,261,0,340]

theorem envBound49269 : H12AffineFastState.Bounded env49269 := by
  intro p hp
  have h : env49269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49268_49269 : H12AffineEnvironment.transform 4 28 env49268 = env49269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 28 env49268 == env49269) = true)

end H12CloudChart2