import H12CloudChart2Data070

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity17401 : scanCanonicalize (H12AffineFastState.compose env17401 (packedSelected [2,4] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound17401 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env17402 : List Nat := [2,4,8,16,32,16,128,256,137,273,293,1,41,1,260,399,0,32,272,261,1,0,16,399,161,17,292,1,0,33,21,396,257,169,1,137]

theorem envBound17402 : H12AffineFastState.Bounded env17402 := by
  intro p hp
  have h : env17402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17401_17402 : H12AffineEnvironment.transform 10 293 env17401 = env17402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env17401 == env17402) = true)

def env17403 : List Nat := [2,4,8,16,0,16,128,256,137,273,261,1,9,1,260,399,0,0,272,261,1,0,16,399,129,17,260,1,0,1,21,396,257,137,1,137]

theorem envBound17403 : H12AffineFastState.Bounded env17403 := by
  intro p hp
  have h : env17403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17402_17403 : H12AffineEnvironment.transform 4 0 env17402 = env17403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17402 == env17403) = true)

theorem identity17403 : scanCanonicalize (H12AffineFastState.compose env17403 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound17403 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17404 : List Nat := [2,4,8,16,0,16,24,256,17,273,261,1,9,1,260,279,0,0,272,261,1,0,16,279,25,17,260,1,0,1,21,276,257,17,1,17]

theorem envBound17404 : H12AffineFastState.Bounded env17404 := by
  intro p hp
  have h : env17404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17403_17404 : H12AffineEnvironment.transform 6 24 env17403 = env17404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env17403 == env17404) = true)

def env17405 : List Nat := [2,4,8,16,1,16,128,256,137,273,260,1,8,1,260,399,0,1,272,261,1,0,16,399,128,17,261,1,0,0,21,396,257,136,1,137]

theorem envBound17405 : H12AffineFastState.Bounded env17405 := by
  intro p hp
  have h : env17405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17402_17405 : H12AffineEnvironment.transform 4 1 env17402 = env17405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env17402 == env17405) = true)

theorem identity17405 : scanCanonicalize (H12AffineFastState.compose env17405 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound17405 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17406 : List Nat := [2,4,8,16,1,16,128,21,137,4,17,1,8,1,17,154,0,1,5,16,1,0,16,154,128,17,16,1,0,0,21,153,20,136,1,137]

theorem envBound17406 : H12AffineFastState.Bounded env17406 := by
  intro p hp
  have h : env17406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17405_17406 : H12AffineEnvironment.transform 7 21 env17405 = env17406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env17405 == env17406) = true)

theorem identity17406 : scanCanonicalize (H12AffineFastState.compose env17406 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound17406 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17407 : List Nat := [2,4,8,1,1,1,128,4,137,4,0,1,8,1,0,139,0,1,5,1,1,0,1,139,128,0,1,1,0,0,4,136,5,136,1,137]

theorem envBound17407 : H12AffineFastState.Bounded env17407 := by
  intro p hp
  have h : env17407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17406_17407 : H12AffineEnvironment.transform 3 1 env17406 = env17407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env17406 == env17407) = true)

def leafEnv17407 : List Nat := [2,4,8,1,1,1,128,4,137,4,0,1,8,1,0,139,0,1,5,1,1,0,1,139,4,128,1,0,1,1,0,0,4,136,5,136,4,2,1,137,0,1,1]

def active17407 : List Nat := [0,1,2,6]

def tree17407 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17407 : H12WitnessSearch.Good tree17407 := H12GlobalWitnessIndex.good

theorem leafIdentity17407 : H12AffineFastState.composeSystem env17407 rootObs = leafEnv17407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17407 rootObs == leafEnv17407) = true)

theorem terminalChecked17407 : H12PackedTerminal.terminalCheckFast leafEnv17407 active17407 tree17407 = true := by decide +kernel

def env17408 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1297,8192,1297,2081,65536,1297,8201,1025,2080,1297,4194304,17,67877,8328,16,4202765,1297,1297,4196612,1284,73770,257,4204965,1296,137]

theorem envBound17408 : H12AffineFastState.Bounded env17408 := by
  intro p hp
  have h : env17408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17379_17408 : H12AffineEnvironment.transform 11 1297 env17379 = env17408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env17379 == env17408) = true)

theorem identity17408 : scanCanonicalize (H12AffineFastState.compose env17408 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 2056) := by decide +kernel

theorem selectedBound17408 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17409 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1297,2056,1297,2081,65536,1297,2049,1025,2080,1297,4194304,17,67877,2176,16,4196613,1297,1297,4196612,1284,67618,257,4194733,1296,137]

theorem envBound17409 : H12AffineFastState.Bounded env17409 := by
  intro p hp
  have h : env17409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17408_17409 : H12AffineEnvironment.transform 12 2056 env17408 = env17409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2056 env17408 == env17409) = true)

theorem identity17409 : scanCanonicalize (H12AffineFastState.compose env17409 (packedSelected [5] rootPS)) = affineNative (2^(21+1) ^^^ 67754) := by decide +kernel

theorem selectedBound17409 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env17410 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1297,2056,1297,2081,65536,1297,2049,1025,2080,1297,67754,17,67877,2176,16,65967,1297,1297,65966,1284,67618,257,67847,1296,137]

theorem envBound17410 : H12AffineFastState.Bounded env17410 := by
  intro p hp
  have h : env17410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17409_17410 : H12AffineEnvironment.transform 21 67754 env17409 = env17410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 67754 env17409 == env17410) = true)

theorem identity17410 : scanCanonicalize (H12AffineFastState.compose env17410 (packedSelected [0,6] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound17410 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env17411 : List Nat := [2,4,8,16,32,16,128,5,137,1024,2048,1044,2056,1044,2081,65536,1044,2049,1025,2080,1044,67754,17,67616,2176,16,65706,1044,1044,65707,1025,67618,4,67586,1045,137]

theorem envBound17411 : H12AffineFastState.Bounded env17411 := by
  intro p hp
  have h : env17411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17410_17411 : H12AffineEnvironment.transform 7 5 env17410 = env17411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env17410 == env17411) = true)

theorem identity17411 : scanCanonicalize (H12AffineFastState.compose env17411 (packedSelected [0,7] rootPS)) = affineNative (2^(15+1) ^^^ 2218) := by decide +kernel

theorem selectedBound17411 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env17412 : List Nat := [2,4,8,16,32,16,128,5,137,1024,2048,1044,2056,1044,2081,2218,1044,2049,1025,2080,1044,0,17,138,2176,16,2048,1044,1044,2049,1025,136,4,168,1045,137]

theorem envBound17412 : H12AffineFastState.Bounded env17412 := by
  intro p hp
  have h : env17412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17411_17412 : H12AffineEnvironment.transform 15 2218 env17411 = env17412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2218 env17411 == env17412) = true)

theorem identity17412 : scanCanonicalize (H12AffineFastState.compose env17412 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1181) := by decide +kernel

theorem selectedBound17412 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17413 : List Nat := [2,4,8,16,32,16,128,5,137,1024,1181,1044,1173,1044,1212,1079,1044,1180,1025,1213,1044,0,17,138,1053,16,1181,1044,1044,1180,1025,136,4,168,1045,137]

theorem envBound17413 : H12AffineFastState.Bounded env17413 := by
  intro p hp
  have h : env17413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17412_17413 : H12AffineEnvironment.transform 10 1181 env17412 = env17413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1181 env17412 == env17413) = true)

def env17414 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4097,32768,65536,1345,262144,1025,32769,4096,4194304,5377,98645,8328,5456,4456789,4097,1344,1073741824,1365,4294967296,257,4299260415,1344,512]

theorem envBound17414 : H12AffineFastState.Bounded env17414 := by
  intro p hp
  have h : env17414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17372_17414 : H12AffineEnvironment.transform 13 4097 env17372 = env17414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4097 env17372 == env17414) = true)

theorem identity17414 : scanCanonicalize (H12AffineFastState.compose env17414 (packedSelected [12,13,15,17,38,41] rootPS)) = affineNative (2^(31+1) ^^^ 1077979297) := by decide +kernel

theorem selectedBound17414 : packedSelected [12,13,15,17,38,41] rootPS < 2^1333 := by decide +kernel

def env17415 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4097,32768,65536,1345,262144,1025,32769,4096,4194304,5377,98645,8328,5456,4456789,4097,1344,1073741824,1365,1077979297,257,1073817950,1344,512]

theorem envBound17415 : H12AffineFastState.Bounded env17415 := by
  intro p hp
  have h : env17415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17414_17415 : H12AffineEnvironment.transform 31 1077979297 env17414 = env17415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1077979297 env17414 == env17415) = true)

def env17416 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,32768,65536,1297,262144,1025,32769,4096,4194304,5377,98565,8328,5376,4456709,4097,1296,1073741824,1285,1077979297,257,1073817870,1296,512]

theorem envBound17416 : H12AffineFastState.Bounded env17416 := by
  intro p hp
  have h : env17416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17415_17416 : H12AffineEnvironment.transform 5 16 env17415 = env17416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env17415 == env17416) = true)

theorem identity17416 : scanCanonicalize (H12AffineFastState.compose env17416 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(21+1) ^^^ 305453) := by decide +kernel

theorem selectedBound17416 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env17417 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,32768,65536,1297,262144,1025,32769,4096,305453,5377,98565,8328,5376,43048,4097,1296,1073741824,1285,1074004364,257,1073817870,1296,512]

theorem envBound17417 : H12AffineFastState.Bounded env17417 := by
  intro p hp
  have h : env17417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17416_17417 : H12AffineEnvironment.transform 21 305453 env17416 = env17417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 305453 env17416 == env17417) = true)

theorem identity17417 : scanCanonicalize (H12AffineFastState.compose env17417 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(29+1) ^^^ 303657) := by decide +kernel

theorem selectedBound17417 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env17418 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,32768,65536,1297,262144,1025,32769,4096,305453,5377,98565,8328,5376,43048,4097,1296,303657,1285,41893,257,363303,1296,512]

theorem envBound17418 : H12AffineFastState.Bounded env17418 := by
  intro p hp
  have h : env17418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17417_17418 : H12AffineEnvironment.transform 29 303657 env17417 = env17418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 303657 env17417 == env17418) = true)

theorem identity17418 : scanCanonicalize (H12AffineFastState.compose env17418 (packedSelected [1,3,5,12,13,24] rootPS)) = affineNative (2^(12+1) ^^^ 2721) := by decide +kernel

theorem selectedBound17418 : packedSelected [1,3,5,12,13,24] rootPS < 2^1333 := by decide +kernel

def env17419 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,2721,4097,32768,65536,1297,262144,1025,32769,4096,295820,5377,98565,2601,5376,33417,4097,1296,297096,1285,35076,257,363303,1296,512]

theorem envBound17419 : H12AffineFastState.Bounded env17419 := by
  intro p hp
  have h : env17419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17418_17419 : H12AffineEnvironment.transform 12 2721 env17418 = env17419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2721 env17418 == env17419) = true)

theorem identity17419 : scanCanonicalize (H12AffineFastState.compose env17419 (packedSelected [8,12,13,28] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound17419 : packedSelected [8,12,13,28] rootPS < 2^1333 := by decide +kernel

def env17420 : List Nat := [2,4,8,16,32,16,128,256,1,1024,2048,4096,2208,4097,32768,65536,1297,262144,1025,32769,4096,295309,5377,98565,2088,5376,32904,4097,1296,297096,1285,35076,257,362790,1296,1]

theorem envBound17420 : H12AffineFastState.Bounded env17420 := by
  intro p hp
  have h : env17420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17419_17420 : H12AffineEnvironment.transform 8 1 env17419 = env17420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env17419 == env17420) = true)

theorem identity17420 : scanCanonicalize (H12AffineFastState.compose env17420 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 32905) := by decide +kernel

theorem selectedBound17420 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env17421 : List Nat := [2,4,8,16,32,16,128,256,1,1024,2048,4096,2208,4097,32768,65536,1297,32905,1025,32769,4096,260,5377,98565,2088,5376,32904,4097,1296,2049,1285,35076,257,68015,1296,1]

theorem envBound17421 : H12AffineFastState.Bounded env17421 := by
  intro p hp
  have h : env17421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17420_17421 : H12AffineEnvironment.transform 17 32905 env17420 = env17421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32905 env17420 == env17421) = true)

theorem identity17421 : scanCanonicalize (H12AffineFastState.compose env17421 (packedSelected [1,3] rootPS)) = affineNative (2^(14+1) ^^^ 7576) := by decide +kernel

theorem selectedBound17421 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17422 : List Nat := [2,4,8,16,32,16,128,256,1,1024,2048,4096,2208,4097,7576,65536,1297,7441,1025,7577,4096,260,5377,72861,2088,5376,7440,4097,1296,2049,1285,5276,257,68015,1296,1]

theorem envBound17422 : H12AffineFastState.Bounded env17422 := by
  intro p hp
  have h : env17422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17421_17422 : H12AffineEnvironment.transform 14 7576 env17421 = env17422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 7576 env17421 == env17422) = true)

def env17423 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,32768,65536,1296,262144,1025,32769,4096,4194304,5377,98564,8328,5377,4456708,4097,1297,1073741824,1284,1077979297,257,1073817871,1297,512]

theorem envBound17423 : H12AffineFastState.Bounded env17423 := by
  intro p hp
  have h : env17423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17415_17423 : H12AffineEnvironment.transform 5 17 env17415 = env17423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env17415 == env17423) = true)

theorem identity17423 : scanCanonicalize (H12AffineFastState.compose env17423 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 43048) := by decide +kernel

theorem selectedBound17423 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env17424 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,32768,65536,1296,43048,1025,32769,4096,4194304,5377,98564,8328,5377,4237612,4097,1297,1073741824,1284,1077979297,257,1073817871,1297,512]

theorem envBound17424 : H12AffineFastState.Bounded env17424 := by
  intro p hp
  have h : env17424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17423_17424 : H12AffineEnvironment.transform 17 43048 env17423 = env17424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43048 env17423 == env17424) = true)

theorem identity17424 : scanCanonicalize (H12AffineFastState.compose env17424 (packedSelected [10,12,13] rootPS)) = affineNative (2^(29+1) ^^^ 4196612) := by decide +kernel

theorem selectedBound17424 : packedSelected [10,12,13] rootPS < 2^1333 := by decide +kernel

def env17425 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,32768,65536,1296,43048,1025,32769,4096,4194304,5377,98564,8328,5377,4237612,4097,1297,4196612,1284,41381,257,4268043,1297,512]

theorem envBound17425 : H12AffineFastState.Bounded env17425 := by
  intro p hp
  have h : env17425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17424_17425 : H12AffineEnvironment.transform 29 4196612 env17424 = env17425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4196612 env17424 == env17425) = true)

theorem identity17425 : scanCanonicalize (H12AffineFastState.compose env17425 (packedSelected [5,8] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound17425 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env17426 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,4096,8192,4097,32768,65536,1296,43048,1025,32769,4096,4194304,5377,98564,8328,5377,4237612,4097,1297,4196612,1284,41381,257,4268043,1297,137]

theorem envBound17426 : H12AffineFastState.Bounded env17426 := by
  intro p hp
  have h : env17426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17425_17426 : H12AffineEnvironment.transform 8 137 env17425 = env17426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env17425 == env17426) = true)

theorem identity17426 : scanCanonicalize (H12AffineFastState.compose env17426 (packedSelected [1,10] rootPS)) = affineNative (2^(14+1) ^^^ 2081) := by decide +kernel

theorem selectedBound17426 : packedSelected [1,10] rootPS < 2^1333 := by decide +kernel

def env17427 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,4096,8192,4097,2081,65536,1296,8201,1025,2080,4096,4194304,5377,67877,8328,5377,4202765,4097,1297,4196612,1284,10628,257,4268043,1297,137]

theorem envBound17427 : H12AffineFastState.Bounded env17427 := by
  intro p hp
  have h : env17427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17426_17427 : H12AffineEnvironment.transform 14 2081 env17426 = env17427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2081 env17426 == env17427) = true)

def env17428 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,1296,8192,1297,2081,65536,1296,8201,1025,2080,1296,4194304,17,67877,8328,17,4202765,1297,1297,4196612,1284,10628,257,4268043,1297,137]

theorem envBound17428 : H12AffineFastState.Bounded env17428 := by
  intro p hp
  have h : env17428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17427_17428 : H12AffineEnvironment.transform 11 1296 env17427 = env17428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env17427 == env17428) = true)

theorem identity17428 : scanCanonicalize (H12AffineFastState.compose env17428 (packedSelected [1,3] rootPS)) = affineNative (2^(21+1) ^^^ 10508) := by decide +kernel

theorem selectedBound17428 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17429 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,1296,8192,1297,2081,65536,1296,8201,1025,2080,1296,10508,17,67877,8328,17,2049,1297,1297,8200,1284,10628,257,67847,1297,137]

theorem envBound17429 : H12AffineFastState.Bounded env17429 := by
  intro p hp
  have h : env17429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17428_17429 : H12AffineEnvironment.transform 21 10508 env17428 = env17429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10508 env17428 == env17429) = true)

def env17430 : List Nat := [2,4,8,16,32,17,128,256,137,272,2048,0,8192,1,2081,65536,0,8201,273,2080,0,10508,17,67877,8328,17,2049,1,1,8200,20,10628,257,67847,1,137]

theorem envBound17430 : H12AffineFastState.Bounded env17430 := by
  intro p hp
  have h : env17430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17429_17430 : H12AffineEnvironment.transform 9 272 env17429 = env17430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env17429 == env17430) = true)

theorem identity17430 : scanCanonicalize (H12AffineFastState.compose env17430 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound17430 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17431 : List Nat := [2,4,8,16,32,17,128,256,137,272,2048,0,268,1,2081,65536,0,261,273,2080,0,2048,17,67877,388,17,2049,1,1,260,20,2184,257,67847,1,137]

theorem envBound17431 : H12AffineFastState.Bounded env17431 := by
  intro p hp
  have h : env17431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17430_17431 : H12AffineEnvironment.transform 12 268 env17430 = env17431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env17430 == env17431) = true)

def env17432 : List Nat := [2,4,8,16,32,17,128,256,137,272,32,0,268,1,1,65536,0,261,273,0,0,32,17,65797,388,17,33,1,1,260,20,168,257,65831,1,137]

theorem envBound17432 : H12AffineFastState.Bounded env17432 := by
  intro p hp
  have h : env17432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17431_17432 : H12AffineEnvironment.transform 10 32 env17431 = env17432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env17431 == env17432) = true)

def env17433 : List Nat := [2,4,8,16,32,17,128,256,137,272,33,0,268,1,0,65536,0,261,273,1,0,33,17,65796,388,17,32,1,1,260,20,169,257,65830,1,137]

theorem envBound17433 : H12AffineFastState.Bounded env17433 := by
  intro p hp
  have h : env17433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17431_17433 : H12AffineEnvironment.transform 10 33 env17431 = env17433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env17431 == env17433) = true)

theorem identity17433 : scanCanonicalize (H12AffineFastState.compose env17433 (packedSelected [0,4] rootPS)) = affineNative (2^(15+1) ^^^ 399) := by decide +kernel

theorem selectedBound17433 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env17434 : List Nat := [2,4,8,16,32,17,128,256,137,272,33,0,268,1,0,399,0,261,273,1,0,33,17,139,388,17,32,1,1,260,20,169,257,169,1,137]

theorem envBound17434 : H12AffineFastState.Bounded env17434 := by
  intro p hp
  have h : env17434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17433_17434 : H12AffineEnvironment.transform 15 399 env17433 = env17434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 399 env17433 == env17434) = true)

theorem identity17434 : scanCanonicalize (H12AffineFastState.compose env17434 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound17434 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17435 : List Nat := [2,4,8,16,32,17,128,20,137,4,33,0,24,1,0,155,0,17,5,1,0,33,17,139,144,17,32,1,1,16,20,169,21,169,1,137]

theorem envBound17435 : H12AffineFastState.Bounded env17435 := by
  intro p hp
  have h : env17435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17434_17435 : H12AffineEnvironment.transform 7 20 env17434 = env17435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env17434 == env17435) = true)

def env17436 : List Nat := [2,4,8,16,0,17,128,20,137,4,1,0,24,1,0,155,0,17,5,1,0,1,17,139,144,17,0,1,1,16,20,137,21,137,1,137]

theorem envBound17436 : H12AffineFastState.Bounded env17436 := by
  intro p hp
  have h : env17436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17435_17436 : H12AffineEnvironment.transform 4 0 env17435 = env17436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17435 == env17436) = true)

theorem identity17436 : scanCanonicalize (H12AffineFastState.compose env17436 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound17436 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17437 : List Nat := [2,4,8,0,0,1,128,4,137,4,1,0,8,1,0,139,0,1,5,1,0,1,1,139,128,1,0,1,1,0,4,137,5,137,1,137]

theorem envBound17437 : H12AffineFastState.Bounded env17437 := by
  intro p hp
  have h : env17437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17436_17437 : H12AffineEnvironment.transform 3 0 env17436 = env17437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env17436 == env17437) = true)

def leafEnv17437 : List Nat := [2,4,8,0,0,1,128,4,137,4,1,0,8,1,0,139,0,1,5,1,0,1,1,139,4,128,1,1,0,1,1,0,4,137,5,137,4,2,1,137,0,0,1]

def active17437 : List Nat := [0,1,2,6]

def tree17437 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17437 : H12WitnessSearch.Good tree17437 := H12GlobalWitnessIndex.good

theorem leafIdentity17437 : H12AffineFastState.composeSystem env17437 rootObs = leafEnv17437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17437 rootObs == leafEnv17437) = true)

theorem terminalChecked17437 : H12PackedTerminal.terminalCheckFast leafEnv17437 active17437 tree17437 = true := by decide +kernel

def env17438 : List Nat := [2,4,8,16,1,17,128,20,137,4,0,0,24,1,0,155,0,17,5,1,0,0,17,139,144,17,1,1,1,16,20,136,21,136,1,137]

theorem envBound17438 : H12AffineFastState.Bounded env17438 := by
  intro p hp
  have h : env17438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17435_17438 : H12AffineEnvironment.transform 4 1 env17435 = env17438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env17435 == env17438) = true)

def leafEnv17438 : List Nat := [2,4,8,16,1,17,128,20,137,4,0,0,24,1,0,155,0,17,5,1,0,0,17,139,20,144,1,17,1,1,1,16,20,136,21,136,4,18,1,137,0,0,1]

def active17438 : List Nat := [0,1,2,3,6]

def tree17438 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17438 : H12WitnessSearch.Good tree17438 := H12GlobalWitnessIndex.good

theorem leafIdentity17438 : H12AffineFastState.composeSystem env17438 rootObs = leafEnv17438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17438 rootObs == leafEnv17438) = true)

theorem terminalChecked17438 : H12PackedTerminal.terminalCheckFast leafEnv17438 active17438 tree17438 = true := by decide +kernel

def env17439 : List Nat := [2,4,8,16,32,17,128,256,137,273,2048,1,8192,0,2081,65536,1,8201,272,2080,1,10508,17,67877,8328,17,2049,0,0,8200,21,10628,257,67847,0,137]

theorem envBound17439 : H12AffineFastState.Bounded env17439 := by
  intro p hp
  have h : env17439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17429_17439 : H12AffineEnvironment.transform 9 273 env17429 = env17439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env17429 == env17439) = true)

theorem identity17439 : scanCanonicalize (H12AffineFastState.compose env17439 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 10402) := by decide +kernel

theorem selectedBound17439 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17440 : List Nat := [2,4,8,16,32,17,128,256,137,273,2048,1,8192,0,2081,10402,1,8201,272,2080,1,10508,17,8583,8328,17,2049,0,0,8200,21,10628,257,8613,0,137]

theorem envBound17440 : H12AffineFastState.Bounded env17440 := by
  intro p hp
  have h : env17440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17439_17440 : H12AffineEnvironment.transform 15 10402 env17439 = env17440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 10402 env17439 == env17440) = true)

def env17441 : List Nat := [2,4,8,16,32,17,128,256,137,273,168,1,8192,0,137,8202,1,8201,272,136,1,8612,17,8583,8328,17,169,0,0,8200,21,8492,257,8613,0,137]

theorem envBound17441 : H12AffineFastState.Bounded env17441 := by
  intro p hp
  have h : env17441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17440_17441 : H12AffineEnvironment.transform 10 168 env17440 = env17441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 168 env17440 == env17441) = true)

def env17442 : List Nat := [2,4,8,16,32,17,128,256,137,273,168,1,128,0,137,138,1,137,272,136,1,292,17,263,8,17,169,0,0,136,21,428,257,293,0,137]

theorem envBound17442 : H12AffineFastState.Bounded env17442 := by
  intro p hp
  have h : env17442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17441_17442 : H12AffineEnvironment.transform 12 128 env17441 = env17442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 128 env17441 == env17442) = true)

theorem identity17442 : scanCanonicalize (H12AffineFastState.compose env17442 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound17442 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17443 : List Nat := [2,4,8,16,32,17,56,256,49,273,16,1,56,0,49,50,1,49,272,48,1,292,17,263,8,17,17,0,0,48,21,276,257,293,0,49]

theorem envBound17443 : H12AffineFastState.Bounded env17443 := by
  intro p hp
  have h : env17443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17442_17443 : H12AffineEnvironment.transform 6 56 env17442 = env17443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env17442 == env17443) = true)

def env17444 : List Nat := [2,4,8,16,0,17,24,256,17,273,16,1,24,0,17,18,1,17,272,16,1,260,17,263,8,17,17,0,0,16,21,276,257,261,0,17]

theorem envBound17444 : H12AffineFastState.Bounded env17444 := by
  intro p hp
  have h : env17444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17443_17444 : H12AffineEnvironment.transform 4 0 env17443 = env17444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17443 == env17444) = true)

def env17445 : List Nat := [2,4,8,0,0,1,8,256,1,257,0,1,8,0,1,2,1,1,256,0,1,260,1,263,8,1,1,0,0,0,5,260,257,261,0,1]

theorem envBound17445 : H12AffineFastState.Bounded env17445 := by
  intro p hp
  have h : env17445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17444_17445 : H12AffineEnvironment.transform 3 0 env17444 = env17445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env17444 == env17445) = true)

theorem identity17445 : scanCanonicalize (H12AffineFastState.compose env17445 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound17445 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env17446 : List Nat := [2,4,8,0,0,1,8,4,1,5,0,1,8,0,1,2,1,1,4,0,1,0,1,3,8,1,1,0,0,0,5,0,5,1,0,1]

theorem envBound17446 : H12AffineFastState.Bounded env17446 := by
  intro p hp
  have h : env17446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17445_17446 : H12AffineEnvironment.transform 7 4 env17445 = env17446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env17445 == env17446) = true)

def leafEnv17446 : List Nat := [2,4,8,0,0,1,8,4,1,5,0,1,8,0,1,2,1,1,4,0,1,0,1,3,5,8,1,1,1,0,0,0,5,0,5,1,4,3,0,1,0,1,1]

def active17446 : List Nat := [0,1,2]

def tree17446 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17446 : H12WitnessSearch.Good tree17446 := H12GlobalWitnessIndex.good

theorem leafIdentity17446 : H12AffineFastState.composeSystem env17446 rootObs = leafEnv17446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17446 rootObs == leafEnv17446) = true)

theorem terminalChecked17446 : H12PackedTerminal.terminalCheckFast leafEnv17446 active17446 tree17446 = true := by decide +kernel

def env17447 : List Nat := [2,4,8,1,0,0,9,256,0,256,1,1,9,0,0,3,1,0,257,1,1,260,0,263,8,0,0,0,0,1,4,261,257,261,0,0]

theorem envBound17447 : H12AffineFastState.Bounded env17447 := by
  intro p hp
  have h : env17447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17444_17447 : H12AffineEnvironment.transform 3 1 env17444 = env17447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env17444 == env17447) = true)

def env17448 : List Nat := [2,4,8,16,1,17,25,256,16,273,16,1,25,0,16,19,1,16,272,17,1,261,17,263,8,17,17,0,0,17,21,276,257,260,0,16]

theorem envBound17448 : H12AffineFastState.Bounded env17448 := by
  intro p hp
  have h : env17448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17443_17448 : H12AffineEnvironment.transform 4 1 env17443 = env17448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env17443 == env17448) = true)

theorem identity17448 : scanCanonicalize (H12AffineFastState.compose env17448 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound17448 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17449 : List Nat := [2,4,8,16,1,17,25,4,16,21,16,1,25,0,16,19,1,16,20,17,1,1,17,3,8,17,17,0,0,17,21,16,5,0,0,16]

theorem envBound17449 : H12AffineFastState.Bounded env17449 := by
  intro p hp
  have h : env17449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17448_17449 : H12AffineEnvironment.transform 7 4 env17448 = env17449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env17448 == env17449) = true)

theorem identity17449 : scanCanonicalize (H12AffineFastState.compose env17449 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound17449 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env17450 : List Nat := [2,4,8,1,1,0,8,4,1,4,1,1,8,0,1,2,1,1,5,0,1,1,0,3,8,0,0,0,0,0,4,1,5,0,0,1]

theorem envBound17450 : H12AffineFastState.Bounded env17450 := by
  intro p hp
  have h : env17450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17449_17450 : H12AffineEnvironment.transform 3 1 env17449 = env17450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env17449 == env17450) = true)

def leafEnv17450 : List Nat := [2,4,8,1,1,0,8,4,1,4,1,1,8,0,1,2,1,1,5,0,1,1,0,3,4,8,1,0,0,0,0,0,4,1,5,0,4,3,0,1,0,1,1]

def active17450 : List Nat := [0,1,2]

def tree17450 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17450 : H12WitnessSearch.Good tree17450 := H12GlobalWitnessIndex.good

theorem leafIdentity17450 : H12AffineFastState.composeSystem env17450 rootObs = leafEnv17450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17450 rootObs == leafEnv17450) = true)

theorem terminalChecked17450 : H12PackedTerminal.terminalCheckFast leafEnv17450 active17450 tree17450 = true := by decide +kernel

def env17451 : List Nat := [2,4,8,16,32,17,128,256,137,273,168,1,129,0,137,139,1,136,272,136,1,293,17,262,9,17,169,0,0,137,21,429,257,292,0,137]

theorem envBound17451 : H12AffineFastState.Bounded env17451 := by
  intro p hp
  have h : env17451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17441_17451 : H12AffineEnvironment.transform 12 129 env17441 = env17451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 129 env17441 == env17451) = true)

theorem identity17451 : scanCanonicalize (H12AffineFastState.compose env17451 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound17451 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17452 : List Nat := [2,4,8,16,32,17,24,256,17,273,48,1,25,0,17,19,1,16,272,16,1,293,17,262,9,17,49,0,0,17,21,309,257,292,0,17]

theorem envBound17452 : H12AffineFastState.Bounded env17452 := by
  intro p hp
  have h : env17452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17451_17452 : H12AffineEnvironment.transform 6 24 env17451 = env17452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env17451 == env17452) = true)

def env17453 : List Nat := [2,4,8,16,0,17,24,256,17,273,16,1,25,0,17,19,1,16,272,16,1,261,17,262,9,17,17,0,0,17,21,277,257,260,0,17]

theorem envBound17453 : H12AffineFastState.Bounded env17453 := by
  intro p hp
  have h : env17453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17452_17453 : H12AffineEnvironment.transform 4 0 env17452 = env17453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17452 == env17453) = true)

theorem identity17453 : scanCanonicalize (H12AffineFastState.compose env17453 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound17453 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17454 : List Nat := [2,4,8,0,0,1,8,256,1,257,0,1,9,0,1,3,1,0,256,0,1,261,1,262,9,1,1,0,0,1,5,261,257,260,0,1]

theorem envBound17454 : H12AffineFastState.Bounded env17454 := by
  intro p hp
  have h : env17454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17453_17454 : H12AffineEnvironment.transform 3 0 env17453 = env17454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env17453 == env17454) = true)

theorem identity17454 : scanCanonicalize (H12AffineFastState.compose env17454 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound17454 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env17455 : List Nat := [2,4,8,0,0,1,8,5,1,4,0,1,9,0,1,3,1,0,5,0,1,0,1,3,9,1,1,0,0,1,5,0,4,1,0,1]

theorem envBound17455 : H12AffineFastState.Bounded env17455 := by
  intro p hp
  have h : env17455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17454_17455 : H12AffineEnvironment.transform 7 5 env17454 = env17455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env17454 == env17455) = true)

def leafEnv17455 : List Nat := [2,4,8,0,0,1,8,5,1,4,0,1,9,0,1,3,1,0,5,0,1,0,1,3,5,9,1,1,1,0,0,1,5,0,4,1,4,2,0,1,0,1,1]

def active17455 : List Nat := [0,1,2]

def tree17455 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17455 : H12WitnessSearch.Good tree17455 := H12GlobalWitnessIndex.good

theorem leafIdentity17455 : H12AffineFastState.composeSystem env17455 rootObs = leafEnv17455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17455 rootObs == leafEnv17455) = true)

theorem terminalChecked17455 : H12PackedTerminal.terminalCheckFast leafEnv17455 active17455 tree17455 = true := by decide +kernel

def env17456 : List Nat := [2,4,8,16,1,17,24,256,17,273,17,1,25,0,17,19,1,16,272,16,1,260,17,262,9,17,16,0,0,17,21,276,257,261,0,17]

theorem envBound17456 : H12AffineFastState.Bounded env17456 := by
  intro p hp
  have h : env17456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17452_17456 : H12AffineEnvironment.transform 4 1 env17452 = env17456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env17452 == env17456) = true)

theorem identity17456 : scanCanonicalize (H12AffineFastState.compose env17456 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound17456 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17457 : List Nat := [2,4,8,16,1,17,24,20,17,5,17,1,25,0,17,19,1,16,4,16,1,16,17,18,9,17,16,0,0,17,21,0,21,17,0,17]

theorem envBound17457 : H12AffineFastState.Bounded env17457 := by
  intro p hp
  have h : env17457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17456_17457 : H12AffineEnvironment.transform 7 20 env17456 = env17457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env17456 == env17457) = true)

def env17458 : List Nat := [2,4,8,16,32,17,128,256,137,273,169,1,8192,0,136,8203,1,8201,272,137,1,8613,17,8583,8328,17,168,0,0,8200,21,8493,257,8613,0,137]

theorem envBound17458 : H12AffineFastState.Bounded env17458 := by
  intro p hp
  have h : env17458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17440_17458 : H12AffineEnvironment.transform 10 169 env17440 = env17458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 169 env17440 == env17458) = true)

def env17459 : List Nat := [2,4,8,16,32,17,128,256,137,273,169,1,128,0,136,139,1,137,272,137,1,293,17,263,8,17,168,0,0,136,21,429,257,293,0,137]

theorem envBound17459 : H12AffineFastState.Bounded env17459 := by
  intro p hp
  have h : env17459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17458_17459 : H12AffineEnvironment.transform 12 128 env17458 = env17459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 128 env17458 == env17459) = true)

theorem identity17459 : scanCanonicalize (H12AffineFastState.compose env17459 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 157) := by decide +kernel

theorem selectedBound17459 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17460 : List Nat := [2,4,8,16,32,17,128,157,137,140,169,1,128,0,136,139,1,137,141,137,1,184,17,154,8,17,168,0,0,136,21,48,156,184,0,137]

theorem envBound17460 : H12AffineFastState.Bounded env17460 := by
  intro p hp
  have h : env17460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17459_17460 : H12AffineEnvironment.transform 7 157 env17459 = env17460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 157 env17459 == env17460) = true)

def env17461 : List Nat := [2,4,8,16,0,17,128,157,137,140,137,1,128,0,136,139,1,137,141,137,1,152,17,154,8,17,136,0,0,136,21,16,156,152,0,137]

theorem envBound17461 : H12AffineFastState.Bounded env17461 := by
  intro p hp
  have h : env17461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17460_17461 : H12AffineEnvironment.transform 4 0 env17460 = env17461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17460 == env17461) = true)

theorem identity17461 : scanCanonicalize (H12AffineFastState.compose env17461 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound17461 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17462 : List Nat := [2,4,8,16,0,17,9,20,0,5,0,1,9,0,1,2,1,0,4,0,1,17,17,19,8,17,1,0,0,1,21,16,21,17,0,0]

theorem envBound17462 : H12AffineFastState.Bounded env17462 := by
  intro p hp
  have h : env17462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17461_17462 : H12AffineEnvironment.transform 6 9 env17461 = env17462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env17461 == env17462) = true)

theorem identity17462 : scanCanonicalize (H12AffineFastState.compose env17462 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound17462 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env17463 : List Nat := [2,4,8,1,0,0,9,5,0,5,0,1,9,0,1,2,1,0,4,0,1,0,0,2,8,0,1,0,0,1,4,1,4,0,0,0]

theorem envBound17463 : H12AffineFastState.Bounded env17463 := by
  intro p hp
  have h : env17463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17462_17463 : H12AffineEnvironment.transform 3 1 env17462 = env17463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env17462 == env17463) = true)

def leafEnv17463 : List Nat := [2,4,8,1,0,0,9,5,0,5,0,1,9,0,1,2,1,0,4,0,1,0,0,2,4,8,1,0,1,0,0,1,4,1,4,0,4,2,0,0,0,1,1]

def active17463 : List Nat := [0,1,2]

def tree17463 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17463 : H12WitnessSearch.Good tree17463 := H12GlobalWitnessIndex.good

theorem leafIdentity17463 : H12AffineFastState.composeSystem env17463 rootObs = leafEnv17463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17463 rootObs == leafEnv17463) = true)

theorem terminalChecked17463 : H12PackedTerminal.terminalCheckFast leafEnv17463 active17463 tree17463 = true := by decide +kernel

def env17464 : List Nat := [2,4,8,16,1,17,128,157,137,140,136,1,128,0,136,139,1,137,141,137,1,153,17,154,8,17,137,0,0,136,21,17,156,153,0,137]

theorem envBound17464 : H12AffineFastState.Bounded env17464 := by
  intro p hp
  have h : env17464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17460_17464 : H12AffineEnvironment.transform 4 1 env17460 = env17464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env17460 == env17464) = true)

theorem identity17464 : scanCanonicalize (H12AffineFastState.compose env17464 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound17464 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17465 : List Nat := [2,4,8,0,1,1,128,141,137,140,136,1,128,0,136,139,1,137,141,137,1,137,1,138,8,1,137,0,0,136,5,1,140,137,0,137]

theorem envBound17465 : H12AffineFastState.Bounded env17465 := by
  intro p hp
  have h : env17465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17464_17465 : H12AffineEnvironment.transform 3 0 env17464 = env17465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env17464 == env17465) = true)

def env17466 : List Nat := [2,4,8,16,32,17,128,256,137,273,169,1,129,0,136,138,1,136,272,137,1,292,17,262,9,17,168,0,0,137,21,428,257,292,0,137]

theorem envBound17466 : H12AffineFastState.Bounded env17466 := by
  intro p hp
  have h : env17466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17458_17466 : H12AffineEnvironment.transform 12 129 env17458 = env17466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 129 env17458 == env17466) = true)

theorem identity17466 : scanCanonicalize (H12AffineFastState.compose env17466 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 188) := by decide +kernel

theorem selectedBound17466 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17467 : List Nat := [2,4,8,16,32,17,128,188,137,173,169,1,129,0,136,138,1,136,172,137,1,152,17,186,9,17,168,0,0,137,21,16,189,152,0,137]

theorem envBound17467 : H12AffineFastState.Bounded env17467 := by
  intro p hp
  have h : env17467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17466_17467 : H12AffineEnvironment.transform 7 188 env17466 = env17467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 188 env17466 == env17467) = true)

def env17468 : List Nat := [2,4,8,16,0,17,128,156,137,141,137,1,129,0,136,138,1,136,140,137,1,152,17,154,9,17,136,0,0,137,21,16,157,152,0,137]

theorem envBound17468 : H12AffineFastState.Bounded env17468 := by
  intro p hp
  have h : env17468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17467_17468 : H12AffineEnvironment.transform 4 0 env17467 = env17468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17467 == env17468) = true)

def env17469 : List Nat := [2,4,8,0,0,1,128,140,137,141,137,1,129,0,136,138,1,136,140,137,1,136,1,138,9,1,136,0,0,137,5,0,141,136,0,137]

theorem envBound17469 : H12AffineFastState.Bounded env17469 := by
  intro p hp
  have h : env17469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17468_17469 : H12AffineEnvironment.transform 3 0 env17468 = env17469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env17468 == env17469) = true)

def env17470 : List Nat := [2,4,8,1,0,0,128,141,137,141,137,1,129,0,136,138,1,136,140,137,1,137,0,139,9,0,136,0,0,137,4,1,140,137,0,137]

theorem envBound17470 : H12AffineFastState.Bounded env17470 := by
  intro p hp
  have h : env17470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17468_17470 : H12AffineEnvironment.transform 3 1 env17468 = env17470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env17468 == env17470) = true)

theorem identity17470 : scanCanonicalize (H12AffineFastState.compose env17470 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound17470 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env17471 : List Nat := [2,4,8,1,0,0,9,4,0,4,0,1,8,0,1,3,1,1,5,0,1,0,0,2,9,0,1,0,0,0,4,1,5,0,0,0]

theorem envBound17471 : H12AffineFastState.Bounded env17471 := by
  intro p hp
  have h : env17471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17470_17471 : H12AffineEnvironment.transform 6 9 env17470 = env17471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env17470 == env17471) = true)

def leafEnv17471 : List Nat := [2,4,8,1,0,0,9,4,0,4,0,1,8,0,1,3,1,1,5,0,1,0,0,2,4,9,1,0,1,0,0,0,4,1,5,0,4,3,0,0,0,1,1]

def active17471 : List Nat := [0,1,2]

def tree17471 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17471 : H12WitnessSearch.Good tree17471 := H12GlobalWitnessIndex.good

theorem leafIdentity17471 : H12AffineFastState.composeSystem env17471 rootObs = leafEnv17471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17471 rootObs == leafEnv17471) = true)

theorem terminalChecked17471 : H12PackedTerminal.terminalCheckFast leafEnv17471 active17471 tree17471 = true := by decide +kernel

def env17472 : List Nat := [2,4,8,16,1,17,128,157,137,140,136,1,129,0,136,138,1,136,141,137,1,152,17,155,9,17,137,0,0,137,21,16,156,152,0,137]

theorem envBound17472 : H12AffineFastState.Bounded env17472 := by
  intro p hp
  have h : env17472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17467_17472 : H12AffineEnvironment.transform 4 1 env17467 = env17472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env17467 == env17472) = true)

theorem identity17472 : scanCanonicalize (H12AffineFastState.compose env17472 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound17472 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17473 : List Nat := [2,4,8,16,1,17,25,4,16,21,17,1,24,0,17,19,1,17,20,16,1,1,17,2,9,17,16,0,0,16,21,16,5,1,0,16]

theorem envBound17473 : H12AffineFastState.Bounded env17473 := by
  intro p hp
  have h : env17473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17472_17473 : H12AffineEnvironment.transform 6 25 env17472 = env17473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env17472 == env17473) = true)

theorem identity17473 : scanCanonicalize (H12AffineFastState.compose env17473 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound17473 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env17474 : List Nat := [2,4,8,0,1,1,9,4,0,5,1,1,8,0,1,3,1,1,4,0,1,1,1,2,9,1,0,0,0,0,5,0,5,1,0,0]

theorem envBound17474 : H12AffineFastState.Bounded env17474 := by
  intro p hp
  have h : env17474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17473_17474 : H12AffineEnvironment.transform 3 0 env17473 = env17474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env17473 == env17474) = true)

def leafEnv17474 : List Nat := [2,4,8,0,1,1,9,4,0,5,1,1,8,0,1,3,1,1,4,0,1,1,1,2,5,9,1,1,0,0,0,0,5,0,5,1,4,3,0,0,0,1,1]

def active17474 : List Nat := [0,1,2]

def tree17474 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17474 : H12WitnessSearch.Good tree17474 := H12GlobalWitnessIndex.good

theorem leafIdentity17474 : H12AffineFastState.composeSystem env17474 rootObs = leafEnv17474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17474 rootObs == leafEnv17474) = true)

theorem terminalChecked17474 : H12PackedTerminal.terminalCheckFast leafEnv17474 active17474 tree17474 = true := by decide +kernel

def env17475 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,1297,8192,1296,2081,65536,1296,8201,1025,2080,1297,4194304,16,67877,8328,16,4202765,1296,1297,4196612,1284,10628,257,4268043,1297,137]

theorem envBound17475 : H12AffineFastState.Bounded env17475 := by
  intro p hp
  have h : env17475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17427_17475 : H12AffineEnvironment.transform 11 1297 env17427 = env17475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env17427 == env17475) = true)

theorem identity17475 : scanCanonicalize (H12AffineFastState.compose env17475 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 2056) := by decide +kernel

theorem selectedBound17475 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17476 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,1297,2056,1296,2081,65536,1296,2049,1025,2080,1297,4194304,16,67877,2176,16,4196613,1296,1297,4196612,1284,396,257,4261891,1297,137]

theorem envBound17476 : H12AffineFastState.Bounded env17476 := by
  intro p hp
  have h : env17476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17475_17476 : H12AffineEnvironment.transform 12 2056 env17475 = env17476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2056 env17475 == env17476) = true)

theorem identity17476 : scanCanonicalize (H12AffineFastState.compose env17476 (packedSelected [5] rootPS)) = affineNative (2^(21+1) ^^^ 67754) := by decide +kernel

theorem selectedBound17476 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env17477 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,1297,2056,1296,2081,65536,1296,2049,1025,2080,1297,67754,16,67877,2176,16,65967,1296,1297,65966,1284,396,257,169,1297,137]

theorem envBound17477 : H12AffineFastState.Bounded env17477 := by
  intro p hp
  have h : env17477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17476_17477 : H12AffineEnvironment.transform 21 67754 env17476 = env17477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 67754 env17476 == env17477) = true)

theorem identity17477 : scanCanonicalize (H12AffineFastState.compose env17477 (packedSelected [0,6] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound17477 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env17478 : List Nat := [2,4,8,16,32,17,128,5,137,1024,2048,1044,2056,1045,2081,65536,1045,2049,1025,2080,1044,67754,16,67616,2176,16,65706,1045,1044,65707,1025,137,4,169,1044,137]

theorem envBound17478 : H12AffineFastState.Bounded env17478 := by
  intro p hp
  have h : env17478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17477_17478 : H12AffineEnvironment.transform 7 5 env17477 = env17478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env17477 == env17478) = true)

theorem identity17478 : scanCanonicalize (H12AffineFastState.compose env17478 (packedSelected [0,7] rootPS)) = affineNative (2^(15+1) ^^^ 2218) := by decide +kernel

theorem selectedBound17478 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env17479 : List Nat := [2,4,8,16,32,17,128,5,137,1024,2048,1044,2056,1045,2081,2218,1045,2049,1025,2080,1044,0,16,138,2176,16,2048,1045,1044,2049,1025,137,4,169,1044,137]

theorem envBound17479 : H12AffineFastState.Bounded env17479 := by
  intro p hp
  have h : env17479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17478_17479 : H12AffineEnvironment.transform 15 2218 env17478 = env17479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2218 env17478 == env17479) = true)

theorem identity17479 : scanCanonicalize (H12AffineFastState.compose env17479 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1213) := by decide +kernel

theorem selectedBound17479 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17480 : List Nat := [2,4,8,16,32,17,128,5,137,1024,1213,1044,1205,1045,1180,1047,1045,1212,1025,1181,1044,0,16,138,1085,16,1213,1045,1044,1212,1025,137,4,169,1044,137]

theorem envBound17480 : H12AffineFastState.Bounded env17480 := by
  intro p hp
  have h : env17480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17479_17480 : H12AffineEnvironment.transform 10 1213 env17479 = env17480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1213 env17479 == env17480) = true)

def env17481 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,4194304,672833,774164,8328,147473,134217728,541696,676865,1073741824,151572,4294967296,525569,4299935934,139351381,512]

theorem envBound17481 : H12AffineFastState.Bounded env17481 := by
  intro p hp
  have h : env17481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17179_17481 : H12AffineEnvironment.transform 22 672833 env17179 = env17481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 672833 env17179 == env17481) = true)

theorem identity17481 : scanCanonicalize (H12AffineFastState.compose env17481 (packedSelected [4,9,16] rootPS)) = affineNative (2^(16+1) ^^^ 21777) := by decide +kernel

theorem selectedBound17481 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env17482 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,21777,262144,524288,32769,4096,4194304,528720,623877,8328,5376,134217728,541696,524560,1073741824,1285,4294967296,525569,4299785647,139198532,512]

theorem envBound17482 : H12AffineFastState.Bounded env17482 := by
  intro p hp
  have h : env17482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17481_17482 : H12AffineEnvironment.transform 16 21777 env17481 = env17482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 21777 env17481 == env17482) = true)

theorem identity17482 : scanCanonicalize (H12AffineFastState.compose env17482 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(29+1) ^^^ 135105934) := by decide +kernel

theorem selectedBound17482 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env17483 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,21777,262144,524288,32769,4096,4194304,528720,623877,8328,5376,134217728,541696,524560,135105934,1285,4294967296,525569,4299785647,139198532,512]

theorem envBound17483 : H12AffineFastState.Bounded env17483 := by
  intro p hp
  have h : env17483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17482_17483 : H12AffineEnvironment.transform 29 135105934 env17482 = env17483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 135105934 env17482 == env17483) = true)

theorem identity17483 : scanCanonicalize (H12AffineFastState.compose env17483 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(26+1) ^^^ 4982021) := by decide +kernel

theorem selectedBound17483 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env17484 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,21777,262144,524288,32769,4096,4194304,528720,623877,8328,5376,4982021,541696,524560,4294795,1285,4294967296,525569,4299785647,1345,512]

theorem envBound17484 : H12AffineFastState.Bounded env17484 := by
  intro p hp
  have h : env17484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17483_17484 : H12AffineEnvironment.transform 26 4982021 env17483 = env17484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 4982021 env17483 == env17484) = true)

theorem identity17484 : scanCanonicalize (H12AffineFastState.compose env17484 (packedSelected [13,21] rootPS)) = affineNative (2^(18+1) ^^^ 62812) := by decide +kernel

theorem selectedBound17484 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env17485 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,21777,262144,62812,32769,4096,4194304,58380,94297,8328,5376,4517977,45404,62540,4294795,1285,4294967296,61533,4299256051,1345,512]

theorem envBound17485 : H12AffineFastState.Bounded env17485 := by
  intro p hp
  have h : env17485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17484_17485 : H12AffineEnvironment.transform 18 62812 env17484 = env17485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 62812 env17484 == env17485) = true)

def env17486 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,1345,262144,42252,32769,4096,4194304,46172,73737,8328,5376,4497417,45404,42012,4294795,1285,4294967296,40973,4299235491,1345,512]

theorem envBound17486 : H12AffineFastState.Bounded env17486 := by
  intro p hp
  have h : env17486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17485_17486 : H12AffineEnvironment.transform 13 4176 env17485 = env17486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env17485 == env17486) = true)

theorem identity17486 : scanCanonicalize (H12AffineFastState.compose env17486 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 4273587) := by decide +kernel

theorem selectedBound17486 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env17487 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,1345,262144,42252,32769,4096,4194304,46172,73737,8328,5376,4497417,45404,42012,4294795,1285,4273587,40973,5392,1345,512]

theorem envBound17487 : H12AffineFastState.Bounded env17487 := by
  intro p hp
  have h : env17487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17486_17487 : H12AffineEnvironment.transform 31 4273587 env17486 = env17487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 4273587 env17486 == env17487) = true)

theorem identity17487 : scanCanonicalize (H12AffineFastState.compose env17487 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 74283) := by decide +kernel

theorem selectedBound17487 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env17488 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,1345,262144,42252,32769,4096,74283,46172,73737,8328,5376,360994,45404,42012,43680,1285,6040,40973,5392,1345,512]

theorem envBound17488 : H12AffineFastState.Bounded env17488 := by
  intro p hp
  have h : env17488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17487_17488 : H12AffineEnvironment.transform 21 74283 env17487 = env17488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 74283 env17487 == env17488) = true)

theorem identity17488 : scanCanonicalize (H12AffineFastState.compose env17488 (packedSelected [0,7,20] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound17488 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env17489 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1296,8192,1344,32768,65536,1345,262144,42252,32769,1296,74283,41292,73737,8328,16,360994,42060,42012,43680,1285,648,40973,0,1345,512]

theorem envBound17489 : H12AffineFastState.Bounded env17489 := by
  intro p hp
  have h : env17489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17488_17489 : H12AffineEnvironment.transform 11 1296 env17488 = env17489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env17488 == env17489) = true)

theorem identity17489 : scanCanonicalize (H12AffineFastState.compose env17489 (packedSelected [3,5,8,13,24] rootPS)) = affineNative (2^(14+1) ^^^ 2170) := by decide +kernel

theorem selectedBound17489 : packedSelected [3,5,8,13,24] rootPS < 2^1333 := by decide +kernel

def env17490 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1296,8192,1344,2170,65536,1345,262144,11638,2171,1296,74283,10550,73737,8328,16,330328,11318,11366,8922,1285,648,10359,0,1345,512]

theorem envBound17490 : H12AffineFastState.Bounded env17490 := by
  intro p hp
  have h : env17490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17489_17490 : H12AffineEnvironment.transform 14 2170 env17489 = env17490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2170 env17489 == env17490) = true)

def env17491 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,1344,262144,42253,32769,4096,4194304,46173,73736,8328,5376,4497416,45404,42013,4294795,1285,4294967296,40972,4299235490,1345,512]

theorem envBound17491 : H12AffineFastState.Bounded env17491 := by
  intro p hp
  have h : env17491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17485_17491 : H12AffineEnvironment.transform 13 4177 env17485 = env17491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env17485 == env17491) = true)

theorem identity17491 : scanCanonicalize (H12AffineFastState.compose env17491 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 74031) := by decide +kernel

theorem selectedBound17491 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env17492 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,1344,262144,42253,32769,4096,4194304,46173,73736,8328,5376,4497416,45404,42013,4294795,1285,74031,40972,4194701,1345,512]

theorem envBound17492 : H12AffineFastState.Bounded env17492 := by
  intro p hp
  have h : env17492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17491_17492 : H12AffineEnvironment.transform 31 74031 env17491 = env17492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 74031 env17491 == env17492) = true)

theorem identity17492 : scanCanonicalize (H12AffineFastState.compose env17492 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound17492 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env17493 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,4177,32768,65536,1344,262144,42253,32769,4096,4194304,46173,73736,8328,5376,4497416,45404,42013,4294795,1285,74031,40972,4194701,1345,137]

theorem envBound17493 : H12AffineFastState.Bounded env17493 := by
  intro p hp
  have h : env17493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17492_17493 : H12AffineEnvironment.transform 8 137 env17492 = env17493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env17492 == env17493) = true)

theorem identity17493 : scanCanonicalize (H12AffineFastState.compose env17493 (packedSelected [3,5,24] rootPS)) = affineNative (2^(17+1) ^^^ 32768) := by decide +kernel

theorem selectedBound17493 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env17494 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,4177,32768,65536,1344,32768,42253,32769,4096,4194304,46173,73736,8328,5376,4202504,45404,42013,4294795,1285,74031,40972,4194701,1345,137]

theorem envBound17494 : H12AffineFastState.Bounded env17494 := by
  intro p hp
  have h : env17494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17493_17494 : H12AffineEnvironment.transform 17 32768 env17493 = env17494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32768 env17493 == env17494) = true)

theorem identity17494 : scanCanonicalize (H12AffineFastState.compose env17494 (packedSelected [7] rootPS)) = affineNative (2^(21+1) ^^^ 261) := by decide +kernel

theorem selectedBound17494 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env17495 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,4177,32768,65536,1344,32768,42253,32769,4096,261,46173,73736,8328,5376,8461,45404,42013,100750,1285,74031,40972,136,1345,137]

theorem envBound17495 : H12AffineFastState.Bounded env17495 := by
  intro p hp
  have h : env17495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17494_17495 : H12AffineEnvironment.transform 21 261 env17494 = env17495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 261 env17494 == env17495) = true)

theorem identity17495 : scanCanonicalize (H12AffineFastState.compose env17495 (packedSelected [1,12,13] rootPS)) = affineNative (2^(15+1) ^^^ 2219) := by decide +kernel

theorem selectedBound17495 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env17496 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,4177,32768,2219,1344,32768,42253,32769,4096,261,46173,10403,8328,5376,8461,45404,42013,33061,1285,10628,40972,136,1345,137]

theorem envBound17496 : H12AffineFastState.Bounded env17496 := by
  intro p hp
  have h : env17496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17495_17496 : H12AffineEnvironment.transform 15 2219 env17495 = env17496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2219 env17495 == env17496) = true)

theorem identity17496 : scanCanonicalize (H12AffineFastState.compose env17496 (packedSelected [0,1,2,3,4,8,11] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound17496 : packedSelected [0,1,2,3,4,8,11] rootPS < 2^1333 := by decide +kernel

def env17497 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,4177,8460,2219,1344,8460,1025,8461,4096,261,5457,10403,8328,5376,8461,4176,1297,8233,1285,10628,256,136,1345,137]

theorem envBound17497 : H12AffineFastState.Bounded env17497 := by
  intro p hp
  have h : env17497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17496_17497 : H12AffineEnvironment.transform 14 8460 env17496 = env17497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env17496 == env17497) = true)

theorem identity17497 : scanCanonicalize (H12AffineFastState.compose env17497 (packedSelected [2,4] rootPS)) = affineNative (2^(11+1) ^^^ 1077) := by decide +kernel

theorem selectedBound17497 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env17498 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1077,8192,1124,8460,2219,1344,8460,1025,8461,1077,261,356,10403,8328,309,8461,1125,1297,8233,1285,10628,256,136,1345,137]

theorem envBound17498 : H12AffineFastState.Bounded env17498 := by
  intro p hp
  have h : env17498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17497_17498 : H12AffineEnvironment.transform 11 1077 env17497 = env17498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1077 env17497 == env17498) = true)

theorem identity17498 : scanCanonicalize (H12AffineFastState.compose env17498 (packedSelected [1,3,8] rootPS)) = affineNative (2^(12+1) ^^^ 2088) := by decide +kernel

theorem selectedBound17498 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env17499 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1077,2088,1124,2340,2219,1344,2340,1025,2341,1077,261,356,139,2208,309,2341,1125,1297,2049,1285,428,256,136,1345,137]

theorem envBound17499 : H12AffineFastState.Bounded env17499 := by
  intro p hp
  have h : env17499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17498_17499 : H12AffineEnvironment.transform 12 2088 env17498 = env17499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2088 env17498 == env17499) = true)

def env17500 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,4194304,8388608,16777216,8328,8914000,134217728,8519745,676864,1073741824,25412672,4294967296,8536385,4315938986,164610304,512]

theorem envBound17500 : H12AffineFastState.Bounded env17500 := by
  intro p hp
  have h : env17500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17177_17500 : H12AffineEnvironment.transform 20 4097 env17177 = env17500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env17177 == env17500) = true)

theorem identity17500 : scanCanonicalize (H12AffineFastState.compose env17500 (packedSelected [14] rootPS)) = affineNative (2^(26+1) ^^^ 4609044) := by decide +kernel

theorem selectedBound17500 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env17501 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,4194304,8388608,16777216,8328,8914000,4609044,8519745,676864,1073741824,25412672,4294967296,8536385,4315938986,25793812,512]

theorem envBound17501 : H12AffineFastState.Bounded env17501 := by
  intro p hp
  have h : env17501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17500_17501 : H12AffineEnvironment.transform 26 4609044 env17500 = env17501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 4609044 env17500 == env17501) = true)

def env17502 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,4194304,17664,16777216,8328,541008,4609044,148801,676864,1073741824,17006912,4294967296,132161,4315938986,17420308,512]

theorem envBound17502 : H12AffineFastState.Bounded env17502 := by
  intro p hp
  have h : env17502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17501_17502 : H12AffineEnvironment.transform 22 17664 env17501 = env17502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17664 env17501 == env17502) = true)

def env17503 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,524288,32769,4097,4194304,17664,16777216,8328,541008,4477268,16385,545088,1073741824,16876544,4294967296,257,4315938986,17420308,512]

theorem envBound17503 : H12AffineFastState.Bounded env17503 := by
  intro p hp
  have h : env17503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17502_17503 : H12AffineEnvironment.transform 16 1344 env17502 = env17503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env17502 == env17503) = true)

def env17504 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32769,4097,4194304,17664,16777216,8328,541008,4477269,16384,545089,1073741824,16876545,4294967296,256,4315938986,17420308,512]

theorem envBound17504 : H12AffineFastState.Bounded env17504 := by
  intro p hp
  have h : env17504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17502_17504 : H12AffineEnvironment.transform 16 1345 env17502 = env17504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env17502 == env17504) = true)

theorem identity17504 : scanCanonicalize (H12AffineFastState.compose env17504 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(18+1) ^^^ 21585) := by decide +kernel

theorem selectedBound17504 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env17505 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,21585,32769,4097,4194304,17664,16777216,8328,5377,4477269,16384,1296,1073741824,16876545,4294967296,256,4315938986,16876613,512]

theorem envBound17505 : H12AffineFastState.Bounded env17505 := by
  intro p hp
  have h : env17505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17504_17505 : H12AffineEnvironment.transform 18 21585 env17504 = env17505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21585 env17504 == env17505) = true)

theorem identity17505 : scanCanonicalize (H12AffineFastState.compose env17505 (packedSelected [0,4,7,9,16,20] rootPS)) = affineNative (2^(13+1) ^^^ 1296) := by decide +kernel

theorem selectedBound17505 : packedSelected [0,4,7,9,16,20] rootPS < 2^1333 := by decide +kernel

def env17506 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1345,262144,4417,32769,4097,4194304,16,16777216,8328,5377,4461637,1296,1296,1073741824,16876545,4294967296,256,4315938986,16876613,512]

theorem envBound17506 : H12AffineFastState.Bounded env17506 := by
  intro p hp
  have h : env17506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17505_17506 : H12AffineEnvironment.transform 13 1296 env17505 = env17506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env17505 == env17506) = true)

theorem identity17506 : scanCanonicalize (H12AffineFastState.compose env17506 (packedSelected [4,16,22] rootPS)) = affineNative (2^(11+1) ^^^ 1345) := by decide +kernel

theorem selectedBound17506 : packedSelected [4,16,22] rootPS < 2^1333 := by decide +kernel

def env17507 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,65536,1345,262144,1024,32769,1344,4194304,16,16777216,8328,64,4456708,1296,1296,1073741824,16876545,4294967296,256,4315938986,16876613,512]

theorem envBound17507 : H12AffineFastState.Bounded env17507 := by
  intro p hp
  have h : env17507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17506_17507 : H12AffineEnvironment.transform 11 1345 env17506 = env17507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env17506 == env17507) = true)

theorem identity17507 : scanCanonicalize (H12AffineFastState.compose env17507 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(31+1) ^^^ 4194440) := by decide +kernel

theorem selectedBound17507 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env17508 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,65536,1345,262144,1024,32769,1344,4194304,16,16777216,8328,64,4456708,1296,1296,1073741824,16876545,4194440,256,16777250,16876613,512]

theorem envBound17508 : H12AffineFastState.Bounded env17508 := by
  intro p hp
  have h : env17508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17507_17508 : H12AffineEnvironment.transform 31 4194440 env17507 = env17508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 4194440 env17507 == env17508) = true)

def env17509 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,65536,1345,8832,1024,32769,1344,4194304,16,16777216,8328,64,4203396,1296,1296,1073741824,16876545,4194440,256,16777250,16876613,512]

theorem envBound17509 : H12AffineFastState.Bounded env17509 := by
  intro p hp
  have h : env17509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17508_17509 : H12AffineEnvironment.transform 17 8832 env17508 = env17509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8832 env17508 == env17509) = true)

theorem identity17509 : scanCanonicalize (H12AffineFastState.compose env17509 (packedSelected [3,5,24] rootPS)) = affineNative (2^(21+1) ^^^ 8580) := by decide +kernel

theorem selectedBound17509 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env17510 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,65536,1345,8832,1024,32769,1344,8580,16,16777216,8328,64,512,1296,1296,1073741824,16876545,8460,256,16777250,16876613,512]

theorem envBound17510 : H12AffineFastState.Bounded env17510 := by
  intro p hp
  have h : env17510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17509_17510 : H12AffineEnvironment.transform 21 8580 env17509 = env17510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8580 env17509 == env17510) = true)

def env17511 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,65536,1345,8832,1024,32769,1344,8580,16,98304,8328,64,512,1296,1296,1073741824,1025,8460,256,98338,1093,512]

theorem envBound17511 : H12AffineFastState.Bounded env17511 := by
  intro p hp
  have h : env17511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17510_17511 : H12AffineEnvironment.transform 23 98304 env17510 = env17511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98304 env17510 == env17511) = true)

theorem identity17511 : scanCanonicalize (H12AffineFastState.compose env17511 (packedSelected [1,8,28] rootPS)) = affineNative (2^(14+1) ^^^ 261) := by decide +kernel

theorem selectedBound17511 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env17512 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,261,65536,1345,8832,1024,260,1344,8580,16,65797,8328,64,512,1296,1296,1073741824,1025,8460,256,65831,1093,512]

theorem envBound17512 : H12AffineFastState.Bounded env17512 := by
  intro p hp
  have h : env17512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17511_17512 : H12AffineEnvironment.transform 14 261 env17511 = env17512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 261 env17511 == env17512) = true)

def env17513 : List Nat := [2,4,8,16,32,64,128,4,512,1024,2048,1093,8192,1044,1,65536,1093,8832,1024,0,1092,8320,16,65537,8328,64,512,1044,1044,1073741824,1025,8200,4,65571,1093,512]

theorem envBound17513 : H12AffineFastState.Bounded env17513 := by
  intro p hp
  have h : env17513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17512_17513 : H12AffineEnvironment.transform 7 4 env17512 = env17513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env17512 == env17513) = true)

theorem identity17513 : scanCanonicalize (H12AffineFastState.compose env17513 (packedSelected [6] rootPS)) = affineNative (2^(29+1) ^^^ 3108) := by decide +kernel

theorem selectedBound17513 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env17514 : List Nat := [2,4,8,16,32,64,128,4,512,1024,2048,1093,8192,1044,1,65536,1093,8832,1024,0,1092,8320,16,65537,8328,64,512,1044,1044,3108,1025,8200,4,65571,1093,512]

theorem envBound17514 : H12AffineFastState.Bounded env17514 := by
  intro p hp
  have h : env17514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17513_17514 : H12AffineEnvironment.transform 29 3108 env17513 = env17514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 3108 env17513 == env17514) = true)

theorem identity17514 : scanCanonicalize (H12AffineFastState.compose env17514 (packedSelected [1,12,13] rootPS)) = affineNative (2^(15+1) ^^^ 2083) := by decide +kernel

theorem selectedBound17514 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env17515 : List Nat := [2,4,8,16,32,64,128,4,512,1024,2048,1093,8192,1044,1,2083,1093,8832,1024,0,1092,8320,16,2082,8328,64,512,1044,1044,3108,1025,8200,4,2048,1093,512]

theorem envBound17515 : H12AffineFastState.Bounded env17515 := by
  intro p hp
  have h : env17515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17514_17515 : H12AffineEnvironment.transform 15 2083 env17514 = env17515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2083 env17514 == env17515) = true)

theorem identity17515 : scanCanonicalize (H12AffineFastState.compose env17515 (packedSelected [3,15,17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound17515 : packedSelected [3,15,17] rootPS < 2^1333 := by decide +kernel

def env17516 : List Nat := [2,4,8,16,32,64,8,4,512,1024,2048,1093,8192,1044,1,2083,1093,8712,1024,0,1092,8200,16,2082,8192,64,512,1044,1044,3108,1025,8200,4,2048,1093,512]

theorem envBound17516 : H12AffineFastState.Bounded env17516 := by
  intro p hp
  have h : env17516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17515_17516 : H12AffineEnvironment.transform 6 8 env17515 = env17516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env17515 == env17516) = true)

theorem identity17516 : scanCanonicalize (H12AffineFastState.compose env17516 (packedSelected [7] rootPS)) = affineNative (2^(12+1) ^^^ 3613) := by decide +kernel

theorem selectedBound17516 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env17517 : List Nat := [2,4,8,16,32,64,8,4,512,1024,2048,1093,3613,1044,1,2083,1093,3093,1024,0,1092,3605,16,2082,3613,64,512,1044,1044,3108,1025,3605,4,2048,1093,512]

theorem envBound17517 : H12AffineFastState.Bounded env17517 := by
  intro p hp
  have h : env17517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17516_17517 : H12AffineEnvironment.transform 12 3613 env17516 = env17517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3613 env17516 == env17517) = true)

theorem identity17517 : scanCanonicalize (H12AffineFastState.compose env17517 (packedSelected [9,32] rootPS)) = affineNative (2^(9+1) ^^^ 581) := by decide +kernel

theorem selectedBound17517 : packedSelected [9,32] rootPS < 2^1333 := by decide +kernel

def env17518 : List Nat := [2,4,8,16,32,64,8,4,512,581,2048,512,2136,593,1,2083,512,2640,581,0,513,2128,16,2082,2136,64,512,593,593,2657,580,2128,4,2048,512,512]

theorem envBound17518 : H12AffineFastState.Bounded env17518 := by
  intro p hp
  have h : env17518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17517_17518 : H12AffineEnvironment.transform 9 581 env17517 = env17518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 581 env17517 == env17518) = true)

theorem identity17518 : scanCanonicalize (H12AffineFastState.compose env17518 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound17518 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env17519 : List Nat := [2,4,8,16,32,64,8,4,0,69,2048,0,2136,81,1,2083,0,2128,69,0,1,2128,16,2082,2136,64,0,81,81,2145,68,2128,4,2048,0,0]

theorem envBound17519 : H12AffineFastState.Bounded env17519 := by
  intro p hp
  have h : env17519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17518_17519 : H12AffineEnvironment.transform 8 0 env17518 = env17519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env17518 == env17519) = true)

theorem identity17519 : scanCanonicalize (H12AffineFastState.compose env17519 (packedSelected [1,4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound17519 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env17520 : List Nat := [2,4,8,16,32,17,8,4,0,20,2048,0,2057,0,1,2083,0,2049,20,0,1,2049,16,2082,2057,17,0,0,0,2096,21,2049,4,2048,0,0]

theorem envBound17520 : H12AffineFastState.Bounded env17520 := by
  intro p hp
  have h : env17520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17519_17520 : H12AffineEnvironment.transform 5 17 env17519 = env17520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env17519 == env17520) = true)

theorem identity17520 : scanCanonicalize (H12AffineFastState.compose env17520 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound17520 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17521 : List Nat := [2,4,8,16,32,17,8,4,0,20,0,0,9,0,1,35,0,1,20,0,1,1,16,34,9,17,0,0,0,48,21,1,4,0,0,0]

theorem envBound17521 : H12AffineFastState.Bounded env17521 := by
  intro p hp
  have h : env17521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17520_17521 : H12AffineEnvironment.transform 10 0 env17520 = env17521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env17520 == env17521) = true)

theorem identity17521 : scanCanonicalize (H12AffineFastState.compose env17521 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound17521 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17522 : List Nat := [2,4,8,1,32,0,8,4,0,5,0,0,9,0,1,35,0,1,5,0,1,1,1,34,9,0,0,0,0,33,4,1,4,0,0,0]

theorem envBound17522 : H12AffineFastState.Bounded env17522 := by
  intro p hp
  have h : env17522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17521_17522 : H12AffineEnvironment.transform 3 1 env17521 = env17522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env17521 == env17522) = true)

theorem identity17522 : scanCanonicalize (H12AffineFastState.compose env17522 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound17522 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17523 : List Nat := [2,4,8,1,1,0,8,4,0,5,0,0,9,0,1,2,0,1,5,0,1,1,1,3,9,0,0,0,0,0,4,1,4,0,0,0]

theorem envBound17523 : H12AffineFastState.Bounded env17523 := by
  intro p hp
  have h : env17523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17522_17523 : H12AffineEnvironment.transform 4 1 env17522 = env17523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env17522 == env17523) = true)

def env17524 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,1092,8192,1045,0,65536,1092,8832,1024,1,1093,8321,16,65536,8328,64,512,1045,1045,1073741824,1025,8201,5,65570,1093,512]

theorem envBound17524 : H12AffineFastState.Bounded env17524 := by
  intro p hp
  have h : env17524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17512_17524 : H12AffineEnvironment.transform 7 5 env17512 = env17524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env17512 == env17524) = true)

theorem identity17524 : scanCanonicalize (H12AffineFastState.compose env17524 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound17524 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env17525 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,1092,8192,1045,0,34,1092,8832,1024,1,1093,8321,16,34,8328,64,512,1045,1045,1073741824,1025,8201,5,0,1093,512]

theorem envBound17525 : H12AffineFastState.Bounded env17525 := by
  intro p hp
  have h : env17525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17524_17525 : H12AffineEnvironment.transform 15 34 env17524 = env17525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env17524 == env17525) = true)

theorem identity17525 : scanCanonicalize (H12AffineFastState.compose env17525 (packedSelected [1,12,13] rootPS)) = affineNative (2^(29+1) ^^^ 2081) := by decide +kernel

theorem selectedBound17525 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env17526 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,1092,8192,1045,0,34,1092,8832,1024,1,1093,8321,16,34,8328,64,512,1045,1045,2081,1025,8201,5,0,1093,512]

theorem envBound17526 : H12AffineFastState.Bounded env17526 := by
  intro p hp
  have h : env17526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17525_17526 : H12AffineEnvironment.transform 29 2081 env17525 = env17526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 2081 env17525 == env17526) = true)

theorem identity17526 : scanCanonicalize (H12AffineFastState.compose env17526 (packedSelected [3,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound17526 : packedSelected [3,15,17] rootPS < 2^1333 := by decide +kernel

def env17527 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,1092,8,1045,0,34,1092,648,1024,1,1093,137,16,34,128,64,512,1045,1045,2081,1025,1,5,0,1093,512]

theorem envBound17527 : H12AffineFastState.Bounded env17527 := by
  intro p hp
  have h : env17527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17526_17527 : H12AffineEnvironment.transform 12 8 env17526 = env17527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env17526 == env17527) = true)

theorem identity17527 : scanCanonicalize (H12AffineFastState.compose env17527 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 169) := by decide +kernel

theorem selectedBound17527 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17528 : List Nat := [2,4,8,16,32,64,128,5,169,1024,2048,1092,8,1045,0,34,1092,33,1024,1,1093,137,16,34,128,64,169,1045,1045,2081,1025,1,5,0,1093,169]

theorem envBound17528 : H12AffineFastState.Bounded env17528 := by
  intro p hp
  have h : env17528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17527_17528 : H12AffineEnvironment.transform 8 169 env17527 = env17528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 169 env17527 == env17528) = true)

theorem identity17528 : scanCanonicalize (H12AffineFastState.compose env17528 (packedSelected [0,4,7] rootPS)) = affineNative (2^(10+1) ^^^ 201) := by decide +kernel

theorem selectedBound17528 : packedSelected [0,4,7] rootPS < 2^1333 := by decide +kernel

def env17529 : List Nat := [2,4,8,16,32,64,128,5,169,1024,201,1092,8,1045,0,34,1092,33,1024,1,1093,137,16,34,128,64,169,1045,1045,232,1025,1,5,0,1093,169]

theorem envBound17529 : H12AffineFastState.Bounded env17529 := by
  intro p hp
  have h : env17529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17528_17529 : H12AffineEnvironment.transform 10 201 env17528 = env17529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 201 env17528 == env17529) = true)

theorem identity17529 : scanCanonicalize (H12AffineFastState.compose env17529 (packedSelected [4,11] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound17529 : packedSelected [4,11] rootPS < 2^1333 := by decide +kernel

def env17530 : List Nat := [2,4,8,16,32,64,40,5,1,1024,97,1092,8,1045,0,34,1092,33,1024,1,1093,33,16,34,40,64,1,1045,1045,64,1025,1,5,0,1093,1]

theorem envBound17530 : H12AffineFastState.Bounded env17530 := by
  intro p hp
  have h : env17530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17529_17530 : H12AffineEnvironment.transform 6 40 env17529 = env17530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env17529 == env17530) = true)

theorem identity17530 : scanCanonicalize (H12AffineFastState.compose env17530 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound17530 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env17531 : List Nat := [2,4,8,16,16,64,24,5,1,1024,81,1092,8,1045,0,18,1092,17,1024,1,1093,17,16,18,24,64,1,1045,1045,64,1025,1,5,0,1093,1]

theorem envBound17531 : H12AffineFastState.Bounded env17531 := by
  intro p hp
  have h : env17531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17530_17531 : H12AffineEnvironment.transform 4 16 env17530 = env17531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env17530 == env17531) = true)

theorem identity17531 : scanCanonicalize (H12AffineFastState.compose env17531 (packedSelected [0,1,3] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound17531 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env17532 : List Nat := [2,4,8,16,16,64,24,5,1,5,81,65,8,16,0,18,65,17,5,1,64,17,16,18,24,64,1,16,16,64,4,1,5,0,64,1]

theorem envBound17532 : H12AffineFastState.Bounded env17532 := by
  intro p hp
  have h : env17532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17531_17532 : H12AffineEnvironment.transform 9 5 env17531 = env17532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env17531 == env17532) = true)

theorem identity17532 : scanCanonicalize (H12AffineFastState.compose env17532 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound17532 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17533 : List Nat := [2,4,8,1,1,64,9,5,1,5,64,65,8,1,0,3,65,0,5,1,64,0,1,3,9,64,1,1,1,64,4,1,5,0,64,1]

theorem envBound17533 : H12AffineFastState.Bounded env17533 := by
  intro p hp
  have h : env17533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17532_17533 : H12AffineEnvironment.transform 3 1 env17532 = env17533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env17532 == env17533) = true)

theorem identity17533 : scanCanonicalize (H12AffineFastState.compose env17533 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound17533 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17534 : List Nat := [2,4,8,1,1,1,9,5,1,5,1,0,8,1,0,3,0,0,5,1,1,0,1,3,9,1,1,1,1,1,4,1,5,0,1,1]

theorem envBound17534 : H12AffineFastState.Bounded env17534 := by
  intro p hp
  have h : env17534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17533_17534 : H12AffineEnvironment.transform 5 1 env17533 = env17534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env17533 == env17534) = true)

def env17535 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,65536,1345,8832,1024,32769,1344,8580,16,98305,8328,64,512,1296,1296,1073741824,1024,8460,256,98339,1092,512]

theorem envBound17535 : H12AffineFastState.Bounded env17535 := by
  intro p hp
  have h : env17535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17510_17535 : H12AffineEnvironment.transform 23 98305 env17510 = env17535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98305 env17510 == env17535) = true)

theorem identity17535 : scanCanonicalize (H12AffineFastState.compose env17535 (packedSelected [1,8,28] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound17535 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env17536 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,1,65536,1345,8832,1024,0,1344,8580,16,65536,8328,64,512,1296,1296,1073741824,1024,8460,256,65570,1092,512]

theorem envBound17536 : H12AffineFastState.Bounded env17536 := by
  intro p hp
  have h : env17536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17535_17536 : H12AffineEnvironment.transform 14 1 env17535 = env17536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env17535 == env17536) = true)

def env17537 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,65,8192,16,1,65536,65,8832,256,0,64,8580,16,65536,8328,64,512,16,16,1073741824,256,8460,256,65570,324,512]

theorem envBound17537 : H12AffineFastState.Bounded env17537 := by
  intro p hp
  have h : env17537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17536_17537 : H12AffineEnvironment.transform 9 256 env17536 = env17537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env17536 == env17537) = true)

theorem identity17537 : scanCanonicalize (H12AffineFastState.compose env17537 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 294) := by decide +kernel

theorem selectedBound17537 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env17538 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,65,8192,16,1,294,65,8832,256,0,64,8580,16,294,8328,64,512,16,16,1073741824,256,8460,256,260,324,512]

theorem envBound17538 : H12AffineFastState.Bounded env17538 := by
  intro p hp
  have h : env17538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17537_17538 : H12AffineEnvironment.transform 15 294 env17537 = env17538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 294 env17537 == env17538) = true)

def env17539 : List Nat := [2,4,8,16,32,64,8,256,512,256,2048,65,8192,16,1,294,65,8712,256,0,64,8460,16,294,8192,64,512,16,16,1073741824,256,8460,256,260,324,512]

theorem envBound17539 : H12AffineFastState.Bounded env17539 := by
  intro p hp
  have h : env17539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17538_17539 : H12AffineEnvironment.transform 6 8 env17538 = env17539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env17538 == env17539) = true)

theorem identity17539 : scanCanonicalize (H12AffineFastState.compose env17539 (packedSelected [7] rootPS)) = affineNative (2^(12+1) ^^^ 796) := by decide +kernel

theorem selectedBound17539 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env17540 : List Nat := [2,4,8,16,32,64,8,256,512,256,2048,65,796,16,1,294,65,276,256,0,64,528,16,294,796,64,512,16,16,1073741824,256,528,256,260,324,512]

theorem envBound17540 : H12AffineFastState.Bounded env17540 := by
  intro p hp
  have h : env17540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17539_17540 : H12AffineEnvironment.transform 12 796 env17539 = env17540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 796 env17539 == env17540) = true)

def env17541 : List Nat := [2,4,8,0,32,64,8,256,512,256,2048,65,780,0,1,294,65,260,256,0,64,512,0,294,780,64,512,0,0,1073741824,256,512,256,260,324,512]

theorem envBound17541 : H12AffineFastState.Bounded env17541 := by
  intro p hp
  have h : env17541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17540_17541 : H12AffineEnvironment.transform 3 0 env17540 = env17541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env17540 == env17541) = true)

theorem identity17541 : scanCanonicalize (H12AffineFastState.compose env17541 (packedSelected [3,5] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound17541 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env17542 : List Nat := [2,4,8,0,32,64,8,256,0,256,2048,65,268,0,1,294,65,260,256,0,64,0,0,294,268,64,0,0,0,1073741824,256,0,256,260,324,0]

theorem envBound17542 : H12AffineFastState.Bounded env17542 := by
  intro p hp
  have h : env17542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17541_17542 : H12AffineEnvironment.transform 8 0 env17541 = env17542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env17541 == env17542) = true)

theorem identity17542 : scanCanonicalize (H12AffineFastState.compose env17542 (packedSelected [1,2,3,4,9,12,13] rootPS)) = affineNative (2^(29+1) ^^^ 2080) := by decide +kernel

theorem selectedBound17542 : packedSelected [1,2,3,4,9,12,13] rootPS < 2^1333 := by decide +kernel

def env17543 : List Nat := [2,4,8,0,32,64,8,256,0,256,2048,65,268,0,1,294,65,260,256,0,64,0,0,294,268,64,0,0,0,2080,256,0,256,260,324,0]

theorem envBound17543 : H12AffineFastState.Bounded env17543 := by
  intro p hp
  have h : env17543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17542_17543 : H12AffineEnvironment.transform 29 2080 env17542 = env17543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 2080 env17542 == env17543) = true)

def env17544 : List Nat := [2,4,8,1,32,64,8,256,512,256,2048,65,781,1,1,294,65,261,256,0,64,513,1,294,781,64,512,1,1,1073741824,256,513,256,260,324,512]

theorem envBound17544 : H12AffineFastState.Bounded env17544 := by
  intro p hp
  have h : env17544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17540_17544 : H12AffineEnvironment.transform 3 1 env17540 = env17544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env17540 == env17544) = true)

theorem identity17544 : scanCanonicalize (H12AffineFastState.compose env17544 (packedSelected [3,5] rootPS)) = affineNative (2^(29+1) ^^^ 836) := by decide +kernel

theorem selectedBound17544 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env17545 : List Nat := [2,4,8,1,32,64,8,256,512,256,2048,65,781,1,1,294,65,261,256,0,64,513,1,294,781,64,512,1,1,836,256,513,256,260,324,512]

theorem envBound17545 : H12AffineFastState.Bounded env17545 := by
  intro p hp
  have h : env17545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17544_17545 : H12AffineEnvironment.transform 29 836 env17544 = env17545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 836 env17544 == env17545) = true)

def env17546 : List Nat := [2,4,8,16,32,64,9,256,512,256,2048,65,8192,16,1,294,65,8713,256,0,64,8461,16,294,8193,64,512,16,16,1073741824,256,8460,256,260,324,512]

theorem envBound17546 : H12AffineFastState.Bounded env17546 := by
  intro p hp
  have h : env17546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17538_17546 : H12AffineEnvironment.transform 6 9 env17538 = env17546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env17538 == env17546) = true)

theorem identity17546 : scanCanonicalize (H12AffineFastState.compose env17546 (packedSelected [7] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound17546 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env17547 : List Nat := [2,4,8,16,32,64,9,256,512,256,2048,65,25,16,1,294,65,528,256,0,64,276,16,294,24,64,512,16,16,1073741824,256,277,256,260,324,512]

theorem envBound17547 : H12AffineFastState.Bounded env17547 := by
  intro p hp
  have h : env17547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17546_17547 : H12AffineEnvironment.transform 12 25 env17546 = env17547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env17546 == env17547) = true)

def env17548 : List Nat := [2,4,8,16,32,0,9,256,512,256,2048,1,25,16,1,294,1,528,256,0,0,276,16,294,24,0,512,16,16,1073741824,256,277,256,260,260,512]

theorem envBound17548 : H12AffineFastState.Bounded env17548 := by
  intro p hp
  have h : env17548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17547_17548 : H12AffineEnvironment.transform 5 0 env17547 = env17548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env17547 == env17548) = true)

theorem identity17548 : scanCanonicalize (H12AffineFastState.compose env17548 (packedSelected [13] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound17548 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env17549 : List Nat := [2,4,8,1,32,0,9,256,512,256,2048,1,8,1,1,294,1,513,256,0,0,261,1,294,9,0,512,1,1,1073741824,256,260,256,260,260,512]

theorem envBound17549 : H12AffineFastState.Bounded env17549 := by
  intro p hp
  have h : env17549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17548_17549 : H12AffineEnvironment.transform 3 1 env17548 = env17549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env17548 == env17549) = true)

theorem identity17549 : scanCanonicalize (H12AffineFastState.compose env17549 (packedSelected [1,2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound17549 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env17550 : List Nat := [2,4,8,1,32,0,9,4,512,4,2048,1,8,1,1,34,1,513,4,0,0,1,1,34,9,0,512,1,1,1073741824,4,0,4,0,0,512]

theorem envBound17550 : H12AffineFastState.Bounded env17550 := by
  intro p hp
  have h : env17550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17549_17550 : H12AffineEnvironment.transform 7 4 env17549 = env17550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env17549 == env17550) = true)

theorem identity17550 : scanCanonicalize (H12AffineFastState.compose env17550 (packedSelected [1] rootPS)) = affineNative (2^(29+1) ^^^ 2593) := by decide +kernel

theorem selectedBound17550 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17551 : List Nat := [2,4,8,1,32,0,9,4,512,4,2048,1,8,1,1,34,1,513,4,0,0,1,1,34,9,0,512,1,1,2593,4,0,4,0,0,512]

theorem envBound17551 : H12AffineFastState.Bounded env17551 := by
  intro p hp
  have h : env17551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17550_17551 : H12AffineEnvironment.transform 29 2593 env17550 = env17551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 2593 env17550 == env17551) = true)

theorem identity17551 : scanCanonicalize (H12AffineFastState.compose env17551 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound17551 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env17552 : List Nat := [2,4,8,1,32,0,9,4,512,4,1,1,8,1,1,34,1,513,4,0,0,1,1,34,9,0,512,1,1,544,4,0,4,0,0,512]

theorem envBound17552 : H12AffineFastState.Bounded env17552 := by
  intro p hp
  have h : env17552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17551_17552 : H12AffineEnvironment.transform 10 1 env17551 = env17552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env17551 == env17552) = true)

theorem identity17552 : scanCanonicalize (H12AffineFastState.compose env17552 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound17552 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17553 : List Nat := [2,4,8,1,0,0,9,4,512,4,1,1,8,1,1,2,1,513,4,0,0,1,1,2,9,0,512,1,1,512,4,0,4,0,0,512]

theorem envBound17553 : H12AffineFastState.Bounded env17553 := by
  intro p hp
  have h : env17553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17552_17553 : H12AffineEnvironment.transform 4 0 env17552 = env17553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17552 == env17553) = true)

theorem identity17553 : scanCanonicalize (H12AffineFastState.compose env17553 (packedSelected [5] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound17553 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env17554 : List Nat := [2,4,8,1,0,0,9,4,1,4,1,1,8,1,1,2,1,0,4,0,0,1,1,2,9,0,1,1,1,1,4,0,4,0,0,1]

theorem envBound17554 : H12AffineFastState.Bounded env17554 := by
  intro p hp
  have h : env17554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17553_17554 : H12AffineEnvironment.transform 8 1 env17553 = env17554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env17553 == env17554) = true)

def env17555 : List Nat := [2,4,8,16,32,1,9,256,512,256,2048,0,25,16,1,294,0,528,256,0,1,276,16,294,24,1,512,16,16,1073741824,256,277,256,260,261,512]

theorem envBound17555 : H12AffineFastState.Bounded env17555 := by
  intro p hp
  have h : env17555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17547_17555 : H12AffineEnvironment.transform 5 1 env17547 = env17555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env17547 == env17555) = true)

theorem identity17555 : scanCanonicalize (H12AffineFastState.compose env17555 (packedSelected [13] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound17555 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env17556 : List Nat := [2,4,8,16,32,1,9,52,512,52,2048,0,25,16,1,18,0,528,52,0,1,32,16,18,24,1,512,16,16,1073741824,52,33,52,48,49,512]

theorem envBound17556 : H12AffineFastState.Bounded env17556 := by
  intro p hp
  have h : env17556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17555_17556 : H12AffineEnvironment.transform 7 52 env17555 = env17556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env17555 == env17556) = true)

theorem identity17556 : scanCanonicalize (H12AffineFastState.compose env17556 (packedSelected [1,3,8,12,15] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound17556 : packedSelected [1,3,8,12,15] rootPS < 2^1333 := by decide +kernel

def env17557 : List Nat := [2,4,8,1,32,1,9,37,512,37,2048,0,8,1,1,3,0,513,37,0,1,32,1,3,9,1,512,1,1,1073741824,37,33,37,33,32,512]

theorem envBound17557 : H12AffineFastState.Bounded env17557 := by
  intro p hp
  have h : env17557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17556_17557 : H12AffineEnvironment.transform 3 1 env17556 = env17557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env17556 == env17557) = true)

theorem identity17557 : scanCanonicalize (H12AffineFastState.compose env17557 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 544) := by decide +kernel

theorem selectedBound17557 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17558 : List Nat := [2,4,8,1,32,1,9,37,512,37,544,0,8,1,1,3,0,513,37,0,1,32,1,3,9,1,512,1,1,1073741824,37,33,37,33,32,512]

theorem envBound17558 : H12AffineFastState.Bounded env17558 := by
  intro p hp
  have h : env17558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17557_17558 : H12AffineEnvironment.transform 10 544 env17557 = env17558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 544 env17557 == env17558) = true)

theorem identity17558 : scanCanonicalize (H12AffineFastState.compose env17558 (packedSelected [2] rootPS)) = affineNative (2^(29+1) ^^^ 1) := by decide +kernel

theorem selectedBound17558 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17559 : List Nat := [2,4,8,1,32,1,9,37,512,37,544,0,8,1,1,3,0,513,37,0,1,32,1,3,9,1,512,1,1,1,37,33,37,33,32,512]

theorem envBound17559 : H12AffineFastState.Bounded env17559 := by
  intro p hp
  have h : env17559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17558_17559 : H12AffineEnvironment.transform 29 1 env17558 = env17559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 1 env17558 == env17559) = true)

theorem identity17559 : scanCanonicalize (H12AffineFastState.compose env17559 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound17559 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17560 : List Nat := [2,4,8,1,0,1,9,5,512,5,512,0,8,1,1,3,0,513,5,0,1,0,1,3,9,1,512,1,1,1,5,1,5,1,0,512]

theorem envBound17560 : H12AffineFastState.Bounded env17560 := by
  intro p hp
  have h : env17560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17559_17560 : H12AffineEnvironment.transform 4 0 env17559 = env17560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17559 == env17560) = true)

theorem identity17560 : scanCanonicalize (H12AffineFastState.compose env17560 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound17560 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env17561 : List Nat := [2,4,8,1,0,1,9,5,0,5,0,0,8,1,1,3,0,1,5,0,1,0,1,3,9,1,0,1,1,1,5,1,5,1,0,0]

theorem envBound17561 : H12AffineFastState.Bounded env17561 := by
  intro p hp
  have h : env17561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17560_17561 : H12AffineEnvironment.transform 8 0 env17560 = env17561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env17560 == env17561) = true)

def env17562 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,64,8192,17,1,65536,64,8832,257,0,65,8580,16,65536,8328,64,512,17,17,1073741824,257,8460,256,65570,325,512]

theorem envBound17562 : H12AffineFastState.Bounded env17562 := by
  intro p hp
  have h : env17562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17536_17562 : H12AffineEnvironment.transform 9 257 env17536 = env17562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 257 env17536 == env17562) = true)

theorem identity17562 : scanCanonicalize (H12AffineFastState.compose env17562 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound17562 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env17563 : List Nat := [2,4,8,16,32,64,128,256,512,257,2048,64,8192,17,1,34,64,8832,257,0,65,8580,16,34,8328,64,512,17,17,1073741824,257,8460,256,0,325,512]

theorem envBound17563 : H12AffineFastState.Bounded env17563 := by
  intro p hp
  have h : env17563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17562_17563 : H12AffineEnvironment.transform 15 34 env17562 = env17563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env17562 == env17563) = true)

def env17564 : List Nat := [2,4,8,16,32,64,8,256,512,257,2048,64,8192,17,1,34,64,8712,257,0,65,8460,16,34,8192,64,512,17,17,1073741824,257,8460,256,0,325,512]

theorem envBound17564 : H12AffineFastState.Bounded env17564 := by
  intro p hp
  have h : env17564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17563_17564 : H12AffineEnvironment.transform 6 8 env17563 = env17564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env17563 == env17564) = true)

theorem identity17564 : scanCanonicalize (H12AffineFastState.compose env17564 (packedSelected [7] rootPS)) = affineNative (2^(12+1) ^^^ 796) := by decide +kernel

theorem selectedBound17564 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env17565 : List Nat := [2,4,8,16,32,64,8,256,512,257,2048,64,796,17,1,34,64,276,257,0,65,528,16,34,796,64,512,17,17,1073741824,257,528,256,0,325,512]

theorem envBound17565 : H12AffineFastState.Bounded env17565 := by
  intro p hp
  have h : env17565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17564_17565 : H12AffineEnvironment.transform 12 796 env17564 = env17565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 796 env17564 == env17565) = true)

def env17566 : List Nat := [2,4,8,16,32,64,8,256,512,257,2048,64,796,17,1,34,64,276,257,0,65,528,16,34,796,64,512,17,17,64,257,528,256,0,325,512]

theorem envBound17566 : H12AffineFastState.Bounded env17566 := by
  intro p hp
  have h : env17566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17565_17566 : H12AffineEnvironment.transform 29 64 env17565 = env17566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 64 env17565 == env17566) = true)

theorem identity17566 : scanCanonicalize (H12AffineFastState.compose env17566 (packedSelected [3,5] rootPS)) = affineNative (2^(8+1) ^^^ 81) := by decide +kernel

theorem selectedBound17566 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env17567 : List Nat := [2,4,8,16,32,64,8,256,81,257,2048,64,333,17,1,34,64,276,257,0,65,65,16,34,333,64,81,17,17,64,257,65,256,0,325,81]

theorem envBound17567 : H12AffineFastState.Bounded env17567 := by
  intro p hp
  have h : env17567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17566_17567 : H12AffineEnvironment.transform 8 81 env17566 = env17567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env17566 == env17567) = true)

theorem identity17567 : scanCanonicalize (H12AffineFastState.compose env17567 (packedSelected [1,8,9,12,15] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound17567 : packedSelected [1,8,9,12,15] rootPS < 2^1333 := by decide +kernel

def env17568 : List Nat := [2,4,8,0,32,64,8,256,65,257,2048,64,333,1,1,34,64,260,257,0,65,65,0,34,333,64,65,1,1,64,257,65,256,0,325,65]

theorem envBound17568 : H12AffineFastState.Bounded env17568 := by
  intro p hp
  have h : env17568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17567_17568 : H12AffineEnvironment.transform 3 0 env17567 = env17568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env17567 == env17568) = true)

theorem identity17568 : scanCanonicalize (H12AffineFastState.compose env17568 (packedSelected [0,8] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound17568 : packedSelected [0,8] rootPS < 2^1333 := by decide +kernel

def env17569 : List Nat := [2,4,8,0,32,64,8,37,65,36,2048,64,104,1,1,34,64,33,36,0,65,65,0,34,104,64,65,1,1,64,36,65,37,0,96,65]

theorem envBound17569 : H12AffineFastState.Bounded env17569 := by
  intro p hp
  have h : env17569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17568_17569 : H12AffineEnvironment.transform 7 37 env17568 = env17569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env17568 == env17569) = true)

theorem identity17569 : scanCanonicalize (H12AffineFastState.compose env17569 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound17569 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17570 : List Nat := [2,4,8,0,32,64,8,37,65,36,0,64,104,1,1,34,64,33,36,0,65,65,0,34,104,64,65,1,1,64,36,65,37,0,96,65]

theorem envBound17570 : H12AffineFastState.Bounded env17570 := by
  intro p hp
  have h : env17570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17569_17570 : H12AffineEnvironment.transform 10 0 env17569 = env17570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env17569 == env17570) = true)

def env17571 : List Nat := [2,4,8,16,32,64,8,256,512,257,2048,64,796,17,1,34,64,276,257,0,65,528,16,34,796,64,512,17,17,65,257,528,256,0,325,512]

theorem envBound17571 : H12AffineFastState.Bounded env17571 := by
  intro p hp
  have h : env17571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17565_17571 : H12AffineEnvironment.transform 29 65 env17565 = env17571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 65 env17565 == env17571) = true)

theorem identity17571 : scanCanonicalize (H12AffineFastState.compose env17571 (packedSelected [3,5] rootPS)) = affineNative (2^(8+1) ^^^ 64) := by decide +kernel

theorem selectedBound17571 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env17572 : List Nat := [2,4,8,16,32,64,8,256,64,257,2048,64,348,17,1,34,64,276,257,0,65,80,16,34,348,64,64,17,17,65,257,80,256,0,325,64]

theorem envBound17572 : H12AffineFastState.Bounded env17572 := by
  intro p hp
  have h : env17572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17571_17572 : H12AffineEnvironment.transform 8 64 env17571 = env17572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 64 env17571 == env17572) = true)

theorem identity17572 : scanCanonicalize (H12AffineFastState.compose env17572 (packedSelected [0,8] rootPS)) = affineNative (2^(10+1) ^^^ 356) := by decide +kernel

theorem selectedBound17572 : packedSelected [0,8] rootPS < 2^1333 := by decide +kernel

def env17573 : List Nat := [2,4,8,16,32,64,8,256,64,257,356,64,348,17,1,34,64,276,257,0,65,80,16,34,348,64,64,17,17,65,257,80,256,0,325,64]

theorem envBound17573 : H12AffineFastState.Bounded env17573 := by
  intro p hp
  have h : env17573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17572_17573 : H12AffineEnvironment.transform 10 356 env17572 = env17573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 356 env17572 == env17573) = true)

theorem identity17573 : scanCanonicalize (H12AffineFastState.compose env17573 (packedSelected [0,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound17573 : packedSelected [0,2,3] rootPS < 2^1333 := by decide +kernel

def env17574 : List Nat := [2,4,8,16,32,64,8,21,64,20,113,64,73,17,1,34,64,1,20,0,65,80,16,34,73,64,64,17,17,65,20,80,21,0,80,64]

theorem envBound17574 : H12AffineFastState.Bounded env17574 := by
  intro p hp
  have h : env17574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17573_17574 : H12AffineEnvironment.transform 7 21 env17573 = env17574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env17573 == env17574) = true)

theorem identity17574 : scanCanonicalize (H12AffineFastState.compose env17574 (packedSelected [0,1,2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound17574 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env17575 : List Nat := [2,4,8,16,32,17,8,21,17,20,32,17,24,17,1,34,17,1,20,0,16,1,16,34,24,17,17,17,17,16,20,1,21,0,1,17]

theorem envBound17575 : H12AffineFastState.Bounded env17575 := by
  intro p hp
  have h : env17575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17574_17575 : H12AffineEnvironment.transform 5 17 env17574 = env17575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env17574 == env17575) = true)

theorem identity17575 : scanCanonicalize (H12AffineFastState.compose env17575 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound17575 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env17576 : List Nat := [2,4,8,16,0,17,8,21,17,20,0,17,24,17,1,2,17,1,20,0,16,1,16,2,24,17,17,17,17,16,20,1,21,0,1,17]

theorem envBound17576 : H12AffineFastState.Bounded env17576 := by
  intro p hp
  have h : env17576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17575_17576 : H12AffineEnvironment.transform 4 0 env17575 = env17576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17575 == env17576) = true)

def env17577 : List Nat := [2,4,8,16,32,64,9,256,512,257,2048,64,8192,17,1,34,64,8713,257,0,65,8461,16,34,8193,64,512,17,17,1073741824,257,8460,256,0,325,512]

theorem envBound17577 : H12AffineFastState.Bounded env17577 := by
  intro p hp
  have h : env17577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17563_17577 : H12AffineEnvironment.transform 6 9 env17563 = env17577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env17563 == env17577) = true)

theorem identity17577 : scanCanonicalize (H12AffineFastState.compose env17577 (packedSelected [7] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound17577 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env17578 : List Nat := [2,4,8,16,32,64,9,256,512,257,2048,64,25,17,1,34,64,528,257,0,65,276,16,34,24,64,512,17,17,1073741824,257,277,256,0,325,512]

theorem envBound17578 : H12AffineFastState.Bounded env17578 := by
  intro p hp
  have h : env17578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17577_17578 : H12AffineEnvironment.transform 12 25 env17577 = env17578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env17577 == env17578) = true)

def env17579 : List Nat := [2,4,8,16,32,0,9,256,512,257,2048,0,25,17,1,34,0,528,257,0,1,276,16,34,24,0,512,17,17,1073741824,257,277,256,0,261,512]

theorem envBound17579 : H12AffineFastState.Bounded env17579 := by
  intro p hp
  have h : env17579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17578_17579 : H12AffineEnvironment.transform 5 0 env17578 = env17579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env17578 == env17579) = true)

theorem identity17579 : scanCanonicalize (H12AffineFastState.compose env17579 (packedSelected [13] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound17579 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env17580 : List Nat := [2,4,8,16,17,0,9,256,512,257,2048,0,25,17,1,19,0,528,257,0,1,276,16,19,24,0,512,17,17,1073741824,257,277,256,0,261,512]

theorem envBound17580 : H12AffineFastState.Bounded env17580 := by
  intro p hp
  have h : env17580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17579_17580 : H12AffineEnvironment.transform 4 17 env17579 = env17580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env17579 == env17580) = true)

theorem identity17580 : scanCanonicalize (H12AffineFastState.compose env17580 (packedSelected [1,3,8,11,12] rootPS)) = affineNative (2^(29+1) ^^^ 2837) := by decide +kernel

theorem selectedBound17580 : packedSelected [1,3,8,11,12] rootPS < 2^1333 := by decide +kernel

def env17581 : List Nat := [2,4,8,16,17,0,9,256,512,257,2048,0,25,17,1,19,0,528,257,0,1,276,16,19,24,0,512,17,17,2837,257,277,256,0,261,512]

theorem envBound17581 : H12AffineFastState.Bounded env17581 := by
  intro p hp
  have h : env17581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17580_17581 : H12AffineEnvironment.transform 29 2837 env17580 = env17581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 2837 env17580 == env17581) = true)

theorem identity17581 : scanCanonicalize (H12AffineFastState.compose env17581 (packedSelected [1,2] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound17581 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env17582 : List Nat := [2,4,8,16,17,0,9,256,512,257,0,0,25,17,1,19,0,528,257,0,1,276,16,19,24,0,512,17,17,789,257,277,256,0,261,512]

theorem envBound17582 : H12AffineFastState.Bounded env17582 := by
  intro p hp
  have h : env17582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17581_17582 : H12AffineEnvironment.transform 10 0 env17581 = env17582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env17581 == env17582) = true)

theorem identity17582 : scanCanonicalize (H12AffineFastState.compose env17582 (packedSelected [3,4] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound17582 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env17583 : List Nat := [2,4,8,16,17,0,9,256,261,257,0,0,25,17,1,19,0,277,257,0,1,276,16,19,24,0,261,17,17,16,257,277,256,0,261,261]

theorem envBound17583 : H12AffineFastState.Bounded env17583 := by
  intro p hp
  have h : env17583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17582_17583 : H12AffineEnvironment.transform 8 261 env17582 = env17583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env17582 == env17583) = true)

theorem identity17583 : scanCanonicalize (H12AffineFastState.compose env17583 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound17583 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17584 : List Nat := [2,4,8,16,17,0,9,21,16,20,0,0,25,17,1,19,0,0,20,0,1,1,16,19,24,0,16,17,17,16,20,0,21,0,16,16]

theorem envBound17584 : H12AffineFastState.Bounded env17584 := by
  intro p hp
  have h : env17584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17583_17584 : H12AffineEnvironment.transform 7 21 env17583 = env17584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env17583 == env17584) = true)

def env17585 : List Nat := [2,4,8,16,32,1,9,256,512,257,2048,1,25,17,1,34,1,528,257,0,0,276,16,34,24,1,512,17,17,1073741824,257,277,256,0,260,512]

theorem envBound17585 : H12AffineFastState.Bounded env17585 := by
  intro p hp
  have h : env17585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17578_17585 : H12AffineEnvironment.transform 5 1 env17578 = env17585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env17578 == env17585) = true)

theorem identity17585 : scanCanonicalize (H12AffineFastState.compose env17585 (packedSelected [13] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound17585 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env17586 : List Nat := [2,4,8,0,32,1,9,256,512,257,2048,1,9,1,1,34,1,512,257,0,0,260,0,34,8,1,512,1,1,1073741824,257,261,256,0,260,512]

theorem envBound17586 : H12AffineFastState.Bounded env17586 := by
  intro p hp
  have h : env17586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17585_17586 : H12AffineEnvironment.transform 3 0 env17585 = env17586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env17585 == env17586) = true)

theorem identity17586 : scanCanonicalize (H12AffineFastState.compose env17586 (packedSelected [1,2] rootPS)) = affineNative (2^(29+1) ^^^ 2049) := by decide +kernel

theorem selectedBound17586 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env17587 : List Nat := [2,4,8,0,32,1,9,256,512,257,2048,1,9,1,1,34,1,512,257,0,0,260,0,34,8,1,512,1,1,2049,257,261,256,0,260,512]

theorem envBound17587 : H12AffineFastState.Bounded env17587 := by
  intro p hp
  have h : env17587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17586_17587 : H12AffineEnvironment.transform 29 2049 env17586 = env17587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 2049 env17586 == env17587) = true)

theorem identity17587 : scanCanonicalize (H12AffineFastState.compose env17587 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound17587 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17588 : List Nat := [2,4,8,0,32,1,9,256,32,257,2048,1,9,1,1,34,1,32,257,0,0,260,0,34,8,1,32,1,1,2049,257,261,256,0,260,32]

theorem envBound17588 : H12AffineFastState.Bounded env17588 := by
  intro p hp
  have h : env17588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17587_17588 : H12AffineEnvironment.transform 8 32 env17587 = env17588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env17587 == env17588) = true)

theorem identity17588 : scanCanonicalize (H12AffineFastState.compose env17588 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound17588 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17589 : List Nat := [2,4,8,0,32,1,9,256,32,257,1,1,9,1,1,34,1,32,257,0,0,260,0,34,8,1,32,1,1,0,257,261,256,0,260,32]

theorem envBound17589 : H12AffineFastState.Bounded env17589 := by
  intro p hp
  have h : env17589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17588_17589 : H12AffineEnvironment.transform 10 1 env17588 = env17589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env17588 == env17589) = true)

theorem identity17589 : scanCanonicalize (H12AffineFastState.compose env17589 (packedSelected [1,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound17589 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env17590 : List Nat := [2,4,8,0,0,1,9,256,0,257,1,1,9,1,1,2,1,0,257,0,0,260,0,2,8,1,0,1,1,0,257,261,256,0,260,0]

theorem envBound17590 : H12AffineFastState.Bounded env17590 := by
  intro p hp
  have h : env17590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17589_17590 : H12AffineEnvironment.transform 4 0 env17589 = env17590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17589 == env17590) = true)

def env17591 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,65536,1345,8833,1024,32769,1344,4194304,16,16777216,8328,64,4203397,1296,1296,1073741824,16876545,4194440,256,16777250,16876613,512]

theorem envBound17591 : H12AffineFastState.Bounded env17591 := by
  intro p hp
  have h : env17591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17508_17591 : H12AffineEnvironment.transform 17 8833 env17508 = env17591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8833 env17508 == env17591) = true)

theorem identity17591 : scanCanonicalize (H12AffineFastState.compose env17591 (packedSelected [3,5,24] rootPS)) = affineNative (2^(23+1) ^^^ 4300929) := by decide +kernel

theorem selectedBound17591 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env17592 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,65536,1345,8833,1024,32769,1344,4194304,16,4300929,8328,64,4203397,1296,1296,1073741824,4203648,4194440,256,4300963,4203716,512]

theorem envBound17592 : H12AffineFastState.Bounded env17592 := by
  intro p hp
  have h : env17592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17591_17592 : H12AffineEnvironment.transform 23 4300929 env17591 = env17592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 4300929 env17591 == env17592) = true)

def env17593 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,65536,1345,8833,1024,32769,1344,8320,16,98305,8328,64,773,1296,1296,1073741824,1024,8200,256,98339,1092,512]

theorem envBound17593 : H12AffineFastState.Bounded env17593 := by
  intro p hp
  have h : env17593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17592_17593 : H12AffineEnvironment.transform 21 8320 env17592 = env17593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8320 env17592 == env17593) = true)

theorem identity17593 : scanCanonicalize (H12AffineFastState.compose env17593 (packedSelected [1,8,28] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound17593 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env17594 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,1,65536,1345,8833,1024,0,1344,8320,16,65536,8328,64,773,1296,1296,1073741824,1024,8200,256,65570,1092,512]

theorem envBound17594 : H12AffineFastState.Bounded env17594 := by
  intro p hp
  have h : env17594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17593_17594 : H12AffineEnvironment.transform 14 1 env17593 = env17594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env17593 == env17594) = true)

def env17595 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,1288,1296,1,65536,1345,1929,1024,0,1344,1416,16,65536,1408,64,773,1296,1296,1073741824,1024,1280,256,65570,1092,512]

theorem envBound17595 : H12AffineFastState.Bounded env17595 := by
  intro p hp
  have h : env17595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17594_17595 : H12AffineEnvironment.transform 12 1288 env17594 = env17595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1288 env17594 == env17595) = true)

theorem identity17595 : scanCanonicalize (H12AffineFastState.compose env17595 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound17595 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env17596 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,1288,1296,1,34,1345,1929,1024,0,1344,1416,16,34,1408,64,773,1296,1296,1073741824,1024,1280,256,0,1092,512]

theorem envBound17596 : H12AffineFastState.Bounded env17596 := by
  intro p hp
  have h : env17596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17595_17596 : H12AffineEnvironment.transform 15 34 env17595 = env17596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env17595 == env17596) = true)

def env17597 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1345,1288,1296,1,34,1345,1793,1024,0,1344,1280,16,34,1288,64,773,1296,1296,1073741824,1024,1280,256,0,1092,512]

theorem envBound17597 : H12AffineFastState.Bounded env17597 := by
  intro p hp
  have h : env17597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17596_17597 : H12AffineEnvironment.transform 6 8 env17596 = env17597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env17596 == env17597) = true)

theorem identity17597 : scanCanonicalize (H12AffineFastState.compose env17597 (packedSelected [7] rootPS)) = affineNative (2^(8+1) ^^^ 277) := by decide +kernel

theorem selectedBound17597 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env17598 : List Nat := [2,4,8,16,32,64,8,256,277,1024,2048,1345,1288,1296,1,34,1345,1044,1024,0,1344,1280,16,34,1288,64,16,1296,1296,1073741824,1024,1280,256,0,1092,277]

theorem envBound17598 : H12AffineFastState.Bounded env17598 := by
  intro p hp
  have h : env17598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17597_17598 : H12AffineEnvironment.transform 8 277 env17597 = env17598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env17597 == env17598) = true)

def env17599 : List Nat := [2,4,8,16,32,64,8,256,277,1024,0,1345,1288,1296,1,34,1345,1044,1024,0,1344,1280,16,34,1288,64,16,1296,1296,1073741824,1024,1280,256,0,1092,277]

theorem envBound17599 : H12AffineFastState.Bounded env17599 := by
  intro p hp
  have h : env17599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17598_17599 : H12AffineEnvironment.transform 10 0 env17598 = env17599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env17598 == env17599) = true)

theorem identity17599 : scanCanonicalize (H12AffineFastState.compose env17599 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 1076) := by decide +kernel

theorem selectedBound17599 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env17600 : List Nat := [2,4,8,16,32,64,8,256,277,1024,0,1345,1288,1296,1,34,1345,1044,1024,0,1344,1280,16,34,1288,64,16,1296,1296,1076,1024,1280,256,0,1092,277]

theorem envBound17600 : H12AffineFastState.Bounded env17600 := by
  intro p hp
  have h : env17600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17599_17600 : H12AffineEnvironment.transform 29 1076 env17599 = env17600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 1076 env17599 == env17600) = true)

theorem identity17600 : scanCanonicalize (H12AffineFastState.compose env17600 (packedSelected [0,2,3,5,9,12] rootPS)) = affineNative (2^(9+1) ^^^ 68) := by decide +kernel

theorem selectedBound17600 : packedSelected [0,2,3,5,9,12] rootPS < 2^1333 := by decide +kernel

def env17601 : List Nat := [2,4,8,16,32,64,8,256,277,68,0,261,332,340,1,34,261,80,68,0,260,324,16,34,332,64,16,340,340,112,68,324,256,0,0,277]

theorem envBound17601 : H12AffineFastState.Bounded env17601 := by
  intro p hp
  have h : env17601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17600_17601 : H12AffineEnvironment.transform 9 68 env17600 = env17601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 68 env17600 == env17601) = true)

theorem identity17601 : scanCanonicalize (H12AffineFastState.compose env17601 (packedSelected [2,5,8,9,13] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound17601 : packedSelected [2,5,8,9,13] rootPS < 2^1333 := by decide +kernel

def env17602 : List Nat := [2,4,8,16,32,64,8,69,80,68,0,64,9,17,1,34,64,80,68,0,65,1,16,34,9,64,16,17,17,112,68,1,69,0,0,80]

theorem envBound17602 : H12AffineFastState.Bounded env17602 := by
  intro p hp
  have h : env17602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17601_17602 : H12AffineEnvironment.transform 7 69 env17601 = env17602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env17601 == env17602) = true)

theorem identity17602 : scanCanonicalize (H12AffineFastState.compose env17602 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound17602 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17603 : List Nat := [2,4,8,1,32,64,8,69,65,68,0,64,9,0,1,34,64,65,68,0,65,1,1,34,9,64,1,0,0,97,68,1,69,0,0,65]

theorem envBound17603 : H12AffineFastState.Bounded env17603 := by
  intro p hp
  have h : env17603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17602_17603 : H12AffineEnvironment.transform 3 1 env17602 = env17603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env17602 == env17603) = true)

theorem identity17603 : scanCanonicalize (H12AffineFastState.compose env17603 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound17603 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env17604 : List Nat := [2,4,8,1,32,0,8,5,1,4,0,0,9,0,1,34,0,1,4,0,1,1,1,34,9,0,1,0,0,33,4,1,5,0,0,1]

theorem envBound17604 : H12AffineFastState.Bounded env17604 := by
  intro p hp
  have h : env17604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17603_17604 : H12AffineEnvironment.transform 5 0 env17603 = env17604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env17603 == env17604) = true)

def env17605 : List Nat := [2,4,8,16,32,64,8,256,277,1024,1,1345,1288,1296,1,34,1345,1044,1024,0,1344,1280,16,34,1288,64,16,1296,1296,1073741824,1024,1280,256,0,1092,277]

theorem envBound17605 : H12AffineFastState.Bounded env17605 := by
  intro p hp
  have h : env17605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17598_17605 : H12AffineEnvironment.transform 10 1 env17598 = env17605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env17598 == env17605) = true)

theorem identity17605 : scanCanonicalize (H12AffineFastState.compose env17605 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 1045) := by decide +kernel

theorem selectedBound17605 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env17606 : List Nat := [2,4,8,16,32,64,8,256,277,1024,1,1345,1288,1296,1,34,1345,1044,1024,0,1344,1280,16,34,1288,64,16,1296,1296,1045,1024,1280,256,0,1092,277]

theorem envBound17606 : H12AffineFastState.Bounded env17606 := by
  intro p hp
  have h : env17606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17605_17606 : H12AffineEnvironment.transform 29 1045 env17605 = env17606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 1045 env17605 == env17606) = true)

theorem identity17606 : scanCanonicalize (H12AffineFastState.compose env17606 (packedSelected [1,2,3,5,8,12,13] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound17606 : packedSelected [1,2,3,5,8,12,13] rootPS < 2^1333 := by decide +kernel

def env17607 : List Nat := [2,4,8,16,32,64,8,256,277,53,1,372,317,293,1,34,372,33,53,0,373,309,16,34,317,64,16,293,293,32,53,309,256,0,113,277]

theorem envBound17607 : H12AffineFastState.Bounded env17607 := by
  intro p hp
  have h : env17607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17606_17607 : H12AffineEnvironment.transform 9 53 env17606 = env17607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env17606 == env17607) = true)

theorem identity17607 : scanCanonicalize (H12AffineFastState.compose env17607 (packedSelected [2,9] rootPS)) = affineNative (2^(7+1) ^^^ 100) := by decide +kernel

theorem selectedBound17607 : packedSelected [2,9] rootPS < 2^1333 := by decide +kernel

def env17608 : List Nat := [2,4,8,16,32,64,8,100,113,53,1,16,89,65,1,34,16,33,53,0,17,81,16,34,89,64,16,65,65,32,53,81,100,0,113,113]

theorem envBound17608 : H12AffineFastState.Bounded env17608 := by
  intro p hp
  have h : env17608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17607_17608 : H12AffineEnvironment.transform 7 100 env17607 = env17608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 100 env17607 == env17608) = true)

theorem identity17608 : scanCanonicalize (H12AffineFastState.compose env17608 (packedSelected [0,1,3] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound17608 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env17609 : List Nat := [2,4,8,16,32,49,8,21,0,53,1,16,40,48,1,34,16,33,53,0,17,32,16,34,40,49,16,48,48,32,53,32,21,0,0,0]

theorem envBound17609 : H12AffineFastState.Bounded env17609 := by
  intro p hp
  have h : env17609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17608_17609 : H12AffineEnvironment.transform 5 49 env17608 = env17609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env17608 == env17609) = true)

theorem identity17609 : scanCanonicalize (H12AffineFastState.compose env17609 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound17609 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17610 : List Nat := [2,4,8,1,32,32,8,4,0,36,1,1,40,33,1,34,1,33,36,0,0,32,1,34,40,32,1,33,33,32,36,32,4,0,0,0]

theorem envBound17610 : H12AffineFastState.Bounded env17610 := by
  intro p hp
  have h : env17610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17609_17610 : H12AffineEnvironment.transform 3 1 env17609 = env17610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env17609 == env17610) = true)

theorem identity17610 : scanCanonicalize (H12AffineFastState.compose env17610 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound17610 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17611 : List Nat := [2,4,8,1,0,0,8,4,0,4,1,1,8,1,1,2,1,1,4,0,0,0,1,2,8,0,1,1,1,0,4,0,4,0,0,0]

theorem envBound17611 : H12AffineFastState.Bounded env17611 := by
  intro p hp
  have h : env17611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17610_17611 : H12AffineEnvironment.transform 4 0 env17610 = env17611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17610 == env17611) = true)

def env17612 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1345,1288,1296,1,34,1345,1792,1024,0,1344,1281,16,34,1289,64,773,1296,1296,1073741824,1024,1280,256,0,1092,512]

theorem envBound17612 : H12AffineFastState.Bounded env17612 := by
  intro p hp
  have h : env17612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17596_17612 : H12AffineEnvironment.transform 6 9 env17596 = env17612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env17596 == env17612) = true)

theorem identity17612 : scanCanonicalize (H12AffineFastState.compose env17612 (packedSelected [7] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound17612 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env17613 : List Nat := [2,4,8,1,32,64,9,256,512,1024,2048,1345,1288,1281,1,34,1345,1792,1024,0,1344,1281,1,34,1289,64,773,1281,1281,1073741824,1024,1280,256,0,1092,512]

theorem envBound17613 : H12AffineFastState.Bounded env17613 := by
  intro p hp
  have h : env17613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17612_17613 : H12AffineEnvironment.transform 3 1 env17612 = env17613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env17612 == env17613) = true)

def env17614 : List Nat := [2,4,8,1,32,64,9,256,512,1024,0,1345,1288,1281,1,34,1345,1792,1024,0,1344,1281,1,34,1289,64,773,1281,1281,1073741824,1024,1280,256,0,1092,512]

theorem envBound17614 : H12AffineFastState.Bounded env17614 := by
  intro p hp
  have h : env17614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17613_17614 : H12AffineEnvironment.transform 10 0 env17613 = env17614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env17613 == env17614) = true)

theorem identity17614 : scanCanonicalize (H12AffineFastState.compose env17614 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 1061) := by decide +kernel

theorem selectedBound17614 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env17615 : List Nat := [2,4,8,1,32,64,9,256,512,1024,0,1345,1288,1281,1,34,1345,1792,1024,0,1344,1281,1,34,1289,64,773,1281,1281,1061,1024,1280,256,0,1092,512]

theorem envBound17615 : H12AffineFastState.Bounded env17615 := by
  intro p hp
  have h : env17615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17614_17615 : H12AffineEnvironment.transform 29 1061 env17614 = env17615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 1061 env17614 == env17615) = true)

theorem identity17615 : scanCanonicalize (H12AffineFastState.compose env17615 (packedSelected [0,1,2,5,13] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound17615 : packedSelected [0,1,2,5,13] rootPS < 2^1333 := by decide +kernel

def env17616 : List Nat := [2,4,8,1,32,64,9,36,512,1024,0,1125,1068,1061,1,34,1125,1572,1024,0,1124,1061,1,34,1069,64,545,1061,1061,1061,1024,1060,36,0,1092,512]

theorem envBound17616 : H12AffineFastState.Bounded env17616 := by
  intro p hp
  have h : env17616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17615_17616 : H12AffineEnvironment.transform 7 36 env17615 = env17616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env17615 == env17616) = true)

theorem identity17616 : scanCanonicalize (H12AffineFastState.compose env17616 (packedSelected [1,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound17616 : packedSelected [1,4,5] rootPS < 2^1333 := by decide +kernel

def env17617 : List Nat := [2,4,8,1,32,64,9,36,0,1024,0,1125,1068,1061,1,34,1125,1060,1024,0,1124,1061,1,34,1069,64,33,1061,1061,1061,1024,1060,36,0,1092,0]

theorem envBound17617 : H12AffineFastState.Bounded env17617 := by
  intro p hp
  have h : env17617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17616_17617 : H12AffineEnvironment.transform 8 0 env17616 = env17617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env17616 == env17617) = true)

theorem identity17617 : scanCanonicalize (H12AffineFastState.compose env17617 (packedSelected [3,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound17617 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env17618 : List Nat := [2,4,8,1,1,64,9,5,0,1024,0,1092,1037,1028,1,3,1092,1029,1024,0,1093,1028,1,3,1036,64,0,1028,1028,1028,1024,1029,5,0,1092,0]

theorem envBound17618 : H12AffineFastState.Bounded env17618 := by
  intro p hp
  have h : env17618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17617_17618 : H12AffineEnvironment.transform 4 1 env17617 = env17618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env17617 == env17618) = true)

def env17619 : List Nat := [2,4,8,1,32,64,9,256,512,1024,1,1345,1288,1281,1,34,1345,1792,1024,0,1344,1281,1,34,1289,64,773,1281,1281,1073741824,1024,1280,256,0,1092,512]

theorem envBound17619 : H12AffineFastState.Bounded env17619 := by
  intro p hp
  have h : env17619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17613_17619 : H12AffineEnvironment.transform 10 1 env17613 = env17619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env17613 == env17619) = true)

theorem identity17619 : scanCanonicalize (H12AffineFastState.compose env17619 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 1028) := by decide +kernel

theorem selectedBound17619 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env17620 : List Nat := [2,4,8,1,32,64,9,256,512,1024,1,1345,1288,1281,1,34,1345,1792,1024,0,1344,1281,1,34,1289,64,773,1281,1281,1028,1024,1280,256,0,1092,512]

theorem envBound17620 : H12AffineFastState.Bounded env17620 := by
  intro p hp
  have h : env17620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17619_17620 : H12AffineEnvironment.transform 29 1028 env17619 = env17620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 1028 env17619 == env17620) = true)

theorem identity17620 : scanCanonicalize (H12AffineFastState.compose env17620 (packedSelected [0,1,2,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound17620 : packedSelected [0,1,2,5] rootPS < 2^1333 := by decide +kernel

def env17621 : List Nat := [2,4,8,1,0,64,9,256,512,1024,1,1345,1288,1281,1,2,1345,1792,1024,0,1344,1281,1,2,1289,64,773,1281,1281,1028,1024,1280,256,0,1092,512]

theorem envBound17621 : H12AffineFastState.Bounded env17621 := by
  intro p hp
  have h : env17621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17620_17621 : H12AffineEnvironment.transform 4 0 env17620 = env17621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17620 == env17621) = true)

theorem identity17621 : scanCanonicalize (H12AffineFastState.compose env17621 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 768) := by decide +kernel

theorem selectedBound17621 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17622 : List Nat := [2,4,8,1,0,64,9,256,512,768,1,577,520,513,1,2,577,0,768,0,576,513,1,2,521,64,773,513,513,772,768,512,256,0,836,512]

theorem envBound17622 : H12AffineFastState.Bounded env17622 := by
  intro p hp
  have h : env17622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17621_17622 : H12AffineEnvironment.transform 9 768 env17621 = env17622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 768 env17621 == env17622) = true)

def env17623 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,1289,1296,1,65536,1345,1928,1024,0,1344,1417,16,65536,1409,64,773,1296,1296,1073741824,1024,1281,256,65570,1092,512]

theorem envBound17623 : H12AffineFastState.Bounded env17623 := by
  intro p hp
  have h : env17623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17594_17623 : H12AffineEnvironment.transform 12 1289 env17594 = env17623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1289 env17594 == env17623) = true)

theorem identity17623 : scanCanonicalize (H12AffineFastState.compose env17623 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 294) := by decide +kernel

theorem selectedBound17623 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env17624 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,1289,1296,1,294,1345,1928,1024,0,1344,1417,16,294,1409,64,773,1296,1296,1073741824,1024,1281,256,260,1092,512]

theorem envBound17624 : H12AffineFastState.Bounded env17624 := by
  intro p hp
  have h : env17624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17623_17624 : H12AffineEnvironment.transform 15 294 env17623 = env17624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 294 env17623 == env17624) = true)

def env17625 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1345,1289,1296,1,294,1345,1792,1024,0,1344,1281,16,294,1289,64,773,1296,1296,1073741824,1024,1281,256,260,1092,512]

theorem envBound17625 : H12AffineFastState.Bounded env17625 := by
  intro p hp
  have h : env17625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17624_17625 : H12AffineEnvironment.transform 6 8 env17624 = env17625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env17624 == env17625) = true)

theorem identity17625 : scanCanonicalize (H12AffineFastState.compose env17625 (packedSelected [7] rootPS)) = affineNative (2^(8+1) ^^^ 277) := by decide +kernel

theorem selectedBound17625 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env17626 : List Nat := [2,4,8,16,32,64,8,256,277,1024,2048,1345,1289,1296,1,294,1345,1045,1024,0,1344,1281,16,294,1289,64,16,1296,1296,1073741824,1024,1281,256,260,1092,277]

theorem envBound17626 : H12AffineFastState.Bounded env17626 := by
  intro p hp
  have h : env17626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17625_17626 : H12AffineEnvironment.transform 8 277 env17625 = env17626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env17625 == env17626) = true)

def env17627 : List Nat := [2,4,8,16,32,64,8,256,277,1024,0,1345,1289,1296,1,294,1345,1045,1024,0,1344,1281,16,294,1289,64,16,1296,1296,1073741824,1024,1281,256,260,1092,277]

theorem envBound17627 : H12AffineFastState.Bounded env17627 := by
  intro p hp
  have h : env17627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17626_17627 : H12AffineEnvironment.transform 10 0 env17626 = env17627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env17626 == env17627) = true)

theorem identity17627 : scanCanonicalize (H12AffineFastState.compose env17627 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 1077) := by decide +kernel

theorem selectedBound17627 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env17628 : List Nat := [2,4,8,16,32,64,8,256,277,1024,0,1345,1289,1296,1,294,1345,1045,1024,0,1344,1281,16,294,1289,64,16,1296,1296,1077,1024,1281,256,260,1092,277]

theorem envBound17628 : H12AffineFastState.Bounded env17628 := by
  intro p hp
  have h : env17628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17627_17628 : H12AffineEnvironment.transform 29 1077 env17627 = env17628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 1077 env17627 == env17628) = true)

theorem identity17628 : scanCanonicalize (H12AffineFastState.compose env17628 (packedSelected [0,1,2,3,4,5,8,9,12] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound17628 : packedSelected [0,1,2,3,4,5,8,9,12] rootPS < 2^1333 := by decide +kernel

def env17629 : List Nat := [2,4,8,16,32,64,8,256,277,101,0,292,364,373,1,294,292,112,101,0,293,356,16,294,364,64,16,373,373,80,101,356,256,260,33,277]

theorem envBound17629 : H12AffineFastState.Bounded env17629 := by
  intro p hp
  have h : env17629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17628_17629 : H12AffineEnvironment.transform 9 101 env17628 = env17629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env17628 == env17629) = true)

theorem identity17629 : scanCanonicalize (H12AffineFastState.compose env17629 (packedSelected [1,2,3,4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound17629 : packedSelected [1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env17630 : List Nat := [2,4,8,16,32,64,8,4,17,101,0,32,104,113,1,34,32,112,101,0,33,96,16,34,104,64,16,113,113,80,101,96,4,0,33,17]

theorem envBound17630 : H12AffineFastState.Bounded env17630 := by
  intro p hp
  have h : env17630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17629_17630 : H12AffineEnvironment.transform 7 4 env17629 = env17630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env17629 == env17630) = true)

theorem identity17630 : scanCanonicalize (H12AffineFastState.compose env17630 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound17630 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env17631 : List Nat := [2,4,8,16,16,64,8,4,17,85,0,16,88,65,1,18,16,64,85,0,17,80,16,18,88,64,16,65,65,80,85,80,4,0,17,17]

theorem envBound17631 : H12AffineFastState.Bounded env17631 := by
  intro p hp
  have h : env17631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17630_17631 : H12AffineEnvironment.transform 4 16 env17630 = env17631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env17630 == env17631) = true)

theorem identity17631 : scanCanonicalize (H12AffineFastState.compose env17631 (packedSelected [0,1] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound17631 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env17632 : List Nat := [2,4,8,16,16,17,8,4,17,4,0,16,9,16,1,18,16,17,4,0,17,1,16,18,9,17,16,16,16,1,4,1,4,0,17,17]

theorem envBound17632 : H12AffineFastState.Bounded env17632 := by
  intro p hp
  have h : env17632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17631_17632 : H12AffineEnvironment.transform 5 17 env17631 = env17632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env17631 == env17632) = true)

theorem identity17632 : scanCanonicalize (H12AffineFastState.compose env17632 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound17632 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17633 : List Nat := [2,4,8,1,1,0,8,4,0,4,0,1,9,1,1,3,1,0,4,0,0,1,1,3,9,0,1,1,1,1,4,1,4,0,0,0]

theorem envBound17633 : H12AffineFastState.Bounded env17633 := by
  intro p hp
  have h : env17633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17632_17633 : H12AffineEnvironment.transform 3 1 env17632 = env17633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env17632 == env17633) = true)

def env17634 : List Nat := [2,4,8,16,32,64,8,256,277,1024,1,1345,1289,1296,1,294,1345,1045,1024,0,1344,1281,16,294,1289,64,16,1296,1296,1073741824,1024,1281,256,260,1092,277]

theorem envBound17634 : H12AffineFastState.Bounded env17634 := by
  intro p hp
  have h : env17634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17626_17634 : H12AffineEnvironment.transform 10 1 env17626 = env17634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env17626 == env17634) = true)

theorem identity17634 : scanCanonicalize (H12AffineFastState.compose env17634 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 1044) := by decide +kernel

theorem selectedBound17634 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env17635 : List Nat := [2,4,8,16,32,64,8,256,277,1024,1,1345,1289,1296,1,294,1345,1045,1024,0,1344,1281,16,294,1289,64,16,1296,1296,1044,1024,1281,256,260,1092,277]

theorem envBound17635 : H12AffineFastState.Bounded env17635 := by
  intro p hp
  have h : env17635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17634_17635 : H12AffineEnvironment.transform 29 1044 env17634 = env17635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 1044 env17634 == env17635) = true)

def env17636 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1345,1289,1296,1,294,1345,1793,1024,0,1344,1280,16,294,1288,64,773,1296,1296,1073741824,1024,1281,256,260,1092,512]

theorem envBound17636 : H12AffineFastState.Bounded env17636 := by
  intro p hp
  have h : env17636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17624_17636 : H12AffineEnvironment.transform 6 9 env17624 = env17636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env17624 == env17636) = true)

theorem identity17636 : scanCanonicalize (H12AffineFastState.compose env17636 (packedSelected [7] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound17636 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env17637 : List Nat := [2,4,8,1,32,64,9,256,512,1024,2048,1345,1289,1281,1,294,1345,1793,1024,0,1344,1280,1,294,1288,64,773,1281,1281,1073741824,1024,1281,256,260,1092,512]

theorem envBound17637 : H12AffineFastState.Bounded env17637 := by
  intro p hp
  have h : env17637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17636_17637 : H12AffineEnvironment.transform 3 1 env17636 = env17637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env17636 == env17637) = true)

def env17638 : List Nat := [2,4,8,1,32,64,9,256,512,1024,0,1345,1289,1281,1,294,1345,1793,1024,0,1344,1280,1,294,1288,64,773,1281,1281,1073741824,1024,1281,256,260,1092,512]

theorem envBound17638 : H12AffineFastState.Bounded env17638 := by
  intro p hp
  have h : env17638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17637_17638 : H12AffineEnvironment.transform 10 0 env17637 = env17638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env17637 == env17638) = true)

theorem identity17638 : scanCanonicalize (H12AffineFastState.compose env17638 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 1060) := by decide +kernel

theorem selectedBound17638 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env17639 : List Nat := [2,4,8,1,32,64,9,256,512,1024,0,1345,1289,1281,1,294,1345,1793,1024,0,1344,1280,1,294,1288,64,773,1281,1281,1060,1024,1281,256,260,1092,512]

theorem envBound17639 : H12AffineFastState.Bounded env17639 := by
  intro p hp
  have h : env17639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17638_17639 : H12AffineEnvironment.transform 29 1060 env17638 = env17639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 1060 env17638 == env17639) = true)

theorem identity17639 : scanCanonicalize (H12AffineFastState.compose env17639 (packedSelected [0,1,2,4,5,8,12] rootPS)) = affineNative (2^(9+1) ^^^ 801) := by decide +kernel

theorem selectedBound17639 : packedSelected [0,1,2,4,5,8,12] rootPS < 2^1333 := by decide +kernel

def env17640 : List Nat := [2,4,8,1,32,64,9,256,512,801,0,608,552,544,1,294,608,32,801,0,609,545,1,294,553,64,773,544,544,773,801,544,256,260,869,512]

theorem envBound17640 : H12AffineFastState.Bounded env17640 := by
  intro p hp
  have h : env17640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17639_17640 : H12AffineEnvironment.transform 9 801 env17639 = env17640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 801 env17639 == env17640) = true)

theorem identity17640 : scanCanonicalize (H12AffineFastState.compose env17640 (packedSelected [1,3,4] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound17640 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env17641 : List Nat := [2,4,8,1,32,64,9,36,512,517,0,608,552,544,1,2,608,32,517,0,609,545,1,2,553,64,545,544,544,545,517,544,36,32,577,512]

theorem envBound17641 : H12AffineFastState.Bounded env17641 := by
  intro p hp
  have h : env17641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17640_17641 : H12AffineEnvironment.transform 7 36 env17640 = env17641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env17640 == env17641) = true)

theorem identity17641 : scanCanonicalize (H12AffineFastState.compose env17641 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound17641 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17642 : List Nat := [2,4,8,1,32,64,9,36,32,37,0,64,8,0,1,2,64,32,37,0,65,1,1,2,9,64,1,0,0,1,37,0,36,32,97,32]

theorem envBound17642 : H12AffineFastState.Bounded env17642 := by
  intro p hp
  have h : env17642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17641_17642 : H12AffineEnvironment.transform 8 32 env17641 = env17642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env17641 == env17642) = true)

theorem identity17642 : scanCanonicalize (H12AffineFastState.compose env17642 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound17642 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env17643 : List Nat := [2,4,8,1,32,33,9,36,32,37,0,33,8,0,1,2,33,32,37,0,32,1,1,2,9,33,1,0,0,1,37,0,36,32,0,32]

theorem envBound17643 : H12AffineFastState.Bounded env17643 := by
  intro p hp
  have h : env17643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17642_17643 : H12AffineEnvironment.transform 5 33 env17642 = env17643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env17642 == env17643) = true)

theorem identity17643 : scanCanonicalize (H12AffineFastState.compose env17643 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound17643 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17644 : List Nat := [2,4,8,1,1,0,9,5,1,4,0,0,8,0,1,2,0,1,4,0,1,1,1,2,9,0,1,0,0,1,4,0,5,1,0,1]

theorem envBound17644 : H12AffineFastState.Bounded env17644 := by
  intro p hp
  have h : env17644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17643_17644 : H12AffineEnvironment.transform 4 1 env17643 = env17644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env17643 == env17644) = true)

def env17645 : List Nat := [2,4,8,1,32,64,9,256,512,1024,1,1345,1289,1281,1,294,1345,1793,1024,0,1344,1280,1,294,1288,64,773,1281,1281,1073741824,1024,1281,256,260,1092,512]

theorem envBound17645 : H12AffineFastState.Bounded env17645 := by
  intro p hp
  have h : env17645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17637_17645 : H12AffineEnvironment.transform 10 1 env17637 = env17645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env17637 == env17645) = true)

theorem identity17645 : scanCanonicalize (H12AffineFastState.compose env17645 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 1029) := by decide +kernel

theorem selectedBound17645 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env17646 : List Nat := [2,4,8,1,32,64,9,256,512,1024,1,1345,1289,1281,1,294,1345,1793,1024,0,1344,1280,1,294,1288,64,773,1281,1281,1029,1024,1281,256,260,1092,512]

theorem envBound17646 : H12AffineFastState.Bounded env17646 := by
  intro p hp
  have h : env17646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17645_17646 : H12AffineEnvironment.transform 29 1029 env17645 = env17646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 1029 env17645 == env17646) = true)

theorem identity17646 : scanCanonicalize (H12AffineFastState.compose env17646 (packedSelected [4,5,9,12,13] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound17646 : packedSelected [4,5,9,12,13] rootPS < 2^1333 := by decide +kernel

def env17647 : List Nat := [2,4,8,1,32,64,9,256,0,1024,1,1345,1289,1281,1,294,1345,1281,1024,0,1344,1280,1,294,1288,64,261,1281,1281,1029,1024,1281,256,260,1092,0]

theorem envBound17647 : H12AffineFastState.Bounded env17647 := by
  intro p hp
  have h : env17647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17646_17647 : H12AffineEnvironment.transform 8 0 env17646 = env17647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env17646 == env17647) = true)

theorem identity17647 : scanCanonicalize (H12AffineFastState.compose env17647 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 289) := by decide +kernel

theorem selectedBound17647 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17648 : List Nat := [2,4,8,1,32,64,9,256,0,289,1,96,40,32,1,294,96,32,289,0,97,33,1,294,41,64,261,32,32,292,289,32,256,260,357,0]

theorem envBound17648 : H12AffineFastState.Bounded env17648 := by
  intro p hp
  have h : env17648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17647_17648 : H12AffineEnvironment.transform 9 289 env17647 = env17648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 289 env17647 == env17648) = true)

theorem identity17648 : scanCanonicalize (H12AffineFastState.compose env17648 (packedSelected [2,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound17648 : packedSelected [2,3,4] rootPS < 2^1333 := by decide +kernel

def env17649 : List Nat := [2,4,8,1,1,64,9,256,0,256,1,65,9,1,1,263,65,1,256,0,64,0,1,263,8,64,261,1,1,261,256,1,256,260,324,0]

theorem envBound17649 : H12AffineFastState.Bounded env17649 := by
  intro p hp
  have h : env17649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17648_17649 : H12AffineEnvironment.transform 4 1 env17648 = env17649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env17648 == env17649) = true)

theorem identity17649 : scanCanonicalize (H12AffineFastState.compose env17649 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound17649 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17650 : List Nat := [2,4,8,1,1,64,9,4,0,4,1,65,9,1,1,3,65,1,4,0,64,0,1,3,8,64,1,1,1,1,4,1,4,0,64,0]

theorem envBound17650 : H12AffineFastState.Bounded env17650 := by
  intro p hp
  have h : env17650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17649_17650 : H12AffineEnvironment.transform 7 4 env17649 = env17650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env17649 == env17650) = true)

theorem identity17650 : scanCanonicalize (H12AffineFastState.compose env17650 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound17650 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env17651 : List Nat := [2,4,8,1,1,1,9,4,0,4,1,0,9,1,1,3,0,1,4,0,1,0,1,3,8,1,1,1,1,1,4,1,4,0,1,0]

theorem envBound17651 : H12AffineFastState.Bounded env17651 := by
  intro p hp
  have h : env17651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17650_17651 : H12AffineEnvironment.transform 5 1 env17650 = env17651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env17650 == env17651) = true)

def env17652 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,65536,1345,8833,1024,32769,1344,8321,16,98304,8328,64,772,1296,1296,1073741824,1025,8201,256,98338,1093,512]

theorem envBound17652 : H12AffineFastState.Bounded env17652 := by
  intro p hp
  have h : env17652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17592_17652 : H12AffineEnvironment.transform 21 8321 env17592 = env17652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8321 env17592 == env17652) = true)

theorem identity17652 : scanCanonicalize (H12AffineFastState.compose env17652 (packedSelected [1,8,28] rootPS)) = affineNative (2^(14+1) ^^^ 261) := by decide +kernel

theorem selectedBound17652 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env17653 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,261,65536,1345,8833,1024,260,1344,8321,16,65797,8328,64,772,1296,1296,1073741824,1025,8201,256,65831,1093,512]

theorem envBound17653 : H12AffineFastState.Bounded env17653 := by
  intro p hp
  have h : env17653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17652_17653 : H12AffineEnvironment.transform 14 261 env17652 = env17653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 261 env17652 == env17653) = true)

def env17654 : List Nat := [2,4,8,16,32,64,128,4,512,1024,2048,1093,8192,1044,1,65536,1093,8833,1024,0,1092,8321,16,65537,8328,64,512,1044,1044,1073741824,1025,8201,4,65571,1093,512]

theorem envBound17654 : H12AffineFastState.Bounded env17654 := by
  intro p hp
  have h : env17654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17653_17654 : H12AffineEnvironment.transform 7 4 env17653 = env17654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env17653 == env17654) = true)

theorem identity17654 : scanCanonicalize (H12AffineFastState.compose env17654 (packedSelected [6] rootPS)) = affineNative (2^(29+1) ^^^ 11309) := by decide +kernel

theorem selectedBound17654 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env17655 : List Nat := [2,4,8,16,32,64,128,4,512,1024,2048,1093,8192,1044,1,65536,1093,8833,1024,0,1092,8321,16,65537,8328,64,512,1044,1044,11309,1025,8201,4,65571,1093,512]

theorem envBound17655 : H12AffineFastState.Bounded env17655 := by
  intro p hp
  have h : env17655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17654_17655 : H12AffineEnvironment.transform 29 11309 env17654 = env17655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 11309 env17654 == env17655) = true)

theorem identity17655 : scanCanonicalize (H12AffineFastState.compose env17655 (packedSelected [1,12,13] rootPS)) = affineNative (2^(15+1) ^^^ 2083) := by decide +kernel

theorem selectedBound17655 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env17656 : List Nat := [2,4,8,16,32,64,128,4,512,1024,2048,1093,8192,1044,1,2083,1093,8833,1024,0,1092,8321,16,2082,8328,64,512,1044,1044,11309,1025,8201,4,2048,1093,512]

theorem envBound17656 : H12AffineFastState.Bounded env17656 := by
  intro p hp
  have h : env17656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17655_17656 : H12AffineEnvironment.transform 15 2083 env17655 = env17656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2083 env17655 == env17656) = true)

theorem identity17656 : scanCanonicalize (H12AffineFastState.compose env17656 (packedSelected [3,15,17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound17656 : packedSelected [3,15,17] rootPS < 2^1333 := by decide +kernel

def env17657 : List Nat := [2,4,8,16,32,64,8,4,512,1024,2048,1093,8192,1044,1,2083,1093,8713,1024,0,1092,8201,16,2082,8192,64,512,1044,1044,11309,1025,8201,4,2048,1093,512]

theorem envBound17657 : H12AffineFastState.Bounded env17657 := by
  intro p hp
  have h : env17657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17656_17657 : H12AffineEnvironment.transform 6 8 env17656 = env17657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env17656 == env17657) = true)

theorem identity17657 : scanCanonicalize (H12AffineFastState.compose env17657 (packedSelected [7] rootPS)) = affineNative (2^(12+1) ^^^ 3613) := by decide +kernel

theorem selectedBound17657 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env17658 : List Nat := [2,4,8,16,32,64,8,4,512,1024,2048,1093,3613,1044,1,2083,1093,3092,1024,0,1092,3604,16,2082,3613,64,512,1044,1044,560,1025,3604,4,2048,1093,512]

theorem envBound17658 : H12AffineFastState.Bounded env17658 := by
  intro p hp
  have h : env17658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17657_17658 : H12AffineEnvironment.transform 12 3613 env17657 = env17658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3613 env17657 == env17658) = true)

theorem identity17658 : scanCanonicalize (H12AffineFastState.compose env17658 (packedSelected [9,32] rootPS)) = affineNative (2^(10+1) ^^^ 1636) := by decide +kernel

theorem selectedBound17658 : packedSelected [9,32] rootPS < 2^1333 := by decide +kernel

def env17659 : List Nat := [2,4,8,16,32,64,8,4,512,1024,1636,1093,121,1044,1,1607,1093,624,1024,0,1092,112,16,1606,121,64,512,1044,1044,560,1025,112,4,1636,1093,512]

theorem envBound17659 : H12AffineFastState.Bounded env17659 := by
  intro p hp
  have h : env17659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17658_17659 : H12AffineEnvironment.transform 10 1636 env17658 = env17659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1636 env17658 == env17659) = true)

theorem identity17659 : scanCanonicalize (H12AffineFastState.compose env17659 (packedSelected [1,3,12] rootPS)) = affineNative (2^(9+1) ^^^ 580) := by decide +kernel

theorem selectedBound17659 : packedSelected [1,3,12] rootPS < 2^1333 := by decide +kernel

def env17660 : List Nat := [2,4,8,16,32,64,8,4,512,580,32,513,121,592,1,3,513,624,580,0,512,112,16,2,121,64,512,592,592,560,581,112,4,32,513,512]

theorem envBound17660 : H12AffineFastState.Bounded env17660 := by
  intro p hp
  have h : env17660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17659_17660 : H12AffineEnvironment.transform 9 580 env17659 = env17660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 580 env17659 == env17660) = true)

theorem identity17660 : scanCanonicalize (H12AffineFastState.compose env17660 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound17660 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env17661 : List Nat := [2,4,8,16,32,64,8,4,1,69,32,0,121,81,1,3,0,113,69,0,1,112,16,2,121,64,1,81,81,49,68,112,4,32,0,1]

end H12CloudChart2