import H12CloudChart2Data050

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env12470 : List Nat := [2,4,8,16,32,16,128,256,429,434,0,163,269,163,292,8,162,162,435,293,162,261,17,40,389,16,163,163,162,0,182,302,257,169,163,429]

theorem envBound12470 : H12AffineFastState.Bounded env12470 := by
  intro p hp
  have h : env12470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12469_12470 : H12AffineEnvironment.transform 9 434 env12469 = env12470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 434 env12469 == env12470) = true)

theorem identity12470 : scanCanonicalize (H12AffineFastState.compose env12470 (packedSelected [3] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound12470 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env12471 : List Nat := [2,4,8,16,32,16,128,172,1,30,0,163,161,163,136,8,162,162,31,137,162,169,17,40,41,16,163,163,162,0,182,130,173,169,163,1]

theorem envBound12471 : H12AffineFastState.Bounded env12471 := by
  intro p hp
  have h : env12471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12470_12471 : H12AffineEnvironment.transform 7 172 env12470 = env12471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env12470 == env12471) = true)

theorem identity12471 : scanCanonicalize (H12AffineFastState.compose env12471 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound12471 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env12472 : List Nat := [2,4,8,16,27,16,128,151,1,30,0,152,154,152,136,8,153,153,31,137,153,146,17,19,18,16,152,152,153,0,141,130,150,146,152,1]

theorem envBound12472 : H12AffineFastState.Bounded env12472 := by
  intro p hp
  have h : env12472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12471_12472 : H12AffineEnvironment.transform 4 27 env12471 = env12472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env12471 == env12472) = true)

theorem identity12472 : scanCanonicalize (H12AffineFastState.compose env12472 (packedSelected [5] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound12472 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env12473 : List Nat := [2,4,8,16,27,16,8,31,1,30,0,16,18,16,0,8,17,17,31,1,17,26,17,19,18,16,16,16,17,0,5,10,30,26,16,1]

theorem envBound12473 : H12AffineFastState.Bounded env12473 := by
  intro p hp
  have h : env12473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12472_12473 : H12AffineEnvironment.transform 6 8 env12472 = env12473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env12472 == env12473) = true)

theorem identity12473 : scanCanonicalize (H12AffineFastState.compose env12473 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound12473 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12474 : List Nat := [2,4,8,1,10,1,8,14,1,15,0,1,3,1,0,8,0,0,14,1,0,11,0,2,3,1,1,1,0,0,5,10,15,11,1,1]

theorem envBound12474 : H12AffineFastState.Bounded env12474 := by
  intro p hp
  have h : env12474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12473_12474 : H12AffineEnvironment.transform 3 1 env12473 = env12474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env12473 == env12474) = true)

theorem identity12474 : scanCanonicalize (H12AffineFastState.compose env12474 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound12474 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12475 : List Nat := [2,4,3,1,1,1,3,5,1,4,0,1,3,1,0,3,0,0,5,1,0,0,0,2,3,1,1,1,0,0,5,1,4,0,1,1]

theorem envBound12475 : H12AffineFastState.Bounded env12475 := by
  intro p hp
  have h : env12475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12474_12475 : H12AffineEnvironment.transform 2 3 env12474 = env12475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env12474 == env12475) = true)

def env12476 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1345,262144,524288,32769,4097,8200,17664,98565,8328,541008,795916,16385,545088,1073741824,1284,4294967296,256,4295074215,1344,512]

theorem envBound12476 : H12AffineFastState.Bounded env12476 := by
  intro p hp
  have h : env12476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12457_12476 : H12AffineEnvironment.transform 16 1345 env12457 = env12476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env12457 == env12476) = true)

theorem identity12476 : scanCanonicalize (H12AffineFastState.compose env12476 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 820517) := by decide +kernel

theorem selectedBound12476 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env12477 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1345,262144,524288,32769,4097,8200,17664,98565,8328,541008,795916,16385,545088,820517,1284,4294967296,256,4295074215,1344,512]

theorem envBound12477 : H12AffineFastState.Bounded env12477 := by
  intro p hp
  have h : env12477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12476_12477 : H12AffineEnvironment.transform 29 820517 env12476 = env12477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 820517 env12476 == env12477) = true)

def env12478 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1345,262144,304168,32769,4097,8200,17664,98565,8328,320888,33060,16385,324968,8461,1284,4294967296,256,4295074215,1344,512]

theorem envBound12478 : H12AffineFastState.Bounded env12478 := by
  intro p hp
  have h : env12478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12477_12478 : H12AffineEnvironment.transform 18 304168 env12477 = env12478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 304168 env12477 == env12478) = true)

theorem identity12478 : scanCanonicalize (H12AffineFastState.compose env12478 (packedSelected [4,9,18] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound12478 : packedSelected [4,9,18] rootPS < 2^1333 := by decide +kernel

def env12479 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,269,16384,32768,65536,1345,262144,296229,32769,4097,261,17664,98565,389,312437,33060,16385,316517,0,1284,4294967296,256,4295065770,1344,512]

theorem envBound12479 : H12AffineFastState.Bounded env12479 := by
  intro p hp
  have h : env12479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12478_12479 : H12AffineEnvironment.transform 12 269 env12478 = env12479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env12478 == env12479) = true)

theorem identity12479 : scanCanonicalize (H12AffineFastState.compose env12479 (packedSelected [20,23] rootPS)) = affineNative (2^(17+1) ^^^ 0) := by decide +kernel

theorem selectedBound12479 : packedSelected [20,23] rootPS < 2^1333 := by decide +kernel

def env12480 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,269,16384,32768,65536,1345,0,34085,32769,4097,261,17664,98565,389,50293,33060,16385,54373,0,1284,4294967296,256,4295065770,1344,512]

theorem envBound12480 : H12AffineFastState.Bounded env12480 := by
  intro p hp
  have h : env12480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12479_12480 : H12AffineEnvironment.transform 17 0 env12479 = env12480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 0 env12479 == env12480) = true)

def env12481 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1345,262144,304169,32769,4097,8200,17664,98565,8328,320889,33061,16385,324969,8460,1284,4294967296,256,4295074215,1344,512]

theorem envBound12481 : H12AffineFastState.Bounded env12481 := by
  intro p hp
  have h : env12481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12477_12481 : H12AffineEnvironment.transform 18 304169 env12477 = env12481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 304169 env12477 == env12481) = true)

theorem identity12481 : scanCanonicalize (H12AffineFastState.compose env12481 (packedSelected [3,10,17,19,21,24] rootPS)) = affineNative (2^(17+1) ^^^ 41001) := by decide +kernel

theorem selectedBound12481 : packedSelected [3,10,17,19,21,24] rootPS < 2^1333 := by decide +kernel

def env12482 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1345,41001,1024,32769,4097,8200,17664,98565,8328,17744,33061,16385,21824,8460,1284,4294967296,256,4295074215,1344,512]

theorem envBound12482 : H12AffineFastState.Bounded env12482 := by
  intro p hp
  have h : env12482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12481_12482 : H12AffineEnvironment.transform 17 41001 env12481 = env12482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 41001 env12481 == env12482) = true)

theorem identity12482 : scanCanonicalize (H12AffineFastState.compose env12482 (packedSelected [1,3,10,13,15] rootPS)) = affineNative (2^(15+1) ^^^ 33166) := by decide +kernel

theorem selectedBound12482 : packedSelected [1,3,10,13,15] rootPS < 2^1333 := by decide +kernel

def env12483 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,33166,1345,41001,1024,32769,4097,8200,17664,139,8328,17744,33061,16385,21824,8460,1284,4294967296,256,4294975529,1344,512]

theorem envBound12483 : H12AffineFastState.Bounded env12483 := by
  intro p hp
  have h : env12483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12482_12483 : H12AffineEnvironment.transform 15 33166 env12482 = env12483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33166 env12482 == env12483) = true)

theorem identity12483 : scanCanonicalize (H12AffineFastState.compose env12483 (packedSelected [5,8,10,12,13] rootPS)) = affineNative (2^(13+1) ^^^ 4177) := by decide +kernel

theorem selectedBound12483 : packedSelected [5,8,10,12,13] rootPS < 2^1333 := by decide +kernel

def env12484 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,4177,32768,33166,1345,41001,1024,32769,4097,8200,5457,139,8328,5377,33061,4176,1297,8460,1284,4294967296,256,4294975529,1344,512]

theorem envBound12484 : H12AffineFastState.Bounded env12484 := by
  intro p hp
  have h : env12484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12483_12484 : H12AffineEnvironment.transform 13 4177 env12483 = env12484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env12483 == env12484) = true)

def env12485 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,4177,512,910,1345,8745,1024,513,4097,8200,5457,139,8328,5377,805,4176,1297,8460,1284,4294967296,256,4294975529,1344,512]

theorem envBound12485 : H12AffineFastState.Bounded env12485 := by
  intro p hp
  have h : env12485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12484_12485 : H12AffineEnvironment.transform 14 512 env12484 = env12485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 512 env12484 == env12485) = true)

theorem identity12485 : scanCanonicalize (H12AffineFastState.compose env12485 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 6041) := by decide +kernel

theorem selectedBound12485 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12486 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,4177,512,910,1345,8745,1024,513,4097,8200,5457,139,8328,5377,805,4176,1297,8460,1284,6041,256,14256,1344,512]

theorem envBound12486 : H12AffineFastState.Bounded env12486 := by
  intro p hp
  have h : env12486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12485_12486 : H12AffineEnvironment.transform 31 6041 env12485 = env12486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 6041 env12485 == env12486) = true)

def env12487 : List Nat := [2,4,8,16,32,64,128,256,136,1024,0,4096,8192,4177,136,262,1345,8353,1024,137,4097,8200,5457,139,8328,5377,429,4176,1297,8460,1284,5393,256,13624,1344,136]

theorem envBound12487 : H12AffineFastState.Bounded env12487 := by
  intro p hp
  have h : env12487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12486_12487 : H12AffineEnvironment.transform 8 136 env12486 = env12487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env12486 == env12487) = true)

theorem identity12487 : scanCanonicalize (H12AffineFastState.compose env12487 (packedSelected [2,4] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound12487 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env12488 : List Nat := [2,4,8,16,32,64,128,253,136,1024,0,4096,8192,4177,136,251,1212,8353,1024,137,4097,8200,5292,139,8328,5372,80,4176,1260,8433,1273,5356,253,13509,1213,136]

theorem envBound12488 : H12AffineFastState.Bounded env12488 := by
  intro p hp
  have h : env12488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12487_12488 : H12AffineEnvironment.transform 7 253 env12487 = env12488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env12487 == env12488) = true)

def env12489 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,4096,8192,4177,137,263,1345,8352,1024,136,4097,8200,5457,139,8328,5377,428,4176,1297,8460,1284,5392,256,13625,1344,137]

theorem envBound12489 : H12AffineFastState.Bounded env12489 := by
  intro p hp
  have h : env12489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12486_12489 : H12AffineEnvironment.transform 8 137 env12486 = env12489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env12486 == env12489) = true)

theorem identity12489 : scanCanonicalize (H12AffineFastState.compose env12489 (packedSelected [2,4] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound12489 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env12490 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,4096,120,4177,137,263,1345,216,1024,136,4097,112,5457,139,240,5377,428,4176,1297,372,1284,5392,256,5441,1344,137]

theorem envBound12490 : H12AffineFastState.Bounded env12490 := by
  intro p hp
  have h : env12490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12489_12490 : H12AffineEnvironment.transform 12 120 env12489 = env12490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env12489 == env12490) = true)

theorem identity12490 : scanCanonicalize (H12AffineFastState.compose env12490 (packedSelected [1,3,5] rootPS)) = affineNative (2^(11+1) ^^^ 1345) := by decide +kernel

theorem selectedBound12490 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env12491 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,1345,120,1296,137,263,1345,216,1024,136,1344,112,16,139,240,64,428,1297,1297,372,1284,81,256,0,1344,137]

theorem envBound12491 : H12AffineFastState.Bounded env12491 := by
  intro p hp
  have h : env12491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12490_12491 : H12AffineEnvironment.transform 11 1345 env12490 = env12491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env12490 == env12491) = true)

theorem identity12491 : scanCanonicalize (H12AffineFastState.compose env12491 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound12491 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12492 : List Nat := [2,4,8,16,32,17,128,256,137,1024,0,1296,41,1296,137,263,1296,137,1024,136,1297,33,16,139,161,17,428,1297,1297,293,1284,0,256,0,1297,137]

theorem envBound12492 : H12AffineFastState.Bounded env12492 := by
  intro p hp
  have h : env12492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12491_12492 : H12AffineEnvironment.transform 5 17 env12491 = env12492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env12491 == env12492) = true)

theorem identity12492 : scanCanonicalize (H12AffineFastState.compose env12492 (packedSelected [3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound12492 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env12493 : List Nat := [2,4,8,16,32,17,128,37,137,1024,0,1077,41,1077,137,34,1077,137,1024,136,1076,33,16,139,161,17,137,1076,1076,0,1057,0,37,0,1076,137]

theorem envBound12493 : H12AffineFastState.Bounded env12493 := by
  intro p hp
  have h : env12493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12492_12493 : H12AffineEnvironment.transform 7 37 env12492 = env12493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env12492 == env12493) = true)

theorem identity12493 : scanCanonicalize (H12AffineFastState.compose env12493 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound12493 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12494 : List Nat := [2,4,8,16,32,17,9,37,0,1024,0,1077,41,1077,0,34,1077,0,1024,1,1076,33,16,2,40,17,0,1076,1076,0,1057,0,37,0,1076,0]

theorem envBound12494 : H12AffineFastState.Bounded env12494 := by
  intro p hp
  have h : env12494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12493_12494 : H12AffineEnvironment.transform 6 9 env12493 = env12494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env12493 == env12494) = true)

def leafEnv12494 : List Nat := [2,4,8,16,32,17,9,37,0,1024,0,1077,41,1077,0,34,1077,0,1024,1,1076,33,16,2,1057,40,1,17,0,1076,1076,0,1057,0,37,0,4,34,1076,0,0,1077,1]

def active12494 : List Nat := [0,1,2,3,4,9]

def tree12494 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood12494 : H12WitnessSearch.Good tree12494 := H12GlobalWitnessIndex.good

theorem leafIdentity12494 : H12AffineFastState.composeSystem env12494 rootObs = leafEnv12494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env12494 rootObs == leafEnv12494) = true)

theorem terminalChecked12494 : H12PackedTerminal.terminalCheckFast leafEnv12494 active12494 tree12494 = true := by decide +kernel

def env12495 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,4177,513,911,1345,8744,1024,512,4097,8200,5457,139,8328,5377,804,4176,1297,8460,1284,4294967296,256,4294975529,1344,512]

theorem envBound12495 : H12AffineFastState.Bounded env12495 := by
  intro p hp
  have h : env12495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12484_12495 : H12AffineEnvironment.transform 14 513 env12484 = env12495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 513 env12484 == env12495) = true)

theorem identity12495 : scanCanonicalize (H12AffineFastState.compose env12495 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 13852) := by decide +kernel

theorem selectedBound12495 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12496 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,4177,513,911,1345,8744,1024,512,4097,8200,5457,139,8328,5377,804,4176,1297,8460,1284,13852,256,5685,1344,512]

theorem envBound12496 : H12AffineFastState.Bounded env12496 := by
  intro p hp
  have h : env12496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12495_12496 : H12AffineEnvironment.transform 31 13852 env12495 = env12496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 13852 env12495 == env12496) = true)

def env12497 : List Nat := [2,4,8,16,32,64,128,256,136,1024,0,4096,8192,4177,137,263,1345,8352,1024,136,4097,8200,5457,139,8328,5377,428,4176,1297,8460,1284,13460,256,5309,1344,136]

theorem envBound12497 : H12AffineFastState.Bounded env12497 := by
  intro p hp
  have h : env12497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12496_12497 : H12AffineEnvironment.transform 8 136 env12496 = env12497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env12496 == env12497) = true)

theorem identity12497 : scanCanonicalize (H12AffineFastState.compose env12497 (packedSelected [2,4] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound12497 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env12498 : List Nat := [2,4,8,16,32,64,128,252,136,1024,0,4096,8192,4177,137,251,1213,8352,1024,136,4097,8200,5293,139,8328,5373,80,4176,1261,8432,1272,13460,252,5309,1212,136]

theorem envBound12498 : H12AffineFastState.Bounded env12498 := by
  intro p hp
  have h : env12498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12497_12498 : H12AffineEnvironment.transform 7 252 env12497 = env12498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env12497 == env12498) = true)

def env12499 : List Nat := [2,4,8,16,32,16,128,172,136,1024,0,4096,8192,4097,137,171,1213,8352,1024,136,4097,8200,5293,139,8328,5293,0,4096,1213,8352,1192,13460,172,5309,1212,136]

theorem envBound12499 : H12AffineFastState.Bounded env12499 := by
  intro p hp
  have h : env12499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12498_12499 : H12AffineEnvironment.transform 5 16 env12498 = env12499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env12498 == env12499) = true)

def env12500 : List Nat := [2,4,8,16,32,17,128,173,136,1024,0,4096,8192,4096,137,170,1213,8352,1024,136,4097,8200,5293,139,8328,5292,1,4097,1212,8353,1193,13460,173,5309,1212,136]

theorem envBound12500 : H12AffineFastState.Bounded env12500 := by
  intro p hp
  have h : env12500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12498_12500 : H12AffineEnvironment.transform 5 17 env12498 = env12500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env12498 == env12500) = true)

theorem identity12500 : scanCanonicalize (H12AffineFastState.compose env12500 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 5268) := by decide +kernel

theorem selectedBound12500 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12501 : List Nat := [2,4,8,16,32,17,128,173,136,1024,0,4096,5268,4096,137,170,1213,5172,1024,136,4097,5276,5293,139,5148,5292,1,4097,1212,5173,1193,0,173,5309,1212,136]

theorem envBound12501 : H12AffineFastState.Bounded env12501 := by
  intro p hp
  have h : env12501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12500_12501 : H12AffineEnvironment.transform 12 5268 env12500 = env12501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5268 env12500 == env12501) = true)

theorem identity12501 : scanCanonicalize (H12AffineFastState.compose env12501 (packedSelected [3,12] rootPS)) = affineNative (2^(11+1) ^^^ 1212) := by decide +kernel

theorem selectedBound12501 : packedSelected [3,12] rootPS < 2^1333 := by decide +kernel

def env12502 : List Nat := [2,4,8,16,32,17,128,173,136,1024,0,1212,40,1212,137,170,1213,136,1024,136,1213,32,17,139,160,16,1,1213,1212,137,1193,0,173,1,1212,136]

theorem envBound12502 : H12AffineFastState.Bounded env12502 := by
  intro p hp
  have h : env12502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12501_12502 : H12AffineEnvironment.transform 11 1212 env12501 = env12502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1212 env12501 == env12502) = true)

theorem identity12502 : scanCanonicalize (H12AffineFastState.compose env12502 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound12502 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12503 : List Nat := [2,4,8,16,32,17,41,4,33,1024,0,1045,40,1045,32,3,1044,33,1024,33,1044,32,17,34,9,16,1,1044,1045,32,1024,0,4,1,1045,33]

theorem envBound12503 : H12AffineFastState.Bounded env12503 := by
  intro p hp
  have h : env12503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12502_12503 : H12AffineEnvironment.transform 6 41 env12502 = env12503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env12502 == env12503) = true)

def leafEnv12503 : List Nat := [2,4,8,16,32,17,41,4,33,1024,0,1045,40,1045,32,3,1044,33,1024,33,1044,32,17,34,1024,9,1,16,1,1044,1045,32,1024,0,4,1,4,35,1045,33,0,1044,1]

def active12503 : List Nat := [0,1,2,3,4,9]

def tree12503 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood12503 : H12WitnessSearch.Good tree12503 := H12GlobalWitnessIndex.good

theorem leafIdentity12503 : H12AffineFastState.composeSystem env12503 rootObs = leafEnv12503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env12503 rootObs == leafEnv12503) = true)

theorem terminalChecked12503 : H12PackedTerminal.terminalCheckFast leafEnv12503 active12503 tree12503 = true := by decide +kernel

def env12504 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,4096,8192,4177,136,262,1345,8353,1024,137,4097,8200,5457,139,8328,5377,429,4176,1297,8460,1284,13461,256,5308,1344,137]

theorem envBound12504 : H12AffineFastState.Bounded env12504 := by
  intro p hp
  have h : env12504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12496_12504 : H12AffineEnvironment.transform 8 137 env12496 = env12504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env12496 == env12504) = true)

theorem identity12504 : scanCanonicalize (H12AffineFastState.compose env12504 (packedSelected [2,4] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound12504 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env12505 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,4096,121,4177,136,262,1345,216,1024,137,4097,113,5457,139,241,5377,429,4176,1297,373,1284,5356,256,5308,1344,137]

theorem envBound12505 : H12AffineFastState.Bounded env12505 := by
  intro p hp
  have h : env12505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12504_12505 : H12AffineEnvironment.transform 12 121 env12504 = env12505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env12504 == env12505) = true)

theorem identity12505 : scanCanonicalize (H12AffineFastState.compose env12505 (packedSelected [1,3,5] rootPS)) = affineNative (2^(11+1) ^^^ 1344) := by decide +kernel

theorem selectedBound12505 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env12506 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,1344,121,1297,136,262,1345,216,1024,137,1345,113,17,139,241,65,429,1296,1297,373,1284,428,256,508,1344,137]

theorem envBound12506 : H12AffineFastState.Bounded env12506 := by
  intro p hp
  have h : env12506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12505_12506 : H12AffineEnvironment.transform 11 1344 env12505 = env12506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env12505 == env12506) = true)

theorem identity12506 : scanCanonicalize (H12AffineFastState.compose env12506 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound12506 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12507 : List Nat := [2,4,8,16,32,64,128,253,137,1024,0,1213,121,1260,136,251,1212,216,1024,137,1212,113,17,139,241,65,80,1261,1260,136,1273,81,253,1,1213,137]

theorem envBound12507 : H12AffineFastState.Bounded env12507 := by
  intro p hp
  have h : env12507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12506_12507 : H12AffineEnvironment.transform 7 253 env12506 = env12507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env12506 == env12507) = true)

def env12508 : List Nat := [2,4,8,16,0,64,128,221,137,1024,0,1181,89,1228,136,219,1180,216,1024,137,1180,81,17,139,209,65,80,1229,1228,136,1241,81,221,1,1181,137]

theorem envBound12508 : H12AffineFastState.Bounded env12508 := by
  intro p hp
  have h : env12508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12507_12508 : H12AffineEnvironment.transform 4 0 env12507 = env12508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env12507 == env12508) = true)

theorem identity12508 : scanCanonicalize (H12AffineFastState.compose env12508 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound12508 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12509 : List Nat := [2,4,8,16,0,64,8,85,1,1024,0,1045,89,1092,0,83,1044,80,1024,1,1044,81,17,3,89,65,80,1093,1092,0,1105,81,85,1,1045,1]

theorem envBound12509 : H12AffineFastState.Bounded env12509 := by
  intro p hp
  have h : env12509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12508_12509 : H12AffineEnvironment.transform 6 8 env12508 = env12509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env12508 == env12509) = true)

def leafEnv12509 : List Nat := [2,4,8,16,0,64,8,85,1,1024,0,1045,89,1092,0,83,1044,80,1024,1,1044,81,17,3,1105,89,1,65,80,1093,1092,0,1105,81,85,1,4,82,1045,1,0,1093,1]

def active12509 : List Nat := [0,1,2,3,5,9]

def tree12509 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood12509 : H12WitnessSearch.Good tree12509 := H12GlobalWitnessIndex.good

theorem leafIdentity12509 : H12AffineFastState.composeSystem env12509 rootObs = leafEnv12509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env12509 rootObs == leafEnv12509) = true)

theorem terminalChecked12509 : H12PackedTerminal.terminalCheckFast leafEnv12509 active12509 tree12509 = true := by decide +kernel

def env12510 : List Nat := [2,4,8,16,1,64,128,220,137,1024,0,1180,88,1229,136,218,1181,216,1024,137,1181,80,17,139,208,65,80,1228,1229,136,1240,81,220,1,1180,137]

theorem envBound12510 : H12AffineFastState.Bounded env12510 := by
  intro p hp
  have h : env12510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12507_12510 : H12AffineEnvironment.transform 4 1 env12507 = env12510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env12507 == env12510) = true)

theorem identity12510 : scanCanonicalize (H12AffineFastState.compose env12510 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound12510 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12511 : List Nat := [2,4,8,16,1,64,88,4,81,1024,0,1092,88,1045,80,2,1093,0,1024,81,1093,80,17,83,8,65,80,1044,1045,80,1024,81,4,1,1092,81]

theorem envBound12511 : H12AffineFastState.Bounded env12511 := by
  intro p hp
  have h : env12511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12510_12511 : H12AffineEnvironment.transform 6 88 env12510 = env12511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env12510 == env12511) = true)

def leafEnv12511 : List Nat := [2,4,8,16,1,64,88,4,81,1024,0,1092,88,1045,80,2,1093,0,1024,81,1093,80,17,83,1024,8,1,65,80,1044,1045,80,1024,81,4,1,4,83,1092,81,0,1044,1]

def active12511 : List Nat := [0,1,2,3,5,9]

def tree12511 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood12511 : H12WitnessSearch.Good tree12511 := H12GlobalWitnessIndex.good

theorem leafIdentity12511 : H12AffineFastState.composeSystem env12511 rootObs = leafEnv12511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env12511 rootObs == leafEnv12511) = true)

theorem terminalChecked12511 : H12PackedTerminal.terminalCheckFast leafEnv12511 active12511 tree12511 = true := by decide +kernel

def env12512 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,8201,17664,230468,8328,541008,925772,148800,676865,1073741824,1284,4294967296,132161,4295206119,131073,512]

theorem envBound12512 : H12AffineFastState.Bounded env12512 := by
  intro p hp
  have h : env12512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12456_12512 : H12AffineEnvironment.transform 10 1 env12456 = env12512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env12456 == env12512) = true)

def env12513 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1344,262144,524288,32769,4097,8201,17664,98564,8328,541008,795916,16384,545089,1073741824,1284,4294967296,257,4295074215,1345,512]

theorem envBound12513 : H12AffineFastState.Bounded env12513 := by
  intro p hp
  have h : env12513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12512_12513 : H12AffineEnvironment.transform 16 1344 env12512 = env12513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env12512 == env12513) = true)

theorem identity12513 : scanCanonicalize (H12AffineFastState.compose env12513 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 537948) := by decide +kernel

theorem selectedBound12513 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env12514 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1344,262144,524288,32769,4097,8201,17664,98564,8328,541008,795916,16384,545089,537948,1284,4294967296,257,4295074215,1345,512]

theorem envBound12514 : H12AffineFastState.Bounded env12514 := by
  intro p hp
  have h : env12514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12513_12514 : H12AffineEnvironment.transform 29 537948 env12513 = env12514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 537948 env12513 == env12514) = true)

theorem identity12514 : scanCanonicalize (H12AffineFastState.compose env12514 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(18+1) ^^^ 1025) := by decide +kernel

theorem selectedBound12514 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env12515 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1344,262144,1025,32769,4097,8201,17664,98564,8328,17745,270605,16384,21824,12637,1284,4294967296,257,4295074215,1345,512]

theorem envBound12515 : H12AffineFastState.Bounded env12515 := by
  intro p hp
  have h : env12515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12514_12515 : H12AffineEnvironment.transform 18 1025 env12514 = env12515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env12514 == env12515) = true)

theorem identity12515 : scanCanonicalize (H12AffineFastState.compose env12515 (packedSelected [1,5,8,15,17,21,24,38] rootPS)) = affineNative (2^(17+1) ^^^ 74150) := by decide +kernel

theorem selectedBound12515 : packedSelected [1,5,8,15,17,21,24,38] rootPS < 2^1333 := by decide +kernel

def env12516 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1344,74150,1025,32769,4097,8201,17664,98564,8328,17745,65707,16384,21824,12637,1284,4294967296,257,4295074215,1345,512]

theorem envBound12516 : H12AffineFastState.Bounded env12516 := by
  intro p hp
  have h : env12516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12515_12516 : H12AffineEnvironment.transform 17 74150 env12515 = env12516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 74150 env12515 == env12516) = true)

theorem identity12516 : scanCanonicalize (H12AffineFastState.compose env12516 (packedSelected [1,5,8,24] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound12516 : packedSelected [1,5,8,24] rootPS < 2^1333 := by decide +kernel

def env12517 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,80,8192,16384,32768,65536,1344,74150,1025,32769,81,8201,17664,98564,8328,17745,65707,16384,17680,8461,1284,4294967296,257,4295074215,1345,512]

theorem envBound12517 : H12AffineFastState.Bounded env12517 := by
  intro p hp
  have h : env12517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12516_12517 : H12AffineEnvironment.transform 11 80 env12516 = env12517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env12516 == env12517) = true)

theorem identity12517 : scanCanonicalize (H12AffineFastState.compose env12517 (packedSelected [1,3,5,8,12,13,15,17] rootPS)) = affineNative (2^(13+1) ^^^ 9293) := by decide +kernel

theorem selectedBound12517 : packedSelected [1,3,5,8,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env12518 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,80,8192,9293,32768,65536,1344,74150,1025,32769,81,8201,8525,98564,8328,8476,65707,9293,8541,8461,1284,4294967296,257,4295074215,1345,512]

theorem envBound12518 : H12AffineFastState.Bounded env12518 := by
  intro p hp
  have h : env12518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12517_12518 : H12AffineEnvironment.transform 13 9293 env12517 = env12518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 9293 env12517 == env12518) = true)

theorem identity12518 : scanCanonicalize (H12AffineFastState.compose env12518 (packedSelected [0,1,7,8,10,15] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound12518 : packedSelected [0,1,7,8,10,15] rootPS < 2^1333 := by decide +kernel

def env12519 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,80,1053,80,32768,65536,1344,67003,1025,32769,81,1044,1360,98564,1173,1281,65707,80,1344,1296,1284,4294967296,257,4295067066,1345,512]

theorem envBound12519 : H12AffineFastState.Bounded env12519 := by
  intro p hp
  have h : env12519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12518_12519 : H12AffineEnvironment.transform 12 1053 env12518 = env12519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env12518 == env12519) = true)

theorem identity12519 : scanCanonicalize (H12AffineFastState.compose env12519 (packedSelected [0,1,3,7,10,13] rootPS)) = affineNative (2^(31+1) ^^^ 33621) := by decide +kernel

theorem selectedBound12519 : packedSelected [0,1,3,7,10,13] rootPS < 2^1333 := by decide +kernel

def env12520 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,80,1053,80,32768,65536,1344,67003,1025,32769,81,1044,1360,98564,1173,1281,65707,80,1344,1296,1284,33621,257,67311,1345,512]

theorem envBound12520 : H12AffineFastState.Bounded env12520 := by
  intro p hp
  have h : env12520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12519_12520 : H12AffineEnvironment.transform 31 33621 env12519 = env12520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 33621 env12519 == env12520) = true)

theorem identity12520 : scanCanonicalize (H12AffineFastState.compose env12520 (packedSelected [0,1,3,4,5,7,8,9,12,18] rootPS)) = affineNative (2^(15+1) ^^^ 250) := by decide +kernel

theorem selectedBound12520 : packedSelected [0,1,3,4,5,7,8,9,12,18] rootPS < 2^1333 := by decide +kernel

def env12521 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,80,1053,80,32768,250,1344,1345,1025,32769,81,1044,1360,33278,1173,1281,81,80,1344,1296,1284,33621,257,1557,1345,512]

theorem envBound12521 : H12AffineFastState.Bounded env12521 := by
  intro p hp
  have h : env12521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12520_12521 : H12AffineEnvironment.transform 15 250 env12520 = env12521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 250 env12520 == env12521) = true)

theorem identity12521 : scanCanonicalize (H12AffineFastState.compose env12521 (packedSelected [4,9] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound12521 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env12522 : List Nat := [2,4,8,16,32,64,128,256,512,273,1,80,268,80,32768,250,81,80,272,32769,81,261,65,33278,388,16,81,80,81,1,21,33621,257,772,80,512]

theorem envBound12522 : H12AffineFastState.Bounded env12522 := by
  intro p hp
  have h : env12522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12521_12522 : H12AffineEnvironment.transform 9 273 env12521 = env12522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env12521 == env12522) = true)

theorem identity12522 : scanCanonicalize (H12AffineFastState.compose env12522 (packedSelected [0,7] rootPS)) = affineNative (2^(14+1) ^^^ 292) := by decide +kernel

theorem selectedBound12522 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env12523 : List Nat := [2,4,8,16,32,64,128,256,512,273,1,80,268,80,292,250,81,80,272,293,81,261,65,218,388,16,81,80,81,1,21,625,257,772,80,512]

theorem envBound12523 : H12AffineFastState.Bounded env12523 := by
  intro p hp
  have h : env12523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12522_12523 : H12AffineEnvironment.transform 14 292 env12522 = env12523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 292 env12522 == env12523) = true)

theorem identity12523 : scanCanonicalize (H12AffineFastState.compose env12523 (packedSelected [3,5] rootPS)) = affineNative (2^(8+1) ^^^ 216) := by decide +kernel

theorem selectedBound12523 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env12524 : List Nat := [2,4,8,16,32,64,128,256,216,273,1,80,268,80,292,250,81,80,272,293,81,261,65,218,388,16,81,80,81,1,21,169,257,476,80,216]

theorem envBound12524 : H12AffineFastState.Bounded env12524 := by
  intro p hp
  have h : env12524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12523_12524 : H12AffineEnvironment.transform 8 216 env12523 = env12524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env12523 == env12524) = true)

theorem identity12524 : scanCanonicalize (H12AffineFastState.compose env12524 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound12524 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env12525 : List Nat := [2,4,8,16,32,64,128,172,216,189,1,80,160,80,136,250,81,80,188,137,81,169,65,218,40,16,81,80,81,1,21,169,173,112,80,216]

theorem envBound12525 : H12AffineFastState.Bounded env12525 := by
  intro p hp
  have h : env12525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12524_12525 : H12AffineEnvironment.transform 7 172 env12524 = env12525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env12524 == env12525) = true)

theorem identity12525 : scanCanonicalize (H12AffineFastState.compose env12525 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound12525 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env12526 : List Nat := [2,4,8,16,32,17,128,172,137,189,1,1,160,1,136,171,0,1,188,137,0,169,16,139,40,16,0,1,0,1,21,169,173,33,1,137]

theorem envBound12526 : H12AffineFastState.Bounded env12526 := by
  intro p hp
  have h : env12526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12525_12526 : H12AffineEnvironment.transform 5 17 env12525 = env12526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env12525 == env12526) = true)

theorem identity12526 : scanCanonicalize (H12AffineFastState.compose env12526 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound12526 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12527 : List Nat := [2,4,8,16,1,17,128,141,137,156,1,1,129,1,136,138,0,1,157,137,0,136,16,139,9,16,0,1,0,1,21,136,140,0,1,137]

theorem envBound12527 : H12AffineFastState.Bounded env12527 := by
  intro p hp
  have h : env12527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12526_12527 : H12AffineEnvironment.transform 4 1 env12526 = env12527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env12526 == env12527) = true)

theorem identity12527 : scanCanonicalize (H12AffineFastState.compose env12527 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound12527 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12528 : List Nat := [2,4,8,16,1,17,8,5,1,20,1,1,9,1,0,2,0,1,21,1,0,0,16,3,9,16,0,1,0,1,21,0,4,0,1,1]

theorem envBound12528 : H12AffineFastState.Bounded env12528 := by
  intro p hp
  have h : env12528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12527_12528 : H12AffineEnvironment.transform 6 8 env12527 = env12528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env12527 == env12528) = true)

theorem identity12528 : scanCanonicalize (H12AffineFastState.compose env12528 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound12528 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12529 : List Nat := [2,4,8,0,1,1,8,5,1,4,1,1,9,1,0,2,0,1,5,1,0,0,0,3,9,0,0,1,0,1,5,0,4,0,1,1]

theorem envBound12529 : H12AffineFastState.Bounded env12529 := by
  intro p hp
  have h : env12529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12528_12529 : H12AffineEnvironment.transform 3 0 env12528 = env12529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env12528 == env12529) = true)

def env12530 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1345,262144,524288,32769,4097,8201,17664,98565,8328,541008,795917,16385,545088,1073741824,1284,4294967296,256,4295074214,1344,512]

theorem envBound12530 : H12AffineFastState.Bounded env12530 := by
  intro p hp
  have h : env12530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12512_12530 : H12AffineEnvironment.transform 16 1345 env12512 = env12530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env12512 == env12530) = true)

theorem identity12530 : scanCanonicalize (H12AffineFastState.compose env12530 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 8460) := by decide +kernel

theorem selectedBound12530 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env12531 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1345,262144,524288,32769,4097,8201,17664,98565,8328,541008,795917,16385,545088,8460,1284,4294967296,256,4295074214,1344,512]

theorem envBound12531 : H12AffineFastState.Bounded env12531 := by
  intro p hp
  have h : env12531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12530_12531 : H12AffineEnvironment.transform 29 8460 env12530 = env12531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 8460 env12530 == env12531) = true)

def env12532 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1345,262144,304168,32769,4097,8201,17664,98565,8328,320888,33061,16385,324968,8460,1284,4294967296,256,4295074214,1344,512]

theorem envBound12532 : H12AffineFastState.Bounded env12532 := by
  intro p hp
  have h : env12532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12531_12532 : H12AffineEnvironment.transform 18 304168 env12531 = env12532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 304168 env12531 == env12532) = true)

theorem identity12532 : scanCanonicalize (H12AffineFastState.compose env12532 (packedSelected [3,10,17,19,21,24] rootPS)) = affineNative (2^(17+1) ^^^ 41000) := by decide +kernel

theorem selectedBound12532 : packedSelected [3,10,17,19,21,24] rootPS < 2^1333 := by decide +kernel

def env12533 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1345,41000,1024,32769,4097,8201,17664,98565,8328,17744,33061,16385,21824,8460,1284,4294967296,256,4295074214,1344,512]

theorem envBound12533 : H12AffineFastState.Bounded env12533 := by
  intro p hp
  have h : env12533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12532_12533 : H12AffineEnvironment.transform 17 41000 env12532 = env12533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 41000 env12532 == env12533) = true)

theorem identity12533 : scanCanonicalize (H12AffineFastState.compose env12533 (packedSelected [1,3,10,13,15] rootPS)) = affineNative (2^(15+1) ^^^ 33166) := by decide +kernel

theorem selectedBound12533 : packedSelected [1,3,10,13,15] rootPS < 2^1333 := by decide +kernel

def env12534 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,33166,1345,41000,1024,32769,4097,8201,17664,139,8328,17744,33061,16385,21824,8460,1284,4294967296,256,4294975528,1344,512]

theorem envBound12534 : H12AffineFastState.Bounded env12534 := by
  intro p hp
  have h : env12534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12533_12534 : H12AffineEnvironment.transform 15 33166 env12533 = env12534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33166 env12533 == env12534) = true)

theorem identity12534 : scanCanonicalize (H12AffineFastState.compose env12534 (packedSelected [5,8,10,12,13] rootPS)) = affineNative (2^(13+1) ^^^ 4177) := by decide +kernel

theorem selectedBound12534 : packedSelected [5,8,10,12,13] rootPS < 2^1333 := by decide +kernel

def env12535 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,4177,32768,33166,1345,41000,1024,32769,4097,8201,5457,139,8328,5377,33061,4176,1297,8460,1284,4294967296,256,4294975528,1344,512]

theorem envBound12535 : H12AffineFastState.Bounded env12535 := by
  intro p hp
  have h : env12535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12534_12535 : H12AffineEnvironment.transform 13 4177 env12534 = env12535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env12534 == env12535) = true)

def env12536 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,4177,512,910,1345,8744,1024,513,4097,8201,5457,139,8328,5377,805,4176,1297,8460,1284,4294967296,256,4294975528,1344,512]

theorem envBound12536 : H12AffineFastState.Bounded env12536 := by
  intro p hp
  have h : env12536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12535_12536 : H12AffineEnvironment.transform 14 512 env12535 = env12536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 512 env12535 == env12536) = true)

theorem identity12536 : scanCanonicalize (H12AffineFastState.compose env12536 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 13853) := by decide +kernel

theorem selectedBound12536 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12537 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,4177,512,910,1345,8744,1024,513,4097,8201,5457,139,8328,5377,805,4176,1297,8460,1284,13853,256,5685,1344,512]

theorem envBound12537 : H12AffineFastState.Bounded env12537 := by
  intro p hp
  have h : env12537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12536_12537 : H12AffineEnvironment.transform 31 13853 env12536 = env12537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 13853 env12536 == env12537) = true)

def env12538 : List Nat := [2,4,8,16,32,64,128,256,136,1024,1,4096,8192,4177,136,262,1345,8352,1024,137,4097,8201,5457,139,8328,5377,429,4176,1297,8460,1284,13461,256,5309,1344,136]

theorem envBound12538 : H12AffineFastState.Bounded env12538 := by
  intro p hp
  have h : env12538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12537_12538 : H12AffineEnvironment.transform 8 136 env12537 = env12538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env12537 == env12538) = true)

theorem identity12538 : scanCanonicalize (H12AffineFastState.compose env12538 (packedSelected [2,4] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound12538 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env12539 : List Nat := [2,4,8,16,32,64,128,252,136,1024,1,4096,8192,4177,136,250,1213,8352,1024,137,4097,8201,5293,139,8328,5373,81,4176,1261,8432,1272,13461,252,5309,1212,136]

theorem envBound12539 : H12AffineFastState.Bounded env12539 := by
  intro p hp
  have h : env12539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12538_12539 : H12AffineEnvironment.transform 7 252 env12538 = env12539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env12538 == env12539) = true)

def env12540 : List Nat := [2,4,8,16,32,16,128,172,136,1024,1,4096,8192,4097,136,170,1213,8352,1024,137,4097,8201,5293,139,8328,5293,1,4096,1213,8352,1192,13461,172,5309,1212,136]

theorem envBound12540 : H12AffineFastState.Bounded env12540 := by
  intro p hp
  have h : env12540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12539_12540 : H12AffineEnvironment.transform 5 16 env12539 = env12540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env12539 == env12540) = true)

def env12541 : List Nat := [2,4,8,16,32,17,128,173,136,1024,1,4096,8192,4096,136,171,1213,8352,1024,137,4097,8201,5293,139,8328,5292,0,4097,1212,8353,1193,13461,173,5309,1212,136]

theorem envBound12541 : H12AffineFastState.Bounded env12541 := by
  intro p hp
  have h : env12541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12539_12541 : H12AffineEnvironment.transform 5 17 env12539 = env12541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env12539 == env12541) = true)

theorem identity12541 : scanCanonicalize (H12AffineFastState.compose env12541 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 5269) := by decide +kernel

theorem selectedBound12541 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12542 : List Nat := [2,4,8,16,32,17,128,173,136,1024,1,4096,5269,4096,136,171,1213,5173,1024,137,4097,5276,5293,139,5149,5292,0,4097,1212,5172,1193,0,173,5309,1212,136]

theorem envBound12542 : H12AffineFastState.Bounded env12542 := by
  intro p hp
  have h : env12542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12541_12542 : H12AffineEnvironment.transform 12 5269 env12541 = env12542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5269 env12541 == env12542) = true)

theorem identity12542 : scanCanonicalize (H12AffineFastState.compose env12542 (packedSelected [3,12] rootPS)) = affineNative (2^(11+1) ^^^ 1212) := by decide +kernel

theorem selectedBound12542 : packedSelected [3,12] rootPS < 2^1333 := by decide +kernel

def env12543 : List Nat := [2,4,8,16,32,17,128,173,136,1024,1,1212,41,1212,136,171,1213,137,1024,137,1213,32,17,139,161,16,0,1213,1212,136,1193,0,173,1,1212,136]

theorem envBound12543 : H12AffineFastState.Bounded env12543 := by
  intro p hp
  have h : env12543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12542_12543 : H12AffineEnvironment.transform 11 1212 env12542 = env12543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1212 env12542 == env12543) = true)

theorem identity12543 : scanCanonicalize (H12AffineFastState.compose env12543 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound12543 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12544 : List Nat := [2,4,8,16,32,17,41,4,33,1024,1,1045,41,1045,33,2,1044,32,1024,32,1044,32,17,34,8,16,0,1044,1045,33,1024,0,4,1,1045,33]

theorem envBound12544 : H12AffineFastState.Bounded env12544 := by
  intro p hp
  have h : env12544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12543_12544 : H12AffineEnvironment.transform 6 41 env12543 = env12544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env12543 == env12544) = true)

def leafEnv12544 : List Nat := [2,4,8,16,32,17,41,4,33,1024,1,1045,41,1045,33,2,1044,32,1024,32,1044,32,17,34,1024,8,1,16,0,1044,1045,33,1024,0,4,1,4,34,1045,33,0,1044,1]

def active12544 : List Nat := [0,1,2,3,4,9]

def tree12544 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood12544 : H12WitnessSearch.Good tree12544 := H12GlobalWitnessIndex.good

theorem leafIdentity12544 : H12AffineFastState.composeSystem env12544 rootObs = leafEnv12544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env12544 rootObs == leafEnv12544) = true)

theorem terminalChecked12544 : H12PackedTerminal.terminalCheckFast leafEnv12544 active12544 tree12544 = true := by decide +kernel

def env12545 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,4096,8192,4177,137,263,1345,8353,1024,136,4097,8201,5457,139,8328,5377,428,4176,1297,8460,1284,13460,256,5308,1344,137]

theorem envBound12545 : H12AffineFastState.Bounded env12545 := by
  intro p hp
  have h : env12545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12537_12545 : H12AffineEnvironment.transform 8 137 env12537 = env12545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env12537 == env12545) = true)

theorem identity12545 : scanCanonicalize (H12AffineFastState.compose env12545 (packedSelected [2,4] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound12545 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env12546 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,4096,120,4177,137,263,1345,217,1024,136,4097,113,5457,139,240,5377,428,4176,1297,372,1284,5356,256,5308,1344,137]

theorem envBound12546 : H12AffineFastState.Bounded env12546 := by
  intro p hp
  have h : env12546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12545_12546 : H12AffineEnvironment.transform 12 120 env12545 = env12546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env12545 == env12546) = true)

theorem identity12546 : scanCanonicalize (H12AffineFastState.compose env12546 (packedSelected [1,3,5] rootPS)) = affineNative (2^(11+1) ^^^ 1344) := by decide +kernel

theorem selectedBound12546 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env12547 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,1344,120,1297,137,263,1345,217,1024,136,1345,113,17,139,240,65,428,1296,1297,372,1284,428,256,508,1344,137]

theorem envBound12547 : H12AffineFastState.Bounded env12547 := by
  intro p hp
  have h : env12547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12546_12547 : H12AffineEnvironment.transform 11 1344 env12546 = env12547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env12546 == env12547) = true)

theorem identity12547 : scanCanonicalize (H12AffineFastState.compose env12547 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound12547 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12548 : List Nat := [2,4,8,16,32,64,128,253,137,1024,1,1213,120,1260,137,250,1212,217,1024,136,1212,113,17,139,240,65,81,1261,1260,137,1273,81,253,1,1213,137]

theorem envBound12548 : H12AffineFastState.Bounded env12548 := by
  intro p hp
  have h : env12548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12547_12548 : H12AffineEnvironment.transform 7 253 env12547 = env12548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env12547 == env12548) = true)

def env12549 : List Nat := [2,4,8,16,0,64,128,221,137,1024,1,1181,88,1228,137,218,1180,217,1024,136,1180,81,17,139,208,65,81,1229,1228,137,1241,81,221,1,1181,137]

theorem envBound12549 : H12AffineFastState.Bounded env12549 := by
  intro p hp
  have h : env12549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12548_12549 : H12AffineEnvironment.transform 4 0 env12548 = env12549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env12548 == env12549) = true)

theorem identity12549 : scanCanonicalize (H12AffineFastState.compose env12549 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound12549 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12550 : List Nat := [2,4,8,16,0,64,8,85,1,1024,1,1045,88,1092,1,82,1044,81,1024,0,1044,81,17,3,88,65,81,1093,1092,1,1105,81,85,1,1045,1]

theorem envBound12550 : H12AffineFastState.Bounded env12550 := by
  intro p hp
  have h : env12550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12549_12550 : H12AffineEnvironment.transform 6 8 env12549 = env12550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env12549 == env12550) = true)

def leafEnv12550 : List Nat := [2,4,8,16,0,64,8,85,1,1024,1,1045,88,1092,1,82,1044,81,1024,0,1044,81,17,3,1105,88,1,65,81,1093,1092,1,1105,81,85,1,4,83,1045,1,0,1093,1]

def active12550 : List Nat := [0,1,2,3,5,9]

def tree12550 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood12550 : H12WitnessSearch.Good tree12550 := H12GlobalWitnessIndex.good

theorem leafIdentity12550 : H12AffineFastState.composeSystem env12550 rootObs = leafEnv12550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env12550 rootObs == leafEnv12550) = true)

theorem terminalChecked12550 : H12PackedTerminal.terminalCheckFast leafEnv12550 active12550 tree12550 = true := by decide +kernel

def env12551 : List Nat := [2,4,8,16,1,64,128,220,137,1024,1,1180,89,1229,137,219,1181,217,1024,136,1181,80,17,139,209,65,81,1228,1229,137,1240,81,220,1,1180,137]

theorem envBound12551 : H12AffineFastState.Bounded env12551 := by
  intro p hp
  have h : env12551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12548_12551 : H12AffineEnvironment.transform 4 1 env12548 = env12551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env12548 == env12551) = true)

theorem identity12551 : scanCanonicalize (H12AffineFastState.compose env12551 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound12551 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12552 : List Nat := [2,4,8,16,1,64,88,4,81,1024,1,1092,89,1045,81,3,1093,1,1024,80,1093,80,17,83,9,65,81,1044,1045,81,1024,81,4,1,1092,81]

theorem envBound12552 : H12AffineFastState.Bounded env12552 := by
  intro p hp
  have h : env12552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12551_12552 : H12AffineEnvironment.transform 6 88 env12551 = env12552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env12551 == env12552) = true)

def leafEnv12552 : List Nat := [2,4,8,16,1,64,88,4,81,1024,1,1092,89,1045,81,3,1093,1,1024,80,1093,80,17,83,1024,9,1,65,81,1044,1045,81,1024,81,4,1,4,82,1092,81,0,1044,1]

def active12552 : List Nat := [0,1,2,3,5,9]

def tree12552 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood12552 : H12WitnessSearch.Good tree12552 := H12GlobalWitnessIndex.good

theorem leafIdentity12552 : H12AffineFastState.composeSystem env12552 rootObs = leafEnv12552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env12552 rootObs == leafEnv12552) = true)

theorem terminalChecked12552 : H12PackedTerminal.terminalCheckFast leafEnv12552 active12552 tree12552 = true := by decide +kernel

def env12553 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,4177,513,911,1345,8745,1024,512,4097,8201,5457,139,8328,5377,804,4176,1297,8460,1284,4294967296,256,4294975528,1344,512]

theorem envBound12553 : H12AffineFastState.Bounded env12553 := by
  intro p hp
  have h : env12553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12535_12553 : H12AffineEnvironment.transform 14 513 env12535 = env12553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 513 env12535 == env12553) = true)

theorem identity12553 : scanCanonicalize (H12AffineFastState.compose env12553 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 6041) := by decide +kernel

theorem selectedBound12553 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12554 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,4177,513,911,1345,8745,1024,512,4097,8201,5457,139,8328,5377,804,4176,1297,8460,1284,6041,256,14257,1344,512]

theorem envBound12554 : H12AffineFastState.Bounded env12554 := by
  intro p hp
  have h : env12554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12553_12554 : H12AffineEnvironment.transform 31 6041 env12553 = env12554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 6041 env12553 == env12554) = true)

def env12555 : List Nat := [2,4,8,16,32,64,128,256,136,1024,1,4096,8192,4177,137,263,1345,8353,1024,136,4097,8201,5457,139,8328,5377,428,4176,1297,8460,1284,5393,256,13625,1344,136]

theorem envBound12555 : H12AffineFastState.Bounded env12555 := by
  intro p hp
  have h : env12555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12554_12555 : H12AffineEnvironment.transform 8 136 env12554 = env12555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env12554 == env12555) = true)

theorem identity12555 : scanCanonicalize (H12AffineFastState.compose env12555 (packedSelected [2,4] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound12555 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env12556 : List Nat := [2,4,8,16,32,64,128,253,136,1024,1,4096,8192,4177,137,250,1212,8353,1024,136,4097,8201,5292,139,8328,5372,81,4176,1260,8433,1273,5356,253,13508,1213,136]

theorem envBound12556 : H12AffineFastState.Bounded env12556 := by
  intro p hp
  have h : env12556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12555_12556 : H12AffineEnvironment.transform 7 253 env12555 = env12556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env12555 == env12556) = true)

def env12557 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,4096,8192,4177,136,262,1345,8352,1024,137,4097,8201,5457,139,8328,5377,429,4176,1297,8460,1284,5392,256,13624,1344,137]

theorem envBound12557 : H12AffineFastState.Bounded env12557 := by
  intro p hp
  have h : env12557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12554_12557 : H12AffineEnvironment.transform 8 137 env12554 = env12557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env12554 == env12557) = true)

theorem identity12557 : scanCanonicalize (H12AffineFastState.compose env12557 (packedSelected [2,4] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound12557 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env12558 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,4096,121,4177,136,262,1345,217,1024,137,4097,112,5457,139,241,5377,429,4176,1297,373,1284,5392,256,5441,1344,137]

theorem envBound12558 : H12AffineFastState.Bounded env12558 := by
  intro p hp
  have h : env12558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12557_12558 : H12AffineEnvironment.transform 12 121 env12557 = env12558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env12557 == env12558) = true)

theorem identity12558 : scanCanonicalize (H12AffineFastState.compose env12558 (packedSelected [1,3,5] rootPS)) = affineNative (2^(11+1) ^^^ 1345) := by decide +kernel

theorem selectedBound12558 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env12559 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,1345,121,1296,136,262,1345,217,1024,137,1344,112,16,139,241,64,429,1297,1297,373,1284,81,256,0,1344,137]

theorem envBound12559 : H12AffineFastState.Bounded env12559 := by
  intro p hp
  have h : env12559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12558_12559 : H12AffineEnvironment.transform 11 1345 env12558 = env12559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env12558 == env12559) = true)

theorem identity12559 : scanCanonicalize (H12AffineFastState.compose env12559 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound12559 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12560 : List Nat := [2,4,8,16,32,17,128,256,137,1024,1,1296,40,1296,136,262,1296,136,1024,137,1297,33,16,139,160,17,429,1297,1297,292,1284,0,256,0,1297,137]

theorem envBound12560 : H12AffineFastState.Bounded env12560 := by
  intro p hp
  have h : env12560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12559_12560 : H12AffineEnvironment.transform 5 17 env12559 = env12560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env12559 == env12560) = true)

theorem identity12560 : scanCanonicalize (H12AffineFastState.compose env12560 (packedSelected [3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound12560 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env12561 : List Nat := [2,4,8,16,32,17,128,37,137,1024,1,1077,40,1077,136,35,1077,136,1024,137,1076,33,16,139,160,17,136,1076,1076,1,1057,0,37,0,1076,137]

theorem envBound12561 : H12AffineFastState.Bounded env12561 := by
  intro p hp
  have h : env12561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12560_12561 : H12AffineEnvironment.transform 7 37 env12560 = env12561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env12560 == env12561) = true)

theorem identity12561 : scanCanonicalize (H12AffineFastState.compose env12561 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound12561 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12562 : List Nat := [2,4,8,16,32,17,9,37,0,1024,1,1077,40,1077,1,35,1077,1,1024,0,1076,33,16,2,41,17,1,1076,1076,1,1057,0,37,0,1076,0]

theorem envBound12562 : H12AffineFastState.Bounded env12562 := by
  intro p hp
  have h : env12562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12561_12562 : H12AffineEnvironment.transform 6 9 env12561 = env12562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env12561 == env12562) = true)

def leafEnv12562 : List Nat := [2,4,8,16,32,17,9,37,0,1024,1,1077,40,1077,1,35,1077,1,1024,0,1076,33,16,2,1057,41,1,17,1,1076,1076,1,1057,0,37,0,4,35,1076,0,0,1077,1]

def active12562 : List Nat := [0,1,2,3,4,9]

def tree12562 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood12562 : H12WitnessSearch.Good tree12562 := H12GlobalWitnessIndex.good

theorem leafIdentity12562 : H12AffineFastState.composeSystem env12562 rootObs = leafEnv12562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env12562 rootObs == leafEnv12562) = true)

theorem terminalChecked12562 : H12PackedTerminal.terminalCheckFast leafEnv12562 active12562 tree12562 = true := by decide +kernel

def env12563 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1345,262144,304169,32769,4097,8201,17664,98565,8328,320889,33060,16385,324969,8460,1284,4294967296,256,4295074214,1344,512]

theorem envBound12563 : H12AffineFastState.Bounded env12563 := by
  intro p hp
  have h : env12563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12531_12563 : H12AffineEnvironment.transform 18 304169 env12531 = env12563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 304169 env12531 == env12563) = true)

theorem identity12563 : scanCanonicalize (H12AffineFastState.compose env12563 (packedSelected [4,9,18] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound12563 : packedSelected [4,9,18] rootPS < 2^1333 := by decide +kernel

def env12564 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,269,16384,32768,65536,1345,262144,296228,32769,4097,260,17664,98565,389,312436,33060,16385,316516,1,1284,4294967296,256,4295065771,1344,512]

theorem envBound12564 : H12AffineFastState.Bounded env12564 := by
  intro p hp
  have h : env12564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12563_12564 : H12AffineEnvironment.transform 12 269 env12563 = env12564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env12563 == env12564) = true)

theorem identity12564 : scanCanonicalize (H12AffineFastState.compose env12564 (packedSelected [20,23] rootPS)) = affineNative (2^(17+1) ^^^ 1) := by decide +kernel

theorem selectedBound12564 : packedSelected [20,23] rootPS < 2^1333 := by decide +kernel

def env12565 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,269,16384,32768,65536,1345,1,34085,32769,4097,260,17664,98565,389,50293,33060,16385,54373,1,1284,4294967296,256,4295065771,1344,512]

theorem envBound12565 : H12AffineFastState.Bounded env12565 := by
  intro p hp
  have h : env12565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12564_12565 : H12AffineEnvironment.transform 17 1 env12564 = env12565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1 env12564 == env12565) = true)

def env12566 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,10249,17664,230468,8328,541008,927820,148800,676865,1073741824,1284,4294967296,132161,4295208167,131073,512]

theorem envBound12566 : H12AffineFastState.Bounded env12566 := by
  intro p hp
  have h : env12566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12455_12566 : H12AffineEnvironment.transform 21 10249 env12455 = env12566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10249 env12455 == env12566) = true)

def env12567 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,8201,17664,230468,8328,541008,925772,148800,676865,1073741824,1284,4294967296,132161,4295206119,131073,512]

theorem envBound12567 : H12AffineFastState.Bounded env12567 := by
  intro p hp
  have h : env12567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12566_12567 : H12AffineEnvironment.transform 10 0 env12566 = env12567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env12566 == env12567) = true)

def env12568 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1344,262144,524288,32769,4097,8201,17664,98564,8328,541008,795916,16384,545089,1073741824,1284,4294967296,257,4295074215,1345,512]

theorem envBound12568 : H12AffineFastState.Bounded env12568 := by
  intro p hp
  have h : env12568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12567_12568 : H12AffineEnvironment.transform 16 1344 env12567 = env12568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env12567 == env12568) = true)

theorem identity12568 : scanCanonicalize (H12AffineFastState.compose env12568 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 570489) := by decide +kernel

theorem selectedBound12568 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env12569 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1344,262144,524288,32769,4097,8201,17664,98564,8328,541008,795916,16384,545089,570489,1284,4294967296,257,4295074215,1345,512]

theorem envBound12569 : H12AffineFastState.Bounded env12569 := by
  intro p hp
  have h : env12569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12568_12569 : H12AffineEnvironment.transform 29 570489 env12568 = env12569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 570489 env12568 == env12569) = true)

theorem identity12569 : scanCanonicalize (H12AffineFastState.compose env12569 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(18+1) ^^^ 1025) := by decide +kernel

theorem selectedBound12569 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env12570 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1344,262144,1025,32769,4097,8201,17664,98564,8328,17745,270605,16384,21824,45176,1284,4294967296,257,4295074215,1345,512]

theorem envBound12570 : H12AffineFastState.Bounded env12570 := by
  intro p hp
  have h : env12570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12569_12570 : H12AffineEnvironment.transform 18 1025 env12569 = env12570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env12569 == env12570) = true)

theorem identity12570 : scanCanonicalize (H12AffineFastState.compose env12570 (packedSelected [1,5,8,15,17,21,24,38] rootPS)) = affineNative (2^(17+1) ^^^ 74151) := by decide +kernel

theorem selectedBound12570 : packedSelected [1,5,8,15,17,21,24,38] rootPS < 2^1333 := by decide +kernel

def env12571 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1344,74151,1025,32769,4097,8201,17664,98564,8328,17745,65706,16384,21824,45176,1284,4294967296,257,4295074215,1345,512]

theorem envBound12571 : H12AffineFastState.Bounded env12571 := by
  intro p hp
  have h : env12571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12570_12571 : H12AffineEnvironment.transform 17 74151 env12570 = env12571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 74151 env12570 == env12571) = true)

theorem identity12571 : scanCanonicalize (H12AffineFastState.compose env12571 (packedSelected [1,5,8,24] rootPS)) = affineNative (2^(14+1) ^^^ 4468) := by decide +kernel

theorem selectedBound12571 : packedSelected [1,5,8,24] rootPS < 2^1333 := by decide +kernel

def env12572 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,4468,65536,1344,74151,1025,4469,4097,8201,17664,69744,8328,17745,65706,16384,21824,8460,1284,4294967296,257,4295045331,1345,512]

theorem envBound12572 : H12AffineFastState.Bounded env12572 := by
  intro p hp
  have h : env12572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12571_12572 : H12AffineEnvironment.transform 14 4468 env12571 = env12572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 4468 env12571 == env12572) = true)

theorem identity12572 : scanCanonicalize (H12AffineFastState.compose env12572 (packedSelected [1,3,5,8,12,13,15,17] rootPS)) = affineNative (2^(13+1) ^^^ 9293) := by decide +kernel

theorem selectedBound12572 : packedSelected [1,3,5,8,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env12573 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,9293,4468,65536,1344,74151,1025,4469,4097,8201,8525,69744,8328,8476,65706,9293,12557,8460,1284,4294967296,257,4295045331,1345,512]

theorem envBound12573 : H12AffineFastState.Bounded env12573 := by
  intro p hp
  have h : env12573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12572_12573 : H12AffineEnvironment.transform 13 9293 env12572 = env12573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 9293 env12572 == env12573) = true)

theorem identity12573 : scanCanonicalize (H12AffineFastState.compose env12573 (packedSelected [3,4,5,9,10,12,15,18] rootPS)) = affineNative (2^(15+1) ^^^ 9446) := by decide +kernel

theorem selectedBound12573 : packedSelected [3,4,5,9,10,12,15,18] rootPS < 2^1333 := by decide +kernel

def env12574 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,9293,4468,9446,1344,1345,1025,4469,4097,8201,8525,13462,8328,8476,9292,9293,12557,8460,1284,4294967296,257,4294972469,1345,512]

theorem envBound12574 : H12AffineFastState.Bounded env12574 := by
  intro p hp
  have h : env12574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12573_12574 : H12AffineEnvironment.transform 15 9446 env12573 = env12574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9446 env12573 == env12574) = true)

theorem identity12574 : scanCanonicalize (H12AffineFastState.compose env12574 (packedSelected [4,9,12] rootPS)) = affineNative (2^(31+1) ^^^ 396) := by decide +kernel

theorem selectedBound12574 : packedSelected [4,9,12] rootPS < 2^1333 := by decide +kernel

def env12575 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,9293,4468,9446,1344,1345,1025,4469,4097,8201,8525,13462,8328,8476,9292,9293,12557,8460,1284,396,257,5561,1345,512]

theorem envBound12575 : H12AffineFastState.Bounded env12575 := by
  intro p hp
  have h : env12575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12574_12575 : H12AffineEnvironment.transform 31 396 env12574 = env12575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 396 env12574 == env12575) = true)

theorem identity12575 : scanCanonicalize (H12AffineFastState.compose env12575 (packedSelected [1,4,5,9,13] rootPS)) = affineNative (2^(12+1) ^^^ 2017) := by decide +kernel

theorem selectedBound12575 : packedSelected [1,4,5,9,13] rootPS < 2^1333 := by decide +kernel

def env12576 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,2017,940,4468,775,1344,1345,1025,4469,4097,2024,1708,4983,1897,1789,941,940,5868,1773,1284,396,257,5561,1345,512]

theorem envBound12576 : H12AffineFastState.Bounded env12576 := by
  intro p hp
  have h : env12576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12575_12576 : H12AffineEnvironment.transform 12 2017 env12575 = env12576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2017 env12575 == env12576) = true)

theorem identity12576 : scanCanonicalize (H12AffineFastState.compose env12576 (packedSelected [2,5,6,7,8,9] rootPS)) = affineNative (2^(8+1) ^^^ 372) := by decide +kernel

theorem selectedBound12576 : packedSelected [2,5,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env12577 : List Nat := [2,4,8,16,32,64,128,256,372,1024,0,4096,1173,216,4468,115,1344,1345,1025,4469,4097,1180,1496,4099,1053,1417,217,216,5528,1433,1284,396,257,5561,1345,372]

theorem envBound12577 : H12AffineFastState.Bounded env12577 := by
  intro p hp
  have h : env12577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12576_12577 : H12AffineEnvironment.transform 8 372 env12576 = env12577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 372 env12576 == env12577) = true)

theorem identity12577 : scanCanonicalize (H12AffineFastState.compose env12577 (packedSelected [0,3,5,7,10,15] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound12577 : packedSelected [0,3,5,7,10,15] rootPS < 2^1333 := by decide +kernel

def env12578 : List Nat := [2,4,8,16,32,64,8,256,372,1024,0,4096,1053,80,4468,115,1344,1345,1025,4469,4097,1044,1360,4099,1053,1281,81,80,5392,1297,1284,260,257,5425,1345,372]

theorem envBound12578 : H12AffineFastState.Bounded env12578 := by
  intro p hp
  have h : env12578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12577_12578 : H12AffineEnvironment.transform 6 8 env12577 = env12578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env12577 == env12578) = true)

theorem identity12578 : scanCanonicalize (H12AffineFastState.compose env12578 (packedSelected [0,2,3,4,6,8,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound12578 : packedSelected [0,2,3,4,6,8,10] rootPS < 2^1333 := by decide +kernel

def env12579 : List Nat := [2,4,8,16,32,64,8,256,372,273,0,4096,268,80,4468,115,81,80,272,4469,4097,261,65,4099,268,16,81,80,4097,0,21,260,257,4128,80,372]

theorem envBound12579 : H12AffineFastState.Bounded env12579 := by
  intro p hp
  have h : env12579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12578_12579 : H12AffineEnvironment.transform 9 273 env12578 = env12579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env12578 == env12579) = true)

theorem identity12579 : scanCanonicalize (H12AffineFastState.compose env12579 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound12579 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env12580 : List Nat := [2,4,8,16,32,64,8,117,1,100,0,4096,121,80,4097,115,81,80,101,4096,4097,112,65,4099,121,16,81,80,4097,0,21,113,116,4128,80,1]

theorem envBound12580 : H12AffineFastState.Bounded env12580 := by
  intro p hp
  have h : env12580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12579_12580 : H12AffineEnvironment.transform 7 117 env12579 = env12580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env12579 == env12580) = true)

theorem identity12580 : scanCanonicalize (H12AffineFastState.compose env12580 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound12580 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env12581 : List Nat := [2,4,8,16,32,64,8,117,1,100,0,81,121,80,80,115,81,80,101,81,80,112,65,82,121,16,81,80,80,0,21,113,116,113,80,1]

theorem envBound12581 : H12AffineFastState.Bounded env12581 := by
  intro p hp
  have h : env12581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12580_12581 : H12AffineEnvironment.transform 11 81 env12580 = env12581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env12580 == env12581) = true)

theorem identity12581 : scanCanonicalize (H12AffineFastState.compose env12581 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound12581 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env12582 : List Nat := [2,4,8,16,32,17,8,36,1,53,0,0,40,1,1,34,0,1,52,0,1,33,16,3,40,16,0,1,1,0,21,32,37,32,1,1]

theorem envBound12582 : H12AffineFastState.Bounded env12582 := by
  intro p hp
  have h : env12582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12581_12582 : H12AffineEnvironment.transform 5 17 env12581 = env12582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env12581 == env12582) = true)

theorem identity12582 : scanCanonicalize (H12AffineFastState.compose env12582 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound12582 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12583 : List Nat := [2,4,8,1,32,0,8,36,1,36,0,0,40,1,1,34,0,1,37,0,1,33,1,3,40,1,0,1,1,0,4,32,37,32,1,1]

theorem envBound12583 : H12AffineFastState.Bounded env12583 := by
  intro p hp
  have h : env12583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12582_12583 : H12AffineEnvironment.transform 3 1 env12582 = env12583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env12582 == env12583) = true)

theorem identity12583 : scanCanonicalize (H12AffineFastState.compose env12583 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound12583 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12584 : List Nat := [2,4,8,1,10,0,8,14,1,14,0,0,2,1,1,8,0,1,15,0,1,11,1,3,2,1,0,1,1,0,4,10,15,10,1,1]

theorem envBound12584 : H12AffineFastState.Bounded env12584 := by
  intro p hp
  have h : env12584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12583_12584 : H12AffineEnvironment.transform 4 10 env12583 = env12584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env12583 == env12584) = true)

def env12585 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1345,262144,524288,32769,4097,8201,17664,98565,8328,541008,795917,16385,545088,1073741824,1284,4294967296,256,4295074214,1344,512]

theorem envBound12585 : H12AffineFastState.Bounded env12585 := by
  intro p hp
  have h : env12585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12567_12585 : H12AffineEnvironment.transform 16 1345 env12567 = env12585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env12567 == env12585) = true)

theorem identity12585 : scanCanonicalize (H12AffineFastState.compose env12585 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 41000) := by decide +kernel

theorem selectedBound12585 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env12586 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1345,262144,524288,32769,4097,8201,17664,98565,8328,541008,795917,16385,545088,41000,1284,4294967296,256,4295074214,1344,512]

theorem envBound12586 : H12AffineFastState.Bounded env12586 := by
  intro p hp
  have h : env12586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12585_12586 : H12AffineEnvironment.transform 29 41000 env12585 = env12586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 41000 env12585 == env12586) = true)

def env12587 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1345,262144,304168,32769,4097,8201,17664,98565,8328,320888,33061,16385,324968,41000,1284,4294967296,256,4295074214,1344,512]

theorem envBound12587 : H12AffineFastState.Bounded env12587 := by
  intro p hp
  have h : env12587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12586_12587 : H12AffineEnvironment.transform 18 304168 env12586 = env12587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 304168 env12586 == env12587) = true)

theorem identity12587 : scanCanonicalize (H12AffineFastState.compose env12587 (packedSelected [4,9,18] rootPS)) = affineNative (2^(17+1) ^^^ 33061) := by decide +kernel

theorem selectedBound12587 : packedSelected [4,9,18] rootPS < 2^1333 := by decide +kernel

def env12588 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1345,33061,9485,32769,4097,8201,17664,98565,8328,25693,33061,16385,29773,41000,1284,4294967296,256,4295074214,1344,512]

theorem envBound12588 : H12AffineFastState.Bounded env12588 := by
  intro p hp
  have h : env12588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12587_12588 : H12AffineEnvironment.transform 17 33061 env12587 = env12588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 33061 env12587 == env12588) = true)

theorem identity12588 : scanCanonicalize (H12AffineFastState.compose env12588 (packedSelected [20,23] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound12588 : packedSelected [20,23] rootPS < 2^1333 := by decide +kernel

def env12589 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,269,16384,32768,65536,1345,33061,1024,32769,4097,260,17664,98565,389,17744,33061,16385,21824,33061,1284,4294967296,256,4295065771,1344,512]

theorem envBound12589 : H12AffineFastState.Bounded env12589 := by
  intro p hp
  have h : env12589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12588_12589 : H12AffineEnvironment.transform 12 269 env12588 = env12589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env12588 == env12589) = true)

theorem identity12589 : scanCanonicalize (H12AffineFastState.compose env12589 (packedSelected [0,7] rootPS)) = affineNative (2^(14+1) ^^^ 292) := by decide +kernel

theorem selectedBound12589 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env12590 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,269,16384,292,65536,1345,1,1024,293,4097,260,17664,65569,389,17744,1,16385,21824,1,1284,4294967296,256,4295033231,1344,512]

theorem envBound12590 : H12AffineFastState.Bounded env12590 := by
  intro p hp
  have h : env12590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12589_12590 : H12AffineEnvironment.transform 14 292 env12589 = env12590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 292 env12589 == env12590) = true)

theorem identity12590 : scanCanonicalize (H12AffineFastState.compose env12590 (packedSelected [1,3,10,12,13] rootPS)) = affineNative (2^(15+1) ^^^ 16555) := by decide +kernel

theorem selectedBound12590 : packedSelected [1,3,10,12,13] rootPS < 2^1333 := by decide +kernel

def env12591 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,269,16384,292,16555,1345,1,1024,293,4097,260,17664,16522,389,17744,1,16385,21824,1,1284,4294967296,256,4294983972,1344,512]

theorem envBound12591 : H12AffineFastState.Bounded env12591 := by
  intro p hp
  have h : env12591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12590_12591 : H12AffineEnvironment.transform 15 16555 env12590 = env12591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 16555 env12590 == env12591) = true)

theorem identity12591 : scanCanonicalize (H12AffineFastState.compose env12591 (packedSelected [12,15] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound12591 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env12592 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,81,269,16384,292,16555,1345,1,1024,293,80,260,17664,16522,389,17744,1,16385,17681,1,1284,4294967296,256,4294983972,1344,512]

theorem envBound12592 : H12AffineFastState.Bounded env12592 := by
  intro p hp
  have h : env12592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12591_12592 : H12AffineEnvironment.transform 11 81 env12591 = env12592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env12591 == env12592) = true)

theorem identity12592 : scanCanonicalize (H12AffineFastState.compose env12592 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(13+1) ^^^ 1) := by decide +kernel

theorem selectedBound12592 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env12593 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,81,269,1,292,170,1345,1,1024,293,80,260,1281,139,389,1361,1,0,1296,1,1284,4294967296,256,4294967589,1344,512]

theorem envBound12593 : H12AffineFastState.Bounded env12593 := by
  intro p hp
  have h : env12593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12592_12593 : H12AffineEnvironment.transform 13 1 env12592 = env12593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1 env12592 == env12593) = true)

theorem identity12593 : scanCanonicalize (H12AffineFastState.compose env12593 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound12593 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env12594 : List Nat := [2,4,8,16,32,64,128,256,512,53,0,81,269,1,292,170,372,1,53,293,80,260,308,139,389,356,1,0,293,1,305,4294967296,256,4294967589,373,512]

theorem envBound12594 : H12AffineFastState.Bounded env12594 := by
  intro p hp
  have h : env12594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12593_12594 : H12AffineEnvironment.transform 9 53 env12593 = env12594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env12593 == env12594) = true)

theorem identity12594 : scanCanonicalize (H12AffineFastState.compose env12594 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound12594 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env12595 : List Nat := [2,4,8,16,32,64,128,256,136,53,0,81,269,1,292,170,372,1,53,293,80,260,308,139,389,356,1,0,293,1,305,4294967296,256,4294967589,373,136]

theorem envBound12595 : H12AffineFastState.Bounded env12595 := by
  intro p hp
  have h : env12595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12594_12595 : H12AffineEnvironment.transform 8 136 env12594 = env12595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env12594 == env12595) = true)

theorem identity12595 : scanCanonicalize (H12AffineFastState.compose env12595 (packedSelected [2,4] rootPS)) = affineNative (2^(7+1) ^^^ 100) := by decide +kernel

theorem selectedBound12595 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env12596 : List Nat := [2,4,8,16,32,64,128,100,136,53,0,81,105,1,64,170,16,1,53,65,80,96,80,139,225,0,1,0,65,1,85,4294967296,100,4294967361,17,136]

theorem envBound12596 : H12AffineFastState.Bounded env12596 := by
  intro p hp
  have h : env12596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12595_12596 : H12AffineEnvironment.transform 7 100 env12595 = env12596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 100 env12595 == env12596) = true)

theorem identity12596 : scanCanonicalize (H12AffineFastState.compose env12596 (packedSelected [5] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound12596 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env12597 : List Nat := [2,4,8,16,32,64,35,100,43,53,0,81,105,1,64,9,16,1,53,65,80,96,80,40,66,0,1,0,65,1,85,4294967296,100,4294967361,17,43]

theorem envBound12597 : H12AffineFastState.Bounded env12597 := by
  intro p hp
  have h : env12597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12596_12597 : H12AffineEnvironment.transform 6 35 env12596 = env12597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env12596 == env12597) = true)

theorem identity12597 : scanCanonicalize (H12AffineFastState.compose env12597 (packedSelected [8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound12597 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env12598 : List Nat := [2,4,8,16,32,16,35,52,43,53,0,1,57,1,16,9,16,1,53,17,0,48,0,40,18,0,1,0,17,1,5,4294967296,52,4294967313,17,43]

theorem envBound12598 : H12AffineFastState.Bounded env12598 := by
  intro p hp
  have h : env12598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12597_12598 : H12AffineEnvironment.transform 5 16 env12597 = env12598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env12597 == env12598) = true)

theorem identity12598 : scanCanonicalize (H12AffineFastState.compose env12598 (packedSelected [0,1] rootPS)) = affineNative (2^(31+1) ^^^ 11) := by decide +kernel

theorem selectedBound12598 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env12599 : List Nat := [2,4,8,16,32,16,35,52,43,53,0,1,57,1,16,9,16,1,53,17,0,48,0,40,18,0,1,0,17,1,5,11,52,26,17,43]

theorem envBound12599 : H12AffineFastState.Bounded env12599 := by
  intro p hp
  have h : env12599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12598_12599 : H12AffineEnvironment.transform 31 11 env12598 = env12599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 11 env12598 == env12599) = true)

theorem identity12599 : scanCanonicalize (H12AffineFastState.compose env12599 (packedSelected [0,2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound12599 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env12600 : List Nat := [2,4,8,1,32,1,35,37,43,36,0,1,40,1,1,9,1,1,36,0,0,33,0,40,3,0,1,0,0,1,5,11,37,11,0,43]

theorem envBound12600 : H12AffineFastState.Bounded env12600 := by
  intro p hp
  have h : env12600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12599_12600 : H12AffineEnvironment.transform 3 1 env12599 = env12600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env12599 == env12600) = true)

theorem identity12600 : scanCanonicalize (H12AffineFastState.compose env12600 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound12600 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12601 : List Nat := [2,4,8,1,10,1,9,15,1,14,0,1,2,1,1,9,1,1,14,0,0,11,0,2,3,0,1,0,0,1,5,11,15,11,0,1]

theorem envBound12601 : H12AffineFastState.Bounded env12601 := by
  intro p hp
  have h : env12601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12600_12601 : H12AffineEnvironment.transform 4 10 env12600 = env12601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env12600 == env12601) = true)

def env12602 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1345,262144,304169,32769,4097,8201,17664,98565,8328,320889,33060,16385,324969,41000,1284,4294967296,256,4295074214,1344,512]

theorem envBound12602 : H12AffineFastState.Bounded env12602 := by
  intro p hp
  have h : env12602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12586_12602 : H12AffineEnvironment.transform 18 304169 env12586 = env12602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 304169 env12586 == env12602) = true)

theorem identity12602 : scanCanonicalize (H12AffineFastState.compose env12602 (packedSelected [4,9,18] rootPS)) = affineNative (2^(17+1) ^^^ 8460) := by decide +kernel

theorem selectedBound12602 : packedSelected [4,9,18] rootPS < 2^1333 := by decide +kernel

def env12603 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1345,8460,34085,32769,4097,8201,17664,98565,8328,50293,33060,16385,54373,41000,1284,4294967296,256,4295074214,1344,512]

theorem envBound12603 : H12AffineFastState.Bounded env12603 := by
  intro p hp
  have h : env12603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12602_12603 : H12AffineEnvironment.transform 17 8460 env12602 = env12603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8460 env12602 == env12603) = true)

theorem identity12603 : scanCanonicalize (H12AffineFastState.compose env12603 (packedSelected [5,8,13,15,19] rootPS)) = affineNative (2^(15+1) ^^^ 33166) := by decide +kernel

theorem selectedBound12603 : packedSelected [5,8,13,15,19] rootPS < 2^1333 := by decide +kernel

def env12604 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,33166,1345,8460,34085,32769,4097,8201,17664,139,8328,50293,33060,16385,54373,41000,1284,4294967296,256,4294975528,1344,512]

theorem envBound12604 : H12AffineFastState.Bounded env12604 := by
  intro p hp
  have h : env12604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12603_12604 : H12AffineEnvironment.transform 15 33166 env12603 = env12604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33166 env12603 == env12604) = true)

def env12605 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,18376,17990,1345,8460,17133,18377,4097,8201,17664,139,8328,957,18156,16385,5037,26592,1284,4294967296,256,4294975528,1344,512]

theorem envBound12605 : H12AffineFastState.Bounded env12605 := by
  intro p hp
  have h : env12605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12604_12605 : H12AffineEnvironment.transform 14 18376 env12604 = env12605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 18376 env12604 == env12605) = true)

theorem identity12605 : scanCanonicalize (H12AffineFastState.compose env12605 (packedSelected [1,3,10,13] rootPS)) = affineNative (2^(13+1) ^^^ 4177) := by decide +kernel

theorem selectedBound12605 : packedSelected [1,3,10,13] rootPS < 2^1333 := by decide +kernel

def env12606 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,4177,6041,5655,1345,8460,4796,6040,4097,8201,5457,139,8328,957,5821,4176,5037,14257,1284,4294967296,256,4294975528,1344,512]

theorem envBound12606 : H12AffineFastState.Bounded env12606 := by
  intro p hp
  have h : env12606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12605_12606 : H12AffineEnvironment.transform 13 4177 env12605 = env12606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env12605 == env12606) = true)

theorem identity12606 : scanCanonicalize (H12AffineFastState.compose env12606 (packedSelected [4,5,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 1724) := by decide +kernel

theorem selectedBound12606 : packedSelected [4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env12607 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1724,8192,1773,293,171,1345,8460,1024,292,1725,8201,1005,139,8328,957,1,1772,1297,8461,1284,4294967296,256,4294975528,1344,512]

theorem envBound12607 : H12AffineFastState.Bounded env12607 := by
  intro p hp
  have h : env12607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12606_12607 : H12AffineEnvironment.transform 11 1724 env12606 = env12607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1724 env12606 == env12607) = true)

def env12608 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1724,672,1773,293,171,1345,940,1024,292,1725,681,1005,139,552,957,1,1772,1297,941,1284,4294967296,256,4294967944,1344,512]

theorem envBound12608 : H12AffineFastState.Bounded env12608 := by
  intro p hp
  have h : env12608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12607_12608 : H12AffineEnvironment.transform 12 672 env12607 = env12608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 672 env12607 == env12608) = true)

theorem identity12608 : scanCanonicalize (H12AffineFastState.compose env12608 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 429) := by decide +kernel

theorem selectedBound12608 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12609 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1724,672,1773,293,171,1345,940,1024,292,1725,681,1005,139,552,957,1,1772,1297,941,1284,429,256,805,1344,512]

theorem envBound12609 : H12AffineFastState.Bounded env12609 := by
  intro p hp
  have h : env12609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12608_12609 : H12AffineEnvironment.transform 31 429 env12608 = env12609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 429 env12608 == env12609) = true)

theorem identity12609 : scanCanonicalize (H12AffineFastState.compose env12609 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 429) := by decide +kernel

theorem selectedBound12609 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env12610 : List Nat := [2,4,8,16,32,64,128,256,429,1024,0,1297,269,1344,293,171,1345,1,1024,292,1296,260,64,139,389,16,1,1345,1297,0,1284,429,256,136,1344,429]

theorem envBound12610 : H12AffineFastState.Bounded env12610 := by
  intro p hp
  have h : env12610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12609_12610 : H12AffineEnvironment.transform 8 429 env12609 = env12610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 429 env12609 == env12610) = true)

theorem identity12610 : scanCanonicalize (H12AffineFastState.compose env12610 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound12610 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12611 : List Nat := [2,4,8,16,32,64,128,172,1,1024,0,1213,161,1260,137,171,1261,1,1024,136,1212,168,64,139,41,16,1,1261,1213,0,1192,1,172,136,1260,1]

theorem envBound12611 : H12AffineFastState.Bounded env12611 := by
  intro p hp
  have h : env12611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12610_12611 : H12AffineEnvironment.transform 7 172 env12610 = env12611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env12610 == env12611) = true)

theorem identity12611 : scanCanonicalize (H12AffineFastState.compose env12611 (packedSelected [2,4] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound12611 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env12612 : List Nat := [2,4,8,16,32,16,128,172,1,1024,0,1213,161,1212,137,171,1213,1,1024,136,1212,168,16,139,41,16,1,1213,1213,0,1192,1,172,136,1212,1]

theorem envBound12612 : H12AffineFastState.Bounded env12612 := by
  intro p hp
  have h : env12612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12611_12612 : H12AffineEnvironment.transform 5 16 env12611 = env12612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env12611 == env12612) = true)

def env12613 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1724,673,1773,293,171,1345,941,1024,292,1725,680,1005,139,553,957,1,1772,1297,940,1284,4294967296,256,4294967945,1344,512]

theorem envBound12613 : H12AffineFastState.Bounded env12613 := by
  intro p hp
  have h : env12613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12607_12613 : H12AffineEnvironment.transform 12 673 env12607 = env12613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 673 env12607 == env12613) = true)

theorem identity12613 : scanCanonicalize (H12AffineFastState.compose env12613 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 648) := by decide +kernel

theorem selectedBound12613 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12614 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1724,673,1773,293,171,1345,941,1024,292,1725,680,1005,139,553,957,1,1772,1297,940,1284,648,256,1,1344,512]

theorem envBound12614 : H12AffineFastState.Bounded env12614 := by
  intro p hp
  have h : env12614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12613_12614 : H12AffineEnvironment.transform 31 648 env12613 = env12614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 648 env12613 == env12614) = true)

def env12615 : List Nat := [2,4,8,16,32,64,8,256,512,1024,0,1588,553,1637,293,35,1345,805,1024,292,1589,544,869,3,553,821,1,1636,1297,804,1284,512,256,1,1344,512]

theorem envBound12615 : H12AffineFastState.Bounded env12615 := by
  intro p hp
  have h : env12615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12614_12615 : H12AffineEnvironment.transform 6 8 env12614 = env12615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env12614 == env12615) = true)

theorem identity12615 : scanCanonicalize (H12AffineFastState.compose env12615 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 81) := by decide +kernel

theorem selectedBound12615 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12616 : List Nat := [2,4,8,16,32,64,8,256,81,1024,0,1125,120,1076,293,35,1345,372,1024,292,1124,113,308,3,120,356,1,1077,1297,373,1284,81,256,1,1344,81]

theorem envBound12616 : H12AffineFastState.Bounded env12616 := by
  intro p hp
  have h : env12616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12615_12616 : H12AffineEnvironment.transform 8 81 env12615 = env12616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env12615 == env12616) = true)

theorem identity12616 : scanCanonicalize (H12AffineFastState.compose env12616 (packedSelected [2,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound12616 : packedSelected [2,4,5] rootPS < 2^1333 := by decide +kernel

def env12617 : List Nat := [2,4,8,16,32,17,8,256,0,1024,0,1076,41,1076,293,35,1296,293,1024,292,1077,32,308,3,41,309,1,1077,1297,292,1284,0,256,1,1297,0]

theorem envBound12617 : H12AffineFastState.Bounded env12617 := by
  intro p hp
  have h : env12617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12616_12617 : H12AffineEnvironment.transform 5 17 env12616 = env12617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env12616 == env12617) = true)

theorem identity12617 : scanCanonicalize (H12AffineFastState.compose env12617 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound12617 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12618 : List Nat := [2,4,8,16,32,17,8,4,0,1024,0,1076,41,1076,33,35,1044,33,1024,32,1077,32,48,3,41,49,1,1077,1045,32,1024,0,4,1,1045,0]

theorem envBound12618 : H12AffineFastState.Bounded env12618 := by
  intro p hp
  have h : env12618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12617_12618 : H12AffineEnvironment.transform 7 4 env12617 = env12618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env12617 == env12618) = true)

theorem identity12618 : scanCanonicalize (H12AffineFastState.compose env12618 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound12618 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env12619 : List Nat := [2,4,8,16,1,17,8,4,0,1024,0,1045,8,1045,0,2,1044,0,1024,1,1044,1,17,3,8,16,1,1044,1045,1,1024,0,4,1,1045,0]

theorem envBound12619 : H12AffineFastState.Bounded env12619 := by
  intro p hp
  have h : env12619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12618_12619 : H12AffineEnvironment.transform 4 1 env12618 = env12619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env12618 == env12619) = true)

def leafEnv12619 : List Nat := [2,4,8,16,1,17,8,4,0,1024,0,1045,8,1045,0,2,1044,0,1024,1,1044,1,17,3,1024,8,1,16,1,1044,1045,1,1024,0,4,1,4,3,1045,0,0,1044,1]

def active12619 : List Nat := [0,1,2,3,9]

def tree12619 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood12619 : H12WitnessSearch.Good tree12619 := H12GlobalWitnessIndex.good

theorem leafIdentity12619 : H12AffineFastState.composeSystem env12619 rootObs = leafEnv12619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env12619 rootObs == leafEnv12619) = true)

theorem terminalChecked12619 : H12PackedTerminal.terminalCheckFast leafEnv12619 active12619 tree12619 = true := by decide +kernel

def env12620 : List Nat := [2,4,8,16,32,64,9,256,512,1024,0,1589,552,1636,293,34,1345,804,1024,292,1588,545,868,2,553,820,1,1637,1297,805,1284,513,256,1,1344,512]

theorem envBound12620 : H12AffineFastState.Bounded env12620 := by
  intro p hp
  have h : env12620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12614_12620 : H12AffineEnvironment.transform 6 9 env12614 = env12620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env12614 == env12620) = true)

theorem identity12620 : scanCanonicalize (H12AffineFastState.compose env12620 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound12620 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12621 : List Nat := [2,4,8,16,32,64,9,117,512,1024,0,1589,552,1636,80,34,1076,593,1024,81,1588,545,529,2,553,577,1,1637,1124,592,1137,513,117,1,1077,512]

theorem envBound12621 : H12AffineFastState.Bounded env12621 := by
  intro p hp
  have h : env12621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12620_12621 : H12AffineEnvironment.transform 7 117 env12620 = env12621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env12620 == env12621) = true)

theorem identity12621 : scanCanonicalize (H12AffineFastState.compose env12621 (packedSelected [5] rootPS)) = affineNative (2^(8+1) ^^^ 80) := by decide +kernel

theorem selectedBound12621 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env12622 : List Nat := [2,4,8,16,32,64,9,117,80,1024,0,1125,120,1076,80,34,1076,1,1024,81,1124,113,65,2,121,17,1,1077,1124,0,1137,81,117,1,1077,80]

theorem envBound12622 : H12AffineFastState.Bounded env12622 := by
  intro p hp
  have h : env12622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12621_12622 : H12AffineEnvironment.transform 8 80 env12621 = env12622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 80 env12621 == env12622) = true)

def env12623 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,18377,17991,1345,8460,17132,18376,4097,8201,17664,139,8328,956,18157,16385,5036,26593,1284,4294967296,256,4294975528,1344,512]

theorem envBound12623 : H12AffineFastState.Bounded env12623 := by
  intro p hp
  have h : env12623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12604_12623 : H12AffineEnvironment.transform 14 18377 env12604 = env12623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 18377 env12604 == env12623) = true)

theorem identity12623 : scanCanonicalize (H12AffineFastState.compose env12623 (packedSelected [1,3,10,13] rootPS)) = affineNative (2^(11+1) ^^^ 1725) := by decide +kernel

theorem selectedBound12623 : packedSelected [1,3,10,13] rootPS < 2^1333 := by decide +kernel

def env12624 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1725,8192,16384,18377,17991,1345,8460,17132,18376,1724,8201,17664,139,8328,956,18157,16385,1297,26593,1284,4294967296,256,4294975528,1344,512]

theorem envBound12624 : H12AffineFastState.Bounded env12624 := by
  intro p hp
  have h : env12624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12623_12624 : H12AffineEnvironment.transform 11 1725 env12623 = env12624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1725 env12623 == env12624) = true)

theorem identity12624 : scanCanonicalize (H12AffineFastState.compose env12624 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 1772) := by decide +kernel

theorem selectedBound12624 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env12625 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1725,8192,1772,293,171,1345,8460,1024,292,1724,8201,1004,139,8328,956,1,1773,1297,8461,1284,4294967296,256,4294975528,1344,512]

theorem envBound12625 : H12AffineFastState.Bounded env12625 := by
  intro p hp
  have h : env12625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12624_12625 : H12AffineEnvironment.transform 13 1772 env12624 = env12625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1772 env12624 == env12625) = true)

def env12626 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1725,672,1772,293,171,1345,940,1024,292,1724,681,1004,139,552,956,1,1773,1297,941,1284,4294967296,256,4294967944,1344,512]

theorem envBound12626 : H12AffineFastState.Bounded env12626 := by
  intro p hp
  have h : env12626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12625_12626 : H12AffineEnvironment.transform 12 672 env12625 = env12626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 672 env12625 == env12626) = true)

theorem identity12626 : scanCanonicalize (H12AffineFastState.compose env12626 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 428) := by decide +kernel

theorem selectedBound12626 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12627 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1725,672,1772,293,171,1345,940,1024,292,1724,681,1004,139,552,956,1,1773,1297,941,1284,428,256,804,1344,512]

theorem envBound12627 : H12AffineFastState.Bounded env12627 := by
  intro p hp
  have h : env12627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12626_12627 : H12AffineEnvironment.transform 31 428 env12626 = env12627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 428 env12626 == env12627) = true)

def env12628 : List Nat := [2,4,8,16,32,64,8,256,512,1024,0,1589,552,1636,293,35,1345,804,1024,292,1588,545,868,3,552,820,1,1637,1297,805,1284,292,256,804,1344,512]

theorem envBound12628 : H12AffineFastState.Bounded env12628 := by
  intro p hp
  have h : env12628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12627_12628 : H12AffineEnvironment.transform 6 8 env12627 = env12628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env12627 == env12628) = true)

theorem identity12628 : scanCanonicalize (H12AffineFastState.compose env12628 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound12628 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12629 : List Nat := [2,4,8,16,32,64,8,36,512,1024,0,1589,552,1636,1,35,1125,512,1024,0,1588,545,576,3,552,528,1,1637,1077,513,1056,0,36,512,1124,512]

theorem envBound12629 : H12AffineFastState.Bounded env12629 := by
  intro p hp
  have h : env12629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12628_12629 : H12AffineEnvironment.transform 7 36 env12628 = env12629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env12628 == env12629) = true)

theorem identity12629 : scanCanonicalize (H12AffineFastState.compose env12629 (packedSelected [2,4] rootPS)) = affineNative (2^(8+1) ^^^ 81) := by decide +kernel

theorem selectedBound12629 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env12630 : List Nat := [2,4,8,16,32,64,8,36,81,1024,0,1124,121,1077,1,35,1125,81,1024,0,1125,112,17,3,121,65,1,1076,1077,80,1056,0,36,81,1124,81]

theorem envBound12630 : H12AffineFastState.Bounded env12630 := by
  intro p hp
  have h : env12630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12629_12630 : H12AffineEnvironment.transform 8 81 env12629 = env12630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env12629 == env12630) = true)

theorem identity12630 : scanCanonicalize (H12AffineFastState.compose env12630 (packedSelected [5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound12630 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env12631 : List Nat := [2,4,8,16,32,16,8,36,1,1024,0,1076,41,1077,1,35,1077,1,1024,0,1077,32,17,3,41,17,1,1076,1077,0,1056,0,36,1,1076,1]

theorem envBound12631 : H12AffineFastState.Bounded env12631 := by
  intro p hp
  have h : env12631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12630_12631 : H12AffineEnvironment.transform 5 16 env12630 = env12631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env12630 == env12631) = true)

theorem identity12631 : scanCanonicalize (H12AffineFastState.compose env12631 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound12631 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12632 : List Nat := [2,4,8,16,1,16,8,5,1,1024,0,1045,8,1044,1,2,1044,1,1024,0,1044,1,17,3,8,17,1,1045,1044,0,1025,0,5,1,1045,1]

theorem envBound12632 : H12AffineFastState.Bounded env12632 := by
  intro p hp
  have h : env12632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12631_12632 : H12AffineEnvironment.transform 4 1 env12631 = env12632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env12631 == env12632) = true)

def leafEnv12632 : List Nat := [2,4,8,16,1,16,8,5,1,1024,0,1045,8,1044,1,2,1044,1,1024,0,1044,1,17,3,1025,8,1,17,1,1045,1044,0,1025,0,5,1,4,3,1045,1,0,1045,1]

def active12632 : List Nat := [0,1,2,3,9]

def tree12632 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood12632 : H12WitnessSearch.Good tree12632 := H12GlobalWitnessIndex.good

theorem leafIdentity12632 : H12AffineFastState.composeSystem env12632 rootObs = leafEnv12632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env12632 rootObs == leafEnv12632) = true)

theorem terminalChecked12632 : H12PackedTerminal.terminalCheckFast leafEnv12632 active12632 tree12632 = true := by decide +kernel

def env12633 : List Nat := [2,4,8,16,32,64,9,256,512,1024,0,1588,553,1637,293,34,1345,805,1024,292,1589,544,869,2,552,821,1,1636,1297,804,1284,293,256,804,1344,512]

theorem envBound12633 : H12AffineFastState.Bounded env12633 := by
  intro p hp
  have h : env12633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12627_12633 : H12AffineEnvironment.transform 6 9 env12627 = env12633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env12627 == env12633) = true)

theorem identity12633 : scanCanonicalize (H12AffineFastState.compose env12633 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound12633 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12634 : List Nat := [2,4,8,16,32,64,9,256,0,1024,0,1076,41,1125,293,34,1345,293,1024,292,1077,32,357,2,40,309,1,1124,1297,292,1284,293,256,292,1344,0]

theorem envBound12634 : H12AffineFastState.Bounded env12634 := by
  intro p hp
  have h : env12634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12633_12634 : H12AffineEnvironment.transform 8 0 env12633 = env12634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env12633 == env12634) = true)

theorem identity12634 : scanCanonicalize (H12AffineFastState.compose env12634 (packedSelected [2,4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound12634 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env12635 : List Nat := [2,4,8,16,32,17,9,256,0,1024,0,1076,41,1076,293,34,1296,293,1024,292,1077,32,308,2,40,309,1,1077,1297,292,1284,293,256,292,1297,0]

theorem envBound12635 : H12AffineFastState.Bounded env12635 := by
  intro p hp
  have h : env12635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12634_12635 : H12AffineEnvironment.transform 5 17 env12634 = env12635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env12634 == env12635) = true)

theorem identity12635 : scanCanonicalize (H12AffineFastState.compose env12635 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound12635 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12636 : List Nat := [2,4,8,16,32,17,9,4,0,1024,0,1076,41,1076,33,34,1044,33,1024,32,1077,32,48,2,40,49,1,1077,1045,32,1024,33,4,32,1045,0]

theorem envBound12636 : H12AffineFastState.Bounded env12636 := by
  intro p hp
  have h : env12636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12635_12636 : H12AffineEnvironment.transform 7 4 env12635 = env12636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env12635 == env12636) = true)

def leafEnv12636 : List Nat := [2,4,8,16,32,17,9,4,0,1024,0,1076,41,1076,33,34,1044,33,1024,32,1077,32,48,2,1024,40,1,49,1,1077,1045,32,1024,33,4,32,4,34,1045,0,0,1044,1]

def active12636 : List Nat := [0,1,2,3,4,9]

def tree12636 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood12636 : H12WitnessSearch.Good tree12636 := H12GlobalWitnessIndex.good

theorem leafIdentity12636 : H12AffineFastState.composeSystem env12636 rootObs = leafEnv12636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env12636 rootObs == leafEnv12636) = true)

theorem terminalChecked12636 : H12PackedTerminal.terminalCheckFast leafEnv12636 active12636 tree12636 = true := by decide +kernel

def env12637 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1725,673,1772,293,171,1345,941,1024,292,1724,680,1004,139,553,956,1,1773,1297,940,1284,4294967296,256,4294967945,1344,512]

theorem envBound12637 : H12AffineFastState.Bounded env12637 := by
  intro p hp
  have h : env12637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12625_12637 : H12AffineEnvironment.transform 12 673 env12625 = env12637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 673 env12625 == env12637) = true)

theorem identity12637 : scanCanonicalize (H12AffineFastState.compose env12637 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 649) := by decide +kernel

theorem selectedBound12637 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12638 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1725,673,1772,293,171,1345,941,1024,292,1724,680,1004,139,553,956,1,1773,1297,940,1284,649,256,0,1344,512]

theorem envBound12638 : H12AffineFastState.Bounded env12638 := by
  intro p hp
  have h : env12638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12637_12638 : H12AffineEnvironment.transform 31 649 env12637 = env12638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 649 env12637 == env12638) = true)

theorem identity12638 : scanCanonicalize (H12AffineFastState.compose env12638 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 428) := by decide +kernel

theorem selectedBound12638 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env12639 : List Nat := [2,4,8,16,32,64,128,256,428,1024,0,1297,269,1344,293,171,1345,1,1024,292,1296,260,64,139,389,16,1,1345,1297,0,1284,293,256,0,1344,428]

theorem envBound12639 : H12AffineFastState.Bounded env12639 := by
  intro p hp
  have h : env12639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12638_12639 : H12AffineEnvironment.transform 8 428 env12638 = env12639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 428 env12638 == env12639) = true)

theorem identity12639 : scanCanonicalize (H12AffineFastState.compose env12639 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound12639 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12640 : List Nat := [2,4,8,16,32,64,128,252,80,1024,0,1261,241,1212,217,171,1213,1,1024,216,1260,248,64,139,121,16,1,1213,1261,0,1272,217,252,0,1212,80]

theorem envBound12640 : H12AffineFastState.Bounded env12640 := by
  intro p hp
  have h : env12640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12639_12640 : H12AffineEnvironment.transform 7 252 env12639 = env12640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env12639 == env12640) = true)

theorem identity12640 : scanCanonicalize (H12AffineFastState.compose env12640 (packedSelected [2,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound12640 : packedSelected [2,4,5] rootPS < 2^1333 := by decide +kernel

def env12641 : List Nat := [2,4,8,16,32,64,89,37,80,1024,0,1076,40,1125,0,114,1124,1,1024,1,1077,33,64,82,121,16,1,1124,1076,0,1057,0,37,0,1125,80]

theorem envBound12641 : H12AffineFastState.Bounded env12641 := by
  intro p hp
  have h : env12641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12640_12641 : H12AffineEnvironment.transform 6 89 env12640 = env12641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env12640 == env12641) = true)

def env12642 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,8200,17664,230468,8328,541008,925773,148800,676865,1073741824,1284,4294967296,132161,4295206118,131073,512]

theorem envBound12642 : H12AffineFastState.Bounded env12642 := by
  intro p hp
  have h : env12642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12566_12642 : H12AffineEnvironment.transform 10 1 env12566 = env12642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env12566 == env12642) = true)

def env12643 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1344,262144,524288,32769,4097,8200,17664,98564,8328,541008,795917,16384,545089,1073741824,1284,4294967296,257,4295074214,1345,512]

theorem envBound12643 : H12AffineFastState.Bounded env12643 := by
  intro p hp
  have h : env12643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12642_12643 : H12AffineEnvironment.transform 16 1344 env12642 = env12643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env12642 == env12643) = true)

theorem identity12643 : scanCanonicalize (H12AffineFastState.compose env12643 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 266320) := by decide +kernel

theorem selectedBound12643 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env12644 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1344,262144,524288,32769,4097,8200,17664,98564,8328,541008,795917,16384,545089,266320,1284,4294967296,257,4295074214,1345,512]

theorem envBound12644 : H12AffineFastState.Bounded env12644 := by
  intro p hp
  have h : env12644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12643_12644 : H12AffineEnvironment.transform 29 266320 env12643 = env12644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 266320 env12643 == env12644) = true)

theorem identity12644 : scanCanonicalize (H12AffineFastState.compose env12644 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(18+1) ^^^ 1025) := by decide +kernel

theorem selectedBound12644 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env12645 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1344,262144,1025,32769,4097,8200,17664,98564,8328,17745,270604,16384,21824,266320,1284,4294967296,257,4295074214,1345,512]

theorem envBound12645 : H12AffineFastState.Bounded env12645 := by
  intro p hp
  have h : env12645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12644_12645 : H12AffineEnvironment.transform 18 1025 env12644 = env12645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env12644 == env12645) = true)

theorem identity12645 : scanCanonicalize (H12AffineFastState.compose env12645 (packedSelected [1,5,8,15,17,21,24,38] rootPS)) = affineNative (2^(17+1) ^^^ 74150) := by decide +kernel

theorem selectedBound12645 : packedSelected [1,5,8,15,17,21,24,38] rootPS < 2^1333 := by decide +kernel

def env12646 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1344,74150,1025,32769,4097,8200,17664,98564,8328,17745,65706,16384,21824,78326,1284,4294967296,257,4295074214,1345,512]

theorem envBound12646 : H12AffineFastState.Bounded env12646 := by
  intro p hp
  have h : env12646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12645_12646 : H12AffineEnvironment.transform 17 74150 env12645 = env12646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 74150 env12645 == env12646) = true)

theorem identity12646 : scanCanonicalize (H12AffineFastState.compose env12646 (packedSelected [1,5,8,24] rootPS)) = affineNative (2^(15+1) ^^^ 4346) := by decide +kernel

theorem selectedBound12646 : packedSelected [1,5,8,24] rootPS < 2^1333 := by decide +kernel

def env12647 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,4346,1344,12636,1025,32769,4097,8200,17664,37374,8328,17745,4176,16384,21824,8460,1284,4294967296,257,4295012700,1345,512]

theorem envBound12647 : H12AffineFastState.Bounded env12647 := by
  intro p hp
  have h : env12647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12646_12647 : H12AffineEnvironment.transform 15 4346 env12646 = env12647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4346 env12646 == env12647) = true)

theorem identity12647 : scanCanonicalize (H12AffineFastState.compose env12647 (packedSelected [1,3,5,8,12,13,15,17] rootPS)) = affineNative (2^(13+1) ^^^ 9292) := by decide +kernel

theorem selectedBound12647 : packedSelected [1,3,5,8,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env12648 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,9292,32768,4346,1344,12636,1025,32769,4097,8200,8524,37374,8328,8477,4176,9292,12556,8460,1284,4294967296,257,4295012700,1345,512]

theorem envBound12648 : H12AffineFastState.Bounded env12648 := by
  intro p hp
  have h : env12648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12647_12648 : H12AffineEnvironment.transform 13 9292 env12647 = env12648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 9292 env12647 == env12648) = true)

theorem identity12648 : scanCanonicalize (H12AffineFastState.compose env12648 (packedSelected [3,4,5,9,10,12,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 5148) := by decide +kernel

theorem selectedBound12648 : packedSelected [3,4,5,9,10,12,15,18] rootPS < 2^1333 := by decide +kernel

def env12649 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,5148,4176,32768,4346,1344,1344,1025,32769,4097,5140,5456,37374,5268,5377,4176,4176,1296,5392,1284,4294967296,257,4295001408,1345,512]

theorem envBound12649 : H12AffineFastState.Bounded env12649 := by
  intro p hp
  have h : env12649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12648_12649 : H12AffineEnvironment.transform 12 5148 env12648 = env12649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5148 env12648 == env12649) = true)

theorem identity12649 : scanCanonicalize (H12AffineFastState.compose env12649 (packedSelected [1,3] rootPS)) = affineNative (2^(31+1) ^^^ 37624) := by decide +kernel

theorem selectedBound12649 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env12650 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,5148,4176,32768,4346,1344,1344,1025,32769,4097,5140,5456,37374,5268,5377,4176,4176,1296,5392,1284,37624,257,6072,1345,512]

theorem envBound12650 : H12AffineFastState.Bounded env12650 := by
  intro p hp
  have h : env12650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12649_12650 : H12AffineEnvironment.transform 31 37624 env12649 = env12650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 37624 env12649 == env12650) = true)

theorem identity12650 : scanCanonicalize (H12AffineFastState.compose env12650 (packedSelected [5,8] rootPS)) = affineNative (2^(11+1) ^^^ 1808) := by decide +kernel

theorem selectedBound12650 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env12651 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1808,780,1856,32768,2026,1344,1344,1025,32769,1809,772,576,34542,900,529,1856,1856,1296,512,1284,34280,257,168,1345,512]

theorem envBound12651 : H12AffineFastState.Bounded env12651 := by
  intro p hp
  have h : env12651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12650_12651 : H12AffineEnvironment.transform 11 1808 env12650 = env12651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1808 env12650 == env12651) = true)

theorem identity12651 : scanCanonicalize (H12AffineFastState.compose env12651 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 373) := by decide +kernel

theorem selectedBound12651 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env12652 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1808,780,1856,373,2026,1344,1344,1025,372,1809,772,576,1947,900,529,1856,1856,1296,512,1284,1181,257,168,1345,512]

theorem envBound12652 : H12AffineFastState.Bounded env12652 := by
  intro p hp
  have h : env12652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12651_12652 : H12AffineEnvironment.transform 14 373 env12651 = env12652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 373 env12651 == env12652) = true)

theorem identity12652 : scanCanonicalize (H12AffineFastState.compose env12652 (packedSelected [0,7,10,13] rootPS)) = affineNative (2^(8+1) ^^^ 508) := by decide +kernel

theorem selectedBound12652 : packedSelected [0,7,10,13] rootPS < 2^1333 := by decide +kernel

def env12653 : List Nat := [2,4,8,16,32,64,128,256,508,1024,1,1260,240,1212,373,1046,1344,1344,1025,372,1261,248,444,1127,120,493,1212,1212,1296,508,1284,1181,257,168,1345,508]

theorem envBound12653 : H12AffineFastState.Bounded env12653 := by
  intro p hp
  have h : env12653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12652_12653 : H12AffineEnvironment.transform 8 508 env12652 = env12653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 508 env12652 == env12653) = true)

theorem identity12653 : scanCanonicalize (H12AffineFastState.compose env12653 (packedSelected [1,4,10] rootPS)) = affineNative (2^(9+1) ^^^ 15) := by decide +kernel

theorem selectedBound12653 : packedSelected [1,4,10] rootPS < 2^1333 := by decide +kernel

def env12654 : List Nat := [2,4,8,16,32,64,128,256,508,15,1,227,240,179,373,25,335,335,14,372,226,248,444,104,120,493,179,179,287,508,267,146,257,168,334,508]

theorem envBound12654 : H12AffineFastState.Bounded env12654 := by
  intro p hp
  have h : env12654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12653_12654 : H12AffineEnvironment.transform 9 15 env12653 = env12654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 15 env12653 == env12654) = true)

theorem identity12654 : scanCanonicalize (H12AffineFastState.compose env12654 (packedSelected [0,1,2,4,6,7,15] rootPS)) = affineNative (2^(7+1) ^^^ 30) := by decide +kernel

theorem selectedBound12654 : packedSelected [0,1,2,4,6,7,15] rootPS < 2^1333 := by decide +kernel

def env12655 : List Nat := [2,4,8,16,32,64,128,30,226,15,1,227,240,179,107,25,81,81,14,106,226,248,162,104,120,243,179,179,1,226,21,146,31,168,80,226]

theorem envBound12655 : H12AffineFastState.Bounded env12655 := by
  intro p hp
  have h : env12655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12654_12655 : H12AffineEnvironment.transform 7 30 env12654 = env12655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 30 env12654 == env12655) = true)

theorem identity12655 : scanCanonicalize (H12AffineFastState.compose env12655 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 58) := by decide +kernel

theorem selectedBound12655 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12656 : List Nat := [2,4,8,16,32,58,128,30,152,15,1,153,138,179,17,25,43,43,14,16,152,130,162,18,2,137,179,179,1,152,21,146,31,168,42,152]

theorem envBound12656 : H12AffineFastState.Bounded env12656 := by
  intro p hp
  have h : env12656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12655_12656 : H12AffineEnvironment.transform 5 58 env12655 = env12656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 58 env12655 == env12656) = true)

theorem identity12656 : scanCanonicalize (H12AffineFastState.compose env12656 (packedSelected [1,2,4,6] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound12656 : packedSelected [1,2,4,6] rootPS < 2^1333 := by decide +kernel

def env12657 : List Nat := [2,4,8,16,32,58,25,30,1,15,1,0,19,42,17,25,43,43,14,16,1,27,59,18,2,16,42,42,1,1,21,11,31,49,42,1]

theorem envBound12657 : H12AffineFastState.Bounded env12657 := by
  intro p hp
  have h : env12657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12656_12657 : H12AffineEnvironment.transform 6 25 env12656 = env12657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env12656 == env12657) = true)

theorem identity12657 : scanCanonicalize (H12AffineFastState.compose env12657 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound12657 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12658 : List Nat := [2,4,8,1,32,43,8,15,1,15,1,0,2,42,0,8,43,43,14,1,1,10,42,3,2,1,42,42,1,1,4,11,14,32,42,1]

theorem envBound12658 : H12AffineFastState.Bounded env12658 := by
  intro p hp
  have h : env12658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12657_12658 : H12AffineEnvironment.transform 3 1 env12657 = env12658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env12657 == env12658) = true)

def env12659 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1345,262144,524288,32769,4097,8200,17664,98565,8328,541008,795916,16385,545088,1073741824,1284,4294967296,256,4295074215,1344,512]

theorem envBound12659 : H12AffineFastState.Bounded env12659 := by
  intro p hp
  have h : env12659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12642_12659 : H12AffineEnvironment.transform 16 1345 env12642 = env12659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env12642 == env12659) = true)

theorem identity12659 : scanCanonicalize (H12AffineFastState.compose env12659 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 787457) := by decide +kernel

theorem selectedBound12659 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env12660 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1345,262144,524288,32769,4097,8200,17664,98565,8328,541008,795916,16385,545088,787457,1284,4294967296,256,4295074215,1344,512]

theorem envBound12660 : H12AffineFastState.Bounded env12660 := by
  intro p hp
  have h : env12660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12659_12660 : H12AffineEnvironment.transform 29 787457 env12659 = env12660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 787457 env12659 == env12660) = true)

def env12661 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1345,262144,304168,32769,4097,8200,17664,98565,8328,320888,33060,16385,324968,41001,1284,4294967296,256,4295074215,1344,512]

theorem envBound12661 : H12AffineFastState.Bounded env12661 := by
  intro p hp
  have h : env12661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12660_12661 : H12AffineEnvironment.transform 18 304168 env12660 = env12661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 304168 env12660 == env12661) = true)

theorem identity12661 : scanCanonicalize (H12AffineFastState.compose env12661 (packedSelected [4,9,18] rootPS)) = affineNative (2^(17+1) ^^^ 8460) := by decide +kernel

theorem selectedBound12661 : packedSelected [4,9,18] rootPS < 2^1333 := by decide +kernel

def env12662 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1345,8460,34084,32769,4097,8200,17664,98565,8328,50292,33060,16385,54372,41001,1284,4294967296,256,4295074215,1344,512]

theorem envBound12662 : H12AffineFastState.Bounded env12662 := by
  intro p hp
  have h : env12662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12661_12662 : H12AffineEnvironment.transform 17 8460 env12661 = env12662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8460 env12661 == env12662) = true)

theorem identity12662 : scanCanonicalize (H12AffineFastState.compose env12662 (packedSelected [5,8,13,15,19] rootPS)) = affineNative (2^(15+1) ^^^ 33166) := by decide +kernel

theorem selectedBound12662 : packedSelected [5,8,13,15,19] rootPS < 2^1333 := by decide +kernel

def env12663 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,33166,1345,8460,34084,32769,4097,8200,17664,139,8328,50292,33060,16385,54372,41001,1284,4294967296,256,4294975529,1344,512]

theorem envBound12663 : H12AffineFastState.Bounded env12663 := by
  intro p hp
  have h : env12663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12662_12663 : H12AffineEnvironment.transform 15 33166 env12662 = env12663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33166 env12662 == env12663) = true)

def env12664 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,18376,17990,1345,8460,17132,18377,4097,8200,17664,139,8328,956,18156,16385,5036,26593,1284,4294967296,256,4294975529,1344,512]

theorem envBound12664 : H12AffineFastState.Bounded env12664 := by
  intro p hp
  have h : env12664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12663_12664 : H12AffineEnvironment.transform 14 18376 env12663 = env12664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 18376 env12663 == env12664) = true)

theorem identity12664 : scanCanonicalize (H12AffineFastState.compose env12664 (packedSelected [1,3,10,13] rootPS)) = affineNative (2^(11+1) ^^^ 1725) := by decide +kernel

theorem selectedBound12664 : packedSelected [1,3,10,13] rootPS < 2^1333 := by decide +kernel

def env12665 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1725,8192,16384,18376,17990,1345,8460,17132,18377,1724,8200,17664,139,8328,956,18156,16385,1297,26593,1284,4294967296,256,4294975529,1344,512]

theorem envBound12665 : H12AffineFastState.Bounded env12665 := by
  intro p hp
  have h : env12665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12664_12665 : H12AffineEnvironment.transform 11 1725 env12664 = env12665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1725 env12664 == env12665) = true)

theorem identity12665 : scanCanonicalize (H12AffineFastState.compose env12665 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 1772) := by decide +kernel

theorem selectedBound12665 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env12666 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1725,8192,1772,292,170,1345,8460,1024,293,1724,8200,1004,139,8328,956,0,1773,1297,8461,1284,4294967296,256,4294975529,1344,512]

theorem envBound12666 : H12AffineFastState.Bounded env12666 := by
  intro p hp
  have h : env12666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12665_12666 : H12AffineEnvironment.transform 13 1772 env12665 = env12666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1772 env12665 == env12666) = true)

def env12667 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1725,672,1772,292,170,1345,940,1024,293,1724,680,1004,139,552,956,0,1773,1297,941,1284,4294967296,256,4294967945,1344,512]

theorem envBound12667 : H12AffineFastState.Bounded env12667 := by
  intro p hp
  have h : env12667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12666_12667 : H12AffineEnvironment.transform 12 672 env12666 = env12667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 672 env12666 == env12667) = true)

theorem identity12667 : scanCanonicalize (H12AffineFastState.compose env12667 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 649) := by decide +kernel

theorem selectedBound12667 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12668 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1725,672,1772,292,170,1345,940,1024,293,1724,680,1004,139,552,956,0,1773,1297,941,1284,649,256,0,1344,512]

theorem envBound12668 : H12AffineFastState.Bounded env12668 := by
  intro p hp
  have h : env12668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12667_12668 : H12AffineEnvironment.transform 31 649 env12667 = env12668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 649 env12667 == env12668) = true)

theorem identity12668 : scanCanonicalize (H12AffineFastState.compose env12668 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 428) := by decide +kernel

theorem selectedBound12668 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env12669 : List Nat := [2,4,8,16,32,64,128,256,428,1024,1,1297,268,1344,292,170,1345,0,1024,293,1296,260,64,139,388,16,0,1345,1297,1,1284,293,256,0,1344,428]

theorem envBound12669 : H12AffineFastState.Bounded env12669 := by
  intro p hp
  have h : env12669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12668_12669 : H12AffineEnvironment.transform 8 428 env12668 = env12669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 428 env12668 == env12669) = true)

theorem identity12669 : scanCanonicalize (H12AffineFastState.compose env12669 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound12669 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12670 : List Nat := [2,4,8,16,32,64,128,252,80,1024,1,1261,240,1212,216,170,1213,0,1024,217,1260,248,64,139,120,16,0,1213,1261,1,1272,217,252,0,1212,80]

theorem envBound12670 : H12AffineFastState.Bounded env12670 := by
  intro p hp
  have h : env12670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12669_12670 : H12AffineEnvironment.transform 7 252 env12669 = env12670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env12669 == env12670) = true)

theorem identity12670 : scanCanonicalize (H12AffineFastState.compose env12670 (packedSelected [2,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound12670 : packedSelected [2,4,5] rootPS < 2^1333 := by decide +kernel

def env12671 : List Nat := [2,4,8,16,32,64,89,37,80,1024,1,1076,41,1125,1,115,1124,0,1024,0,1077,33,64,82,120,16,0,1124,1076,1,1057,0,37,0,1125,80]

theorem envBound12671 : H12AffineFastState.Bounded env12671 := by
  intro p hp
  have h : env12671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12670_12671 : H12AffineEnvironment.transform 6 89 env12670 = env12671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env12670 == env12671) = true)

def env12672 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1725,673,1772,292,170,1345,941,1024,293,1724,681,1004,139,553,956,0,1773,1297,940,1284,4294967296,256,4294967944,1344,512]

theorem envBound12672 : H12AffineFastState.Bounded env12672 := by
  intro p hp
  have h : env12672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12666_12672 : H12AffineEnvironment.transform 12 673 env12666 = env12672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 673 env12666 == env12672) = true)

theorem identity12672 : scanCanonicalize (H12AffineFastState.compose env12672 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 428) := by decide +kernel

theorem selectedBound12672 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12673 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1725,673,1772,292,170,1345,941,1024,293,1724,681,1004,139,553,956,0,1773,1297,940,1284,428,256,804,1344,512]

theorem envBound12673 : H12AffineFastState.Bounded env12673 := by
  intro p hp
  have h : env12673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12672_12673 : H12AffineEnvironment.transform 31 428 env12672 = env12673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 428 env12672 == env12673) = true)

def env12674 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1,1589,553,1636,292,34,1345,805,1024,293,1588,545,868,3,553,820,0,1637,1297,804,1284,292,256,804,1344,512]

theorem envBound12674 : H12AffineFastState.Bounded env12674 := by
  intro p hp
  have h : env12674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12673_12674 : H12AffineEnvironment.transform 6 8 env12673 = env12674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env12673 == env12674) = true)

theorem identity12674 : scanCanonicalize (H12AffineFastState.compose env12674 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound12674 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12675 : List Nat := [2,4,8,16,32,64,8,36,512,1024,1,1589,553,1636,0,34,1125,513,1024,1,1588,545,576,3,553,528,0,1637,1077,512,1056,0,36,512,1124,512]

theorem envBound12675 : H12AffineFastState.Bounded env12675 := by
  intro p hp
  have h : env12675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12674_12675 : H12AffineEnvironment.transform 7 36 env12674 = env12675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env12674 == env12675) = true)

theorem identity12675 : scanCanonicalize (H12AffineFastState.compose env12675 (packedSelected [2,4] rootPS)) = affineNative (2^(8+1) ^^^ 81) := by decide +kernel

theorem selectedBound12675 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env12676 : List Nat := [2,4,8,16,32,64,8,36,81,1024,1,1124,120,1077,0,34,1125,80,1024,1,1125,112,17,3,120,65,0,1076,1077,81,1056,0,36,81,1124,81]

theorem envBound12676 : H12AffineFastState.Bounded env12676 := by
  intro p hp
  have h : env12676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12675_12676 : H12AffineEnvironment.transform 8 81 env12675 = env12676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env12675 == env12676) = true)

theorem identity12676 : scanCanonicalize (H12AffineFastState.compose env12676 (packedSelected [5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound12676 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env12677 : List Nat := [2,4,8,16,32,16,8,36,1,1024,1,1076,40,1077,0,34,1077,0,1024,1,1077,32,17,3,40,17,0,1076,1077,1,1056,0,36,1,1076,1]

theorem envBound12677 : H12AffineFastState.Bounded env12677 := by
  intro p hp
  have h : env12677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12676_12677 : H12AffineEnvironment.transform 5 16 env12676 = env12677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env12676 == env12677) = true)

theorem identity12677 : scanCanonicalize (H12AffineFastState.compose env12677 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound12677 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12678 : List Nat := [2,4,8,16,1,16,8,5,1,1024,1,1045,9,1044,0,3,1044,0,1024,1,1044,1,17,3,9,17,0,1045,1044,1,1025,0,5,1,1045,1]

theorem envBound12678 : H12AffineFastState.Bounded env12678 := by
  intro p hp
  have h : env12678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12677_12678 : H12AffineEnvironment.transform 4 1 env12677 = env12678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env12677 == env12678) = true)

def leafEnv12678 : List Nat := [2,4,8,16,1,16,8,5,1,1024,1,1045,9,1044,0,3,1044,0,1024,1,1044,1,17,3,1025,9,1,17,0,1045,1044,1,1025,0,5,1,4,2,1045,1,0,1045,1]

def active12678 : List Nat := [0,1,2,3,9]

def tree12678 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood12678 : H12WitnessSearch.Good tree12678 := H12GlobalWitnessIndex.good

theorem leafIdentity12678 : H12AffineFastState.composeSystem env12678 rootObs = leafEnv12678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env12678 rootObs == leafEnv12678) = true)

theorem terminalChecked12678 : H12PackedTerminal.terminalCheckFast leafEnv12678 active12678 tree12678 = true := by decide +kernel

def env12679 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1,1588,552,1637,292,35,1345,804,1024,293,1589,544,869,2,553,821,0,1636,1297,805,1284,293,256,804,1344,512]

theorem envBound12679 : H12AffineFastState.Bounded env12679 := by
  intro p hp
  have h : env12679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12673_12679 : H12AffineEnvironment.transform 6 9 env12673 = env12679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env12673 == env12679) = true)

theorem identity12679 : scanCanonicalize (H12AffineFastState.compose env12679 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound12679 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12680 : List Nat := [2,4,8,16,32,64,9,256,0,1024,1,1076,40,1125,292,35,1345,292,1024,293,1077,32,357,2,41,309,0,1124,1297,293,1284,293,256,292,1344,0]

theorem envBound12680 : H12AffineFastState.Bounded env12680 := by
  intro p hp
  have h : env12680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12679_12680 : H12AffineEnvironment.transform 8 0 env12679 = env12680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env12679 == env12680) = true)

theorem identity12680 : scanCanonicalize (H12AffineFastState.compose env12680 (packedSelected [2,4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound12680 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env12681 : List Nat := [2,4,8,16,32,17,9,256,0,1024,1,1076,40,1076,292,35,1296,292,1024,293,1077,32,308,2,41,309,0,1077,1297,293,1284,293,256,292,1297,0]

theorem envBound12681 : H12AffineFastState.Bounded env12681 := by
  intro p hp
  have h : env12681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12680_12681 : H12AffineEnvironment.transform 5 17 env12680 = env12681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env12680 == env12681) = true)

theorem identity12681 : scanCanonicalize (H12AffineFastState.compose env12681 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound12681 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12682 : List Nat := [2,4,8,16,32,17,9,4,0,1024,1,1076,40,1076,32,35,1044,32,1024,33,1077,32,48,2,41,49,0,1077,1045,33,1024,33,4,32,1045,0]

theorem envBound12682 : H12AffineFastState.Bounded env12682 := by
  intro p hp
  have h : env12682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12681_12682 : H12AffineEnvironment.transform 7 4 env12681 = env12682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env12681 == env12682) = true)

def leafEnv12682 : List Nat := [2,4,8,16,32,17,9,4,0,1024,1,1076,40,1076,32,35,1044,32,1024,33,1077,32,48,2,1024,41,1,49,0,1077,1045,33,1024,33,4,32,4,35,1045,0,0,1044,1]

def active12682 : List Nat := [0,1,2,3,4,9]

def tree12682 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood12682 : H12WitnessSearch.Good tree12682 := H12GlobalWitnessIndex.good

theorem leafIdentity12682 : H12AffineFastState.composeSystem env12682 rootObs = leafEnv12682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env12682 rootObs == leafEnv12682) = true)

theorem terminalChecked12682 : H12PackedTerminal.terminalCheckFast leafEnv12682 active12682 tree12682 = true := by decide +kernel

def env12683 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,18377,17991,1345,8460,17133,18376,4097,8200,17664,139,8328,957,18157,16385,5037,26592,1284,4294967296,256,4294975529,1344,512]

theorem envBound12683 : H12AffineFastState.Bounded env12683 := by
  intro p hp
  have h : env12683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12663_12683 : H12AffineEnvironment.transform 14 18377 env12663 = env12683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 18377 env12663 == env12683) = true)

theorem identity12683 : scanCanonicalize (H12AffineFastState.compose env12683 (packedSelected [1,3,10,13] rootPS)) = affineNative (2^(13+1) ^^^ 4177) := by decide +kernel

theorem selectedBound12683 : packedSelected [1,3,10,13] rootPS < 2^1333 := by decide +kernel

def env12684 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,4177,6040,5654,1345,8460,4796,6041,4097,8200,5457,139,8328,957,5820,4176,5037,14257,1284,4294967296,256,4294975529,1344,512]

theorem envBound12684 : H12AffineFastState.Bounded env12684 := by
  intro p hp
  have h : env12684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12683_12684 : H12AffineEnvironment.transform 13 4177 env12683 = env12684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env12683 == env12684) = true)

theorem identity12684 : scanCanonicalize (H12AffineFastState.compose env12684 (packedSelected [4,5,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 1724) := by decide +kernel

theorem selectedBound12684 : packedSelected [4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env12685 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1724,8192,1773,292,170,1345,8460,1024,293,1725,8200,1005,139,8328,957,0,1772,1297,8461,1284,4294967296,256,4294975529,1344,512]

theorem envBound12685 : H12AffineFastState.Bounded env12685 := by
  intro p hp
  have h : env12685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12684_12685 : H12AffineEnvironment.transform 11 1724 env12684 = env12685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1724 env12684 == env12685) = true)

def env12686 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1724,672,1773,292,170,1345,940,1024,293,1725,680,1005,139,552,957,0,1772,1297,941,1284,4294967296,256,4294967945,1344,512]

theorem envBound12686 : H12AffineFastState.Bounded env12686 := by
  intro p hp
  have h : env12686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12685_12686 : H12AffineEnvironment.transform 12 672 env12685 = env12686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 672 env12685 == env12686) = true)

theorem identity12686 : scanCanonicalize (H12AffineFastState.compose env12686 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 648) := by decide +kernel

theorem selectedBound12686 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12687 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1724,672,1773,292,170,1345,940,1024,293,1725,680,1005,139,552,957,0,1772,1297,941,1284,648,256,1,1344,512]

theorem envBound12687 : H12AffineFastState.Bounded env12687 := by
  intro p hp
  have h : env12687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12686_12687 : H12AffineEnvironment.transform 31 648 env12686 = env12687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 648 env12686 == env12687) = true)

def env12688 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1,1588,552,1637,292,34,1345,804,1024,293,1589,544,869,3,552,821,0,1636,1297,805,1284,512,256,1,1344,512]

theorem envBound12688 : H12AffineFastState.Bounded env12688 := by
  intro p hp
  have h : env12688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12687_12688 : H12AffineEnvironment.transform 6 8 env12687 = env12688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env12687 == env12688) = true)

theorem identity12688 : scanCanonicalize (H12AffineFastState.compose env12688 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 81) := by decide +kernel

theorem selectedBound12688 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12689 : List Nat := [2,4,8,16,32,64,8,256,81,1024,1,1125,121,1076,292,34,1345,373,1024,293,1124,113,308,3,121,356,0,1077,1297,372,1284,81,256,1,1344,81]

theorem envBound12689 : H12AffineFastState.Bounded env12689 := by
  intro p hp
  have h : env12689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12688_12689 : H12AffineEnvironment.transform 8 81 env12688 = env12689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env12688 == env12689) = true)

theorem identity12689 : scanCanonicalize (H12AffineFastState.compose env12689 (packedSelected [2,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound12689 : packedSelected [2,4,5] rootPS < 2^1333 := by decide +kernel

def env12690 : List Nat := [2,4,8,16,32,17,8,256,0,1024,1,1076,40,1076,292,34,1296,292,1024,293,1077,32,308,3,40,309,0,1077,1297,293,1284,0,256,1,1297,0]

theorem envBound12690 : H12AffineFastState.Bounded env12690 := by
  intro p hp
  have h : env12690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12689_12690 : H12AffineEnvironment.transform 5 17 env12689 = env12690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env12689 == env12690) = true)

theorem identity12690 : scanCanonicalize (H12AffineFastState.compose env12690 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound12690 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12691 : List Nat := [2,4,8,16,32,17,8,4,0,1024,1,1076,40,1076,32,34,1044,32,1024,33,1077,32,48,3,40,49,0,1077,1045,33,1024,0,4,1,1045,0]

theorem envBound12691 : H12AffineFastState.Bounded env12691 := by
  intro p hp
  have h : env12691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12690_12691 : H12AffineEnvironment.transform 7 4 env12690 = env12691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env12690 == env12691) = true)

theorem identity12691 : scanCanonicalize (H12AffineFastState.compose env12691 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound12691 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env12692 : List Nat := [2,4,8,16,1,17,8,4,0,1024,1,1045,9,1045,1,3,1044,1,1024,0,1044,1,17,3,9,16,0,1044,1045,0,1024,0,4,1,1045,0]

theorem envBound12692 : H12AffineFastState.Bounded env12692 := by
  intro p hp
  have h : env12692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12691_12692 : H12AffineEnvironment.transform 4 1 env12691 = env12692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env12691 == env12692) = true)

def leafEnv12692 : List Nat := [2,4,8,16,1,17,8,4,0,1024,1,1045,9,1045,1,3,1044,1,1024,0,1044,1,17,3,1024,9,1,16,0,1044,1045,0,1024,0,4,1,4,2,1045,0,0,1044,1]

def active12692 : List Nat := [0,1,2,3,9]

def tree12692 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood12692 : H12WitnessSearch.Good tree12692 := H12GlobalWitnessIndex.good

theorem leafIdentity12692 : H12AffineFastState.composeSystem env12692 rootObs = leafEnv12692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env12692 rootObs == leafEnv12692) = true)

theorem terminalChecked12692 : H12PackedTerminal.terminalCheckFast leafEnv12692 active12692 tree12692 = true := by decide +kernel

def env12693 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1,1589,553,1636,292,35,1345,805,1024,293,1588,545,868,2,552,820,0,1637,1297,804,1284,513,256,1,1344,512]

theorem envBound12693 : H12AffineFastState.Bounded env12693 := by
  intro p hp
  have h : env12693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12687_12693 : H12AffineEnvironment.transform 6 9 env12687 = env12693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env12687 == env12693) = true)

theorem identity12693 : scanCanonicalize (H12AffineFastState.compose env12693 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound12693 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12694 : List Nat := [2,4,8,16,32,64,9,117,512,1024,1,1589,553,1636,81,35,1076,592,1024,80,1588,545,529,2,552,577,0,1637,1124,593,1137,513,117,1,1077,512]

theorem envBound12694 : H12AffineFastState.Bounded env12694 := by
  intro p hp
  have h : env12694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12693_12694 : H12AffineEnvironment.transform 7 117 env12693 = env12694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env12693 == env12694) = true)

theorem identity12694 : scanCanonicalize (H12AffineFastState.compose env12694 (packedSelected [5] rootPS)) = affineNative (2^(8+1) ^^^ 80) := by decide +kernel

theorem selectedBound12694 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env12695 : List Nat := [2,4,8,16,32,64,9,117,80,1024,1,1125,121,1076,81,35,1076,0,1024,80,1124,113,65,2,120,17,0,1077,1124,1,1137,81,117,1,1077,80]

theorem envBound12695 : H12AffineFastState.Bounded env12695 := by
  intro p hp
  have h : env12695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12694_12695 : H12AffineEnvironment.transform 8 80 env12694 = env12695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 80 env12694 == env12695) = true)

def env12696 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1724,673,1773,292,170,1345,941,1024,293,1725,681,1005,139,553,957,0,1772,1297,940,1284,4294967296,256,4294967944,1344,512]

theorem envBound12696 : H12AffineFastState.Bounded env12696 := by
  intro p hp
  have h : env12696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12685_12696 : H12AffineEnvironment.transform 12 673 env12685 = env12696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 673 env12685 == env12696) = true)

theorem identity12696 : scanCanonicalize (H12AffineFastState.compose env12696 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 429) := by decide +kernel

theorem selectedBound12696 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12697 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1724,673,1773,292,170,1345,941,1024,293,1725,681,1005,139,553,957,0,1772,1297,940,1284,429,256,805,1344,512]

theorem envBound12697 : H12AffineFastState.Bounded env12697 := by
  intro p hp
  have h : env12697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12696_12697 : H12AffineEnvironment.transform 31 429 env12696 = env12697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 429 env12696 == env12697) = true)

theorem identity12697 : scanCanonicalize (H12AffineFastState.compose env12697 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 429) := by decide +kernel

theorem selectedBound12697 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env12698 : List Nat := [2,4,8,16,32,64,128,256,429,1024,1,1297,268,1344,292,170,1345,0,1024,293,1296,260,64,139,388,16,0,1345,1297,1,1284,429,256,136,1344,429]

theorem envBound12698 : H12AffineFastState.Bounded env12698 := by
  intro p hp
  have h : env12698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12697_12698 : H12AffineEnvironment.transform 8 429 env12697 = env12698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 429 env12697 == env12698) = true)

theorem identity12698 : scanCanonicalize (H12AffineFastState.compose env12698 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound12698 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12699 : List Nat := [2,4,8,16,32,64,128,172,1,1024,1,1213,160,1260,136,170,1261,0,1024,137,1212,168,64,139,40,16,0,1261,1213,1,1192,1,172,136,1260,1]

theorem envBound12699 : H12AffineFastState.Bounded env12699 := by
  intro p hp
  have h : env12699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12698_12699 : H12AffineEnvironment.transform 7 172 env12698 = env12699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env12698 == env12699) = true)

theorem identity12699 : scanCanonicalize (H12AffineFastState.compose env12699 (packedSelected [2,4] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound12699 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env12700 : List Nat := [2,4,8,16,32,16,128,172,1,1024,1,1213,160,1212,136,170,1213,0,1024,137,1212,168,16,139,40,16,0,1213,1213,1,1192,1,172,136,1212,1]

theorem envBound12700 : H12AffineFastState.Bounded env12700 := by
  intro p hp
  have h : env12700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12699_12700 : H12AffineEnvironment.transform 5 16 env12699 = env12700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env12699 == env12700) = true)

def env12701 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1345,262144,304169,32769,4097,8200,17664,98565,8328,320889,33061,16385,324969,41000,1284,4294967296,256,4295074215,1344,512]

theorem envBound12701 : H12AffineFastState.Bounded env12701 := by
  intro p hp
  have h : env12701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12660_12701 : H12AffineEnvironment.transform 18 304169 env12660 = env12701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 304169 env12660 == env12701) = true)

theorem identity12701 : scanCanonicalize (H12AffineFastState.compose env12701 (packedSelected [4,9,18] rootPS)) = affineNative (2^(17+1) ^^^ 33061) := by decide +kernel

theorem selectedBound12701 : packedSelected [4,9,18] rootPS < 2^1333 := by decide +kernel

def env12702 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1345,33061,9484,32769,4097,8200,17664,98565,8328,25692,33061,16385,29772,41000,1284,4294967296,256,4295074215,1344,512]

theorem envBound12702 : H12AffineFastState.Bounded env12702 := by
  intro p hp
  have h : env12702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12701_12702 : H12AffineEnvironment.transform 17 33061 env12701 = env12702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 33061 env12701 == env12702) = true)

theorem identity12702 : scanCanonicalize (H12AffineFastState.compose env12702 (packedSelected [20,23] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound12702 : packedSelected [20,23] rootPS < 2^1333 := by decide +kernel

def env12703 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,269,16384,32768,65536,1345,33061,1025,32769,4097,261,17664,98565,389,17745,33061,16385,21825,33061,1284,4294967296,256,4295065770,1344,512]

theorem envBound12703 : H12AffineFastState.Bounded env12703 := by
  intro p hp
  have h : env12703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12702_12703 : H12AffineEnvironment.transform 12 269 env12702 = env12703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env12702 == env12703) = true)

theorem identity12703 : scanCanonicalize (H12AffineFastState.compose env12703 (packedSelected [0,7] rootPS)) = affineNative (2^(13+1) ^^^ 4176) := by decide +kernel

theorem selectedBound12703 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env12704 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,269,4176,32768,65536,1345,33061,1025,32769,4097,261,5456,98565,389,5377,33061,4177,1297,33061,1284,4294967296,256,4295065770,1344,512]

theorem envBound12704 : H12AffineFastState.Bounded env12704 := by
  intro p hp
  have h : env12704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12703_12704 : H12AffineEnvironment.transform 13 4176 env12703 = env12704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env12703 == env12704) = true)

theorem identity12704 : scanCanonicalize (H12AffineFastState.compose env12704 (packedSelected [1,3,5,8,10,13,15] rootPS)) = affineNative (2^(15+1) ^^^ 38423) := by decide +kernel

theorem selectedBound12704 : packedSelected [1,3,5,8,10,13,15] rootPS < 2^1333 := by decide +kernel

def env12705 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,269,4176,32768,38423,1345,33061,1025,32769,4097,261,5456,5906,389,5377,33061,4177,1297,33061,1284,4294967296,256,4294973117,1344,512]

theorem envBound12705 : H12AffineFastState.Bounded env12705 := by
  intro p hp
  have h : env12705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12704_12705 : H12AffineEnvironment.transform 15 38423 env12704 = env12705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38423 env12704 == env12705) = true)

theorem identity12705 : scanCanonicalize (H12AffineFastState.compose env12705 (packedSelected [5,8,10,12,17] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound12705 : packedSelected [5,8,10,12,17] rootPS < 2^1333 := by decide +kernel

def env12706 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,4096,269,4176,32768,38046,1345,33061,1025,32769,4097,261,5456,5531,389,5377,33061,4177,1297,33061,1284,4294967296,256,4294972468,1344,137]

theorem envBound12706 : H12AffineFastState.Bounded env12706 := by
  intro p hp
  have h : env12706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12705_12706 : H12AffineEnvironment.transform 8 137 env12705 = env12706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env12705 == env12706) = true)

theorem identity12706 : scanCanonicalize (H12AffineFastState.compose env12706 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(14+1) ^^^ 293) := by decide +kernel

theorem selectedBound12706 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env12707 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,4096,269,4176,293,5563,1345,0,1025,292,4097,261,5456,5531,389,5377,0,4177,1297,0,1284,4294967296,256,4294972468,1344,137]

theorem envBound12707 : H12AffineFastState.Bounded env12707 := by
  intro p hp
  have h : env12707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12706_12707 : H12AffineEnvironment.transform 14 293 env12706 = env12707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 293 env12706 == env12707) = true)

theorem identity12707 : scanCanonicalize (H12AffineFastState.compose env12707 (packedSelected [1,3,5] rootPS)) = affineNative (2^(11+1) ^^^ 1212) := by decide +kernel

theorem selectedBound12707 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env12708 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,1212,269,1260,293,263,1345,0,1025,292,1213,261,492,295,389,445,0,1261,1297,0,1284,4294967296,256,4294967432,1344,137]

theorem envBound12708 : H12AffineFastState.Bounded env12708 := by
  intro p hp
  have h : env12708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12707_12708 : H12AffineEnvironment.transform 11 1212 env12707 = env12708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1212 env12707 == env12708) = true)

theorem identity12708 : scanCanonicalize (H12AffineFastState.compose env12708 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 217) := by decide +kernel

theorem selectedBound12708 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12709 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,1212,269,1260,293,263,1345,0,1025,292,1213,261,492,295,389,445,0,1261,1297,0,1284,217,256,81,1344,137]

theorem envBound12709 : H12AffineFastState.Bounded env12709 := by
  intro p hp
  have h : env12709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12708_12709 : H12AffineEnvironment.transform 31 217 env12708 = env12709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 217 env12708 == env12709) = true)

def env12710 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,4194304,17665,16777216,8328,541009,5111876,148801,676865,1073741824,17006913,4294967296,132160,4315938986,16876613,512]

theorem envBound12710 : H12AffineFastState.Bounded env12710 := by
  intro p hp
  have h : env12710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12453_12710 : H12AffineEnvironment.transform 22 17665 env12453 = env12710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17665 env12453 == env12710) = true)

def env12711 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,8914000,134217728,8519744,2769921,1073741824,27513920,4294967296,10637633,4315938986,164610305,512]

theorem envBound12711 : H12AffineFastState.Bounded env12711 := by
  intro p hp
  have h : env12711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12207_12711 : H12AffineEnvironment.transform 28 2769921 env12207 = env12711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 28 2769921 env12207 == env12711) = true)

def env12712 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,4194304,8388608,16777216,8328,8914000,134217728,8519744,676865,1073741824,25412672,4294967296,8536385,4315938986,164610305,512]

theorem envBound12712 : H12AffineFastState.Bounded env12712 := by
  intro p hp
  have h : env12712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12711_12712 : H12AffineEnvironment.transform 20 4096 env12711 = env12712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env12711 == env12712) = true)

theorem identity12712 : scanCanonicalize (H12AffineFastState.compose env12712 (packedSelected [14] rootPS)) = affineNative (2^(23+1) ^^^ 230469) := by decide +kernel

theorem selectedBound12712 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env12713 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,4194304,8388608,230469,8328,8914000,134217728,8519744,676865,1073741824,8404997,4294967296,8536385,4299392239,147604804,512]

theorem envBound12713 : H12AffineFastState.Bounded env12713 := by
  intro p hp
  have h : env12713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12712_12713 : H12AffineEnvironment.transform 23 230469 env12712 = env12713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 230469 env12712 == env12713) = true)

def env12714 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,524288,32769,4096,4194304,8388608,98565,8328,8914000,134217728,8389888,545089,1073741824,8404997,4294967296,8406017,4299260335,147604804,512]

theorem envBound12714 : H12AffineFastState.Bounded env12714 := by
  intro p hp
  have h : env12714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12713_12714 : H12AffineEnvironment.transform 16 1344 env12713 = env12714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env12713 == env12714) = true)

theorem identity12714 : scanCanonicalize (H12AffineFastState.compose env12714 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(22+1) ^^^ 17665) := by decide +kernel

theorem selectedBound12714 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env12715 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,524288,32769,4096,4194304,17665,98565,8328,541009,134217728,16385,545089,1073741824,1284,4294967296,256,4299260335,139198533,512]

theorem envBound12715 : H12AffineFastState.Bounded env12715 := by
  intro p hp
  have h : env12715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12714_12715 : H12AffineEnvironment.transform 22 17665 env12714 = env12715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17665 env12714 == env12715) = true)

def env12716 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,16384,32768,65536,1344,262144,524288,32769,1344,4194304,17665,98565,8328,541009,134217728,16385,541697,1073741824,1284,4294967296,256,4299260335,139198533,512]

theorem envBound12716 : H12AffineFastState.Bounded env12716 := by
  intro p hp
  have h : env12716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12715_12716 : H12AffineEnvironment.transform 11 1344 env12715 = env12716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env12715 == env12716) = true)

def env12717 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,32768,65536,1344,262144,524288,32769,1344,4194304,65,98565,8328,525329,134217728,1345,524609,1073741824,1284,4294967296,256,4299260335,139198533,512]

theorem envBound12717 : H12AffineFastState.Bounded env12717 := by
  intro p hp
  have h : env12717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12716_12717 : H12AffineEnvironment.transform 13 1344 env12716 = env12717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env12716 == env12717) = true)

theorem identity12717 : scanCanonicalize (H12AffineFastState.compose env12717 (packedSelected [9,22] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound12717 : packedSelected [9,22] rootPS < 2^1333 := by decide +kernel

def env12718 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1297,32768,65536,1297,262144,524288,32769,1297,4194304,16,98565,8328,525329,134217728,1296,524560,1073741824,1284,4294967296,256,4299260335,139198484,512]

theorem envBound12718 : H12AffineFastState.Bounded env12718 := by
  intro p hp
  have h : env12718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12717_12718 : H12AffineEnvironment.transform 5 17 env12717 = env12718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env12717 == env12718) = true)

def env12719 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1297,32768,65536,1297,262144,524288,32769,1297,4194304,16,98565,8328,525329,4982440,1296,524560,1073741824,1284,4294967296,256,4299260335,1724,512]

theorem envBound12719 : H12AffineFastState.Bounded env12719 := by
  intro p hp
  have h : env12719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12718_12719 : H12AffineEnvironment.transform 26 4982440 env12718 = env12719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 4982440 env12718 == env12719) = true)

end H12CloudChart2